"""
Admin, system configuration, audit, and user management endpoints.
Extracted from main.py (Phase 29 enterprise refactoring).
"""
from __future__ import annotations

import asyncio
from core.table_prefix import prefix_matches, same_prefix
import json
import os
import logging
import uuid
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, HTTPException, Depends, Request, Query, BackgroundTasks
from fastapi.responses import Response as _Resp, StreamingResponse
from pydantic import BaseModel, Field, model_validator

from api.deps import get_current_user, require_admin, require_admin_rate_limited, require_execute_access, require_admin_read
from core.audit import audit_event
from core.execution_state import (
    running_tasks, cancellation_flags, user_query_counts, user_query_lock,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["admin"])


# BF-NONBLOCK-AUDIT-6: every sync DB call inside an
# `async def` route is wrapped via this helper.
async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)

# ── Module-level singletons — populated by set_admin_dependencies() ──────────
_db_manager  = None
_engine      = None
_paths       = None
_qe_cfg      = None
_auth_cfg    = None
_ws_manager  = None


def set_admin_dependencies(db_manager, engine, paths, qe_cfg, auth_cfg, ws_manager):
    """Call once from main.py after all components are initialised."""
    global _db_manager, _engine, _paths, _qe_cfg, _auth_cfg, _ws_manager
    _db_manager = db_manager
    _engine     = engine
    _paths      = paths
    _qe_cfg     = qe_cfg
    _auth_cfg   = auth_cfg
    _ws_manager = ws_manager


# ── Pydantic models ────────────────────────────────────────────────────────────

class WorkerPoolConfigUpdate(BaseModel):
    interactive_max_concurrent:  Optional[int] = None
    interactive_default_timeout: Optional[int] = None
    interactive_max_queue:       Optional[int] = None
    report_max_concurrent:       Optional[int] = None
    report_default_timeout:      Optional[int] = None
    report_max_queue:            Optional[int] = None
    scheduled_max_concurrent:    Optional[int] = None
    scheduled_default_timeout:   Optional[int] = None
    scheduled_max_queue:         Optional[int] = None
    export_max_concurrent:       Optional[int] = None
    export_default_timeout:      Optional[int] = None
    export_max_queue:            Optional[int] = None
    system_max_concurrent:       Optional[int] = None
    system_default_timeout:      Optional[int] = None
    system_max_queue:            Optional[int] = None


class AppConfigUpdateRequest(BaseModel):
    limits:     Optional[dict] = None
    features:   Optional[dict] = None
    s3_results: Optional[dict] = None
    # Phase 140-A — Proxy admin UI.  Until now proxy was config-file-only;
    # admins had to SSH/edit-ConfigMap + restart the backend pod to flip
    # `enabled`.  Surfacing the dict here lets the existing app-config GET/PUT
    # round-trip handle it.  Proxy state is held in module-level singletons
    # used by cached boto3 clients, so changes still need a backend restart
    # — the UI shows a banner explaining this.
    proxy:      Optional[dict] = None
    # BF-273 — Iceberg admin UI.  These were config-file-only until now and
    # are correctness/perf-critical:
    #  - iceberg_mor.enabled: true when tables have V2 delete files (UPDATE /
    #    DELETE / MERGE).  Off → COUNT(DISTINCT) returns deleted rows.
    #  - iceberg.metadata_cache_ttl_seconds: skip full metadata/ prefix scan
    #    on every query
    #  - s3_local_cache.enabled: persistent NFS cache of S3 files (immutable
    #    Iceberg data files round-trip free of charge after first read)
    iceberg:         Optional[dict] = None
    iceberg_mor:     Optional[dict] = None
    s3_local_cache:  Optional[dict] = None
    # BF-275 / Tier 2 — per-Iceberg-table sort columns applied at INSERT.
    # Generic admin-configurable dict: {table_name: [col1, col2, ...]}.
    # Sort-on-write makes file-level min/max bounds non-overlapping for the
    # sort key, multiplying read-side pruning effectiveness.
    iceberg_sort_orders: Optional[dict] = None


class QueueConfigUpdateRequest(BaseModel):
    backend:        Optional[str]  = None
    redis_url:      Optional[str]  = None
    redis_password: Optional[str]  = None
    redis_db:       Optional[int]  = None
    redis_ssl:      Optional[bool] = None
    key_prefix:     Optional[str]  = None
    task_ttl_hours: Optional[int]  = None


class _UserPayload(BaseModel):
    username: str
    password: Optional[str] = None
    role: str = "viewer"


class CacheInvalidateSourceRequest(BaseModel):
    table_name:    Optional[str] = None   # registered table name (e.g. "orders")
    file_prefix:   Optional[str] = None   # S3/local prefix (e.g. "data/orders/")
    connection_id: Optional[int] = None   # invalidate all queries for a connection


class _SubjectExportRequest(BaseModel):
    username: str


class ReplicaConfigUpdate(BaseModel):
    read_preference: str = Field(..., description="One of: primary, replica, primary_preferred")


class HorizontalWorkersConfigUpdate(BaseModel):
    registry_backend:           Optional[str]  = None
    heartbeat_interval_seconds: Optional[int]  = None
    heartbeat_ttl_seconds:      Optional[int]  = None
    worker_eviction_seconds:    Optional[int]  = None
    max_workers_per_host:       Optional[int]  = None
    enable_load_aware_claiming: Optional[bool] = None
    memory_threshold_pct:       Optional[int]  = None
    cpu_threshold_pct:          Optional[int]  = None
    metrics_retention_hours:    Optional[int]  = None


class StreamingConfigUpdate(BaseModel):
    cancel_enabled:              Optional[bool] = None
    max_active_streams:          Optional[int]  = None
    cancel_check_interval_rows:  Optional[int]  = None


class PresignedUrlConfigUpdate(BaseModel):
    expiry_seconds:           Optional[int]  = None
    retry_enabled:            Optional[bool] = None
    max_retries:              Optional[int]  = None
    retry_on_403:             Optional[bool] = None
    retry_delay_seconds:      Optional[int]  = None
    download_timeout_seconds: Optional[int]  = None   # Phase 78G


class S3ValidationConfigUpdate(BaseModel):
    """Phase 78 — runtime config for S3 bucket/ARN validation and safety limits."""
    bucket_name_regex_aws:                   Optional[str]  = None
    bucket_name_regex_onprem:                Optional[str]  = None
    validate_bucket_on_create:               Optional[bool] = None
    validate_arn_format:                     Optional[bool] = None
    arn_regex:                               Optional[str]  = None
    root_prefix_test_on_create:              Optional[bool] = None
    warn_unsupported_partition_ops:          Optional[bool] = None
    max_folder_browser_items:                Optional[int]  = None
    partition_refresh_mutex_timeout_seconds: Optional[int]  = None
    file_list_max_files:                     Optional[int]  = None


class DuckDBConfigUpdate(BaseModel):
    """Phase 79 — runtime config for DuckDB engine resilience."""
    circuit_breaker_enabled: Optional[bool]  = None
    retry_on_engine_error:   Optional[bool]  = None
    retry_max_attempts:      Optional[int]   = None
    retry_delay_seconds:     Optional[float] = None


class QueryGuardrailsConfigUpdate(BaseModel):
    """Phase 96 — runtime config for query builder guardrails."""
    enabled:                    Optional[bool] = None
    max_files_warn:             Optional[int]  = None
    max_files_block:            Optional[int]  = None
    max_rows_warn:              Optional[int]  = None
    max_rows_block:             Optional[int]  = None
    require_partition_filter:   Optional[bool] = None
    warn_no_partition:          Optional[bool] = None
    warn_no_limit:              Optional[bool] = None
    default_limit_suggestion:   Optional[int]  = None


class PublishedViewsConfigUpdate(BaseModel):
    enabled:                     Optional[bool] = None
    max_concurrent:              Optional[int]  = None
    default_cache_ttl_seconds:   Optional[int]  = None
    max_cache_size_mb:           Optional[int]  = None
    default_rate_limit:          Optional[str]  = None
    max_rate_limit:              Optional[str]  = None
    default_row_limit:           Optional[int]  = None
    max_row_limit:               Optional[int]  = None
    access_log_retention_days:   Optional[int]  = None
    cleanup_interval_hours:      Optional[int]  = None
    param_substitution_enabled:  Optional[bool] = None   # Phase 80
    dedup_timeout_seconds:       Optional[int]  = None   # Phase 80
    ad_group_fetch_fail_mode:    Optional[str]  = None   # Phase 83H: "deny" | "allow"


class SmartPredictionsConfigUpdate(BaseModel):
    enabled:                  Optional[bool]  = None
    max_chart_suggestions:    Optional[int]   = None
    max_pivot_suggestions:    Optional[int]   = None
    profile_max_top_values:   Optional[int]   = None
    outlier_method:           Optional[str]   = None
    outlier_iqr_multiplier:   Optional[float] = None
    profile_sample_limit:     Optional[int]   = None
    inline_chart_enabled:     Optional[bool]  = None


class FeedGenerationConfigUpdate(BaseModel):
    enabled:                          Optional[bool] = None
    max_concurrent_native:            Optional[int]  = None
    max_output_rows:                  Optional[int]  = None
    max_file_size_mb:                 Optional[int]  = None
    # A key in `allowed` but NOT here is silently dropped: pydantic discards
    # the unknown field, the route returns 200, and the operator watches a
    # setting refuse to change with no error anywhere.  This product has
    # shipped that exact defect twice (2026-08-23 BQB raw_sql, 2026-09-02
    # two feed fields no handler forwarded) -- the model and the allowlist
    # are two halves of one declaration.
    max_file_size_action:             Optional[str]  = None
    filename_template:                Optional[str]  = None
    auto_route_threshold_rows:        Optional[int]  = None
    retry_max_attempts:               Optional[int]  = None
    retry_delay_seconds:              Optional[int]  = None
    execution_history_retention_days: Optional[int]  = None
    cleanup_interval_hours:           Optional[int]  = None
    chunk_size:                       Optional[int]  = None


# ── Helper functions ───────────────────────────────────────────────────────────

def _dir_extend_span(mt, oldest, newest):
    """Widen an (oldest, newest) mtime span with one more file's mtime."""
    if oldest is None or mt < oldest:
        oldest = mt
    if newest is None or mt > newest:
        newest = mt
    return oldest, newest


def _dir_walk_totals(path: Path):
    """(file count, total bytes, oldest mtime, newest mtime) under ``path``.

    A file whose stat or mtime conversion raises OSError is logged and left
    out of the mtime span — but it has already been counted, exactly as
    before this was extracted.
    """
    count = total = 0
    oldest = newest = None
    for f in path.rglob("*"):
        if not f.is_file():
            continue
        try:
            st = f.stat()
            count += 1
            total += st.st_size
            mt = datetime.fromtimestamp(st.st_mtime, tz=timezone.utc)
            oldest, newest = _dir_extend_span(mt, oldest, newest)
        except OSError as exc:
            logger.debug("Recoverable error: %s", exc, exc_info=True)
    return count, total, oldest, newest


def _dir_stats(path: Path) -> dict:
    """Return file count, total bytes, and oldest/newest mtime for a directory."""
    count = total = 0
    oldest = newest = None
    if path.exists():
        count, total, oldest, newest = _dir_walk_totals(path)
    return {
        "path":       str(path),
        "file_count": count,
        "size_bytes": total,
        "size_mb":    round(total / (1024 * 1024), 2),
        "oldest_file": oldest.isoformat() if oldest else None,
        "newest_file": newest.isoformat() if newest else None,
    }


def _audit(user: dict, action: str, req: Request = None,
           resource_type: str = None, resource_id=None, details: dict = None):
    """Non-blocking audit call — fires in background thread, never raises.

    BF-WS-NOBLOCK-5: delegates to the shared core.audit helper which
    submits to a dedicated audit thread pool, so async route handlers
    don't block the event loop on the DB INSERT.
    """
    try:
        from core.audit import audit_event
        audit_event(_db_manager, user, req, action, resource_type, resource_id, details)
    except Exception as exc:
        logger.warning("Recoverable error: %s", exc, exc_info=True)


def _task_created_at(task: dict):
    """A task's created_at as an aware UTC datetime, or None if unusable."""
    ca = task.get("created_at")
    if not ca:
        return None
    try:
        dt = datetime.fromisoformat(ca)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt
    except Exception:
        return None


def _oldest_age_secs(tasks: list) -> float:
    """Return age in seconds of oldest task by created_at."""
    oldest = None
    for t in tasks:
        dt = _task_created_at(t)
        if dt is not None and (oldest is None or dt < oldest):
            oldest = dt
    if oldest is None:
        return 0.0
    now = datetime.now(timezone.utc)
    return (now - oldest).total_seconds()


async def _scheduler_worker_proxy(method: str, path: str, json_body=None, timeout: float = 10.0):
    """Proxy a request to the scheduler worker's internal HTTP API.

    Used when ``scheduler.mode = "external"`` — the scheduler runs in a
    separate process (``scheduler_worker.py``) and exposes a small FastAPI
    control API on ``scheduler.worker_host:scheduler.worker_port``.
    """
    import httpx
    from core.config import scheduler as _sched_cfg
    url = f"{_sched_cfg.worker_url}{path}"
    try:
        async with httpx.AsyncClient() as client:
            resp = await client.request(method, url, json=json_body, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
    except httpx.ConnectError:
        raise HTTPException(503, "Scheduler worker is not running or unreachable") from None
    except httpx.HTTPStatusError as exc:
        raise HTTPException(exc.response.status_code, exc.response.text)
    except Exception as exc:
        raise HTTPException(503, f"Scheduler worker communication failed: {exc}")


def _parse_pair_list(raw: str, lower_key: bool = False,
                     lower_value: bool = False) -> Dict[str, str]:
    """Parse a ``"k:v,k:v"`` config string into a dict, skipping malformed pairs."""
    out: Dict[str, str] = {}
    for pair in raw.split(","):
        pair = pair.strip()
        if ":" not in pair:
            continue
        k, v = pair.split(":", 1)
        k = k.strip().lower() if lower_key else k.strip()
        v = v.strip().lower() if lower_value else v.strip()
        out[k] = v
    return out


def _update_config_users(username: str, password: Optional[str], role: Optional[str],
                         action: str) -> Dict[str, Any]:
    """Persist a user change through ``config.set()`` (the cross-pod DB
    overlay) so every pod sees it; returns the persistence status.

    2026-09-27: this used to read-modify-write ``backend/config.json`` --
    hard-coded, ignoring ``$QUERYSTUDIO_CONFIG`` -- and ``reload()``.  A user
    added on one pod did not exist on the next, and on a read-only
    ConfigMap mount the write itself failed.  The EFFECTIVE ``auth.local_users``
    / ``auth.user_roles`` strings are read through ``config.get`` (file, env
    and overlay merged), edited, and written back as overlay rows; the
    ``_AuthCfg`` accessors read them back through the same ``get``.

    Actions:
      add          — add local user (username + hashed password + role)
      update       — update local user (password optional, role required)
      remove       — remove local user entirely
      add_role     — add AD user role mapping (no password)
      update_role  — update AD user role mapping
      remove_role  — remove AD user role mapping
    """
    from core import config as _config_mod

    # Parse current EFFECTIVE local_users and user_roles
    users_dict = _parse_pair_list(str(_config_mod.get("auth", "local_users", "") or ""))
    roles_dict = _parse_pair_list(str(_config_mod.get("auth", "user_roles", "") or ""),
                                  lower_key=True, lower_value=True)

    from core.ad_auth import hash_password as _hash_pw

    if action == "add":
        users_dict[username] = _hash_pw(password)
        roles_dict[username.lower()] = role
    elif action == "update":
        if password:
            users_dict[username] = _hash_pw(password)
        roles_dict[username.lower()] = role
    elif action == "remove":
        users_dict.pop(username, None)
        roles_dict.pop(username.lower(), None)
    elif action == "add_role":
        roles_dict[username.lower()] = role
    elif action == "update_role":
        roles_dict[username.lower()] = role
    elif action == "remove_role":
        roles_dict.pop(username.lower(), None)

    result = _persist_config_section("auth", {
        "local_users": ",".join(f"{u}:{p}" for u, p in users_dict.items()),
        "user_roles":  ",".join(f"{u}:{r}" for u, r in roles_dict.items()),
    })
    logger.info("auth users updated (%s %s): persisted=%s",
                action, username, result["persisted"])
    return result


# ── VPC + S3 connectivity check ──────────────────────────────────────────────
# Same 6-layer probe as tools/qs_vpc_check.py (single source of truth in
# core/vpc_check.py).  Two flavours:
#
#   POST /api/admin/vpc-check
#     {bucket, region, vpc_endpoint?, proxy?, profile?, no_creds?,
#      aws_access_key_id?, aws_secret_access_key?, aws_session_token?}
#     Free-form — admin types in any bucket/region/vpce URL.
#
#   POST /api/admin/vpc-check/connection/{connection_id}
#     No body — pulls bucket / region / endpoint_url / creds from the
#     saved S3 connection.  This is the "one click and see what's
#     broken" button on the Connection card.


class _VpcCheckRequest(BaseModel):
    bucket: str
    region: str
    vpc_endpoint: Optional[str] = None
    proxy: Optional[str] = None
    profile: Optional[str] = None
    no_creds: bool = False
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_session_token: Optional[str] = None


@router.post("/api/admin/vpc-check")
async def vpc_check(body: _VpcCheckRequest,
                    _user: dict = Depends(require_admin)):
    """Run the 6-layer VPC + S3 connectivity probe on caller-supplied
    inputs.  Returns the same shape as the CLI's --json output."""
    from core.vpc_check import run_full_check
    report = await _adb(
        run_full_check,
        bucket=body.bucket, region=body.region,
        vpc_endpoint=body.vpc_endpoint, proxy=body.proxy,
        profile=body.profile, no_creds=body.no_creds,
        aws_access_key_id=body.aws_access_key_id,
        aws_secret_access_key=body.aws_secret_access_key,
        aws_session_token=body.aws_session_token,
    )
    return report.to_dict()


def _vpc_portal_credentials(connection_id: int, conn: dict, cfg: dict,
                            username: str, resolved_cfg: Dict[str, Any],
                            creds_source: str):
    """PORTAL layer — STS keys from the system-account / per-user vault.

    ``resolve_s3_credentials`` injects them; ``is_shared`` is spliced in from
    the row.  A failure leaves the caller's config untouched and is logged.
    """
    try:
        from core.credential_manager import get_credential_manager
        cm = get_credential_manager()
        if cm:
            shared_cfg = {**cfg, "is_shared": bool(conn.get("is_shared"))}
            resolved_cfg = cm.resolve_s3_credentials(shared_cfg, username) or dict(cfg)
            creds_source = "portal-resolved"
    except Exception as exc:
        logger.warning(
            "vpc-check: portal credential resolution failed for conn %d: %s",
            connection_id, exc,
        )
    return resolved_cfg, creds_source


async def _vpc_live_handler_credentials(connection_id: int, cfg: dict,
                                        auth_mode: str,
                                        resolved_cfg: Dict[str, Any],
                                        creds_source: str) -> str:
    """LIVE BOTOCORE layer — the keys boto3 would actually send next.

    Ask the cached handler for its botocore Credentials object
    (RefreshableCredentials for assume_role / iam_role).  The frozen
    snapshot gives us (access_key, secret_key, token) regardless of how
    it was acquired.  Mutates ``resolved_cfg`` in place; returns the
    credential source label.
    """
    try:
        from core.connection_manager import get_connection_manager
        _cm_obj = get_connection_manager()
        if _cm_obj is not None:
            _handler = await _adb(_cm_obj._get_s3_handler,
                                   connection_id, cfg)
            _client = getattr(_handler, "s3_client", None)
            if _client is not None:
                # botocore Credentials live on the request signer
                _sig = getattr(_client, "_request_signer", None)
                _creds = getattr(_sig, "_credentials", None) if _sig else None
                if _creds is not None and hasattr(_creds, "get_frozen_credentials"):
                    frozen = _creds.get_frozen_credentials()
                    resolved_cfg["aws_access_key_id"]     = frozen.access_key
                    resolved_cfg["aws_secret_access_key"] = frozen.secret_key
                    resolved_cfg["aws_session_token"]     = frozen.token
                    creds_source = f"live-handler ({auth_mode or 'unknown'})"
    except Exception as exc:
        logger.warning(
            "vpc-check: live-credential extraction failed for conn %d: %s",
            connection_id, exc,
        )
    return creds_source


@router.post("/api/admin/vpc-check/connection/{connection_id}")
async def vpc_check_for_connection(connection_id: int,
                                   _user: dict = Depends(require_admin)):
    """Run the probe against a saved S3 connection.

    Credential resolution mirrors the path the rest of the app uses
    (the cached S3StorageHandler from connection_manager) so portal-auth,
    shared / is_shared, IAM-role, profile, and plain-keys connections
    ALL exercise their real credentials — not just the ``keys`` mode.

    Pre-fix this endpoint read ``aws_access_key_id`` etc. directly from
    the encrypted config, which is empty for portal/iam_role/profile
    modes → boto3 raised ``NoCredentialsError`` on layers 4 + 5 even
    though the same connection executed BQB/CQB queries successfully
    elsewhere in the app.
    """
    from core.vpc_check import run_full_check
    if _db_manager is None:
        raise HTTPException(status_code=500,
                            detail="db_manager not initialised")
    conn = await _adb(_db_manager.get_connection_raw, connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn.get("connection_type") != "s3":
        raise HTTPException(
            status_code=400,
            detail=f"vpc-check only applies to S3 connections, "
                   f"got {conn.get('connection_type')!r}")
    cfg = conn.get("config", {}) or {}
    bucket = (cfg.get("bucket_name") or cfg.get("bucket")
              or cfg.get("s3_bucket") or "")
    from core.s3_storage import resolve_s3_region as _qs_region
    region = _qs_region(cfg)
    if not bucket:
        raise HTTPException(status_code=400,
                            detail="Connection has no bucket_name")

    # ── Credential resolution ────────────────────────────────────────
    # Hand the cached S3StorageHandler's live credentials to
    # run_full_check so every auth mode (portal, keys, iam_role,
    # assume_role, profile) is tested with the SAME credentials the
    # rest of the app uses — not whatever happens to be sitting in
    # the encrypted config dict.
    #
    # Two layers:
    #   1. PORTAL — resolve_s3_credentials injects STS keys derived
    #      from the system-account / per-user vault.  Splice is_shared
    #      in from the row.
    #   2. LIVE BOTOCORE — for every mode, ask the cached handler for
    #      its botocore Credentials object (RefreshableCredentials for
    #      assume_role / iam_role).  Frozen snapshot gives us
    #      (access_key, secret_key, token) — what boto3 would send on
    #      the next request, regardless of how it was acquired.
    auth_mode = (cfg.get("auth_mode") or "").lower()
    username = _user.get("username", "")
    resolved_cfg: Dict[str, Any] = dict(cfg)
    creds_source = "config"

    if auth_mode == "portal":
        resolved_cfg, creds_source = _vpc_portal_credentials(
            connection_id, conn, cfg, username, resolved_cfg, creds_source)

    # Fallback: pull live credentials off the cached handler's session.
    # Works for assume_role + iam_role + profile (where the keys are
    # NEVER in cfg — they live in boto3's RefreshableCredentials).
    if not resolved_cfg.get("aws_access_key_id"):
        creds_source = await _vpc_live_handler_credentials(
            connection_id, cfg, auth_mode, resolved_cfg, creds_source)

    report = await _adb(
        run_full_check,
        bucket=bucket, region=region,
        vpc_endpoint=cfg.get("endpoint_url") or None,
        aws_access_key_id=resolved_cfg.get("aws_access_key_id"),
        aws_secret_access_key=resolved_cfg.get("aws_secret_access_key"),
        aws_session_token=resolved_cfg.get("aws_session_token"),
        profile=resolved_cfg.get("aws_profile"),
    )
    return {**report.to_dict(),
            "connection_id": connection_id,
            "bucket": bucket, "region": region,
            "vpc_endpoint": cfg.get("endpoint_url") or None,
            "auth_mode": auth_mode,
            "credentials_source": creds_source}


# ── Storage management endpoints ───────────────────────────────────────────────

@router.get("/api/admin/storage")
async def get_storage_summary(_user: dict = Depends(require_admin)):
    """Return per-directory disk usage and configured retention settings."""
    import shutil as _shutil
    dirs = {
        "downloads": _paths.downloads_dir,
        "cache":     _paths.data_dir / "cache",
        "parquet":   _paths.parquet_dir,
        "uploads":   _paths.data_dir / "uploads",
    }
    breakdown = {name: _dir_stats(Path(p)) for name, p in dirs.items()}

    try:
        du = _shutil.disk_usage(str(_paths.data_dir))
        disk = {
            "total_gb": round(du.total / (1024 ** 3), 2),
            "used_gb":  round(du.used  / (1024 ** 3), 2),
            "free_gb":  round(du.free  / (1024 ** 3), 2),
            "used_pct": round(du.used  / du.total * 100, 1),
        }
    except Exception as _disk_exc:
        logger.error("Failed to read disk usage: %s", _disk_exc)
        disk = {}

    from core.config import storage as _stg_cfg, scheduler as _sched_cfg
    return {
        "disk": disk,
        "directories": breakdown,
        "settings": {
            "downloads_expiry_days":    _stg_cfg.downloads_expiry_days,
            "execution_retention_days": _sched_cfg.execution_retention_days,
            "max_cache_size_mb":        _stg_cfg.max_cache_size_mb,
            "max_downloads_size_mb":    _stg_cfg.max_downloads_size_mb,
        },
        "tracked_downloads": await _adb(_db_manager.get_downloads_size_bytes) // (1024 * 1024),
    }


@router.post("/api/admin/storage/cleanup")
async def trigger_cleanup(_user: dict = Depends(require_admin)):
    """Manually trigger all cleanup jobs immediately (admin action).

    BF-NONBLOCK-AUDIT: each cleanup function does sync FS iteration + DB
    DELETEs that can take 10-60s on busy systems.  Each is wrapped in
    asyncio.to_thread + 30s wait_for so a slow one doesn't block the API
    worker thread.  On per-fn timeout we record the timeout and continue
    with the next one.
    """
    from core.scheduler import _cleanup_temp_files, _enforce_storage_quotas, _cleanup_execution_history
    results = {}
    for name, fn in [
        ("temp_files",        _cleanup_temp_files),
        ("storage_quotas",    _enforce_storage_quotas),
        ("execution_history", _cleanup_execution_history),
    ]:
        try:
            await asyncio.wait_for(asyncio.to_thread(fn), timeout=30.0)
            results[name] = "ok"
        except asyncio.TimeoutError:
            results[name] = "timeout (>30s) — still running in background; check next sweep"
        except Exception as exc:
            results[name] = str(exc)
    _audit(_user, "manual_storage_cleanup", None, details=results)
    logger.info("Manual storage cleanup triggered by %s: %s", (_user or {}).get("username", "guest"), results)
    return {"status": "completed", "results": results}


# ── Active queries / user stats ────────────────────────────────────────────────

def _active_live_execution_ids() -> set:
    """Execution ids actually running now — worker pool plus legacy globals."""
    try:
        from core.worker_pool import get_pool
        _pool_tasks = get_pool().get_active_tasks()
        live_ids = {t["execution_id"] for t in _pool_tasks if t.get("execution_id")}
    except RuntimeError:
        live_ids = set()
    # Also check legacy globals (for anything not yet migrated)
    live_ids |= (
        {eid for eid, task in running_tasks.items() if not task.done()} |
        set(cancellation_flags.keys())
    )
    return live_ids


async def _active_backfill_live_rows(live_ids, db_rows: dict, now) -> None:
    """Add DB records for live tasks the status batch missed.

    Was an N+1 loop: one get_execution() per missing live id.  Now a single
    WHERE execution_id IN (...) query regardless of how many live tasks exist.
    """
    missing = [eid for eid in live_ids if eid not in db_rows]
    if not missing:
        return
    live_db_map = await _adb(_db_manager.get_executions_by_ids, missing)
    for eid in missing:
        if eid in live_db_map:
            db_rows[eid] = live_db_map[eid]
        else:
            # Task exists in memory but no DB record yet — synthesise a minimal row
            db_rows[eid] = {
                "execution_id":     eid,
                "status":           "processing",
                "started_at":       now.isoformat(),
                "executed_by":      None,
                "chunks_processed": 0,
                "query_config":     {},
            }


def _active_connection_label(cid) -> str:
    """A connection's display name, falling back to ``#id`` when unreadable."""
    try:
        c = _db_manager.get_connection_raw(cid)
        return c.get("name", f"#{cid}") if c else f"#{cid}"
    except Exception:
        return f"#{cid}"


def _active_duration_seconds(started, now) -> int:
    """Seconds a still-running execution has been going; 0 when unparseable."""
    try:
        dt = datetime.fromisoformat(started)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return int((now - dt).total_seconds())
    except Exception:
        return 0


@router.get("/api/admin/active-queries")
async def get_active_queries(_user: dict = Depends(require_admin)):
    """Return all currently running/pending executions with live duration and connection info.

    Source of truth is running_tasks (in-memory), not DB status — the DB record
    may still show 'pending' while the background task is already executing.
    """
    now = datetime.now(timezone.utc)

    # 1. Live execution IDs — from pool + legacy globals.
    live_ids = _active_live_execution_ids()

    # 2. DB rows for pending/processing (catches tasks not yet in running_tasks).
    # Cap each status batch at 200 — the UI table is a live-monitor, not an
    # archive, and 200/status keeps the response under ~50KB even on busy
    # clusters.  Was 500 each = up to 1000 rows transferred per 30s poll.
    db_rows: dict = {}
    for status in ("processing", "pending"):
        for r in await _adb(_db_manager.list_executions, limit=200, status=status):
            db_rows[r["execution_id"]] = r

    # 3. Bulk-fetch DB records for any live task not captured by the status batch.
    # Was an N+1 loop: one get_execution() per missing live id.  Now a single
    # WHERE execution_id IN (...) query regardless of how many live tasks exist.
    await _active_backfill_live_rows(live_ids, db_rows, now)

    conn_cache: dict = {}

    def _conn_name(cid):
        if cid is None:
            return None
        if cid not in conn_cache:
            conn_cache[cid] = _active_connection_label(cid)
        return conn_cache[cid]

    enriched = []
    for r in db_rows.values():
        started = r.get("started_at")
        duration_s = _active_duration_seconds(started, now) if started else 0

        qcfg    = r.get("query_config") or {}
        conn_id = qcfg.get("connection_id") or r.get("connection_id")

        enriched.append({
            **r,
            "duration_seconds": duration_s,
            "connection_name":  _conn_name(conn_id),
            "task_alive":       r["execution_id"] in live_ids,
        })

    enriched.sort(key=lambda x: x["duration_seconds"], reverse=True)
    return enriched


@router.get("/api/admin/executions/{execution_id}/stage")
async def get_execution_stage_breakdown(
    execution_id: str,
    _user: dict = Depends(require_admin),
):
    """BF-PRUNE-PERF — live per-step timing breakdown for a running query.

    Returns:
      {
        "execution_id":   "...",
        "current_stage":  "file_prune",         # or null when not tracked
        "stage_label":    "Pruning files (...)",
        "stage_elapsed":  23.4,                  # seconds in current stage
        "stages":         [                      # all stages including in-flight
          {"stage": "metadata_read",  "duration_seconds": 1.2,  ...},
          {"stage": "manifest_prune", "duration_seconds": 3.4,  ...},
          {"stage": "file_prune",     "duration_seconds": 23.4, "in_flight": true},
        ],
        "extras":         {                      # iceberg cache-hit, manifest count, ...
          "iceberg_meta_seconds__claudestore.fins.fact_table": 0.2,
          "iceberg_manifests_seconds__claudestore.fins.fact_table": 14.8,
          "iceberg_cache_hit__claudestore.fins.fact_table": true,
        },
        "files_done":     3032,
        "files_total":    14025,
      }

    Polled by Admin > Active Queries detail panel; also useful for
    curl/jq diagnostics during a slow query:

      curl -u admin:... .../api/admin/executions/{id}/stage | jq '.stages[]'
    """
    try:
        from core.execution_stage import (
            get_snapshot as _get_snap,
            get_stage_history as _get_hist,
        )
    except Exception:
        return {"execution_id": execution_id, "tracked": False,
                "reason": "execution_stage module not available"}

    snap = _get_snap(execution_id)
    if not snap:
        return {"execution_id": execution_id, "tracked": False,
                "reason": "no live tracker (execution finished or never started)"}
    history = _get_hist(execution_id)
    return {
        "execution_id":   execution_id,
        "tracked":        True,
        "current_stage":  snap.get("stage"),
        "stage_label":    snap.get("stage_label"),
        "stage_elapsed":  snap.get("stage_elapsed_seconds"),
        "files_done":     snap.get("files_done"),
        "files_total":    snap.get("files_total"),
        "bytes_done":     snap.get("bytes_done"),
        "throughput_bps": snap.get("throughput_bytes_per_sec"),
        "message":        snap.get("message"),
        "stages":         history,
        "extras":         snap.get("extras") or {},
    }


@router.get("/api/admin/executions/{execution_id}/logs")
async def get_execution_log_lines(
    execution_id: str,
    limit: int = Query(default=200, ge=1, le=1000),
    _user: dict = Depends(require_admin),
):
    """BF-PRUNE-PERF — return the per-execution log buffer for diagnostics.

    Backend logs include EVERY execution + scheduler + agent + admin
    line, which makes finding "what happened to MY query" hard.  This
    endpoint returns ONLY records produced inside the ContextVar-bound
    scope of this execution_id — usually 50-300 lines for a typical
    Iceberg query, far less than the full server log.

    Returns:
      {
        "execution_id": "...",
        "tracked":      true,
        "count":        47,
        "lines":        [
          {"_mt": ..., "ts": "2026-05-07T12:00:06,768",
           "level": "INFO", "logger": "core.iceberg_reader",
           "message": "Iceberg V2: 11 data manifests, ...",
           "file": "...", "line": 1872},
          ...
        ]
      }

    Use cases:
      curl -u admin:... .../api/admin/executions/{id}/logs | jq '.lines[-20:]'
      → just the last 20 log lines from this query

      curl ... | jq '.lines[] | select(.level=="WARNING")'
      → all warnings (often the most actionable lines)
    """
    try:
        from core.execution_log_buffer import peek as _peek, buffer_size as _bsize
    except Exception:
        return {"execution_id": execution_id, "tracked": False,
                "reason": "execution_log_buffer module not available"}
    lines = _peek(execution_id, limit=limit)
    return {
        "execution_id":   execution_id,
        "tracked":        bool(_bsize(execution_id) > 0 or lines),
        "count":          len(lines),
        "lines":          lines,
    }


@router.get("/api/admin/user-stats")
async def get_user_stats(_user: dict = Depends(require_admin)):
    """Per-user query activity: active now, completed today, last seen.

    Date-filters at the DB level via ``started_after=today_start`` instead of
    pulling 2,000 unfiltered rows and filtering in Python — was a 10s-poll
    hot path, now scans only today's rows.
    """
    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)

    # Today's executions only — the cap of 2000 is now a safety upper bound,
    # not the working-set size.  Typical orgs see <500/day per user.
    all_today = await _adb(_db_manager.list_executions, limit=2000, started_after=today_start)
    user_map: dict = {}

    for r in all_today:
        row = _user_stats_row(user_map, r.get("executed_by") or "guest")
        # Already filtered to today at the DB layer — no need to re-parse + re-compare.
        row["queries_today"] += 1
        if r.get("status") == "failed":
            row["failed_today"] += 1
        started = r.get("started_at")
        if started and (row["last_seen"] is None or started > row["last_seen"]):
            row["last_seen"] = started

    # Overlay live active counts
    with user_query_lock:
        for uname, cnt in user_query_counts.items():
            _user_stats_row(user_map, uname)["active_now"] = cnt
    _overlay_waiting_now(user_map)

    return sorted(user_map.values(), key=lambda x: x["active_now"], reverse=True)


def _user_stats_row(user_map: dict, username: str) -> dict:
    """The ``/api/admin/user-stats`` row for ``username``, created empty on
    first sight (every overlay -- today's runs, live slots, waiters -- may be
    the first to see a user)."""
    row = user_map.get(username)
    if row is None:
        row = {"username": username, "queries_today": 0, "last_seen": None,
               "active_now": 0, "failed_today": 0}
        user_map[username] = row
    return row


def _overlay_waiting_now(user_map: dict) -> None:
    """2026-10-07: how many of each user's runs are WAITING for a slot (their
    own per-user queue + the pod-wide fair queue at the global cap).
    Observability only -- an unavailable queue manager leaves the rows
    without ``waiting_now`` rather than failing the route."""
    try:
        from core.query_queue import get_queue_manager
        for uname, n in get_queue_manager().waiting_by_user().items():
            _user_stats_row(user_map, uname)["waiting_now"] = n
    except Exception as _wq_exc:
        logger.debug("user-stats: waiting counts unavailable: %s", _wq_exc)


def _eta_row_matches_connection(row: dict, connection_id: Optional[int]) -> bool:
    """Decide whether one completed execution belongs to ``connection_id``.

    ``connection_id is None`` means "no filter", so every row matches.
    """
    if connection_id is None:
        return True
    qcfg = row.get("query_config") or {}
    if isinstance(qcfg, str):
        try:
            qcfg = json.loads(qcfg)
        except Exception:
            qcfg = {}
    if not isinstance(qcfg, dict):
        return False
    # Compare as int — stored value may be str or int
    try:
        return int(qcfg.get("connection_id", -1)) == int(connection_id)
    except (ValueError, TypeError):
        return False


def _eta_duration_seconds(started_at, completed_at) -> Optional[float]:
    """Wall-clock seconds for one execution, or None when unusable.

    Unusable = unparseable timestamps, or an outlier longer than an hour.
    """
    try:
        dt_s = datetime.fromisoformat(started_at)
        dt_c = datetime.fromisoformat(completed_at)
        if dt_s.tzinfo is None:
            dt_s = dt_s.replace(tzinfo=timezone.utc)
        if dt_c.tzinfo is None:
            dt_c = dt_c.replace(tzinfo=timezone.utc)
        secs = (dt_c - dt_s).total_seconds()
        if 0 < secs < 3600:  # ignore outliers > 1hr
            return secs
        return None
    except Exception:
        return None


def _eta_collect_durations(recent: list, connection_id: Optional[int]) -> list:
    """Usable durations from recent completed executions, in row order."""
    durations = []
    for r in recent:
        s = r.get("started_at")
        c = r.get("completed_at")
        if not s or not c:
            continue
        # Filter by connection if requested
        if not _eta_row_matches_connection(r, connection_id):
            continue
        secs = _eta_duration_seconds(s, c)
        if secs is not None:
            durations.append(secs)
    return durations


@router.get("/api/admin/query-eta")
async def get_query_eta(connection_id: Optional[int] = None,
                        _user: dict = Depends(get_current_user)):
    """Return estimated execution time (seconds) based on recent completed executions.
    Optionally scoped to a specific connection_id for a more accurate estimate.
    """
    try:
        recent = await _adb(_db_manager.list_executions, limit=200, status="completed")
        durations = _eta_collect_durations(recent, connection_id)
        if not durations:
            return {"avg_seconds": None, "sample_count": 0, "connection_id": connection_id}
        durations.sort()
        p75_idx = int(len(durations) * 0.75)
        avg = sum(durations) / len(durations)
        p75 = durations[min(p75_idx, len(durations) - 1)]
        return {
            "avg_seconds":  round(avg, 1),
            "p75_seconds":  round(p75, 1),
            "min_seconds":  round(min(durations), 1),
            "max_seconds":  round(max(durations), 1),
            "sample_count": len(durations),
            "connection_id": connection_id,
        }
    except Exception as exc:
        logger.error("query-eta failed: %s", exc, exc_info=True)
        return {"avg_seconds": None, "sample_count": 0, "connection_id": connection_id}


def _cancel_queued_wait(execution_id: str) -> None:
    """BF-585 (2026-05-29): cancel a queue-waiting execution first.

    If the query is sitting in the per-user queue (BF-584), it
    has no worker_pool task and no cancel_event yet — only the
    queue cancel event can abort the wait.
    """
    try:
        from api.execute_api import cancel_queued_execution as _cancel_queued
        if _cancel_queued(execution_id):
            logger.info(
                "BF-585 admin cancel: aborted queued wait for %s",
                execution_id,
            )
    except Exception:
        pass  # not in queue — fall through to normal cancel


def _cancel_running_task(execution_id: str) -> None:
    """Cancel through the worker pool, falling back to the legacy globals."""
    from core.worker_pool import get_pool
    try:
        get_pool().cancel_by_execution_id(execution_id)
    except RuntimeError:
        cancel_event = cancellation_flags.get(execution_id)
        if cancel_event:
            cancel_event.set()
        task = running_tasks.get(execution_id)
        if task and not task.done():
            task.cancel()


@router.delete("/api/admin/queries/{execution_id}")
async def admin_cancel_execution(execution_id: str, _user: dict = Depends(require_admin)):
    """Admin-level cancel — no ownership check. Uses same cancel machinery."""
    try:
        execution = await _adb(_db_manager.get_execution, execution_id)
        if not execution:
            raise HTTPException(status_code=404, detail="Execution not found")
        if execution.get("status") not in ("pending", "processing"):
            return {"execution_id": execution_id,
                    "message": f"Already {execution.get('status')}"}

        _cancel_queued_wait(execution_id)
        _cancel_running_task(execution_id)

        cancelled_by = (_user or {}).get("username", "admin")
        await _adb(_db_manager.update_execution, execution_id, status="cancelled",
                                     error_message=f"Cancelled by admin: {cancelled_by}")
        _cancel_target = execution.get("executed_by") or cancelled_by
        await _ws_manager.broadcast_to_user(_cancel_target, {
            "type":         "execution_cancelled",
            "execution_id": execution_id,
            "cancelled_by": cancelled_by,
            "timestamp":    datetime.now(timezone.utc).isoformat(),
        })
        _audit(_user, "admin_cancel_query", None, "execution", execution_id,
               {"cancelled_user": execution.get("executed_by")})
        return {"execution_id": execution_id, "message": "Cancelled by admin"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ── Worker Pool admin endpoints ────────────────────────────────────────────────

@router.get("/api/admin/worker-pool")
async def admin_worker_pool_stats(_user: dict = Depends(require_admin)):
    """Pool stats: by-type counts, queue depth, avg wait/run times."""
    from core.worker_pool import get_pool
    try:
        return get_pool().get_stats()
    except RuntimeError:
        return {"error": "Worker pool not initialised"}


@router.get("/api/admin/worker-pool/tasks")
async def admin_worker_pool_tasks(
    work_type: Optional[str] = None,
    _user: dict = Depends(require_admin),
):
    """All active tasks, optionally filtered by work type."""
    from core.worker_pool import get_pool, WorkType
    try:
        pool = get_pool()
    except RuntimeError:
        return []
    wt = None
    if work_type:
        try:
            wt = WorkType[work_type.upper()]
        except KeyError:
            raise HTTPException(status_code=400, detail=f"Invalid work_type: {work_type}")
    return pool.get_active_tasks(wt)


@router.get("/api/admin/worker-pool/history")
async def admin_worker_pool_history(
    limit: int = 100,
    work_type: Optional[str] = None,
    _user: dict = Depends(require_admin),
):
    """Recent completed/failed/cancelled tasks (newest first)."""
    from core.worker_pool import get_pool, WorkType
    try:
        pool = get_pool()
    except RuntimeError:
        return []
    wt = None
    if work_type:
        try:
            wt = WorkType[work_type.upper()]
        except KeyError:
            raise HTTPException(status_code=400, detail=f"Invalid work_type: {work_type}")
    return pool.get_task_history(limit=min(limit, 500), work_type=wt)


@router.post("/api/admin/worker-pool/tasks/{task_id}/cancel")
async def admin_worker_pool_cancel(task_id: str, _user: dict = Depends(require_admin)):
    """Cancel any task by its internal task_id."""
    from core.worker_pool import get_pool
    try:
        pool = get_pool()
    except RuntimeError:
        raise HTTPException(status_code=500, detail="Worker pool not initialised")
    if not pool.cancel(task_id):
        raise HTTPException(status_code=404, detail="Task not found or already completed")
    cancelled_by = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, cancelled_by, "cancel_pool_task", resource_type="task", resource_id=task_id)
    return {"task_id": task_id, "message": "Cancelled"}


@router.get("/api/admin/worker-pool/config")
async def admin_worker_pool_config(_user: dict = Depends(require_admin)):
    """Return current worker pool configuration."""
    from core.worker_pool import get_pool
    try:
        return get_pool().get_config()
    except RuntimeError:
        raise HTTPException(status_code=500, detail="Worker pool not initialised")


def _worker_pool_type_config(prefix: str, cur: dict, updates: dict, TypeConfig):
    """Build the new TypeConfig for one work type, or None when unchanged.

    Range checks fire only for a type the request actually touches, so an
    untouched type with a legacy out-of-range value is not a 400.
    """
    mc = updates.get(f"{prefix}_max_concurrent",  cur["max_concurrent"])
    dt = updates.get(f"{prefix}_default_timeout", cur["default_timeout"])
    mq = updates.get(f"{prefix}_max_queue",       cur["max_queue"])
    if mc == cur["max_concurrent"] and dt == cur["default_timeout"] and mq == cur["max_queue"]:
        return None
    if mc < 1:
        raise HTTPException(400, f"{prefix}_max_concurrent must be >= 1")
    if dt < 10:
        raise HTTPException(400, f"{prefix}_default_timeout must be >= 10")
    if mq < 1:
        raise HTTPException(400, f"{prefix}_max_queue must be >= 1")
    return TypeConfig(mc, dt, mq)


@router.put("/api/admin/worker-pool/config")
async def admin_worker_pool_reconfigure(req: WorkerPoolConfigUpdate, _user: dict = Depends(require_admin)):
    """Hot-reconfigure worker pool limits. Running tasks are NOT affected."""
    from core.worker_pool import get_pool, WorkType, TypeConfig
    try:
        pool = get_pool()
    except RuntimeError:
        raise HTTPException(status_code=500, detail="Worker pool not initialised")

    current = pool.get_config()["types"]
    updates = req.model_dump(exclude_none=True)
    if not updates:
        return {"message": "No changes", "changes": {}}

    # Build new TypeConfig for each type that has changes
    _TYPE_MAP = {
        "interactive": WorkType.INTERACTIVE, "report": WorkType.REPORT,
        "scheduled":   WorkType.SCHEDULED,   "export": WorkType.EXPORT,
        "system":      WorkType.SYSTEM,
    }
    new_cfgs: dict = {}
    for prefix, wt in _TYPE_MAP.items():
        changed = _worker_pool_type_config(prefix, current[wt.name], updates,
                                           TypeConfig)
        if changed is not None:
            new_cfgs[wt] = changed

    changes = pool.reconfigure(new_cfgs)

    # BF-412: persist via the shared helper so the write is atomic
    # (temp-file + os.replace) AND off the event loop (asyncio.to_thread).
    try:
        await asyncio.to_thread(_persist_config_section, "worker_pool", updates)
    except Exception as e:
        logger.warning("Could not persist worker pool config: %s", e)

    changed_by = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, changed_by, "reconfigure_worker_pool", resource_type="worker_pool",
                      details={"changes": changes, "updates": updates})
    return {"message": "Reconfigured", "changes": changes}


# ── Shared config-write helper ────────────────────────────────────────────────
# 2026-09-27 -- EVERY admin config write goes through ``core.config.set()``,
# the DB overlay (system_settings ``config.<section>.<key>``) that
# ``config.get()`` / ``get_section()`` consult FIRST on every pod.
#
# Until today five route families did a read-modify-write of a POD-LOCAL
# config.json instead (BF-390/398: fail-closed read + atomic write, then
# ``reload()``).  That was correct on one pod and wrong on a fleet: only the
# pod that took the PUT changed, the others kept the old value until they
# restarted -- and a restart re-read whatever the mount said.  Two of the
# five (this helper and the local-user writer) wrote ``backend/config.json``
# even when ``$QUERYSTUDIO_CONFIG`` pointed the loader at another file.  On
# the read-only ConfigMap mount a production pod runs with, every one of
# them answered 500.  Record: docs/PROD_CONFIG_DEPLOYMENT_PLAN_2026_09_27.html
# section 1.2.
#
# The DB overlay wins over the file and the env on every pod (that is its
# contract, core/config.py above ``get()``), so an admin's write is visible
# fleet-wide within _RUNTIME_OVERLAY_TTL_S and survives restarts.  A write
# that could NOT reach the DB is still applied in-process and REPORTED
# (``persisted`` in the response), never silent: "saved" and "saved here
# only" are different facts.


def _persist_config_section(section: str, updates: dict) -> Dict[str, Any]:
    """Write every ``updates`` key of ``section`` through ``config.set()``.

    Returns ``{"persisted": <status>, "keys": [...]}`` where status is one
    of ``core.config.SET_PERSISTED_DB`` (every pod converges),
    ``SET_IN_PROCESS_ONLY`` (no DB wired -- tests / standalone) or
    ``SET_DB_WRITE_FAILED`` (this pod only; other pods keep the old value).
    The worst status across the keys is reported.  Never touches a file.
    """
    from core import config as _cfg
    order = (_cfg.SET_PERSISTED_DB, _cfg.SET_IN_PROCESS_ONLY,
             _cfg.SET_DB_WRITE_FAILED)
    worst = _cfg.SET_PERSISTED_DB
    for k, v in updates.items():
        status = _cfg.set(section, k, v)
        if order.index(status) > order.index(worst):
            worst = status
    return {"persisted": worst, "keys": sorted(updates)}


def _replace_config_section(section: str, new_values: dict) -> Dict[str, Any]:
    """Make ``section`` equal to ``new_values`` as far as the overlay can.

    Every key in ``new_values`` is set.  Every key currently EFFECTIVE in the
    section but absent from ``new_values`` has its overlay row deleted
    (``config.set(section, key, None)``) -- which restores the file/default
    value, if the reviewed config file carries one.  A key the file holds
    cannot be removed from a UI; it must be removed from the file.  The
    response names such keys under ``kept_by_config_file`` so the operator
    is told rather than left to discover it.
    """
    from core import config as _cfg
    result = _persist_config_section(section, new_values)
    current = _cfg.get_section(section) or {}
    kept = []
    for key in list(current):
        if key in new_values:
            continue
        _cfg.set(section, key, None)
        still = _cfg.get_section(section) or {}
        if key in still:
            kept.append(key)
    result["kept_by_config_file"] = sorted(kept)
    return result


def _worst_persist_status(statuses) -> str:
    """The least-good of several ``config.set()`` statuses (db < in_process
    < db_write_failed); ``db`` when nothing was written."""
    from core import config as _cfg
    order = (_cfg.SET_PERSISTED_DB, _cfg.SET_IN_PROCESS_ONLY,
             _cfg.SET_DB_WRITE_FAILED)
    worst = _cfg.SET_PERSISTED_DB
    for s in statuses:
        if order.index(s) > order.index(worst):
            worst = s
    return worst


def _persist_message(status: str, ok_message: str) -> str:
    """The message a route returns: the good one, or the honest one."""
    from core import config as _cfg
    if status == _cfg.SET_DB_WRITE_FAILED:
        return (ok_message + " on THIS pod only -- the system_settings write "
                "failed, other pods keep the previous value until it succeeds "
                "or they restart (see the server log)")
    if status == _cfg.SET_IN_PROCESS_ONLY:
        return ok_message + " (in-process only: no database wired)"
    return ok_message


# ── Result Cache (Option D) ───────────────────────────────────────────────────
# BF-382 — Repeat-query result cache (L1 in-memory + L2 on-disk parquet).
# All admin endpoints are gated by require_admin.


class ResultCacheConfigUpdate(BaseModel):
    enabled:             Optional[bool]   = None
    max_entries_l1:      Optional[int]    = None
    max_size_gb_l2:      Optional[float]  = None
    default_ttl_seconds: Optional[int]    = None
    max_result_mb:       Optional[int]    = None
    skip_patterns:       Optional[List[str]] = None


@router.get("/api/admin/result-cache/stats")
async def admin_result_cache_stats(_user: dict = Depends(require_admin)):
    """Hit-rate, entry counts (L1+L2), evictions, rejections."""
    try:
        from core.result_cache import get_result_cache
        rc = get_result_cache()
        if rc is None:
            return {"enabled": False, "message": "Result cache disabled"}
        return {"enabled": True, **rc.stats()}
    except Exception as e:
        logger.exception("result-cache stats failed")
        raise HTTPException(500, f"Stats unavailable: {e}")


@router.get("/api/admin/result-cache/entries")
async def admin_result_cache_entries(limit: int = 50,
                                       _user: dict = Depends(require_admin)):
    """List cached entries (newest first) with SQL preview + TTL remaining."""
    try:
        from core.result_cache import get_result_cache
        rc = get_result_cache()
        if rc is None:
            return {"enabled": False, "entries": []}
        return {"enabled": True, "entries": rc.list_entries(limit=limit)}
    except Exception as e:
        logger.exception("result-cache entries failed")
        raise HTTPException(500, f"Listing unavailable: {e}")


@router.post("/api/admin/result-cache/clear")
async def admin_result_cache_clear(_user: dict = Depends(require_admin_rate_limited)):
    """Drop ALL cached results (L1 + L2).  Audit-logged."""
    try:
        from core.result_cache import get_result_cache
        rc = get_result_cache()
        if rc is None:
            raise HTTPException(400, "Result cache is not enabled")
        removed = rc.clear()
        await _adb(_db_manager.audit,
                   (_user or {}).get("username", "admin"),
                   "result_cache_clear",
                   resource_type="result_cache",
                   details={"removed": removed})
        return {"message": "Cleared", "removed": removed}
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("result-cache clear failed")
        raise HTTPException(500, f"Clear failed: {e}")


@router.delete("/api/admin/result-cache/entries/{key}")
async def admin_result_cache_invalidate(key: str,
                                          _user: dict = Depends(require_admin)):
    """Drop a single cached entry by its cache key."""
    try:
        from core.result_cache import get_result_cache
        rc = get_result_cache()
        if rc is None:
            raise HTTPException(400, "Result cache is not enabled")
        ok = rc.invalidate(key)
        if not ok:
            raise HTTPException(404, "Entry not found")
        await _adb(_db_manager.audit,
                   (_user or {}).get("username", "admin"),
                   "result_cache_invalidate",
                   resource_type="result_cache",
                   details={"key": key})
        return {"message": "Invalidated", "key": key}
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("result-cache invalidate failed")
        raise HTTPException(500, f"Invalidate failed: {e}")


@router.get("/api/admin/result-cache/config")
async def admin_result_cache_get_config(_user: dict = Depends(require_admin)):
    """Return current result-cache config (from config.json)."""
    from core.config import get_section as _cfg_section
    rc_cfg = _cfg_section("result_cache") or {}
    return {
        "enabled":             bool(rc_cfg.get("enabled", True)),
        "cache_dir":           rc_cfg.get("cache_dir", ""),
        "max_entries_l1":      int(rc_cfg.get("max_entries_l1", 100)),
        "max_size_gb_l2":      float(rc_cfg.get("max_size_gb_l2", 10)),
        "default_ttl_seconds": int(rc_cfg.get("default_ttl_seconds", 3600)),
        "max_result_mb":       int(rc_cfg.get("max_result_mb", 100)),
        "skip_patterns":       list(rc_cfg.get("skip_patterns") or []),
    }


@router.put("/api/admin/result-cache/config")
async def admin_result_cache_set_config(req: ResultCacheConfigUpdate,
                                          _user: dict = Depends(require_admin)):
    """Update result-cache config keys.  Changes persist to config.json
    and apply on next process restart for max_entries_l1 / cache_dir;
    enabled / TTL / size cap take effect immediately."""
    updates = req.model_dump(exclude_none=True)
    if not updates:
        return {"message": "No changes"}
    try:
        _persist_config_section("result_cache", updates)
        # Hot-apply where possible
        try:
            from core.result_cache import get_result_cache, reset_result_cache
            reset_result_cache()
            get_result_cache()  # re-init under new config
        except Exception as _hot_err:
            logger.debug("Result cache hot-reload skipped: %s", _hot_err)
        await _adb(_db_manager.audit,
                   (_user or {}).get("username", "admin"),
                   "result_cache_reconfigure",
                   resource_type="result_cache",
                   details={"updates": updates})
        return {"message": "Updated", "updates": updates}
    except Exception as e:
        logger.exception("result-cache config update failed")
        raise HTTPException(500, f"Update failed: {e}")


# ── Multi-Worker Query Execution (Option F) ───────────────────────────────────
# BF-383 — Splits large queries across N parallel DuckDB workers.


class MultiWorkerConfigUpdate(BaseModel):
    enabled:              Optional[bool] = None
    max_workers:          Optional[int]  = None
    min_files_to_split:   Optional[int]  = None
    max_files_per_worker: Optional[int]  = None
    fallback_on_error:    Optional[bool] = None
    executor_mode:        Optional[str]  = None   # 'thread' | 'subprocess'
    # Phase 141 / 143 — broadcast-JOIN knobs.  Were missing from the admin
    # endpoint so admins had to edit config.json + restart to flip them.
    allow_broadcast_join:     Optional[bool] = None
    broadcast_max_rows:       Optional[int]  = None
    broadcast_max_small_files: Optional[int] = None
    # Phase 144 — partition-aligned JOIN (big × big without Spark)
    allow_partition_aligned_join: Optional[bool] = None


@router.get("/api/admin/multi-worker/config")
async def admin_multi_worker_get_config(_user: dict = Depends(require_admin)):
    from core.config import get_section as _cfg_section
    mw = _cfg_section("multi_worker") or {}
    return {
        "enabled":              bool(mw.get("enabled", True)),
        "max_workers":          int(mw.get("max_workers", 4)),
        "min_files_to_split":   int(mw.get("min_files_to_split", 50)),
        "max_files_per_worker": int(mw.get("max_files_per_worker", 5000)),
        "fallback_on_error":    bool(mw.get("fallback_on_error", True)),
        "executor_mode":        str(mw.get("executor_mode", "thread")),
        # Phase 141 / 143 — broadcast-JOIN admin surface
        "allow_broadcast_join":     bool(mw.get("allow_broadcast_join", True)),
        "broadcast_max_rows":       int(mw.get("broadcast_max_rows", 10_000_000)),
        "broadcast_max_small_files": int(mw.get("broadcast_max_small_files", 50)),
        # Phase 144 — partition-aligned JOIN admin surface
        "allow_partition_aligned_join": bool(mw.get("allow_partition_aligned_join", True)),
    }


@router.put("/api/admin/multi-worker/config")
async def admin_multi_worker_set_config(req: MultiWorkerConfigUpdate,
                                          _user: dict = Depends(require_admin)):
    updates = req.model_dump(exclude_none=True)
    if not updates:
        return {"message": "No changes"}
    # Validate executor_mode
    em = updates.get("executor_mode")
    if em is not None and em not in ("thread", "subprocess"):
        raise HTTPException(400, "executor_mode must be 'thread' or 'subprocess'")
    if updates.get("max_workers") is not None and updates["max_workers"] < 1:
        raise HTTPException(400, "max_workers must be >= 1")
    try:
        _persist_config_section("multi_worker", updates)
        await _adb(_db_manager.audit,
                   (_user or {}).get("username", "admin"),
                   "multi_worker_reconfigure",
                   resource_type="multi_worker",
                   details={"updates": updates})
        return {"message": "Updated", "updates": updates}
    except Exception as e:
        logger.exception("multi-worker config update failed")
        raise HTTPException(500, f"Update failed: {e}")


@router.get("/api/admin/multi-worker/stats")
async def admin_multi_worker_stats(_user: dict = Depends(require_admin)):
    """Per-process dispatch counters (best-effort)."""
    try:
        from core.multi_worker_executor import get_dispatch_stats
        return get_dispatch_stats()
    except ImportError:
        return {"enabled": False, "submitted": 0, "succeeded": 0,
                "failed": 0, "fell_back": 0, "single_worker_fallbacks": 0}
    except Exception as e:
        logger.exception("multi-worker stats failed")
        raise HTTPException(500, f"Stats unavailable: {e}")


@router.get("/api/admin/multi-worker/history")
async def admin_multi_worker_history(limit: int = 50,
                                       _user: dict = Depends(require_admin)):
    """Recent dispatches (newest first) — ring buffer of last 100."""
    try:
        from core.multi_worker_executor import get_dispatch_history
        return {"entries": get_dispatch_history(limit=limit)}
    except ImportError:
        return {"entries": []}
    except Exception as e:
        logger.exception("multi-worker history failed")
        raise HTTPException(500, f"History unavailable: {e}")


@router.get("/api/admin/multi-worker/active")
async def admin_multi_worker_active(_user: dict = Depends(require_admin)):
    """BF-405: live worker state — what every in-flight chunk is doing
    RIGHT NOW.  Admin UI polls this every 1-2s to render a live grid.
    Terminal states (completed/failed/cancelled) stay visible for 60s
    then are garbage-collected."""
    try:
        from core.multi_worker_executor import get_active_workers
        return {"workers": get_active_workers()}
    except ImportError:
        return {"workers": []}
    except Exception as e:
        logger.exception("multi-worker active workers failed")
        raise HTTPException(500, f"Active workers unavailable: {e}")


class MultiWorkerSplitTestRequest(BaseModel):
    sql:        str
    file_count: int = 100


@router.post("/api/admin/multi-worker/test-split")
async def admin_multi_worker_test_split(req: MultiWorkerSplitTestRequest,
                                          _user: dict = Depends(require_admin)):
    """Dry-run: would this SQL split?  Returns the SplitPlan summary
    without executing anything.  Useful for admins to validate a query
    pattern before flipping a feature flag in production."""
    try:
        from core.query_splitter import decide_split
        from core.config import get_section as _cfg_section
        mw = _cfg_section("multi_worker") or {}
        # Synthetic file list — paths don't matter for splittability check
        fake_files = [f"f{i}.parquet" for i in range(max(0, int(req.file_count)))]
        plan = decide_split(
            req.sql,
            fake_files,
            max_workers=int(mw.get("max_workers", 4)),
            min_files_to_split=int(mw.get("min_files_to_split", 50)),
            max_files_per_worker=int(mw.get("max_files_per_worker", 5000)),
        )
        return {
            "splittable":      bool(plan.splittable),
            "skip_reason":     plan.skip_reason or "",
            "chunk_count":     len(plan.chunks),
            "merge_strategy":  plan.merge_strategy or "",
            "partial_sql":     plan.partial_sql,
            "needs_fallback":  bool(plan.merge_metadata.get("needs_fallback", False)),
        }
    except Exception as e:
        logger.exception("multi-worker test-split failed")
        raise HTTPException(500, f"Test failed: {e}")


# ── Multi-Pod (Option G) ──────────────────────────────────────────────────────


class MultiPodConfigUpdate(BaseModel):
    enabled:           Optional[bool] = None
    worker_urls:       Optional[List[str]] = None
    k8s_service:       Optional[str] = None
    k8s_service_port:  Optional[int] = None
    worker_port:       Optional[int] = None
    shared_secret:     Optional[str] = None
    per_worker_timeout_seconds: Optional[int] = None
    fallback_on_error: Optional[bool] = None
    # BF-393 — SQL-connector parallelism config (Snowflake/Trino/Starburst/etc)
    sql_connector_enabled:           Optional[bool] = None
    sql_connector_shard_count:       Optional[int] = None
    sql_connector_shard_strategy:    Optional[str] = None
    sql_connector_default_shard_column: Optional[str] = None


@router.get("/api/admin/multi-pod/config")
async def admin_multi_pod_get_config(_user: dict = Depends(require_admin)):
    from core.config import get_section as _cfg_section
    cfg = _cfg_section("multi_pod") or {}
    # Don't echo shared_secret in plaintext — return whether it's set instead
    return {
        "enabled":           bool(cfg.get("enabled", True)),
        "worker_urls":       list(cfg.get("worker_urls") or []),
        "k8s_service":       str(cfg.get("k8s_service", "") or ""),
        "k8s_service_port":  int(cfg.get("k8s_service_port", 8000) or 8000),
        "worker_port":       int(cfg.get("worker_port", 8000) or 8000),
        "shared_secret_set": bool(cfg.get("shared_secret") or os.environ.get("QS_WORKER_SECRET")),
        "per_worker_timeout_seconds": int(cfg.get("per_worker_timeout_seconds", 1800) or 1800),
        "fallback_on_error": bool(cfg.get("fallback_on_error", True)),
        # BF-393 — SQL-connector sharding
        "sql_connector_enabled":           bool(cfg.get("sql_connector_enabled", False)),
        "sql_connector_shard_count":       int(cfg.get("sql_connector_shard_count", 4) or 4),
        "sql_connector_shard_strategy":    str(cfg.get("sql_connector_shard_strategy", "bucket") or "bucket"),
        "sql_connector_default_shard_column": str(cfg.get("sql_connector_default_shard_column", "") or ""),
    }


@router.put("/api/admin/multi-pod/config")
async def admin_multi_pod_set_config(req: MultiPodConfigUpdate,
                                       _user: dict = Depends(require_admin)):
    updates = req.model_dump(exclude_none=True)
    if not updates:
        return {"message": "No changes"}
    try:
        _persist_config_section("multi_pod", updates)
        await _adb(_db_manager.audit,
                   (_user or {}).get("username", "admin"),
                   "multi_pod_reconfigure",
                   resource_type="multi_pod",
                   details={"updates_keys": list(updates.keys())})  # don't log secret value
        return {"message": "Updated", "updates_keys": list(updates.keys())}
    except Exception as e:
        logger.exception("multi-pod config update failed")
        raise HTTPException(500, f"Update failed: {e}")


class SqlConnectorShardDryRun(BaseModel):
    """BF-393 — payload for the dry-run shard preview endpoint."""
    sql:             str
    connector_type:  str
    shard_count:     int = 4
    shard_strategy:  str = "bucket"
    shard_column:    str
    shard_bounds:    Optional[List[List[Any]]] = None     # for range strategy


@router.post("/api/admin/multi-pod/sql-shard-dry-run")
async def admin_multi_pod_sql_shard_dry_run(
    req: SqlConnectorShardDryRun,
    _user: dict = Depends(require_admin),
):
    """Preview the shard SQL that would be sent to each worker pod for a
    given (sql, connector, shard config) — WITHOUT actually executing any
    of it.  Used by admins to validate their shard column choice and
    confirm the predicate looks reasonable.

    Returns the SqlShardPlan as a dict: splittable, skip_reason, shards
    (each with shard_index + partial_sql + predicate), merge_strategy.
    """
    from core.sql_connector_splitter import decide_sql_connector_split
    bounds = None
    if req.shard_bounds:
        bounds = [tuple(b) for b in req.shard_bounds]
    plan = decide_sql_connector_split(
        req.sql,
        shard_count=int(req.shard_count),
        shard_strategy=req.shard_strategy,
        shard_column=req.shard_column,
        connector_type=req.connector_type,
        shard_bounds=bounds,
    )
    return {
        "splittable":      plan.splittable,
        "skip_reason":     plan.skip_reason,
        "shard_strategy":  plan.shard_strategy,
        "shard_column":    plan.shard_column,
        "merge_strategy":  plan.merge_strategy,
        "shards": [
            {
                "shard_index": s.shard_index,
                "predicate":   s.predicate,
                "partial_sql": s.partial_sql,
            }
            for s in plan.shards
        ],
    }


@router.get("/api/admin/multi-pod/pods")
async def admin_multi_pod_list_pods(_user: dict = Depends(require_admin)):
    """List discovered worker pods + health probe results.

    2026-09-15: also reports the HONEST state -- ``state`` is
    ``disabled`` | ``inert`` | ``active``; when inert, ``reason`` says which
    discovery strategy failed and why, and ``remedy`` what to set.  An
    operator can tell "configured and working" from "configured and inert"
    without reading a DEBUG log.
    """
    try:
        from core.multi_pod_dispatcher import multi_pod_state
        _mp_state = multi_pod_state()
        pods = list(_mp_state.get("pods") or [])
        # Probe each for health.
        # BF-599h (2026-05-31): the previous serial requests.get() loop
        # blocked the event loop for ~3s per pod (timeout) × N pods.
        # With 10 pods that's 30s of total loop freeze on each admin
        # poll.  Now: probe each pod concurrently via asyncio.to_thread
        # so the event loop stays responsive.  All probes complete in
        # ~3s wall (max single probe), not 30s serialised.
        import requests as _requests

        def _probe_one(url: str) -> Dict[str, Any]:
            entry = {"url": url, "alive": False, "last_request": 0, "error": None}
            try:
                r = _requests.get(f"{url}/api/worker/health", timeout=3)
                if r.status_code == 200:
                    entry["alive"] = True
                    entry["last_request"] = r.json().get("last_request", 0)
                else:
                    entry["error"] = f"HTTP {r.status_code}"
            except Exception as probe_err:
                entry["error"] = str(probe_err)[:200]
            return entry

        results = await asyncio.gather(
            *[asyncio.to_thread(_probe_one, url) for url in pods],
            return_exceptions=False,
        )
        return {
            "pods": list(results), "count": len(results),
            "state": _mp_state.get("state"),
            "configured_enabled": _mp_state.get("configured_enabled"),
            "strategy": _mp_state.get("strategy"),
            "secret_configured": _mp_state.get("secret_configured"),
            "reason": _mp_state.get("reason"),
            "remedy": _mp_state.get("remedy"),
        }
    except Exception as e:
        logger.exception("multi-pod pods listing failed")
        raise HTTPException(500, f"Listing failed: {e}")


# ── Engine Router ─────────────────────────────────────────────────────────────


class EngineRouterConfigUpdate(BaseModel):
    enabled:        Optional[bool] = None
    default_engine: Optional[str] = None
    rules:          Optional[List[Dict[str, Any]]] = None


@router.get("/api/admin/engine-router/config")
async def admin_engine_router_get_config(_user: dict = Depends(require_admin)):
    from core.config import get_section as _cfg_section
    from core.engine_router import DEFAULT_RULES, ALL_ENGINES
    cfg = _cfg_section("engine_router") or {}
    return {
        "enabled":         bool(cfg.get("enabled", True)),
        "default_engine":  str(cfg.get("default_engine", "single")),
        "rules":           list(cfg.get("rules") or []),
        "default_rules":   DEFAULT_RULES,
        "available_engines": list(ALL_ENGINES),
    }


@router.put("/api/admin/engine-router/config")
async def admin_engine_router_set_config(req: EngineRouterConfigUpdate,
                                           _user: dict = Depends(require_admin)):
    from core.engine_router import ALL_ENGINES
    updates = req.model_dump(exclude_none=True)
    if not updates:
        return {"message": "No changes"}
    if "default_engine" in updates and updates["default_engine"] not in ALL_ENGINES:
        raise HTTPException(400, f"default_engine must be one of {ALL_ENGINES}")
    try:
        _persist_config_section("engine_router", updates)
        await _adb(_db_manager.audit,
                   (_user or {}).get("username", "admin"),
                   "engine_router_reconfigure",
                   resource_type="engine_router",
                   details={"updates": updates})
        return {"message": "Updated", "updates": updates}
    except Exception as e:
        logger.exception("engine router config update failed")
        raise HTTPException(500, f"Update failed: {e}")


@router.get("/api/admin/engine-router/history")
async def admin_engine_router_history(limit: int = 50,
                                        _user: dict = Depends(require_admin)):
    """Recent routing decisions (newest first)."""
    try:
        from core.engine_router import get_decision_history
        return {"entries": get_decision_history(limit=limit)}
    except Exception as e:
        logger.exception("engine router history failed")
        raise HTTPException(500, f"History unavailable: {e}")


# ── Phase 155/156 -- brain telemetry endpoints ─────────────────────────────


@router.get("/api/admin/brain/telemetry")
async def admin_brain_telemetry(_user: dict = Depends(require_admin)):
    """Phase 156 (2026-06-25) -- single endpoint that returns the brain's
    full operational picture: sql-cache + prewarm + pruning memo + route
    history.  Powers the admin "Brain" panel.  Fail-OPEN per section so
    one bad sub-telemetry doesn't break the chip."""
    out: dict = {}
    try:
        from core.agg_cache import get_brain_cache_stats as _bc_stats
        out["sql_cache"] = _bc_stats()
    except Exception as exc:
        out["sql_cache"] = {"error": str(exc)[:200]}
    try:
        from core import brain_prewarm as _pw
        out["prewarm"] = {
            "enabled":           _pw.enabled(),
            "top_n":             _pw.top_n(),
            "throttle_seconds":  _pw.throttle_seconds(),
            # Phase 156 R23 -- public accessor, no longer the
            # underscore-prefixed internal.
            "in_flight_keys":    _pw.in_flight_count(),
        }
    except Exception as exc:
        out["prewarm"] = {"error": str(exc)[:200]}
    try:
        from core.brain_pruning_memo import get_stats as _mem_stats
        out["pruning_memo"] = _mem_stats()
    except Exception as exc:
        out["pruning_memo"] = {"error": str(exc)[:200]}
    try:
        from core.brain_route_history import get_recent as _rh_recent, enabled as _rh_enabled
        out["route_history"] = {
            "enabled": _rh_enabled(),
            "recent":  _rh_recent(limit=20),
        }
    except Exception as exc:
        out["route_history"] = {"error": str(exc)[:200]}
    return out


@router.get("/api/admin/brain/route-history")
async def admin_brain_route_history(limit: int = 50,
                                     _user: dict = Depends(require_admin)):
    """Phase 156.3 -- recent route outcomes.  Lets operators see which
    SQL shapes have evidence of local-vs-Spark performance."""
    # Phase 156 R3 -- bound the limit so an admin URL probe can't ask
    # for a million rows and pressure the DB.  500 is plenty for the
    # paginated chip + UI.
    bounded = max(1, min(int(limit or 50), 500))
    try:
        from core.brain_route_history import get_recent
        return {"entries": get_recent(limit=bounded)}
    except Exception as e:
        logger.exception("brain route history failed")
        raise HTTPException(500, f"Route history unavailable: {e}")


@router.post("/api/admin/brain/cleanup-tick")
async def admin_brain_cleanup_tick(_user: dict = Depends(require_admin)):
    """Phase 156 -- force a brain cleanup sweep without waiting for the
    6h cron.  Useful for ops drills and post-deploy sanity checks.
    2026-10-07: runs in the OWNING process through _bg_run_now."""
    return await _bg_run_now("brain_cleanup_daemon", legacy_shape="spread")


# ── Per-query diagnostic (2026-06-03) ──────────────────────────────────────
#
# User pain: "we should have querywise diagnostic ... rather than going here
# n there".  These two endpoints collapse engine_router decisions +
# multi_worker dispatch history + active worker state + iceberg cache state
# + scan_strategy config into ONE response keyed on execution_id, plus a
# heuristic classifier that flags the likely bottleneck (10 rules).
#
# See backend/core/query_diagnostic.py for the aggregator + classifier.


@router.get("/api/admin/queries/diagnose/recent")
async def admin_queries_diagnose_recent(limit: int = 10,
                                          _user: dict = Depends(require_admin)):
    """Last N queries with their full diagnostic + bottleneck hints.

    Returns the newest queries first (de-duped by execution_id).  Each
    entry is the same shape as ``/queries/diagnose/{execution_id}``.

    Use this when you don't remember the execution_id of the slow
    query — call it right after running the query.
    """
    try:
        from core.query_diagnostic import diagnose_recent
        return {"queries": diagnose_recent(limit=int(limit))}
    except Exception as exc:
        logger.exception("query_diagnostic recent failed")
        raise HTTPException(500, f"diagnose_recent failed: {exc}")


@router.get("/api/admin/system-resources")
async def admin_system_resources(_user: dict = Depends(require_admin)):
    """Live system resource snapshot — what the admission check sees.

    Operators hit this BEFORE running a heavy query to know whether
    the box has enough RAM, or AFTER a slow query to confirm the
    auto-throttle decision was reasonable.

    Returns:
      {
        ram_mb_total, ram_mb_available, ram_mb_used,
        cpu_count, cpu_load_pct, source: "psutil"|"procfs"|"config_fallback"
      }
    """
    try:
        from core.resource_admission import get_system_resources
        res = get_system_resources()
        from dataclasses import asdict
        return asdict(res)
    except Exception as exc:
        logger.exception("system_resources probe failed")
        raise HTTPException(500, f"resource probe failed: {exc}")


def _validate_pruning_probe(connection_id, bucket: str, table_prefix: str,
                            filters) -> None:
    """Refuse a probe request that cannot identify a table or its filters."""
    if not connection_id:
        raise HTTPException(400, "connection_id is required (used to resolve S3 auth)")
    if not bucket or not table_prefix:
        raise HTTPException(400, "bucket + table_prefix are required (get them from Admin → Connections → Tables)")
    if not isinstance(filters, list):
        raise HTTPException(400, "filters must be a list")
    for f in filters:
        if not isinstance(f, dict) or "column" not in f or "operator" not in f:
            raise HTTPException(400, f"filter entry missing column/operator: {f!r}")


def _pruning_probe_refusal_status(exc: BaseException):
    """400 for a refusal the caller can act on; None when it is not one.

    ``PruningProbeRefusal`` (core.pruning_probe) and ``TruncatedScanRefusal``
    (a listing over its budget) already carry their sentence.  A botocore
    ``ClientError`` is S3's own verdict on the request (NoSuchBucket,
    AccessDenied, 403) -- the source judged it, so it is a 400 with that
    sentence rather than a 500 the chokepoint erases.  Transport failures
    (EndpointConnectionError, timeouts) are NOT ClientError and fall through
    to the seam, which classifies them 503.
    """
    from core.pruning_probe import PruningProbeRefusal
    if isinstance(exc, PruningProbeRefusal):
        return 400
    try:
        from core.scan_truncation import TruncatedScanRefusal
        if isinstance(exc, TruncatedScanRefusal):
            return 400
    except Exception:                                       # noqa: BLE001
        pass
    try:
        from botocore.exceptions import ClientError
        if isinstance(exc, ClientError):
            return 400
    except Exception:                                       # noqa: BLE001
        pass
    return None


@router.post("/api/admin/queries/pruning-probe")
async def admin_pruning_probe(body: dict, _user: dict = Depends(require_admin)):
    """Standalone pruning probe (2026-06-04).

    User pain: "I have partition filter + bucketing + column stats but
    still see 3000+ files post-prune — I don't know how to validate
    pruning is working."  Solution: a probe endpoint that takes
    (connection_id + table OR bucket+prefix, filters) and returns the
    pruner's verdict WITHOUT running the heavy query.  Iterate on the
    filter shape, see file counts drop in real time, then re-run the
    real query when the math is right.

    Body:
      {
        "connection_id": int (required), # used to resolve S3 auth
        "bucket":        str (required),
        "table_prefix":  str (required),
        "table_name":    str (optional, used for column-stats lookup),
        "filters": [                     # list of WHERE clauses
          {"column": str, "operator": str, "value": Any},
          ...
        ],
        "force_fresh": bool (optional),  # bypass snapshot pointer cache
        "format": "iceberg"|"parquet"    # (optional) only for a prefix with NO
                                         # registration; a registered table's
                                         # declared format always wins
      }

    FB-43 (2026-09-20): the branch is the table's DECLARED format.  A hive
    parquet table is listed and pruned by path segments (the query path's
    own chokepoint); an Iceberg table goes through the reader.  Counts the
    branch cannot know are null, not 0: for Iceberg the before-count is the
    snapshot's total-data-files and per-stage drops are not recorded.

    Returns:
      {
        "files_before_prune": int,
        "files_after_prune":  int,
        "pct_pruned":         float,
        "stage_drops": {
          "partition":   int,
          "column_stats":int,
          "supplement":  int,
          "bloom":       int,
        },
        "filter_breakdown": [
          {"column": str, "operator": str, "value": Any,
           "support": "supported"|"weak"|"unsupported"|"unknown",
           "support_reason": str}, ...
        ],
        "source": "cache"|"s3_fallback",
        "cache_hit": bool,
        "manifests_attempted": int,
        "manifests_succeeded": int,
        "metadata_seconds": float,
        "manifests_seconds": float,
        "snapshot_id": str,
      }
    """
    def _do():
        connection_id = body.get("connection_id")
        bucket        = (body.get("bucket") or "").strip()
        table_prefix  = (body.get("table_prefix") or "").strip()
        table_name    = body.get("table_name")
        filters       = body.get("filters") or []
        force_fresh   = bool(body.get("force_fresh", False))
        req_format    = body.get("format")

        _validate_pruning_probe(connection_id, bucket, table_prefix, filters)

        # FB-43 (2026-09-20): the branch is the table's DECLARED format
        # (registered_tables[].format on the connection) -- a hive parquet
        # table used to be pushed through the Iceberg reader and answered
        # 500 "No Iceberg metadata JSON found".  core.pruning_probe owns the
        # dispatch and both branches; this route resolves the connection,
        # the S3 client, and the HTTP status of a refusal.
        from core.pruning_probe import run_pruning_probe
        from core.s3_utilities import make_s3_client_for_conn
        # 2026-09-01 -- ``core.database`` exposes ``get_db_manager()``;
        # there is no module-level ``db_manager``.  This import is NOT inside
        # a try, so the endpoint raised ImportError on every call.
        from core.database import get_db_manager as _get_dbm
        _dbm = _get_dbm()
        conn_raw = _dbm.get_connection_raw(int(connection_id))
        if not conn_raw:
            raise HTTPException(404, f"connection {connection_id} not found")
        s3_client = make_s3_client_for_conn(conn_raw)

        return run_pruning_probe(
            conn_raw=conn_raw, s3_client=s3_client, db_manager=_dbm,
            connection_id=int(connection_id), bucket=bucket,
            table_prefix=table_prefix, filters=filters, table_name=table_name,
            force_fresh=force_fresh, requested_format=req_format,
        )

    try:
        return await asyncio.to_thread(_do)
    except HTTPException:
        raise
    except Exception as exc:
        # A refusal with a reason (wrong declared format, an unregistered
        # prefix with no metadata, a listing over budget, S3 itself judging
        # the request: NoSuchBucket / AccessDenied) is the caller's to fix
        # -- 400 carrying the sentence.  A source that could not be reached
        # is the seam's 503.  Only the honest residue stays a 500.
        _status = _pruning_probe_refusal_status(exc)
        if _status is not None:
            raise HTTPException(_status, str(exc)) from exc
        from api.connector_errors import raise_if_source_error
        raise_if_source_error(exc, "s3", context="pruning_probe failed")
        logger.exception("pruning_probe failed")
        raise HTTPException(500, f"pruning_probe failed: {exc}")


@router.get("/api/admin/queries/pruning-history")
async def admin_pruning_history(
    execution_id: Optional[str] = None,
    bucket:       Optional[str] = None,
    limit:        int           = 100,
    _user:        dict          = Depends(require_admin),
):
    """Recent pruning rows from query_pruning_history table (2026-06-04).

    Returns one row per iceberg_reader call: files_before/after, per-stage
    drop counts (partition / column_stats / supplement / bloom),
    per-WHERE-clause breakdown with operator-level prune-support
    classification.  Use this to debug 'why is this query scanning so
    many files?' against historical baselines.

    Filter options:
      * execution_id — drill into ONE query (1-3 rows usually)
      * bucket       — all queries against this S3 bucket
      * limit        — cap response (default 100, max 1000)

    2026-10-08 -- ``writer`` is the writer thread's ledger IN THIS PROCESS
    (enqueued / written / dropped_queue_full / failed / skipped_*, the last
    error, worker_alive): an empty ``rows`` with ``writer.counters.failed``
    > 0 is a dead writer, not a quiet table.  Every process that runs a
    query has its own writer; the per-process view of any pod is
    ``GET /api/admin/background-jobs/pruning_history_writer/status``.
    """
    def _do():
        from core.query_diagnostic_store import (get_pruning_history,
                                                 pruning_history_writer_status)
        return {
            "rows":  get_pruning_history(execution_id=execution_id,
                                          bucket=bucket, limit=limit),
            "limit": limit,
            "writer": pruning_history_writer_status(),
        }
    try:
        return await asyncio.to_thread(_do)
    except Exception as exc:
        logger.exception("pruning_history fetch failed")
        raise HTTPException(500, f"pruning_history fetch failed: {exc}")


@router.get("/api/admin/memory-guard/status")
async def admin_memory_guard_status(_user: dict = Depends(require_admin)):
    """Live memory_guard watchdog + accountant status (2026-06-03).

    Used by the Operations Dashboard to show whether admission is
    blocked, how much memory is in-flight across all queries, and
    whether the watchdog has had to refuse queries since startup.

    2026-06-04 audit — wrapped in asyncio.to_thread.  Reads from
    watchdog_status take _ACCOUNTANT_LOCK + iterate inflight_snapshot
    iterates the dict; brief on small inflight but dashboard polls
    every 5s, so off-loop the work for consistency with the other
    admin status endpoints.
    """
    def _do():
        from core.memory_guard import watchdog_status, inflight_snapshot
        return {
            **watchdog_status(),
            "inflight_queries": inflight_snapshot()[:50],   # cap to 50 entries
        }
    try:
        return await asyncio.to_thread(_do)
    except Exception as exc:
        logger.exception("memory_guard status failed")
        raise HTTPException(500, f"memory_guard status failed: {exc}")


class PreflightTestRequest(BaseModel):
    file_count:        int
    n_workers:         int = 4
    per_worker_mem_mb: int = 2048


@router.post("/api/admin/queries/admission-test")
async def admin_admission_test(req: PreflightTestRequest,
                                  _user: dict = Depends(require_admin)):
    """Dry-run the admission check for a hypothetical query.

    Operators use this to ask 'what would happen if I ran a 2800-file
    query right now?' without actually firing it.  Returns the full
    AdmissionDecision (decision, reason, proposed_overrides, ...).
    """
    try:
        from core.resource_admission import preflight
        from core.config import get_section as _gs
        cfg = _gs("query_admission") or {}
        dec = preflight(
            file_count=req.file_count,
            n_workers=req.n_workers,
            per_worker_mem_mb=req.per_worker_mem_mb,
            policy=cfg.get("policy", "auto_throttle"),
            headroom_factor=float(cfg.get("headroom_factor", 0.7)),
            min_free_ram_mb=int(cfg.get("min_free_ram_mb", 2048)),
            per_file_overhead_mb=float(cfg.get("per_file_overhead_mb", 2.0)),
        )
        return dec.to_dict()
    except Exception as exc:
        logger.exception("admission_test failed")
        raise HTTPException(500, f"admission_test failed: {exc}")


def _diagnose_scan_plan_from_db(execution_id: str, diag: dict) -> None:
    """Fall back to the persisted scan plan when the in-memory one has aged out."""
    try:
        from core.db.models import QueryScanPlan
        with _db_manager.get_session(read_only=True) as sess:
            row = (sess.query(QueryScanPlan)
                   .filter(QueryScanPlan.execution_id == execution_id)
                   .order_by(QueryScanPlan.id.desc())
                   .first())
            if row:
                diag["scan_plan"] = row.plan
                diag["scan_plan_source"] = "db"
    except Exception:
        pass


def _diagnose_brain_logs(execution_id: str, diag: dict) -> None:
    """Attach the brain's own narrative for this execution when it was captured.

    Phase Z.7 (2026-06-09) — brain log narrative.  Captures
    the rich diagnostic lines the brain emits (JOIN-PRUNER
    attribution, Phase S anchor bounds, BF-547 self-heal
    triggers, supplement load diagnostics) so the diagnose
    UI shows them in order WITHOUT the operator grepping
    server logs.  User feedback: "diagnose UI still missing
    such logs ... no use of".
    """
    try:
        from core.brain.log_capture import get_brain_logs as _gbl
        _logs = _gbl(execution_id)
        if _logs:
            diag["brain_logs"] = _logs
    except Exception:
        pass


def _diagnose_enrich_scan_plan(execution_id: str, diag: dict) -> None:
    """Fold the brain's scan plan, routing path and bound report into ``diag``."""
    # Phase T — branch routing always available even if brain
    # didn't run (e.g. query hit a path that bypasses brain).
    from core.brain.scan_plan import (
        get_recent as _sp_recent,
        get_execution_path as _gep,
        get_bound_report as _gbr,
    )
    _exec_path = _gep(execution_id)
    if _exec_path:
        diag["execution_path"] = _exec_path
    _sp_ctx = _sp_recent(execution_id)
    if _sp_ctx is not None:
        diag["scan_plan"] = _sp_ctx.to_dict()
        diag["scan_plan_source"] = "in_memory"
    else:
        # Fall back to DB
        _diagnose_scan_plan_from_db(execution_id, diag)
    # Phase Z (2026-06-09) — JOIN-PRUNER per-col source
    # attribution from the BoundProviderRegistry.  Tells the
    # operator exactly which source (partition / manifest_stats
    # / supplement) produced bounds for each requested col.
    _bound_rep = _gbr(execution_id)
    if _bound_rep:
        diag["join_key_bound_report"] = _bound_rep
    _diagnose_brain_logs(execution_id, diag)


@router.get("/api/admin/queries/diagnose/{execution_id}")
async def admin_queries_diagnose_one(execution_id: str,
                                       _user: dict = Depends(require_admin)):
    """Full diagnostic for ONE query.

    Aggregates:
      * engine_router decisions (multi-worker vs single, skip reasons)
      * multi_worker dispatch history (per-worker file count, timing,
        merge strategy, fallback reason)
      * Active worker state if the query is still running
      * Config snapshot (multi_worker / query_engine / scan_strategy /
        iceberg keys that affect parallelism + caching)
      * Per-execution stage tracker last sample
      * Heuristic bottleneck hints (multi-worker disabled, skew,
        oversubscribed CPU, low memory, cold extension storm, ...)

    ``execution_id`` comes from the query response's X-Execution-Id
    header or the BQB UI execution-history panel.
    """
    try:
        from core.query_diagnostic import diagnose_query
        diag = diagnose_query(execution_id)
        # Phase S (2026-06-08) -- enrich diagnose response with the
        # unified scan_plan if available so the QueryDiagnosticSection UI
        # shows brain decisions (filters, JoinPruner probes, self-heal,
        # per-table file counts) WITHOUT having to call a second endpoint.
        try:
            _diagnose_enrich_scan_plan(execution_id, diag)
        except Exception as _sp_enrich_exc:
            logger.debug(
                "[diagnose] scan_plan enrichment failed: %s",
                _sp_enrich_exc)
        return diag
    except Exception as exc:
        logger.exception("query_diagnostic one failed")
        raise HTTPException(500, f"diagnose_query failed: {exc}")


class EngineRouterTestRequest(BaseModel):
    sql:             str
    file_count:      int = 100
    row_estimate:    int = 0
    is_cross_source: bool = False


def _brain_store_enabled_flag(default: bool) -> bool:
    """The brain-store kill-switch, keeping ``default`` when config is unreadable.

    2026-07-02 -- config-module missing OR brain_store section
    absent.  Debug-log; the caller keeps its default (True) so
    the admin panel doesn't misreport disabled state.
    """
    try:
        from core import config as _cfg
        return bool(getattr(_cfg.brain_store, "enabled", True))
    except Exception as _cfg_exc:                                     # pragma: no cover
        logger.debug(
            "admin/brain/store-stats: config read suppressed %s: %s",
            type(_cfg_exc).__name__, _cfg_exc,
        )
        return default


def _brain_store_mirror_state(store, component: str) -> Dict[str, Any]:
    """One component's mirror state, or the read error in its place."""
    try:
        return store.get_mirror_state(component)
    except Exception as exc:
        return {"error": str(exc)[:200]}


def _brain_store_meta_into(store, payload: dict) -> None:
    """Fold the store's ``_meta`` row (schema version, last writer) into payload.

    2026-07-02 -- store._open_reader() now returns a context
    manager (_ReaderCtx) that owns the close; use ``with`` form
    so the connection releases cleanly even on error.
    """
    try:
        with store._open_reader() as con:
            row = con.execute(
                "SELECT schema_version, last_writer_id, last_writer_at "
                "FROM _meta LIMIT 1"
            ).fetchone()
            if row is not None:
                payload["schema_version"] = int(row[0])
                payload["last_writer_id"] = row[1]
                payload["last_writer_at"] = (
                    row[2].isoformat() if row[2] else None
                )
    except Exception as exc:
        payload["meta_error"] = str(exc)[:200]


@router.get("/api/admin/brain/store-stats")
async def admin_brain_store_stats(
    _user: dict = Depends(require_admin),
):
    """Phase 160 (2026-07-01) — brain DuckDB store diagnostics.

    Returns:
      * ``enabled``    — kill-switch state
      * ``available``  — is the store file readable?
      * ``path``       — resolved store file path
      * ``mirror``     — per-component last_run / last_success /
                          rows_upserted_total / last_error
      * ``hot_tables`` — top-20 hottest tables by 7-day query count
      * ``schema_version`` — current on-disk schema version

    Never raises — always returns a JSON payload even when the store
    is empty / disabled.  ``available=False`` tells the operator to
    check the mirror daemon.
    """
    try:
        from core.brain_duckdb_store import get_store
    except Exception as exc:
        return {"enabled": False, "available": False, "error": str(exc)}
    store = get_store()
    payload = {
        "enabled":   True,
        "available": store.is_available(),
        "path":      str(store.path),
        "mirror":    {},
        "hot_tables": [],
        "schema_version": None,
    }
    # Read config enabled flag
    payload["enabled"] = _brain_store_enabled_flag(payload["enabled"])
    if not payload["available"]:
        return payload
    # Per-component mirror_state
    for component in ("col_stats", "snapshot_pointer", "hot_tables_columns"):
        payload["mirror"][component] = _brain_store_mirror_state(store, component)
    # Hot tables (top 20)
    try:
        payload["hot_tables"] = store.get_hot_tables(top_k=20)
    except Exception as exc:
        payload["hot_tables_error"] = str(exc)[:200]
    _brain_store_meta_into(store, payload)
    return payload


@router.get("/api/admin/brain/mirror-candidates")
async def admin_brain_mirror_candidates(
    top_k: int = 50,
    include_ineligible: bool = False,
    _user: dict = Depends(require_admin),
):
    """Phase 160 Slice 2 (2026-07-01) — ranked mirror-candidate list.

    Consumes brain store data (``hot_tables`` + ``manifest_summary``
    + ``hot_columns``) to score which tables are worth consolidating
    into a QS-owned mirror.  Purely advisory — does NOT build any
    mirror files.  Phase 3 executor will read from operator opt-in
    state after admin flips per-table switches.

    Query params:
      * ``top_k``: cap on the ranked list (default 50)
      * ``include_ineligible``: when true, also list tables that
        FAILED the small-file / hot / time-budget checks with a
        ``why_not`` diagnostic — useful for ops debugging "why isn't
        my hot table showing up".

    Never raises — a store-unavailable / no-data run returns an
    empty ``candidates`` list with a diagnostic ``note`` field.
    """
    try:
        from core.brain_mirror_advisor import list_candidates
    except Exception as exc:
        return {"candidates": [], "error": f"import: {exc}"}
    try:
        return list_candidates(
            top_k=int(top_k) if top_k else None,
            include_ineligible=bool(include_ineligible),
        )
    except Exception as exc:
        logger.exception("mirror candidates listing failed")
        return {"candidates": [], "error": str(exc)[:500]}


@router.get("/api/admin/brain/mirror-opt-in")
async def admin_brain_mirror_opt_in_list(
    include_disabled: bool = False,
    _user: dict = Depends(require_admin),
):
    """Phase 160 Slice 3 (2026-07-01) — list opted-in mirror tables.

    Returns the persistent opt-in state (which tables the admin has
    enabled for future Phase 3 mirror executor).  Empty list when
    the store is unavailable — never raises.
    """
    try:
        from core.brain_duckdb_store import get_store
        store = get_store()
        rows = store.list_mirror_opt_in(enabled_only=(not include_disabled))
        return {"opt_ins": rows, "count": len(rows)}
    except Exception as exc:
        logger.exception("mirror opt-in list failed")
        return {"opt_ins": [], "error": str(exc)[:500]}


@router.post("/api/admin/brain/mirror-opt-in")
async def admin_brain_mirror_opt_in_set(
    payload: dict,
    _user: dict = Depends(require_admin),
):
    """Phase 160 Slice 3 — opt in / opt out one table.

    Body:
      {
        "bucket": "...",
        "table_prefix": "...",
        "enabled": true | false,
        "note": "..."       (optional)
      }

    Idempotent — flipping enabled twice is safe.  Persists to the
    brain store; Phase 3 executor will read this on each tick.
    """
    bucket   = str(payload.get("bucket") or "").strip()
    prefix   = str(payload.get("table_prefix") or "").strip()
    enabled  = bool(payload.get("enabled"))
    note     = payload.get("note")
    if not (bucket and prefix):
        return {
            "ok": False,
            "error": "bucket and table_prefix are required",
        }
    who = str((_user or {}).get("username")
              or (_user or {}).get("user")
              or "admin")
    try:
        from core.brain_duckdb_store import get_store
        store = get_store()
        ok = store.set_mirror_opt_in(
            bucket=bucket, table_prefix=prefix,
            enabled=enabled, opted_in_by=who,
            note=(str(note) if note else None),
        )
        return {
            "ok": ok,
            "bucket": bucket,
            "table_prefix": prefix,
            "enabled": enabled,
        }
    except Exception as exc:
        logger.exception("mirror opt-in set failed")
        return {"ok": False, "error": str(exc)[:500]}


@router.post("/api/admin/brain/mirror-tick")
async def admin_brain_mirror_tick(
    _user: dict = Depends(require_admin),
):
    """Phase 160 — force ONE synchronous mirror tick.

    For ops: when the operator opts in a new hot table (or the
    background daemon is paused) they can manually run one pass and
    see the per-component summary in the response.  Bounded work
    (top-K hot pairs) so the request completes in <5 s in practice.

    Never raises — errors surface in the response payload.
    2026-10-07: runs in the OWNING process through _bg_run_now.
    """
    try:
        return await _bg_run_now("brain_duckdb_mirror", legacy_shape="summary")
    except HTTPException as exc:
        return {"ok": False, "error": str(exc.detail)[:500]}


@router.get("/api/admin/brain/mirror-enabled")
async def admin_brain_mirror_enabled_get(
    _user: dict = Depends(require_admin),
):
    """Report the brain DuckDB mirror writer's effective on/off state.

    The mirror DUPLICATES brain metadata (col_stats / snapshot pointers /
    hot rollups) into a separate columnar store and is OFF by default per
    operator direction (no data duplication unless opted in).  Shows the
    effective flag, the admin runtime override (True / False / null=none),
    and whether the writer thread is alive on the pod serving this call.
    """
    try:
        from core.brain_duckdb_mirror import (
            _config_enabled, _runtime_enabled_override, is_running,
            MIRROR_ENABLED_SETTING_KEY,
        )
    except Exception as exc:
        return {"ok": False, "error": f"import: {exc}"}
    try:
        return {
            "ok": True,
            "enabled": bool(_config_enabled()),
            "runtime_override": _runtime_enabled_override(),
            "running_on_this_pod": bool(is_running()),
            "setting_key": MIRROR_ENABLED_SETTING_KEY,
        }
    except Exception as exc:
        logger.exception("brain mirror-enabled GET failed")
        return {"ok": False, "error": str(exc)[:500]}


def _mirror_reconcile_here(reconcile, get_db_manager) -> bool:
    """Apply the mirror flag on THIS pod only if it is a legitimate writer.

    On API pods we persist-only; the scheduler pod's supervisor applies it on
    its next reconcile.  This avoids starting a writer on the wrong pod.
    """
    try:
        from core.pod_role import should_run as _pr_should_run
        from core.config import scheduler as _sched_cfg
        if _pr_should_run("brain_duckdb_mirror",
                          scheduler_mode=getattr(_sched_cfg, "mode", None)):
            reconcile(get_db_manager())
            return True
    except Exception as _rec_exc:
        logger.debug("mirror-enabled: local reconcile skipped: %s", _rec_exc)
    return False


@router.post("/api/admin/brain/mirror-enabled")
async def admin_brain_mirror_enabled_set(
    body: dict,
    _user: dict = Depends(require_admin),
):
    """Enable/disable the brain DuckDB mirror writer at runtime.

    Body: ``{"enabled": true|false}``.  Persists the flag to
    SystemSetting -- the single source of truth every pod reads.  The
    durable writer lives on the dedicated scheduler pod (external mode)
    or the embedded leader, where a supervisor reconciles running-state
    to this flag within its interval.  We do NOT start a writer on the
    pod serving this request unless that pod is itself a writer pod, so
    an admin hitting an API pod never spawns a stray writer there.
    Enabling opts into metadata duplication; readers fail open when the
    store is empty, so disabling is always safe.
    """
    enabled = body.get("enabled") if isinstance(body, dict) else None
    if not isinstance(enabled, bool):
        raise HTTPException(
            status_code=400,
            detail='body must be {"enabled": true|false}',
        )
    try:
        from core.brain_duckdb_mirror import (
            set_mirror_enabled, reconcile, is_running,
        )
        from core.database import get_db_manager
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"import: {exc}")
    # Match the sibling opt-in endpoint's attribution fallback so we never
    # persist updated_by=None (useful audit trail on who flipped the mirror).
    actor = (
        (_user.get("username") or _user.get("user") or "admin")
        if isinstance(_user, dict) else "admin"
    )
    try:
        set_mirror_enabled(enabled, updated_by=actor)
        # Apply lifecycle immediately ONLY if this pod is a legitimate
        # writer (scheduler pod / embedded leader).  On API pods we
        # persist-only; the scheduler pod's supervisor applies it on its
        # next reconcile.  This avoids starting a writer on the wrong pod.
        applied_here = _mirror_reconcile_here(reconcile, get_db_manager)
        return {
            "ok": True,
            "enabled": enabled,
            "applied_on_this_pod": applied_here,
            "running_on_this_pod": bool(is_running()),
        }
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("brain mirror-enabled POST failed")
        raise HTTPException(status_code=500, detail=str(exc)[:500])


@router.get("/api/admin/brain/last-decisions")
async def admin_brain_last_decisions(
    limit: int = 50,
    _user: dict = Depends(require_admin),
):
    """Return the last N brain decisions + cumulative pruning counters.

    2026-06-30 deep-dive #2 -- operators can debug "why didn't pruning
    fire" or "is bloom actually working" without code-level logging.
    Each entry shows: SQL hash, file count, sensors consulted, the
    final engine pick, the per-layer pruning breakdown, and the cost
    model's predictions.

    Cumulative counters (process-lifetime) surface in the response too
    so dashboards can compute "files pruned per layer per N queries".
    """
    try:
        from core.brain_decision_log import get_log
        return get_log().snapshot(limit=limit)
    except Exception as e:
        logger.exception("brain decision log unavailable")
        raise HTTPException(500, f"unavailable: {e}")


def _self_test_fake_manifest_stats() -> list:
    """Ten synthetic manifest rows with a KNOWN answer: five match dt=2026-06-01.

    Fabricating them is what lets evaluate_where + brain_router exercise
    Layer 1 (manifest bounds) without a live table.
    """
    fake_manifest_stats = []
    for i in range(10):
        fake_manifest_stats.append({
            "file_path":    f"s3://self-test/f{i}.parquet",
            "record_count": 100,
            "stats": {
                "dt": {
                    "lower_bound": "2026-06-01" if i < 5 else "2026-07-01",
                    "upper_bound": "2026-06-01" if i < 5 else "2026-07-01",
                    "null_count":  0,
                    "value_count": 100,
                },
                "DT": {    # deep-dive #3 alias so Layer 1 works for uppercase too
                    "lower_bound": "2026-06-01" if i < 5 else "2026-07-01",
                    "upper_bound": "2026-06-01" if i < 5 else "2026-07-01",
                    "null_count":  0,
                    "value_count": 100,
                },
            },
        })
    return fake_manifest_stats


def _self_test_evaluate_where(report: dict, bundle, evaluate_where) -> bool:
    """Step 4 — evaluate_where directly, isolating the pruning layers from
    the sensor orchestration.  Expected: 5 files survive (files 0-4
    match dt='2026-06-01'; files 5-9 have '2026-07-01' bounds).

    Returns False when the step raised, so the caller stops there.
    """
    try:
        prune_stats = {}
        surviving = evaluate_where(
            manifest_stats=bundle.manifest_stats,
            filter_columns=bundle.filter_columns,
            where_predicates=list(bundle.where_predicates),
            db_manager=None,    # no DB in self-test
            supplement_bounds={},
            stats_out=prune_stats,
        )
        report["steps"].append({
            "name":               "evaluate_where_direct",
            "ok":                 True,
            "surviving":          surviving,
            "expected_surviving": 5,
            "match":              surviving == 5,
            "layer_counters":     prune_stats,
        })
        if surviving != 5:
            report["verdict"] = f"FAIL_evaluate_where_returned_{surviving}_expected_5"
    except Exception as exc:
        report["verdict"] = "FAIL_at_evaluate_where"
        report["steps"].append({"name": "evaluate_where_direct", "ok": False,
                                 "error": f"{type(exc).__name__}: {exc}"})
        return False
    return True


def _self_test_brain_router(report: dict, bundle, BrainRouter,
                            QueryContext) -> bool:
    """Step 5 — brain_router end-to-end: consult_all_sensors then read
    manifest_surviving.  This proves the full router->pruning wire.

    Returns False when the step raised, so the caller stops there.
    """
    try:
        ctx = QueryContext(
            sql=bundle.sql, file_count_unpruned=10,
            bucket=bundle.bucket, table_prefix=bundle.table_prefix,
            snapshot_id=bundle.snapshot_id,
            filter_columns=bundle.filter_columns,
            partition_columns=bundle.partition_columns,
            manifest_stats=bundle.manifest_stats,
            where_predicates=bundle.where_predicates,
            has_prunable_predicates=bundle.has_prunable_predicates,
            manifest_stats_includes_supplement=True,
        )
        sensors = BrainRouter()._consult_all_sensors(ctx)
        report["steps"].append({
            "name":                 "brain_router_end_to_end",
            "ok":                   True,
            "sensors_consulted":    list(sensors.consulted),
            "manifest_surviving":   sensors.manifest_surviving,
            "expected_surviving":   5,
            "match":                sensors.manifest_surviving == 5,
            "prune_breakdown":      dict(sensors.prune_breakdown or {}),
        })
        if sensors.manifest_surviving != 5 and report["verdict"] == "unknown":
            report["verdict"] = (
                f"FAIL_brain_router_returned_{sensors.manifest_surviving}"
                f"_expected_5"
            )
    except Exception as exc:
        report["verdict"] = "FAIL_at_brain_router"
        report["steps"].append({"name": "brain_router_end_to_end", "ok": False,
                                 "error": f"{type(exc).__name__}: {exc}"})
        return False
    return True


def _self_test_read_counters(report: dict, get_prune_counters, get_log) -> None:
    """Read counters + recent log entries so operator sees
    the fingerprints of the self-test in the decision log too."""
    try:
        report["counters_after"] = dict(get_prune_counters())
        report["counter_delta"] = {
            k: report["counters_after"].get(k, 0)
                - report["counters_before"].get(k, 0)
            for k in report["counters_after"]
        }
        snap = get_log().snapshot(limit=5)
        report["recent_log"] = snap.get("recent", [])[-5:]
    except Exception as exc:
        report["steps"].append({"name": "post_counters", "ok": False,
                                 "error": f"{type(exc).__name__}: {exc}"})


@router.get("/api/admin/brain/self-test")
async def admin_brain_self_test(_user: dict = Depends(require_admin)):
    """END-TO-END proof the brain pipeline is working.

    Deep-dive #11 (2026-06-30) -- operator report: "not 100% sure brain
    is really functioning well".  Instead of asking operators to trust
    tests, this endpoint runs a REAL brain consultation against a
    synthetic 10-file / 5-matching-predicate scenario and reports what
    happened at EVERY layer:
      * predicate extraction    (WHERE parsing + normalisation)
      * partition-column classifier (has_prunable_predicates?)
      * manifest_stats layer    (bounded by min/max)
      * supplement bounds layer (per-file bounds from DB)
      * bloom sidecar layer     (equality/IN pruning)
      * final surviving count
      * per-layer counter delta
      * matching brain-decision-log entry

    If any layer fires 0 prunes on this synthetic input, THAT layer
    is broken -- the response makes it obvious which one.

    Returns HTTP 200 with a structured report even when some layers
    fail (defensive: the endpoint MUST work even when the layer
    under test is broken -- that's the whole point).
    """
    import time as _t
    from core.brain_decision_log import get_prune_counters, get_log
    from core.query_feature_builder import QueryFeatureBuilder
    from core.brain_router import BrainRouter, QueryContext
    from core.iceberg_manifest_prune import evaluate_where

    report = {
        "verdict":      "unknown",
        "timestamp":    _t.time(),
        "steps":        [],
        "counters_before": {},
        "counters_after":  {},
        "counter_delta":   {},
        "recent_log":   [],
    }

    try:
        report["counters_before"] = dict(get_prune_counters())
    except Exception as exc:
        report["steps"].append({"name": "read_counters", "ok": False,
                                 "error": f"{type(exc).__name__}: {exc}"})

    # Step 1: build a synthetic FeatureBundle exercising the pipeline
    # without hitting Postgres.  10 files, filter on partition column
    # dt='2026-06-01' matches 5 of them.
    try:
        class _QC:
            filters = [{"column": "dt", "operator": "=", "value": "2026-06-01"}]
        bundle = QueryFeatureBuilder.build(
            sql="SELECT * FROM t WHERE dt = '2026-06-01'",
            query_config=_QC(),
            table_metadata={"bucket": "self-test-bucket",
                            "table_prefix": "self-test-prefix",
                            "snapshot_id": "self-test-snap",
                            "partition_columns": ["dt"]},
            file_count=10,
            file_paths=[f"s3://self-test/f{i}.parquet" for i in range(10)],
            skip_db=True,    # no live DB dependency
        )
        report["steps"].append({
            "name": "feature_builder",
            "ok":   True,
            "predicates_extracted":   len(bundle.where_predicates),
            "has_prunable_predicates": bundle.has_prunable_predicates,
            "partition_columns":      list(bundle.partition_columns),
            "filter_columns":         list(bundle.filter_columns),
            "build_notes":            list(bundle.build_notes),
        })
    except Exception as exc:
        report["verdict"] = "FAIL_at_feature_builder"
        report["steps"].append({"name": "feature_builder", "ok": False,
                                 "error": f"{type(exc).__name__}: {exc}"})
        return report

    # Step 2: run the classifier -- has_prunable_predicates must be True
    # since 'dt' IS a partition column.
    if not bundle.has_prunable_predicates:
        report["verdict"] = "FAIL_classifier_missed_partition_col"
        return report

    # Step 3: fabricate manifest_stats so the evaluate_where + brain_router
    # code path exercises Layer 1 (manifest bounds) with a KNOWN answer.
    bundle.manifest_stats = _self_test_fake_manifest_stats()
    bundle.manifest_stats_includes_supplement = True

    # Step 4: evaluate_where directly (isolates the pruning layers from
    # the sensor orchestration).  Expected: 5 files survive (files 0-4
    # match dt='2026-06-01'; files 5-9 have '2026-07-01' bounds).
    if not _self_test_evaluate_where(report, bundle, evaluate_where):
        return report

    # Step 5: brain_router end-to-end -- consult_all_sensors then read
    # manifest_surviving.  This proves the full router->pruning wire.
    if not _self_test_brain_router(report, bundle, BrainRouter, QueryContext):
        return report

    # Step 6: read counters + recent log entries so operator sees
    # the fingerprints of the self-test in the decision log too.
    _self_test_read_counters(report, get_prune_counters, get_log)

    if report["verdict"] == "unknown":
        report["verdict"] = "PASS"
    return report


def _decision_pruned(entry: dict) -> bool:
    """Did this brain decision actually drop any files, on any layer?"""
    return sum(int(v or 0) for v in
               (entry.get("prune_breakdown") or {}).values()) > 0


def _brain_engine_histogram(recent: list) -> Dict[str, int]:
    """How often each decision_engine was picked across the window."""
    engine_hist: Dict[str, int] = {}
    for e in recent:
        eng = str(e.get("decision_engine") or "unknown")
        engine_hist[eng] = engine_hist.get(eng, 0) + 1
    return engine_hist


def _brain_last_useful_prune_ts(recent: list):
    """Timestamp of the most recent decision that actually pruned, or None."""
    for e in reversed(recent):
        if _decision_pruned(e):
            return e.get("ts")
    return None


@router.get("/api/admin/brain/health-summary")
async def admin_brain_health_summary(
    window_size: int = 100,
    _user: dict = Depends(require_admin),
):
    """Rolling summary: what % of recent decisions actually pruned?

    Deep-dive #11 (2026-06-30) -- gives operator a single number to
    check "is brain doing anything?"  If pruning_rate < 5% over the
    last 100 decisions, brain is effectively dead (either no queries
    have prunable predicates, or the pipeline is broken).

    Also reports:
      * count of decisions in the window
      * distribution of decision_engine picks
      * cumulative counter values
      * approximate "last useful prune" timestamp
    """
    try:
        from core.brain_decision_log import get_log, get_prune_counters
        snap = get_log().snapshot(limit=max(1, int(window_size)))
        recent = snap.get("recent", [])
        counters = dict(get_prune_counters())
        total = len(recent)
        with_prunable = sum(1 for e in recent
                              if e.get("has_prunable_preds"))
        with_actual_prune = sum(1 for e in recent if _decision_pruned(e))
        # Engine distribution
        engine_hist = _brain_engine_histogram(recent)
        # Last useful prune timestamp
        last_useful = _brain_last_useful_prune_ts(recent)

        return {
            "window_size":              total,
            "decisions_with_prunable_preds": with_prunable,
            "decisions_with_actual_prune":   with_actual_prune,
            "pruning_fire_rate_pct":         (
                round(100.0 * with_actual_prune / total, 1)
                if total else 0.0
            ),
            "engine_distribution":       engine_hist,
            "cumulative_counters":       counters,
            "last_useful_prune_ts":      last_useful,
            "health_verdict": (
                "HEALTHY"   if total > 0 and with_actual_prune / max(total, 1) >= 0.05
                else "DEGRADED" if total > 0 and with_prunable / max(total, 1) >= 0.05
                else "NO_PRUNABLE_QUERIES" if total > 0
                else "NO_DECISIONS_YET"
            ),
        }
    except Exception as exc:
        logger.exception("brain health-summary failed")
        raise HTTPException(500, f"unavailable: {exc}")


@router.post("/api/admin/engine-router/test")
async def admin_engine_router_test(req: EngineRouterTestRequest,
                                      _user: dict = Depends(require_admin)):
    """Dry-run: what engine would the router pick for these features?

    2026-06-30 -- routed through QueryFeatureBuilder so the admin UI
    test shows the SAME brain behaviour the production code path sees.
    ``skip_db=True`` avoids the Postgres roundtrip on an admin dry-run.
    """
    try:
        from core.engine_router import decide_engine, QueryFeatures
        from core.query_feature_builder import QueryFeatureBuilder
        bundle = QueryFeatureBuilder.build(
            sql=req.sql,
            file_count=req.file_count,
            row_estimate=req.row_estimate,
            is_cross_source=req.is_cross_source,
            skip_db=True,
        )
        decision = decide_engine(QueryFeatures(**bundle.to_query_features_kwargs()))
        # Surface the build trace so admins can see what the brain
        # was given (or wasn't given) on this dry-run.
        out = decision.to_dict()
        out["_feature_bundle_build_stats"] = bundle.build_stats
        out["_feature_bundle_build_notes"] = bundle.build_notes
        out["_has_prunable_predicates"]    = bundle.has_prunable_predicates
        return out
    except Exception as e:
        logger.exception("engine router test failed")
        raise HTTPException(500, f"Test failed: {e}")


@router.get("/api/admin/industrialization/partition-bloat")
async def admin_partition_bloat(
    _user: dict = Depends(require_admin),
    bucket: Optional[str] = None,
    table_prefix: Optional[str] = None,
    max_tables: int = 25,
):
    """Industrialization Phase 9 — READ-ONLY partition-bloat view over
    ``iceberg_snapshot_files``: per (bucket, table_prefix, partition
    tuple) file_count / avg file size / total bytes / growth vs the prior
    synced snapshot.  The alarm surface AND the Phase-8 materialization
    work-queue signal (which partition to compact next) — flagged rows
    (``bloated=true``) sort first.

    Pass ``bucket`` + ``table_prefix`` to scope to one table; omit both to
    scan the watched-table registry (bounded by ``max_tables`` so a fleet
    with many tables can't turn one admin call into an unbounded scan).
    Never mutates anything; fail-open (empty list on any error/no data
    yet — never a 500 for the "nothing synced" common case).
    """
    try:
        from core.industrialization.bloat_view import (
            compute_partition_bloat, compute_partition_bloat_across_tables,
        )
        if bucket and table_prefix is not None:
            rows = await asyncio.to_thread(
                compute_partition_bloat, _db_manager, bucket, table_prefix)
            scope: Dict[str, Any] = {"bucket": bucket, "table_prefix": table_prefix}
        else:
            rows = await asyncio.to_thread(
                compute_partition_bloat_across_tables, _db_manager,
                max_tables=max_tables)
            scope = {"scanned": "watched_iceberg_tables", "max_tables": max_tables}
        out = [r.to_dict() for r in rows]
        return {
            "scope": scope,
            "partitions": out,
            "total": len(out),
            "bloated_count": sum(1 for r in out if r.get("bloated")),
        }
    except Exception as exc:
        logger.debug("partition-bloat view failed (fail-open, empty): %s", exc)
        return {"scope": {}, "partitions": [], "total": 0, "bloated_count": 0}


# ── Application Configuration ──────────────────────────────────────────────────

def _app_config_iceberg_block(_config_mod) -> Dict[str, Any]:
    """BF-273 — the Iceberg settings the admin UI reads back, previously
    config-file-only."""
    return {
        "metadata_cache_ttl_seconds":      int(_config_mod.get("iceberg", "metadata_cache_ttl_seconds", 60) or 60),
        "metadata_count_warn_threshold":   int(_config_mod.get("iceberg", "metadata_count_warn_threshold", 5000) or 5000),
        # BF-316 — per-query file cap (admin-editable, no restart)
        "max_files_per_query":              int(_config_mod.get("iceberg", "max_files_per_query", 0) or 0),
        # BF-296/298/299/301 sync + cache controls (admin-editable)
        "snapshot_cache_enabled":           bool(_config_mod.get("iceberg", "snapshot_cache_enabled", True)),
        "snapshot_pointer_ttl_hours":       int(_config_mod.get("iceberg", "snapshot_pointer_ttl_hours", 3) or 3),
        "metadata_sync_enabled":            bool(_config_mod.get("iceberg", "metadata_sync_enabled", True)),
        "metadata_sync_autostart":          bool(_config_mod.get("iceberg", "metadata_sync_autostart", True)),
        "metadata_sync_startup_delay_seconds": int(_config_mod.get("iceberg", "metadata_sync_startup_delay_seconds", 15) or 15),
        "metadata_sync_interval_minutes":   int(_config_mod.get("iceberg", "metadata_sync_interval_minutes", 5) or 5),
        "metadata_sync_max_per_cycle":      int(_config_mod.get("iceberg", "metadata_sync_max_per_cycle", 25) or 25),
        "metadata_sync_predownload_enabled": bool(_config_mod.get("iceberg", "metadata_sync_predownload_enabled", False)),
        "metadata_sync_predownload_max_files": int(_config_mod.get("iceberg", "metadata_sync_predownload_max_files", 50) or 50),
        "metadata_sync_predownload_max_gb": int(_config_mod.get("iceberg", "metadata_sync_predownload_max_gb", 5) or 5),
        # BF-COL-STATS sync controls (admin-editable, no restart)
        "column_stats_sync_enabled": bool(_config_mod.get("iceberg", "column_stats_sync_enabled", True)),
        "column_stats_sync_workers": int(_config_mod.get("iceberg", "column_stats_sync_workers", 32) or 32),
        "column_stats_sync_max_files_per_tick": int(_config_mod.get("iceberg", "column_stats_sync_max_files_per_tick", 1000) or 1000),
    }


def _app_config_s3_cache_block(_config_mod) -> Dict[str, Any]:
    """BF-257 — the NFS-backed S3 file cache settings the admin UI reads back."""
    return {
        "enabled":                         bool(_config_mod.get("s3_local_cache", "enabled", False)),
        "cache_dir":                       str(_config_mod.get("s3_local_cache", "cache_dir", "") or ""),
        "max_size_gb":                     int(_config_mod.get("s3_local_cache", "max_size_gb", 100) or 100),
        "evict_interval_minutes":          int(_config_mod.get("s3_local_cache", "evict_interval_minutes", 30) or 30),
        "min_free_disk_gb":                float(_config_mod.get("s3_local_cache", "min_free_disk_gb", 5.0) or 5.0),
    }


@router.get("/api/admin/app-config")
async def admin_get_app_config(_user: dict = Depends(require_admin)):
    """Return current application limits and feature toggle configuration."""
    from core.config import limits as _limits_cfg, features as _features_cfg, s3_results as _s3r_cfg
    from core import config as _config_mod  # BF-273: read iceberg/s3_local_cache via get()
    # Phase 140-A — also surface proxy config so the admin UI can read it.
    try:
        from core.config import proxy_cfg as _proxy_cfg
        _proxy_block = {
            "enabled":          _proxy_cfg.enabled,
            "url":              getattr(_proxy_cfg, "url", "") or "",
            "host":             getattr(_proxy_cfg, "host", "") or "",
            "port":             getattr(_proxy_cfg, "port", 0) or 0,
            "apply_to_boto3":   getattr(_proxy_cfg, "apply_to_boto3", True),
            "apply_to_duckdb":  getattr(_proxy_cfg, "apply_to_duckdb", True),
            "apply_to_httpx":   getattr(_proxy_cfg, "apply_to_httpx", True),
            "no_proxy":         getattr(_proxy_cfg, "no_proxy", "") or "",
            "system_account":   getattr(_proxy_cfg, "system_account", "") or "",
        }
    except Exception as _proxy_err:
        # Fail-OPEN — if proxy_cfg can't be loaded, surface an empty section
        # so the UI still renders rather than 500.
        logger.debug("proxy_cfg load failed (non-fatal): %s", _proxy_err)
        _proxy_block = {"enabled": False, "url": "", "host": "", "port": 0,
                        "apply_to_boto3": True, "apply_to_duckdb": True,
                        "apply_to_httpx": True, "no_proxy": "",
                        "system_account": ""}
    return {
        "limits": {
            "max_stream_files":           _limits_cfg.max_stream_files,
            "stream_query_limit_default": _limits_cfg.stream_query_limit_default,
            "stream_query_limit_max":     _limits_cfg.stream_query_limit_max,
            "stream_page_size_default":   _limits_cfg.stream_page_size_default,
            "stream_page_size_max":       _limits_cfg.stream_page_size_max,
            "stream_chart_top_n":         _limits_cfg.stream_chart_top_n,
            "stream_chart_max_series":    _limits_cfg.stream_chart_max_series,
            "max_upload_size_mb":         _limits_cfg.max_upload_size_bytes // (1024 * 1024),
            "max_display_cols":           _limits_cfg.max_display_cols,
            "col_auto_project":           _limits_cfg.col_auto_project,
            "default_query_limit":        _limits_cfg.default_query_limit,
            "streaming_default_on":       _limits_cfg.streaming_default_on,
            "stream_bg_download_default": _limits_cfg.stream_bg_download_default,
            # Query engine settings (from query_engine config section)
            "duckdb_threads_per_query":   _qe_cfg.duckdb_threads_per_query,
            "duckdb_memory_limit_mb":     _qe_cfg.duckdb_memory_limit_mb,
            "query_timeout_seconds":      _qe_cfg.query_timeout_seconds,
            "max_concurrent_per_user":    _qe_cfg.max_concurrent_per_user,
            "max_concurrent_global":      _qe_cfg.max_concurrent_global,
        },
        "features": {
            "streaming_mode":             _features_cfg.streaming_mode,
            "streaming_enabled_roles":    ",".join(_features_cfg.streaming_enabled_roles),
            "export_enabled_roles":       ",".join(_features_cfg.export_enabled_roles),
            "sql_editor_enabled_roles":   ",".join(_features_cfg.sql_editor_enabled_roles),
            "scheduler_enabled_roles":    ",".join(_features_cfg.scheduler_enabled_roles),
            "connections_enabled_roles":  ",".join(_features_cfg.connections_enabled_roles),
            "upload_enabled_roles":       ",".join(_features_cfg.upload_enabled_roles),
            "max_query_limit_by_role":    ",".join(f"{r}:{v}" for r, v in _features_cfg.max_query_limit_by_role.items()),
        },
        "s3_results": {
            "enabled":                    _s3r_cfg.enabled,
            "storage_mode":               _s3r_cfg.storage_mode,
            "size_threshold_mb":          _s3r_cfg.size_threshold_mb,
            "prefix":                     _s3r_cfg.prefix,
            "delete_local_after_upload":  _s3r_cfg.delete_local_after_upload,
            "bucket_override":            _s3r_cfg.bucket_override,
        },
        "proxy": _proxy_block,
        # BF-273 — Iceberg + S3 cache settings, previously config-file-only.
        "iceberg":        _app_config_iceberg_block(_config_mod),
        "iceberg_mor": {
            "enabled":                         bool(_config_mod.get("iceberg_mor", "enabled", True)),
        },
        "s3_local_cache": _app_config_s3_cache_block(_config_mod),
        # BF-275: per-table sort orders ({table_name: [col1, col2]}).
        "iceberg_sort_orders": dict(_config_mod.get_section("iceberg_sort_orders") or {}),
    }


#: Keys that belong to query_engine config section (not limits)
_APP_CFG_QE_KEYS = {"duckdb_threads_per_query", "duckdb_memory_limit_mb",
                    "query_timeout_seconds", "max_concurrent_per_user",
                    "max_concurrent_global"}

#: Phase 140-A — proxy round-trip.  Filter to a known whitelist so the UI
#: can't accidentally write arbitrary keys into the proxy section.
_APP_CFG_PROXY_KEYS = {"enabled", "url", "host", "port", "apply_to_boto3",
                       "apply_to_duckdb", "apply_to_httpx", "no_proxy",
                       "system_account"}

#: BF-273 — Iceberg + s3_local_cache round-trip with key whitelists.
_APP_CFG_ICE_KEYS = {
    "metadata_cache_ttl_seconds",
    "metadata_count_warn_threshold",
    # BF-316 — per-query file cap, admin-editable at runtime
    "max_files_per_query",
    # BF-296/298 metadata cache controls
    "snapshot_cache_enabled",
    "snapshot_pointer_ttl_hours",
    # BF-299 sync controls
    "metadata_sync_enabled",
    "metadata_sync_autostart",
    "metadata_sync_startup_delay_seconds",
    "metadata_sync_interval_minutes",
    "metadata_sync_max_per_cycle",
    # BF-301 predownload controls
    "metadata_sync_predownload_enabled",
    "metadata_sync_predownload_max_files",
    "metadata_sync_predownload_max_gb",
    # BF-COL-STATS sync controls
    "column_stats_sync_enabled",
    "column_stats_sync_workers",
    "column_stats_sync_max_files_per_tick",
}
_APP_CFG_MOR_KEYS = {"enabled"}
_APP_CFG_CACHE_KEYS = {"enabled", "cache_dir", "max_size_gb",
                       "evict_interval_minutes", "min_free_disk_gb"}


def _app_config_limits_updates(limits: dict, updates: dict) -> None:
    """Split the limits payload: query_engine keys go to their own section."""
    qe_vals  = {k: v for k, v in limits.items() if k in _APP_CFG_QE_KEYS}
    lim_vals = {k: v for k, v in limits.items() if k not in _APP_CFG_QE_KEYS}
    if lim_vals:
        updates["limits"] = lim_vals
    if qe_vals:
        updates["query_engine"] = qe_vals


def _app_config_whitelisted(section: str, payload: dict, allowed: set,
                            updates: dict) -> None:
    """Copy only whitelisted keys of one section into ``updates``."""
    filtered = {k: v for k, v in payload.items() if k in allowed}
    if filtered:
        updates[section] = filtered


def _app_config_sort_orders(raw) -> dict:
    """Validate the BF-275 iceberg_sort_orders mapping.

    Free-form ``{table_name: [columns]}``.  Keys must be non-empty strings,
    values must be lists of non-empty strings.  Empty list = clear sort for
    that table.  Whole-dict replacement (admin UI sends the full mapping
    each save).
    """
    _so_validated: dict = {}
    for _tbl, _cols in (raw or {}).items():
        if not isinstance(_tbl, str) or not _tbl.strip():
            continue
        if not isinstance(_cols, list):
            continue
        _clean_cols = [str(c).strip() for c in _cols
                       if isinstance(c, str) and str(c).strip()]
        _so_validated[_tbl.strip()] = _clean_cols
    return _so_validated


def _app_config_updates(request: AppConfigUpdateRequest) -> Dict[str, Any]:
    """Turn one app-config PUT into the per-section updates it may write."""
    updates: Dict[str, Any] = {}
    if request.limits:
        _app_config_limits_updates(request.limits, updates)
    if request.features:
        updates["features"] = request.features
    if request.s3_results:
        updates["s3_results"] = request.s3_results
    if request.proxy:
        _app_config_whitelisted("proxy", request.proxy,
                                _APP_CFG_PROXY_KEYS, updates)
    if request.iceberg:
        _app_config_whitelisted("iceberg", request.iceberg,
                                _APP_CFG_ICE_KEYS, updates)
    if request.iceberg_mor:
        _app_config_whitelisted("iceberg_mor", request.iceberg_mor,
                                _APP_CFG_MOR_KEYS, updates)
    if request.s3_local_cache:
        _app_config_whitelisted("s3_local_cache", request.s3_local_cache,
                                _APP_CFG_CACHE_KEYS, updates)
    if request.iceberg_sort_orders is not None:
        # Replace entire section (admin UI is authoritative)
        updates["iceberg_sort_orders"] = _app_config_sort_orders(
            request.iceberg_sort_orders)
    return updates


@router.put("/api/admin/app-config")
async def admin_update_app_config(request: AppConfigUpdateRequest,
                                  _user: dict = Depends(require_admin)):
    """Hot-reconfigure application limits and feature toggles."""
    updates = _app_config_updates(request)
    if not updates:
        return {"message": "No changes"}

    # 2026-09-27: every section goes through config.set() -- the DB overlay
    # every pod reads -- instead of a read-modify-write of this pod's
    # config.json (see the helper block above _persist_config_section).
    # The DB write is synchronous; keep it off the event loop (BF-409).
    _REPLACE_SECTIONS = {"iceberg_sort_orders"}

    def _write_through():
        statuses, kept = [], {}
        for section, values in updates.items():
            if section in _REPLACE_SECTIONS:
                res = _replace_config_section(section, values)
                if res["kept_by_config_file"]:
                    kept[section] = res["kept_by_config_file"]
            else:
                res = _persist_config_section(section, values)
            statuses.append(res["persisted"])
        return statuses, kept
    _statuses, _kept = await asyncio.to_thread(_write_through)
    _persisted = _worst_persist_status(_statuses)

    changed_by = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, changed_by, "update_app_config", resource_type="app_config",
                      details={"updates": updates})
    # Phase 140-A — proxy state is held in module-level singletons used by
    # cached boto3 clients; a hot-reload won't propagate to those caches.
    # Tell the UI a restart is needed when proxy keys were touched.
    _restart_required = "proxy" in updates
    out = {
        "message": _persist_message(_persisted, "Configuration updated"),
        "updates": updates,
        "restart_required": _restart_required,
        "persisted": _persisted,
    }
    if _kept:
        out["kept_by_config_file"] = _kept
        out["note"] = ("these keys are held by the reviewed config file and "
                       "cannot be removed from the UI; remove them from the file")
    return out


# ── Queue Backend Configuration ────────────────────────────────────────────────

@router.get("/api/admin/queue-config")
async def admin_get_queue_config(_user: dict = Depends(require_admin)):
    """Return queue backend configuration and live status."""
    from core.config import queue as _queue_cfg
    from core.queue_backend import get_queue_status
    status = get_queue_status()
    return {
        "config": {
            "backend":        _queue_cfg.backend,
            "redis_url":      _queue_cfg.redis_url,
            "redis_password": "***" if _queue_cfg.redis_password else "",
            "redis_db":       _queue_cfg.redis_db,
            "redis_ssl":      _queue_cfg.redis_ssl,
            "key_prefix":     _queue_cfg.key_prefix,
            "task_ttl_hours": _queue_cfg.task_ttl_hours,
        },
        "status": status,
    }


#: queue-config request field -> config key, in the order they are written.
_QUEUE_CFG_FIELDS = (
    "backend", "redis_url", "redis_password", "redis_db",
    "redis_ssl", "key_prefix", "task_ttl_hours",
)


def _queue_config_updates(request) -> Dict[str, Any]:
    """Collect the queue-config fields this request actually set.

    ``backend`` is the one value with a closed vocabulary — an unknown
    backend is refused rather than persisted and discovered at restart.
    """
    if request.backend is not None and request.backend not in (
        "sqlite", "database", "redis",
    ):
        raise HTTPException(400, "backend must be 'sqlite', 'database', or 'redis'")
    updates: Dict[str, Any] = {}
    for field in _QUEUE_CFG_FIELDS:
        value = getattr(request, field)
        if value is not None:
            updates[field] = value
    return updates


@router.put("/api/admin/queue-config")
async def admin_update_queue_config(request: QueueConfigUpdateRequest,
                                    _user: dict = Depends(require_admin)):
    """Update queue backend config. Requires restart to take effect."""
    updates = _queue_config_updates(request)

    if not updates:
        return {"message": "No changes"}

    # 2026-09-27: through config.set() -- the DB overlay every pod reads --
    # not this pod's config.json (see the helper block above
    # _persist_config_section).  Off the event loop (BF-409/412).
    result = await asyncio.to_thread(_persist_config_section, "queue", updates)

    changed_by = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, changed_by, "update_queue_config", resource_type="queue_config",
                      details={"updates": {k: v for k, v in updates.items() if k != "redis_password"}})
    return {
        "message": _persist_message(
            result["persisted"],
            "Queue configuration updated. Restart required for backend switch to take effect."),
        "updates": {k: v for k, v in updates.items() if k != "redis_password"},
        "restart_required": "backend" in updates,
        "persisted": result["persisted"],
    }


@router.post("/api/admin/queue-config/test-redis")
async def admin_test_redis(_user: dict = Depends(require_admin)):
    """Test Redis connectivity using current config."""
    from core.config import queue as _queue_cfg
    if _queue_cfg.backend != "redis" and not _queue_cfg.redis_url:
        return {"connected": False, "error": "No Redis URL configured"}
    try:
        import redis
        r = redis.from_url(
            _queue_cfg.redis_url,
            password=_queue_cfg.redis_password or None,
            db=_queue_cfg.redis_db,
            ssl=_queue_cfg.redis_ssl,
            socket_connect_timeout=5,
        )
        try:
            info = r.info("server")
            return {
                "connected":        True,
                "redis_version":    info.get("redis_version", "?"),
                "uptime_seconds":   info.get("uptime_in_seconds", 0),
                "used_memory_human": info.get("used_memory_human", "?"),
            }
        finally:
            r.close()
    except ImportError:
        return {"connected": False, "error": "redis package not installed (pip install redis)"}
    except Exception as exc:
        return {"connected": False, "error": str(exc)}


@router.get("/api/admin/queue/depths")
async def admin_queue_depths(_user: dict = Depends(require_admin)):
    """Return queue depth counts by status and task type."""
    from core.queue_backend import get_task_queue, get_queue_status
    tq = get_task_queue()
    status_info = get_queue_status()

    pending  = tq.list_tasks(status="pending",    limit=1000)
    active   = tq.list_tasks(status="processing", limit=1000)
    done     = tq.list_tasks(status="completed",  limit=200)
    failed   = tq.list_tasks(status="failed",     limit=200)

    def _by_type(tasks):
        counts = {}
        for t in tasks:
            tt = t.get("task_type", "unknown")
            counts[tt] = counts.get(tt, 0) + 1
        return counts

    # Priority breakdown for pending tasks
    priority_buckets = {"high": 0, "normal": 0, "low": 0}
    for t in pending:
        p = t.get("priority", 5)
        if p <= 2:
            priority_buckets["high"] += 1
        elif p <= 6:
            priority_buckets["normal"] += 1
        else:
            priority_buckets["low"] += 1

    return {
        "backend": status_info.get("backend", "sqlite"),
        "totals": {
            "pending":    len(pending),
            "processing": len(active),
            "completed":  len(done),
            "failed":     len(failed),
        },
        "by_type": {
            "pending":    _by_type(pending),
            "processing": _by_type(active),
        },
        "priority_breakdown": priority_buckets,
        "oldest_pending_age_secs": (
            _oldest_age_secs(pending) if pending else 0
        ),
    }


# ── Dead-Letter Queue Admin ────────────────────────────────────────────────────

@router.get("/api/admin/queue/dead-letter")
async def admin_list_dead_letter(
    resolved: Optional[bool] = None,
    limit: int = Query(default=100, ge=1, le=1000),
    _user: dict = Depends(require_admin),
):
    """List dead-letter queue entries (permanently failed tasks)."""
    entries = await _adb(_db_manager.list_dead_letter, resolved=resolved, limit=limit)
    return {"entries": entries, "count": len(entries)}


@router.post("/api/admin/queue/dead-letter/{task_id}/resolve")
async def admin_resolve_dead_letter(
    task_id: str,
    _user: dict = Depends(require_admin),
):
    """Mark a DLQ entry as resolved (acknowledged, no retry)."""
    ok = await _adb(_db_manager.resolve_dead_letter, task_id, resolved_by=_user["username"])
    if not ok:
        raise HTTPException(status_code=404, detail="DLQ entry not found")
    return {"resolved": True, "task_id": task_id}


@router.post("/api/admin/queue/dead-letter/{task_id}/requeue")
async def admin_requeue_dead_letter(
    task_id: str,
    _user: dict = Depends(require_admin),
):
    """Requeue a DLQ entry for another attempt and mark it resolved."""
    entries = await _adb(_db_manager.list_dead_letter, resolved=False, limit=1000)
    entry = next((e for e in entries if e["task_id"] == task_id), None)
    if not entry:
        raise HTTPException(status_code=404, detail="DLQ entry not found or already resolved")

    from core.queue_backend import get_task_queue
    tq = get_task_queue()
    new_task_id = str(uuid.uuid4())
    tq.enqueue_task(
        task_id=new_task_id,
        task_type=entry.get("task_type", "parquet_query"),
        payload=entry.get("payload") or {},
        execution_id=entry.get("execution_id"),
        created_by=_user["username"],
        priority=5,
        retry_count=0,
        max_retries=3,
    )
    await _adb(_db_manager.resolve_dead_letter, task_id, resolved_by=_user["username"])
    return {"requeued": True, "task_id": task_id, "new_task_id": new_task_id}


# ── Batch Submit API ───────────────────────────────────────────────────────────

class _BatchQueryItem(BaseModel):
    query_id:       Optional[int]  = None
    raw_sql:        Optional[str]  = None
    connection_id:  Optional[int]  = None
    output_format:  str            = Field(default="csv", pattern="^(csv|json)$")
    cache_strategy: str            = Field(default="auto", pattern="^(auto|bypass|refresh)$")
    callback_url:   Optional[str]  = None
    priority:       int            = Field(default=5, ge=0, le=9)
    label:          Optional[str]  = None   # caller-defined label for tracking


class _BatchSubmitRequest(BaseModel):
    queries: List[_BatchQueryItem] = Field(..., min_length=1, max_length=50)


async def _batch_item_query_config(item):
    """Resolve one batch item to its query_config.

    Returns ``(config, None)`` or ``(None, error_message)`` — a bad item is
    reported in the results list, it never aborts the batch.
    """
    if item.query_id:
        saved = await _adb(_db_manager.get_query, item.query_id)
        if not saved:
            return None, f"query_id {item.query_id} not found"
        return saved["query_config"], None
    if item.raw_sql:
        return {"files": [], "raw_sql": item.raw_sql}, None
    return None, "query_id or raw_sql required"


async def _batch_enqueue_item(i: int, item, qc_dict, _username: str,
                              get_task_queue) -> Dict[str, Any]:
    """Create the execution row and enqueue one batch item."""
    execution_id = str(uuid.uuid4())
    task_id      = str(uuid.uuid4())
    try:
        await _adb(_db_manager.create_execution,
            execution_id=execution_id,
            query_id=item.query_id,
            query_config=qc_dict,
            executed_by=_username,
        )
        get_task_queue().enqueue_task(
            task_id=task_id,
            task_type="parquet_query",
            payload={
                "execution_id": execution_id,
                "query_config": qc_dict,
                "connection_id": item.connection_id,
                "executed_by": _username,
                "raw_sql": item.raw_sql,
                "cache_strategy": item.cache_strategy,
                "callback_url": item.callback_url or "",
            },
            execution_id=execution_id,
            created_by=_username,
            priority=item.priority,
        )
    except Exception as exc:
        return {"index": i, "label": item.label, "error": str(exc)}
    return {
        "index":        i,
        "label":        item.label,
        "execution_id": execution_id,
        "task_id":      task_id,
        "status":       "queued",
    }


@router.post("/api/jobs/submit-batch", status_code=202)
async def submit_batch_queries(
    request: _BatchSubmitRequest,
    _user: dict = Depends(require_execute_access),
):
    """Enqueue multiple queries atomically. Returns list of execution_ids.
    Requires executor.mode = 'external'. Max 50 queries per batch."""
    # SECURITY AUDIT 2026-08-03 (S5): batch items carry raw SQL — a share/
    # embed token must never reach this surface.
    from api.deps import reject_token_principals as _rtp
    _rtp(_user)
    from core.config import executor as _exec_cfg
    if _exec_cfg.mode != "external":
        raise HTTPException(
            400,
            "Batch submit requires executor.mode = 'external'. "
            "Use POST /api/execute individually in embedded mode."
        )
    from core.queue_backend import get_task_queue

    _username = (_user or {}).get("username", "guest")
    results = []

    for i, item in enumerate(request.queries):
        # Resolve query config
        qc_dict, qc_error = await _batch_item_query_config(item)
        if qc_error is not None:
            results.append({"index": i, "label": item.label, "error": qc_error})
            continue
        results.append(await _batch_enqueue_item(i, item, qc_dict, _username,
                                                 get_task_queue))

    queued = sum(1 for r in results if r.get("status") == "queued")
    failed = len(results) - queued
    return {
        "submitted": len(request.queries),
        "queued":    queued,
        "errors":    failed,
        "results":   results,
    }


# ── App Settings (role-resolved, for frontend) ─────────────────────────────────

def _apply_scheduler_scope(user: dict, resolved: dict, known_keys: list) -> dict:
    """Thin seam over ``core.clockwork.scope.apply_scope_to_visibility`` so
    the app-settings route reads the ONE predicate (and a test can patch
    the seam to prove the route consults it)."""
    from core.clockwork.scope import apply_scope_to_visibility
    return apply_scope_to_visibility(user, resolved, known_keys)


@router.get("/api/app-settings")
async def get_app_settings(_user: dict = Depends(get_current_user)):
    """Return role-resolved application settings for the frontend."""
    from core.config import limits as _limits_cfg, features as _features_cfg, query_guardrails as _qg_cfg
    from api.deps import _auth_genuinely_disabled
    role = (_user or {}).get("role", "viewer")
    role_limit = _features_cfg.max_query_limit_by_role.get(role, 0)
    return {
        "limits": {
            "col_auto_project":           _limits_cfg.col_auto_project,
            "default_query_limit":        _limits_cfg.default_query_limit,
            "streaming_default_on":       _limits_cfg.streaming_default_on,
            "stream_bg_download_default": _limits_cfg.stream_bg_download_default,
            "max_display_cols":           _limits_cfg.max_display_cols,
            "stream_query_limit_max":     _limits_cfg.stream_query_limit_max,
            "max_stream_files":           _limits_cfg.max_stream_files,
        },
        "query_guardrails": {
            "enabled":                  _qg_cfg.enabled,
            "max_files_warn":           _qg_cfg.max_files_warn,
            "max_files_block":          _qg_cfg.max_files_block,
            "max_rows_warn":            _qg_cfg.max_rows_warn,
            "max_rows_block":           _qg_cfg.max_rows_block,
            "require_partition_filter": _qg_cfg.require_partition_filter,
            "warn_no_partition":        _qg_cfg.warn_no_partition,
            "warn_no_limit":            _qg_cfg.warn_no_limit,
            "default_limit_suggestion": _qg_cfg.default_limit_suggestion,
        },
        "features": {
            "streaming_mode":      _features_cfg.streaming_mode,
            "streaming_enabled":   role in _features_cfg.streaming_enabled_roles,
            "export_enabled":      role in _features_cfg.export_enabled_roles,
            "sql_editor_enabled":  role in _features_cfg.sql_editor_enabled_roles,
            "scheduler_enabled":   role in _features_cfg.scheduler_enabled_roles,
            "connections_enabled": role in _features_cfg.connections_enabled_roles,
            "upload_enabled":      role in _features_cfg.upload_enabled_roles,
            "max_query_limit":     role_limit,
        },
        "role": role,
        "component_visibility": (
            # Phase 107-H: resolved cascade — applies global kill-switch,
            # parent→child sub-feature cascade, and super_admin bypass.
            # 2026-09-10: then the scheduler-only scope
            # (core/clockwork/scope.py) — for a scheduler-scoped principal
            # every non-scheduler key is stated False, explicitly, because
            # the frontend defaults an ABSENT key to visible.  Same rule
            # the API middleware enforces; one predicate, two consumers.
            _apply_scheduler_scope(
                _user,
                await _adb(_db_manager.get_ui_visibility_resolved,
                    role,
                    known_components=[k for k, _, _ in KNOWN_COMPONENTS],
                ) if _db_manager else {},
                [k for k, _, _ in KNOWN_COMPONENTS],
            )
        ),
        "active_connection_profile": (
            lambda p: {"id": p["id"], "name": p["name"]} if p else None
        )(await _adb(_db_manager.get_active_profile) if _db_manager else None),
        "workspaces": (
            # AUTHZ (2026-08-23): scope to the caller's own workspaces unless
            # auth is GENUINELY disabled.  Testing ``_auth_cfg.type != "none"``
            # directly meant a config-load failure (type defaults to 'none')
            # dropped the username filter and listed EVERY workspace — an
            # info leak on exactly the failure (a missing ConfigMap) where
            # DB-backed sessions still resolve a real, non-admin caller.
            await _adb(_db_manager.list_workspaces,
                username=None if _auth_genuinely_disabled() else (_user or {}).get("username")
            ) if _db_manager else []
        ),
    }


# ── Scheduler admin endpoints ──────────────────────────────────────────────────

@router.get("/api/admin/scheduler")
async def admin_scheduler_status(_user: dict = Depends(require_admin)):
    """Return scheduler state: running, paused, job list."""
    from core.config import scheduler as _sched_cfg
    if _sched_cfg.mode == "external":
        return await _scheduler_worker_proxy("GET", "/control/status")
    from core.scheduler import get_scheduler_status
    return get_scheduler_status()


@router.post("/api/admin/scheduler/pause")
async def admin_scheduler_pause(_user: dict = Depends(require_admin)):
    """Pause all scheduled jobs. Running jobs finish normally."""
    from core.config import scheduler as _sched_cfg
    if _sched_cfg.mode == "external":
        result = await _scheduler_worker_proxy("POST", "/control/pause")
    else:
        from core.scheduler import pause_scheduler
        ok = pause_scheduler()
        if not ok:
            raise HTTPException(status_code=400, detail="Scheduler not running")
        result = {"message": "Scheduler paused — no new jobs will fire"}
    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "pause_scheduler", resource_type="scheduler")
    return result


@router.post("/api/admin/scheduler/resume")
async def admin_scheduler_resume(_user: dict = Depends(require_admin)):
    """Resume all scheduled jobs."""
    from core.config import scheduler as _sched_cfg
    if _sched_cfg.mode == "external":
        result = await _scheduler_worker_proxy("POST", "/control/resume")
    else:
        from core.scheduler import resume_scheduler
        ok = resume_scheduler()
        if not ok:
            raise HTTPException(status_code=400, detail="Scheduler not initialized")
        result = {"message": "Scheduler resumed"}
    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "resume_scheduler", resource_type="scheduler")
    return result


# ── Per-job admin control (job_control.py registry) ──────────────────────────
#
# The admin chooses which background jobs run.  Each job has a config-backed
# enabled flag (jobs.<job_id>.enabled).  When admin pauses a job:
#   1. The flag is persisted to config.json so the choice survives pod restart
#   2. The running APScheduler job is paused via the scheduler-worker proxy
#      (external mode) or directly (embedded mode), so the job stops firing
#      immediately — no need to wait for a reload.

async def _scheduled_jobs_runtime_external() -> Dict[str, Any]:
    """Runtime job info from the scheduler-worker.

    An unreachable worker yields a single ``__error__`` marker so the caller
    can flag it — registry-only info is not the same as "nothing scheduled".
    """
    runtime_by_id: Dict[str, Any] = {}
    try:
        status = await _scheduler_worker_proxy("GET", "/control/status")
        for job in (status or {}).get("jobs", []) or []:
            jid = job.get("id") or job.get("job_id")
            if jid:
                runtime_by_id[jid] = job
    except HTTPException:
        # Scheduler worker unreachable — return registry-only info; flag it.
        runtime_by_id = {"__error__": "scheduler-worker unreachable"}
    return runtime_by_id


def _scheduled_jobs_runtime_embedded(_jc) -> Dict[str, Any]:
    """Runtime job info from the in-process APScheduler."""
    runtime_by_id: Dict[str, Any] = {}
    try:
        from core.scheduler import get_scheduler
        sched = get_scheduler()
        for spec in _jc.JOB_REGISTRY.values():
            info = _jc.job_runtime_info(sched, spec.job_id)
            if info.get("registered"):
                runtime_by_id[spec.job_id] = info
    except Exception:
        pass
    return runtime_by_id


def _scheduled_job_entry(_jc, spec, runtime_by_id: Dict[str, Any]) -> Dict[str, Any]:
    """Registry metadata for one job, overlaid with its runtime state."""
    entry: Dict[str, Any] = {
        "job_id":          spec.job_id,
        "name":            spec.name,
        "description":     spec.description,
        "category":        spec.category,
        "default_enabled": spec.default_enabled,
        "enabled":         _jc.is_enabled(spec.job_id),
    }
    rt = runtime_by_id.get(spec.job_id)
    if isinstance(rt, dict):
        for k in ("registered", "paused", "next_run", "trigger"):
            if k in rt:
                entry[k] = rt[k]
    return entry


@router.get("/api/admin/scheduled-jobs")
async def admin_list_scheduled_jobs(_user: dict = Depends(require_admin)):
    """List every known background job: registry metadata + current
    enabled state + APScheduler runtime info (paused, next_run, trigger).
    """
    from core import job_control as _jc
    from core.config import scheduler as _sched_cfg

    # Fetch live runtime info from the scheduler-worker (external mode)
    # or directly from the in-process scheduler (embedded mode).
    if _sched_cfg.mode == "external":
        runtime_by_id = await _scheduled_jobs_runtime_external()
    else:
        runtime_by_id = _scheduled_jobs_runtime_embedded(_jc)

    jobs: List[Dict[str, Any]] = []
    for spec in _jc.JOB_REGISTRY.values():
        jobs.append(_scheduled_job_entry(_jc, spec, runtime_by_id))

    return {
        "scheduler_mode": _sched_cfg.mode,
        "jobs":           jobs,
        "warning": (runtime_by_id.get("__error__")
                    if isinstance(runtime_by_id, dict) and "__error__" in runtime_by_id
                    else None),
    }


@router.post("/api/admin/scheduled-jobs/{job_id}/pause")
async def admin_pause_scheduled_job(job_id: str, _user: dict = Depends(require_admin)):
    """Disable a specific background job — persist the choice AND stop the
    running APScheduler trigger so it doesn't tick until admin resumes."""
    from core import job_control as _jc
    if job_id not in _jc.JOB_REGISTRY:
        raise HTTPException(status_code=404, detail=f"Unknown job_id: {job_id}")

    # Persist + flip in-memory state via job_control.  Iceberg metadata
    # sync is not in APScheduler — only the config flag matters there.
    from core.config import scheduler as _sched_cfg
    result = await asyncio.to_thread(_jc.pause, None, job_id)

    if job_id != "__iceberg_metadata_sync__":
        if _sched_cfg.mode == "external":
            await _pause_job_external(job_id, result)
        else:
            _pause_job_embedded(job_id, result)

    username = (_user or {}).get("username", "admin")
    await _adb(
        _db_manager.audit, username, "pause_background_job",
        resource_type="background_job", resource_id=job_id,
    )
    return result


async def _pause_job_external(job_id: str, result: dict) -> None:
    """Pause a job on the scheduler-worker; a 503 leaves the persist standing."""
    try:
        await _scheduler_worker_proxy("POST", f"/control/pause-job/{job_id}")
    except HTTPException as exc:
        if exc.status_code != 503:  # 503 = worker unreachable, still record the persist
            raise
        # Worker unreachable — persist succeeded, runtime pause didn't
        result["runtime_paused"] = False
        result["warning"] = "Scheduler worker unreachable — runtime pause will apply on next worker restart."
    else:
        result["runtime_paused"] = True


def _pause_job_embedded(job_id: str, result: dict) -> None:
    """Pause a job on this pod's in-process APScheduler."""
    try:
        from core.scheduler import pause_schedule
        pause_schedule(job_id)
        result["runtime_paused"] = True
    except Exception as exc:
        result["runtime_paused"] = False
        result["warning"] = f"Runtime pause failed: {exc}"


async def _resume_job_external(job_id: str, result: dict) -> None:
    """Resume a job on the scheduler-worker; a 503 leaves the persist standing."""
    try:
        resume_info = await _scheduler_worker_proxy("POST", f"/control/resume-job/{job_id}")
        if isinstance(resume_info, dict) and resume_info.get("next_run"):
            result["next_run"] = resume_info["next_run"]
        result["runtime_resumed"] = True
    except HTTPException as exc:
        if exc.status_code != 503:
            raise
        result["runtime_resumed"] = False
        result["warning"] = "Scheduler worker unreachable — runtime resume will apply on next worker restart."


def _resume_job_embedded(job_id: str, result: dict) -> None:
    """Resume a job on this pod's in-process APScheduler."""
    try:
        from core.scheduler import resume_schedule
        next_run = resume_schedule(job_id)
        if next_run:
            result["next_run"] = next_run.isoformat()
        result["runtime_resumed"] = True
    except Exception as exc:
        result["runtime_resumed"] = False
        result["warning"] = f"Runtime resume failed: {exc}"


@router.post("/api/admin/scheduled-jobs/{job_id}/resume")
async def admin_resume_scheduled_job(job_id: str, _user: dict = Depends(require_admin)):
    """Enable a specific background job — persist the choice AND resume
    the running APScheduler trigger so it ticks on its schedule."""
    from core import job_control as _jc
    if job_id not in _jc.JOB_REGISTRY:
        raise HTTPException(status_code=404, detail=f"Unknown job_id: {job_id}")

    from core.config import scheduler as _sched_cfg
    result = await asyncio.to_thread(_jc.resume, None, job_id)

    if job_id != "__iceberg_metadata_sync__":
        if _sched_cfg.mode == "external":
            await _resume_job_external(job_id, result)
        else:
            _resume_job_embedded(job_id, result)
    else:
        # Iceberg metadata sync — runtime change requires scheduler-worker
        # restart since the asyncio loop is created at startup.  Flag this
        # so the admin UI tells the user.
        result["restart_required"] = True
        result["warning"] = (
            "Iceberg metadata sync runs as an asyncio task created at "
            "scheduler-worker startup. The persisted flag will take effect "
            "after the scheduler pod restarts."
        )

    username = (_user or {}).get("username", "admin")
    await _adb(
        _db_manager.audit, username, "resume_background_job",
        resource_type="background_job", resource_id=job_id,
    )
    return result


# ── Audit log endpoints ────────────────────────────────────────────────────────

@router.get("/api/admin/audit-log")
async def get_audit_log(
    username:      Optional[str] = None,
    action:        Optional[str] = None,
    resource_type: Optional[str] = None,
    date_from:     Optional[str] = None,
    date_to:       Optional[str] = None,
    limit:         int = 200,
    offset:        int = 0,
    _user: dict = Depends(require_admin),
):
    """Return audit log entries (admin only). Filterable by username, action, resource_type, dates."""
    from core.config import admin_governance as _gov_cfg
    _cap = _gov_cfg.audit_log_max_results
    return await _adb(_db_manager.get_audit_log_filtered, 
        username=username, action=action, resource_type=resource_type,
        date_from=date_from, date_to=date_to,
        limit=min(limit, _cap), offset=offset,
    )


@router.get("/api/admin/audit-log/export")
async def export_audit_log(
    username:      Optional[str] = None,
    action:        Optional[str] = None,
    resource_type: Optional[str] = None,
    date_from:     Optional[str] = None,
    date_to:       Optional[str] = None,
    _user: dict = Depends(require_admin),
):
    """Stream the filtered audit log as a CSV file (admin only)."""
    import csv
    import io
    rows = await _adb(_db_manager.get_audit_log_filtered, 
        username=username, action=action, resource_type=resource_type,
        date_from=date_from, date_to=date_to, limit=100000, offset=0,
    )
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=["id", "timestamp", "username", "action",
                                              "resource_type", "resource_id",
                                              "ip_address", "details"])
    writer.writeheader()
    for r in rows:
        writer.writerow({k: r.get(k, "") for k in writer.fieldnames})
    content = buf.getvalue()
    return _Resp(
        content=content,
        media_type="text/csv",
        headers={"Content-Disposition": "attachment; filename=audit_log.csv"},
    )


@router.get("/api/admin/audit-log/data-access-summary")
async def get_data_access_summary(_user: dict = Depends(require_admin)):
    """Return per-user aggregate data access statistics (admin only)."""
    return {"summary": await _adb(_db_manager.get_data_access_summary)}


@router.post("/api/admin/compliance/subject-export")
async def generate_subject_export(req: _SubjectExportRequest, _user: dict = Depends(require_admin)):
    """GDPR: generate a ZIP export of all data for a given user (admin only)."""
    import csv
    import io
    import zipfile
    data = await _adb(_db_manager.get_user_data_export, req.username)

    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        # audit_log.csv
        audit_buf = io.StringIO()
        if data["audit_log"]:
            fields = list(data["audit_log"][0].keys())
            w = csv.DictWriter(audit_buf, fieldnames=fields)
            w.writeheader()
            for r in data["audit_log"]:
                w.writerow({k: r.get(k, "") for k in fields})
        zf.writestr("audit_log.csv", audit_buf.getvalue())
        # JSON files
        import json as _json
        zf.writestr("saved_queries.json", _json.dumps(data["saved_queries"],  indent=2, default=str))
        zf.writestr("sql_queries.json",   _json.dumps(data["sql_queries"],    indent=2, default=str))
        zf.writestr("executions.json",    _json.dumps(data["executions"],     indent=2, default=str))
        zf.writestr("downloads.json",     _json.dumps(data["downloads"],      indent=2, default=str))
        zf.writestr("schedules.json",     _json.dumps(data["schedules"],      indent=2, default=str))

    buf.seek(0)
    return StreamingResponse(
        buf,
        media_type="application/zip",
        headers={"Content-Disposition": f"attachment; filename=subject_export_{req.username}.zip"},
    )


# ── User management endpoints ──────────────────────────────────────────────────

@router.get("/api/admin/users")
async def list_users(_user: dict = Depends(require_admin)):
    """List all configured users (local or AD auth)."""
    if _auth_cfg.type == "local":
        local_users = _auth_cfg.local_users
        user_roles  = _auth_cfg.user_roles
        return [
            {"username": u, "role": user_roles.get(u.lower(), "viewer")}
            for u in local_users
        ]
    if _auth_cfg.type == "ad":
        # AD mode: return users from the role mapping
        user_roles = _auth_cfg.user_roles
        return [
            {"username": u, "role": r}
            for u, r in user_roles.items()
        ]
    return {"auth_type": _auth_cfg.type, "message": "User management not available when auth is disabled"}


@router.get("/api/admin/users/known")
async def list_known_users(
    since_days: Optional[int] = None,
    limit: int = 1000,
    _user: dict = Depends(require_admin_read),
):
    """List every user the system has SEEN — distinct usernames from
    audit_log (any action, including login) plus users mapped to
    groups who may not have logged in yet.

    Powers the admin UI's username autocompletes.  Users are auto-
    created on first login by the auth layer; this endpoint reads from
    activity history rather than from a separately-maintained registry.

    Query params:
      since_days: optional N — only include users seen in the last N days
      limit:      cap on rows returned (default 1000)
    """
    if not _db_manager:
        raise HTTPException(status_code=503, detail="DB manager not available")
    rows = _db_manager.list_known_usernames(since_days=since_days, limit=limit)
    return {"items": rows, "count": len(rows)}


@router.get("/api/admin/users/lookup/{username}")
async def lookup_user_ad(username: str, _user: dict = Depends(require_admin)):
    """Look up a user in Active Directory by Windows ID (sAMAccountName)."""
    if _auth_cfg.type != "ad":
        raise HTTPException(400, "AD lookup only available when auth.type = 'ad'")
    from core.ad_auth import lookup_ad_user
    result = lookup_ad_user(username)
    if not result:
        raise HTTPException(404, f"User '{username}' not found in Active Directory")
    return result


@router.post("/api/admin/users", status_code=201)
async def add_user(req: _UserPayload, _user: dict = Depends(require_admin)):
    """Add a new user (local: with password, AD: role mapping only)."""
    if _auth_cfg.type not in ("local", "ad"):
        raise HTTPException(400, "User management not available when auth is disabled")
    # 2026-10-17 -- support is a real, grantable role (core/roles.py: read
    # everything, write nothing; the API's require_admin_read principal);
    # the user routes refused to create one.
    if req.role not in ("admin", "analyst", "viewer", "support"):
        raise HTTPException(400, "Role must be admin, analyst, or viewer")

    if _auth_cfg.type == "local":
        if not req.password:
            raise HTTPException(400, "Password is required for local users")
        local_users = _auth_cfg.local_users
        if req.username in local_users:
            raise HTTPException(409, f"User '{req.username}' already exists")
        await asyncio.to_thread(_update_config_users, req.username, req.password, req.role, "add")
    else:
        # AD mode: just save the role mapping (no password needed)
        user_roles = _auth_cfg.user_roles
        if req.username.lower() in user_roles:
            raise HTTPException(409, f"User '{req.username}' already exists")
        await asyncio.to_thread(_update_config_users, req.username, None, req.role, "add_role")

    return {"username": req.username, "role": req.role}


@router.put("/api/admin/users/{username}")
async def update_user(username: str, req: _UserPayload, _user: dict = Depends(require_admin)):
    """Update a user's role (and optionally password for local auth)."""
    if _auth_cfg.type not in ("local", "ad"):
        raise HTTPException(400, "User management not available when auth is disabled")
    # 2026-10-17 -- support is a real, grantable role (core/roles.py: read
    # everything, write nothing; the API's require_admin_read principal);
    # the user routes refused to create one.
    if req.role not in ("admin", "analyst", "viewer", "support"):
        raise HTTPException(400, "Role must be admin, analyst, or viewer")

    if _auth_cfg.type == "local":
        local_users = _auth_cfg.local_users
        if username not in local_users:
            raise HTTPException(404, f"User '{username}' not found")
        await asyncio.to_thread(_update_config_users, username, req.password, req.role, "update")
    else:
        # AD mode: update role mapping only
        user_roles = _auth_cfg.user_roles
        if username.lower() not in user_roles:
            raise HTTPException(404, f"User '{username}' not found in role mappings")
        await asyncio.to_thread(_update_config_users, username, None, req.role, "update_role")

    return {"username": username, "role": req.role}


@router.delete("/api/admin/users/{username}")
async def remove_user(username: str, req: Request, _user: dict = Depends(require_admin_rate_limited)):
    """Remove a user (local: delete entirely, AD: remove role mapping)."""
    if _auth_cfg.type not in ("local", "ad"):
        raise HTTPException(400, "User management not available when auth is disabled")
    if username.lower() == (_user or {}).get("username", "").lower():
        raise HTTPException(400, "Cannot delete your own account")

    if _auth_cfg.type == "local":
        local_users = _auth_cfg.local_users
        if username not in local_users:
            raise HTTPException(404, f"User '{username}' not found")
        await asyncio.to_thread(_update_config_users, username, None, None, "remove")
    else:
        user_roles = _auth_cfg.user_roles
        if username.lower() not in user_roles:
            raise HTTPException(404, f"User '{username}' not found in role mappings")
        await asyncio.to_thread(_update_config_users, username, None, None, "remove_role")

    _audit(_user, "remove_user", req, "user", 0, {"username": username})
    return {"message": f"User '{username}' removed"}


# ── Cache management endpoints ─────────────────────────────────────────────────

@router.get("/api/cache/stats")
async def get_cache_stats(_user: dict = Depends(get_current_user)):
    from core.query_cache import get_stats
    return get_stats()


@router.delete("/api/cache")
async def clear_cache(_user: dict = Depends(require_admin)):
    from core.query_cache import cleanup_expired
    count = cleanup_expired()
    audit_event(_db_manager, _user, None, "clear_expired_cache", "cache")
    return {"message": f"Removed {count} expired cache entries"}


@router.get("/api/admin/cache/layer-stats")
async def get_cache_layer_stats(_user: dict = Depends(require_admin)):
    """Return per-cache hit rates and sizes for the cache abstraction layer."""
    from core.cache_layer import get_all_cache_stats
    return {"caches": get_all_cache_stats()}


@router.get("/api/admin/cache/recent-misses")
async def get_cache_recent_misses(limit: int = 100,
                                  _user: dict = Depends(require_admin)):
    """Phase 139 (Tier 2.3) — recent cache misses ring buffer.

    Returns the most-recent N misses across all cache layers, newest first.
    Used by the admin Cache Telemetry dashboard to spot patterns like
    trivial-whitespace keys that are wasting cache.
    """
    from core.cache_layer import get_recent_misses
    capped = max(1, min(int(limit), 500))
    return {"misses": get_recent_misses(capped)}


@router.get("/api/admin/cache/per-user-stats")
async def get_cache_per_user_stats(_user: dict = Depends(require_admin)):
    """Phase 139 (Tier 2.3) — per-user, per-layer cache hit/miss breakdown."""
    from core.cache_layer import get_per_user_stats
    return {"users": get_per_user_stats()}


@router.delete("/api/admin/cache/recent-misses")
async def clear_cache_recent_misses(_user: dict = Depends(require_admin)):
    from core.cache_layer import clear_recent_misses, clear_per_user_stats
    cleared_misses = clear_recent_misses()
    cleared_per_user = clear_per_user_stats()
    # BF-263: audit cache-telemetry clears (compliance — admin mutation)
    try:
        _audit_username = (_user or {}).get("username", "admin")
        await _adb(_db_manager.audit, _audit_username, "clear_cache_telemetry",
                          resource_type="cache_telemetry",
                          details={"cleared_misses": cleared_misses,
                                   "cleared_per_user": cleared_per_user})
    except Exception as _aud_err:
        logger.warning("audit failed for clear_cache_telemetry: %s", _aud_err)
    return {
        "cleared_misses":   cleared_misses,
        "cleared_per_user": cleared_per_user,
    }


@router.post("/api/cache/invalidate-source")
async def invalidate_cache_by_source(
    body: CacheInvalidateSourceRequest,
    _user: dict = Depends(require_execute_access),
):
    """Invalidate cache entries that reference a changed data source.

    Intended to be called by an external consumer (e.g. Kafka -> Oracle pipeline)
    when new data is ingested.  Matching entries are evicted; the next query
    execution will fetch fresh data from S3 and repopulate the cache automatically.

    Provide at least one of: table_name, file_prefix, connection_id.
    """
    # SECURITY AUDIT 2026-08-03 (S5): share/embed tokens are viewer-scoped —
    # they must not be able to flush server caches.
    from api.deps import reject_token_principals as _rtp
    _rtp(_user)
    if not any([body.table_name, body.file_prefix, body.connection_id is not None]):
        raise HTTPException(status_code=400,
                            detail="Provide at least one of: table_name, file_prefix, connection_id")
    from core.query_cache import invalidate_by_source
    evicted = invalidate_by_source(
        table_name=body.table_name,
        file_prefix=body.file_prefix,
        connection_id=body.connection_id,
    )
    logger.info("[cache/invalidate-source] %d entries evicted by %s (table=%s prefix=%s conn=%s)",
                evicted, _user.get("username", "?"), body.table_name, body.file_prefix, body.connection_id)
    return {"evicted": evicted, "message": f"Invalidated {evicted} cache entries"}



@router.delete("/api/admin/cache/clear")
async def clear_all_cache(_user: dict = Depends(require_admin_rate_limited)):
    """Clear all query result cache entries (expired and non-expired)."""
    from core.query_cache import cleanup_expired, invalidate
    # First remove expired entries
    count = cleanup_expired()
    # Then remove all remaining (non-expired) entries
    entries = await _adb(_db_manager.list_cache_entries) if _db_manager else []
    for entry in entries:
        invalidate(entry["cache_key"])
    # Also clear S3 file listing cache
    # BF-263: track per-cache success so the response signals partial failure
    # instead of pretending everything cleared.
    _s3_listing_ok = True
    try:
        from core.s3_utilities import clear_listing_cache
        clear_listing_cache()
    except Exception as _exc:
        logger.warning("clear_all_cache: S3 listing cache clear failed: %s", _exc)
        _s3_listing_ok = False
    # Clear Iceberg metadata key cache
    _iceberg_meta_cleared = 0
    _iceberg_meta_ok = True
    try:
        from core.iceberg_reader import invalidate_metadata_cache
        _iceberg_meta_cleared = invalidate_metadata_cache()
    except Exception as _exc:
        logger.warning("clear_all_cache: Iceberg metadata cache clear failed: %s", _exc)
        _iceberg_meta_ok = False
    audit_event(_db_manager, _user, None, "clear_all_cache", "cache")
    return {
        "cleared": len(entries) + count,
        "iceberg_metadata_keys_cleared": _iceberg_meta_cleared,
        "s3_listing_cache_cleared": _s3_listing_ok,
        "iceberg_metadata_cache_cleared": _iceberg_meta_ok,
    }


# ── BF-308: Background-jobs registry (admin control over all bg tasks) ────────

#: A daemon whose pod has not reported for this long is shown as stale
#: rather than as running.  Three reconciler ticks
#: (background_jobs._PAUSE_RECONCILE_INTERVAL_S = 5s): long enough that one
#: slow tick or a brief DB blip is not reported as an outage, short enough
#: that a genuinely dead pod is visible in well under a minute.
_DAEMON_STALE_AFTER_S = 30


def _bg_jobs_declared_inventory():
    """The DECLARED daemon inventory: which pod owns what, plus the disable check.

    Returns ``(declared, admin_disabled)``.  An unreadable registry degrades to
    an empty inventory — the caller then lists only what this pod can see.
    """
    declared: Dict[str, str] = {}
    _daemon_disabled = lambda _n: False      # noqa: E731 - replaced below
    try:
        from core.daemon_registry import (
            SCHEDULER_OWNED, API_OWNED, KNOWN_ORPHANS,
            admin_disabled as _daemon_disabled,
        )
        for n in SCHEDULER_OWNED:
            declared[n] = "scheduler/worker pod"
        for n in API_OWNED:
            declared[n] = "api pod"
        for n in KNOWN_ORPHANS:
            declared[n] = "NO POD — declared orphan"
    except Exception as exc:
        logger.warning("daemon registry unreadable, listing local jobs only: %s",
                       exc)
    return declared, _daemon_disabled


def _bg_jobs_heartbeat_reports() -> Dict[str, list]:
    """Cross-pod OBSERVED state, keyed by daemon name.

    Each pod writes only its own daemons (background_jobs.publish_heartbeat),
    so these are first-hand reports.
    """
    reports: Dict[str, list] = {}
    try:
        for hb in (_db_manager.list_daemon_heartbeats(
                max_age_seconds=_DAEMON_STALE_AFTER_S) or []):
            reports.setdefault(hb.get("name"), []).append(hb)
    except Exception as exc:
        # Fail-OPEN: without heartbeats the answer is less complete, never
        # wrong — rows fall back to declared ownership below.
        logger.warning("daemon heartbeats unreadable: %s", exc)
    return reports


def _bg_jobs_remote_row(name: str, reports: Dict[str, list],
                        _daemon_disabled) -> Dict[str, Any]:
    """Describe a daemon this pod cannot observe directly.

    Live heartbeat > stale heartbeat > switched off on purpose > no report at
    all.  The last three are different facts and must not read alike.
    """
    live = [h for h in reports.get(name, []) if not h.get("stale")]
    if live:
        best = max(live, key=lambda h: h.get("updated_at") or "")
        row = {"name": name, "status": best.get("status"),
               "running": best.get("running"),
               "paused": best.get("paused"),
               "last_error": best.get("last_error"),
               "restart_count": best.get("restart_count"),
               "reported_by": best.get("pod_id"),
               "last_seen": best.get("updated_at")}
        # The same daemon reported running by two pods is a
        # duplicated singleton — the reason (pod_id, name) is the
        # key.  Surfaced rather than collapsed.
        running_on = [h["pod_id"] for h in live if h.get("running")]
        if len(running_on) > 1:
            row["warning"] = ("running on more than one pod: "
                              + ", ".join(sorted(running_on)))
        return row
    if reports.get(name):
        stale = max(reports[name],
                    key=lambda h: h.get("updated_at") or "")
        return {"name": name, "status": "stale",
                "running": False,
                "reported_by": stale.get("pod_id"),
                "last_seen": stale.get("updated_at"),
                "warning": (f"last reported "
                            f"{_DAEMON_STALE_AFTER_S}s+ ago — the "
                            f"owning pod may be down")}
    if _daemon_disabled(name):
        # Switched off on purpose.  Reporting this as "nobody has
        # reported it" would send an operator looking for a broken
        # pod to explain their own setting.
        return {"name": name, "status": "disabled by admin",
                "running": False,
                "warning": ("switched off via the job_control toggle; "
                            "it is not running anywhere by design")}
    return {"name": name, "status": "no report",
            "running": False,
            "warning": ("no pod has reported this daemon; it may "
                        "not be registered anywhere")}


def _bg_jobs_row(name: str, job: Optional[dict], reports: Dict[str, list],
                 _daemon_disabled) -> Dict[str, Any]:
    """One background-jobs row: this pod's own observation, or someone else's.

    A placeholder is not evidence: it is this pod's note that some
    OTHER pod owns the daemon.  Treating it as a local observation is
    what would put "remote" next to a daemon that has actually died.
    """
    local_real = bool(job) and not job.get("remote")
    if local_real:
        row = dict(job)
        row["reported_by"] = "this pod"
        return row
    return _bg_jobs_remote_row(name, reports, _daemon_disabled)


@router.get("/api/admin/background-jobs")
async def list_background_jobs(_user: dict = Depends(require_admin)):
    """Every background job that SHOULD exist, and whether this pod can see it.

    2026-09-01 — this used to return ``background_jobs.list_jobs()`` alone,
    which is a module-level dict: it holds the daemons registered in THIS
    process and nothing else.  The daemons run on the scheduler/worker pod
    (``pod_role.should_run``: role=api is False always, role=worker is True
    always), and the admin API is normally served by the API pod.  So an
    operator looking for the iceberg manifest watcher saw an empty list and
    reasonably concluded nothing was running.

    An empty list and "running elsewhere" are completely different facts, and
    the first one is the dangerous one to show by mistake — it invites
    restarting a pod to fix a problem that is not there, or missing one that
    is.

    So the answer is the DECLARED inventory (core.daemon_registry, which is
    the single source of truth for which pod owns what) joined with this
    pod's runtime status.  Each row says who owns it and whether the status
    is real or simply not visible from here.  Runtime status for another
    pod's daemons needs a heartbeat this system does not have yet; that
    absence is stated in ``status`` rather than implied by omission.
    """
    try:
        from core import background_jobs as _bj
        local = {j.get("name"): j for j in (_bj.list_jobs() or [])}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"list failed: {exc}")

    declared, _daemon_disabled = _bg_jobs_declared_inventory()

    try:
        from core.pod_role import current as _pod_current
        this_pod = str(_pod_current().role)
    except Exception:
        this_pod = "unknown"

    reports = _bg_jobs_heartbeat_reports()

    rows = []
    for name in sorted(set(declared) | set(local) | set(reports)):
        job = local.get(name)
        row = _bg_jobs_row(name, job, reports, _daemon_disabled)
        row["owner"] = declared.get(name, "not declared in the registry")
        row["controllable_here"] = bool(job)
        rows.append(row)

    return {
        "jobs": rows,
        "this_pod_role": this_pod,
        "note": (f"This pod's role is '{this_pod}'. Daemons owned by another "
                 f"pod are reported by that pod's heartbeat (reported_by / "
                 f"last_seen). Pause and resume work from here on any row "
                 f"with controllable_here=true; stop is local-only, because "
                 f"a cancellation cannot be sent across pods."),
    }


def _audit_bg_control(user: dict, action: str, name: str, out: Dict[str, Any]) -> None:
    """2026-10-17 (component health, defect 3): the four background-job
    control routes wrote NO audit row -- a pause stored ``paused_by`` and
    nothing else said who clicked.  One row per control, by value, through
    the fire-and-forget audit every other admin action uses."""
    try:
        from core.audit import audit_event
        audit_event(_db_manager, user, None, f"background_job_{action}", "background_job", name,
                    {"status": (out or {}).get("status"), "paused": (out or {}).get("paused"),
                     "remote": (out or {}).get("remote"), "owner": (out or {}).get("owner")})
    except Exception as exc:                               # noqa: BLE001 -- audit never fails the control
        logger.debug("background-job audit failed: %s", exc)


@router.post("/api/admin/background-jobs/{name}/start")
async def start_background_job(name: str, _user: dict = Depends(require_admin)):
    """Start (or restart) a background job by name."""
    try:
        from core import background_jobs as _bj
        out = _bj.start(name)
        _audit_bg_control(_user, "start", name, out)
        return out
    except KeyError:
        raise HTTPException(status_code=404, detail=f"unknown job: {name}")
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"start failed: {exc}")


@router.post("/api/admin/background-jobs/{name}/stop")
async def stop_background_job(name: str, _user: dict = Depends(require_admin)):
    """Cancel a running background job."""
    try:
        from core import background_jobs as _bj
        out = _bj.stop(name)
        _audit_bg_control(_user, "stop", name, out)
        return out
    except KeyError:
        raise HTTPException(status_code=404, detail=f"unknown job: {name}")
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"stop failed: {exc}")


@router.post("/api/admin/background-jobs/{name}/pause")
async def pause_background_job(name: str, _user: dict = Depends(require_admin)):
    """Admin-deliberate pause — distinct from stop so the status shows
    'paused' (not 'stopped' or 'errored').  Resume with /start.

    BF-320: paused state persists across pod restart."""
    try:
        from core import background_jobs as _bj
        out = _bj.pause(name, paused_by=(_user or {}).get("username"))
        _audit_bg_control(_user, "pause", name, out)
        return out
    except KeyError:
        raise HTTPException(status_code=404, detail=f"unknown job: {name}")
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"pause failed: {exc}")


@router.post("/api/admin/background-jobs/{name}/resume")
async def resume_background_job(name: str, _user: dict = Depends(require_admin)):
    """Resume a paused job (alias for start)."""
    try:
        from core import background_jobs as _bj
        out = _bj.resume(name)
        _audit_bg_control(_user, "resume", name, out)
        return out
    except KeyError:
        raise HTTPException(status_code=404, detail=f"unknown job: {name}")
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"resume failed: {exc}")


# ── 2026-10-07: ONE status + run-now path per background job ─────────────────
#
# core/background_job_contract.py declares, per job, its status reader and
# its run-now (or why it has none).  Both are answered by the OWNING process:
# in external mode the scheduler worker's control API, through
# _scheduler_worker_proxy -- a tick is never run on this pod when another
# owns the job.  The per-daemon routes below (/brain/cleanup-tick, /iceberg/
# prefetch/tick, ...) delegate here so one answer exists, not two.

async def _bg_run_now(name: str, *, legacy_shape: Optional[str] = None
                      ) -> Dict[str, Any]:
    """ONE tick of ``name`` in the owning process; the tick's ledger record.

    ``legacy_shape`` keeps a per-daemon route's response shape: ``"spread"``
    puts the tick's raw dict fields at top level (the record's own keys
    win), ``"summary"`` returns ``{"ok": True, "summary": <raw>, ...}``;
    on those routes an ``error`` outcome is a 500, as it always was.
    """
    from core import background_job_contract as _bjc
    if name not in _bjc.CONTRACTS:
        raise HTTPException(status_code=404,
                            detail=f"unknown background job: {name}")
    try:
        rec = await _bjc.run_now(name, _db_manager, proxy=_scheduler_worker_proxy)
    except _bjc.TickRefused as exc:
        raise HTTPException(status_code=exc.status_code, detail=exc.reason)
    if legacy_shape is None:
        return rec
    if rec.get("outcome") == "error":
        raise HTTPException(status_code=500,
                            detail=f"{name} tick failed: {rec.get('reason')}")
    raw = rec.get("result")
    if legacy_shape == "summary":
        return {"ok": True, "summary": raw, **rec}
    out: Dict[str, Any] = dict(raw) if isinstance(raw, dict) else {}
    out.update(rec)
    return out


@router.get("/api/admin/background-jobs/ticks")
async def background_jobs_ticks(_user: dict = Depends(require_admin)):
    """Every declared background job's last tick (outcome, time, counts)
    and whether it can be run now -- from the owning process."""
    from core import background_job_contract as _bjc
    return await _bjc.all_ticks(_db_manager, proxy=_scheduler_worker_proxy)


@router.get("/api/admin/background-jobs/{name}/status")
async def background_job_status(name: str, limit: int = 10,
                                _user: dict = Depends(require_admin)):
    """One job's status from the process that RUNS it (``answered_by``)."""
    from core import background_job_contract as _bjc
    if name not in _bjc.CONTRACTS:
        raise HTTPException(status_code=404,
                            detail=f"unknown background job: {name}")
    return await _bjc.status(name, _db_manager, limit=limit,
                             proxy=_scheduler_worker_proxy)


@router.post("/api/admin/background-jobs/{name}/run-now")
async def background_job_run_now(name: str, _user: dict = Depends(require_admin)):
    """ONE tick in the owning process; returns that tick's outcome and
    records it where ``/status`` reads.  409 when the job declares it
    cannot run on demand; 503 when the owner cannot be reached (never run
    here instead)."""
    return await _bg_run_now(name)


# ── BF-312: Custom periodic jobs (admin-defined cron schedule) ────────────────

@router.get("/api/admin/custom-jobs")
async def list_custom_jobs_endpoint(_user: dict = Depends(require_admin)):
    """List all custom jobs with their schedule + last-run status."""
    try:
        return {"jobs": await _adb(_db_manager.list_custom_jobs, enabled_only=False)}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"list failed: {exc}")


@router.post("/api/admin/custom-jobs")
async def create_custom_job_endpoint(body: dict, _user: dict = Depends(require_admin)):
    """Create a new custom job.  Validates job_type, parameters, and
    cron expression before persisting."""
    from core.custom_jobs import (
        validate_cron, validate_parameters, compute_next_run,
        VALID_JOB_TYPES,
    )
    body = body or {}
    name = (body.get("name") or "").strip()
    job_type = (body.get("job_type") or "").strip()
    parameters = body.get("parameters") or {}
    cron_expression = (body.get("cron_expression") or "").strip()
    description = body.get("description")
    enabled = bool(body.get("enabled", True))

    if not name:
        raise HTTPException(status_code=400, detail="name is required")
    if job_type not in VALID_JOB_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"invalid job_type — allowed: {', '.join(VALID_JOB_TYPES)}",
        )
    ok, err = validate_cron(cron_expression)
    if not ok:
        raise HTTPException(status_code=400, detail=err)
    ok, err = validate_parameters(job_type, parameters)
    if not ok:
        raise HTTPException(status_code=400, detail=err)

    # Conflict check
    existing = await _adb(_db_manager.get_custom_job_by_name, name)
    if existing:
        raise HTTPException(status_code=409, detail=f"name '{name}' already exists")

    try:
        row = await _adb(_db_manager.create_custom_job, 
            name=name, description=description, job_type=job_type,
            parameters=parameters, cron_expression=cron_expression,
            enabled=enabled, created_by=(_user or {}).get("username"),
        )
        # Schedule the first run
        nxt = compute_next_run(cron_expression)
        await _adb(_db_manager.update_custom_job, row["id"], next_run_at=nxt)
        return await _adb(_db_manager.get_custom_job, row["id"])
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"create failed: {exc}")


@router.get("/api/admin/custom-jobs/{job_id}")
async def get_custom_job_endpoint(job_id: int, _user: dict = Depends(require_admin)):
    row = await _adb(_db_manager.get_custom_job, int(job_id))
    if not row:
        raise HTTPException(status_code=404, detail="not found")
    return row


async def _custom_job_validated_name(raw_name, job_id) -> str:
    """A non-empty custom-job name that no OTHER row already uses."""
    new_name = (raw_name or "").strip()
    if not new_name:
        raise HTTPException(status_code=400, detail="name cannot be empty")
    # Conflict check (different row, same name)
    clash = await _adb(_db_manager.get_custom_job_by_name, new_name)
    if clash and clash["id"] != int(job_id):
        raise HTTPException(status_code=409, detail=f"name '{new_name}' already exists")
    return new_name


def _custom_job_apply_cron(raw_cron, updates: dict,
                           validate_cron, compute_next_run) -> None:
    """Validate a cron change and recompute next_run_at alongside it."""
    ok, err = validate_cron(raw_cron)
    if not ok:
        raise HTTPException(status_code=400, detail=err)
    updates["cron_expression"] = raw_cron.strip()
    # Recompute next_run_at when cron changes
    try:
        updates["next_run_at"] = compute_next_run(updates["cron_expression"])
    except Exception:
        pass


@router.put("/api/admin/custom-jobs/{job_id}")
async def update_custom_job_endpoint(job_id: int, body: dict,
                                       _user: dict = Depends(require_admin)):
    """Update a custom job.  Validates anything that's set on the
    incoming body."""
    from core.custom_jobs import (
        validate_cron, validate_parameters, compute_next_run,
        VALID_JOB_TYPES,
    )
    existing = await _adb(_db_manager.get_custom_job, int(job_id))
    if not existing:
        raise HTTPException(status_code=404, detail="not found")

    body = body or {}
    updates: Dict[str, Any] = {}

    if "name" in body:
        updates["name"] = await _custom_job_validated_name(body["name"], job_id)

    if "description" in body:
        updates["description"] = body["description"]

    job_type = body.get("job_type", existing["job_type"])
    if job_type != existing["job_type"]:
        if job_type not in VALID_JOB_TYPES:
            raise HTTPException(status_code=400, detail="invalid job_type")
        updates["job_type"] = job_type
    parameters = body.get("parameters", existing["parameters"])
    if "parameters" in body or "job_type" in body:
        ok, err = validate_parameters(job_type, parameters)
        if not ok:
            raise HTTPException(status_code=400, detail=err)
        updates["parameters"] = parameters

    if "cron_expression" in body:
        _custom_job_apply_cron(body["cron_expression"], updates,
                               validate_cron, compute_next_run)

    if "enabled" in body:
        updates["enabled"] = bool(body["enabled"])

    try:
        return await _adb(_db_manager.update_custom_job, int(job_id), **updates)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"update failed: {exc}")


@router.delete("/api/admin/custom-jobs/{job_id}")
async def delete_custom_job_endpoint(job_id: int, _user: dict = Depends(require_admin)):
    deleted = await _adb(_db_manager.delete_custom_job, int(job_id))
    if not deleted:
        raise HTTPException(status_code=404, detail="not found")
    return {"deleted": True, "id": int(job_id)}


@router.post("/api/admin/custom-jobs/{job_id}/run-now")
async def run_custom_job_now(job_id: int, _user: dict = Depends(require_admin)):
    """Trigger one immediate run of this job, regardless of cron schedule.
    Persists the result and returns it.  Useful for testing config
    before relying on the schedule.

    2026-10-10: takes the SAME atomic claim the scheduler loop takes
    (``claim_custom_job_run``; here without the "due" predicate) BEFORE
    running.  The route used to read-then-run with no claim, so two
    clicks or two pods ran the same webhook / SQL job twice, and a click
    during a scheduled run ran it beside that run.  A lost claim is a 409
    naming the run in flight; nothing runs here.
    """
    from core.custom_jobs import (execute_one, compute_next_run, _run_off_loop,
                                  run_outcome_updates)
    job = await _adb(_db_manager.get_custom_job, int(job_id))
    if not job:
        raise HTTPException(status_code=404, detail="not found")
    # The schedule the claim advances to (the route always did this after
    # the run); an unparseable cron leaves next_run_at as it is.
    try:
        nxt = compute_next_run(job["cron_expression"])
    except Exception:
        nxt = None
    try:
        won = await _adb(_db_manager.claim_custom_job_run, int(job_id),
                         new_next_run_at=nxt, require_due=False)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"run claim failed: {exc}")
    if not won:
        raise HTTPException(
            status_code=409,
            detail=(f"custom job {job_id} ('{job.get('name')}') already has a run "
                    f"in flight (lease held since {job.get('running_since')}); "
                    f"one run at a time -- wait for it to record its outcome"))
    try:
        # BF-314: use the dedicated jobs executor, not the default
        # asyncio pool, so this manual run never starves /health etc.
        result = await _run_off_loop(execute_one, job)
    except Exception as exc:
        result = {"status": "error", "error": str(exc)[:500], "duration_seconds": 0}
    try:
        # ONE outcome record for both callers; it also releases the lease.
        await _adb(_db_manager.update_custom_job, int(job_id),
                   **run_outcome_updates(job, result))
        return {"job": await _adb(_db_manager.get_custom_job, int(job_id)), "result": result}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"run failed: {exc}")


@router.post("/api/admin/custom-jobs/preview-cron")
async def preview_cron_endpoint(body: dict, _user: dict = Depends(require_admin)):
    """Validate + show next 5 firings of a cron expression.  UI uses
    this for live preview as the admin types."""
    from core.custom_jobs import validate_cron, next_n_runs
    expr = (body or {}).get("cron_expression", "")
    ok, err = validate_cron(expr)
    if not ok:
        return {"valid": False, "error": err, "next_runs": []}
    runs = next_n_runs(expr, n=int((body or {}).get("count", 5) or 5))
    return {
        "valid":     True,
        "cron":      expr,
        "next_runs": [r.isoformat() for r in runs],
    }


# ── BF-299: Watched Iceberg Tables + Background Sync ──────────────────────────

async def _bootstrap_raw_connection(m: dict) -> Optional[Dict[str, Any]]:
    """Decrypted row for one masked connection; None when it cannot be read."""
    try:
        return await _adb(_db_manager.get_connection_raw, int(m.get("id")))
    except Exception:
        return None


async def _bootstrap_all_raw_connections() -> List[Dict[str, Any]]:
    """Every connection, read RAW (decrypted).

    list_connections returns masked configs.  We need raw for bucket_name +
    registered_tables, so iterate IDs and fetch raw.  A total failure yields
    an empty list — bootstrap then simply finds nothing to register.
    """
    try:
        masked = await _adb(_db_manager.list_connections) or []
        connections = []
        for m in masked:
            raw = await _bootstrap_raw_connection(m)
            if raw:
                connections.append(raw)
        return connections
    except Exception:
        return []


async def _bootstrap_target_connections(target_conn_id: Optional[int]) -> List[Dict[str, Any]]:
    """The S3 connections a bootstrap run should walk.

    One explicit connection when an id is given, otherwise every connection;
    either way only S3 ones survive — nothing else can hold Iceberg tables.
    """
    # Collect target connections — must read RAW (decrypted) so we can
    # pick up registered_tables + bucket_name from the encrypted config.
    if target_conn_id:
        try:
            conn = await _adb(_db_manager.get_connection_raw, int(target_conn_id))
        except Exception:
            conn = None
        connections = [conn] if conn else []
    else:
        connections = await _bootstrap_all_raw_connections()
    # Only S3 connections can hold Iceberg tables
    return [c for c in connections
            if c and c.get("connection_type") == "s3"]


def _bootstrap_registered_iceberg_tables(cfg: dict) -> List[Dict[str, Any]]:
    """Iceberg tables a connection's own registry declares.

    ── Primary path: use the connection's registered_tables list ─────
    Admins explicitly register Iceberg tables with name + s3_prefix +
    format=iceberg via the connection editor.  We don't need to scan
    S3 (which requires ListBucket permission and may mis-detect).
    """
    registered_tables = cfg.get("registered_tables") or []
    ice_tables: List[Dict[str, Any]] = []
    for t in registered_tables:
        if not isinstance(t, dict):
            continue
        fmt = (t.get("format") or "").lower()
        if fmt != "iceberg":
            continue
        tp = (t.get("s3_prefix") or "").strip()
        if not tp:
            continue
        ice_tables.append({"name": t.get("name") or tp.rstrip("/").rsplit("/", 1)[-1],
                            "prefix": tp})
    return ice_tables


def _bootstrap_scan_s3_tables(cid, bucket: str, prefix: str,
                              ice_tables: list, errors: list) -> None:
    """Opt-in fallback: discover Iceberg tables by listing S3 under ``prefix``.

    Appends to ``ice_tables`` in place; every failure is recorded in
    ``errors`` rather than raised, so one bad connection cannot abort the run.
    """
    try:
        from core.iceberg_metadata_sync import _build_s3_client
        client = _build_s3_client(int(cid))
    except Exception as exc:
        client = None
        errors.append({"connection_id": cid, "error": f"client: {exc}"})
    if client is not None:
        _bootstrap_list_iceberg_tables(client, cid, bucket, prefix, ice_tables, errors)


def _bootstrap_list_iceberg_tables(client, cid, bucket: str, prefix: str,
                                   ice_tables: list, errors: list) -> None:
    """List Iceberg tables under ``prefix``, appending each to ``ice_tables``."""
    try:
        from core.iceberg_reader import list_iceberg_tables
        scanned = list_iceberg_tables(client, bucket, prefix)
        for t in scanned:
            tp = t.get("prefix") or ""
            if tp:
                ice_tables.append({"name": t.get("name"), "prefix": tp})
    except Exception as exc:
        errors.append({"connection_id": cid, "error": f"list: {exc}"})


async def _bootstrap_register_tables(cid, bucket: str, ice_tables: list, pin: bool,
                                     discovered: list, errors: list) -> int:
    """Upsert each discovered table into the watched registry; count successes."""
    registered = 0
    for t in ice_tables:
        tp = t["prefix"]
        try:
            await _adb(_db_manager.upsert_watched_iceberg_table,
                connection_id=int(cid), bucket=bucket,
                table_prefix=tp, pinned=pin, enabled=True,
            )
            registered += 1
            discovered.append({
                "connection_id": cid, "bucket": bucket,
                "table_prefix": tp, "name": t.get("name"),
            })
        except Exception as exc:
            errors.append({"connection_id": cid, "table_prefix": tp,
                            "error": f"upsert: {exc}"})
    return registered


async def _bootstrap_one_connection(conn: dict, user_bucket: Optional[str], prefix: str,
                                    pin: bool, scan_s3: bool, discovered: list,
                                    errors: list, skipped: list) -> int:
    """Register every Iceberg table one connection exposes; return how many.

    A connection with no id, no bucket or no discoverable tables is recorded
    in ``skipped`` and contributes zero — it never aborts the bootstrap run.
    """
    cid = conn.get("id")
    cfg = conn.get("config") or {}
    # Connections store the bucket as ``bucket_name`` (not ``bucket``).
    bucket = user_bucket or cfg.get("bucket_name") or cfg.get("bucket") or ""
    if not cid:
        return 0
    if not bucket:
        skipped.append({"connection_id": cid, "reason": "no bucket_name in config"})
        return 0

    ice_tables = _bootstrap_registered_iceberg_tables(cfg)

    # ── Fallback path: scan S3 when nothing registered (opt-in) ─────
    if not ice_tables and scan_s3:
        _bootstrap_scan_s3_tables(cid, bucket, prefix, ice_tables, errors)

    if not ice_tables:
        skipped.append({
            "connection_id": cid,
            "bucket": bucket,
            "reason": ("no Iceberg tables in registered_tables — "
                      "register tables via the connection editor, "
                      "or pass scan_s3=true to discover via S3 listing"),
        })
        return 0

    return await _bootstrap_register_tables(
        cid, bucket, ice_tables, pin, discovered, errors)


@router.post("/api/admin/iceberg-sync/bootstrap")
async def iceberg_sync_bootstrap(
    body: dict = None,
    _user: dict = Depends(require_admin),
):
    """BF-300 — bulk-bootstrap the watched registry + pre-warm caches.

    Body (all optional):
      {
        "connection_id": int,    # if omitted, scan ALL connections
        "bucket":        str,    # if omitted, derived from connection cfg
        "prefix":        str,    # warehouse root to scan, default ""
        "pin":           bool,   # default True — keep these synced forever
        "run_now":       bool    # default True — trigger sync immediately
      }

    For each Iceberg table found under the prefix, upsert it into the
    WatchedIcebergTable registry, then run an immediate sync pass so
    metadata is ready before users query.

    Returns: {discovered: N, registered: N, sync_summary: {...}}
    """
    body = body or {}
    target_conn_id: Optional[int] = body.get("connection_id")
    user_bucket: Optional[str] = body.get("bucket")
    prefix: str = body.get("prefix") or ""
    pin: bool = bool(body.get("pin", True))
    run_now: bool = bool(body.get("run_now", True))
    scan_s3: bool = bool(body.get("scan_s3", False))   # fallback when no registered_tables

    connections = await _bootstrap_target_connections(target_conn_id)

    discovered: List[Dict[str, Any]] = []
    registered = 0
    errors: List[Dict[str, Any]] = []
    skipped: List[Dict[str, Any]] = []

    for conn in connections:
        registered += await _bootstrap_one_connection(
            conn, user_bucket, prefix, pin, scan_s3, discovered, errors, skipped)

    # BF-MANUAL-SYNC-NONBLOCK: was awaiting sync_all_once() inline — that
    # could take 5+ minutes on a fresh prod with many tables, blocking the
    # HTTP request long enough for the UI to show "Backend API unavailable"
    # (health probe / WebSocket heartbeat both miss their timeouts).  Now
    # we kick the sync as a background asyncio.Task and return immediately.
    # The /status endpoint reports `manual_sync.running=true` until the
    # task finishes, so the UI can poll for progress.
    sync_kick: Optional[Dict[str, Any]] = None
    if run_now and registered:
        try:
            from core.iceberg_metadata_sync import kick_manual_sync
            sync_kick = kick_manual_sync(_db_manager)
        except Exception as exc:
            errors.append({"error": f"sync: {exc}"})

    return {
        "discovered":      len(discovered),
        "registered":      registered,
        "tables":          discovered,
        # ``sync_kick`` carries {started: bool, already_running: bool, ...}
        # — the UI polls /api/admin/iceberg-sync/status to see progress.
        "sync_kick":       sync_kick,
        "errors":          errors,
        "skipped":         skipped,
        "connections_checked": len(connections),
    }


async def _sync_reconcile_within_budget(_run_off_loop, reconcile_table,
                                        client, cid, bucket: str,
                                        table_prefix: str) -> Dict[str, Any]:
    """Reconcile one table with a 30s wall-clock cap.

    On timeout the work is NOT cancelled — the reconcile keeps running in
    the executor and will update the watched-table row when it finishes, so
    the caller is told ``completed: False`` rather than that it failed.
    """
    async def _run():
        return await _run_off_loop(
            reconcile_table,
            client, connection_id=int(cid), bucket=bucket,
            table_prefix=table_prefix, db_manager=_db_manager,
        )
    try:
        result = await asyncio.wait_for(_run(), timeout=30.0)
        return {"ok": result.get("status") == "ok", "result": result, "completed": True}
    except asyncio.TimeoutError:
        # Kicked off; the reconcile keeps running in the executor and
        # will update the watched-table row when it finishes.
        logger.info(
            "iceberg-sync/refresh-table: %s/%s exceeded 30s budget — "
            "still running in background; /status will reflect completion",
            bucket, table_prefix,
        )
        return {"ok": True, "completed": False,
                 "message": "Refresh started; takes longer than 30s — poll /status for progress"}


@router.post("/api/admin/iceberg-sync/refresh-table")
async def iceberg_sync_refresh_one(body: dict, _user: dict = Depends(require_admin)):
    """BF-300 — pre-warm a single table.  Body:
       {connection_id, bucket, table_prefix}.

    BF-MANUAL-SYNC-NONBLOCK: was awaiting reconcile_table() inline.  One
    table on a cold cache can take 30+ seconds (S3 metadata + manifest-
    list + per-manifest decodes).  Now wrapped via asyncio.to_thread with
    a hard 30s wall-clock cap; on timeout the request returns 202
    indicating the work was kicked off and is still completing in the
    background — the user can poll /status to see when it's done.
    """
    cid = (body or {}).get("connection_id")
    bucket = (body or {}).get("bucket")
    table_prefix = (body or {}).get("table_prefix")
    if not cid or not bucket or not table_prefix:
        raise HTTPException(status_code=400,
                              detail="connection_id, bucket, table_prefix required")
    try:
        from core.iceberg_metadata_sync import (
            _build_s3_client, reconcile_table, _run_off_loop,
        )
        # BF-WS-NOBLOCK-2: route ALL iceberg-sync work through the
        # dedicated _sync_executor (2 threads) instead of the default
        # asyncio executor.  /health uses the default executor too, so
        # when refresh-table saturated it the health probes queued and
        # the frontend showed "Backend API unavailable".  The dedicated
        # pool is isolated — sync can never starve health.
        client = await asyncio.wait_for(
            _run_off_loop(_build_s3_client, int(cid)),
            timeout=15.0,
        )
        if client is None:
            raise HTTPException(status_code=500, detail="No S3 client")
        # Register first.  Same dedicated-pool routing — DB upsert is
        # quick but on a busy cluster it still benefits from isolation.
        await asyncio.wait_for(
            _run_off_loop(
                _db_manager.upsert_watched_iceberg_table,
                connection_id=int(cid), bucket=bucket, table_prefix=table_prefix,
                pinned=True, enabled=True,
            ),
            timeout=10.0,
        )

        return await _sync_reconcile_within_budget(
            _run_off_loop, reconcile_table, client, cid, bucket, table_prefix)
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Refresh failed: {exc}")


async def _sync_status_all_tables(_run_off_loop, fallback: list) -> list:
    """Every watched table, off the event loop, with a 20s ceiling.

    Pull a generous slice and paginate in-Python.  list_watched_iceberg_tables
    supports limit but not offset; for now we accept the memory cost (each
    table row is ~500 bytes; 5000 tables = 2.5 MB).  If admins ever exceed
    that, this can grow into a proper SQL OFFSET/LIMIT query.  A timeout or
    read failure returns ``fallback`` — the page renders without the list
    rather than erroring.
    """
    try:
        _max_rows = 5000
        if _run_off_loop is not None:
            return await asyncio.wait_for(
                _run_off_loop(
                    _db_manager.list_watched_iceberg_tables,
                    enabled_only=False, limit=_max_rows,
                ),
                timeout=20.0,
            )
        return await asyncio.wait_for(
            asyncio.to_thread(
                _db_manager.list_watched_iceberg_tables,
                enabled_only=False, limit=_max_rows,
            ),
            timeout=20.0,
        )
    except (asyncio.TimeoutError, Exception):
        return fallback


def _sync_status_filtered(all_tables: list, search: Optional[str],
                          status_filter: Optional[str]) -> list:
    """Apply the search + status filters to the watched-table list."""
    filtered = all_tables
    if search:
        s = search.lower()
        filtered = [t for t in filtered
                    if s in (t.get("bucket", "") or "").lower()
                    or s in (t.get("table_prefix", "") or "").lower()]
    if status_filter:
        sf = status_filter.lower()
        if sf == "unsynced":
            filtered = [t for t in filtered if not t.get("last_sync_status")]
        else:
            filtered = [t for t in filtered
                        if (t.get("last_sync_status") or "").lower() == sf]
    return filtered


async def _iceberg_sync_from_owner(summary, progress, recent_runs):
    """2026-10-07 -- the SCHEDULED iceberg sync runs on the scheduler pod;
    this pod's summary / progress / run ring are empty there.  Ask the
    process that runs it (core/daemon_snapshots.py).  Returns
    ``(summary, progress, recent_runs, answered_by, warning)``."""
    try:
        from core.daemon_snapshots import daemon_snapshot
        snap = await daemon_snapshot("iceberg_metadata_sync.runs",
                                     proxy=_scheduler_worker_proxy)
    except Exception as exc:
        return (summary, progress, recent_runs, "this_process",
                f"sync owner snapshot unavailable: {exc}")
    if snap["answered_by"] != "this_process":
        data = snap["data"] or {}
        summary = data.get("summary") or summary
        progress = data.get("progress") or progress
        recent_runs = data.get("recent_runs") or recent_runs
    return (summary, progress, recent_runs, snap["answered_by"],
            snap.get("warning"))


@router.get("/api/admin/iceberg-sync/status")
async def iceberg_sync_status(
    _user: dict = Depends(require_admin),
    page: int = 1,
    page_size: int = 50,
    status_filter: Optional[str] = None,
    search: Optional[str] = None,
):
    """Last sync run summary + per-table sync status + manual-sync flag
    + live per-run progress + recent run history + pagination.

    Query parameters:
      * ``page``         — 1-based page number for the tables list
      * ``page_size``    — rows per page (default 50, max 500)
      * ``status_filter``— optional 'ok' / 'error' / 'pending' / 'unsynced'
      * ``search``       — substring search across bucket + table_prefix
    """
    summary: Dict[str, Any] = {}
    progress: Dict[str, Any] = {}
    recent_runs: List[Dict[str, Any]] = []
    _sync_answered_by = "this_process"
    _sync_warning: Optional[str] = None
    try:
        from core.iceberg_metadata_sync import (
            get_last_summary, is_manual_sync_running,
            manual_sync_elapsed_seconds, _run_off_loop,
            get_sync_progress, get_recent_runs,
        )
        summary = get_last_summary()
        manual = {
            "running":         is_manual_sync_running(),
            "elapsed_seconds": manual_sync_elapsed_seconds(),
        }
        try:
            progress = get_sync_progress()
            recent_runs = get_recent_runs()
        except Exception as _pe:
            logger.debug("iceberg sync progress fetch failed: %s", _pe)
        # 2026-10-07 -- the SCHEDULED sync runs on the scheduler pod; this
        # pod's summary / progress / run ring are empty there.  A manual
        # sync started through THIS pod still shows (it runs here).
        if not manual["running"]:
            (summary, progress, recent_runs, _sync_answered_by,
             _sync_warning) = await _iceberg_sync_from_owner(
                summary, progress, recent_runs)
    except Exception:
        manual = {"running": False, "elapsed_seconds": None}
        _run_off_loop = None
    all_tables: List[Dict[str, Any]] = []
    # Pull a generous slice and paginate in-Python.  list_watched_iceberg_tables
    # supports limit but not offset; for now we accept the memory cost (each
    # table row is ~500 bytes; 5000 tables = 2.5 MB).  If admins ever exceed
    # that, this can grow into a proper SQL OFFSET/LIMIT query.
    all_tables = await _sync_status_all_tables(_run_off_loop, all_tables)

    # Apply filters
    filtered = _sync_status_filtered(all_tables, search, status_filter)

    total = len(filtered)
    # Clamp page_size + page
    page_size = max(1, min(int(page_size or 50), 500))
    page = max(1, int(page or 1))
    start = (page - 1) * page_size
    end = start + page_size
    page_tables = filtered[start:end]

    return {
        "summary":     summary,
        "tables":      page_tables,
        "manual_sync": manual,
        "progress":    progress,        # NEW: live per-run progress
        "recent_runs": recent_runs,     # NEW: rolling history of completed runs
        # 2026-10-07: which process's summary / progress / runs these are
        # (the per-table rows below are durable, the same on every pod).
        "summary_answered_by": _sync_answered_by,
        **({"warning": _sync_warning} if _sync_warning else {}),
        "pagination": {                 # NEW: pagination metadata
            "page":      page,
            "page_size": page_size,
            "total":     total,
            "total_pages": max(1, (total + page_size - 1) // page_size),
        },
    }


@router.post("/api/admin/iceberg-sync/run")
async def iceberg_sync_run_now(_user: dict = Depends(require_admin)):
    """Trigger a sync pass right now (in addition to the scheduled run).

    BF-MANUAL-SYNC-NONBLOCK: returns immediately after scheduling the
    sync as a background asyncio.Task.  Was awaiting inline which could
    block for minutes on busy clusters — clients polled health probes
    timed out and the UI rendered "Backend API unavailable".  The UI now
    polls /status to watch progress.
    """
    try:
        from core.iceberg_metadata_sync import kick_manual_sync
        kick = kick_manual_sync(_db_manager)
        return {"ok": True, "kick": kick}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Sync kick failed: {exc}")


def _scan_plan_from_memory(execution_id: str):
    """The in-memory scan plan for one execution, or None."""
    try:
        from core.brain.scan_plan import get_recent
        ctx = get_recent(execution_id)
        if ctx:
            return {"source": "in_memory", "plan": ctx.to_dict()}
    except Exception:
        pass
    return None


def _scan_plan_from_db(execution_id: str):
    """The persisted scan plan for one execution, or None.

    A lookup FAILURE is a 500 — "the DB could not be read" and "there is no
    plan" are different answers and must not read alike.
    """
    try:
        from core.db.models import QueryScanPlan
        with _db_manager.get_session(read_only=True) as sess:
            row = (sess.query(QueryScanPlan)
                   .filter(QueryScanPlan.execution_id == execution_id)
                   .order_by(QueryScanPlan.id.desc())
                   .first())
            if row:
                return {"source": "db", "plan": row.to_dict()}
    except Exception as exc:
        raise HTTPException(500, f"scan-plan db lookup failed: {exc}")
    return None


@router.get("/api/admin/queries/scan-plan/{execution_id}")
async def admin_scan_plan(execution_id: str,
                            _user: dict = Depends(require_admin)):
    """Phase P (2026-06-08) — unified scan-plan diagnostic.

    Returns the complete PruneContext for one query: every iceberg
    table touched, every Decision (per gate), every JOIN probe,
    per-stage file counts, self-heal outcomes.

    Single endpoint replaces grepping logs + bouncing across
    /pruning-history + /diagnose + /iceberg-watcher/status.

    Read-order:
      1. Try in-memory recent contexts (fastest)
      2. Fall back to DB query_scan_plans table (durable, survives restart)
    """
    def _do():
        # First: in-memory
        found = _scan_plan_from_memory(execution_id)
        if found is not None:
            return found
        # Second: DB
        found = _scan_plan_from_db(execution_id)
        if found is not None:
            return found
        raise HTTPException(404, f"no scan plan for execution_id={execution_id}")
    try:
        return await asyncio.to_thread(_do)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("scan_plan fetch failed")
        raise HTTPException(500, f"scan_plan fetch failed: {exc}")


def _scan_plan_combine_db(out: list, limit: int) -> None:
    """Append persisted scan plans the in-memory ring no longer holds."""
    try:
        from core.db.models import QueryScanPlan
        with _db_manager.get_session(read_only=True) as sess:
            rows = (sess.query(QueryScanPlan)
                    .order_by(QueryScanPlan.id.desc())
                    .limit(limit).all())
            seen = {x.get("execution_id") for x in out}
            for r in rows:
                if r.execution_id in seen:
                    continue
                out.append({
                    "execution_id":       r.execution_id,
                    "created_at":         r.created_at.isoformat() if r.created_at else None,
                    "completed_at":       r.completed_at.isoformat() if r.completed_at else None,
                    "total_files_before": r.total_files_before,
                    "total_files_after":  r.total_files_after,
                    "tables":             len((r.plan or {}).get("tables", [])),
                })
                seen.add(r.execution_id)
    except Exception as exc:
        logger.debug("scan-plan-recent DB combine failed: %s", exc)


@router.get("/api/admin/queries/scan-plan-recent")
async def admin_scan_plan_recent(limit: int = 20,
                                   _user: dict = Depends(require_admin)):
    """Phase P — list recent query scan plans (in-memory + DB combined)."""
    def _do():
        out: List[Dict[str, Any]] = []
        try:
            from core.brain.scan_plan import list_recent
            out.extend(list_recent(limit=limit))
        except Exception:
            pass
        _scan_plan_combine_db(out, limit)
        return {"rows": out[:limit]}
    try:
        return await asyncio.to_thread(_do)
    except Exception as exc:
        logger.exception("scan_plan_recent failed")
        raise HTTPException(500, f"scan_plan_recent failed: {exc}")


@router.get("/api/admin/iceberg-watcher/status")
async def iceberg_watcher_status(_user: dict = Depends(require_admin)):
    """Phase C — current state of the iceberg manifest watcher.

    Cheap fast-tick poller that detects snapshot-id changes between heavy
    reconciles and invalidates L1/L2 caches on change.  This endpoint
    shows the most recent tick summary + per-table outcome.
    """
    # 2026-10-07 -- answered from the certificate / changes tables (durable,
    # the same on every pod).  The watcher runs on the scheduler pod; this
    # route is answered by the API pod, whose in-process tick record is
    # empty -- a healthy watcher used to read ``ran_at: null``.  The DB read
    # runs off the event loop.
    try:
        from core.iceberg_manifest_watcher import get_watcher_status
        return await asyncio.to_thread(get_watcher_status, _db_manager)
    except Exception as exc:
        raise HTTPException(status_code=500,
                            detail=f"watcher status failed: {exc}")


@router.post("/api/admin/iceberg-watcher/run")
async def iceberg_watcher_run_now(_user: dict = Depends(require_admin)):
    """Phase C — run one watcher tick synchronously.

    Useful for testing + force-invalidation after a manual table rewrite.
    Returns the tick summary directly.  2026-10-07: runs in the OWNING
    process (the watcher's listeners live there) through _bg_run_now.
    """
    return await _bg_run_now("iceberg_manifest_watcher", legacy_shape="summary")


@router.get("/api/admin/iceberg-watcher/settings")
async def iceberg_watcher_settings_list(_user: dict = Depends(require_admin)):
    """Phase E — list all watcher + DB-first knobs with their current value,
    default, type, choices (where applicable), and a human-readable
    description.  Drives the admin settings UI so operators can SEE
    exactly what is tunable, no hidden hardcoded behaviour."""
    try:
        from core.iceberg_manifest_watcher import list_settings as _wat_list
        from core.iceberg_db_first_reader import (
            list_settings as _dbf_list,
            get_outcomes as _dbf_outcomes,
        )
        # db_first_outcomes: aggregate hit / fallthrough:<reason> counters so
        # operators can SEE whether the Postgres supplement is actually
        # accelerating queries or constantly falling back.  A rising
        # ``fallthrough:incomplete`` / ``fallthrough:post_fetch_incomplete``
        # count means the column-stats scanner is behind for those snapshots
        # (queries stay correct via S3, just not accelerated) -> warm the
        # supplement / check the watcher.
        return {
            "watcher":            _wat_list(),
            "db_first":           _dbf_list(),
            "db_first_outcomes":  _dbf_outcomes(),
        }
    except Exception as exc:
        raise HTTPException(status_code=500,
                            detail=f"settings list failed: {exc}")


def _write_iceberg_setting(key: str, value: Any, actor: Optional[str]) -> Dict[str, Any]:
    """The one dispatch by key prefix: the watcher's settings or the
    db-first reader's.  An unknown prefix is the caller's 400."""
    if key.startswith("iceberg_watcher."):
        from core.iceberg_manifest_watcher import set_setting as _set
        return _set(key, value, updated_by=actor)
    if key.startswith("iceberg_db_first."):
        from core.iceberg_db_first_reader import set_setting as _set
        return _set(key, value, updated_by=actor)
    raise HTTPException(status_code=400, detail=f"unknown setting key: {key}")


@router.patch("/api/admin/iceberg-watcher/settings/{key}")
async def iceberg_watcher_settings_update(
    key: str, body: dict,
    _user: dict = Depends(require_admin),
):
    """Phase E — update one watcher / db_first setting.

    Body: ``{"value": <new value>}``.  Type coercion + choice validation
    is done in the module's set_setting().  Persists to SystemSetting +
    invalidates the in-process cache so the next read returns the new
    value within 30 seconds (or immediately for the writing pod).
    """
    new_value = body.get("value") if isinstance(body, dict) else None
    if new_value is None and not isinstance(body, dict):
        raise HTTPException(status_code=400,
                            detail="body must be {\"value\": ...}")
    actor = _user.get("username") if isinstance(_user, dict) else None
    from core.database import DbHandleUnavailable
    try:
        return {"ok": True,
                "setting": _write_iceberg_setting(key, new_value, actor)}
    except HTTPException:
        # FB-33 (2026-09-19): the ``except Exception`` below wrapped the
        # 400 raised two lines up into ``500 "setting update failed: 400:
        # unknown setting key"``.  A handler's own HTTPException keeps its
        # status.
        raise
    except (KeyError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except DbHandleUnavailable as exc:
        # 2026-10-08 (found live): the module's "db_manager unavailable"
        # left here as a 500, and the platform's 500 handler erases every
        # 500 body by design (CWE-209) -- the operator read "contact
        # support" for a setting that was simply not persisted.  "No
        # manager in this process" is an AVAILABILITY statement: 503,
        # authored text, ``from None`` so the handler passes it through.
        raise HTTPException(status_code=503, detail=str(exc)) from None
    except Exception as exc:
        raise HTTPException(status_code=500,
                            detail=f"setting update failed: {exc}")


@router.post("/api/admin/iceberg-sync/watched")
async def iceberg_sync_pin_table(body: dict, _user: dict = Depends(require_admin)):
    """Pin a table to the watched registry (sync runs even if no recent
    queries against it).  Body: {connection_id, bucket, table_prefix,
    pinned?, enabled?}.
    """
    cid = (body or {}).get("connection_id")
    bucket = (body or {}).get("bucket")
    prefix = (body or {}).get("table_prefix")
    if not cid or not bucket or not prefix:
        raise HTTPException(status_code=400,
                              detail="connection_id, bucket, table_prefix required")
    try:
        # BF-NONBLOCK-AUDIT-3: wrap sync DB upsert.
        row = await asyncio.wait_for(
            asyncio.to_thread(
                _db_manager.upsert_watched_iceberg_table,
                connection_id=int(cid), bucket=bucket, table_prefix=prefix,
                pinned=body.get("pinned", True),
                enabled=body.get("enabled", True),
            ),
            timeout=10.0,
        )
        return row
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Pin failed: {exc}")


@router.delete("/api/admin/iceberg-sync/watched")
async def iceberg_sync_unwatch_table(
    connection_id: int, bucket: str, table_prefix: str,
    _user: dict = Depends(require_admin),
):
    """Stop syncing a single table."""
    try:
        # BF-NONBLOCK-AUDIT-3: wrap sync DB delete.
        deleted = await asyncio.wait_for(
            asyncio.to_thread(
                _db_manager.delete_watched_iceberg_table,
                connection_id=connection_id, bucket=bucket, table_prefix=table_prefix,
            ),
            timeout=10.0,
        )
        return {"deleted": deleted}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Unwatch failed: {exc}")


def _require_recent_dates_fields(rule: dict) -> None:
    """A recent_dates rule needs a partition column and a positive lookback."""
    if not rule.get("partition_column"):
        raise HTTPException(status_code=400,
                              detail="recent_dates requires partition_column")
    if not isinstance(rule.get("lookback_days"), int) or rule["lookback_days"] <= 0:
        raise HTTPException(status_code=400,
                              detail="recent_dates requires lookback_days > 0")


def _require_specific_dates_fields(rule: dict) -> None:
    """A specific_dates rule needs a partition column and a non-empty list."""
    if not rule.get("partition_column"):
        raise HTTPException(status_code=400,
                              detail="specific_dates requires partition_column")
    if not isinstance(rule.get("dates"), list) or not rule["dates"]:
        raise HTTPException(status_code=400,
                              detail="specific_dates requires non-empty dates list")


def _validate_predownload_rule(rule) -> None:
    """Refuse a predownload rule whose strategy lacks its required fields.

    Light validation only — a strategy that cannot be executed must be
    rejected at admission rather than stored and silently skipped.
    """
    if not isinstance(rule, dict):
        raise HTTPException(status_code=400, detail="rule must be an object or null")
    strategy = (rule.get("strategy") or "").lower()
    valid = {"off", "top_n_by_record_count", "top_n",
             "recent_dates", "specific_dates", "custom"}
    if strategy and strategy not in valid:
        raise HTTPException(
            status_code=400,
            detail=f"strategy must be one of: {', '.join(sorted(valid))}")
    if strategy == "recent_dates":
        _require_recent_dates_fields(rule)
    if strategy == "specific_dates":
        _require_specific_dates_fields(rule)
    if strategy == "custom":
        if not isinstance(rule.get("filters"), list) or not rule["filters"]:
            raise HTTPException(status_code=400,
                                  detail="custom requires non-empty filters list")


@router.post("/api/admin/iceberg-sync/predownload-rule")
async def set_predownload_rule(body: dict, _user: dict = Depends(require_admin)):
    """BF-318 — set the per-table predownload rule.

    Body:
      {
        "connection_id": int,
        "bucket": str,
        "table_prefix": str,
        "rule": {
          "strategy": "off"               // skip predownload entirely for this table
                    | "top_n_by_record_count"   // current default behaviour
                    | "recent_dates"        // partition[col] >= today - lookback_days
                    | "specific_dates"      // partition[col] in [...]
                    | "custom",             // arbitrary {col, op, val} list
          // strategy-specific fields:
          "partition_column": "business_close_date",  // recent_dates / specific_dates
          "lookback_days":    60,                      // recent_dates
          "dates":            ["2025-09-30", ...],     // specific_dates
          "filters":          [{col, op, val}],         // custom
          // optional caps (override the global iceberg.metadata_sync_predownload_*)
          "max_files":        500,
          "max_gb":           20
        }
      }

    To clear a rule (revert to global defaults), pass rule=null.
    """
    cid = (body or {}).get("connection_id")
    bucket = (body or {}).get("bucket")
    table_prefix = (body or {}).get("table_prefix")
    rule = (body or {}).get("rule")
    if not (cid and bucket and table_prefix):
        raise HTTPException(status_code=400,
                              detail="connection_id, bucket, table_prefix required")
    # Light validation
    if rule is not None:
        _validate_predownload_rule(rule)
    try:
        # BF-NONBLOCK-AUDIT-3: wrap sync DB upsert (rule editor save).
        return await asyncio.wait_for(
            asyncio.to_thread(
                _db_manager.upsert_watched_iceberg_table,
                connection_id=int(cid), bucket=bucket, table_prefix=table_prefix,
                predownload_rule=rule,
            ),
            timeout=10.0,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Save rule failed: {exc}")


def _require_int_at_least(rule: dict, key: str, minimum: int, detail: str) -> None:
    """Refuse when ``rule[key]`` is present but is not an int >= ``minimum``."""
    if key not in rule:
        return
    try:
        if int(rule[key]) < minimum:
            raise ValueError
    except (TypeError, ValueError):
        raise HTTPException(status_code=400, detail=detail)


def _validate_column_stats_rule(rule) -> None:
    """Refuse a malformed per-table column-stats rule with a 400.

    Every key is optional, but a key that IS present must be well-typed —
    an unusable override would otherwise be stored and silently ignored.
    """
    if not isinstance(rule, dict):
        raise HTTPException(status_code=400, detail="rule must be an object or null")
    if "enabled" in rule and not isinstance(rule["enabled"], bool):
        raise HTTPException(status_code=400, detail="enabled must be boolean")
    _require_int_at_least(rule, "max_files", 0,
                          "max_files must be an integer >= 0")
    _require_int_at_least(rule, "workers", 1,
                          "workers must be an integer >= 1")
    if "columns" in rule and rule["columns"] is not None:
        if not isinstance(rule["columns"], list) or not all(
            isinstance(c, str) and c.strip() for c in rule["columns"]
        ):
            raise HTTPException(
                status_code=400,
                detail="columns must be a list of non-empty strings or null",
            )
    unknown = set(rule.keys()) - {"enabled", "max_files", "workers", "columns"}
    if unknown:
        raise HTTPException(
            status_code=400,
            detail=f"unknown keys in rule: {sorted(unknown)}",
        )


def _clear_column_stats_rule(cid, bucket: str, table_prefix: str):
    """Drop a table's column-stats override so it follows the global config."""
    from core.db.models import WatchedIcebergTable
    with _db_manager.get_session() as session:
        row = session.query(WatchedIcebergTable).filter(
            WatchedIcebergTable.connection_id == int(cid),
            WatchedIcebergTable.bucket == bucket,
            prefix_matches(WatchedIcebergTable.table_prefix, table_prefix),
        ).first()
        if not row:
            # Nothing to clear — create the row with a NULL rule so the
            # caller sees the same shape as if a row had existed.
            return _db_manager.upsert_watched_iceberg_table(
                connection_id=int(cid), bucket=bucket,
                table_prefix=table_prefix,
            )
        row.column_stats_rule = None
        session.flush()
        return row.to_dict()


@router.post("/api/admin/iceberg-sync/column-stats-rule")
async def set_column_stats_rule(body: dict, _user: dict = Depends(require_admin)):
    """Set the per-table column-stats scan rule.

    Body:
      {
        "connection_id": int,
        "bucket": str,
        "table_prefix": str,
        "rule": {
          "enabled":   bool,          // override iceberg.column_stats_sync_enabled
          "max_files": int,           // override max_files_per_tick (0 = unlimited)
          "workers":   int,           // override worker concurrency
          "columns":   ["col_a", ...] // scan only these columns (null = all)
        }
      }

    When ``rule`` is null, the per-table override is cleared and the table
    falls back to the global iceberg.column_stats_sync_* config.  Any
    omitted key in the rule object also falls back to the global default.
    """
    cid = (body or {}).get("connection_id")
    bucket = (body or {}).get("bucket")
    table_prefix = (body or {}).get("table_prefix")
    rule = (body or {}).get("rule")
    if not (cid and bucket and table_prefix):
        raise HTTPException(status_code=400,
                              detail="connection_id, bucket, table_prefix required")
    if rule is not None:
        _validate_column_stats_rule(rule)
    # ``rule=null`` must actually CLEAR the override (back to global defaults).
    # The upsert helper short-circuits on None (matching its existing semantic
    # for predownload_rule), so we go through a small direct UPDATE for the
    # clear case.  Non-null rules go through upsert as usual.
    def _do_save():
        if rule is None:
            return _clear_column_stats_rule(cid, bucket, table_prefix)
        return _db_manager.upsert_watched_iceberg_table(
            connection_id=int(cid), bucket=bucket, table_prefix=table_prefix,
            column_stats_rule=rule,
        )

    try:
        return await asyncio.wait_for(asyncio.to_thread(_do_save), timeout=10.0)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Save column-stats rule failed: {exc}")


# ── BF-296: Iceberg Snapshot-keyed Metadata Cache ──────────────────────────────

_SNAPSHOT_CACHE_STATS_CACHE: Dict[str, Any] = {"value": None, "expires_at": 0.0}
_SNAPSHOT_CACHE_STATS_TTL_SECONDS = 30.0  # Refresh at most every 30 s


@router.get("/api/admin/iceberg-snapshot-cache/stats")
async def iceberg_snapshot_cache_stats(_user: dict = Depends(require_admin)):
    """L1 pointer cache + L2 contents cache telemetry.

    BF-WS-NOBLOCK-3: this endpoint is polled by the admin UI on a tight
    loop during manual syncs.  Two prior issues were causing 10 s
    response times that starved the asyncio loop and silently killed
    WebSockets:
      1. SELECT 1000 rows + sum-in-Python   → replaced with one COUNT/SUM SQL query
      2. 10 s timeout on the wait_for       → dropped to 3 s
      3. Multiple in-flight calls stacking  → 30 s in-process result cache
    """
    import time
    from core.iceberg_snapshot_cache import cache_stats as _ic_stats
    s = _ic_stats()

    # In-process cache — admin UI polls this every ~5 s during manual
    # syncs but the underlying numbers don't change that fast, and they
    # get refreshed by the metadata sync loop anyway.
    now_ts = time.monotonic()
    cached = _SNAPSHOT_CACHE_STATS_CACHE.get("value")
    if cached and now_ts < _SNAPSHOT_CACHE_STATS_CACHE.get("expires_at", 0.0):
        s.update(cached)
        s["_cache_age_seconds"] = round(
            _SNAPSHOT_CACHE_STATS_TTL_SECONDS - (_SNAPSHOT_CACHE_STATS_CACHE["expires_at"] - now_ts), 1)
        return s

    try:
        from core.iceberg_metadata_sync import _run_off_loop as _ms_off_loop
        agg = await asyncio.wait_for(
            _ms_off_loop(_db_manager.iceberg_snapshot_cache_summary),
            timeout=3.0,
        )
        s.update(agg or {})
        _SNAPSHOT_CACHE_STATS_CACHE["value"] = dict(agg or {})
        _SNAPSHOT_CACHE_STATS_CACHE["expires_at"] = now_ts + _SNAPSHOT_CACHE_STATS_TTL_SECONDS
    except (asyncio.TimeoutError, Exception) as _exc:
        # Fail-soft: preserve any prior cached value rather than zeroing
        if cached:
            s.update(cached)
        else:
            s.setdefault("l2_row_count", 0)
            s.setdefault("l2_total_files", 0)
            s.setdefault("l2_total_bytes", 0)
        s["_stats_error"] = type(_exc).__name__
    return s


@router.get("/api/admin/iceberg-snapshot-cache/list")
async def iceberg_snapshot_cache_list(
    bucket: Optional[str] = None,
    limit: int = Query(100, ge=1, le=1000),
    _user: dict = Depends(require_admin),
):
    """Return cached snapshot rows for the admin UI."""
    pointers = []
    try:
        from core.iceberg_snapshot_cache import list_pointer_entries
        pointers = list_pointer_entries()
    except Exception:
        pass
    rows = []
    try:
        # BF-NONBLOCK-AUDIT-3: wrap sync DB scan.
        rows = await asyncio.wait_for(
            asyncio.to_thread(
                _db_manager.list_iceberg_snapshot_cache,
                bucket=bucket, limit=limit,
            ),
            timeout=10.0,
        )
    except (asyncio.TimeoutError, Exception):
        pass
    return {"pointers": pointers, "rows": rows}


def _verify_manifest_sample(manifest_entries, sample_keys: list, sample_size: int) -> None:
    """Append this manifest's parquet file keys until the sample is full."""
    for entry in manifest_entries:
        df = entry.get("data_file") or {}
        fp = df.get("file_path") or df.get("path") or ""
        if not fp.endswith(".parquet"):
            continue
        # Strip s3:// prefix
        if fp.startswith("s3://"):
            fp = fp.split("/", 3)[-1] if fp.count("/") >= 3 else fp
        sample_keys.append(fp)
        if len(sample_keys) >= sample_size:
            break


def _verify_sample_keys(files, sample_size: int) -> List[str]:
    """The first ``sample_size`` parquet keys held in the cached contents."""
    # Pull first N file paths
    sample_keys: List[str] = []
    for manifest_entries in files:
        _verify_manifest_sample(manifest_entries, sample_keys, sample_size)
        if len(sample_keys) >= sample_size:
            break
    return sample_keys


def _verify_cache_root() -> Optional[str]:
    """Absolute root of the local S3 file cache, or None when it is off."""
    try:
        from core.config import s3_local_cache as _sclc
        return os.path.abspath(_sclc.cache_dir) if _sclc.enabled and _sclc.cache_dir else None
    except Exception:
        return None


def _verify_new_buckets() -> Dict[str, list]:
    """Empty verdict buckets for one verify run."""
    return {
        "match":           [],
        "size_mismatch":   [],
        "missing_in_s3":   [],
        "missing_locally": [],
        "s3_only":         [],
    }


def _verify_local_size(local_path: str) -> int:
    """Size of the locally cached file, or -1 when it cannot be stat'd."""
    try:
        return os.path.getsize(local_path)
    except OSError:
        return -1


def _verify_classify_local(key: str, s3_size: int, cache_root: str,
                           bucket: str, buckets: Dict[str, list]) -> None:
    """File one key by comparing the locally cached copy against its S3 size."""
    local_path = os.path.normpath(os.path.join(cache_root, bucket, key))
    if not os.path.exists(local_path):
        buckets["s3_only"].append(key)
        return
    local_size = _verify_local_size(local_path)
    if local_size == s3_size:
        buckets["match"].append(key)
    elif local_size == -1:
        buckets["missing_locally"].append(key)
    else:
        buckets["size_mismatch"].append({
            "key": key, "s3_size": s3_size, "local_size": local_size,
        })


def _verify_one_key(s3, bucket: str, key: str, cache_root: Optional[str],
                    buckets: Dict[str, list]) -> None:
    """head_object one cached file and record the verdict for it.

    A 404-shaped error means the file expired in S3; anything else is
    reported as a mismatch carrying the error text.
    """
    try:
        resp = s3.head_object(Bucket=bucket, Key=key)
        s3_size = int(resp.get("ContentLength", 0))
    except Exception as exc:
        err = str(exc)
        if "404" in err or "NoSuchKey" in err or "Not Found" in err:
            buckets["missing_in_s3"].append(key)
        else:
            buckets["size_mismatch"].append({"key": key, "error": err[:200]})
        return
    if cache_root:
        _verify_classify_local(key, s3_size, cache_root, bucket, buckets)
    else:
        buckets["match"].append(key)


def _verify_build_s3_client(cid):
    """The S3 client for a verify run, refusing loudly when it cannot be built."""
    try:
        from core.iceberg_metadata_sync import _build_s3_client
        s3 = _build_s3_client(int(cid))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"S3 client failed: {exc}")
    if s3 is None:
        raise HTTPException(status_code=500, detail="No S3 client")
    return s3


@router.post("/api/admin/iceberg-snapshot-cache/verify")
async def iceberg_snapshot_cache_verify(
    body: dict,
    _user: dict = Depends(require_admin),
):
    """BF-317 — verify cached files match S3.

    Iceberg's design says they always will (path-keyed immutable files),
    but this endpoint lets admin PROVE it on demand:
      1. Take the first N cached files for a table
      2. head_object each one on S3 to read its current size
      3. Compare to the local cache file's size
      4. Report match / mismatch / missing

    Body: {connection_id, bucket, table_prefix, sample_size?: int}.
    sample_size defaults to 20, max 200 (head_object is cheap but
    bounded so a verify run can't hammer S3).

    Returns:
      {
        "checked": N,
        "match": M,                 # local size == S3 size
        "size_mismatch": [],        # if any: integrity issue or partial download
        "missing_in_s3": [],        # files cached locally but no longer in S3 (expired)
        "missing_locally": [],      # cached metadata says we have them but disk doesn't
        "verified_paths": [...],
      }
    """
    body = body or {}
    cid = body.get("connection_id")
    bucket = body.get("bucket")
    table_prefix = body.get("table_prefix")
    sample_size = min(200, max(1, int(body.get("sample_size", 20) or 20)))
    if not (cid and bucket and table_prefix):
        raise HTTPException(status_code=400,
                              detail="connection_id, bucket, table_prefix required")
    from core.iceberg_snapshot_cache import get_cached_contents
    sid = await _resolve_cached_snapshot_id(bucket, table_prefix)
    if not sid:
        raise HTTPException(status_code=404, detail="No cache entry for this table")
    files = get_cached_contents(bucket, table_prefix, sid)
    if not files:
        raise HTTPException(status_code=404, detail="Cache contents empty")

    sample_keys = _verify_sample_keys(files, sample_size)

    # Local cache root
    cache_root = _verify_cache_root()

    # Build S3 client
    s3 = _verify_build_s3_client(cid)

    # BF-NONBLOCK-AUDIT: was a sync loop of up to 200 s3.head_object() calls
    # in the async handler — 20-60s blocking on cold S3, holding the FastAPI
    # request thread → /health probes time out + WS disconnect.  Wrapped in
    # asyncio.to_thread + 30s timeout.
    def _do_verify():
        buckets = _verify_new_buckets()
        for key in sample_keys:
            _verify_one_key(s3, bucket, key, cache_root, buckets)
        return (buckets["match"], buckets["size_mismatch"],
                buckets["missing_in_s3"], buckets["missing_locally"],
                buckets["s3_only"])

    try:
        match, size_mismatch, missing_in_s3, missing_locally, s3_only = await asyncio.wait_for(
            asyncio.to_thread(_do_verify), timeout=30.0,
        )
    except asyncio.TimeoutError:
        raise HTTPException(
            status_code=202,
            detail=f"Verify exceeded 30s budget for {len(sample_keys)} files — try a smaller sample_size",
        )

    return {
        "checked":           len(sample_keys),
        "snapshot_id":       sid,
        "cache_root":        cache_root,
        "match":             len(match),
        "size_mismatch":     size_mismatch,
        "missing_in_s3":     missing_in_s3,
        "missing_locally":   missing_locally,
        "s3_only_not_cached": s3_only,
        "verdict": (
            "INTEGRITY OK — every checked file matches S3"
            if not size_mismatch and not missing_in_s3 and not missing_locally else
            f"INVESTIGATE — {len(size_mismatch)} mismatch · "
            f"{len(missing_in_s3)} expired · {len(missing_locally)} missing"
        ),
    }


def _inspect_serialise(v):
    """Convert bytes/dates to strings so the JSON response is serialisable."""
    if isinstance(v, (bytes, bytearray)):
        return f"<{len(v)} bytes: {v.hex()[:40]}…>"
    if hasattr(v, "isoformat"):
        return v.isoformat()
    if isinstance(v, dict):
        return {str(k): _inspect_serialise(vv) for k, vv in v.items()}
    if isinstance(v, list):
        return [_inspect_serialise(x) for x in v]
    return v


def _inspect_sample_row(df: dict, lb: dict, ub: dict) -> Dict[str, Any]:
    """One JSON-safe sample row for the cache-inspect response."""
    return {
        "file_path":     df.get("file_path"),
        "record_count":  df.get("record_count"),
        "size_bytes":    df.get("file_size_in_bytes"),
        "partition":     _inspect_serialise(df.get("partition") or {}),
        "lower_bounds":  _inspect_serialise(lb),
        "upper_bounds":  _inspect_serialise(ub),
        "lower_bounds_key_types": list(set(type(k).__name__ for k in lb.keys())) if lb else [],
    }


def _inspect_manifest_entries(manifest_entries, sample: list,
                              files_with_lb: Dict[str, int]) -> int:
    """Fold one manifest into the sample + bound coverage; return entries seen."""
    total = 0
    for entry in manifest_entries:
        total += 1
        df = entry.get("data_file") or {}
        lb = df.get("lower_bounds") or {}
        ub = df.get("upper_bounds") or {}
        # Track which field IDs have bounds across the whole sample
        for fid in lb.keys():
            k = str(fid)
            files_with_lb[k] = files_with_lb.get(k, 0) + 1
        if len(sample) < 3:
            sample.append(_inspect_sample_row(df, lb, ub))
    return total


def _inspect_scan_entries(files):
    """Walk the cached contents once: sample rows, entry count, bound coverage."""
    sample: list = []
    total = 0
    files_with_lb: Dict[str, int] = {}
    for manifest_entries in files:
        total += _inspect_manifest_entries(manifest_entries, sample, files_with_lb)
    return sample, total, files_with_lb


async def _resolve_cached_snapshot_id(bucket: str, table_prefix: str):
    """The cached snapshot pointer for a table, else the most recent DB row."""
    from core.iceberg_snapshot_cache import get_cached_snapshot_id
    sid = get_cached_snapshot_id(bucket, table_prefix)
    if sid:
        return sid
    # Fall back to most recent DB row
    rows = await _adb(_db_manager.list_iceberg_snapshot_cache, bucket=bucket, limit=10)
    rows = [r for r in rows if same_prefix(r.get("table_prefix"), table_prefix)]
    if rows:
        return rows[0].get("snapshot_id")
    return None


@router.get("/api/admin/iceberg-snapshot-cache/inspect")
async def iceberg_snapshot_cache_inspect(
    bucket: str,
    table_prefix: str,
    snapshot_id: Optional[str] = None,
    _user: dict = Depends(require_admin),
):
    """BF-316 — INSPECT cache contents to verify bounds are present.

    Returns a sample (first 3 entries) from the cached manifest data
    showing exactly what's in the cache: file_path, partition,
    lower_bounds, upper_bounds, record_count.

    Use this to answer "is column-stats pruning even possible for my
    filter columns?" — if lower_bounds is empty for those fields, the
    writer didn't save min/max and pruning can't help.
    """
    try:
        from core.iceberg_snapshot_cache import get_cached_contents
        # If snapshot_id not provided, look up the pointer
        sid = snapshot_id or await _resolve_cached_snapshot_id(
            bucket, table_prefix)
        if not sid:
            raise HTTPException(status_code=404,
                                  detail="No cache entry found for this table")

        files = get_cached_contents(bucket, table_prefix, sid)
        if files is None:
            raise HTTPException(status_code=404,
                                  detail=f"No cached contents for snapshot {sid}")

        # Sample the first 3 entries from the first manifest
        sample, total, files_with_lb = _inspect_scan_entries(files)

        return {
            "bucket":      bucket,
            "table_prefix": table_prefix,
            "snapshot_id": sid,
            "total_entries": total,
            "sample_first_3": sample,
            "field_id_with_lower_bound_coverage":
                [{"field_id": k, "files_with_bound": v,
                   "pct_of_total": round(100 * v / max(1, total), 1)}
                 for k, v in sorted(files_with_lb.items())],
            "diagnostic_hints": {
                "if_sample_lower_bounds_empty":
                    "Writer did NOT save column min/max stats.  Re-write "
                    "the table via Spark with '--conf spark.sql.parquet."
                    "writeLegacyFormat=false' or Trino with column stats enabled.",
                "if_lower_bounds_key_types_has_str":
                    "Bounds were stored with STRING keys (legacy from before "
                    "BF-305 int-key wrap).  Clear cache to force re-fetch with "
                    "proper int keys.",
                "if_only_some_files_have_bounds":
                    "Some manifests pre-date the writer enabling stats.  "
                    "Pruning works partially — re-COMPACT the table to "
                    "rewrite all files with consistent stats.",
            },
        }
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"inspect failed: {exc}")


@router.post("/api/admin/iceberg-snapshot-cache/refresh")
async def iceberg_snapshot_cache_refresh(
    body: dict,
    _user: dict = Depends(require_admin),
):
    """Drop the L1 pointer for a single table so the next read fetches
    the latest metadata.json and (potentially) a new snapshot_id.

    Body: {bucket, table_prefix}
    """
    bucket = (body or {}).get("bucket", "")
    table_prefix = (body or {}).get("table_prefix", "")
    if not bucket or not table_prefix:
        raise HTTPException(status_code=400, detail="bucket and table_prefix required")
    try:
        from core.iceberg_snapshot_cache import invalidate_pointer
        evicted = invalidate_pointer(bucket, table_prefix)
        return {"evicted": evicted, "bucket": bucket, "table_prefix": table_prefix}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Refresh failed: {exc}")


@router.delete("/api/admin/iceberg-snapshot-cache/clear")
async def iceberg_snapshot_cache_clear(
    bucket: Optional[str] = None,
    table_prefix: Optional[str] = None,
    snapshot_id: Optional[str] = None,
    _user: dict = Depends(require_admin),
):
    """Clear the L1 pointer cache + the L2 DB rows.  Filterable."""
    p_evicted = 0
    try:
        from core.iceberg_snapshot_cache import (
            invalidate_all_pointers, invalidate_pointer,
        )
        if bucket and table_prefix:
            p_evicted = 1 if invalidate_pointer(bucket, table_prefix) else 0
        else:
            p_evicted = invalidate_all_pointers()
    except Exception:
        pass
    l2_evicted = 0
    try:
        l2_evicted = await _adb(_db_manager.delete_iceberg_snapshot_cache,
            bucket=bucket, table_prefix=table_prefix, snapshot_id=snapshot_id,
        )
    except Exception:
        pass
    # BF-500 — also drop L1 in-process snapshot-content cache.  Without
    # this, a partially-populated L1 entry from a previous interrupted
    # sync stays cached and the watched-tables registry keeps returning
    # "half the files" until the process restarts.  Admin "Clear cache"
    # should mean ALL layers.
    l1_contents_evicted = 0
    try:
        from core.iceberg_snapshot_cache import (
            invalidate_contents, invalidate_all_contents,
        )
        if bucket and table_prefix:
            l1_contents_evicted = invalidate_contents(
                bucket, table_prefix, snapshot_id,
            )
        else:
            l1_contents_evicted = invalidate_all_contents()
    except Exception:
        pass
    return {
        "pointers_evicted":     p_evicted,
        "rows_evicted":         l2_evicted,
        "l1_contents_evicted":  l1_contents_evicted,
    }


# ── Iceberg File Cache ─────────────────────────────────────────────────────────

@router.get("/api/admin/iceberg-cache/stats")
async def iceberg_cache_stats(_user: dict = Depends(require_admin)):
    """Get Iceberg file cache statistics (L1 in-memory + L2 persistent)."""
    import time as _t
    from core.iceberg_cache import ICE_FILE_CACHE as _ICE_FILE_CACHE, ICE_FILE_CACHE_TTL as _ICE_FILE_CACHE_TTL
    now = _t.monotonic()
    l1_entries = len(_ICE_FILE_CACHE)
    l1_active = sum(1 for v in _ICE_FILE_CACHE.values() if now - v["ts"] < _ICE_FILE_CACHE_TTL)
    # L2 stats from DB
    l2_entries = 0
    try:
        all_l2 = await _adb(_db_manager.list_iceberg_file_cache) if hasattr(_db_manager, "list_iceberg_file_cache") else []
        l2_entries = len(all_l2)
    except Exception:
        pass
    return {"l1_total": l1_entries, "l1_active": l1_active, "l2_total": l2_entries}


def _iceberg_cache_matching_keys(cache, connection_id, table_name) -> list:
    """L1 cache keys that match the optional connection / table filters."""
    keys_to_remove = []
    for k in list(cache.keys()):
        cid, tname, _ = k
        if connection_id and cid != connection_id:
            continue
        if table_name and tname != table_name:
            continue
        keys_to_remove.append(k)
    return keys_to_remove


async def _iceberg_cache_delete_l2(**filters) -> int:
    """Best-effort L2 delete.  -1 means "all of them, exact count unknown"."""
    try:
        await _adb(_db_manager.delete_iceberg_file_cache, **filters)
        return -1  # unknown exact count
    except Exception:
        return 0


def _clear_brain_result_cache() -> int:
    """Bust the brain SQL-hash RESULT cache (cached DATA, not just a file list).

    Also drops the pruning memo generation, so an operator "clear cache"
    fully takes effect for a pruning/stats change instead of a cached result
    or survivor list surviving until TTL.  Small + fail-open.
    """
    try:
        from core.agg_cache import invalidate_brain_cache_all as _inv_agg
        return _inv_agg()
    except Exception:
        return 0


@router.delete("/api/admin/iceberg-cache/clear")
async def clear_iceberg_cache(
    connection_id: int = None, table_name: str = None,
    _user: dict = Depends(require_admin),
):
    """Clear Iceberg file cache. Optional connection_id/table_name filters."""
    from core.iceberg_cache import ICE_FILE_CACHE as _ICE_FILE_CACHE
    l1_cleared = 0
    l2_cleared = 0
    if connection_id or table_name:
        # Selective clear
        for k in _iceberg_cache_matching_keys(_ICE_FILE_CACHE,
                                              connection_id, table_name):
            _ICE_FILE_CACHE.pop(k, None)
            l1_cleared += 1
        l2_cleared = await _iceberg_cache_delete_l2(
            connection_id=connection_id, table_name=table_name)
    else:
        l1_cleared = len(_ICE_FILE_CACHE)
        _ICE_FILE_CACHE.clear()
        l2_cleared = await _iceberg_cache_delete_l2()
    _result_cache_cleared = _clear_brain_result_cache()
    audit_event(_db_manager, _user, None, "clear_iceberg_cache", "iceberg_cache",
                details={"connection_id": connection_id, "table_name": table_name})
    return {"l1_cleared": l1_cleared,
            "l2_cleared": "all" if l2_cleared == -1 else l2_cleared,
            "brain_result_cache_cleared": _result_cache_cleared}


# ── S3 Local Cache (BF-257 NFS PVC) ────────────────────────────────────────────
# Function existed in duckdb_views.py but had no HTTP exposure — the NFS-backed
# file cache was invisible from the admin UI.  Two endpoints here: stats for
# the storage-overview page, and an explicit LRU eviction trigger.

@router.get("/api/admin/s3-local-cache/stats")
async def s3_local_cache_stats(_user: dict = Depends(require_admin)):
    """BF-257 — read-only stats for the persistent NFS S3-file cache:
    enabled flag, cache dir, file count, total bytes vs max, utilisation."""
    try:
        from core.duckdb_views import s3_cache_stats
        return s3_cache_stats()
    except Exception as exc:
        return {"status": "error", "error": str(exc)[:300]}


@router.post("/api/admin/s3-local-cache/evict")
async def s3_local_cache_evict(_user: dict = Depends(require_admin)):
    """Trigger an LRU eviction pass on the BF-257 cache right now.  The
    scheduler already runs this periodically; this endpoint lets admin
    force a sweep without waiting."""
    try:
        from core.duckdb_views import evict_s3_cache_lru
        result = evict_s3_cache_lru()
        audit_event(_db_manager, _user, None, "evict_s3_local_cache",
                    "s3_local_cache", details=result)
        return result
    except Exception as exc:
        raise HTTPException(status_code=500,
                            detail=f"S3 cache eviction failed: {exc}")


# ── Storage & Caches Overview (single aggregated endpoint) ────────────────────
# Replaces the 8-page admin maze where each cache layer had its own UI but no
# single view answered "what's the storage footprint of all caches on this pod?"
# Calls every existing stats endpoint in parallel + tolerates each one failing
# independently so a partial degradation never blanks the whole page.

def _storage_row(key: str, name: str, **kw) -> Dict[str, Any]:
    """One storage-overview row in the shape the admin page expects."""
    return {
        "key": key, "name": name,
        "status":     kw.get("status", "ok"),
        "enabled":    kw.get("enabled", True),
        "entries":    kw.get("entries"),
        "size_bytes": kw.get("size_bytes"),
        "hit_rate":   kw.get("hit_rate"),
        "hits":       kw.get("hits"),
        "misses":     kw.get("misses"),
        "extra":      kw.get("extra") or {},
        "clear_url":  kw.get("clear_url"),
        "clear_method": kw.get("clear_method", "DELETE"),
        "error":      kw.get("error"),
    }


def _storage_layer_query_cache() -> Dict[str, Any]:
    """Query result cache (general — /api/cache/stats)."""
    try:
        from core.query_cache import get_stats as _qc_stats
        s = _qc_stats() or {}
        return _storage_row(
            "query_cache", "Query Result Cache",
            enabled=bool(s.get("enabled", True)),
            entries=s.get("entry_count") or s.get("total_entries") or s.get("count"),
            size_bytes=s.get("total_size_bytes") or s.get("size_bytes"),
            hit_rate=s.get("hit_rate"),
            hits=s.get("hits"), misses=s.get("misses"),
            clear_url="/api/cache", clear_method="DELETE",
            extra={k: v for k, v in s.items()
                   if k not in {"enabled", "entry_count", "total_entries", "count",
                                "total_size_bytes", "size_bytes",
                                "hit_rate", "hits", "misses"}},
        )
    except Exception as exc:
        return _storage_row("query_cache", "Query Result Cache",
                            status="unavailable", error=str(exc)[:200])


def _storage_layer_result_cache() -> Dict[str, Any]:
    """Result Cache (BF-382 / Option D) — instance method, lazy singleton."""
    try:
        from core.result_cache import get_result_cache
        _rc = get_result_cache()
        if _rc is None:
            return _storage_row("result_cache", "Result Cache (Option D)",
                                enabled=False, status="disabled")
        s = _rc.stats() or {}
        _hits = (s.get("l1_hits", 0) or 0) + (s.get("l2_hits", 0) or 0)
        _misses = (s.get("l1_misses", 0) or 0) + (s.get("l2_misses", 0) or 0)
        _total = _hits + _misses
        return _storage_row(
            "result_cache", "Result Cache (Option D)",
            enabled=True,
            entries=(s.get("l1_entries", 0) or 0) + (s.get("l2_entries", 0) or 0),
            size_bytes=(s.get("l1_size_bytes", 0) or 0) + (s.get("l2_size_bytes", 0) or 0),
            hits=_hits, misses=_misses,
            hit_rate=(_hits / _total) if _total > 0 else None,
            clear_url="/api/admin/result-cache/clear", clear_method="POST",
            extra=s,
        )
    except Exception as exc:
        return _storage_row("result_cache", "Result Cache (Option D)",
                            status="unavailable", error=str(exc)[:200])


def _storage_layer_cache_abstraction() -> List[Dict[str, Any]]:
    """Cache abstraction layer (schema / partition / br_results) — one row each."""
    rows: List[Dict[str, Any]] = []
    try:
        from core.cache_layer import get_all_cache_stats
        for name, s in (get_all_cache_stats() or {}).items():
            s = s or {}
            rows.append(_storage_row(
                f"cache_layer:{name}", f"Cache Layer — {name}",
                enabled=bool(s.get("enabled", True)),
                entries=s.get("size") or s.get("entries"),
                size_bytes=s.get("size_bytes"),
                hit_rate=s.get("hit_rate"),
                hits=s.get("hits"), misses=s.get("misses"),
                extra=s,
            ))
    except Exception as exc:
        rows.append(_storage_row("cache_layer", "Cache Abstraction Layer",
                                 status="unavailable", error=str(exc)[:200]))
    return rows


def _storage_layer_iceberg_snapshot_cache() -> Dict[str, Any]:
    """Iceberg snapshot cache (BF-296 / contents + pointer)."""
    try:
        from core.iceberg_snapshot_cache import cache_stats as _ic_stats
        s = _ic_stats() or {}
        _hits = (s.get("contents_l1_hits", 0) + s.get("contents_l2_hits", 0)
                 + s.get("pointer_hits", 0))
        _misses = s.get("contents_misses", 0) + s.get("pointer_misses", 0)
        total = _hits + _misses
        return _storage_row(
            "iceberg_snapshot_cache", "Iceberg Snapshot Cache",
            enabled=bool(s.get("enabled", True)),
            entries=s.get("l2_row_count") or s.get("contents_count"),
            size_bytes=s.get("l2_total_bytes"),
            hits=_hits, misses=_misses,
            hit_rate=(_hits / total) if total > 0 else None,
            extra=s,
        )
    except Exception as exc:
        return _storage_row("iceberg_snapshot_cache", "Iceberg Snapshot Cache",
                            status="unavailable", error=str(exc)[:200])


def _storage_layer_iceberg_file_cache() -> Dict[str, Any]:
    """Iceberg file cache (legacy L1+L2)."""
    try:
        import time as _t
        from core.iceberg_cache import (ICE_FILE_CACHE as _IFC,
                                          ICE_FILE_CACHE_TTL as _IFC_TTL)
        now = _t.monotonic()
        l1_active = sum(1 for v in _IFC.values() if now - v["ts"] < _IFC_TTL)
        return _storage_row(
            "iceberg_file_cache", "Iceberg File Cache (L1+L2)",
            entries=len(_IFC),
            clear_url="/api/admin/iceberg-cache/clear", clear_method="DELETE",
            extra={"l1_total": len(_IFC), "l1_active": l1_active,
                    "ttl_seconds": _IFC_TTL},
        )
    except Exception as exc:
        return _storage_row("iceberg_file_cache", "Iceberg File Cache (L1+L2)",
                            status="unavailable", error=str(exc)[:200])


async def _storage_layer_iceberg_col_stats() -> Dict[str, Any]:
    """Iceberg column-stats supplement (BF-COL-STATS).

    2026-06-03 — wrapped 3 sync count(distinct) aggregates in
    asyncio.to_thread; these can be slow on a populated supplement
    table and were blocking the event loop.
    """
    try:
        from core.db.models import IcebergColumnStatsSupplement as _CS
        def _col_stats_counts():
            with _db_manager.get_session(read_only=True) as _sess:
                from sqlalchemy import func as _sa_func
                _row_count = _sess.query(_sa_func.count(_CS.id)).scalar() or 0
                _distinct_files = _sess.query(_sa_func.count(_sa_func.distinct(_CS.file_path))).scalar() or 0
                _distinct_tables = _sess.query(
                    _sa_func.count(_sa_func.distinct(
                        _sa_func.concat(_CS.bucket, '|', _CS.table_prefix)
                    ))
                ).scalar() or 0
                return int(_row_count), int(_distinct_files), int(_distinct_tables)
        _row_count, _distinct_files, _distinct_tables = await asyncio.to_thread(_col_stats_counts)
        return _storage_row(
            "iceberg_col_stats", "Iceberg Column-Stats Supplement",
            entries=_row_count,
            extra={"row_count": _row_count,
                   "distinct_files": _distinct_files,
                   "distinct_tables": _distinct_tables},
        )
    except Exception as exc:
        return _storage_row("iceberg_col_stats", "Iceberg Column-Stats Supplement",
                            status="unavailable", error=str(exc)[:200])


def _storage_layer_s3_local_cache() -> Dict[str, Any]:
    """S3 local cache (BF-257 NFS PVC) — the previously-orphaned layer."""
    try:
        from core.duckdb_views import s3_cache_stats
        s = s3_cache_stats() or {}
        return _storage_row(
            "s3_local_cache", "S3 Local File Cache (NFS PVC)",
            enabled=bool(s.get("enabled", False)),
            status=s.get("status", "ok"),
            entries=s.get("file_count", 0),
            size_bytes=s.get("total_bytes", 0),
            clear_url="/api/admin/s3-local-cache/evict", clear_method="POST",
            extra={"cache_dir":      s.get("cache_dir"),
                   "max_bytes":      s.get("max_bytes"),
                   "utilisation_pct": s.get("utilisation_pct")},
        )
    except Exception as exc:
        return _storage_row("s3_local_cache", "S3 Local File Cache (NFS PVC)",
                            status="unavailable", error=str(exc)[:200])


async def _storage_layer_agg_cache() -> Dict[str, Any]:
    """Agg cache (pre-computed aggregates) — DB-backed."""
    try:
        s = await _adb(_db_manager.agg_cache_stats) if hasattr(_db_manager, "agg_cache_stats") else {}
        s = s or {}
        return _storage_row(
            "agg_cache", "Aggregate Cache",
            entries=s.get("total_entries"),
            size_bytes=s.get("total_bytes"),
            hits=s.get("hits"), misses=s.get("misses"),
            hit_rate=s.get("hit_rate"),
            extra=s,
        )
    except Exception as exc:
        return _storage_row("agg_cache", "Aggregate Cache",
                            status="unavailable", error=str(exc)[:200])


def _storage_layer_aws_portal_cache() -> Dict[str, Any]:
    """AWS Portal credential cache."""
    try:
        from core.aws_portal_auth import cache_stats as _pcs
        s = _pcs() or {}
        return _storage_row(
            "aws_portal_cache", "AWS Portal Credential Cache",
            entries=s.get("total_entries", 0),
            extra=s,
        )
    except Exception as exc:
        return _storage_row("aws_portal_cache", "AWS Portal Credential Cache",
                            status="unavailable", error=str(exc)[:200])


@router.get("/api/admin/storage-overview")
async def storage_overview(_user: dict = Depends(require_admin)):
    """Unified per-layer view of every cache + storage subsystem.

    Returns a list of dicts each with: ``key``, ``name``, ``status``, ``enabled``,
    ``entries``, ``size_bytes``, ``hit_rate`` (0..1 or None), ``hits``, ``misses``,
    ``extra`` (layer-specific metadata), ``clear_url`` (POST/DELETE path, or None).

    Per-layer call failures degrade gracefully — ``status="unavailable"`` +
    ``error`` carries the reason.  Total page never blanks because one layer
    is broken.
    """
    layers: List[Dict[str, Any]] = []

    # 1) Query result cache (general — /api/cache/stats)
    layers.append(_storage_layer_query_cache())
    # 2) Result Cache (BF-382 / Option D) — instance method, lazy singleton
    layers.append(_storage_layer_result_cache())
    # 3) Cache abstraction layer (schema / partition / br_results)
    layers.extend(_storage_layer_cache_abstraction())
    # 4) Iceberg snapshot cache (BF-296 / contents + pointer)
    layers.append(_storage_layer_iceberg_snapshot_cache())
    # 5) Iceberg file cache (legacy L1+L2)
    layers.append(_storage_layer_iceberg_file_cache())
    # 6) Iceberg column-stats supplement (BF-COL-STATS).
    layers.append(await _storage_layer_iceberg_col_stats())
    # 7) S3 local cache (BF-257 NFS PVC) — the previously-orphaned layer
    layers.append(_storage_layer_s3_local_cache())
    # 8) Agg cache (pre-computed aggregates) — DB-backed
    layers.append(await _storage_layer_agg_cache())
    # 9) AWS Portal credential cache
    layers.append(_storage_layer_aws_portal_cache())

    # Totals — only across layers that actually report numbers, no zeros from
    # unavailable rows skewing the headline number.
    total_entries = sum((_ly["entries"] or 0) for _ly in layers
                        if _ly["status"] == "ok" and _ly["entries"] is not None)
    total_bytes   = sum((_ly["size_bytes"] or 0) for _ly in layers
                        if _ly["status"] == "ok" and _ly["size_bytes"] is not None)
    return {
        "layers":         layers,
        "total_entries":  total_entries,
        "total_size_bytes": total_bytes,
        "layer_count":    len(layers),
        "ok_count":       sum(1 for _ly in layers if _ly["status"] == "ok"),
        "unavailable_count": sum(1 for _ly in layers if _ly["status"] == "unavailable"),
    }


# ── Webhooks ───────────────────────────────────────────────────────────────────

@router.post("/api/webhooks/test")
async def test_webhook_url(body: dict, _user: dict = Depends(get_current_user)):
    """Test a webhook URL by sending a sample notification."""
    url = body.get("url", "")
    if not url:
        raise HTTPException(status_code=400, detail="url is required")
    from core.webhook_service import test_webhook
    return test_webhook(url)


# ── Exports listing ────────────────────────────────────────────────────────────

# Route registered by api/downloads_api.py (the Download Centre surface
# owns every /api/downloads path); the handler stays here with the
# helpers it shares.  2026-08-30.
async def list_exports(status: str = "available", limit: int = 100, offset: int = 0,
                       _user: dict = Depends(get_current_user)):
    """
    List EXPLICIT exports only — xlsx/json files created by the user via Export button.
    Filters out internal auto-generated query result csvs (created_by='internal').

    SECURITY 2026-08-17: this was the ONE route in this 334-route admin module
    with no dependency at all, and it returned EVERY user's export records to
    an anonymous caller.  Paired with the download-by-id route it was a
    two-step exfiltration of the whole export corpus.

    Not admin-gated: this backs the user-facing Downloads page, so it is
    authenticated and SCOPED to the caller instead.  It already read
    ``created_by`` (to drop 'internal' rows) and simply never compared it to
    anyone -- admins keep the org-wide view.
    """
    try:
        # 2026-08-30 — page until enough VISIBLE rows are found.  This used
        # to fetch limit*3 rows and filter afterwards, which merely moves the
        # threshold: it fails as soon as more than two thirds of recent rows
        # belong to other users.  Measured at limit=5 with 25 other-user rows
        # ahead: alice saw 0 of her 5 files — an empty Download Centre for
        # someone who has five downloads.
        #
        # The 'internal' exclusion is a DISPLAY concern (this page is for
        # explicit exports, not every background query result), so it joins
        # the visibility predicate rather than being a second pass.
        from core.download_listing import visible_page
        from api.data_grid_api import _enforce_download_ownership
        from core.download_retention import download_refusal
        _share_memo: dict = {}

        def _visible(row) -> bool:
            if row.get("created_by") == "internal":
                return False
            # Do not list what a click would 410.
            if download_refusal(row):
                return False
            try:
                _enforce_download_ownership(row, _user, allow_service=False,
                                            share_memo=_share_memo)
                return True
            except HTTPException:
                return False

        return await _adb(
            lambda: visible_page(
                lambda lim, off: _db_manager.list_download_files(
                    status=status, limit=lim, offset=off),
                _visible, limit=limit, offset=offset, label="api/exports"))
    except Exception as e:
        logger.error(f"Error listing exports: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


# ── Circuit Breaker endpoints ────────────────────────────────────────────────

@router.get("/api/admin/circuit-breakers")
async def list_circuit_breakers(_user: dict = Depends(require_admin)):
    """List circuit breaker states for all connections."""
    from core.circuit_breaker import get_circuit_states
    return {"circuit_breakers": get_circuit_states()}


@router.get("/api/admin/circuit-breakers/{connection_id}")
async def get_circuit_breaker(connection_id: int, _user: dict = Depends(require_admin)):
    """Get circuit breaker state for a specific connection."""
    from core.circuit_breaker import get_circuit_state
    state = get_circuit_state(connection_id)
    if not state:
        raise HTTPException(status_code=404, detail="No circuit breaker for this connection")
    return state


@router.post("/api/admin/circuit-breakers/{connection_id}/reset")
async def reset_circuit_breaker(connection_id: int, _user: dict = Depends(require_admin)):
    """Manually reset circuit breaker for a connection (force CLOSED)."""
    from core.circuit_breaker import reset_circuit
    result = reset_circuit(connection_id)
    if not result:
        raise HTTPException(status_code=404, detail="No circuit breaker for this connection")
    return result


# -- Anomaly Detection endpoints (Phase 38) ------------------------------------

@router.get("/api/admin/anomalies")
async def list_anomalies(
    schedule_id: int = None,
    limit: int = 50,
    _user: dict = Depends(require_admin),
):
    """List recent anomaly detections across all scheduled reports."""
    return {"anomalies": await _adb(_db_manager.list_anomalies, schedule_id=schedule_id, limit=limit)}


# -- Connection Pool endpoints (Phase 40) --------------------------------------

@router.get("/api/admin/connection-pools")
async def get_connection_pool_stats(
    _user: dict = Depends(require_admin),
):
    """Return connection pool statistics AND whether pooling does anything.

    2026-09-16 — this returned ``{"pools": []}`` forever.  An empty list
    reads as "no connections pooled right now"; the truth is that nothing
    ever acquires a pooled connector, so the list can never be anything
    else.  ``status`` + ``reason`` say which, the same shape the feed
    backend-options, multi_pod and DataFlow-runnability surfaces use.
    ``pools`` is kept for any existing reader.
    """
    from core.connection_pool import pool_status
    return pool_status()


# ── Super Admin (Phase 107-G) ────────────────────────────────────────────────
#
# Break-glass admin accounts stored in SQLite. Used to recover access when AD
# is unreachable or auth.type misconfigured. The CLI subcommand `python -m
# querystudio super-admin create` is the bootstrap path; these endpoints expose
# the same operations to the AdminPage UI for ongoing management.

class SuperAdminCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=100)
    password: str = Field(..., min_length=12, max_length=200)
    notes: Optional[str] = Field(default=None, max_length=500)


class SuperAdminPasswordReset(BaseModel):
    password: str = Field(..., min_length=12, max_length=200)


class SuperAdminActiveToggle(BaseModel):
    is_active: bool


@router.get("/api/admin/super-admins")
async def list_super_admins_endpoint(_user: dict = Depends(require_admin)):
    """List all break-glass super admins (no password hashes returned)."""
    rows = await _adb(_db_manager.list_super_admins)
    return {"super_admins": rows, "active_count": await _adb(_db_manager.count_active_super_admins)}


@router.post("/api/admin/super-admins")
async def create_super_admin_endpoint(
    body: SuperAdminCreate,
    request: Request,
    _user: dict = Depends(require_admin_rate_limited),
):
    """Create a new break-glass super admin."""
    from core.ad_auth import hash_password
    try:
        row = await _adb(_db_manager.create_super_admin, 
            username=body.username,
            password_hash=hash_password(body.password),
            created_by=(_user or {}).get("username", "admin"),
            notes=body.notes,
        )
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    await _adb(_db_manager.audit, 
        username=(_user or {}).get("username", "admin"),
        action="super_admin_create",
        resource_type="super_admin",
        resource_id=body.username,
        ip_address=getattr(request.client, "host", None) if request.client else None,
        details={"notes": body.notes or ""},
    )
    return {"super_admin": row}


@router.put("/api/admin/super-admins/{username}/password")
async def reset_super_admin_password_endpoint(
    username: str,
    body: SuperAdminPasswordReset,
    request: Request,
    _user: dict = Depends(require_admin),
):
    """Rotate the password for an existing super admin."""
    from core.ad_auth import hash_password
    if await _adb(_db_manager.get_super_admin_by_username, username) is None:
        raise HTTPException(status_code=404, detail=f"super admin not found: {username}")
    if not await _adb(_db_manager.update_super_admin_password, username, hash_password(body.password)):
        raise HTTPException(status_code=500, detail="failed to update password")
    await _adb(_db_manager.audit, 
        username=(_user or {}).get("username", "admin"),
        action="super_admin_reset_password",
        resource_type="super_admin",
        resource_id=username,
        ip_address=getattr(request.client, "host", None) if request.client else None,
    )
    return {"updated": True, "username": username}


@router.put("/api/admin/super-admins/{username}/active")
async def toggle_super_admin_endpoint(
    username: str,
    body: SuperAdminActiveToggle,
    request: Request,
    _user: dict = Depends(require_admin),
):
    """Enable or disable a super admin (lockout-protected on disable)."""
    sa = await _adb(_db_manager.get_super_admin_by_username, username)
    if sa is None:
        raise HTTPException(status_code=404, detail=f"super admin not found: {username}")

    # Last-active lockout protection: refuse to disable the only active row
    if (not body.is_active) and sa.get("is_active") and await _adb(_db_manager.count_active_super_admins) <= 1:
        raise HTTPException(
            status_code=400,
            detail="cannot disable the last active super admin (lockout protection)",
        )

    if not await _adb(_db_manager.set_super_admin_active, username, body.is_active):
        raise HTTPException(status_code=500, detail="failed to update active flag")

    await _adb(_db_manager.audit, 
        username=(_user or {}).get("username", "admin"),
        action="super_admin_set_active",
        resource_type="super_admin",
        resource_id=username,
        ip_address=getattr(request.client, "host", None) if request.client else None,
        details={"is_active": bool(body.is_active)},
    )
    return {"updated": True, "username": username, "is_active": bool(body.is_active)}


@router.delete("/api/admin/super-admins/{username}")
async def delete_super_admin_endpoint(
    username: str,
    request: Request,
    _user: dict = Depends(require_admin_rate_limited),
):
    """Hard-delete a super admin row (lockout-protected)."""
    sa = await _adb(_db_manager.get_super_admin_by_username, username)
    if sa is None:
        raise HTTPException(status_code=404, detail=f"super admin not found: {username}")

    # Last-active lockout protection: refuse to delete the only active row
    if sa.get("is_active") and await _adb(_db_manager.count_active_super_admins) <= 1:
        raise HTTPException(
            status_code=400,
            detail="cannot delete the last active super admin (lockout protection)",
        )

    if not await _adb(_db_manager.delete_super_admin, username):
        raise HTTPException(status_code=500, detail="failed to delete")

    await _adb(_db_manager.audit, 
        username=(_user or {}).get("username", "admin"),
        action="super_admin_delete",
        resource_type="super_admin",
        resource_id=username,
        ip_address=getattr(request.client, "host", None) if request.client else None,
    )
    return {"deleted": True, "username": username}


# ── UI Component Visibility (admin control per role) ────────────────────────────
#
# COMPONENT_REGISTRY is the SINGLE source of truth for every visibility key the
# UI honours: key, human label, admin-screen group, and a description telling
# the admin what hiding it actually does.  The admin screen is driven from this
# list (GET /api/admin/ui-visibility → components/components_detail), the PUT
# endpoint validates against it, and /api/app-settings resolves defaults from
# it — so a key added here is immediately discoverable, toggleable and honoured
# without any parallel list to keep in sync.
#
# IMPORTANT — visibility is DECLUTTERING, NOT AUTHORIZATION.  Hiding a control
# removes it from the screen for a role; it does not revoke the capability or
# restrict the API.  Access control lives in roles/permissions.
#
# Dot-notation keys ("parent.child") are in-page sub-features: the parent
# cascade (Phase 107-H) forces every child off when the parent is off, both
# here (get_ui_visibility_resolved) and in the frontend UIVisibilityContext.

COMPONENT_REGISTRY = [
    # {key, label, group, description}
    {"key": "query_builder",      "label": "Query Builder",      "group": "Data",
     "description": "Visual query builder page (Complete Query Builder)."},
    {"key": "sql_editor",         "label": "SQL Editor",         "group": "Data",
     "description": "Free-form SQL editor page."},
    {"key": "sql_editor.streaming", "label": "  > Streaming controls", "group": "Data",
     "description": "Stream / Stream+Download toggles on the SQL Editor toolbar. "
                    "Hidden: queries run with the page's default streaming behaviour."},
    {"key": "saved_queries",      "label": "Saved Queries",      "group": "Data",
     "description": "Saved queries list page."},
    {"key": "dashboards",         "label": "Dashboards",         "group": "Analytics",
     "description": "Dashboards page."},
    {"key": "report_catalog",     "label": "Report Catalog",     "group": "Analytics",
     "description": "Report catalog browser."},
    {"key": "report_connectors",  "label": "Report Connectors",  "group": "Analytics",
     "description": "Report connector management."},
    {"key": "schedules",          "label": "Schedules",          "group": "Automation",
     "description": "Scheduled query/report management page."},
    {"key": "executions",         "label": "Executions",         "group": "Automation",
     "description": "Execution history page."},
    {"key": "downloads",          "label": "Downloads",          "group": "Automation",
     "description": "Downloads page (completed result files)."},
    {"key": "connections",        "label": "Connections",        "group": "Admin",
     "description": "Connection manager page."},
    {"key": "materialized_views", "label": "Materialized Views", "group": "Admin",
     "description": "Materialized views admin page."},
    {"key": "local_tables",       "label": "Local Tables",       "group": "Admin",
     "description": "Uploaded local tables page."},
    {"key": "lineage",            "label": "Data Lineage",       "group": "Admin",
     "description": "Data lineage explorer."},
    {"key": "lineage_history",    "label": "Lineage History",    "group": "Admin",
     "description": "Lineage snapshot history."},
    {"key": "data_freshness",     "label": "Data Freshness",     "group": "Admin",
     "description": "Data freshness monitor."},
    {"key": "semantic_layer",     "label": "Semantic Layer",     "group": "Admin",
     "description": "Semantic layer / dataset manager."},
    # LEGACY — "federation" was old key; sidebar uses "federation_views" now
    {"key": "federation",         "label": "Federation Engine (legacy)", "group": "Admin",
     "description": "Legacy federation key (superseded by federation_views)."},
    {"key": "agg_cache",          "label": "Aggregation Cache",  "group": "Admin",
     "description": "Aggregation cache admin page."},
    {"key": "aws_portal",         "label": "AWS Portal Auth",    "group": "Admin",
     "description": "AWS portal authentication page."},
    {"key": "business_reports",   "label": "Business Reports",   "group": "Analytics",
     "description": "Unified business reports (list, build, view)."},
    {"key": "report_templates",   "label": "Report Templates",   "group": "Analytics",
     "description": "Report template management."},
    {"key": "business_portal",    "label": "Business Portal",    "group": "Analytics",
     "description": "Business portal landing page."},
    {"key": "chatbot",            "label": "NL Chatbot",         "group": "Analytics",
     "description": "Natural-language chatbot."},
    {"key": "admin",              "label": "Admin Panel",        "group": "Admin",
     "description": "Admin panel."},
    {"key": "data_quality",       "label": "Data Quality",       "group": "Admin",
     "description": "Data quality dashboard."},
    {"key": "guided_tours",       "label": "Guided Tours",       "group": "General",
     "description": "In-app guided tours."},
    {"key": "glossary",           "label": "Business Glossary",  "group": "Data",
     "description": "Business glossary page."},
    {"key": "pivot_reports",      "label": "Pivot Reports (legacy)", "group": "Analytics",
     "description": "Legacy pivot reports (redirects to unified reports)."},
    # Phase 107-H: dot-notation sub-features. Parent cascade applies — if the
    # parent (e.g. pivot_reports) is disabled, all children are forced off.
    {"key": "pivot_reports.builder",    "label": "  > Builder",  "group": "Analytics",
     "description": "Pivot report builder sub-feature."},
    {"key": "pivot_reports.viewer",     "label": "  > Viewer",   "group": "Analytics",
     "description": "Pivot report viewer sub-feature."},
    {"key": "pivot_reports.export",     "label": "  > Export",   "group": "Analytics",
     "description": "Pivot report export sub-feature."},
    {"key": "business_reports.builder", "label": "  > Builder",  "group": "Analytics",
     "description": "Business report builder sub-feature."},
    {"key": "business_reports.viewer",  "label": "  > Viewer",   "group": "Analytics",
     "description": "Business report viewer sub-feature."},
    {"key": "business_reports.publish", "label": "  > Publish",  "group": "Analytics",
     "description": "Business report publishing sub-feature."},
    {"key": "data_quality.monitors",    "label": "  > Monitors", "group": "Admin",
     "description": "Data quality monitors sub-feature."},
    {"key": "report_comments",    "label": "Report Comments",    "group": "Collaboration",
     "description": "Comments on reports."},
    {"key": "report_change_log",  "label": "Change History",     "group": "Collaboration",
     "description": "Report change history."},
    # Phase 125: Missing visibility entries — these features had no admin toggle
    {"key": "federation_views",   "label": "Federation Views",   "group": "Data",
     "description": "Federation views page."},
    {"key": "data_catalog",       "label": "Data Catalog",       "group": "Data",
     "description": "Data catalog browser."},
    {"key": "api_explorer",       "label": "API Explorer",       "group": "Admin",
     "description": "API explorer page."},
    {"key": "published_views",    "label": "Published Views",    "group": "Admin",
     "description": "Published views (Published API) admin page."},
    {"key": "api_keys",           "label": "API Keys",           "group": "Admin",
     "description": "API key management page."},
    {"key": "feeds",              "label": "Feed Files",         "group": "Automation",
     "description": "Feed files page."},
    # 2026-09-10 — Clockwork, the scheduler.  THE key the scheduler-only
    # scope is expressed in (core/clockwork/scope.py): a scheduler-scoped
    # principal sees this component and nothing else, and an admin hiding
    # it for a role hides the scheduler's API for that role too.
    {"key": "clockwork",          "label": "Scheduler (Clockwork)", "group": "Automation",
     "description": "Clockwork scheduler: jobs, run history, alerts, deployments."},
    # Phase 125+: sidebar items that were missing admin visibility control
    {"key": "file_preview",       "label": "File Preview",       "group": "History",
     "description": "File preview page."},
    {"key": "system_accounts",    "label": "System Accounts",    "group": "Admin",
     "description": "System accounts admin page."},
    {"key": "user_guide",         "label": "User Guide",         "group": "Support",
     "description": "User guide."},
    # Phase 130: Query Editor (formerly Business Query Builder / Smart Query)
    {"key": "business_query_builder", "label": "Query Editor", "group": "Data",
     "description": "Query Editor page (Business Query Builder). Turning this off "
                    "hides the whole page AND every sub-feature below (parent cascade)."},
    # In-page Query Editor sub-features — each toggle hides ONE control
    # (declutter). Core building blocks (connection picker, table/column tree,
    # SQL editor, filters, sort, limit, Execute, results grid, Save/Load) are
    # deliberately NOT toggleable: hiding them would leave a broken page —
    # hide the whole page instead via the parent key.
    #   Power-user affordances:
    {"key": "business_query_builder.advanced_sql", "label": "  > Advanced SQL menu", "group": "Data",
     "description": "Advanced dropdown: HAVING, computed columns, CASE expressions, "
                    "window functions, DISTINCT. Typed SQL still supports all of these."},
    {"key": "business_query_builder.templates", "label": "  > Query templates", "group": "Data",
     "description": "Pre-built query templates entry in the Save/Load menu."},
    {"key": "business_query_builder.publish", "label": "  > Publish API", "group": "Data",
     "description": "'Publish API…' action. Publishing stays available from Published "
                    "Views / Saved Queries — this only hides the shortcut here."},
    {"key": "business_query_builder.create_feed", "label": "  > Create feed", "group": "Data",
     "description": "'Create Feed…' action in the Save/Load menu. Feeds remain "
                    "manageable from the Feed Files page."},
    # 2026-08-25 — the frontend has asked for this key since the action
    # shipped (business-query/visibilityKeys.ts: createDataset), but it was
    # never registered here, so it was the ONE business_query_builder
    # sub-feature with no admin toggle: invisible in the admin UI and
    # ungovernable.  Registering it changes nothing for users — an
    # unregistered key already resolved to "show" on both sides (the
    # resolver only emits known keys; the frontend defaults absent keys to
    # visible) — it simply makes the switch exist.
    {"key": "business_query_builder.create_dataset", "label": "  > Create dataset", "group": "Data",
     "description": "'Create Dataset…' action in the Save/Load menu — models a "
                    "saved query or .sql file as a Semantic Layer dataset. "
                    "Datasets remain creatable from the Datasets page."},
    {"key": "business_query_builder.cross_connection", "label": "  > 2nd source (cross-connection)", "group": "Data",
     "description": "Cross-connection UNION/JOIN panel ('2nd Source'). Hidden: "
                    "queries run against a single connection."},
    {"key": "business_query_builder.streaming", "label": "  > Streaming controls", "group": "Data",
     "description": "Streaming mode selector for S3 connections. Hidden: queries "
                    "run in the normal (non-streaming) mode."},
    {"key": "business_query_builder.cache_controls", "label": "  > Cache controls", "group": "Data",
     "description": "Run-options cache strategy menu and the 'Cached — use cached / "
                    "run fresh' banner. Hidden: default cache behaviour applies."},
    #   Diagnostics / power-user aids:
    {"key": "business_query_builder.explain", "label": "  > EXPLAIN plan", "group": "Data",
     "description": "EXPLAIN button and query-plan viewer."},
    {"key": "business_query_builder.validate_fix", "label": "  > Validate & Fix", "group": "Data",
     "description": "Proactive 'Validate & Fix' SQL button. Error-driven auto-fix "
                    "suggestions after a failed run are never hidden."},
    {"key": "business_query_builder.sql_hints", "label": "  > SQL performance hints", "group": "Data",
     "description": "Inline performance suggestions (e.g. COUNT(DISTINCT) → "
                    "APPROX_COUNT_DISTINCT banner)."},
    {"key": "business_query_builder.cost_estimate", "label": "  > Cost estimate chip", "group": "Data",
     "description": "Pre-flight '~rows · files' estimate chip in the toolbar."},
    {"key": "business_query_builder.partition_hints", "label": "  > Partition pruning hints", "group": "Data",
     "description": "Partition-column chip row and pruning guide popover."},
    {"key": "business_query_builder.engine_selector", "label": "  > Engine selector", "group": "Data",
     "description": "Auto / DuckDB / Spark Connect engine override row. Hidden: "
                    "engine routing is automatic."},
    {"key": "business_query_builder.s3_reader_selector", "label": "  > S3 reader selector", "group": "Data",
     "description": "Per-query S3 reader override row. Hidden: reader selection "
                    "is automatic."},
    {"key": "business_query_builder.execution_diagnostics", "label": "  > Execution diagnostics", "group": "Data",
     "description": "Engine/scan-plan/prewarm chips and the live per-worker grid "
                    "shown while a query runs. Progress and errors remain visible."},
]

# Legacy 3-tuple view — DERIVED from COMPONENT_REGISTRY (do not edit directly).
# Kept because existing callers/tests unpack (key, label, group).
KNOWN_COMPONENTS = [(e["key"], e["label"], e["group"]) for e in COMPONENT_REGISTRY]

# ── Role visibility presets (DATA, not code) ──────────────────────────────────
# A preset is a bundle of explicit rules an admin can APPLY from the admin
# screen; applying one writes ordinary rows through the same PUT endpoint, so
# it stays fully overridable per key afterwards.  Presets are NEVER applied
# automatically — until an admin applies one (or toggles keys manually) every
# user keeps seeing everything (safe default = show).
ROLE_VISIBILITY_PRESETS = [
    {
        "id": "viewer_clean_query_editor",
        "label": "Viewer — clean Query Editor",
        "role": "viewer",
        "description": "Hides power-user and diagnostic Query Editor controls for "
                       "viewers: advanced SQL menu, templates, publish/feed shortcuts, "
                       "cross-connection, streaming, cache controls, EXPLAIN, "
                       "Validate & Fix, engine/reader selectors and execution "
                       "diagnostics. Keeps the guardrails (cost estimate, partition "
                       "hints, SQL performance hints) visible.",
        "rules": {
            "business_query_builder.advanced_sql":          False,
            "business_query_builder.templates":             False,
            "business_query_builder.publish":               False,
            "business_query_builder.create_feed":           False,
            "business_query_builder.cross_connection":      False,
            "business_query_builder.streaming":             False,
            "business_query_builder.cache_controls":        False,
            "business_query_builder.explain":               False,
            "business_query_builder.validate_fix":          False,
            "business_query_builder.engine_selector":       False,
            "business_query_builder.s3_reader_selector":    False,
            "business_query_builder.execution_diagnostics": False,
        },
    },
    {
        "id": "analyst_full_toolbox",
        "label": "Analyst — full toolbox",
        "role": "analyst",
        "description": "Explicitly shows every Query Editor sub-feature for analysts "
                       "(writes enabled=true rows, undoing any prior hides).",
        "rules": {
            e["key"]: True
            for e in COMPONENT_REGISTRY
            if e["key"].startswith("business_query_builder.")
        },
    },
]

# Phase 107-H: extended role set.
#   - "super_admin" — real role assigned to authenticated SuperAdmin records;
#     bypasses all gating, frontend gets {} (= show everything).
#   - "global"      — synthetic master kill-switch. A row
#     (component_key, "global", enabled=False) hides that component for every
#     non-super-admin role, regardless of per-role overrides.
KNOWN_ROLES = ["admin", "analyst", "viewer", "scheduler", "super_admin", "global"]


@router.get("/api/admin/ui-visibility")
async def get_ui_visibility(_user: dict = Depends(require_admin)):
    """
    Return the full component-visibility matrix.
    Rows not in DB default to enabled=True.
    """
    stored = {(r["component_key"], r["role"]): r["enabled"]
              for r in await _adb(_db_manager.get_ui_visibility)}
    result = []
    for key, label, group in KNOWN_COMPONENTS:
        for role in KNOWN_ROLES:
            result.append({
                "component_key": key,
                "label":         label,
                "group":         group,
                "role":          role,
                "enabled":       stored.get((key, role), True),
            })
    return {
        "visibility": result,
        "components": KNOWN_COMPONENTS,          # legacy 3-tuple shape
        "components_detail": COMPONENT_REGISTRY, # key/label/group/description
        "presets": ROLE_VISIBILITY_PRESETS,      # data-driven role defaults (admin-applied)
        "roles": KNOWN_ROLES,
    }


@router.put("/api/admin/ui-visibility")
async def set_ui_visibility(
    body: dict,
    _user: dict = Depends(require_admin),
):
    """
    Bulk-upsert visibility rules.
    Body: { "rules": [{"component_key": str, "role": str, "enabled": bool}, ...] }
    """
    rules = body.get("rules", [])
    if not rules:
        raise HTTPException(status_code=400, detail="rules list required")
    valid_keys  = {k for k, _, _ in KNOWN_COMPONENTS}
    valid_roles = set(KNOWN_ROLES)
    cleaned = []
    for r in rules:
        ck = r.get("component_key", "")
        ro = r.get("role", "")
        if ck not in valid_keys or ro not in valid_roles:
            raise HTTPException(status_code=422, detail=f"Unknown component_key={ck!r} or role={ro!r}")
        cleaned.append({"component_key": ck, "role": ro, "enabled": bool(r.get("enabled", True))})
    count = await _adb(_db_manager.bulk_set_ui_visibility, cleaned)
    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "set_ui_visibility", resource_type="ui_visibility",
                      resource_id=f"{count}_rules")
    return {"updated": count}


# ── Lineage Feature Config (Phase 52) ─────────────────────────────────────────

@router.get("/api/admin/lineage/config")
async def get_lineage_config(_user: dict = Depends(require_admin)):
    """Return current lineage snapshot + freshness configuration."""
    from core import config as _cfg
    return {
        "snapshots_enabled":           _cfg.lineage.snapshots_enabled,
        "freshness_enabled":           _cfg.lineage.freshness_enabled,
        "snapshot_retention_days":     _cfg.lineage.snapshot_retention_days,
        "default_stale_threshold_hours": _cfg.lineage.default_stale_threshold_hours,
        "auto_extract":                _cfg.lineage.auto_extract,
    }


@router.put("/api/admin/lineage/config")
async def set_lineage_config(body: dict, _user: dict = Depends(require_admin)):
    """Update lineage feature flags in the runtime config.

    Body keys (all optional):
      snapshots_enabled: bool
      freshness_enabled: bool
      snapshot_retention_days: int
      default_stale_threshold_hours: int
      auto_extract: bool
    """
    from core import config as _cfg
    allowed = {
        "snapshots_enabled", "freshness_enabled",
        "snapshot_retention_days", "default_stale_threshold_hours", "auto_extract",
    }
    updates = {k: v for k, v in body.items() if k in allowed}
    if not updates:
        raise HTTPException(status_code=400, detail=f"No valid keys. Allowed: {sorted(allowed)}")
    for key, val in updates.items():
        _cfg.set("lineage", key, val)
    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "set_lineage_config", resource_type="lineage_config",
                      resource_id=str(updates))
    return {"updated": updates}


# ── Phase 57 — NL Chatbot Config ──────────────────────────────────────────

@router.get("/api/admin/chatbot/config")
async def get_chatbot_config(_user: dict = Depends(require_admin)):
    """Return current NL chatbot configuration."""
    from core import config as _cfg
    return {
        "semantic_context_enabled":  _cfg.chatbot.semantic_context_enabled,
        "time_intelligence_enabled": _cfg.chatbot.time_intelligence_enabled,
        "max_pattern_alternatives":  _cfg.chatbot.max_pattern_alternatives,
    }


@router.put("/api/admin/chatbot/config")
async def set_chatbot_config(body: dict, _user: dict = Depends(require_admin)):
    """Update NL chatbot feature flags at runtime."""
    from core import config as _cfg
    allowed = {"semantic_context_enabled", "time_intelligence_enabled", "max_pattern_alternatives"}
    updates = {k: v for k, v in body.items() if k in allowed}
    if not updates:
        raise HTTPException(status_code=400, detail=f"No valid keys. Allowed: {sorted(allowed)}")
    for key, val in updates.items():
        _cfg.set("chatbot", key, val)
    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "set_chatbot_config", resource_type="chatbot_config",
                      resource_id=str(updates))
    return {"updated": updates}


# ── Suggestion Corrections Config ──────────────────────────────────────────

@router.get("/api/admin/suggestion-corrections/config")
async def get_suggestion_corrections_config(_user: dict = Depends(require_admin)):
    """Return current suggestion corrections configuration."""
    from core import config as _cfg
    return {
        "enabled":                  _cfg.suggestion_corrections.enabled,
        "max_corrections":          _cfg.suggestion_corrections.max_corrections,
        "agg_pattern_priority":     _cfg.suggestion_corrections.agg_pattern_priority,
        "join_correction_priority": _cfg.suggestion_corrections.join_correction_priority,
        "retention_days":           _cfg.suggestion_corrections.retention_days,
    }


@router.put("/api/admin/suggestion-corrections/config")
async def set_suggestion_corrections_config(body: dict, _user: dict = Depends(require_admin)):
    """Update suggestion corrections feature flags at runtime."""
    from core import config as _cfg
    allowed = {"enabled", "max_corrections", "agg_pattern_priority",
               "join_correction_priority", "retention_days"}
    updates = {k: v for k, v in body.items() if k in allowed}
    if not updates:
        raise HTTPException(status_code=400, detail=f"No valid keys. Allowed: {sorted(allowed)}")
    for key, val in updates.items():
        _cfg.set("suggestion_corrections", key, val)
    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "set_suggestion_corrections_config",
                      resource_type="suggestion_corrections_config", resource_id=str(updates))
    return {"updated": updates}


@router.get("/api/admin/suggestion-corrections")
async def list_suggestion_corrections(
    correction_type: Optional[str] = None,
    _user: dict = Depends(require_admin),
):
    """List all stored suggestion corrections (admin view)."""
    if correction_type:
        corrections = await _adb(_db_manager.get_suggestion_corrections, correction_type)
    else:
        agg = await _adb(_db_manager.get_all_agg_corrections)
        join = await _adb(_db_manager.get_all_join_corrections)
        corrections = agg + join
    return {"corrections": corrections, "total": len(corrections)}


@router.delete("/api/admin/suggestion-corrections/{correction_id}")
async def delete_suggestion_correction(
    correction_id: int,
    _user: dict = Depends(require_admin),
):
    """Delete a single suggestion correction by ID."""
    deleted = await _adb(_db_manager.delete_suggestion_correction, correction_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Correction not found")
    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "delete_suggestion_correction",
                      resource_type="suggestion_correction", resource_id=str(correction_id))
    return {"deleted": True}


# ── AWS Portal Credential Provider ─────────────────────────────────────────

@router.get("/api/admin/aws-portal/config")
async def get_aws_portal_config(_user: dict = Depends(require_admin)):
    """Return current AWS portal configuration (passwords masked)."""
    from core import config as _cfg
    section = dict(_cfg._DEFAULTS.get("aws_portal", {}))
    # Overlay runtime overrides
    for k in section:
        section[k] = _cfg.get("aws_portal", k, section[k])
    # Mask sensitive values
    if section.get("service_password"):
        section["service_password"] = "********"
    if section.get("proxy_password"):
        section["proxy_password"] = "********"
    # Redact credentials from proxy_url (e.g. http://user:pass@host:port)
    if section.get("proxy_url") and "@" in str(section["proxy_url"]):
        from core.proxy_utils import sanitize_proxy_error
        section["proxy_url"] = sanitize_proxy_error(section["proxy_url"])
    return section


class AWSPortalConfigUpdate(BaseModel):
    enabled: Optional[bool] = None
    portal_base_url: Optional[str] = None
    jwt_url: Optional[str] = None
    creds_url_template: Optional[str] = None
    account_id: Optional[str] = None
    role_name: Optional[str] = None
    sf_ref_no: Optional[str] = None
    service_username: Optional[str] = None
    service_password: Optional[str] = None
    proxy_url: Optional[str] = None
    proxy_host: Optional[str] = None
    proxy_port: Optional[int] = None
    proxy_username: Optional[str] = None
    proxy_password: Optional[str] = None
    verify_ssl: Optional[bool] = None
    creds_ttl_seconds: Optional[int] = None
    timeout_seconds: Optional[int] = None
    auto_retry_on_expiry: Optional[bool] = None
    max_retry_attempts: Optional[int] = None
    system_account_fallback: Optional[bool] = None


@router.put("/api/admin/aws-portal/config")
async def set_aws_portal_config(body: AWSPortalConfigUpdate, _user: dict = Depends(require_admin)):
    """Update AWS portal configuration."""
    from core import config as _cfg
    updates = {k: v for k, v in body.model_dump(exclude_none=True).items()}
    if not updates:
        raise HTTPException(status_code=400, detail="No valid fields provided")
    for key, val in updates.items():
        _cfg.set("aws_portal", key, val)
    username = (_user or {}).get("username", "admin")
    # Mask password in audit
    audit_updates = dict(updates)
    if "service_password" in audit_updates:
        audit_updates["service_password"] = "********"
    if "proxy_password" in audit_updates:
        audit_updates["proxy_password"] = "********"
    if "proxy_url" in audit_updates and "@" in str(audit_updates.get("proxy_url", "")):
        from core.proxy_utils import sanitize_proxy_error
        audit_updates["proxy_url"] = sanitize_proxy_error(audit_updates["proxy_url"])
    await _adb(_db_manager.audit, username, "set_aws_portal_config", resource_type="aws_portal_config",
                      resource_id=str(audit_updates))
    return {"updated": audit_updates}


def _portal_reach_proxies(_cfg):
    """Proxy dict for the credential-less reachability probe, or None.

    Reuse proxy config if portal proxy is set.  URL-encode the
    credentials so special chars (@, :, /) in proxy_password
    don't break the proxy URL parser.
    """
    if not _cfg.aws_portal.proxy_host:
        return None
    from urllib.parse import quote
    phost = _cfg.aws_portal.proxy_host
    pport = _cfg.aws_portal.proxy_port or 8080
    puser = _cfg.aws_portal.proxy_username or ""
    ppass = _cfg.aws_portal.proxy_password or ""
    if puser:
        cred = f"{quote(puser, safe='')}:{quote(ppass, safe='')}@"
    else:
        cred = ""
    return {
        "http":  f"http://{cred}{phost}:{pport}",
        "https": f"http://{cred}{phost}:{pport}",
    }


def _portal_reach_hint(err: str) -> str:
    """Turn a sanitized transport error into the admin-facing next step."""
    elow = err.lower()
    if "ssl" in elow or "certificate" in elow:
        return " — SSL cert verification failed.  Disable 'Verify SSL' or install the corporate CA bundle."
    if "name or service" in elow or "nodename" in elow or "getaddrinfo" in elow:
        return " — DNS resolution failed.  Check the Portal Base URL hostname."
    if "proxy" in elow or "407" in elow:
        return " — Proxy connection failed.  Check proxy host/port/credentials."
    if "connection refused" in elow or "connecttimeout" in elow:
        return " — Connection refused or timed out.  Portal may be down or unreachable from this pod."
    return ""


def _portal_reach_verdict(status: int) -> Dict[str, Any]:
    """Read the credential-less JWT probe's HTTP status as reachable / not."""
    # Any HTTP response = network path works.  Auth-error codes are
    # EXPECTED with empty creds and confirm the endpoint is alive.
    if status in (400, 401, 403, 405, 422):
        return {
            "success": True,
            "mode": "reachability",
            "message": (
                f"Portal reachable (HTTP {status} from JWT endpoint with empty creds — "
                "this confirms URL + proxy + SSL all work).  Add service account "
                "credentials and click Test again for a full auth check."
            ),
            "http_status": status,
        }
    return {
        "success": False,
        "mode": "reachability",
        "message": (
            f"Portal returned unexpected HTTP {status} — URL reachable but "
            "JWT endpoint may be wrong path"
        ),
        "http_status": status,
    }


async def _portal_reachability_test(_cfg, portal_url: str) -> Dict[str, Any]:
    """Reachability + SSL probe used when no service account is configured."""
    def _reach_test():
        import requests
        jwt_url = f"{portal_url}/v1/jwttoken"
        verify = bool(_cfg.aws_portal.verify_ssl)
        proxies = _portal_reach_proxies(_cfg)
        timeout = float(_cfg.aws_portal.timeout_seconds or 10)
        # Keep the timeout tight — the outer asyncio.wait_for caps at 15s
        timeout = min(timeout, 12)
        return requests.post(
            jwt_url, json={"username": "", "password": ""},
            timeout=timeout, verify=verify, proxies=proxies,
        )
    try:
        resp = await asyncio.wait_for(asyncio.to_thread(_reach_test),
                                       timeout=15.0)
        return _portal_reach_verdict(resp.status_code)
    except asyncio.TimeoutError:
        return {
            "success": False,
            "mode": "reachability",
            "message": ("Portal reachability test exceeded 15s — likely "
                        "network/DNS/proxy issue.  Check Portal Base URL + Proxy settings."),
        }
    except Exception as exc:
        from core.proxy_utils import sanitize_proxy_error
        err = sanitize_proxy_error(str(exc))
        hint = _portal_reach_hint(err)
        return {
            "success": False,
            "mode": "reachability",
            "message": f"Reachability test failed: {err}{hint}",
        }


@router.post("/api/admin/aws-portal/test")
async def test_aws_portal_config(_user: dict = Depends(require_admin)):
    """Test the AWS portal connection.

    Two-mode test (BF-388):
      * **Service account configured** → full auth + creds fetch test
      * **No service account** → reachability + SSL test (validates URL,
        proxy, SSL cert) by hitting the JWT endpoint without creds —
        a 400/401/403/405 response proves the endpoint is reachable.

    BF-NONBLOCK-AUDIT: synchronous HTTP calls can hang 5-30s on cold cache
    or 60s+ through a misconfigured corporate proxy.  Wrapped in
    asyncio.to_thread + 15s wait_for so the test doesn't pin the API worker.
    """
    from core import config as _cfg
    svc_user = _cfg.aws_portal.service_username
    svc_pass = _cfg.aws_portal.service_password
    portal_url = (_cfg.aws_portal.portal_base_url or "").rstrip("/")

    if not portal_url:
        return {
            "success": False,
            "message": "Portal Base URL not configured — set it in the Configuration form above",
            "mode": "config_missing",
        }

    # ── Reachability test mode (no service account) ────────────────────
    # Hits the JWT endpoint without credentials to validate URL + proxy +
    # SSL trust.  We DON'T care about the auth result — any HTTP response
    # at all means the network path works.
    if not svc_user or not svc_pass:
        return await _portal_reachability_test(_cfg, portal_url)

    return await _portal_full_auth_test(svc_user, svc_pass)


def _portal_step_jwt(_add_step, _req, sanitize_proxy_error, resolved,
                     svc_user, svc_pass, verify, timeout, proxies):
    """Step 1 — return the portal JWT, or None once the failure is recorded."""
    jwt_url = resolved["jwt_url"]
    if not jwt_url:
        _add_step("config", False, "No JWT URL — set portal_base_url")
        return None
    try:
        r = _req.post(jwt_url,
                      json={"username": svc_user, "password": svc_pass},
                      headers={"Content-Type": "application/json"},
                      verify=verify, timeout=timeout, proxies=proxies)
    except Exception as exc:
        _add_step("jwt_token", False,
                  f"Network/transport error: {sanitize_proxy_error(str(exc))}")
        return None
    if r.status_code != 200:
        _add_step("jwt_token", False,
                  f"Portal returned HTTP {r.status_code} — credentials likely "
                  f"wrong OR JWT endpoint path is incorrect",
                  http_status=r.status_code,
                  response_preview=sanitize_proxy_error(r.text))
        return None
    try:
        token = r.json().get("token")
    except Exception:
        token = None
    if not token:
        _add_step("jwt_token", False,
                  "Portal returned 200 but response had no 'token' field — "
                  "check that this is the correct JWT endpoint",
                  http_status=200, response_preview=r.text)
        return None
    _add_step("jwt_token", True,
              f"JWT obtained ({len(token)} chars)", http_status=200)
    return token


def _portal_role_status_hint(status_code: int) -> str:
    """Explain a non-200 from the roles endpoint in admin terms."""
    if status_code == 401:
        return " — Basic Auth (username:password) rejected; the portal " \
               "may not allow Basic Auth on the roles endpoint, " \
               "OR credentials lack roles permission"
    if status_code == 403:
        return " — user lacks permission to list roles"
    if status_code == 404:
        return " — roles endpoint URL may be wrong"
    return ""


def _portal_pick_role_arn(items, account_id):
    """Choose the role ARN to assume: the account_id match, else the first."""
    # Find matching ARN
    target_arn = None
    if account_id:
        for role in items:
            arn = role.get("role_arn", "")
            if account_id in arn:
                target_arn = arn
                break
    if not target_arn:
        target_arn = items[0].get("role_arn", "")
    return target_arn


def _portal_step_role(_add_step, _req, sanitize_proxy_error, resolved,
                      svc_user, svc_pass, verify, timeout, proxies):
    """Step 2 — return the role ARN to assume, or None once recorded as failed."""
    roles_url = resolved["roles_url"]
    if not roles_url:
        _add_step("role_lookup", False,
                  "No roles URL — portal_base_url missing")
        return None
    role_name = resolved["role_name"]
    account_id = resolved["account_id"]
    params = {"search": role_name} if role_name else {}
    try:
        rr = _req.get(roles_url, params=params,
                      auth=(svc_user, svc_pass),
                      headers={"Content-Type": "application/json"},
                      verify=verify, timeout=timeout, proxies=proxies)
    except Exception as exc:
        _add_step("role_lookup", False,
                  f"Network/transport error: {sanitize_proxy_error(str(exc))}")
        return None
    if rr.status_code != 200:
        hint = _portal_role_status_hint(rr.status_code)
        _add_step("role_lookup", False,
                  f"Portal returned HTTP {rr.status_code}{hint}",
                  http_status=rr.status_code,
                  response_preview=sanitize_proxy_error(rr.text))
        return None
    try:
        role_data = rr.json()
        items = role_data.get("items") or []
    except Exception:
        items = []
    if not items:
        hint = (f" for search='{role_name}'" if role_name else
                " (no role_name filter — portal returned empty list)")
        _add_step("role_lookup", False,
                  f"No roles found{hint}. Confirm role_name + account_id "
                  f"OR remove the role_name filter to see all roles",
                  http_status=200,
                  response_preview=str(role_data)[:500])
        return None
    available = [r.get("role_arn") for r in items if r.get("role_arn")]
    target_arn = _portal_pick_role_arn(items, account_id)
    if not target_arn:
        _add_step("role_lookup", False,
                  f"Could not find role ARN for account_id='{account_id}'. "
                  f"Available roles: {available}",
                  http_status=200,
                  response_preview=str(items)[:500])
        return None
    _add_step("role_lookup", True,
              f"Found role: {target_arn}", http_status=200,
              response_preview=f"available={len(items)} roles, picked: {target_arn}")
    return target_arn


def _portal_creds_status_hint(status_code: int) -> str:
    """Explain a non-200 from the STS credentials endpoint in admin terms."""
    if status_code == 401:
        return " — JWT may have expired or wrong format"
    if status_code == 403:
        return " — user lacks permission to assume this role"
    if status_code == 400:
        return " — may need service_first_number (sf_ref_no) in config"
    return ""


def _portal_step_credentials(_add_step, _req, sanitize_proxy_error, resolved,
                             token, target_arn, verify, timeout, proxies):
    """Step 3 — return the STS credentials dict, or None once recorded failed."""
    creds_url = f"{resolved['creds_url_base']}/{target_arn}"
    sf_ref_no = resolved.get("sf_ref_no")
    payload = {"service_first_number": sf_ref_no} if sf_ref_no else {}
    try:
        cr = _req.post(creds_url,
                        headers={"Authorization": f"Bearer {token}",
                                  "Content-Type": "application/json"},
                        json=payload,
                        verify=verify, timeout=timeout, proxies=proxies)
    except Exception as exc:
        _add_step("sts_credentials", False,
                  f"Network/transport error: {sanitize_proxy_error(str(exc))}")
        return None
    if cr.status_code != 200:
        hint = _portal_creds_status_hint(cr.status_code)
        _add_step("sts_credentials", False,
                  f"Portal returned HTTP {cr.status_code}{hint}",
                  http_status=cr.status_code,
                  response_preview=sanitize_proxy_error(cr.text))
        return None
    try:
        raw = cr.json().get("Credentials")
    except Exception:
        raw = None
    if not raw or not raw.get("AccessKeyId"):
        _add_step("sts_credentials", False,
                  "Portal returned 200 but no Credentials.AccessKeyId in response",
                  http_status=200,
                  response_preview=cr.text)
        return None
    _add_step("sts_credentials", True,
              f"AWS creds obtained (key: {raw['AccessKeyId'][:8]}...)",
              http_status=200)
    return raw


def _portal_run_steps(_add_step, _req, sanitize_proxy_error, resolved,
                      svc_user, svc_pass, verify, timeout, proxies):
    """Run JWT → role lookup → STS in order, stopping at the first failure.

    Returns ``(token, raw_credentials)``; on a failure the second element is
    whatever was resolved so far (None, or the role ARN) and the failing step
    has already been appended to the diagnostic ``steps`` array.
    """
    # ── Step 1: JWT auth ──────────────────────────────────────
    token = _portal_step_jwt(_add_step, _req, sanitize_proxy_error,
                             resolved, svc_user, svc_pass,
                             verify, timeout, proxies)
    if token is None:
        return None, None

    # ── Step 2: Role lookup ────────────────────────────────────
    target_arn = _portal_step_role(_add_step, _req, sanitize_proxy_error,
                                   resolved, svc_user, svc_pass,
                                   verify, timeout, proxies)
    if target_arn is None:
        return token, None

    # ── Step 3: Fetch STS credentials ─────────────────────────
    raw = _portal_step_credentials(_add_step, _req, sanitize_proxy_error,
                                   resolved, token, target_arn,
                                   verify, timeout, proxies)
    if raw is None:
        return token, target_arn
    return token, raw


async def _portal_full_auth_test(svc_user: str, svc_pass: str) -> Dict[str, Any]:
    """Full three-step portal auth diagnostic for a configured service account."""
    # ── Full auth test mode (service account configured) ──────────────
    # BF-395: STEP-BY-STEP diagnostic.  The previous version called
    # fetch_credentials() as a single black box and only surfaced a
    # sanitized PortalAuthError message.  Admins couldn't tell whether
    # JWT, role lookup, or final creds fetch failed — and HTTP status
    # codes / response bodies were swallowed.
    #
    # Now we run each step individually and return a ``steps`` array
    # with per-step status, HTTP code, and the portal's actual response
    # body (sanitized).  Admins can immediately see which step broke.
    from core.aws_portal_auth import (
        PortalAuthError, clear_cache, _resolve_portal_config,
        _build_proxies,
    )
    from core.proxy_utils import sanitize_proxy_error
    import requests as _req

    steps: list = []

    def _add_step(name: str, ok: bool, message: str = "", http_status: int = 0,
                   response_preview: str = ""):
        steps.append({
            "name":              name,
            "ok":                ok,
            "message":           message,
            "http_status":       http_status,
            "response_preview":  response_preview[:500] if response_preview else "",
        })

    try:
        clear_cache(svc_user)

        # Resolve config to get URLs + proxy + verify
        resolved = _resolve_portal_config()
        verify = resolved["verify_ssl"]
        timeout = min(float(resolved["timeout"] or 10), 12)
        proxies = _build_proxies(resolved["proxy_url"])

        def _run_steps():
            return _portal_run_steps(_add_step, _req, sanitize_proxy_error,
                                      resolved, svc_user, svc_pass,
                                      verify, timeout, proxies)

        try:
            token, raw = await asyncio.wait_for(
                asyncio.to_thread(_run_steps), timeout=20.0,
            )
        except asyncio.TimeoutError:
            return {"success": False, "mode": "full_auth",
                     "message": "Portal auth exceeded 20s — check network/proxy reachability",
                     "steps": steps}

        all_ok = all(s["ok"] for s in steps) and bool(raw and raw.get("AccessKeyId"))
        if all_ok:
            return {
                "success":           True,
                "mode":              "full_auth",
                "message":           f"All 3 portal steps succeeded for service account '{svc_user}'",
                "access_key_prefix": raw["AccessKeyId"][:8] + "...",
                "expires_at":        raw.get("Expiration"),
                "steps":             steps,
            }
        # Find first failed step for a top-level summary message
        failed = next((s for s in steps if not s["ok"]), None)
        return {
            "success": False,
            "mode":    "full_auth",
            "message": (
                f"Step '{failed['name']}' failed: {failed['message']}"
                if failed else "Unknown failure — see steps for details"
            ),
            "steps":   steps,
        }
    except PortalAuthError as exc:
        # Fallback in case any helper raises despite our manual stepping
        return {"success": False, "mode": "full_auth",
                "message": sanitize_proxy_error(str(exc)),
                "steps":   steps}
    except Exception as exc:
        logger.exception("AWS portal full-auth test crashed")
        return {"success": False, "mode": "full_auth",
                "message": f"Unexpected error: {sanitize_proxy_error(str(exc))}",
                "steps":   steps}


@router.get("/api/admin/aws-portal/cache")
async def get_aws_portal_cache_stats(_user: dict = Depends(require_admin)):
    """Return AWS portal credential cache statistics."""
    from core.aws_portal_auth import cache_stats
    return cache_stats()


@router.delete("/api/admin/aws-portal/cache")
async def clear_aws_portal_cache(username: Optional[str] = None, _user: dict = Depends(require_admin)):
    """Clear cached AWS portal credentials."""
    from core.aws_portal_auth import clear_cache
    cleared = clear_cache(username)
    audit_event(_db_manager, _user, None, "clear_aws_portal_cache", "aws_portal_cache",
                details={"target_username": username or "all"})
    return {"cleared": cleared, "username": username or "all"}


# ── User-facing portal auth (per-user mode) ──

class PortalAuthRequest(BaseModel):
    username: str = Field(min_length=1)
    password: str = Field(min_length=1)
    # BF-PORTAL-CONN-OVERRIDES: when the modal pops up DURING a query, the
    # frontend now forwards the connection_id that triggered the failure.
    # We use it to resolve the connection's portal_base_url / role_name /
    # portal_account_id / sf_ref_no / proxy_url overrides so the JWT call
    # hits the same endpoint Connection Manager uses for that connection.
    # Without this, the global aws_portal config wins — which causes
    # "wrong version number" SSL errors when the global proxy/URL doesn't
    # match what the connection expects.
    connection_id: Optional[int] = None


def _resolve_portal_overrides_for_connection(connection_id: int) -> dict:
    """Read connection-level portal overrides for the JWT/STS call.

    Thin wrapper around ``aws_portal_auth.build_portal_kwargs_for_connection``
    that handles the DB lookup.  The actual field-mapping lives in
    ``aws_portal_auth.py`` — single source of truth for every code path
    that fetches portal credentials for a specific connection.

    Returns ``{}`` when the connection is missing / DB raises (so the
    caller's ``fetch_credentials`` call falls through to global config —
    better than failing the whole password modal).
    """
    try:
        conn = _db_manager.get_connection_raw(int(connection_id))
        if not conn:
            return {}
        from core.aws_portal_auth import build_portal_kwargs_for_connection
        return build_portal_kwargs_for_connection(conn.get("config") or {})
    except Exception as exc:
        logger.warning(
            "[portal-auth] could not resolve overrides for connection_id=%s: %s",
            connection_id, exc,
        )
        return {}


@router.post("/api/aws-portal/authenticate")
async def user_portal_authenticate(body: PortalAuthRequest, _user: dict = Depends(get_current_user)):
    """Authenticate the current user against the AWS portal and cache creds.

    This is for per-user mode — user provides their own portal credentials.
    For shared/system account mode, admin configures service_username/password
    and all connections auto-use those creds.

    BF-285: also stores the password (encrypted via Fernet) in the
    in-memory portal-password vault so subsequent BF-284 RefreshableCredentials
    auto-refresh callbacks can re-fetch without re-prompting the user.
    The vault TTL matches session TTL (8 hours by default).  No persistence —
    a pod restart wipes it.

    BF-PORTAL-CONN-OVERRIDES: when ``connection_id`` is present, the
    connection-level portal overrides (portal_base_url, role_name,
    account_id, sf_ref_no, proxy_url) are loaded from the Connection row
    and forwarded to ``fetch_credentials`` — same overrides that
    Connection Manager uses, so a connection whose test-button works
    won't fail here with "SSL wrong version number" or similar.
    """
    # SECURITY P1 (2026-08-23): the session user was NEVER compared to
    # ``body.username``, so any authenticated user could authenticate AS any
    # other AD account it held (or guessed) credentials for — seeding the
    # VICTIM's password vault and STS credential cache (both keyed by
    # username), and able to lock the victim's AD account by spamming wrong
    # passwords under their name.  ``core.roles.may_act_as`` is the ONE
    # chokepoint for this rule (shared with /api/aws-portal/credentials):
    # admins may act for anyone, everyone else only for themselves.
    # Checked BEFORE the feature flag so the authz contract holds — and is
    # testable — whether or not the portal is enabled.
    from core.roles import may_act_as as _may_act_as
    if not _may_act_as(_user, body.username):
        logger.warning(
            "[portal-auth] DENIED: session user %r tried to authenticate as %r",
            (_user or {}).get("username"), body.username)
        raise HTTPException(
            status_code=403,
            detail="You may only authenticate the AWS portal as your own AD user")
    from core import config as _cfg
    if not _cfg.aws_portal.enabled:
        raise HTTPException(status_code=400, detail="AWS portal authentication is not enabled")
    from core.aws_portal_auth import fetch_credentials, PortalAuthError
    from core.portal_password_vault import store_password

    # Pull connection-level overrides (if any) BEFORE the portal call so
    # the JWT request hits the right endpoint with the right proxy.
    portal_kwargs: dict = {}
    if body.connection_id:
        portal_kwargs = await asyncio.to_thread(
            _resolve_portal_overrides_for_connection, int(body.connection_id),
        )

    try:
        creds = fetch_credentials(body.username, body.password, **portal_kwargs)
        # BF-285: cache the password (encrypted) for the duration of the
        # session so the BF-284 RefreshableCredentials refresh-callback
        # can re-fetch fresh STS tokens without prompting the user again.
        try:
            store_password(body.username, body.password)
        except Exception as _vault_exc:
            # Vault write failure is non-fatal — auth still succeeded; user
            # may just be re-prompted on next refresh.
            logger.warning("[portal-vault] store_password failed for '%s': %s",
                            body.username, _vault_exc)
        return {
            "success": True,
            "message": "AWS credentials obtained successfully",
            "access_key_prefix": creds["aws_access_key_id"][:8] + "...",
            "expires_in_seconds": int(creds.get("expires_at", 0) - __import__("time").time()),
            # BF-285: tell the frontend whether the password is now vaulted
            # so it can skip the prompt on subsequent submits.
            "password_vaulted": True,
            # Echo back so the frontend can log which connection's overrides
            # were used (helps diagnose multi-connection portal setups).
            "connection_id": body.connection_id,
        }
    except PortalAuthError as exc:
        raise HTTPException(status_code=401, detail=str(exc))


@router.get("/api/aws-portal/password-status")
async def user_portal_password_status(_user: dict = Depends(get_current_user)):
    """BF-285: cheap check — does the current user have a vaulted password?

    Frontend uses this on app load to decide whether to show the
    "enter your AWS portal password" modal preemptively, vs. waiting
    for a 401 on the first portal-mode query.
    """
    from core.portal_password_vault import has_password
    username = (_user or {}).get("username", "")
    return {"username": username, "vaulted": has_password(username)}


@router.post("/api/aws-portal/clear-password")
async def user_portal_clear_password(_user: dict = Depends(get_current_user)):
    """BF-285: drop the current user's vaulted portal password.  Forces
    them to re-enter on the next portal-mode query.  Useful when the user
    has rotated their AD password — saves them from the next refresh
    failure.  Also called automatically from the logout handler (see
    auth router)."""
    from core.portal_password_vault import clear_password
    username = (_user or {}).get("username", "")
    cleared = clear_password(username)
    return {"username": username, "cleared": cleared}


# ── Partition Cache Config ──────────────────────────────────────────────────

@router.get("/api/admin/partition-cache/config")
async def get_partition_cache_config(_user: dict = Depends(require_admin)):
    """Return current partition cache TTL configuration."""
    from core import config as _cfg
    return {
        "l1_ttl_seconds": _cfg.partition_cache.l1_ttl_seconds,
        "l2_ttl_seconds": _cfg.partition_cache.l2_ttl_seconds,
        "l1_max_entries": _cfg.partition_cache.l1_max_entries,
    }


@router.put("/api/admin/partition-cache/config")
async def set_partition_cache_config(body: dict, _user: dict = Depends(require_admin)):
    """Update partition cache TTLs at runtime."""
    from core import config as _cfg
    allowed = {"l1_ttl_seconds", "l2_ttl_seconds", "l1_max_entries"}
    updates = {k: v for k, v in body.items() if k in allowed}
    if not updates:
        raise HTTPException(status_code=400, detail=f"No valid keys. Allowed: {sorted(allowed)}")
    for key, val in updates.items():
        _cfg.set("partition_cache", key, int(val))
    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "set_partition_cache_config", resource_type="partition_cache_config",
                      resource_id=str(updates))
    return {"updated": updates}


# ── S3 Handler Cache Config ──────────────────────────────────────────────────

@router.get("/api/admin/s3/config")
async def get_s3_config(_user: dict = Depends(require_admin)):
    """Return S3 handler cache configuration."""
    from core import config as _cfg
    return {
        "default_region": _cfg.s3.default_region,
        "handler_cache_ttl_seconds": _cfg.s3.handler_cache_ttl_seconds,
        "default_onprem_access_mode": _cfg.s3.default_onprem_access_mode,
    }


@router.put("/api/admin/s3/config")
async def set_s3_config(body: dict, _user: dict = Depends(require_admin)):
    """Update S3 handler cache configuration at runtime."""
    from core import config as _cfg
    allowed = {"default_region", "handler_cache_ttl_seconds", "default_onprem_access_mode"}
    updates = {k: v for k, v in body.items() if k in allowed}
    if not updates:
        raise HTTPException(status_code=400, detail=f"No valid keys. Allowed: {sorted(allowed)}")
    if "default_onprem_access_mode" in updates and updates["default_onprem_access_mode"] not in ("native", "presigned"):
        raise HTTPException(status_code=400, detail="default_onprem_access_mode must be 'native' or 'presigned'")
    for key, val in updates.items():
        _cfg.set("s3", key, val)
    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "set_s3_config", resource_type="s3_config", resource_id=str(updates))
    return {"updated": updates}


@router.get("/api/admin/s3/handler-cache")
async def get_s3_handler_cache(_user: dict = Depends(require_admin)):
    """Return info about cached S3 handler instances (age, auth mode, expiry)."""
    from main import conn_manager
    return await _adb(conn_manager.get_cache_info)


@router.post("/api/admin/s3/clear-cache")
async def clear_s3_handler_cache(_user: dict = Depends(require_admin)):
    """Clear all cached S3 handlers — forces credential re-creation on next use."""
    from main import conn_manager
    with conn_manager._s3_lock:
        count = len(conn_manager._s3_handlers)
        conn_manager._s3_handlers.clear()
    username = (_user or {}).get("username", "admin")
    # Also clear S3 file listing cache (stale after credential refresh)
    try:
        from core.s3_utilities import clear_listing_cache
        clear_listing_cache()
    except Exception:
        pass
    await _adb(_db_manager.audit, username, "clear_s3_handler_cache", resource_type="s3_cache", resource_id=f"cleared={count}")
    logger.info("Admin %s cleared S3 handler cache (%d handlers)", username, count)
    return {"cleared": count}


@router.get("/api/aws-portal/status")
async def user_portal_status(_user: dict = Depends(get_current_user)):
    """Check if the current user has active AWS portal credentials."""
    from core import config as _cfg
    if not _cfg.aws_portal.enabled:
        return {"enabled": False, "authenticated": False, "mode": "disabled"}
    from core.aws_portal_auth import get_cached_credentials
    import time as _time
    username = (_user or {}).get("username", "")
    cached = get_cached_credentials(username)
    has_service = bool(_cfg.aws_portal.service_username and _cfg.aws_portal.service_password)
    svc_cached = get_cached_credentials(_cfg.aws_portal.service_username) if has_service else None
    return {
        "enabled": True,
        "mode": "service_account" if has_service else "per_user",
        "authenticated": bool(cached or svc_cached),
        "user_creds_active": bool(cached),
        "service_creds_active": bool(svc_cached),
        "expires_in_seconds": int(cached["expires_at"] - _time.time()) if cached else (
            int(svc_cached["expires_at"] - _time.time()) if svc_cached else 0),
    }


# ── Reusable AWS credential retrieval endpoint ────────────────────────────
# Single endpoint that returns STS credentials for use by:
#   - Published API consumers (server-to-server S3 access)
#   - ETL batch jobs (Spark / Airflow tasks fetch fresh creds at runtime)
#   - External integrations that need to query S3 on behalf of QueryStudio
#
# Caller chooses a mode:
#   - "current_user"   → uses the logged-in user's vault/cache (AD bearer)
#   - "system_account" → uses a DB-stored system account (admin/api-key)
#   - "service"        → uses aws_portal.service_username from config (admin)
#
# Response contains the FULL STS payload including ISO + epoch expiry so
# the caller can cache locally and refresh only when needed (see
# core/aws_credentials_client.py for a reference Python client).

class AwsCredentialsRequest(BaseModel):
    """Generic AWS credential request.

    Common (generic) shape — supply AD credentials + portal details:
        {
          "username": "svc_acct",
          "password": "...",
          "portal_base_url": "https://portal.corp",  // optional, falls back to config
          "role_name": "DataReader",                 // optional
          "account_id": "123456789012",              // optional
          "sf_ref_no": "...",                        // optional
          "proxy_url": "..."                         // optional
        }

    Convenience modes for QueryStudio-internal callers (auto-selected when
    ``username``/``password`` are omitted):
      - ``system_account`` + ``system_account_id`` — admin-only DB lookup
      - ``service`` — admin-only, uses ``aws_portal.service_username`` config
      - ``current_user`` — uses the calling user's vaulted password
    """
    mode: Optional[str] = Field(
        default=None,
        description=(
            "Auto-derived when omitted: 'direct' if username+password set, "
            "'system_account' if system_account_id set, else 'current_user'. "
            "Valid values: direct | current_user | system_account | service."
        ),
    )
    # mode=direct — generic primary path
    username: Optional[str] = None
    password: Optional[str] = None
    # mode=system_account
    system_account_id: Optional[int] = None
    force_refresh: bool = False
    # Per-call portal overrides — usually omitted (config defaults win)
    portal_base_url: Optional[str] = None
    role_name: Optional[str] = None
    account_id: Optional[str] = None
    sf_ref_no: Optional[str] = None
    proxy_url: Optional[str] = None


def _shape_creds_response(creds: dict, source: str) -> dict:
    """Normalise the cached/fresh creds dict into the API response shape."""
    import time as _time
    from datetime import datetime as _dt, timezone as _tz

    expires_at = float(creds.get("expires_at") or 0)
    expiration_iso = creds.get("expiration_iso")
    if not expiration_iso and expires_at:
        expiration_iso = _dt.fromtimestamp(expires_at, tz=_tz.utc).isoformat()
    expires_in = max(0, int(expires_at - _time.time())) if expires_at else 0

    return {
        "aws_access_key_id": creds.get("aws_access_key_id", ""),
        "aws_secret_access_key": creds.get("aws_secret_access_key", ""),
        "aws_session_token": creds.get("aws_session_token", ""),
        "expires_at": expires_at,
        "expiration_iso": expiration_iso,
        "expires_in_seconds": expires_in,
        "source": source,
    }


async def _aws_creds_current_user(_user: dict, body, portal_kwargs: dict):
    """mode=current_user — serve the session user's own STS credentials.

    Cache first (unless force_refresh), then a vault-driven fresh fetch.
    """
    from core.aws_portal_auth import (
        fetch_credentials, get_cached_credentials, PortalAuthError,
    )
    username = (_user or {}).get("username", "")
    if not username:
        raise HTTPException(status_code=401, detail="No authenticated user")

    if not body.force_refresh:
        cached = get_cached_credentials(username)
        if cached:
            return _shape_creds_response(cached, source=f"user:{username}")

    # Try vault-driven fresh fetch
    try:
        from core.portal_password_vault import get_password as _vault_get
        vault_pw = _vault_get(username)
        if not vault_pw:
            raise HTTPException(
                status_code=401,
                detail={
                    "type": "portal_password_required",
                    "message": "No vaulted password for current user. "
                               "POST /api/aws-portal/authenticate first.",
                },
            )
        creds = fetch_credentials(username, vault_pw, **portal_kwargs)
    except PortalAuthError as exc:
        raise HTTPException(status_code=401, detail=str(exc))

    await _adb(
        _db_manager.audit, username, "aws_creds_fetch",
        resource_type="aws_portal_credentials",
        resource_id=f"user:{username}",
    )
    return _shape_creds_response(creds, source=f"user:{username}")


async def _aws_creds_direct(_user: dict, body, portal_kwargs: dict):
    """mode=direct — caller supplies the AD username + password in the body.

    Decides whether the CACHE may answer: only a caller acting for itself (or
    an admin) gets the unauthenticated shortcut.
    """
    from core.aws_portal_auth import (
        fetch_credentials, get_cached_credentials, PortalAuthError,
    )
    if not (body.username and body.password):
        raise HTTPException(
            status_code=400,
            detail="username and password required for mode=direct",
        )

    # 2026-08-23 — SCOPED TO THE CACHE, deliberately.  The P0 is that a
    # cache HIT returned live STS credentials with the supplied password
    # NEVER CHECKED, so a non-admin plus a victim's username and junk
    # password got the victim's credentials.  Gating all of mode=direct
    # instead would break a legitimate flow: supplying a SERVICE
    # ACCOUNT's username AND password is authentication, not
    # impersonation, and `fetch_credentials` validates it.
    #
    # So: only the unauthenticated shortcut is restricted.  A caller
    # acting for someone else skips the cache and must prove the password
    # every time — which is the property that was missing.
    from core.roles import may_act_as as _may_act_as
    _may_use_cache = _may_act_as(_user, body.username)
    if not _may_use_cache:
        logger.info(
            "[portal-creds] session user %r requested credentials for "
            "%r — cache BYPASSED, the supplied password must "
            "authenticate.",
            (_user or {}).get("username"), body.username)

    if _may_use_cache and not body.force_refresh:
        cached = get_cached_credentials(body.username)
        if cached:
            return _shape_creds_response(cached, source=f"direct:{body.username}")

    try:
        creds = fetch_credentials(body.username, body.password, **portal_kwargs)
    except PortalAuthError as exc:
        raise HTTPException(status_code=401, detail=str(exc))

    await _adb(
        _db_manager.audit,
        (_user or {}).get("username", "") or body.username,
        "aws_creds_fetch",
        resource_type="aws_portal_credentials",
        resource_id=f"direct:{body.username}",
    )
    return _shape_creds_response(creds, source=f"direct:{body.username}")


async def _aws_creds_system_account_row(body) -> Dict[str, Any]:
    """Load the aws_portal system account named by the body, or refuse."""
    acct = await _adb(_db_manager.get_system_account_raw, int(body.system_account_id))
    if not acct or not acct.get("is_active", True):
        raise HTTPException(
            status_code=404,
            detail=f"System account {body.system_account_id} not found or inactive",
        )
    if acct.get("account_type") != "aws_portal":
        raise HTTPException(
            status_code=400,
            detail=f"System account {body.system_account_id} is not aws_portal type",
        )
    return acct


async def _aws_creds_system_account_login(acct: dict, body) -> Tuple[str, str]:
    """Resolve the AD username + password a system account should present.

    Phase 156 (2026-06-25) deep-dive -- when use_vault=True the
    acct["password"] column is BLANK by design.  Route through the
    Phase 154 qs_credentials chokepoint so vault-backed accounts
    work for the admin-credential-fetch endpoint too.  Pre-fix:
    fetch_credentials was called with empty password and surfaced
    a confusing portal auth error.
    """
    _aws_username = acct.get("username") or ""
    _aws_password = acct.get("password") or ""
    if not acct.get("use_vault"):
        return _aws_username, _aws_password
    try:
        from core.qs_credentials import resolve_system_account
        _resolved = await _adb(resolve_system_account,
                                int(body.system_account_id))
        if _resolved.get("username"):
            _aws_username = _resolved["username"]
        if _resolved.get("password"):
            _aws_password = _resolved["password"]
    except Exception as _sr_exc:
        await _adb(
            _db_manager.update_system_account_status,
            int(body.system_account_id), "failed",
            f"vault resolution failed: {_sr_exc}",
        )
        raise HTTPException(
            status_code=500,
            detail=(
                f"System account {body.system_account_id} has "
                f"use_vault=True but qs_credentials failed: "
                f"{_sr_exc}.  Refusing to call portal with blank "
                f"password."
            ),
        ) from _sr_exc
    return _aws_username, _aws_password


async def _aws_creds_system_account(_user: dict, body, portal_kwargs: dict):
    """mode=system_account — admin-only fetch under a service identity."""
    from core.aws_portal_auth import (
        fetch_credentials, get_cached_credentials, PortalAuthError,
        _cache_lock, _cred_cache,
    )
    import time as _time

    if not body.system_account_id:
        raise HTTPException(status_code=400, detail="system_account_id required for mode=system_account")

    acct = await _aws_creds_system_account_row(body)

    cache_key = f"sys:{body.system_account_id}"
    if not body.force_refresh:
        cached = get_cached_credentials(cache_key)
        if cached:
            return _shape_creds_response(cached, source=cache_key)

    _aws_username, _aws_password = await _aws_creds_system_account_login(acct, body)

    try:
        creds = fetch_credentials(_aws_username, _aws_password, **portal_kwargs)
        # Re-cache under the system-account key so subsequent S3 clients
        # (CredentialManager) hit the same cache.
        with _cache_lock:
            _cred_cache[cache_key] = (creds, creds.get("expires_at", _time.time() + 3300))
        await _adb(_db_manager.update_system_account_status, int(body.system_account_id), "success")
    except PortalAuthError as exc:
        await _adb(
            _db_manager.update_system_account_status,
            int(body.system_account_id), "failed", str(exc),
        )
        raise HTTPException(status_code=401, detail=str(exc))

    await _adb(
        _db_manager.audit, (_user or {}).get("username", "admin"),
        "aws_creds_fetch", resource_type="aws_portal_credentials",
        resource_id=cache_key,
    )
    return _shape_creds_response(creds, source=cache_key)


async def _aws_creds_service(_cfg, _user: dict, body, portal_kwargs: dict):
    """mode=service — admin-only legacy path using the global service account."""
    from core.aws_portal_auth import (
        fetch_credentials, get_cached_credentials, PortalAuthError,
    )
    svc_user = _cfg.aws_portal.service_username
    svc_pass = _cfg.aws_portal.service_password
    if not (svc_user and svc_pass):
        raise HTTPException(
            status_code=400,
            detail="aws_portal.service_username/service_password not configured",
        )

    if not body.force_refresh:
        cached = get_cached_credentials(svc_user)
        if cached:
            return _shape_creds_response(cached, source=f"service:{svc_user}")

    try:
        creds = fetch_credentials(svc_user, svc_pass, **portal_kwargs)
    except PortalAuthError as exc:
        raise HTTPException(status_code=401, detail=str(exc))

    await _adb(
        _db_manager.audit, (_user or {}).get("username", "admin"),
        "aws_creds_fetch", resource_type="aws_portal_credentials",
        resource_id=f"service:{svc_user}",
    )
    return _shape_creds_response(creds, source=f"service:{svc_user}")


@router.post("/api/aws-portal/credentials")
async def get_aws_credentials(
    body: AwsCredentialsRequest,
    _user: dict = Depends(get_current_user),
):
    """Return AWS STS credentials for the requested identity.

    Modes:
      * ``current_user`` — any authenticated user. Resolves via the
        portal-password vault if present, otherwise via the existing
        per-user cache. Used by interactive sessions and published-API
        consumers that authenticate as a real AD user.
      * ``system_account`` — admin-only. Looks up the system account
        row by ``system_account_id`` and fetches creds against the
        portal using the encrypted AD password. Used by ETL batch jobs
        and scheduled feeds that run under a service identity.
      * ``service`` — admin-only. Uses ``aws_portal.service_username``
        from config. Legacy global-fallback path.
      * ``direct`` — generic mode. Caller supplies ``username`` +
        ``password`` directly in the request body, along with any
        portal overrides (``portal_base_url``, ``role_name``,
        ``account_id``, ``sf_ref_no``, ``proxy_url``). For external
        consumers / scripts that already have AD service credentials
        and just want STS keys back. Admins can fetch for ANY user;
        non-admins may only fetch for their own AD username.

    All modes honour ``force_refresh`` to bypass the cache. Per-connection
    portal overrides may be passed via ``portal_base_url``/``role_name``/
    ``account_id``/``sf_ref_no``/``proxy_url`` (otherwise config defaults
    apply).
    """
    from core import config as _cfg
    if not _cfg.aws_portal.enabled:
        raise HTTPException(status_code=400, detail="AWS portal authentication is not enabled")

    # Auto-derive mode from the request shape when the caller hasn't
    # specified one. This keeps the endpoint simple for the generic case
    # (caller just sends username + password + portal details).
    if body.mode:
        mode = body.mode.lower()
    elif body.username and body.password:
        mode = "direct"
    elif body.system_account_id:
        mode = "system_account"
    else:
        mode = "current_user"

    portal_kwargs = {
        k: v for k, v in {
            "portal_base_url": body.portal_base_url,
            "role_name": body.role_name,
            "account_id": body.account_id,
            "sf_ref_no": body.sf_ref_no,
            "proxy_url": body.proxy_url,
        }.items() if v
    }

    # ── current_user: vault or per-user cache ────────────────────────────
    if mode == "current_user":
        return await _aws_creds_current_user(_user, body, portal_kwargs)

    # ── direct: caller supplies AD username + password in body ───────────
    # SECURITY P0 (2026-08-23): "the portal validates the AD password" was
    # only true on the FETCH path.  The CACHE lookup ran first, keyed on the
    # caller-supplied ``body.username``, with no comparison to the session
    # user — so a non-admin submitting a victim's username plus a JUNK
    # password got a 200 with the victim's live STS credentials whenever the
    # victim had authenticated recently (cache hit = password never checked).
    # The docstring's contract — "Admins can fetch for ANY user; non-admins
    # may only fetch for their own AD username" — is now ENFORCED, before
    # the cache is ever consulted, via the same ``core.roles.may_act_as``
    # chokepoint that guards /api/aws-portal/authenticate.
    if mode == "direct":
        return await _aws_creds_direct(_user, body, portal_kwargs)

    # ── system_account and service: admin-only paths ─────────────────────
    # BF-401 cleanup — replace pre-existing inline check with the canonical
    # is_admin_like() helper (satisfies test_phase115_hardening regression net).
    from core.roles import is_admin_like as _is_admin_like
    if not _is_admin_like(_user):
        raise HTTPException(
            status_code=403,
            detail="mode=system_account|service requires admin privileges",
        )

    if mode == "system_account":
        return await _aws_creds_system_account(_user, body, portal_kwargs)

    if mode == "service":
        return await _aws_creds_service(_cfg, _user, body, portal_kwargs)

    raise HTTPException(
        status_code=400,
        detail=f"Unknown mode '{body.mode}'. Use: current_user | system_account | service",
    )


# ── Phase 134: S3 Performance Admin ──────────────────────────────────────────

@router.get("/api/admin/s3-performance/config")
async def get_s3_performance_config(_user: dict = Depends(require_admin)):
    """Return all S3 performance tuning configuration."""
    from core import config as _cfg
    s = _cfg.s3
    pv = _cfg.published_views
    return {
        "column_pruning_download": s.column_pruning_download,
        "scan_budget_soft": s.scan_budget_soft,
        # 2026-09-21 (FB-55) — THE plain-parquet file-count ceiling.
        # ``scan_budget_hard`` is still served because the admin panel
        # renders a control bound to it and it is honoured as a
        # DEPRECATED ALIAS, but an admin setting the ceiling from the
        # UI must be able to set the key that is now its name —
        # otherwise the product itself teaches the old spelling.
        "max_files_per_query": int(_cfg.get("s3", "max_files_per_query", 0) or 0),
        "scan_budget_hard": s.scan_budget_hard,
        "suggest_partitions": s.suggest_partitions,
        "footer_stats_enabled": s.footer_stats_enabled,
        "footer_stats_ttl_hours": s.footer_stats_ttl_hours,
        "footer_stats_min_files_threshold": s.footer_stats_min_files_threshold,
        # ── file_cache_* : INERT since 2026-09-07 ────────────────────
        # ``core/s3_file_cache.py`` was deleted (no production reader or
        # writer; its last consumer was removed on purpose — see
        # duckdb_subprocess.py:2703).  These four keys are still SERVED
        # because frontend/src/components/admin/S3PerformanceSection.tsx
        # renders controls bound to them, and dropping them here would
        # leave that panel with undefined-valued inputs.  They now change
        # NOTHING.  Removing them means one commit that touches, together:
        # core/config.py (`s3.file_cache_*` properties + `_DEFAULTS`),
        # this response, the PUT allow-list below, and the .tsx.
        "file_cache_enabled": s.file_cache_enabled,
        "file_cache_max_gb": s.file_cache_max_gb,
        "file_cache_ttl_hours": s.file_cache_ttl_hours,
        "file_cache_validate_etag": s.file_cache_validate_etag,
        "estimate_enabled": s.estimate_enabled,
        "estimate_threshold": s.estimate_threshold,
        "scan_quotas_enabled": s.scan_quotas_enabled,
        "scan_quota_analyst_hourly": s.scan_quota_analyst_hourly,
        "scan_quota_analyst_daily": s.scan_quota_analyst_daily,
        "scan_quota_viewer_hourly": s.scan_quota_viewer_hourly,
        "scan_quota_viewer_daily": s.scan_quota_viewer_daily,
        "scan_quota_api_key_hourly": s.scan_quota_api_key_hourly,
        "scan_quota_api_key_daily": s.scan_quota_api_key_daily,
        "perf_audit_enabled": s.perf_audit_enabled,
        "perf_audit_retention_days": s.perf_audit_retention_days,
        "cache_encryption_enabled": s.cache_encryption_enabled,
        "cache_encryption_key_source": s.cache_encryption_key_source,
        "circuit_breaker_enabled": s.circuit_breaker_enabled,
        "circuit_breaker_threshold": s.circuit_breaker_threshold,
        "circuit_breaker_cooldown_seconds": s.circuit_breaker_cooldown_seconds,
        "graceful_degradation_enabled": s.graceful_degradation_enabled,
        "warmup_enabled": pv.warmup_enabled,
        "warmup_interval_minutes": pv.warmup_interval_minutes,
        "warmup_max_concurrent": pv.warmup_max_concurrent,
    }


@router.put("/api/admin/s3-performance/config")
async def set_s3_performance_config(body: dict, _user: dict = Depends(require_admin)):
    """Update S3 performance configuration at runtime."""
    from core import config as _cfg
    s3_keys = {
        "column_pruning_download", "scan_budget_soft", "scan_budget_hard",
        "max_files_per_query",
        "suggest_partitions", "footer_stats_enabled", "footer_stats_ttl_hours",
        "footer_stats_min_files_threshold", "file_cache_enabled", "file_cache_max_gb",
        "file_cache_ttl_hours", "file_cache_validate_etag", "estimate_enabled",
        "estimate_threshold", "scan_quotas_enabled", "scan_quota_analyst_hourly",
        "scan_quota_analyst_daily", "scan_quota_viewer_hourly", "scan_quota_viewer_daily",
        "scan_quota_api_key_hourly", "scan_quota_api_key_daily",
        "perf_audit_enabled", "perf_audit_retention_days",
        "cache_encryption_enabled", "cache_encryption_key_source",
        "circuit_breaker_enabled", "circuit_breaker_threshold",
        "circuit_breaker_cooldown_seconds", "graceful_degradation_enabled",
    }
    pv_keys = {"warmup_enabled", "warmup_interval_minutes", "warmup_max_concurrent"}
    allowed = s3_keys | pv_keys
    updates = {k: v for k, v in body.items() if k in allowed}
    if not updates:
        raise HTTPException(status_code=400, detail=f"No valid keys. Allowed: {sorted(allowed)}")
    # Validate enum values
    if "column_pruning_download" in updates and updates["column_pruning_download"] not in ("auto", "full", "columns_only"):
        raise HTTPException(status_code=400, detail="column_pruning_download must be 'auto', 'full', or 'columns_only'")
    for key, val in updates.items():
        section = "published_views" if key in pv_keys else "s3"
        _cfg.set(section, key, val)
    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "set_s3_performance_config",
                      resource_type="s3_performance_config", resource_id=str(updates))
    return {"updated": updates}


@router.get("/api/admin/s3-performance/stats")
async def get_s3_performance_stats(_user: dict = Depends(require_admin)):
    """Return live stats from all S3 performance modules."""
    result = {}
    try:
        from core.s3_footer_stats import FooterStatsCache
        fsc = FooterStatsCache.instance()
        result["footer_stats"] = fsc.stats() if fsc else {}
    except Exception:
        result["footer_stats"] = {}
    # ``file_cache`` -- REMOVED 2026-09-07 with core/s3_file_cache.py.
    # It reported the stats of a cache with no production reader or
    # writer, so ``hits``/``misses``/``hit_rate`` were structurally zero
    # and ``total_files`` structurally empty.  A tile that can only ever
    # show zero is not observability; an operator reading it concludes
    # the cache is cold and goes looking for a warm-up that never
    # existed.  The disk cache that IS on the S3 pre-download path is
    # ``s3_local_cache`` (BF-257) and has never been surfaced here.
    try:
        from core.s3_circuit_breaker import get_s3_circuit_breaker
        cb = get_s3_circuit_breaker()
        result["circuit_breakers"] = cb.get_all_states() if cb else {}
    except Exception:
        result["circuit_breakers"] = {}
    try:
        from core.s3_scan_quota import scan_quota_tracker
        result["scan_quotas"] = scan_quota_tracker.get_all_usage() if scan_quota_tracker else {}
    except Exception:
        result["scan_quotas"] = {}
    return result


def _clear_footer_stats_cache(cleared: list) -> None:
    """Drop the parquet footer-stats cache; record it only if it was there."""
    try:
        from core.s3_footer_stats import FooterStatsCache
        fsc = FooterStatsCache.instance()
        if fsc:
            fsc.clear()
            cleared.append("footer_stats")
    except Exception:
        pass


def _clear_s3_circuit_breaker(cleared: list) -> None:
    """Reset the S3 circuit breaker; record it only if one exists."""
    try:
        from core.s3_circuit_breaker import get_s3_circuit_breaker
        cb = get_s3_circuit_breaker()
        if cb:
            cb.reset()
            cleared.append("circuit_breaker")
    except Exception:
        pass


def _clear_s3_scan_quotas(cleared: list) -> None:
    """Reset per-role scan quota counters; record it only if tracking is on."""
    try:
        from core.s3_scan_quota import scan_quota_tracker
        if scan_quota_tracker:
            scan_quota_tracker.reset()
            cleared.append("quotas")
    except Exception:
        pass


@router.post("/api/admin/s3-performance/clear-cache")
async def clear_s3_performance_cache(body: dict = None, _user: dict = Depends(require_admin)):
    """Clear S3 performance caches. Body: {target: 'all'|'footer_stats'|'file_cache'|'circuit_breaker'|'quotas'}"""
    target = (body or {}).get("target", "all")
    cleared = []
    if target in ("all", "footer_stats"):
        _clear_footer_stats_cache(cleared)
    # ``file_cache`` -- REMOVED 2026-09-07 with core/s3_file_cache.py.
    # Nothing ever wrote that cache, so the button cleared an empty
    # directory and reported success.  A ``target="file_cache"`` request
    # now falls through to ``cleared: []``, which is the honest answer:
    # there is no such cache to clear.  (It is not an error -- callers
    # that still send the old target get an empty list, not a 500.)
    if target in ("all", "circuit_breaker"):
        _clear_s3_circuit_breaker(cleared)
    if target in ("all", "quotas"):
        _clear_s3_scan_quotas(cleared)
    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "clear_s3_performance_cache",
                      resource_type="s3_performance_cache", resource_id=target)
    out = {"cleared": cleared, "target": target}
    if target == "file_cache":
        # An empty ``cleared`` for a target the caller explicitly named is
        # indistinguishable from "the clear failed".  Say which it is:
        # the cache was deleted, so there is nothing to clear and never
        # was anything to clear.  Unknown is not empty, and neither is
        # gone.
        out["removed"] = (
            "the Phase 134-D S3 file cache was deleted on 2026-09-07 — it "
            "had no production reader or writer, so this target cleared an "
            "always-empty directory. The disk cache on the S3 pre-download "
            "path is s3_local_cache and is not cleared from here.")
    return out


# ── Scan Strategy Admin (2026-06-01) ─────────────────────────────────────────
# Surfaces the unified ``scan_strategy`` config block to operators.
# Replaces the legacy pattern of toggling 10+ individual flags
# (max_workers, BF-535 ordering, prewarm, DuckDB pragmas, boto3 pool) —
# now ONE profile picker + per-profile overrides.  See
# backend/core/scan_strategy.py for the design rationale.

_SCAN_PROFILE_NAMES = ("auto", "bulk_scan", "interactive", "low_latency")
_SCAN_FILE_ORDER_NAMES = (
    "manifest_order", "largest_first", "smallest_first", "size_balanced",
)
_SCAN_PROFILE_INT_KEYS = {
    "max_workers", "min_files_to_split", "max_files_per_worker",
    "prewarm_concurrency", "duckdb_threads", "boto3_max_pool_connections",
}
_SCAN_PROFILE_BOOL_KEYS = {
    "prewarm_footers", "duckdb_object_cache",
    "duckdb_http_keep_alive", "wait_for_supplement",
}


@router.get("/api/admin/scan-strategy/config")
async def get_scan_strategy_config(_user: dict = Depends(require_admin)):
    """Return the current scan-strategy admin block + the built-in
    profile defaults so the UI can render the effective plan even when
    the operator hasn't set overrides yet."""
    from core import config as _cfg
    from core.scan_strategy import _PROFILE_DEFAULTS, ScanProfile
    block = _cfg.get_section("scan_strategy") or {}

    def _plan_to_dict(p):
        return {
            "file_order":                p.file_order.value,
            "max_workers":               p.max_workers,
            "min_files_to_split":        p.min_files_to_split,
            "max_files_per_worker":      p.max_files_per_worker,
            "prewarm_footers":           p.prewarm_footers,
            "prewarm_concurrency":       p.prewarm_concurrency,
            "duckdb_threads":            p.duckdb_threads,
            "duckdb_object_cache":       p.duckdb_object_cache,
            "duckdb_http_keep_alive":    p.duckdb_http_keep_alive,
            "boto3_max_pool_connections": p.boto3_max_pool_connections,
            "wait_for_supplement":       p.wait_for_supplement,
            "rationale":                 p.rationale,
        }

    return {
        "profile":            block.get("profile", "auto"),
        "default_file_order": block.get("default_file_order", "smallest_first"),
        "profile_overrides":  block.get("profiles") or {},
        "built_in_defaults": {
            ScanProfile.BULK_SCAN.value:   _plan_to_dict(_PROFILE_DEFAULTS[ScanProfile.BULK_SCAN]),
            ScanProfile.INTERACTIVE.value: _plan_to_dict(_PROFILE_DEFAULTS[ScanProfile.INTERACTIVE]),
            ScanProfile.LOW_LATENCY.value: _plan_to_dict(_PROFILE_DEFAULTS[ScanProfile.LOW_LATENCY]),
        },
        "valid_profiles":    list(_SCAN_PROFILE_NAMES),
        "valid_file_orders": list(_SCAN_FILE_ORDER_NAMES),
    }


def _coerced_file_order(prof_name: str, v):
    """A declared file-order name, or a 400 naming the offending profile."""
    if v not in _SCAN_FILE_ORDER_NAMES:
        raise HTTPException(
            status_code=400,
            detail=f"profile_overrides.{prof_name}.file_order invalid",
        )
    return v


def _coerced_profile_int(prof_name: str, k: str, v) -> int:
    """An int-typed profile override, or a 400 naming the offending key."""
    try:
        return int(v)
    except (TypeError, ValueError):
        raise HTTPException(
            status_code=400,
            detail=f"profile_overrides.{prof_name}.{k} must be int",
        )


def _clean_profile_override_block(prof_name: str, prof_block: dict) -> Dict[str, Any]:
    """Coerce one profile's override block to its declared key types.

    Unknown keys are dropped; a value that will not coerce is a 400.
    """
    inner: Dict[str, Any] = {}
    for k, v in prof_block.items():
        if k == "file_order":
            inner[k] = _coerced_file_order(prof_name, v)
        elif k in _SCAN_PROFILE_INT_KEYS:
            inner[k] = _coerced_profile_int(prof_name, k, v)
        elif k in _SCAN_PROFILE_BOOL_KEYS:
            inner[k] = bool(v)
        else:
            # Silently drop unknown keys — keeps the API forward-
            # compatible if the UI sends extra fields.
            pass
    return inner


def _clean_profile_overrides(po) -> Dict[str, Dict[str, Any]]:
    """Validate the whole ``profile_overrides`` map before it reaches config."""
    if not isinstance(po, dict):
        raise HTTPException(status_code=400, detail="profile_overrides must be a dict")
    cleaned: Dict[str, Dict[str, Any]] = {}
    for prof_name, prof_block in po.items():
        if prof_name == "auto":
            continue   # AUTO has no overrides — it picks a profile, not a config
        if prof_name not in _SCAN_PROFILE_NAMES:
            raise HTTPException(
                status_code=400,
                detail=f"unknown profile in profile_overrides: {prof_name}",
            )
        if not isinstance(prof_block, dict):
            raise HTTPException(
                status_code=400,
                detail=f"profile_overrides.{prof_name} must be a dict",
            )
        cleaned[prof_name] = _clean_profile_override_block(prof_name, prof_block)
    return cleaned


@router.put("/api/admin/scan-strategy/config")
async def set_scan_strategy_config(body: dict, _user: dict = Depends(require_admin)):
    """Update scan-strategy admin block.

    Body shape::

        {
          "profile": "auto" | "bulk_scan" | "interactive" | "low_latency",
          "default_file_order": "manifest_order" | "largest_first" | ...,
          "profile_overrides": {
              "bulk_scan":   {"max_workers": 24, "prewarm_concurrency": 100},
              "interactive": {"prewarm_footers": true},
              "low_latency": {}
          }
        }

    Each field is optional — only the keys you send get updated.
    """
    from core import config as _cfg
    updates: Dict[str, Any] = {}

    if "profile" in body:
        if body["profile"] not in _SCAN_PROFILE_NAMES:
            raise HTTPException(
                status_code=400,
                detail=f"profile must be one of {list(_SCAN_PROFILE_NAMES)}",
            )
        updates["profile"] = body["profile"]

    if "default_file_order" in body:
        if body["default_file_order"] not in _SCAN_FILE_ORDER_NAMES:
            raise HTTPException(
                status_code=400,
                detail=f"default_file_order must be one of {list(_SCAN_FILE_ORDER_NAMES)}",
            )
        updates["default_file_order"] = body["default_file_order"]

    if "profile_overrides" in body:
        updates["profiles"] = _clean_profile_overrides(body["profile_overrides"] or {})

    if not updates:
        raise HTTPException(
            status_code=400,
            detail="no valid fields in body (expected profile / default_file_order / profile_overrides)",
        )

    for k, v in updates.items():
        _cfg.set("scan_strategy", k, v)

    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "set_scan_strategy_config",
                      resource_type="scan_strategy_config",
                      resource_id=str(list(updates.keys())))
    return {"updated": updates}


# ── Report Catalog Config (Phase 58) ─────────────────────────────────────────

@router.get("/api/admin/report-catalog/config")
async def get_report_catalog_config(_user: dict = Depends(require_admin)):
    """Return current report catalog configuration."""
    from core import config as _cfg
    rc = _cfg.report_catalog
    return {
        "enabled":                      rc.enabled,
        "certification_enabled":        rc.certification_enabled,
        "template_gallery_enabled":     rc.template_gallery_enabled,
        "sharing_enabled":              rc.sharing_enabled,
        "embed_enabled":                rc.embed_enabled,
        "max_shares_per_report":        rc.max_shares_per_report,
        "max_embed_tokens_per_report":  rc.max_embed_tokens_per_report,
        "share_default_expiry_hours":   rc.share_default_expiry_hours,
        "embed_default_expiry_days":    rc.embed_default_expiry_days,
        "template_categories":          rc.template_categories,
    }


@router.put("/api/admin/report-catalog/config")
async def set_report_catalog_config(body: dict, _user: dict = Depends(require_admin)):
    """Update report catalog configuration."""
    from core import config as _cfg
    allowed = {
        "enabled", "certification_enabled", "template_gallery_enabled",
        "sharing_enabled", "embed_enabled", "max_shares_per_report",
        "max_embed_tokens_per_report", "share_default_expiry_hours",
        "embed_default_expiry_days", "template_categories",
    }
    for k, v in body.items():
        if k in allowed:
            _cfg.set("report_catalog", k, v)
    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "update_report_catalog_config", resource_type="config",
                      resource_id="report_catalog")
    return await get_report_catalog_config(_user)


# ── Business Portal Config (Phase 59) ─────────────────────────────────────────

@router.get("/api/admin/business-portal/config")
async def get_business_portal_config(_user: dict = Depends(require_admin)):
    """Return current business portal configuration."""
    from core import config as _cfg
    bp = _cfg.business_portal
    return {
        "enabled":                    bp.enabled,
        "welcome_message":            bp.welcome_message,
        "welcome_subtitle":           bp.welcome_subtitle,
        "recent_reports_limit":       bp.recent_reports_limit,
        "favorites_limit":            bp.favorites_limit,
        "certified_templates_limit":  bp.certified_templates_limit,
        "recent_activity_limit":      bp.recent_activity_limit,
        "quick_actions_enabled":      bp.quick_actions_enabled,
        "kpi_cards_enabled":          bp.kpi_cards_enabled,
    }


@router.put("/api/admin/business-portal/config")
async def set_business_portal_config(body: dict, _user: dict = Depends(require_admin)):
    """Update business portal configuration."""
    from core import config as _cfg
    allowed = {
        "enabled", "welcome_message", "welcome_subtitle",
        "recent_reports_limit", "favorites_limit", "certified_templates_limit",
        "recent_activity_limit", "quick_actions_enabled", "kpi_cards_enabled",
    }
    for k, v in body.items():
        if k in allowed:
            _cfg.set("business_portal", k, v)
    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "update_business_portal_config", resource_type="config",
                      resource_id="business_portal")
    return await get_business_portal_config(_user)


# ── REST API Config ──────────────────────────────────────────────────────────

@router.get("/api/admin/rest-api/config")
async def get_rest_api_config(_user: dict = Depends(require_admin)):
    """Return REST API connector configuration."""
    from core import config as _cfg
    return {
        "enabled": _cfg.rest_api.enabled,
        "max_response_size_mb": _cfg.rest_api.max_response_size_mb,
        "max_rows_per_query": _cfg.rest_api.max_rows_per_query,
        "default_timeout_seconds": _cfg.rest_api.default_timeout_seconds,
        "max_timeout_seconds": _cfg.rest_api.max_timeout_seconds,
        "oauth2_token_cache_seconds": _cfg.rest_api.oauth2_token_cache_seconds,
        "flatten_max_depth": _cfg.rest_api.flatten_max_depth,
        "allow_private_ips": _cfg.rest_api.allow_private_ips,
    }


@router.put("/api/admin/rest-api/config")
async def set_rest_api_config(body: dict, _user: dict = Depends(require_admin)):
    """Update REST API connector configuration at runtime."""
    from core import config as _cfg
    allowed = {
        "enabled", "max_response_size_mb", "max_rows_per_query",
        "default_timeout_seconds", "max_timeout_seconds",
        "oauth2_token_cache_seconds", "flatten_max_depth",
        "allow_private_ips",
    }
    updates = {k: v for k, v in body.items() if k in allowed}
    if not updates:
        raise HTTPException(status_code=400, detail=f"No valid keys. Allowed: {sorted(allowed)}")
    for key, val in updates.items():
        _cfg.set("rest_api", key, val)
    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "update_rest_api_config", resource_type="config",
                      resource_id="rest_api")
    return {"updated": updates}


# ── Database Backend Status ──────────────────────────────────────────────────

def _db_status_identity(engine):
    """(backend name, display URL) with any password masked out."""
    url_str = str(engine.url)
    if _db_manager.is_postgresql:
        # Mask password: postgresql://user:***@host:port/db
        if "@" in url_str:
            prefix, suffix = url_str.split("@", 1)
            scheme_user = prefix.rsplit(":", 1)[0]
            return "postgresql", f"{scheme_user}:***@{suffix}"
        return "postgresql", url_str
    if _db_manager.is_sqlite:
        return "sqlite", url_str.replace("sqlite:///", "")
    return engine.dialect.name, "(masked)"


def _db_status_healthy(engine) -> bool:
    """Does a trivial SELECT round-trip right now?"""
    try:
        with engine.connect() as conn:
            conn.execute(__import__("sqlalchemy").text("SELECT 1"))
        return True
    except Exception as _hc_exc:
        logger.warning("Database health check failed: %s", _hc_exc)
        return False


def _db_status_read_preference() -> str:
    """Configured read routing preference; 'primary' when unreadable."""
    try:
        from core.config import database as _db_cfg
        return _db_cfg.read_preference
    except Exception as _rp_exc:
        logger.warning("Could not load read_preference config: %s", _rp_exc)
        return "primary"


@router.get("/api/admin/database/status")
async def get_database_status(_user: dict = Depends(require_admin)):
    """Return metadata about the active database backend."""
    db_type = "unknown"
    url_masked = ""
    pool_size = 0
    is_healthy = False

    if _db_manager:
        engine = _db_manager.engine
        db_type, url_masked = _db_status_identity(engine)

        pool = engine.pool
        pool_size = getattr(pool, "size", 0) if pool else 0

        # 2026-10-17 (component health, defect 5): a SELECT round trip is DB
        # I/O -- off the event loop like every other probe in this module.
        is_healthy = await asyncio.to_thread(_db_status_healthy, engine)

    # Include replica summary in status response
    replica_count = 0
    healthy_replicas = 0
    read_pref = "primary"
    if _db_manager and _db_manager.is_postgresql:
        read_pref = _db_status_read_preference()
        replicas = await _adb(_db_manager.get_replica_status)
        replica_count = len(replicas)
        healthy_replicas = sum(1 for r in replicas if r.get("healthy"))

    return {
        "type": db_type,
        "url": url_masked,
        "pool_size": pool_size,
        "is_healthy": is_healthy,
        "replica_count": replica_count,
        "healthy_replicas": healthy_replicas,
        "read_preference": read_pref,
    }


# ── Read Replica Management (Phase 43D) ─────────────────────────────────────

@router.get("/api/admin/database/replicas")
async def get_database_replicas(_user: dict = Depends(require_admin)):
    """Return replica health, primary info, and read routing preference."""
    if not _db_manager:
        raise HTTPException(status_code=503, detail="Database manager not initialised")

    # Primary engine info
    engine = _db_manager.engine
    primary_pool = engine.pool
    primary_info = {
        "type": "postgresql" if _db_manager.is_postgresql else (
            "sqlite" if _db_manager.is_sqlite else engine.dialect.name
        ),
        "pool_size": getattr(primary_pool, "size", lambda: 0)()
            if callable(getattr(primary_pool, "size", None))
            else getattr(primary_pool, "size", 0),
        "pool_checked_out": primary_pool.checkedout()
            if hasattr(primary_pool, "checkedout") else 0,
    }

    # Read preference from config
    read_pref = "primary"
    try:
        from core.config import database as _db_cfg
        read_pref = _db_cfg.read_preference
    except Exception:
        pass

    replicas = await _adb(_db_manager.get_replica_status)
    healthy_count = sum(1 for r in replicas if r.get("healthy"))

    return {
        "primary": primary_info,
        "replicas": replicas,
        "read_preference": read_pref,
        "replica_count": len(replicas),
        "healthy_count": healthy_count,
    }


@router.put("/api/admin/database/replicas/config")
async def set_database_replicas_config(body: ReplicaConfigUpdate,
                                       _user: dict = Depends(require_admin)):
    """Update read routing preference at runtime.

    Allowed values: primary, replica, primary_preferred.
    Note: changing replica_urls requires a restart — only read_preference
    is hot-reloadable.
    """
    from core import config as _cfg

    allowed_values = {"primary", "replica", "primary_preferred"}
    if body.read_preference not in allowed_values:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid read_preference '{body.read_preference}'. "
                   f"Allowed: {sorted(allowed_values)}",
        )

    _cfg.set("database", "read_preference", body.read_preference)

    username = (_user or {}).get("username", "admin")
    if _db_manager:
        await _adb(_db_manager.audit, username, "set_replica_config",
                          resource_type="database_replicas",
                          resource_id=body.read_preference)

    logger.info("Read preference updated to '%s' by %s", body.read_preference, username)
    return {"updated": {"read_preference": body.read_preference}}


# ── Horizontal Worker Management (Phase 45G) ────────────────────────────────

@router.get("/api/admin/workers")
async def list_workers(worker_type: str = None, _user: dict = Depends(require_admin)):
    """List all registered workers with health status.

    2026-09-15: carries the honest ``multi_pod`` block (state / reason /
    remedy) so an empty worker list under ``multi_pod.enabled=true`` reads
    as "inert: <why>", not as a bare fallback.  ``registry`` says whether
    the empty list means "no workers" or "could not ask" -- unknown is not
    empty.
    """
    from core.worker_registry import get_worker_registry
    from core.multi_pod_dispatcher import multi_pod_state
    _mp = await asyncio.to_thread(multi_pod_state)
    _mp_block = {k: _mp.get(k) for k in (
        "state", "configured_enabled", "pods", "strategy",
        "secret_configured", "reason", "remedy")}
    try:
        registry = get_worker_registry()
    except RuntimeError:
        return {"workers": [], "count": 0, "registry": "not_initialised",
                "message": "Worker registry not initialized",
                "multi_pod": _mp_block}
    workers = registry.list_workers(worker_type=worker_type)
    return {"workers": [w.to_dict() for w in workers], "count": len(workers),
            "registry": "ok", "multi_pod": _mp_block}


@router.get("/api/admin/workers/metrics")
async def get_worker_fleet_metrics(_user: dict = Depends(require_admin)):
    """Return fleet-wide aggregate metrics suitable for HPA decision-making."""
    from core.worker_registry import get_worker_registry
    try:
        registry = get_worker_registry()
    except RuntimeError:
        return {"total_workers": 0, "message": "Worker registry not initialized"}
    return registry.get_fleet_metrics()


@router.get("/api/admin/workers/{worker_id}/stats")
async def get_worker_stats(worker_id: str, _user: dict = Depends(require_admin)):
    """Return detailed stats for a single worker."""
    from core.worker_registry import get_worker_registry
    try:
        registry = get_worker_registry()
    except RuntimeError:
        raise HTTPException(status_code=404, detail="Worker registry not initialized")
    worker = registry.get_worker(worker_id)
    if not worker:
        raise HTTPException(status_code=404, detail=f"Worker '{worker_id}' not found")
    return worker.to_dict()


@router.post("/api/admin/workers/{worker_id}/drain")
async def drain_worker(worker_id: str, _user: dict = Depends(require_admin)):
    """Signal a worker to stop claiming new tasks (sets status to 'draining').

    The actual drain is performed by the worker reading its updated status
    on next heartbeat or via its control API.
    """
    from core.worker_registry import get_worker_registry
    try:
        registry = get_worker_registry()
    except RuntimeError:
        raise HTTPException(status_code=503, detail="Worker registry not initialized") from None
    worker = registry.get_worker(worker_id)
    if not worker:
        raise HTTPException(status_code=404, detail=f"Worker '{worker_id}' not found")
    worker.status = "draining"
    registry.heartbeat(worker_id, worker)
    if _db_manager:
        await _adb(_db_manager.audit, 
            (_user or {}).get("username", "admin"),
            "worker_drain",
            resource_type="worker",
            resource_id=worker_id,
        )
    logger.info("Worker %s set to draining by %s", worker_id, (_user or {}).get("username", "admin"))
    return {"worker_id": worker_id, "status": "draining"}


# ── Horizontal Workers Config ────────────────────────────────────────────────

@router.get("/api/admin/horizontal-workers/config")
async def get_horizontal_workers_config(_user: dict = Depends(require_admin)):
    """Return current horizontal workers configuration."""
    from core import config as _cfg
    hw = _cfg.horizontal_workers
    return {
        "registry_backend":           hw.registry_backend,
        "heartbeat_interval_seconds": hw.heartbeat_interval_seconds,
        "heartbeat_ttl_seconds":      hw.heartbeat_ttl_seconds,
        "worker_eviction_seconds":    hw.worker_eviction_seconds,
        "max_workers_per_host":       hw.max_workers_per_host,
        "enable_load_aware_claiming": hw.enable_load_aware_claiming,
        "memory_threshold_pct":       hw.memory_threshold_pct,
        "cpu_threshold_pct":          hw.cpu_threshold_pct,
        "metrics_retention_hours":    hw.metrics_retention_hours,
    }


@router.put("/api/admin/horizontal-workers/config")
async def set_horizontal_workers_config(body: HorizontalWorkersConfigUpdate,
                                        _user: dict = Depends(require_admin)):
    """Update horizontal workers configuration at runtime."""
    from core import config as _cfg
    allowed = {
        "registry_backend", "heartbeat_interval_seconds", "heartbeat_ttl_seconds",
        "worker_eviction_seconds", "max_workers_per_host", "enable_load_aware_claiming",
        "memory_threshold_pct", "cpu_threshold_pct", "metrics_retention_hours",
    }
    updates = body.model_dump(exclude_none=True)
    if not updates:
        raise HTTPException(status_code=400, detail=f"No valid keys. Allowed: {sorted(allowed)}")
    for key, val in updates.items():
        if key in allowed:
            _cfg.set("horizontal_workers", key, val)
    username = (_user or {}).get("username", "admin")
    if _db_manager:
        await _adb(_db_manager.audit, username, "update_horizontal_workers_config",
                          resource_type="config", resource_id="horizontal_workers")
    logger.info("Horizontal workers config updated by %s: %s", username, list(updates.keys()))
    return await get_horizontal_workers_config(_user)


# ═══════════════════════════════════════════════════════════════════════════
# Streaming config (Phase 72)
# ═══════════════════════════════════════════════════════════════════════════

@router.get("/api/admin/streaming/config")
async def get_streaming_config(_user: dict = Depends(require_admin)):
    """Return current streaming configuration."""
    from core import config as _cfg
    s = _cfg.streaming
    from api.execute_stream_api import get_active_stream_count
    return {
        "cancel_enabled":             s.cancel_enabled,
        "max_active_streams":         s.max_active_streams,
        "cancel_check_interval_rows": s.cancel_check_interval_rows,
        "active_streams":             get_active_stream_count(),
    }


@router.put("/api/admin/streaming/config")
async def set_streaming_config(body: StreamingConfigUpdate,
                               _user: dict = Depends(require_admin)):
    """Update streaming configuration at runtime."""
    from core import config as _cfg
    allowed = {"cancel_enabled", "max_active_streams", "cancel_check_interval_rows"}
    updates = body.model_dump(exclude_none=True)
    if not updates:
        raise HTTPException(status_code=400, detail=f"No valid keys. Allowed: {sorted(allowed)}")
    for key, val in updates.items():
        if key in allowed:
            _cfg.set("streaming", key, val)
    username = (_user or {}).get("username", "admin")
    if _db_manager:
        await _adb(_db_manager.audit, username, "update_streaming_config",
                          resource_type="config", resource_id="streaming")
    logger.info("Streaming config updated by %s: %s", username, list(updates.keys()))
    return await get_streaming_config(_user)


# ═══════════════════════════════════════════════════════════════════════════
# Pre-signed URL config (Phase 74)
# ═══════════════════════════════════════════════════════════════════════════

@router.get("/api/admin/presigned-url/config")
async def get_presigned_url_config(_user: dict = Depends(require_admin)):
    """Return current pre-signed URL configuration."""
    from core import config as _cfg
    p = _cfg.presigned_url
    return {
        "expiry_seconds":           p.expiry_seconds,
        "retry_enabled":            p.retry_enabled,
        "max_retries":              p.max_retries,
        "retry_on_403":             p.retry_on_403,
        "retry_delay_seconds":      p.retry_delay_seconds,
        "download_timeout_seconds": p.download_timeout_seconds,
    }


@router.put("/api/admin/presigned-url/config")
async def set_presigned_url_config(body: PresignedUrlConfigUpdate,
                                   _user: dict = Depends(require_admin)):
    """Update pre-signed URL configuration at runtime."""
    from core import config as _cfg
    allowed = {
        "expiry_seconds", "retry_enabled", "max_retries", "retry_on_403",
        "retry_delay_seconds", "download_timeout_seconds",
    }
    updates = body.model_dump(exclude_none=True)
    if not updates:
        raise HTTPException(status_code=400, detail=f"No valid keys. Allowed: {sorted(allowed)}")
    for key, val in updates.items():
        if key in allowed:
            _cfg.set("presigned_url", key, val)
    username = (_user or {}).get("username", "admin")
    if _db_manager:
        await _adb(_db_manager.audit, username, "update_presigned_url_config",
                          resource_type="config", resource_id="presigned_url")
    logger.info("Pre-signed URL config updated by %s: %s", username, list(updates.keys()))
    return await get_presigned_url_config(_user)


# ── Phase 75: Published Views Config ─────────────────────────────────────────

@router.get("/api/admin/published-views/config")
async def get_published_views_config(_user: dict = Depends(require_admin)):
    """Return current published views configuration."""
    from core import config as _cfg
    p = _cfg.published_views
    return {
        "enabled":                   p.enabled,
        "max_concurrent":            p.max_concurrent,
        "default_cache_ttl_seconds": p.default_cache_ttl_seconds,
        "max_cache_size_mb":         p.max_cache_size_mb,
        "cache_dir":                 p.cache_dir,
        "default_rate_limit":        p.default_rate_limit,
        "max_rate_limit":            p.max_rate_limit,
        "default_row_limit":         p.default_row_limit,
        "max_row_limit":             p.max_row_limit,
        "api_key_prefix":            p.api_key_prefix,
        "access_log_retention_days":  p.access_log_retention_days,
        "cleanup_interval_hours":     p.cleanup_interval_hours,
        "param_substitution_enabled": p.param_substitution_enabled,
        "dedup_timeout_seconds":      p.dedup_timeout_seconds,
    }


@router.put("/api/admin/published-views/config")
async def set_published_views_config(body: PublishedViewsConfigUpdate,
                                     _user: dict = Depends(require_admin)):
    """Update published views configuration at runtime."""
    from core import config as _cfg
    allowed = {
        "enabled", "max_concurrent", "default_cache_ttl_seconds", "max_cache_size_mb",
        "default_rate_limit", "max_rate_limit", "default_row_limit", "max_row_limit",
        "access_log_retention_days", "cleanup_interval_hours",
        "param_substitution_enabled", "dedup_timeout_seconds",
    }
    updates = body.model_dump(exclude_none=True)
    if not updates:
        raise HTTPException(status_code=400, detail=f"No valid keys. Allowed: {sorted(allowed)}")
    for key, val in updates.items():
        if key in allowed:
            _cfg.set("published_views", key, val)
    username = (_user or {}).get("username", "admin")
    if _db_manager:
        await _adb(_db_manager.audit, username, "update_published_views_config",
                          resource_type="config", resource_id="published_views")
    logger.info("Published views config updated by %s: %s", username, list(updates.keys()))
    return await get_published_views_config(_user)


@router.get("/api/admin/published-views/kafka-status")
async def admin_kafka_status(_user: dict = Depends(require_admin)):
    """Phase 98-I: Return Kafka consumer connection status and config."""
    try:
        from core.kafka_cache_consumer import get_status
        return get_status()
    except ImportError:
        return {"enabled": False, "kafka_available": False, "consumer_running": False}


@router.post("/api/admin/published-views/{view_id}/invalidate-cache")
async def admin_invalidate_published_view_cache(
    view_id: int,
    _user: dict = Depends(require_admin),
):
    """Phase 98-G: Force-invalidate all cached results for a published view."""
    if not _db_manager:
        raise HTTPException(503, "DB not available")
    pv = await _adb(_db_manager.get_published_view, view_id)
    if not pv:
        raise HTTPException(404, "View not found")
    try:
        from api.published_views_api import _clear_view_cache
        deleted = _clear_view_cache(view_id)
    except ImportError:
        deleted = 0
    username = (_user or {}).get("username", "admin")
    logger.info("Admin %s manually invalidated cache for view %d (%s) — %d files deleted",
                username, view_id, pv.get("slug"), deleted)
    return {"view_id": view_id, "slug": pv.get("slug"), "files_deleted": deleted, "status": "invalidated"}


# ── Phase 76: Feed Generation Config ─────────────────────────────────────────

@router.get("/api/admin/feed-generation/config")
async def get_feed_generation_config(_user: dict = Depends(require_admin)):
    """Return current feed generation configuration."""
    from core import config as _cfg
    fg = _cfg.feed_generation
    return {
        "enabled":                          fg.enabled,
        "max_concurrent_native":            fg.max_concurrent_native,
        "output_dir":                       fg.output_dir,
        "max_output_rows":                  fg.max_output_rows,
        "max_file_size_mb":                 fg.max_file_size_mb,
        "max_file_size_action":             fg.max_file_size_action,
        "default_output_format":            fg.default_output_format,
        "filename_template":                fg.filename_template,
        "auto_route_threshold_rows":        fg.auto_route_threshold_rows,
        "retry_max_attempts":               fg.retry_max_attempts,
        "retry_delay_seconds":              fg.retry_delay_seconds,
        "execution_history_retention_days": fg.execution_history_retention_days,
        "cleanup_interval_hours":           fg.cleanup_interval_hours,
        "chunk_size":                       fg.chunk_size,
        "airflow_enabled":                  fg.airflow_enabled,
    }


@router.put("/api/admin/feed-generation/config")
async def set_feed_generation_config(body: FeedGenerationConfigUpdate,
                                     _user: dict = Depends(require_admin)):
    """Update feed generation configuration at runtime."""
    from core import config as _cfg
    allowed = {
        "enabled", "max_concurrent_native", "max_output_rows", "max_file_size_mb",
        "max_file_size_action",
        "default_output_format", "filename_template", "auto_route_threshold_rows",
        "retry_max_attempts", "retry_delay_seconds", "execution_history_retention_days",
        "cleanup_interval_hours", "chunk_size",
    }
    updates = body.model_dump(exclude_none=True)
    if not updates:
        raise HTTPException(status_code=400, detail=f"No valid keys. Allowed: {sorted(allowed)}")
    if updates.get("execution_history_retention_days", 0) < 0:
        raise HTTPException(status_code=422, detail="execution_history_retention_days must be 0 "
                                                    "(keep forever) or a number of days")
    # each key's before / after is audited by config.set itself (2026-10-13)
    for key, val in updates.items():
        if key in allowed:
            _cfg.set("feed_generation", key, val)
    username = (_user or {}).get("username", "admin")
    if _db_manager:
        await _adb(_db_manager.audit, username, "update_feed_generation_config",
                          resource_type="config", resource_id="feed_generation")
    logger.info("Feed generation config updated by %s: %s", username, list(updates.keys()))
    return await get_feed_generation_config(_user)


@router.get("/api/admin/feed-generation/backends")
async def get_feed_backends(_user: dict = Depends(require_admin_read)):
    """Return circuit breaker status for all feed execution backends."""
    from core.feed_engine import get_backend_status
    return get_backend_status()


@router.post("/api/admin/feed-generation/backends/{name}/reset")
async def reset_feed_backend(name: str, _user: dict = Depends(require_admin)):
    """Reset circuit breaker for a named feed backend."""
    from core.feed_engine import reset_backend_breaker
    ok = reset_backend_breaker(name)
    if not ok:
        raise HTTPException(status_code=404, detail=f"Backend '{name}' not found")
    username = (_user or {}).get("username", "admin")
    logger.info("Feed backend '%s' circuit breaker reset by %s", name, username)
    return {"detail": f"Circuit breaker for '{name}' reset", "backend": name}


# ── Phase 130 hotfix-13: Backend failover (admin-tunable, DB-driven) ─────────

_VALID_OVERRIDES = {"auto", "native_only", "airflow_only", "halt"}
_OVERRIDE_KEY = "feed_generation.backend_override"
_FAILOVER_TUNABLES = {
    # key in system_settings -> python type (used for runtime coercion)
    # Every hotfix-13 runtime knob lives here so the admin UI can flip
    # any of them WITHOUT a code change OR pod restart.  Adding a new
    # admin-tunable value? Add it here so the UI exposes it.
    "feed_generation.airflow_failover_to_native":           bool,
    "feed_generation.failover_agent_enabled":               bool,
    "feed_generation.failover_agent_interval_seconds":      int,
    "feed_generation.failover_agent_unhealthy_streak_required": int,
    "feed_generation.failover_agent_healthy_streak_required":   int,
    "feed_generation.native_worker_stale_after_seconds":    int,
    # Dedicated worker pod toggle — when true, scheduler/API pods skip
    # in-process queue worker and expect a feed_worker.py pod.
    "feed_generation.worker_pod_only":                      bool,
    # Stale-running reclamation (shard pod failure rescue).
    "feed_generation.stale_running_reclaim_seconds":        int,
    "feed_generation.stale_running_reclaim_interval_seconds": int,
    # Support-role rename so orgs can match their internal conventions.
    "roles.support_role_name":                              str,

    # ── Phase 131-A — ETL dependency check ───────────────────────────
    "feed_generation.etl_dep_check_enabled":                bool,
    "feed_generation.etl_dep_check_interval_seconds":       int,
    "feed_generation.etl_dep_sla_hours":                    float,
    "feed_generation.etl_dep_check_leader_only":            bool,

    # ── Phase 131-B — Row-count threshold defaults ───────────────────
    "feed_generation.row_count_threshold_pct_default":      float,
    "feed_generation.row_count_min_samples":                int,
    "feed_generation.row_count_window_days":                int,
    "feed_generation.row_count_baseline_cron":              str,

    # ── Phase 131-C — File integrity check ───────────────────────────
    "feed_generation.integrity_check_enabled":              bool,
    "feed_generation.integrity_check_action":               str,    # 'warn' | 'fail'
    "feed_generation.integrity_check_post_delivery":        bool,
    "feed_generation.integrity_csv_line_tolerance":         int,

    # ── Path-safety roots for local delivery (Phase 131 hotfix-1) ─────
    # JSON array of absolute paths; values OUTSIDE _cfg.output_dir
    # require this list to permit them.  Always includes _cfg.output_dir
    # implicitly so the default-config install never trips on its own
    # data/feeds directory.
    "feed_generation.local_destination_allowed_roots":      list,
}


class FeedBackendOverrideUpdate(BaseModel):
    value: str  # 'auto' | 'native_only' | 'airflow_only' | 'halt'


class FeedFailoverTunableUpdate(BaseModel):
    key:   str
    value: Any


@router.get("/api/admin/feed-generation/backend-override")
async def get_feed_backend_override(_user: dict = Depends(require_admin_read)):
    """Return the current global backend override + persisted-row metadata
    so the admin UI can show 'last changed by X at Y'."""
    from core.config import feed_generation as _fg
    meta = None
    if _db_manager:
        try:
            meta = _db_manager.get_system_setting_meta(_OVERRIDE_KEY)
        except Exception:
            meta = None
    return {
        "value": str(_fg.backend_override),
        "valid_values": sorted(_VALID_OVERRIDES),
        "persisted": meta,  # None when never set via the UI (config.json default in use)
    }


@router.post("/api/admin/feed-generation/backend-override")
async def set_feed_backend_override(body: FeedBackendOverrideUpdate,
                                     _user: dict = Depends(require_admin)):
    """Set the global feed backend override.  Takes effect immediately
    on this pod (cache invalidation) and on all other pods on the next
    settings-cache TTL (5 s)."""
    value = (body.value or "").lower()
    if value not in _VALID_OVERRIDES:
        raise HTTPException(status_code=400,
                              detail=f"value must be one of {sorted(_VALID_OVERRIDES)}; got {body.value!r}")
    if not _db_manager:
        raise HTTPException(status_code=503, detail="DB manager not available")
    username = (_user or {}).get("username", "admin")
    persisted = _db_manager.set_system_setting(
        _OVERRIDE_KEY, value,
        updated_by=username,
        description="Global feed backend override",
    )
    try:
        from core import config as _cfg_mod
        _cfg_mod.invalidate_db_setting_cache(_OVERRIDE_KEY)
    except Exception:
        pass
    try:
        await _adb(_db_manager.audit, username, "feed_backend_override_set",
                    resource_type="config", resource_id=_OVERRIDE_KEY,
                    extra={"to": value})
    except Exception:
        pass
    logger.info("Feed backend override set to %r by %s", value, username)
    return {"value": value, "persisted": persisted}


@router.get("/api/admin/feed-generation/failover-tunables")
async def get_feed_failover_tunables(_user: dict = Depends(require_admin_read)):
    """List all DB-overridable failover knobs with their current values.
    The frontend renders these as inputs so every threshold is admin-
    tunable — no constants in code."""
    from core.config import feed_generation as _fg
    out = []
    for key, _type in _FAILOVER_TUNABLES.items():
        meta = None
        if _db_manager:
            try:
                meta = _db_manager.get_system_setting_meta(key)
            except Exception:
                meta = None
        # Effective value (DB override OR config.json)
        leaf = key.split(".", 1)[1]
        effective = getattr(_fg, leaf, None)
        out.append({
            "key": key,
            "type": _type.__name__,
            "effective_value": effective,
            "persisted": meta,
        })
    return {"items": out}


def _coerce_failover_value(type_fn, raw):
    """Coerce a failover tunable to its declared type, raising on a bad value.

    Special-cases list-of-strings (e.g. local_destination_allowed_roots) —
    accepts a JSON-array string OR an already-decoded list from the UI.
    """
    if type_fn is not list:
        return type_fn(raw)
    v = raw
    if isinstance(v, str):
        import json as _json
        v = _json.loads(v)
    if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
        raise ValueError("value must be a JSON array of strings")
    return v


@router.put("/api/admin/feed-generation/failover-tunables")
async def set_feed_failover_tunable(body: FeedFailoverTunableUpdate,
                                      _user: dict = Depends(require_admin)):
    """Persist one failover tunable.  Whitelisted keys only."""
    if body.key not in _FAILOVER_TUNABLES:
        raise HTTPException(status_code=400,
                              detail=f"key must be one of {sorted(_FAILOVER_TUNABLES.keys())}; got {body.key!r}")
    if not _db_manager:
        raise HTTPException(status_code=503, detail="DB manager not available")
    type_fn = _FAILOVER_TUNABLES[body.key]
    try:
        coerced = _coerce_failover_value(type_fn, body.value)
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=400,
                              detail=f"value cannot be coerced to {type_fn.__name__}: {exc}")
    username = (_user or {}).get("username", "admin")
    persisted = _db_manager.set_system_setting(
        body.key, coerced, updated_by=username,
        description="Feed failover tunable",
    )
    try:
        from core import config as _cfg_mod
        _cfg_mod.invalidate_db_setting_cache(body.key)
    except Exception:
        pass
    try:
        await _adb(_db_manager.audit, username, "feed_failover_tunable_set",
                    resource_type="config", resource_id=body.key,
                    extra={"to": coerced})
    except Exception:
        pass
    return {"key": body.key, "value": coerced, "persisted": persisted}


@router.get("/api/admin/feed-generation/health")
async def get_feed_backend_health(_user: dict = Depends(require_admin_read)):
    """Combined health snapshot for the admin UI failover panel:
    backend probes (airflow + native worker) + breaker states +
    failover agent streaks + current override."""
    from core.feed.health import probe_all
    from core.config import feed_generation as _fg
    from core.daemon_snapshots import daemon_snapshot
    snapshot = {
        "checked_at": datetime.now(timezone.utc).isoformat(),
        "override": {
            "value": str(_fg.backend_override),
            "airflow_failover_to_native": bool(_fg.airflow_failover_to_native),
        },
        # The native probe reads the durable fleet table (worker_health_state).
        "probes": await asyncio.to_thread(probe_all, _fg),
    }
    # 2026-10-07 -- the breakers and the failover agent's streaks live in the
    # memory of the process that runs feeds and the agent tick (the scheduler
    # worker in external mode); the API pod's copies are always fresh/empty.
    _ff = await daemon_snapshot("feed_failover.state",
                                proxy=_scheduler_worker_proxy)
    snapshot["circuit_breakers"] = (_ff["data"] or {}).get("circuit_breakers")
    snapshot["agent"] = (_ff["data"] or {}).get("agent")
    snapshot["breakers_and_agent_answered_by"] = _ff["answered_by"]
    if _ff.get("warning"):
        snapshot["warning"] = _ff["warning"]
    return snapshot


# ── Phase 131-A: ETL Dependencies admin API ──────────────────────────────

class EtlDependencyTypeUpsert(BaseModel):
    dependency_type: str
    description:     Optional[str] = None
    server:          Optional[str] = None
    param_value:     Optional[str] = None
    is_active:       bool = True


class EtlDependencyMappingCreate(BaseModel):
    etl_id:             int
    dependency_type_id: int
    dependency_key:     str
    description:        Optional[str] = None
    is_active:          bool = True


class EtlDependencyTrackingUpsert(BaseModel):
    dependency_type_id: int
    dependency_key:     str
    business_date:      str  # YYYY-MM-DD
    action:             str  # COMPLETE | SKIP | PENDING | RESET
    comments:           Optional[str] = None


@router.get("/api/admin/etl-dependencies/types")
async def list_etl_dep_types(_user: dict = Depends(require_admin_read)):
    if not _db_manager:
        raise HTTPException(status_code=503, detail="DB manager not available")
    return {"items": _db_manager.list_etl_dependency_types(is_active=None)}


@router.post("/api/admin/etl-dependencies/types")
async def upsert_etl_dep_type(body: EtlDependencyTypeUpsert,
                                _user: dict = Depends(require_admin)):
    if not _db_manager:
        raise HTTPException(status_code=503, detail="DB manager not available")
    row = _db_manager.upsert_etl_dependency_type(body.model_dump())
    return row


@router.get("/api/admin/etl-dependencies/mappings/{etl_id}")
async def list_etl_dep_mappings(etl_id: int,
                                  _user: dict = Depends(require_admin_read)):
    if not _db_manager:
        raise HTTPException(status_code=503, detail="DB manager not available")
    return {"items": _db_manager.list_etl_dependency_mappings(etl_id)}


@router.post("/api/admin/etl-dependencies/mappings")
async def create_etl_dep_mapping(body: EtlDependencyMappingCreate,
                                   _user: dict = Depends(require_admin)):
    if not _db_manager:
        raise HTTPException(status_code=503, detail="DB manager not available")
    return _db_manager.create_etl_dependency_mapping(body.model_dump())


@router.delete("/api/admin/etl-dependencies/mappings/{mapping_id}")
async def delete_etl_dep_mapping(mapping_id: int,
                                   _user: dict = Depends(require_admin)):
    if not _db_manager:
        raise HTTPException(status_code=503, detail="DB manager not available")
    if not _db_manager.delete_etl_dependency_mapping(mapping_id):
        raise HTTPException(status_code=404, detail="mapping not found")
    return {"ok": True}


@router.post("/api/admin/etl-dependencies/tracking")
async def record_etl_dep_tracking(body: EtlDependencyTrackingUpsert,
                                    _user: dict = Depends(require_admin)):
    """Operator-facing endpoint for recording a dependency arrival
    manually.  The production path is an external Kafka consumer
    writing directly to etl_dependency_tracking — this endpoint is for
    ops to backfill / RESET / SKIP individual rows during incidents."""
    if not _db_manager:
        raise HTTPException(status_code=503, detail="DB manager not available")
    from datetime import date as _date
    try:
        biz = _date.fromisoformat(body.business_date)
    except ValueError:
        raise HTTPException(status_code=400, detail="business_date must be YYYY-MM-DD")
    valid = {"COMPLETE", "SKIP", "PENDING", "RESET"}
    if body.action.upper() not in valid:
        raise HTTPException(status_code=400,
                              detail=f"action must be one of {sorted(valid)}")
    return _db_manager.record_etl_dependency_tracking(
        dependency_type_id=body.dependency_type_id,
        dependency_key=body.dependency_key,
        business_date=biz,
        action=body.action.upper(),
        comments=body.comments,
    )


@router.get("/api/admin/etl-dependencies/poll-status")
async def get_etl_dep_poll_status(_user: dict = Depends(require_admin_read)):
    """One-shot inspector — list the pending feed_runs the dependency
    gate governs (feeds with active mappings under their EFFECTIVE
    etl_id, feeds with an explicit etl_id, and runs already held at
    WAIT) and whether each is currently RUN-ready or WAIT-ing.  Each
    row's ``etl_id`` is the effective key.  Useful when triaging a
    stalled feed."""
    if not _db_manager:
        raise HTTPException(status_code=503, detail="DB manager not available")
    rows = _db_manager.list_pending_runs_needing_dep_check(limit=200)
    return {"items": rows, "count": len(rows)}


# ── Phase 77: Smart Predictions config ────────────────────────────────────────

@router.get("/api/admin/smart-predictions/config")
async def get_smart_predictions_config(_user: dict = Depends(require_admin)):
    """Return current smart predictions configuration."""
    from core import config as _cfg
    sp = _cfg.smart_predictions
    return {
        "enabled":                sp.enabled,
        "max_chart_suggestions":  sp.max_chart_suggestions,
        "max_pivot_suggestions":  sp.max_pivot_suggestions,
        "profile_max_top_values": sp.profile_max_top_values,
        "outlier_method":         sp.outlier_method,
        "outlier_iqr_multiplier": sp.outlier_iqr_multiplier,
        "profile_sample_limit":   sp.profile_sample_limit,
        "inline_chart_enabled":   sp.inline_chart_enabled,
    }


@router.put("/api/admin/smart-predictions/config")
async def set_smart_predictions_config(body: SmartPredictionsConfigUpdate,
                                       _user: dict = Depends(require_admin)):
    """Update smart predictions configuration at runtime."""
    from core import config as _cfg
    allowed = {
        "enabled", "max_chart_suggestions", "max_pivot_suggestions",
        "profile_max_top_values", "outlier_method", "outlier_iqr_multiplier",
        "profile_sample_limit", "inline_chart_enabled",
    }
    updates = body.model_dump(exclude_none=True)
    if not updates:
        raise HTTPException(status_code=400, detail=f"No valid keys. Allowed: {sorted(allowed)}")
    for key, val in updates.items():
        if key in allowed:
            _cfg.set("smart_predictions", key, val)
    username = (_user or {}).get("username", "admin")
    if _db_manager:
        await _adb(_db_manager.audit, username, "update_smart_predictions_config",
                          resource_type="config", resource_id="smart_predictions")
    logger.info("Smart predictions config updated by %s: %s", username, list(updates.keys()))
    return await get_smart_predictions_config(_user)


# ── Phase 78: S3 Validation Config ───────────────────────────────────────────

@router.get("/api/admin/s3-validation/config")
async def get_s3_validation_config(_user: dict = Depends(require_admin)):
    """Return current S3 validation configuration (Phase 78)."""
    from core import config as _cfg
    sv = _cfg.s3_validation
    return {
        "bucket_name_regex_aws":                   sv.bucket_name_regex_aws,
        "bucket_name_regex_onprem":                sv.bucket_name_regex_onprem,
        "validate_bucket_on_create":               sv.validate_bucket_on_create,
        "validate_arn_format":                     sv.validate_arn_format,
        "arn_regex":                               sv.arn_regex,
        "root_prefix_test_on_create":              sv.root_prefix_test_on_create,
        "warn_unsupported_partition_ops":          sv.warn_unsupported_partition_ops,
        "max_folder_browser_items":                sv.max_folder_browser_items,
        "partition_refresh_mutex_timeout_seconds": sv.partition_refresh_mutex_timeout_seconds,
        "file_list_max_files":                     sv.file_list_max_files,
    }


@router.put("/api/admin/s3-validation/config")
async def set_s3_validation_config(body: S3ValidationConfigUpdate,
                                   _user: dict = Depends(require_admin)):
    """Update S3 validation configuration at runtime (Phase 78)."""
    from core import config as _cfg
    allowed = {
        "bucket_name_regex_aws", "bucket_name_regex_onprem",
        "validate_bucket_on_create", "validate_arn_format", "arn_regex",
        "root_prefix_test_on_create", "warn_unsupported_partition_ops",
        "max_folder_browser_items", "partition_refresh_mutex_timeout_seconds",
        "file_list_max_files",
    }
    updates = body.model_dump(exclude_none=True)
    if not updates:
        raise HTTPException(status_code=400, detail=f"No valid keys. Allowed: {sorted(allowed)}")
    for key, val in updates.items():
        if key in allowed:
            _cfg.set("s3_validation", key, val)
    username = (_user or {}).get("username", "admin")
    if _db_manager:
        await _adb(_db_manager.audit, username, "update_s3_validation_config",
                          resource_type="config", resource_id="s3_validation")
    logger.info("S3 validation config updated by %s: %s", username, list(updates.keys()))
    return await get_s3_validation_config(_user)


# ── Phase 78: S3 Health + Partition Cache Management ─────────────────────────

@router.get("/api/admin/s3/health")
async def get_s3_health(_user: dict = Depends(require_admin)):
    """S3 health: is any S3 connection's circuit breaker OPEN, the per-
    connection breaker states, partition-cache counts, and the live
    s3_validation config (Phase 78).

    FB-30 (2026-09-19): this endpoint could not run.  It read
    ``core.circuit_breaker.get_circuit_states()`` -- a LIST -- and called
    ``.items()`` on it, so every call was ``500 "Internal server error:
    AttributeError"``.  Its premise was wrong too: S3 connections never had
    "negative ids" in the SQL breaker registry; S3 has its own breaker
    (``core.s3_circuit_breaker``, Phase 134-G6) and that is what is
    reported now.  A health endpoint answers its own question: ``healthy``
    with a ``reason`` when it is not -- and a partition-cache count that
    could not be READ is reported as unknown with the error, never as 0
    (unknown != empty).
    """
    from core.s3_circuit_breaker import get_s3_circuit_breaker

    states = get_s3_circuit_breaker().get_all_states()   # {conn_id: {state,...}}
    open_ids = sorted(cid for cid, st in states.items() if st.get("state") == "open")
    half_open_ids = sorted(cid for cid, st in states.items() if st.get("state") == "half_open")

    async def _count(level: str):
        if not _db_manager:
            return None, "no database manager on this pod"
        try:
            return await _adb(_db_manager.count_partition_cache_entries, level=level), None
        except Exception as exc:                        # noqa: BLE001
            logger.warning("s3/health: partition cache %s count failed: %s", level, exc)
            return None, f"could not be read: {type(exc).__name__}"

    l1_count, l1_err = await _count("l1")
    l2_count, l2_err = await _count("l2")

    healthy = not open_ids
    if healthy:
        reason = None
    else:
        _cool = {st.get("cooldown_seconds") for cid, st in states.items() if cid in open_ids}
        reason = (f"{len(open_ids)} S3 connection(s) have an OPEN circuit breaker "
                  f"(connection ids {', '.join(open_ids)}): S3 calls against them "
                  f"fast-fail until the cooldown ({', '.join(str(c) for c in sorted(_cool, key=str))}s) "
                  f"elapses and a probe succeeds.  Reset via "
                  f"POST /api/admin/s3-performance/clear-cache "
                  f'{{"target": "circuit_breaker"}} or wait it out.')
    return {
        "healthy": healthy,
        "reason": reason,
        "open_connection_ids": open_ids,
        "half_open_connection_ids": half_open_ids,
        "circuit_breakers": states,
        "partition_cache": {
            "l1_entries": l1_count,
            "l1_error": l1_err,
            "l2_entries": l2_count,
            "l2_error": l2_err,
        },
        "s3_validation_config": await get_s3_validation_config(_user),
    }


@router.post("/api/admin/partition-cache/clear/{connection_id}")
async def clear_partition_cache(connection_id: int,
                                _user: dict = Depends(require_admin)):
    """Clear L1 and L2 partition cache for a specific connection (Phase 78)."""
    cleared_l1 = 0
    cleared_l2 = 0
    if _db_manager:
        try:
            cleared_l2 = await _adb(_db_manager.delete_partition_cache_for_connection, connection_id)
        except Exception as exc:
            logger.warning("Failed to clear L2 partition cache for conn %d: %s", connection_id, exc)

    # Clear L1 (in-memory cache in connections_api.py)
    try:
        from api.connections_api import _partition_cache
        keys_to_del = [k for k in _partition_cache.keys() if f":{connection_id}:" in k or k.startswith(f"{connection_id}:")]
        for k in keys_to_del:
            _partition_cache.delete(k)
            cleared_l1 += 1
    except Exception as exc:
        logger.warning("Failed to clear L1 partition cache for conn %d: %s", connection_id, exc)

    username = (_user or {}).get("username", "admin")
    if _db_manager:
        await _adb(_db_manager.audit, username, "clear_partition_cache",
                          resource_type="connection", resource_id=str(connection_id))
    logger.info("Partition cache cleared for connection %d by %s: l1=%d l2=%d",
                connection_id, username, cleared_l1, cleared_l2)
    return {"cleared_l1": cleared_l1, "cleared_l2": cleared_l2, "connection_id": connection_id}


# ── Phase 79: DuckDB Resilience Config ───────────────────────────────────────

@router.get("/api/admin/duckdb/config")
async def get_duckdb_config(_user: dict = Depends(require_admin)):
    """Return current DuckDB engine resilience configuration (Phase 79)."""
    from core import config as _cfg
    dc = _cfg.duckdb_cfg
    return {
        "circuit_breaker_enabled": dc.circuit_breaker_enabled,
        "retry_on_engine_error":   dc.retry_on_engine_error,
        "retry_max_attempts":      dc.retry_max_attempts,
        "retry_delay_seconds":     dc.retry_delay_seconds,
    }


@router.put("/api/admin/duckdb/config")
async def set_duckdb_config(body: DuckDBConfigUpdate,
                            _user: dict = Depends(require_admin)):
    """Update DuckDB engine resilience configuration at runtime (Phase 79)."""
    from core import config as _cfg
    allowed = {
        "circuit_breaker_enabled": body.circuit_breaker_enabled,
        "retry_on_engine_error":   body.retry_on_engine_error,
        "retry_max_attempts":      body.retry_max_attempts,
        "retry_delay_seconds":     body.retry_delay_seconds,
    }
    updated = {}
    for k, v in allowed.items():
        if v is not None:
            _cfg.set("duckdb", k, v)
            updated[k] = v
    username = (_user or {}).get("username", "admin")
    if _db_manager:
        await _adb(_db_manager.audit, username, "update_duckdb_config", resource_type="config")
    logger.info("DuckDB config updated by %s: %s", username, updated)
    return {"updated": updated, **await get_duckdb_config(_user)}


# ── Phase 96: Query Guardrails Config ─────────────────────────────────────────

@router.get("/api/admin/query-guardrails/config")
async def get_query_guardrails_config(_user: dict = Depends(require_admin)):
    """Return current query builder guardrail configuration (Phase 96)."""
    from core import config as _cfg
    qg = _cfg.query_guardrails
    return {
        "enabled":                  qg.enabled,
        "max_files_warn":           qg.max_files_warn,
        "max_files_block":          qg.max_files_block,
        "max_rows_warn":            qg.max_rows_warn,
        "max_rows_block":           qg.max_rows_block,
        "require_partition_filter": qg.require_partition_filter,
        "warn_no_partition":        qg.warn_no_partition,
        "warn_no_limit":            qg.warn_no_limit,
        "default_limit_suggestion": qg.default_limit_suggestion,
    }


@router.put("/api/admin/query-guardrails/config")
async def set_query_guardrails_config(body: QueryGuardrailsConfigUpdate,
                                       _user: dict = Depends(require_admin)):
    """Update query builder guardrail configuration at runtime (Phase 96)."""
    from core import config as _cfg
    allowed = {
        "enabled":                  body.enabled,
        "max_files_warn":           body.max_files_warn,
        "max_files_block":          body.max_files_block,
        "max_rows_warn":            body.max_rows_warn,
        "max_rows_block":           body.max_rows_block,
        "require_partition_filter": body.require_partition_filter,
        "warn_no_partition":        body.warn_no_partition,
        "warn_no_limit":            body.warn_no_limit,
        "default_limit_suggestion": body.default_limit_suggestion,
    }
    updated = {}
    for k, v in allowed.items():
        if v is not None:
            _cfg.set("query_guardrails", k, v)
            updated[k] = v
    username = (_user or {}).get("username", "admin")
    if _db_manager:
        await _adb(_db_manager.audit, username, "update_query_guardrails_config", resource_type="config")
    logger.info("Query guardrails config updated by %s: %s", username, updated)
    return {"updated": updated, **await get_query_guardrails_config(_user)}


# ── Phase 87: System Account Management ──────────────────────────────────────

class SystemAccountCreate(BaseModel):
    name: str
    # Phase 154 (2026-06-25) -- expanded set: db_account / ad_account /
    # s3_keys join the existing aws_portal + snowflake_sso so operators
    # can register vault-backed creds for Trino / Snowflake / Oracle /
    # Databricks / Athena / direct S3 keys via the same UI.
    account_type: str = Field(
        ...,
        pattern="^(aws_portal|snowflake_sso|db_account|ad_account|s3_keys|sftp_account|snowflake_keypair)$",
    )
    # 2026-10-03: ``snowflake_keypair`` -- a Snowflake KEY-PAIR login whose
    # private key lives in a vault kv_secrets entry ({username, private_key
    # [, private_key_passphrase]}; core.connectors.get_connector accepts the
    # aliases), attached to a Snowflake connection as system_account_id so
    # nobody pastes the key into the connection.  Vault-only (validator).
    # AQD-11 (2026-09-23): ``sftp_account`` -- an SFTP login whose username
    # and password OR PRIVATE KEY live in a vault kv_secrets entry
    # ({username, private_key[, private_key_passphrase]} or {username,
    # password}), referenced from a feed's destination_config as
    # system_account_id.  Before it existed an operator storing an SFTP key
    # had to file it under a DB or AD type.
    username: str
    password: str
    config: Optional[dict] = None
    # 2026-09-10 — Clockwork plan v2 §3.2.  Optional at CREATE so existing
    # callers keep working; absent = the fail-closed UNSPECIFIED default.
    environment: Optional[str] = Field(None, pattern="^[A-Z][A-Z0-9_\\-]{0,19}$")
    # Phase 154 vault-resolver fields.  All optional; required only when
    # use_vault=True (validator enforces).  Mirrors the SystemAccount
    # model + ETL vault_config.yaml refs shape exactly.
    use_vault: Optional[bool] = False
    secret_ref: Optional[str] = Field(None, max_length=255)
    secret_type: Optional[str] = Field(
        None, pattern="^(DB_accounts|AD_accounts|kv_secrets)$",
    )
    vault_auth_url: Optional[str] = None
    vault_role_name: Optional[str] = Field(None, max_length=255)
    vault_role_type: Optional[str] = Field(None, max_length=50)
    vault_secret_url: Optional[str] = None
    vault_rotate_url: Optional[str] = None
    # 2026-07-13 — ETL PARITY: AppRole / JWT-step-up ref fields.  Optional;
    # only used when the account authenticates via AppRole.  Not required by
    # the validator (JWT accounts leave them blank).
    vault_step_up_name: Optional[str] = Field(None, max_length=255)
    vault_step_up_auth_url: Optional[str] = None
    vault_approle_secret_id_url: Optional[str] = None
    vault_approle_auth_url: Optional[str] = None
    vault_role_id: Optional[str] = Field(None, max_length=255)

    @model_validator(mode="after")
    def _check_vault_fields(self) -> "SystemAccountCreate":
        """When use_vault=True, the QSClient call REQUIRES auth_url
        + role_name + role_type + secret_url + secret_type.  Reject at
        the API boundary so the operator sees the missing fields
        immediately, not on first resolution attempt."""
        if self.use_vault:
            missing = [
                k for k in ("secret_type", "vault_auth_url",
                             "vault_role_name", "vault_role_type",
                             "vault_secret_url")
                if not (getattr(self, k, None) or "").strip()
            ]
            if missing:
                raise ValueError(
                    f"use_vault=True requires the following fields: "
                    f"{missing}.  Either fill them in OR set "
                    f"use_vault=False to use the encrypted password "
                    f"column."
                )
        # A key-pair account's key exists ONLY in Vault: the password column
        # cannot hold one, and a DB_accounts tuple carries no key -- an
        # account stored any other way could never log in.
        if self.account_type == "snowflake_keypair" and not (
                self.use_vault and self.secret_type == "kv_secrets"):
            raise ValueError(
                "account_type=snowflake_keypair reads its private key from a "
                "Vault kv_secrets entry: set use_vault=True and "
                "secret_type=kv_secrets (the entry holds username and "
                "private_key, plus private_key_passphrase if the key is "
                "encrypted).")
        return self


class SystemAccountUpdate(BaseModel):
    name: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None
    config: Optional[dict] = None
    is_active: Optional[bool] = None
    # 2026-09-10 — Clockwork plan v2 §3.2: PROD / NONPROD / the site's own
    # upper-case vocabulary.  UNSPECIFIED (the migration default) is refused
    # at fire time, so an operator must declare it here.
    environment: Optional[str] = Field(None, pattern="^[A-Z][A-Z0-9_\\-]{0,19}$")
    # Phase 154 vault-resolver fields (same shape as Create, all None-
    # only-when-not-touching).
    use_vault: Optional[bool] = None
    secret_ref: Optional[str] = Field(None, max_length=255)
    secret_type: Optional[str] = Field(
        None, pattern="^(DB_accounts|AD_accounts|kv_secrets)$",
    )
    vault_auth_url: Optional[str] = None
    vault_role_name: Optional[str] = Field(None, max_length=255)
    vault_role_type: Optional[str] = Field(None, max_length=50)
    vault_secret_url: Optional[str] = None
    vault_rotate_url: Optional[str] = None
    # 2026-07-13 — ETL PARITY: AppRole / JWT-step-up ref fields (see Create).
    vault_step_up_name: Optional[str] = Field(None, max_length=255)
    vault_step_up_auth_url: Optional[str] = None
    vault_approle_secret_id_url: Optional[str] = None
    vault_approle_auth_url: Optional[str] = None
    vault_role_id: Optional[str] = Field(None, max_length=255)

    @model_validator(mode="after")
    def _check_vault_fields_on_enable(self) -> "SystemAccountUpdate":
        """BUG-H fix (2026-06-25 deep dive): SystemAccountCreate had a
        validator that rejected ``use_vault=True`` without the required
        vault config.  SystemAccountUpdate did NOT.  Operator could
        PATCH a row to ``{"use_vault": true}`` alone -- row saved with
        use_vault=True + every vault_* column NULL -> resolver raises
        on next runtime use ('SystemAccount X has use_vault=True but is
        missing required vault field(s)').

        Fix: when use_vault is explicitly being set to True in this
        patch, require ALL vault config in the same patch.  If the
        operator wants to toggle vault on for an already-configured
        row, they re-send the existing values (matches what the UI
        does post-config; we can't trust the partial-patch case to be
        complete without seeing the existing row state).
        """
        if self.use_vault is True:
            missing = [
                k for k in ("secret_type", "vault_auth_url",
                             "vault_role_name", "vault_role_type",
                             "vault_secret_url")
                if not (getattr(self, k, None) or "").strip()
            ]
            if missing:
                raise ValueError(
                    f"PATCH sets use_vault=True but omits required "
                    f"vault config: {missing}.  Include all 5 required "
                    f"fields in this PATCH (UI re-sends them) OR send "
                    f"use_vault=False to revert."
                )
        return self


@router.get("/api/admin/system-accounts")
async def list_system_accounts(account_type: Optional[str] = None,
                                _user: dict = Depends(require_admin)):
    """List all system accounts (passwords masked)."""
    return {"accounts": await _adb(_db_manager.list_system_accounts, 
        account_type=account_type, active_only=False
    )}


@router.post("/api/admin/system-accounts")
async def create_system_account(body: SystemAccountCreate,
                                 _user: dict = Depends(require_admin)):
    """Create a new system account with encrypted credentials."""
    username = (_user or {}).get("username", "admin")
    # Phase 154 -- thread the vault-resolver kwargs into the DB layer.
    # exclude_none on model_dump skips fields the operator didn't fill,
    # so existing back-compat callers (no vault fields at all) work
    # unchanged.
    _vault_payload = body.model_dump(
        include={"use_vault", "secret_ref", "secret_type",
                  "vault_auth_url", "vault_role_name", "vault_role_type",
                  "vault_secret_url", "vault_rotate_url",
                  # ETL-parity AppRole / step-up fields
                  "vault_step_up_name", "vault_step_up_auth_url",
                  "vault_approle_secret_id_url", "vault_approle_auth_url",
                  "vault_role_id",
                  # 2026-09-10 -- declared here, and dropped by this very set
                  # until now: a PROD/NONPROD given at create was stored as
                  # UNSPECIFIED and refused at fire time.
                  "environment"},
        exclude_none=True,
    )
    result = await _adb(_db_manager.create_system_account,
        name=body.name,
        account_type=body.account_type,
        username=body.username,
        password=body.password,
        config=body.config,
        created_by=username,
        **_vault_payload,
    )
    await _adb(_db_manager.audit, username, "create_system_account",
                       resource_type="system_account", resource_id=str(result["id"]))
    return result


@router.get("/api/admin/system-accounts/{account_id}")
async def get_system_account(account_id: int,
                              _user: dict = Depends(require_admin)):
    """Get a system account by ID (password masked)."""
    acct = await _adb(_db_manager.get_system_account, account_id)
    if not acct:
        raise HTTPException(status_code=404, detail="System account not found")
    return acct


@router.put("/api/admin/system-accounts/{account_id}")
async def update_system_account(account_id: int, body: SystemAccountUpdate,
                                 _user: dict = Depends(require_admin)):
    """Update a system account."""
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")
    result = await _adb(_db_manager.update_system_account, account_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="System account not found")
    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "update_system_account",
                       resource_type="system_account", resource_id=str(account_id))
    return result


@router.delete("/api/admin/system-accounts/{account_id}")
async def delete_system_account(account_id: int,
                                 _user: dict = Depends(require_admin)):
    """Delete a system account."""
    deleted = await _adb(_db_manager.delete_system_account, account_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="System account not found")
    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "delete_system_account",
                       resource_type="system_account", resource_id=str(account_id))
    return {"deleted": True, "id": account_id}


class _MaterializeSystemAccountRequest(BaseModel):
    # Phase 154 (2026-06-25) -- hidden materialise endpoint.
    # Operator: "no plain password text accoross in network".
    #
    # Two modes:
    #   * No reveal_pubkey   -- response masks secrets (password='***',
    #                            kv fields='***').  Diagnostic only.
    #   * reveal_pubkey set  -- response encrypts each secret field
    #                            with RSA-OAEP-SHA256 using the
    #                            caller-provided public key.  Caller
    #                            decrypts locally with their private
    #                            key.  Cleartext NEVER appears on
    #                            the wire.
    #
    # The cleartext-reveal mode (reveal=true) was REMOVED -- even on
    # TLS, an intercepting log/middleware could capture plaintext.
    # Asymmetric envelope makes the bytes-on-wire useless to anyone
    # without the matching private key.
    reveal_pubkey: Optional[str] = Field(
        default=None,
        description=(
            "PEM-encoded RSA public key (e.g. 2048-bit).  When set, "
            "the endpoint encrypts each secret field with RSA-OAEP-"
            "SHA256 and returns base64 ciphertext.  Caller decrypts "
            "with the matching private key locally."
        ),
    )


@router.post(
    "/api/admin/system-accounts/{name_or_id}/materialize",
    include_in_schema=False,  # hidden -- not in OpenAPI / Swagger UI
)
async def _materialize_system_account(
    name_or_id: str,
    body: Optional[_MaterializeSystemAccountRequest] = None,
    _user: dict = Depends(require_admin),
):
    """Internal helper -- materialise a SystemAccount row to its
    runtime form via the Phase 154 qs_credentials chokepoint.

    Hidden from the public OpenAPI surface (include_in_schema=False)
    so it's not listed in /docs.  Admin auth still enforced.

    Path accepts either the row id (int as string) OR the row name.

    Request body:

        {}                          -- diagnostic (masked) response
        {"reveal_pubkey": "<PEM>"}  -- encrypted-envelope response
                                      using caller's RSA public key
                                      (2048..4096-bit)

    Cleartext NEVER appears in the response bytes.  Diagnostic mode
    returns ``"***"`` for every secret field; encrypted mode returns
    ``<field>_encrypted`` base64 ciphertext (RSA-OAEP-SHA256) which
    the caller decrypts with their matching private key.

    The username field is also encrypted in pubkey mode (service-
    account names can carry sensitive context like project / role).

    Audit log: written on EVERY call -- success or failure.  Action
    tag distinguishes outcome (materialize / materialize_encrypted /
    materialize_not_found / materialize_failed / materialize_bad_
    request) so access reviews can filter probe attempts from
    legitimate fetches.
    """
    body = body or _MaterializeSystemAccountRequest()
    username = (_user or {}).get("username", "admin")

    # BUG-E fix: write an audit row on EVERY outcome -- failed
    # resolution still leaves a trail so an attacker probing for
    # valid account names can't enumerate untracked.  Helper
    # consolidates the audit + WARN-on-failure pattern.
    async def _audit(action: str, resource_id: Any) -> None:
        try:
            await _adb(
                _db_manager.audit, username, action,
                resource_type="system_account",
                resource_id=str(resource_id),
            )
        except Exception as _audit_exc:
            # BUG-B fix: warn so SIEM sees audit-pipeline degradation.
            import logging as _logging
            _logging.getLogger(__name__).warning(
                "AUDIT-LOSS: materialize endpoint failed to write "
                "audit row for user=%s action=%s account=%s: %s",
                username, action, resource_id, _audit_exc,
            )

    # BUG-C/D fix: validate the pubkey BEFORE resolving any secret,
    # so a bad pubkey gets a 400 without us pulling creds into memory.
    # Bounded key size: < 2048 is broken crypto; > 4096 is a DoS
    # vector (RSA-OAEP encrypt is O(n^2) in modulus bits + every
    # secret field pays the cost).
    _pubkey = None
    _enc_pad = None
    if body.reveal_pubkey:
        try:
            from cryptography.hazmat.primitives import serialization, hashes
            from cryptography.hazmat.primitives.asymmetric import padding, rsa
        except ImportError as _crypt_exc:
            await _audit("materialize_bad_request", name_or_id)
            raise HTTPException(
                status_code=500,
                detail=(
                    "cryptography library not installed; cannot "
                    f"encrypt response: {_crypt_exc}"
                ),
            )
        try:
            _pubkey = serialization.load_pem_public_key(
                body.reveal_pubkey.encode("utf-8"),
            )
        except Exception as _pk_exc:
            await _audit("materialize_bad_request", name_or_id)
            raise HTTPException(
                status_code=400,
                detail=(
                    f"reveal_pubkey is not a valid PEM-encoded public "
                    f"key: {_pk_exc}"
                ),
            )
        if not isinstance(_pubkey, rsa.RSAPublicKey):
            await _audit("materialize_bad_request", name_or_id)
            raise HTTPException(
                status_code=400,
                detail=(
                    "reveal_pubkey must be an RSA public key (got "
                    f"{type(_pubkey).__name__}); RSA-OAEP-SHA256 is "
                    f"the only supported envelope."
                ),
            )
        # BUG-C: reject keys below 2048-bit (broken crypto).
        # BUG-D: reject keys above 4096-bit (DoS via slow encrypt;
        # per-field cost is O(modulus^2) and we encrypt up to 9
        # secret fields per request).
        _key_size = getattr(_pubkey, "key_size", 0)
        if _key_size < 2048:
            await _audit("materialize_bad_request", name_or_id)
            raise HTTPException(
                status_code=400,
                detail=(
                    f"reveal_pubkey is {_key_size}-bit; minimum "
                    f"required is 2048-bit (anything weaker is "
                    f"considered broken)."
                ),
            )
        if _key_size > 4096:
            await _audit("materialize_bad_request", name_or_id)
            raise HTTPException(
                status_code=400,
                detail=(
                    f"reveal_pubkey is {_key_size}-bit; maximum "
                    f"supported is 4096-bit (larger keys take too "
                    f"long to encrypt; a denial-of-service vector "
                    f"when applied to every secret field)."
                ),
            )
        _enc_pad = padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        )

    # Resolve the SystemAccount.  Audit failures so an attacker
    # probing for valid account names can't enumerate untracked.
    try:
        from core.qs_credentials import resolve_system_account
        creds = await _adb(resolve_system_account, name_or_id)
    except ValueError as exc:
        await _audit("materialize_not_found", name_or_id)
        raise HTTPException(status_code=404, detail=str(exc))
    except Exception as exc:
        await _audit("materialize_failed", name_or_id)
        raise HTTPException(
            status_code=500, detail=f"resolve failed: {exc}",
        )

    # BUG-A fix: canonical row id for audit-correlation.
    _audit_id = creds.get("id")
    if _audit_id is None:
        _audit_id = name_or_id

    _reveal_mode = "encrypted" if body.reveal_pubkey else "masked"
    await _audit(
        "materialize_encrypted" if body.reveal_pubkey else "materialize",
        _audit_id,
    )

    # Build response.  Metadata always included.  Secrets either
    # masked (no pubkey) or RSA-OAEP encrypted (pubkey provided).
    # Cleartext NEVER appears in the response bytes.
    out: Dict[str, Any] = {
        "name_or_id":    name_or_id,
        "via":           creds.get("via"),
        "account_type":  creds.get("account_type"),
        "reveal_mode":   _reveal_mode,
    }

    _SECRET_FIELDS = (
        # BUG-G fix: include username in the encryption set.  Service
        # account names can leak project / role / environment context
        # ("svc_prod_oracle_finance" -> attacker learns prod oracle
        # finance exists).  In pubkey mode username gets encrypted
        # alongside the password.  In masked mode username stays
        # cleartext for diagnostic readability (it's already in the
        # SystemAccounts admin UI list view).
        "username",
        "password", "access_key", "secret_key", "session_token",
        "endpoint_url", "region", "token", "tns_alias",
    )

    if body.reveal_pubkey and _pubkey is not None and _enc_pad is not None:
        # Encrypted-only delivery.  Encrypt EVERY non-empty field in
        # _SECRET_FIELDS (including username per BUG-G) with the
        # caller's pubkey.  Cleartext bytes never reach the response.
        import base64 as _b64
        out["envelope"] = "RSA-OAEP-SHA256"
        out["key_size"] = _key_size
        for k in _SECRET_FIELDS:
            v = creds.get(k)
            if v is None or v == "":
                continue
            try:
                _ct = _pubkey.encrypt(str(v).encode("utf-8"), _enc_pad)
            except Exception as _enc_exc:
                # ValueError for plaintext-too-long (rare with 2048+
                # OAEP-SHA256 -- ~190-byte max -- but possible for
                # very long endpoint_urls).  Per-field 500 leaves
                # the rest of the response usable.
                raise HTTPException(
                    status_code=500,
                    detail=(
                        f"encryption failed for field {k!r}: {_enc_exc}"
                    ),
                )
            out[f"{k}_encrypted"] = _b64.b64encode(_ct).decode("ascii")
    else:
        # Masked diagnostic response.  Useful to verify the resolver
        # chain works end-to-end without ANY secret bytes on the wire.
        out["username"] = creds.get("username") or ""
        for k in _SECRET_FIELDS:
            if k == "username":
                continue  # already set above as cleartext for diagnostics
            v = creds.get(k)
            if v is None or v == "":
                continue
            out[k] = "***"
    return out


def _refuse_unusable_resolution(account_type: str, creds: dict) -> None:
    """2026-10-03 -- a Snowflake key-pair account is tested as a login would
    use it: Vault answering is not enough, the entry must hold a key (and
    passphrase) that opens.  Raises with the reason (field NAMES only)."""
    if account_type != "snowflake_keypair":
        return
    from core.connectors import snowflake_key_pair_problem
    problem = snowflake_key_pair_problem(creds)
    if problem:
        raise RuntimeError(f"Resolver reached Vault, but {problem}")


@router.post("/api/admin/system-accounts/{account_id}/test")
async def test_system_account(account_id: int,
                               _user: dict = Depends(require_admin)):
    """Test a system account by attempting to fetch credentials from the portal."""
    acct = await _adb(_db_manager.get_system_account_raw, account_id)
    if not acct:
        raise HTTPException(status_code=404, detail="System account not found")

    # BUG-J fix (2026-06-25 deep dive): when use_vault=True OR the
    # account_type is one of the Phase 154 additions (db_account /
    # ad_account / s3_keys), route through the qs_credentials
    # chokepoint instead of the legacy aws_portal/snowflake_sso
    # branches.  Pre-fix: the UI Test button returned 'Unknown
    # account type' for every new type even though the underlying
    # resolver chain worked.
    if acct.get("use_vault") or acct["account_type"] in (
        "db_account", "ad_account", "s3_keys", "sftp_account",
        "snowflake_keypair",
    ):
        try:
            from core.qs_credentials import resolve_system_account
            creds = await _adb(resolve_system_account, account_id)
            _refuse_unusable_resolution(acct["account_type"], creds)
            await _adb(_db_manager.update_system_account_status,
                        account_id, "success")
            return {
                "success": True,
                "message": (
                    f"Resolver succeeded via {creds.get('via')} "
                    f"(type={acct['account_type']})."
                ),
            }
        except Exception as exc:
            await _adb(_db_manager.update_system_account_status,
                        account_id, "failed", str(exc))
            return {"success": False, "message": str(exc)}

    if acct["account_type"] == "aws_portal":
        try:
            from core.aws_portal_auth import fetch_credentials
            creds = fetch_credentials(acct["username"], acct["password"])
            await _adb(_db_manager.update_system_account_status, account_id, "success")
            return {
                "success": True,
                "message": f"Portal login successful. Credentials expire at {creds.get('expires_at', 'unknown')}.",
                "access_key_prefix": creds.get("aws_access_key_id", "")[:8] + "...",
            }
        except Exception as exc:
            await _adb(_db_manager.update_system_account_status, account_id, "failed", str(exc))
            return {"success": False, "message": str(exc)}
    elif acct["account_type"] == "snowflake_sso":
        return {
            "success": True,
            "message": "Snowflake system account stored. Will be tested on first connection use.",
        }
    else:
        return {"success": False, "message": f"Unknown account type: {acct['account_type']}"}


@router.post("/api/admin/system-accounts/{account_id}/refresh")
async def refresh_system_account(account_id: int,
                                  _user: dict = Depends(require_admin)):
    """Force-refresh cached credentials for a system account."""
    acct = await _adb(_db_manager.get_system_account_raw, account_id)
    if not acct:
        raise HTTPException(status_code=404, detail="System account not found")

    # BUG-J fix (deep dive): vault-backed accounts have their own
    # cache layer (qs_credentials in-process + disk).  Refresh =
    # drop the resolver cache for this row's secret_ref then re-
    # resolve so the next caller sees a fresh vault fetch.
    if acct.get("use_vault"):
        try:
            from core.qs_credentials import (
                invalidate as _sr_invalidate,
                resolve_system_account,
            )
            _sr_invalidate(acct.get("secret_ref") or acct.get("name"))
            await _adb(resolve_system_account, account_id)
            await _adb(_db_manager.update_system_account_status,
                        account_id, "success")
            return {
                "success": True,
                "message": "Vault cache dropped + re-resolved.",
            }
        except Exception as exc:
            await _adb(_db_manager.update_system_account_status,
                        account_id, "failed", str(exc))
            return {"success": False, "message": str(exc)}

    if acct["account_type"] == "aws_portal":
        from core.aws_portal_auth import clear_cache
        cache_key = f"sys:{account_id}"
        clear_cache(cache_key)
        try:
            from core.aws_portal_auth import fetch_credentials, _cache_lock, _cred_cache
            creds = fetch_credentials(acct["username"], acct["password"])
            import time
            with _cache_lock:
                _cred_cache[cache_key] = (creds, creds.get("expires_at", time.time() + 3300))
            await _adb(_db_manager.update_system_account_status, account_id, "success")
            return {"success": True, "message": "Credentials refreshed."}
        except Exception as exc:
            await _adb(_db_manager.update_system_account_status, account_id, "failed", str(exc))
            return {"success": False, "message": str(exc)}

    return {"success": True, "message": "No refresh needed for this account type."}


# ─────────────────────────────────────────────────────────────────────
#  Phase 158 R10 (2026-06-28) -- vault runtime configuration
#
#  Surfaces every env-var-only knob the qs_credentials package consults
#  (QS_USE_VAULT, QS_VAULT_VERIFY_SSL, QS_VAULT_TIMEOUT_SECONDS, etc.)
#  through the admin UI so operators tune them WITHOUT a pod restart.
#  Resolution priority at every call site: env var > this config > default.
#  GET reports the EFFECTIVE values + which layer wins per knob.
# ─────────────────────────────────────────────────────────────────────


class VaultConfigUpdate(BaseModel):
    enabled:             Optional[bool]  = None
    machine:             Optional[str]   = Field(None, max_length=50)
    token_method:        Optional[str]   = Field(None, max_length=50)
    cache_ttl_seconds:   Optional[int]   = Field(None, ge=0, le=86400)
    disk_cache_enabled:  Optional[bool]  = None
    disk_cache_path:     Optional[str]   = Field(None, max_length=512)
    disk_cache_ttl_seconds: Optional[int] = Field(None, ge=0, le=2592000)
    disk_cache_key_env:  Optional[str]   = Field(None, max_length=64)
    # R10 additions -- previously env-only.
    verify_ssl:          Optional[bool]  = None
    timeout_seconds:     Optional[float] = Field(None, ge=0.1, le=300.0)
    legacy_ciphers:      Optional[bool]  = None
    app_name:            Optional[str]   = Field(None, max_length=64)
    cred_refresh_hours:  Optional[float] = Field(None, ge=0, le=720)
    daemon_force:        Optional[bool]  = None
    token_path:          Optional[str]   = Field(None, max_length=512)


def _vault_env_truthy(name: str) -> Optional[bool]:
    """Read an env var as a tri-state bool: True / False / not-set."""
    v = os.environ.get(name, "").strip().lower()
    if v in ("1", "true", "yes"):
        return True
    if v in ("0", "false", "no"):
        return False
    return None


def _vault_env_float(name: str) -> Optional[float]:
    """Read an env var as a float, or None when unset / unparseable."""
    raw = os.environ.get(name, "").strip()
    if not raw:
        return None
    try:
        return float(raw)
    except ValueError:
        return None


def _vault_resolve_bool(_s, env_var: str, cfg_attr: str, default: bool):
    """(value, winning layer) for a boolean knob: env beats config beats default."""
    env_v = _vault_env_truthy(env_var)
    if env_v is not None:
        return env_v, "env"
    try:
        return bool(getattr(_s, cfg_attr)), "config"
    except Exception:
        return default, "default"


def _vault_resolve_float(_s, env_var: str, cfg_attr: str, default: float):
    """(value, winning layer) for a float knob: env beats config beats default."""
    env_v = _vault_env_float(env_var)
    if env_v is not None:
        return env_v, "env"
    try:
        return float(getattr(_s, cfg_attr)), "config"
    except Exception:
        return default, "default"


def _vault_resolve_str(_s, env_var: str, cfg_attr: str, default: str):
    """(value, winning layer) for a string knob: env beats config beats default."""
    env_v = os.environ.get(env_var, "").strip() if env_var else ""
    if env_v:
        return env_v, "env"
    try:
        val = str(getattr(_s, cfg_attr) or "")
        return (val or default), ("config" if val else "default")
    except Exception:
        return default, "default"


def _vault_effective_config() -> Dict[str, Any]:
    """Read the effective config + which layer wins per knob.

    For each knob we return:
      value     -- the value qs_credentials would actually use right now
      source    -- 'env' | 'config' | 'default'
      env_var   -- the env var name (empty for config-only knobs)
      env_set   -- True when the env var is currently set
    """
    from core.config import secrets as _s

    def _resolve_bool(env_var: str, cfg_attr: str, default: bool):
        return _vault_resolve_bool(_s, env_var, cfg_attr, default)

    def _resolve_float(env_var: str, cfg_attr: str, default: float):
        return _vault_resolve_float(_s, env_var, cfg_attr, default)

    def _resolve_str(env_var: str, cfg_attr: str, default: str):
        return _vault_resolve_str(_s, env_var, cfg_attr, default)

    out: Dict[str, Any] = {}

    # Master toggle (env > config-block > default False).
    v, src = _resolve_bool("QS_USE_VAULT", "enabled", False)
    out["enabled"] = {"value": v, "source": src,
                      "env_var": "QS_USE_VAULT",
                      "env_set": "QS_USE_VAULT" in os.environ}

    # Machine + token_method (config-only currently; surfaced for visibility).
    out["machine"] = {"value": str(_s.machine), "source": "config",
                       "env_var": "", "env_set": False}
    out["token_method"] = {"value": str(_s.token_method),
                            "source": "config", "env_var": "",
                            "env_set": False}

    # Cache + disk knobs (config-only).
    out["cache_ttl_seconds"] = {"value": int(_s.cache_ttl_seconds),
                                 "source": "config", "env_var": "",
                                 "env_set": False}
    out["disk_cache_enabled"] = {"value": bool(_s.disk_cache_enabled),
                                  "source": "config", "env_var": "",
                                  "env_set": False}
    out["disk_cache_path"] = {"value": str(_s.disk_cache_path),
                               "source": "config", "env_var": "",
                               "env_set": False}
    out["disk_cache_ttl_seconds"] = {"value": int(_s.disk_cache_ttl_seconds),
                                      "source": "config", "env_var": "",
                                      "env_set": False}
    out["disk_cache_key_env"] = {"value": str(_s.disk_cache_key_env),
                                  "source": "config", "env_var": "",
                                  "env_set": False}

    # R10 knobs (env > config > default).
    v, src = _resolve_bool("QS_VAULT_VERIFY_SSL", "verify_ssl", False)
    out["verify_ssl"] = {"value": v, "source": src,
                          "env_var": "QS_VAULT_VERIFY_SSL",
                          "env_set": "QS_VAULT_VERIFY_SSL" in os.environ}

    v, src = _resolve_float("QS_VAULT_TIMEOUT_SECONDS", "timeout_seconds", 3.0)
    out["timeout_seconds"] = {"value": v, "source": src,
                               "env_var": "QS_VAULT_TIMEOUT_SECONDS",
                               "env_set": "QS_VAULT_TIMEOUT_SECONDS" in os.environ}

    v, src = _resolve_bool("QS_VAULT_LEGACY_CIPHERS", "legacy_ciphers", False)
    out["legacy_ciphers"] = {"value": v, "source": src,
                              "env_var": "QS_VAULT_LEGACY_CIPHERS",
                              "env_set": "QS_VAULT_LEGACY_CIPHERS" in os.environ}

    v, src = _resolve_str("QS_VAULT_APP_NAME", "app_name", "querystudio")
    out["app_name"] = {"value": v, "source": src,
                        "env_var": "QS_VAULT_APP_NAME",
                        "env_set": "QS_VAULT_APP_NAME" in os.environ}

    v, src = _resolve_float("QS_CRED_REFRESH_HOURS", "cred_refresh_hours", 24.0)
    out["cred_refresh_hours"] = {"value": v, "source": src,
                                  "env_var": "QS_CRED_REFRESH_HOURS",
                                  "env_set": "QS_CRED_REFRESH_HOURS" in os.environ}

    v, src = _resolve_bool("QS_CRED_DAEMON_FORCE", "daemon_force", False)
    out["daemon_force"] = {"value": v, "source": src,
                            "env_var": "QS_CRED_DAEMON_FORCE",
                            "env_set": "QS_CRED_DAEMON_FORCE" in os.environ}

    v, src = _resolve_str("ETL_VAULT_TOKEN_PATH", "token_path", "")
    out["token_path"] = {"value": v, "source": src,
                          "env_var": "ETL_VAULT_TOKEN_PATH",
                          "env_set": "ETL_VAULT_TOKEN_PATH" in os.environ}

    return out


@router.get("/api/admin/vault-config")
async def get_vault_config(_user: dict = Depends(require_admin)):
    """Return current effective vault config + per-knob source layer.
    Lets admins see which knobs are env-overridden vs config-driven."""
    return {"config": _vault_effective_config()}


@router.put("/api/admin/vault-config")
async def update_vault_config(body: VaultConfigUpdate,
                                _user: dict = Depends(require_admin)):
    """Persist vault config knobs to the ``secrets`` section through
    ``config.set()`` -- the DB overlay every pod reads (2026-09-27; it
    used to rewrite this pod's ``backend/config.json``, ignoring
    ``$QUERYSTUDIO_CONFIG``).  The ``QS_*`` env vars STILL win at
    resolution time in ``_vault_effective_config`` -- this endpoint edits
    the config layer that loses to env when both are set."""
    updates = body.model_dump(exclude_none=True)
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")

    result = await asyncio.to_thread(_persist_config_section, "secrets", updates)

    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "update_vault_config",
                       resource_type="config",
                       resource_id=",".join(sorted(updates.keys())))

    # Reset the qs_credentials cache so the next resolution picks up
    # the new TTLs / paths.
    try:
        from core.qs_credentials import reset_cache, disk_cache_clear
        reset_cache()
        if any(k in updates for k in ("disk_cache_path",
                                        "disk_cache_key_env")):
            disk_cache_clear()
    except Exception:
        pass

    # Phase 158 R10 -- HTTP transport knobs (verify_ssl /
    # timeout_seconds / legacy_ciphers) are baked into the module-
    # level PoolManager on FIRST construction.  Without a pool reset
    # the next vault call would still use the OLD timeout / TLS
    # verification settings.  Drop the pool so it rebuilds with the
    # new effective values on next send_request().
    _TRANSPORT_KEYS = {"verify_ssl", "timeout_seconds", "legacy_ciphers"}
    if any(k in updates for k in _TRANSPORT_KEYS):
        try:
            from core.qs_credentials.vault.qs_utils import reset_pool
            reset_pool()
        except Exception:
            pass

    return {"updated": updates, "effective": _vault_effective_config(),
            "persisted": result["persisted"],
            "message": _persist_message(result["persisted"], "Vault config updated")}


@router.post("/api/admin/vault-config/clear-cache")
async def clear_vault_cache(_user: dict = Depends(require_admin)):
    """Drop ALL cached vault secrets (in-memory + on-disk).  Next
    resolution for any account re-fetches from Vault.  Use after a
    Vault rotation that didn't propagate via the natural mem_ttl."""
    from core.qs_credentials import reset_cache, disk_cache_clear
    reset_cache()
    disk_cache_clear()
    username = (_user or {}).get("username", "admin")
    await _adb(_db_manager.audit, username, "clear_vault_cache",
                       resource_type="config", resource_id="vault-cache")
    return {"success": True, "message": "Vault cache cleared (mem + disk)."}


# ── Phase 100: Onboarding / Guided Tours Config ─────────────────────────────

@router.get("/api/admin/onboarding/config")
async def get_onboarding_config(_user: dict = Depends(require_admin)):
    """Return the current onboarding configuration."""
    from core import config as _cfg
    return {
        "enabled": _cfg.onboarding.enabled,
        "auto_show_on_first_login": _cfg.onboarding.auto_show_on_first_login,
        "available_tours": _cfg.onboarding.available_tours,
        "default_tour": _cfg.onboarding.default_tour,
    }


@router.put("/api/admin/onboarding/config")
async def update_onboarding_config(body: dict, _user: dict = Depends(require_admin)):
    """Update onboarding configuration keys (additive merge)."""
    from core import config as _cfg
    allowed = {"enabled", "auto_show_on_first_login", "available_tours", "default_tour"}
    updated = {}
    for key, val in body.items():
        if key in allowed:
            _cfg.set("onboarding", key, val)
            updated[key] = val
    if not updated:
        raise HTTPException(400, f"No valid keys. Allowed: {sorted(allowed)}")
    return {"detail": "updated", "updated_keys": list(updated.keys())}


# ── Admin Governance Config (Phase 102-B) ────────────────────────────────────

# FB-48 (2026-09-20).  This allowlist is what makes a governance key
# OPERABLE, and the sweep's picture of it was wrong in both directions:
#   * ``rate_limit_enabled`` and ``max_saved_queries_per_user`` were NOT
#     written by this route -- they were unreachable from both ends, no
#     reader and no writer.  Both are now read by production code, so both
#     are settable here and shown on the screen.
#   * ``export_max_file_size_mb`` WAS settable here and is read by nothing
#     but this route's own GET.  The key is gone (see config._REMOVED_KEYS)
#     and so is the control: a screen that accepts a governance value and
#     discards it is worse than one that does not offer it.
_GOVERNANCE_ALLOWED_KEYS = {
    "enabled",
    "rate_limit_enabled",
    "rate_limit_admin", "rate_limit_analyst", "rate_limit_viewer",
    "daily_quota_admin", "daily_quota_analyst", "daily_quota_viewer",
    "export_formats_admin", "export_formats_analyst", "export_formats_viewer",
    "export_rate_limit_per_minute",
    "max_connections_per_user", "max_schedules_per_user",
    "max_published_views_per_user", "max_saved_queries_per_user",
    "audit_log_max_results", "daily_quota_cache_ttl_seconds",
}


@router.get("/api/admin/governance/config")
async def get_governance_config(_user: dict = Depends(require_admin)):
    """Return full admin-governance configuration (Phase 102-B)."""
    from core import config as _cfg
    g = _cfg.admin_governance
    return {
        "enabled": g.enabled,
        "rate_limit_enabled": g.rate_limit_enabled,
        "rate_limit_admin": g.rate_limit_admin,
        "rate_limit_analyst": g.rate_limit_analyst,
        "rate_limit_viewer": g.rate_limit_viewer,
        "daily_quota_admin": g.daily_quota_admin,
        "daily_quota_analyst": g.daily_quota_analyst,
        "daily_quota_viewer": g.daily_quota_viewer,
        "export_formats_admin": g.export_formats_admin,
        "export_formats_analyst": g.export_formats_analyst,
        "export_formats_viewer": g.export_formats_viewer,
        "export_rate_limit_per_minute": g.export_rate_limit_per_minute,
        "max_connections_per_user": g.max_connections_per_user,
        "max_schedules_per_user": g.max_schedules_per_user,
        "max_published_views_per_user": g.max_published_views_per_user,
        "max_saved_queries_per_user": g.max_saved_queries_per_user,
        "audit_log_max_results": g.audit_log_max_results,
        "daily_quota_cache_ttl_seconds": g.daily_quota_cache_ttl_seconds,
    }


@router.put("/api/admin/governance/config")
async def update_governance_config(body: dict, _user: dict = Depends(require_admin)):
    """Update admin-governance configuration keys (additive merge)."""
    from core import config as _cfg
    updated = {}
    for key, val in body.items():
        if key in _GOVERNANCE_ALLOWED_KEYS:
            _cfg.set("admin_governance", key, val)
            updated[key] = val
    if not updated:
        raise HTTPException(400, f"No valid keys. Allowed: {sorted(_GOVERNANCE_ALLOWED_KEYS)}")
    username = (_user or {}).get("username", "admin")
    if _db_manager:
        await _adb(_db_manager.audit, username, "update_governance_config", resource_type="config",
                          resource_id="admin_governance")
    return {"detail": "updated", "updated_keys": list(updated.keys())}


# ── Usage Stats — Daily Query Counts (Phase 102-C) ───────────────────────────

async def _usage_role_for_user(username: str) -> str:
    """One user's role, defaulting to viewer when the list cannot be read."""
    role = "viewer"
    try:
        users = await _adb(_db_manager.list_users) or []
        for u in users:
            if u.get("username") == username:
                role = u.get("role", "viewer")
                break
    except Exception:
        pass
    return role


async def _usage_role_map() -> Dict[str, str]:
    """username -> role for every user; empty when the list cannot be read."""
    role_map: Dict[str, str] = {}
    try:
        for u in (await _adb(_db_manager.list_users) or []):
            role_map[u.get("username")] = u.get("role", "viewer")
    except Exception:
        pass
    return role_map


async def _usage_counts_by_user() -> list:
    """(username, executions) pairs for today; empty when the query fails."""
    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    rows = []
    try:
        with await _adb(_db_manager.get_session, read_only=True) as _s:
            from sqlalchemy import func
            from core.db.models import QueryExecution
            grouped = (_s.query(QueryExecution.executed_by,
                                func.count(QueryExecution.id))
                         .filter(QueryExecution.started_at >= today_start)
                         .group_by(QueryExecution.executed_by)
                         .all())
            rows = [(u or "unknown", int(c)) for u, c in grouped]
    except Exception as exc:
        logger.warning("usage-stats aggregate failed: %s", exc)
    return rows


@router.get("/api/admin/usage-stats/daily")
async def get_usage_stats_daily(
    username: Optional[str] = Query(None, description="Filter to a specific user"),
    _user: dict = Depends(require_admin),
):
    """Return today's per-user query-execution counts and quota utilisation.

    Response:
      {
        "date": "2026-04-04",
        "users": [
          {"username": "alice", "executions_today": 42,
           "role": "analyst", "quota": 1000, "utilisation_pct": 4.2},
          ...
        ],
        "total_today": 128
      }
    """
    if not _db_manager:
        raise HTTPException(503, "Database not initialized")
    from core.config import admin_governance as _gov
    today_count = await _adb(_db_manager.count_executions_today, username=username)
    if username:
        # Single-user view — try to resolve the user's role from the users list
        role = await _usage_role_for_user(username)
        quota = _gov.daily_quota_for_role(role)
        return {
            "date": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
            "users": [{
                "username": username,
                "executions_today": today_count,
                "role": role,
                "quota": quota,
                "utilisation_pct": round((today_count / quota * 100.0), 2) if quota > 0 else None,
            }],
            "total_today": today_count,
        }
    # Aggregate view — group by user via DB query
    rows = await _usage_counts_by_user()
    role_map = await _usage_role_map()
    users_resp = []
    for uname, cnt in rows:
        urole = role_map.get(uname, "viewer")
        q = _gov.daily_quota_for_role(urole)
        users_resp.append({
            "username": uname,
            "executions_today": cnt,
            "role": urole,
            "quota": q,
            "utilisation_pct": round((cnt / q * 100.0), 2) if q > 0 else None,
        })
    users_resp.sort(key=lambda r: r["executions_today"], reverse=True)
    return {
        "date": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
        "users": users_resp,
        "total_today": today_count,
    }


# ── Audit Log Enhancements (Phase 102-G) ─────────────────────────────────────

@router.get("/api/admin/audit-log/action-summary")
async def get_audit_action_summary_endpoint(
    days:     int = Query(7, ge=1, le=365, description="Lookback window in days"),
    username: Optional[str] = Query(None, description="Scope to a single user"),
    _user: dict = Depends(require_admin),
):
    """Return aggregated audit-log counts grouped by action (admin only).

    Response: [{action, count, last_seen}] sorted by count desc.
    """
    if not _db_manager:
        raise HTTPException(503, "Database not initialized")
    return {
        "days":    days,
        "summary": await _adb(_db_manager.get_audit_action_summary, days=days, username=username),
    }


@router.get("/api/admin/audit-log/distinct-values")
async def get_audit_distinct_values_endpoint(
    days: int = Query(30, ge=1, le=365, description="Lookback window in days"),
    _user: dict = Depends(require_admin),
):
    """Return distinct usernames, actions, resource_types for filter dropdowns (admin only)."""
    if not _db_manager:
        raise HTTPException(503, "Database not initialized")
    return await _adb(_db_manager.get_audit_distinct_values, days=days)


@router.get("/api/admin/usage-stats/detailed")
async def get_usage_stats_detailed(
    days: int = Query(7, ge=1, le=90, description="Number of days to report"),
    _user: dict = Depends(require_admin),
):
    """Per-user per-day execution counts over the last N days (admin only).

    Response:
      {
        "days": 7,
        "from": "2026-03-28",
        "to":   "2026-04-04",
        "rows": [{"date": "2026-04-04", "username": "alice", "count": 42}, ...]
      }
    """
    if not _db_manager:
        raise HTTPException(503, "Database not initialized")
    now = datetime.now(timezone.utc)
    since = (now - timedelta(days=days)).replace(hour=0, minute=0, second=0, microsecond=0)
    rows_out = []
    try:
        with await _adb(_db_manager.get_session, read_only=True) as _s:
            from sqlalchemy import func
            from core.db.models import QueryExecution
            # Use DATE(started_at) for per-day bucketing
            date_expr = func.date(QueryExecution.started_at).label("d")
            grouped = (_s.query(
                        date_expr,
                        QueryExecution.executed_by,
                        func.count(QueryExecution.id).label("cnt"))
                       .filter(QueryExecution.started_at >= since)
                       .group_by(date_expr, QueryExecution.executed_by)
                       .order_by(date_expr.desc())
                       .all())
            for r in grouped:
                rows_out.append({
                    "date":     str(r[0]) if r[0] else None,
                    "username": r[1] or "unknown",
                    "count":    int(r[2] or 0),
                })
    except Exception as exc:
        logger.warning("usage-stats detailed failed: %s", exc)
    return {
        "days": days,
        "from": since.strftime("%Y-%m-%d"),
        "to":   now.strftime("%Y-%m-%d"),
        "rows": rows_out,
    }


# ── Phase 104: Cache Explorer Admin Endpoints ─────────────────────────────────

class BulkEvictRequest(BaseModel):
    connection_id: Optional[int] = None
    table_name: Optional[str] = None
    stale_only: bool = False


def _cache_fingerprint_source(make_s3_client, cid, tname):
    """Locate ``(s3 client, bucket, prefix)`` for one registered table.

    Returns None whenever the connection, its bucket or the table cannot be
    resolved — the staleness checker reads that as "cannot tell".
    """
    try:
        c = _db_manager.get_connection_raw(cid)
        if not c:
            return None
        cfg = c.get("config", {})
        bucket = cfg.get("bucket_name", "")
        for t2 in cfg.get("registered_tables", []):
            if t2.get("name") == tname:
                return (make_s3_client(c), bucket, t2.get("s3_prefix", ""))
        return None
    except Exception:
        return None


def _cache_entry_age_seconds(created_at, now) -> Optional[int]:
    """Whole seconds since a cache entry was written; None if unparseable."""
    try:
        import dateutil.parser
        ca = dateutil.parser.parse(created_at)
        if ca.tzinfo is None:
            ca = ca.replace(tzinfo=timezone.utc)
        return int((now - ca).total_seconds())
    except Exception:
        return None


def _cache_entry_ttl_remaining(expires_at, now) -> Optional[int]:
    """Seconds of TTL left (never negative); None if unparseable."""
    try:
        import dateutil.parser
        ea = dateutil.parser.parse(expires_at)
        if ea.tzinfo is None:
            ea = ea.replace(tzinfo=timezone.utc)
        return max(0, int((ea - now).total_seconds()))
    except Exception:
        return None


async def _cache_entry_connection_name(entry: dict) -> Optional[str]:
    """Display name of the entry's connection; None when it cannot be read."""
    if not entry.get("connection_id"):
        return None
    try:
        conn = await _adb(_db_manager.get_connection, entry["connection_id"])
        if conn:
            return conn.get("name")
    except Exception:
        pass
    return None


def _cache_entry_staleness(entry: dict, check_staleness: bool) -> str:
    """Classify one cache entry as fresh / stale / unknown / legacy.

    ``legacy`` = the entry predates fingerprinting; ``unknown`` = it carries a
    fingerprint that we did not, or could not, compare against S3.
    """
    if check_staleness and entry.get("source_fingerprint"):
        try:
            from core.snapshot_fingerprint import check_cache_entry_staleness_multi
            from core.s3_utilities import make_s3_client_for_conn

            def _fp_s3(cid, tname):
                return _cache_fingerprint_source(make_s3_client_for_conn, cid, tname)

            is_stale, _ = check_cache_entry_staleness_multi(entry, _fp_s3)
            return "stale" if is_stale else "fresh"
        except Exception:
            return "unknown"
    if entry.get("source_fingerprint"):
        return "unknown"
    return "legacy"


async def _cache_explorer_row(entry: dict, tables_json: list,
                              check_staleness: bool) -> Dict[str, Any]:
    """Enrich one cache row with age, TTL, connection name and staleness."""
    now = datetime.now(timezone.utc)
    age_seconds = None
    ttl_remaining = None
    if entry.get("created_at"):
        age_seconds = _cache_entry_age_seconds(entry["created_at"], now)
    if entry.get("expires_at"):
        ttl_remaining = _cache_entry_ttl_remaining(entry["expires_at"], now)

    # Connection name lookup
    conn_name = await _cache_entry_connection_name(entry)

    staleness = _cache_entry_staleness(entry, check_staleness)

    # Size in MB
    size_mb = round(entry.get("file_size_bytes", 0) / 1_048_576, 2)

    return {
        "cache_key":        entry["cache_key"],
        "connection_id":    entry.get("connection_id"),
        "connection_name":  conn_name,
        "tables":           [t.get("table_name") for t in tables_json],
        "format":           (tables_json[0].get("format") if tables_json else None),
        "cached_at":        entry.get("created_at"),
        "age_seconds":      age_seconds,
        "expires_at":       entry.get("expires_at"),
        "ttl_remaining":    ttl_remaining,
        "size_mb":          size_mb,
        "hit_count":        entry.get("hit_count", 0),
        "staleness":        staleness,
        "source_fingerprint": entry.get("source_fingerprint"),
        "source_tables_json": tables_json,
    }


@router.get("/api/admin/cache/entries")
async def list_cache_explorer_entries(
    connection_id: Optional[int] = None,
    table: Optional[str] = None,
    check_staleness: bool = False,
    _user: dict = Depends(require_admin),
):
    """List all query cache entries with enriched detail.

    Optional filters: connection_id, table name.
    Pass check_staleness=true to do live S3 staleness check (expensive).
    """
    if _db_manager is None:
        raise HTTPException(503, "DB not available")

    entries = await _adb(_db_manager.list_cache_entries)
    result = []
    for entry in entries:
        # Filter
        if connection_id is not None and entry.get("connection_id") != connection_id:
            continue
        tables_json = entry.get("source_tables_json") or []
        if table and not any(t.get("table_name") == table for t in tables_json):
            continue

        result.append(await _cache_explorer_row(entry, tables_json, check_staleness))

    return {"entries": result, "total": len(result)}


def _cache_entry_staleness_detail(entry: dict) -> Tuple[str, Optional[str]]:
    """Live staleness verdict for one cache entry, plus the reason text.

    ``('unknown', None)`` when the entry predates fingerprinting; the reason
    carries the exception text when the S3 comparison could not run.
    """
    staleness = "unknown"
    staleness_detail = None
    if entry.get("source_fingerprint"):
        try:
            from core.snapshot_fingerprint import check_cache_entry_staleness_multi
            from core.s3_utilities import make_s3_client_for_conn

            def _fp_s3(cid, tname):
                return _cache_fingerprint_source(make_s3_client_for_conn, cid, tname)

            is_stale, reason = check_cache_entry_staleness_multi(entry, _fp_s3)
            staleness = "stale" if is_stale else "fresh"
            staleness_detail = reason
        except Exception as exc:
            staleness_detail = str(exc)
    return staleness, staleness_detail


@router.get("/api/admin/cache/entries/{cache_key}")
async def get_cache_explorer_entry(
    cache_key: str,
    _user: dict = Depends(require_admin),
):
    """Get single cache entry detail with real-time staleness check."""
    if _db_manager is None:
        raise HTTPException(503, "DB not available")

    entry = await _adb(_db_manager.get_cache_entry, cache_key)
    if not entry:
        raise HTTPException(404, "Cache entry not found")

    staleness, staleness_detail = _cache_entry_staleness_detail(entry)

    return {**entry, "staleness": staleness, "staleness_detail": staleness_detail}


@router.delete("/api/admin/cache/entries/{cache_key}")
async def evict_cache_explorer_entry(
    cache_key: str,
    _user: dict = Depends(require_admin),
):
    """Evict (delete) a single cache entry."""
    if _db_manager is None:
        raise HTTPException(503, "DB not available")
    from core.query_cache import invalidate as _qc_invalidate
    _qc_invalidate(cache_key)
    return {"evicted": True, "cache_key": cache_key}


@router.post("/api/admin/cache/entries/{cache_key}/refresh")
async def refresh_cache_explorer_entry(
    cache_key: str,
    background_tasks: BackgroundTasks,
    _user: dict = Depends(require_admin),
):
    """Evict a single cache entry and trigger background re-execution."""
    if _db_manager is None:
        raise HTTPException(503, "DB not available")

    entry = await _adb(_db_manager.get_cache_entry, cache_key)
    if not entry:
        raise HTTPException(404, "Cache entry not found")

    from core.query_cache import invalidate as _qc_invalidate
    _qc_invalidate(cache_key)

    return {
        "evicted": True,
        "cache_key": cache_key,
        "message": "Cache entry evicted. Re-execute the query to refresh.",
    }


def _bulk_evict_should_skip_fresh(entry: dict) -> bool:
    """Under ``stale_only``, decide whether this entry must be LEFT alone.

    True for a fresh entry and — fail-open — for any entry whose staleness
    could not be determined at all.
    """
    try:
        from core.snapshot_fingerprint import check_cache_entry_staleness_multi
        from core.s3_utilities import make_s3_client_for_conn

        def _fp_s3_bulk(cid, tname):
            return _cache_fingerprint_source(make_s3_client_for_conn, cid, tname)

        is_stale, _ = check_cache_entry_staleness_multi(entry, _fp_s3_bulk)
        return not is_stale
    except Exception:
        return True  # fail-open — skip entries that can't be checked


def _bulk_evict_matches(entry: dict, tables_json: list, body) -> bool:
    """Decide whether one cache entry falls inside a bulk-evict filter."""
    if body.connection_id is not None and entry.get("connection_id") != body.connection_id:
        return False
    if body.table_name:
        if not any(t.get("table_name") == body.table_name for t in tables_json):
            return False
    if body.stale_only and _bulk_evict_should_skip_fresh(entry):
        return False
    return True


@router.post("/api/admin/cache/bulk-evict")
async def bulk_evict_cache_entries(
    body: BulkEvictRequest,
    _user: dict = Depends(require_admin),
):
    """Bulk evict cache entries by filter (connection_id, table_name, stale_only)."""
    if _db_manager is None:
        raise HTTPException(503, "DB not available")

    from core.query_cache import invalidate as _qc_invalidate
    entries = await _adb(_db_manager.list_cache_entries)
    evicted = 0

    for entry in entries:
        cache_key = entry.get("cache_key")
        if not cache_key:
            continue
        tables_json = entry.get("source_tables_json") or []

        if not _bulk_evict_matches(entry, tables_json, body):
            continue

        _qc_invalidate(cache_key)
        evicted += 1

    return {"evicted_count": evicted}


# ── Spark Connect Admin (Phase SC) ───────────────────────────────────────────

class SparkConnectConfigUpdate(BaseModel):
    """Fields that may be updated via PUT /api/admin/spark-connect/config."""
    enabled:                         Optional[bool]  = None
    server_url:                      Optional[str]   = None
    row_threshold:                   Optional[int]   = None
    timeout_seconds:                 Optional[int]   = None
    max_result_rows:                 Optional[int]   = None
    session_idle_timeout_minutes:    Optional[int]   = None
    max_sessions_per_user:           Optional[int]   = None
    max_concurrent_queries:          Optional[int]   = None
    # Phase 151 follow-up — operator-configurable routing rules.
    # Validation happens against the same shape spark_routing_rules
    # accepts; bad rules are tolerated at evaluation time (fail-OPEN)
    # but reject obviously malformed shapes on the admin write path.
    routing_rules:                   Optional[List[Dict[str, Any]]] = None


@router.get("/api/admin/spark-connect/status")
async def get_spark_connect_status(_user: dict = Depends(require_admin)):
    """Return Spark Connect server health, active sessions, circuit breaker state."""
    from core.config import spark_connect as _sc

    session_stats: dict = {"active_sessions": 0, "active_queries": 0, "users": []}
    try:
        from core.spark_connect_session_manager import get_session_stats
        session_stats = get_session_stats()
    except Exception:
        pass

    # Phase 151 follow-up — surface routing rules in the status payload
    # so admins see what overrides are active.  Read-only here; PUT
    # /api/admin/spark-connect/config edits them.
    routing_rules: List[Dict[str, Any]] = []
    try:
        from core.config import get as _cfg_get
        rules = _cfg_get("spark_connect", "routing_rules", [])
        if isinstance(rules, list):
            routing_rules = [r for r in rules if isinstance(r, dict)]
    except Exception:
        pass

    # 2026-10-17 (component health, defect 2): the state was the constant
    # "unknown" ("updated by breaker below" -- nothing did).  Read THE breaker
    # the reset route resets; unreadable = unknown WITH the reason.
    try:
        from api.execute_api import _get_spark_breaker
        _breaker_state = "open" if _get_spark_breaker().is_open else "closed"
        _breaker_reason = None
    except Exception as _sb_exc:                           # noqa: BLE001
        _breaker_state = "unknown"
        _breaker_reason = f"breaker unreadable: {type(_sb_exc).__name__}: {str(_sb_exc)[:120]}"

    return {
        "enabled":       _sc.enabled,
        "server_url":    _sc.server_url,
        "row_threshold": _sc.row_threshold,
        "circuit_breaker": {
            "state":              _breaker_state,
            "reason":             _breaker_reason,
            "failure_threshold":  _sc.circuit_breaker_failure_threshold,
            "cooldown_seconds":   _sc.circuit_breaker_cooldown_seconds,
        },
        "sessions":      session_stats,
        "config": {
            "timeout_seconds":              _sc.timeout_seconds,
            "max_result_rows":              _sc.max_result_rows,
            "session_idle_timeout_minutes": _sc.session_idle_timeout_minutes,
            "max_sessions_per_user":        _sc.max_sessions_per_user,
            "max_concurrent_queries":       _sc.max_concurrent_queries,
        },
        "routing_rules": routing_rules,
    }


@router.post("/api/admin/spark-connect/test")
async def test_spark_connect(_user: dict = Depends(require_admin)):
    """Run SELECT 1 via a temporary Spark session; return latency_ms."""
    import time
    from core.config import spark_connect as _sc
    if not _sc.enabled:
        raise HTTPException(status_code=400, detail="spark_connect.enabled is false")

    try:
        from pyspark.sql import SparkSession  # type: ignore[import]
    except ImportError:
        raise HTTPException(status_code=503, detail="pyspark is not installed") from None

    try:
        t0 = time.monotonic()
        session = SparkSession.builder.remote(_sc.server_url).appName("qs-admin-test").getOrCreate()
        result = session.sql("SELECT 1 AS ok").collect()
        session.stop()
        latency_ms = round((time.monotonic() - t0) * 1000)
        return {"status": "ok", "latency_ms": latency_ms, "result": str(result)}
    except Exception as exc:
        from core.error_sanitizer import sanitize_error
        raise HTTPException(status_code=503, detail=f"Spark Connect test failed: {sanitize_error(str(exc))}")


@router.put("/api/admin/spark-connect/config")
async def update_spark_connect_config(
    update: SparkConnectConfigUpdate,
    _user: dict = Depends(require_admin),
):
    """Update spark_connect config at runtime. SSRF-validates server_url."""
    from core import config as _c

    if update.server_url is not None:
        # SSRF safety: validate the target host before accepting the URL
        try:
            from core.url_safety import validate_url_safety
            from urllib.parse import urlparse
            parsed = urlparse(update.server_url)
            validate_url_safety(f"http://{parsed.netloc or parsed.path}")
        except ValueError as ssrf_err:
            raise HTTPException(status_code=400, detail=f"SSRF risk: {ssrf_err}")
        _c.set("spark_connect", "server_url", update.server_url)

    if update.enabled is not None:
        _c.set("spark_connect", "enabled", update.enabled)
    if update.row_threshold is not None:
        _c.set("spark_connect", "row_threshold", update.row_threshold)
    if update.timeout_seconds is not None:
        _c.set("spark_connect", "timeout_seconds", update.timeout_seconds)
    if update.max_result_rows is not None:
        _c.set("spark_connect", "max_result_rows", update.max_result_rows)
    if update.session_idle_timeout_minutes is not None:
        _c.set("spark_connect", "session_idle_timeout_minutes", update.session_idle_timeout_minutes)
    if update.max_sessions_per_user is not None:
        _c.set("spark_connect", "max_sessions_per_user", update.max_sessions_per_user)
    if update.max_concurrent_queries is not None:
        _c.set("spark_connect", "max_concurrent_queries", update.max_concurrent_queries)

    return {"status": "updated"}


@router.post("/api/admin/spark-connect/circuit-breaker/reset")
async def reset_spark_connect_circuit_breaker(_user: dict = Depends(require_admin)):
    """Force-close the Spark Connect circuit breaker after server recovery."""
    try:
        from api.execute_api import _get_spark_breaker
        _get_spark_breaker().reset()
        return {"status": "reset", "message": "Spark Connect circuit breaker force-closed"}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


def _spark_breaker_open(_get_spark_breaker) -> bool:
    """Is the Spark circuit breaker open?  False when it cannot be read."""
    try:
        return _get_spark_breaker().is_open
    except Exception:
        return False


def _spark_dry_run_report(sql, sql_hint, tables, rule_result, use_spark,
                          decision_reason, _sc, breaker_open,
                          cross_connection, file_count, row_estimate):
    """Shape the dry-run verdict: what matched, what was decided, what floored it."""
    return {
        "sql_preview":          sql[:300],
        "sql_hint":             sql_hint,
        "tables_extracted":     tables,
        "routing_rule_match":   rule_result.to_dict(),
        "decision": {
            "engine":           "spark" if use_spark else "duckdb",
            "reason":           decision_reason or "all_gates_passed",
        },
        "safety_floors": {
            "spark_connect_enabled":   bool(_sc.enabled) if _sc else False,
            "row_threshold":           int(_sc.row_threshold) if _sc else 0,
            "circuit_breaker_open":    breaker_open,
            "cross_connection_input":  cross_connection,
            "file_count_input":        file_count,
            "row_estimate_input":      row_estimate,
        },
        "notes": [
            "This endpoint does NOT execute the query — only "
            "evaluates the routing decision tree.",
            "Hard safety floors (enabled / S3-only / cross-conn / "
            "circuit breaker) override routing rules.",
            "SQL hints (/*+ spark */ or -- @engine=spark) override "
            "routing rules.  API-body engine_override overrides "
            "everything except hard safety floors.",
        ],
    }


@router.post("/api/admin/spark-connect/dry-run")
async def spark_connect_dry_run(
    body: Dict[str, Any], _user: dict = Depends(require_admin),
):
    """Phase 151 follow-up — paste a SQL string and see exactly where
    it would route + why.  Surfaces:

      * SQL hint detected (if any)
      * Routing rule that matched (if any, with rule name + reason)
      * Final engine + reason as ``_should_use_spark_connect`` would
        emit at execute time
      * Tables extracted from the SQL (so admins can see what the
        rule matcher sees)
      * All safety floors evaluated (enabled, S3, circuit breaker)

    Body: ``{sql: str, file_count?: int, row_estimate?: int,
             cross_connection?: bool}``.  Does NOT execute — pure
    decision diagnostic.
    """
    sql = (body.get("sql") or "").strip()
    if not sql:
        raise HTTPException(status_code=400, detail="'sql' is required")
    file_count = int(body.get("file_count") or 0)
    row_estimate = int(body.get("row_estimate") or 0)
    cross_connection = bool(body.get("cross_connection") or False)

    def _do():
        from core.spark_routing_rules import (
            decide_engine, parse_sql_hint, extract_table_names,
        )
        try:
            from core.config import spark_connect as _sc
        except Exception:
            _sc = None
        try:
            from api.execute_api import (
                _should_use_spark_connect, _get_spark_breaker,
            )
        except Exception as exc:
            raise HTTPException(
                status_code=500,
                detail=f"could not import routing helpers: {exc}",
            )

        sql_hint    = parse_sql_hint(sql)
        tables      = extract_table_names(sql)
        rule_result = decide_engine(
            sql=sql, file_count=file_count, row_estimate=row_estimate,
        )

        # Simulate the _should_use_spark_connect contract.  Pass a
        # sentinel conn_config so we exercise the S3 + cross-conn
        # safety floors without touching a real connection.
        sentinel_conn = {"bucket": "dry-run-sentinel"}
        sim_qcfg = {
            "raw_sql": sql,
            "files":   list(range(file_count)),
            "cross_connection_id": "x" if cross_connection else None,
        }
        use_spark, decision_reason = _should_use_spark_connect(
            engine_override=None,
            conn_config=sentinel_conn,
            estimated_rows=row_estimate,
            query_config_dict=sim_qcfg,
        )

        breaker_open = _spark_breaker_open(_get_spark_breaker)

        return _spark_dry_run_report(
            sql, sql_hint, tables, rule_result, use_spark, decision_reason,
            _sc, breaker_open, cross_connection, file_count, row_estimate)

    return await asyncio.to_thread(_do)


# ── Phase 139 — Iceberg WRITE admin endpoints ─────────────────────────────
# All gated by iceberg_writer.enabled=true in config + require admin role +
# require pyiceberg installed in the runtime image.

class IcebergInsertRequest(BaseModel):
    connection_id:  int
    table_prefix:   str          # S3 prefix of the iceberg table root
    rows:           List[Dict[str, Any]]


class IcebergDeleteRequest(BaseModel):
    connection_id:  int
    table_prefix:   str
    filter:         Dict[str, Any]   # {col, op, val}


class IcebergUpdateRequest(BaseModel):
    connection_id:  int
    table_prefix:   str
    match_filter:   Dict[str, Any]
    new_rows:       List[Dict[str, Any]]


class IcebergCompactRequest(BaseModel):
    connection_id:           int
    table_prefix:            str
    partition_filter:        Optional[Dict[str, Any]] = None
    target_file_size_mb:     int = 256
    # Phase 139 honest-fix #3: Z-order columns for clustering compaction
    zorder_columns:          Optional[List[str]] = None


def _get_iceberg_s3_config(connection_id: int) -> Dict[str, Any]:
    """Resolve a connection_id to an S3 config dict for iceberg_writer."""
    rec = _db_manager.get_connection_raw(connection_id)
    if not rec:
        raise HTTPException(status_code=404, detail=f"Connection {connection_id} not found")
    if rec.get("connection_type") != "s3":
        raise HTTPException(status_code=400,
                            detail=f"Connection {connection_id} is not S3")
    cfg = rec.get("config", {})
    from core.s3_storage import build_s3_config
    s3c = build_s3_config(cfg)
    return {
        "bucket":               s3c.bucket,
        "region":               getattr(s3c, "region", "us-east-1"),
        "aws_access_key_id":    getattr(s3c, "aws_access_key_id", None),
        "aws_secret_access_key": getattr(s3c, "aws_secret_access_key", None),
        "aws_session_token":    getattr(s3c, "aws_session_token", None),
        "endpoint_url":         getattr(s3c, "endpoint_url", None),
    }


@router.post("/api/admin/iceberg/insert")
async def iceberg_insert(req: IcebergInsertRequest,
                         _user: dict = Depends(require_admin)):
    """Append rows to an Iceberg table. Admin-only, requires iceberg_writer.enabled."""
    # BF-NONBLOCK-AUDIT-3: _get_iceberg_s3_config does sync DB read +
    # boto3 setup + STS AssumeRole; insert_rows does sync S3 PUTs +
    # manifest writes (multi-second).  Run the whole body in to_thread.
    def _inner() -> Dict[str, Any]:
        from core.iceberg_writer import insert_rows
        import pyarrow as pa
        s3c = _get_iceberg_s3_config(req.connection_id)
        if not req.rows:
            return {"status": "noop", "rows_appended": 0}
        cols: Dict[str, list] = {}
        for r in req.rows:
            for k, v in r.items():
                cols.setdefault(k, []).append(v)
        arrow_table = pa.table(cols)
        result = insert_rows(s3c, s3c["bucket"], req.table_prefix, arrow_table)
        # BF-263: audit Iceberg data mutation (compliance — privileged write)
        try:
            _u = (_user or {}).get("username", "admin")
            _db_manager.audit(_u, "iceberg_insert", resource_type="iceberg_table",
                              resource_id=req.table_prefix,
                              details={"connection_id": req.connection_id,
                                       "rows_appended": result.get("rows_appended", 0)})
        except Exception as _aud_err:
            logger.warning("audit failed for iceberg_insert: %s", _aud_err)
        return {"status": "ok", **result}
    try:
        return await asyncio.to_thread(_inner)
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/api/admin/iceberg/delete")
async def iceberg_delete(req: IcebergDeleteRequest,
                         _user: dict = Depends(require_admin)):
    """Delete rows from an Iceberg table via equality-delete file (V2 MoR)."""
    # BF-NONBLOCK-AUDIT-3: see iceberg_insert above.
    def _inner() -> Dict[str, Any]:
        from core.iceberg_writer import delete_rows
        s3c = _get_iceberg_s3_config(req.connection_id)
        result = delete_rows(s3c, s3c["bucket"], req.table_prefix, req.filter)
        # BF-263: audit Iceberg data mutation (compliance — privileged delete)
        try:
            _u = (_user or {}).get("username", "admin")
            _db_manager.audit(_u, "iceberg_delete", resource_type="iceberg_table",
                              resource_id=req.table_prefix,
                              details={"connection_id": req.connection_id,
                                       "filter": req.filter})
        except Exception as _aud_err:
            logger.warning("audit failed for iceberg_delete: %s", _aud_err)
        return {"status": "ok", **result}
    try:
        return await asyncio.to_thread(_inner)
    except (RuntimeError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/api/admin/iceberg/update")
async def iceberg_update(req: IcebergUpdateRequest,
                         _user: dict = Depends(require_admin)):
    """Update rows in an Iceberg table (DELETE matching + INSERT new)."""
    # BF-NONBLOCK-AUDIT-3: see iceberg_insert above.
    def _inner() -> Dict[str, Any]:
        from core.iceberg_writer import update_rows
        import pyarrow as pa
        s3c = _get_iceberg_s3_config(req.connection_id)
        if not req.new_rows:
            return {"status": "noop", "rows_updated": 0}
        cols: Dict[str, list] = {}
        for r in req.new_rows:
            for k, v in r.items():
                cols.setdefault(k, []).append(v)
        arrow_table = pa.table(cols)
        result = update_rows(s3c, s3c["bucket"], req.table_prefix,
                             req.match_filter, arrow_table)
        # BF-263: audit Iceberg data mutation (compliance — privileged update)
        try:
            _u = (_user or {}).get("username", "admin")
            _db_manager.audit(_u, "iceberg_update", resource_type="iceberg_table",
                              resource_id=req.table_prefix,
                              details={"connection_id": req.connection_id,
                                       "match_filter": req.match_filter,
                                       "rows_updated": result.get("rows_updated", 0)})
        except Exception as _aud_err:
            logger.warning("audit failed for iceberg_update: %s", _aud_err)
        return {"status": "ok", **result}
    try:
        return await asyncio.to_thread(_inner)
    except (RuntimeError, ValueError) as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/api/admin/iceberg/compact")
async def iceberg_compact(req: IcebergCompactRequest,
                          _user: dict = Depends(require_admin)):
    """Compact small data files in a partition into one file.

    Phase 139 honest-fix #3: when zorder_columns is provided AND
    iceberg_writer.zorder_enabled=true, rows are sorted by Z-order over those
    columns before rewrite. Multi-column range queries scan less data after.
    """
    # BF-NONBLOCK-AUDIT-3: compact_partition rewrites whole partitions —
    # multi-second by design.  Wrap in to_thread so /health stays alive.
    def _inner() -> Dict[str, Any]:
        from core.iceberg_writer import compact_partition
        s3c = _get_iceberg_s3_config(req.connection_id)
        result = compact_partition(
            s3c, s3c["bucket"], req.table_prefix,
            req.partition_filter, req.target_file_size_mb,
            zorder_columns=req.zorder_columns,
        )
        return {"status": "ok", **result}
    try:
        return await asyncio.to_thread(_inner)
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


# ── Phase 139 honest-fix #2 — Iceberg WRITE smoke-test ───────────────────

class IcebergSmokeRequest(BaseModel):
    connection_id:  int
    table_prefix:   str   # MUST be a NEW or test-only table — this writes data!


def _smoke_check_pyiceberg(_add) -> bool:
    """Step 1 — is pyiceberg importable at all?"""
    try:
        import pyiceberg  # noqa: F401
        from pyiceberg import __version__ as pyi_version
        _add("pyiceberg_installed", "ok", f"pyiceberg {pyi_version} loaded")
        return True
    except ImportError:
        _add("pyiceberg_installed", "error",
             "pyiceberg not installed. pip install 'pyiceberg[s3fs,pyarrow]>=0.7.0'")
        return False


def _smoke_check_writer_enabled(_add) -> bool:
    """Step 2 — is the iceberg_writer.enabled config gate open?"""
    try:
        from core.iceberg_writer import is_writer_enabled
        if not is_writer_enabled():
            _add("writer_enabled", "error",
                 "iceberg_writer.enabled=false in config. Set to true and restart.")
            return False
        _add("writer_enabled", "ok", "iceberg_writer.enabled=true")
        return True
    except Exception as exc:
        _add("writer_enabled", "error", f"Config check failed: {exc}")
        return False


def _smoke_build_catalog(_add, connection_id):
    """Step 3 — build the SqlCatalog.  Returns ``(ok, catalog, s3_config)``.

    Building it proves the S3 credentials resolve and the endpoint answers.
    """
    try:
        s3c = _get_iceberg_s3_config(connection_id)
        from core.iceberg_writer import _build_catalog
        cat = _build_catalog(s3c)
        _add("catalog_init", "ok",
             f"SqlCatalog initialised (warehouse=s3://{s3c['bucket']}/)")
        return True, cat, s3c
    except Exception as exc:
        _add("catalog_init", "error", f"SqlCatalog init failed: {exc}")
        return False, None, None


def _smoke_load_table(_add, cat, s3c, table_prefix):
    """Step 4 — load (or register) the target table.  Returns ``(ok, table)``.

    Success confirms metadata.json exists and is parseable.
    """
    try:
        from core.iceberg_writer import _load_or_register_table, _table_identifier
        ident = ".".join(_table_identifier(table_prefix))
        table = _load_or_register_table(cat, s3c, s3c["bucket"], table_prefix)
        _add("table_load", "ok",
             f"Table {ident} loaded (current snapshot {table.current_snapshot().snapshot_id if table.current_snapshot() else 'NONE'})")
        return True, table
    except Exception as exc:
        _add("table_load", "error",
             f"Table load failed: {exc}. Hint: create the table first via Spark/PyIceberg.")
        return False, None


def _smoke_row_value(pa, field, i: int, marker: str):
    """One synthetic cell, typed to match the table's own arrow field."""
    if pa.types.is_string(field.type):
        return marker
    if pa.types.is_integer(field.type):
        return i
    if pa.types.is_floating(field.type):
        return float(i)
    if pa.types.is_boolean(field.type):
        return (i % 2 == 0)
    if pa.types.is_timestamp(field.type):
        return datetime.now(timezone.utc)
    return None


def _smoke_build_arrow_table(pa, table, marker: str):
    """Five synthetic rows shaped to the table's own arrow schema."""
    schema = table.schema().as_arrow()
    field_names = schema.names  # noqa: F841 — schema access is part of the probe
    rows = []
    for i in range(5):
        row = {}
        for f in schema:
            row[f.name] = _smoke_row_value(pa, f, i, marker)
        rows.append(row)
    return pa.Table.from_pylist(rows, schema=schema)


def _smoke_insert(_add, table) -> str:
    """Step 5 — append five synthetic rows.  Returns 'ok' or 'partial'."""
    try:
        import pyarrow as pa
        marker = f"__qs_smoke_{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
        try:
            arrow_table = _smoke_build_arrow_table(pa, table, marker)
        except Exception as schema_err:
            _add("insert", "warning",
                 f"Schema synthesis fallback: {schema_err}. Try insert with custom rows via /api/admin/iceberg/insert.")
            return "partial"

        snap_before = table.current_snapshot().snapshot_id if table.current_snapshot() else None
        table.append(arrow_table)
        snap_after = table.current_snapshot().snapshot_id if table.current_snapshot() else None
        _add("insert", "ok",
             f"Inserted 5 rows. Snapshot {snap_before} → {snap_after}.")
        return "ok"
    except Exception as exc:
        _add("insert", "error", f"Insert failed: {exc}")
        return "partial"


def _smoke_read_back(_add, s3c, table_prefix) -> None:
    """Step 6 — confirm QueryStudio's own reader now sees the written files."""
    try:
        from core.iceberg_reader import get_iceberg_data_files
        from core.s3_utilities import make_s3_client_for_config
        s3 = make_s3_client_for_config(s3c)
        files_after = get_iceberg_data_files(s3, s3c["bucket"], table_prefix,
                                              keys_only=True, force_fresh=True)
        _add("read_back", "ok",
             f"Reader sees {len(files_after)} data files after insert.")
    except Exception as exc:
        _add("read_back", "warning", f"Read-back via QueryStudio reader failed: {exc}")


def _iceberg_smoke_run(connection_id: int, table_prefix: str) -> Dict[str, Any]:
    """Run the Iceberg writer round-trip, stopping at the first broken step."""
    steps: List[Dict[str, Any]] = []

    def _add(name: str, status: str, msg: str, detail: Any = None):
        entry = {"step": name, "status": status, "message": msg}
        if detail is not None:
            entry["detail"] = detail
        steps.append(entry)

    # 1. pyiceberg installed?
    if not _smoke_check_pyiceberg(_add):
        return {"overall_status": "fail", "steps": steps}

    # 2. iceberg_writer.enabled?
    if not _smoke_check_writer_enabled(_add):
        return {"overall_status": "fail", "steps": steps}

    # 3. Build catalog
    _cat_ok, cat, s3c = _smoke_build_catalog(_add, connection_id)
    if not _cat_ok:
        return {"overall_status": "fail", "steps": steps}

    # 4. Load or register table
    _tbl_ok, table = _smoke_load_table(_add, cat, s3c, table_prefix)
    if not _tbl_ok:
        return {"overall_status": "fail", "steps": steps}

    # 5. INSERT smoke rows
    if _smoke_insert(_add, table) != "ok":
        return {"overall_status": "partial", "steps": steps}

    # 6. Read back via QueryStudio's reader
    _smoke_read_back(_add, s3c, table_prefix)

    return {"overall_status": "ok", "steps": steps,
            "note": "Smoke test inserted 5 rows. To roll back, run /api/admin/iceberg/delete with a filter on the marker column."}


@router.post("/api/admin/iceberg/smoke-test")
async def iceberg_smoke_test(req: IcebergSmokeRequest,
                             _user: dict = Depends(require_admin)):
    """Round-trip smoke test for the Iceberg writer.

    Step-by-step diagnostic that runs in production without external test
    rigging:
      1. Verify pyiceberg installed
      2. Verify iceberg_writer.enabled config gate
      3. Build SqlCatalog (verifies S3 credentials + endpoint reachable)
      4. Load (or attempt to load) the target table — confirms metadata.json
         exists and is parseable
      5. INSERT 5 synthetic test rows
      6. Read back via the standard Iceberg reader; verify row count matches
      7. Optional: DELETE the synthetic rows (V2 equality-delete)

    Each step's outcome is reported with a status (ok / warning / error) and
    a short message. Designed to be the FIRST thing an admin runs after
    deploying iceberg_writer.enabled=true.

    SAFETY: this endpoint WRITES rows. Use a TEST table prefix — do NOT
    point it at production data.
    """
    # BF-NONBLOCK-AUDIT-3: this endpoint chains S3/STS + pyiceberg
    # catalog init + table load + write + read-back — every step is
    # sync and any single one can stall on a slow STS.  Run the entire
    # multi-step diagnostic off the event loop in a worker thread.
    return await asyncio.to_thread(_iceberg_smoke_run,
                                   req.connection_id, req.table_prefix)


# ═══════════════════════════════════════════════════════════════════
# BF-COL-STATS — column-statistics supplement admin endpoints
# ═══════════════════════════════════════════════════════════════════

# 2026-06-03 — DEAD ROUTE REMOVED.  The handler that previously sat
# here was a duplicate of /api/admin/iceberg/column-stats/status
# defined again at line ~9730.  FastAPI registers both but the LAST
# wins for routing, so the earlier (sync DB session) handler was
# never actually called.  Removed entirely to avoid the audit
# confusion + the dead-code maintenance cost.  The live handler is
# the cached single-flight version at line ~9730.


def _capped_max_workers(body: dict, default_key: str, cap_key: str,
                        default_workers: int, cap_workers: int) -> int:
    """Resolve a scan's worker count: request override, bounded by config.

    Both the default and the ceiling come from the ``iceberg`` config section
    so admins/agents can tune without code edits; a request may lower the
    count but never raise it above the cap.
    """
    try:
        from core.config import get as _cfg_get
        _default_workers = int(_cfg_get("iceberg", default_key, default_workers)
                               or default_workers)
        _max_workers_cap = int(_cfg_get("iceberg", cap_key, cap_workers)
                               or cap_workers)
    except Exception:
        _default_workers, _max_workers_cap = default_workers, cap_workers
    return max(1, min(
        int(body.get("max_workers") or _default_workers),
        _max_workers_cap,
    ))


async def _resolve_registered_iceberg_table(cid, tbl, s3_only_detail: str,
                                            iceberg_only_detail: str):
    """Resolve ``(conn, bucket, s3_prefix)`` for a registered Iceberg table.

    Refuses with the CALLER's wording on the two feature-specific checks, so
    an admin reading the error still learns which tool turned them away.
    """
    conn = await _adb(_db_manager.get_connection_raw, cid)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn.get("connection_type") != "s3":
        raise HTTPException(status_code=400, detail=s3_only_detail)
    cfg = conn.get("config", {})
    bucket = cfg.get("bucket_name")
    if not bucket:
        raise HTTPException(status_code=400, detail="Connection has no bucket")
    rt = next((t for t in cfg.get("registered_tables", []) if t.get("name") == tbl), None)
    if not rt:
        raise HTTPException(status_code=404, detail=f"Table '{tbl}' not registered")
    if rt.get("format") != "iceberg":
        raise HTTPException(status_code=400, detail=iceberg_only_detail)
    return conn, bucket, rt.get("s3_prefix", "")


def _col_stats_force_clear(bucket: str, norm_prefix: str, snap) -> None:
    """Drop this snapshot's supplement rows so a forced re-scan rewrites them.

    BF-COL-STATS-V2: clear by bucket+prefix (shared identity), not
    connection_id — otherwise re-scanning here wouldn't clear rows
    populated by the OTHER connection on the same S3 location.
    """
    try:
        _db_manager.iceberg_col_stats_clear(
            bucket=bucket, table_prefix=norm_prefix,
            snapshot_id=str(snap),
        )
    except Exception:
        pass


def _col_stats_record_tick(result, elapsed_seconds: float) -> None:
    """Feed a manual scan into the supplement backpressure ring.

    2026-06-10 audit follow-up — admin-triggered scans also
    feed the supplement backpressure ring so coordinator
    pressure is observed from MANUAL scans on slow S3 too,
    not just the cron path.  Previously the ring only saw
    reconcile_table's per-table-rule loop, leaving manual
    scans invisible to the pressure flag.
    """
    try:
        from core.iceberg_metadata_sync import record_col_stats_tick
        _scanned = int((result or {}).get("scanned") or 0)
        record_col_stats_tick(
            files_scanned   = _scanned,
            elapsed_seconds = elapsed_seconds,
        )
    except Exception:
        pass


def _scan_snapshot_unresolved_detail(out_meta: dict, tbl, cid, terse: bool) -> str:
    """Say WHY a table's current snapshot could not be resolved.

    2026-06-03 — user feedback: status was showing "done"
    with 0/N files scanned and no actionable error.  Raise
    with the cache diagnostic so admins see WHY the snapshot
    couldn't be resolved (cache empty + S3 read failure /
    bucket typo / no current snapshot).
    """
    cd = out_meta.get("iceberg_cache_diagnostic") or {}
    mrf = out_meta.get("manifest_read_failures") or 0
    gap = " " if terse else "  "
    head = (
        f"Could not resolve snapshot for table '{tbl}' on "
        f"connection {cid}.{gap}Cache state: "
        f"{cd.get('cache_state', 'unknown')}, "
        f"manifest reads attempted={cd.get('manifests_attempted', 0)} "
        f"failed={mrf}."
    )
    if terse:
        return head
    return head + (
        "  Either the iceberg cache is empty AND "
        "S3 manifest reads failed (check proxy / VPC endpoint / "
        "credentials), OR the table has no current snapshot "
        "(check writer commit state)."
    )


def _column_stats_scan_run(conn, bucket, s3_prefix, cid, tbl, cols,
                           force: bool, max_workers: int, job_id: str):
    """Read every parquet footer in the latest snapshot into the supplement."""
    from core.s3_utilities import make_s3_client_for_conn
    from core.iceberg_reader import get_iceberg_data_files
    from core.iceberg_column_stats import (
        scan_files_to_supplement,
        progress_register, progress_update, progress_finish,
    )

    s3 = make_s3_client_for_conn(conn)
    out_meta: Dict[str, Any] = {}
    files = get_iceberg_data_files(
        s3, bucket, s3_prefix,
        partition_filters=None, keys_only=True,
        force_fresh=False,
        _out_meta=out_meta,
    )
    snap = out_meta.get("snapshot_id")
    if not snap:
        raise HTTPException(
            status_code=502,
            detail=_scan_snapshot_unresolved_detail(out_meta, tbl, cid, terse=False),
        )
    file_keys = [f.get("key") for f in files if f.get("key")]
    _norm_prefix = (s3_prefix or "").rstrip("/")

    if force:
        _col_stats_force_clear(bucket, _norm_prefix, snap)

    progress_register(
        job_id, connection_id=cid, table_name=tbl,
        total=len(file_keys), bucket=bucket, table_prefix=_norm_prefix,
        target_columns=cols,
    )
    def _pf(done, total, scanned=0, skipped=0, failed=0):
        progress_update(job_id, done=done, scanned=scanned,
                        skipped=skipped, failed=failed)
    try:
        import time as _time_mod
        _scan_t0 = _time_mod.monotonic()
        result = scan_files_to_supplement(
            db_manager=_db_manager,
            s3_client=s3,
            bucket=bucket,
            table_prefix=_norm_prefix,
            snapshot_id=str(snap),
            file_keys=file_keys,
            target_columns=cols,
            max_workers=max_workers,
            skip_already_scanned=not force,
            connection_id=cid,        # telemetry
            table_name=tbl,           # telemetry
            progress_fn=_pf,
        )
        _col_stats_record_tick(result, _time_mod.monotonic() - _scan_t0)
        progress_finish(job_id, status="done", summary=result)
    except Exception as exc:
        progress_finish(job_id, status="error", error=str(exc)[:300])
        raise
    result["snapshot_id"] = str(snap)
    result["files_total"] = len(file_keys)
    result["job_id"] = job_id
    return result


@router.post("/api/admin/iceberg/column-stats/scan")
async def iceberg_column_stats_scan(body: Dict[str, Any], _user: dict = Depends(require_admin)):
    """Trigger a one-time column-stats supplement scan for a table.

    Body: {
      connection_id: int,
      table_name:    str,                # registered table name
      columns:       Optional[List[str]] # only scan these (default: all)
      max_workers:   Optional[int]       # default 32
      force:         Optional[bool]      # re-scan even if already cached
    }

    Each parquet file in the latest snapshot is read for footer-only
    column min/max/null/row stats.  Idempotent: existing rows for the
    same (connection, table, snapshot, file, column) are updated rather
    than duplicated.

    Returns: {scanned, skipped, failed, rows_inserted, elapsed_seconds,
             files_per_second, snapshot_id}.
    """
    cid = body.get("connection_id")
    tbl = body.get("table_name")
    if not cid or not tbl:
        raise HTTPException(status_code=400,
                              detail="connection_id and table_name required")
    cols = body.get("columns") or None
    # Cap max_workers to prevent thread/connection exhaustion when admin
    # types a very large value.  S3 default conn pool is 50; >128 causes
    # boto3 connection-pool warnings at high concurrency.
    # Default + cap pulled from config so admins/agents can tune without
    # code edits.  iceberg.column_stats_sync_workers (default 32) sets
    # the default; iceberg.column_stats_max_workers_cap (default 128)
    # bounds how high a per-request override can go.
    max_workers = _capped_max_workers(
        body, "column_stats_sync_workers", "column_stats_max_workers_cap",
        32, 128)
    force = bool(body.get("force", False))

    conn, bucket, s3_prefix = await _resolve_registered_iceberg_table(
        cid, tbl,
        "Column-stats supplement only applies to S3 Iceberg connections",
        "Supplement is Iceberg-only")

    job_id = f"scan-{cid}-{tbl}-{uuid.uuid4().hex[:8]}"

    def _do():
        return _column_stats_scan_run(conn, bucket, s3_prefix, cid, tbl,
                                      cols, force, max_workers, job_id)

    return await asyncio.to_thread(_do)


# ─── Phase 149.4 / 149.7: bloom sidecar scan ─────────────────────────────


@router.post("/api/admin/iceberg/bloom/scan-now")
async def iceberg_bloom_scan_now(
    body: Optional[Dict[str, Any]] = None,
    _user: dict = Depends(require_admin),
):
    """2026-06-24 -- one-click admin trigger that fires the adaptive
    prefetch tick IMMEDIATELY instead of waiting for the next hourly
    APScheduler interval.

    Operator pushback: "how to start bloom filter job?dont see any
    background job".  The adaptive prefetcher has been running every
    hour all along (registered with APScheduler at startup, also
    visible in the background_jobs registry as 'adaptive_prefetch'
    since 2026-06-24), but admins had no way to FORCE a tick right
    now without restarting pods.

    Body (all optional):
      max_targets:    Optional[int]   default 50 (cap on # tables to scan)

    Returns the same shape as a scheduled tick:
      {summary: {...}, plan: {targets: [...]}, elapsed_seconds: float}

    Note: this kicks off the SAME tick the scheduler runs.  It auto-
    selects (table, column) pairs based on query_pruning_history --
    the operator does NOT pick columns.  Use POST /bloom/scan (the
    other endpoint) for targeted single-table scans.
    """
    from core.query_history_prefetcher import (
        prefetch_daemon_tick, make_default_s3_client_factory,
    )
    _factory = make_default_s3_client_factory(_db_manager)
    body = body or {}

    def _do():
        import time as _t
        _t0 = _t.monotonic()
        result = prefetch_daemon_tick(_db_manager, _factory)
        result["elapsed_seconds"] = round(_t.monotonic() - _t0, 2)
        # Operator-readable summary lifted to the top level so the UI
        # doesn't have to dig.
        summary = result.get("summary") or {}
        targets = (result.get("plan") or {}).get("targets") or []
        result["targets_scanned"] = len(targets)
        result["bloom_jobs_fired"] = summary.get("bloom_jobs_fired", 0)
        result["supplement_jobs_fired"] = summary.get(
            "supplement_jobs_fired", 0,
        )
        return result

    return await asyncio.to_thread(_do)


@router.post("/api/admin/iceberg/bloom/scan")
async def iceberg_bloom_scan(body: Dict[str, Any], _user: dict = Depends(require_admin)):
    """Phase 149.7 — trigger a bloom-filter sidecar scan for one table.

    Body: {
      connection_id: int,
      table_name:    str,                   # registered table name
      columns:       List[str],             # REQUIRED — bloom only makes
                                            # sense for specific sparse-eq
                                            # columns; scanning all cols is
                                            # heavy (full column read each).
      max_workers:   Optional[int],         # default 8 (bloom is heavier
                                            # per file than supplement
                                            # footer reads)
      force:         Optional[bool],        # re-scan even if (file, col)
                                            # rows already exist
      target_fp_rate: Optional[float],      # default 0.01 (1%)
    }

    Each parquet file in the latest snapshot is read for the target
    column-chunk values, hashed into a bloom filter, and upserted to
    iceberg_bloom_sidecar_v1.  Idempotent: existing rows for the same
    (bucket, prefix, snapshot, file, column) are updated rather than
    duplicated.  ``force=true`` clears matching rows before scanning.

    Returns the same shape as /column-stats/scan:
      {scanned, skipped, failed, rows_inserted, elapsed_seconds,
       files_per_second, snapshot_id, files_total, job_id,
       failure_categories}.

    Once rows exist in iceberg_bloom_sidecar_v1, every subsequent query
    on this (bucket, prefix) with an equality / IN filter on a scanned
    column gets sparse-eq pruning automatically (see iceberg_reader.py
    149.4 block).  No client / config change needed.
    """
    cid = body.get("connection_id")
    tbl = body.get("table_name")
    if not cid or not tbl:
        raise HTTPException(status_code=400,
                              detail="connection_id and table_name required")
    cols = body.get("columns") or []
    # Bloom REQUIRES target_columns — scanning all cols is too heavy.
    if not isinstance(cols, list) or not cols:
        raise HTTPException(
            status_code=400,
            detail=("'columns' is required for bloom scan (non-empty list "
                    "of equality-filter column names).  Bloom extraction "
                    "reads the entire column-chunk per file — scanning "
                    "every column would be prohibitively expensive."),
        )
    # Config-driven default + cap (mirrors column-stats pattern).  Bloom
    # default is 8 (vs 32 for supplement) because each worker reads a
    # full column chunk, not just the footer.
    max_workers = _capped_max_workers(
        body, "bloom_scan_workers", "bloom_scan_max_workers_cap", 8, 32)
    force = bool(body.get("force", False))
    target_fp_rate = float(body.get("target_fp_rate") or 0.01)
    if not (0.0 < target_fp_rate < 1.0):
        target_fp_rate = 0.01

    conn, bucket, s3_prefix = await _resolve_registered_iceberg_table(
        cid, tbl,
        "Bloom sidecar only applies to S3 Iceberg connections",
        "Bloom sidecar is Iceberg-only")

    job_id = f"bloom-{cid}-{tbl}-{uuid.uuid4().hex[:8]}"

    def _do():
        return _bloom_scan_run(conn, bucket, s3_prefix, cid, tbl, cols,
                               force, max_workers, target_fp_rate, job_id)

    return await asyncio.to_thread(_do)


def _bloom_force_clear(bucket: str, norm_prefix: str) -> None:
    """Clear existing bloom rows for this (bucket, prefix) so the
    re-scan creates fresh ones.

    Best-effort delete via raw SQL since we don't have a dedicated helper yet.
    """
    try:
        from core.db.models import IcebergBloomSidecar
        with _db_manager.get_session() as session:
            session.query(IcebergBloomSidecar).filter(
                IcebergBloomSidecar.bucket == bucket,
                prefix_matches(IcebergBloomSidecar.table_prefix, norm_prefix),
            ).delete(synchronize_session=False)
    except Exception as _del_exc:
        logger.debug("[bloom] force-clear failed: %s", _del_exc)


def _bloom_scan_run(conn, bucket, s3_prefix, cid, tbl, cols, force: bool,
                    max_workers: int, target_fp_rate: float, job_id: str):
    """Hash each file's target column-chunks into the bloom sidecar."""
    from core.s3_utilities import make_s3_client_for_conn
    from core.iceberg_reader import get_iceberg_data_files
    from core.iceberg_bloom_sidecar import scan_files_for_bloom
    # Reuse the column-stats progress registry — same UI surface
    # already polls /api/admin/iceberg/column-stats/scan-progress
    # so the bloom job will appear there too.  job_id prefix
    # "bloom-..." lets admins filter visually.
    from core.iceberg_column_stats import (
        progress_register, progress_update, progress_finish,
        _new_cancel_event, _drop_cancel_event,
    )

    s3 = make_s3_client_for_conn(conn)
    out_meta: Dict[str, Any] = {}
    files = get_iceberg_data_files(
        s3, bucket, s3_prefix,
        partition_filters=None, keys_only=True,
        force_fresh=False,
        _out_meta=out_meta,
    )
    snap = out_meta.get("snapshot_id")
    if not snap:
        raise HTTPException(
            status_code=502,
            detail=_scan_snapshot_unresolved_detail(out_meta, tbl, cid, terse=True),
        )
    file_keys = [f.get("key") for f in files if f.get("key")]
    _norm_prefix = (s3_prefix or "").rstrip("/")

    if force:
        _bloom_force_clear(bucket, _norm_prefix)

    progress_register(
        job_id, connection_id=cid, table_name=tbl,
        total=len(file_keys), bucket=bucket, table_prefix=_norm_prefix,
        target_columns=cols,
    )
    # 149-fix-4: register a cancel event so admins can stop a
    # long-running bloom scan via the existing
    # /api/admin/iceberg/column-stats/cancel endpoint (the bloom
    # job lives in the same _CANCEL_FLAGS registry).  Without this
    # admins could trigger but couldn't stop — N-hour scans were
    # uninterruptible.
    cancel_ev = _new_cancel_event(job_id)
    def _pf(done, total, scanned=0, skipped=0, failed=0):
        progress_update(job_id, done=done, scanned=scanned,
                        skipped=skipped, failed=failed)
    try:
        result = scan_files_for_bloom(
            db_manager=_db_manager,
            s3_client=s3,
            bucket=bucket,
            table_prefix=_norm_prefix,
            snapshot_id=str(snap),
            file_keys=file_keys,
            target_columns=cols,
            max_workers=max_workers,
            skip_already_scanned=not force,
            connection_id=cid,
            table_name=tbl,
            progress_fn=_pf,
            target_fp_rate=target_fp_rate,
            cancel_event=cancel_ev,
        )
        progress_finish(job_id, status="done", summary=result)
    except Exception as exc:
        progress_finish(job_id, status="error", error=str(exc)[:300])
        raise
    finally:
        _drop_cancel_event(job_id)
    result["snapshot_id"] = str(snap)
    result["files_total"] = len(file_keys)
    result["job_id"]      = job_id
    return result


# ─── Phase 149.9: adaptive-prefetch daemon status + force-run ─────────────


@router.get("/api/admin/iceberg/prefetch/status")
async def iceberg_prefetch_status(_user: dict = Depends(require_admin)):
    """Phase 149.9 — return everything the admin UI needs to see what
    the adaptive prefetch daemon is doing without log-grepping.

    Returns:
      {
        enabled, interval_hours, lookback_hours, top_n,
        max_files_per_target, daily_budget_bytes, dry_run,
        next_run_at, job_registered,
        recent_ticks: [
          {started_at, elapsed_s, targets_total, enqueued,
           supplement_jobs, bloom_jobs, skipped_budget, skipped_dry_run,
           errors, targets_preview: [{bucket, table_prefix, column,
                                       occurrence_count, needs_supplement,
                                       needs_bloom, reason}, ...]},
          ...
        ]
      }

    Recent ticks are an in-memory ring per pod (max 50, newest first) —
    survives across ticks but is lost on restart.  Operators primarily
    want "what did the LAST few runs do?" which the in-memory shape
    covers cheaply.
    """
    # 2026-10-07 -- answered by the process that RUNS the prefetcher (the
    # scheduler worker in external mode); see core/daemon_snapshots.py.
    from core.daemon_snapshots import daemon_snapshot
    snap = await daemon_snapshot("adaptive_prefetch.status",
                                 proxy=_scheduler_worker_proxy)
    out = dict(snap["data"] or {})
    out["answered_by"] = snap["answered_by"]
    if snap.get("warning"):
        out["warning"] = snap["warning"]
    return out


@router.get("/api/admin/iceberg/freshness")
async def iceberg_freshness(_user: dict = Depends(require_admin)):
    """Phase 149.10 — per-(bucket, prefix) brain freshness ledger.

    Returns:
      {
        ledger: [ { bucket, table_prefix, current_snapshot,
                    last_scanned_snapshot, snapshot_in_sync,
                    cols_covered, last_scan_at, last_check_at,
                    last_check_source, last_action, last_error }, ... ],
        recent_events: [ { at, bucket, table_prefix, source, action,
                            reason, current_snapshot,
                            last_scanned_snapshot, error }, ... ]
      }

    Surfaced in the Adaptive Prefetch Daemon panel under Query
    Diagnostic so admins can see per-table snapshot lag at a glance
    + the live event log of recent freshness decisions across all
    three triggers (cron / watcher / lazy / manual).
    """
    from core.brain_freshness import list_ledger, get_recent_events
    return {
        "ledger":         list_ledger(limit=200),
        "recent_events":  get_recent_events(limit=50),
    }


@router.post("/api/admin/iceberg/freshness/refresh")
async def iceberg_freshness_refresh(
    body: Dict[str, Any],
    _user: dict = Depends(require_admin),
):
    """Phase 149.10 — force-refresh ONE (bucket, prefix).  Useful when
    admin sees a stale-snapshot chip and wants to dispatch immediately
    rather than wait for the next cron / lazy / watcher fire.

    Body: { bucket: str, table_prefix: str, blocking?: bool }

    Returns the ensure_fresh decision: ``{action, current_snapshot,
    last_scanned_snapshot, error}``.
    """
    bucket = (body or {}).get("bucket") or ""
    prefix = (body or {}).get("table_prefix") or ""
    blocking = bool((body or {}).get("blocking", False))
    if not bucket or not prefix:
        raise HTTPException(
            status_code=400,
            detail="bucket and table_prefix required",
        )

    def _do():
        from core.brain_freshness import ensure_fresh
        from core.query_history_prefetcher import make_default_s3_client_factory
        factory = make_default_s3_client_factory(_db_manager)
        return ensure_fresh(
            _db_manager, factory, bucket, prefix,
            source="manual", blocking=blocking,
        )

    return await asyncio.to_thread(_do)


# ─── 2026-07-15  "Pruning Brain" diagnostics (read-only, admin-only) ──────
#
# Surface what the pruning brain has LEARNED across three small brain
# stores so an admin can SEE it and ACT on it (build a bloom, distrust a
# lying version-hint).  All three endpoints are:
#   * additive + backward-compatible
#   * behind require_admin
#   * fail-soft — any DB error returns an empty collection, never 500
#   * NEVER consulted by the query / pruning path (diagnostics only) — so
#     they cannot change any keep/drop verdict.

# A column whose min/max bounds overlap the queried value in this fraction
# (or more) of files can't be pruned by bounds — a bloom would help.
_BRAIN_NEEDS_BLOOM_OVERLAP = 0.5
# ...but only worth building when the column is reasonably covered by stats
# (otherwise bounds coverage, not the column, is the problem).
_BRAIN_NEEDS_BLOOM_MIN_COVERAGE = 0.25


def _brain_needs_bloom(row: Dict[str, Any], bloom_present: bool) -> bool:
    """True when accumulated prunability evidence says min/max bounds
    are useless for this column (high overlap, well-covered, not already
    singleton-clustered) AND no bloom sidecar exists for it yet."""
    if bloom_present:
        return False
    try:
        overlap  = float(row.get("bounds_overlap_ratio") or 0.0)
        coverage = float(row.get("stats_coverage_pct") or 0.0)
        singleton = float(row.get("singleton_ratio") or 0.0)
    except (TypeError, ValueError):
        return False
    return (overlap >= _BRAIN_NEEDS_BLOOM_OVERLAP
            and coverage >= _BRAIN_NEEDS_BLOOM_MIN_COVERAGE
            and singleton < 0.5)


async def _prunability_bloom_map(bucket: str, prefix: str) -> Dict[str, dict]:
    """Which columns already have a bloom sidecar; {} when unreadable."""
    try:
        return await _adb(
            _db_manager.iceberg_bloom_columns_present, bucket, prefix,
        ) or {}
    except Exception:
        return {}


async def _prunability_rows(rows, bloom_for):
    """Annotate every profile row; returns ``(rows, needs_bloom_count)``."""
    out: List[Dict[str, Any]] = []
    needs = 0
    for r in rows:
        try:
            enriched, nb = await _prunability_enriched_row(r, bloom_for)
            if nb:
                needs += 1
            out.append(enriched)
        except Exception:
            # never let one malformed row 500 the panel
            out.append(dict(r))
    return out, needs


async def _prunability_enriched_row(r: dict, bloom_for):
    """Annotate one prunability profile with its bloom state.

    Returns ``(row, needs_bloom)``.  Raises on a malformed row so the caller
    can fall back to the raw row rather than 500 the whole panel.
    """
    bkt = r.get("bucket") or ""
    pfx = (r.get("table_prefix") or "").rstrip("/")
    col = (r.get("column_name") or "").lower()
    bloom_map = await bloom_for(bkt, pfx)
    present = bloom_map.get(col)
    nb = _brain_needs_bloom(r, present is not None)
    enriched = dict(r)
    enriched["needs_bloom"] = nb
    enriched["bloom_file_count"] = int(
        (present or {}).get("file_count") or 0)
    return enriched, nb


@router.get("/api/admin/brain/prunability")
async def brain_prunability(
    bucket: Optional[str] = None,
    table_prefix: Optional[str] = None,
    limit: int = Query(200, ge=1, le=2000),
    _user: dict = Depends(require_admin),
):
    """2026-07-15 — what the brain learned about which COLUMNS can be
    pruned by min/max bounds.  Each row is a per-(bucket, table_prefix,
    column) prunability profile accumulated from real queries at zero
    extra S3 I/O, annotated with a computed ``needs_bloom`` flag:
    high bounds-overlap + decent stats coverage + no bloom sidecar yet
    == this column would benefit from a bloom sidecar build.

    Query params (all optional):
      bucket, table_prefix   — narrow to one table; unfiltered otherwise
      limit (1-2000, def 200)

    Returns: {rows: [{bucket, table_prefix, column_name,
      stats_coverage_pct, bounds_overlap_ratio, singleton_ratio,
      ndv_estimate, sample_count, updated_at, needs_bloom,
      bloom_file_count}], total, needs_bloom_count}.

    Fail-soft: {rows: [], total: 0, needs_bloom_count: 0} on any error.
    """
    _pfx = table_prefix.rstrip("/") if table_prefix else None
    try:
        rows = await _adb(
            _db_manager.iceberg_prunability_list, bucket, _pfx, limit,
        ) or []
    except Exception:
        return {"rows": [], "total": 0, "needs_bloom_count": 0}

    # One bloom-presence lookup per distinct (bucket, prefix) in the page.
    bloom_cache: Dict[Tuple[str, str], Dict[str, dict]] = {}

    async def _bloom_for(bkt: str, pfx: str) -> Dict[str, dict]:
        key = (bkt or "", (pfx or "").rstrip("/"))
        if key not in bloom_cache:
            bloom_cache[key] = await _prunability_bloom_map(key[0], key[1])
        return bloom_cache[key]

    out, needs = await _prunability_rows(rows, _bloom_for)
    return {"rows": out, "total": len(out), "needs_bloom_count": needs}


@router.get("/api/admin/brain/freshness-reliability")
async def brain_freshness_reliability(
    limit: int = Query(200, ge=1, le=2000),
    _user: dict = Depends(require_admin),
):
    """2026-07-15 — which tables' snapshot freshness the brain has
    learned to DISTRUST.  Per-(bucket, table_prefix) reliability record:
    ``hint_lied_count`` = how many times the resolved metadata pointer
    (version-hint.text / cache) disagreed with the newest metadata.json
    found by a capped LIST (once > 0 the table is cross-checked
    permanently); ``last_lied_at`` / ``last_anomaly_at`` timestamps.

    Returns: {rows: [{bucket, table_prefix, hint_lied_count, last_lied_at,
      last_anomaly_at, updated_at}], total}.  Fail-soft: {rows: [],
      total: 0}.
    """
    try:
        rows = await _adb(_db_manager.iceberg_freshness_list, limit) or []
    except Exception:
        rows = []
    return {"rows": rows, "total": len(rows)}


def _bloom_coverage_status(profile_row: dict, present) -> str:
    """Classify one column: bloom already built / needed / not worth it."""
    if present is not None:
        return "built"
    if _brain_needs_bloom(profile_row, False):
        return "needed"
    return "ok"


def _bloom_coverage_profile_rows(prof_rows, bloom_map):
    """Coverage rows for columns that HAVE a prunability profile.

    Returns ``(rows, built, needed, seen)`` — ``seen`` lets the caller add the
    columns that have a bloom but no profile without double-counting.
    """
    rows: List[Dict[str, Any]] = []
    built = needed = 0
    seen: set = set()
    for r in prof_rows:
        col = (r.get("column_name") or "").lower()
        if not col or col in seen:
            continue
        seen.add(col)
        present = bloom_map.get(col)
        status = _bloom_coverage_status(r, present)
        if status == "built":
            built += 1
        elif status == "needed":
            needed += 1
        rows.append({
            "column_name":          col,
            "status":               status,
            "bloom_file_count":     int((present or {}).get("file_count") or 0),
            "bounds_overlap_ratio": r.get("bounds_overlap_ratio"),
            "stats_coverage_pct":   r.get("stats_coverage_pct"),
            "singleton_ratio":      r.get("singleton_ratio"),
            "sample_count":         r.get("sample_count"),
            "last_scanned":         (present or {}).get("last_scanned"),
            "table_name":           (present or {}).get("table_name"),
        })
    return rows, built, needed, seen


def _bloom_coverage_orphan_row(col: str, present) -> Dict[str, Any]:
    """A column with a bloom but NO prunability profile — still 'built'."""
    return {
        "column_name":          col,
        "status":               "built",
        "bloom_file_count":     int((present or {}).get("file_count") or 0),
        "bounds_overlap_ratio": None,
        "stats_coverage_pct":   None,
        "singleton_ratio":      None,
        "sample_count":         None,
        "last_scanned":         (present or {}).get("last_scanned"),
        "table_name":           (present or {}).get("table_name"),
    }


@router.get("/api/admin/brain/bloom-coverage")
async def brain_bloom_coverage(
    bucket: str,
    table_prefix: str,
    _user: dict = Depends(require_admin),
):
    """2026-07-15 — per-column BUILT-vs-NEEDED bloom coverage for one
    (bucket, table_prefix).  Joins the prunability profile (what the
    brain learned) against actual bloom-sidecar presence (what's been
    built):

      * a column WITH bloom rows          -> status 'built'
      * high-overlap column, no bloom yet -> status 'needed'
      * everything else                   -> status 'ok'

    Query params: bucket, table_prefix (both required).

    Returns: {rows: [{column_name, status, bloom_file_count,
      bounds_overlap_ratio, stats_coverage_pct, singleton_ratio,
      sample_count, last_scanned, table_name}], total, built_count,
      needed_count}.  Fail-soft: empty collection on any error.
    """
    if not bucket or not table_prefix:
        raise HTTPException(400, "bucket + table_prefix are required")
    _pfx = table_prefix.rstrip("/")
    try:
        prof_rows = await _adb(
            _db_manager.iceberg_prunability_list, bucket, _pfx, 2000,
        ) or []
        bloom_map = await _adb(
            _db_manager.iceberg_bloom_columns_present, bucket, _pfx,
        ) or {}
    except Exception:
        return {"rows": [], "total": 0, "built_count": 0, "needed_count": 0}

    rows, built, needed, seen = _bloom_coverage_profile_rows(prof_rows, bloom_map)
    # Columns with a bloom but NO prunability profile — still 'built'.
    for col, present in bloom_map.items():
        if col in seen:
            continue
        seen.add(col)
        built += 1
        rows.append(_bloom_coverage_orphan_row(col, present))
    rows.sort(key=lambda x: ({"needed": 0, "built": 1, "ok": 2}.get(x["status"], 3),
                             x["column_name"]))
    return {"rows": rows, "total": len(rows),
            "built_count": built, "needed_count": needed}


@router.post("/api/admin/iceberg/prefetch/tick")
async def iceberg_prefetch_force_tick(_user: dict = Depends(require_admin)):
    """Phase 149.9 — force-run the adaptive prefetch daemon NOW
    (instead of waiting for the next nightly tick).

    Useful when:
      * Just deployed 149 and want to populate bloom rows immediately
      * Tuned the config + want to test what the daemon would do
      * Investigating a slow query right now and want fresh coverage

    Synchronous via asyncio.to_thread — caller waits for the full tick
    to finish (could be ~30 min if a target is large; per-target cap
    iceberg.adaptive_prefetch.max_files_per_target bounds this).
    Returns the same shape as one entry of recent_ticks plus the full
    plan.  2026-10-07: runs in the OWNING process through _bg_run_now.
    """
    return await _bg_run_now("adaptive_prefetch", legacy_shape="spread")


# ─── Phase 150: iceberg mirror admin endpoints ───────────────────────────


async def _aresolve_mirror_target(
    body: Dict[str, Any],
) -> Tuple[Dict[str, Any], str, str]:
    cid = body.get("connection_id")
    tbl = body.get("table_name")
    if not cid or not tbl:
        raise HTTPException(
            status_code=400,
            detail="connection_id and table_name required",
        )
    conn = await _adb(_db_manager.get_connection_raw, cid)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn.get("connection_type") != "s3":
        raise HTTPException(
            status_code=400,
            detail="Mirror is S3 iceberg only",
        )
    cfg = conn.get("config", {}) or {}
    bucket = cfg.get("bucket_name")
    if not bucket:
        raise HTTPException(status_code=400, detail="Connection has no bucket")
    rt = next(
        (t for t in cfg.get("registered_tables", []) if t.get("name") == tbl),
        None,
    )
    if not rt:
        raise HTTPException(status_code=404, detail=f"Table '{tbl}' not registered")
    if rt.get("format") != "iceberg":
        raise HTTPException(
            status_code=400,
            detail="Mirror is iceberg-only",
        )
    return conn, bucket, (rt.get("s3_prefix", "") or "").rstrip("/")


@router.post("/api/admin/iceberg/mirror/analyse")
async def iceberg_mirror_analyse(
    body: Dict[str, Any], _user: dict = Depends(require_admin),
):
    """Cheap analysis — resolve current snapshot, count source files,
    surface existing mirror row state + eligibility.  No build.

    Body: {connection_id, table_name}
    """
    conn, bucket, prefix = await _aresolve_mirror_target(body)

    def _do():
        from core.iceberg_mirror import IcebergMirrorEngine
        from core.s3_utilities import make_s3_client_for_conn
        s3 = make_s3_client_for_conn(conn)
        engine = IcebergMirrorEngine.get_default(_db_manager)
        return engine.analyse_table(s3, bucket, prefix).to_dict()

    return await asyncio.to_thread(_do)


@router.post("/api/admin/iceberg/mirror/build")
async def iceberg_mirror_build(
    body: Dict[str, Any], _user: dict = Depends(require_admin),
):
    """Trigger a mirror build for one (connection_id, table_name).

    Body: {
      connection_id, table_name, force?: bool,
      partition_filters?: Dict       # {<partition_col>: <value>} or
                                     # {<partition_col>: [<v1>, <v2>]}
                                     # scopes the mirror to that slice
                                     # (manifest-side pruning fires).
                                     # Column name comes from the
                                     # table's actual partition layout
                                     # (use GET .../partition-detect
                                     # to discover top columns).
    }

    Use ``partition_filters`` to mirror only a slice of the table —
    e.g. exclude today's still-evolving partition by listing only
    historical values.  Same dict shape the plain-parquet mirror
    accepts.  The source-file cap (iceberg.mirror.max_build_source_files,
    default 5000) then applies to the FILTERED count, so a table with
    many thousand files spanning long periods can still build
    per-partition mirrors.

    Streams natively via DuckDB COPY → s3.  Synchronous from the
    admin's perspective: the response returns once the build is
    ``ready`` (or ``failed`` with a reason).  Heavy tables can take
    minutes; the front-end should set a longer timeout.

    Honours ``iceberg.mirror.enabled`` global kill switch.
    """
    conn, bucket, prefix = await _aresolve_mirror_target(body)
    force = bool(body.get("force", False))
    partition_filters = body.get("partition_filters") or None
    sort_by = body.get("sort_by") or None

    def _do():
        from core.iceberg_mirror import IcebergMirrorEngine
        from core.s3_utilities import make_s3_client_for_conn
        s3 = make_s3_client_for_conn(conn)
        engine = IcebergMirrorEngine.get_default(_db_manager)
        result = engine.build_mirror(
            s3, bucket, prefix,
            source_conn_config=conn.get("config") or {},
            connection_id=conn.get("id"),
            force=force,
            partition_filters=partition_filters,
            sort_by=sort_by,
        )
        out = result.to_dict()
        if partition_filters:
            out["partition_filters"] = dict(partition_filters)
        if sort_by:
            out["sort_by"] = list(sort_by)
        return out

    return await asyncio.to_thread(_do)


async def _resolve_sort_analysis_table(connection_id, table_name):
    """Resolve ``(conn, bucket, prefix, format)`` for a sort-analysis target.

    Accepts BOTH iceberg and plain-parquet registrations — the column-sort
    signal is read-format-independent (parquet footer statistics).
    """
    conn = await _adb(_db_manager.get_connection_raw, connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn.get("connection_type") != "s3":
        raise HTTPException(status_code=400, detail="S3-only endpoint")
    cfg = conn.get("config", {})
    bucket = cfg.get("bucket_name")
    rt = next(
        (t for t in cfg.get("registered_tables", [])
         if t.get("name") == table_name),
        None,
    )
    if not rt:
        raise HTTPException(
            status_code=404, detail=f"Table '{table_name}' not registered",
        )
    fmt = (rt.get("format") or "").lower()
    if fmt not in ("iceberg", "parquet"):
        raise HTTPException(
            status_code=400,
            detail="sort-analysis target must be format='iceberg' or 'parquet'",
        )
    return conn, bucket, (rt.get("s3_prefix") or "").rstrip("/"), fmt


def _sort_analysis_iceberg_keys(s3, bucket: str, prefix: str) -> list:
    """Bare S3 keys for an iceberg table's current data files."""
    from core.iceberg_reader import (
        get_iceberg_data_files, get_iceberg_snapshot_id_only,
    )
    snap = get_iceberg_snapshot_id_only(s3, bucket, prefix)
    files = get_iceberg_data_files(
        s3, bucket, prefix,
        partition_filters=None,
        keys_only=True,
        force_fresh=False,
        snapshot_id=int(snap) if snap and str(snap).lstrip("-").isdigit() else None,
    )
    file_keys = [
        (f.get("path") or f.get("key") or "")
        for f in files
        if (f.get("path") or f.get("key"))
    ]
    # Iceberg paths come as s3://... → strip to bare keys for
    # the ranged-GET helper.
    return [
        k[len("s3://"):].split("/", 1)[1]
        if k.startswith("s3://") else k
        for k in file_keys
    ]


def _sort_analysis_file_keys(s3, bucket: str, prefix: str, fmt: str) -> list:
    """The files to sample, enumerated by the reader that matches ``fmt``."""
    if fmt == "iceberg":
        return _sort_analysis_iceberg_keys(s3, bucket, prefix)
    from core.plain_parquet_catalog import PlainParquetCatalog
    entry = PlainParquetCatalog.get_default().enumerate_files(
        s3, bucket, prefix,
    )
    return list(entry.files or [])


@router.get("/api/admin/mirror/sort-analysis")
async def mirror_sort_analysis(
    connection_id: int,
    table_name: str,
    column: str,
    sample_n: int = 5,
    _user: dict = Depends(require_admin),
):
    """Phase 151 follow-up — diagnose whether ``column`` is already
    sorted in the source files, so operators know whether a mirror
    with ``sort_by=[column]`` would actually unlock new row-group
    skipping or would just duplicate data for no gain.

    Works for BOTH iceberg + plain-parquet registered tables — the
    column-sort signal is read-format-independent (parquet footer
    statistics).  Reads ``sample_n`` files' footers via ranged S3
    GETs (cheap — 5 ranged GETs total, no data bytes read).

    Returns: SortednessReport dict — verdict ('sorted' /
    'partially_sorted' / 'unsorted' / 'unknown'), per-file evidence,
    and an operator-facing recommendation.
    """
    if not column or not column.strip():
        raise HTTPException(
            status_code=400, detail="column is required",
        )
    conn, bucket, prefix, fmt = await _resolve_sort_analysis_table(
        connection_id, table_name)

    def _do():
        from core.s3_utilities import make_s3_client_for_conn
        from core.sort_analysis import analyse_column_sortedness
        s3 = make_s3_client_for_conn(conn)
        # Enumerate files via the right reader for the format.
        file_keys = _sort_analysis_file_keys(s3, bucket, prefix, fmt)
        report = analyse_column_sortedness(
            s3_client=s3,
            bucket=bucket,
            file_keys=file_keys,
            column=column.strip(),
            sample_n=max(1, min(20, int(sample_n))),
        )
        return report.to_dict()

    return await asyncio.to_thread(_do)


@router.get("/api/admin/iceberg/mirror/partition-detect")
async def iceberg_mirror_partition_detect(
    connection_id: int,
    table_name: str,
    min_coverage: float = 0.5,
    max_cols: int = 5,
    _user: dict = Depends(require_admin),
):
    """Phase 151 follow-up — detect top hive-style partition columns
    for an iceberg table by parsing the file-list segments.  Same
    helper the plain-parquet detector uses; returns columns admins
    can scope a partition-filtered mirror build to.

    Returns: ``{table, snapshot_id, files_total, columns:
                [{column, coverage_pct, distinct_value_count,
                  distinct_values_sample}]}``.
    """
    conn = await _adb(_db_manager.get_connection_raw, connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn.get("connection_type") != "s3":
        raise HTTPException(status_code=400, detail="S3-only endpoint")
    cfg = conn.get("config", {})
    bucket = cfg.get("bucket_name")
    rt = next(
        (t for t in cfg.get("registered_tables", [])
         if t.get("name") == table_name),
        None,
    )
    if not rt:
        raise HTTPException(
            status_code=404, detail=f"Table '{table_name}' not registered",
        )
    if (rt.get("format") or "") != "iceberg":
        raise HTTPException(
            status_code=400,
            detail="Iceberg partition-detect target must be format='iceberg'",
        )
    prefix = (rt.get("s3_prefix") or "").rstrip("/")

    def _do():
        from core.s3_utilities import make_s3_client_for_conn
        from core.iceberg_reader import (
            get_iceberg_data_files, get_iceberg_snapshot_id_only,
        )
        from core.plain_parquet_partition_helpers import (
            detect_top_partition_columns,
        )
        s3 = make_s3_client_for_conn(conn)
        snap = get_iceberg_snapshot_id_only(s3, bucket, prefix)
        files = get_iceberg_data_files(
            s3, bucket, prefix,
            partition_filters=None,
            keys_only=True,
            force_fresh=False,
            snapshot_id=int(snap) if snap and str(snap).lstrip("-").isdigit() else None,
        )
        file_keys = [
            (f.get("path") or f.get("key") or "")
            for f in files
            if (f.get("path") or f.get("key"))
        ]
        return {
            "table":           table_name,
            "snapshot_id":     str(snap) if snap is not None else "",
            "files_total":     len(file_keys),
            "columns":         detect_top_partition_columns(
                                 file_keys,
                                 min_coverage=min_coverage,
                                 max_cols=max_cols,
                              ),
        }
    return await asyncio.to_thread(_do)


@router.get("/api/admin/iceberg/mirror/list")
async def iceberg_mirror_list(
    limit: int = 200,
    _user: dict = Depends(require_admin),
):
    """List every mirror row + status + counters."""
    def _do():
        from core.iceberg_mirror import IcebergMirrorEngine
        engine = IcebergMirrorEngine.get_default(_db_manager)
        return {"mirrors": engine.list_mirrors(limit=max(1, min(1000, int(limit))))}
    return await asyncio.to_thread(_do)


@router.get("/api/admin/iceberg/mirror/events")
async def iceberg_mirror_events(
    limit: int = 50,
    _user: dict = Depends(require_admin),
):
    """Recent event ring (build / route / invalidate / dual-run / etc.)
    plus the last 10 daemon ticks."""
    # 2026-10-07 -- events are emitted by the query path (this pod's ring);
    # TICKS by the mirror daemon, answered by the process that runs it.
    def _do():
        from core.iceberg_mirror import get_recent_events
        return get_recent_events(limit=max(1, min(200, int(limit))))
    from core.daemon_snapshots import daemon_snapshot
    snap = await daemon_snapshot("iceberg_mirror.ticks", limit=10,
                                 proxy=_scheduler_worker_proxy)
    out = {"events": await asyncio.to_thread(_do),
           "ticks": (snap["data"] or {}).get("ticks", []),
           "ticks_answered_by": snap["answered_by"]}
    if snap.get("warning"):
        out["warning"] = snap["warning"]
    return out


@router.post("/api/admin/iceberg/mirror/{mirror_id}/routing")
async def iceberg_mirror_set_routing(
    mirror_id: int, body: Dict[str, Any],
    _user: dict = Depends(require_admin),
):
    """Flip the per-row routing toggle.

    Body: {enabled: bool, reason?: str}
    """
    enabled = bool(body.get("enabled", False))
    reason  = str(body.get("reason", "manual"))[:200]

    def _do():
        from core.iceberg_mirror import IcebergMirrorEngine
        engine = IcebergMirrorEngine.get_default(_db_manager)
        ok = engine.set_routing_enabled(int(mirror_id), enabled, reason=reason)
        return {"ok": ok, "mirror_id": int(mirror_id), "enabled": enabled}

    try:
        return await asyncio.to_thread(_do)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.post("/api/admin/iceberg/mirror/{mirror_id}/invalidate")
async def iceberg_mirror_invalidate(
    mirror_id: int, body: Dict[str, Any],
    _user: dict = Depends(require_admin),
):
    """Mark a mirror row stale.  Files are NOT deleted yet — cleanup_stale
    handles deletion after retention.

    Body: {reason?: str}
    """
    reason = str((body or {}).get("reason", "manual"))[:200]

    def _do():
        from core.iceberg_mirror import IcebergMirrorEngine
        engine = IcebergMirrorEngine.get_default(_db_manager)
        ok = engine.invalidate_mirror(int(mirror_id), reason=reason)
        return {"ok": ok, "mirror_id": int(mirror_id), "reason": reason}

    return await asyncio.to_thread(_do)


@router.delete("/api/admin/iceberg/mirror/{mirror_id}")
async def iceberg_mirror_delete(
    mirror_id: int,
    hard: bool = True,
    _user: dict = Depends(require_admin),
):
    """Hard-delete: S3 objects + DB row.

    Query param ``hard=false`` drops the DB row only (S3 retained by an
    out-of-band lifecycle policy).
    """
    def _do():
        from core.iceberg_mirror import IcebergMirrorEngine
        engine = IcebergMirrorEngine.get_default(_db_manager)
        ok = engine.delete_mirror(int(mirror_id), hard=bool(hard))
        return {"ok": ok, "mirror_id": int(mirror_id), "hard": bool(hard)}

    return await asyncio.to_thread(_do)


@router.get("/api/admin/iceberg/mirror/{mirror_id}/dual-run")
async def iceberg_mirror_dual_run(
    mirror_id: int, limit: int = 100,
    _user: dict = Depends(require_admin),
):
    """List per-divergence audit rows from the Layer-3 canary."""
    def _do():
        from core.iceberg_mirror import IcebergMirrorEngine
        engine = IcebergMirrorEngine.get_default(_db_manager)
        return {
            "mirror_id": int(mirror_id),
            "events": engine.list_dual_run_events(
                mirror_id=int(mirror_id),
                limit=max(1, min(500, int(limit))),
            ),
        }
    return await asyncio.to_thread(_do)


@router.post("/api/admin/iceberg/mirror/tick")
async def iceberg_mirror_force_tick(_user: dict = Depends(require_admin)):
    """Force-run the mirror daemon NOW.  Same shape as one entry in
    /events.ticks — useful for verifying the cron tick after editing
    config keys, or building a mirror for a freshly-onboarded table
    without waiting for the 6h cron.  2026-10-07: runs in the OWNING
    process through _bg_run_now."""
    return await _bg_run_now("iceberg_mirror_daemon", legacy_shape="spread")


def _discoverable_candidates() -> List[Dict[str, Any]]:
    """Every registered iceberg table on an active S3 connection."""
    # Walk active S3 connections + their registered iceberg tables.
    candidates: List[Dict[str, Any]] = []
    try:
        conns = _db_manager.list_connections(
            active_only=True, limit=500, offset=0,
        )
    except Exception:
        conns = []
    for c in conns or []:
        if (c or {}).get("connection_type") != "s3":
            continue
        cfg = c.get("config") or {}
        bucket = cfg.get("bucket_name") or ""
        if not bucket:
            continue
        _discoverable_add_tables(c, cfg, bucket, candidates)
    return candidates


def _discoverable_add_tables(c: dict, cfg: dict, bucket: str,
                             candidates: list) -> None:
    """Append one connection's registered iceberg tables to ``candidates``."""
    for rt in cfg.get("registered_tables") or []:
        if rt.get("format") != "iceberg":
            continue
        tprefix = (rt.get("s3_prefix") or "").rstrip("/")
        if not tprefix:
            continue
        candidates.append({
            "connection_id":     c.get("id"),
            "connection_name":   c.get("name"),
            "bucket":            bucket,
            "table_prefix":      tprefix,
            "table_name":        rt.get("name"),
        })


def _discoverable_mirror_row(r) -> Dict[str, Any]:
    """The mirror fields the discoverable-tables view shows for one row."""
    return {
        "mirror_id":            r.id,
        "mirror_status":        r.status,
        "mirror_snapshot_id":   r.source_snapshot_id,
        "mirror_built_at":      r.built_at.isoformat() if r.built_at else None,
        "routing_enabled":      bool(r.routing_enabled),
        "mirror_row_count":     int(r.mirror_row_count or 0),
        "mirror_file_count":    int(r.mirror_file_count or 0),
    }


def _discoverable_mirrors(IcebergMirror) -> Dict[Tuple[str, str], Dict[str, Any]]:
    """Freshest mirror row per (bucket, prefix); empty when unreadable."""
    mirror_by_key: Dict[Tuple[str, str], Dict[str, Any]] = {}
    try:
        with _db_manager.get_session(read_only=True) as session:
            # Latest mirror row per (bucket, prefix) — order_by id desc
            # so we pick the freshest entry when multiple exist
            # (e.g. snapshot rollforward queued a new one).
            rows = (
                session.query(IcebergMirror)
                .order_by(IcebergMirror.id.desc())
                .limit(2000)
                .all()
            )
            for r in rows:
                key = (r.source_bucket or "",
                       (r.source_prefix or "").rstrip("/"))
                if key in mirror_by_key:
                    continue  # already have the freshest
                mirror_by_key[key] = _discoverable_mirror_row(r)
    except Exception as exc:
        logger.debug("discoverable-tables: mirror lookup failed: %s", exc)
    return mirror_by_key


def _discoverable_query_counts(QueryPruningHistory, _td) -> Dict[Tuple[str, str], int]:
    """Last-168h query count per (bucket, prefix) — the mirror cron priority signal."""
    query_counts: Dict[Tuple[str, str], int] = {}
    try:
        since = datetime.now(timezone.utc) - _td(hours=168)
        with _db_manager.get_session(read_only=True) as session:
            from sqlalchemy import func as _sa_func
            rows = (
                session.query(
                    QueryPruningHistory.bucket,
                    QueryPruningHistory.table_prefix,
                    _sa_func.count(QueryPruningHistory.id),
                )
                .filter(QueryPruningHistory.created_at >= since)
                .group_by(
                    QueryPruningHistory.bucket,
                    QueryPruningHistory.table_prefix,
                )
                .all()
            )
            for b, p, n in rows:
                if not b or not p:
                    continue
                query_counts[(b, (p or "").rstrip("/"))] = int(n or 0)
    except Exception as exc:
        logger.debug("discoverable-tables: query_count lookup failed: %s", exc)
    return query_counts


def _discoverable_annotate(candidates: list, mirror_by_key: dict,
                           query_counts: dict) -> None:
    """Fold mirror state + query activity into each candidate row."""
    for cand in candidates:
        key = (cand["bucket"], cand["table_prefix"])
        cand.update(mirror_by_key.get(key) or {
            "mirror_id": None, "mirror_status": None,
            "mirror_snapshot_id": None, "mirror_built_at": None,
            "routing_enabled": False, "mirror_row_count": 0,
            "mirror_file_count": 0,
        })
        cand["queries_last_168h"] = query_counts.get(key, 0)
        # Eligibility = no current mirror OR existing mirror in a
        # non-ready state.  Mirror cron's own decision logic is more
        # nuanced (checks snapshot drift, big-query threshold,
        # source size caps); this is the UI-friendly approximation.
        cand["eligible_to_build"] = (
            cand["mirror_status"] in (None, "stale", "invalid", "failed")
        )


def _discoverable_tables() -> Dict[str, Any]:
    """Assemble the discoverable-tables view, most-queried table first."""
    from core.db.models import IcebergMirror, QueryPruningHistory
    from datetime import timedelta as _td
    candidates = _discoverable_candidates()
    # Annotate each with current mirror row (if any).
    mirror_by_key = _discoverable_mirrors(IcebergMirror)
    # Annotate with last-168h query count (mirror cron priority signal).
    query_counts = _discoverable_query_counts(QueryPruningHistory, _td)
    _discoverable_annotate(candidates, mirror_by_key, query_counts)

    # Most-queried first, then by name for stable tie-break.
    candidates.sort(
        key=lambda r: (-r["queries_last_168h"], r.get("table_name") or ""),
    )
    return {
        "tables":          candidates,
        "total":           len(candidates),
        "ready_mirrors":   sum(1 for c in candidates
                                if c.get("mirror_status") == "ready"),
        "eligible_count":  sum(1 for c in candidates
                                if c.get("eligible_to_build")),
    }


@router.get("/api/admin/iceberg/mirror/discoverable-tables")
async def iceberg_mirror_discoverable_tables(
    _user: dict = Depends(require_admin),
):
    """List every registered iceberg table across active S3 connections,
    annotated with current mirror status + query activity.

    Powers the dashboard "Discoverable tables" view so the panel isn't
    blank before any mirror exists.  Each row tells ops:
      * which (bucket, prefix) is registered + the owning connection
      * whether a mirror already exists + its status
      * how many queries hit the table in the last 168h (drives mirror
        cron prioritisation — same signal as _collect_build_candidates)
      * whether the table is eligible for a Build click
    """
    return await asyncio.to_thread(_discoverable_tables)


def _brain_job_state(job_id: str) -> Dict[str, Any]:
    """Scheduler state for one brain daemon.

    Best-effort — APScheduler may not be wired yet in tests, and an
    unregistered job is a fact worth reporting rather than an error.
    """
    try:
        from core.scheduler import get_scheduler
        sched = get_scheduler()
        if sched is None:
            return {"registered": False}
        job = sched.get_job(job_id)
        if job is None:
            return {"registered": False}
        nxt = getattr(job, "next_run_time", None)
        return {
            "registered": True,
            "next_run_time": nxt.isoformat() if nxt else None,
            "trigger":      str(job.trigger),
        }
    except Exception as exc:
        return {"registered": False, "error": str(exc)[:200]}


def _min_max_stats_table() -> str:
    """The table the per-file min/max stats ACTUALLY live in, by the
    configured grain (2026-10-06).  These labels said
    ``iceberg_column_stats_supplement_v2`` for months after the default grain
    moved to v3 -- an operator checking that table found 0 rows and read a
    healthy scanner as dead.  The grain resolver is the one the writer and
    every reader use."""
    try:
        from core import config as _qs_cfg
        grain = _qs_cfg.iceberg_file_stats_grain()
    except Exception:
        grain = "v3"
    if grain == "v2":
        return "iceberg_column_stats_supplement_v2"
    if grain == "both":
        return "iceberg_file_stats_v3 (+ iceberg_column_stats_supplement_v2)"
    return "iceberg_file_stats_v3"


def _brain_component_supplement_scanner(_cfg_get) -> Dict[str, Any]:
    """Per-file column min/max scanner — the pruner's non-partition filter source."""
    # 1. Supplement scanner
    try:
        sup_enabled = bool(_cfg_get(
            "iceberg", "column_stats_sync_enabled", True,
        ))
    except Exception:
        sup_enabled = True
    return {
        "name":        "supplement_scanner",
        "purpose":     "Populates per-file column min/max so the pruner can skip files on non-partition WHERE clauses",
        "enabled":     sup_enabled,
        "storage":     f"DB: {_min_max_stats_table()}",
        "scheduler":   _brain_job_state("iceberg_column_stats_sync"),
        "config_keys": [
            "iceberg.column_stats_sync_enabled",
            "iceberg.column_stats_sync_max_files_per_tick",
        ],
    }


def _adaptive_prefetch_last_tick() -> Dict[str, Any]:
    """The newest adaptive-prefetch tick, as the brain-health panel shows it."""
    ap_last: Dict[str, Any] = {}
    # 2026-09-01 -- this used to import ``get_recent_ticks``, which
    # core.query_history_prefetcher does not define; the ImportError was
    # swallowed and the panel said nothing.  2026-09-26 (F4b): the ring
    # DOES exist -- ``get_prefetch_status()["recent_ticks"]`` is what the
    # prefetch status route already serves -- so read its newest record.
    # ``status`` is the input verdict (ok / no_input / unreadable): a
    # daemon that ranks an empty history every hour must not look idle.
    try:
        from core.query_history_prefetcher import get_prefetch_status
        _ticks = (get_prefetch_status() or {}).get("recent_ticks") or []
        if _ticks:
            _t0 = _ticks[0]
            ap_last = {
                "started_at":    _t0.get("started_at"),
                "status":        _t0.get("status"),
                "input_rows":    _t0.get("input_rows"),
                "input_error":   _t0.get("input_error"),
                "targets_total": _t0.get("targets_total"),
                "bloom_jobs":    _t0.get("bloom_jobs"),
                "errors":        len(_t0.get("errors") or []),
            }
        else:
            ap_last = {"detail": "no tick recorded since this pod started"}
    except Exception as _ap_exc:
        ap_last = {"detail": f"tick ring unreadable: {_ap_exc}"[:200]}
    return ap_last


def _brain_component_adaptive_prefetch(_cfg_section) -> Dict[str, Any]:
    """Bloom adaptive prefetch (149.7) — ranks hot (table, column) pairs to scan."""
    # 2. Bloom adaptive prefetch (149.7)
    try:
        ap = _cfg_section("iceberg") or {}
        ap_cfg = (ap.get("adaptive_prefetch") or {})
        ap_enabled = bool(ap_cfg.get("enabled", True))
        # 2026-10-07 -- the ONE cadence (this was a third copy, saying 6).
        from core.query_history_prefetcher import resolve_interval_hours
        ap_interval = resolve_interval_hours()
    except Exception:
        ap_enabled, ap_interval = True, 1
    ap_last = _adaptive_prefetch_last_tick()
    return {
        "name":        "bloom_adaptive_prefetch",
        "purpose":     "Reads query_pruning_history → ranks hot (table, column) pairs → enqueues bloom + supplement scans so future queries prune automatically",
        "enabled":     ap_enabled,
        "interval_hours": ap_interval,
        "storage":     f"DB: iceberg_bloom_sidecar_v1 (bloom), {_min_max_stats_table()} (min/max)",
        "scheduler":   _brain_job_state("iceberg_adaptive_prefetch"),
        "last_tick":   ap_last or None,
        "config_keys": [
            "iceberg.adaptive_prefetch.enabled",
            "iceberg.adaptive_prefetch.interval_hours",
            "iceberg.adaptive_prefetch.max_targets_per_tick",
        ],
    }


def _brain_component_mirror() -> Dict[str, Any]:
    """Iceberg mirror (Phase 150) — small-file consolidation, SHADOW by default."""
    # 3. Iceberg mirror (Phase 150)
    try:
        from core.iceberg_mirror import (
            mirror_globally_enabled, routing_globally_enabled,
            cron_interval_hours, get_recent_ticks as _m_recent,
            internal_bucket, internal_prefix,
        )
        m_enabled = mirror_globally_enabled()
        m_route   = routing_globally_enabled()
        m_hours   = cron_interval_hours()
        m_recent  = _m_recent(limit=1)
        m_bucket  = internal_bucket()
        m_prefix  = internal_prefix()
    except Exception:
        m_enabled = m_route = False
        m_hours = 6
        m_recent = []
        m_bucket = m_prefix = ""
    return {
        "name":         "iceberg_mirror",
        "purpose":      "Consolidates many-small source parquet files into one logical-equivalent rewrite (Phase 150 SHADOW stage default — routing off)",
        "enabled":      m_enabled,
        "routing_enabled_global": m_route,
        "interval_hours": m_hours,
        "storage":      f"DB: iceberg_mirror + iceberg_mirror_dual_run_v1.  S3: s3://{m_bucket}/{m_prefix}",
        "scheduler":    _brain_job_state("iceberg_mirror_daemon"),
        "last_tick":    (m_recent[0] if m_recent else None),
        "config_keys": [
            "iceberg.mirror.enabled",
            "iceberg.mirror.routing_enabled",
            "iceberg.mirror.cron_enabled",
            "iceberg.mirror.cron_interval_hours",
        ],
    }


def _brain_component_output_gateway() -> Dict[str, Any]:
    """Output gateway (Phase 150 follow-up) — S3-backed result cache."""
    # 4. Output gateway (Phase 150 follow-up)
    try:
        from core.output_gateway import (
            gateway_globally_enabled, gateway_serve_enabled,
            get_recent_ticks as _g_recent,
        )
        g_enabled = gateway_globally_enabled()
        g_serve   = gateway_serve_enabled()
        g_recent  = _g_recent(limit=1)
    except Exception:
        g_enabled = g_serve = False
        g_recent = []
    return {
        "name":        "output_gateway",
        "purpose":     "S3-backed result cache for repeat large scans — mutually exclusive with local L2",
        "enabled":     g_enabled,
        "serve_enabled": g_serve,
        "storage":     "S3: configurable (output_gateway.bucket / .prefix); meta.json + parquet payload",
        "scheduler":   _brain_job_state("output_gateway_cleanup"),
        "last_tick":   (g_recent[0] if g_recent else None),
        "config_keys": [
            "output_gateway.enabled",
            "output_gateway.serve_enabled",
            "output_gateway.min_files_threshold",
        ],
    }


def _brain_component_freshness_watcher() -> Dict[str, Any]:
    """Brain freshness watcher (149.10) — snapshot rollforward invalidation hook."""
    # 5. Brain freshness watcher (149.10 — snapshot rollforward hook)
    return {
        "name":        "brain_freshness_watcher",
        "purpose":     "Invalidates stale brain state (supplement bounds, bloom sidecar, mirror rows) when source iceberg snapshot rolls forward",
        "enabled":     True,
        "storage":     "DB: query_pruning_history (signal source)",
        "scheduler":   _brain_job_state("brain_freshness_watcher"),
        "config_keys": [
            "iceberg.brain_freshness_interval_minutes",
        ],
    }


def _brain_component_coordinator() -> Dict[str, Any]:
    """BrainCoordinator — single arbiter across all brain daemons."""
    # 6. BrainCoordinator — single arbiter across all daemons
    try:
        from core.brain_coordinator import (
            enabled as _bc_enabled, get_current_pressure,
        )
        bc_on = _bc_enabled()
        current_pressure = get_current_pressure()
    except Exception:
        bc_on = False
        current_pressure = "unknown"
    return {
        "name":          "brain_coordinator",
        "purpose":       "Master arbiter — sets a process-wide pressure flag from supplement scanner bandwidth; defers heavy daemons (mirror/gateway/bloom prefetch) when bandwidth is tight",
        "enabled":       bc_on,
        "current_pressure": current_pressure,
        "storage":       "In-memory ring (last 50 tick reports)",
        "scheduler":     _brain_job_state("brain_coordinator_daemon"),
        "config_keys": [
            "brain_coordinator.enabled",
            "brain_coordinator.cron_interval_minutes",
            "brain_coordinator.pressure_threshold_seconds_per_file",
        ],
    }


def _brain_component_cost_model() -> Dict[str, Any]:
    """Cost model — predicted-cost routing instead of thresholds."""
    # 7. Cost model — predicted-cost routing
    try:
        from core.brain_cost_model import (
            enabled as _cm_enabled,
        )
        cm_on = _cm_enabled()
    except Exception:
        cm_on = False
    return {
        "name":        "brain_cost_model",
        "purpose":     "Replaces threshold-based mirror/gateway routing with predicted wall-clock cost from observed history (avg bytes/file × p95 seconds/byte)",
        "enabled":     cm_on,
        "storage":     "In-memory LRU per-table TableStats",
        "scheduler":   {"registered": False, "note": "on-demand from route path"},
        "config_keys": [
            "brain_cost_model.enabled",
            "brain_cost_model.lookback_hours",
            "brain_cost_model.min_observations_for_prediction",
        ],
    }


def _brain_component_skew_detector() -> Dict[str, Any]:
    """Skew detector — the false-pruning-win signal."""
    # 8. Skew detector — false-pruning-win signal
    try:
        from core.brain_skew_detector import (
            enabled as _sd_enabled,
        )
        sd_on = _sd_enabled()
    except Exception:
        sd_on = False
    return {
        "name":        "brain_skew_detector",
        "purpose":     "Catches 'pruning illusion' — bucket pruning fires (file count drops) but scan time doesn't drop proportionally because the workload is value-skewed",
        "enabled":     sd_on,
        "storage":     "Stateless — recomputed on each read",
        "scheduler":   {"registered": False, "note": "on-demand from coordinator + UI"},
        "config_keys": [
            "brain_skew_detector.enabled",
            "brain_skew_detector.skew_divergence_threshold",
        ],
    }


def _brain_component_forecaster() -> Dict[str, Any]:
    """Workload forecaster — time-of-day spike prediction."""
    # 9. Workload forecaster — time-of-day spike prediction
    try:
        from core.brain_forecaster import (
            enabled as _wf_enabled,
        )
        wf_on = _wf_enabled()
    except Exception:
        wf_on = False
    return {
        "name":        "brain_forecaster",
        "purpose":     "Time-of-day / day-of-week pattern detector — biases the adaptive prefetcher toward tables predicted to spike in the next 24h",
        "enabled":     wf_on,
        "storage":     "Stateless — recomputed on each read",
        "scheduler":   {"registered": False, "note": "on-demand from prefetcher + coordinator"},
        "config_keys": [
            "brain_forecaster.enabled",
            "brain_forecaster.spike_multiplier_threshold",
        ],
    }


def _brain_component_writer_advisor() -> Dict[str, Any]:
    """WriterAdvisor SHADOW auto-apply — recommendations without DDL."""
    # 10. WriterAdvisor SHADOW auto-apply
    try:
        from core.writer_advisor import (
            auto_apply_enabled as _wa_auto_on,
        )
        wa_on = _wa_auto_on()
    except Exception:
        wa_on = False
    return {
        "name":        "writer_advisor_shadow_auto_apply",
        "purpose":     "SHADOW stage of auto-apply — marks high-leverage recommendations status='shadow' in the ledger without DDL.  Operator promotes to CANARY/DEFAULT after a 7-day SHADOW soak",
        "enabled":     wa_on,
        "storage":     "DB: writer_advisor_decisions (status='shadow')",
        "scheduler":   {"registered": False, "note": "on-demand from admin endpoint"},
        "config_keys": [
            "writer_advisor.auto_apply_enabled",
            "writer_advisor.auto_apply_min_leverage_pct",
            "writer_advisor.auto_apply_min_queries",
        ],
    }

def _brain_pipeline_snapshot() -> Dict[str, Any]:
    """Assemble the cross-component view of the pruning-brain pipeline."""
    from core.config import get as _cfg_get, get_section as _cfg_section
    out: Dict[str, Any] = {
        "components": [
            _brain_component_supplement_scanner(_cfg_get),
            _brain_component_adaptive_prefetch(_cfg_section),
            _brain_component_mirror(),
            _brain_component_output_gateway(),
            _brain_component_freshness_watcher(),
            _brain_component_coordinator(),
            _brain_component_cost_model(),
            _brain_component_skew_detector(),
            _brain_component_forecaster(),
            _brain_component_writer_advisor(),
        ],
        "storage":    {},
        "computed_at": datetime.now(timezone.utc).isoformat(),
    }
    out["summary"] = {
        "total_components":   len(out["components"]),
        "enabled_count":      sum(1 for c in out["components"]
                                   if c.get("enabled")),
        "registered_count":   sum(1 for c in out["components"]
                                   if (c.get("scheduler") or {}).get("registered")),
    }
    return out


@router.get("/api/admin/brain/status")
async def brain_pipeline_status(_user: dict = Depends(require_admin)):
    """Cross-component view of the pruning-brain pipeline.

    Reports, for each component:
      * enabled flag (config-driven)
      * scheduler state (job_id + next_run_time when registered)
      * storage backing (DB table, S3 bucket/prefix, in-memory ring)
      * last tick summary when available

    Components reported:
      * supplement scanner (iceberg.column_stats_sync — 5min cron)
      * bloom adaptive prefetcher (iceberg.adaptive_prefetch — 6h cron)
      * iceberg mirror (iceberg.mirror — 6h cron, default off)
      * output gateway (output_gateway — 6h cleanup cron, default off)
      * brain freshness watcher (snapshot rollforward hook)

    Used by the Mirror Status admin section to explain "where the
    brain is at" without log-grepping.
    """
    return await asyncio.to_thread(_brain_pipeline_snapshot)


# ═══════════════════════════════════════════════════════════════════════
# Phase 149 (charter P2) — Writer Advisor admin endpoints
# ═══════════════════════════════════════════════════════════════════════


@router.get("/api/admin/brain/writer-advisor/recommendations")
async def writer_advisor_list(
    bucket: Optional[str] = None,
    window_hours: Optional[int] = None,
    _user: dict = Depends(require_admin),
):
    """List Writer Advisor recommendations.

    Reads `query_pruning_history` over the lookback window + cross-
    references against the dismissal ledger.  Returns recommendations
    ranked by estimated leverage (avg_files_after → est_files_after).
    """
    def _do():
        from core.writer_advisor import WriterAdvisor
        adv = WriterAdvisor.get_default(_db_manager)
        recs = adv.compute_all(
            window_hours=window_hours, bucket_filter=bucket,
        )
        return {
            "recommendations": [r.to_dict() for r in recs],
            "total": len(recs),
            "computed_at": datetime.now(timezone.utc).isoformat(),
        }
    return await asyncio.to_thread(_do)


@router.post("/api/admin/brain/writer-advisor/decision")
async def writer_advisor_decision(
    body: Dict[str, Any], request: Request,
    _user: dict = Depends(require_admin),
):
    """Persist accept / dismiss decision for a recommendation.

    Body: {
        bucket: str, table_prefix: str, column: str, kind: str,
        status: "accepted" | "dismissed",
        reason?: str,
    }

    Accept = "we'll have the writer team apply this".
    Dismiss = "not appropriate" — suppresses the same shape for
              `writer_advisor.dismissal_ttl_days` (default 30d).
    """
    try:
        from core.writer_advisor import WriterAdvisor
        adv = WriterAdvisor.get_default(_db_manager)
        decided_by = (_user or {}).get("username", "admin")
        result = adv.record_decision(
            bucket       = str(body.get("bucket") or ""),
            prefix       = str(body.get("table_prefix") or ""),
            column       = str(body.get("column") or ""),
            kind         = str(body.get("kind") or ""),
            status       = str(body.get("status") or ""),
            decided_by   = decided_by,
            reason       = body.get("reason"),
            details      = body.get("details"),
        )
        # Audit log so accept/dismiss is traceable.
        try:
            from core.audit import audit_event
            audit_event(
                _db_manager, _user, request,
                action       = f"writer_advisor_{result['status']}",
                resource_type= "writer_recommendation",
                resource_id  = (
                    f"{result['bucket']}|{result['table_prefix']}|"
                    f"{result['column']}|{result['kind']}"
                ),
                details      = result,
            )
        except Exception:
            pass
        return result
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.get("/api/admin/brain/writer-advisor/decisions")
async def writer_advisor_decisions(
    status: Optional[str] = None, limit: int = 100,
    _user: dict = Depends(require_admin),
):
    """Read the persisted decision ledger — drives the "previously
    accepted / dismissed" history pane in the UI."""
    def _do():
        from core.writer_advisor import WriterAdvisor
        adv = WriterAdvisor.get_default(_db_manager)
        return {"decisions": adv.list_decisions(status=status, limit=limit)}
    return await asyncio.to_thread(_do)


# ═══════════════════════════════════════════════════════════════════════
# Phase 148.D — pruning alert dispatcher admin endpoints
# ═══════════════════════════════════════════════════════════════════════


@router.post("/api/admin/pruning/alerts/dispatch")
async def pruning_alerts_dispatch(
    _user: dict = Depends(require_admin),
):
    """Force-run the alert dispatcher against the current cluster
    snapshot.  Useful after editing the webhook config to validate the
    delivery path without waiting for the cron tick.  2026-10-07: runs in
    the OWNING process through _bg_run_now."""
    return await _bg_run_now("pruning_alerts_daemon", legacy_shape="spread")


@router.post("/api/admin/pruning/alerts/test")
async def pruning_alerts_test(
    body: Optional[Dict[str, Any]] = None,
    _user: dict = Depends(require_admin),
):
    """Smoke-test the configured webhook channels with a synthetic
    payload.

    Body: ``{"dry_run": bool}`` — when true, returns what WOULD be sent
    without actually firing the webhook.
    """
    dry = bool((body or {}).get("dry_run", False))

    def _do():
        from core.pruning_alerts import PruningAlertDispatcher
        d = PruningAlertDispatcher.get_default(_db_manager)
        return d.test_channels(dry_run=dry)
    return await asyncio.to_thread(_do)


@router.get("/api/admin/pruning/alerts/history")
async def pruning_alerts_history(
    limit: int = 50,
    _user: dict = Depends(require_admin),
):
    """Recent alerts, from the DURABLE ``pruning_alert_events`` table.

    2026-09-07: this used to read a process-local ``deque(maxlen=200)``
    that a restart emptied, and that was only ever appended to when a
    channel returned ok — so a deployment with no webhook configured (the
    shipped default) answered "nothing" to "what fired?".  Each entry now
    carries ``delivery_status``, ``delivered`` and ``reason``, and
    ``source`` says whether it came from the table or the in-memory
    fallback ring.
    """
    def _do():
        from core.pruning_alerts import PruningAlertDispatcher
        d = PruningAlertDispatcher.get_default(_db_manager)
        return {"history": d.recent_history(limit=limit)}
    return await asyncio.to_thread(_do)


@router.get("/api/admin/pruning/alerts/events")
async def pruning_alerts_events(
    limit: int = 50,
    undelivered_only: bool = False,
    since_hours: Optional[int] = None,
    bucket: Optional[str] = None,
    table_prefix: Optional[str] = None,
    kind: Optional[str] = None,
    _user: dict = Depends(require_admin),
):
    """The durable alert record — ``pruning_alert_events``.

    ``undelivered_only=true`` answers **what did we fail to page?**: every
    degradation that was detected and did NOT reach ops, whether because
    no channel is configured, every channel failed, the dedup window
    suppressed it, or ``max_alerts_per_tick`` dropped it.  Each row
    carries the reason in words.

    UNKNOWN IS NOT EMPTY: when the table cannot be read the response says
    ``source: "unavailable"`` with an ``error`` rather than an empty list
    that reads as "no alerts".
    """
    def _do():
        from core.pruning_alerts import recent_events
        return recent_events(
            _db_manager, limit=limit, undelivered_only=undelivered_only,
            since_hours=since_hours, bucket=bucket,
            table_prefix=table_prefix, kind=kind,
        )
    return await asyncio.to_thread(_do)


@router.get("/api/admin/pruning/alerts/undelivered-summary")
async def pruning_alerts_undelivered_summary(
    since_hours: int = 168,
    _user: dict = Depends(require_admin),
):
    """Counts per ``delivery_status`` over a window — the one-glance
    answer to "is our pruning alerting actually reaching anybody?"."""
    def _do():
        from core.pruning_alerts import undelivered_summary
        return undelivered_summary(_db_manager, since_hours=since_hours)
    return await asyncio.to_thread(_do)


# ═══════════════════════════════════════════════════════════════════════
# Phase 148.D follow-up — supplement scanner adaptive backpressure status
# ═══════════════════════════════════════════════════════════════════════


@router.get("/api/admin/iceberg/column-stats/adaptive-state")
async def iceberg_column_stats_adaptive_state(
    _user: dict = Depends(require_admin),
):
    """Current backpressure-adjusted per-tick cap + the rolling
    per-file latency the adapter is using.  Lets ops verify the
    scanner is throttling appropriately on slow-S3 deployments
    without log-grepping."""
    def _do():
        from core.iceberg_metadata_sync import adaptive_state
        return adaptive_state()
    return await asyncio.to_thread(_do)


# ═══════════════════════════════════════════════════════════════════════
# Phase 151.A — plain parquet brain admin endpoints
# ═══════════════════════════════════════════════════════════════════════


@router.get("/api/admin/parquet/catalog/state")
async def plain_parquet_catalog_state(
    _user: dict = Depends(require_admin),
):
    """Cached file-list state for every (bucket, prefix) the plain-
    parquet catalog has enumerated.  Read-only — no S3 calls."""
    def _do():
        from core.plain_parquet_catalog import PlainParquetCatalog
        return PlainParquetCatalog.get_default().state_snapshot()
    return await asyncio.to_thread(_do)


@router.get("/api/admin/parquet/discoverable-tables")
async def plain_parquet_discoverable_tables(
    _user: dict = Depends(require_admin),
):
    """List every registered plain-parquet table across active S3
    connections.  Mirrors the iceberg discoverable-tables endpoint."""
    def _do():
        from core.plain_parquet_catalog import (
            list_registered_parquet_tables,
        )
        tables = list_registered_parquet_tables(_db_manager)
        return {"tables": tables, "total": len(tables)}
    return await asyncio.to_thread(_do)


@router.post("/api/admin/parquet/sync/tick")
async def plain_parquet_sync_force_tick(
    _user: dict = Depends(require_admin),
):
    """Force-run the parquet sync tick NOW -- in the OWNING process
    (2026-10-07, _bg_run_now)."""
    return await _bg_run_now("plain_parquet_sync", legacy_shape="spread")


@router.get("/api/admin/parquet/sync/recent-ticks")
async def plain_parquet_sync_recent_ticks(
    limit: int = 10,
    _user: dict = Depends(require_admin),
):
    """Recent sync tick records — tables scanned, files scanned,
    pressure deferrals, errors -- from the process that runs the sync
    (core/daemon_snapshots.py)."""
    from core.daemon_snapshots import daemon_snapshot
    snap = await daemon_snapshot("plain_parquet_sync.ticks", limit=limit,
                                 proxy=_scheduler_worker_proxy)
    out = dict(snap["data"] or {})
    out["answered_by"] = snap["answered_by"]
    if snap.get("warning"):
        out["warning"] = snap["warning"]
    return out


async def _resolve_parquet_bloom_target(cid, tbl):
    """Resolve ``(conn, bucket, prefix)`` for a plain-parquet bloom scan."""
    conn = await _adb(_db_manager.get_connection_raw, cid)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn.get("connection_type") != "s3":
        raise HTTPException(
            status_code=400,
            detail="Plain parquet bloom only applies to S3 connections",
        )
    cfg = conn.get("config", {})
    bucket = cfg.get("bucket_name")
    if not bucket:
        raise HTTPException(status_code=400, detail="Connection has no bucket")
    rt = next(
        (t for t in cfg.get("registered_tables", []) if t.get("name") == tbl),
        None,
    )
    if not rt:
        raise HTTPException(
            status_code=404, detail=f"Table '{tbl}' not registered",
        )
    if (rt.get("format") or "") != "parquet":
        raise HTTPException(
            status_code=400,
            detail=("Bloom scan target must be format='parquet'.  "
                    "Use /api/admin/iceberg/bloom/scan for iceberg tables."),
        )
    return conn, bucket, (rt.get("s3_prefix") or "").rstrip("/")


@router.post("/api/admin/parquet/bloom/scan")
async def plain_parquet_bloom_scan(
    body: Dict[str, Any],
    _user: dict = Depends(require_admin),
):
    """Phase 151.C — trigger a bloom-filter sidecar scan for one
    plain-parquet table.  Body shape mirrors the iceberg bloom-scan
    endpoint:

      {
        connection_id:   int,
        table_name:      str,             # registered plain-parquet table
        columns:         List[str],       # REQUIRED — bloom is heavy
        max_workers:     Optional[int],   # default 8
        target_fp_rate:  Optional[float], # default 0.01 (1%)
        partition_filters: Optional[Dict] # e.g. {"business_date": "2024-01-15"}
                                          # scopes scan to matching files
      }
    """
    cid = body.get("connection_id")
    tbl = body.get("table_name")
    if not cid or not tbl:
        raise HTTPException(
            status_code=400,
            detail="connection_id and table_name required",
        )
    cols = body.get("columns") or []
    if not isinstance(cols, list) or not cols:
        raise HTTPException(
            status_code=400,
            detail="'columns' is required for parquet bloom scan",
        )
    try:
        max_workers = max(1, min(int(body.get("max_workers") or 8), 32))
    except Exception:
        max_workers = 8
    target_fp_rate = float(body.get("target_fp_rate") or 0.01)

    conn, bucket, prefix = await _resolve_parquet_bloom_target(cid, tbl)

    partition_filters = body.get("partition_filters") or None

    def _do():
        from core.s3_utilities import make_s3_client_for_conn
        from core.plain_parquet_bloom_scanner import scan_parquet_bloom
        s3 = make_s3_client_for_conn(conn)
        return scan_parquet_bloom(
            db_manager=_db_manager,
            s3_client=s3,
            bucket=bucket,
            table_prefix=prefix,
            target_columns=cols,
            max_workers=max_workers,
            connection_id=int(cid),
            table_name=tbl,
            target_fp_rate=target_fp_rate,
            partition_filters=partition_filters,
        )
    return await asyncio.to_thread(_do)


async def _resolve_registered_parquet_table(cid, tbl):
    """Resolve ``(conn, bucket, prefix)`` for a registered PLAIN-parquet table.

    Refuses a non-S3 connection, an unregistered table, or one registered
    with a format other than parquet — an iceberg table would be scanned
    with the wrong file enumerator.
    """
    conn = await _adb(_db_manager.get_connection_raw, cid)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn.get("connection_type") != "s3":
        raise HTTPException(status_code=400, detail="S3-only endpoint")
    cfg = conn.get("config", {})
    bucket = cfg.get("bucket_name")
    rt = next(
        (t for t in cfg.get("registered_tables", []) if t.get("name") == tbl),
        None,
    )
    if not rt:
        raise HTTPException(
            status_code=404, detail=f"Table '{tbl}' not registered",
        )
    if (rt.get("format") or "") != "parquet":
        raise HTTPException(
            status_code=400,
            detail="Supplement scan target must be format='parquet'",
        )
    return conn, bucket, (rt.get("s3_prefix") or "").rstrip("/")


@router.post("/api/admin/parquet/supplement/scan")
async def plain_parquet_supplement_scan(
    body: Dict[str, Any],
    _user: dict = Depends(require_admin),
):
    """Phase 151 follow-up — targeted supplement (column-stats)
    refresh for a plain-parquet table.

    Body:
      {
        connection_id:    int,
        table_name:       str,
        columns:          Optional[List[str]],  # None = all cols
        max_workers:      Optional[int],        # default 16
        force:            Optional[bool],       # bypass skip-already-scanned
        partition_filters: Optional[Dict]       # e.g. {"business_date": "2024-01-15"}
      }

    Without ``partition_filters``, this scans every file in the
    directory (same work the daemon does, but on demand).  With it,
    scoped to the partition slice — much faster for daily refreshes.
    """
    cid = body.get("connection_id")
    tbl = body.get("table_name")
    if not cid or not tbl:
        raise HTTPException(
            status_code=400,
            detail="connection_id and table_name required",
        )
    cols = body.get("columns") or None
    try:
        max_workers = max(1, min(int(body.get("max_workers") or 16), 64))
    except Exception:
        max_workers = 16
    force = bool(body.get("force", False))
    partition_filters = body.get("partition_filters") or None

    conn, bucket, prefix = await _resolve_registered_parquet_table(cid, tbl)

    def _do():
        import time as _t
        from core.s3_utilities import make_s3_client_for_conn
        from core.plain_parquet_catalog import PlainParquetCatalog
        from core.iceberg_column_stats import scan_files_to_supplement
        from core.plain_parquet_partition_helpers import (
            filter_files_by_partition,
        )
        s3 = make_s3_client_for_conn(conn)
        catalog = PlainParquetCatalog.get_default()
        entry = catalog.enumerate_files(s3, bucket, prefix)
        if not entry.files:
            return {"status": "skipped", "reason": "empty directory",
                     "files_total": 0,
                     "snapshot_token": entry.snapshot_token}
        files = list(entry.files)
        files_before = len(files)
        if partition_filters:
            files = filter_files_by_partition(files, partition_filters)
            if not files:
                return {
                    "status": "skipped",
                    "reason": "no files matched partition_filters",
                    "files_total": files_before,
                    "files_after_partition_filter": 0,
                    "snapshot_token": entry.snapshot_token,
                    "partition_filters": dict(partition_filters),
                }
        t0 = _t.monotonic()
        result = scan_files_to_supplement(
            db_manager=_db_manager,
            s3_client=s3,
            bucket=bucket,
            table_prefix=prefix,
            snapshot_id=entry.snapshot_token,
            file_keys=files,
            target_columns=cols,
            max_workers=max_workers,
            skip_already_scanned=(not force),
            connection_id=int(cid),
            table_name=tbl,
            format="parquet",
        )
        result["files_total"] = files_before
        result["snapshot_token"] = entry.snapshot_token
        result["elapsed_seconds"] = round(_t.monotonic() - t0, 3)
        if partition_filters:
            result["files_after_partition_filter"] = len(files)
            result["partition_filters"] = dict(partition_filters)
        return result
    return await asyncio.to_thread(_do)


@router.get("/api/admin/parquet/partition-detect")
async def plain_parquet_partition_detect(
    connection_id: int,
    table_name: str,
    min_coverage: float = 0.5,
    max_cols: int = 5,
    _user: dict = Depends(require_admin),
):
    """Phase 151 follow-up — detect top partition columns for a
    plain-parquet table by parsing hive-style segments in the file
    list.  Used by the admin UI to populate a "refresh by partition"
    dropdown — operator picks a column + value rather than guessing
    the layout.

    Returns: ``{table, snapshot_token, columns:
                [{column, coverage_pct, distinct_value_count,
                  distinct_values_sample}]}``.
    """
    conn = await _adb(_db_manager.get_connection_raw, connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn.get("connection_type") != "s3":
        raise HTTPException(status_code=400, detail="S3-only endpoint")
    cfg = conn.get("config", {})
    bucket = cfg.get("bucket_name")
    rt = next(
        (t for t in cfg.get("registered_tables", [])
         if t.get("name") == table_name),
        None,
    )
    if not rt:
        raise HTTPException(
            status_code=404, detail=f"Table '{table_name}' not registered",
        )
    if (rt.get("format") or "") != "parquet":
        raise HTTPException(
            status_code=400,
            detail="Partition detect target must be format='parquet'",
        )
    prefix = (rt.get("s3_prefix") or "").rstrip("/")

    def _do():
        from core.s3_utilities import make_s3_client_for_conn
        from core.plain_parquet_catalog import PlainParquetCatalog
        from core.plain_parquet_partition_helpers import (
            detect_top_partition_columns,
        )
        s3 = make_s3_client_for_conn(conn)
        catalog = PlainParquetCatalog.get_default()
        entry = catalog.enumerate_files(s3, bucket, prefix)
        return {
            "table":           table_name,
            "snapshot_token":  entry.snapshot_token,
            "files_total":     len(entry.files),
            "columns":         detect_top_partition_columns(
                                 entry.files,
                                 min_coverage=min_coverage,
                                 max_cols=max_cols,
                              ),
        }
    return await asyncio.to_thread(_do)


# ═══════════════════════════════════════════════════════════════════════
# Phase 151.E — plain parquet mirror admin endpoints
# ═══════════════════════════════════════════════════════════════════════


@router.get("/api/admin/parquet/mirror/state")
async def plain_parquet_mirror_state(
    _user: dict = Depends(require_admin),
):
    """Plain-parquet mirror dashboard summary — by-status counts,
    routing-enabled count, flag posture."""
    def _do():
        from core.plain_parquet_mirror import PlainParquetMirrorEngine
        eng = PlainParquetMirrorEngine.get_default(_db_manager)
        return eng.state_snapshot()
    return await asyncio.to_thread(_do)


@router.get("/api/admin/parquet/mirror/list")
async def plain_parquet_mirror_list(
    status: Optional[str] = None,
    limit: int = 100,
    _user: dict = Depends(require_admin),
):
    """List plain-parquet mirror rows (newest first).  Optional
    ?status= filter."""
    def _do():
        from core.plain_parquet_mirror import PlainParquetMirrorEngine
        eng = PlainParquetMirrorEngine.get_default(_db_manager)
        return {"mirrors": eng.list_mirrors(status=status, limit=limit)}
    return await asyncio.to_thread(_do)


@router.post("/api/admin/parquet/mirror/build")
async def plain_parquet_mirror_build(
    body: Dict[str, Any],
    _user: dict = Depends(require_admin),
):
    """Force-build a plain-parquet mirror for a specific (conn, table).

    Body: {
      connection_id:    int,
      table_name:       str,
      force?:           bool,
      partition_filters?: Dict     # e.g. {"business_date": "2024-01-15"}
                                   # scopes the mirror to that slice
    }

    Honours plain_parquet.mirror.enabled — if the flag is off, returns
    skipped=true so admins can sanity-check the engine without
    flipping the global flag.
    """
    cid = body.get("connection_id")
    tbl = body.get("table_name")
    if not cid or not tbl:
        raise HTTPException(
            status_code=400,
            detail="connection_id and table_name required",
        )
    force = bool(body.get("force", False))
    partition_filters = body.get("partition_filters") or None
    sort_by = body.get("sort_by") or None
    conn = await _adb(_db_manager.get_connection_raw, cid)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    cfg = conn.get("config", {})
    bucket = cfg.get("bucket_name")
    rt = next(
        (t for t in cfg.get("registered_tables", []) if t.get("name") == tbl),
        None,
    )
    if not rt:
        raise HTTPException(
            status_code=404, detail=f"Table '{tbl}' not registered",
        )
    if (rt.get("format") or "") != "parquet":
        raise HTTPException(
            status_code=400,
            detail="Mirror target must be format='parquet'",
        )
    prefix = (rt.get("s3_prefix") or "").rstrip("/")

    def _do():
        from core.s3_utilities import make_s3_client_for_conn
        from core.plain_parquet_mirror import PlainParquetMirrorEngine
        eng = PlainParquetMirrorEngine.get_default(_db_manager)
        s3 = make_s3_client_for_conn(conn)
        br = eng.build_mirror(
            bucket=bucket, prefix=prefix, s3_client=s3,
            connection_id=int(cid), force=force,
            partition_filters=partition_filters,
            sort_by=sort_by,
        )
        out = br.to_dict()
        if partition_filters:
            out["partition_filters"] = dict(partition_filters)
        if sort_by:
            out["sort_by"] = list(sort_by)
        return out
    return await asyncio.to_thread(_do)


@router.post("/api/admin/parquet/mirror/cleanup")
async def plain_parquet_mirror_cleanup(
    _user: dict = Depends(require_admin),
):
    """Run cleanup_stale immediately (without waiting for the cron)."""
    def _do():
        from core.plain_parquet_mirror import PlainParquetMirrorEngine
        eng = PlainParquetMirrorEngine.get_default(_db_manager)
        return eng.cleanup_stale()
    return await asyncio.to_thread(_do)


@router.get("/api/admin/parquet/mirror/recent-ticks")
async def plain_parquet_mirror_recent_ticks(
    limit: int = 10,
    _user: dict = Depends(require_admin),
):
    # 2026-10-07 -- from the process that runs the mirror daemon.
    from core.daemon_snapshots import daemon_snapshot
    snap = await daemon_snapshot("plain_parquet_mirror.ticks", limit=limit,
                                 proxy=_scheduler_worker_proxy)
    out = dict(snap["data"] or {})
    out["answered_by"] = snap["answered_by"]
    if snap.get("warning"):
        out["warning"] = snap["warning"]
    return out


# ═══════════════════════════════════════════════════════════════════════
# Brain coordinator + cost model + skew + forecaster admin endpoints
# ═══════════════════════════════════════════════════════════════════════


@router.get("/api/admin/brain/coordinator/status")
async def brain_coordinator_status(
    limit: int = 20,
    _user: dict = Depends(require_admin),
):
    """Current pressure flag + recent coordinator tick reports -- from the
    process that runs the coordinator (core/daemon_snapshots.py)."""
    from core.daemon_snapshots import daemon_snapshot
    snap = await daemon_snapshot("brain_coordinator.status", limit=limit,
                                 proxy=_scheduler_worker_proxy)
    out = dict(snap["data"] or {})
    out["answered_by"] = snap["answered_by"]
    if snap.get("warning"):
        out["warning"] = snap["warning"]
    return out


@router.post("/api/admin/brain/coordinator/tick")
async def brain_coordinator_force_tick(
    _user: dict = Depends(require_admin),
):
    """Force-run the coordinator tick NOW -- in the OWNING process
    (2026-10-07, _bg_run_now)."""
    return await _bg_run_now("brain_coordinator_daemon", legacy_shape="spread")


@router.get("/api/admin/brain/cost-model/state")
async def brain_cost_model_state(
    _user: dict = Depends(require_admin),
):
    """Cached per-table cost-model statistics."""
    def _do():
        from core.brain_cost_model import CostModel
        cm = CostModel.get_default(_db_manager)
        return cm.state_snapshot()
    return await asyncio.to_thread(_do)


@router.get("/api/admin/brain/cost-model/decision")
async def brain_cost_model_decision(
    bucket: str, table_prefix: str, files_after_prune: int,
    mirror_file_count: Optional[int] = None,
    gateway_eligible: bool = True,
    _user: dict = Depends(require_admin),
):
    """Per-table cost decision for the supplied scan plan."""
    def _do():
        from core.brain_cost_model import CostModel
        cm = CostModel.get_default(_db_manager)
        rd = cm.route_decision(
            bucket, table_prefix,
            files_after_prune=int(files_after_prune),
            mirror_file_count=mirror_file_count,
            gateway_eligible=bool(gateway_eligible),
        )
        if rd is None:
            return {"decision": None, "reason": "insufficient observations"}
        return {"decision": rd.to_dict()}
    return await asyncio.to_thread(_do)


@router.get("/api/admin/brain/skew/signals")
async def brain_skew_signals(
    bucket: Optional[str] = None,
    _user: dict = Depends(require_admin),
):
    """Skew signals — columns where bucket pruning fires but scan
    time per file is materially above the table baseline."""
    def _do():
        from core.brain_skew_detector import SkewDetector
        sd = SkewDetector.get_default(_db_manager)
        sigs = sd.detect_skewed_columns(bucket_filter=bucket)
        return {
            "signals": [s.to_dict() for s in sigs],
            "total":   len(sigs),
        }
    return await asyncio.to_thread(_do)


@router.get("/api/admin/brain/forecaster/predictions")
async def brain_forecaster_predictions(
    bucket: Optional[str] = None,
    _user: dict = Depends(require_admin),
):
    """Workload forecast — predicted query spikes per (bucket, prefix)
    over the next forecast window."""
    def _do():
        from core.brain_forecaster import WorkloadForecaster
        wf = WorkloadForecaster.get_default(_db_manager)
        preds = wf.next_24h_predictions(bucket_filter=bucket)
        return {
            "predictions": [p.to_dict() for p in preds],
            "total":       len(preds),
        }
    return await asyncio.to_thread(_do)


@router.post("/api/admin/brain/writer-advisor/shadow-tick")
async def brain_writer_advisor_shadow_tick(
    _user: dict = Depends(require_admin),
):
    """Force-run the SHADOW auto-apply tick.  Honors
    writer_advisor.auto_apply_enabled (default false).  2026-10-07: runs
    in the OWNING process through _bg_run_now."""
    return await _bg_run_now("writer_advisor_shadow_auto_apply",
                             legacy_shape="spread")


@router.get("/api/admin/brain/portal-cred-prewarmer/status")
async def brain_portal_prewarmer_status(
    limit: int = 10,
    _user: dict = Depends(require_admin),
):
    """Recent portal-cred pre-warmer ticks + config knobs.

    Defeats the cold-portal 30s budget bug by keeping the
    aws_portal_auth._cred_cache populated on a background interval.
    Each tick lists eligible portal-backed S3 connections + per-conn
    outcome (warmed / cached / error).
    """
    def _do():
        from core.portal_cred_prewarmer import (
            recent_ticks, enabled as _en, interval_minutes,
            cache_ttl_seconds, max_parallel_resolutions,
        )
        return {
            "enabled":          _en(),
            "interval_minutes": interval_minutes(),
            "cache_ttl_seconds": cache_ttl_seconds(),
            "max_parallel":     max_parallel_resolutions(),
            "recent_ticks":     recent_ticks(limit=limit),
        }
    return await asyncio.to_thread(_do)


@router.post("/api/admin/brain/portal-cred-prewarmer/tick")
async def brain_portal_prewarmer_tick(
    _user: dict = Depends(require_admin),
):
    """Force-run the pre-warmer NOW (a per-pod daemon: this pod's cache,
    through _bg_run_now, 2026-10-07)."""
    return await _bg_run_now("portal_cred_prewarmer", legacy_shape="spread")


def _brain_ov_mirror() -> Dict[str, Any]:
    """Mirror inventory: total, per-status counts and how many route."""
    from core.iceberg_mirror import IcebergMirrorEngine
    eng = IcebergMirrorEngine.get_default(_db_manager)
    mirrors = eng.list_mirrors(limit=500)
    status_counter: Dict[str, int] = {}
    routing_on = 0
    for m in mirrors:
        status_counter[m.get("status", "?")] = (
            status_counter.get(m.get("status", "?"), 0) + 1
        )
        if m.get("routing_enabled"):
            routing_on += 1
    return {
        "total":      len(mirrors),
        "by_status":  status_counter,
        "routing_on": routing_on,
    }


def _brain_ov_plain_parquet() -> Dict[str, Any]:
    """Phase 151 — the plain-parquet brain section of the overview panel.

    Shows the catalog's cached-tables view + most recent sync tick + the
    discoverable-parquet-table count so admins see the parquet brain
    alongside the iceberg one in a single panel.
    """
    from core.plain_parquet_catalog import (
        PlainParquetCatalog, list_registered_parquet_tables,
        enabled as _cat_en,
    )
    from core.plain_parquet_metadata_sync import (
        recent_ticks, sync_enabled, cron_interval_minutes,
    )
    from core.plain_parquet_brain_hooks import (
        brain_enabled as _read_path_en,
    )
    from core.plain_parquet_bloom_scanner import (
        bloom_enabled as _bloom_en,
    )
    from core.plain_parquet_mirror import (
        PlainParquetMirrorEngine,
    )
    try:
        tables = list_registered_parquet_tables(_db_manager)
    except Exception as _e:
        tables = []
    try:
        catalog_state = (
            PlainParquetCatalog.get_default().state_snapshot()
        )
    except Exception as _e:
        catalog_state = {"error": str(_e)[:200]}
    try:
        mirror_state = PlainParquetMirrorEngine.get_default(
            _db_manager
        ).state_snapshot()
    except Exception as _e:
        mirror_state = {"error": str(_e)[:200]}
    return {
        "catalog_enabled":      bool(_cat_en()),
        "sync_enabled":         bool(sync_enabled()),
        "read_path_enabled":    bool(_read_path_en()),
        "bloom_scanner_enabled": bool(_bloom_en()),
        "sync_interval_minutes": cron_interval_minutes(),
        "discoverable_tables":  len(tables),
        "catalog":              catalog_state,
        "recent_ticks":         recent_ticks(limit=3),
        "mirror":               mirror_state,
    }


@router.get("/api/admin/brain/overview")
async def brain_overview(_user: dict = Depends(require_admin)):
    """Consolidated brain dashboard — single roundtrip returns every
    brain signal the admin UI needs to render the unified panel:

      * coordinator pressure + last decisions
      * cost model cache state
      * skew signals (top 10)
      * forecaster predictions (top 10)
      * writer-advisor recommendation count + top 5
      * pruning health cluster snapshot (24h)
      * mirror summary (total / ready / routing)
      * gateway summary
      * supplement scanner adaptive state
      * portal pre-warmer recent tick
      * alerts dispatcher dedup ring state

    Replaces ~10 separate fetches the scattered admin sections did
    before this endpoint.  Single call → single render → single
    refresh button.

    2026-06-10 audit follow-up: the 11 component reads are dispatched
    in parallel via a thread pool so one slow backend (e.g. a heavy
    pruning_health cluster snapshot) doesn't serialise the whole
    panel.  Per-section fail-OPEN: any individual error lands in
    that section's ``error`` field; the rest of the panel still
    renders.
    """
    def _do():
        from concurrent.futures import ThreadPoolExecutor, as_completed

        # Per-component fetchers — each one captures its own
        # exception locally so a single failing backend doesn't
        # poison the whole gather.
        def _coordinator():
            from core.brain_coordinator import (
                get_current_pressure_state, recent_reports,
            )
            return {
                "current":          get_current_pressure_state(),
                "recent_reports":   recent_reports(limit=5),
            }
        def _cost_model():
            from core.brain_cost_model import CostModel
            cm = CostModel.get_default(_db_manager)
            return cm.state_snapshot()
        def _skew():
            from core.brain_skew_detector import SkewDetector
            sd = SkewDetector.get_default(_db_manager)
            sigs = sd.detect_skewed_columns()
            return {"total": len(sigs),
                     "top":   [s.to_dict() for s in sigs[:10]]}
        def _forecaster():
            from core.brain_forecaster import WorkloadForecaster
            wf = WorkloadForecaster.get_default(_db_manager)
            preds = wf.next_24h_predictions()
            return {"total": len(preds),
                     "top":   [p.to_dict() for p in preds[:10]]}
        def _writer_advisor():
            from core.writer_advisor import WriterAdvisor
            wa = WriterAdvisor.get_default(_db_manager)
            recs = wa.compute_all()
            return {"total": len(recs),
                     "top":   [r.to_dict() for r in recs[:5]]}
        def _pruning_health():
            from core.pruning_health import PruningHealthAggregator
            agg = PruningHealthAggregator.get_default(_db_manager)
            snap = agg.cluster_snapshot(window="24h").to_dict()
            return {
                "window":             snap.get("window"),
                "total_queries":      snap.get("total_queries"),
                "avg_prune_pct":      snap.get("avg_prune_pct"),
                "p95_prune_pct":      snap.get("p95_prune_pct"),
                "alerts":             snap.get("alerts") or [],
                "top_worst_tables":   (snap.get("top_worst_tables")
                                        or [])[:5],
            }
        def _mirror():
            return _brain_ov_mirror()
        def _output_gateway():
            from core.output_gateway import OutputGateway
            gw = OutputGateway.get_default(_db_manager)
            return gw.stats()
        def _supplement_backpressure():
            from core.iceberg_metadata_sync import adaptive_state
            return adaptive_state()
        def _portal_prewarmer():
            from core.portal_cred_prewarmer import (
                recent_ticks, enabled as _en, warm_scope,
            )
            # ``warm_scope`` is the half the tile was missing.  The cache
            # is ``aws_portal_auth._cred_cache`` -- a module-level dict --
            # so "the pre-warmer is enabled and ticking" says nothing about
            # whether THIS pod's queries benefit.  It reports which process
            # is covered and why, and says "unknown" rather than "not
            # warmed" when the pod role cannot be resolved.
            return {"enabled": _en(),
                     "recent":  recent_ticks(limit=3),
                     "warm_scope": warm_scope()}
        def _alerts():
            from core.pruning_alerts import (
                PruningAlertDispatcher, undelivered_summary,
            )
            d = PruningAlertDispatcher.get_default(_db_manager)
            # The dashboard's alert tile showed only what was DELIVERED,
            # which on a default deployment is nothing at all.  The
            # undelivered counts are the half an operator needs.
            return {"recent": d.recent_history(limit=5),
                     "delivery": undelivered_summary(_db_manager,
                                                     since_hours=168)}
        # Phase 151 — plain parquet brain section.  Shows the catalog's
        # cached-tables view + most recent sync tick + the discoverable-
        # parquet-table count so admins see the parquet brain alongside
        # the iceberg one in a single panel.
        def _plain_parquet():
            return _brain_ov_plain_parquet()

        fetchers = [
            ("coordinator",             _coordinator),
            ("cost_model",              _cost_model),
            ("skew",                    _skew),
            ("forecaster",              _forecaster),
            ("writer_advisor",          _writer_advisor),
            ("pruning_health",          _pruning_health),
            ("mirror",                  _mirror),
            ("output_gateway",          _output_gateway),
            ("supplement_backpressure", _supplement_backpressure),
            ("portal_prewarmer",        _portal_prewarmer),
            ("alerts",                  _alerts),
            ("plain_parquet",           _plain_parquet),
        ]

        # 12 parallel calls capped at 8 workers — keeps DB connection
        # pool happy while still pushing all the in-memory reads
        # through immediately.
        results: Dict[str, Any] = {}
        with ThreadPoolExecutor(
            max_workers=min(8, len(fetchers)),
            thread_name_prefix="brain-overview",
        ) as pool:
            futures = {pool.submit(fn): name for name, fn in fetchers}
            for fut in as_completed(futures):
                name = futures[fut]
                try:
                    results[name] = fut.result()
                except Exception as exc:
                    results[name] = {"error": str(exc)[:200]}

        out: Dict[str, Any] = {
            "computed_at": datetime.now(timezone.utc).isoformat(),
            **results,
        }
        return out

    return await asyncio.to_thread(_do)


# Legacy serial brain-overview body removed 2026-06-10 — the parallel
# implementation above handles all callers with the same per-section
# fail-OPEN error isolation.  Dead-code block deleted in this commit.


@router.post("/api/admin/iceberg/mirror/cleanup")
async def iceberg_mirror_cleanup(
    body: Optional[Dict[str, Any]] = None,
    _user: dict = Depends(require_admin),
):
    """Force-run cleanup_stale.

    Body: {retention_days?: int}  (defaults to iceberg.mirror.stale_retention_days)
    """
    days = None
    if body and "retention_days" in body:
        try:
            days = int(body["retention_days"])
        except Exception:
            days = None

    def _do():
        from core.iceberg_mirror import IcebergMirrorEngine
        engine = IcebergMirrorEngine.get_default(_db_manager)
        return engine.cleanup_stale(retention_days=days)
    return await asyncio.to_thread(_do)


# ─── Phase 150: output gateway admin endpoints ──────────────────────────


@router.get("/api/admin/output-gateway/stats")
async def output_gateway_stats(_user: dict = Depends(require_admin)):
    """Roll-up stats + config view."""
    def _do():
        from core.output_gateway import OutputGateway
        gw = OutputGateway.get_default(_db_manager)
        return gw.stats()
    return await asyncio.to_thread(_do)


@router.get("/api/admin/output-gateway/list")
async def output_gateway_list(
    limit: int = 200,
    _user: dict = Depends(require_admin),
):
    """List meta.json contents for every gateway entry, newest first."""
    def _do():
        from core.output_gateway import OutputGateway
        gw = OutputGateway.get_default(_db_manager)
        return {"entries": gw.list_entries(limit=max(1, min(1000, int(limit))))}
    return await asyncio.to_thread(_do)


@router.get("/api/admin/output-gateway/events")
async def output_gateway_events(
    limit: int = 100,
    _user: dict = Depends(require_admin),
):
    """Recent event ring (store / hit / invalidate / snapshot_bulk_delete)
    + the last 10 cleanup ticks."""
    # 2026-10-07 -- store/hit events come from the query path (this pod);
    # cleanup TICKS from the daemon, answered by the process that runs it.
    def _do():
        from core.output_gateway import get_recent_events
        return get_recent_events(limit=max(1, min(200, int(limit))))
    from core.daemon_snapshots import daemon_snapshot
    snap = await daemon_snapshot("output_gateway.ticks", limit=10,
                                 proxy=_scheduler_worker_proxy)
    out = {"events": await asyncio.to_thread(_do),
           "ticks": (snap["data"] or {}).get("ticks", []),
           "ticks_answered_by": snap["answered_by"]}
    if snap.get("warning"):
        out["warning"] = snap["warning"]
    return out


@router.post("/api/admin/output-gateway/cleanup")
async def output_gateway_cleanup(_user: dict = Depends(require_admin)):
    """Force-run the expired-entry cleanup (same as the 6h cron tick)."""
    def _do():
        from core.output_gateway import output_gateway_cleanup_tick
        return output_gateway_cleanup_tick(_db_manager)
    return await asyncio.to_thread(_do)


# ─── Phase 148 — pruning health admin endpoints ─────────────────────────


@router.get("/api/admin/pruning/cluster-snapshot")
async def pruning_cluster_snapshot(
    window: str = "24h",
    cache_ok: bool = True,
    _user: dict = Depends(require_admin),
):
    """Cluster-wide pruning effectiveness over ``window``.

    Returns:
      {window, total_queries, total_tables, avg_prune_pct,
       p50/p95/p99_prune_pct, stage_drops_total, top_worst_tables,
       top_worst_queries, alerts, computed_at}

    Cached per-pod for ``pruning_health.snapshot_cache_seconds``
    (default 60s).  Pass ``cache_ok=false`` to force a fresh
    aggregation (operator's "Refresh now" button).
    """
    def _do():
        from core.pruning_health import PruningHealthAggregator
        agg = PruningHealthAggregator.get_default(_db_manager)
        return agg.cluster_snapshot(
            window=window, cache_ok=bool(cache_ok),
        ).to_dict()
    return await asyncio.to_thread(_do)


@router.get("/api/admin/pruning/table-card")
async def pruning_table_card(
    bucket: str,
    table_prefix: str,
    window: str = "7d",
    _user: dict = Depends(require_admin),
):
    """Per-table pruning report card.

    Returns TableHealth.to_dict() — including trend series + top
    unprunable filter columns + week-over-week delta when prior data
    is available.
    """
    def _do():
        from core.pruning_health import PruningHealthAggregator
        agg = PruningHealthAggregator.get_default(_db_manager)
        return agg.table_card(
            bucket=bucket, table_prefix=table_prefix, window=window,
        ).to_dict()
    return await asyncio.to_thread(_do)


@router.get("/api/admin/pruning/supplement-coverage")
async def pruning_supplement_coverage(
    bucket: str,
    table_prefix: str,
    window: str = "30d",
    _user: dict = Depends(require_admin),
):
    """Supplement coverage gap report for one (bucket, prefix).

    Returns columns most-queried in the window vs columns covered by
    column-stats / bloom sidecar.  Drives "scan these N columns" hint
    on the table card.
    """
    def _do():
        from core.pruning_health import PruningHealthAggregator
        agg = PruningHealthAggregator.get_default(_db_manager)
        return agg.supplement_coverage(
            bucket=bucket, table_prefix=table_prefix, window=window,
        ).to_dict()
    return await asyncio.to_thread(_do)


def _uncovered_matching_table(c: dict, bucket: str, tprefix: str):
    """Find the registered iceberg table at (bucket, prefix) on one connection.

    Returns ``(matched, table_name)``.  ``table_name`` can be None when the
    registration itself carries no name — the caller then refuses rather than
    scanning an unnamed table.
    """
    if c.get("connection_type") != "s3":
        return False, None
    cfg = c.get("config") or {}
    if (cfg.get("bucket_name") or "") != bucket:
        return False, None
    for rt in cfg.get("registered_tables") or []:
        if (rt.get("s3_prefix") or "").rstrip("/") != tprefix:
            continue
        if rt.get("format") != "iceberg":
            continue
        return True, rt.get("name")
    return False, None


def _uncovered_resolve(conns, bucket: str, tprefix: str):
    """Walk active connections for the Iceberg table at (bucket, prefix).

    Returns ``(conn_record, table_name, other_format)``.  First Iceberg hit
    wins -- if two connections somehow expose the same physical location,
    ops disambiguate via the existing /scan endpoint.  ``other_format`` is
    ``(declared format, name)`` for a table that IS registered at the
    prefix with a NON-iceberg format (FB-43, 2026-09-20), so the caller's
    refusal can name the real reason instead of "may have been
    unregistered"; None when nothing else is registered there.
    """
    from core.pruning_probe import find_registered_table
    other_format: Optional[Tuple[str, str]] = None
    for c in conns or []:
        matched, name = _uncovered_matching_table(c, bucket, tprefix)
        if matched:
            return c, name, other_format
        if other_format is None and c.get("connection_type") == "s3":
            _rt = find_registered_table(c, bucket, tprefix)
            if _rt is not None:
                other_format = ((_rt.get("format") or "parquet").lower(),
                                _rt.get("name") or tprefix)
    return None, None, other_format


@router.post("/api/admin/pruning/scan-uncovered-columns")
async def pruning_scan_uncovered_columns(
    body: Dict[str, Any], _user: dict = Depends(require_admin),
):
    """Phase 148.C — one-click scan of uncovered columns for a table.

    Resolves (bucket, table_prefix) to a registered iceberg connection +
    table, then hands the column list to the existing column-stats
    scanner.  Lets ops close a coverage gap without leaving the Pruning
    Health dashboard.

    Body: {
        bucket:       str,
        table_prefix: str,                # the prefix recorded in
                                          # query_pruning_history (matches
                                          # the registered_tables[].s3_prefix)
        columns:      List[str],          # uncovered columns to scan
        max_workers:  Optional[int],      # default from config
    }

    Returns: same shape as /api/admin/iceberg/column-stats/scan.

    Returns 404 when no matching registered table is found — usually
    means the table was unregistered after the queries were logged.
    """
    bucket = body.get("bucket")
    tprefix = (body.get("table_prefix") or "").rstrip("/")
    cols = body.get("columns") or []
    if not bucket or not tprefix:
        raise HTTPException(
            status_code=400,
            detail="bucket and table_prefix required",
        )
    if not isinstance(cols, list) or not cols:
        raise HTTPException(
            status_code=400,
            detail="columns must be a non-empty list",
        )

    # Resolve (bucket, prefix) → (connection_id, table_name).  Walks
    # active S3 connections and finds the registered iceberg table whose
    # bucket_name + s3_prefix match.  First hit wins — if two
    # connections somehow expose the same physical location, ops
    # will need to disambiguate via the existing /scan endpoint.
    try:
        conns = await _adb(_db_manager.list_connections,
                            active_only=True, limit=500, offset=0)
        conn_record, table_name, other_format = _uncovered_resolve(
            conns, bucket, tprefix)
    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"Connection lookup failed: {exc}",
        )

    if other_format is not None and not conn_record:
        _fmt, _name = other_format
        raise HTTPException(
            status_code=400,
            detail=(
                f"Table {_name!r} at bucket={bucket} prefix={tprefix} is "
                f"registered with format {_fmt!r}.  Column-statistics scanning "
                f"reads Iceberg manifests and does not apply to a "
                f"{_fmt} layout; use the pruning probe for its partition "
                f"coverage instead."
            ),
        )
    if not conn_record or not table_name:
        raise HTTPException(
            status_code=404,
            detail=(
                f"No active iceberg table registered for "
                f"bucket={bucket} prefix={tprefix}.  The table may have "
                f"been unregistered since these queries ran."
            ),
        )

    # Delegate to the existing scan endpoint logic by re-issuing into
    # the same handler.  Same body shape, same response shape, same
    # progress tracking — so the existing scan-progress polling works
    # for this entry point too.
    return await iceberg_column_stats_scan(
        body={
            "connection_id": conn_record["id"],
            "table_name":    table_name,
            "columns":       cols,
            "max_workers":   body.get("max_workers"),
            "force":         False,
        },
        _user=_user,
    )


@router.delete("/api/admin/output-gateway/snap/{files_hash}")
async def output_gateway_delete_snap(
    files_hash: str, _user: dict = Depends(require_admin),
):
    """Bulk-delete every entry under one snapshot fingerprint.

    Use when the source iceberg snapshot rolled forward and the old
    gateway entries are guaranteed stale — saves walking individual
    meta.json files.
    """
    def _do():
        from core.output_gateway import OutputGateway
        gw = OutputGateway.get_default(_db_manager)
        deleted = gw.delete_snapshot_prefix(files_hash)
        return {"deleted": deleted, "files_hash": files_hash}
    return await asyncio.to_thread(_do)


def _ws_seconds_since(now, then):
    """Seconds between ``then`` and ``now``; None when unset or unusable."""
    try:
        return (now - then).total_seconds() if then else None
    except Exception:
        return None


def _ws_diag_row(info: dict, now) -> Dict[str, Any]:
    """One WebSocket connection's diagnostics row.

    High ``idle_seconds`` = the client is probably dead and the staleness
    pruner should be reaping it.
    """
    connected_at = info.get("connected_at")
    last_seen_at = info.get("last_seen_at") or connected_at
    age = _ws_seconds_since(now, connected_at)
    idle = _ws_seconds_since(now, last_seen_at)
    return {
        "username":      info.get("username", "anon"),
        "connected_at":  connected_at.isoformat() if connected_at else None,
        "last_seen_at":  last_seen_at.isoformat() if last_seen_at else None,
        "age_seconds":   round(age, 1) if age is not None else None,
        "idle_seconds":  round(idle, 1) if idle is not None else None,
        "message_count": info.get("message_count", 0),
    }


@router.get("/api/admin/ws-diagnostics")
async def ws_diagnostics(_user: dict = Depends(require_admin)):
    """Live snapshot of every WebSocket connection on this pod.

    Returns one row per connection with:
      * username
      * connected_at      — ISO timestamp of accept
      * last_seen_at      — ISO of most-recent receive (pong / identify / heartbeat)
      * age_seconds       — now - connected_at
      * idle_seconds      — now - last_seen_at  (HIGH = client probably dead)
      * message_count     — how many frames we sent to this client
      * stale_threshold   — current staleness prune cutoff
      * heartbeat_interval — how often we ping clients

    Use this to debug "WS disconnected" reports without server log access.
    Idle > stale_threshold means the staleness pruner should be reaping.
    """
    from datetime import datetime, timezone
    if _ws_manager is None:
        return {"error": "WebSocket manager not initialized"}

    now = datetime.now(timezone.utc)
    rows = []
    try:
        # Snapshot the dict so concurrent connect/disconnect can't cause races
        items = list(_ws_manager.connection_info.items())
    except Exception:
        items = []

    for _ws, info in items:
        rows.append(_ws_diag_row(info, now))

    # Sort newest connections first
    rows.sort(key=lambda r: r["connected_at"] or "", reverse=True)
    stale_threshold = getattr(_ws_manager, "_STALE_THRESHOLD_SECONDS", 90)
    return {
        "now":                datetime.now(timezone.utc).isoformat(),
        "total_connections":  len(rows),
        "stale_threshold":    stale_threshold,
        "heartbeat_interval": 10,
        "connections":        rows,
        "stale_count":        sum(1 for r in rows
                                   if r["idle_seconds"] is not None
                                   and r["idle_seconds"] > stale_threshold),
    }


def _preview_total_from_snapshot(md: dict) -> Optional[int]:
    """``total-data-files`` from the current snapshot's summary, or None."""
    cur_snap_id = md.get("current-snapshot-id")
    snapshots = md.get("snapshots") or []
    cur_snap = next(
        (s for s in snapshots if s.get("snapshot-id") == cur_snap_id),
        snapshots[-1] if snapshots else None,
    )
    if not cur_snap:
        return None
    summ = cur_snap.get("summary") or {}
    raw = summ.get("total-data-files")
    if raw is None:
        return None
    try:
        return int(raw)
    except (TypeError, ValueError):
        return None


def _preview_read_metadata(s3, bucket: str, s3_prefix: str,
                           _latest_metadata_key, _read_s3_json_cached):
    """Read the table's metadata.json for preview-files.

    This is one S3 GET (cached after first call).  Gives us:
      - current-snapshot-id
      - snapshot.summary["total-data-files"] for the total (no walk!)
      - partition spec for the source→field rewrite

    Returns ``(md, md_key, total_from_summary, failure_reason)``.

    2026-06-03 — user feedback: preview popup was returning
    ``{total_files: 0}`` silently when metadata.json couldn't
    be reached (proxy timeout / wrong creds / typo in bucket).
    The UI showed "0 files" with no error and admins thought
    the tool was broken.  Capture the failure cause so the
    response carries it back instead of silently degrading.
    """
    md: Dict[str, Any] = {}
    md_key = ""
    total_from_summary: Optional[int] = None
    _md_failure: Optional[str] = None
    try:
        meta_prefix = (s3_prefix.rstrip("/") + "/metadata"
                        if s3_prefix else "metadata")
        md_key = _latest_metadata_key(s3, bucket, meta_prefix,
                                        force_fresh=True)
        if not md_key:
            _md_failure = (
                f"no metadata.json under s3://{bucket}/{meta_prefix}/ — "
                "check the registered_tables s3_prefix or that the "
                "iceberg writer has finished its first commit"
            )
        else:
            md = _read_s3_json_cached(s3, bucket, md_key) or {}
            if not md:
                _md_failure = (
                    f"metadata.json at s3://{bucket}/{md_key} read "
                    "as empty — likely a corrupt write or S3 transient"
                )
            total_from_summary = _preview_total_from_snapshot(md)
    except Exception as _md_exc:
        _md_failure = (
            f"metadata.json read raised {type(_md_exc).__name__}: "
            f"{str(_md_exc)[:200]}.  Check S3 credentials / proxy / "
            f"VPC endpoint / bucket name"
        )
        logger.warning("preview-files: metadata.json direct read failed "
                        "(%s) — falling back to walk", _md_exc)
    return md, md_key, total_from_summary, _md_failure


def _preview_rewrite_filters(md: dict, filters: list,
                             build_source_to_partition_field_map):
    """Point each preview filter at the Iceberg partition FIELD name.

    Returns ``(rewritten_filters, rewrites)``; the filters come back
    untouched when the metadata offers no source→field mapping.
    """
    try:
        src_to_part = build_source_to_partition_field_map(md)
    except Exception:
        src_to_part = {}
    rewrites: list = []
    rewritten_filters = filters
    if filters and src_to_part:
        rewritten_filters = []
        for f in filters:
            fc = (f.get("col") or f.get("column") or "").strip()
            pname = src_to_part.get(fc.lower())
            if pname and pname != fc:
                nf = dict(f)
                nf["col"] = pname
                rewrites.append({"from": fc, "to": pname})
                rewritten_filters.append(nf)
            else:
                rewritten_filters.append(f)
    return rewritten_filters, rewrites


def _preview_current_spec_and_schema(md: dict, specs: list, schemas: list):
    """Pick the ACTIVE partition spec + schema out of an evolved table.

    Iceberg evolution: tables can have MULTIPLE specs/schemas over time.
    Pick the active one via default-spec-id / current-schema-id, NOT the
    last entry in the list (which could be wrong post-evolution).
    """
    # Pick the current spec by default-spec-id; fall back to first
    # spec if the field is missing or doesn't resolve.
    default_spec_id = md.get("default-spec-id")
    current_spec = None
    if default_spec_id is not None:
        current_spec = next(
            (s for s in specs if s.get("spec-id") == default_spec_id),
            None,
        )
    if current_spec is None:
        current_spec = specs[-1]  # safe fallback

    # Same for schema — use current-schema-id, not [0]
    current_schema_id = md.get("current-schema-id")
    current_schema = None
    if current_schema_id is not None:
        current_schema = next(
            (s for s in schemas if s.get("schema-id") == current_schema_id),
            None,
        )
    if current_schema is None:
        current_schema = schemas[0] if schemas else {}
    return current_spec, current_schema


def _preview_add_partition_field(f: dict, schema_cols: dict,
                                 partition_cols: list,
                                 partition_transforms: list) -> None:
    """Record one partition-spec field as a filterable column.

    Source column name is what admin should filter on —
    Iceberg applies the transform internally during pruning.
    """
    src_id = f.get("source-id") or f.get("source_id")
    transform = f.get("transform", "identity")
    src_name = schema_cols.get(src_id) if src_id is not None else None
    if src_name:
        partition_cols.append(src_name)
        # Track transform for admin awareness — non-identity
        # transforms (day/month/bucket/truncate) might surprise
        # admins who expect raw value comparison.
        if transform and transform != "identity":
            partition_transforms.append({
                "column": src_name,
                "transform": transform,
            })
    elif f.get("name"):
        partition_cols.append(f["name"])


def _preview_collect_partition_columns(md: dict, partition_cols: list,
                                       partition_transforms: list) -> None:
    """Append the columns an admin may usefully filter on, in spec order.

    Mutates the two lists in place so a mid-way failure still leaves the
    caller with what was resolved before it — the caller logs and moves on.
    """
    specs = (md.get("partition-specs") or md.get("partition_specs") or [])
    schemas = md.get("schemas") or []
    if not isinstance(specs, list) or not specs:
        return
    current_spec, current_schema = _preview_current_spec_and_schema(
        md, specs, schemas)

    schema_cols = {
        c["id"]: c["name"]
        for c in current_schema.get("fields", [])
        if isinstance(c, dict) and "id" in c and "name" in c
    }

    for f in current_spec.get("fields", []):
        _preview_add_partition_field(f, schema_cols, partition_cols,
                                     partition_transforms)


def _preview_snapshot_info(md, walk_meta: dict):
    """Resolve ``(snapshot_id, snapshot_timestamp_ms)`` for the preview response.

    Falls back to whatever the manifest walk reported when the metadata is
    unusable — a malformed snapshot list must not fail the diagnostic.
    """
    _snapshot_id = walk_meta.get("snapshot_id")
    _snapshot_ts_ms = None
    try:
        if isinstance(md, dict):
            _snapshot_id = md.get("current-snapshot-id")
            _snapshots_list = md.get("snapshots") or []
            _cur_snap = next(
                (s for s in _snapshots_list if s.get("snapshot-id") == _snapshot_id),
                None,
            )
            if _cur_snap:
                _snapshot_ts_ms = _cur_snap.get("timestamp-ms")
    except Exception:
        pass
    return _snapshot_id, _snapshot_ts_ms


def _preview_no_pruning_warning(total: int, matched: int, filters):
    """Say when a filter pruned nothing at all, or None when it did prune."""
    if total > 0 and matched == total and filters:
        return ("Filter matched ALL files — the column may not be a partition column "
                "or the value doesn't match any partition.  Check partition_columns above.")
    return None


def _preview_partial_read_warning(manifest_failures: int, failure_paths: list,
                                  total: int) -> Optional[str]:
    """BF-500 — say WHY a preview count may be short, or None when it isn't."""
    if manifest_failures and total > 0:
        return (
            f"Partial read: {manifest_failures} manifest file(s) failed "
            f"to read from S3 — file count may be incomplete.  Cache was "
            f"NOT updated (next call will retry).  Check IAM permissions "
            f"or transient S3 errors.  Sample failed paths: "
            + ", ".join(failure_paths[:3])
        )
    return None


async def _preview_resolve_table(cid, tbl):
    """Resolve ``(conn, bucket, s3_prefix)`` for preview-files, or refuse."""
    conn = await _adb(_db_manager.get_connection_raw, int(cid))
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    if conn.get("connection_type") != "s3":
        raise HTTPException(status_code=400,
                              detail="preview-files requires an S3 connection")

    cfg = conn.get("config", {})
    bucket = cfg.get("bucket_name")
    if not bucket:
        raise HTTPException(status_code=400, detail="Connection has no bucket")
    rt = next((t for t in cfg.get("registered_tables", []) if t.get("name") == tbl), None)
    if not rt:
        raise HTTPException(status_code=404, detail=f"Table '{tbl}' not registered")
    return conn, bucket, rt.get("s3_prefix", "")


def _preview_total_files(total_from_summary, matched: int, rewritten_filters):
    """Total: prefer snapshot.summary (zero extra S3 calls), else fall
    back to walk's count (when no filter, walk count == total)."""
    if total_from_summary is not None:
        return total_from_summary
    return matched if not rewritten_filters else max(matched, 0)


@router.post("/api/admin/iceberg/column-stats/preview-files")
async def iceberg_column_stats_preview_files(
    body: Dict[str, Any],
    _user: dict = Depends(require_admin),
):
    """Preview how many files would survive a partition filter — WITHOUT
    triggering a scan.  Use this to verify your filter is actually pruning
    before committing to a 12-hour scan.

    Body: {
      connection_id: int,
      table_name:    str,
      partition_filters: [{col, op, val}, ...]  (optional — empty = full count)
    }

    Returns: {
      total_files:    int   (all files in current snapshot),
      matching_files: int   (after applying partition filter),
      reduction_pct:  float (% reduction),
      partition_columns: [str]  (columns the table is partitioned BY,
                                  for hint about valid filter columns),
      sample_paths:   [str] (first 5 file paths that match — sanity check)
    }
    """
    cid = body.get("connection_id")
    tbl = body.get("table_name")
    filters = body.get("partition_filters") or []
    if not cid or not tbl:
        raise HTTPException(status_code=400,
                              detail="connection_id and table_name required")

    conn, bucket, s3_prefix = await _preview_resolve_table(cid, tbl)

    def _do_preview():
        import time as _time
        from core.s3_utilities import make_s3_client_for_conn
        from core.iceberg_reader import (
            get_iceberg_data_files,
            build_source_to_partition_field_map,
            _latest_metadata_key,
            _read_s3_json_cached,
        )

        s3 = make_s3_client_for_conn(conn)
        timings: Dict[str, float] = {}

        # ── Stage 1: read metadata.json directly (no manifest walk) ──────
        _t_meta = _time.monotonic()
        md, md_key, total_from_summary, _md_failure = _preview_read_metadata(
            s3, bucket, s3_prefix, _latest_metadata_key, _read_s3_json_cached)
        timings["metadata_read"] = round(_time.monotonic() - _t_meta, 3)
        # If metadata.json couldn't be reached AT ALL, fail loud
        # instead of silently returning {total_files: 0}.
        if _md_failure and not md:
            raise HTTPException(
                status_code=502,
                detail=f"iceberg metadata read failed: {_md_failure}",
            )

        # ── Stage 2: build rewrite map from metadata ─────────────────────
        rewritten_filters, rewrites = _preview_rewrite_filters(
            md, filters, build_source_to_partition_field_map)

        # ── Stage 3: ONE manifest walk (filtered if filter present) ──────
        # BF-499 (2026-05-28) — admin diagnostic must NEVER show stale
        # data.  The default cache-stale-while-revalidate behaviour can
        # return a snapshot from up to 1 HOUR ago, which is fine for
        # high-volume query paths but catastrophic here: an admin
        # writes new files via Starburst → presses "Preview file count"
        # → sees 0 matches → thinks the tool is broken (when really
        # the cache is just stale).  ``force_fresh=True`` also skips
        # the snapshot-keyed manifest cache so we see the LATEST
        # metadata.json + manifest contents on every click.
        sample_keys: list = []
        _t_walk = _time.monotonic()
        walk_meta: Dict[str, Any] = {}
        files_list = get_iceberg_data_files(
            s3, bucket, s3_prefix,
            partition_filters=rewritten_filters or None,
            keys_only=True, force_fresh=True,
            _out_meta=walk_meta,
        )
        timings["manifest_walk"] = round(_time.monotonic() - _t_walk, 3)
        matched = len(files_list)
        sample_keys = [f.get("key") for f in files_list[:5] if f.get("key")]

        # Total: prefer snapshot.summary (zero extra S3 calls), else fall
        # back to walk's count (when no filter, walk count == total).
        total = _preview_total_files(total_from_summary, matched,
                                     rewritten_filters)
        total_meta = walk_meta or {"metadata": md}

        logger.info("[preview-files] timings=%s total=%d matched=%d "
                     "filters=%d rewrites=%d source_of_total=%s",
                     timings, total, matched,
                     len(filters or []), len(rewrites),
                     "snapshot_summary" if total_from_summary is not None
                     else "manifest_walk")

        # Try to extract partition columns from the metadata's partition spec.
        # This tells the admin which columns are valid to filter on.
        partition_cols: list = []
        partition_transforms: list = []
        try:
            md = total_meta.get("metadata") or {}
            _preview_collect_partition_columns(md, partition_cols,
                                               partition_transforms)
        except Exception as _exc:
            logger.debug("preview-files: partition spec extraction failed: %s", _exc)

        reduction = round((1 - matched / total) * 100, 1) if total > 0 else 0

        # BF-499 — surface the resolved snapshot info so admins can verify
        # which version of the table they're querying.  If Starburst just
        # wrote new files but our snapshot_id lags, the admin can spot
        # the discrepancy here instead of guessing.  ``md_key`` was
        # resolved at Stage 1 above (line ~8343) so we already know
        # WHICH metadata.json was read.
        _snapshot_id, _snapshot_ts_ms = _preview_snapshot_info(md, walk_meta)
        _metadata_key_used = md_key or None

        # BF-500 — surface manifest-read failures so the admin sees
        # exactly why the count looks wrong.  Without this, "half the
        # files" looks like a successful read with surprising count.
        _manifest_failures = walk_meta.get("manifest_read_failures") or 0
        _failure_paths = walk_meta.get("manifest_read_failure_paths") or []
        partial_warning = _preview_partial_read_warning(
            _manifest_failures, _failure_paths, total)

        return {
            "total_files":          total,
            "matching_files":       matched,
            "reduction_pct":        reduction,
            "partition_columns":    partition_cols,
            "partition_transforms": partition_transforms,
            "filters_applied":      filters,
            "filters_rewrites":     rewrites,  # source→partition-field rewrites
            "sample_paths":         sample_keys,
            "snapshot_id":          _snapshot_id,
            "snapshot_timestamp_ms": _snapshot_ts_ms,
            "metadata_key":         _metadata_key_used,
            "force_fresh":          True,  # BF-499 — always live
            "manifest_read_failures":      _manifest_failures,  # BF-500
            "manifest_read_failure_paths": _failure_paths,      # BF-500
            "partial_read_warning":        partial_warning,     # BF-500
            "warning": _preview_no_pruning_warning(total, matched, filters),
        }

    return await asyncio.to_thread(_do_preview)


@router.post("/api/admin/s3/flush-handler-cache")
async def flush_s3_handler_cache(_user: dict = Depends(require_admin)):
    """Drop the cached S3StorageHandler instances so the next call re-builds
    them with current config (e.g. pick up new max_pool_connections after
    BF-349 without a pod restart).  Returns the number of evictions."""
    # 2026-09-01 -- ``_conn_manager`` is not a module attribute; the
    # accessor is ``get_connection_manager()``.  Not inside a try, so this
    # admin endpoint raised ImportError on every call.
    from core.connection_manager import get_connection_manager
    _conn_manager = get_connection_manager()
    if _conn_manager is None:
        raise HTTPException(503, "connection manager is not initialised")
    n = 0
    try:
        with _conn_manager._s3_lock:
            n = len(_conn_manager._s3_handlers)
            _conn_manager._s3_handlers.clear()
    except Exception as exc:
        raise HTTPException(500, f"Cache flush failed: {exc}")
    logger.info("[s3-cache] flushed %d cached S3 handlers — next call rebuilds", n)
    return {"flushed": n,
            "next_call_will_pick_up": [
                "s3.max_pool_connections", "s3.read_timeout",
                "s3.connect_timeout", "proxy.* changes",
            ]}


def _paratest_scan_one(extract_parquet_column_stats, s3, bucket: str,
                       key: str, target_columns) -> Dict[str, Any]:
    """Time one file's footer extract, recording which thread ran it."""
    import threading
    import time as _time
    tname = threading.current_thread().name
    t = _time.monotonic()
    timing: Dict[str, Any] = {}
    try:
        extract_parquet_column_stats(
            s3, bucket, key, target_columns,
            timing_out=timing,
        )
        err = None
    except Exception as exc:
        err = str(exc)[:200]
    return {
        "file":          key.rsplit("/", 1)[-1],
        "thread":        tname,
        "total":         round(_time.monotonic() - t, 3),
        "head_open":     timing.get("head_open"),
        "schema_walk":   timing.get("schema_walk"),
        "stats_extract": timing.get("stats_extract"),
        "row_groups":    timing.get("row_groups"),
        "error":         err,
    }


def _paratest_report(keys, file_count, threads_used, total_seconds, baseline,
                     sum_per_file, speedup, active_pool, per_file,
                     verdict, hint) -> Dict[str, Any]:
    """Shape the parallelism probe's answer, slowest file first."""
    return {
        "file_count":                  len(keys),
        "parallel_workers":            file_count,
        "threads_actually_used":       threads_used,
        "total_seconds":               total_seconds,
        "throughput_files_per_sec":    round(len(keys) / total_seconds, 2) if total_seconds > 0 else 0,
        "sequential_baseline_seconds": baseline,
        "sum_of_per_file_seconds":     round(sum_per_file, 3),
        "parallel_speedup":            speedup,
        "active_pool_connections":     active_pool,
        "per_file":                    sorted(per_file, key=lambda p: p["total"] or 0, reverse=True),
        "verdict":                     verdict,
        "hint":                        hint,
    }


def _paratest_verdict(speedup, threads_used, file_count, baseline):
    """Read the parallelism probe's numbers as a verdict plus a next step."""
    if speedup < file_count * 0.5 and threads_used >= file_count - 1:
        return "POOR_PARALLELISM", (
            f"Speedup {speedup}× of expected ~{file_count}× — workers ARE "
            "running on different threads but extract calls are "
            "serializing.  Likely candidates: boto3 credential refresh "
            "lock (auth_mode=portal/assume_role), GIL contention in "
            "pyarrow stats extraction, or HTTP/S connection pool "
            "exhaustion.  Try: POST /admin/s3/flush-handler-cache, "
            "narrow target_columns, or change auth_mode to keys for "
            "this connection."
        )
    if threads_used < file_count - 1:
        return "WORKERS_NOT_SCHEDULED", (
            f"Only {threads_used} thread(s) ran of {file_count} workers — "
            "ThreadPoolExecutor is serializing.  Could be Python GIL "
            "contention (high CPU % on one core) or a global lock in "
            "boto3 client.  Restart pod and re-test."
        )
    if baseline > 2.0:
        return "SLOW_PER_FILE", (
            f"Even with parallelism, slowest single file took {baseline}s. "
            "Per-file cost dominates.  Check stats_extract vs head_open "
            "in per_file — if stats_extract > 1s, narrow target_columns; "
            "if head_open > 1s, S3 latency is the bottleneck (network)."
        )
    return "OK", ("Looks healthy — full scan slowness is elsewhere "
                  "(DB writes, batch flush, or queue drain).")


def _paratest_pool_size(s3):
    """The boto3 client's configured connection-pool size, or None."""
    try:
        return int(s3.meta.config.max_pool_connections)
    except Exception:
        return None


@router.post("/api/admin/iceberg/column-stats/parallelism-test")
async def iceberg_column_stats_parallelism_test(
    body: Dict[str, Any],
    _user: dict = Depends(require_admin),
):
    """Run extract_parquet_column_stats on N files in parallel and report
    per-thread timing.  Tells us whether the slow full-scan is bottlenecked
    on per-file cost (workers fast individually) or on parallelism
    (workers serializing on shared resource — credentials, GIL, etc.).

    Body: {connection_id, table_name, file_count?: 8, target_columns?: [...]}

    Returns: {
      file_count, parallel_workers, total_seconds, throughput_files_per_sec,
      sequential_baseline_seconds,  # max single-file time
      parallel_speedup,             # baseline*N / total — should be ~N
      per_file: [{file, thread, total, head_open, schema_walk, stats_extract}],
      verdict, hint
    }
    """
    import time as _time
    from concurrent.futures import ThreadPoolExecutor, as_completed
    cid = body.get("connection_id")
    tbl = body.get("table_name")
    file_count = max(2, min(int(body.get("file_count", 8) or 8), 32))
    target_columns = body.get("target_columns")
    if not cid or not tbl:
        raise HTTPException(400, "connection_id and table_name required")

    conn = await _adb(_db_manager.get_connection_raw, int(cid))
    if not conn or conn.get("connection_type") != "s3":
        raise HTTPException(400, "S3 connection required")
    cfg = conn.get("config", {})
    bucket = cfg.get("bucket_name")
    rt = next((t for t in cfg.get("registered_tables", []) if t.get("name") == tbl), None)
    if not rt:
        raise HTTPException(404, f"Table '{tbl}' not registered")
    s3_prefix = rt.get("s3_prefix", "")

    def _do():
        from core.s3_utilities import make_s3_client_for_conn
        from core.iceberg_reader import get_iceberg_data_files
        from core.iceberg_column_stats import extract_parquet_column_stats

        s3 = make_s3_client_for_conn(conn)
        out_meta: Dict[str, Any] = {}
        files = get_iceberg_data_files(
            s3, bucket, s3_prefix, partition_filters=None, keys_only=True,
            force_fresh=False, _out_meta=out_meta,
        )
        keys = [f.get("key") for f in files[:file_count] if f.get("key")]
        if not keys:
            return {"error": "No files to test"}

        per_file: List[Dict[str, Any]] = []

        def _scan_one(key: str) -> Dict[str, Any]:
            return _paratest_scan_one(extract_parquet_column_stats, s3,
                                      bucket, key, target_columns)

        # Run in parallel
        wall_t0 = _time.monotonic()
        with ThreadPoolExecutor(max_workers=file_count,
                                 thread_name_prefix="qs-paratest") as ex:
            futs = [ex.submit(_scan_one, k) for k in keys]
            for fut in as_completed(futs):
                per_file.append(fut.result())
        total_seconds = round(_time.monotonic() - wall_t0, 3)

        # Compute baseline + speedup
        per_total = [p["total"] for p in per_file if p["total"] is not None]
        baseline = max(per_total) if per_total else 0
        sum_per_file = sum(per_total)
        # Perfect parallelism: total ≈ baseline (slowest file).
        # No parallelism: total ≈ sum(per_total).
        # We compute speedup as sum / wall — closer to N means better parallelism.
        speedup = round(sum_per_file / total_seconds, 2) if total_seconds > 0 else 0
        threads_used = len({p["thread"] for p in per_file})

        verdict, hint = _paratest_verdict(speedup, threads_used, file_count,
                                          baseline)

        active_pool = _paratest_pool_size(s3)

        return _paratest_report(keys, file_count, threads_used, total_seconds,
                                baseline, sum_per_file, speedup, active_pool,
                                per_file, verdict, hint)

    return await asyncio.to_thread(_do)


def _diagnose_proxy_enabled() -> bool:
    """Is the boto3 client behind the configured proxy?

    2026-08-19 -- was `import proxy`, which always raised, so this
    diagnostic reported proxy_enabled=false no matter what was
    configured: the tool operators use to debug S3 slowness was
    lying about the proxy.  ``proxy_cfg`` is the right name and was
    already in use elsewhere in this module at the time.
    """
    try:
        from core.config import proxy_cfg as _prx_cfg
        return bool(getattr(_prx_cfg, "enabled", False))
    except Exception:
        return False


def _diagnose_e2e_extract(s3, bucket: str, first_key: str, target_columns):
    """End-to-end footer extract — same code path the scan uses.

    Critical: tells us whether the per-file slowness is in the
    pyarrow stats extraction (wide table, many row groups) or
    in the S3 round trips.  Returns
    ``(timing, total_seconds, error, column_count)``.
    """
    import time as _time
    from core.iceberg_column_stats import extract_parquet_column_stats
    e2e_timing: Dict[str, Any] = {}
    e2e_t0 = _time.monotonic()
    e2e_error: Optional[str] = None
    try:
        stats = extract_parquet_column_stats(
            s3, bucket, first_key,
            target_columns=target_columns,
            timing_out=e2e_timing,
        )
        stats_count = len(stats)
    except Exception as exc:
        e2e_error = str(exc)[:300]
        stats_count = 0
    return e2e_timing, round(_time.monotonic() - e2e_t0, 3), e2e_error, stats_count


@router.post("/api/admin/iceberg/column-stats/diagnose")
async def iceberg_column_stats_diagnose(
    body: Dict[str, Any],
    _user: dict = Depends(require_admin),
):
    """Time a single S3 footer read to diagnose slow column-stats scan rates.

    Body: {
      connection_id: int   (required)
      table_name:    str   (required) — must be a registered Iceberg table
    }

    Returns: {
      head_seconds:  float  — HEAD object latency
      get_seconds:   float  — ranged GET (256KB) latency
      total_seconds: float  — sum
      bytes_read:    int    — bytes returned by the GET
      proxy_enabled: bool   — whether the boto3 client is behind the proxy
      file_path:     str    — the file that was probed
      error:         str    (only on failure)
    }

    Use this to identify whether slow scans are network-bound (per-request
    latency too high) vs concurrency-bound (parallelism not effective) vs
    DB-bound (writes saturating the SQLite/PG).
    """
    import time as _time
    cid = body.get("connection_id")
    tbl = body.get("table_name")
    if not cid or not tbl:
        raise HTTPException(
            status_code=400,
            detail="connection_id and table_name required",
        )

    conn, bucket, s3_prefix = await _resolve_registered_iceberg_table(
        int(cid), tbl,
        "diagnose requires an S3 connection",
        "diagnose is Iceberg-only")

    def _do_diagnose():
        from core.s3_utilities import make_s3_client_for_conn
        from core.iceberg_reader import get_iceberg_data_files

        s3 = make_s3_client_for_conn(conn)
        # Resolve the latest snapshot and pick the FIRST data file
        out_meta: Dict[str, Any] = {}
        files = get_iceberg_data_files(
            s3, bucket, s3_prefix,
            partition_filters=None, keys_only=True,
            force_fresh=False,
            _out_meta=out_meta,
        )
        if not files:
            return {"error": "Snapshot has no data files to probe"}
        first_key = files[0].get("key")
        if not first_key:
            return {"error": "First file has no key"}

        # Time HEAD
        t0 = _time.monotonic()
        try:
            head = s3.head_object(Bucket=bucket, Key=first_key)
        except Exception as exc:
            return {"error": f"HEAD failed: {exc}"}
        head_seconds = _time.monotonic() - t0
        size = int(head.get("ContentLength", 0))

        # Time ranged GET (last 256KB — that's where the parquet footer lives)
        range_start = max(0, size - 262_144)
        range_end = size - 1
        t1 = _time.monotonic()
        try:
            resp = s3.get_object(
                Bucket=bucket, Key=first_key,
                Range=f"bytes={range_start}-{range_end}",
            )
            data = resp["Body"].read()
        except Exception as exc:
            return {
                "head_seconds": round(head_seconds, 3),
                "error": f"GET failed: {exc}",
            }
        get_seconds = _time.monotonic() - t1

        # Detect proxy from config
        proxy_enabled = _diagnose_proxy_enabled()

        e2e_timing, e2e_total, e2e_error, stats_count = _diagnose_e2e_extract(
            s3, bucket, first_key, body.get("target_columns"))

        # Active pool size on the s3 client we just used — confirms whether
        # BF-349 (default 64) is in effect or the cached handler still has
        # the old default (25).  If pool < max_workers, scans are slow.
        active_pool = _paratest_pool_size(s3)

        return {
            "head_seconds":      round(head_seconds, 3),
            "get_seconds":       round(get_seconds, 3),
            "total_seconds":     round(head_seconds + get_seconds, 3),
            "bytes_read":        len(data),
            "proxy_enabled":     proxy_enabled,
            "file_path":         first_key,
            "file_size":         size,
            # End-to-end stats extract (the actual scan cost per file)
            "extract_e2e_seconds": e2e_total,
            "extract_breakdown": e2e_timing,    # {head_open, schema_walk, stats_extract, row_groups, columns_iterated}
            "extract_columns":   stats_count,
            "extract_error":     e2e_error,
            # Pool sanity — if < typical max_workers (32), bump
            # s3.max_pool_connections OR call /s3/flush-handler-cache
            "active_pool_connections": active_pool,
            "max_workers_default":     32,
            "pool_warning": (
                f"Active pool {active_pool} < typical max_workers 32 — "
                "scans will be throttled by urllib3 connection discards. "
                "POST /api/admin/s3/flush-handler-cache to refresh."
                if active_pool is not None and active_pool < 32 else None
            ),
        }

    return await asyncio.to_thread(_do_diagnose)


def _scan_all_parse_tables_filter(tables_filter_raw: list):
    """Split a scan-all ``tables`` filter into scope, column and partition maps.

    Returns ``(tables_filter, cols_per_table, parts_per_table)``; an entry whose
    connection_id / table_name will not coerce is dropped, not fatal.
    """
    tables_filter: set = set()
    cols_per_table: Dict[Tuple[int, str], List[str]] = {}
    parts_per_table: Dict[Tuple[int, str], List[dict]] = {}
    for t in tables_filter_raw:
        try:
            cid_t = int(t.get("connection_id"))
            tname = str(t.get("table_name") or "")
            tables_filter.add((cid_t, tname))
            # Per-table column whitelist (optional)
            t_cols = t.get("columns")
            if isinstance(t_cols, list) and t_cols:
                cols_per_table[(cid_t, tname)] = [str(c) for c in t_cols if c]
            # Per-table partition filters (optional) — list of
            # {col, op, val} dicts in iceberg_reader's adv_filters format
            # e.g. [{"col":"business_close_date","op":"equals","val":"2025-09-30"}]
            t_parts = t.get("partition_filters")
            if isinstance(t_parts, list) and t_parts:
                parts_per_table[(cid_t, tname)] = list(t_parts)
        except (TypeError, ValueError):
            continue
    return tables_filter, cols_per_table, parts_per_table


async def _raw_s3_connection(m: dict) -> Optional[Dict[str, Any]]:
    """Decrypted row for one masked connection, but only when it is S3."""
    try:
        raw = await _adb(_db_manager.get_connection_raw, int(m.get("id")))
        if raw and raw.get("connection_type") == "s3":
            return raw
    except Exception:
        return None
    return None


async def _scan_all_resolve_connections(cid) -> List[Dict[str, Any]]:
    """Resolve target connections — either one explicit, or all S3 ones."""
    if cid:
        conn = await _adb(_db_manager.get_connection_raw, int(cid))
        if not conn:
            raise HTTPException(status_code=404, detail="Connection not found")
        if conn.get("connection_type") != "s3":
            raise HTTPException(
                status_code=400,
                detail="scan-all is S3 / Iceberg only",
            )
        return [conn]
    # All S3 connections
    masked = await _adb(_db_manager.list_connections) or []
    connections = []
    for m in masked:
        raw = await _raw_s3_connection(m)
        if raw:
            connections.append(raw)
    return connections


def _scan_all_table_in_scope(rt: dict, conn: dict, tables_filter: set):
    """``(table_name, s3_prefix)`` when this registration is in scope, else ``(None, None)``.

    Out of scope = not iceberg, missing name or prefix, or excluded by the
    caller's per-table filter.
    """
    if rt.get("format") != "iceberg":
        return None, None
    tname = rt.get("name")
    tprefix = rt.get("s3_prefix", "")
    if not tname or not tprefix:
        return None, None
    # Apply per-table filter if caller provided one
    if tables_filter and (int(conn.get("id")), tname) not in tables_filter:
        return None, None
    return tname, tprefix


def _scan_all_connection_work(conn: dict, tables_filter: set,
                              seen_bucket_prefix: set,
                              work: list, skipped_dups: list) -> None:
    """Append one connection's Iceberg tables to the shared scan work list.

    Deduplication: if two
    connections register the same (bucket, s3_prefix), only the FIRST
    one is scanned — V2 supplement schema is keyed on bucket+prefix
    so the result is shared anyway.  Avoids racing concurrent writers
    on the same composite key.
    """
    cfg = conn.get("config") or {}
    bucket = cfg.get("bucket_name", "")
    if not bucket:
        return
    for rt in cfg.get("registered_tables", []) or []:
        tname, tprefix = _scan_all_table_in_scope(rt, conn, tables_filter)
        if tname is None:
            continue
        _norm_prefix = (tprefix or "").rstrip("/")
        dup_key = (bucket, _norm_prefix)
        if dup_key in seen_bucket_prefix:
            skipped_dups.append({
                "connection_id": conn.get("id"),
                "connection_name": conn.get("name") or "",
                "bucket": bucket,
                "table_name": tname,
                "s3_prefix": tprefix,
                "reason": "duplicate (bucket, prefix) — shared scan via another connection",
            })
            continue
        seen_bucket_prefix.add(dup_key)
        work.append({
            "connection_id":   conn.get("id"),
            "connection_name": conn.get("name") or "",
            "bucket":          bucket,
            "table_name":      tname,
            "s3_prefix":       tprefix,
        })


def _scan_all_build_worklist(connections: list, tables_filter: set):
    """Build the (connection, table) work list upfront so the response
    tells the caller exactly what's queued.  Returns ``(work, skipped_dups)``.
    """
    work: list = []
    seen_bucket_prefix: set = set()
    skipped_dups: list = []
    for conn in connections:
        _scan_all_connection_work(conn, tables_filter, seen_bucket_prefix,
                                  work, skipped_dups)
    return work, skipped_dups


def _scan_all_imports() -> Dict[str, Any]:
    """Resolve the scan-all worker's imports ONCE, before any table is touched.

    Deliberately at the top of the run rather than per table: a broken install
    must fail the whole background job, not be recorded as a per-table error.
    """
    from core.s3_utilities import make_s3_client_for_conn
    from core.iceberg_reader import (
        get_iceberg_data_files,
        build_source_to_partition_field_map,
    )
    from core.iceberg_column_stats import (
        scan_files_to_supplement,
        progress_register, progress_update, progress_finish,
    )
    return {
        "make_s3_client_for_conn":             make_s3_client_for_conn,
        "get_iceberg_data_files":              get_iceberg_data_files,
        "build_source_to_partition_field_map": build_source_to_partition_field_map,
        "scan_files_to_supplement":            scan_files_to_supplement,
        "progress_register":                   progress_register,
        "progress_update":                     progress_update,
        "progress_finish":                     progress_finish,
    }


def _scan_all_read_metadata(s3, w: dict, build_source_to_partition_field_map):
    """Read metadata.json directly (one cached S3 GET) — no
    manifest walk needed for the rewrite map + pre-prune
    total.  Same fast path as preview-files (BF-354).

    Returns ``(src_to_part, total_pre_prune)``; an unreadable
    metadata.json yields ``({}, None)`` and is only logged.
    """
    _total_pre_prune: Optional[int] = None
    try:
        from core.iceberg_reader import (
            _latest_metadata_key as _mk,
            _read_s3_json_cached as _rj,
        )
        _mp = (w["s3_prefix"].rstrip("/") + "/metadata"
                if w["s3_prefix"] else "metadata")
        _md_key = _mk(s3, w["bucket"], _mp)
        _md = _rj(s3, w["bucket"], _md_key) or {} if _md_key else {}
        _src_to_part = build_source_to_partition_field_map(_md)
        # Pre-prune total from snapshot.summary
        _snaps = _md.get("snapshots") or []
        _csid = _md.get("current-snapshot-id")
        _csnap = next(
            (s for s in _snaps if s.get("snapshot-id") == _csid),
            _snaps[-1] if _snaps else None,
        )
        if _csnap:
            _summ = _csnap.get("summary") or {}
            try:
                _total_pre_prune = int(_summ.get("total-data-files"))
            except (TypeError, ValueError):
                _total_pre_prune = None
    except Exception as _meta_exc:
        logger.debug("scan-all: meta read for rewrite failed: %s", _meta_exc)
        _src_to_part = {}
    return _src_to_part, _total_pre_prune


def _scan_all_rewrite_filters(src_to_part: dict, part_filters: list):
    """Point each partition filter at the Iceberg partition FIELD name.

    Returns ``(part_filters, filter_rewrites)`` — both unchanged when the
    table's spec offers no source→field mapping.
    """
    _filter_rewrites: list = []
    if not src_to_part:
        return part_filters, _filter_rewrites
    _rewritten = []
    for f in part_filters:
        fc = (f.get("col") or f.get("column") or "").strip()
        pname = src_to_part.get(fc.lower())
        if pname and pname != fc:
            nf = dict(f)
            nf["col"] = pname
            _rewritten.append(nf)
            _filter_rewrites.append({"from": fc, "to": pname})
        else:
            _rewritten.append(f)
    return _rewritten, _filter_rewrites


def _scan_all_one_table(w: dict, conn: dict, deps: dict, cols,
                        cols_per_table: dict, parts_per_table: dict,
                        force: bool, max_workers: int):
    """Scan one table's parquet footers into the column-stats supplement.

    Returns ``(record, is_error, cancelled)`` — the caller decides whether a
    failed or cancelled table stops the rest of the scan-all run.
    """
    make_s3_client_for_conn = deps["make_s3_client_for_conn"]
    get_iceberg_data_files = deps["get_iceberg_data_files"]
    build_source_to_partition_field_map = deps["build_source_to_partition_field_map"]
    scan_files_to_supplement = deps["scan_files_to_supplement"]
    progress_register = deps["progress_register"]
    progress_update = deps["progress_update"]
    progress_finish = deps["progress_finish"]

    s3 = make_s3_client_for_conn(conn)
    out_meta: Dict[str, Any] = {}
    # Per-table partition filter — if admin specified, only
    # files matching the partition values are scanned.
    _part_filters = parts_per_table.get(
        (int(w["connection_id"]), str(w["table_name"])))
    # First call without filter to get metadata for the
    # source→partition-field rewrite, then apply rewritten
    # filter on the second call.  Cheap because metadata
    # is cached snapshot-keyed.
    _filter_rewrites: list = []
    _total_pre_prune: Optional[int] = None
    if _part_filters:
        _src_to_part, _total_pre_prune = _scan_all_read_metadata(
            s3, w, build_source_to_partition_field_map)
        _part_filters, _filter_rewrites = _scan_all_rewrite_filters(
            _src_to_part, _part_filters)
    files = get_iceberg_data_files(
        s3, w["bucket"], w["s3_prefix"],
        partition_filters=_part_filters, keys_only=True,
        force_fresh=False,
        _out_meta=out_meta,
    )
    snap = out_meta.get("snapshot_id")
    if not snap:
        return ({**w, "status": "error",
                 "error": "snapshot resolution failed"}, True, False)
    file_keys = [f.get("key") for f in files if f.get("key")]
    _w_prefix = (w["s3_prefix"] or "").rstrip("/")
    if force:
        try:
            _db_manager.iceberg_col_stats_clear(
                bucket=w["bucket"],
                table_prefix=_w_prefix,
                snapshot_id=str(snap),
            )
        except Exception:
            pass
    _job_id = f"scanall-{w['connection_id']}-{w['table_name']}-{uuid.uuid4().hex[:6]}"
    # Per-table column override beats the global cols arg.
    _per_table_cols = cols_per_table.get(
        (int(w["connection_id"]), str(w["table_name"])))
    _use_cols = _per_table_cols if _per_table_cols else cols
    progress_register(
        _job_id,
        connection_id=w["connection_id"],
        table_name=w["table_name"],
        total=len(file_keys),
        bucket=w["bucket"],
        table_prefix=_w_prefix,
        target_columns=_use_cols,
        partition_filters=_part_filters,
        filter_rewrites=_filter_rewrites or None,
        total_pre_prune=_total_pre_prune,
    )
    def _pf(done, total, scanned=0, skipped=0, failed=0,
            _jid=_job_id):
        progress_update(_jid, done=done, scanned=scanned,
                        skipped=skipped, failed=failed)
    # Register a cancellation flag — admin can hit /cancel to stop
    from core.iceberg_column_stats import _new_cancel_event, _drop_cancel_event
    _cancel_ev = _new_cancel_event(_job_id)
    try:
        summary = scan_files_to_supplement(
            db_manager=_db_manager,
            s3_client=s3,
            bucket=w["bucket"],
            table_prefix=_w_prefix,
            snapshot_id=str(snap),
            file_keys=file_keys,
            target_columns=_use_cols,
            max_workers=max_workers,
            cancel_event=_cancel_ev,
            skip_already_scanned=not force,
            connection_id=w["connection_id"],   # telemetry
            table_name=w["table_name"],         # telemetry
            progress_fn=_pf,
        )
        final_status = "cancelled" if summary.get("cancelled") else "done"
        progress_finish(_job_id, status=final_status, summary=summary)
    except Exception as _se:
        progress_finish(_job_id, status="error",
                        error=str(_se)[:300])
        _drop_cancel_event(_job_id)
        raise
    _drop_cancel_event(_job_id)
    record = {
        **w, "status": final_status,
        "snapshot_id": str(snap),
        "files_total": len(file_keys),
        "job_id": _job_id,
        **summary,
    }
    # If admin hit cancel on this job, stop iterating remaining
    # tables in scan-all.  Simpler than per-table cancel.
    return record, False, bool(summary.get("cancelled"))


def _scan_all_table_entry(w: dict, connections: list, deps: dict, cols,
                          cols_per_table: dict, parts_per_table: dict,
                          force: bool, max_workers: int):
    """Scan one queued table, turning any raised failure into a result row."""
    conn = next((c for c in connections if c.get("id") == w["connection_id"]), None)
    if not conn:
        return {**w, "status": "error", "error": "connection lookup failed"}, True, False
    try:
        return _scan_all_one_table(w, conn, deps, cols, cols_per_table,
                                   parts_per_table, force, max_workers)
    except Exception as exc:
        logger.warning(
            "scan-all failed for conn=%s table=%s: %s",
            w["connection_id"], w["table_name"], exc,
        )
        return {**w, "status": "error", "error": str(exc)[:300]}, True, False


def _scan_all_run(work: list, connections: list, cols, cols_per_table: dict,
                  parts_per_table: dict, force: bool, max_workers: int,
                  stop_on_error: bool) -> list:
    """Scan every queued table in turn; stop early on error or cancellation."""
    deps = _scan_all_imports()
    results = []
    for w in work:
        record, is_error, cancelled = _scan_all_table_entry(
            w, connections, deps, cols, cols_per_table, parts_per_table,
            force, max_workers)
        results.append(record)
        if is_error and stop_on_error:
            break
        if cancelled:
            break
    return results


@router.post("/api/admin/iceberg/column-stats/scan-all")
async def iceberg_column_stats_scan_all(body: Dict[str, Any], _user: dict = Depends(require_admin)):
    """Bulk-scan all (or specific) Iceberg tables on a connection or across all S3 connections.

    Body: {
      connection_id: Optional[int]   # if omitted, scans across all S3 connections
      tables:        Optional[List[{connection_id, table_name}]]
                                     # if provided, only these tables are scanned
      columns:       Optional[List[str]]
      max_workers:   Optional[int]   # per-table parallel boto3 workers (default 32)
      force:         Optional[bool]  # re-scan even if already cached
      stop_on_error: Optional[bool]  # default false — keep going on per-table errors
    }

    Iterates over registered_tables where format=='iceberg'.  Tables filter
    narrows the scope to specific (connection_id, table_name) pairs.
    Auto-deduplicates by (bucket, s3_prefix) — shared S3 locations across
    multiple connections are scanned exactly once (V2 supplement schema is
    keyed on bucket+prefix, so repeated scans would race on the same rows).

    Long-running for many tables × many files — wrap in a worker thread
    so the HTTP request returns BEFORE the scan completes.  Caller polls
    /scan-progress + /status to watch coverage grow.
    """
    cid = body.get("connection_id")
    cols = body.get("columns") or None
    # Cap max_workers to prevent thread/connection exhaustion (S3 conn pool
    # default 50; >128 triggers boto3 pool warnings at high concurrency).
    # Default + cap pulled from config so admins/agents can tune without
    # code edits.  iceberg.column_stats_sync_workers (default 32) sets
    # the default; iceberg.column_stats_max_workers_cap (default 128)
    # bounds how high a per-request override can go.
    try:
        from core.config import get as _cfg_get
        _default_workers = int(_cfg_get("iceberg", "column_stats_sync_workers", 32) or 32)
        _max_workers_cap = int(_cfg_get("iceberg", "column_stats_max_workers_cap", 128) or 128)
    except Exception:
        _default_workers, _max_workers_cap = 32, 128
    max_workers = max(1, min(
        int(body.get("max_workers") or _default_workers),
        _max_workers_cap,
    ))
    force = bool(body.get("force", False))
    stop_on_error = bool(body.get("stop_on_error", False))
    # tables filter: list of {connection_id, table_name, columns?, partition_filters?}
    # narrows scope and optionally provides per-table column whitelist + partition
    # value filter so admin can scan only specific partitions (e.g. a single date)
    # for huge tables — 30× speedup if you only care about today's data.
    tables_filter, cols_per_table, parts_per_table = _scan_all_parse_tables_filter(
        body.get("tables") or [])

    connections = await _scan_all_resolve_connections(cid)

    work, skipped_dups = _scan_all_build_worklist(connections, tables_filter)

    if not work:
        return {
            "queued":    0,
            "tables":    [],
            "message":   "No Iceberg tables found on the given connection(s).",
        }

    def _do_all():
        return _scan_all_run(work, connections, cols, cols_per_table,
                             parts_per_table, force, max_workers, stop_on_error)

    # Fire-and-forget: schedule the bulk scan as a background task so the
    # HTTP request doesn't sit open for minutes.  Caller polls
    # /column-stats/status to watch coverage grow.
    # 2026-08-17: was a bare ``create_task`` -- the event loop keeps only a
    # WEAK reference, so a minutes-long scan could be garbage-collected
    # mid-flight while the caller polled /column-stats/status forever
    # (CPython issue #88831).  track_bg_task holds a strong ref until done.
    import asyncio as _aio
    from core.bg_tasks import track_bg_task as _track
    _track(_aio.to_thread(_do_all))

    return {
        "queued":        len(work),
        "tables":        work,
        "skipped_dups":  skipped_dups,
        "message":       (
            f"Bulk scan kicked off in background. {len(work)} table(s) queued"
            + (f", {len(skipped_dups)} skipped as duplicates of shared S3 paths"
               if skipped_dups else "")
            + ". Poll /api/admin/iceberg/column-stats/scan-progress + /status to watch progress."
        ),
    }


# BF-359: in-process cache for /column-stats/status with stale-while-
# revalidate + single-flight.
#
# The fast variant (no DISTINCT counts) is sub-100ms; the detailed variant
# with COUNT(DISTINCT file_path/column_name) is O(rows) — 5-30s on 13M-row
# supplement tables.  Without single-flight, when the cache expired during
# active polling, every concurrent request would issue its own slow query
# in parallel, exhausting the asyncio default executor (32 threads) and
# making the entire backend api unavailable for the duration.
#
# New behaviour:
#   - Each cache entry has fresh_until (TTL-strict) and stale_until
#     (TTL × 4).  Inside fresh: serve cache.  Between fresh and stale:
#     serve cache + kick off a background refresh.  Past stale: block
#     for fresh data.
#   - Single-flight: only ONE refresh per cache_key in flight.  Other
#     concurrent requests serve stale data.
#   - During scans (frequent polling), cache stays warm forever with
#     background refreshes the user never waits on.
_COL_STATS_STATUS_CACHE: Dict[str, Any] = {}
_COL_STATS_STATUS_TTL = 30.0
_COL_STATS_STATUS_STALE_FACTOR = 4.0  # serve stale up to TTL × this
_COL_STATS_STATUS_REFRESH_LOCKS: Dict[str, "asyncio.Lock"] = {}


async def _refresh_col_stats_status(cache_key: str,
                                     connection_id: Optional[int],
                                     include_distinct_counts: bool) -> list:
    """Single-flight refresh — only one concurrent execution per cache_key."""
    import time as _time
    lock = _COL_STATS_STATUS_REFRESH_LOCKS.setdefault(
        cache_key, asyncio.Lock())
    if lock.locked():
        # Another refresh in flight — serve stale (caller decides) instead
        # of waiting in line behind it.
        existing = _COL_STATS_STATUS_CACHE.get(cache_key)
        return existing.get("rows") if existing else []
    async with lock:
        rows = await _adb(_db_manager.iceberg_col_stats_status,
                          connection_id=connection_id,
                          include_distinct_counts=include_distinct_counts)
        now = _time.monotonic()
        _COL_STATS_STATUS_CACHE[cache_key] = {
            "rows":         rows,
            "fetched_at":   now,
            "fresh_until":  now + _COL_STATS_STATUS_TTL,
            "stale_until":  now + _COL_STATS_STATUS_TTL * _COL_STATS_STATUS_STALE_FACTOR,
            "include_distinct_counts": include_distinct_counts,
        }
        # Bound the cache
        if len(_COL_STATS_STATUS_CACHE) > 32:
            for k, v in list(_COL_STATS_STATUS_CACHE.items()):
                if v.get("stale_until", 0) < now:
                    _COL_STATS_STATUS_CACHE.pop(k, None)
                    _COL_STATS_STATUS_REFRESH_LOCKS.pop(k, None)
        return rows


@router.get("/api/admin/iceberg/column-stats/status")
async def iceberg_column_stats_status(
    connection_id: Optional[int] = None,
    include_distinct_counts: bool = False,
    _user: dict = Depends(require_admin),
):
    """Per-(connection, table, snapshot) coverage telemetry.

    Default behaviour (include_distinct_counts=false): fast aggregates only
    (row count + last_scanned).  Sub-100ms even on 13M-row supplement
    tables.  files/columns return null — frontend renders '—'.

    With include_distinct_counts=true: full breakdown including distinct
    files/columns (5-30s on big tables).  Use sparingly — the polling UI
    should NOT enable this on every refresh.

    Stale-while-revalidate: when the 30s TTL expires, the next request
    triggers a background refresh and serves the stale cache immediately.
    Up to TTL × 4 (120s) of staleness is acceptable.  Past that, requests
    block for fresh data.  Single-flight ensures only ONE refresh per
    cache_key runs at a time even under concurrent expiry.
    """
    import time as _time
    cache_key = f"status:{connection_id or 'all'}:{int(include_distinct_counts)}"
    now = _time.monotonic()
    cached = _COL_STATS_STATUS_CACHE.get(cache_key)

    if cached:
        fresh_until = cached.get("fresh_until", 0)
        stale_until = cached.get("stale_until", 0)
        if now < fresh_until:
            # Cache hit — fresh
            return {
                "rows":               cached["rows"],
                "_cache_age_seconds": round(now - cached.get("fetched_at", now), 1),
                "_status":            "fresh",
            }
        if now < stale_until:
            # Stale — serve cache + kick background refresh (don't await)
            # BF-594: strong-ref track (Python issue #88831).
            from core.bg_tasks import track_bg_task as _track_bg_task_admin
            _track_bg_task_admin(_refresh_col_stats_status(
                cache_key, connection_id, include_distinct_counts))
            return {
                "rows":               cached["rows"],
                "_cache_age_seconds": round(now - cached.get("fetched_at", now), 1),
                "_status":            "stale_revalidating",
            }
        # Past stale window — must wait for fresh data

    rows = await _refresh_col_stats_status(
        cache_key, connection_id, include_distinct_counts)
    return {
        "rows":               rows,
        "_cache_age_seconds": 0,
        "_status":            "miss",
    }


@router.get("/api/admin/iceberg/file-stats/grain")
async def iceberg_file_stats_grain(_user: dict = Depends(require_admin)):
    """2026-07-13 — effective per-file column-stats storage grain on THIS pod
    ('v2' | 'both' | 'v3').  The admin UI shows this so an operator can tell
    at a glance whether scans are writing the per-file v3 table (default) or
    the legacy per-(file×column) v2 table.  Resolved through the single
    canonical accessor so it can never disagree with the writer/reader."""
    try:
        from core import config as _qs_cfg
        grain = _qs_cfg.iceberg_file_stats_grain()
    except Exception:
        grain = "v3"
    return {
        "grain": grain,
        "writes_v3": grain in ("both", "v3"),
        "writes_v2": grain in ("v2", "both"),
        "v3_table": "iceberg_file_stats_v3",
        "v2_table": "iceberg_column_stats_supplement_v2",
    }


@router.get("/api/admin/iceberg/file-stats/files")
async def iceberg_file_stats_files(
    bucket: str,
    table_prefix: str,
    snapshot_id: Optional[str] = None,
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
    _user: dict = Depends(require_admin),
):
    """2026-07-13 — Starburst-style per-file drill-down for the admin brain
    page.  Returns the per-file v3 rows for a (bucket, table_prefix[,
    snapshot]) with each file's full column_stats map so the UI can render
    per-file min/max/null/value-count/size the way Starburst surfaces
    per-file column statistics.

    Query params:
      bucket, table_prefix   (required)   — the S3 iceberg table identity
      snapshot_id            (optional)   — narrow to one snapshot
      limit (1-1000, def 100), offset     — pagination

    Returns: {total, files: [{file_path, snapshot_id, row_count, file_size,
              columns, scanned_at, column_stats}], limit, offset}.
    """
    if not bucket or not table_prefix:
        raise HTTPException(400, "bucket + table_prefix are required")
    result = await _adb(
        _db_manager.iceberg_file_stats_list_files,
        bucket, table_prefix, snapshot_id,
        limit=limit, offset=offset,
    )
    return result


async def _backfill_bust_pruning_caches(bucket, table_prefix, snapshot_id):
    """Drop stale survivor lists through the SAME chokepoint the scan path uses.

    Otherwise db-first "engages immediately" (per the backfill endpoint's
    promise) but the memo / ICE_FILE_CACHE / brain-SQL result cache keep
    serving PRE-stats survivor lists until the snapshot rolls or the TTL
    expires.  Best-effort — a cache-bust hiccup never fails the backfill.
    """
    try:
        from core.pruning_cache_invalidation import invalidate_all_pruning_caches_for
        return await _adb(
            invalidate_all_pruning_caches_for,
            bucket or "", table_prefix or "", snapshot_id,
            None, None, _db_manager, "v3_backfill",
        )
    except Exception as exc:  # never fail the backfill on a cache-bust hiccup
        logger.warning("v3 backfill: cache invalidation failed: %s", exc)
        return None


@router.post("/api/admin/iceberg/file-stats/backfill")
async def iceberg_file_stats_backfill(
    body: Dict[str, Any],
    _user: dict = Depends(require_admin),
):
    """2026-07-13 — one-shot backfill of the per-file v3 table FROM the legacy
    v2 supplement.  After a grain cutover to v3 the v3 table starts empty
    (existing v2 rows are NOT auto-migrated), so db-first falls back to the
    S3 manifest walk until the next scan.  This lets an operator populate v3
    immediately from data already in v2 — no S3 re-scan required.

    Body: {bucket?, table_prefix?, snapshot_id?, confirm_full?} — a scope
    (bucket / table_prefix / snapshot_id) is REQUIRED unless confirm_full=true.
    An unscoped backfill reads the ENTIRE v2 supplement into memory (OOM risk),
    so an empty-scope request is rejected with 400 to stop an accidental
    full-table migration from the UI.

    Returns: {rows_written: int, scope: {...}}.
    """
    bucket       = (body or {}).get("bucket")
    table_prefix = (body or {}).get("table_prefix")
    snapshot_id  = (body or {}).get("snapshot_id")
    confirm_full = bool((body or {}).get("confirm_full", False))
    if table_prefix:
        table_prefix = str(table_prefix).rstrip("/")
    if not (bucket or table_prefix or snapshot_id) and not confirm_full:
        raise HTTPException(
            400,
            "backfill requires a scope (bucket / table_prefix / snapshot_id); "
            "pass confirm_full=true to intentionally migrate the entire v2 table")
    written = await _adb(
        _db_manager.iceberg_file_stats_backfill_from_v2,
        bucket=bucket, table_prefix=table_prefix, snapshot_id=snapshot_id,
        allow_full_table=confirm_full,
    )
    # Bust the stale survivor-list caches through the SAME chokepoint the scan
    # path uses — otherwise db-first "engages immediately" (per this endpoint's
    # promise) but the memo / ICE_FILE_CACHE / brain-SQL result cache keep
    # serving PRE-stats survivor lists until the snapshot rolls or the TTL
    # expires.  Best-effort; a backfill with a concrete scope is the common
    # case (an unscoped confirm_full can't target one table, so skip it).
    invalidation = None
    if int(written or 0) > 0 and (bucket or table_prefix):
        invalidation = await _backfill_bust_pruning_caches(
            bucket, table_prefix, snapshot_id)
    return {
        "rows_written": int(written or 0),
        "scope": {"bucket": bucket, "table_prefix": table_prefix,
                  "snapshot_id": snapshot_id, "confirm_full": confirm_full},
        "cache_invalidation": invalidation,
    }


def _list_tables_coverage_index(coverage_rows) -> Dict[Tuple[str, str], dict]:
    """Index supplement coverage by (bucket, prefix) — the primary identity."""
    cov_idx: Dict[Tuple[str, str], dict] = {}
    for r in (coverage_rows or []):
        bucket = r.get("bucket") or ""
        prefix = (r.get("table_prefix") or "").rstrip("/")
        # Take latest snapshot per (bucket, prefix) — pick row with max
        # files, since multiple snapshots may exist over time.
        key = (bucket, prefix)
        if key not in cov_idx or (r.get("files") or 0) > (cov_idx[key].get("files") or 0):
            cov_idx[key] = r
    return cov_idx


def _list_tables_index_shared(conn: dict, shared_idx: Dict[Tuple[str, str], list]) -> None:
    """Record which connections register the same (bucket, prefix)."""
    cfg = conn.get("config") or {}
    bucket = cfg.get("bucket_name", "")
    if not bucket:
        return
    for rt in cfg.get("registered_tables", []) or []:
        if rt.get("format") != "iceberg":
            continue
        tprefix = (rt.get("s3_prefix") or "").rstrip("/")
        if not tprefix:
            continue
        shared_idx.setdefault((bucket, tprefix), []).append(int(conn.get("id")))


def _list_tables_coverage(cov: Optional[dict]) -> Optional[Dict[str, Any]]:
    """The coverage block for one table, or None when it was never scanned."""
    if not cov:
        return None
    return {
        "files":        int(cov.get("files") or 0),
        "columns":      int(cov.get("columns") or 0),
        "rows":         int(cov.get("rows") or 0),
        "snapshot_id":  cov.get("snapshot_id"),
        "last_scanned": str(cov.get("last_scanned")) if cov.get("last_scanned") else None,
    }


def _list_tables_rows(conn: dict, cov_idx: dict, shared_idx: dict,
                      out_tables: list) -> None:
    """Append one connection's Iceberg tables with their coverage state."""
    cfg = conn.get("config") or {}
    bucket = cfg.get("bucket_name", "")
    if not bucket:
        return
    for rt in cfg.get("registered_tables", []) or []:
        if rt.get("format") != "iceberg":
            continue
        tname = rt.get("name")
        tprefix = (rt.get("s3_prefix") or "")
        if not tname or not tprefix:
            continue
        norm_prefix = tprefix.rstrip("/")
        cov = cov_idx.get((bucket, norm_prefix))
        shared = [c for c in shared_idx.get((bucket, norm_prefix), []) if c != int(conn.get("id"))]
        out_tables.append({
            "connection_id":           int(conn.get("id")),
            "connection_name":         conn.get("name") or "",
            "bucket":                  bucket,
            "table_name":              tname,
            "s3_prefix":               tprefix,
            "shared_with_connections": shared,
            "coverage":                _list_tables_coverage(cov),
        })


@router.get("/api/admin/iceberg/column-stats/list-tables")
async def iceberg_column_stats_list_tables(
    _user: dict = Depends(require_admin),
):
    """List all Iceberg tables registered on any S3 connection, with current
    supplement coverage state.  Used by the admin UI to build a per-table
    scan picker.

    Returns: {tables: [{
      connection_id, connection_name, bucket, table_name, s3_prefix,
      shared_with_connections: [int],   # other connections at the same (bucket, prefix)
      coverage: {files: int, columns: int, last_scanned: str|null} | null,
    }]}.
    """
    masked = await _adb(_db_manager.list_connections) or []
    coverage_rows = await _adb(_db_manager.iceberg_col_stats_status)
    cov_idx = _list_tables_coverage_index(coverage_rows)

    raw_conns = []
    for m in masked:
        raw = await _raw_s3_connection(m)
        if raw:
            raw_conns.append(raw)

    # Build per-(bucket, prefix) registration map → which connections share it
    shared_idx: Dict[Tuple[str, str], list] = {}
    for conn in raw_conns:
        _list_tables_index_shared(conn, shared_idx)

    out_tables: list = []
    for conn in raw_conns:
        _list_tables_rows(conn, cov_idx, shared_idx, out_tables)
    return {"tables": out_tables}


# ─── Multi-pod prep PR1: event bus observability ──────────────────────────────

@router.get("/api/admin/event-bus/recent")
async def event_bus_recent(
    limit: int = Query(100, ge=1, le=1000),
    event_type: Optional[str] = None,
    username: Optional[str] = None,
    _user: dict = Depends(require_admin),
):
    """Return recent events from the in-memory ring buffer.

    Multi-pod prep — see docs/multi-pod-architecture-plan.html.

    The event bus is a foundation for splitting QueryStudio into separate
    pods (UI / Query Worker / WebSocket / Background / Spark Connect).
    Currently in 'dual-write' mode: every event published to the bus also
    goes through the existing in-process WS broadcast, so this endpoint
    lets you observe what's flowing without changing user-visible behavior.

    Args:
      limit:      Max events to return (1-1000, default 100).
      event_type: Filter by type (e.g. 'execution_progress').
      username:   Filter by target user.

    Returns: {events: [...], stats: {...}} where stats includes the
    backend mode (in_memory vs postgresql), publish counts, error counts.
    """
    from core.event_bus import recent_events, stats as eb_stats
    return {
        "events": recent_events(limit=limit, event_type=event_type, username=username),
        "stats":  eb_stats(),
    }


@router.get("/api/admin/event-bus/stats")
async def event_bus_stats_endpoint(_user: dict = Depends(require_admin)):
    """Event bus telemetry: backend mode, publish counts, errors.

    Use this to verify dual-write is working: published count should
    match observed broadcast volume; pg_notify_ok > 0 confirms PG NOTIFY
    is firing (only meaningful when database.type=postgresql).
    """
    from core.event_bus import stats as eb_stats
    return eb_stats()


@router.post("/api/admin/iceberg/column-stats/cancel")
async def iceberg_column_stats_cancel(
    body: Dict[str, Any],
    _user: dict = Depends(require_admin),
):
    """Cancel a running column-stats scan.

    Body: {job_id: str}  — get this from the /scan-progress response.

    Sets a cancellation flag.  The scan loop checks the flag between
    files and exits cleanly.  Currently in-flight S3 reads (worker
    threads) cannot be killed mid-flight — they finish their current
    file before the loop notices.  Per-file granularity, so cancel
    takes effect within ~5-30 seconds depending on per-file latency.

    Returns: {cancelled: bool, job_id: str}
    """
    from core.iceberg_column_stats import cancel_job
    job_id = body.get("job_id")
    if not job_id:
        raise HTTPException(status_code=400, detail="job_id required")
    ok = cancel_job(str(job_id))
    return {"cancelled": ok, "job_id": job_id}


@router.get("/api/admin/iceberg/column-stats/scan-progress")
async def iceberg_column_stats_scan_progress(
    _user: dict = Depends(require_admin),
):
    """Live in-flight + recently-finished scan progress (per-pod, in-memory).

    Each entry: {job_id, connection_id, table_name, bucket, table_prefix,
                 total, done, scanned, skipped, failed, files_per_sec,
                 eta_seconds, status (running|done|error), started_at,
                 updated_at, finished_at?, error?, summary?}.

    Multi-pod: this returns only what THIS pod is running.  The DB-backed
    /status endpoint above gives cluster-wide row coverage.
    """
    from core.iceberg_column_stats import progress_snapshot
    return {"jobs": progress_snapshot()}


async def _col_stats_clear_identity(connection_id, table_name):
    """Resolve (bucket, prefix) for a table so a clear hits SHARED identity.

    Returns ``(None, None)`` when the table no longer resolves — the caller
    then falls back to legacy connection_id attribution rather than failing.
    """
    bucket = None
    table_prefix = None
    try:
        conn_raw = await _adb(_db_manager.get_connection_raw, int(connection_id))
        if conn_raw:
            cfg = conn_raw.get("config") or {}
            bucket = cfg.get("bucket_name", "") or None
            rt = next(
                (t for t in cfg.get("registered_tables", []) or []
                 if t.get("name") == table_name),
                None,
            )
            if rt:
                table_prefix = (rt.get("s3_prefix") or "").rstrip("/") or None
    except Exception:
        pass
    return bucket, table_prefix


@router.delete("/api/admin/iceberg/column-stats")
async def iceberg_column_stats_clear(
    connection_id: int,
    table_name: Optional[str] = None,
    snapshot_id: Optional[str] = None,
    _user: dict = Depends(require_admin),
):
    """Clear supplement rows.  Either ``table_name`` or ``snapshot_id``
    must be provided alongside ``connection_id``.

    BF-COL-STATS-V2: when table_name is given, the endpoint RESOLVES
    bucket + table_prefix from the connection's registered_tables list
    and clears by content identity (bucket + prefix + optional snapshot).
    This wipes rows scanned by ANY connection pointing at the same S3
    location — matches admin's mental model of "clear cache for table X".
    Falling back to legacy connection_id-attribution match when the
    table_name doesn't resolve (table no longer registered, etc.).
    """
    if not table_name and not snapshot_id:
        raise HTTPException(
            status_code=400,
            detail="Either table_name or snapshot_id required (refusing wipe-all)",
        )
    bucket = None
    table_prefix = None
    if table_name:
        bucket, table_prefix = await _col_stats_clear_identity(
            connection_id, table_name)
    if bucket and table_prefix:
        # Preferred: clear shared identity (bucket + prefix)
        deleted = await _adb(
            _db_manager.iceberg_col_stats_clear,
            bucket=bucket, table_prefix=table_prefix, snapshot_id=snapshot_id,
        )
    else:
        # Fallback: clear by telemetry attribution (legacy semantics —
        # only removes rows where THIS connection_id was the last scanner)
        deleted = await _adb(
            _db_manager.iceberg_col_stats_clear,
            connection_id=connection_id, table_name=table_name,
            snapshot_id=snapshot_id,
        )
    return {"deleted": deleted, "by": "bucket_prefix" if bucket and table_prefix else "telemetry"}


# ── Spark pods: the settings an admin changes, on screen (2026-10-13) ──
# The owner: "why we did not create admin ui".  Every spark_k8s knob that
# shapes the pods a large feed runs in was a file / config.set() edit only.
# The same audited, cross-pod write path every admin config uses
# (_persist_config_section -> core.config.set).  Values are VALIDATED here:
# a bad memory string or namespace would otherwise surface hours later as
# a pod that never starts.

_SPARK_POD_KEYS = (
    "namespace", "image", "image_pull_policy", "image_pull_secrets", "service_account",
    "submit_mode", "callback_base_url", "driver_cores", "driver_memory", "executor_cores",
    "executor_memory", "num_executors", "job_timeout_seconds", "max_retries",
    "driver_run_as_user", "size_classes",
)
_LARGE_FEED_KEYS = ("auto_route_threshold_rows", "csv_parallel_workers", "csv_parallel_min_rows")
_MEMORY_RE = r"^[1-9][0-9]*(\.[0-9]+)?[mMgG]$"
_DNS_LABEL_RE = r"^[a-z0-9]([-a-z0-9]{0,61}[a-z0-9])?$"


class SparkPodsConfigUpdate(BaseModel):
    """PUT /api/admin/spark-pods/config -- only the fields sent change."""
    namespace:           Optional[str]  = Field(None, pattern=_DNS_LABEL_RE)
    image:               Optional[str]  = Field(None, min_length=1, max_length=500)
    image_pull_policy:   Optional[str]  = Field(None, pattern=r"^(Always|IfNotPresent|Never)$")
    image_pull_secrets:  Optional[List[str]] = None
    service_account:     Optional[str]  = Field(None, pattern=_DNS_LABEL_RE)
    submit_mode:         Optional[str]  = Field(None, pattern=r"^(auto|spark_application|driver_pod)$")
    callback_base_url:   Optional[str]  = Field(None, pattern=r"^https?://\S+$")
    driver_cores:        Optional[int]  = Field(None, ge=1, le=64)
    driver_memory:       Optional[str]  = Field(None, pattern=_MEMORY_RE)
    executor_cores:      Optional[int]  = Field(None, ge=1, le=64)
    executor_memory:     Optional[str]  = Field(None, pattern=_MEMORY_RE)
    num_executors:       Optional[int]  = Field(None, ge=1, le=500)
    job_timeout_seconds: Optional[int]  = Field(None, ge=60, le=172800)
    max_retries:         Optional[int]  = Field(None, ge=0, le=99)
    #: "" = OpenShift assigns the UID from the project's range
    driver_run_as_user:  Optional[str]  = Field(None, pattern=r"^([1-9][0-9]{0,9})?$")
    size_classes:        Optional[Dict[str, Dict[str, Any]]] = None
    # feed_generation -- when a feed gets its own pods, how its CSV is written
    auto_route_threshold_rows: Optional[int] = Field(None, ge=1000)
    csv_parallel_workers:      Optional[int] = Field(None, ge=0, le=128)
    csv_parallel_min_rows:     Optional[int] = Field(None, ge=1000)

    @model_validator(mode="after")
    def _size_classes_shape(self):
        for name, cls in (self.size_classes or {}).items():
            _check_size_class(name, cls or {})
        for s in self.image_pull_secrets or []:
            _check_name(s, _DNS_LABEL_RE, f"image pull secret {s!r} is not a valid name")
        return self


_SIZE_CLASS_MEMORY = ("driver_memory", "executor_memory")
_SIZE_CLASS_COUNTS = ("driver_cores", "executor_cores", "num_executors", "job_timeout_seconds")


def _check_name(value: Any, pattern: str, message: str) -> None:
    import re as _re
    if not _re.match(pattern, str(value)):
        raise ValueError(message)


def _check_size_class(name: str, cls: Dict[str, Any]) -> None:
    """One named pod size: a sane name, known settings, sane values."""
    _check_name(name, r"^[a-z][a-z0-9_-]{0,31}$",
                f"size class name {name!r}: lower case letters, digits, - or _")
    for k, v in cls.items():
        if k in _SIZE_CLASS_MEMORY:
            _check_name(v, _MEMORY_RE, f"size class {name}: {k} must look like 4g or 512m")
        elif k in _SIZE_CLASS_COUNTS:
            if not isinstance(v, int) or v < 1:
                raise ValueError(f"size class {name}: {k} must be a whole number above 0")
        else:
            raise ValueError(f"size class {name}: unknown setting {k!r}")


def _spark_pods_view() -> Dict[str, Any]:
    from core import config as _c
    sk = _c.get_section("spark_k8s") or {}
    fg = _c.get_section("feed_generation") or {}
    return {
        "spark_k8s": {k: sk.get(k) for k in _SPARK_POD_KEYS},
        "large_feeds": {
            "auto_route_threshold_rows": int(fg.get("auto_route_threshold_rows", 500000)),
            "csv_parallel_workers": int(fg.get("csv_parallel_workers", 0)),
            "csv_parallel_min_rows": int(fg.get("csv_parallel_min_rows", 200000)),
        },
    }


@router.get("/api/admin/spark-pods/config")
async def get_spark_pods_config(_user: dict = Depends(require_admin_read)):
    """The Spark pod settings in effect (all pods read the same)."""
    return _spark_pods_view()


@router.put("/api/admin/spark-pods/config")
async def update_spark_pods_config(update: SparkPodsConfigUpdate,
                                   user: dict = Depends(require_admin)):
    sent = update.model_dump(exclude_unset=True)
    pods = {k: v for k, v in sent.items() if k in _SPARK_POD_KEYS}
    large = {k: v for k, v in sent.items() if k in _LARGE_FEED_KEYS}
    if not pods and not large:
        raise HTTPException(status_code=400, detail="Nothing to change: send at least one setting.")
    results = []
    if pods:
        results.append(_persist_config_section("spark_k8s", pods))
    if large:
        results.append(_persist_config_section("feed_generation", large))
    # who / from / to of every key is audited by core.config.set itself
    from core import config as _c
    order = (_c.SET_PERSISTED_DB, _c.SET_IN_PROCESS_ONLY, _c.SET_DB_WRITE_FAILED)
    worst = max((r["persisted"] for r in results), key=order.index)
    return {"persisted": worst, "changed": sorted(sent), **_spark_pods_view()}
