"""
Phase 93 — Multi-Source Federation Views API.

Provides CRUD endpoints for named cross-connection queries (JOIN/UNION of
two queries on connections of ANY supported type -- every SQL connector,
S3, local; 2026-10-04) and a preview endpoint that executes the view and
returns sample results.  The core execution helper `execute_federation_view`
is also used by published_views_api and business_reports_api when
source_type="federation".
"""
import asyncio
import logging
import uuid
from typing import TYPE_CHECKING, Iterable, Optional, List, Dict

if TYPE_CHECKING:  # annotation-only — Path is imported inside the functions
    from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from api.deps import get_current_user, require_role
from core.audit import audit_event
from core.db_async import adb  # BF-594: off-load sync DB calls from async endpoints
from core.json_utils import sanitize_for_json
from core.parquet_utils import read_resolved_schema

logger = logging.getLogger(__name__)
router = APIRouter(tags=["federation-views"])

# ── Module-level dependencies (injected from main.py::_startup) ──────────
_db_manager = None
_connection_manager = None


def set_federation_views_dependencies(db_manager=None, connection_manager=None):
    global _db_manager, _connection_manager
    if db_manager:
        _db_manager = db_manager
    if connection_manager:
        _connection_manager = connection_manager


def _require_db():
    from api.deps import require_db as _central_require_db
    return _central_require_db()


# ── Pydantic models ──────────────────────────────────────────────────────

class FederationViewCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    description: str = ""
    primary_conn_id: int
    primary_query: dict
    secondary_conn_id: int
    secondary_query: dict
    combine_mode: str = Field(default="union", pattern=r"^(join|union)$")
    join_on: List[dict] = Field(default_factory=list)
    # The ONE join vocabulary (core.executors.cross_source_combine.
    # normalise_join_how): "outer" is "full".  Validated by combine_spec at
    # authoring time, not by a second spelling list here.
    join_how: str = Field(default="inner")
    output_columns: List[str] = Field(default_factory=list)
    is_active: bool = True


class FederationViewUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    primary_conn_id: Optional[int] = None
    primary_query: Optional[dict] = None
    secondary_conn_id: Optional[int] = None
    secondary_query: Optional[dict] = None
    combine_mode: Optional[str] = None
    join_on: Optional[List[dict]] = None
    join_how: Optional[str] = None
    output_columns: Optional[List[str]] = None
    is_active: Optional[bool] = None


# ── CRUD Endpoints ────────────────────────────────────────────────────────

@router.get("/api/federation-views")
async def list_federation_views(
    active_only: bool = False,
    user: dict = Depends(require_role("admin", "analyst")),
):
    db = _require_db()
    # BF-594: off-load sync DB calls from async endpoints.
    return await adb(db.list_federation_views, active_only=active_only)


#: Which connection types a federation view side can read is answered ONCE,
#: by THE cross-source capability (``core.executors.cross_source_combine.
#: supported_side_types`` / ``refuse_unsupported_side``): every SQL connector
#: (Trino, Starburst, Snowflake, Oracle, Databricks, Athena), S3 and local.
#:
#: 2026-10-04 -- this was a local ``{"s3", "local"}``, so a cloud + on-prem
#: view (Snowflake x Trino) -- and a published API over one -- was a 400
#: (measured live, X4).  2026-09-21 put the gate at authoring time (a view
#: over Trino used to save with a 201 and fail at execute); the gate stays,
#: its answer now comes from the capability that actually runs the sides.


def _side_config(qc: dict) -> dict:
    """A side's stored query config as the query model reads it.

    2026-09-24 (click crawl): a RAW-SQL side (``{"raw_sql": ...}``) is a
    designed shape -- row security and Dynamic WHERE both handle it below --
    but the query model requires ``files`` (a VISUAL-config field that raw
    SQL does not use), so such a view could never preview or run.  The UI
    always sends ``files: []``; a view authored through the API did not.
    """
    qc = dict(qc or {})
    if (qc.get("raw_sql") or qc.get("custom_sql")) and "files" not in qc:
        qc["files"] = []
    return qc


def _refuse_unrunnable_sides(sides) -> None:
    """Validate each side at AUTHORING time: a view that can never execute is
    refused with a 422 naming the side, not saved with a 201 to fail later."""
    from api.models.query_models import QueryConfigModel
    for qc, side in sides:
        if qc is None:
            continue
        try:
            QueryConfigModel(**_side_config(qc))
        except Exception as exc:
            from core.error_sanitizer import sanitize_error as _se
            raise HTTPException(
                422, f"The {side} query cannot be executed: {_se(str(exc))}")


async def _refuse_unsupported_side_connections(db, pairs):
    """Refuse at AUTHORING what ``_execute_side`` can only refuse at run.

    A view that cannot execute must not be storable: the author is here
    now, and nobody is here when the scheduled report runs.
    """
    from core.executors.cross_source_combine import (
        CrossSourceRefusal, refuse_unsupported_side)
    for cid, label in pairs:
        conn = await adb(db.get_connection_raw, cid)
        if not conn:
            raise HTTPException(404, f"{label.capitalize()} connection {cid} not found")
        ctype = str(conn.get("connection_type") or "").lower()
        try:
            refuse_unsupported_side(ctype, f"{label} (connection {cid})")
        except CrossSourceRefusal as exc:
            raise HTTPException(400, str(exc))


def _refuse_uncombinable(combine_mode, join_on, join_how) -> None:
    """A combine that can never run (a JOIN without keys, an unknown join
    type) is refused at AUTHORING, in the one vocabulary every surface uses."""
    from core.executors.cross_source_combine import (
        CrossSourceRefusal, combine_spec)
    try:
        combine_spec(combine_mode, None, join_on=join_on or [],
                     join_how=join_how, default_mode="union")
    except CrossSourceRefusal as exc:
        raise HTTPException(400, str(exc))


@router.post("/api/federation-views", status_code=201)
async def create_federation_view(
    body: FederationViewCreate,
    user: dict = Depends(require_role("admin", "analyst")),
):
    db = _require_db()
    # Validate unique name
    existing = await adb(db.get_federation_view_by_name, body.name)
    if existing:
        raise HTTPException(409, f"Federation view '{body.name}' already exists")
    # Validate the connections exist AND that this feature can read them.
    await _refuse_unsupported_side_connections(
        db, [(body.primary_conn_id, "primary"),
             (body.secondary_conn_id, "secondary")])
    _refuse_unrunnable_sides([(body.primary_query, "primary"),
                              (body.secondary_query, "secondary")])
    _refuse_uncombinable(body.combine_mode, body.join_on, body.join_how)
    fv = await adb(
        db.create_federation_view,
        name=body.name,
        description=body.description,
        primary_conn_id=body.primary_conn_id,
        primary_query=body.primary_query,
        secondary_conn_id=body.secondary_conn_id,
        secondary_query=body.secondary_query,
        combine_mode=body.combine_mode,
        join_on=body.join_on,
        join_how=body.join_how,
        output_columns=body.output_columns,
        is_active=body.is_active,
        created_by=user.get("username", ""),
    )
    return fv


# NOTE: static paths MUST appear before parameterized {view_id} to avoid 422 (BF-78)
@router.get("/api/federation-views/materialized")
async def list_materialized_federation_views(
    user: dict = Depends(get_current_user),
):
    """Return federation views with status='ready' — for query builder sidebar."""
    db = _require_db()
    return await adb(db.list_materialized_federation_views)


@router.get("/api/federation-views/{view_id}")
async def get_federation_view(
    view_id: int,
    user: dict = Depends(require_role("admin", "analyst")),
):
    db = _require_db()
    fv = await adb(db.get_federation_view, view_id)
    if not fv:
        raise HTTPException(404, "Federation view not found")
    return fv


@router.put("/api/federation-views/{view_id}")
async def update_federation_view(
    view_id: int,
    body: FederationViewUpdate,
    user: dict = Depends(require_role("admin", "analyst")),
):
    db = _require_db()
    existing = await adb(db.get_federation_view, view_id)
    if not existing:
        raise HTTPException(404, "Federation view not found")
    updates = body.model_dump(exclude_none=True)
    if not updates:
        return existing
    if "name" in updates and updates["name"] != existing["name"]:
        dup = await adb(db.get_federation_view_by_name, updates["name"])
        if dup:
            raise HTTPException(409, f"Name '{updates['name']}' already taken")
    # Re-pointing a side at a connection this feature cannot read is the
    # same defect as creating one; the gate has to be on both doors or
    # the one that is missing it becomes the way in.
    _repointed = [(updates[k], label) for k, label in
                  (("primary_conn_id", "primary"),
                   ("secondary_conn_id", "secondary")) if k in updates]
    if _repointed:
        await _refuse_unsupported_side_connections(db, _repointed)
    _refuse_unrunnable_sides([(updates.get("primary_query"), "primary"),
                              (updates.get("secondary_query"), "secondary")])
    if {"combine_mode", "join_on", "join_how"} & set(updates):
        _refuse_uncombinable(
            updates.get("combine_mode", existing.get("combine_mode")),
            updates.get("join_on", existing.get("join_on")),
            updates.get("join_how", existing.get("join_how")))
    fv = await adb(db.update_federation_view, view_id, **updates)
    return fv


@router.delete("/api/federation-views/{view_id}")
async def delete_federation_view(
    view_id: int,
    acknowledge_dependents: bool = False,
    user: dict = Depends(require_role("admin", "analyst")),
):
    """2026-10-17 -- refused (409) while a PUBLISHED API serves this view
    (core/published_api/impact.py); ``acknowledge_dependents=true`` deletes
    anyway and audits the APIs."""
    db = _require_db()
    from api.published_api_api import refuse_if_apis_depend_async
    await refuse_if_apis_depend_async(db, "federation_view", view_id,
                                      acknowledged=acknowledge_dependents, actor=user)
    deleted = await adb(db.delete_federation_view, view_id)
    if not deleted:
        raise HTTPException(404, "Federation view not found")
    # 2026-08-23 — the materialized parquet directory used to be orphaned
    # forever on delete (MV delete rmtree's; this route didn't).  Always
    # derive the path from config + id — the same way materialize writes it
    # — never from a stored string, so a tampered row cannot aim the rmtree.
    try:
        import os as _os
        import shutil as _shutil
        from core.config import federation_views_cfg as _fv_cfg
        _stor = _os.path.join(_fv_cfg.storage_dir, str(view_id))
        if _os.path.isdir(_stor):
            await asyncio.to_thread(_shutil.rmtree, _stor)
    except Exception as _rm_exc:
        logger.warning("Federation view %d deleted but storage cleanup "
                       "failed: %s", view_id, _rm_exc)
    audit_event(db, user, None, "delete_federation_view", "federation_view", view_id)
    return {"detail": "Deleted"}


# ── Preview Endpoint ──────────────────────────────────────────────────────

@router.post("/api/federation-views/{view_id}/preview")
async def preview_federation_view(
    view_id: int,
    user: dict = Depends(require_role("admin", "analyst")),
):
    db = _require_db()
    fv = await adb(db.get_federation_view, view_id)
    if not fv:
        raise HTTPException(404, "Federation view not found")
    try:
        # 2026-08-23 — the caller's identity MUST ride along: without it the
        # RLS principal was a fabricated "system"/fv_consumer, so the
        # preview either refused governed tables for everyone or showed
        # rows the caller's own policies would filter differently.
        result = await execute_federation_view(
            fv, limit=50, offset=0,
            username=user.get("username", ""), user_ctx=user)
        # Phase 97: Auto-cache schema from preview columns
        if result.get("columns") and not fv.get("schema_cache"):
            cols = [{"name": c["name"], "type": c["type"], "nullable": True} for c in result["columns"]]
            await adb(db.update_federation_view, view_id, schema_cache=cols,
                      schema_cached_at=__import__('datetime').datetime.now(
                          __import__('datetime').timezone.utc))
        return result
    except HTTPException:
        raise
    except Exception as exc:
        from core.error_sanitizer import sanitize_error as _se
        logger.error("Federation view preview failed id=%d: %s", view_id, _se(str(exc)), exc_info=True)
        # 2026-10-04 -- the ONE classifier first: a source's verdict on the
        # view's SQL (Trino COLUMN_NOT_FOUND, ORA-00942) is the author's to
        # fix -- 400 with the source's sentence -- and an unreachable source
        # or missing credential is 503 + Retry-After.  Found live: a typo in
        # a view's Trino SQL answered 500 "contact support".
        from api.connector_errors import raise_if_self_clearing, raise_if_source_error
        raise_if_self_clearing(exc)
        raise_if_source_error(exc, context="Federation view preview")
        raise HTTPException(500, f"Preview failed: {_se(str(exc))}")


# ── Phase 97: Materialization + Schema Endpoints ─────────────────────────

@router.get("/api/federation-views/{view_id}/schema")
async def get_federation_view_schema(
    view_id: int,
    user: dict = Depends(get_current_user),
):
    """Return cached output schema (columns) for a federation view."""
    db = _require_db()
    fv = await adb(db.get_federation_view, view_id)
    if not fv:
        raise HTTPException(404, "Federation view not found")

    # Check inline schema cache first (instant)
    if fv.get("schema_cache"):
        return {"columns": fv["schema_cache"], "source": fv["name"], "cache": "db"}

    # If materialized, read from parquet header.  BF-NONBLOCK-AUDIT: glob +
    # parquet schema read are sync FS/IO; wrapped in asyncio.to_thread so a
    # storage_path with hundreds of parquet files doesn't block the event loop.
    if fv.get("status") == "ready" and fv.get("storage_path"):
        import glob as _glob
        import os
        def _read_first_parquet_schema():
            pq_files = sorted(_glob.glob(os.path.join(fv["storage_path"], "*.parquet")))
            if not pq_files:
                return None
            return read_resolved_schema(pq_files[0])
        cols = await asyncio.to_thread(_read_first_parquet_schema)
        if cols is not None:
            from datetime import datetime, timezone
            await adb(db.update_federation_view, view_id, schema_cache=cols,
                      schema_cached_at=datetime.now(timezone.utc))
            return {"columns": cols, "source": fv["name"], "cache": "parquet"}

    raise HTTPException(400, "Schema not available — materialize the view or run a preview first")


@router.post("/api/federation-views/{view_id}/materialize")
async def materialize_federation_view(
    view_id: int,
    user: dict = Depends(require_role("admin", "analyst")),
):
    """Execute the federation view and store results as local parquet files."""
    db = _require_db()
    fv = await adb(db.get_federation_view, view_id)
    if not fv:
        raise HTTPException(404, "Federation view not found")
    if fv.get("status") == "materializing":
        raise HTTPException(409, "Materialization already in progress")

    await adb(db.update_federation_view, view_id, status="materializing", last_error=None)
    # BF-594: materialisation is a multi-minute job — must NOT run on
    # the default executor (40 threads shared with adb()); long-running
    # tasks there starve every other DB call.  Spawn a dedicated
    # daemon thread that runs the sync body without burdening any pool.
    import threading as _t_fed
    _mat_thread = _t_fed.Thread(
        target=_materialize_sync,
        args=(view_id, user.get("username", "system"), dict(user)),
        daemon=True,
        name=f"fed-mat-{view_id}",
    )
    _mat_thread.start()
    return {"detail": "Materialization started", "view_id": view_id}


def _materialize_sync(view_id: int, username: str = "system",
                      user_ctx: Optional[Dict] = None):
    """Execute the federation view and write the combined result to parquet.

    2026-08-23 — REWIRED through execute_federation_view's ``materialize_to``
    path (DuckDB ``COPY`` — streams with disk spill, bounded memory).  The
    previous body pulled EVERY row of the combined result into a Python list
    of dicts and then a pandas DataFrame: an OOM bomb on any large view,
    sitting right next to the bounded path that the PV redesign had already
    built.  One chokepoint now serves both.

    The snapshot is materialized under the TRIGGERING user's identity
    (user_ctx) — like a published snapshot, its contents are the
    materializer's row-security view.
    """
    import time
    import shutil
    import os
    from core.config import federation_views_cfg as _cfg
    from datetime import datetime, timezone

    db = _require_db()
    fv = db.get_federation_view(view_id)
    if not fv:
        return

    start = time.monotonic()
    try:
        storage_dir = os.path.join(_cfg.storage_dir, str(view_id))
        if os.path.exists(storage_dir):
            shutil.rmtree(storage_dir)
        os.makedirs(storage_dir, exist_ok=True)
        out_path = os.path.join(storage_dir, "part_0000.parquet")

        # Execute with no limit on either side (full_fetch=True strips any
        # saved per-side limit) and COPY the combined result straight to
        # parquet — no rows ever enter this process's memory.
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            result = loop.run_until_complete(
                execute_federation_view(fv, limit=0, offset=0, username=username,
                                        full_fetch=True, user_ctx=user_ctx,
                                        materialize_to=out_path)
            )
        finally:
            loop.close()

        total_rows = result.get("total_rows", 0)
        if total_rows == 0:
            logger.warning("Materialize view %d: execution returned 0 rows — "
                           "check primary/secondary query configs and S3 credentials",
                           view_id)

        # COPY writes a schema-bearing file even for 0 rows, so the schema
        # always comes from the artifact itself — one source of truth.
        schema_cols = read_resolved_schema(out_path)
        total_size = os.path.getsize(out_path)

        elapsed = time.monotonic() - start
        db.update_federation_view(view_id,
            status="ready",
            storage_path=storage_dir,
            row_count=total_rows,
            column_count=len(schema_cols),
            file_size_bytes=total_size,
            last_materialized=datetime.now(timezone.utc),
            last_mat_duration=round(elapsed, 2),
            last_error=None,
            schema_cache=schema_cols,
            schema_cached_at=datetime.now(timezone.utc),
        )
        logger.info("Materialized federation view %d: %d rows, %d bytes in %.1fs",
                     view_id, total_rows, total_size, elapsed)
    except Exception as exc:
        elapsed = time.monotonic() - start
        logger.error("Materialize federation view %d failed: %s", view_id, exc, exc_info=True)
        db.update_federation_view(view_id,
            status="failed",
            last_error=str(exc)[:2000],
            last_mat_duration=round(elapsed, 2),
        )


# ── Core Execution Helper ─────────────────────────────────────────────────
# Also called from published_views_api and business_reports_api.

# ── Result-cache helpers for the federation road (2026-09-07) ─────────
#
# The gate itself is ``core.dataset_result_cache`` — the SAME lookup/store
# the dataset and raw-SQL roads use, with a third identity builder.  What
# lives here is only what is specific to this road's ARTIFACT: it is a
# page, not a whole answer, and its ``total_rows`` is a COUNT over the
# combine that the page cannot reproduce.


def _fv_policy_fingerprint(db) -> str:
    """The row-security configuration this entry was produced under.

    A STRUCTURED federation side carries no SQL at consult time — its SQL
    is synthesised and secured inside ``execute_api.execute_query_background``
    — so the post-RLS text cannot carry the policy for that side the way it
    does on the other two roads.  This closes it from the other end: any
    policy add / edit / delete / rebinding changes the DB-derived digest, so
    no cached body can survive the policy that produced it.  It
    over-invalidates (an edit to a policy that binds nobody here still
    changes the digest) — a cap, not a gate: the next run simply executes.

    RAISES rather than guessing.  ``compute_policy_fingerprint`` is strict
    for the same reason: an unreadable policy store must never look like
    "nothing changed".  The caller's try block turns a raise into a MISS,
    which costs an execution and can never cost a stale serve.
    """
    from core.row_security.api import _is_enabled as _rs_is_enabled
    if not _rs_is_enabled():
        # A literal, not the digest: with enforcement off there is no
        # rewrite to invalidate, and reading three policy tables on every
        # consult to learn that would be a DB round trip bought for
        # nothing.  Turning enforcement ON changes this token, so an entry
        # built while it was off can never be served after it is on.
        return "rls:off"
    from core.identity.rls_predicates import compute_policy_fingerprint
    return compute_policy_fingerprint(db)


def _fv_cache_scratch_path() -> str:
    """A private path for a cached page on its way in or out.

    In the configured downloads dir so it shares a filesystem with the
    cache's own store (``lookup`` copies, it does not move), and named so
    it can never collide with an execution artifact.
    """
    import uuid as _uuid
    from pathlib import Path as _P
    try:
        from core.config import paths as _p
        base = _P(_p.downloads_dir)
    except Exception:
        import tempfile
        base = _P(tempfile.gettempdir())
    base.mkdir(parents=True, exist_ok=True)
    return str(base / f"fvcache_{_uuid.uuid4().hex[:16]}.parquet")


def _fv_response_from_parquet(path: str, *, offset: int, materialized: bool,
                              total_rows: int, type_mismatches: List,
                              cache_freshness: str,
                              cache_age_seconds: float) -> dict:
    """Rebuild this road's response envelope from a cached artifact.

    Byte-for-byte the same SHAPE the live path returns — a hit must be
    indistinguishable from a run except in cost and in the disclosure keys
    below, which say plainly that it WAS one.  ``total_rows`` comes from
    the stored ``extra`` rather than from the artifact: the artifact holds
    the requested PAGE, and counting it would silently redefine
    ``total_rows`` as ``returned_rows`` on every hit.
    """
    import os as _os
    import pyarrow.parquet as _pq
    disclosure = {
        "cache_hit": True,
        "result_cache_hit": True,
        "cache_freshness": cache_freshness,
        "cache_age_seconds": cache_age_seconds,
    }
    if materialized:
        _schema = _pq.read_schema(path)
        return {
            "total_rows": total_rows,
            "returned_rows": 0,
            "offset": 0,
            "columns": [{"name": f.name, "type": str(f.type)}
                        for f in _schema],
            "data": [],
            "parquet_path": str(path),
            "materialized": True,
            "type_mismatches": list(type_mismatches or []),
            **disclosure,
        }
    try:
        table = _pq.read_table(path)
        col_meta = [{"name": f.name, "type": str(f.type)}
                    for f in table.schema]
        data = table.to_pydict()
        rows = []
        for i in range(table.num_rows):
            rows.append({col: data[col][i] for col in data})
        return {
            "total_rows": total_rows,
            "returned_rows": table.num_rows,
            "offset": offset,
            "columns": col_meta,
            "data": sanitize_for_json(rows),
            "type_mismatches": list(type_mismatches or []),
            **disclosure,
        }
    finally:
        # The scratch copy has been read into the response; leaving it
        # would leak a file per cache hit.
        try:
            _os.unlink(path)
        except OSError:
            pass


def _fv_cache_store(identity, key: str, path: str, *, row_count: int,
                    column_count: int, total_rows: int,
                    type_mismatches: List, sides: List[Dict], db,
                    table=None) -> None:
    """Write-through.  Best effort; the answer is already produced.

    ``table`` (the inline path) is the arrow PAGE still in memory — it is
    written to a scratch parquet, stored, and removed.  Bounded by the
    caller's ``limit``, so this never materialises a combine the caller did
    not ask for.
    """
    if identity is None:
        return
    import os as _os
    scratch = ""
    try:
        from core import dataset_result_cache as _drc
        art = path
        if table is not None:
            import pyarrow.parquet as _pq
            scratch = _fv_cache_scratch_path()
            _pq.write_table(table, scratch)
            art = scratch
        if not art or not _os.path.exists(art):
            return
        src_tables: List[Dict] = []
        local_pats: List[str] = []
        for s in (sides or []):
            src_tables.extend(s.get("source_tables") or [])
            local_pats.extend(s.get("local_patterns") or [])
        _drc.store(
            identity=identity, output_path=art,
            row_count=int(row_count or 0), column_count=int(column_count or 0),
            source_tables=src_tables, db_manager=db, key=key,
            local_patterns=local_pats,
            # OUTPUTS of the run, not identity: the whole-combine count the
            # stored page cannot reproduce, and the cross-side type-mismatch
            # warning, which is derived from the two SIDE schemas and so is
            # unavailable to a hit that never executed a side.
            extra={"total_rows": int(total_rows or 0),
                   "type_mismatches": list(type_mismatches or [])},
        )
    except Exception as exc:
        logger.debug("[fv-cache] store skipped (ignored): %s", exc)
    finally:
        if scratch:
            try:
                _os.unlink(scratch)
            except OSError:
                pass

async def execute_federation_view(
    fv: dict,
    limit: int = 1000,
    offset: int = 0,
    extra_filters: Optional[List[Dict]] = None,
    username: str = "system",
    full_fetch: bool = False,
    dynamic_columns: Optional[Iterable[str]] = None,
    materialize_to: Optional[str] = None,
    user_ctx: Optional[Dict] = None,
    side_execution_ids: Optional[List[str]] = None,
) -> dict:
    """Execute a federation view and return combined results.

    ``side_execution_ids`` (2026-09-29) -- an OUT list each side appends its
    execution id to as it is minted (see ``_execute_side``); the caller's
    handle on the sides' pool tasks.  ``None`` changes nothing.

    Phase 124-A: DuckDB-based combine — each side writes to temp parquet,
    DuckDB reads both and UNION/JOIN with disk spill.  Pagination via
    DuckDB LIMIT/OFFSET instead of post-load .iloc[].

    full_fetch=True removes any saved per-side row limit (used during
    materialization to ensure all rows are written to parquet).

    materialize_to (2026-08 PV redesign) — when set, the COMBINED result is
    written to this parquet path via DuckDB ``COPY`` (bounded memory, disk
    spill) and NO rows are returned in ``data``; ``limit``/``offset`` are
    ignored on this path (the caller pages the parquet itself).  This is the
    seam the Published-API federation handler uses so pagination is applied
    exactly ONCE — in the caller's pager — never both here and there.

    Phase 134-M parity — ``dynamic_columns`` carries the set of column
    names whose existing hardcoded predicates in either side's raw_sql
    MUST be removed before the merged consumer override is AND-ed.
    Without this, a federation view with raw_sql + Dynamic WHERE
    silently drops the consumer override (engine ignores the
    structured filter list when raw_sql is present, so the
    publisher's hardcoded value wins).  Passed through to _execute_side
    for both primary and secondary.
    """
    db = _require_db()

    import asyncio
    primary_path = None
    secondary_path = None

    # ══ RESULT CACHE (2026-09-07) — THE THIRD REPORT ROAD ═══════════════
    #
    # ``8379f4ff`` cached the dataset road, ``916d820b`` cached the raw-SQL
    # road, and a ``federation_view``-backed business report enters NEITHER:
    # it comes straight here.  This view had a SCHEMA cache and nothing
    # else, so both sides re-executed against S3 and the DuckDB combine
    # re-ran on every single run — the exact symptom the first of those
    # commits was written for, on the road neither of them looked at.
    #
    # WHY THE CONSULT SITS HERE.  Both sides are PREPARED first — connection
    # resolved, query config finished, ``secure_sql`` applied — so the key
    # is built from the FINAL, POST-RLS SQL and a cached body cannot outlive
    # the policy that shaped it.  The prepared sides are then handed BACK to
    # ``_execute_side``, so the rewrite happens once and the SQL that was
    # keyed is the SQL that runs.  Structured sides carry no SQL at this
    # point (theirs is synthesised inside ``execute_query_background``); the
    # row-security POLICY FINGERPRINT in the key closes that from the other
    # end.  See ``dataset_result_cache.build_identity_for_federation_view``.
    _prepared = await asyncio.gather(
        _prepare_side(
            fv["primary_conn_id"], fv["primary_query"],
            extra_filters=extra_filters, side="primary", username=username,
            no_limit=full_fetch, dynamic_columns=dynamic_columns,
            user_ctx=user_ctx,
        ),
        _prepare_side(
            fv["secondary_conn_id"], fv["secondary_query"],
            extra_filters=extra_filters, side="secondary", username=username,
            no_limit=full_fetch, dynamic_columns=dynamic_columns,
            user_ctx=user_ctx,
        ),
        return_exceptions=True,
    )
    for _pr in _prepared:
        if isinstance(_pr, BaseException):
            raise _pr
    _prep_p, _prep_s = _prepared

    _rc_identity = None
    _rc_key = ""
    _rc_dec = None
    try:
        from core import dataset_result_cache as _drc
        _rc_identity = _drc.build_identity_for_federation_view(
            view_id=fv.get("id"),
            sides=[_prep_p, _prep_s],
            combine_mode=fv.get("combine_mode", "union"),
            join_on=fv.get("join_on") or [],
            join_how=fv.get("join_how") or "",
            output_columns=fv.get("output_columns") or [],
            extra_filters=extra_filters,
            dynamic_columns=dynamic_columns,
            limit=limit, offset=offset,
            materialize=bool(materialize_to),
            rls_policy_fingerprint=_fv_policy_fingerprint(db),
            credential_username=username,
            user_ctx=_fv_principal(user_ctx, username, "primary"),
        )
        _rc_out = (str(materialize_to) if materialize_to
                   else _fv_cache_scratch_path())
        _rc_dec = _drc.lookup(identity=_rc_identity, output_path=_rc_out,
                              db_manager=db)
        _rc_key = _rc_dec.key
        if _rc_dec.served:
            logger.info(
                "[fv-cache] HIT view=%s rows=%d freshness=%s age=%.1fs — "
                "neither side executed, no combine",
                fv.get("id"), _rc_dec.row_count, _rc_dec.freshness,
                _rc_dec.age_seconds)
            return _fv_response_from_parquet(
                _rc_out, offset=offset,
                materialized=bool(materialize_to),
                total_rows=int(_rc_dec.extra.get("total_rows")
                               or _rc_dec.row_count),
                type_mismatches=list(_rc_dec.extra.get("type_mismatches") or []),
                cache_freshness=_rc_dec.freshness,
                cache_age_seconds=_rc_dec.age_seconds,
            )
    except Exception as _rc_exc:
        # Fail-open in BOTH directions: a broken cache must not break a
        # federation view, and a miss must cost nothing but this block.
        _rc_identity = None
        logger.debug("[fv-cache] consult skipped (fail-open miss): %s", _rc_exc)

    # ── Execute both sides in parallel ──────────────────────────────────
    # The OUT list travels only when a caller supplied one: every other
    # caller (and every stand-in for ``_execute_side``) sees the call it
    # always saw.
    _side_kw = ({"side_execution_ids": side_execution_ids}
                if side_execution_ids is not None else {})
    try:
        _gather_results = await asyncio.gather(
            _execute_side(
                fv["primary_conn_id"], fv["primary_query"],
                extra_filters=extra_filters, side="primary", username=username,
                no_limit=full_fetch,
                dynamic_columns=dynamic_columns,
                user_ctx=user_ctx,
                prepared=_prep_p,
                **_side_kw,
            ),
            _execute_side(
                fv["secondary_conn_id"], fv["secondary_query"],
                extra_filters=extra_filters, side="secondary", username=username,
                no_limit=full_fetch,
                dynamic_columns=dynamic_columns,
                user_ctx=user_ctx,
                prepared=_prep_s,
                **_side_kw,
            ),
            return_exceptions=True,
        )
        # Capture paths from successful sides (for cleanup in finally)
        from pathlib import Path as _Path
        if isinstance(_gather_results[0], _Path):
            primary_path = _gather_results[0]
        if isinstance(_gather_results[1], _Path):
            secondary_path = _gather_results[1]
        # Raise the first real error
        for _gr in _gather_results:
            if isinstance(_gr, BaseException):
                raise _gr
        # ── Combine via DuckDB — streams through disk ─────────────────────
        from core.duckdb_factory import duckdb_connection

        combine_mode = fv.get("combine_mode", "union")

        # BF-525 (2026-05-28): detect cross-side type mismatches so the
        # user-facing response carries a structured warning.  Without
        # this DuckDB silently auto-promotes (DECIMAL(10,2) + FLOAT
        # → DOUBLE) — operators reading the result viewer have no way
        # to know aggregations ran at a different precision than the
        # source schemas would suggest.  Probe runs BEFORE the combine
        # SQL so the warning is available even on the 0-row path.
        _type_mismatches: list = []
        try:
            from core.executors.cross_source_combine import (
                describe_columns, detect_union_type_mismatches,
            )
            with duckdb_connection() as _diag_con:
                _p_cols_diag = describe_columns(_diag_con, str(primary_path))
                _s_cols_diag = describe_columns(_diag_con, str(secondary_path))
            _type_mismatches = detect_union_type_mismatches(
                _p_cols_diag, _s_cols_diag,
            )
            if _type_mismatches:
                logger.warning(
                    "[bf-525 fv-type-mismatch] Federation %s side schemas "
                    "differ: %s.  DuckDB will auto-promote; downstream "
                    "aggregations may lose precision.",
                    combine_mode, "; ".join(_type_mismatches),
                )
        except Exception as _diag_exc:
            logger.debug("BF-525 type-mismatch probe skipped: %s", _diag_exc)

        # 2026-10-04 -- THE combine (core.executors.cross_source_combine.
        # combine_select_sql): the same SQL every other surface's combine
        # runs, as a SELECT this road can count, project and page.  This was
        # an inline copy of the join builder with its own suffix rule (a
        # ``SELECT *`` whenever no column overlapped, which kept a
        # differently-named right key that every other surface drops) and
        # its own join-type list.
        from core.executors.cross_source_combine import (
            CrossSourceRefusal as _XRefusal, combine_select_sql,
            combine_spec as _x_spec, describe_columns as _x_describe)
        try:
            _fv_spec = _x_spec(combine_mode, None,
                               join_on=fv.get("join_on") or [],
                               join_how=fv.get("join_how") or "inner",
                               default_mode="union")
        except _XRefusal as _x_ref:
            raise HTTPException(400, str(_x_ref))
        _key_casts: list = []
        with duckdb_connection() as con:
            try:
                base_sql, _key_casts, _ = combine_select_sql(
                    str(primary_path), str(secondary_path), _fv_spec,
                    _x_describe(con, str(primary_path)),
                    _x_describe(con, str(secondary_path)))
            except _XRefusal as _x_ref:
                raise HTTPException(500, str(_x_ref))

            # Output columns projection
            output_columns = fv.get("output_columns") or []
            if output_columns:
                col_list = ", ".join(
                    f'"{c.replace(chr(34), chr(34)+chr(34))}"' for c in output_columns
                )
                wrapped = f"SELECT {col_list} FROM ({base_sql}) _fv"
            else:
                wrapped = base_sql

            # Count total rows
            count_result = con.execute(f"SELECT COUNT(*) FROM ({wrapped}) _cnt").fetchone()
            total_rows = count_result[0] if count_result else 0

            # ── Materialize-only path (2026-08 PV redesign) ───────────────
            # Write the combined dataset to parquet via COPY (DuckDB streams
            # with disk spill — bounded memory) and return WITHOUT fetching
            # rows.  No LIMIT/OFFSET is applied here by construction; the
            # caller owns paging.
            if materialize_to:
                _mat_esc = str(materialize_to).replace("'", "''")
                con.execute(
                    f"COPY ({wrapped}) TO '{_mat_esc}' "
                    f"(FORMAT PARQUET, COMPRESSION ZSTD)"
                )
                import pyarrow.parquet as _mat_pq
                _mat_schema = _mat_pq.read_schema(str(materialize_to))
                # Write-through.  The materialised parquet IS the artifact
                # the cache stores, so there is nothing extra to produce.
                _fv_cache_store(_rc_identity, _rc_key, str(materialize_to),
                                row_count=int(total_rows or 0),
                                column_count=len(_mat_schema),
                                total_rows=int(total_rows or 0),
                                type_mismatches=list(_type_mismatches or []),
                                sides=[_prep_p, _prep_s], db=db)
                return {
                    "total_rows": total_rows,
                    "returned_rows": 0,
                    "offset": 0,
                    "columns": [{"name": f.name, "type": str(f.type)}
                                for f in _mat_schema],
                    "data": [],
                    "parquet_path": str(materialize_to),
                    "materialized": True,
                    "type_mismatches": list(_type_mismatches or []),
                    **({"key_casts": list(_key_casts)} if _key_casts else {}),
                }

            # Apply pagination via DuckDB LIMIT/OFFSET (standard order)
            final_sql = wrapped
            if limit > 0:
                final_sql += f" LIMIT {int(limit)}"
            if offset > 0:
                final_sql += f" OFFSET {int(offset)}"

            result_table = con.execute(final_sql).to_arrow_table()

        # ── Build response ────────────────────────────────────────────────
        col_meta = [{"name": f.name, "type": str(f.type)} for f in result_table.schema]
        data = result_table.to_pydict()
        rows = []
        if result_table.num_rows > 0:
            for i in range(result_table.num_rows):
                rows.append({col: data[col][i] for col in data})

        # Write-through.  The artifact on this road is the PAGE the caller
        # asked for (the combine applies LIMIT/OFFSET), and ``limit`` and
        # ``offset`` are in the key, so what is stored is exactly what a
        # hit may serve.  The whole-combine ``total_rows`` cannot be
        # recomputed from that page, so it rides along in ``extra``.
        _fv_cache_store(_rc_identity, _rc_key, "",
                        row_count=int(result_table.num_rows),
                        column_count=len(col_meta),
                        total_rows=int(total_rows or 0),
                        type_mismatches=list(_type_mismatches or []),
                        sides=[_prep_p, _prep_s], db=db,
                        table=result_table)
        return {
            "total_rows": total_rows,
            "returned_rows": result_table.num_rows,
            "offset": offset,
            "columns": col_meta,
            "data": sanitize_for_json(rows),
            # BF-525 (2026-05-28): cross-side type-mismatch warning.
            # Empty list = schemas align; populated list = DuckDB
            # auto-promoted these columns and downstream aggregations
            # may lose precision.  Each entry: "col_name: primary_type
            # → secondary_type".
            "type_mismatches": list(_type_mismatches or []),
            **({"key_casts": list(_key_casts)} if _key_casts else {}),
        }
    finally:
        # Clean up temp parquet files to prevent disk leak
        import os
        for _tmp_path in (primary_path, secondary_path):
            try:
                if _tmp_path and os.path.exists(str(_tmp_path)):
                    os.unlink(str(_tmp_path))
            except Exception as _cleanup_exc:
                logger.warning("Failed to clean up temp parquet %s: %s", _tmp_path, _cleanup_exc)


def _fv_principal(user_ctx: Optional[Dict], username: str, side: str) -> Dict:
    """THE single builder for the RLS principal on every FV execution path.

    A REAL caller identity (the route's authenticated user dict, carrying
    username/role/groups/is_admin) is used as-is.  Headless callers that
    supply only a username keep a fabricated fv_consumer principal MARKED
    ``rls_unresolved`` — in this engine an unmarked principal with missing
    groups reads governed tables UNFILTERED (core/row_security/rewriter.py
    only refuses when the marker is present), so the marker is what keeps
    the failure CLOSED.  Before 2026-08-23 the two structured-path sites
    fabricated ``groups: []`` withOUT the marker — the exact escalation
    shape this codebase has shipped twice.
    """
    if user_ctx and user_ctx.get("username"):
        return dict(user_ctx)
    return {"username": username or f"fv:{side}",
            "role": "fv_consumer",
            "groups": [],
            "is_admin": False,
            "rls_unresolved": True}


# -- Side preparation / execution -----------------------------------------
#
# 2026-09-07 - SPLIT SO THE RESULT CACHE CAN SEE THE POST-RLS SQL.
#
# ``_execute_side`` used to be one function: resolve the connection, build
# the query config, apply row security, pick an engine, run it.  The result
# cache's consult has to sit BEFORE the sides run (that is the whole point)
# and its key has to be built from the SQL that ACTUALLY runs, which is the
# post-RLS text - so the resolve-and-secure half is hoisted into
# :func:`_prepare_side` and handed back to :func:`_execute_side` verbatim.
#
# Hoisted, NOT copied.  A second implementation of "what does this side
# run" would be a second answer to the question, and the cache would key
# one thing while the engine ran another; here there is exactly one
# ``secure_sql`` call per side per execution, its output is what goes into
# the key, and the same object is what executes.


async def _prepare_side(
    conn_id: int,
    query_dict: dict,
    extra_filters: Optional[List[Dict]] = None,
    side: str = "primary",
    username: str = "system",
    no_limit: bool = False,
    dynamic_columns: Optional[Iterable[str]] = None,
    user_ctx: Optional[Dict] = None,
) -> Dict:
    """Resolve one side up to (not including) the choice of engine.

    Returns the connection, the finished query config, the validated
    model, and - for a side that carries ``raw_sql`` - the FINAL,
    POST-RLS, post-consumer-override SQL text.  ``final_sql`` is ``""``
    for a STRUCTURED side, whose SQL is synthesised and secured inside
    ``execute_api.execute_query_background`` and does not exist yet here.

    Also reports what the result cache needs to VERIFY this side later:
    ``source_tables`` (``conn_id``/name pairs the S3 fingerprinter can
    resolve through the registered-table resolver) and ``local_patterns``
    (absolute paths, for the exact stat-per-file check).
    """
    db = _require_db()
    # BF-594: off-load sync DB.
    conn = await adb(db.get_connection_raw, conn_id)
    if not conn:
        raise HTTPException(500, f"Federation view {side} connection {conn_id} not found")

    conn_type = conn.get("connection_type", "")
    cfg = conn.get("config", {})

    # Build a temporary QueryConfigModel
    from api.models.query_models import QueryConfigModel

    qc_dict = dict(query_dict)
    qc_dict["connection_id"] = conn_id

    # Remove per-side limit during full materialization so all rows are fetched
    if no_limit:
        qc_dict.pop("limit", None)
        qc_dict["limit"] = None

    # Inject extra filters
    if extra_filters:
        existing = list(qc_dict.get("filters") or [])
        existing.extend(extra_filters)
        qc_dict["filters"] = existing

    # The dict ITSELF carries the model's shape: row security and the filter
    # wrap below rebuild the model from it (2026-09-25: only this first build
    # had the raw-SQL fix, so with row security ON a raw-SQL view failed its
    # rewrite with "files: Field required" and answered 403).
    qc_dict = _side_config(qc_dict)
    try:
        qc_model = QueryConfigModel(**qc_dict)
    except Exception as exc:
        # 2026-09-21 -- this was a 500, and a 500 goes through the generic
        # handler, so the caller got "Internal server error, please
        # contact support" while the one actionable sentence ("files:
        # Field required") stayed in the pod log.  The config is CLIENT
        # DATA: POST /api/federation-views stores primary_query /
        # secondary_query WITHOUT validating them against
        # QueryConfigModel, so a view that can never execute saves with a
        # 201 and only fails here.  Found the first time a business report
        # was ever built on data_source_type='federation_view'.  A 400
        # that names the side and the field is the difference between a
        # fix and a support ticket.
        from core.error_sanitizer import sanitize_error as _se
        raise HTTPException(
            400,
            f"Invalid {side} query config on this federation view: "
            f"{_se(str(exc))}. The view stored a query config that "
            f"cannot be executed -- edit the view's {side}_query.")

    # Phase 141: row-security rewrite for the side's raw_sql (no-op when
    # disabled or no policy matches).  The principal is the caller of the
    # federation view; if not supplied we fall back to "fv:<side>" so admin
    # default policies still apply.  Wrapped in asyncio.to_thread - the
    # rewriter performs DB lookups and we are inside an async function.
    import asyncio as _asyncio_fv
    from core.executors.cross_source_combine import side_kind as _x_side_kind
    from core.sql_filter_wrapper import (
        dialect_for_connection_type as _fv_dialect_for)
    _fv_raw_sql = qc_dict.get("raw_sql") or qc_dict.get("custom_sql")
    _is_connector_side = _x_side_kind(conn_type) == "connector"
    if _is_connector_side and not _fv_raw_sql:
        # 2026-10-04 -- a STRUCTURED side on a SQL connector: its statement
        # is built HERE, in the connector's dialect, through the builder's
        # one engine-aware entry point -- so it is secured below like any
        # raw side and the result cache keys the SQL that actually runs.
        _fv_raw_sql = await _asyncio_fv.to_thread(
            _connector_side_sql, qc_model, conn_type, conn_id, conn, side)
        qc_dict["raw_sql"] = _fv_raw_sql
        qc_model = QueryConfigModel(**qc_dict)
    if _fv_raw_sql:
        try:
            from core.row_security import secure_sql as _rs_secure
            _fv_user_ctx = _fv_principal(user_ctx, username, side)
            _secured = await _asyncio_fv.to_thread(
                _rs_secure,
                _fv_raw_sql,
                # The SIDE's grammar (2026-10-04; was hardcoded duckdb).  s3
                # and local resolve to duckdb, as before.
                dialect=_fv_dialect_for(conn_type),
                user_ctx=_fv_user_ctx,
                connection_id=conn_id,
                request_id=f"fv_{side}",
            )
            if _secured != _fv_raw_sql:
                qc_dict["raw_sql"] = _secured
                qc_model = QueryConfigModel(**qc_dict)
                _fv_raw_sql = _secured
        except HTTPException:
            raise
        except Exception as _rs_exc:
            raise HTTPException(
                status_code=403,
                detail=f"Row-security policy enforcement failed: {_rs_exc}",
            )

        # Phase 134-M parity - federation views with raw_sql had the
        # same bug as PV/Feed/Recon: the engine ignores the structured
        # ``filters`` list when raw_sql is present, so the
        # consumer-merged ``extra_filters`` were silently dropped and
        # the publisher's hardcoded ``WHERE business_close_date='...'``
        # always won.  Apply wrap_sql_with_filters with dynamic_columns
        # so each Dynamic-mode column's hardcoded predicate is REMOVED
        # from raw_sql before AND-ing the consumer override.
        if extra_filters and _fv_raw_sql:
            try:
                from core.sql_filter_wrapper import (
                    FilterWrapError, wrap_sql_with_filters,
                    dialect_for_connection_type,
                )
                _fv_dialect = dialect_for_connection_type(conn_type)
                # 2026-10-05 -- the COLUMN's type, from the source's own
                # description of this side's statement (a filter row's
                # declared ``data_type`` wins), so a date filter is a DATE
                # literal on Trino instead of ``date = varchar`` -> failure.
                from core.raw_sql_filter_types import filter_column_types
                _fv_types = await filter_column_types(
                    _fv_raw_sql, extra_filters, connection_id=conn_id, db=db)
                _wrapped_fv_sql = wrap_sql_with_filters(
                    _fv_raw_sql, extra_filters,
                    dialect=_fv_dialect,
                    dynamic_columns=set(dynamic_columns) if dynamic_columns else None,
                    column_types=_fv_types or None,
                )
                if _wrapped_fv_sql and _wrapped_fv_sql != _fv_raw_sql:
                    qc_dict["raw_sql"] = _wrapped_fv_sql
                    qc_model = QueryConfigModel(**qc_dict)
                    # 2026-09-07: the local name is advanced too, so
                    # ``final_sql`` below is the text that RUNS.  It was
                    # previously left at the pre-wrap value, which nothing
                    # read - now the cache key reads it.
                    _fv_raw_sql = _wrapped_fv_sql
                    logger.info(
                        "[fv-wrap] side=%s conn_id=%s filters=%d "
                        "dynamic_cols=%s sql=%s",
                        side, conn_id, len(extra_filters),
                        sorted(dynamic_columns) if dynamic_columns else [],
                        _wrapped_fv_sql[:4000],
                    )
            except FilterWrapError as _fv_wrap_exc:
                # 2026-10-05 -- a filter that cannot be rendered (a value
                # that is not of its column's type, an empty IN list) is the
                # caller's to fix.  It used to fall through to the
                # "structured filter append" below, which a raw-SQL side
                # never reads: the filter was DROPPED and the view answered
                # with MORE rows than asked.  A correctness gate fails.
                raise HTTPException(400, str(_fv_wrap_exc)) from _fv_wrap_exc
            except Exception as _fv_wrap_exc:
                # Not a filter the caller wrote wrong -- the rewrite itself
                # broke.  Refuse rather than run the side unfiltered (the
                # structured append is ignored when raw_sql is present).
                logger.error("[fv-wrap] side=%s wrap failed: %s", side,
                             _fv_wrap_exc, exc_info=True)
                raise HTTPException(
                    500,
                    f"The {side} side's filters could not be applied to its "
                    f"SQL; refusing rather than returning unfiltered rows."
                ) from _fv_wrap_exc

    return {
        "conn": conn,
        "conn_type": conn_type,
        "cfg": cfg,
        "qc_dict": qc_dict,
        "qc_model": qc_model,
        "connection_id": conn_id,
        "side": side,
        # The POST-RLS text, or "" for a structured side.  This is what the
        # result cache hashes; see core/dataset_result_cache.py.
        "final_sql": str(_fv_raw_sql or ""),
        "source_tables": _side_source_tables(conn_id, qc_dict),
        "local_patterns": _side_local_patterns(conn_type, cfg, qc_dict),
    }


def _connector_side_sql(qc_model, conn_type: str, conn_id: int, conn: dict,
                        side: str) -> str:
    """A structured federation side on a SQL connector, rendered for THAT
    engine by ``ParquetQueryEngine.build_query_sql_for_connection`` (the
    builder's one engine-aware entry point; ``QueryNotExpressible`` -- a
    shape the engine cannot run -- is a 400 naming the engine)."""
    from core.parquet_engine_v2 import ParquetQueryEngine, QueryNotExpressible
    from core.query_converter import convert_query_config_to_engine
    engine_config = convert_query_config_to_engine(qc_model)
    try:
        from core.column_types import annotate_from_connector
        from core.connectors import get_connector
        _files = list(engine_config.files or [])
        if _files:
            _c = get_connector(conn_type, conn.get("config") or {})
            try:
                annotate_from_connector(engine_config.filters, _c,
                                        str(_files[0]),
                                        conn.get("config") or {}, conn_id)
            finally:
                try:
                    _c.close()
                except Exception:
                    pass
    except Exception as exc:          # typing is best-effort, as on /execute
        logger.debug("[fv] %s filter typing skipped: %s", side, exc)
    try:
        sql = ParquetQueryEngine(base_path=".").build_query_sql_for_connection(
            engine_config, conn_type)
    except QueryNotExpressible as exc:
        raise HTTPException(400, f"The {side} side cannot run on {conn_type}: {exc}")
    if not (sql or "").strip():
        raise HTTPException(
            400, f"The {side} side on a {conn_type} connection has no table "
                 f"and no SQL -- give it raw_sql or files[0].")
    return sql


def _side_source_tables(conn_id: int, qc_dict: dict) -> List[Dict]:
    """``[{"connection_id", "table"}]`` for the files this side reads.

    Fed to ``dataset_result_cache.store(source_tables=)``, which resolves
    each name through ``snapshot_fingerprint.make_registered_table_s3_resolver``
    with ``table_name_is_prefix=True`` - so a registered table resolves by
    name and a bare S3 prefix resolves as itself.  A name that resolves to
    nothing is simply absent from the fingerprint, which the freshness gate
    reads as "no opinion" and therefore REFUSES to serve.
    """
    out: List[Dict] = []
    for f in (qc_dict.get("files") or []):
        name = str(f or "").strip()
        if name:
            out.append({"connection_id": conn_id, "table": name})
    return out


def _side_local_patterns(conn_type: str, cfg: dict, qc_dict: dict) -> List[str]:
    """Absolute local paths this side reads, for the exact freshness check.

    Only for ``local`` connections: an S3 side is fingerprinted by LIST
    through :func:`_side_source_tables`.

    ALL OR NOTHING.  One file this cannot resolve to a real path - a
    ``virtual://`` reference, an empty entry - and the WHOLE side returns
    ``[]``.  A partial list would be fingerprinted, matched, and reported
    as ``cache_freshness="verified"`` while a file nobody looked at had
    been rewritten underneath: "could not read" is not "unchanged", and a
    freshness claim narrower than the sources it claims about is the
    failure that looks like success.  Returning nothing costs a cache
    miss, which is the safe direction (``serve_unverifiable_seconds``
    defaults to 0, so an entry with nothing verifiable is never stored).
    """
    if (conn_type or "") != "local":
        return []
    import os as _os
    base = str(cfg.get("base_path") or "")
    files = list(qc_dict.get("files") or [])
    if not files:
        return []
    out: List[str] = []
    for f in files:
        p = str(f or "").strip()
        if not p or "://" in p:
            return []
        out.append(p if _os.path.isabs(p) else _os.path.join(base, p))
    return sorted(set(out))


async def _execute_side(
    conn_id: int,
    query_dict: dict,
    extra_filters: Optional[List[Dict]] = None,
    side: str = "primary",
    username: str = "system",
    no_limit: bool = False,
    dynamic_columns: Optional[Iterable[str]] = None,
    user_ctx: Optional[Dict] = None,
    prepared: Optional[Dict] = None,
    side_execution_ids: Optional[List[str]] = None,
) -> "Path":
    """Execute one side of a federation view and return path to output parquet.

    ``side_execution_ids`` (2026-09-29) -- an OUT list: this side's execution
    id is APPENDED to it the moment it is minted, before any await, so a
    caller that holds a resource for as long as the engine runs (the
    published-view handler's slot in the global query cap) can find this
    side's pool task by id (``WorkerPool.on_execution_done``) even after
    its own await was cancelled mid-side.  ``None`` (every other caller)
    changes nothing.

    Phase 124-A: Returns a Path to the result parquet file instead of loading
    the entire result into a pandas DataFrame.  The caller (execute_federation_view)
    uses DuckDB to read + combine both parquet files without loading into RAM.

    no_limit=True removes any saved row limit from the query config so that
    full-table materialization fetches all rows (not just the preview limit).

    ``prepared`` (2026-09-07) - the :func:`_prepare_side` result the caller
    already computed to build the result-cache key.  Passing it back is what
    keeps ONE ``secure_sql`` per side per execution: the SQL that was keyed
    is the SQL that runs.  Omitting it prepares the side here, so every
    existing caller keeps working unchanged.
    """
    from pathlib import Path

    db = _require_db()
    prep = prepared if prepared is not None else await _prepare_side(
        conn_id, query_dict, extra_filters=extra_filters, side=side,
        username=username, no_limit=no_limit,
        dynamic_columns=dynamic_columns, user_ctx=user_ctx,
    )
    conn_type = prep["conn_type"]
    cfg = prep["cfg"]
    qc_dict = prep["qc_dict"]
    qc_model = prep["qc_model"]

    # Build engine
    from core.parquet_engine_v2 import ParquetQueryEngine
    from core.s3_storage import build_s3_config
    from api.execute_api import (
        execute_query_background,
        _paths as _exec_paths,
        _qe_cfg as _exec_qe_cfg,
    )

    from core.executors.cross_source_combine import side_kind as _x_kind
    if _x_kind(conn_type) == "connector":
        return await _execute_connector_side(prep, conn_id, side, username,
                                             side_execution_ids, db)

    if conn_type == "s3":
        # BF-122 H14: Use unified credential resolver (handles keys/portal/assume_role/profile/iam_role + on-prem)
        s3_cfg = dict(cfg)
        try:
            # Phase 131 deep-dive #8 — single utility resolves consumer
            # username (real user string when present; "" when API-key
            # only, which then hits system_account per connection policy).
            from core.credential_resolver import resolve_s3_for_consumer
            # BF-461: federation materialization can run for minutes —
            # preflight refresh prevents mid-flight STS expiry.
            from core.config import aws_portal as _ap_fv_cfg
            s3_cfg = resolve_s3_for_consumer(
                s3_cfg, username,
                min_lifetime_seconds=_ap_fv_cfg.preflight_min_lifetime_seconds,
            )
        except Exception as _fv_cred_exc:
            logger.warning("[fv] credential resolver failed for %s: %s", side, _fv_cred_exc)
        engine = ParquetQueryEngine(
            base_path=str(_exec_paths.parquet_dir) if _exec_paths else "/usr/local/querystudioapi/nfs/data/parquet",
            chunk_size=_exec_qe_cfg.chunk_size if _exec_qe_cfg else 50000,
            s3_config=build_s3_config(s3_cfg),
        )
        engine._registered_tables = cfg.get("registered_tables", [])
        engine._s3_conn_config = s3_cfg  # resolved creds, not original portal config
        engine._s3_bucket = cfg.get("bucket_name", "")
        engine._s3_conn_id = conn_id
    elif conn_type == "local":
        engine = ParquetQueryEngine(
            base_path=str(cfg.get("base_path", str(_exec_paths.parquet_dir) if _exec_paths else "/usr/local/querystudioapi/nfs/data/parquet")),
            chunk_size=_exec_qe_cfg.chunk_size if _exec_qe_cfg else 50000,
        )
    else:
        from core.executors.cross_source_combine import supported_side_types
        raise HTTPException(
            400,
            f"Unsupported connection type '{conn_type}' for federation "
            f"view (supported: {sorted(supported_side_types())}). This "
            f"view was stored before the save-time gate existed.")

    # Check for cross-connection sub-query (the side itself may have secondary_connection)
    sec_conn_id = qc_dict.get("secondary_connection_id")
    sec_qc_dict = qc_dict.get("secondary_query_config")

    execution_id = f"fv_{side}_{uuid.uuid4().hex[:12]}"
    if side_execution_ids is not None:
        side_execution_ids.append(execution_id)      # before any await: a cancel cannot lose it
    output_dir = Path(_exec_paths.downloads_dir) if _exec_paths else Path("/usr/local/querystudioapi/nfs/data/downloads")
    output_dir.mkdir(parents=True, exist_ok=True)
    output_file = output_dir / f"{execution_id}.parquet"

    if sec_conn_id and sec_qc_dict:
        # This side is itself a cross-connection query
        from api.execute_api import execute_cross_query_background
        from core.query_converter import convert_query_config_to_engine
        # 2026-09-07 -- RE-IMPORTED HERE, not inherited.  The
        # ``_prepare_side`` split moved this branch into a different
        # function from the one that binds ``QueryConfigModel``
        # (a function-LOCAL import), so ``sec_qc_model = ...`` below
        # raised NameError the moment a federation side was itself a
        # cross-connection query against s3/local.  A function-local
        # import is a binding with a function-sized scope, and moving
        # code past it silently unbinds the name -- the compiler says
        # nothing because the module never imports it either.
        from api.models.query_models import QueryConfigModel

        engine_config = convert_query_config_to_engine(qc_model)

        # Build secondary engine
        # BF-594: off-load sync DB.
        sec_conn = await adb(db.get_connection_raw, sec_conn_id)
        if not sec_conn:
            raise HTTPException(500, f"Federation {side}: secondary connection {sec_conn_id} not found")
        sec_type = sec_conn.get("connection_type", "")
        sec_cfg = sec_conn.get("config", {})
        # BF-122 H14: unified credential resolver via shared helper.
        # Phase 131 deep-dive #8: extract_username_from_consumer.
        sec_cfg_inj = dict(sec_cfg)
        try:
            from core.credential_resolver import resolve_s3_for_consumer
            # BF-461: federation secondary side — preflight refresh too.
            from core.config import aws_portal as _ap_fv_sec_cfg
            sec_cfg_inj = resolve_s3_for_consumer(
                sec_cfg_inj, username,
                min_lifetime_seconds=_ap_fv_sec_cfg.preflight_min_lifetime_seconds,
            )
        except Exception as _fv_sec_exc:
            logger.warning("[fv] credential resolver failed for %s secondary: %s", side, _fv_sec_exc)

        if sec_type == "s3":
            sec_engine = ParquetQueryEngine(
                base_path=str(_exec_paths.parquet_dir) if _exec_paths else "/usr/local/querystudioapi/nfs/data/parquet",
                chunk_size=_exec_qe_cfg.chunk_size if _exec_qe_cfg else 50000,
                s3_config=build_s3_config(sec_cfg_inj),
            )
            sec_engine._registered_tables = sec_cfg.get("registered_tables", [])
            sec_engine._s3_conn_config = sec_cfg_inj  # BF-101: use injected creds, not original
            sec_engine._s3_bucket = sec_cfg.get("bucket_name", "")
            sec_engine._s3_conn_id = sec_conn_id
        elif sec_type == "local":
            sec_engine = ParquetQueryEngine(
                base_path=str(sec_cfg.get("base_path", str(_exec_paths.parquet_dir) if _exec_paths else "/usr/local/querystudioapi/nfs/data/parquet")),
                chunk_size=_exec_qe_cfg.chunk_size if _exec_qe_cfg else 50000,
            )
        else:
            raise HTTPException(400, f"Unsupported secondary connection type '{sec_type}'")

        sec_qc_model = QueryConfigModel(**_side_config(sec_qc_dict))
        sec_engine_config = convert_query_config_to_engine(sec_qc_model)

        combine = qc_dict.get("combine_mode", "union")
        join_cfg = qc_dict.get("join_config")

        # Phase 131 deep-dive #13 (round 4 follow-up): RLS on cross-source FV.
        _fv_user_ctx_cross = _fv_principal(user_ctx, username, side)
        await execute_cross_query_background(
            execution_id, engine, engine_config,
            sec_engine, sec_engine_config,
            combine_mode=combine,
            join_config=join_cfg,
            executed_by=username,
            user_ctx=_fv_user_ctx_cross,
        )
    else:
        # Simple single-connection execution
        from core.query_converter import convert_query_config_to_engine
        engine_config = convert_query_config_to_engine(qc_model)

        # Phase 131 deep-dive #13 (round 4 follow-up): plumb identity so the
        # structured FV path (no raw_sql) applies RLS via the background
        # function's synth+secure step.
        _fv_user_ctx_bg = _fv_principal(user_ctx, username, side)
        # 2026-10-02 -- a RAW-SQL side hands the executor its statement.
        # ``_prepare_side`` finished it (row security, the consumer's
        # Dynamic-WHERE override) and the result cache keyed THAT text as
        # ``final_sql``, but this call never passed it: the executor ran
        # the side as a STRUCTURED query over ``files`` -- on S3 that read
        # the bare name as a local path ("No files found that match the
        # pattern .../parquet/trades") and the published view answered 500.
        # A structured side's ``final_sql`` is "" -> None, unchanged.
        await execute_query_background(
            execution_id, engine_config,
            active_engine=engine,
            executed_by=username,
            raw_sql=(prep.get("final_sql") or None),
            user_ctx=_fv_user_ctx_bg,
            rls_connection_id=conn_id,
            # 2026-10-02 -- a scan refusal comes back as itself (the callers
            # answer it 422 through api.connector_errors), not as the
            # "execution failed" 500 below.
            reraise_refusals=True,
        )

    # Phase 124-A: Return path to parquet output (no DataFrame load)
    if output_file.exists():
        return output_file

    # Last resort: check DB for output_file path.  BF-594: off-load sync DB.
    exec_record = (
        await adb(db.get_execution, execution_id)
        if hasattr(db, "get_execution") else None
    )
    if exec_record:
        of = exec_record.get("output_file")
        if of and Path(of).exists():
            return Path(of)
        if exec_record.get("status") == "failed":
            raise HTTPException(500, f"Federation {side} execution failed: {exec_record.get('error_message', 'unknown')}")

    raise HTTPException(500, f"Federation {side} execution produced no output")


async def _execute_connector_side(prep: Dict, conn_id: int, side: str,
                                  username: str,
                                  side_execution_ids: Optional[List[str]],
                                  db) -> "Path":
    """One SQL-connector side of a federation view (2026-10-04).

    Runs the side's FINAL, SECURED statement (``_prepare_side``) through THE
    cross-source side runner -- pooled connector -> parquet, bounded memory
    -- ON THE WORKER POOL under the side's execution id, so the published-
    view handler's slot in the global query cap is held for exactly as long
    as the engine runs (``WorkerPool.on_execution_done``), as it is for the
    s3 / local sides.
    """
    from pathlib import Path
    from core.executors.cross_source_combine import (
        SideSpec, run_side_to_parquet)
    from core.worker_pool import WorkType, get_pool
    from api.execute_api import _paths as _exec_paths

    sql = prep.get("final_sql") or ""
    if not sql.strip():
        raise HTTPException(
            400, f"The {side} side of this federation view is on a "
                 f"{prep.get('conn_type')} connection and has no SQL to run.")
    execution_id = f"fv_{side}_{uuid.uuid4().hex[:12]}"
    if side_execution_ids is not None:
        side_execution_ids.append(execution_id)  # before any await
    output_dir = (Path(_exec_paths.downloads_dir) if _exec_paths
                  else Path("/usr/local/querystudioapi/nfs/data/downloads"))
    output_dir.mkdir(parents=True, exist_ok=True)
    output_file = output_dir / f"{execution_id}.parquet"
    connection = {**(prep.get("conn") or {}), "id": conn_id}

    def _run(cancel_event=None) -> int:
        return run_side_to_parquet(
            SideSpec(side, connection=connection, sql=sql), str(output_file),
            cancel_event=cancel_event, db_manager=db,
            execution_id=execution_id).rows

    record = await get_pool().submit(WorkType.INTERACTIVE, _run,
                                     execution_id=execution_id,
                                     username=username or "system")
    await asyncio.wrap_future(record.future)
    if not output_file.exists():
        raise HTTPException(500, f"Federation {side} execution produced no output")
    return output_file
