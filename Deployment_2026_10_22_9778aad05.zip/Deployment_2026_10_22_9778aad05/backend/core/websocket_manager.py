"""
WebSocket Manager for real-time notifications
Handles multiple client connections and broadcasting
"""

from fastapi import WebSocket
from typing import List, Dict, Any
import asyncio
import logging
import threading
from collections import deque, OrderedDict
from datetime import datetime, timezone

from core.json_utils import sanitize_for_json

# BF-591: catch FastAPI/Starlette-specific WS disconnects distinctly from
# real application bugs so the latter get logger.exception while the
# former are routine.  Import is fail-safe (very old Starlette versions).
try:
    from starlette.websockets import WebSocketDisconnect as _WSDisconnect
except Exception:  # pragma: no cover
    class _WSDisconnect(Exception):  # type: ignore
        pass

logger = logging.getLogger(__name__)


async def _safe_send_json(ws: WebSocket, message: Dict[str, Any]) -> None:
    """BF-396 — wrapper around ``WebSocket.send_json`` that ALWAYS sanitises
    the payload through ``sanitize_for_json`` first.

    Starlette's ``send_json`` uses Python's default ``json.dumps`` which emits
    bare ``NaN`` / ``Infinity`` literals for non-finite floats — those are
    RFC-invalid and the browser's ``JSON.parse()`` (and ``fetch().json()``)
    rejects them, breaking the WS message handler with a parse error.

    Every WS message sent by this manager goes through this helper so the
    sanitisation is in ONE place — no scattered ``sanitize_for_json()`` calls
    at each call site.  NaN / Infinity → None; datetimes / Decimal / pandas
    NaT → str / float / None as appropriate.
    """
    await ws.send_json(sanitize_for_json(message))


class WebSocketManager:
    """
    Manages WebSocket connections and broadcasting
    """

    MAX_CONNECTIONS = 500  # Global limit to prevent DoS

    def __init__(self):
        """Initialize WebSocket manager"""
        self.active_connections: List[WebSocket] = []
        self.connection_info: Dict[WebSocket, Dict[str, Any]] = {}
        self._heartbeat_task: asyncio.Task | None = None
        self._main_loop: asyncio.AbstractEventLoop | None = None
        # BF-470 (2026-05-19) — per-user pending-message buffer.  When
        # broadcast_to_user fires for a username that has NO matching
        # connection (typical race: server fires feed_progress in the
        # ~100 ms gap between the client's ws.onopen and its identify
        # message being processed), we buffer the message here keyed
        # by username.  The buffer is drained when the client identifies
        # (see main._handle_ws identify branch).  Bounded:
        #   BUFFER_TTL_SECONDS — entries expire after this many seconds
        #   BUFFER_MAX_PER_USER — cap per-user list to prevent memory bombs
        #   BUFFER_MAX_USERS — cap distinct usernames buffered
        # All values are conservative defaults; expiry sweep runs inside
        # the heartbeat loop so we don't need a separate task.
        # BF-591: switched to ``OrderedDict`` so eviction can be LRU via
        # ``move_to_end`` instead of FIFO-by-first-insert — previously the
        # quietest user was always evicted first when the cap was hit.
        self._pending_per_user: "OrderedDict[str, deque]" = OrderedDict()
        self._PENDING_TTL_SECONDS: float = 60.0
        self._PENDING_MAX_PER_USER: int = 100
        self._PENDING_MAX_USERS: int = 200
        # BF-591: instance-level counter + lock for sync-broadcast cap.
        # Previously declared as class attributes — first ``self.X += 1``
        # creates an instance attr while the class attr stays at 0,
        # decoupling lock-and-counter across instances and yielding
        # stale reads from tests that introspected the class attribute.
        self._inflight_sync_broadcasts: int = 0
        self._inflight_sync_lock = threading.Lock()
        self._MAX_INFLIGHT_SYNC_BROADCASTS = 5000
        # BF-591: thread-safe lock around the pending-buffer mutations.
        # Sync wrappers can be called from worker threads while the
        # event loop reads / drains the buffer.
        self._pending_buffer_lock = threading.Lock()

    async def connect(self, websocket: WebSocket):
        """
        Accept and register a new WebSocket connection

        Args:
            websocket: WebSocket connection
        """
        # Reject if at global connection limit
        if len(self.active_connections) >= self.MAX_CONNECTIONS:
            logger.warning("WebSocket connection rejected — max connections (%d) reached", self.MAX_CONNECTIONS)
            await websocket.close(code=1013, reason="Max connections reached")
            return

        await websocket.accept()

        # BF-WS-KEEPALIVE: enable aggressive TCP keepalive so the OS detects
        # dead clients (browser tab closed, network dropped) within ~90 s
        # instead of the default 2-hour Windows / 7200 s Linux timeout.
        # 2026-06-03 audit closeout — enhanced socket extraction
        # (try 5 paths for Windows uvicorn-websockets compatibility) +
        # Windows-specific SIO_KEEPALIVE_VALS ioctl fallback.  Without
        # this the BF-WS-KEEPALIVE patch was a silent no-op on the
        # most common prod combo (Windows + uvicorn + websockets impl).
        try:
            import socket as _sock
            import sys as _sys
            raw_sock = None
            # Path 1 — modern transport with get_extra_info("socket")
            transport = getattr(websocket, "_transport", None)
            if transport is None and hasattr(websocket, "scope"):
                transport = websocket.scope.get("transport")
            if transport is not None:
                _gei = getattr(transport, "get_extra_info", None)
                if _gei is not None:
                    raw_sock = _gei("socket")
            # Path 2 — walk private attributes (uvicorn-websockets stores
            # the protocol on _send.__self__.protocol).
            if raw_sock is None:
                for _attr in ("_send", "_receive"):
                    _bound = getattr(websocket, _attr, None)
                    if _bound is None:
                        continue
                    _self = getattr(_bound, "__self__", None)
                    if _self is None:
                        continue
                    _proto = getattr(_self, "protocol", None) or _self
                    _t = getattr(_proto, "transport", None)
                    if _t is not None:
                        _gei = getattr(_t, "get_extra_info", None)
                        if _gei is not None:
                            raw_sock = _gei("socket")
                            if raw_sock is not None:
                                break
            # Path 3 — uvicorn websockets impl stores connection on
            # websocket.scope["asgi"]["server"] (rare).
            if raw_sock is None and hasattr(websocket, "scope"):
                _asgi = websocket.scope.get("asgi", {})
                _srv = _asgi.get("server") if isinstance(_asgi, dict) else None
                if _srv is not None:
                    _gei = getattr(_srv, "get_extra_info", None)
                    if _gei is not None:
                        raw_sock = _gei("socket")
            if raw_sock is not None:
                raw_sock.setsockopt(_sock.SOL_SOCKET, _sock.SO_KEEPALIVE, 1)
                # Linux / macOS tuning — fine-grained via setsockopt.
                if hasattr(_sock, "TCP_KEEPIDLE"):
                    raw_sock.setsockopt(_sock.IPPROTO_TCP, _sock.TCP_KEEPIDLE, 30)
                if hasattr(_sock, "TCP_KEEPINTVL"):
                    raw_sock.setsockopt(_sock.IPPROTO_TCP, _sock.TCP_KEEPINTVL, 15)
                if hasattr(_sock, "TCP_KEEPCNT"):
                    raw_sock.setsockopt(_sock.IPPROTO_TCP, _sock.TCP_KEEPCNT, 4)
                # Windows — SIO_KEEPALIVE_VALS via ioctl gives equivalent
                # control (onoff, idle_ms, interval_ms).  Constants:
                #   onoff      = 1
                #   keepalive  = 30000 ms (30s idle before first probe)
                #   interval   = 15000 ms (15s between probes)
                # Win counts up to 5 unacknowledged probes by default → dead in ~75-90s.
                if _sys.platform.startswith("win"):
                    try:
                        if hasattr(_sock, "SIO_KEEPALIVE_VALS"):
                            raw_sock.ioctl(_sock.SIO_KEEPALIVE_VALS, (1, 30000, 15000))
                        else:
                            # Fall back to the raw control code.
                            raw_sock.ioctl(0x98000004, (1, 30000, 15000))
                        logger.debug("WS keepalive: Windows SIO_KEEPALIVE_VALS applied (idle=30s, interval=15s)")
                    except Exception as _win_exc:
                        logger.debug("WS keepalive Windows ioctl failed: %s", _win_exc)
                logger.debug(
                    "WS keepalive enabled (idle=30s, interval=15s, platform=%s)",
                    _sys.platform,
                )
            else:
                logger.debug(
                    "WS keepalive could not access raw socket (transport=%s); "
                    "OS defaults apply (Linux ~2h, Windows 2h).  This is the "
                    "known limitation on the uvicorn-websockets impl.",
                    type(transport).__name__ if transport else "None",
                )
        except Exception as _ka_exc:
            # Never fail accept on keepalive tuning issues — best-effort.
            logger.debug("WS TCP keepalive tuning skipped: %s", _ka_exc)

        # BF-591: populate ``connection_info`` BEFORE adding to
        # ``active_connections`` so any concurrent reader (heartbeat tick,
        # broadcast, get_connection_stats) cannot observe the ws in the
        # list but missing from the info dict.
        self.connection_info[websocket] = {
            "connected_at": datetime.now(timezone.utc),
            "last_seen_at": datetime.now(timezone.utc),
            "message_count": 0
        }
        self.active_connections.append(websocket)

        # Send welcome message
        await self.send_personal_message(
            {
                "type": "connection_established",
                "message": "Connected to Parquet Query Engine",
                "timestamp": datetime.now(timezone.utc).isoformat()
            },
            websocket
        )

        logger.info(f"New WebSocket connection. Total connections: {len(self.active_connections)}")

    def disconnect(self, websocket: WebSocket):
        """
        Remove a WebSocket connection (sync — for synchronous callers).

        BF-591: prefer :meth:`disconnect_and_close` from async paths so
        the underlying OS socket is actively closed.  This sync variant
        only removes tracking entries.
        """
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)

        if websocket in self.connection_info:
            del self.connection_info[websocket]

        logger.info(f"WebSocket disconnected. Total connections: {len(self.active_connections)}")

    async def disconnect_and_close(self, websocket: WebSocket) -> None:
        """BF-591: async disconnect that actively closes the socket so
        a stale/dead client doesn't linger in the OS until TCP retransmits
        give up.  Heartbeat prune path should use this; sync callers can
        keep calling :meth:`disconnect`.
        """
        try:
            await asyncio.wait_for(websocket.close(), timeout=1.0)
        except Exception:
            # Best-effort — if the socket was already dead the close
            # call may raise; we still need to drop our tracking.
            pass
        self.disconnect(websocket)

    async def send_personal_message(self, message: Dict[str, Any], websocket: WebSocket):
        """
        Send a message to a specific client

        Args:
            message: Message to send
            websocket: Target WebSocket connection

        BF-591: split exception handling — ``WebSocketDisconnect`` is a
        routine event (client closed), but any other exception is likely
        a real application bug (unserializable payload, etc.) and
        deserves an ERROR-level log with stack trace so it surfaces in
        ops dashboards instead of being silently swallowed as a
        disconnect.
        """
        try:
            await _safe_send_json(websocket, message)

            if websocket in self.connection_info:
                self.connection_info[websocket]["message_count"] += 1

        except (_WSDisconnect, asyncio.CancelledError):
            self.disconnect(websocket)
        except Exception as e:
            logger.exception("WS send_personal_message failed (likely app bug): %s", e)
            self.disconnect(websocket)

    # ── Fleet routing (2026-08-02) — websocket_and_progress_fleet_routed ──
    #
    # ``active_connections`` is per-process, so with >1 replica behind a
    # TLS-passthrough route (no cookie affinity) a user's WebSocket lands on
    # a random pod while their query may execute on another — progress,
    # completion and cancellation events used to reach only the EXECUTING
    # pod's clients.  Every non-``local_only`` broadcast is therefore ALSO
    # relayed to peer pods through the event bus's NOTIFY-only half
    # (``publish_notify_only``): PG LISTEN/NOTIFY, already a hard dependency,
    # no new infrastructure.  Each pod's LISTEN consumer (started by main.py)
    # delivers relayed events to ITS local clients via the registered
    # subscriber, which calls back into this manager with ``local_only=True``
    # so bus-delivered events are never re-relayed (no ping-pong).
    #
    # Cost/guarantees:
    #   * N=1 / sqlite / bus un-wired: publish_notify_only returns
    #     immediately (no PG backend) — the local path is byte-identical.
    #   * The relay is fire-and-forget on the bus's thread pool — the event
    #     loop never waits on a DB round-trip, and a broken bus can never
    #     block or fail a broadcast (fail-open, debug-logged).
    #   * Delivery is at-least-once fleet-wide: local delivery is unchanged;
    #     the cross-pod fast path is PG NOTIFY (lost-on-listener-outage
    #     windows are healed by the event bus gap-replay of terminal
    #     execution rows).  UI updates are idempotent per execution_id.

    def _relay_cross_pod(self, message: Dict[str, Any],
                         username: "str | None" = None) -> None:
        """Best-effort relay of *message* to peer pods.  Never raises,
        never blocks on the DB, no-op when the PG event bus is not wired."""
        try:
            from core.event_bus import publish_notify_only
            publish_notify_only(message, username=username)
        except Exception as exc:
            logger.debug("[websocket] cross-pod relay skipped (fail-open, "
                         "local delivery unaffected): %s", exc)

    async def broadcast(self, message: Dict[str, Any], local_only: bool = False):
        """
        Broadcast a message to all connected clients.

        Snapshots the connection list before iterating so that concurrent
        connects/disconnects (which can happen between await points) do not
        cause RuntimeError from list mutation during iteration.

        ``local_only=True`` skips the cross-pod relay — used by the event-bus
        subscriber (the message ALREADY came from / went to the bus) and by
        per-pod DB pollers that run identically on every pod.
        """
        if not local_only:
            self._relay_cross_pod(message)
        # Take a snapshot so mutations during await points don't affect this pass
        connections = list(self.active_connections)
        disconnected = []

        for connection in connections:
            try:
                # BF-WS-NOBLOCK: bound the per-client send so one slow client
                # can't stall the entire broadcast (and event loop).
                # BF-396: sanitise NaN/Infinity/etc via _safe_send_json.
                await asyncio.wait_for(_safe_send_json(connection, message), timeout=5.0)

                if connection in self.connection_info:
                    self.connection_info[connection]["message_count"] += 1

            except asyncio.TimeoutError:
                logger.warning("WS broadcast to client exceeded 5s — disconnecting slow client")
                disconnected.append(connection)
            except Exception as e:
                logger.error(f"Error broadcasting to client: {e}")
                disconnected.append(connection)

        # Clean up disconnected clients
        for connection in disconnected:
            self.disconnect(connection)

        if connections:
            logger.debug(f"Broadcast message to {len(connections)} clients")

    # ── BF-470 buffer helpers ──────────────────────────────────────────────

    @staticmethod
    def _is_synthetic_username(username: str) -> bool:
        """BF-470 deep-dive gap #1 — synthetic usernames (the ones with
        a ``:`` prefix like ``pv:slug``, ``apikey:abc``, ``shared:xxx``,
        ``embed:yyy``, ``published_view:slug``) intentionally never
        match a real WS connection (BF-110).  Buffering messages for
        them is pure waste — they'd sit until TTL and could evict
        legitimate pending events for real users when the
        total-users cap is hit.  Skip them.
        """
        return bool(username) and ":" in username

    def _buffer_for_unconnected_user(self, username: str, message: Dict[str, Any]) -> None:
        """Stash a message for *username* until they identify.  Bounded by
        TTL + per-user cap + total-users cap so it can't be used to OOM
        the pod.  Called from broadcast_to_user when no matching WS
        connection exists.  Safe to call frequently — uses deque for
        O(1) append + O(1) drop-oldest on overflow.

        Synthetic usernames (containing ``:``) are skipped — they'd
        never be drained.  See _is_synthetic_username.

        BF-591: LRU eviction via ``move_to_end`` keeps the *quietest*
        user from being evicted first when the user-cap is hit; and
        thread-safe mutation via ``_pending_buffer_lock`` permits
        worker-thread callers (``broadcast_to_user_sync``) to share
        state with the event-loop reader.
        """
        if not username:
            return
        if self._is_synthetic_username(username):
            return
        import time as _t
        with self._pending_buffer_lock:
            # Cap distinct users: if we're at the limit and this user is
            # new, evict the oldest-touched (LRU) user.
            if (username not in self._pending_per_user
                    and len(self._pending_per_user) >= self._PENDING_MAX_USERS):
                self._pending_per_user.popitem(last=False)
            buf = self._pending_per_user.setdefault(
                username, deque(maxlen=self._PENDING_MAX_PER_USER),
            )
            # LRU: move user to most-recently-used end.
            self._pending_per_user.move_to_end(username, last=True)
            buf.append((_t.time(), message))

    def take_pending_for_user(self, username: str) -> List[Dict[str, Any]]:
        """Pop ALL pending (and not-yet-expired) messages for *username*
        and return them in arrival order.  Called by the identify
        handler.  Expired entries (> TTL) are silently dropped — they're
        stale anyway and the client wouldn't act on them sensibly.
        Returns ``[]`` when no pending entries exist.

        BF-591: locked snapshot avoids losing entries to a concurrent
        worker-thread ``broadcast_to_user_sync`` append.
        """
        if not username:
            return []
        import time as _t
        now = _t.time()
        with self._pending_buffer_lock:
            buf = self._pending_per_user.pop(username, None)
        if buf is None:
            return []
        return [
            payload for ts, payload in buf
            if (now - ts) <= self._PENDING_TTL_SECONDS
        ]

    def _sweep_pending_buffers(self) -> int:
        """Drop expired entries from every per-user buffer.  Returns the
        number of entries dropped.  Called from the heartbeat loop so
        we don't need a separate task.  Cheap: O(users * messages-per-user)
        with deque popleft on stale entries.
        """
        import time as _t
        now = _t.time()
        dropped = 0
        with self._pending_buffer_lock:
            for username in list(self._pending_per_user.keys()):
                buf = self._pending_per_user[username]
                while buf and (now - buf[0][0]) > self._PENDING_TTL_SECONDS:
                    buf.popleft()
                    dropped += 1
                if not buf:
                    del self._pending_per_user[username]
        return dropped

    async def broadcast_to_user(self, username: str, message: Dict[str, Any],
                                local_only: bool = False):
        """Broadcast a message only to connections identified as *username*.

        Fleet routing (2026-08-02): unless ``local_only`` is set, the message
        is ALSO relayed to peer pods via the event bus's NOTIFY-only half so
        a user whose WebSocket landed on a different pod than the one
        executing their query still receives progress / completion / cancel
        events.  The relay happens BEFORE the local-connection lookup because
        "no matching local connection" is precisely the case where the user
        is most likely connected elsewhere.  ``local_only=True`` is passed by
        the event-bus subscriber (bus-delivered events must not re-relay) and
        by per-pod DB pollers (every pod already delivers locally).

        Falls back to full broadcast ONLY when no connections have identified
        themselves at all (backward-compatible: old clients without ``identify``
        still receive all messages). If ANY connection has identified, we only
        target matching usernames — non-matching users get nothing.

        BF-110: Published view executions use synthetic usernames like
        'published_view:slug' that never match real WS connections, preventing
        execution progress messages from leaking to logged-in users.

        BF-WS-NOBLOCK: per-client send wrapped in 5s timeout so a slow / stalled
        WS client cannot block the event loop (and the WS heartbeat task) for
        the full TCP retransmit window.  Slow clients are disconnected.  This
        was the suspected cause of "WebSocket connection closed → API
        unavailable" the user reported during long-running queries: a single
        slow send blocked the heartbeat, the WS ping stopped firing, browser
        detected dead WS, closed it.
        """
        if not local_only and username and not self._is_synthetic_username(username):
            # Empty username is silently dropped locally (BF-110) — relaying
            # it would hit the broadcast-all fallback on REMOTE pods and leak
            # a user-scoped event to everyone.  Synthetic usernames
            # ("pv:slug", "published_view:slug", ...) never match a real WS
            # connection on ANY pod, so relaying them is pure NOTIFY waste.
            self._relay_cross_pod(message, username=username)
        # 2026-06-03 — snapshot connection_info BEFORE iterating to
        # avoid `RuntimeError: dictionary changed size during iteration`
        # when a concurrent connect/disconnect mutates the dict mid-
        # fan-out.  Was a root cause of the user-reported wifi-icon
        # disconnect: an unhandled RuntimeError dropped the broadcast,
        # heartbeat tick fell behind, browser declared the WS dead.
        # broadcast() at line 234 already does this; broadcast_to_user
        # was the missing twin.
        try:
            _snapshot = list(self.connection_info.items())
        except RuntimeError:
            # Extremely rare — list() race itself.  Retry once with
            # tuple-copy.
            _snapshot = list(tuple(self.connection_info.items()))
        targeted = [ws for ws, info in _snapshot if info.get("username") == username]
        if not targeted:
            # BF-470 (2026-05-19) — buffer the message keyed by username
            # so a client that's about to identify (ws.onopen → identify
            # race window) doesn't miss events.  Drained on identify.
            # No-op for synthetic usernames that will never have a real
            # WS connection (e.g. "published_view:slug") because they
            # expire via TTL sweep.
            self._buffer_for_unconnected_user(username, message)
            # Only fall back to full broadcast if NO connections have ever identified
            # themselves. If any have, it means the target user simply isn't connected.
            # H1 (2026-10-07): a message marked ``user_only`` (execution_queued
            # -- it names the user's execution and correlation id) NEVER takes
            # that fallback.  The mark travels in the message itself, so a
            # peer pod delivering the cross-pod relay honours it too.
            any_identified = any(info.get("username") for _, info in _snapshot)
            if any_identified or message.get("user_only"):
                return  # Target user not connected — buffered above for later replay
            # local_only=True: the cross-pod relay (if any) already fired at
            # the top of this method — relaying again here would duplicate.
            await self.broadcast(message, local_only=True)
            return

        disconnected = []
        for ws in targeted:
            try:
                # BF-396: sanitise NaN/Infinity/etc via _safe_send_json.
                await asyncio.wait_for(_safe_send_json(ws, message), timeout=5.0)
                if ws in self.connection_info:
                    self.connection_info[ws]["message_count"] += 1
            except asyncio.TimeoutError:
                logger.warning("WS send to user %s exceeded 5s — disconnecting slow client", username)
                disconnected.append(ws)
            except Exception as e:
                logger.error("Error sending to user %s: %s", username, e)
                disconnected.append(ws)
        for ws in disconnected:
            self.disconnect(ws)

    async def broadcast_to_users(self, usernames: List[str],
                                 message: Dict[str, Any],
                                 local_only: bool = False):
        """Deliver *message* to the connections of EVERY name in
        *usernames* (2026-10-07: a feed event's audience is the actor, the
        owner and the owner group -- one list, one delivery).

        One name is exactly :meth:`broadcast_to_user`.  For several: the
        cross-pod relay fires ONCE carrying the list (each peer delivers to
        its own connections of those names); each matching local connection
        gets one send; a name with no local connection is buffered for its
        identify (BF-470); the broadcast-all fallback for a pod where NOBODY
        has identified is the same as the single-user method's, and never
        for a ``user_only`` message.  The routing list itself never reaches
        a browser (``audience`` is stripped from what is sent).
        """
        names: List[str] = []
        for n in usernames or []:
            if isinstance(n, str) and n and n not in names:
                names.append(n)
        if not names:
            return
        client_msg = {k: v for k, v in message.items() if k != "audience"}
        if len(names) == 1:
            await self.broadcast_to_user(names[0], client_msg,
                                         local_only=local_only)
            return
        real = [n for n in names if not self._is_synthetic_username(n)]
        if not local_only and real:
            try:
                from core.event_bus import publish_notify_only
                publish_notify_only(client_msg, username=real[0],
                                    audience=real)
            except Exception as exc:
                logger.debug("[websocket] cross-pod relay skipped (fail-open, "
                             "local delivery unaffected): %s", exc)
        try:
            _snapshot = list(self.connection_info.items())
        except RuntimeError:
            _snapshot = list(tuple(self.connection_info.items()))
        wanted = set(names)
        targeted = [ws for ws, info in _snapshot
                    if info.get("username") in wanted]
        connected = {info.get("username") for ws, info in _snapshot
                     if info.get("username") in wanted}
        for n in names:
            if n not in connected:
                self._buffer_for_unconnected_user(n, client_msg)
        if not targeted:
            any_identified = any(info.get("username") for _, info in _snapshot)
            if any_identified or client_msg.get("user_only"):
                return
            await self.broadcast(client_msg, local_only=True)
            return
        disconnected = []
        for ws in targeted:
            try:
                await asyncio.wait_for(_safe_send_json(ws, client_msg),
                                       timeout=5.0)
                if ws in self.connection_info:
                    self.connection_info[ws]["message_count"] += 1
            except asyncio.TimeoutError:
                logger.warning("WS send to user %s exceeded 5s — "
                               "disconnecting slow client",
                               self.connection_info.get(ws, {}).get("username"))
                disconnected.append(ws)
            except Exception as e:
                logger.error("Error sending to user %s: %s",
                             self.connection_info.get(ws, {}).get("username"), e)
                disconnected.append(ws)
        for ws in disconnected:
            self.disconnect(ws)

    async def deliver_addressed(self, event: Dict[str, Any],
                                local_only: bool = False):
        """Deliver an event that arrived ADDRESSED -- from the event bus (a
        local publish or a peer pod's NOTIFY), the notification outbox, or
        the Redis relay -- to exactly its recipients
        (``core.event_bus.recipients_of``: the ``audience`` list, else the
        ``username``).  An event published with NO address keeps the
        pre-existing unaddressed broadcast; an EMPTY audience goes to
        nobody.  The one delivering half every relay calls, so a list
        published on one pod is honoured on all of them."""
        from core.event_bus import recipients_of
        targets = recipients_of(event)
        if targets is None:
            await self.broadcast(event, local_only=local_only)
            return
        if targets:
            await self.broadcast_to_users(targets, event, local_only=local_only)
        # 2026-10-17 -- the BOARD WATCH: a feed event addressed to its owner
        # also reaches every local connection watching the feed board whose
        # principal sees the whole estate.  Local on every pod: the relay
        # above (or the bus that brought this event) already carries it to
        # the peers, each of which runs this same fan-out for its own
        # watchers.  An EMPTY audience still reaches a watcher: the event is
        # about a feed, and the watcher's grant is the estate.
        await self._deliver_to_watchers(event, targets)

    # ── the board watch (2026-10-17) ──────────────────────────────────────
    #
    # Feed events are ADDRESSED (core/feed/event_audience.py): the actor, the
    # owner and the owner group -- deliberately not every admin, so the
    # estate's every event does not reach every admin browser.  The
    # operations user watching Feed Run Status is the one person who DOES
    # want every feed's event, and only while watching: a connection may
    # WATCH a scope, and a feed event is then also delivered to it.  Only an
    # IDENTIFIED connection whose principal sees every feed
    # (core.feed.permissions.sees_every_feed, stamped at identify) may
    # watch; anyone else is refused, and an unidentified socket cannot ask.

    WATCH_SCOPES = frozenset({"feed_board"})

    def set_watch(self, websocket: WebSocket, scope: str, on: bool) -> Dict[str, Any]:
        """Start (``on``) or stop watching ``scope`` on this connection.
        Returns the answer to send back: ``{"type": "watching", "scope",
        "ok", "reason"}`` -- a refusal is SAID, never silent."""
        info = self.connection_info.get(websocket)
        if scope not in self.WATCH_SCOPES:
            return {"type": "watching", "scope": scope, "ok": False, "on": on,
                    "reason": f"unknown scope {scope!r}"}
        if info is None:
            return {"type": "watching", "scope": scope, "ok": False, "on": on,
                    "reason": "connection not registered"}
        watching = info.setdefault("watch", set())
        if not on:
            watching.discard(scope)
            return {"type": "watching", "scope": scope, "ok": True, "on": False, "reason": None}
        if not info.get("username"):
            return {"type": "watching", "scope": scope, "ok": False, "on": True,
                    "reason": "identify first (a watch needs a signed-in principal)"}
        if not info.get("sees_every_feed"):
            return {"type": "watching", "scope": scope, "ok": False, "on": True,
                    "reason": "only a principal who sees every feed (admin / support) may watch the board"}
        watching.add(scope)
        return {"type": "watching", "scope": scope, "ok": True, "on": True, "reason": None}

    def watchers_of(self, scope: str) -> List[WebSocket]:
        try:
            snapshot = list(self.connection_info.items())
        except RuntimeError:
            snapshot = list(tuple(self.connection_info.items()))
        return [ws for ws, info in snapshot
                if scope in (info.get("watch") or ()) and info.get("username")
                and info.get("sees_every_feed")]

    @staticmethod
    def _is_feed_event(event: Dict[str, Any]) -> bool:
        try:
            from core.feed.event_audience import FEED_EVENT_TYPES
            return str(event.get("type") or "") in FEED_EVENT_TYPES
        except Exception:                               # noqa: BLE001
            return str(event.get("type") or "").startswith("feed_")

    async def _deliver_to_watchers(self, event: Dict[str, Any], already: List[str]) -> None:
        if not self._is_feed_event(event):
            return
        watchers = self.watchers_of("feed_board")
        if not watchers:
            return
        skip = set(already or [])
        disconnected = []
        for ws in watchers:
            info = self.connection_info.get(ws) or {}
            name = info.get("username")
            if name in skip:
                continue                                # addressed: it already arrived
            # the browser's per-user filter (wsService: a message naming
            # another user is dropped) -- address the copy to the watcher
            msg = {k: v for k, v in event.items() if k != "audience"}
            msg["username"] = name
            msg["via"] = "feed_board_watch"
            try:
                await asyncio.wait_for(_safe_send_json(ws, msg), timeout=5.0)
                if ws in self.connection_info:
                    self.connection_info[ws]["message_count"] += 1
            except asyncio.TimeoutError:
                logger.warning("WS send to board watcher %s exceeded 5s — disconnecting", name)
                disconnected.append(ws)
            except Exception as exc:                    # noqa: BLE001
                logger.error("Error sending to board watcher %s: %s", name, exc)
                disconnected.append(ws)
        for ws in disconnected:
            self.disconnect(ws)

    # BF-589/590/591: bounded back-pressure on sync broadcasts.
    # The actual counter + lock + cap are instance attributes set in
    # ``__init__`` so multi-instance test harnesses don't share state.
    # See ``__init__`` for the canonical declarations.

    def broadcast_sync(self, message: Dict[str, Any], local_only: bool = False):
        """Fire-and-forget broadcast from synchronous (non-async) code.

        Uses ``run_coroutine_threadsafe`` to schedule on the main event loop.
        Safe to call from background threads (e.g. ThreadPoolExecutor workers).
        Silently no-ops if no loop is available.

        BF-589: rejects when in-flight sync broadcasts exceed the cap —
        prevents memory blow-up when the event loop is blocked by a
        long-running task.

        ``local_only`` is forwarded to :meth:`broadcast` (fleet routing) —
        the relay fires when the scheduled coroutine runs, so a message
        dropped by the back-pressure cap is dropped everywhere (unchanged
        semantics: today it would not have been delivered at all).
        """
        loop = self._main_loop
        if loop is None:
            logger.debug("[websocket] broadcast_sync: no event loop captured yet")
            return
        # BF-590: atomic check-and-increment.
        with self._inflight_sync_lock:
            if self._inflight_sync_broadcasts >= self._MAX_INFLIGHT_SYNC_BROADCASTS:
                # Don't unbound-queue more.  Drop with a one-time log.
                logger.warning(
                    "[websocket] BF-589: broadcast_sync back-pressure cap "
                    "reached (%d in flight) — dropping message type=%s",
                    self._inflight_sync_broadcasts, message.get("type"),
                )
                return
            self._inflight_sync_broadcasts += 1
        coro = self.broadcast(message, local_only=local_only)
        # BF-591: wrap BOTH ``run_coroutine_threadsafe`` and
        # ``add_done_callback`` in the try so a failure in either path
        # decrements the counter (previously only ``run_coroutine_threadsafe``
        # was guarded — if ``add_done_callback`` raised, the future would
        # run to completion without the callback decrementing).
        _scheduled = False
        try:
            fut = asyncio.run_coroutine_threadsafe(coro, loop)
            _scheduled = True
            fut.add_done_callback(lambda _f: self._dec_inflight_sync())
        except Exception:
            if not _scheduled:
                # run_coroutine_threadsafe failed — coro never started.
                try:
                    coro.close()
                except Exception:
                    pass
            with self._inflight_sync_lock:
                self._inflight_sync_broadcasts = max(
                    0, self._inflight_sync_broadcasts - 1,
                )
            logger.debug("[websocket] broadcast_sync: scheduling failed")

    def _dec_inflight_sync(self):
        # BF-590/591: lock-protected; nothing else to swallow.
        with self._inflight_sync_lock:
            self._inflight_sync_broadcasts = max(
                0, self._inflight_sync_broadcasts - 1
            )

    def broadcast_to_user_sync(self, username: str, message: Dict[str, Any],
                               local_only: bool = False):
        """Fire-and-forget user-scoped broadcast from synchronous (non-async) code.

        Mirrors :meth:`broadcast_sync` but targets only connections identified
        as *username*.  Falls back to full broadcast if no identified connections.

        BF-591: shares the same back-pressure cap as ``broadcast_sync`` —
        without this, a hung event loop with a worker-thread caller of
        ``broadcast_to_user_sync`` would queue unbounded coroutines and
        OOM the pod (the same hazard BF-589 closed for ``broadcast_sync``).
        """
        loop = self._main_loop
        if loop is None:
            logger.debug("[websocket] broadcast_to_user_sync: no event loop captured yet")
            return
        with self._inflight_sync_lock:
            if self._inflight_sync_broadcasts >= self._MAX_INFLIGHT_SYNC_BROADCASTS:
                logger.warning(
                    "[websocket] BF-591: broadcast_to_user_sync back-pressure "
                    "cap reached (%d in flight) — dropping message to %s type=%s",
                    self._inflight_sync_broadcasts, username, message.get("type"),
                )
                return
            self._inflight_sync_broadcasts += 1
        coro = self.broadcast_to_user(username, message, local_only=local_only)
        _scheduled = False
        try:
            fut = asyncio.run_coroutine_threadsafe(coro, loop)
            _scheduled = True
            fut.add_done_callback(lambda _f: self._dec_inflight_sync())
        except Exception:
            if not _scheduled:
                try:
                    coro.close()
                except Exception:
                    pass
            with self._inflight_sync_lock:
                self._inflight_sync_broadcasts = max(
                    0, self._inflight_sync_broadcasts - 1,
                )
            logger.debug("[websocket] broadcast_to_user_sync: scheduling failed")

    def get_connection_count(self) -> int:
        """
        Get the number of active connections

        Returns:
            Number of active connections
        """
        return len(self.active_connections)

    def get_connection_stats(self) -> Dict[str, Any]:
        """
        Get connection statistics

        Returns:
            Connection statistics
        """
        return {
            "active_connections": len(self.active_connections),
            "total_messages_sent": sum(
                info["message_count"] for info in self.connection_info.values()
            ),
            "connections": [
                {
                    "connected_at": info["connected_at"].isoformat(),
                    "message_count": info["message_count"]
                }
                for info in self.connection_info.values()
            ]
        }

    # ── Heartbeat ───────────────────────────────────────────────────────────

    async def start_heartbeat(self, interval: int = 30):
        """Start periodic ping to detect dead connections.

        Should be called once during FastAPI startup.  Sends a ``ping``
        message every *interval* seconds.  Clients that fail to receive
        the ping are disconnected so the connection list stays clean.
        """
        self._main_loop = asyncio.get_running_loop()
        if self._heartbeat_task and not self._heartbeat_task.done():
            return  # already running
        self._heartbeat_task = asyncio.ensure_future(self._heartbeat_loop(interval))

    async def stop_heartbeat(self):
        """Cancel the heartbeat background task."""
        if self._heartbeat_task and not self._heartbeat_task.done():
            self._heartbeat_task.cancel()
            try:
                await self._heartbeat_task
            except asyncio.CancelledError:
                pass

    # Maximum staleness allowed before a connection is force-pruned even
    # if its OS buffer is still accepting writes.  Browsers should respond
    # to our ping within seconds; 90 s is generous and matches our TCP
    # keepalive (~90 s) so both lines of defense agree.
    # BF-387: raised from 90s to 300s.  Idle tab + 12-second query was being
    # pruned mid-flight because the user's WS hadn't seen traffic in 90s.
    # 5 min gives normal user activity (notification fetches every ~60s)
    # plenty of margin while still cleaning up truly dead connections.
    _STALE_THRESHOLD_SECONDS = 300.0

    async def _heartbeat_loop(self, interval: int = 30):
        """Send ping every *interval* seconds, prune dead connections.

        Two prune signals:
          1. send_json() raises (OS-level error) — the connection is
             definitively dead.
          2. last_seen_at is older than _STALE_THRESHOLD_SECONDS — the
             client hasn't said anything to us in too long, so even if
             the OS still accepts writes (zombie buffer state) we treat
             the connection as dead.  This catches the Windows TCP
             "writes succeed for 2 hours into a dead peer" scenario.
        """
        while True:
            try:
                await asyncio.sleep(interval)
                if not self.active_connections:
                    continue

                ping_msg = {
                    "type": "ping",
                    "ts": datetime.now(timezone.utc).isoformat(),
                }
                now = datetime.now(timezone.utc)
                dead = []
                stale = []
                # BF-588 (2026-05-29): parallel-send heartbeat.  The legacy
                # sequential ``for ws in ...: await asyncio.wait_for(send, 5)``
                # loop took up to 5 × N seconds to complete a tick.  With
                # 100 zombie clients = 500 seconds of event-loop occupation
                # per heartbeat.  Audit (Agent 3) identified this as one of
                # the top causes of perceived "API stopped".  asyncio.gather
                # fan-out fires all sends in parallel; total tick time is
                # bounded by the slowest client (5s cap).

                # Phase 1: identify stale (no per-client send required).
                _candidates: list = []
                for ws in list(self.active_connections):
                    info = self.connection_info.get(ws, {})
                    last_seen = info.get("last_seen_at") or info.get("connected_at")
                    if last_seen:
                        try:
                            age = (now - last_seen).total_seconds()
                            if age > self._STALE_THRESHOLD_SECONDS:
                                stale.append(ws)
                                continue
                        except Exception as _age_exc:
                            logger.debug("WS staleness check skipped: %s", _age_exc)
                    _candidates.append(ws)

                # Phase 2: parallel send with per-client timeout + bounded
                # concurrency.  BF-590: an unbounded ``asyncio.gather`` over
                # N clients fans out N concurrent sends; with 1000 idle
                # connections the loop scheduler does 1000 simultaneous
                # ``send_json`` waits, multiplying per-task overhead and
                # starving real query traffic.  Cap concurrent sends with
                # a Semaphore so tick time scales with the slowest 50,
                # not with N.
                _hb_sem = asyncio.Semaphore(50)

                async def _send_one(ws):
                    async with _hb_sem:
                        try:
                            await asyncio.wait_for(
                                _safe_send_json(ws, ping_msg), timeout=5.0,
                            )
                            if ws in self.connection_info:
                                self.connection_info[ws]["message_count"] += 1
                            return ws, None
                        except asyncio.CancelledError:
                            # BF-593: propagate cancellation — heartbeat
                            # shutdown must not be treated as a per-ws
                            # failure that prunes the client.
                            raise
                        except Exception as exc:
                            # BF-593: TimeoutError is a subclass of
                            # Exception — the old `(TimeoutError, Exception)`
                            # tuple was redundant.
                            return ws, exc

                _results = await asyncio.gather(
                    *(_send_one(ws) for ws in _candidates),
                    return_exceptions=False,
                )
                for ws, err in _results:
                    if err is not None:
                        dead.append(ws)

                # BF-591: the disconnect loop below MUST execute even if
                # the per-ws prune-diagnostic logging raises — otherwise
                # an unexpected error in the diagnostic block (e.g. a
                # naive/aware datetime mismatch on ``info.get("last_seen_at")``)
                # leaves the entire batch undisconnected.  Wrap the
                # logging in its own try/except so it can never starve
                # the disconnect path.

                # BF-WS-DIAG-2: verbose per-connection logging when we
                # prune.  BF-591: each per-ws log line is wrapped so a
                # diagnostic failure (naive/aware datetime, missing key,
                # etc.) cannot block the disconnect path below.
                for ws in dead:
                    try:
                        info = self.connection_info.get(ws, {})
                        user = info.get("username", "anon")
                        last = info.get("last_seen_at") or info.get("connected_at")
                        age = (now - last).total_seconds() if last else -1
                        logger.warning(
                            "WS prune (DEAD): user=%s idle=%.1fs msgs=%d — send_json failed",
                            user, age, info.get("message_count", 0),
                        )
                    except Exception as _diag_dead:
                        logger.debug("WS prune-DEAD diagnostic failed: %s", _diag_dead)
                for ws in stale:
                    try:
                        info = self.connection_info.get(ws, {})
                        user = info.get("username", "anon")
                        last = info.get("last_seen_at") or info.get("connected_at")
                        age = (now - last).total_seconds() if last else -1
                        logger.warning(
                            "WS prune (STALE): user=%s idle=%.1fs msgs=%d — exceeded %.0fs threshold",
                            user, age, info.get("message_count", 0),
                            self._STALE_THRESHOLD_SECONDS,
                        )
                    except Exception as _diag_stale:
                        logger.debug("WS prune-STALE diagnostic failed: %s", _diag_stale)

                # BF-591: prefer ``disconnect_and_close`` so the OS
                # socket is actively closed instead of leaking until
                # TCP retransmits give up.
                # 2026-06-03 — parallelise via asyncio.gather so 50 dead
                # clients × 1s sequential close (= up to 50s of blocking
                # the heartbeat tick) becomes one ~1s burst.  Audit
                # finding: serialized prune could overlap the next
                # heartbeat interval (30s) on a burst-disconnect event.
                _to_close = dead + stale
                if _to_close:
                    async def _close_one(_ws):
                        try:
                            await self.disconnect_and_close(_ws)
                        except Exception:
                            try:
                                self.disconnect(_ws)
                            except Exception:
                                pass
                    await asyncio.gather(
                        *(_close_one(ws) for ws in _to_close),
                        return_exceptions=True,
                    )

                if dead or stale:
                    logger.info(
                        "Heartbeat: pruned %d dead + %d stale connection(s) — total now=%d",
                        len(dead), len(stale), len(self.active_connections),
                    )
                # BF-470 — opportunistic sweep of expired entries in the
                # per-user replay buffer.  Cheap (typically empty), runs
                # alongside the WS prune so we don't need a separate task.
                try:
                    _dropped = self._sweep_pending_buffers()
                    if _dropped:
                        logger.debug(
                            "BF-470: pending buffer expired %d stale message(s)",
                            _dropped,
                        )
                except Exception as _sweep_exc:
                    logger.debug("BF-470 sweep failed (non-fatal): %s", _sweep_exc)
            except asyncio.CancelledError:
                return
            except Exception as exc:
                logger.warning("Heartbeat error: %s", exc)
