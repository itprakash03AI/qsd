"""Feed secrets are ENCRYPTED AT REST (2026-10-13).

Found while building the SQL setup for the owner's 5,000 feeds: a feed's
SFTP password sat in PLAIN TEXT in ``feed_configs.destination_config`` (and
in every definition snapshot and template).  The API masked it on screen;
anyone reading the database -- a DBA, a backup, a support dump -- read every
counterparty's credentials.  Connection passwords were encrypted; feeds were
not.

ONE rule decides what a secret is (:func:`is_secret_key` -- the rule the API
masks with, moved here so the two can never disagree), and ONE column type
applies it: :class:`SecretJSON` encrypts every non-empty STRING under a
secret key when written (``core.crypto.encrypt_value`` -> ``enc::...``) and
decrypts it when read.  Every reader keeps working unchanged; the database
only ever holds ciphertext.  A value already encrypted is left as it is
(idempotent), and a plain value read from an older row passes through
(``decrypt_value``) until :func:`encrypt_stored_feed_secrets` re-writes it
at start-up.
"""
from __future__ import annotations

import logging
from typing import Any

from sqlalchemy.types import JSON, TypeDecorator

logger = logging.getLogger(__name__)

SECRET_KEYS = frozenset({
    "password", "pwd", "secret_access_key", "aws_secret_access_key",
    "secret_key", "private_key", "passphrase", "token", "api_key",
    "sas_token", "connection_string", "access_token", "client_secret",
    "session_token", "aws_session_token",
})
# Substring matches -- any key CONTAINING one of these.  Deliberately not a
# bare "key", so identifiers like ``access_key_id`` / ``key_prefix`` /
# ``host_key_b64`` stay readable.
SECRET_SUBSTR = (
    "password", "secret", "token", "passphrase", "private_key",
    "client_secret", "connection_string", "credential", "sas",
)


def is_secret_key(k: Any) -> bool:
    if not isinstance(k, str):
        return False
    kl = k.lower()
    return kl in SECRET_KEYS or any(s in kl for s in SECRET_SUBSTR)


def _walk(obj: Any, fn) -> Any:
    if isinstance(obj, dict):
        return {k: (fn(v) if is_secret_key(k) and isinstance(v, str) and v else _walk(v, fn))
                for k, v in obj.items()}
    if isinstance(obj, list):
        return [_walk(x, fn) for x in obj]
    return obj


def encrypt_tree(obj: Any) -> Any:
    """A copy with every secret string encrypted (``***`` is never a secret:
    a masked value reaching a write is the caller's bug and is kept as is)."""
    from core.crypto import encrypt_value
    return _walk(obj, lambda v: v if v == "***" else encrypt_value(v))


def decrypt_tree(obj: Any) -> Any:
    """A copy with every secret decrypted -- and a value NO key of this
    process can read KEPT AS STORED (``enc::...``), never turned into "".
    2026-10-15: a pod holding the wrong key read "" and any re-write of the
    row (an edit, the start-up pass) then stored "" encrypted -- the real
    credential destroyed.  Kept, a re-write leaves it untouched (an
    ``enc::`` value is never re-encrypted)."""
    from core.crypto import decrypt_value
    return _walk(obj, lambda v: (decrypt_value(v) or v) if v.startswith("enc::") else v)


def has_plain_secret(obj: Any) -> bool:
    found = []
    _walk(obj, lambda v: found.append(v) or v)
    return any(v != "***" and not v.startswith("enc::") for v in found)


class SecretJSON(TypeDecorator):
    """JSON whose secret values are encrypted in the database."""
    impl = JSON
    cache_ok = True

    def process_bind_param(self, value, dialect):
        return None if value is None else encrypt_tree(value)

    def process_result_value(self, value, dialect):
        return None if value is None else decrypt_tree(value)


#: (model, column) pairs whose stored secrets the start-up pass encrypts
def _secret_columns():
    from core.db.models import (FeedConfig, FeedDefinitionVersion, FeedTemplate,
                                FeedTemplateApplyRequest)
    return ((FeedConfig, ("destination_config", "backend_config", "delivery_chain")),
            (FeedTemplate, ("definition",)),
            (FeedDefinitionVersion, ("definition",)),
            (FeedTemplateApplyRequest, ("feed",)))


def encrypt_stored_feed_secrets(db: Any) -> int:
    """Re-write every row still holding a PLAIN secret (rows written before
    2026-10-13); the column type encrypts on the write.  Rows counted.

    2026-10-17: the key OWNER (the API) only -- every component ran it at
    start, so several containers could rewrite the same rows at once."""
    from sqlalchemy import text
    from core.crypto import is_key_owner
    if not is_key_owner():
        return 0
    fixed = 0
    engine = db.engine
    for model, cols in _secret_columns():
        table = model.__table__.name
        with engine.connect() as conn:
            rows = conn.execute(text(f"SELECT id, {', '.join(cols)} FROM {table}")).fetchall()
        import json as _json
        todo = []
        for r in rows:
            vals = {c: (_json.loads(v) if isinstance(v, str) else v) for c, v in zip(cols, r[1:])}
            if any(has_plain_secret(v) for v in vals.values() if v is not None):
                todo.append((r[0], vals))
        if not todo:
            continue
        from sqlalchemy.orm.attributes import flag_modified
        with db.get_session() as s:
            for rid, vals in todo:
                obj = s.get(model, rid)
                for c in vals:
                    flag_modified(obj, c)          # same value: the column type encrypts on the write
                fixed += 1
        logger.warning("[secrets] %s: %d row(s) held a plain-text secret -- now encrypted",
                       table, len(todo))
    return fixed
