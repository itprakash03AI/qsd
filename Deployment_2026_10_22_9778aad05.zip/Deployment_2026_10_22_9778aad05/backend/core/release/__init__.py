"""Configuration release -- UAT-tested configuration carried to PROD
(2026-10-17, docs/RELEASE_CONFIG_DESIGN_2026_10_17.html).

ONE model, extending core/feed/governance.py (BRD §15), never a fourth
export/import path:

* ``vocabulary``     -- the leaf declarations every other module imports:
                        the three table KINDS, every ORM table's kind, and
                        the closed vocabulary of releasable object types
                        (models.py's CHECK constraint and governance.py's
                        GOVERNED_OBJECT_TYPES both derive from it -- "a
                        decision made twice is a bug").
* ``contract``       -- ``ReleasableType``: serialize by natural key, list
                        dependencies, compare field by field, apply, verify.
* ``registry``       -- the plugin registry; a type declares itself.
* ``package``        -- the ONE package format (JSON, names not ids, no
                        secrets, version, source environment, checksum).
* ``diff``           -- the three-way field diff (base = last release,
                        ours = package, theirs = PROD now).
* ``engine``         -- export / preview / apply / rollback / verify over
                        the DB seam, one transaction per release.

Nothing here is imported by the run path (feed_engine, queue_worker,
pipeline): a release is a CHANGE, never a run.
"""
