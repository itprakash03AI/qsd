"""The registry of releasable types -- the plugin seam.

A type declares itself by being registered from ``core/release/types/*``
(imported here once).  ``vocabulary.OBJECT_TYPES`` is the closed vocabulary
the database CHECK and the package schema enforce; the guard test fails when
the two disagree, so a type cannot be half-declared.
"""
from __future__ import annotations

import logging
from typing import Iterable, Optional

from core.release.contract import ReleasableType
from core.release.vocabulary import KIND_RELEASE, OBJECT_TYPES, TABLE_KINDS, kind_of, tables_of_kind

logger = logging.getLogger(__name__)


class Registry:
    def __init__(self) -> None:
        self._types: dict[str, ReleasableType] = {}

    def register(self, rtype: ReleasableType) -> ReleasableType:
        if rtype.kind in self._types:
            raise ValueError(f"release type {rtype.kind!r} registered twice")
        if rtype.kind not in OBJECT_TYPES:
            raise ValueError(f"release type {rtype.kind!r} is not in vocabulary.OBJECT_TYPES -- "
                             f"declare it there first (one vocabulary)")
        self._types[rtype.kind] = rtype
        return rtype

    def get(self, kind: str) -> Optional[ReleasableType]:
        return self._types.get(kind)

    def require(self, kind: str) -> ReleasableType:
        t = self._types.get(kind)
        if t is None:
            raise KeyError(f"unknown release object type {kind!r} -- one of {sorted(self._types)}")
        return t

    def kinds(self) -> list[str]:
        """In apply order (vocabulary order)."""
        return [k for k in OBJECT_TYPES if k in self._types]

    def types(self) -> list[ReleasableType]:
        return [self._types[k] for k in self.kinds()]

    def tables_carried(self) -> dict[str, str]:
        """RELEASE table -> the kind that carries it (own or as a child)."""
        out: dict[str, str] = {}
        for t in self._types.values():
            out[t.table] = t.kind
            for c in t.children:
                out[c.model.__table__.name] = f"child of {t.kind}"
            for tb in t.also_carries:
                out[tb] = f"carried by {t.kind}"
        return out

    def release_tables_uncarried(self) -> list[str]:
        """RELEASE tables no registered type carries -- the guard's list.
        (Phases not yet built appear here until their declarations land.)"""
        carried = self.tables_carried()
        return sorted(t for t in tables_of_kind(KIND_RELEASE) if t not in carried)

    def kind_of_table(self, table: str) -> str | None:
        """RELEASE / ENVIRONMENT / RUNTIME, or None for a table the vocabulary
        does not know (the guard's question)."""
        return kind_of(table)

    def describe(self) -> list[dict]:
        return [{
            "kind": t.kind, "table": t.table, "key": list(t.key), "phase": t.phase,
            "refs": {c: {"kind": r.kind, "by": r.by, "environment": r.environment}
                     for c, r in t.refs.items()},
            "children": [{"name": c.name, "table": c.model.__table__.name, "key": list(c.key)}
                         for c in t.children],
            "environment_fields": [{"path": e.path, "mapping": e.mapping} for e in t.env],
            "requires_config": list(t.requires_config),
            "tables": [t.table, *[c.model.__table__.name for c in t.children], *t.also_carries],
            "table_kinds": {tb: self.kind_of_table(tb)
                            for tb in [t.table, *[c.model.__table__.name for c in t.children], *t.also_carries]},
        } for t in self.types()]


REGISTRY = Registry()
_loaded = False


def load() -> Registry:
    """Import every type module once (they register on import)."""
    global _loaded
    if not _loaded:
        from core.release.types import dashboards, feedgen, published, reports  # noqa: F401
        _loaded = True
    return REGISTRY


def kinds_in_order(kinds: Iterable[str]) -> list[str]:
    order = {k: i for i, k in enumerate(OBJECT_TYPES)}
    return sorted(set(kinds), key=lambda k: order.get(k, 999))
