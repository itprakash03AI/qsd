"""The ONE package format: JSON, names not ids, no secrets, a schema version,
the source environment, a checksum over the CANONICAL items.

Canonical = items sorted by (kind order, key), each definition normalized
exactly as ``governed_definition`` does.  The one-file package and the
exploded Git tree (``<kind>/<key>.json``) share the checksum, so a review
in Git and an upload in the UI are provably the same bytes.
"""
from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from typing import Any

from core.release.contract import Item, ReleaseRefusal, normalize
from core.release.vocabulary import OBJECT_TYPES

PACKAGE_SCHEMA_VERSION = 1
_ORDER = {k: i for i, k in enumerate(OBJECT_TYPES)}
_SLUG = re.compile(r"[^A-Za-z0-9._-]+")


def canonical_items(items: list[dict]) -> list[dict]:
    """Sorted, normalized, deterministic key order (json.dumps sorts)."""
    norm = [normalize(dict(i)) for i in items]
    norm.sort(key=lambda i: (_ORDER.get(i.get("kind"), 999), str(i.get("key"))))
    return norm


def checksum(items: list[dict]) -> str:
    payload = json.dumps(canonical_items(items), sort_keys=True, separators=(",", ":"),
                         ensure_ascii=False)
    return "sha256:" + hashlib.sha256(payload.encode("utf-8")).hexdigest()


def build_package(items: list[Item], *, source_environment: str, exported_by: str | None,
                  scope: dict, source_commit: str | None = None,
                  requires_config: list[str] | None = None,
                  exported_at: datetime | None = None,
                  excluded: list[dict] | None = None) -> dict:
    dicts = [i.to_dict() for i in items]
    canon = canonical_items(dicts)
    ts = (exported_at or datetime.now(timezone.utc)).replace(microsecond=0).isoformat()
    kinds = sorted({i["kind"] for i in canon}, key=lambda k: _ORDER.get(k, 999))
    return {
        "schema_version": PACKAGE_SCHEMA_VERSION,
        "package_id": f"rel-{ts.replace('-', '').replace(':', '')[:15]}-{checksum(canon)[7:13]}",
        "source_environment": source_environment,
        "source_commit": source_commit,
        "exported_at": ts,
        "exported_by": exported_by,
        "scope": scope,
        "requires": {"config_keys": sorted(set(requires_config or [])), "object_types": kinds},
        # what the exporter DELIBERATELY left out and why (shown in the target's preview)
        "excluded": [dict(e) for e in (excluded or [])],
        "items": canon,
        "checksum": checksum(canon),
    }


def validate_package(pkg: Any, *, known_kinds: set[str]) -> list[dict]:
    """Shape + checksum + vocabulary.  Raises ReleaseRefusal; returns the
    canonical items.  Secrets are checked by the caller per item (the
    type knows its vocabulary)."""
    if not isinstance(pkg, dict):
        raise ReleaseRefusal("a package is a JSON object")
    sv = pkg.get("schema_version")
    if sv != PACKAGE_SCHEMA_VERSION:
        raise ReleaseRefusal(f"unsupported package schema_version {sv!r} (this build understands "
                             f"{PACKAGE_SCHEMA_VERSION})")
    items = pkg.get("items")
    if not isinstance(items, list) or not items:
        raise ReleaseRefusal("the package carries no items")
    for i in items:
        if not isinstance(i, dict) or not i.get("kind") or i.get("key") in (None, ""):
            raise ReleaseRefusal("every item needs a kind and a key")
        if i["kind"] not in known_kinds:
            raise ReleaseRefusal(f"item {i.get('key')!r}: unknown object type {i['kind']!r} -- this "
                                 f"build knows {sorted(known_kinds)}; deploy the image first",
                                 kind=i["kind"], key=str(i.get("key")))
        if not isinstance(i.get("definition"), dict):
            raise ReleaseRefusal(f"{i['kind']} {i['key']!r}: 'definition' must be an object",
                                 kind=i["kind"], key=str(i["key"]))
    seen = set()
    for i in items:
        k = (i["kind"], str(i["key"]))
        if k in seen:
            raise ReleaseRefusal(f"duplicate object {k[0]}/{k[1]} in one package", kind=k[0], key=k[1])
        seen.add(k)
    canon = canonical_items(items)
    want = pkg.get("checksum")
    have = checksum(canon)
    if want != have:
        raise ReleaseRefusal(f"package checksum does not match its items (declared {want}, "
                             f"computed {have}) -- the file was altered after export")
    return canon


def explode(pkg: dict) -> dict[str, str]:
    """One file per object for a Git review: ``<kind>/<key>.json`` -> text,
    plus ``package.json`` (the envelope without items)."""
    out: dict[str, str] = {}
    for i in canonical_items(pkg["items"]):
        slug = _SLUG.sub("_", str(i["key"])).strip("_") or "object"
        out[f"{i['kind']}/{slug}.json"] = json.dumps(i, indent=1, sort_keys=True, ensure_ascii=False) + "\n"
    env = {k: v for k, v in pkg.items() if k != "items"}
    out["package.json"] = json.dumps(env, indent=1, sort_keys=True, ensure_ascii=False) + "\n"
    return out


def implode(files: dict[str, str]) -> dict:
    """The inverse of explode: the envelope + every ``<kind>/*.json``."""
    env = json.loads(files["package.json"])
    items = [json.loads(text) for path, text in files.items()
             if path != "package.json" and path.endswith(".json")]
    env["items"] = canonical_items(items)
    env["checksum"] = checksum(env["items"])
    return env
