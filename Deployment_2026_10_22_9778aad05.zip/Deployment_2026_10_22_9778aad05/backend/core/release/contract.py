"""The ONE export/import contract every releasable object type implements
(docs/RELEASE_CONFIG_DESIGN_2026_10_17.html §3.1).

A type is a DECLARATION (``DeclaredType``): its ORM model, its natural key,
its references (always resolved to NAMES in a package and back to ids on
apply), its children (rows serialized INSIDE the parent's definition and
matched within it by their own key), its environment fields (values that
differ per environment: never compared, never copied raw -- mapped or kept),
and what is secret.  Export, dependency listing, resolution, apply and
verify come from the declaration; only ``feed`` and ``feed_template`` need
code of their own (core/release/types/feedgen.py).

Secrets, the primary threat: a column whose type is ``SecretJSON`` (the
product's own at-rest decision) is stripped of credential-shaped keys
heuristically; any OTHER credential-shaped key the type neither declared
secret nor declared not-secret REFUSES the export -- unknown is unsafe, and
an export that guessed would be how a password reaches a git repository.
"""
from __future__ import annotations

import copy
import logging
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any, Callable, Optional

from sqlalchemy.orm import Session

from core.feed.pinning import definition_hash
from core.release.vocabulary import KIND_ENVIRONMENT, OBJECT_TYPES

logger = logging.getLogger(__name__)

#: Columns no definition carries: identity the target mints, audit stamps.
AUDIT_COLUMNS = frozenset({"id", "created_at", "updated_at", "created_by", "updated_by"})

#: Reference kinds that are ENVIRONMENT (never carried; resolved in the
#: target by name, through ``release_mappings`` when mapped).
ENV_REF_KINDS = frozenset({"connection"})

#: Field states of the three-way diff (core/release/diff.py) a decision may
#: name.  ``take_release`` / ``keep_prod`` are the two decisions.
DECISION_TAKE = "take_release"
DECISION_KEEP = "keep_prod"


class ReleaseRefusal(ValueError):
    """A refused release operation -- the message says exactly why and
    names the object.  Never a silent skip."""

    def __init__(self, message: str, *, kind: str | None = None, key: str | None = None,
                 path: str | None = None, problems: list | None = None):
        super().__init__(message)
        self.kind, self.key, self.path = kind, key, path
        #: every problem of a scope, answered TOGETHER (an export never stops at the first)
        self.problems = list(problems or [])

    def to_dict(self) -> dict:
        d = {"kind": self.kind, "key": self.key, "path": self.path, "reason": str(self)}
        if self.problems:
            d["problems"] = self.problems
        return d


@dataclass(frozen=True)
class Ref:
    """A column that references another object.

    ``by="id"``: the column holds the referenced row's id; the package
    carries the referenced object's KEY under ``field`` (default: the kind
    name) and the column is dropped.  ``by="key"``: the column already holds
    the key (``calendar_name``); it stays and is only a dependency.
    """
    kind: str                       # an OBJECT_TYPE, or "connection"
    by: str = "id"
    field: Optional[str] = None     # package field name; default = kind
    required: bool = False          # a missing target refuses (else None)

    @property
    def name(self) -> str:
        return self.field or self.kind

    @property
    def environment(self) -> bool:
        return self.kind in ENV_REF_KINDS


@dataclass(frozen=True)
class Env:
    """An environment field: a dotted path inside the definition whose value
    differs per environment (``destination_config.host``).  ``[*]`` walks a
    list.  ``mapping`` is the ``release_mappings.kind`` that translates it."""
    path: str
    mapping: str                    # sftp_host | email | user | path | bucket | url | value


@dataclass
class Child:
    """Rows serialized inside their parent."""
    name: str                       # the field name inside the definition
    model: Any                      # ORM model
    parent_col: str                 # FK column to the parent id
    key: tuple[str, ...]            # within-parent key
    refs: dict[str, Ref] = field(default_factory=dict)
    strip: tuple[str, ...] = ()
    env: tuple[Env, ...] = ()
    order_by: Optional[str] = None


@dataclass
class Item:
    """One object as it travels in a package."""
    kind: str
    key: str
    definition: dict
    environment_fields: dict = field(default_factory=dict)   # path -> {"kind", "value"}
    environment_refs: list = field(default_factory=list)     # [{"kind","name","path"}]
    dependencies: list = field(default_factory=list)         # [[kind, key], ...]
    hash: str = ""
    extra: dict = field(default_factory=dict)                # type-private (members: derived)

    def to_dict(self) -> dict:
        d = {"kind": self.kind, "key": self.key, "hash": self.hash,
             "definition": self.definition,
             "environment_fields": self.environment_fields,
             "environment_refs": self.environment_refs,
             "dependencies": self.dependencies}
        d.update(self.extra)
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "Item":
        known = {"kind", "key", "hash", "definition", "environment_fields",
                 "environment_refs", "dependencies"}
        return cls(kind=d["kind"], key=d["key"], hash=d.get("hash") or "",
                   definition=d.get("definition") or {},
                   environment_fields=d.get("environment_fields") or {},
                   environment_refs=d.get("environment_refs") or [],
                   dependencies=d.get("dependencies") or [],
                   extra={k: v for k, v in d.items() if k not in known})


@dataclass
class Verdict:
    """A verification outcome.  ``unknown`` is its own state (the check
    could not run) and is never "ok"."""
    state: str                      # ok | failed | unknown
    reason: str = ""
    checks: list = field(default_factory=list)

    def to_dict(self) -> dict:
        return {"state": self.state, "reason": self.reason, "checks": self.checks}


# ── normalization (one spelling for the whole platform) ─────────────────

def normalize(value: Any) -> Any:
    """YAML/JSON-stable: datetimes -> ISO, sets -> sorted lists, keys -> str.
    The same rule governance.py applies (it imports this one)."""
    if isinstance(value, dict):
        return {str(k): normalize(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [normalize(v) for v in value]
    if isinstance(value, (set, frozenset)):
        return sorted(normalize(v) for v in value)
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    return value


def item_hash(definition: dict) -> str:
    return definition_hash(normalize(definition))


# ── dotted paths (with [*] over lists) ───────────────────────────────────

def _walk_paths(tree: Any, parts: list[str], prefix: str = ""):
    """Yield (container, key, concrete_path) for every leaf a dotted path
    with ``[*]`` names.  Missing branches yield nothing."""
    if not parts:
        return
    head, rest = parts[0], parts[1:]
    if head == "[*]":
        if isinstance(tree, list):
            for i, elem in enumerate(tree):
                p = f"{prefix}[{i}]"
                if rest:
                    yield from _walk_paths(elem, rest, p)
        return
    if not isinstance(tree, dict) or head not in tree:
        return
    p = f"{prefix}.{head}" if prefix else head
    if rest:
        yield from _walk_paths(tree[head], rest, p)
    else:
        yield tree, head, p


def path_parts(path: str) -> list[str]:
    """``"a.b[*].c"`` -> ``["a", "b", "[*]", "c"]``."""
    out: list[str] = []
    for seg in path.split("."):
        stars = 0
        while seg.endswith("[*]"):
            seg = seg[:-3]
            stars += 1
        if seg:
            out.append(seg)
        out.extend(["[*]"] * stars)
    return out


def pop_env_fields(definition: dict, envs: tuple[Env, ...], prefix: str = "") -> dict:
    """Move every declared environment field OUT of the definition.  Returns
    ``{concrete_path: {"kind": mapping_kind, "value": value}}`` for the
    values that were present and non-empty."""
    out: dict = {}
    for env in envs:
        for container, key, cpath in list(_walk_paths(definition, path_parts(env.path))):
            value = container.pop(key)
            if value in (None, "", [], {}):
                continue
            out[(prefix + "." + cpath) if prefix else cpath] = {"kind": env.mapping, "value": value}
    return out


def set_path(tree: dict, cpath: str, value: Any) -> None:
    """Write ``value`` at a CONCRETE path (``a.b[2].c``)."""
    node: Any = tree
    tokens: list = []
    for seg in cpath.split("."):
        while "[" in seg:
            name, _, rest = seg.partition("[")
            if name:
                tokens.append(name)
            idx, _, seg = rest.partition("]")
            tokens.append(int(idx))
        if seg:
            tokens.append(seg)
    for tok in tokens[:-1]:
        if isinstance(tok, int):
            node = node[tok]
        else:
            node = node.setdefault(tok, {})
    last = tokens[-1]
    node[last] = value


# ── secret handling ───────────────────────────────────────────────────────

def _secret_json_columns(model) -> set[str]:
    from core.secrets_at_rest import SecretJSON
    return {c.name for c in model.__table__.columns if isinstance(c.type, SecretJSON)}


def scrub_secrets(definition: dict, *, secret_columns: set[str], secret_paths: tuple[str, ...],
                  not_secret: tuple[str, ...], kind: str, key: str) -> tuple[dict, list[str]]:
    """Strip declared/at-rest secrets; REFUSE any other credential-shaped key.

    Returns ``(clean, stripped_paths)``.  ``not_secret`` names leaf keys that
    the heuristic flags but are vocabulary (``feed_message_tokens.token``)."""
    from core.feed.governance import find_secret_paths, strip_secrets
    clean = copy.deepcopy(definition)
    stripped: list[str] = []
    for path in secret_paths:
        for container, k, cpath in list(_walk_paths(clean, path_parts(path))):
            container.pop(k)
            stripped.append(cpath)
    for col in secret_columns:
        if isinstance(clean.get(col), (dict, list)):
            clean[col], removed = strip_secrets(clean[col], col)
            stripped.extend(removed)
    allowed = set(not_secret)
    offenders = [p for p in find_secret_paths(clean)
                 if p.split(".")[-1].split("[")[0] not in allowed and p not in allowed]
    if offenders:
        raise ReleaseRefusal(
            f"{kind} {key!r}: credential-shaped key(s) {offenders} are neither declared "
            f"secret (stripped) nor declared vocabulary (kept) -- unknown is unsafe; declare "
            f"them on the type before this object can be exported",
            kind=kind, key=key, path=offenders[0])
    return clean, stripped


# ── the contract ──────────────────────────────────────────────────────────

class ReleasableType:
    """Base of every releasable type.  Subclasses override what the
    declaration cannot express."""

    kind: str = ""
    model: Any = None
    key: tuple[str, ...] = ("name",)
    refs: dict[str, Ref] = {}
    children: list[Child] = []
    env: tuple[Env, ...] = ()
    strip: tuple[str, ...] = ()
    secret_paths: tuple[str, ...] = ()
    not_secret: tuple[str, ...] = ()
    requires_config: tuple[str, ...] = ()
    phase: int = 1
    #: RELEASE tables this type carries in CODE rather than as declared
    #: children (a feed's dependency mappings, keyed by etl_id)
    also_carries: tuple[str, ...] = ()
    #: a filter on which rows are RELEASE objects of this type (feeds: not members)
    row_filter: Optional[Callable[[Any], bool]] = None

    # -- identity --------------------------------------------------------
    @property
    def table(self) -> str:
        return self.model.__table__.name

    def all_env(self) -> tuple:
        """The parent's environment fields plus every child's, as paths
        from the parent (``webhooks[*].url``)."""
        return tuple(self.env) + tuple(Env(f"{c.name}[*].{e.path}", e.mapping)
                                       for c in self.children for e in c.env)

    def row_key(self, row) -> str:
        return "|".join(str(getattr(row, c)) for c in self.key)

    def rows(self, session: Session) -> list:
        q = session.query(self.model)
        rows = q.all()
        if self.row_filter is not None:
            rows = [r for r in rows if self.row_filter(r)]
        return sorted(rows, key=self.row_key)

    def find_row(self, session: Session, key: str):
        parts = key.split("|")
        if len(parts) != len(self.key):
            return None
        q = session.query(self.model)
        for col, val in zip(self.key, parts):
            column = getattr(self.model, col)
            q = q.filter(column == (None if val == "None" else self._coerce(column, val)))
        return q.first()

    @staticmethod
    def _coerce(column, val: str):
        try:
            py = column.type.python_type
        except (NotImplementedError, AttributeError):
            return val
        if py is int:
            return int(val)
        if py is bool:
            return val in ("True", "true", "1")
        return val

    # -- export ----------------------------------------------------------
    def _columns(self, row, *, strip: tuple[str, ...]) -> dict:
        return {c.name: getattr(row, c.name) for c in row.__table__.columns
                if c.name not in AUDIT_COLUMNS and c.name not in strip}

    def export_row(self, session: Session, row, registry) -> Item:
        d = self._columns(row, strip=self.strip)
        deps: list = []
        env_refs: list = []
        self._refs_to_names(session, d, self.refs, registry, deps, env_refs, prefix="")
        for child in self.children:
            d[child.name] = self._export_children(session, row, child, registry, deps, env_refs)
        key = self.row_key(row)
        clean, _stripped = scrub_secrets(
            d, secret_columns=_secret_json_columns(self.model), secret_paths=self.secret_paths,
            not_secret=self.not_secret, kind=self.kind, key=key)
        env_fields = pop_env_fields(clean, self.all_env())
        definition = normalize(clean)
        return Item(kind=self.kind, key=key, definition=definition,
                    environment_fields=normalize(env_fields), environment_refs=env_refs,
                    dependencies=sorted({(k, v) for k, v in deps if v is not None} | set(),
                                        key=lambda kv: (OBJECT_TYPES.index(kv[0]) if kv[0] in OBJECT_TYPES else 99, kv[1])),
                    hash=item_hash(definition))

    def _export_children(self, session, row, child: Child, registry, deps, env_refs) -> list:
        q = session.query(child.model).filter(getattr(child.model, child.parent_col) == row.id)
        rows = q.all()
        out = []
        for i, crow in enumerate(sorted(rows, key=lambda r: tuple(str(getattr(r, c)) for c in child.key))):
            cd = self._columns(crow, strip=child.strip + (child.parent_col,))
            self._refs_to_names(session, cd, child.refs, registry, deps, env_refs,
                                prefix=f"{child.name}[{i}]")
            out.append(cd)
        return out

    def _refs_to_names(self, session, d: dict, refs: dict[str, Ref], registry, deps, env_refs, *, prefix):
        for col, ref in refs.items():
            if col not in d:
                continue
            if ref.by == "key":
                if d[col] not in (None, ""):
                    deps.append((ref.kind, str(d[col])))
                continue
            rid = d.pop(col)
            name = None
            if rid not in (None, 0, ""):
                name = resolve_name(session, ref.kind, rid, registry)
                if name is None:
                    raise ReleaseRefusal(
                        f"{self.kind}: column {col!r} references {ref.kind} id {rid} which does not "
                        f"exist -- a dangling reference cannot be exported (unknown != empty)",
                        kind=self.kind, path=col)
            d[ref.name] = name
            if name is not None:
                if ref.environment:
                    env_refs.append({"kind": ref.kind, "name": name,
                                     "path": f"{prefix}.{ref.name}" if prefix else ref.name})
                else:
                    deps.append((ref.kind, name))

    # -- dependencies ------------------------------------------------------
    def dependencies(self, item: Item) -> list[tuple[str, str]]:
        return [tuple(d) for d in item.dependencies]

    # -- the item as it reads in the TARGET --------------------------------
    def effective(self, item: Item, mapping: "Mapping") -> Item:
        """Environment references (a connection name) translated through the
        target's mapping, so the diff compares what WILL be written with what
        IS there -- never UAT's connection name against PROD's.  The hash is
        the effective definition's; the package itself is never rewritten."""
        out = copy.deepcopy(item)
        for ref in item.environment_refs or []:
            mapped = mapping.lookup(ref.get("kind"), ref.get("name"))
            if mapped is not None and mapped != ref.get("name"):
                try:
                    set_path(out.definition, ref["path"], mapped)
                except (KeyError, IndexError, TypeError):
                    continue
        out.hash = item_hash(out.definition)
        return out

    # -- resolve (target) --------------------------------------------------
    def resolve(self, session: Session, item: Item, mapping: "Mapping", registry,
                in_package: set[tuple[str, str]]) -> dict:
        """Names -> target ids.  Returns ``{"refs": {path: id}, "env": {path: value},
        "missing": [...]}``; a missing ENVIRONMENT ref or an unmapped
        environment field is reported, never guessed."""
        out: dict = {"refs": {}, "env": {}, "missing": []}
        self._resolve_refs(session, item.definition, self.refs, mapping, registry,
                           in_package, out, prefix="")
        for child in self.children:
            for i, cd in enumerate(item.definition.get(child.name) or []):
                self._resolve_refs(session, cd, child.refs, mapping, registry, in_package, out,
                                   prefix=f"{child.name}[{i}]")
        for cpath, ef in (item.environment_fields or {}).items():
            mapped = mapping.lookup(ef.get("kind"), ef.get("value"))
            if mapped is None:
                out["missing"].append({"what": "environment_field", "path": cpath,
                                       "mapping_kind": ef.get("kind"), "value": ef.get("value"),
                                       "reason": f"no release mapping of kind {ef.get('kind')!r} "
                                                 f"for {ef.get('value')!r}"})
            else:
                out["env"][cpath] = mapped
        return out

    def _resolve_refs(self, session, d: dict, refs: dict[str, Ref], mapping, registry,
                      in_package, out: dict, *, prefix: str):
        for col, ref in refs.items():
            if ref.by == "key":
                val = d.get(col)
                if val in (None, "") or (ref.kind, str(val)) in in_package:
                    continue
                rtype = registry.get(ref.kind)
                if rtype is not None and rtype.find_row(session, str(val)) is None:
                    out["missing"].append({"what": "dependency", "kind": ref.kind, "key": str(val),
                                           "path": f"{prefix}.{col}" if prefix else col,
                                           "reason": f"{ref.kind} {val!r} is neither in the package "
                                                     f"nor in the target"})
                continue
            name = d.get(ref.name)
            cpath = f"{prefix}.{ref.name}" if prefix else ref.name
            if name in (None, ""):
                continue
            if ref.environment:
                target_name = mapping.lookup(ref.kind, name) or name
                rid = resolve_id(session, ref.kind, target_name, registry)
                if rid is None:
                    out["missing"].append({"what": "environment_ref", "kind": ref.kind, "name": name,
                                           "mapped_to": target_name, "path": cpath,
                                           "reason": f"{ref.kind} {target_name!r} does not exist in "
                                                     f"the target (map {name!r} to one that does)"})
                else:
                    out["refs"][cpath] = rid
            else:
                rid = resolve_id(session, ref.kind, name, registry)
                if rid is None and (ref.kind, name) not in in_package:
                    out["missing"].append({"what": "dependency", "kind": ref.kind, "key": name,
                                           "path": cpath,
                                           "reason": f"{ref.kind} {name!r} is neither in the package "
                                                     f"nor in the target"})
                elif rid is not None:
                    out["refs"][cpath] = rid

    # -- apply (target, inside the release transaction) ----------------------
    def apply(self, session: Session, item: Item, resolved: dict, existing, *,
              keep_fields: set[str], actor: str | None, registry) -> tuple[int, str]:
        """Create or update the row (+ children).  ``keep_fields`` are the
        top-level definition fields a decision keeps as PROD has them.
        Returns ``(object_id, action)``."""
        definition = copy.deepcopy(item.definition)
        # environment fields come from the mapping: on a NEW object every one of
        # them; on an update only the CHILDREN's (a new child row needs a value;
        # an existing child keeps PROD's -- see _apply_children), the parent's
        # own are kept as PROD has them by _keep_env_paths
        child_names = {c.name for c in self.children}
        for cpath, value in (resolved.get("env") or {}).items():
            top = cpath.split(".")[0].split("[")[0]
            if existing is None or top in child_names:
                try:
                    set_path(definition, cpath, value)
                except (KeyError, IndexError, TypeError):
                    pass
        child_defs = {c.name: definition.pop(c.name, []) for c in self.children}
        columns = self._to_columns(session, definition, self.refs, resolved, registry, prefix="")
        if existing is None:
            if "created_by" in self.model.__table__.columns and actor and not columns.get("created_by"):
                columns["created_by"] = actor           # unless the mapping named the owner
            row = self.model(**columns)
            session.add(row)
            session.flush()
            action = "created"
        else:
            row = existing
            for col, value in columns.items():
                if col in keep_fields or col in self.key:
                    continue
                if hasattr(row, col):
                    # a JSON column holding environment fields: keep PROD's
                    # values at those paths
                    current = getattr(row, col)
                    if isinstance(value, dict) and isinstance(current, dict):
                        value = self._keep_env_paths(col, value, current)
                    setattr(row, col, value)
            if "updated_by" in self.model.__table__.columns and actor:
                row.updated_by = actor
            if "updated_at" in self.model.__table__.columns:
                row.updated_at = datetime.now()
            action = "updated"
        for child in self.children:
            self._apply_children(session, row, child, child_defs.get(child.name) or [],
                                 resolved, registry, existing is not None)
        session.flush()
        return int(row.id), action

    def _keep_env_paths(self, col: str, incoming: dict, current: dict) -> dict:
        merged = copy.deepcopy(incoming)
        for env in self.env:
            parts = path_parts(env.path)
            if parts and parts[0] == col:
                for container, k, cpath in list(_walk_paths(current, parts[1:])):
                    try:
                        set_path(merged, cpath, container[k])
                    except (KeyError, IndexError, TypeError):
                        pass
        return merged

    def _to_columns(self, session, d: dict, refs: dict[str, Ref], resolved: dict, registry, *,
                    prefix: str) -> dict:
        cols = dict(d)
        for col, ref in refs.items():
            if ref.by == "key":
                continue
            name = cols.pop(ref.name, None)
            cpath = f"{prefix}.{ref.name}" if prefix else ref.name
            rid = (resolved.get("refs") or {}).get(cpath)
            if rid is None and name not in (None, ""):
                # landed earlier in this transaction (same package)
                rid = resolve_id(session, ref.kind, name, registry)
                if rid is None and ref.environment:
                    raise ReleaseRefusal(f"{self.kind}: {ref.kind} {name!r} is not in the target",
                                         kind=self.kind, path=cpath)
                if rid is None and name is not None:
                    raise ReleaseRefusal(f"{self.kind}: dependency {ref.kind} {name!r} did not land "
                                         f"before its user", kind=self.kind, path=cpath)
            cols[col] = rid
        return cols

    def _apply_children(self, session, parent_row, child: Child, defs: list, resolved: dict,
                        registry, existed: bool) -> None:
        existing = {tuple(str(getattr(r, c)) for c in child.key): r
                    for r in session.query(child.model).filter(
                        getattr(child.model, child.parent_col) == parent_row.id).all()}
        seen = set()
        for i, cd in enumerate(defs):
            cols = self._to_columns(session, cd, child.refs, resolved, registry,
                                    prefix=f"{child.name}[{i}]")
            cols = self._coerce_columns(child.model, cols)
            ckey = tuple(str(cols.get(c)) for c in child.key)
            seen.add(ckey)
            row = existing.get(ckey)
            if row is None:
                cols[child.parent_col] = parent_row.id
                session.add(child.model(**cols))
            else:
                env_cols = {e.path for e in child.env if "." not in e.path and "[" not in e.path}
                for k, v in cols.items():
                    if hasattr(row, k) and k not in env_cols:       # a child's env column stays PROD's
                        setattr(row, k, v)
        for ckey, row in existing.items():
            if ckey not in seen:
                session.delete(row)
        session.flush()

    @staticmethod
    def _coerce_columns(model, cols: dict) -> dict:
        """ISO strings back to date/datetime for typed columns (the package
        is JSON)."""
        out = dict(cols)
        for c in model.__table__.columns:
            v = out.get(c.name)
            if not isinstance(v, str):
                continue
            try:
                py = c.type.python_type
            except (NotImplementedError, AttributeError):
                continue
            try:
                if py is date:
                    out[c.name] = date.fromisoformat(v)
                elif py is datetime:
                    out[c.name] = datetime.fromisoformat(v)
            except ValueError:
                pass
        return out

    # -- the target's current governed form (theirs) ---------------------------
    def current_item(self, session: Session, key: str, registry) -> Optional[Item]:
        row = self.find_row(session, key)
        return None if row is None else self.export_row(session, row, registry)

    # -- verify --------------------------------------------------------------
    def verify(self, db, session: Session, object_id: int, registry) -> Verdict:
        row = session.query(self.model).filter(self.model.id == object_id).first()
        if row is None:
            return Verdict("failed", f"{self.kind} id {object_id} is not in the target after apply")
        checks = []
        for col, ref in self.refs.items():
            rid = getattr(row, col, None)
            if ref.by == "key":
                val = getattr(row, col, None)
                if val in (None, ""):
                    continue
                rtype = registry.get(ref.kind)
                ok = rtype is not None and rtype.find_row(session, str(val)) is not None
                checks.append({"check": f"{col} -> {ref.kind} {val!r}", "ok": ok})
                continue
            if rid in (None, 0):
                continue
            name = resolve_name(session, ref.kind, rid, registry)
            checks.append({"check": f"{col} -> {ref.kind} id {rid}", "ok": name is not None,
                           "name": name})
        failed = [c for c in checks if not c["ok"]]
        if failed:
            return Verdict("failed", f"{len(failed)} reference(s) do not resolve", checks)
        return Verdict("ok", "", checks)


class DeclaredType(ReleasableType):
    """A type that is nothing but its declaration."""

    def __init__(self, *, kind: str, model, key: tuple[str, ...] = ("name",),
                 refs: Optional[dict[str, Ref]] = None, children: Optional[list[Child]] = None,
                 env: tuple[Env, ...] = (), strip: tuple[str, ...] = (),
                 secret_paths: tuple[str, ...] = (), not_secret: tuple[str, ...] = (),
                 requires_config: tuple[str, ...] = (), phase: int = 1,
                 row_filter: Optional[Callable[[Any], bool]] = None):
        self.kind, self.model, self.key = kind, model, key
        self.refs = dict(refs or {})
        self.children = list(children or [])
        self.env, self.strip = env, strip
        self.secret_paths, self.not_secret = secret_paths, not_secret
        self.requires_config, self.phase = requires_config, phase
        self.row_filter = row_filter


def model_for(table: str):
    """The ORM class of a table (class names vary across the codebase; table
    names are the vocabulary)."""
    from core.db.models import Base
    for mapper in Base.registry.mappers:
        if mapper.local_table.name == table:
            return mapper.class_
    raise KeyError(f"no ORM model for table {table!r}")


# ── name <-> id resolution for references ────────────────────────────────

def resolve_name(session: Session, kind: str, rid: Any, registry) -> Optional[str]:
    """The NAME a package carries for a referenced row id, or None."""
    if kind == "connection":
        from core.db.models import Connection
        row = session.query(Connection).filter(Connection.id == int(rid)).first()
        return None if row is None else row.name
    rtype = registry.get(kind)
    if rtype is None:
        raise ReleaseRefusal(f"reference to unknown object type {kind!r}", kind=kind)
    row = session.query(rtype.model).filter(rtype.model.id == int(rid)).first()
    return None if row is None else rtype.row_key(row)


def resolve_id(session: Session, kind: str, name: str, registry) -> Optional[int]:
    if kind == "connection":
        from core.db.models import Connection
        row = session.query(Connection).filter(Connection.name == str(name)).first()
        return None if row is None else int(row.id)
    rtype = registry.get(kind)
    if rtype is None:
        raise ReleaseRefusal(f"reference to unknown object type {kind!r}", kind=kind)
    row = rtype.find_row(session, str(name))
    return None if row is None else int(row.id)


class Mapping:
    """The target's ``release_mappings`` as a lookup: ``(kind, from) -> to``.
    A mapping whose ``to`` equals ``from`` is an explicit "same here"."""

    def __init__(self, rows: list[dict] | None = None):
        self._m: dict[tuple[str, str], str] = {}
        for r in rows or []:
            self._m[(str(r["kind"]), str(r["from_value"]))] = r["to_value"]

    def lookup(self, kind: str | None, value: Any) -> Optional[Any]:
        if kind is None or value is None:
            return None
        hit = self._m.get((str(kind), str(value)))
        if hit is None:
            return None
        # keep the source type where the value was a number (a port)
        if isinstance(value, int) and not isinstance(value, bool):
            try:
                return int(hit)
            except (TypeError, ValueError):
                return hit
        return hit

    def to_rows(self) -> list[dict]:
        return [{"kind": k, "from_value": f, "to_value": t} for (k, f), t in sorted(self._m.items())]


__all__ = ["AUDIT_COLUMNS", "Child", "DECISION_KEEP", "DECISION_TAKE", "DeclaredType", "Env",
           "ENV_REF_KINDS", "Item", "KIND_ENVIRONMENT", "Mapping", "Ref", "ReleasableType",
           "ReleaseRefusal", "Verdict", "item_hash", "normalize", "pop_env_fields", "resolve_id",
           "resolve_name", "scrub_secrets", "set_path"]
