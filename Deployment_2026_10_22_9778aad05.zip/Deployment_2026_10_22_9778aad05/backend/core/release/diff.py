"""The three-way field diff: base = what the last release deployed here
(``config_deployments.definition``), ours = the package, theirs = the
target as it is NOW.  Per field, one of:

    new          object absent in the target
    unchanged    ours == theirs
    changed      ours != base, theirs == base         -> apply ours
    prod_edited  ours == base, theirs != base         -> keep theirs (visible)
    conflict     ours != base, theirs != base, ours != theirs -> a DECISION
    (no base)    every difference is a conflict unless first_release_overwrites

Secrets never reach this module: both sides are governed forms.
"""
from __future__ import annotations

from typing import Any

from core.release.contract import DECISION_KEEP, DECISION_TAKE

STATES = ("new", "unchanged", "changed", "prod_edited", "conflict", "deleted_in_prod")


def flatten(tree: Any, path: str = "") -> dict[str, Any]:
    """Dotted leaves.  Lists are compared whole under their path (a list of
    children is one field: its order and members ARE its value)."""
    if isinstance(tree, dict):
        out: dict[str, Any] = {}
        for k in sorted(tree):
            child = f"{path}.{k}" if path else str(k)
            out.update(flatten(tree[k], child))
        return out if tree else {path or "<root>": {}}
    return {path or "<root>": tree}


def three_way(base: dict | None, ours: dict, theirs: dict | None, *,
              first_release_overwrites: bool = False) -> dict:
    """Returns ``{"state": object_state, "fields": [{path, state, base, ours, theirs}]}``."""
    if theirs is None:
        fields = [{"path": p, "state": "new", "base": None, "ours": v, "theirs": None}
                  for p, v in flatten(ours).items()]
        return {"state": "new", "fields": fields, "conflicts": 0}
    fo, ft = flatten(ours), flatten(theirs)
    fb = flatten(base) if base is not None else None
    fields = []
    for p in sorted(set(fo) | set(ft) | set(fb or {})):
        o, t = fo.get(p, _MISSING), ft.get(p, _MISSING)
        b = fb.get(p, _MISSING) if fb is not None else _MISSING
        if o == t:
            state = "unchanged"
        elif fb is None:
            state = "changed" if first_release_overwrites else "conflict"
        elif t == b:
            state = "changed"
        elif o == b:
            state = "prod_edited"
        else:
            state = "conflict"
        fields.append({"path": p, "state": state, "base": _show(b), "ours": _show(o),
                       "theirs": _show(t)})
    conflicts = sum(1 for f in fields if f["state"] == "conflict")
    if conflicts:
        state = "conflict"
    elif any(f["state"] == "changed" for f in fields):
        state = "changed"
    elif any(f["state"] == "prod_edited" for f in fields):
        state = "prod_edited"
    else:
        state = "unchanged"
    return {"state": state, "fields": fields, "conflicts": conflicts}


class _Missing:
    def __repr__(self):
        return "<absent>"


_MISSING = _Missing()


def _show(v):
    return None if v is _MISSING else v


def keep_fields(diff: dict, decisions: dict[str, str]) -> set[str]:
    """The TOP-LEVEL fields the apply must leave as PROD has them: every
    ``prod_edited`` field, and every conflict decided ``keep_prod``.  A
    conflict without a decision is the caller's refusal (``undecided``)."""
    keep: set[str] = set()
    for f in diff.get("fields") or []:
        top = f["path"].split(".")[0].split("[")[0]
        if f["state"] == "prod_edited":
            keep.add(top)
        elif f["state"] == "conflict":
            d = decisions.get(f["path"]) or decisions.get(top)
            if d == DECISION_KEEP:
                keep.add(top)
            elif d != DECISION_TAKE:
                keep.add(top)   # undecided: never overwrite; the caller refuses the apply
    return keep


def undecided(diff: dict, decisions: dict[str, str]) -> list[str]:
    out = []
    for f in diff.get("fields") or []:
        if f["state"] != "conflict":
            continue
        top = f["path"].split(".")[0].split("[")[0]
        if (decisions.get(f["path"]) or decisions.get(top)) not in (DECISION_KEEP, DECISION_TAKE):
            out.append(f["path"])
    return out
