"""Releasable type declarations, one module per area.  Importing a module
registers its types (core/release/registry.load)."""
