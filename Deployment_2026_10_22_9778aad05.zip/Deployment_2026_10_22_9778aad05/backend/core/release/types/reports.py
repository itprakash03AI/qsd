"""Datasets, business reports and the query layer as releasable types
(phase 2, docs/RELEASE_CONFIG_DESIGN_2026_10_17.html §6 step 6).

What the declaration alone cannot say and this module does:

* A dataset's children reference EACH OTHER by id (a column's class, a
  hierarchy level's column, an aggregation's measure column).  In the
  package every such id is the referenced child's own key (class name,
  column physical_name); on apply the target's ids are looked up after the
  children land, in dependency order.
* A business report references dataset COLUMNS by id in a dozen JSON homes
  (column_ids, filter_specs, order_by, section_definitions,
  running_calculations, slicer_column_ids, merged_dataset_column_ids,
  layout_config.pivot_config / chart_config / metric_ids, and its
  parameters' lov / cascade columns).  Across environments the ids differ,
  so a report copied by id would point at the WRONG columns silently -- the
  worst outcome of this feature after a leaked secret.  Every id travels as
  the column's physical_name (a condition's / hierarchy's / metric's name)
  and is resolved against the TARGET dataset on apply; a name the target
  dataset lacks refuses the apply and names it.
* Rows whose NAME is not unique (saved queries) carry a ``release_key``,
  minted deterministically on first export, written back to the source and
  stored in the target.
"""
from __future__ import annotations

import copy
import hashlib
import logging
import re
from typing import Any, Optional

from core.release.contract import (
    Child, DeclaredType, Env, Item, Ref, ReleasableType, ReleaseRefusal, Verdict, item_hash,
    model_for, normalize, pop_env_fields, resolve_id, resolve_name, scrub_secrets, set_path,
)
from core.release.registry import REGISTRY

logger = logging.getLogger(__name__)

BusinessDataset = model_for("business_datasets")
DatasetClass = model_for("dataset_classes")
DatasetColumn = model_for("dataset_columns")
DatasetRelationship = model_for("dataset_relationships")
DrillHierarchy = model_for("drill_hierarchies")
CalculatedMetric = model_for("calculated_metrics")
PreDefinedCondition = model_for("predefined_conditions")
AggregationAwareness = model_for("aggregation_awareness")
MergedDimension = model_for("merged_dimensions")
BusinessReport = model_for("business_reports")
ReportParameter = model_for("report_parameters")
ReportPDFConfig = model_for("report_pdf_configs")
ReportSlo = model_for("report_slos")
ReportDependencyMapping = model_for("report_dependency_mappings")
ReportReadinessSubject = model_for("report_readiness_subjects")
ConditionalFormatRule = model_for("conditional_format_rules")
RLSPolicy = model_for("rls_policies")
AlertRule = model_for("alert_rules")
ReportFolder = model_for("report_folders")
ReportFolderAssignment = model_for("report_folder_assignments")
ReportTag = model_for("report_tags")
ReportTagAssignment = model_for("report_tag_assignments")
SavedQuery = model_for("saved_queries")
SqlSavedQuery = model_for("sql_saved_queries")
LogicalTable = model_for("logical_tables")
LogicalTableBinding = model_for("logical_table_bindings")
FederationView = model_for("federation_views")
MaterializedView = model_for("materialized_views")
RestQueryDef = model_for("rest_query_defs")
TableDescription = model_for("table_descriptions")

#: (model, id, key) minted during an export; the engine persists them in a
#: WRITE session after the closure (export runs read-only).
MINTED_KEYS: list[tuple[Any, int, str]] = []
_SLUG = re.compile(r"[^A-Za-z0-9_-]+")


def mint_release_key(name: str, row_id: int) -> str:
    base = _SLUG.sub("_", str(name or "object")).strip("_")[:40] or "object"
    # content addressing (an identity suffix, not a gate): SHA-256 like every other hash here
    return f"{base}-{hashlib.sha256(f'{row_id}:{name}'.encode('utf-8')).hexdigest()[:6]}"


class ReleaseKeyType(DeclaredType):
    """A type keyed by ``release_key`` (minted on first export)."""

    def row_key(self, row) -> str:
        if not getattr(row, "release_key", None):
            key = mint_release_key(getattr(row, "name", ""), int(row.id))
            row.release_key = key
            MINTED_KEYS.append((self.model, int(row.id), key))
        return str(row.release_key)

    def find_row(self, session, key: str):
        row = session.query(self.model).filter(self.model.release_key == str(key)).first()
        if row is not None:
            return row
        # a key minted in THIS export and not yet flushed (read-only session):
        # the mint is deterministic from (id, name), so the row is still found
        for cand in session.query(self.model).filter(self.model.release_key.is_(None)).all():
            if mint_release_key(getattr(cand, "name", ""), int(cand.id)) == str(key):
                return cand
        return None


# ── simple declarations ───────────────────────────────────────────────────

REGISTRY.register(DeclaredType(kind="report_tag", model=ReportTag, key=("name",), phase=2,
                               env=(Env("created_by", "user"),)))

REGISTRY.register(DeclaredType(
    kind="logical_table", model=LogicalTable, key=("logical_name",), phase=2,
    children=[Child("bindings", LogicalTableBinding, "logical_table_id", key=("connection",),
                    refs={"connection_id": Ref("connection")}, env=())]))

REGISTRY.register(DeclaredType(
    kind="federation_view", model=FederationView, key=("name",), phase=2,
    refs={"primary_conn_id": Ref("connection", field="primary_connection"),
          "secondary_conn_id": Ref("connection", field="secondary_connection")},
    strip=("storage_path", "status", "last_materialized", "last_mat_duration", "row_count",
           "column_count", "file_size_bytes", "last_error")))

REGISTRY.register(DeclaredType(
    kind="materialized_view", model=MaterializedView, key=("name",), phase=2,
    refs={"connection_id": Ref("connection")},
    strip=("status", "last_refresh_at", "last_refresh_duration", "row_count", "file_count",
           "size_bytes", "last_error", "apscheduler_job_id", "next_refresh_at", "workspace_id")))

REGISTRY.register(ReleaseKeyType(
    kind="sql_saved_query", model=SqlSavedQuery, key=("release_key",), phase=2,
    refs={"primary_connection_id": Ref("connection", field="primary_connection"),
          "secondary_connection_id": Ref("connection", field="secondary_connection")},
    strip=("execution_count", "last_executed_at", "workspace_id")))


class SavedQueryType(ReleaseKeyType):
    """``query_config`` holds the connection id INSIDE the JSON."""

    def __init__(self):
        super().__init__(kind="saved_query", model=SavedQuery, key=("release_key",), phase=2,
                         strip=("execution_count", "last_executed_at", "is_favorite", "workspace_id"))

    def export_row(self, session, row, registry) -> Item:
        item = super().export_row(session, row, registry)
        qc = item.definition.get("query_config") or {}
        for col, field in (("connection_id", "connection"), ("secondary_connection_id", "secondary_connection")):
            cid = qc.pop(col, None) if isinstance(qc, dict) else None
            if cid not in (None, 0, ""):
                name = resolve_name(session, "connection", int(cid), registry)
                if name is None:
                    raise ReleaseRefusal(f"saved_query {item.key!r}: query_config.{col} {cid} does not exist",
                                         kind=self.kind, key=item.key)
                qc[field] = name
                item.environment_refs.append({"kind": "connection", "name": name, "path": f"query_config.{field}"})
        item.hash = item_hash(item.definition)
        return item

    def resolve(self, session, item, mapping, registry, in_package) -> dict:
        out = super().resolve(session, item, mapping, registry, in_package)
        qc = item.definition.get("query_config") or {}
        for field in ("connection", "secondary_connection"):
            name = qc.get(field) if isinstance(qc, dict) else None
            if name:
                target = mapping.lookup("connection", name) or name
                rid = resolve_id(session, "connection", target, registry)
                if rid is None:
                    out["missing"].append({"what": "environment_ref", "kind": "connection", "name": name,
                                           "mapped_to": target, "path": f"query_config.{field}",
                                           "reason": f"connection {target!r} does not exist in the target"})
                else:
                    out["refs"][f"query_config.{field}"] = rid
        return out

    def apply(self, session, item, resolved, existing, *, keep_fields, actor, registry):
        item = copy.deepcopy(item)
        qc = item.definition.get("query_config") or {}
        for col, field in (("connection_id", "connection"), ("secondary_connection_id", "secondary_connection")):
            name = qc.pop(field, None) if isinstance(qc, dict) else None
            if name:
                rid = (resolved.get("refs") or {}).get(f"query_config.{field}") or resolve_id(session, "connection", name, registry)
                if rid is None:
                    raise ReleaseRefusal(f"saved_query {item.key!r}: connection {name!r} is not in the target")
                qc[col] = rid
        return super().apply(session, item, resolved, existing, keep_fields=keep_fields, actor=actor, registry=registry)


REGISTRY.register(SavedQueryType())


class RestQueryDefType(DeclaredType):
    """Key: connection NAME + name (the row is scoped to its connection)."""

    def __init__(self):
        super().__init__(kind="rest_query_def", model=RestQueryDef, key=("connection", "name"), phase=2,
                         refs={"connection_id": Ref("connection")})

    def row_key(self, row) -> str:
        from sqlalchemy.orm import object_session
        name = resolve_name(object_session(row), "connection", int(row.connection_id), REGISTRY)
        if name is None:
            raise ReleaseRefusal(f"rest_query_def {row.name!r}: connection id {row.connection_id} does not exist")
        return f"{name}|{row.name}"

    def find_row(self, session, key: str):
        cname, _, name = key.partition("|")
        cid = resolve_id(session, "connection", cname, REGISTRY)
        if cid is None:
            return None
        return session.query(RestQueryDef).filter(RestQueryDef.connection_id == cid,
                                                  RestQueryDef.name == name).first()


REGISTRY.register(RestQueryDefType())


class TableDescriptionType(DeclaredType):
    def __init__(self):
        super().__init__(kind="table_description", model=TableDescription, key=("connection", "table_name"),
                         phase=2, refs={"connection_id": Ref("connection")},
                         strip=("preview_count", "last_queried_at"))

    def row_key(self, row) -> str:
        from sqlalchemy.orm import object_session
        name = resolve_name(object_session(row), "connection", int(row.connection_id), REGISTRY)
        if name is None:
            raise ReleaseRefusal(f"table_description {row.table_name!r}: connection id {row.connection_id} does not exist")
        return f"{name}|{row.table_name}"

    def find_row(self, session, key: str):
        cname, _, tname = key.partition("|")
        cid = resolve_id(session, "connection", cname, REGISTRY)
        if cid is None:
            return None
        return session.query(TableDescription).filter(TableDescription.connection_id == cid,
                                                      TableDescription.table_name == tname).first()


REGISTRY.register(TableDescriptionType())


class ReportFolderType(DeclaredType):
    """Key: the path of names (``Finance/Month end``).  Two folders with the
    same name under the same parent cannot be told apart by name: refused."""

    def __init__(self):
        super().__init__(kind="report_folder", model=ReportFolder, key=("path",), phase=2,
                         strip=("parent_id",), env=(Env("created_by", "user"),))

    def _path(self, session, row) -> str:
        parts, seen = [], set()
        cur = row
        while cur is not None:
            if cur.id in seen:
                raise ReleaseRefusal(f"report_folder {row.name!r}: folder cycle", kind=self.kind)
            seen.add(cur.id)
            parts.append(str(cur.name))
            cur = session.query(ReportFolder).filter(ReportFolder.id == cur.parent_id).first() if cur.parent_id else None
        return "/".join(reversed(parts))

    def row_key(self, row) -> str:
        from sqlalchemy.orm import object_session
        session = object_session(row)
        path = self._path(session, row)
        twins = [r for r in session.query(ReportFolder).filter(ReportFolder.name == row.name,
                                                               ReportFolder.parent_id == row.parent_id).all()]
        if len(twins) > 1:
            raise ReleaseRefusal(f"report_folder {path!r}: {len(twins)} folders share this name under the same "
                                 f"parent -- rename one; a release cannot tell them apart", kind=self.kind, key=path)
        return path

    def find_row(self, session, key: str):
        parent_id = None
        row = None
        for name in key.split("/"):
            q = session.query(ReportFolder).filter(ReportFolder.name == name)
            q = q.filter(ReportFolder.parent_id.is_(None)) if parent_id is None else q.filter(ReportFolder.parent_id == parent_id)
            row = q.first()
            if row is None:
                return None
            parent_id = row.id
        return row

    def export_row(self, session, row, registry) -> Item:
        item = super().export_row(session, row, registry)
        parent = item.key.rsplit("/", 1)[0] if "/" in item.key else None
        item.definition["parent"] = parent
        if parent:
            item.dependencies = sorted(set(map(tuple, item.dependencies)) | {("report_folder", parent)})
        item.hash = item_hash(item.definition)
        return item

    def resolve(self, session, item, mapping, registry, in_package) -> dict:
        out = super().resolve(session, item, mapping, registry, in_package)
        parent = item.definition.get("parent")
        if parent and ("report_folder", parent) not in in_package and self.find_row(session, parent) is None:
            out["missing"].append({"what": "dependency", "kind": "report_folder", "key": parent, "path": "parent",
                                   "reason": f"report_folder {parent!r} is neither in the package nor in the target"})
        return out

    def apply(self, session, item, resolved, existing, *, keep_fields, actor, registry):
        item = copy.deepcopy(item)
        parent = item.definition.pop("parent", None)
        pid = None
        if parent:
            prow = self.find_row(session, parent)
            if prow is None:
                raise ReleaseRefusal(f"report_folder {item.key!r}: parent {parent!r} is not in the target")
            pid = prow.id
        oid, action = super().apply(session, item, resolved, existing, keep_fields=keep_fields, actor=actor,
                                    registry=registry)
        row = session.query(ReportFolder).filter(ReportFolder.id == oid).first()
        row.parent_id = pid
        session.flush()
        return oid, action


REGISTRY.register(ReportFolderType())


# ── datasets ─────────────────────────────────────────────────────────────

def column_names(session, dataset_id: int) -> dict[int, str]:
    return {int(c.id): str(c.physical_name) for c in
            session.query(DatasetColumn).filter(DatasetColumn.dataset_id == int(dataset_id)).all()}


def column_ids(session, dataset_id: int) -> dict[str, int]:
    return {v: k for k, v in column_names(session, dataset_id).items()}


def _names_of(session, model, dataset_id: int, attr: str = "name") -> dict[int, str]:
    return {int(r.id): str(getattr(r, attr)) for r in
            session.query(model).filter(model.dataset_id == int(dataset_id)).all()}


class DatasetType(ReleasableType):
    kind = "dataset"
    model = BusinessDataset
    key = ("name",)
    phase = 2
    env = (Env("owner", "user"),)
    strip = ("is_certified", "certified_by", "certified_at")      # certification is a PROD act
    also_carries = ("dataset_classes", "dataset_columns", "dataset_relationships", "drill_hierarchies",
                    "calculated_metrics", "predefined_conditions", "aggregation_awareness", "merged_dimensions")

    def export_row(self, session, row, registry) -> Item:
        d = self._columns(row, strip=self.strip)
        deps: list = []
        env_refs: list = []
        # connections: a list of ids + one per source table
        conns = []
        for cid in d.pop("connection_ids", None) or []:
            name = resolve_name(session, "connection", int(cid), registry)
            if name is None:
                raise ReleaseRefusal(f"dataset {row.name!r}: connection id {cid} does not exist", kind=self.kind)
            conns.append(name)
            env_refs.append({"kind": "connection", "name": name, "path": f"connections[{len(conns) - 1}]"})
        d["connections"] = conns
        tables = []
        for i, t in enumerate(d.pop("source_tables", None) or []):
            t = dict(t)
            cid = t.pop("connection_id", None)
            if cid not in (None, 0, ""):
                name = resolve_name(session, "connection", int(cid), registry)
                if name is None:
                    raise ReleaseRefusal(f"dataset {row.name!r}: source table connection id {cid} does not exist")
                t["connection"] = name
                env_refs.append({"kind": "connection", "name": name, "path": f"source_tables[{i}].connection"})
            tables.append(t)
        d["source_tables"] = tables
        og = d.pop("owner_group_id", None)
        d["owner_group"] = None
        if og:
            d["owner_group"] = resolve_name(session, "user_group", int(og), registry)
            if d["owner_group"] is None:
                raise ReleaseRefusal(f"dataset {row.name!r}: owner group id {og} does not exist")
            deps.append(("user_group", d["owner_group"]))
        ws = d.pop("workspace_id", None) if "workspace_id" in d else None
        if ws:
            raise ReleaseRefusal(f"dataset {row.name!r} belongs to workspace id {ws}; workspaces are a later phase",
                                 kind=self.kind, key=str(row.name))
        cols = column_names(session, row.id)
        classes = _names_of(session, DatasetClass, row.id)
        d["classes"] = [self._columns(c, strip=("dataset_id",)) for c in
                        sorted(session.query(DatasetClass).filter(DatasetClass.dataset_id == row.id).all(), key=lambda c: c.name)]
        out_cols = []
        for c in sorted(session.query(DatasetColumn).filter(DatasetColumn.dataset_id == row.id).all(),
                        key=lambda c: c.physical_name):
            cd = self._columns(c, strip=("dataset_id",))
            cls = cd.pop("class_id", None)
            cd["class"] = classes.get(int(cls)) if cls else None
            out_cols.append(cd)
        d["columns"] = out_cols
        d["relationships"] = [self._columns(r, strip=("dataset_id",)) for r in
                              sorted(session.query(DatasetRelationship).filter(DatasetRelationship.dataset_id == row.id).all(),
                                     key=lambda r: (r.left_table, r.right_table))]
        hier = []
        for h in sorted(session.query(DrillHierarchy).filter(DrillHierarchy.dataset_id == row.id).all(), key=lambda h: h.name):
            hd = self._columns(h, strip=("dataset_id",))
            levels = []
            for lv in hd.get("levels") or []:
                lv = dict(lv)
                cid = lv.pop("column_id", None)
                if cid is not None:
                    if int(cid) not in cols:
                        raise ReleaseRefusal(f"dataset {row.name!r}: hierarchy {h.name!r} names column id {cid} which does not exist")
                    lv["column"] = cols[int(cid)]
                levels.append(lv)
            hd["levels"] = levels
            hier.append(hd)
        d["hierarchies"] = hier
        d["metrics"] = [self._columns(m, strip=("dataset_id",)) for m in
                        sorted(session.query(CalculatedMetric).filter(CalculatedMetric.dataset_id == row.id).all(), key=lambda m: m.name)]
        d["conditions"] = [self._columns(c, strip=("dataset_id",)) for c in
                           sorted(session.query(PreDefinedCondition).filter(PreDefinedCondition.dataset_id == row.id).all(), key=lambda c: c.name)]
        aggs = []
        for a in session.query(AggregationAwareness).filter(AggregationAwareness.dataset_id == row.id).all():
            ad = self._columns(a, strip=("dataset_id",))
            mc = ad.pop("measure_col_id", None)
            if mc is None or int(mc) not in cols:
                raise ReleaseRefusal(f"dataset {row.name!r}: aggregation awareness names column id {mc} which does not exist")
            ad["measure_column"] = cols[int(mc)]
            cid = ad.pop("connection_id", None)
            ad["connection"] = resolve_name(session, "connection", int(cid), registry) if cid else None
            if ad["connection"]:
                env_refs.append({"kind": "connection", "name": ad["connection"], "path": f"aggregations[{len(aggs)}].connection"})
            aggs.append(ad)
        d["aggregations"] = sorted(aggs, key=lambda a: (a["measure_column"], a["agg_table"]))
        merged = []
        for m in session.query(MergedDimension).filter(MergedDimension.primary_dataset_id == row.id).all():
            md = self._columns(m, strip=("primary_dataset_id",))
            sid = md.pop("secondary_dataset_id", None)
            sname = resolve_name(session, "dataset", int(sid), registry) if sid else None
            if sname is None:
                raise ReleaseRefusal(f"dataset {row.name!r}: merged dimension {m.name!r} names dataset id {sid} which does not exist")
            md["secondary_dataset"] = sname
            deps.append(("dataset", sname))
            merged.append(md)
        d["merged_dimensions"] = sorted(merged, key=lambda m: (m["secondary_dataset"], m["name"]))
        clean, _ = scrub_secrets(d, secret_columns=set(), secret_paths=(), not_secret=(), kind=self.kind, key=str(row.name))
        env_fields = pop_env_fields(clean, self.env)
        definition = normalize(clean)
        return Item(kind=self.kind, key=str(row.name), definition=definition, environment_fields=normalize(env_fields),
                    environment_refs=env_refs, dependencies=sorted({(k, v) for k, v in deps}), hash=item_hash(definition))

    def resolve(self, session, item, mapping, registry, in_package) -> dict:
        out: dict = {"refs": {}, "env": {}, "missing": []}
        d = item.definition
        for i, name in enumerate(d.get("connections") or []):
            self._resolve_conn(session, name, f"connections[{i}]", mapping, registry, out)
        for i, t in enumerate(d.get("source_tables") or []):
            if t.get("connection"):
                self._resolve_conn(session, t["connection"], f"source_tables[{i}].connection", mapping, registry, out)
        for i, a in enumerate(d.get("aggregations") or []):
            if a.get("connection"):
                self._resolve_conn(session, a["connection"], f"aggregations[{i}].connection", mapping, registry, out)
        og = d.get("owner_group")
        if og and ("user_group", og) not in in_package and resolve_id(session, "user_group", og, registry) is None:
            out["missing"].append({"what": "dependency", "kind": "user_group", "key": og, "path": "owner_group",
                                   "reason": f"user_group {og!r} is neither in the package nor in the target"})
        for m in d.get("merged_dimensions") or []:
            s = m.get("secondary_dataset")
            if s and ("dataset", s) not in in_package and self.find_row(session, s) is None:
                out["missing"].append({"what": "dependency", "kind": "dataset", "key": s, "path": "merged_dimensions",
                                       "reason": f"dataset {s!r} is neither in the package nor in the target"})
        for cpath, ef in (item.environment_fields or {}).items():
            mapped = mapping.lookup(ef.get("kind"), ef.get("value"))
            if mapped is None:
                out["missing"].append({"what": "environment_field", "path": cpath, "mapping_kind": ef.get("kind"),
                                       "value": ef.get("value"), "reason": f"no release mapping of kind {ef.get('kind')!r} for {ef.get('value')!r}"})
            else:
                out["env"][cpath] = mapped
        return out

    @staticmethod
    def _resolve_conn(session, name, cpath, mapping, registry, out):
        target = mapping.lookup("connection", name) or name
        rid = resolve_id(session, "connection", target, registry)
        if rid is None:
            out["missing"].append({"what": "environment_ref", "kind": "connection", "name": name, "mapped_to": target,
                                   "path": cpath, "reason": f"connection {target!r} does not exist in the target (map {name!r} to one that does)"})
        else:
            out["refs"][cpath] = rid

    def _conn_id(self, session, name, cpath, resolved, registry) -> int:
        rid = (resolved.get("refs") or {}).get(cpath) or resolve_id(session, "connection", name, registry)
        if rid is None:
            raise ReleaseRefusal(f"dataset: connection {name!r} is not in the target", kind=self.kind, path=cpath)
        return int(rid)

    def apply(self, session, item, resolved, existing, *, keep_fields, actor, registry):
        d = copy.deepcopy(item.definition)
        children = {k: d.pop(k, []) for k in ("classes", "columns", "relationships", "hierarchies", "metrics",
                                              "conditions", "aggregations", "merged_dimensions")}
        cols = dict(d)
        cols["connection_ids"] = [self._conn_id(session, n, f"connections[{i}]", resolved, registry)
                                  for i, n in enumerate(cols.pop("connections", None) or [])]
        tables = []
        for i, t in enumerate(cols.pop("source_tables", None) or []):
            t = dict(t)
            name = t.pop("connection", None)
            if name:
                t["connection_id"] = self._conn_id(session, name, f"source_tables[{i}].connection", resolved, registry)
            tables.append(t)
        cols["source_tables"] = tables
        og = cols.pop("owner_group", None)
        cols["owner_group_id"] = resolve_id(session, "user_group", og, registry) if og else None
        if og and cols["owner_group_id"] is None:
            raise ReleaseRefusal(f"dataset {item.key!r}: user_group {og!r} is not in the target")
        if existing is None:
            for cpath, value in (resolved.get("env") or {}).items():
                set_path(cols, cpath, value)
            row = BusinessDataset(**cols)
            session.add(row)
            session.flush()
            action = "created"
        else:
            row = existing
            for col, value in cols.items():
                if col in keep_fields or col == "name" or col == "owner":
                    continue
                if hasattr(row, col):
                    setattr(row, col, value)
            action = "updated"
        did = int(row.id)
        # children in dependency order; each matched by its own key
        self._sync(session, DatasetClass, did, children["classes"], key=("name",))
        classes = {v: k for k, v in _names_of(session, DatasetClass, did).items()}
        col_defs = []
        for c in children["columns"]:
            c = dict(c)
            cls = c.pop("class", None)
            c["class_id"] = classes.get(cls) if cls else None
            if cls and c["class_id"] is None:
                raise ReleaseRefusal(f"dataset {item.key!r}: column {c.get('physical_name')!r} names class {cls!r} which did not land")
            col_defs.append(c)
        self._sync(session, DatasetColumn, did, col_defs, key=("physical_name",))
        cids = column_ids(session, did)
        self._sync(session, DatasetRelationship, did, children["relationships"], key=("left_table", "right_table"))
        hier = []
        for h in children["hierarchies"]:
            h = dict(h)
            levels = []
            for lv in h.get("levels") or []:
                lv = dict(lv)
                name = lv.pop("column", None)
                if name is not None:
                    if name not in cids:
                        raise ReleaseRefusal(f"dataset {item.key!r}: hierarchy {h.get('name')!r} names column {name!r} which the dataset lacks")
                    lv["column_id"] = cids[name]
                levels.append(lv)
            h["levels"] = levels
            hier.append(h)
        self._sync(session, DrillHierarchy, did, hier, key=("name",))
        self._sync(session, CalculatedMetric, did, children["metrics"], key=("name",))
        self._sync(session, PreDefinedCondition, did, children["conditions"], key=("name",))
        aggs = []
        for i, a in enumerate(children["aggregations"]):
            a = dict(a)
            mc = a.pop("measure_column", None)
            if mc not in cids:
                raise ReleaseRefusal(f"dataset {item.key!r}: aggregation names column {mc!r} which the dataset lacks")
            a["measure_col_id"] = cids[mc]
            cn = a.pop("connection", None)
            a["connection_id"] = self._conn_id(session, cn, f"aggregations[{i}].connection", resolved, registry) if cn else None
            aggs.append(a)
        self._sync(session, AggregationAwareness, did, aggs, key=("measure_col_id", "agg_table"))
        merged = []
        for m in children["merged_dimensions"]:
            m = dict(m)
            sname = m.pop("secondary_dataset", None)
            sid = resolve_id(session, "dataset", sname, registry) if sname else None
            if sid is None:
                raise ReleaseRefusal(f"dataset {item.key!r}: merged dimension {m.get('name')!r} names dataset {sname!r} which is not in the target")
            m["secondary_dataset_id"] = sid
            merged.append(m)
        self._sync(session, MergedDimension, did, merged, key=("secondary_dataset_id", "name"), parent_col="primary_dataset_id")
        session.flush()
        return did, action

    def _sync(self, session, model, dataset_id: int, defs: list[dict], *, key: tuple[str, ...],
              parent_col: str = "dataset_id") -> None:
        existing = {tuple(str(getattr(r, k)) for k in key): r
                    for r in session.query(model).filter(getattr(model, parent_col) == dataset_id).all()}
        seen = set()
        for d in defs:
            cols = self._coerce_columns(model, {k: v for k, v in d.items() if k != "id"})
            ck = tuple(str(cols.get(k)) for k in key)
            seen.add(ck)
            row = existing.get(ck)
            if row is None:
                cols[parent_col] = dataset_id
                session.add(model(**cols))
            else:
                for k, v in cols.items():
                    if hasattr(row, k):
                        setattr(row, k, v)
        for ck, row in existing.items():
            if ck not in seen:
                session.delete(row)
        session.flush()

    def verify(self, db, session, object_id, registry) -> Verdict:
        row = session.query(BusinessDataset).filter(BusinessDataset.id == object_id).first()
        if row is None:
            return Verdict("failed", f"dataset id {object_id} is not in the target after apply")
        from core.db.models import Connection
        checks = []
        for cid in row.connection_ids or []:
            c = session.query(Connection).filter(Connection.id == int(cid)).first()
            checks.append({"check": f"connection {cid}", "ok": bool(c and c.is_active), "name": c.name if c else None})
        n = session.query(DatasetColumn).filter(DatasetColumn.dataset_id == row.id).count()
        checks.append({"check": f"{n} column(s) present", "ok": n > 0})
        failed = [c for c in checks if c["ok"] is False]
        return Verdict("failed" if failed else "ok", "; ".join(c["check"] for c in failed), checks)


REGISTRY.register(DatasetType())


# ── business reports: column ids travel as column NAMES ────────────────────

#: top-level JSON homes of column ids in a business_reports row
_REPORT_COL_LIST = ("column_ids", "slicer_column_ids")
_REPORT_COL_IN_LIST = (("filter_specs", "column_id"), ("order_by", "column_id"),
                       ("section_definitions", "break_column_id"),
                       ("running_calculations", "measure_col_id"), ("running_calculations", "partition_col_id"))
_REPORT_COL_LISTS_IN_LIST = (("section_definitions", "subtotal_measure_ids"),)
_LAYOUT_COLS = (("pivot_config", "row_field_ids"), ("pivot_config", "col_field_ids"),
                ("chart_config", "measure_col_ids"), ("chart_config", "line_measure_col_ids"))
_LAYOUT_COL = (("chart_config", "dimension_col_id"), ("chart_config", "split_col_id"),
               ("chart_config", "kpi_comparison_col_id"))


class _Names:
    """id <-> name maps of ONE dataset in ONE direction."""

    def __init__(self, session, dataset_id: int, to_names: bool):
        cols = column_names(session, dataset_id)
        conds = _names_of(session, PreDefinedCondition, dataset_id)
        hiers = _names_of(session, DrillHierarchy, dataset_id)
        mets = _names_of(session, CalculatedMetric, dataset_id)
        inv = (lambda m: m) if to_names else (lambda m: {v: k for k, v in m.items()})
        self.col, self.cond, self.hier, self.met = inv(cols), inv(conds), inv(hiers), inv(mets)
        self.to_names = to_names

    def _one(self, table: dict, value, what: str, who: str):
        if value in (None, ""):
            return value
        k = int(value) if self.to_names else str(value)
        if k not in table:
            raise ReleaseRefusal(f"{who}: {what} {value!r} is not in the dataset", path=what)
        return table[k]

    def col_one(self, v, who, what):
        return self._one(self.col, v, f"column {what}", who)

    def col_list(self, vs, who, what):
        return [self.col_one(v, who, what) for v in (vs or [])]


def translate_report(d: dict, names: _Names, merged: Optional[_Names], who: str) -> dict:
    """Every column / condition / hierarchy / metric reference in a report
    row, ids -> names (``names.to_names``) or names -> ids."""
    out = copy.deepcopy(d)
    for f in _REPORT_COL_LIST:
        if f in out:
            out[f] = names.col_list(out.get(f), who, f)
    for lst, f in _REPORT_COL_IN_LIST:
        for i, e in enumerate(out.get(lst) or []):
            if isinstance(e, dict) and f in e:
                e[f] = names.col_one(e[f], who, f"{lst}[{i}].{f}")
    for lst, f in _REPORT_COL_LISTS_IN_LIST:
        for i, e in enumerate(out.get(lst) or []):
            if isinstance(e, dict) and f in e:
                e[f] = names.col_list(e[f], who, f"{lst}[{i}].{f}")
    if "condition_ids" in out:
        out["condition_ids"] = [names._one(names.cond, v, "condition", who) for v in (out.get("condition_ids") or [])]
    if "drill_hierarchy_id" in out:
        out["drill_hierarchy_id"] = names._one(names.hier, out.get("drill_hierarchy_id"), "hierarchy", who)
    if out.get("merged_dataset_column_ids") is not None:
        if merged is None and out["merged_dataset_column_ids"]:
            raise ReleaseRefusal(f"{who}: merged_dataset_column_ids without a merged dataset")
        out["merged_dataset_column_ids"] = merged.col_list(out["merged_dataset_column_ids"], who, "merged_dataset_column_ids") if merged else []
    lc = out.get("layout_config")
    if isinstance(lc, dict):
        for blk, f in _LAYOUT_COLS:
            b = lc.get(blk)
            if isinstance(b, dict) and f in b:
                b[f] = names.col_list(b[f], who, f"layout_config.{blk}.{f}")
        for blk, f in _LAYOUT_COL:
            b = lc.get(blk)
            if isinstance(b, dict) and f in b:
                b[f] = names.col_one(b[f], who, f"layout_config.{blk}.{f}")
        pv = lc.get("pivot_config")
        if isinstance(pv, dict):
            for i, vf in enumerate(pv.get("value_fields") or []):
                if isinstance(vf, dict) and "column_id" in vf:
                    vf["column_id"] = names.col_one(vf["column_id"], who, f"layout_config.pivot_config.value_fields[{i}].column_id")
        if "metric_ids" in lc:
            lc["metric_ids"] = [names._one(names.met, v, "metric", who) for v in (lc.get("metric_ids") or [])]
    return out


REPORT_STRIP = ("execution_count", "last_executed_at", "is_certified", "certified_by", "certified_at",
                "cloned_from_id", "legacy_report_id", "created_at", "updated_at",
                # 2026-10-17 -- the external-API lifecycle's audit stamps (the status,
                # sunset, note and successor travel: they are the report's configuration)
                "api_lifecycle_changed_by", "api_lifecycle_changed_at")


class BusinessReportType(ReleasableType):
    kind = "business_report"
    model = BusinessReport
    key = ("slug",)
    phase = 2
    env = (Env("owner", "user"), Env("parameters[*].created_by", "user"),
           Env("alert_rules[*].recipients", "email"), Env("alert_rules[*].slack_webhook", "url"))
    also_carries = ("report_parameters", "report_pdf_configs", "report_slos", "report_dependency_mappings",
                    "report_readiness_subjects", "conditional_format_rules", "rls_policies", "alert_rules",
                    "report_folder_assignments", "report_tag_assignments")
    refs = {"dataset_id": Ref("dataset"), "merged_dataset_id": Ref("dataset", field="merged_dataset"),
            "federation_view_id": Ref("federation_view"), "published_view_id": Ref("published_view"),
            "owner_group_id": Ref("user_group", field="owner_group"),
            # the raw-SQL report family: its query / file / connection override
            "raw_saved_query_id": Ref("saved_query", field="raw_saved_query"),
            "raw_sql_saved_query_id": Ref("sql_saved_query", field="raw_sql_saved_query"),
            "raw_sql_file_id": Ref("sql_file", field="raw_sql_file"),
            "raw_connection_override_id": Ref("connection", field="raw_connection_override"),
            "secondary_connection_id": Ref("connection", field="secondary_connection"),
            # 2026-10-17 -- the external-API lifecycle's successor, another report by slug
            "api_successor": Ref("business_report", by="key")}

    @staticmethod
    def row_filter(row) -> bool:
        return bool(getattr(row, "slug", None))      # a report with no slug has not been backfilled: not exportable by key

    def export_row(self, session, row, registry) -> Item:
        who = f"business_report {row.slug!r}"
        d = self._columns(row, strip=REPORT_STRIP)
        deps: list = []
        env_refs: list = []
        if d.get("workspace_id"):
            raise ReleaseRefusal(f"{who} belongs to a workspace; workspaces are a later phase", kind=self.kind, key=str(row.slug))
        d.pop("workspace_id", None)
        dataset_name = resolve_name(session, "dataset", int(row.dataset_id), registry)
        if dataset_name is None:
            raise ReleaseRefusal(f"{who}: dataset id {row.dataset_id} does not exist", kind=self.kind, key=str(row.slug))
        self._refs_to_names(session, d, self.refs, registry, deps, env_refs, prefix="")
        names = _Names(session, int(row.dataset_id), True)
        merged = _Names(session, int(row.merged_dataset_id), True) if row.merged_dataset_id else None
        d = translate_report(d, names, merged, who)
        # children
        params = []
        pnames = {int(p.id): str(p.name) for p in session.query(ReportParameter).filter(ReportParameter.report_id == row.id).all()}
        for p in sorted(session.query(ReportParameter).filter(ReportParameter.report_id == row.id).all(), key=lambda p: p.sort_order or 0):
            pd = self._columns(p, strip=("report_id",))
            pd["lov_column"] = names.col_one(pd.pop("lov_column_id", None), who, "lov_column_id")
            pd["cascade_filter_column"] = names.col_one(pd.pop("cascade_filter_column_id", None), who, "cascade_filter_column_id")
            dep = pd.pop("depends_on_param_id", None)
            pd["depends_on_param"] = pnames.get(int(dep)) if dep else None
            params.append(pd)
        d["parameters"] = params
        pdf = session.query(ReportPDFConfig).filter(ReportPDFConfig.report_id == row.id).first()
        d["pdf_config"] = self._columns(pdf, strip=("report_id",)) if pdf else None
        slo = session.query(ReportSlo).filter(ReportSlo.report_id == row.id).first()
        d["slo"] = self._columns(slo, strip=("report_id",)) if slo else None
        if slo and slo.calendar_name:
            deps.append(("calendar", str(slo.calendar_name)))
        subj = session.query(ReportReadinessSubject).filter(ReportReadinessSubject.report_id == row.id).first()
        d["readiness"] = self._columns(subj, strip=("report_id",)) if subj else None
        depmaps = []
        for m in sorted(session.query(ReportDependencyMapping).filter(ReportDependencyMapping.report_id == row.id).all(),
                        key=lambda m: (str(m.dependency_type_id), m.dependency_key)):
            md = self._columns(m, strip=("report_id",))
            tid = md.pop("dependency_type_id", None)
            tname = resolve_name(session, "dependency_type", int(tid), registry) if tid else None
            if tname is None:
                raise ReleaseRefusal(f"{who}: dependency type id {tid} does not exist")
            md["dependency_type"] = tname
            deps.append(("dependency_type", tname))
            if md.get("calendar_name"):
                deps.append(("calendar", str(md["calendar_name"])))
            depmaps.append(md)
        d["dependencies"] = depmaps
        d["format_rules"] = [self._columns(r, strip=("report_id",)) for r in
                             sorted(session.query(ConditionalFormatRule).filter(ConditionalFormatRule.report_id == row.id).all(),
                                    key=lambda r: (r.column_name, r.rule_order or 0))]
        d["rls_policies"] = [self._columns(r, strip=("report_id",)) for r in
                             sorted(session.query(RLSPolicy).filter(RLSPolicy.report_id == row.id).all(),
                                    key=lambda r: (r.column_name, r.operator))]
        d["alert_rules"] = [self._columns(r, strip=("report_id", "last_triggered_at")) for r in
                            sorted(session.query(AlertRule).filter(AlertRule.report_id == row.id).all(), key=lambda r: r.name)]
        folders = []
        for a in session.query(ReportFolderAssignment).filter(ReportFolderAssignment.report_id == row.id,
                                                              ReportFolderAssignment.report_type == "business").all():
            fname = resolve_name(session, "report_folder", int(a.folder_id), registry)
            if fname is None:
                raise ReleaseRefusal(f"{who}: folder id {a.folder_id} does not exist")
            folders.append(fname)
            deps.append(("report_folder", fname))
        d["folders"] = sorted(folders)
        tags = []
        for a in session.query(ReportTagAssignment).filter(ReportTagAssignment.report_id == row.id,
                                                           ReportTagAssignment.report_type == "business").all():
            tname = resolve_name(session, "report_tag", int(a.tag_id), registry)
            if tname is None:
                raise ReleaseRefusal(f"{who}: tag id {a.tag_id} does not exist")
            tags.append(tname)
            deps.append(("report_tag", tname))
        d["tags"] = sorted(tags)
        clean, _ = scrub_secrets(d, secret_columns=set(), secret_paths=("alert_rules[*].slack_webhook",) if False else (),
                                 not_secret=("role_whitelist",), kind=self.kind, key=str(row.slug))
        env_fields = pop_env_fields(clean, self.env)
        definition = normalize(clean)
        return Item(kind=self.kind, key=str(row.slug), definition=definition, environment_fields=normalize(env_fields),
                    environment_refs=env_refs, dependencies=sorted({(k, v) for k, v in deps}), hash=item_hash(definition))

    def resolve(self, session, item, mapping, registry, in_package) -> dict:
        out = super().resolve(session, item, mapping, registry, in_package)
        d = item.definition
        for dep in d.get("dependencies") or []:
            t = dep.get("dependency_type")
            if t and ("dependency_type", t) not in in_package and resolve_id(session, "dependency_type", t, registry) is None:
                out["missing"].append({"what": "dependency", "kind": "dependency_type", "key": t, "path": "dependencies",
                                       "reason": f"dependency_type {t!r} is neither in the package nor in the target"})
        for kind, field in (("report_folder", "folders"), ("report_tag", "tags")):
            for name in d.get(field) or []:
                if (kind, name) not in in_package and resolve_id(session, kind, name, registry) is None:
                    out["missing"].append({"what": "dependency", "kind": kind, "key": name, "path": field,
                                           "reason": f"{kind} {name!r} is neither in the package nor in the target"})
        return out

    def apply(self, session, item, resolved, existing, *, keep_fields, actor, registry):
        who = f"business_report {item.key!r}"
        d = copy.deepcopy(item.definition)
        kids = {k: d.pop(k, None) for k in ("parameters", "pdf_config", "slo", "readiness", "dependencies",
                                            "format_rules", "rls_policies", "alert_rules", "folders", "tags")}
        cols = self._to_columns(session, d, self.refs, resolved, registry, prefix="")
        did = cols.get("dataset_id")
        if did is None:
            raise ReleaseRefusal(f"{who}: dataset {d.get('dataset')!r} is not in the target")
        names = _Names(session, int(did), False)
        merged = _Names(session, int(cols["merged_dataset_id"]), False) if cols.get("merged_dataset_id") else None
        cols = translate_report(cols, names, merged, who)
        cols = self._coerce_columns(BusinessReport, cols)
        if existing is None:
            for cpath, value in (resolved.get("env") or {}).items():
                if cpath.split(".")[0].split("[")[0] in kids:
                    continue
                set_path(cols, cpath, value)
            cols.setdefault("owner", actor or "release")
            row = BusinessReport(**cols)
            session.add(row)
            session.flush()
            action = "created"
        else:
            row = existing
            for col, value in cols.items():
                if col in keep_fields or col in ("slug", "owner"):
                    continue
                if hasattr(row, col):
                    setattr(row, col, value)
            action = "updated"
        rid = int(row.id)
        # parameters (two passes: depends_on_param by name)
        pdefs = []
        for p in kids["parameters"] or []:
            p = dict(p)
            p["lov_column_id"] = names.col_one(p.pop("lov_column", None), who, "lov_column")
            p["cascade_filter_column_id"] = names.col_one(p.pop("cascade_filter_column", None), who, "cascade_filter_column")
            p["_depends_on"] = p.pop("depends_on_param", None)
            pdefs.append(p)
        self._sync_children(session, ReportParameter, rid, [{k: v for k, v in p.items() if k != "_depends_on"} for p in pdefs],
                            key=("name",), parent_col="report_id")
        pid = {str(p.name): int(p.id) for p in session.query(ReportParameter).filter(ReportParameter.report_id == rid).all()}
        for p in pdefs:
            dep = p.get("_depends_on")
            prow = session.query(ReportParameter).filter(ReportParameter.report_id == rid, ReportParameter.name == p["name"]).first()
            if prow is not None:
                prow.depends_on_param_id = pid.get(dep) if dep else None
        self._sync_children(session, ReportPDFConfig, rid, [kids["pdf_config"]] if kids["pdf_config"] else [], key=("report_type",), parent_col="report_id")
        self._sync_children(session, ReportSlo, rid, [kids["slo"]] if kids["slo"] else [], key=("serve_by",), parent_col="report_id")
        self._sync_children(session, ReportReadinessSubject, rid, [kids["readiness"]] if kids["readiness"] else [], key=("business_date_param",), parent_col="report_id")
        depdefs = []
        for m in kids["dependencies"] or []:
            m = dict(m)
            tid = resolve_id(session, "dependency_type", m.pop("dependency_type"), registry)
            if tid is None:
                raise ReleaseRefusal(f"{who}: dependency type is not in the target")
            m["dependency_type_id"] = tid
            depdefs.append(m)
        self._sync_children(session, ReportDependencyMapping, rid, depdefs, key=("dependency_type_id", "dependency_key"), parent_col="report_id")
        self._sync_children(session, ConditionalFormatRule, rid, kids["format_rules"] or [], key=("column_name", "rule_order"), parent_col="report_id")
        self._sync_children(session, RLSPolicy, rid, kids["rls_policies"] or [], key=("column_name", "operator"), parent_col="report_id")
        alerts = []
        for i, a in enumerate(kids["alert_rules"] or []):
            a = dict(a)
            for f in ("recipients", "slack_webhook"):
                v = (resolved.get("env") or {}).get(f"alert_rules[{i}].{f}")
                if v is not None and existing is None:
                    a[f] = v
            alerts.append(a)
        if existing is not None:
            cur = {str(r.name): r for r in session.query(AlertRule).filter(AlertRule.report_id == rid).all()}
            for a in alerts:
                c = cur.get(a.get("name"))
                if c is not None:
                    a["recipients"], a["slack_webhook"] = c.recipients, c.slack_webhook
        self._sync_children(session, AlertRule, rid, alerts, key=("name",), parent_col="report_id")
        fids = []
        for fname in kids["folders"] or []:
            fid = resolve_id(session, "report_folder", fname, registry)
            if fid is None:
                raise ReleaseRefusal(f"{who}: folder {fname!r} is not in the target")
            fids.append({"folder_id": fid, "report_type": "business"})
        self._sync_children(session, ReportFolderAssignment, rid, fids, key=("folder_id",), parent_col="report_id",
                            extra_filter=("report_type", "business"))
        tids = []
        for tname in kids["tags"] or []:
            tid = resolve_id(session, "report_tag", tname, registry)
            if tid is None:
                raise ReleaseRefusal(f"{who}: tag {tname!r} is not in the target")
            tids.append({"tag_id": tid, "report_type": "business"})
        self._sync_children(session, ReportTagAssignment, rid, tids, key=("tag_id",), parent_col="report_id",
                            extra_filter=("report_type", "business"))
        session.flush()
        return rid, action

    def _sync_children(self, session, model, parent_id: int, defs: list[dict], *, key, parent_col: str,
                       extra_filter: Optional[tuple] = None) -> None:
        q = session.query(model).filter(getattr(model, parent_col) == parent_id)
        if extra_filter:
            q = q.filter(getattr(model, extra_filter[0]) == extra_filter[1])
        existing = {tuple(str(getattr(r, k)) for k in key): r for r in q.all()}
        seen = set()
        for d in defs:
            cols = self._coerce_columns(model, {k: v for k, v in d.items() if k != "id" and hasattr(model, k)})
            ck = tuple(str(cols.get(k)) for k in key)
            seen.add(ck)
            row = existing.get(ck)
            if row is None:
                cols[parent_col] = parent_id
                session.add(model(**cols))
            else:
                for k, v in cols.items():
                    setattr(row, k, v)
        for ck, row in existing.items():
            if ck not in seen:
                session.delete(row)
        session.flush()

    def verify(self, db, session, object_id, registry) -> Verdict:
        row = session.query(BusinessReport).filter(BusinessReport.id == object_id).first()
        if row is None:
            return Verdict("failed", f"business_report id {object_id} is not in the target after apply")
        checks = []
        ds = session.query(BusinessDataset).filter(BusinessDataset.id == row.dataset_id).first()
        checks.append({"check": f"dataset {row.dataset_id}", "ok": ds is not None, "name": ds.name if ds else None})
        if ds is not None:
            cols = column_names(session, ds.id)
            missing = [c for c in (row.column_ids or []) if int(c) not in cols]
            checks.append({"check": f"{len(row.column_ids or [])} selected column(s) exist in the dataset", "ok": not missing,
                           "missing": missing})
        failed = [c for c in checks if c["ok"] is False]
        return Verdict("failed" if failed else "ok", "; ".join(c["check"] for c in failed), checks)


REGISTRY.register(BusinessReportType())
