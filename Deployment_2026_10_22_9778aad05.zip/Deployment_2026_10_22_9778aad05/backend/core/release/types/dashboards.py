"""Dashboards and DataFlows as releasable types (phase 4).

* A dashboard has no unique name: it carries a ``release_key`` (minted on
  first export, like saved queries), and so does each widget.  A widget's
  ``source_id`` is polymorphic on ``widget_type``: it travels as the source's
  own key (a saved query's release_key, a business report's slug) and is
  resolved in the target.  A legacy ``report`` widget is refused (DECIDED:
  legacy reports are not released).
* A DataFlow is keyed by name; the release carries the LATEST version and
  updates it in place (the dataflow engine's own promote flow owns version
  numbers -- a release does not mint versions).  Stages travel with their
  ``config`` as authored, except top-level ``*connection_id`` keys, which
  become connection NAMES (the bundle export used to keep raw ids).  A
  secret variable's value never travels; a plain variable's value is an
  environment field (``value`` mapping).
"""
from __future__ import annotations

import copy

from core.release.contract import (
    Child, DeclaredType, Env, Item, Ref, ReleasableType, ReleaseRefusal, item_hash, model_for, normalize,
    pop_env_fields, resolve_id, resolve_name, scrub_secrets, set_path,
)
from core.release.registry import REGISTRY
from core.release.types.reports import MINTED_KEYS, ReleaseKeyType, mint_release_key

Dashboard = model_for("dashboards")
DashboardWidget = model_for("dashboard_widgets")
DataFlow = model_for("dataflows")
DataFlowStage = model_for("dataflow_stages")
DataFlowSchedule = model_for("dataflow_schedules")
DataFlowVariable = model_for("dataflow_variables")
DataFlowNotificationPolicy = model_for("dataflow_notification_policies")
DataFlowCustomStageType = model_for("dataflow_custom_stage_types")

REGISTRY.register(DeclaredType(kind="custom_stage_type", model=DataFlowCustomStageType, key=("name",), phase=4,
                               env=(Env("created_by", "user"),)))

#: widget_type -> the releasable kind its source_id names
WIDGET_SOURCE_KINDS = {"saved_query": "saved_query", "sql_query": "sql_saved_query", "business_report": "business_report"}


class DashboardType(ReleaseKeyType):
    def __init__(self):
        super().__init__(kind="dashboard", model=Dashboard, key=("release_key",), phase=4,
                         env=(Env("created_by", "user"),), strip=("workspace_id",))
        self.also_carries = ("dashboard_widgets",)

    def export_row(self, session, row, registry) -> Item:
        if getattr(row, "workspace_id", None):
            raise ReleaseRefusal(f"dashboard {row.name!r} belongs to a workspace; workspaces are a later phase",
                                 kind=self.kind)
        item = super().export_row(session, row, registry)
        widgets = []
        deps = {tuple(d) for d in item.dependencies}
        for w in sorted(session.query(DashboardWidget).filter(DashboardWidget.dashboard_id == row.id).all(),
                        key=lambda w: int(w.id)):
            if not getattr(w, "release_key", None):
                w.release_key = mint_release_key(w.title or w.widget_type, int(w.id))
                MINTED_KEYS.append((DashboardWidget, int(w.id), w.release_key))
            wd = self._columns(w, strip=("dashboard_id",))
            skind = WIDGET_SOURCE_KINDS.get(str(w.widget_type))
            if skind is None:
                raise ReleaseRefusal(f"dashboard {item.key!r}: widget {w.release_key!r} is a {w.widget_type!r} widget -- "
                                     f"legacy reports are not released (DECIDED)", kind=self.kind, key=item.key)
            sid = wd.pop("source_id", None)
            sname = resolve_name(session, skind, int(sid), registry) if sid else None
            if sname is None:
                raise ReleaseRefusal(f"dashboard {item.key!r}: widget {w.release_key!r} names {skind} id {sid} which does not exist",
                                     kind=self.kind, key=item.key)
            wd["source"] = sname
            deps.add((skind, sname))
            widgets.append(wd)
        item.definition["widgets"] = normalize(widgets)
        item.dependencies = sorted(deps)
        item.hash = item_hash(item.definition)
        return item

    def resolve(self, session, item, mapping, registry, in_package) -> dict:
        out = super().resolve(session, item, mapping, registry, in_package)
        for w in item.definition.get("widgets") or []:
            skind = WIDGET_SOURCE_KINDS.get(str(w.get("widget_type")))
            sname = w.get("source")
            if skind and sname and (skind, sname) not in in_package and resolve_id(session, skind, sname, registry) is None:
                out["missing"].append({"what": "dependency", "kind": skind, "key": sname, "path": "widgets",
                                       "reason": f"{skind} {sname!r} is neither in the package nor in the target"})
        return out

    def apply(self, session, item, resolved, existing, *, keep_fields, actor, registry):
        item = copy.deepcopy(item)
        widgets = item.definition.pop("widgets", []) or []
        oid, action = super().apply(session, item, resolved, existing, keep_fields=keep_fields, actor=actor, registry=registry)
        current = {str(w.release_key): w for w in session.query(DashboardWidget).filter(DashboardWidget.dashboard_id == oid).all()}
        seen = set()
        for w in widgets:
            w = dict(w)
            skind = WIDGET_SOURCE_KINDS[str(w["widget_type"])]
            sid = resolve_id(session, skind, w.pop("source"), registry)
            if sid is None:
                raise ReleaseRefusal(f"dashboard {item.key!r}: widget source is not in the target")
            w["source_id"] = sid
            key = str(w.get("release_key"))
            seen.add(key)
            row = current.get(key)
            if row is None:
                session.add(DashboardWidget(dashboard_id=oid, **{k: v for k, v in w.items() if hasattr(DashboardWidget, k)}))
            else:
                for k, v in w.items():
                    if hasattr(row, k):
                        setattr(row, k, v)
        for key, row in current.items():
            if key not in seen:
                session.delete(row)
        session.flush()
        return oid, action


REGISTRY.register(DashboardType())


class DataFlowType(ReleasableType):
    kind = "dataflow"
    model = DataFlow
    key = ("name",)
    phase = 4
    strip = ("version", "is_paused", "workspace_id")
    env = (Env("created_by", "user"), Env("variables[*].value", "value"))
    not_secret = ("is_secret",)          # the FLAG that says a variable is secret; its value is stripped
    also_carries = ("dataflow_stages", "dataflow_schedules", "dataflow_variables", "dataflow_notification_policies")

    def rows(self, session):
        """The LATEST version of every name."""
        latest: dict[str, object] = {}
        for r in session.query(DataFlow).all():
            cur = latest.get(r.name)
            if cur is None or int(r.version or 0) > int(cur.version or 0):
                latest[r.name] = r
        return sorted(latest.values(), key=lambda r: r.name)

    def find_row(self, session, key: str):
        rows = session.query(DataFlow).filter(DataFlow.name == str(key)).all()
        return max(rows, key=lambda r: int(r.version or 0)) if rows else None

    def export_row(self, session, row, registry) -> Item:
        if getattr(row, "workspace_id", None):
            raise ReleaseRefusal(f"dataflow {row.name!r} belongs to a workspace; workspaces are a later phase", kind=self.kind)
        d = self._columns(row, strip=self.strip)
        deps: list = []
        env_refs: list = []
        stages = []
        for i, s in enumerate(sorted(session.query(DataFlowStage).filter(DataFlowStage.dataflow_id == row.id).all(),
                                     key=lambda s: (int(s.seq or 0), s.stage_alias))):
            sd = self._columns(s, strip=("dataflow_id",))
            cfg = dict(sd.get("config") or {})
            for k in list(cfg):
                if k.endswith("connection_id") and cfg[k] not in (None, "", 0):
                    name = resolve_name(session, "connection", int(cfg[k]), registry) if str(cfg[k]).isdigit() or isinstance(cfg[k], int) else str(cfg[k])
                    if name is None:
                        raise ReleaseRefusal(f"dataflow {row.name!r}: stage {s.stage_alias!r} names connection id {cfg[k]} which does not exist")
                    cfg[k[:-len("_id")]] = name
                    del cfg[k]
                    env_refs.append({"kind": "connection", "name": name, "path": f"stages[{i}].config.{k[:-3]}"})
            sd["config"] = cfg
            stages.append(sd)
        d["stages"] = stages
        d["schedules"] = [self._columns(s, strip=("dataflow_id", "last_run_at", "next_run_at")) for s in
                          sorted(session.query(DataFlowSchedule).filter(DataFlowSchedule.dataflow_id == row.id).all(), key=lambda s: s.name)]
        variables = []
        for v in sorted(session.query(DataFlowVariable).filter(DataFlowVariable.dataflow_id == row.id).all(), key=lambda v: v.name):
            vd = self._columns(v, strip=("dataflow_id",))
            if v.is_secret:
                vd["value"] = None          # a secret never travels; PROD supplies its own
            variables.append(vd)
        d["variables"] = variables
        d["notification_policies"] = [self._columns(p, strip=("dataflow_id", "last_fired_at")) for p in
                                      sorted(session.query(DataFlowNotificationPolicy).filter(DataFlowNotificationPolicy.dataflow_id == row.id).all(),
                                             key=lambda p: (p.name, p.event, p.channel))]
        clean, _ = scrub_secrets(d, secret_columns=set(), secret_paths=(), not_secret=self.not_secret, kind=self.kind,
                                 key=str(row.name))
        env_fields = pop_env_fields(clean, self.env)
        definition = normalize(clean)
        return Item(kind=self.kind, key=str(row.name), definition=definition, environment_fields=normalize(env_fields),
                    environment_refs=env_refs, dependencies=sorted({(k, v) for k, v in deps}), hash=item_hash(definition))

    def resolve(self, session, item, mapping, registry, in_package) -> dict:
        out: dict = {"refs": {}, "env": {}, "missing": []}
        for ref in item.environment_refs or []:
            target = mapping.lookup("connection", ref["name"]) or ref["name"]
            rid = resolve_id(session, "connection", target, registry)
            if rid is None:
                out["missing"].append({"what": "environment_ref", "kind": "connection", "name": ref["name"], "mapped_to": target,
                                       "path": ref["path"], "reason": f"connection {target!r} does not exist in the target"})
            else:
                out["refs"][ref["path"]] = rid
        for cpath, ef in (item.environment_fields or {}).items():
            mapped = mapping.lookup(ef.get("kind"), ef.get("value"))
            if mapped is None:
                out["missing"].append({"what": "environment_field", "path": cpath, "mapping_kind": ef.get("kind"), "value": ef.get("value"),
                                       "reason": f"no release mapping of kind {ef.get('kind')!r} for {ef.get('value')!r}"})
            else:
                out["env"][cpath] = mapped
        return out

    def apply(self, session, item, resolved, existing, *, keep_fields, actor, registry):
        d = copy.deepcopy(item.definition)
        if existing is None:
            for cpath, value in (resolved.get("env") or {}).items():
                set_path(d, cpath, value)
        kids = {k: d.pop(k, []) for k in ("stages", "schedules", "variables", "notification_policies")}
        if existing is None:
            d["created_by"] = actor
            d["version"] = 1
            row = DataFlow(**d)
            session.add(row)
            session.flush()
            action = "created"
        else:
            row = existing
            for k, v in d.items():
                if k in keep_fields or k == "name" or not hasattr(row, k):
                    continue
                setattr(row, k, v)
            action = "updated"
        fid = int(row.id)
        stages = []
        for i, s in enumerate(kids["stages"]):
            s = dict(s)
            cfg = dict(s.get("config") or {})
            for k in list(cfg):
                if k.endswith("connection") and isinstance(cfg[k], str):
                    rid = (resolved.get("refs") or {}).get(f"stages[{i}].config.{k}") or resolve_id(session, "connection", cfg[k], registry)
                    if rid is None:
                        raise ReleaseRefusal(f"dataflow {item.key!r}: stage {s.get('stage_alias')!r}: connection {cfg[k]!r} is not in the target")
                    cfg[k + "_id"] = rid
                    del cfg[k]
            s["config"] = cfg
            stages.append(s)
        self._sync(session, DataFlowStage, fid, stages, key=("stage_alias",))
        self._sync(session, DataFlowSchedule, fid, kids["schedules"], key=("name",))
        variables = []
        cur = {str(v.name): v for v in session.query(DataFlowVariable).filter(DataFlowVariable.dataflow_id == fid).all()}
        for v in kids["variables"]:
            v = dict(v)
            c = cur.get(str(v.get("name")))
            if v.get("is_secret") or (c is not None and existing is not None):
                v["value"] = c.value if c is not None else None     # PROD keeps its own value
            variables.append(v)
        self._sync(session, DataFlowVariable, fid, variables, key=("name",))
        self._sync(session, DataFlowNotificationPolicy, fid, kids["notification_policies"], key=("name", "event", "channel"))
        session.flush()
        return fid, action

    def _sync(self, session, model, fid, defs, *, key):
        existing = {tuple(str(getattr(r, k)) for k in key): r
                    for r in session.query(model).filter(model.dataflow_id == fid).all()}
        seen = set()
        for d in defs:
            cols = self._coerce_columns(model, {k: v for k, v in d.items() if k != "id" and hasattr(model, k)})
            ck = tuple(str(cols.get(k)) for k in key)
            seen.add(ck)
            row = existing.get(ck)
            if row is None:
                cols["dataflow_id"] = fid
                session.add(model(**cols))
            else:
                for k, v in cols.items():
                    setattr(row, k, v)
        for ck, row in existing.items():
            if ck not in seen:
                session.delete(row)
        session.flush()


REGISTRY.register(DataFlowType())
