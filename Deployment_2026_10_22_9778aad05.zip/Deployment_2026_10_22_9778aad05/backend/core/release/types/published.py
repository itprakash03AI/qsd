"""Published views as a releasable type (phase 3).

The Phase 98-E export/import routes (`api/published_views/management.py`)
MOVE onto this contract: their response shapes stay (a CI consumer may read
them) but the bytes come from this type and the import is a release through
the engine.  The defect they carried -- ``execution_connection_id`` round-
tripped as a RAW ID, so a UAT id landed in PROD -- is gone: every connection
travels by name and is mapped like every other environment reference.
"""
from __future__ import annotations

from core.release.contract import (
    Child, DeclaredType, Env, Item, Ref, ReleasableType, ReleaseRefusal, item_hash, model_for, resolve_id, resolve_name,
)
from core.release.registry import REGISTRY

PublishedView = model_for("published_views")
PublishedViewWebhook = model_for("published_view_webhooks")


class PublishedViewType(ReleasableType):
    kind = "published_view"
    model = PublishedView
    key = ("slug",)
    phase = 3
    refs = {
        "connection_id": Ref("connection"),
        # the defect of the old import: a raw id crossed environments
        "execution_connection_id": Ref("connection", field="execution_connection"),
        "query_id": Ref("saved_query", field="query"),
        "business_report_id": Ref("business_report"),
        "federation_view_id": Ref("federation_view"),
        "sql_file_id": Ref("sql_file"),
        # 2026-10-17 -- the API lifecycle's successor is another view, by slug;
        # a release carries the successor first (core/published_api/lifecycle.py)
        "api_successor": Ref("published_view", by="key"),
    }
    children = [Child("webhooks", PublishedViewWebhook, "view_id", key=("url",),
                      strip=("last_triggered_at", "last_status_code"), env=(Env("url", "url"),))]
    env = (Env("publisher_username", "user"), Env("created_by", "user"))
    # the lifecycle's who / when are audit stamps the target mints
    strip = ("workspace_id", "api_lifecycle_changed_by", "api_lifecycle_changed_at")
    #: a webhook's HMAC secret never travels (PROD mints its own)
    secret_paths = ("webhooks[*].secret",)
    #: ``credential_mode`` (consumer | publisher) is vocabulary, not a credential
    not_secret = ("credential_mode",)

    def export_row(self, session, row, registry) -> Item:
        item = super().export_row(session, row, registry)
        aec = item.definition.get("allowed_engine_connections")
        if aec:
            names = []
            for i, cid in enumerate(aec):
                if isinstance(cid, int):
                    name = resolve_name(session, "connection", cid, registry)
                    if name is None:
                        raise ReleaseRefusal(f"published_view {row.slug!r}: engine connection id {cid} does not exist",
                                             kind=self.kind, key=str(row.slug))
                    names.append(name)
                    item.environment_refs.append({"kind": "connection", "name": name,
                                                  "path": f"allowed_engine_connections[{i}]"})
                else:
                    names.append(cid)
            item.definition["allowed_engine_connections"] = names
            item.hash = item_hash(item.definition)
        return item

    def resolve(self, session, item, mapping, registry, in_package) -> dict:
        out = super().resolve(session, item, mapping, registry, in_package)
        for i, name in enumerate(item.definition.get("allowed_engine_connections") or []):
            target = mapping.lookup("connection", name) or name
            rid = resolve_id(session, "connection", target, registry)
            if rid is None:
                out["missing"].append({"what": "environment_ref", "kind": "connection", "name": name, "mapped_to": target,
                                       "path": f"allowed_engine_connections[{i}]",
                                       "reason": f"connection {target!r} does not exist in the target"})
            else:
                out["refs"][f"allowed_engine_connections[{i}]"] = rid
        return out

    def apply(self, session, item, resolved, existing, *, keep_fields, actor, registry):
        import copy
        item = copy.deepcopy(item)
        names = item.definition.get("allowed_engine_connections")
        if names:
            ids = []
            for i, name in enumerate(names):
                rid = (resolved.get("refs") or {}).get(f"allowed_engine_connections[{i}]") or resolve_id(session, "connection", name, registry)
                if rid is None:
                    raise ReleaseRefusal(f"published_view {item.key!r}: connection {name!r} is not in the target")
                ids.append(rid)
            item.definition["allowed_engine_connections"] = ids
        return super().apply(session, item, resolved, existing, keep_fields=keep_fields, actor=actor, registry=registry)


REGISTRY.register(PublishedViewType())


# ── published-API alert thresholds (2026-10-17, core/published_api/alerts.py) ──

class ApiAlertThresholdType(DeclaredType):
    """A threshold's scope key is a NAME: a view's slug travels as it is; a
    REPORT API's key in the inventory is the report's id in THIS environment,
    so the package carries the report's release KEY (what the business_report
    type travels under -- its slug) and the target maps it back (an id
    crossing environments is the defect the old view import had).
    The key the item travels under is spelled the same way, so a diff in the
    target finds the row it means."""

    REPORT = "published_report"

    def __init__(self):
        super().__init__(kind="api_alert_threshold", model=model_for("published_api_alert_thresholds"),
                         key=("scope", "api_kind", "scope_key", "metric", "name"), phase=3,
                         refs={"alert_kind": Ref("alert_kind", by="key")},
                         env=(Env("created_by", "user"),), strip=("created_at", "updated_by", "updated_at"))

    @classmethod
    def _report_scoped(cls, scope, api_kind) -> bool:
        return scope == "api" and api_kind == cls.REPORT

    def row_key(self, row) -> str:
        if self._report_scoped(row.scope, row.api_kind):
            from sqlalchemy.orm import object_session
            s = object_session(row)
            name = resolve_name(s, "business_report", int(row.scope_key), REGISTRY) if s is not None else None
            if name is not None:
                return "|".join(str(v) for v in (row.scope, row.api_kind, name, row.metric, row.name))
        return super().row_key(row)

    def find_row(self, session, key: str):
        parts = key.split("|")
        if len(parts) == len(self.key) and self._report_scoped(parts[0], parts[1]):
            rid = resolve_id(session, "business_report", parts[2], REGISTRY)
            if rid is None:
                return None
            parts[2] = str(rid)
            key = "|".join(parts)
        return super().find_row(session, key)

    def export_row(self, session, row, registry) -> Item:
        item = super().export_row(session, row, registry)
        d = item.definition
        if d.get("scope") == "api":
            if self._report_scoped(d.get("scope"), d.get("api_kind")):
                name = resolve_name(session, "business_report", int(d["scope_key"]), registry)
                if name is None:
                    raise ReleaseRefusal(f"api_alert_threshold {item.key!r}: scoped to report API #{d['scope_key']} "
                                         f"which does not exist", kind=self.kind, key=item.key)
                d["scope_key"] = name
                item.dependencies.append(("business_report", name))
            elif d.get("api_kind") == "published_view":
                item.dependencies.append(("published_view", str(d["scope_key"])))
            item.hash = item_hash(d)
        return item

    def resolve(self, session, item, mapping, registry, in_package) -> dict:
        out = super().resolve(session, item, mapping, registry, in_package)
        d = item.definition
        if self._report_scoped(d.get("scope"), d.get("api_kind")):
            rid = resolve_id(session, "business_report", str(d["scope_key"]), registry)
            if rid is None and ("business_report", str(d["scope_key"])) not in in_package:
                out["missing"].append({"what": "dependency", "kind": "business_report", "name": d["scope_key"],
                                       "path": "scope_key",
                                       "reason": f"business report {d['scope_key']!r} is not in the target and not in the package"})
            elif rid is not None:
                out["refs"]["scope_key"] = rid
        return out

    def apply(self, session, item, resolved, existing, *, keep_fields, actor, registry):
        import copy
        item = copy.deepcopy(item)
        d = item.definition
        if self._report_scoped(d.get("scope"), d.get("api_kind")):
            rid = (resolved.get("refs") or {}).get("scope_key") or resolve_id(session, "business_report", str(d["scope_key"]), registry)
            if rid is None:
                raise ReleaseRefusal(f"api_alert_threshold {item.key!r}: business report {d['scope_key']!r} is not in the target")
            d["scope_key"] = str(int(rid))
        return super().apply(session, item, resolved, existing, keep_fields=keep_fields, actor=actor, registry=registry)


REGISTRY.register(ApiAlertThresholdType())


def legacy_export_dict(session, row, registry) -> dict:
    """The Phase 98-E portable dict, now derived from the release item: the
    keys a CI consumer reads stay; connections are NAMES (the raw
    ``execution_connection_id`` is gone), and ``release_item`` is the
    package item the import route applies."""
    item = REGISTRY.require("published_view").export_row(session, row, registry)
    from core.release.engine import closure
    deps, problems, _excluded = closure(session, registry, {"kind": "published_view", "keys": [str(row.slug)]})
    if problems:
        raise ReleaseRefusal(f"published_view {row.slug!r}: {len(problems)} of the objects it names cannot be "
                             f"exported", kind="published_view", key=str(row.slug), problems=problems)
    others = [i.to_dict() for i in deps if (i.kind, i.key) != ("published_view", str(row.slug))]
    d = dict(item.definition)
    from datetime import datetime, timezone
    import os
    out = {
        "_schema": "querystudio_published_view_v1",
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "exported_from": os.environ.get("QUERYSTUDIO_HOSTNAME", "unknown"),
        "slug": d.get("slug"), "name": d.get("name"), "description": d.get("description"),
        "connection_name": d.get("connection") or "",
        "execution_connection_name": d.get("execution_connection"),
        "execution_connection_id": None,                 # never an id across environments
        "query_config": d.get("query_config") or {},
        "param_definitions": d.get("param_definitions") or [],
        "allowed_filters": d.get("allowed_filters") or [],
        "allowed_ad_groups": d.get("allowed_ad_groups") or [],
        "default_limit": d.get("default_limit", 1000), "max_limit": d.get("max_limit", 50000),
        "rate_limit_per_minute": d.get("rate_limit_per_minute", 60),
        "cache_ttl_seconds": d.get("cache_ttl_seconds", 28800),
        "min_cache_age_seconds": d.get("min_cache_age_seconds", 60),
        "allow_cache_bypass": d.get("allow_cache_bypass", True),
        "cache_strategy": d.get("cache_strategy", "ttl"),
        "source_type": d.get("source_type", "saved_query"),
        "version": d.get("version", 1), "query_hash": d.get("query_hash"),
        "credential_mode": d.get("credential_mode") or "consumer",
        "publisher_username": (item.environment_fields.get("publisher_username") or {}).get("value"),
        "release_item": item.to_dict(),
        # what the view names (its saved query / SQL file / report): the import
        # applies them in the same release, so a view never lands without its source
        "release_dependencies": others,
    }
    return out


def legacy_dict_to_items(view: dict) -> list:
    """A Phase 98-E dict -> the release items it carries: the view (and, for
    an export made since 2026-10-17, the objects it names)."""
    items = [legacy_dict_to_item(view)]
    for d in view.get("release_dependencies") or []:
        if isinstance(d, dict):
            items.append(Item.from_dict(d))
    return items


def legacy_dict_to_item(view: dict) -> Item:
    """A Phase 98-E dict (an older export, or one built by hand) -> the
    release item.  ``connection_name`` becomes the ``connection`` reference;
    a raw ``execution_connection_id`` is REFUSED (an id means nothing in
    another environment -- name it with ``execution_connection_name``)."""
    if isinstance(view.get("release_item"), dict):
        return Item.from_dict(view["release_item"])
    slug = view.get("slug")
    if not slug:
        raise ReleaseRefusal("view has no slug", kind="published_view")
    if view.get("execution_connection_id") not in (None, "", 0):
        raise ReleaseRefusal(f"published_view {slug!r}: execution_connection_id is a raw id from another environment; "
                             f"name the connection (execution_connection_name) instead", kind="published_view", key=str(slug))
    skip = {"_schema", "exported_at", "exported_from", "connection_name", "execution_connection_name",
            "execution_connection_id", "publisher_username", "release_item"}
    definition = {k: v for k, v in view.items() if k not in skip}
    definition["connection"] = view.get("connection_name") or None
    definition["execution_connection"] = view.get("execution_connection_name") or None
    definition.setdefault("is_active", True)
    definition.setdefault("webhooks", [])
    env_refs = [{"kind": "connection", "name": definition["connection"], "path": "connection"}] if definition["connection"] else []
    if definition["execution_connection"]:
        env_refs.append({"kind": "connection", "name": definition["execution_connection"], "path": "execution_connection"})
    env_fields = {}
    if view.get("publisher_username"):
        env_fields["publisher_username"] = {"kind": "user", "value": view["publisher_username"]}
    from core.release.contract import normalize
    definition = normalize(definition)
    return Item(kind="published_view", key=str(slug), definition=definition, environment_fields=env_fields,
                environment_refs=env_refs, dependencies=[], hash=item_hash(definition))
