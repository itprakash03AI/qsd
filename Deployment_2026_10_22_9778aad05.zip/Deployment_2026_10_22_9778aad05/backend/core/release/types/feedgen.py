"""FeedGen setup as releasable types (phase 1).

Declarations for everything a feed estate is made of: user groups,
calendars (+ holidays), dependency types, control-file formats, SQL files
(their TEXT travels), feed groups, alert kinds and routes, restatement
policies, hold approvers, the upstream-contract vocabulary (environments,
message fields, tokens), custom step types, flows (+ steps), hand-authored
feeds (+ their dependency mappings) and feed templates (members DERIVED --
the target re-renders them with the existing template apply).

Two things the declaration cannot say are code here: a feed body's
polymorphic source (``source_type`` + ``source_id``) and the scoped rows
(``scope`` + ``scope_id`` pointing at a feed / group / template).
"""
from __future__ import annotations

import copy
import hashlib
import logging
import socket
from pathlib import Path
from typing import Any, Optional

from sqlalchemy.orm import Session

from core.db.models import (
    EtlDependencyMapping, EtlDependencyType, FeedAlertKind, FeedAlertRoute, FeedCalendar,
    FeedConfig, FeedControlFileFormat, FeedCustomStepType, FeedEnvironment, FeedFlow,
    FeedFlowStep, FeedGroup, FeedHoldApprover, FeedHoliday, FeedMessageField, FeedMessageToken,
    FeedRestatementPolicy, FeedTemplate, SqlFile, UserGroup,
)
from core.feed.pinning import VOLATILE_KEYS
from core.release.contract import (
    Child, DeclaredType, Env, Item, Ref, ReleasableType, ReleaseRefusal, Verdict, item_hash,
    normalize, pop_env_fields, resolve_id, resolve_name, scrub_secrets, set_path,
)
from core.release.registry import REGISTRY

logger = logging.getLogger(__name__)

# ── simple declarations ───────────────────────────────────────────────────

REGISTRY.register(DeclaredType(
    kind="user_group", model=UserGroup, key=("name",),
    env=(Env("notification_email", "email"),)))

REGISTRY.register(DeclaredType(
    kind="calendar", model=FeedCalendar, key=("name",),
    strip=("version",), env=(Env("owner", "user"),),
    children=[Child("holidays", FeedHoliday, "calendar_id", key=("holiday_date",))]))

REGISTRY.register(DeclaredType(
    kind="dependency_type", model=EtlDependencyType, key=("dependency_type",),
    env=(Env("server", "url"), Env("param_value", "value"))))

REGISTRY.register(DeclaredType(
    kind="control_file_format", model=FeedControlFileFormat, key=("name",)))

REGISTRY.register(DeclaredType(
    kind="feed_group", model=FeedGroup, key=("name",),
    env=(Env("notification_email", "email"),)))

REGISTRY.register(DeclaredType(kind="alert_kind", model=FeedAlertKind, key=("kind",)))
REGISTRY.register(DeclaredType(kind="feed_environment", model=FeedEnvironment, key=("side",)))
REGISTRY.register(DeclaredType(kind="message_field", model=FeedMessageField, key=("field",)))
REGISTRY.register(DeclaredType(
    kind="message_token", model=FeedMessageToken, key=("token",),
    # ``token`` is a {TOKEN} vocabulary word of the OG SQL contract, not a credential
    not_secret=("token",)))
REGISTRY.register(DeclaredType(kind="custom_step_type", model=FeedCustomStepType, key=("name",)))
REGISTRY.register(DeclaredType(
    kind="feed_flow", model=FeedFlow, key=("name",),
    children=[Child("steps", FeedFlowStep, "flow_id", key=("alias",))]))


# ── SQL files: the TEXT travels ───────────────────────────────────────────

def _sql_storage_dir() -> Path:
    from core import config as _config
    raw = _config.get("sql_files", "storage_dir", "") or ""
    return Path(raw) if raw else Path("data/sql_files")


class SqlFileType(DeclaredType):
    def __init__(self):
        super().__init__(kind="sql_file", model=SqlFile, key=("file_path",),
                         refs={"connection_id": Ref("connection"),
                               "secondary_connection_id": Ref("connection", field="secondary_connection")},
                         strip=("version", "content_hash", "file_size"),
                         requires_config=("sql_files.storage_dir",))

    def export_row(self, session, row, registry) -> Item:
        item = super().export_row(session, row, registry)
        path = _sql_storage_dir() / str(row.file_path)
        try:
            content = path.read_text(encoding="utf-8")
        except OSError as exc:
            raise ReleaseRefusal(f"sql_file {row.file_path!r}: its content cannot be read "
                                 f"({exc}) -- a package with a nameless query is a hole",
                                 kind=self.kind, key=item.key) from exc
        if row.content_hash and hashlib.sha256(content.encode("utf-8")).hexdigest() != row.content_hash:
            logger.warning("[release] sql_file %s: content on disk differs from the stored hash "
                           "-- the package carries what is ON DISK (what the engine runs)",
                           row.file_path)
        item.definition["content"] = content
        item.hash = item_hash(item.definition)
        return item

    def apply(self, session, item, resolved, existing, *, keep_fields, actor, registry):
        content = str(item.definition.get("content") or "")
        item = copy.deepcopy(item)
        item.definition.pop("content", None)
        oid, action = super().apply(session, item, resolved, existing, keep_fields=keep_fields,
                                    actor=actor, registry=registry)
        row = session.query(SqlFile).filter(SqlFile.id == oid).first()
        if "content" not in keep_fields:
            path = _sql_storage_dir() / str(row.file_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            row.content_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()
            row.file_size = len(content.encode("utf-8"))
            if action == "updated":
                row.version = int(row.version or 1) + 1
        session.flush()
        return oid, action

    def verify(self, db, session, object_id, registry) -> Verdict:
        v = super().verify(db, session, object_id, registry)
        row = session.query(SqlFile).filter(SqlFile.id == object_id).first()
        if row is None:
            return v
        path = _sql_storage_dir() / str(row.file_path)
        try:
            on_disk = hashlib.sha256(path.read_bytes()).hexdigest()
            ok = on_disk == row.content_hash
            v.checks.append({"check": f"content on disk == stored hash ({row.file_path})", "ok": ok})
            if not ok:
                return Verdict("failed", "the SQL text on disk does not match its stored hash", v.checks)
        except OSError as exc:
            v.checks.append({"check": f"content readable ({row.file_path})", "ok": False, "error": str(exc)})
            return Verdict("failed", f"the SQL file cannot be read: {exc}", v.checks)
        return v


REGISTRY.register(SqlFileType())


# ── the feed body: ids -> names, shared by feed and feed_template ─────────

#: body column -> Ref.  ``source_id`` is polymorphic and handled apart.
FEED_BODY_REFS: dict[str, Ref] = {
    "connection_id": Ref("connection"),
    "secondary_connection_id": Ref("connection", field="secondary_connection"),
    "control_file_format_id": Ref("control_file_format"),
    "feed_group_id": Ref("feed_group"),
    "flow_id": Ref("feed_flow"),
    "owner_group_id": Ref("user_group", field="owner_group"),
    "calendar_name": Ref("calendar", by="key"),
}
#: source_type -> the releasable kind its source_id names (raw_sql: none)
SOURCE_KINDS = {"sql_file": "sql_file", "saved_query": "saved_query",
                "published_view": "published_view"}

FEED_ENV: tuple[Env, ...] = (
    Env("destination_config.host", "sftp_host"),
    Env("destination_config.username", "user"),
    Env("destination_config.remote_dir", "path"),
    Env("destination_config.path", "path"),
    Env("destination_config.bucket", "bucket"),
    Env("destination_config.prefix", "path"),
    Env("destination_config.endpoint_url", "url"),
    Env("delivery_chain[*].config.host", "sftp_host"),
    Env("delivery_chain[*].config.username", "user"),
    Env("delivery_chain[*].config.remote_dir", "path"),
    Env("delivery_chain[*].config.bucket", "bucket"),
    Env("delivery_chain[*].config.prefix", "path"),
    Env("notify_emails", "email"),
    Env("notify_webhook", "url"),
)

FEED_STRIP = tuple(sorted(set(VOLATILE_KEYS) | {
    "last_row_count", "last_execution_id", "next_run_at", "run_count", "apscheduler_job_id",
    "template_id", "template_member_key", "created_by", "created_at", "updated_at"}))


def body_ids_to_names(session, body: dict, registry, *, who: str, deps: list, env_refs: list,
                      prefix: str = "") -> dict:
    """A feed body (a feed_configs row or a template's ``definition.feed``)
    with every id reference replaced by the referenced object's key."""
    out = dict(body)
    for col, ref in FEED_BODY_REFS.items():
        if col not in out:
            continue
        if ref.by == "key":
            if out[col] not in (None, ""):
                deps.append((ref.kind, str(out[col])))
            continue
        rid = out.pop(col)
        name = None
        if rid not in (None, 0, "", "None"):
            if isinstance(rid, str) and not rid.isdigit():
                # a template may already hold a NAME (a group rule renders one)
                name = rid
            else:
                name = resolve_name(session, ref.kind, int(rid), registry)
                if name is None:
                    raise ReleaseRefusal(f"{who}: {col} references {ref.kind} id {rid} which does "
                                         f"not exist (unknown != empty)", path=f"{prefix}{col}")
        out[ref.name] = name
        if name is not None:
            (env_refs if ref.environment else deps).append(
                {"kind": ref.kind, "name": name, "path": f"{prefix}{ref.name}"} if ref.environment
                else (ref.kind, name))
    # the polymorphic source
    stype = out.get("source_type")
    sid = out.pop("source_id", None)
    skind = SOURCE_KINDS.get(str(stype or ""))
    if skind and sid not in (None, 0, "", "None"):
        if isinstance(sid, str) and not sid.isdigit():
            sname = sid
        else:
            if registry.get(skind) is None:
                raise ReleaseRefusal(f"{who}: source_type {stype!r} names a {skind}, a type this build "
                                     f"cannot release yet -- the feed cannot travel without its source",
                                     path=f"{prefix}source_id")
            sname = resolve_name(session, skind, int(sid), registry)
            if sname is None:
                raise ReleaseRefusal(f"{who}: source {skind} id {sid} does not exist",
                                     path=f"{prefix}source_id")
        out["source"] = sname
        deps.append((skind, sname))
    else:
        out["source"] = None
    # consumer groups: a list of user_group ids -> names
    cg = out.pop("consumer_group_ids", None)
    if cg:
        names = []
        for gid in cg:
            n = resolve_name(session, "user_group", int(gid), registry) if str(gid).isdigit() else str(gid)
            if n is None:
                raise ReleaseRefusal(f"{who}: consumer group id {gid} does not exist", path=f"{prefix}consumer_group_ids")
            names.append(n)
            deps.append(("user_group", n))
        out["consumer_groups"] = sorted(names)
    return out


def body_names_to_ids(session, body: dict, registry, *, who: str) -> dict:
    """The inverse, in the TARGET: every name back to the target's id.  A
    name the target lacks is a refusal (the preview said so already)."""
    out = dict(body)
    for col, ref in FEED_BODY_REFS.items():
        if ref.by == "key":
            continue
        if ref.name not in out:
            continue
        name = out.pop(ref.name)
        rid = None
        if name not in (None, ""):
            rid = resolve_id(session, ref.kind, name, registry)
            if rid is None:
                raise ReleaseRefusal(f"{who}: {ref.kind} {name!r} is not in the target", path=col)
        out[col] = rid
    stype = out.get("source_type")
    sname = out.pop("source", None)
    skind = SOURCE_KINDS.get(str(stype or ""))
    if skind and sname not in (None, ""):
        rid = resolve_id(session, skind, sname, registry)
        if rid is None:
            raise ReleaseRefusal(f"{who}: source {skind} {sname!r} is not in the target", path="source")
        out["source_id"] = rid
    else:
        out.setdefault("source_id", 0)
    groups = out.pop("consumer_groups", None)
    if groups is not None:
        ids = []
        for n in groups:
            gid = resolve_id(session, "user_group", n, registry)
            if gid is None:
                raise ReleaseRefusal(f"{who}: consumer group {n!r} is not in the target", path="consumer_groups")
            ids.append(gid)
        out["consumer_group_ids"] = ids
    return out


def _dependency_rows(session, etl_id: int, registry, deps: list) -> list[dict]:
    rows = (session.query(EtlDependencyMapping)
            .filter(EtlDependencyMapping.etl_id == int(etl_id)).all())
    out = []
    for r in sorted(rows, key=lambda r: (str(r.dependency_type_id), str(r.dependency_key))):
        tname = resolve_name(session, "dependency_type", r.dependency_type_id, registry)
        if tname is None:
            raise ReleaseRefusal(f"dependency mapping {r.dependency_key!r} names dependency type id "
                                 f"{r.dependency_type_id} which does not exist")
        deps.append(("dependency_type", tname))
        if r.calendar_name:
            deps.append(("calendar", str(r.calendar_name)))
        out.append({
            "dependency_type": tname, "dependency_key": r.dependency_key,
            "description": r.description, "calendar_name": r.calendar_name,
            "expected_rows": r.expected_rows, "arrival_sources": r.arrival_sources,
            "require_mode": r.require_mode, "certifies_side": r.certifies_side,
            "reruns_delivered": r.reruns_delivered, "is_active": r.is_active,
        })
    return out


def _apply_dependency_rows(session, etl_id: int, defs: list[dict], registry) -> None:
    existing = {(str(r.dependency_type_id), str(r.dependency_key)): r
                for r in session.query(EtlDependencyMapping)
                .filter(EtlDependencyMapping.etl_id == int(etl_id)).all()}
    seen = set()
    for d in defs:
        tid = resolve_id(session, "dependency_type", d["dependency_type"], registry)
        if tid is None:
            raise ReleaseRefusal(f"dependency type {d['dependency_type']!r} is not in the target")
        k = (str(tid), str(d["dependency_key"]))
        seen.add(k)
        cols = {kk: vv for kk, vv in d.items() if kk != "dependency_type"}
        cols["dependency_type_id"] = tid
        row = existing.get(k)
        if row is None:
            session.add(EtlDependencyMapping(etl_id=int(etl_id), **cols))
        else:
            for kk, vv in cols.items():
                setattr(row, kk, vv)
    for k, row in existing.items():
        if k not in seen:
            session.delete(row)
    session.flush()


def _probe_destination(dtype: str | None, cfg: dict | None) -> dict:
    """A reachability probe for the destination: ok / failed / unknown."""
    cfg = cfg or {}
    if dtype == "sftp" and cfg.get("host"):
        host, port = str(cfg["host"]), int(cfg.get("port") or 22)
        try:
            with socket.create_connection((host, port), timeout=3):
                return {"check": f"sftp {host}:{port} reachable", "ok": True}
        except OSError as exc:
            return {"check": f"sftp {host}:{port} reachable", "ok": False, "error": str(exc)}
    if dtype == "local":
        return {"check": "local destination", "ok": True}
    return {"check": f"destination {dtype}", "ok": None, "note": "no probe for this destination type"}


class FeedType(ReleasableType):
    kind = "feed"
    model = FeedConfig
    key = ("name",)
    phase = 1
    env = FEED_ENV
    strip = FEED_STRIP
    also_carries = ("etl_dependency_mappings",)
    #: ``token_bindings`` binds SQL literals to {TOKEN}s (core/feed/sql_tokens.py)
    #: -- vocabulary the heuristic flags, not a credential
    not_secret = ("token_bindings",)

    @staticmethod
    def row_filter(row) -> bool:            # template MEMBERS are derived
        return getattr(row, "template_id", None) is None

    def export_row(self, session, row, registry) -> Item:
        d = self._columns(row, strip=self.strip)
        deps: list = []
        env_refs: list = []
        d = body_ids_to_names(session, d, registry, who=f"feed {row.name!r}", deps=deps,
                              env_refs=env_refs)
        from core.feed.etl_dependency import effective_etl_id
        d["dependencies"] = _dependency_rows(session, effective_etl_id({"id": row.id, "etl_id": row.etl_id}),
                                             registry, deps)
        clean, _ = scrub_secrets(d, secret_columns={"destination_config", "delivery_chain", "backend_config"},
                                 secret_paths=(), not_secret=self.not_secret, kind=self.kind, key=str(row.name))
        env_fields = pop_env_fields(clean, self.env)
        definition = normalize(clean)
        return Item(kind=self.kind, key=str(row.name), definition=definition,
                    environment_fields=normalize(env_fields), environment_refs=env_refs,
                    dependencies=sorted({(k, v) for k, v in deps}), hash=item_hash(definition))

    def resolve(self, session, item, mapping, registry, in_package) -> dict:
        out: dict = {"refs": {}, "env": {}, "missing": []}
        d = item.definition
        for col, ref in FEED_BODY_REFS.items():
            if ref.by == "key":
                val = d.get(col)
                if val in (None, "") or (ref.kind, str(val)) in in_package:
                    continue
                if resolve_id(session, ref.kind, str(val), registry) is None:
                    out["missing"].append({"what": "dependency", "kind": ref.kind, "key": str(val), "path": col,
                                           "reason": f"{ref.kind} {val!r} is neither in the package nor in the target"})
                continue
            name = d.get(ref.name)
            if name in (None, ""):
                continue
            if ref.environment:
                target = mapping.lookup(ref.kind, name) or name
                rid = resolve_id(session, ref.kind, target, registry)
                if rid is None:
                    out["missing"].append({"what": "environment_ref", "kind": ref.kind, "name": name,
                                           "mapped_to": target, "path": ref.name,
                                           "reason": f"connection {target!r} does not exist in the target "
                                                     f"(map {name!r} to one that does)"})
                else:
                    out["refs"][ref.name] = rid
            elif (ref.kind, name) not in in_package and resolve_id(session, ref.kind, name, registry) is None:
                out["missing"].append({"what": "dependency", "kind": ref.kind, "key": name, "path": ref.name,
                                       "reason": f"{ref.kind} {name!r} is neither in the package nor in the target"})
        skind = SOURCE_KINDS.get(str(d.get("source_type") or ""))
        sname = d.get("source")
        if skind and sname and (skind, sname) not in in_package and resolve_id(session, skind, sname, registry) is None:
            out["missing"].append({"what": "dependency", "kind": skind, "key": sname, "path": "source",
                                   "reason": f"{skind} {sname!r} is neither in the package nor in the target"})
        for dep in d.get("dependencies") or []:
            t = dep.get("dependency_type")
            if t and ("dependency_type", t) not in in_package and resolve_id(session, "dependency_type", t, registry) is None:
                out["missing"].append({"what": "dependency", "kind": "dependency_type", "key": t,
                                       "path": "dependencies", "reason": f"dependency_type {t!r} is neither in the package nor in the target"})
        for cpath, ef in (item.environment_fields or {}).items():
            mapped = mapping.lookup(ef.get("kind"), ef.get("value"))
            if mapped is None:
                out["missing"].append({"what": "environment_field", "path": cpath, "mapping_kind": ef.get("kind"),
                                       "value": ef.get("value"),
                                       "reason": f"no release mapping of kind {ef.get('kind')!r} for {ef.get('value')!r}"})
            else:
                out["env"][cpath] = mapped
        return out

    def apply(self, session, item, resolved, existing, *, keep_fields, actor, registry):
        definition = copy.deepcopy(item.definition)
        dep_defs = definition.pop("dependencies", []) or []
        # connection names may have been MAPPED: substitute before resolving
        for ref_name in ("connection", "secondary_connection"):
            rid = (resolved.get("refs") or {}).get(ref_name)
            if rid is not None and definition.get(ref_name):
                from core.db.models import Connection
                row = session.query(Connection).filter(Connection.id == rid).first()
                definition[ref_name] = row.name if row else definition[ref_name]
        cols = body_names_to_ids(session, definition, registry, who=f"feed {item.key!r}")
        cols = self._coerce_columns(FeedConfig, cols)
        if existing is None:
            for cpath, value in (resolved.get("env") or {}).items():
                set_path(cols, cpath, value)
            cols["created_by"] = actor
            row = FeedConfig(**cols)
            session.add(row)
            session.flush()
            action = "created"
        else:
            row = existing
            for col, value in cols.items():
                if col in keep_fields or col == "name":
                    continue
                current = getattr(row, col, None)
                if isinstance(value, (dict, list)) and isinstance(current, (dict, list)):
                    value = self._keep_env_paths(col, value, current) if isinstance(value, dict) else value
                    if col == "delivery_chain":
                        value = self._keep_chain_env(value, current)
                if hasattr(row, col):
                    setattr(row, col, value)
            action = "updated"
        session.flush()
        from core.feed.etl_dependency import effective_etl_id
        if "dependencies" not in keep_fields:
            _apply_dependency_rows(session, effective_etl_id({"id": row.id, "etl_id": row.etl_id}),
                                   dep_defs, registry)
        return int(row.id), action

    @staticmethod
    def _keep_chain_env(incoming: list, current: list) -> list:
        """PROD's hop hosts/paths stay on an update (hops matched by label)."""
        cur = {h.get("label"): h for h in current if isinstance(h, dict)}
        out = []
        for hop in incoming:
            if not isinstance(hop, dict):
                out.append(hop)
                continue
            c = cur.get(hop.get("label"))
            if c and isinstance(c.get("config"), dict):
                merged = dict(hop.get("config") or {})
                for k in ("host", "username", "remote_dir", "bucket", "prefix", "password",
                          "private_key", "host_key_b64"):
                    if k in c["config"]:
                        merged[k] = c["config"][k]
                hop = dict(hop, config=merged)
            out.append(hop)
        return out

    def verify(self, db, session, object_id, registry) -> Verdict:
        row = session.query(FeedConfig).filter(FeedConfig.id == object_id).first()
        if row is None:
            return Verdict("failed", f"feed id {object_id} is not in the target after apply")
        checks = []
        from core.db.models import Connection
        for col in ("connection_id", "secondary_connection_id"):
            cid = getattr(row, col)
            if cid:
                c = session.query(Connection).filter(Connection.id == int(cid)).first()
                checks.append({"check": f"{col} -> connection {cid}", "ok": bool(c and c.is_active),
                               "name": c.name if c else None})
        skind = SOURCE_KINDS.get(str(row.source_type or ""))
        if skind and row.source_id:
            name = resolve_name(session, skind, row.source_id, registry) if registry.get(skind) else None
            checks.append({"check": f"source {skind} {row.source_id}", "ok": name is not None, "name": name})
            if skind == "sql_file" and name is not None:
                sv = registry.require("sql_file").verify(db, session, int(row.source_id), registry)
                checks.extend(sv.checks)
        if row.calendar_name:
            checks.append({"check": f"calendar {row.calendar_name!r}", "ok":
                           resolve_id(session, "calendar", row.calendar_name, registry) is not None})
        if row.control_file_format_id:
            checks.append({"check": "control file format", "ok":
                           resolve_name(session, "control_file_format", row.control_file_format_id, registry) is not None})
        probe = _probe_destination(row.destination_type, row.destination_config)
        checks.append(probe)
        failed = [c for c in checks if c.get("ok") is False]
        unknown = [c for c in checks if c.get("ok") is None]
        if failed:
            return Verdict("failed", "; ".join(c["check"] for c in failed), checks)
        if unknown:
            return Verdict("unknown", "; ".join(c["check"] for c in unknown), checks)
        return Verdict("ok", "", checks)


REGISTRY.register(FeedType())


# ── feed templates: members DERIVED ───────────────────────────────────────

class FeedTemplateType(ReleasableType):
    kind = "feed_template"
    model = FeedTemplate
    key = ("name",)
    phase = 1
    strip = ("definition_hash", "last_applied_at", "last_apply_report", "apply_job_id", "apply_status")
    env = tuple(Env("definition.feed." + e.path, e.mapping) for e in FEED_ENV)
    not_secret = ("token_bindings",)

    def export_row(self, session, row, registry) -> Item:
        d = self._columns(row, strip=self.strip)
        deps: list = []
        env_refs: list = []
        definition = copy.deepcopy(d.get("definition") or {})
        feed_body = definition.get("feed") or {}
        definition["feed"] = body_ids_to_names(session, feed_body, registry, who=f"feed_template {row.name!r}",
                                               deps=deps, env_refs=env_refs, prefix="definition.feed.")
        rendered_deps = []
        for dep in definition.get("dependencies") or []:
            dep = dict(dep)
            tid = dep.pop("dependency_type_id", None)
            if tid is not None and not dep.get("dependency_type"):
                tname = resolve_name(session, "dependency_type", int(tid), registry)
                if tname is None:
                    raise ReleaseRefusal(f"feed_template {row.name!r}: dependency type id {tid} does not exist")
                dep["dependency_type"] = tname
            if dep.get("dependency_type") and "{" not in str(dep["dependency_type"]):
                deps.append(("dependency_type", str(dep["dependency_type"]).upper()))
            if dep.get("calendar_name") and "{" not in str(dep["calendar_name"]):
                deps.append(("calendar", str(dep["calendar_name"])))
            rendered_deps.append(dep)
        definition["dependencies"] = rendered_deps
        d["definition"] = definition
        members = session.query(FeedConfig).filter(FeedConfig.template_id == row.id).count()
        clean, _ = scrub_secrets(d, secret_columns={"definition"}, secret_paths=(), not_secret=self.not_secret,
                                 kind=self.kind, key=str(row.name))
        env_fields = pop_env_fields(clean, self.env)
        norm = normalize(clean)
        return Item(kind=self.kind, key=str(row.name), definition=norm,
                    environment_fields=normalize(env_fields), environment_refs=env_refs,
                    dependencies=sorted({(k, v) for k, v in deps}), hash=item_hash(norm),
                    extra={"members": "derived", "member_count": members})

    def resolve(self, session, item, mapping, registry, in_package) -> dict:
        body = (item.definition.get("definition") or {}).get("feed") or {}
        proxy = Item(kind="feed", key=item.key, definition=dict(body, dependencies=[]),
                     environment_fields=item.environment_fields)
        out = registry.require("feed").resolve(session, proxy, mapping, registry, in_package)
        for dep in (item.definition.get("definition") or {}).get("dependencies") or []:
            t = dep.get("dependency_type")
            if t and "{" not in str(t) and ("dependency_type", str(t).upper()) not in in_package \
                    and resolve_id(session, "dependency_type", str(t).upper(), registry) is None:
                out["missing"].append({"what": "dependency", "kind": "dependency_type", "key": t,
                                       "path": "definition.dependencies",
                                       "reason": f"dependency_type {t!r} is neither in the package nor in the target"})
        return out

    def apply(self, session, item, resolved, existing, *, keep_fields, actor, registry):
        d = copy.deepcopy(item.definition)
        if existing is None:
            # environment fields of a NEW template come from the mapping
            for cpath, value in (resolved.get("env") or {}).items():
                set_path(d, cpath, value)
        definition = d.get("definition") or {}
        body = dict(definition.get("feed") or {})
        for ref_name in ("connection", "secondary_connection"):
            rid = (resolved.get("refs") or {}).get(ref_name)
            if rid is not None and body.get(ref_name):
                from core.db.models import Connection
                row = session.query(Connection).filter(Connection.id == rid).first()
                body[ref_name] = row.name if row else body[ref_name]
        body = body_names_to_ids(session, body, registry, who=f"feed_template {item.key!r}")
        body.pop("source_id", None) if not body.get("source_id") else None
        definition["feed"] = body
        d["definition"] = definition
        if existing is None:
            d["created_by"] = actor
            row = FeedTemplate(**d)
            session.add(row)
            session.flush()
            action = "created"
        else:
            row = existing
            if "definition" not in keep_fields:
                cur = existing.definition or {}
                cur_body = (cur.get("feed") or {})
                merged = self._keep_env_paths("definition", d["definition"], cur) if isinstance(cur, dict) else d["definition"]
                for k in ("password", "private_key", "host_key_b64", "passphrase"):
                    dc = (cur_body.get("destination_config") or {})
                    if k in dc:
                        merged.setdefault("feed", {}).setdefault("destination_config", {})[k] = dc[k]
                row.definition = merged
            for col in ("description", "parameters", "matrix", "is_active", "auto_onboard"):
                if col in d and col not in keep_fields:
                    setattr(row, col, d[col])
            action = "updated"
        # the hash the template routes keep (api/feed_template_api._hash)
        import hashlib as _h
        import json as _j
        row.definition_hash = _h.sha256(_j.dumps(
            {"parameters": row.parameters, "definition": row.definition, "matrix": row.matrix},
            sort_keys=True, default=str).encode("utf-8")).hexdigest()
        session.flush()
        return int(row.id), action

    def verify(self, db, session, object_id, registry) -> Verdict:
        row = session.query(FeedTemplate).filter(FeedTemplate.id == object_id).first()
        if row is None:
            return Verdict("failed", f"feed_template id {object_id} is not in the target after apply")
        body = (row.definition or {}).get("feed") or {}
        checks = []
        from core.db.models import Connection
        for col in ("connection_id", "secondary_connection_id"):
            cid = body.get(col)
            if cid:
                c = session.query(Connection).filter(Connection.id == int(cid)).first()
                checks.append({"check": f"{col} -> connection {cid}", "ok": bool(c and c.is_active)})
        skind = SOURCE_KINDS.get(str(body.get("source_type") or ""))
        if skind and body.get("source_id") and registry.get(skind):
            checks.append({"check": f"source {skind} {body['source_id']}", "ok":
                           resolve_name(session, skind, body["source_id"], registry) is not None})
        members = session.query(FeedConfig).filter(FeedConfig.template_id == row.id).count()
        matrix = row.matrix or []
        checks.append({"check": f"members rendered ({members} of {len(matrix)} matrix rows)",
                       "ok": True if members >= len(matrix) else None,
                       "note": None if members >= len(matrix) else "the member walk runs after the release transaction"})
        failed = [c for c in checks if c.get("ok") is False]
        if failed:
            return Verdict("failed", "; ".join(c["check"] for c in failed), checks)
        if any(c.get("ok") is None for c in checks):
            return Verdict("unknown", "members not yet rendered", checks)
        return Verdict("ok", "", checks)


REGISTRY.register(FeedTemplateType())


# ── scoped rows: (scope, scope_id) -> (scope, the scoped object's key) ─────

SCOPE_KINDS = {"feed": "feed", "feed_group": "feed_group", "template": "feed_template", "global": None}


class ScopedType(DeclaredType):
    """Restatement policies, alert routes, hold approvers: a row mapped at a
    scope.  ``scope_id`` travels as ``scope_ref`` (the scoped object's key)."""

    def __init__(self, *, kind, model, extra_key: tuple[str, ...] = (), refs=None, env=(),
                 strip=(), upsert_cols: tuple[str, ...] = ()):
        super().__init__(kind=kind, model=model, key=("scope", "scope_ref") + extra_key,
                         refs=refs, env=env, strip=strip)
        self.upsert_cols = upsert_cols

    def row_key(self, row) -> str:
        from sqlalchemy.orm import object_session
        parts = [str(row.scope), self._scope_ref_of_row(row) or ""]
        for c in self.key[2:]:
            val = getattr(row, c)
            ref = self.refs.get(c)
            if ref is not None and ref.by == "id" and val not in (None, ""):
                name = resolve_name(object_session(row), ref.kind, int(val), REGISTRY)
                if name is None:
                    raise ReleaseRefusal(f"{self.kind}: {c} references {ref.kind} id {val} which does not exist",
                                         kind=self.kind)
                val = name
            parts.append(str(val))
        return "|".join(parts)

    def _scope_ref_of_row(self, row) -> Optional[str]:
        from sqlalchemy.orm import object_session
        session = object_session(row)
        skind = SCOPE_KINDS.get(str(row.scope))
        if skind is None or row.scope_id is None:
            return None
        name = resolve_name(session, skind, int(row.scope_id), REGISTRY)
        if name is None:
            raise ReleaseRefusal(f"{self.kind}: scope {row.scope} id {row.scope_id} does not exist",
                                 kind=self.kind)
        return name

    def find_row(self, session, key: str):
        parts = key.split("|")
        if len(parts) != len(self.key):
            return None
        scope, scope_ref = parts[0], parts[1]
        q = session.query(self.model).filter(self.model.scope == scope)
        skind = SCOPE_KINDS.get(scope)
        if skind is None or not scope_ref:
            q = q.filter(self.model.scope_id.is_(None))
        else:
            sid = resolve_id(session, skind, scope_ref, REGISTRY)
            if sid is None:
                return None
            q = q.filter(self.model.scope_id == sid)
        for col, val in zip(self.key[2:], parts[2:]):
            column = getattr(self.model, col)
            ref = self.refs.get(col)
            if ref is not None and ref.by == "id" and val not in ("None", ""):
                rid = resolve_id(session, ref.kind, val, REGISTRY)
                if rid is None:
                    return None
                q = q.filter(column == rid)
                continue
            q = q.filter(column.is_(None) if val == "None" else column == self._coerce(column, val))
        return q.first()

    def export_row(self, session, row, registry) -> Item:
        d = self._columns(row, strip=self.strip + ("scope_id",))
        d["scope_ref"] = self._scope_ref_of_row(row)
        deps: list = []
        env_refs: list = []
        skind = SCOPE_KINDS.get(str(row.scope))
        if skind and d["scope_ref"]:
            deps.append((skind, d["scope_ref"]))
        self._refs_to_names(session, d, self.refs, registry, deps, env_refs, prefix="")
        key = self.row_key(row)
        clean, _ = scrub_secrets(d, secret_columns=set(), secret_paths=self.secret_paths,
                                 not_secret=self.not_secret, kind=self.kind, key=key)
        env_fields = pop_env_fields(clean, self.env)
        definition = normalize(clean)
        return Item(kind=self.kind, key=key, definition=definition, environment_fields=normalize(env_fields),
                    environment_refs=env_refs, dependencies=sorted({(k, v) for k, v in deps}),
                    hash=item_hash(definition))

    def resolve(self, session, item, mapping, registry, in_package) -> dict:
        out = super().resolve(session, item, mapping, registry, in_package)
        scope, ref = item.definition.get("scope"), item.definition.get("scope_ref")
        skind = SCOPE_KINDS.get(str(scope))
        if skind and ref and (skind, ref) not in in_package and resolve_id(session, skind, ref, registry) is None:
            out["missing"].append({"what": "dependency", "kind": skind, "key": ref, "path": "scope_ref",
                                   "reason": f"{skind} {ref!r} is neither in the package nor in the target"})
        return out

    def apply(self, session, item, resolved, existing, *, keep_fields, actor, registry):
        d = copy.deepcopy(item.definition)
        scope, ref = d.get("scope"), d.pop("scope_ref", None)
        skind = SCOPE_KINDS.get(str(scope))
        sid = None
        if skind and ref:
            sid = resolve_id(session, skind, ref, registry)
            if sid is None:
                raise ReleaseRefusal(f"{self.kind}: scope {scope} {ref!r} is not in the target", kind=self.kind)
        cols = self._to_columns(session, d, self.refs, resolved, registry, prefix="")
        cols["scope_id"] = sid
        for cpath, value in (resolved.get("env") or {}).items():
            if existing is None:
                set_path(cols, cpath, value)
        if existing is None:
            if "created_by" in self.model.__table__.columns:
                cols["created_by"] = actor
            row = self.model(**cols)
            session.add(row)
            session.flush()
            return int(row.id), "created"
        for col, value in cols.items():
            if col in keep_fields or col in ("scope", "scope_id"):
                continue
            if hasattr(existing, col):
                setattr(existing, col, value)
        if "updated_by" in self.model.__table__.columns:
            existing.updated_by = actor
        session.flush()
        return int(existing.id), "updated"


REGISTRY.register(ScopedType(kind="restatement_policy", model=FeedRestatementPolicy))
REGISTRY.register(ScopedType(kind="hold_approver", model=FeedHoldApprover,
                             extra_key=("user_group_id",),
                             refs={"user_group_id": Ref("user_group")}))


class AlertRouteType(ScopedType):
    """Routes: the target (an address, a username, ``group:<name>``) is
    environment-specific -- MAPPED when the target environment declares a
    mapping (kind ``email`` / ``user``), copied otherwise (an address is not
    a credential).  The row's identity includes its target."""

    def __init__(self):
        super().__init__(kind="alert_route", model=FeedAlertRoute, extra_key=("kind", "channel", "target"))

    def apply(self, session, item, resolved, existing, *, keep_fields, actor, registry):
        d = item.definition
        mapping_kind = "email" if d.get("channel") == "email" else "user"
        mapped = (resolved.get("env") or {}).get("target")
        if mapped is not None and mapped != d.get("target"):
            item = copy.deepcopy(item)
            item.definition["target"] = mapped
            existing = self.find_row(session, "|".join(
                [str(d.get("scope")), d.get("scope_ref") or "", str(d.get("kind")), str(d.get("channel")), str(mapped)]))
        return super().apply(session, item, resolved, existing, keep_fields=keep_fields, actor=actor,
                             registry=registry)

    def resolve(self, session, item, mapping, registry, in_package) -> dict:
        out = super().resolve(session, item, mapping, registry, in_package)
        d = item.definition
        mapped = mapping.lookup("email" if d.get("channel") == "email" else "user", d.get("target"))
        if mapped is not None:
            out["env"]["target"] = mapped
        return out

    def effective(self, item, mapping):
        out = super().effective(item, mapping)
        d = out.definition
        mapped = mapping.lookup("email" if d.get("channel") == "email" else "user", d.get("target"))
        if mapped is not None and mapped != d.get("target"):
            d["target"] = mapped
            out.key = "|".join([str(d.get("scope")), d.get("scope_ref") or "", str(d.get("kind")),
                                str(d.get("channel")), str(mapped)])
            out.hash = item_hash(d)
        return out


REGISTRY.register(AlertRouteType())

#: kinds whose rows ATTACH to a feed / group / template: selecting the
#: object pulls them in (reverse closure)
ATTACHED_KINDS = ("restatement_policy", "alert_route", "hold_approver")
