"""The release engine: export, upload, preview, decide, approve, apply,
verify, rollback -- over the DB seam, ONE transaction per apply
(docs/RELEASE_CONFIG_DESIGN_2026_10_17.html §3).

Every operation is a value or a ``ReleaseRefusal`` that names the object:
nothing here is a silent skip, and nothing here is reachable from the run
path (a release is a CHANGE).
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Callable, Optional

from core.release import diff as diffmod
from core.release import package as pkgmod
from core.release.contract import Item, Mapping, ReleaseRefusal, Verdict
from core.release.registry import kinds_in_order, load

logger = logging.getLogger(__name__)

_MISSING = object()

#: states from which an apply may start / a rollback may start
APPLY_FROM = ("approved",)
ROLLBACK_FROM = ("applied", "verified", "applied_unverified")


# ── config (every key here IS read) ─────────────────────────────────────

def gov_cfg() -> dict:
    from core import config as _config
    return _config.get("feed_generation", "governance", {}) or {}


def release_cfg() -> dict:
    rel = dict(gov_cfg().get("release") or {})
    rel.setdefault("four_eyes_environments", ["prod"])
    rel.setdefault("require_ticket_environments", ["prod"])
    rel.setdefault("verify", {"on_failure": "hold"})
    rel.setdefault("first_release_overwrites", False)
    rel.setdefault("max_package_mb", 64)
    return rel


def this_environment() -> str:
    return str(gov_cfg().get("environment") or "dev")


def git_truth_environments() -> list[str]:
    return list(gov_cfg().get("git_truth_environments", ["prod"]) or [])


def _audit(db, actor: Optional[str], action: str, release_id: Optional[int], details: dict) -> None:
    try:
        from core.audit import audit_event
        audit_event(db, {"username": actor or "system"}, None, action, "config_release",
                    release_id, details)
    except Exception:  # noqa: BLE001 -- audit is fire-and-forget by contract
        logger.exception("[release] audit of %s failed", action)


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ── export ─────────────────────────────────────────────────────────────────

def _area_kinds(registry, area: str) -> list[str]:
    phases = {"feedgen": 1, "reports": 2, "published": 3, "dashboards": 4}
    if area not in phases:
        raise ReleaseRefusal(f"unknown area {area!r} -- one of {sorted(phases)}")
    return [t.kind for t in registry.types() if t.phase == phases[area]]


def _problem(exc: ReleaseRefusal, kind: str | None = None, key: str | None = None) -> dict:
    return {"kind": exc.kind or kind, "key": exc.key or key, "path": exc.path, "reason": str(exc)}


def closure(session, registry, scope: dict) -> tuple[list[Item], list[dict], list[dict]]:
    """The selected objects plus everything they depend on (forward) and
    everything attached to them (policies, routes, approvers -- reverse).

    Returns ``(items, problems, excluded)``.  EVERY object that cannot be
    exported is a problem ``{kind, key, path, reason}`` and the walk goes on
    -- a real UAT always has stale objects, and an export that stopped at
    the first one taught them to the operator one export at a time.
    ``scope["exclude"]`` (``[{kind, key, reason?}]``) leaves an object out
    DELIBERATELY: it is recorded in ``excluded`` with its reason (the package
    carries the list; the target's preview shows it); an object whose
    dependency is excluded is itself a problem (no silent hole); an exclusion
    naming an object this environment does not have is a problem too (a typo
    is not an exclusion).
    """
    from core.release.types.feedgen import ATTACHED_KINDS
    kind = str(scope.get("kind") or "everything")
    with_deps = bool(scope.get("with_dependencies", True))
    selected: dict[tuple[str, str], Item] = {}
    problems: list[dict] = []
    seen_problem: set[tuple] = set()
    worklist: list[tuple[str, str]] = []
    exclude: dict[tuple[str, str], str] = {}
    for ex in scope.get("exclude") or []:
        k, key = str((ex or {}).get("kind") or ""), str((ex or {}).get("key") or "")
        if registry.get(k) is None:
            problems.append({"kind": k, "key": key, "path": "exclude",
                             "reason": f"exclude names an unknown object type {k!r}"})
            continue
        if registry.require(k).find_row(session, key) is None:
            problems.append({"kind": k, "key": key, "path": "exclude",
                             "reason": f"exclude names {k} {key!r}, which is not in this environment"})
            continue
        exclude[(k, key)] = str((ex or {}).get("reason") or "excluded by the operator")
    excluded: list[dict] = []

    def _record(exc: ReleaseRefusal, k=None, key=None):
        d = _problem(exc, k, key)
        sig = (d["kind"], d["key"], d["path"], d["reason"])
        if sig not in seen_problem:
            seen_problem.add(sig)
            problems.append(d)

    def _take(k: str, key: str, item: Item | None) -> None:
        if (k, key) in exclude:
            if not any(e["kind"] == k and e["key"] == key for e in excluded):
                excluded.append({"kind": k, "key": key, "reason": exclude[(k, key)]})
            return
        if item is not None:
            selected[(k, key)] = item

    def _export_row(t, row):
        try:
            return t.export_row(session, row, registry)
        except ReleaseRefusal as exc:
            _record(exc, t.kind, t.row_key(row) if not exc.key else None)
            return None

    def _export(k: str, key: str) -> Item | None:
        t = registry.require(k)
        row = t.find_row(session, key)
        if row is None:
            _record(ReleaseRefusal(f"{k} {key!r} is not in this environment", kind=k, key=key))
            return None
        return _export_row(t, row)

    def _rows_of(t):
        for row in t.rows(session):
            try:
                rk = t.row_key(row)
            except ReleaseRefusal as exc:
                _record(exc, t.kind, None)
                continue
            if (t.kind, rk) in exclude:
                _take(t.kind, rk, None)
                continue
            item = _export_row(t, row)
            if item is not None:
                selected[(t.kind, item.key)] = item

    if kind == "everything":
        for t in registry.types():
            _rows_of(t)
    elif kind == "area":
        for k in _area_kinds(registry, str(scope.get("area") or "")):
            _rows_of(registry.require(k))
        if with_deps:                       # an area's objects pull what they name from OTHER areas
            for item in list(selected.values()):
                worklist.extend(tuple(d) for d in item.dependencies if tuple(d) not in selected)
    else:
        registry.require(kind)
        keys = [str(k) for k in (scope.get("keys") or [])]
        if not keys:
            raise ReleaseRefusal(f"scope {kind!r} names no keys")
        worklist.extend((kind, k) for k in keys)
        if kind == "feed_group":
            from core.db.models import FeedConfig, FeedTemplate
            for gkey in keys:
                grow = registry.require("feed_group").find_row(session, gkey)
                if grow is None:
                    raise ReleaseRefusal(f"feed_group {gkey!r} is not in this environment",
                                         kind="feed_group", key=gkey)
                members = session.query(FeedConfig).filter(FeedConfig.feed_group_id == grow.id).all()
                for f in members:
                    if f.template_id is None:
                        worklist.append(("feed", str(f.name)))
                    else:
                        t = session.query(FeedTemplate).filter(FeedTemplate.id == f.template_id).first()
                        if t is not None:
                            worklist.append(("feed_template", str(t.name)))
                # templates whose body names the group (by id or by the group RULE)
                for t in session.query(FeedTemplate).all():
                    body = ((t.definition or {}).get("feed") or {})
                    if body.get("feed_group_id") == grow.id or body.get("feed_group_name") == gkey:
                        worklist.append(("feed_template", str(t.name)))
    visited: set[tuple[str, str]] = set()
    while worklist:
        k, key = worklist.pop()
        if (k, key) in selected or (k, key) in visited:
            continue
        visited.add((k, key))
        if (k, key) in exclude:
            _take(k, key, None)
            continue
        item = _export(k, key)
        if item is None:
            continue
        selected[(k, key)] = item
        if with_deps:
            worklist.extend(tuple(d) for d in item.dependencies if tuple(d) not in selected)
    if with_deps and kind != "everything":
        changed = True
        while changed:
            changed = False
            for ak in ATTACHED_KINDS:
                t = registry.get(ak)
                if t is None:
                    continue
                for row in t.rows(session):
                    try:
                        rk = t.row_key(row)
                    except ReleaseRefusal as exc:
                        _record(exc, ak, None)
                        continue
                    if (ak, rk) in selected or (ak, rk) in visited:
                        continue
                    item = _export_row(t, row)
                    if item is None:
                        visited.add((ak, rk))
                        continue
                    if any(tuple(d) in selected or tuple(d) in exclude for d in item.dependencies):
                        visited.add((ak, rk))
                        if (ak, rk) in exclude:
                            _take(ak, rk, None)
                            continue
                        selected[(ak, rk)] = item
                        changed = True
                        for d in item.dependencies:
                            if tuple(d) not in selected and tuple(d) not in exclude and tuple(d) not in visited:
                                visited.add(tuple(d))
                                dep = _export(*d)
                                if dep is not None:
                                    selected[tuple(d)] = dep
    # an object whose dependency is EXCLUDED is refused -- never a silent hole
    for (k, key), item in list(selected.items()):
        for d in item.dependencies:
            if tuple(d) in exclude:
                _record(ReleaseRefusal(
                    f"{k} {key!r} depends on {d[0]} {d[1]!r}, which is excluded ({exclude[tuple(d)]}) -- "
                    f"exclude it too, or do not exclude its dependency", kind=k, key=key, path=f"{d[0]}:{d[1]}"))
                selected.pop((k, key), None)
                break
    # every exclusion the operator named is RECORDED, reached by the walk or not
    # (the target's preview shows what was deliberately left out)
    for (k, key), reason in exclude.items():
        if not any(e["kind"] == k and e["key"] == key for e in excluded):
            excluded.append({"kind": k, "key": key, "reason": reason})
    problems.sort(key=lambda p: (str(p.get("kind")), str(p.get("key")), str(p.get("path"))))
    excluded.sort(key=lambda e: (e["kind"], e["key"]))
    return list(selected.values()), problems, excluded


def export_package(db, *, scope: dict, actor: Optional[str], source_commit: Optional[str] = None) -> dict:
    registry = load()
    from core.release.types import reports as _reports
    _reports.MINTED_KEYS.clear()
    with db.get_session(read_only=True) as session:
        items, problems, excluded = closure(session, registry, scope)
    if _reports.MINTED_KEYS:
        # release keys minted during the (read-only) export: persisted now, so
        # the next export of the same row carries the same key
        with db.get_session() as session:
            for model, rid, key in _reports.MINTED_KEYS:
                row = session.query(model).filter(model.id == rid).first()
                if row is not None and not getattr(row, "release_key", None):
                    row.release_key = key
            session.flush()
        _reports.MINTED_KEYS.clear()
    if bool(scope.get("plan")):
        # the DRY RUN: every problem and exclusion of the scope, nothing built
        return {"plan": True, "scope": scope, "count": len(items),
                "items": [{"kind": i.kind, "key": i.key} for i in items],
                "problems": problems, "excluded": excluded,
                "ready": not problems and bool(items)}
    if problems:
        named = "; ".join(f"{p.get('kind')} {p.get('key')!r}: {p.get('reason')}" for p in problems)
        raise ReleaseRefusal(
            f"{len(problems)} object(s) in the scope cannot be released -- exclude them deliberately "
            f"(scope.exclude) or repair them, then export again: {named}",
            problems=problems)
    if not items:
        raise ReleaseRefusal("the scope selects nothing -- a package with no items is not a release")
    requires = sorted({k for i in items for k in registry.require(i.kind).requires_config})
    pkg = pkgmod.build_package(items, source_environment=this_environment(), exported_by=actor,
                               scope=scope, source_commit=source_commit, requires_config=requires,
                               excluded=excluded)
    _audit(db, actor, "release.export", None,
           {"scope": scope, "items": len(items), "excluded": len(excluded), "checksum": pkg["checksum"]})
    return pkg


# ── upload ─────────────────────────────────────────────────────────────────

def _scan_secrets(items: list[dict], registry) -> None:
    from core.feed.governance import find_secret_paths
    for i in items:
        t = registry.require(i["kind"])
        allowed = set(t.not_secret)
        hits = [p for p in find_secret_paths(i.get("definition") or {})
                if p.split(".")[-1].split("[")[0] not in allowed]
        if hits:
            raise ReleaseRefusal(
                f"REFUSED: {i['kind']} {i['key']!r} carries credential-shaped key(s) {hits} -- "
                f"a secret in a package means a secret in the repository that held it; purge it, "
                f"never import it", kind=i["kind"], key=str(i["key"]), path=hits[0])


def _check_requires(pkg: dict) -> list[dict]:
    from core import config as _config
    out = []
    for dotted in ((pkg.get("requires") or {}).get("config_keys") or []):
        section, _, key = str(dotted).partition(".")
        val = _config.get(section, key, _MISSING) if key else _MISSING
        if val is _MISSING:
            raise ReleaseRefusal(f"the package requires config key {dotted!r}, which this build does "
                                 f"not declare -- deploy the image / Helm change first")
        out.append({"key": dotted, "effective": val if not _looks_secret(dotted) else "***"})
    return out


def _looks_secret(dotted: str) -> bool:
    from core.secrets_at_rest import is_secret_key
    return is_secret_key(dotted.split(".")[-1])


def upload(db, pkg: Any, *, environment: str, actor: Optional[str], ticket: Optional[str] = None,
           options: Optional[dict] = None) -> dict:
    registry = load()
    rcfg = release_cfg()
    raw = json.dumps(pkg, ensure_ascii=False) if not isinstance(pkg, (str, bytes)) else pkg
    size_mb = len(raw.encode("utf-8") if isinstance(raw, str) else raw) / (1024 * 1024)
    if size_mb > float(rcfg["max_package_mb"]):
        raise ReleaseRefusal(f"package is {size_mb:.1f} MB; the cap is {rcfg['max_package_mb']} MB "
                             f"(feed_generation.governance.release.max_package_mb)")
    if isinstance(pkg, (str, bytes)):
        try:
            pkg = json.loads(pkg)
        except ValueError as exc:
            raise ReleaseRefusal(f"package is not valid JSON: {exc}") from exc
    items = pkgmod.validate_package(pkg, known_kinds=set(registry.kinds()))
    _scan_secrets(items, registry)
    if environment in git_truth_environments() and not pkg.get("source_commit"):
        raise ReleaseRefusal(
            f"environment {environment!r} treats git as the truth "
            f"(feed_generation.governance.git_truth_environments): a package must carry the "
            f"source_commit the pipeline resolved -- a hand export cannot be applied here")
    requires = _check_requires(pkg)
    opts = dict(options or {})
    opts.setdefault("first_release_overwrites", bool(rcfg["first_release_overwrites"]))
    row = db.create_config_release({
        "environment": environment, "state": "uploaded", "package_id": pkg.get("package_id"),
        "package_checksum": pkg["checksum"], "source_environment": pkg.get("source_environment"),
        "source_commit": pkg.get("source_commit"), "source_exported_at": pkg.get("exported_at"),
        "source_exported_by": pkg.get("exported_by"), "scope": pkg.get("scope"),
        "package": dict(pkg, items=items), "options": dict(opts, requires=requires),
        "jira_ticket": ticket, "uploaded_by": actor, "uploaded_at": _now(),
    })
    _audit(db, actor, "release.upload", row["id"],
           {"environment": environment, "checksum": pkg["checksum"], "items": len(items),
            "source": pkg.get("source_environment"), "commit": pkg.get("source_commit")})
    return row


# ── preview ────────────────────────────────────────────────────────────────

def _release(db, release_id: int) -> dict:
    rel = db.get_config_release(int(release_id), with_package=True)
    if rel is None:
        raise ReleaseRefusal(f"release {release_id} does not exist")
    return rel


def _items_of(rel: dict) -> list[Item]:
    return [Item.from_dict(i) for i in (rel["package"].get("items") or [])]


def preview(db, release_id: int, *, actor: Optional[str] = None) -> dict:
    rel = _release(db, release_id)
    if rel["state"] in ("applying", "applied", "verified", "applied_unverified", "rolled_back"):
        raise ReleaseRefusal(f"release {release_id} is {rel['state']}; a preview is for a release not yet applied")
    registry = load()
    env = rel["environment"]
    items = _items_of(rel)
    mapping = Mapping(db.list_release_mappings(env))
    base = db.latest_deployment_by_key(env)
    opts = rel.get("options") or {}
    decisions = rel.get("decisions") or {}
    items = [registry.require(i.kind).effective(i, mapping) for i in items]
    in_package = {(i.kind, i.key) for i in items}
    entries: list[dict] = []
    with db.get_session(read_only=True) as session:
        for item in sorted(items, key=lambda i: (registry.kinds().index(i.kind), i.key)):
            t = registry.require(item.kind)
            missing: list[dict] = []
            try:
                resolved = t.resolve(session, item, mapping, registry, in_package)
                missing.extend(resolved.get("missing") or [])
            except ReleaseRefusal as exc:
                resolved = {"refs": {}, "env": {}}
                missing.append({"what": "refusal", "reason": str(exc), "path": exc.path})
            theirs = None
            try:
                theirs = t.current_item(session, item.key, registry)
            except ReleaseRefusal as exc:
                missing.append({"what": "target_unreadable", "reason": str(exc)})
            base_def = (base.get((item.kind, item.key)) or {}).get("definition")
            d = diffmod.three_way(base_def, item.definition, theirs.definition if theirs else None,
                                  first_release_overwrites=bool(opts.get("first_release_overwrites")))
            undecided = diffmod.undecided(d, decisions.get(f"{item.kind}|{item.key}") or {})
            entries.append({
                "kind": item.kind, "key": item.key, "hash": item.hash,
                "theirs_hash": theirs.hash if theirs else None,
                "has_base": base_def is not None,
                "state": d["state"], "conflicts": d["conflicts"], "undecided": undecided,
                "fields": [f for f in d["fields"] if f["state"] != "unchanged"],
                "unchanged_fields": sum(1 for f in d["fields"] if f["state"] == "unchanged"),
                "missing": missing, "env": resolved.get("env") or {},
                "environment_fields": item.environment_fields,
                "environment_refs": item.environment_refs,
                "dependencies": item.dependencies,
                "blocked": bool(missing), "blocked_by": [],
            })
    # cascade: an object whose dependency is blocked is blocked
    blocked = {(e["kind"], e["key"]) for e in entries if e["blocked"]}
    changed = True
    while changed:
        changed = False
        for e in entries:
            if e["blocked"]:
                continue
            bad = [list(d) for d in e["dependencies"] if tuple(d) in blocked]
            if bad:
                e["blocked"], e["blocked_by"] = True, bad
                blocked.add((e["kind"], e["key"]))
                changed = True
    counts = {s: sum(1 for e in entries if e["state"] == s) for s in diffmod.STATES}
    counts["blocked"] = sum(1 for e in entries if e["blocked"])
    counts["undecided"] = sum(len(e["undecided"]) for e in entries)
    needed = sorted({(m.get("mapping_kind") or m.get("kind"), m.get("value") or m.get("name"))
                     for e in entries for m in e["missing"]
                     if m.get("what") in ("environment_field", "environment_ref")}, key=str)
    pv = {"at": _now().isoformat(), "by": actor, "counts": counts, "items": entries,
          "ready": counts["blocked"] == 0 and counts["undecided"] == 0,
          "mappings_needed": [{"kind": k, "from_value": v} for k, v in needed],
          # what the exporter DELIBERATELY left out, with each reason
          "excluded": list(rel["package"].get("excluded") or [])}
    state = rel["state"] if rel["state"] == "approved" else "previewed"
    out = db.update_config_release(rel["id"], {"preview": pv, "mapping_used": mapping.to_rows(),
                                               "state": state})
    _audit(db, actor, "release.preview", rel["id"], {"counts": counts, "ready": pv["ready"]})
    return out


def decide(db, release_id: int, decisions: dict, *, actor: Optional[str]) -> dict:
    rel = _release(db, release_id)
    if rel["state"] not in ("uploaded", "previewed", "approved"):
        raise ReleaseRefusal(f"release {release_id} is {rel['state']}; decisions belong before the apply")
    merged = dict(rel.get("decisions") or {})
    for obj, fields in (decisions or {}).items():
        if not isinstance(fields, dict):
            raise ReleaseRefusal(f"decisions for {obj!r} must map field paths to take_release | keep_prod")
        for path, d in fields.items():
            if d not in ("take_release", "keep_prod"):
                raise ReleaseRefusal(f"{obj} {path}: decision must be take_release or keep_prod, not {d!r}")
        merged.setdefault(obj, {}).update(fields)
    # a decision changes the plan: back to previewed so it is re-approved
    db.update_config_release(rel["id"], {"decisions": merged,
                                         "state": "previewed" if rel["state"] == "approved" else rel["state"],
                                         "approved_by": None, "approved_at": None})
    _audit(db, actor, "release.decide", rel["id"], {"decisions": decisions})
    return preview(db, rel["id"], actor=actor)


# ── approve ────────────────────────────────────────────────────────────────

def approve(db, release_id: int, *, actor: Optional[str], ticket: Optional[str] = None,
            note: Optional[str] = None, validate_ticket_fn: Optional[Callable[..., dict]] = None) -> dict:
    rel = _release(db, release_id)
    if rel["state"] not in ("previewed",):
        raise ReleaseRefusal(f"release {release_id} is {rel['state']}; approve a PREVIEWED release")
    rcfg = release_cfg()
    env = rel["environment"]
    if env in (rcfg["four_eyes_environments"] or []) and actor and actor == rel.get("uploaded_by"):
        raise ReleaseRefusal(f"four-eyes: {actor!r} uploaded release {release_id} and may not approve it "
                             f"in {env!r} (feed_generation.governance.release.four_eyes_environments)")
    ticket = ticket or rel.get("jira_ticket")
    if env in (rcfg["require_ticket_environments"] or []) and not ticket:
        raise ReleaseRefusal(f"a JIRA ticket is required to approve a release to {env!r} "
                             f"(feed_generation.governance.release.require_ticket_environments)")
    from core.feed.jira_link import gate_change, validate_ticket
    validation = (validate_ticket_fn or validate_ticket)(ticket) if ticket else {"outcome": "skipped"}
    if ticket:
        allowed, reason = gate_change(validation)
        if not allowed:
            raise ReleaseRefusal(f"approval refused: {reason}")
    out = db.update_config_release(rel["id"], {
        "state": "approved", "approved_by": actor, "approved_at": _now(), "approval_note": note,
        "jira_ticket": ticket, "ticket_validation": validation})
    _audit(db, actor, "release.approve", rel["id"], {"ticket": ticket, "validation": validation})
    return out


# ── apply ──────────────────────────────────────────────────────────────────

def _ensure_enabled(environment: str) -> None:
    """The master gate protects the environments where git is the truth
    (PROD): there an apply needs ``governance.enabled``.  A DB-first
    environment (DEV, UAT) applies regardless -- the legacy promotion routes
    (published-view import, DataFlow bundle import) ride this engine and
    were never gated there; gating them would be a regression, not a control."""
    if environment in git_truth_environments() and not bool(gov_cfg().get("enabled", False)):
        raise ReleaseRefusal(f"release applies to {environment!r} are disabled "
                             f"(feed_generation.governance.enabled=false) -- export, upload and preview remain available")


def apply(db, release_id: int, *, actor: Optional[str], take_all: bool = False) -> dict:
    """ONE transaction: snapshot, every object, every ledger row -- or nothing.
    Returns the release with ``followups`` (templates whose members the
    caller must re-render) and ``ledger``."""
    rel = _release(db, release_id)
    _ensure_enabled(rel["environment"])
    if rel["state"] not in APPLY_FROM:
        raise ReleaseRefusal(f"release {release_id} is {rel['state']}; only an APPROVED release applies")
    pv = rel.get("preview") or {}
    if not pv:
        raise ReleaseRefusal(f"release {release_id} has no preview")
    if not pv.get("ready") and not take_all:
        raise ReleaseRefusal(
            f"release {release_id} is not ready: {pv['counts'].get('blocked', 0)} blocked object(s), "
            f"{pv['counts'].get('undecided', 0)} undecided conflict(s) -- map, decide, preview again")
    registry = load()
    env = rel["environment"]
    items = _items_of(rel)
    mapping = Mapping(rel.get("mapping_used") or db.list_release_mappings(env))
    decisions = rel.get("decisions") or {}
    by_key = {(e["kind"], e["key"]): e for e in pv.get("items") or []}
    items = [registry.require(i.kind).effective(i, mapping) for i in items]
    in_package = {(i.kind, i.key) for i in items}
    order = {k: i for i, k in enumerate(kinds_in_order(i.kind for i in items))}
    ordered = sorted(items, key=lambda i: (order[i.kind], i.key))
    commit = rel.get("source_commit") or rel["package_checksum"]
    snapshot: list[dict] = []
    created: list[dict] = []
    ledger: list[dict] = []
    followups: list[dict] = []
    from core.db.models import ConfigDeployment, ConfigRelease
    try:
        with db.get_session() as session:
            row = session.query(ConfigRelease).filter(ConfigRelease.id == rel["id"])
            try:
                row = row.with_for_update(nowait=False)
            except Exception:  # noqa: BLE001 -- dialects without row locks
                pass
            row = row.first()
            if row is None or row.state not in APPLY_FROM:
                raise ReleaseRefusal(f"release {release_id} is no longer approved (another apply?)")
            row.state, row.applied_by, row.applied_at = "applying", actor, _now()
            session.flush()
            # pass 1 -- the SNAPSHOT of every object as it is NOW, before anything
            # moves (a dataset applied first would otherwise change what its
            # report's snapshot sees), and the "nothing moved since the preview" check
            current: dict = {}
            for item in ordered:
                t = registry.require(item.kind)
                entry = by_key.get((item.kind, item.key)) or {}
                existing = t.find_row(session, item.key)
                theirs = t.export_row(session, existing, registry) if existing is not None else None
                current[(item.kind, item.key)] = (existing, theirs)
                if theirs is not None:
                    snapshot.append({"kind": item.kind, "key": item.key, "definition": theirs.definition,
                                     "hash": theirs.hash})
                    if entry.get("theirs_hash") not in (None, theirs.hash):
                        raise ReleaseRefusal(
                            f"{item.kind} {item.key!r} changed in {env} since the preview -- preview again",
                            kind=item.kind, key=item.key)
                elif entry.get("theirs_hash"):
                    raise ReleaseRefusal(f"{item.kind} {item.key!r} was deleted in {env} since the preview",
                                         kind=item.kind, key=item.key)
            # pass 2 -- apply, in vocabulary order
            for item in ordered:
                t = registry.require(item.kind)
                entry = by_key.get((item.kind, item.key)) or {}
                existing, theirs = current[(item.kind, item.key)]
                keep = set() if take_all else diffmod.keep_fields(
                    {"fields": entry.get("fields") or []}, decisions.get(f"{item.kind}|{item.key}") or {})
                if existing is not None and theirs is not None and theirs.hash == item.hash:
                    oid, action = int(existing.id), "unchanged"
                else:
                    resolved = t.resolve(session, item, mapping, registry, in_package)
                    if resolved.get("missing"):
                        raise ReleaseRefusal(
                            f"{item.kind} {item.key!r}: {resolved['missing'][0].get('reason')}",
                            kind=item.kind, key=item.key)
                    oid, action = t.apply(session, item, resolved, existing, keep_fields=keep,
                                          actor=actor, registry=registry)
                    if action == "updated" and keep:
                        action = "kept_prod" if keep >= set(item.definition) else "updated"
                    if action == "created":
                        created.append({"kind": item.kind, "key": item.key, "object_id": oid})
                    if item.kind == "feed_template":
                        followups.append({"kind": "feed_template", "key": item.key, "object_id": oid})
                dep = ConfigDeployment(
                    environment=env, object_type=item.kind, object_id=oid, name=item.key,
                    git_commit=str(commit)[:64], jira_ticket=rel.get("jira_ticket"), deployed_by=actor,
                    definition=item.definition if action != "kept_prod" else (theirs.definition if theirs else item.definition),
                    definition_hash=item.hash if action != "kept_prod" else (theirs.hash if theirs else item.hash),
                    release_id=rel["id"], action=action, package_checksum=rel["package_checksum"],
                    created_by=actor, updated_by=actor)
                session.add(dep)
                session.flush()
                ledger.append({"kind": item.kind, "key": item.key, "object_id": oid, "action": action,
                               "kept_fields": sorted(keep)})
            row.state = "applied"
            row.snapshot = snapshot
            row.snapshot_checksum = pkgmod.checksum(snapshot) if snapshot else None
            row.created_objects = created
            row.applied_at = _now()
            session.flush()
    except ReleaseRefusal as exc:
        db.update_config_release(rel["id"], {"state": "failed", "error": str(exc)})
        _audit(db, actor, "release.apply_failed", rel["id"], {"error": str(exc)})
        raise
    except Exception as exc:  # noqa: BLE001 -- the database's own refusal, named
        db.update_config_release(rel["id"], {"state": "failed", "error": f"{type(exc).__name__}: {exc}"[:2000]})
        _audit(db, actor, "release.apply_failed", rel["id"], {"error": str(exc)[:500]})
        raise ReleaseRefusal(f"apply of release {release_id} failed and NOTHING was applied: "
                             f"{type(exc).__name__}: {exc}") from exc
    _audit(db, actor, "release.apply", rel["id"],
           {"objects": len(ledger), "created": len(created), "commit": commit})
    out = db.get_config_release(rel["id"], with_package=False)
    out["ledger"] = ledger
    out["followups"] = followups
    return out


# ── verify ─────────────────────────────────────────────────────────────────

def verify(db, release_id: int, *, actor: Optional[str] = None) -> dict:
    rel = _release(db, release_id)
    if rel["state"] not in ("applied", "applied_unverified", "verified"):
        raise ReleaseRefusal(f"release {release_id} is {rel['state']}; verify an APPLIED release")
    registry = load()
    ledger = db.list_release_ledger(rel["id"])
    results: list[dict] = []
    with db.get_session(read_only=True) as session:
        for l in ledger:
            t = registry.get(l["object_type"])
            if t is None:
                v = Verdict("unknown", f"type {l['object_type']!r} is not registered in this build")
            elif l.get("object_id") is None:
                v = Verdict("failed", "the ledger row has no object id -- nothing was written")
            else:
                try:
                    v = t.verify(db, session, int(l["object_id"]), registry)
                except Exception as exc:  # noqa: BLE001 -- a verifier that crashes is UNKNOWN, said
                    v = Verdict("unknown", f"verifier raised {type(exc).__name__}: {exc}")
            results.append({"kind": l["object_type"], "key": l["name"], "object_id": l.get("object_id"),
                            "verdict": v.to_dict()})
    states = {r["verdict"]["state"] for r in results}
    overall = "failed" if "failed" in states else ("unknown" if "unknown" in states else "ok")
    if not results:
        overall = "unknown"
    verification = {"state": overall, "at": _now().isoformat(), "by": actor, "items": results,
                    "counts": {s: sum(1 for r in results if r["verdict"]["state"] == s)
                               for s in ("ok", "failed", "unknown")}}
    new_state = "verified" if overall == "ok" else "applied_unverified"
    out = db.update_config_release(rel["id"], {"verification": verification, "verified_at": _now(),
                                               "state": new_state})
    _audit(db, actor, "release.verify", rel["id"], {"state": overall, "counts": verification["counts"]})
    if overall != "ok":
        logger.error("[release] release %s to %s is APPLIED but NOT VERIFIED (%s): %s", rel["id"],
                     rel["environment"], overall,
                     "; ".join(f"{r['kind']} {r['key']}: {r['verdict']['reason']}"
                               for r in results if r["verdict"]["state"] != "ok")[:1000])
        policy = str((release_cfg().get("verify") or {}).get("on_failure") or "hold")
        if policy == "rollback" and overall == "failed":
            logger.error("[release] verify.on_failure=rollback: rolling release %s back", rel["id"])
            rb = rollback(db, rel["id"], actor=f"{actor or 'system'} (verify.on_failure=rollback)")
            out = db.get_config_release(rel["id"])
            out["rolled_back_by_release"] = rb["id"]
    return out


# ── rollback ───────────────────────────────────────────────────────────────

def rollback(db, release_id: int, *, actor: Optional[str]) -> dict:
    """A NEW release whose package is the snapshot the apply took: the
    objects return to their governed form before the release; objects the
    release CREATED are deactivated where the model allows (never deleted:
    runs may reference them) and reported otherwise.  Four-eyes is waived
    for a rollback -- it restores a state that was itself approved -- and
    the waiver is recorded on the row."""
    rel = _release(db, release_id)
    _ensure_enabled(rel["environment"])
    if rel["state"] not in ROLLBACK_FROM:
        raise ReleaseRefusal(f"release {release_id} is {rel['state']}; roll back an APPLIED release")
    registry = load()
    snapshot = rel.get("snapshot") or []
    created = rel.get("created_objects") or []
    items = [Item(kind=s["kind"], key=s["key"], definition=s["definition"], hash=s["hash"])
             for s in snapshot]
    deactivated: list[dict] = []
    left: list[dict] = []
    with db.get_session() as session:
        for c in created:
            t = registry.get(c["kind"])
            row = session.query(t.model).filter(t.model.id == int(c["object_id"])).first() if t else None
            if row is None:
                left.append(dict(c, why="no longer present"))
            elif hasattr(row, "is_active"):
                row.is_active = False
                deactivated.append(c)
            else:
                left.append(dict(c, why=f"{c['kind']} has no is_active -- left in place, named here"))
        session.flush()
    if not items:
        out = db.update_config_release(rel["id"], {"state": "rolled_back"})
        _audit(db, actor, "release.rollback", rel["id"], {"deactivated": deactivated, "left": left,
                                                         "restored": 0})
        out["deactivated"], out["left"] = deactivated, left
        return out
    pkg = pkgmod.build_package(items, source_environment=rel["environment"], exported_by=actor,
                               scope={"kind": "rollback", "of": rel["id"]},
                               source_commit=rel.get("source_commit"))
    row = db.create_config_release({
        "environment": rel["environment"], "state": "uploaded", "package_id": pkg["package_id"],
        "package_checksum": pkg["checksum"], "source_environment": rel["environment"],
        "source_commit": rel.get("source_commit"), "source_exported_at": pkg["exported_at"],
        "source_exported_by": actor, "scope": pkg["scope"], "package": pkg,
        "options": {"first_release_overwrites": True, "rollback": True,
                    "deactivated": deactivated, "left": left},
        "jira_ticket": rel.get("jira_ticket"), "uploaded_by": actor, "uploaded_at": _now(),
    })
    preview(db, row["id"], actor=actor)
    db.update_config_release(row["id"], {
        "state": "approved", "approved_by": actor, "approved_at": _now(),
        "approval_note": f"rollback of release {rel['id']} -- four-eyes waived for a rollback "
                         f"(it restores an approved state); recorded here",
        "rollback_of": rel["id"]})
    out = apply(db, row["id"], actor=actor, take_all=True)
    db.update_config_release(rel["id"], {"state": "rolled_back"})
    _audit(db, actor, "release.rollback", rel["id"], {"by_release": row["id"], "restored": len(items),
                                                     "deactivated": deactivated, "left": left})
    out["deactivated"], out["left"] = deactivated, left
    return out


# ── the legacy git deploy (POST /api/governance/deploy) ────────────────────

def apply_items(db, *, environment: str, items: list[dict], commit: str, ticket: Optional[str],
                actor: Optional[str]) -> list[dict]:
    """``apply_config_deploy``'s body: reviewed definition files -> ONE
    release, approved by the reviewed commit, applied in one transaction.
    Returns ``[{object_type, object_id, name}]`` as the old seam did."""
    rel_items = [Item(kind=str(i["object_type"]), key=str(i["name"]), definition=i.get("definition") or {},
                      hash=str(i.get("definition_hash") or "")) for i in items]
    for it in rel_items:
        if not it.hash:
            from core.release.contract import item_hash
            it.hash = item_hash(it.definition)
    pkg = pkgmod.build_package(rel_items, source_environment="git", exported_by=actor,
                               scope={"kind": "git_deploy", "files": [i.get("path") for i in items]},
                               source_commit=commit)
    row = upload(db, pkg, environment=environment, actor=actor, ticket=ticket,
                 options={"first_release_overwrites": True, "git_deploy": True})
    pv = preview(db, row["id"], actor=actor)
    if not (pv.get("preview") or {}).get("ready"):
        blocked = [e for e in pv["preview"]["items"] if e["blocked"]]
        reason = (blocked[0]["missing"][0].get("reason") if blocked and blocked[0]["missing"]
                  else "undecided conflicts")
        db.update_config_release(row["id"], {"state": "failed", "error": reason})
        raise ReleaseRefusal(f"deploy refused: {reason}")
    db.update_config_release(row["id"], {
        "state": "approved", "approved_by": actor, "approved_at": _now(),
        "approval_note": f"approved by the reviewed git commit {commit} (the review happened in git)"})
    out = apply(db, row["id"], actor=actor, take_all=True)
    return [{"object_type": l["kind"], "object_id": l["object_id"], "name": l["key"]}
            for l in out["ledger"]]


# ── the legacy promotion routes ride the same engine ───────────────────────

def promote_items(db, items: list, *, actor: Optional[str], environment: Optional[str] = None,
                  ticket: Optional[str] = None, source_commit: Optional[str] = None,
                  source_environment: str = "import", scope: Optional[dict] = None,
                  connection_map: Optional[dict] = None, overwrite_existing: bool = True,
                  dry_run: bool = False) -> dict:
    """What the Phase 98-E published-view import and the DataFlow bundle
    import now do: ONE release through the engine, answered in their old
    summary shape -- ``created / updated / skipped / errors`` plus the
    release id(s), so the Releases panel shows the same thing.

    ``connection_map`` becomes this environment's connection mapping.  With
    ``overwrite_existing=False`` every object that already exists is SKIPPED
    (a reduced release is applied).  ``dry_run`` stops after the preview.
    In a four-eyes environment the single-call import cannot approve itself:
    the release stays ``previewed`` and the summary says who must approve."""
    env = environment or this_environment()
    errors: list[dict] = []
    summary = {"dry_run": dry_run, "created": 0, "updated": 0, "skipped": 0, "errors": errors,
               "total_input": len(items), "release_ids": [], "environment": env}
    if not items:
        return summary
    if connection_map:
        db.upsert_release_mappings(env, [{"kind": "connection", "from_value": k, "to_value": v}
                                         for k, v in connection_map.items()], created_by=actor)

    def _upload_and_preview(its):
        pkg = pkgmod.build_package(its, source_environment=source_environment, exported_by=actor,
                                   scope=scope or {"kind": "import", "items": len(its)}, source_commit=source_commit)
        rel = upload(db, pkg, environment=env, actor=actor, ticket=ticket, options={"first_release_overwrites": True})
        summary["release_ids"].append(rel["id"])
        return rel, preview(db, rel["id"], actor=actor)["preview"]

    rel, pv = _upload_and_preview(items)
    entries = pv["items"]
    by = {(e["kind"], e["key"]): e for e in entries}
    for e in entries:
        if e["blocked"]:
            reason = (e["missing"][0].get("reason") if e["missing"] else f"blocked by {e['blocked_by']}")
            errors.append({"kind": e["kind"], "slug": e["key"], "key": e["key"], "error": reason})
    keep = [i for i in items if not by[(i.kind, i.key)]["blocked"]]
    if not overwrite_existing:
        existing_keys = {(e["kind"], e["key"]) for e in entries if e["state"] != "new"}
        summary["skipped"] = len([i for i in keep if (i.kind, i.key) in existing_keys])
        keep = [i for i in keep if (i.kind, i.key) not in existing_keys]
    summary["created"] = sum(1 for i in keep if by[(i.kind, i.key)]["state"] == "new")
    summary["updated"] = sum(1 for i in keep if by[(i.kind, i.key)]["state"] != "new")
    if dry_run or not keep:
        return summary
    if len(keep) != len(items):
        rel, pv = _upload_and_preview(keep)
    try:
        approve(db, rel["id"], actor=actor, ticket=ticket, note="approved by the import call")
    except ReleaseRefusal as exc:
        errors.append({"kind": "release", "key": rel["id"], "slug": str(rel["id"]),
                       "error": f"release {rel['id']} is previewed but NOT applied: {exc} -- approve it in "
                                f"Admin -> Governance -> Configuration releases"})
        summary["created"] = summary["updated"] = 0
        return summary
    try:
        out = apply(db, rel["id"], actor=actor)
    except ReleaseRefusal as exc:
        errors.append({"kind": "release", "key": rel["id"], "slug": str(rel["id"]), "error": str(exc)})
        summary["created"] = summary["updated"] = 0
        return summary
    actions = [l["action"] for l in out.get("ledger") or []]
    summary["created"] = actions.count("created")
    summary["updated"] = sum(1 for a in actions if a in ("updated", "kept_prod"))
    summary["unchanged"] = actions.count("unchanged")
    summary["state"] = out.get("state")
    summary["followups"] = out.get("followups") or []
    return summary
