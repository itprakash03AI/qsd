"""BF-410.4 — Distributed scheduler leader election via DB lease.

Why this exists
---------------
If `scheduler.replicaCount > 1` (either explicitly, or transiently during a
rolling upgrade where new+old scheduler pods overlap), APScheduler in each
pod fires the SAME jobs at the SAME time → duplicate backups, duplicate
webhook dispatches, duplicate notification emails.

This module gives one of N scheduler pods an exclusive lease (DB row) that
expires unless renewed.  Only the lease holder runs `start_scheduler()`;
the rest wait + try to acquire.  Works on both SQLite (single-node) and
PostgreSQL (multi-pod) deployments.

API
---
    SchedulerLease(db_manager, holder_id, lease_seconds=30, renew_every=10)
        .try_acquire() -> bool        # become the leader
        .renew()        -> bool        # extend the lease (call every renew_every s)
        .release()      -> None        # explicit logout on shutdown
        .is_leader      -> bool        # True if we currently hold the lease

The lease row lives in a single-row table `scheduler_lease` (id=1).  Lease
expiry is enforced by comparing `expires_at` to `NOW()` at acquire time
via a conditional UPSERT — fully atomic, no double-acquire races.
"""
from __future__ import annotations

import logging
import os
import socket
import threading
from datetime import datetime, timedelta, timezone
from typing import Callable, Optional

logger = logging.getLogger(__name__)


def default_holder_id() -> str:
    """Build a stable, human-readable holder ID from the pod's hostname + pid.
    Logged in the lease row so admins can see WHICH pod currently owns it."""
    host = os.environ.get("POD_NAME") or os.environ.get("HOSTNAME") or socket.gethostname()
    return f"{host}#{os.getpid()}"


class SchedulerLease:
    """DB-row-based exclusive lease for scheduler leader election."""

    def __init__(self, db_manager, holder_id: Optional[str] = None,
                 lease_seconds: int = 30, renew_every: int = 10,
                 on_acquired: Optional[Callable[[], None]] = None,
                 on_lost: Optional[Callable[[], None]] = None):
        if lease_seconds <= renew_every:
            raise ValueError(
                f"lease_seconds ({lease_seconds}) must exceed renew_every "
                f"({renew_every}) — otherwise the lease expires between heartbeats"
            )
        self._db = db_manager
        self.holder_id = holder_id or default_holder_id()
        self.lease_seconds = int(lease_seconds)
        self.renew_every = int(renew_every)
        self._is_leader = False
        self._lock = threading.Lock()
        self._renew_thread: Optional[threading.Thread] = None
        self._stop = threading.Event()
        # BF-414 — callbacks fire OUTSIDE the lease lock when the leadership
        # state changes.  Used by the scheduler bootstrap (main.py) to
        # ``pause_scheduler()`` on loss + ``resume_scheduler()`` on
        # re-acquire — without this, both pods kept running APScheduler
        # during a renew failure, defeating leader election.
        self._on_acquired = on_acquired
        self._on_lost = on_lost

    # ── Public ─────────────────────────────────────────────────────────────

    @property
    def is_leader(self) -> bool:
        with self._lock:
            return self._is_leader

    def try_acquire(self) -> bool:
        """Attempt to become leader.  Returns True if WE now hold the lease.

        Atomicity: uses a single UPSERT with `expires_at <= NOW()` predicate
        so two pods racing for the lease never both succeed.  Postgres uses
        `ON CONFLICT DO UPDATE WHERE ...`; SQLite uses `INSERT OR REPLACE`
        wrapped in a transaction with the same expiry check.

        BF-410-AUDIT-FOLLOWUP: the table is now declared via the ORM model
        (core/db/models.py::SchedulerLease) and created by
        Base.metadata.create_all() at startup, so we don't risk a race when
        multiple pods start simultaneously on a fresh deploy.  The
        _ensure_table() fallback below remains as defence-in-depth for
        deployments that upgrade past the ORM model addition.
        """
        self._ensure_table()
        now = datetime.now(timezone.utc)
        new_expires = now + timedelta(seconds=self.lease_seconds)

        try:
            with self._db.get_session() as s:
                from sqlalchemy import text
                # Check + upsert in one statement (per dialect)
                if getattr(self._db, "is_postgresql", False):
                    # Postgres: ON CONFLICT DO UPDATE with expiry check
                    res = s.execute(
                        text(
                            "INSERT INTO scheduler_lease (id, holder_id, acquired_at, expires_at) "
                            "VALUES (1, :h, :now, :exp) "
                            "ON CONFLICT (id) DO UPDATE "
                            "SET holder_id = EXCLUDED.holder_id, "
                            "    acquired_at = EXCLUDED.acquired_at, "
                            "    expires_at = EXCLUDED.expires_at "
                            "WHERE scheduler_lease.expires_at <= :now "
                            "   OR scheduler_lease.holder_id = :h "
                            "RETURNING holder_id"
                        ),
                        {"h": self.holder_id, "now": now, "exp": new_expires},
                    )
                    row = res.fetchone()
                    won = bool(row and row[0] == self.holder_id)
                else:
                    # SQLite path — read current state, upsert if expired or ours
                    row = s.execute(
                        text("SELECT holder_id, expires_at FROM scheduler_lease WHERE id=1"),
                    ).fetchone()
                    if row is None:
                        s.execute(
                            text(
                                "INSERT INTO scheduler_lease (id, holder_id, acquired_at, expires_at) "
                                "VALUES (1, :h, :now, :exp)"
                            ),
                            {"h": self.holder_id, "now": now, "exp": new_expires},
                        )
                        won = True
                    else:
                        _existing_holder, _existing_exp = row[0], row[1]
                        # Parse SQLite TEXT timestamp back to datetime
                        if isinstance(_existing_exp, str):
                            try:
                                _existing_exp = datetime.fromisoformat(_existing_exp)
                            except Exception:
                                _existing_exp = now - timedelta(seconds=1)
                        if (_existing_exp is None
                                or _existing_exp <= now
                                or _existing_holder == self.holder_id):
                            s.execute(
                                text(
                                    "UPDATE scheduler_lease SET holder_id=:h, "
                                    "acquired_at=:now, expires_at=:exp WHERE id=1"
                                ),
                                {"h": self.holder_id, "now": now, "exp": new_expires},
                            )
                            won = True
                        else:
                            won = False
        except Exception as exc:
            logger.warning("[scheduler-lease] try_acquire failed: %s", exc)
            return False

        with self._lock:
            self._is_leader = won
        if won:
            logger.info(
                "[scheduler-lease] ACQUIRED holder=%s expires=%s",
                self.holder_id, new_expires.isoformat(),
            )
        else:
            logger.debug("[scheduler-lease] another holder owns the lease")
        return won

    def renew(self) -> bool:
        """Extend the lease.  Only succeeds if WE still hold it."""
        if not self.is_leader:
            return False
        now = datetime.now(timezone.utc)
        new_expires = now + timedelta(seconds=self.lease_seconds)
        try:
            with self._db.get_session() as s:
                from sqlalchemy import text
                res = s.execute(
                    text(
                        "UPDATE scheduler_lease SET expires_at = :exp "
                        "WHERE id = 1 AND holder_id = :h"
                    ),
                    {"exp": new_expires, "h": self.holder_id},
                )
                won = (getattr(res, "rowcount", 0) or 0) >= 1
        except Exception as exc:
            logger.warning("[scheduler-lease] renew failed: %s", exc)
            won = False

        if not won:
            with self._lock:
                _was_leader = self._is_leader
                self._is_leader = False
            logger.warning(
                "[scheduler-lease] LOST lease (renew failed) — another pod took over"
            )
            if _was_leader and self._on_lost is not None:
                try:
                    self._on_lost()
                except Exception as _cb_exc:
                    logger.warning(
                        "[scheduler-lease] on_lost callback raised: %s", _cb_exc,
                    )
        else:
            logger.debug("[scheduler-lease] renewed until %s", new_expires.isoformat())
        return won

    def release(self) -> None:
        """Voluntary release on shutdown (faster failover than waiting for
        the expiry).  Idempotent + safe to call even when we're not leader."""
        with self._lock:
            was_leader = self._is_leader
            self._is_leader = False
        self._stop.set()
        if not was_leader:
            return
        try:
            with self._db.get_session() as s:
                from sqlalchemy import text
                s.execute(
                    text("DELETE FROM scheduler_lease WHERE id=1 AND holder_id=:h"),
                    {"h": self.holder_id},
                )
            logger.info("[scheduler-lease] RELEASED holder=%s", self.holder_id)
        except Exception as exc:
            logger.warning("[scheduler-lease] release failed: %s", exc)

    def run_renew_loop(self) -> None:
        """Start a background thread that renews the lease every `renew_every`
        seconds.  Call once after a successful try_acquire().  Stop via release()."""
        if self._renew_thread and self._renew_thread.is_alive():
            return
        self._stop.clear()
        self._renew_thread = threading.Thread(
            target=self._renew_loop,
            name="scheduler-lease-renew",
            daemon=True,
        )
        self._renew_thread.start()

    # ── Internal ──────────────────────────────────────────────────────────

    def _renew_loop(self) -> None:
        while not self._stop.wait(self.renew_every):
            if not self.is_leader:
                # Lost lease — try to re-acquire
                if self.try_acquire():
                    logger.info("[scheduler-lease] re-acquired after loss")
                    if self._on_acquired is not None:
                        try:
                            self._on_acquired()
                        except Exception as _cb_exc:
                            logger.warning(
                                "[scheduler-lease] on_acquired callback raised: %s",
                                _cb_exc,
                            )
                continue
            self.renew()

    def _ensure_table(self) -> None:
        """Create the scheduler_lease table if it doesn't exist.  Idempotent.

        Schema is dialect-portable plain SQL; the migration system catches
        this table on next startup but we create it ourselves on first
        acquire to support fresh deployments where the migration hasn't
        landed yet.
        """
        try:
            with self._db.engine.connect() as conn:
                from sqlalchemy import text
                if getattr(self._db, "is_postgresql", False):
                    conn.execute(text(
                        "CREATE TABLE IF NOT EXISTS scheduler_lease ("
                        "  id INTEGER PRIMARY KEY, "
                        "  holder_id VARCHAR(200) NOT NULL, "
                        "  acquired_at TIMESTAMP WITH TIME ZONE NOT NULL, "
                        "  expires_at TIMESTAMP WITH TIME ZONE NOT NULL"
                        ")"
                    ))
                else:
                    conn.execute(text(
                        "CREATE TABLE IF NOT EXISTS scheduler_lease ("
                        "  id INTEGER PRIMARY KEY, "
                        "  holder_id VARCHAR(200) NOT NULL, "
                        "  acquired_at TIMESTAMP NOT NULL, "
                        "  expires_at TIMESTAMP NOT NULL"
                        ")"
                    ))
                conn.commit()
        except Exception as exc:
            logger.debug("[scheduler-lease] _ensure_table noop: %s", exc)


# ── Shared leader gate for other background jobs ──────────────────────────
# The scheduler bootstrap (main.py) creates ONE SchedulerLease per pod and
# registers it here.  Other leader-gated background workers (brain DuckDB
# mirror writer, DataFlow scheduler) used to call ``is_scheduler_leader()`` (removed 2026-10-18) so that
# at most ONE pod ever runs the single-runner work — reusing the SAME lease
# the cron daemons already use rather than inventing a second election.

_active_lease: Optional["SchedulerLease"] = None
_active_lease_lock = threading.Lock()


def set_active_lease(lease: Optional["SchedulerLease"]) -> None:
    """Register (or clear) this pod's live SchedulerLease so leader-gated
    background jobs can consult it.  Called by the scheduler bootstrap."""
    global _active_lease
    with _active_lease_lock:
        _active_lease = lease


def get_active_lease() -> Optional["SchedulerLease"]:
    with _active_lease_lock:
        return _active_lease


def _leader_election_enabled() -> bool:
    """Whether leader-election is on (default True).  When OFF, a pod is
    treated as the sole runner — single-pod / election-disabled deploys
    must never have their background jobs starved."""
    try:
        from core.config import scheduler as _sl_cfg
        return bool(getattr(_sl_cfg, "leader_election_enabled", True))
    except Exception:
        return True


# 2026-10-18: is_scheduler_leader() is GONE -- a second election.  The lease made a
# hybrid api pod a leader beside the scheduler pod's LOCK; every single-runner duty
# asks core.daemon_registry.holds_single_runner_role() (the lock) instead.


def current_holder(db_manager) -> Optional[str]:
    """Read-only: return the current lease holder_id or None.

    Used by jobs that need a per-tick "am I still the leader?" check
    when the registered job survived a lease handover (rare — only
    during a network blip / handoff window).  Safe-fail to None on
    DB error: callers should treat that as "unknown, proceed" rather
    than panic.
    """
    if db_manager is None:
        return None
    try:
        from sqlalchemy import text
        with db_manager.get_session(read_only=True) as s:
            row = s.execute(
                text("SELECT holder_id, expires_at FROM scheduler_lease WHERE id=1"),
            ).fetchone()
            if not row:
                return None
            from datetime import datetime, timezone
            holder, expires = row[0], row[1]
            if expires is None:
                return holder
            # Expired lease — treat as no holder.
            try:
                if isinstance(expires, str):
                    expires_dt = datetime.fromisoformat(expires)
                else:
                    expires_dt = expires
                if expires_dt.tzinfo is None:
                    expires_dt = expires_dt.replace(tzinfo=timezone.utc)
                if expires_dt < datetime.now(timezone.utc):
                    return None
            except Exception:
                pass
            return holder
    except Exception:
        return None
