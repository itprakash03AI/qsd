"""The inventory: every published API as ONE shape, computed per request from
the owning tables in a bounded number of queries (2026-10-17, design §3.1 /
§3.9) -- and its CSV for governance reviews.

Unknown != empty: a lookup that fails is a ``problems`` entry on the answer
and ``unknown`` on the affected fields (health ``unknown``, last_call
``unknown``), never a shorter list.  A kind whose rows cannot be listed is
a refusal (:class:`InventoryUnavailable`), never an empty inventory.
"""
from __future__ import annotations

import csv
import io
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Iterable, List, Optional, Tuple

from core.published_api.contract import BuildContext, PublishedApi
from core.published_api.registry import load

logger = logging.getLogger(__name__)


class InventoryUnavailable(RuntimeError):
    """A kind's rows could not be listed: the inventory is not answered
    (a 503 at the route), because a partial list reads as the whole."""


def _numbers(db) -> Tuple[Dict[tuple, Dict[str, Any]], Optional[str]]:
    """``(kind, id) -> {last_call_at, calls_7d}`` from the call record, one
    GROUP BY.  Rows written before 2026-10-17 carry no api_kind: a row with a
    view_id is a published_view call (the only kind that wrote rows then)."""
    try:
        from core.published_api.numbers import inventory_numbers
        return inventory_numbers(db), None
    except Exception as exc:                                # noqa: BLE001
        logger.warning("[published-api] call numbers unreadable: %s", exc)
        return {}, f"the call record could not be read: {type(exc).__name__}: {str(exc)[:160]}"


def _audit_tail(session, resource_types: Iterable[str]) -> Dict[tuple, Dict[str, Any]]:
    """Newest audit row per (resource_type, resource_id): who last changed it."""
    try:
        from sqlalchemy import func
        from core.db.models import AuditLog
        types = list(resource_types)
        sub = (session.query(AuditLog.resource_type, AuditLog.resource_id, func.max(AuditLog.id).label("mx"))
               .filter(AuditLog.resource_type.in_(types)).group_by(AuditLog.resource_type, AuditLog.resource_id)
               .subquery())
        rows = session.query(AuditLog).join(sub, AuditLog.id == sub.c.mx).all()
        return {(str(r.resource_type), str(r.resource_id)): {
            "username": r.username, "action": r.action,
            "timestamp": r.timestamp.isoformat() if r.timestamp else None} for r in rows}
    except Exception as exc:                                # noqa: BLE001
        logger.debug("[published-api] audit tail unreadable: %s", exc)
        return {}


def build_inventory(db, *, kinds: Optional[Iterable[str]] = None) -> Tuple[List[PublishedApi], Dict[str, Any]]:
    """Every API of the given kinds (default: all) and the build's meta:
    ``{"generated_at", "problems": [...], "numbers_error", "kinds": [...]}``."""
    registry = load()
    wanted = [k for k in registry.kinds() if kinds is None or k in set(kinds)]
    numbers, numbers_error = _numbers(db)
    try:
        keys = db.list_api_keys() or []
    except Exception as exc:                                # noqa: BLE001
        raise InventoryUnavailable(f"the API keys could not be read: {type(exc).__name__}: {exc}") from exc
    ctx = BuildContext(db=db, keys=keys, numbers=numbers, numbers_error=numbers_error)
    apis: List[PublishedApi] = []
    with db.get_session(read_only=True) as session:
        ctx.audit = _audit_tail(session, ("published_view", "business_report", "published_api"))
        for kname in wanted:
            kind = registry.require(kname)
            try:
                rows = kind.rows(session)
            except Exception as exc:                        # noqa: BLE001
                raise InventoryUnavailable(f"the {kname} rows could not be listed: {type(exc).__name__}: {exc}") from exc
            apis.extend(kind.build(session, rows, ctx))
    meta = {"generated_at": datetime.now(timezone.utc).isoformat(), "problems": list(ctx.problems),
            "numbers_error": numbers_error, "kinds": wanted, "total": len(apis)}
    return apis, meta


# ── visibility and filters ───────────────────────────────────────────────

def visible_to(apis: List[PublishedApi], user: Optional[dict]) -> List[PublishedApi]:
    """admin / support: everything in full; an analyst: their own in full and
    every other API as a redacted catalog entry (the published-views list
    route's rule); anyone else: nothing (the route refuses before this)."""
    from core.roles import is_admin_like
    u = user or {}
    if is_admin_like(u) or str(u.get("role") or "") in ("support", "admin_read"):
        return list(apis)
    me = str(u.get("username") or "")
    return [a if (a.owner == me or a.created_by == me) else a.redacted() for a in apis]


def filter_apis(apis: List[PublishedApi], *, kind: Optional[str] = None, status: Optional[str] = None,
                health: Optional[str] = None, owner: Optional[str] = None, consumer: Optional[str] = None,
                q: Optional[str] = None, idle_days: Optional[int] = None) -> List[PublishedApi]:
    out = []
    now = datetime.now(timezone.utc)
    needle = (q or "").strip().lower()
    for a in apis:
        if kind and a.api_kind != kind:
            continue
        if status and (a.lifecycle or {}).get("status") != status:
            continue
        if health and (a.health or {}).get("state") != health:
            continue
        if owner and (a.owner or "") != owner:
            continue
        if consumer and not any(consumer in (c.id, c.identity, c.name, c.consumer or "", c.owner or "")
                                for c in a.consumers):
            continue
        if needle and needle not in f"{a.key} {a.name} {a.description or ''} {a.owner or ''}".lower():
            continue
        if idle_days is not None:
            lc = a.last_call or {}
            if lc.get("state") == "unknown":
                pass                                          # unknown is listed: it may be idle
            else:
                at = lc.get("at")
                if at:
                    try:
                        t = datetime.fromisoformat(str(at).replace("Z", "+00:00"))
                        t = t if t.tzinfo else t.replace(tzinfo=timezone.utc)
                        if now - t < timedelta(days=int(idle_days)):
                            continue
                    except ValueError:
                        pass
        out.append(a)
    return out


# ── the CSV ──────────────────────────────────────────────────────────────

CSV_COLUMNS = ("kind", "key", "name", "owner", "owner_group", "lifecycle", "sunset_at", "successor", "health",
               "health_reasons", "source", "connections", "endpoints", "formats", "parameters", "filters",
               "definition_version", "schema_version", "rls_mode", "rls_policies", "consumers", "consumer_count",
               "dependencies", "created_by", "created_at", "last_changed_by", "last_changed_at", "last_call_at",
               "calls_7d")


def _u(v, unknown: str = "unknown") -> str:
    return unknown if v is None else str(v)


def to_csv(apis: Iterable[PublishedApi]) -> str:
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(CSV_COLUMNS)
    for a in apis:
        lc = a.last_call or {}
        last_at = "unknown" if lc.get("state") == "unknown" else (lc.get("at") or "never")
        w.writerow([
            a.api_kind, a.key, a.name, _u(a.owner, ""), _u(a.owner_group, ""),
            (a.lifecycle or {}).get("status", "unknown"), _u((a.lifecycle or {}).get("sunset_at"), ""),
            _u((a.lifecycle or {}).get("successor"), ""), (a.health or {}).get("state", "unknown"),
            "; ".join((a.health or {}).get("reasons") or []),
            f"{(a.source or {}).get('kind', '')} #{(a.source or {}).get('id', '')} {(a.source or {}).get('name') or ''}".strip()
            if not a.is_redacted else "redacted",
            "; ".join(f"{c.get('name') or '#' + str(c.get('id'))} ({c.get('role')}, {c.get('state')})" for c in a.connections)
            if not a.is_redacted else "redacted",
            "; ".join(f"{e.method} {e.path}" for e in a.endpoints),
            "; ".join(sorted({f for e in a.endpoints for f in e.formats})),
            "; ".join(str(p.get("name") if isinstance(p, dict) else p) for p in a.parameters) if not a.is_redacted else "redacted",
            "; ".join(a.filters) if not a.is_redacted else "redacted",
            _u(a.definition_version), _u(a.schema_version),
            (a.rls or {}).get("mode", "unknown") if not a.is_redacted else "redacted",
            "; ".join((a.rls or {}).get("policies") or []) if not a.is_redacted else "redacted",
            "; ".join(f"{c.kind}:{c.name or c.id}" + (f" ({c.owner})" if c.owner else "") for c in a.consumers)
            if not a.is_redacted else "redacted",
            len(a.consumers) if not a.is_redacted else "redacted",
            "; ".join(f"{d.kind} #{d.id} {d.role} {d.state}" for d in a.dependencies) if not a.is_redacted else "redacted",
            _u(a.created_by, ""), _u(a.created_at, ""), _u(a.last_changed_by, ""), _u(a.last_changed_at, ""),
            last_at, _u(a.calls_7d),
        ])
    return buf.getvalue()


__all__ = ["CSV_COLUMNS", "InventoryUnavailable", "build_inventory", "filter_apis", "to_csv", "visible_to"]
