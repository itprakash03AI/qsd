"""Lifecycle of a published API: draft -> active -> deprecated -> retired
(2026-10-17, design §3.4).

Stored on the kind's own table in six ``api_lifecycle_*`` columns; NULL
status DERIVES from the kind's own flag (a view's ``is_active``, a report's
``is_published``) so no row needs a backfill and every existing API reads
``active`` or ``retired`` exactly as it behaved.

What a consumer sees:

* ``deprecated`` -> the call is served with ``Deprecation`` (RFC 9745 style:
  ``@<epoch>`` of the change), ``Sunset`` (RFC 8594, when a date is set) and
  ``Link: <successor>; rel="successor-version"`` headers, and the JSON
  envelope carries a ``deprecation`` block;
* ``retired``    -> ``published_views.lifecycle_retired_status`` (410 Gone by
  default; 404 is the other spelling an estate may want) with the note and
  the successor in the body and the headers -- and the call is RECORDED, so
  the dashboard shows who still calls it;
* ``draft``      -> 404 to consumers (listed to its owner).

Who may move it: the API's owner or an admin; ``retired -> active`` is an
admin's act.  A sunset in the past retires the API on the daemon's next tick
(``sweep_sunsets``); seven days before (``lifecycle_sunset_notice_days``) the
consumers are told once.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from email.utils import format_datetime
from typing import Any, Dict, Optional

from core.published_api.contract import (
    LIFECYCLE_ACTIVE, LIFECYCLE_COLUMNS, LIFECYCLE_DEPRECATED, LIFECYCLE_DRAFT, LIFECYCLE_RETIRED,
    LIFECYCLE_STATES,
)

logger = logging.getLogger(__name__)

#: Transitions anyone with edit rights may make; the rest need an admin.
OWNER_TRANSITIONS = {
    (LIFECYCLE_DRAFT, LIFECYCLE_ACTIVE), (LIFECYCLE_ACTIVE, LIFECYCLE_DEPRECATED),
    (LIFECYCLE_DEPRECATED, LIFECYCLE_ACTIVE), (LIFECYCLE_DEPRECATED, LIFECYCLE_RETIRED),
    (LIFECYCLE_ACTIVE, LIFECYCLE_RETIRED), (LIFECYCLE_ACTIVE, LIFECYCLE_DRAFT),
    (LIFECYCLE_DRAFT, LIFECYCLE_RETIRED), (LIFECYCLE_DEPRECATED, LIFECYCLE_DRAFT),
}
#: ``retired -> *`` is a governance act (an admin's): a retired API's
#: consumers were told it is gone.
ADMIN_ONLY_FROM = {LIFECYCLE_RETIRED}

OFFERED_STATES = {LIFECYCLE_ACTIVE, LIFECYCLE_DEPRECATED}


class LifecycleRefused(ValueError):
    """A lifecycle change the rules refuse; ``status`` is the HTTP status
    a route answers with (403 for a role, 422 for the shape)."""

    def __init__(self, message: str, status: int = 422):
        super().__init__(message)
        self.status = status


def _cfg(key: str, default):
    try:
        from core.config import published_views as _pv
        return getattr(_pv, key)
    except Exception:                                   # noqa: BLE001
        return default


def retired_status() -> int:
    """``published_views.lifecycle_retired_status`` (410)."""
    try:
        v = int(_cfg("lifecycle_retired_status", 410))
    except (TypeError, ValueError):
        v = 410
    return v if v in (404, 410) else 410


def sunset_notice_days() -> int:
    try:
        return max(0, int(_cfg("lifecycle_sunset_notice_days", 7)))
    except (TypeError, ValueError):
        return 7


# ── reading ───────────────────────────────────────────────────────────────

def _as_dt(v) -> Optional[datetime]:
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v if v.tzinfo else v.replace(tzinfo=timezone.utc)
    try:
        d = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def _get(obj, name, default=None):
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def effective_status(obj, offered: bool) -> str:
    """The lifecycle status of a row (ORM row or dict): the stored one, else
    DERIVED from the kind's flag -- offered = active, not offered = retired."""
    stored = _get(obj, "api_lifecycle_status")
    if stored in LIFECYCLE_STATES:
        return str(stored)
    return LIFECYCLE_ACTIVE if offered else LIFECYCLE_RETIRED


def lifecycle_of(obj, offered: bool) -> Dict[str, Any]:
    """The lifecycle block of an inventory row."""
    status = effective_status(obj, offered)
    sunset = _as_dt(_get(obj, "api_sunset_at"))
    changed = _as_dt(_get(obj, "api_lifecycle_changed_at"))
    return {
        "status": status,
        "stored": _get(obj, "api_lifecycle_status"),            # None = derived from the kind's flag
        "sunset_at": sunset.isoformat() if sunset else None,
        "deprecation_note": _get(obj, "api_deprecation_note"),
        "successor": _get(obj, "api_successor"),
        "changed_by": _get(obj, "api_lifecycle_changed_by"),
        "changed_at": changed.isoformat() if changed else None,
        "sunset_due": bool(sunset and sunset <= datetime.now(timezone.utc)),
    }


# ── what the consumer sees ────────────────────────────────────────────────

def consumer_headers(pv, *, kind: str = "published_view", base_path: str = "/api/v1/views") -> Dict[str, str]:
    """Headers for a DEPRECATED or RETIRED API's response; ``{}`` otherwise.
    ``pv`` is the view / report row or dict (the consumer routes hold a dict)."""
    status = _get(pv, "api_lifecycle_status")
    if status not in (LIFECYCLE_DEPRECATED, LIFECYCLE_RETIRED):
        return {}
    out: Dict[str, str] = {}
    changed = _as_dt(_get(pv, "api_lifecycle_changed_at"))
    out["Deprecation"] = f"@{int(changed.timestamp())}" if changed else "true"
    sunset = _as_dt(_get(pv, "api_sunset_at"))
    if sunset:
        out["Sunset"] = format_datetime(sunset, usegmt=True)
    succ = _get(pv, "api_successor")
    if succ:
        out["Link"] = f'<{base_path}/{succ}>; rel="successor-version"'
    return out


def deprecation_block(pv) -> Optional[Dict[str, Any]]:
    """The envelope's ``deprecation`` block for a deprecated API, else None."""
    if _get(pv, "api_lifecycle_status") != LIFECYCLE_DEPRECATED:
        return None
    sunset = _as_dt(_get(pv, "api_sunset_at"))
    return {"status": LIFECYCLE_DEPRECATED, "note": _get(pv, "api_deprecation_note"),
            "sunset_at": sunset.isoformat() if sunset else None, "successor": _get(pv, "api_successor")}


def refusal_for(info: Optional[Dict[str, Any]], *, slug: str, kind_word: str = "view") -> Dict[str, Any]:
    """What a consumer is answered for a slug the active lookup did not find:
    ``{"status", "detail", "headers", "refusal"}``.  ``info`` is the kind's
    lifecycle row for the slug (``get_published_view_lifecycle``) or None
    when no such API ever existed."""
    if not info:
        return {"status": 404, "detail": f"{kind_word.capitalize()} not found", "headers": {},
                "refusal": "not_found"}
    status = effective_status(info, bool(info.get("offered")))
    if status == LIFECYCLE_RETIRED:
        code = retired_status()
        note = info.get("api_deprecation_note") or ""
        succ = info.get("api_successor")
        detail = f"This {kind_word} ({slug}) has been retired"
        if note:
            detail += f": {note}"
        if succ:
            detail += f".  Use '{succ}' instead"
        hdrs = consumer_headers({**info, "api_lifecycle_status": LIFECYCLE_RETIRED})
        hdrs["X-QS-Refused"] = "retired"
        return {"status": code, "detail": detail + ".", "headers": hdrs, "refusal": "retired"}
    if status == LIFECYCLE_DRAFT:
        return {"status": 404, "detail": f"{kind_word.capitalize()} not found", "headers": {"X-QS-Refused": "draft"},
                "refusal": "draft"}
    # active / deprecated but the kind's flag is off (a deactivated row with
    # a stale status): the consumer sees what the flag says -- gone
    return {"status": 404, "detail": f"{kind_word.capitalize()} not found", "headers": {},
            "refusal": "not_found"}


# ── writing ───────────────────────────────────────────────────────────────

def validate_change(current: str, new: str, *, is_admin: bool, sunset_at, successor,
                    successor_exists: Optional[bool], successor_status: Optional[str]) -> None:
    """The rules a lifecycle change must pass; raises :class:`LifecycleRefused`."""
    if new not in LIFECYCLE_STATES:
        raise LifecycleRefused(f"status must be one of {LIFECYCLE_STATES}, not {new!r}")
    if current in ADMIN_ONLY_FROM and new != current and not is_admin:
        raise LifecycleRefused(f"only an admin may move a {current} API to {new} -- its consumers were "
                               f"told it is gone", status=403)
    if sunset_at is not None and new != LIFECYCLE_DEPRECATED:
        raise LifecycleRefused("a sunset date belongs to a deprecated API (deprecate it with the date)")
    if successor:
        if successor_exists is False:
            raise LifecycleRefused(f"successor {successor!r} is not a published API")
        if successor_status == LIFECYCLE_RETIRED:
            raise LifecycleRefused(f"successor {successor!r} is itself retired")


def fields_for(new: str, *, sunset_at, note, successor, actor: Optional[str]) -> Dict[str, Any]:
    """The six columns' new values for a change (the kind's flag follows
    through ``ApiKind.set_offered``)."""
    now = datetime.now(timezone.utc)
    return {
        "api_lifecycle_status": new,
        "api_sunset_at": _as_dt(sunset_at) if new == LIFECYCLE_DEPRECATED else None,
        "api_deprecation_note": (str(note)[:2000] if note else None) if new in (LIFECYCLE_DEPRECATED, LIFECYCLE_RETIRED) else None,
        "api_successor": (str(successor)[:220] if successor else None) if new in (LIFECYCLE_DEPRECATED, LIFECYCLE_RETIRED) else None,
        "api_lifecycle_changed_by": (str(actor)[:100] if actor else None),
        "api_lifecycle_changed_at": now,
    }


def is_offered(status: str) -> bool:
    return status in OFFERED_STATES


__all__ = ["ADMIN_ONLY_FROM", "LIFECYCLE_COLUMNS", "LifecycleRefused", "OFFERED_STATES", "OWNER_TRANSITIONS",
           "consumer_headers", "deprecation_block", "effective_status", "fields_for", "is_offered",
           "lifecycle_of", "refusal_for", "retired_status", "sunset_notice_days", "validate_change"]
