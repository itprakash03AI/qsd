"""The kinds of published API.  Each module registers its ``ApiKind`` on
import (core/published_api/registry.py imports them once)."""
