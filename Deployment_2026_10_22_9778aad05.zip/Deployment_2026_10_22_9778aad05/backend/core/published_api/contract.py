"""The ONE model of a published API and the ``ApiKind`` plugin seam
(2026-10-17, design §3.1).

A published API is an endpoint an external principal can call for data.  The
inventory row (:class:`PublishedApi`) is DERIVED from the owning tables every
time it is asked for -- never copied into a table of its own -- by the KIND
that owns it (:class:`ApiKind`): what rows exist, who owns them, what they
serve, which endpoints they expose, who may call them, what they rest on and
whether that still stands.  Only what no table holds became columns: the
LIFECYCLE (``api_lifecycle_*`` on the kind's table) and a key's consumer
identity.  ``broken`` and ``unknown`` are computed, never stored.

A kind is a declaration plus the few queries only it can write; everything
cross-kind (lifecycle, impact, numbers, export, routes) works on this shape
and nothing else.  A third kind registers itself in ``kinds/`` and appears
everywhere without a page or a route changing.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional

# ── lifecycle vocabulary ──────────────────────────────────────────────────
LIFECYCLE_DRAFT = "draft"
LIFECYCLE_ACTIVE = "active"
LIFECYCLE_DEPRECATED = "deprecated"
LIFECYCLE_RETIRED = "retired"
LIFECYCLE_STATES = (LIFECYCLE_DRAFT, LIFECYCLE_ACTIVE, LIFECYCLE_DEPRECATED, LIFECYCLE_RETIRED)

# ── health vocabulary (computed, never stored) ────────────────────────────
HEALTH_ACTIVE = "active"
HEALTH_BROKEN = "broken"
HEALTH_UNKNOWN = "unknown"

# ── dependency states ─────────────────────────────────────────────────────
DEP_OK = "ok"
DEP_MISSING = "missing"
DEP_INACTIVE = "inactive"
DEP_UNPUBLISHED = "unpublished"
DEP_UNKNOWN = "unknown"
DEP_BAD = (DEP_MISSING, DEP_INACTIVE, DEP_UNPUBLISHED)

#: The six lifecycle columns every kind's table carries (same names, so the
#: lifecycle module works on any kind's row).
LIFECYCLE_COLUMNS = ("api_lifecycle_status", "api_sunset_at", "api_deprecation_note",
                     "api_successor", "api_lifecycle_changed_by", "api_lifecycle_changed_at")


@dataclass
class Consumer:
    """Who may call the API: an API key, an AD group, a report token, every
    AD user (an empty allowed_ad_groups), the dev-mode guest."""
    kind: str                                 # api_key | ad_group | token | every_ad_user | dev_guest
    id: str                                   # apikey:<row id> | group:<name> | token:<8> | *
    name: str = ""
    owner: Optional[str] = None               # the person answerable (owner_username / created_by)
    consumer: Optional[str] = None            # the team / system a key represents
    contact: Optional[str] = None
    scope: str = "this_api"                   # this_api | every_api
    is_active: bool = True
    expires_at: Optional[str] = None
    last_used_at: Optional[str] = None
    identity: str = ""                        # the call record's consumer string (apikey:<id>, token:<8>)
    # 2026-10-18 -- a key's rate limit as DECLARED and as ENFORCED (the operator's
    # max_rate_limit cap applied by the one function core/published_api/rate_limits.py)
    rate_limit: Optional[str] = None
    effective_rate_limit: Optional[str] = None
    rate_limit_capped: Optional[bool] = None
    rate_limit_cap_reason: Optional[str] = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Dependency:
    """Something the API rests on, and whether it still stands."""
    kind: str                                 # connection | saved_query | sql_file | federation_view | business_report | dataset | report_version
    id: Optional[int]
    name: Optional[str] = None
    role: str = ""                            # primary | execution | engine | secondary | source | dataset | published_version
    state: str = DEP_UNKNOWN                  # ok | missing | inactive | unpublished | unknown
    reason: Optional[str] = None
    via: Optional[str] = None                 # the chain: "business_report #7 -> dataset #3"

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class Endpoint:
    method: str
    path: str
    formats: List[str] = field(default_factory=list)
    auth: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class PublishedApi:
    """One API as the inventory shows it."""
    api_kind: str
    api_id: int
    key: str                                   # the natural key (slug)
    name: str
    description: Optional[str] = None
    owner: Optional[str] = None
    owner_group: Optional[str] = None
    source: Dict[str, Any] = field(default_factory=dict)         # {"kind", "id", "name"}
    connections: List[Dict[str, Any]] = field(default_factory=list)
    endpoints: List[Endpoint] = field(default_factory=list)
    parameters: List[Dict[str, Any]] = field(default_factory=list)
    filters: List[str] = field(default_factory=list)
    definition_version: Optional[int] = None
    schema_version: Optional[int] = None
    schema_changed_at: Optional[str] = None
    rls: Dict[str, Any] = field(default_factory=dict)            # {"mode", "policies", "reason"}
    consumers: List[Consumer] = field(default_factory=list)
    lifecycle: Dict[str, Any] = field(default_factory=dict)      # {"status", "stored", "sunset_at", ...}
    health: Dict[str, Any] = field(default_factory=dict)         # {"state", "reasons": [...]}
    dependencies: List[Dependency] = field(default_factory=list)
    created_by: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None
    last_changed_by: Optional[str] = None
    last_changed_at: Optional[str] = None
    last_call: Dict[str, Any] = field(default_factory=dict)      # {"at", "consumer", "status"} | {"state": "unknown", "reason"}
    calls_7d: Optional[int] = None                               # None = unknown
    is_redacted: bool = False

    def to_dict(self) -> dict:
        d = asdict(self)
        d["endpoints"] = [e.to_dict() if isinstance(e, Endpoint) else e for e in self.endpoints]
        d["consumers"] = [c.to_dict() if isinstance(c, Consumer) else c for c in self.consumers]
        d["dependencies"] = [x.to_dict() if isinstance(x, Dependency) else x for x in self.dependencies]
        return d

    def redacted(self) -> "PublishedApi":
        """The catalog entry another publisher may see: what it is and whether
        it stands; never its query, consumers, parameters or dependencies."""
        return PublishedApi(api_kind=self.api_kind, api_id=self.api_id, key=self.key, name=self.name,
                            description=self.description, owner=self.owner, lifecycle=dict(self.lifecycle),
                            health={"state": self.health.get("state"), "reasons": []},
                            endpoints=list(self.endpoints), is_redacted=True)


def health_from(dependencies: List[Dependency]) -> Dict[str, Any]:
    """``broken`` when any dependency is gone / inactive / unpublished;
    ``unknown`` when any could not be read (never active); else active."""
    def _words(d: Dependency, default: str) -> str:
        return d.reason or f"{d.kind} #{d.id} ({d.role}) {default}"

    bad = [d for d in dependencies if d.state in DEP_BAD]
    if bad:
        return {"state": HEALTH_BROKEN, "reasons": [_words(d, f"is {d.state}") for d in bad]}
    unknown = [d for d in dependencies if d.state == DEP_UNKNOWN]
    if unknown:
        return {"state": HEALTH_UNKNOWN, "reasons": [_words(d, "could not be read") for d in unknown]}
    return {"state": HEALTH_ACTIVE, "reasons": []}


class ApiKind:
    """The plugin seam.  A kind implements the queries only it can write; the
    base gives it nothing it must repeat."""

    kind: str = ""
    model: Any = None                          # the owning ORM model
    #: the ORM column names the lifecycle module writes (the six, on this model)
    lifecycle_columns: tuple = LIFECYCLE_COLUMNS

    # -- rows ----------------------------------------------------------------
    def rows(self, session) -> list:
        """Every object of this kind the inventory lists (every lifecycle state)."""
        raise NotImplementedError

    def row(self, session, api_id: int):
        return session.query(self.model).filter(self.model.id == int(api_id)).first()

    def row_by_key(self, session, key: str):
        return session.query(self.model).filter(self.model.slug == str(key)).first()

    def key_of(self, row) -> str:
        return str(getattr(row, "slug", None) or row.id)

    def is_offered(self, row) -> bool:
        """Does the kind's own flag say this object is offered to consumers
        (a view's is_active, a report's is_published)?  The lifecycle's
        derived state reads it when no explicit status is stored."""
        raise NotImplementedError

    def set_offered(self, row, offered: bool) -> None:
        """The kind's own flag follows the lifecycle (active / deprecated =
        offered; draft / retired = not)."""
        raise NotImplementedError

    # -- the inventory row --------------------------------------------------
    def build(self, session, rows: list, ctx: "BuildContext") -> List[PublishedApi]:
        """Every PublishedApi of these rows, in a BOUNDED number of queries
        (one per lookup kind, never one per row)."""
        raise NotImplementedError

    def endpoints(self, row) -> List[Endpoint]:
        raise NotImplementedError

    # -- what the call record names -----------------------------------------
    def owner_of(self, row) -> Optional[str]:
        return getattr(row, "created_by", None)


@dataclass
class BuildContext:
    """What a build already looked up, so kinds share lookups: the keys, the
    dependency rows by kind, the numbers, the audit tail."""
    db: Any
    keys: list = field(default_factory=list)                     # api_keys rows (dicts)
    numbers: Dict[tuple, Dict[str, Any]] = field(default_factory=dict)   # (kind, id) -> {last_call, calls_7d}
    numbers_error: Optional[str] = None
    audit: Dict[tuple, Dict[str, Any]] = field(default_factory=dict)     # (resource_type, id) -> {username, timestamp}
    problems: List[str] = field(default_factory=list)            # lookups that failed (said on the answer)


__all__ = ["ApiKind", "BuildContext", "Consumer", "DEP_BAD", "DEP_INACTIVE", "DEP_MISSING", "DEP_OK",
           "DEP_UNKNOWN", "DEP_UNPUBLISHED", "Dependency", "Endpoint", "HEALTH_ACTIVE", "HEALTH_BROKEN",
           "HEALTH_UNKNOWN", "LIFECYCLE_ACTIVE", "LIFECYCLE_COLUMNS", "LIFECYCLE_DEPRECATED",
           "LIFECYCLE_DRAFT", "LIFECYCLE_RETIRED", "LIFECYCLE_STATES", "PublishedApi", "health_from"]
