"""The dependency graph of the published APIs: what each rests on, whether
it still stands, and what breaks if an object goes (2026-10-17, design §3.5).

ONE reader.  :class:`DependencyResolver` fetches each dependency kind's rows
in ONE ``IN`` query per kind, memoised for the build, and answers the state
of a reference: ``ok`` / ``missing`` / ``inactive`` / ``unpublished`` -- or
``unknown`` with the reason when the lookup itself failed (never "ok" by
default, never "missing" by default).  :func:`impact_of` walks the whole
inventory's dependencies (bounded: a handful of queries for every API) and
names the APIs that would break if one object went, with their consumers --
the delete routes refuse with that list, the inventory shows it, and the
daemon raises ``api_dependency_broken`` from it.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Iterable, List, Optional, Tuple

from core.published_api.contract import (
    DEP_INACTIVE, DEP_MISSING, DEP_OK, DEP_UNKNOWN, DEP_UNPUBLISHED, Dependency, PublishedApi,
)

logger = logging.getLogger(__name__)

#: dependency kind -> (table / model name, the "alive" rule)
DEPENDENCY_KINDS = ("connection", "saved_query", "sql_file", "federation_view", "business_report",
                    "dataset", "system_account", "report_version")

#: The words a dependency sentence uses: ``the <WORDS[kind]> it <VERBS[role]> (#id) ...``
WORDS = {"connection": "connection", "saved_query": "saved query", "sql_file": "SQL file",
         "federation_view": "federation view", "business_report": "finance report", "dataset": "dataset",
         "system_account": "system account", "report_version": "published version", "published_view": "published view"}
VERBS = {"source": "serves", "primary": "runs on", "execution": "executes on", "engine": "may run on",
         "secondary": "also reads", "dataset": "reads", "merged_dataset": "merges", "published_version": "serves"}

#: The query-string / route parameter names ``GET /api/published-apis/impact`` takes.
IMPACT_PARAMS = {"connection_id": "connection", "saved_query_id": "saved_query", "sql_file_id": "sql_file",
                 "federation_view_id": "federation_view", "report_id": "business_report",
                 "dataset_id": "dataset", "system_account_id": "system_account"}


class DependencyResolver:
    """Rows of each dependency kind, fetched once per kind for a build."""

    def __init__(self, session):
        self.session = session
        self._cache: Dict[str, Dict[int, Any]] = {}
        self._errors: Dict[str, str] = {}

    # -- fetching ---------------------------------------------------------------
    def _model(self, kind: str):
        from core.db import models as m
        return {"connection": m.Connection, "saved_query": m.SavedQuery, "sql_file": m.SqlFile,
                "federation_view": m.FederationView, "business_report": m.BusinessReport,
                "dataset": m.BusinessDataset, "system_account": m.SystemAccount}[kind]

    def load(self, kind: str, ids: Iterable[Any]) -> None:
        """Fetch the rows of ``kind`` for these ids (those not loaded yet), ONE query."""
        want = set()
        for i in ids or []:
            try:
                want.add(int(i))
            except (TypeError, ValueError):
                continue
        have = self._cache.setdefault(kind, {})
        missing = [i for i in want if i not in have]
        if not missing:
            return
        try:
            model = self._model(kind)
            for row in self.session.query(model).filter(model.id.in_(missing)).all():
                have[int(row.id)] = row
            for i in missing:
                have.setdefault(i, None)                      # looked up, absent
        except Exception as exc:                            # noqa: BLE001 -- unknown, said per reference
            self._errors[kind] = f"{type(exc).__name__}: {str(exc)[:200]}"
            logger.warning("[published-api] dependency lookup of %s failed: %s", kind, exc)

    def get(self, kind: str, obj_id: Any):
        try:
            return self._cache.get(kind, {}).get(int(obj_id))
        except (TypeError, ValueError):
            return None

    def error(self, kind: str) -> Optional[str]:
        return self._errors.get(kind)

    # -- the state of one reference ----------------------------------------------
    def dependency(self, kind: str, obj_id: Any, *, role: str, via: Optional[str] = None) -> Dependency:
        """The dependency with its state and a SENTENCE an operator reads
        ("the finance report it serves (#7) no longer exists")."""
        what = f"the {WORDS.get(kind, kind)} it {VERBS.get(role, 'uses')}"
        if obj_id in (None, "", 0):
            return Dependency(kind=kind, id=None, role=role, state=DEP_MISSING,
                              reason=f"{what} is not recorded (no reference stored)", via=via)
        err = self.error(kind)
        if err:
            return Dependency(kind=kind, id=int(obj_id), role=role, state=DEP_UNKNOWN,
                              reason=f"{what} (#{obj_id}) could not be read: {err}", via=via)
        row = self.get(kind, obj_id)
        if row is None:
            return Dependency(kind=kind, id=int(obj_id), role=role, state=DEP_MISSING,
                              reason=f"{what} (#{obj_id}) no longer exists", via=via)
        name = getattr(row, "name", None) or getattr(row, "slug", None) or getattr(row, "file_path", None)
        state, reason = DEP_OK, None
        if kind == "business_report":
            if getattr(row, "lifecycle_status", None) == "archived":
                state, reason = DEP_UNPUBLISHED, f"{what} (#{obj_id}) is archived (consumers get 410)"
            elif not getattr(row, "is_published", False):
                state, reason = DEP_UNPUBLISHED, f"{what} (#{obj_id}) is not published (consumers get 410)"
        elif kind == "dataset":
            pass                                              # a dataset runs whether or not it is published
        elif hasattr(row, "is_active") and not getattr(row, "is_active"):
            state, reason = DEP_INACTIVE, f"{what} (#{obj_id}) is inactive"
        return Dependency(kind=kind, id=int(obj_id), name=str(name) if name is not None else None,
                          role=role, state=state, reason=reason, via=via)


def connection_ids_of_dataset(ds_row) -> List[int]:
    out = []
    for c in (getattr(ds_row, "connection_ids", None) or []):
        try:
            out.append(int(c))
        except (TypeError, ValueError):
            continue
    return out


# ── what breaks if ───────────────────────────────────────────────────────

def dependents_of(apis: Iterable[PublishedApi], kind: str, obj_id: int) -> List[Dict[str, Any]]:
    """Every API among ``apis`` that names (kind, obj_id) in its dependencies,
    with the roles it fills and the API's consumers."""
    out = []
    for api in apis:
        if (api.lifecycle or {}).get("status") == "retired":
            continue                                        # nothing is served; nothing breaks
        roles = sorted({d.role for d in api.dependencies
                        if d.kind == kind and d.id is not None and int(d.id) == int(obj_id)})
        # NOT the report's own token API: deleting a report RETIRES it -- its
        # tokens are deactivated by the delete (2026-09-15 contract,
        # tests/test_published_surfaces_revoke_2026_09_15.py); only OTHER APIs
        # resting on the report block
        if not roles:
            continue
        out.append({
            "api_kind": api.api_kind, "api_id": api.api_id, "key": api.key, "name": api.name,
            "owner": api.owner, "lifecycle": api.lifecycle.get("status"), "roles": roles,
            "would": ("break" if any(r in ("primary", "source", "dataset", "published_version") for r in roles)
                      else ("lose its execution connection" if "execution" in roles
                            else "lose an engine option" if "engine" in roles else "break")),
            "consumers": [{"kind": c.kind, "id": c.id, "name": c.name, "owner": c.owner}
                          for c in api.consumers if c.is_active],
        })
    return out


def impact_of(db, kind: str, obj_id: int) -> Dict[str, Any]:
    """``{"kind", "id", "dependents": [...], "count", "unknown": bool, "reason"}``
    -- computed over the WHOLE inventory (bounded queries), so one answer
    serves the delete routes, the inventory and the daemon.  ``unknown`` is
    True when the inventory itself could not be built: the caller refuses
    (never "nothing depends on it")."""
    from core.published_api.inventory import build_inventory
    try:
        apis, meta = build_inventory(db)
    except Exception as exc:                                # noqa: BLE001
        return {"kind": kind, "id": int(obj_id), "dependents": [], "count": 0, "unknown": True,
                "reason": f"the inventory could not be built: {type(exc).__name__}: {str(exc)[:200]}"}
    deps = dependents_of(apis, kind, int(obj_id))
    return {"kind": kind, "id": int(obj_id), "dependents": deps, "count": len(deps), "unknown": False,
            "reason": None, "problems": list(meta.get("problems") or [])}


class ImpactRefused(Exception):
    """A delete the published APIs refuse (or could not judge).  ``status``
    409 = dependents named; 503 = could not check (never "has none")."""

    def __init__(self, status: int, detail: str, dependents: Optional[List[dict]] = None):
        super().__init__(detail)
        self.status = status
        self.detail = detail
        self.dependents = list(dependents or [])


def refuse_if_apis_depend(db, kind: str, obj_id: int, *, acknowledged: bool, actor: Optional[dict],
                          action: str, audit) -> List[dict]:
    """The delete routes' ONE rule: refuse (409) naming the published APIs
    (and their consumers) that rest on the object; refuse (503) when that
    cannot be checked; with ``acknowledged`` proceed and audit the names.
    Returns the dependents (for the route's own log)."""
    verdict = impact_of(db, kind, int(obj_id))
    if verdict["unknown"]:
        raise ImpactRefused(503, f"Could not check which published APIs rest on this {kind}: "
                                 f"{verdict['reason']} -- refusing rather than breaking their consumers.  Retry.")
    deps = verdict["dependents"]
    if deps and not acknowledged:
        # the 2026-09-27 sentence named each view with its id; this one names
        # the kind, the key and the consumers as well -- strictly more
        names = ", ".join(f"{d['name']!r} (id {d['api_id']}, {d['api_kind']} {d['key']}, "
                          f"{len(d['consumers'])} consumer(s), would {d['would']})"
                          for d in deps[:20])
        more = f" and {len(deps) - 20} more" if len(deps) > 20 else ""
        raise ImpactRefused(409, f"{len(deps)} published API(s) rest on this {kind}: {names}{more}.  "
                                 f"Deleting it breaks their consumers.  Retire or re-point them first, or "
                                 f"delete anyway with acknowledge_dependents=true (audited).", deps)
    if deps and audit is not None:
        try:
            # the 2026-09-27 audit carried {"published_views": [{id, name}]}; this
            # row carries every API kind with id, NAME, key and consumer count
            audit(db, actor or {}, None, action, kind, int(obj_id),
                  {"published_apis": [{"kind": d["api_kind"], "id": d["api_id"], "name": d["name"], "key": d["key"],
                                       "consumers": len(d["consumers"])} for d in deps]})
        except Exception as exc:                            # noqa: BLE001
            logger.warning("[published-api] dependency-removed audit not written: %s", exc)
    return deps


__all__ = ["DEPENDENCY_KINDS", "DependencyResolver", "IMPACT_PARAMS", "ImpactRefused",
           "connection_ids_of_dataset", "dependents_of", "impact_of", "refuse_if_apis_depend"]
