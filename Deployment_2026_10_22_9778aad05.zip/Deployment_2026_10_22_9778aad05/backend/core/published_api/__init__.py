"""Published APIs -- ONE inventory, ONE call record, ONE set of numbers
(2026-10-17, docs/PUBLISHED_API_INVENTORY_DASHBOARD_DESIGN_2026_10_17.html).

A published API is an endpoint an external principal can call for data: a
published VIEW (``/api/v1/views/{slug}/*``, GraphQL ``publishedViewData``,
bulk) or a published REPORT reached by an embed / share token.  This package
holds what is common to every kind:

* ``calls``     -- THE call record (``api_access_log``) and the refusal
                   recorder: every consumer route records a call or a refusal
                   through here, off the request (core/access_log_batcher.py).
* ``contract``  -- the ``ApiKind`` plugin seam and the inventory row.
* ``registry``  -- the kinds that exist (``kinds/*`` register on import).
* ``impact``    -- the dependency graph: what an API rests on, what breaks.
* ``consumers`` -- ONE answer to "may this key call this view".
* ``lifecycle`` -- draft / active / deprecated / retired, sunset, successor.
* ``rollup``    -- hourly / daily buckets with a latency histogram, rolled
                   by a scheduler-pod daemon; ``latency`` reads percentiles.
* ``alerts``    -- threshold rows evaluated after the roll, raised through
                   THE alert road with an AlertSubject of kind published_api.
"""
