"""The rollup: raw call rows folded into hourly and daily buckets per
(API, consumer, endpoint), by a scheduler-pod daemon, OFF the hot path
(2026-10-17, design §3.7).

ONE pass (:func:`roll`):

1. the window = every hour from ``rolled_through - rollup_lag_minutes`` to
   the current hour -- late batches (a pod's flush interval, a dead pod's
   last rows) land inside the lag and are folded in;
2. refusals recorded BEFORE the view was read carry a slug and no id
   (core/published_api/calls.py): the slugs seen in the window are resolved
   to (kind, id) once per pass; a slug that names nothing stays the
   "unknown API" line;
3. per hour bucket: the raw rows are folded in Python (counts by status
   class and code, refusals by reason, rows, bytes, cache, latency sum / min
   / max and the log-spaced histogram), then the bucket's hourly rows are
   REPLACED in one transaction -- idempotent, a second pass gives the same
   rows;
4. the touched DAYS are re-summed from the hourly rows (bins add);
5. ``rolled_through`` advances to the newest hour that ended before the lag;
6. retention: hourly rows older than ``rollup_hourly_retention_days``, daily
   older than ``rollup_daily_retention_days`` (0 = keep).

The tick returns a dict the background-job contract classifies (``ran`` /
``no_input`` / ``skipped`` / ``error``); the state row carries the
watermark every dashboard answer shows ("numbers end at HH:MM").
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Iterable, List, Optional, Tuple

from core.published_api import latency as lat

logger = logging.getLogger(__name__)

GRAIN_HOUR = "hour"
GRAIN_DAY = "day"
UNKNOWN_KIND = ""           # the key column cannot be NULL: '' / 0 = "unknown API" (api_slug kept)
UNKNOWN_ID = 0

#: the refusal reasons counted (others fold into "other")
REFUSALS = ("rate_limit", "key_concurrency", "lane_full", "bulk_lane", "bulk_per_key", "memory_pressure",
            "unauthenticated", "forbidden", "not_found", "retired", "draft", "ceiling", "dataset_version",
            "timeout", "unavailable")


def _cfg(key: str, default):
    try:
        from core.config import published_views as _pv
        return getattr(_pv, key)
    except Exception:                                   # noqa: BLE001
        return default


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _naive(dt: datetime) -> datetime:
    return dt.astimezone(timezone.utc).replace(tzinfo=None) if dt.tzinfo else dt


def _aware(dt) -> Optional[datetime]:
    if dt is None:
        return None
    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt.replace("Z", "+00:00"))
        except ValueError:
            return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def floor_hour(dt: datetime) -> datetime:
    return dt.replace(minute=0, second=0, microsecond=0)


def floor_day(dt: datetime) -> datetime:
    return dt.replace(hour=0, minute=0, second=0, microsecond=0)


# ── folding ───────────────────────────────────────────────────────────────

class _Acc:
    __slots__ = ("calls", "ok", "redir", "c4", "c5", "by_status", "refused", "rows", "bytes", "bytes_known",
                 "hit", "miss", "bypass", "lat_sum", "lat_min", "lat_max", "bins", "last_at", "slug")

    def __init__(self, slug: Optional[str]):
        self.calls = self.ok = self.redir = self.c4 = self.c5 = 0
        self.by_status: Dict[str, int] = {}
        self.refused: Dict[str, int] = {}
        self.rows = self.bytes = self.bytes_known = 0
        self.hit = self.miss = self.bypass = 0
        self.lat_sum = 0
        self.lat_min: Optional[int] = None
        self.lat_max: Optional[int] = None
        self.bins = lat.empty_bins()
        self.last_at: Optional[datetime] = None
        self.slug = slug

    def add(self, r: Dict[str, Any], ratio: float) -> None:
        self.calls += 1
        st = int(r.get("status_code") or 0)
        if 200 <= st < 300:
            self.ok += 1
        elif 300 <= st < 400:
            self.redir += 1
        elif 400 <= st < 500:
            self.c4 += 1
        elif st >= 500:
            self.c5 += 1
        self.by_status[str(st)] = self.by_status.get(str(st), 0) + 1
        ref = r.get("refusal")
        if ref:
            k = str(ref) if str(ref) in REFUSALS else "other"
            self.refused[k] = self.refused.get(k, 0) + 1
        self.rows += int(r.get("response_rows") or 0)
        if r.get("response_bytes") is not None:
            self.bytes += int(r.get("response_bytes") or 0)
            self.bytes_known += 1
        cs = str(r.get("cache_status") or "").upper()
        if cs == "HIT":
            self.hit += 1
        elif cs == "MISS":
            self.miss += 1
        elif cs == "BYPASS":
            self.bypass += 1
        ms = r.get("response_ms")
        if ms is not None:
            ms = int(ms)
            self.lat_sum += ms
            self.lat_min = ms if self.lat_min is None else min(self.lat_min, ms)
            self.lat_max = ms if self.lat_max is None else max(self.lat_max, ms)
            self.bins[lat.bin_of(ms, ratio)] += 1
        at = _aware(r.get("created_at"))
        if at and (self.last_at is None or at > self.last_at):
            self.last_at = at
        if not self.slug and r.get("api_slug"):
            self.slug = r.get("api_slug")

    def row(self, grain: str, bucket: datetime, kind: str, api_id: int, consumer: str, endpoint: str) -> dict:
        return {"grain": grain, "bucket_start": _naive(bucket), "api_kind": kind, "api_id": api_id,
                "api_slug": self.slug, "consumer": consumer, "endpoint": endpoint,
                "calls": self.calls, "ok_2xx": self.ok, "redirect_3xx": self.redir, "client_4xx": self.c4,
                "server_5xx": self.c5, "by_status": self.by_status, "refused": self.refused,
                "rows_sum": self.rows, "bytes_sum": self.bytes, "bytes_known_calls": self.bytes_known,
                "cache_hit": self.hit, "cache_miss": self.miss, "cache_bypass": self.bypass,
                "latency_ms_sum": self.lat_sum, "latency_ms_min": self.lat_min, "latency_ms_max": self.lat_max,
                "latency_bins": self.bins, "last_call_at": _naive(self.last_at) if self.last_at else None,
                "rolled_at": _naive(_utcnow())}


def resolve_slugs(db, slugs: Iterable[str]) -> Dict[str, Tuple[str, int]]:
    """slug -> (kind, id) for the slugs the window named without an id."""
    want = {s for s in slugs if s}
    if not want:
        return {}
    out: Dict[str, Tuple[str, int]] = {}
    from core.db.models import BusinessReport, PublishedView
    with db.get_session(read_only=True) as session:
        for sid, slug in session.query(PublishedView.id, PublishedView.slug).filter(PublishedView.slug.in_(list(want))).all():
            out[str(slug)] = ("published_view", int(sid))
        rest = want - set(out)
        if rest:
            for sid, slug in session.query(BusinessReport.id, BusinessReport.slug).filter(BusinessReport.slug.in_(list(rest))).all():
                out[str(slug)] = ("published_report", int(sid))
    return out


def resolve_names(db, pairs: Iterable[Tuple[str, int]]) -> Dict[Tuple[str, int], str]:
    """(kind, id) -> slug for rolled rows that carry an id and no slug (a
    pre-2026-10-17 row knew only its view_id)."""
    want = {(k, int(i)) for k, i in pairs if k and i}
    if not want:
        return {}
    out: Dict[Tuple[str, int], str] = {}
    from core.db.models import BusinessReport, PublishedView
    with db.get_session(read_only=True) as session:
        vids = [i for k, i in want if k == "published_view"]
        if vids:
            for sid, slug in session.query(PublishedView.id, PublishedView.slug).filter(PublishedView.id.in_(vids)).all():
                out[("published_view", int(sid))] = str(slug)
        rids = [i for k, i in want if k == "published_report"]
        if rids:
            for sid, slug in session.query(BusinessReport.id, BusinessReport.slug).filter(BusinessReport.id.in_(rids)).all():
                if slug:
                    out[("published_report", int(sid))] = str(slug)
    return out


def fold_bucket(rows: Iterable[Dict[str, Any]], *, grain: str, bucket: datetime, slug_map: Dict[str, Tuple[str, int]],
                ratio: float) -> List[dict]:
    """The rollup rows of one bucket from its raw rows."""
    accs: Dict[tuple, _Acc] = {}
    for r in rows:
        kind = r.get("api_kind")
        api_id = r.get("api_id")
        if api_id is None and r.get("view_id") is not None:
            kind, api_id = (kind or "published_view"), r.get("view_id")
        if api_id is None and r.get("api_slug") and r.get("api_slug") in slug_map:
            kind, api_id = slug_map[r["api_slug"]]
        if api_id is None:
            kind, api_id = UNKNOWN_KIND, UNKNOWN_ID
        kind = str(kind or (UNKNOWN_KIND if int(api_id) == UNKNOWN_ID else "published_view"))
        key = (kind, int(api_id), str(r.get("consumer") or ""), str(r.get("endpoint") or ""))
        acc = accs.get(key)
        if acc is None:
            acc = accs[key] = _Acc(r.get("api_slug"))
        acc.add(r, ratio)
    return [acc.row(grain, bucket, k[0], k[1], k[2], k[3]) for k, acc in accs.items()]


def sum_rows(rows: Iterable[dict], *, grain: str, bucket: datetime) -> List[dict]:
    """Daily rows from hourly rows (bins add, min / max fold, last call max)."""
    accs: Dict[tuple, dict] = {}
    for r in rows:
        key = (r["api_kind"], int(r["api_id"]), r["consumer"], r["endpoint"])
        a = accs.get(key)
        if a is None:
            a = accs[key] = {"grain": grain, "bucket_start": _naive(bucket), "api_kind": r["api_kind"],
                             "api_id": int(r["api_id"]), "api_slug": r.get("api_slug"), "consumer": r["consumer"],
                             "endpoint": r["endpoint"], "calls": 0, "ok_2xx": 0, "redirect_3xx": 0, "client_4xx": 0,
                             "server_5xx": 0, "by_status": {}, "refused": {}, "rows_sum": 0, "bytes_sum": 0,
                             "bytes_known_calls": 0, "cache_hit": 0, "cache_miss": 0, "cache_bypass": 0,
                             "latency_ms_sum": 0, "latency_ms_min": None, "latency_ms_max": None,
                             "latency_bins": lat.empty_bins(), "last_call_at": None, "rolled_at": _naive(_utcnow())}
        for k in ("calls", "ok_2xx", "redirect_3xx", "client_4xx", "server_5xx", "rows_sum", "bytes_sum",
                  "bytes_known_calls", "cache_hit", "cache_miss", "cache_bypass", "latency_ms_sum"):
            a[k] += int(r.get(k) or 0)
        for d in ("by_status", "refused"):
            for kk, vv in (r.get(d) or {}).items():
                a[d][kk] = a[d].get(kk, 0) + int(vv or 0)
        if r.get("latency_ms_min") is not None:
            a["latency_ms_min"] = r["latency_ms_min"] if a["latency_ms_min"] is None else min(a["latency_ms_min"], r["latency_ms_min"])
        if r.get("latency_ms_max") is not None:
            a["latency_ms_max"] = r["latency_ms_max"] if a["latency_ms_max"] is None else max(a["latency_ms_max"], r["latency_ms_max"])
        a["latency_bins"] = lat.merge_bins([a["latency_bins"], r.get("latency_bins") or []])
        la = _aware(r.get("last_call_at"))
        if la and (a["last_call_at"] is None or la > _aware(a["last_call_at"])):
            a["last_call_at"] = _naive(la)
        if not a.get("api_slug") and r.get("api_slug"):
            a["api_slug"] = r["api_slug"]
    return list(accs.values())


# ── the pass ──────────────────────────────────────────────────────────────

def roll(db, *, now: Optional[datetime] = None) -> Dict[str, Any]:
    """One pass.  Returns the tick's summary dict."""
    if not bool(_cfg("rollup_enabled", True)):
        return {"status": "skipped", "reason": "published_views.rollup_enabled is false"}
    now = _aware(now) or _utcnow()
    lag = timedelta(minutes=max(0, int(_cfg("rollup_lag_minutes", 10))))
    ratio = lat.bin_ratio()
    state = db.get_published_api_rollup_state(GRAIN_HOUR) or {}
    recorded_ratio = state.get("bin_ratio")
    if recorded_ratio not in (None, "") and abs(float(recorded_ratio) - ratio) > 1e-9:
        msg = (f"published_views.rollup_latency_bin_ratio is {ratio} but the rollup rows were built with "
               f"{recorded_ratio}: refusing to mix two histograms (drop the rollups to change the ratio)")
        db.set_published_api_rollup_state(GRAIN_HOUR, last_error=msg, last_tick_at=_naive(now))
        return {"status": "error", "error": msg}
    rolled_through = _aware(state.get("rolled_through"))
    if rolled_through is None:
        oldest = _aware(db.oldest_api_access_log_at())
        if oldest is None:
            db.set_published_api_rollup_state(GRAIN_HOUR, last_tick_at=_naive(now), last_tick_rows=0, last_error=None,
                                              bin_ratio=ratio)
            return {"status": "no_input", "buckets": 0, "rows": 0, "reason": "no call rows yet"}
        start = floor_hour(oldest)
    else:
        start = floor_hour(rolled_through + timedelta(hours=1) - lag)
    current_hour = floor_hour(now)
    buckets: List[datetime] = []
    b = start
    while b <= current_hour:
        buckets.append(b)
        b += timedelta(hours=1)
    # slugs with no id in the window, once
    slug_map = resolve_slugs(db, db.api_access_log_unresolved_slugs(_naive(start), _naive(current_hour + timedelta(hours=1))))
    total_rows = 0
    touched_days = set()
    folded: List[Tuple[datetime, List[dict]]] = []
    for bucket in buckets:
        raw = db.iter_api_access_log_rows(_naive(bucket), _naive(bucket + timedelta(hours=1)))
        folded.append((bucket, fold_bucket(raw, grain=GRAIN_HOUR, bucket=bucket, slug_map=slug_map, ratio=ratio)))
    # rows that know their id but not their slug (pre-2026-10-17 history): named once
    names = resolve_names(db, [(r["api_kind"], r["api_id"]) for _b, rows in folded for r in rows
                               if not r.get("api_slug") and r["api_id"] != UNKNOWN_ID])
    for bucket, rows in folded:
        for r in rows:
            if not r.get("api_slug"):
                r["api_slug"] = names.get((r["api_kind"], r["api_id"]))
        db.replace_published_api_rollup_bucket(GRAIN_HOUR, _naive(bucket), rows)
        total_rows += len(rows)
        touched_days.add(floor_day(bucket))
    for day in sorted(touched_days):
        hourly = db.list_published_api_rollups(GRAIN_HOUR, _naive(day), _naive(day + timedelta(days=1)))
        db.replace_published_api_rollup_bucket(GRAIN_DAY, _naive(day), sum_rows(hourly, grain=GRAIN_DAY, bucket=day))
    # the watermark: the newest hour that ENDED before the lag
    final = floor_hour(now - lag) - timedelta(hours=1)
    new_through = max(final, rolled_through) if rolled_through else final
    swept = retention(db, now=now)
    db.set_published_api_rollup_state(GRAIN_HOUR, rolled_through=_naive(new_through), last_tick_at=_naive(now),
                                      last_tick_rows=total_rows, last_error=None, bin_ratio=ratio)
    db.set_published_api_rollup_state(GRAIN_DAY, rolled_through=_naive(floor_day(new_through)), last_tick_at=_naive(now),
                                      last_tick_rows=len(touched_days), last_error=None, bin_ratio=ratio)
    return {"status": "ran" if total_rows else "no_input", "buckets": len(buckets), "rows": total_rows,
            "days": len(touched_days), "rolled_through": new_through.isoformat(), "swept": swept}


def tick(db, *, now: Optional[datetime] = None) -> Dict[str, Any]:
    """THE daemon's tick -- ONE definition for the periodic thread and for a
    run-now through the background-job contract: the roll, then the alert
    pass over the rolled numbers (core/published_api/alerts.py::after_roll --
    thresholds, dependency-broken, sunsets).  The alert pass runs even when
    the roll had no input (a dependency breaks without a call); it is skipped
    when the roll itself failed (its numbers would be stale)."""
    out = roll(db, now=now)
    # the writers' heartbeat rows: a process the generic silence rule says is
    # RETIRED (superseded on its pod, or silent past the retire window) is
    # gone with its container; its counters must not haunt /health
    try:
        from core.published_api.ingest_health import retire as _retire_ingest
        out["ingest_health_retired"] = int(_retire_ingest(db, now=now).get("rows_deleted") or 0)
    except Exception as exc:                            # noqa: BLE001
        out["ingest_health_retired"] = f"error: {type(exc).__name__}: {exc}"
    if out.get("status") == "error":
        out["alerts"] = {"status": "skipped", "reason": "the roll failed; the alert pass needs its numbers"}
        return out
    try:
        from core.published_api.alerts import after_roll
        out["alerts"] = after_roll(db, now=now)
    except Exception as exc:                            # noqa: BLE001 -- the roll's result stands
        logger.exception("[published-api rollup] the alert pass failed")
        out["alerts"] = {"status": "error", "error": f"{type(exc).__name__}: {exc}"}
    return out


def retention(db, *, now: Optional[datetime] = None) -> Dict[str, int]:
    now = _aware(now) or _utcnow()
    out = {"hourly_deleted": 0, "daily_deleted": 0}
    hd = int(_cfg("rollup_hourly_retention_days", 400) or 0)
    if hd > 0:
        out["hourly_deleted"] = int(db.delete_published_api_rollups_before(GRAIN_HOUR, _naive(now - timedelta(days=hd))) or 0)
    dd = int(_cfg("rollup_daily_retention_days", 0) or 0)
    if dd > 0:
        out["daily_deleted"] = int(db.delete_published_api_rollups_before(GRAIN_DAY, _naive(now - timedelta(days=dd))) or 0)
    return out


def watermark(db) -> Dict[str, Any]:
    """What the dashboard says about its own currency."""
    st = db.get_published_api_rollup_state(GRAIN_HOUR) or {}
    through = _aware(st.get("rolled_through"))
    now = _utcnow()
    return {"rolled_through": through.isoformat() if through else None,
            "numbers_end_at": (through + timedelta(hours=1)).isoformat() if through else None,
            "lag_seconds": int((now - through - timedelta(hours=1)).total_seconds()) if through else None,
            "last_tick_at": st.get("last_tick_at"), "last_tick_rows": st.get("last_tick_rows"),
            "last_error": st.get("last_error"), "bin_ratio": st.get("bin_ratio"),
            "state": ("never_rolled" if not st else ("error" if st.get("last_error") else "ok"))}


# ── reading ───────────────────────────────────────────────────────────────

def _key_of(row: dict, group_by: str) -> str:
    if group_by == "api":
        return f"{row['api_kind'] or 'unknown'}:{row['api_slug'] or row['api_id']}"
    if group_by == "consumer":
        return row["consumer"] or "(nobody)"
    if group_by == "endpoint":
        return row["endpoint"] or "?"
    return "all"


def series(db, *, start: datetime, end: datetime, grain: str = GRAIN_HOUR, group_by: str = "none",
           kind: Optional[str] = None, api_id: Optional[int] = None, consumer: Optional[str] = None,
           endpoint: Optional[str] = None, api_slug: Optional[str] = None) -> Dict[str, Any]:
    """Buckets x groups over the rollups, each with counts, refusals, rows,
    bytes, cache and percentiles (histogram), plus totals."""
    rows = db.list_published_api_rollups(grain, _naive(start), _naive(end), api_kind=kind, api_id=api_id,
                                         consumer=consumer, endpoint=endpoint)
    ratio = lat.bin_ratio()
    cells: Dict[tuple, dict] = {}
    totals_bins = lat.empty_bins()
    totals = {"calls": 0, "ok_2xx": 0, "client_4xx": 0, "server_5xx": 0, "rows_sum": 0, "bytes_sum": 0,
              "bytes_known_calls": 0, "cache_hit": 0, "cache_miss": 0, "cache_bypass": 0, "by_status": {}, "refused": {}}
    for r in rows:
        k = (str(r["bucket_start"]), _key_of(r, group_by))
        c = cells.get(k)
        if c is None:
            c = cells[k] = {"bucket_start": r["bucket_start"], "group": k[1], "calls": 0, "ok_2xx": 0, "client_4xx": 0,
                            "server_5xx": 0, "rows_sum": 0, "bytes_sum": 0, "bytes_known_calls": 0, "cache_hit": 0,
                            "cache_miss": 0, "cache_bypass": 0, "by_status": {}, "refused": {}, "_bins": lat.empty_bins()}
        for f in ("calls", "ok_2xx", "client_4xx", "server_5xx", "rows_sum", "bytes_sum", "bytes_known_calls",
                  "cache_hit", "cache_miss", "cache_bypass"):
            c[f] += int(r.get(f) or 0)
            totals[f] += int(r.get(f) or 0)
        for d in ("by_status", "refused"):
            for kk, vv in (r.get(d) or {}).items():
                c[d][kk] = c[d].get(kk, 0) + int(vv or 0)
                totals[d][kk] = totals[d].get(kk, 0) + int(vv or 0)
        c["_bins"] = lat.merge_bins([c["_bins"], r.get("latency_bins") or []])
        totals_bins = lat.merge_bins([totals_bins, r.get("latency_bins") or []])
    out_cells = []
    for c in sorted(cells.values(), key=lambda x: (str(x["bucket_start"]), x["group"])):
        bins = c.pop("_bins")
        c["error_rate"] = round((c["client_4xx"] + c["server_5xx"]) / c["calls"], 4) if c["calls"] else None
        c["cache_hit_rate"] = (round(c["cache_hit"] / (c["cache_hit"] + c["cache_miss"]), 4)
                               if (c["cache_hit"] + c["cache_miss"]) else None)
        c.update(lat.percentiles(bins, ratio=ratio))
        out_cells.append(c)
    totals["error_rate"] = round((totals["client_4xx"] + totals["server_5xx"]) / totals["calls"], 4) if totals["calls"] else None
    totals["cache_hit_rate"] = (round(totals["cache_hit"] / (totals["cache_hit"] + totals["cache_miss"]), 4)
                                if (totals["cache_hit"] + totals["cache_miss"]) else None)
    totals.update(lat.percentiles(totals_bins, ratio=ratio))
    totals["method"] = "histogram"
    # ONE rule: exact percentiles for ONE API over a range small enough and inside raw retention
    if kind and api_id is not None and totals["calls"]:
        cap = int(_cfg("metrics_exact_percentile_max_rows", 200000))
        try:
            # the same row set the rollup folded: id rows AND the slug-only
            # refusals (resolve_slugs gave them to this API in the histogram)
            n = db.count_api_access_log_rows(kind, int(api_id), _naive(start), _naive(end), consumer=consumer,
                                             endpoint=endpoint, api_slug=api_slug)
            if 0 < n <= cap:
                values = db.api_access_log_latencies(kind, int(api_id), _naive(start), _naive(end), consumer=consumer,
                                                     endpoint=endpoint, api_slug=api_slug)
                if len(values) == n:
                    totals.update(lat.exact_percentiles(values))
                    totals["method"] = "exact"
        except Exception as exc:                        # noqa: BLE001 -- the histogram answer stands
            logger.debug("[published-api] exact percentiles skipped: %s", exc)
    return {"grain": grain, "group_by": group_by, "from": start.isoformat(), "to": end.isoformat(),
            "cells": out_cells, "totals": totals, "watermark": watermark(db),
            "resolution_note": "p50/p95/p99 are read from log-spaced latency bins (lo_ms..hi_ms is the bin); "
                               "method=exact when one API's raw rows fit the exact budget"}


def top(db, *, start: datetime, end: datetime, by: str = "calls", n: int = 10) -> Dict[str, Any]:
    """Busiest / slowest / most-erroring / heaviest / most-refused APIs and
    consumers over the hourly rollups of a window."""
    rows = db.list_published_api_rollups(GRAIN_HOUR, _naive(start), _naive(end))
    ratio = lat.bin_ratio()

    def _agg(keyfn):
        acc: Dict[str, dict] = {}
        for r in rows:
            k = keyfn(r)
            a = acc.get(k)
            if a is None:
                a = acc[k] = {"key": k, "api_kind": r["api_kind"], "api_id": r["api_id"], "api_slug": r.get("api_slug"),
                              "calls": 0, "errors": 0, "bytes": 0, "rows": 0, "rate_limited": 0, "_bins": lat.empty_bins()}
            a["calls"] += int(r.get("calls") or 0)
            a["errors"] += int(r.get("client_4xx") or 0) + int(r.get("server_5xx") or 0)
            a["bytes"] += int(r.get("bytes_sum") or 0)
            a["rows"] += int(r.get("rows_sum") or 0)
            a["rate_limited"] += int((r.get("refused") or {}).get("rate_limit") or 0)
            a["_bins"] = lat.merge_bins([a["_bins"], r.get("latency_bins") or []])
        out = []
        for a in acc.values():
            bins = a.pop("_bins")
            a["p95_ms"] = (lat.percentile(bins, 95, ratio) or {}).get("value_ms")
            a["error_rate"] = round(a["errors"] / a["calls"], 4) if a["calls"] else None
            out.append(a)
        return out

    def _sort(items):
        key = {"calls": lambda a: a["calls"], "p95": lambda a: a["p95_ms"] or 0, "errors": lambda a: a["errors"],
               "bytes": lambda a: a["bytes"], "rate_limited": lambda a: a["rate_limited"]}.get(by, lambda a: a["calls"])
        return sorted(items, key=key, reverse=True)[:max(1, int(n))]

    apis = _agg(lambda r: f"{r['api_kind'] or 'unknown'}:{r['api_slug'] or r['api_id']}")
    consumers = _agg(lambda r: r["consumer"] or "(nobody)")
    for c in consumers:
        c.pop("api_kind", None); c.pop("api_id", None); c.pop("api_slug", None)
    return {"by": by, "from": start.isoformat(), "to": end.isoformat(), "apis": _sort(apis),
            "consumers": _sort(consumers), "watermark": watermark(db)}


def numbers_from_rollups(db, *, days: int = 7) -> Tuple[Dict[tuple, Dict[str, Any]], Optional[datetime]]:
    """``(kind, id) -> {last_call_at, calls_7d}`` from the hourly rollups, and
    the raw-tail boundary the caller adds raw rows from.  ONE rule
    (2026-10-18, a double count found on the rig: the CSV said 360 calls for
    192 sent): the roll folds every bucket up to the CURRENT hour at its
    tick, so the rows the rollups do not yet hold are exactly those created
    STRICTLY AFTER the last tick (``last_tick_at``) -- not after the
    watermark hour, which the current hour's bucket already covers.  No
    state = ``(({}, None))`` -- everything from raw."""
    st = db.get_published_api_rollup_state(GRAIN_HOUR) or {}
    through = _aware(st.get("rolled_through"))
    if through is None:
        return {}, None
    tail_since = _aware(st.get("last_tick_at")) or (through + timedelta(hours=1))
    now = _utcnow()
    since7 = now - timedelta(days=int(days))
    out: Dict[tuple, Dict[str, Any]] = {}
    for kind, api_id, last_at, calls in db.published_api_rollup_numbers(GRAIN_HOUR, _naive(since7)):
        if kind == UNKNOWN_KIND:
            continue
        la = _aware(last_at)
        out[(str(kind), int(api_id))] = {"last_call_at": la.isoformat() if la else None, "calls_7d": int(calls or 0)}
    # last calls older than 7 days: the daily grain
    for kind, api_id, last_at, _calls in db.published_api_rollup_numbers(GRAIN_DAY, None):
        if kind == UNKNOWN_KIND:
            continue
        key = (str(kind), int(api_id))
        la = _aware(last_at)
        if key not in out:
            out[key] = {"last_call_at": la.isoformat() if la else None, "calls_7d": 0}
    return out, tail_since


__all__ = ["GRAIN_DAY", "GRAIN_HOUR", "REFUSALS", "UNKNOWN_ID", "UNKNOWN_KIND", "floor_day", "floor_hour",
           "fold_bucket", "numbers_from_rollups", "resolve_names", "resolve_slugs", "retention", "roll", "series",
           "sum_rows", "tick", "top", "watermark"]
