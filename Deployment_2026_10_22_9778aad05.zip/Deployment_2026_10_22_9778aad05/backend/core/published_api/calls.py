"""THE call record of every published API (2026-10-17).

``api_access_log`` was the published VIEWS' per-request usage row, written in
batches off the request by ``core/access_log_batcher.py``; it recorded a view
id, a key id, rows, ms and a status -- and nothing for a refused call (a 429
raised before the view was read left no row), nothing for an AD caller's
identity, nothing for a report served by a token.  It is now the call record
of EVERY kind (``api_kind`` / ``api_id`` / ``api_slug``), with the consumer
(the admission identity), the auth method, the endpoint and format, the cache
status as a column, the bytes when measured, and the REFUSAL reason.

Three writers, one row shape:

* :func:`record`         -- a route that answered (or failed inside its
                            handler) records what it knows: rows, ms, cache,
                            execution id.  Marks the request RECORDED.
* :func:`record_refusal` -- a refusal with nothing more to say than status +
                            reason (the rate limit before the view is read, a
                            bad key, a retired API).  Also marks the request.
* :class:`CallRecordMiddleware` -- the backstop: a response >= 400 on a
                            published-API path that NO route recorded is
                            recorded here from the status, the ``X-QS-Refused``
                            header the raise site set (``rate_limit``,
                            ``memory_pressure``, ...) and the consumer the auth
                            dependency stashed on ``request.state``.  So a new
                            refusal in a route is never a hole in the numbers.

NEVER on the hot path: every writer queues a dict (O(1)); the batcher writes.
A refusal raised BEFORE the definition read (the rate limit, by design)
carries the slug only -- ``api_id`` NULL -- and the rollup resolves it off the
request (core/published_api/rollup.py).  A refused hot key therefore still
costs ZERO statements (tests/test_published_api_call_record_2026_10_17.py).
"""
from __future__ import annotations

import logging
import socket
import time
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

KIND_VIEW = "published_view"
KIND_REPORT = "published_report"
API_KINDS = (KIND_VIEW, KIND_REPORT)

#: The paths of each kind, longest first.  A path under one of these is a
#: published-API call; the middleware records refusals on them.
PATH_PREFIXES: Tuple[Tuple[str, str], ...] = (
    ("/api/v1/views/", KIND_VIEW),
    ("/graphql", KIND_VIEW),
    ("/api/embedded-business-report/", KIND_REPORT),
    ("/api/business-reports/embedded/", KIND_REPORT),
    ("/api/business-reports/shared/", KIND_REPORT),
)

#: ``X-QS-Refused`` -- the header a raise site sets to NAME its refusal; the
#: middleware reads it.  The memory guard already sets ``memory_pressure``.
REFUSED_HEADER = "X-QS-Refused"

#: Refusal reasons the status alone implies, when no header named one.
REFUSAL_BY_STATUS = {
    401: "unauthenticated", 403: "forbidden", 404: "not_found", 409: "dataset_version",
    410: "retired", 416: "ceiling", 429: "rate_limit", 503: "unavailable", 504: "timeout",
}

#: Which ``request.state`` keys the auth dependency and the recorders share.
STATE_RECORDED = "qs_call_recorded"
STATE_API_USER = "qs_api_user"
STATE_AUTH_FAILED = "qs_api_auth_failed"

_POD = socket.gethostname()[:64]


# ── the one identity rule ─────────────────────────────────────────────────

def consumer_of(api_user: Optional[Dict[str, Any]]) -> Tuple[str, str]:
    """``(consumer, auth_method)`` of a resolved principal -- THE admission
    identity: ``apikey:<row id>`` for a key (never the display prefix: two
    keys may share one), the username for a session / AD-Basic / dev-mode
    caller, ``token:<8>`` for a report token.  An empty consumer = nobody
    resolved (the caller then charges its own fallback)."""
    if not api_user:
        return "", ""
    method = str(api_user.get("auth_method") or "")
    key_id = api_user.get("api_key_id")
    if key_id not in (None, "", 0):
        from core.reports.admission import API_KEY_IDENTITY_PREFIX
        return f"{API_KEY_IDENTITY_PREFIX}{key_id}", method or "api_key"
    tok = api_user.get("token_prefix")
    if tok:
        return f"token:{str(tok)[:8]}", method or "token"
    username = str(api_user.get("username") or "").strip()
    return username, method


def token_consumer(token: str) -> str:
    """A report token's identity on the record: its first 8 characters (what
    the UI shows; the credential itself never lands in a row)."""
    return f"token:{str(token or '')[:8]}"


# ── path -> (kind, slug or token, endpoint) ───────────────────────────────

def kind_of_path(path: str) -> Optional[str]:
    if not isinstance(path, str):
        return None
    for prefix, kind in PATH_PREFIXES:
        if path.startswith(prefix):
            return kind
    return None


def parse_path(path: str) -> Dict[str, Optional[str]]:
    """``{"api_kind", "api_slug", "endpoint"}`` from a published-API path.

    ``/api/v1/views/sales/data.csv`` -> view ``sales``, endpoint ``data.csv``;
    ``/api/v1/views/sales/bulk/parts/3`` -> ``bulk.part``;
    ``/graphql`` -> ``graphql``; ``/api/embedded-business-report/<tok>/execute``
    -> report (slug unknown from the path; the token is NOT a slug), endpoint
    ``embed.execute``; ``/api/business-reports/shared/<tok>/download-csv`` ->
    ``share.download``.  A path of no kind -> all None.
    """
    if not isinstance(path, str):                      # a test double's MagicMock url
        path = ""
    kind = kind_of_path(path)
    out: Dict[str, Optional[str]] = {"api_kind": kind, "api_slug": None, "endpoint": None,
                                     "token": None}
    if kind is None:
        return out
    if path.startswith("/graphql"):
        out["endpoint"] = "graphql"
        return out
    parts = [p for p in path.split("/") if p]
    if kind == KIND_VIEW:
        # api / v1 / views / <slug> / <rest...>
        rest = parts[3:]
        out["api_slug"] = rest[0] if rest else None
        tail = rest[1:]
        if not tail:
            out["endpoint"] = "meta"
        elif tail[0] in ("data", "data.csv", "data.parquet"):
            out["endpoint"] = tail[0]
        elif tail[0].startswith("bulk"):
            if len(tail) == 1:
                out["endpoint"] = tail[0]                       # bulk | bulk.jsonl | bulk.arrow | bulk.csv
            elif tail[1] == "parts":
                out["endpoint"] = "bulk.part"
            elif tail[1] == "jobs":
                out["endpoint"] = "bulk.job"
            else:
                out["endpoint"] = f"bulk.{tail[1]}"             # manifest | prepare | download
        else:
            out["endpoint"] = tail[0][:40]
        return out
    # reports by token
    if parts[:2] == ["api", "embedded-business-report"]:
        out["token"] = parts[2] if len(parts) > 2 else None
        tail = parts[3:]
        out["endpoint"] = "embed." + (tail[0] if tail else "meta")
    else:                                                       # api / business-reports / shared|embedded / <tok> / download-x
        out["token"] = parts[3] if len(parts) > 3 else None
        tail = parts[4:]
        out["endpoint"] = ("share" if parts[2] == "shared" else "embed") + "." + (
            "download" if tail and tail[0].startswith("download") else (tail[0] if tail else "meta"))
    return out


def format_of(path: str, query_format: Optional[str] = None) -> Optional[str]:
    if not isinstance(query_format, str):
        query_format = None
    if not isinstance(path, str):
        return query_format[:16] if query_format else None
    ep = parse_path(path).get("endpoint") or ""
    if "." in ep and ep.split(".")[-1] in ("csv", "parquet", "jsonl", "arrow"):
        return ep.split(".")[-1]
    if ep.endswith("download"):
        tail = path.rstrip("/").rsplit("/", 1)[-1]
        return tail.replace("download-", "")[:16] if tail.startswith("download-") else None
    if query_format:
        return str(query_format)[:16]
    if ep in ("data", "graphql", "bulk", "embed.execute"):
        return "json"
    return None


# ── the writers ───────────────────────────────────────────────────────────

def _mark_recorded(request) -> None:
    try:
        if request is not None:
            setattr(request.state, STATE_RECORDED, True)
    except Exception:                                   # noqa: BLE001 -- a bare object in a unit test
        pass


def _client_ip(request) -> Optional[str]:
    try:
        return request.client.host if request is not None and request.client else None
    except Exception:                                   # noqa: BLE001
        return None


def record(db_manager, *, request=None, api_kind: str, api_id: Optional[int], api_slug: Optional[str],
           consumer: str, auth_method: str, endpoint: Optional[str], fmt: Optional[str],
           status_code: int, response_ms: Optional[int], response_rows: Optional[int] = None,
           cache_status: Optional[str] = None, response_bytes: Optional[int] = None,
           refusal: Optional[str] = None, execution_id: Optional[str] = None,
           request_params: Optional[dict] = None, api_key_id: Optional[int] = None,
           view_id: Optional[int] = None, client_ip: Optional[str] = None) -> None:
    """THE write.  Queues one row (never blocks, never raises) and marks the
    request recorded so the middleware adds nothing."""
    _mark_recorded(request)
    if db_manager is None:
        return
    if refusal is None and int(status_code) >= 400:
        refusal = REFUSAL_BY_STATUS.get(int(status_code), "error" if int(status_code) >= 500 else "refused")
    try:
        from core.access_log_batcher import record as _queue
        _queue(db_manager,
               api_key_id=api_key_id, view_id=view_id,
               execution_id=execution_id or None, request_params=request_params,
               response_rows=response_rows, response_ms=response_ms, status_code=int(status_code),
               client_ip=client_ip if client_ip is not None else _client_ip(request),
               api_kind=api_kind, api_id=api_id, api_slug=(str(api_slug)[:220] if api_slug else None),
               consumer=str(consumer or "")[:200], auth_method=str(auth_method or "")[:20],
               endpoint=(str(endpoint)[:40] if endpoint else None),
               format=(str(fmt)[:16] if fmt else None),
               cache_status=(str(cache_status)[:10] if cache_status else None),
               response_bytes=response_bytes, refusal=(str(refusal)[:40] if refusal else None),
               pod=_POD)
    except Exception as exc:                            # noqa: BLE001 -- the record never fails the call
        logger.warning("[published-api] call record not queued: %s", exc)


def record_refusal(db_manager, request, *, status: int, refusal: Optional[str] = None,
                   consumer: Optional[str] = None, auth_method: Optional[str] = None,
                   api_kind: Optional[str] = None, api_slug: Optional[str] = None,
                   api_id: Optional[int] = None, view_id: Optional[int] = None,
                   api_key_id: Optional[int] = None, response_ms: Optional[int] = None,
                   detail: Optional[str] = None) -> None:
    """A refusal: status + reason + whoever was identified.  What the path
    says fills what the caller did not."""
    path = ""
    try:
        path = request.url.path if request is not None else ""
    except Exception:                                   # noqa: BLE001
        path = ""
    parsed = parse_path(path)
    kind = api_kind or parsed["api_kind"] or KIND_VIEW
    slug = api_slug if api_slug is not None else parsed["api_slug"]
    if consumer is None or auth_method is None:
        c, m = _identity_from_state(request, parsed)
        consumer = c if consumer is None else consumer
        auth_method = m if auth_method is None else auth_method
    record(db_manager, request=request, api_kind=kind, api_id=api_id, api_slug=slug,
           consumer=consumer or "", auth_method=auth_method or "", endpoint=parsed["endpoint"],
           fmt=format_of(path), status_code=int(status), response_ms=response_ms, response_rows=0,
           refusal=refusal or REFUSAL_BY_STATUS.get(int(status), "refused"),
           request_params={"error_details": str(detail)[:500]} if detail else None,
           api_key_id=api_key_id, view_id=view_id)


def _identity_from_state(request, parsed: Dict[str, Optional[str]]) -> Tuple[str, str]:
    """The consumer the auth dependency stashed, else the claim a failed auth
    left, else a report token from the path, else nobody."""
    st = None
    try:
        st = request.state if request is not None else None
    except Exception:                                   # noqa: BLE001
        st = None
    user = getattr(st, STATE_API_USER, None) if st is not None else None
    if user:
        return consumer_of(user)
    failed = getattr(st, STATE_AUTH_FAILED, None) if st is not None else None
    if isinstance(failed, dict):
        return str(failed.get("consumer") or ""), str(failed.get("auth_method") or "")
    if parsed.get("token"):
        return token_consumer(parsed["token"]), "token"
    return "", ""


def stash_api_user(request, api_user: Dict[str, Any]) -> None:
    """The auth dependency's hand-off: the resolved principal, read by the
    refusal recorders."""
    try:
        setattr(request.state, STATE_API_USER, api_user)
    except Exception:                                   # noqa: BLE001
        pass


def stash_auth_failure(request, *, auth_method: str, claim: str) -> None:
    """A failed authentication leaves its CLAIM (a key prefix, a username
    typed into Basic auth): labelled ``claimed-*`` because nothing verified
    it.  Never the credential itself."""
    try:
        setattr(request.state, STATE_AUTH_FAILED,
                {"auth_method": auth_method, "consumer": f"claimed-{auth_method}:{str(claim)[:8]}" if claim else ""})
    except Exception:                                   # noqa: BLE001
        pass


# ── the backstop ──────────────────────────────────────────────────────────

class CallRecordMiddleware:
    """Pure ASGI: a response >= 400 on a published-API path that no route
    recorded becomes a refusal row.  Everything else passes untouched; a
    recorded request (``request.state.qs_call_recorded``) adds nothing."""

    def __init__(self, app, db_resolver=None):
        self.app = app
        self._db_resolver = db_resolver

    def _db(self):
        if self._db_resolver is not None:
            try:
                return self._db_resolver()
            except Exception:                           # noqa: BLE001
                return None
        try:
            from core.database import get_db_manager
            return get_db_manager()
        except Exception:                               # noqa: BLE001
            return None

    async def __call__(self, scope, receive, send):
        if scope.get("type") != "http" or kind_of_path(scope.get("path") or "") is None:
            await self.app(scope, receive, send)
            return
        scope.setdefault("state", {})
        started = time.monotonic()
        status_holder = {"status": None, "headers": {}}

        async def _send(message):
            if message.get("type") == "http.response.start":
                status_holder["status"] = int(message.get("status") or 0)
                hdrs = {}
                for k, v in message.get("headers") or []:
                    try:
                        hdrs[k.decode("latin-1").lower()] = v.decode("latin-1")
                    except Exception:                   # noqa: BLE001
                        continue
                status_holder["headers"] = hdrs
            await send(message)

        try:
            await self.app(scope, receive, _send)
        finally:
            status = status_holder["status"]
            if status is not None and status >= 400 and not scope["state"].get(STATE_RECORDED):
                self._record(scope, status, status_holder["headers"], started)

    def _record(self, scope, status: int, headers: Dict[str, str], started: float) -> None:
        try:
            from starlette.requests import Request
            request = Request(scope)
            reason = headers.get(REFUSED_HEADER.lower()) or None
            record_refusal(self._db(), request, status=status, refusal=reason,
                           response_ms=int((time.monotonic() - started) * 1000))
        except Exception as exc:                        # noqa: BLE001
            logger.debug("[published-api] middleware record skipped: %s", exc)


__all__ = ["API_KINDS", "CallRecordMiddleware", "KIND_REPORT", "KIND_VIEW", "PATH_PREFIXES",
           "REFUSAL_BY_STATUS", "REFUSED_HEADER", "STATE_API_USER", "STATE_AUTH_FAILED",
           "STATE_RECORDED", "consumer_of", "format_of", "kind_of_path", "parse_path", "record",
           "record_refusal", "stash_api_user", "stash_auth_failure", "token_consumer"]
