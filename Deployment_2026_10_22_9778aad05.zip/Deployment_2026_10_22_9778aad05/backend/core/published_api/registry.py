"""The registry of API kinds -- the plugin seam (2026-10-17).

A kind registers itself from ``core/published_api/kinds/*`` (imported here
once).  The call record's ``api_kind`` vocabulary (``calls.API_KINDS``) and
the registry must agree; the guard test fails when they do not, so a kind
cannot be half-declared.
"""
from __future__ import annotations

from typing import Dict, List, Optional

from core.published_api.contract import ApiKind


class Registry:
    def __init__(self) -> None:
        self._kinds: Dict[str, ApiKind] = {}

    def register(self, kind: ApiKind) -> ApiKind:
        from core.published_api.calls import API_KINDS
        if not kind.kind:
            raise ValueError("an ApiKind needs a kind name")
        if kind.kind in self._kinds:
            raise ValueError(f"API kind {kind.kind!r} registered twice")
        if kind.kind not in API_KINDS:
            raise ValueError(f"API kind {kind.kind!r} is not in calls.API_KINDS -- declare it there first "
                             f"(one vocabulary for the registry and the call record)")
        self._kinds[kind.kind] = kind
        return kind

    def get(self, kind: str) -> Optional[ApiKind]:
        return self._kinds.get(kind)

    def require(self, kind: str) -> ApiKind:
        k = self._kinds.get(kind)
        if k is None:
            raise KeyError(f"unknown published-API kind {kind!r} -- one of {sorted(self._kinds)}")
        return k

    def kinds(self) -> List[str]:
        return list(self._kinds)

    def all(self) -> List[ApiKind]:
        return list(self._kinds.values())


REGISTRY = Registry()
_loaded = False


def load() -> Registry:
    """Import every kind module once (they register on import)."""
    global _loaded
    if not _loaded:
        from core.published_api.kinds import report, view
        view.register(REGISTRY)
        report.register(REGISTRY)
        _loaded = True
    return REGISTRY


__all__ = ["REGISTRY", "Registry", "load"]
