"""Telling an API's consumers something (2026-10-17): a deprecation, a
sunset coming, a retirement.  The same mechanism the schema-change notice
uses (core/published_view_schema.py::notify_owners -- a username is not an
address; ``published_views.notify_email_domain`` makes one), generalised to
the inventory's consumers: every consumer with an owner gets an in-app
notice, every derivable address an e-mail, and the verdict says who could
not be routed.  Never raises.
"""
from __future__ import annotations

import html as _html
import logging
from typing import Any, Dict, List

from core.published_api.contract import PublishedApi

logger = logging.getLogger(__name__)


def render_lifecycle_notice(api: PublishedApi, kind_of_notice: str) -> Dict[str, str]:
    lc = api.lifecycle or {}
    base = f"{api.api_kind.replace('_', ' ')} '{api.key}'"
    if kind_of_notice == "deprecated":
        subject = f"[QueryStudio] {base} is deprecated"
        text = (f"The {base} ({api.name}) has been deprecated."
                + (f"\n\nSunset: {lc.get('sunset_at')} -- it will stop answering then." if lc.get("sunset_at") else "")
                + (f"\n\nUse '{lc.get('successor')}' instead." if lc.get("successor") else "")
                + (f"\n\nNote from the publisher: {lc.get('deprecation_note')}" if lc.get("deprecation_note") else "")
                + "\n\nEvery response now carries Deprecation / Sunset / Link headers.")
    elif kind_of_notice == "sunset_due":
        subject = f"[QueryStudio] {base} retires on {lc.get('sunset_at')}"
        text = (f"The {base} ({api.name}) retires on {lc.get('sunset_at')}: calls will be answered "
                f"{'410 Gone' if True else ''} from then."
                + (f"  Use '{lc.get('successor')}' instead." if lc.get("successor") else ""))
    else:
        subject = f"[QueryStudio] {base} has been retired"
        text = (f"The {base} ({api.name}) has been retired and no longer answers."
                + (f"  Use '{lc.get('successor')}' instead." if lc.get("successor") else "")
                + (f"\n\nNote from the publisher: {lc.get('deprecation_note')}" if lc.get("deprecation_note") else ""))
    return {"subject": subject, "text": text, "html": "<pre>" + _html.escape(text) + "</pre>"}


def notify_consumers(db, api: PublishedApi, kind_of_notice: str) -> Dict[str, Any]:
    """In-app notice to every consumer owner; e-mail to every derivable
    address; the verdict records who was told and who could not be routed."""
    from core.published_view_schema import _address_for
    verdict: Dict[str, Any] = {"kind": kind_of_notice, "usernames": [], "emails": [], "unrouted": [],
                               "sent": False, "reason": ""}
    try:
        from core import config as _cfg
        domain = _cfg.published_views.notify_email_domain
    except Exception:                                   # noqa: BLE001
        domain = ""
    owners: List[str] = []
    addresses: List[str] = []
    for c in api.consumers:
        if not c.is_active:
            continue
        for who in (c.owner, c.contact):
            if not who or who in owners:
                continue
            owners.append(str(who))
    msg = render_lifecycle_notice(api, kind_of_notice)
    for u in owners:
        addr = _address_for(u, domain)
        if addr and addr.lower() not in {a.lower() for a in addresses}:
            addresses.append(addr)
        elif not addr:
            verdict["unrouted"].append(u)
        if "@" not in u:
            verdict["usernames"].append(u)
            try:
                db.log_notification(event_type=f"published_api_{kind_of_notice}", channel="in_app",
                                    recipient=u, status="unread", title=msg["subject"], message=msg["text"],
                                    payload={"api_kind": api.api_kind, "api_id": api.api_id, "key": api.key})
            except Exception:                           # noqa: BLE001
                logger.debug("[published-api] in-app notice for %s not logged", u, exc_info=True)
    if not owners:
        verdict["reason"] = "no consumer of this API has an owner to tell"
        return verdict
    if not addresses:
        verdict["reason"] = ("no address derivable: set published_views.notify_email_domain or record a "
                             "contact_email on the keys")
        return verdict
    try:
        from core import email_service
        ok = bool(email_service.send_email(addresses, msg["subject"], msg["html"], text_body=msg["text"]))
        verdict["emails"], verdict["sent"] = list(addresses), ok
        if not ok:
            verdict["reason"] = email_service.last_send_failure_reason() or "send failed"
    except Exception as exc:                            # noqa: BLE001
        verdict["emails"], verdict["reason"] = list(addresses), f"send raised: {exc}"
    return verdict


__all__ = ["notify_consumers", "render_lifecycle_notice"]
