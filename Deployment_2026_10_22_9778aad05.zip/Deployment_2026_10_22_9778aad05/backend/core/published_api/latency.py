"""Latency as a MERGEABLE histogram (2026-10-17, design §3.7).

A percentile over a month cannot be computed from hourly averages, and
keeping every raw row for a year is the cost the rollup exists to avoid.
Each rollup bucket therefore carries ``N`` log-spaced bins of response
times: bin ``i`` counts the calls whose latency lay in ``[r**i, r**(i+1))``
milliseconds (``r`` = ``published_views.rollup_latency_bin_ratio``, 1.5;
``N`` = 26 covers 1 ms to ~10.6 h).  Bins ADD across buckets, APIs and
consumers, so p50 / p95 / p99 are read for ANY range by interpolating inside
the bin where the cumulative count crosses the rank -- and every answer
states its ``resolution``, the bin's bounds, so nobody mistakes an estimate
for a measurement.  Changing the ratio after rows exist would make old bins
mean something else: the daemon refuses to roll under a ratio that differs
from the one the state row recorded.
"""
from __future__ import annotations

import math
from typing import Dict, Iterable, List, Optional, Sequence

N_BINS = 26
DEFAULT_RATIO = 1.5


def bin_ratio() -> float:
    try:
        from core.config import published_views as _pv
        r = float(_pv.rollup_latency_bin_ratio)
    except Exception:                                   # noqa: BLE001
        r = DEFAULT_RATIO
    return r if r > 1.0 else DEFAULT_RATIO


def edges(ratio: Optional[float] = None) -> List[float]:
    """``N_BINS + 1`` edges in ms: ``[1, r, r**2, ..., r**N]``."""
    r = ratio or bin_ratio()
    return [r ** i for i in range(N_BINS + 1)]


def bin_of(ms: Optional[float], ratio: Optional[float] = None) -> int:
    """Which bin a latency lands in (sub-millisecond -> 0, beyond the last
    edge -> the last bin)."""
    r = ratio or bin_ratio()
    try:
        v = float(ms)
    except (TypeError, ValueError):
        return 0
    if v < 1.0:
        return 0
    i = int(math.floor(math.log(v) / math.log(r)))
    return max(0, min(N_BINS - 1, i))


def empty_bins() -> List[int]:
    return [0] * N_BINS


def merge_bins(parts: Iterable[Sequence[int]]) -> List[int]:
    out = empty_bins()
    for p in parts:
        if not p:
            continue
        for i, v in enumerate(p[:N_BINS]):
            out[i] += int(v or 0)
    return out


def percentile(bins: Sequence[int], p: float, ratio: Optional[float] = None) -> Optional[Dict[str, float]]:
    """``{"value_ms", "lo_ms", "hi_ms"}`` -- the p-th percentile interpolated
    inside its bin, with the bin's bounds as the resolution.  None when the
    histogram is empty."""
    total = sum(int(b or 0) for b in bins)
    if total <= 0:
        return None
    e = edges(ratio)
    rank = max(1.0, math.ceil(total * (float(p) / 100.0)))
    cum = 0
    for i, b in enumerate(bins[:N_BINS]):
        b = int(b or 0)
        if b <= 0:
            continue
        if cum + b >= rank:
            frac = (rank - cum - 0.5) / b             # the middle of the rank's slot
            frac = min(1.0, max(0.0, frac))
            lo, hi = e[i], e[i + 1]
            return {"value_ms": round(lo + (hi - lo) * frac, 2), "lo_ms": round(lo, 2), "hi_ms": round(hi, 2)}
        cum += b
    lo, hi = e[N_BINS - 1], e[N_BINS]
    return {"value_ms": round(hi, 2), "lo_ms": round(lo, 2), "hi_ms": round(hi, 2)}


def percentiles(bins: Sequence[int], ps: Sequence[int] = (50, 95, 99), ratio: Optional[float] = None) -> Dict[str, Optional[dict]]:
    return {f"p{p}": percentile(bins, p, ratio) for p in ps}


def exact_percentiles(values: Sequence[float], ps: Sequence[int] = (50, 95, 99)) -> Dict[str, Optional[dict]]:
    """The exact nearest-rank percentiles of raw latencies (small ranges)."""
    vals = sorted(float(v) for v in values if v is not None)
    out: Dict[str, Optional[dict]] = {}
    for p in ps:
        if not vals:
            out[f"p{p}"] = None
            continue
        k = max(1, math.ceil(len(vals) * p / 100.0)) - 1
        v = vals[min(k, len(vals) - 1)]
        out[f"p{p}"] = {"value_ms": round(v, 2), "lo_ms": round(v, 2), "hi_ms": round(v, 2)}
    return out


__all__ = ["DEFAULT_RATIO", "N_BINS", "bin_of", "bin_ratio", "edges", "empty_bins", "exact_percentiles",
           "merge_bins", "percentile", "percentiles"]
