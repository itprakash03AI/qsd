"""The access-log writers' heartbeat rows (``published_api_ingest_health``),
judged by THE generic silence rule -- ``core/component_health/retire.py::
silence_verdict`` -- not a second one (2026-10-18, the rebuilt rig: /health
said 29 rows lost when no live writer had lost one; the rows of processes
REPLACED with the containers were summed in).

A writer process is LIVE while it reported within
``component_health.pod_down_after_seconds``; DOWN once silent past that; and
RETIRED when a newer process on the SAME pod has reported since (superseded
-- a restarted writer) or when silent past
``component_health.pod_retire_after_seconds``.  The fleet's verdict is the
LIVE writers' (their losses sum); a DOWN writer is listed with its own
counters and never summed; a RETIRED one leaves the table (the rollup tick
retires it) -- its counters are history, not a state.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from core.component_health.retire import LIVE, silence_verdict
from core.component_health.rules import age_seconds
from core.component_health.vocabulary import DOWN, RETIRED

logger = logging.getLogger(__name__)


def thresholds() -> Tuple[float, float]:
    """``(down_after_s, retire_after_s)`` -- component health's declared keys."""
    from core.config import component_health as c
    return float(c.pod_down_after_seconds), float(c.pod_retire_after_seconds)


def classify(rows: List[Dict[str, Any]], *, now: Optional[datetime] = None,
             down_after_s: Optional[float] = None, retire_after_s: Optional[float] = None) -> List[Dict[str, Any]]:
    """Each row with its ``verdict`` (live / down / retired), ``age_seconds``
    and ``superseded_by`` (the newer live pid on the same pod, or None)."""
    now = now or datetime.now(timezone.utc)
    if down_after_s is None or retire_after_s is None:
        d, r = thresholds()
        down_after_s = d if down_after_s is None else down_after_s
        retire_after_s = r if retire_after_s is None else retire_after_s
    ages = {(r["pod"], r["pid"]): age_seconds(r.get("reported_at"), now) for r in rows}
    live = [r for r in rows if ages[(r["pod"], r["pid"])] is not None and ages[(r["pod"], r["pid"])] <= down_after_s]
    out = []
    for r in rows:
        age = ages[(r["pod"], r["pid"])]
        mine = _ts(r.get("reported_at"))
        by = None
        for cand in live:
            if cand["pod"] != r["pod"] or cand["pid"] == r["pid"]:
                continue
            cand_at = _ts(cand.get("reported_at"))
            if mine is None or (cand_at is not None and cand_at > mine):
                by = f"{cand['pod']}:{cand['pid']}"
                break
        verdict = silence_verdict(age, superseded=by is not None, down_after_s=down_after_s, retire_after_s=retire_after_s)
        out.append({**r, "verdict": verdict, "age_seconds": None if age is None else round(age, 1), "superseded_by": by})
    return out


def _ts(v) -> Optional[datetime]:
    from core.component_health.rules import parse_ts
    return parse_ts(v)


def summary(db, *, now: Optional[datetime] = None) -> Dict[str, Any]:
    """What /health says about the writers: the LIVE ones' losses as the
    verdict, the DOWN ones listed with their counters, the RETIRED ones gone
    (they are deleted by the tick; until then they are not shown)."""
    try:
        down_after_s, retire_after_s = thresholds()
        rows = db.list_all_published_api_ingest_health()
    except Exception as exc:                            # noqa: BLE001
        return {"state": "unknown", "reason": f"ingest health unreadable: {type(exc).__name__}: {exc}"}
    judged = classify(rows, now=now, down_after_s=down_after_s, retire_after_s=retire_after_s)
    live = [r for r in judged if r["verdict"] == LIVE]
    down = [r for r in judged if r["verdict"] == DOWN]
    retired = [r for r in judged if r["verdict"] == RETIRED]
    lost = sum(int(r.get("lost_write_failed") or 0) for r in live)
    dropped = sum(int(r.get("dropped_queue_full") or 0) for r in live)

    def _face(r):
        return {"pod": r["pod"], "pid": r["pid"], "reported_at": r.get("reported_at"), "age_seconds": r.get("age_seconds"),
                "written": int(r.get("written") or 0), "lost_write_failed": int(r.get("lost_write_failed") or 0),
                "dropped_queue_full": int(r.get("dropped_queue_full") or 0), "superseded_by": r.get("superseded_by")}

    return {"state": ("no_writers_reporting" if not live else ("loss" if (lost or dropped) else "ok")),
            "judged": (f"the writers that reported within {down_after_s:.0f} s (component_health.pod_down_after_seconds); "
                       f"a writer silent longer is listed as down, never summed; one silent past {retire_after_s:.0f} s "
                       f"or superseded on its pod is retired by the rollup tick"),
            "writers_reporting": len(live), "writers_down": len(down), "writers_retired_pending": len(retired),
            "stale_pods": [f"{r['pod']}:{r['pid']}" for r in down],       # the name the dashboard already reads
            "down": [_face(r) for r in down],
            "rows_dropped_queue_full": dropped, "rows_lost_write_failed": lost,
            "rows_submitted": sum(int(r.get("submitted") or 0) for r in live),
            "rows_written": sum(int(r.get("written") or 0) for r in live),
            "bound": "a process killed hard loses at most one flush interval (published_views.access_log_flush_seconds) of rows"}



def _retired_note(r: Dict[str, Any]) -> str:
    """One retired writer, said.  (A plain function, not a nested f-string:
    Python 3.11 -- the image's interpreter -- refuses a quote of the same kind
    inside an f-string's braces, 2026-10-18: the rollup failed on every tick.)"""
    why = ("superseded by " + str(r["superseded_by"])) if r.get("superseded_by") else ("silent %s s" % r.get("age_seconds"))
    return "%s:%s (%s)" % (r["pod"], r["pid"], why)

def retire(db, *, now: Optional[datetime] = None) -> Dict[str, Any]:
    """Delete the rows the rule says are RETIRED; returns them by name."""
    down_after_s, retire_after_s = thresholds()
    rows = db.list_all_published_api_ingest_health()
    gone = [r for r in classify(rows, now=now, down_after_s=down_after_s, retire_after_s=retire_after_s)
            if r["verdict"] == RETIRED]
    deleted = 0
    for r in gone:
        try:
            deleted += int(db.delete_published_api_ingest_health_row(r["pod"], r["pid"]) or 0)
        except Exception as exc:                        # noqa: BLE001
            logger.warning("[published-api] ingest row %s:%s not retired: %s", r["pod"], r["pid"], exc)
    if gone:
        logger.info("[published-api] retired %d ingest-health row(s): %s", len(gone),
                    "; ".join(_retired_note(r) for r in gone))
    return {"retired": [{"pod": r["pod"], "pid": r["pid"], "superseded_by": r["superseded_by"], "age_seconds": r["age_seconds"]}
                        for r in gone], "rows_deleted": deleted}


__all__ = ["classify", "retire", "summary", "thresholds"]
