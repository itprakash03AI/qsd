"""Published-API ALERTS (2026-10-17, design §3.8): thresholds as ROWS, raised
through THE alert road.

A threshold (``published_api_alert_thresholds``, RELEASE configuration) says
WHAT is watched (a metric over a window), FOR WHOM (every API, every API of
a kind, or one API by its key), WHEN it is a breach (operator + value, and
``min_calls`` under which a window is INSUFFICIENT -- never a breach, never
a step toward recovery), and WHICH alert kind (a ``feed_alert_kinds`` row:
severity, channels, AlertGroup, clears_when) a breach raises.

Evaluation rides the rollup daemon's tick, after the roll (one election,
one interval; ``rollup.tick``): the window's HOURLY rollup rows -- the
current hour is re-rolled every tick, so the window is current to the tick
-- are summed per API in scope and the metric read.  A breach raises
``raise_alert(subject=...)`` with ONE dedupe key per (API, threshold), so a
flapping metric never raises twice; a recovery clears after
``clear_after_windows`` x ``window_minutes`` of CONSECUTIVE measurable
healthy windows (an insufficient or unknown window breaks the streak) --
``clear()`` sends the Netcool resolution.  The per-(threshold, API) verdict
(``published_api_alert_state``, RUNTIME) is what the page shows as "the
thresholds that apply and their current value".

Three sweeps ride the same tick: a deprecated API whose sunset has passed is
RETIRED (the route's own lifecycle write), its consumers told, the act
audited ``api.sunset_reached``; one inside its notice period raises
``api_sunset_due`` once and its consumers are told once; an offered API whose
dependency is gone / inactive / unpublished (``health.state == broken`` --
the inventory's one verdict; ``unknown`` is NOT broken) raises ONE
``api_dependency_broken`` until it resolves; an open alert about an API that
no longer exists is cleared.

The subject of every alert here is ``AlertSubject(kind="published_api",
key="<api kind>:<api key>")`` -- ONE spelling (``subject_key_of``) read by
the raise, the clears, the one-API route and the alerts route.  Nothing in
core/feed knows the word published_api.  The AlertGroup the six kinds are
SEEDED with is ``published_views.alert_group`` (default PUBLISHED_API, a
member of core/feed/netcool.py::ALERT_GROUPS -- the console routes by group);
the ``feed_alert_kinds`` rows are the truth afterwards and the admin's kind
editor edits them like every other kind.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

from core.feed.alert_subject import AlertSubject
from core.published_api import latency as lat
from core.published_api.contract import HEALTH_BROKEN, LIFECYCLE_DEPRECATED, LIFECYCLE_RETIRED, PublishedApi
from core.published_api.lifecycle import OFFERED_STATES, fields_for, lifecycle_of, sunset_notice_days

logger = logging.getLogger(__name__)

SUBJECT_KIND = "published_api"
#: who the daemon is in audits and in ``cleared_by``
ACTOR = "published_api_rollup"
DEFAULT_ALERT_GROUP = "PUBLISHED_API"

SCOPE_GLOBAL, SCOPE_KIND, SCOPE_API = "global", "kind", "api"
SCOPES = (SCOPE_GLOBAL, SCOPE_KIND, SCOPE_API)
OPERATORS = (">", ">=", "<", "<=")
STATE_OK, STATE_BREACH, STATE_INSUFFICIENT, STATE_UNKNOWN = "ok", "breach", "insufficient", "unknown"
STATES = (STATE_OK, STATE_BREACH, STATE_INSUFFICIENT, STATE_UNKNOWN)

#: metric -> unit, words, and whether ``min_calls`` applies (a RATE or a
#: percentile over too few calls is noise; a COUNT of zero is a value).
METRICS: Dict[str, Dict[str, Any]] = {
    "error_rate":        {"unit": "%", "words": "4xx + 5xx answers as a share of the window's calls", "needs_calls": True},
    "server_error_rate": {"unit": "%", "words": "5xx answers as a share of the window's calls", "needs_calls": True},
    "p50_ms":            {"unit": "ms", "words": "median latency, read from the histogram", "needs_calls": True},
    "p95_ms":            {"unit": "ms", "words": "95th-percentile latency, read from the histogram", "needs_calls": True},
    "p99_ms":            {"unit": "ms", "words": "99th-percentile latency, read from the histogram", "needs_calls": True},
    "cache_hit_rate":    {"unit": "%", "words": "cache hits as a share of hits + misses", "needs_calls": True},
    "calls":             {"unit": "calls", "words": "calls in the window", "needs_calls": False},
    "rate_limit_hits":   {"unit": "calls", "words": "429 refusals in the window", "needs_calls": False},
    "refusals":          {"unit": "calls", "words": "every refusal in the window (rate limit, timeout, retired, ...)", "needs_calls": False},
    "bytes":             {"unit": "bytes", "words": "bytes served in the window (measured calls only)", "needs_calls": False},
    "rows":              {"unit": "rows", "words": "rows served in the window", "needs_calls": False},
    "no_calls_days":     {"unit": "days", "words": "days since the API's last call (since its creation when it never had "
                                                   "one); the window is ignored", "needs_calls": False},
}

KIND_ERROR_RATE = "api_error_rate"
KIND_LATENCY = "api_latency"
KIND_RATE_LIMITED = "api_rate_limited"
KIND_NO_CALLS = "api_no_calls"
KIND_DEPENDENCY_BROKEN = "api_dependency_broken"
KIND_SUNSET_DUE = "api_sunset_due"

#: The six kinds, seeded into ``feed_alert_kinds`` BY NAME when missing (a
#: non-empty table gets them too; an edited row is never touched) with
#: ``alert_group()`` -- design §3.8.
ALERT_KINDS = (
    {"kind": KIND_ERROR_RATE, "title": "Published API: error rate over the threshold",
     "severity": 4, "to_bell": True, "to_email": True, "to_netcool": True,
     "clears_when": "the error rate stays under the threshold for clear_after_windows consecutive windows"},
    {"kind": KIND_LATENCY, "title": "Published API: latency over the threshold",
     "severity": 3, "to_bell": True, "to_email": True, "to_netcool": False,
     "clears_when": "latency stays under the threshold for clear_after_windows consecutive windows"},
    {"kind": KIND_RATE_LIMITED, "title": "Published API: consumers rate-limited",
     "severity": 2, "to_bell": True, "to_email": False, "to_netcool": False,
     "clears_when": "rate-limit refusals stay under the threshold for clear_after_windows consecutive windows"},
    {"kind": KIND_NO_CALLS, "title": "Published API: no calls -- retirement candidate",
     "severity": 1, "to_bell": True, "to_email": False, "to_netcool": False,
     "clears_when": "a call arrives"},
    {"kind": KIND_DEPENDENCY_BROKEN, "title": "Published API: a dependency is gone",
     "severity": 4, "to_bell": True, "to_email": True, "to_netcool": True,
     "clears_when": "the dependency exists and is active again, or the API is no longer offered"},
    {"kind": KIND_SUNSET_DUE, "title": "Published API: sunset within the notice period",
     "severity": 2, "to_bell": True, "to_email": True, "to_netcool": False,
     "clears_when": "the sunset date passes and the API retires, or the deprecation is lifted"},
)
API_ALERT_KIND_NAMES: Tuple[str, ...] = tuple(k["kind"] for k in ALERT_KINDS)

#: Shipped once into an EMPTY thresholds table (editable rows afterwards; to
#: watch nothing, deactivate them -- an empty table is re-seeded at start-up).
DEFAULT_THRESHOLDS = (
    {"name": "Error rate over 5 %", "metric": "error_rate", "operator": ">", "value": 5.0,
     "window_minutes": 15, "min_calls": 50, "clear_after_windows": 2, "alert_kind": KIND_ERROR_RATE},
    {"name": "p95 over 10 s", "metric": "p95_ms", "operator": ">", "value": 10000.0,
     "window_minutes": 15, "min_calls": 50, "clear_after_windows": 2, "alert_kind": KIND_LATENCY},
    {"name": "No calls in 30 days", "metric": "no_calls_days", "operator": ">", "value": 30.0,
     "window_minutes": 0, "min_calls": 0, "clear_after_windows": 1, "alert_kind": KIND_NO_CALLS},
    {"name": "Rate limited over 100 per 15 min", "metric": "rate_limit_hits", "operator": ">", "value": 100.0,
     "window_minutes": 15, "min_calls": 0, "clear_after_windows": 2, "alert_kind": KIND_RATE_LIMITED},
)


# ── config ────────────────────────────────────────────────────────────────

def _cfg(key: str, default):
    try:
        from core.config import published_views as _pv
        return getattr(_pv, key)
    except Exception:                                   # noqa: BLE001
        return default


def alerts_enabled() -> bool:
    return bool(_cfg("alerts_enabled", True))


def alert_group() -> str:
    """The Netcool AlertGroup the API alert kinds are SEEDED with
    (``published_views.alert_group``).  Validated against the closed set the
    console routes by: a group the console does not know reaches nobody's
    queue, so an unknown value is refused -- logged at ERROR and the default
    used -- rather than seeded into rows that would be silently dropped."""
    from core.feed.netcool import ALERT_GROUPS
    raw = str(_cfg("alert_group", DEFAULT_ALERT_GROUP) or "").strip()
    if raw in ALERT_GROUPS:
        return raw
    logger.error("[published-api alerts] published_views.alert_group=%r is not one of %s -- the console routes "
                 "BY GROUP, so the API alert kinds are seeded with %s instead", raw, sorted(ALERT_GROUPS),
                 DEFAULT_ALERT_GROUP)
    return DEFAULT_ALERT_GROUP


# ── the subject ───────────────────────────────────────────────────────────

def subject_key_of(api_kind: str, key: Any) -> str:
    """ONE spelling of an API as an alert subject: ``<kind>:<key>`` (a view's
    slug and a report's id would otherwise be ambiguous)."""
    return f"{api_kind}:{key}"


def subject_for(api: PublishedApi) -> AlertSubject:
    """Who is told: the API's owner (and its creator when different) in the
    bell; by e-mail where an address can be derived (``notify_email_domain``)."""
    owners = tuple(dict.fromkeys(str(x) for x in (api.owner, api.created_by) if x))
    emails: Tuple[str, ...] = ()
    try:
        from core import config as _c
        from core.published_view_schema import _address_for
        domain = _c.published_views.notify_email_domain
        emails = tuple(dict.fromkeys(a for a in (_address_for(o, domain) for o in owners) if a))
    except Exception:                                   # noqa: BLE001
        emails = ()
    return AlertSubject(kind=SUBJECT_KIND, key=subject_key_of(api.api_kind, api.key), name=api.name or str(api.key),
                        owners=owners, emails=emails,
                        href=f"/published-views?tab=dashboard&kind={api.api_kind}&api={api.key}",
                        scopes=(("api_kind", api.api_kind),))


def threshold_dedupe_key(subject: AlertSubject, thr: Dict[str, Any]) -> str:
    """ONE open alert per (API, threshold)."""
    return f"{subject.dedupe_key(str(thr['alert_kind']))}:threshold:{int(thr['id'])}"


# ── measuring ─────────────────────────────────────────────────────────────

def _as_dt(v) -> Optional[datetime]:
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v if v.tzinfo else v.replace(tzinfo=timezone.utc)
    try:
        d = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def _naive(dt: datetime) -> datetime:
    return dt.astimezone(timezone.utc).replace(tzinfo=None) if dt.tzinfo else dt


def _floor_hour(dt: datetime) -> datetime:
    return dt.replace(minute=0, second=0, microsecond=0)


def _fmt(v: Any) -> str:
    if v is None:
        return "?"
    f = float(v)
    return str(int(f)) if f == int(f) else f"{f:.2f}"


def totals(rows: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    """The window's sums over rollup rows (any grain, any consumer / endpoint)."""
    t: Dict[str, Any] = {"calls": 0, "ok": 0, "c4": 0, "c5": 0, "refused": {}, "bytes": 0, "rows": 0,
                         "hit": 0, "miss": 0, "bins": lat.empty_bins()}
    for r in rows:
        t["calls"] += int(r.get("calls") or 0)
        t["ok"] += int(r.get("ok_2xx") or 0)
        t["c4"] += int(r.get("client_4xx") or 0)
        t["c5"] += int(r.get("server_5xx") or 0)
        t["bytes"] += int(r.get("bytes_sum") or 0)
        t["rows"] += int(r.get("rows_sum") or 0)
        t["hit"] += int(r.get("cache_hit") or 0)
        t["miss"] += int(r.get("cache_miss") or 0)
        for k, v in (r.get("refused") or {}).items():
            t["refused"][k] = t["refused"].get(k, 0) + int(v or 0)
        bins = r.get("latency_bins") or []
        if bins:
            t["bins"] = lat.merge_bins([t["bins"], bins])
    t["rate_limit"] = int(t["refused"].get("rate_limit", 0))
    return t


def measure(metric: str, rows: Iterable[Dict[str, Any]], *, api: Optional[PublishedApi], now: datetime) -> Dict[str, Any]:
    """``{"value", "calls", "reason"}``: the metric over the window rows, or
    ``value None`` with the reason it has no value (never a default)."""
    if metric not in METRICS:
        raise ValueError(f"unknown metric {metric!r}; one of {sorted(METRICS)}")
    if metric == "no_calls_days":
        last = ((api.last_call or {}).get("at") if api is not None else None) or (api.created_at if api is not None else None)
        dt = _as_dt(last)
        if dt is None:
            return {"value": None, "calls": 0, "reason": "no call on record and no creation date"}
        return {"value": (now - dt).total_seconds() / 86400.0, "calls": 0, "reason": None}
    t = totals(rows)
    calls = t["calls"]
    none = {"value": None, "calls": calls, "reason": "no call in the window"}
    if metric == "calls":
        return {"value": float(calls), "calls": calls, "reason": None}
    if metric == "rate_limit_hits":
        return {"value": float(t["rate_limit"]), "calls": calls, "reason": None}
    if metric == "refusals":
        return {"value": float(sum(t["refused"].values())), "calls": calls, "reason": None}
    if metric == "bytes":
        return {"value": float(t["bytes"]), "calls": calls, "reason": None}
    if metric == "rows":
        return {"value": float(t["rows"]), "calls": calls, "reason": None}
    if metric == "error_rate":
        return none if not calls else {"value": 100.0 * (t["c4"] + t["c5"]) / calls, "calls": calls, "reason": None}
    if metric == "server_error_rate":
        return none if not calls else {"value": 100.0 * t["c5"] / calls, "calls": calls, "reason": None}
    if metric == "cache_hit_rate":
        den = t["hit"] + t["miss"]
        if not den:
            return {"value": None, "calls": calls, "reason": "no cacheable call in the window"}
        return {"value": 100.0 * t["hit"] / den, "calls": calls, "reason": None}
    # p50_ms / p95_ms / p99_ms
    p = lat.percentile(t["bins"], int(metric[1:3]))
    if p is None:
        return none
    return {"value": float(p["value_ms"]), "calls": calls, "reason": None}


def breaches(value: float, operator: str, threshold: float) -> bool:
    if operator == ">":
        return value > threshold
    if operator == ">=":
        return value >= threshold
    if operator == "<":
        return value < threshold
    if operator == "<=":
        return value <= threshold
    raise ValueError(f"unknown operator {operator!r}")


def judge(thr: Dict[str, Any], api: Optional[PublishedApi], rows: Iterable[Dict[str, Any]], *, now: datetime) -> Dict[str, Any]:
    """The verdict of one threshold over one API's window:
    ``{"state": ok | breach | insufficient | unknown, "value", "calls", "detail"}``."""
    metric = str(thr["metric"])
    m = measure(metric, rows, api=api, now=now)
    unit = METRICS[metric]["unit"]
    out: Dict[str, Any] = {"value": m["value"], "calls": m["calls"], "detail": None}
    need = max(1, int(thr.get("min_calls") or 0))
    if METRICS[metric]["needs_calls"] and m["calls"] < need:
        out["state"] = STATE_INSUFFICIENT
        out["detail"] = f"{m['calls']} calls in the window, {need} needed to judge {metric}"
    elif m["value"] is None:
        out["state"] = STATE_UNKNOWN
        out["detail"] = m["reason"]
    elif breaches(float(m["value"]), str(thr["operator"]), float(thr["value"])):
        out["state"] = STATE_BREACH
        out["detail"] = f"{metric} = {_fmt(m['value'])} {unit}, {thr['operator']} {_fmt(thr['value'])} {unit}"
    else:
        out["state"] = STATE_OK
        out["detail"] = f"{metric} = {_fmt(m['value'])} {unit}, not {thr['operator']} {_fmt(thr['value'])} {unit}"
    return out


# ── scope + validation ────────────────────────────────────────────────────

def is_offered(api: PublishedApi) -> bool:
    return (api.lifecycle or {}).get("status") in OFFERED_STATES


def apis_in_scope(thr: Dict[str, Any], apis: Iterable[PublishedApi]) -> List[PublishedApi]:
    """The OFFERED APIs (active / deprecated) a threshold watches: every one,
    every one of a kind, or the one named by (kind, key)."""
    scope = thr.get("scope")
    out = []
    for a in apis:
        if not is_offered(a):
            continue
        if scope == SCOPE_KIND and a.api_kind != thr.get("api_kind"):
            continue
        if scope == SCOPE_API and (a.api_kind != thr.get("api_kind") or str(a.key) != str(thr.get("scope_key"))):
            continue
        out.append(a)
    return out


def validate_threshold(data: Dict[str, Any], *, kinds: Iterable[str], api_keys: Set[Tuple[str, str]],
                       alert_kinds: Iterable[str]) -> List[str]:
    """Every reason a threshold row is refused (empty = valid)."""
    problems: List[str] = []
    kinds = set(kinds)
    metric = str(data.get("metric") or "")
    if metric not in METRICS:
        problems.append(f"metric must be one of {sorted(METRICS)}, not {metric!r}")
    if str(data.get("operator") or "") not in OPERATORS:
        problems.append(f"operator must be one of {OPERATORS}")
    scope = str(data.get("scope") or "")
    api_kind = str(data.get("api_kind") or "")
    scope_key = str(data.get("scope_key") or "")
    if scope not in SCOPES:
        problems.append(f"scope must be one of {SCOPES}")
    elif scope == SCOPE_GLOBAL:
        if api_kind or scope_key:
            problems.append("a global threshold names no api_kind and no scope_key")
    elif scope == SCOPE_KIND:
        if api_kind not in kinds:
            problems.append(f"api_kind must be one of {sorted(kinds)} for a kind-scoped threshold")
        if scope_key:
            problems.append("a kind-scoped threshold names no scope_key")
    else:
        if api_kind not in kinds:
            problems.append(f"api_kind must be one of {sorted(kinds)} for an API-scoped threshold")
        elif (api_kind, scope_key) not in api_keys:
            problems.append(f"no published API {api_kind} {scope_key!r} (the inventory lists none)")
    if str(data.get("alert_kind") or "") not in set(alert_kinds):
        problems.append(f"alert_kind {data.get('alert_kind')!r} is not declared (or inactive) in feed_alert_kinds")
    try:
        if metric != "no_calls_days" and int(data.get("window_minutes") or 0) < 1:
            problems.append("window_minutes must be at least 1 (no_calls_days ignores the window)")
    except (TypeError, ValueError):
        problems.append("window_minutes must be an integer")
    try:
        if int(data.get("clear_after_windows") or 0) < 1:
            problems.append("clear_after_windows must be at least 1")
    except (TypeError, ValueError):
        problems.append("clear_after_windows must be an integer")
    try:
        if int(data.get("min_calls") or 0) < 0:
            problems.append("min_calls cannot be negative")
    except (TypeError, ValueError):
        problems.append("min_calls must be an integer")
    try:
        float(data.get("value"))
    except (TypeError, ValueError):
        problems.append("value must be a number")
    if not str(data.get("name") or "").strip():
        problems.append("a threshold needs a name")
    return problems


# ── the pass ──────────────────────────────────────────────────────────────

def _hourly_rows_by_api(db, *, now: datetime, window_minutes: int) -> Dict[Tuple[str, int], List[Dict[str, Any]]]:
    """ONE query: every hourly rollup row overlapping the widest window."""
    from core.published_api.rollup import GRAIN_HOUR
    start = _floor_hour(now - timedelta(minutes=max(0, int(window_minutes))))
    end = _floor_hour(now) + timedelta(hours=1)
    out: Dict[Tuple[str, int], List[Dict[str, Any]]] = {}
    for r in db.list_published_api_rollups(GRAIN_HOUR, _naive(start), _naive(end)):
        out.setdefault((str(r.get("api_kind") or ""), int(r.get("api_id") or 0)), []).append(r)
    return out


def _transition(db, thr: Dict[str, Any], api: PublishedApi, verdict: Dict[str, Any], prev: Dict[str, Any], *,
                now: datetime, open_alerts: Dict[str, dict], summary: Dict[str, Any]) -> Dict[str, Any]:
    """The next state row for (threshold, API) from the verdict and the
    previous row; raises or clears on the way.  A breach raises once (the
    dedupe key); a recovery clears after ``clear_after_windows`` x
    ``window_minutes`` of consecutive healthy, measurable windows; an
    insufficient or unknown window breaks the healthy streak and never
    raises."""
    from core.feed import feed_alerts
    subject = subject_for(api)
    dk = threshold_dedupe_key(subject, thr)
    state = str(verdict["state"])
    st: Dict[str, Any] = {
        "threshold_id": int(thr["id"]), "api_kind": api.api_kind, "api_id": int(api.api_id), "api_slug": str(api.key),
        "state": state, "value": verdict.get("value"), "calls": int(verdict.get("calls") or 0),
        "detail": (str(verdict.get("detail") or "")[:255] or None),
        "healthy_since": _as_dt(prev.get("healthy_since")), "breached_since": _as_dt(prev.get("breached_since")),
        "alert_id": prev.get("alert_id"), "dedupe_key": dk, "evaluated_at": now,
    }
    summary[state] = int(summary.get(state) or 0) + 1
    summary["evaluated"] = int(summary.get("evaluated") or 0) + 1
    unit = METRICS[str(thr["metric"])]["unit"]
    if state == STATE_BREACH:
        st["healthy_since"] = None
        st["breached_since"] = st["breached_since"] or now
        if dk in open_alerts:
            st["alert_id"] = open_alerts[dk].get("id")
        else:
            window_words = (f"over the last {int(thr.get('window_minutes') or 0)} min ({st['calls']} calls)"
                            if str(thr["metric"]) != "no_calls_days" else "since the last call")
            msg = (f"{thr['metric']} = {_fmt(verdict.get('value'))} {unit}, {thr['operator']} {_fmt(thr['value'])} {unit} "
                   f"{window_words} -- threshold '{thr['name']}' #{int(thr['id'])}")
            a = feed_alerts.raise_alert(db, str(thr["alert_kind"]), subject=subject, message=msg, dedupe_key=dk)
            if a is None:
                summary.setdefault("errors", []).append(
                    f"{dk}: NOT raised -- alert kind {thr['alert_kind']!r} undeclared or inactive, or the road failed")
            else:
                open_alerts[dk] = a
                st["alert_id"] = a.get("id")
                summary["raised"] = int(summary.get("raised") or 0) + 1
    elif state == STATE_OK:
        st["breached_since"] = None
        st["healthy_since"] = st["healthy_since"] or now
        if dk in open_alerts:
            need = timedelta(minutes=int(thr.get("clear_after_windows") or 1) * int(thr.get("window_minutes") or 0))
            if now - st["healthy_since"] >= need:
                cleared = feed_alerts.clear(db, by=ACTOR, dedupe_keys=[dk])
                if cleared:
                    open_alerts.pop(dk, None)
                    st["alert_id"] = None
                    summary["cleared"] = int(summary.get("cleared") or 0) + len(cleared)
    else:
        # insufficient / unknown: not a breach, and not a step toward clearing
        st["healthy_since"] = None
    return st


def evaluate_thresholds(db, apis: List[PublishedApi], *, now: datetime, open_alerts: Dict[str, dict]) -> Dict[str, Any]:
    """Every active threshold x every API in its scope, one query for the
    rows; the state rows replaced; (threshold, API) pairs no longer in scope
    dropped and their open alerts cleared."""
    summary: Dict[str, Any] = {"thresholds": 0, "evaluated": 0, STATE_OK: 0, STATE_BREACH: 0, STATE_INSUFFICIENT: 0,
                               STATE_UNKNOWN: 0, "raised": 0, "cleared": 0, "dropped": 0, "errors": []}
    thresholds = [t for t in db.list_published_api_alert_thresholds(active_only=True)]
    summary["thresholds"] = len(thresholds)
    prev = {(int(s["threshold_id"]), str(s["api_kind"]), int(s["api_id"])): s for s in db.list_published_api_alert_states()}
    seen: Set[Tuple[int, str, int]] = set()
    if thresholds:
        widest = max(int(t.get("window_minutes") or 0) for t in thresholds)
        rows_by_api = _hourly_rows_by_api(db, now=now, window_minutes=widest)
        for thr in thresholds:
            win_start = _floor_hour(now - timedelta(minutes=int(thr.get("window_minutes") or 0)))
            for api in apis_in_scope(thr, apis):
                key = (int(thr["id"]), api.api_kind, int(api.api_id))
                seen.add(key)
                rows = [r for r in rows_by_api.get((api.api_kind, int(api.api_id)), [])
                        if (_as_dt(r.get("bucket_start")) or now) >= win_start]
                try:
                    verdict = judge(thr, api, rows, now=now)
                    st = _transition(db, thr, api, verdict, prev.get(key) or {}, now=now, open_alerts=open_alerts,
                                     summary=summary)
                    db.upsert_published_api_alert_state(st)
                except Exception as exc:                # noqa: BLE001 -- one pair never stops the pass
                    logger.exception("[published-api alerts] threshold #%s over %s:%s failed", thr.get("id"),
                                     api.api_kind, api.key)
                    summary["errors"].append(f"threshold #{thr.get('id')} over {api.api_kind}:{api.key}: "
                                             f"{type(exc).__name__}: {exc}"[:300])
    # pairs that left the scope (a threshold deactivated or deleted, an API
    # retired or gone): the state goes, and an alert about them is cleared
    from core.feed import feed_alerts
    for key, s in prev.items():
        if key in seen:
            continue
        db.delete_published_api_alert_state(*key)
        summary["dropped"] += 1
        dk = s.get("dedupe_key")
        if dk and dk in open_alerts:
            if feed_alerts.clear(db, by=f"{ACTOR}:out of scope", dedupe_keys=[dk]):
                open_alerts.pop(dk, None)
                summary["cleared"] += 1
    return summary


def sweep_dependencies(db, apis: List[PublishedApi], *, now: datetime, open_alerts: Dict[str, dict]) -> Dict[str, Any]:
    """ONE ``api_dependency_broken`` per offered API whose health is broken
    (the inventory's verdict, with its sentences as the message); cleared
    when it resolves or the API stops being offered.  ``unknown`` health is
    not broken: a lookup that failed is said on the inventory, not paged."""
    from core.feed import feed_alerts
    out: Dict[str, Any] = {"broken": 0, "raised": 0, "cleared": 0, "errors": []}
    for api in apis:
        subject = subject_for(api)
        dk = subject.dedupe_key(KIND_DEPENDENCY_BROKEN)
        offered = is_offered(api)
        broken = offered and (api.health or {}).get("state") == HEALTH_BROKEN
        if broken:
            out["broken"] += 1
            if dk not in open_alerts:
                msg = "; ".join((api.health or {}).get("reasons") or ["a dependency is gone"])[:2000]
                a = feed_alerts.raise_alert(db, KIND_DEPENDENCY_BROKEN, subject=subject, message=msg)
                if a is None:
                    out["errors"].append(f"{dk}: NOT raised -- kind {KIND_DEPENDENCY_BROKEN!r} undeclared or the road failed")
                else:
                    open_alerts[dk] = a
                    out["raised"] += 1
        elif dk in open_alerts:
            by = f"{ACTOR}:resolved" if offered else f"{ACTOR}:not offered"
            if feed_alerts.clear(db, by=by, dedupe_keys=[dk]):
                open_alerts.pop(dk, None)
                out["cleared"] += 1
    return out


def sweep_sunsets(db, apis: List[PublishedApi], *, now: datetime, open_alerts: Dict[str, dict]) -> Dict[str, Any]:
    """A deprecated API past its sunset is RETIRED (the route's own write),
    its consumers told, the act audited; one inside the notice period raises
    ``api_sunset_due`` once and tells the consumers once; a deprecation
    lifted clears the notice."""
    from core.audit import audit_event
    from core.feed import feed_alerts
    from core.published_api.notices import notify_consumers
    from core.published_api.registry import load
    reg = load()
    notice = timedelta(days=sunset_notice_days())
    out: Dict[str, Any] = {"retired": 0, "due": 0, "notified": 0, "cleared": 0, "errors": []}
    for api in apis:
        lc = api.lifecycle or {}
        subject = subject_for(api)
        dk = subject.dedupe_key(KIND_SUNSET_DUE)
        sunset = _as_dt(lc.get("sunset_at")) if lc.get("status") == LIFECYCLE_DEPRECATED else None
        if sunset is None:
            if dk in open_alerts and feed_alerts.clear(db, by=f"{ACTOR}:no sunset pending", dedupe_keys=[dk]):
                open_alerts.pop(dk, None)
                out["cleared"] += 1
            continue
        if sunset <= now:
            kind = reg.get(api.api_kind)
            if kind is None:
                out["errors"].append(f"{api.api_kind}:{api.key}: kind not registered")
                continue
            fields = fields_for(LIFECYCLE_RETIRED, sunset_at=None, note=lc.get("deprecation_note"),
                                successor=lc.get("successor"), actor=ACTOR)
            row = db.set_api_lifecycle(kind.model, int(api.api_id), fields, offered=False, set_offered=kind.set_offered)
            if row is None:
                out["errors"].append(f"{api.api_kind}:{api.key}: row gone before retirement")
                continue
            out["retired"] += 1
            api.lifecycle = lifecycle_of(row, False)
            verdict = notify_consumers(db, api, "retired")
            try:
                audit_event(db, {"username": ACTOR, "role": "system"}, None, "api.sunset_reached", "published_api",
                            f"{api.api_kind}:{api.api_id}",
                            {"kind": api.api_kind, "key": api.key, "sunset_at": sunset.isoformat(), "notified": verdict})
            except Exception:                           # noqa: BLE001
                logger.debug("[published-api alerts] sunset audit not written", exc_info=True)
            if dk in open_alerts and feed_alerts.clear(db, by=f"{ACTOR}:sunset reached", dedupe_keys=[dk]):
                open_alerts.pop(dk, None)
                out["cleared"] += 1
            logger.warning("[published-api alerts] RETIRED %s:%s at its sunset %s", api.api_kind, api.key, sunset.isoformat())
        elif sunset - now <= notice:
            out["due"] += 1
            if dk not in open_alerts:
                days = max(0, int((sunset - now).total_seconds() // 86400))
                msg = (f"retires {sunset.date().isoformat()} ({days} days): its consumers are told now"
                       + (f"; successor '{lc.get('successor')}'" if lc.get("successor") else ""))
                a = feed_alerts.raise_alert(db, KIND_SUNSET_DUE, subject=subject, message=msg)
                if a is None:
                    out["errors"].append(f"{dk}: NOT raised -- kind {KIND_SUNSET_DUE!r} undeclared or the road failed")
                else:
                    open_alerts[dk] = a
                    notify_consumers(db, api, "sunset_due")
                    out["notified"] += 1
    return out


def sweep_gone(db, apis: List[PublishedApi], *, now: datetime, open_alerts: Dict[str, dict]) -> Dict[str, Any]:
    """An open alert about an API the inventory no longer lists is cleared."""
    from core.feed import feed_alerts
    live = {subject_key_of(a.api_kind, a.key) for a in apis}
    gone = [dk for dk, a in open_alerts.items() if a.get("subject_key") not in live]
    cleared = feed_alerts.clear(db, by=f"{ACTOR}:api gone", dedupe_keys=gone) if gone else []
    for dk in gone:
        open_alerts.pop(dk, None)
    return {"cleared": len(cleared)}


SWEEPS = (("sunsets", sweep_sunsets), ("thresholds", evaluate_thresholds),
          ("dependencies", sweep_dependencies), ("gone", sweep_gone))


def after_roll(db, *, now: Optional[datetime] = None) -> Dict[str, Any]:
    """The alert pass of one tick: the inventory built ONCE, the open API
    alerts read ONCE, then the sweeps in order (a sunset that retires an API
    this tick takes it out of every later scope).  Each sweep's failure is
    its own line; the pass goes on."""
    if not alerts_enabled():
        return {"status": "skipped", "reason": "published_views.alerts_enabled is false"}
    now = _as_dt(now) or datetime.now(timezone.utc)
    try:
        from core.published_api.inventory import build_inventory
        apis, meta = build_inventory(db)
    except Exception as exc:                            # noqa: BLE001
        return {"status": "error", "error": f"the inventory could not be built: {type(exc).__name__}: {exc}"}
    try:
        open_alerts = {a["dedupe_key"]: a for a in db.list_feed_alerts(subject_kind=SUBJECT_KIND, status="open", limit=100000)}
    except Exception as exc:                            # noqa: BLE001
        return {"status": "error", "error": f"the open alerts could not be read: {type(exc).__name__}: {exc}"}
    out: Dict[str, Any] = {"status": "ran", "apis": len(apis), "open_alerts_before": len(open_alerts),
                           "inventory_problems": list(meta.get("problems") or [])}
    for name, fn in SWEEPS:
        try:
            out[name] = fn(db, apis, now=now, open_alerts=open_alerts)
        except Exception as exc:                        # noqa: BLE001
            logger.exception("[published-api alerts] the %s sweep failed", name)
            out[name] = {"status": "error", "error": f"{type(exc).__name__}: {exc}"}
            out["status"] = "error"
    out["open_alerts_after"] = len(open_alerts)
    return out


def retire_threshold(db, threshold_id: int, *, by: str) -> Dict[str, Any]:
    """Delete a threshold AND clear the alerts it raised (2026-10-18, found on
    the rig: the proof deleted its threshold in its cleanup, the delete took
    the verdict rows with it, and the alert it had raised stayed open with
    nobody left to clear it -- the out-of-scope rule needs a verdict row to
    read).  The dedupe keys come from the verdict rows BEFORE they go; the
    clears send the Netcool resolutions.  Returns what happened."""
    from core.feed import feed_alerts
    states = db.list_published_api_alert_states(threshold_id=int(threshold_id))
    keys = sorted({s["dedupe_key"] for s in states if s.get("dedupe_key")})
    cleared = feed_alerts.clear(db, by=by, dedupe_keys=keys) if keys else []
    deleted = db.delete_published_api_alert_threshold(int(threshold_id))
    return {"deleted": bool(deleted), "verdicts_dropped": len(states), "alerts_cleared": len(cleared),
            "cleared_keys": [a.get("dedupe_key") for a in cleared]}


# ── what the page reads ───────────────────────────────────────────────────

def thresholds_for(db, api: PublishedApi) -> List[Dict[str, Any]]:
    """The active thresholds in this API's scope, each with its last verdict
    for this API (None = not yet evaluated)."""
    states = {int(s["threshold_id"]): s for s in db.list_published_api_alert_states(api_kind=api.api_kind, api_id=int(api.api_id))}
    out = []
    for t in db.list_published_api_alert_thresholds(active_only=True):
        if api in apis_in_scope(t, [api]) or (not is_offered(api) and _scope_matches(t, api)):
            out.append({**t, "state": states.get(int(t["id"]))})
    return out


def _scope_matches(thr: Dict[str, Any], api: PublishedApi) -> bool:
    scope = thr.get("scope")
    if scope == SCOPE_GLOBAL:
        return True
    if scope == SCOPE_KIND:
        return api.api_kind == thr.get("api_kind")
    return api.api_kind == thr.get("api_kind") and str(api.key) == str(thr.get("scope_key"))


__all__ = ["ACTOR", "ALERT_KINDS", "API_ALERT_KIND_NAMES", "DEFAULT_ALERT_GROUP", "DEFAULT_THRESHOLDS",
           "KIND_DEPENDENCY_BROKEN", "KIND_ERROR_RATE", "KIND_LATENCY", "KIND_NO_CALLS", "KIND_RATE_LIMITED",
           "KIND_SUNSET_DUE", "METRICS", "OPERATORS", "SCOPES", "SCOPE_API", "SCOPE_GLOBAL", "SCOPE_KIND", "STATES",
           "STATE_BREACH", "STATE_INSUFFICIENT", "STATE_OK", "STATE_UNKNOWN", "SUBJECT_KIND", "SWEEPS", "after_roll",
           "alert_group", "alerts_enabled", "apis_in_scope", "breaches", "evaluate_thresholds", "is_offered", "judge",
           "measure", "subject_for", "subject_key_of", "sweep_dependencies", "sweep_gone", "sweep_sunsets",
           "threshold_dedupe_key", "thresholds_for", "totals", "validate_threshold"]
