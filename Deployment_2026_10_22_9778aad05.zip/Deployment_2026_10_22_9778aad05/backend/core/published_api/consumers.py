"""ONE answer to "may this API key call this view" (2026-10-17).

Found in the design review: the GATE (``api/published_views/helpers.py::
_check_key_scope``, fail-closed since 2026-08-17 -- an EMPTY scope grants
nothing, ``"*"`` / ``-1`` is the explicit master key) and the READER
(``DatabaseManager.list_api_keys_for_view``) disagreed: the reader listed a
key with an EMPTY scope as a consumer of EVERY view, so the inventory, the
schema-change notices and "who can call this" named people who could call
nothing.  Both now ask :func:`key_can_call`; a test pins them to it.
"""
from __future__ import annotations

from typing import Any, Iterable, Optional, Tuple

#: The explicit global-scope markers (``helpers._GLOBAL_SCOPE_MARKERS``):
#: a MASTER key is a presence on the row, never an absence.
GLOBAL_MARKERS = frozenset({"*", -1, "-1"})

REASON_GLOBAL = "global"
REASON_SCOPED = "scoped"
REASON_LEGACY_MASTER = "legacy_master"
REASON_NOT_IN_SCOPE = "not_in_scope"
REASON_EMPTY_SCOPE = "empty_scope"


def scope_is_global(scoped: Iterable[Any]) -> bool:
    return any(s in GLOBAL_MARKERS for s in (scoped or []))


def scoped_ids(scoped: Iterable[Any]) -> set:
    out = set()
    for s in scoped or []:
        if s in GLOBAL_MARKERS:
            continue
        try:
            out.add(int(s))
        except (TypeError, ValueError):
            continue
    return out


def _empty_scope_legacy_master_key() -> bool:
    """``published_views.empty_scope_master_key`` -- the loud, documented
    legacy escape hatch (ships false)."""
    try:
        from core.config import get as _get
        return bool(_get("published_views", "empty_scope_master_key", False))
    except Exception:                                   # noqa: BLE001 -- unknown = unsafe
        return False


def key_can_call(scoped_view_ids: Optional[Iterable[Any]], view_id: int,
                 *, legacy_master: Optional[bool] = None) -> Tuple[bool, str]:
    """``(allowed, reason)`` -- the whole rule, fail-closed:

    * the scope carries the global marker            -> (True, "global")
    * the view id is in the scope                    -> (True, "scoped")
    * the scope is EMPTY and the legacy escape hatch
      ``published_views.empty_scope_master_key`` is on -> (True, "legacy_master")
    * the scope is EMPTY                             -> (False, "empty_scope")
    * anything else                                  -> (False, "not_in_scope")
    """
    scoped = list(scoped_view_ids or [])
    if scope_is_global(scoped):
        return True, REASON_GLOBAL
    ids = scoped_ids(scoped)
    try:
        if int(view_id) in ids:
            return True, REASON_SCOPED
    except (TypeError, ValueError):
        return False, REASON_NOT_IN_SCOPE
    if not ids:
        allowed = _empty_scope_legacy_master_key() if legacy_master is None else bool(legacy_master)
        return (True, REASON_LEGACY_MASTER) if allowed else (False, REASON_EMPTY_SCOPE)
    return False, REASON_NOT_IN_SCOPE


def keys_for_view(keys: Iterable[dict], view_id: int) -> list:
    """The key rows (dicts) that can call ``view_id``, each with ``scope``
    = ``every_api`` (global) | ``this_api``, by THE rule."""
    out = []
    for k in keys or []:
        ok, reason = key_can_call(k.get("scoped_view_ids") or [], view_id)
        if ok:
            d = dict(k)
            d["scope"] = "every_api" if reason in (REASON_GLOBAL, REASON_LEGACY_MASTER) else "this_api"
            d["scope_reason"] = reason
            out.append(d)
    return out


__all__ = ["GLOBAL_MARKERS", "REASON_EMPTY_SCOPE", "REASON_GLOBAL", "REASON_LEGACY_MASTER",
           "REASON_NOT_IN_SCOPE", "REASON_SCOPED", "key_can_call", "keys_for_view", "scope_is_global",
           "scoped_ids"]
