"""A key's EFFECTIVE rate limit -- computed ONCE, read by the enforcement
and by every place a key's limit is shown (2026-10-18).

Found on the rig: both proof keys declared ``100000/minute`` and 170 calls
came back 429 ``rate_limit``.  Not a limiter bug: ``published_views.
max_rate_limit`` (300/minute) caps every key, inside the enforcement, where
nobody reading the key's face, the Consumers & keys tab or the inventory
could see it -- the consumer was refused at 300 while every screen said
100000.  The cap is right; its invisibility was the defect.  This module is
the one answer: ``effective_rate_limit(declared)`` says what the consumer is
held to and WHY, the enforcement charges exactly that, the 429 names it, and
the displays repeat it -- so they can never disagree.
"""
from __future__ import annotations

from typing import Any, Dict, Optional, Tuple

_WINDOWS = {"second": 1, "minute": 60, "hour": 3600}
_UNIT_OF = {v: k for k, v in _WINDOWS.items()}

DEFAULT_RATE_LIMIT = "60/minute"
DEFAULT_MAX_RATE_LIMIT = "300/minute"


def parse_rate_limit(rate_str: Optional[str], default: str = DEFAULT_RATE_LIMIT) -> Tuple[int, int]:
    """``'120/minute'`` -> ``(120, 60)``.  Formats ``N/second|minute|hour``;
    a blank or malformed value reads as *default* (never as unlimited)."""
    s = (rate_str or default)
    try:
        parts = str(s).strip().split("/", 1)
        limit = int(parts[0])
        unit = parts[1].lower().strip() if len(parts) > 1 else "minute"
        window = _WINDOWS.get(unit, 60)
        return max(limit, 0), window
    except (ValueError, IndexError, AttributeError):
        return parse_rate_limit(default, DEFAULT_RATE_LIMIT) if rate_str else (60, 60)


def _configured() -> Tuple[str, str]:
    """``(default_rate_limit, max_rate_limit)`` as the deployment declares them."""
    default_rl, max_rl = DEFAULT_RATE_LIMIT, DEFAULT_MAX_RATE_LIMIT
    try:
        from core.config import published_views as _pv
        v = _pv.default_rate_limit
        if isinstance(v, str) and "/" in v:
            default_rl = v
        v2 = _pv.max_rate_limit
        if isinstance(v2, str) and "/" in v2:
            max_rl = v2
    except Exception:                                   # noqa: BLE001 -- the declared defaults stand
        pass
    return default_rl, max_rl


def words(limit: int, window_seconds: int) -> str:
    return f"{int(limit)}/{_UNIT_OF.get(int(window_seconds), f'{int(window_seconds)}s')}"


def effective_rate_limit(declared: Optional[str], *, default_rl: Optional[str] = None,
                         max_rl: Optional[str] = None) -> Dict[str, Any]:
    """THE rule.  ``declared`` is the key's own ``rate_limit`` (None = the
    deployment's default).  The operator's ``max_rate_limit`` caps it when
    both speak the same window.  Returns::

        {"declared": "100000/minute" | None,
         "effective": "300/minute",      # what the consumer is held to
         "limit": 300, "window_seconds": 60,
         "capped": True,
         "reason": "capped by published_views.max_rate_limit (300/minute)" | None,
         "source": "key" | "default"}
    """
    cfg_default, cfg_max = _configured()
    default_rl = default_rl if isinstance(default_rl, str) and "/" in default_rl else cfg_default
    max_rl = max_rl if isinstance(max_rl, str) and "/" in max_rl else cfg_max
    limit, window = parse_rate_limit(declared, default_rl)
    max_limit, max_window = parse_rate_limit(max_rl, DEFAULT_MAX_RATE_LIMIT)
    capped = window == max_window and limit > max_limit
    eff_limit = max_limit if capped else limit
    reason = None
    if capped:
        reason = f"capped by published_views.max_rate_limit ({words(max_limit, max_window)})"
    elif not declared:
        reason = f"the key declares no limit: published_views.default_rate_limit ({words(limit, window)})"
    return {"declared": declared or None, "effective": words(eff_limit, window), "limit": int(eff_limit),
            "window_seconds": int(window), "capped": bool(capped), "reason": reason,
            "source": "key" if declared else "default"}


def annotate_key(row: Dict[str, Any]) -> Dict[str, Any]:
    """A key record (the keys list, a create / approve answer, a consumer) with
    its effective limit beside the declared one -- the same function the
    enforcement charges by."""
    if not isinstance(row, dict):
        return row
    eff = effective_rate_limit(row.get("rate_limit"))
    return {**row, "effective_rate_limit": eff["effective"], "rate_limit_capped": eff["capped"],
            "rate_limit_cap_reason": eff["reason"], "effective_rate_limit_detail": eff}


__all__ = ["DEFAULT_MAX_RATE_LIMIT", "DEFAULT_RATE_LIMIT", "annotate_key", "effective_rate_limit",
           "parse_rate_limit", "words"]
