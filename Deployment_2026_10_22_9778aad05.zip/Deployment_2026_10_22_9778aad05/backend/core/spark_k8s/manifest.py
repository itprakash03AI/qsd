"""THE SparkApplication manifest builder — single source (2026-08-22).

PROMOTED out of ``airflow/dags/querystudio_feed_factory.py`` (which carried
``_build_spark_application_spec`` + the credential-redaction machinery since
Phase 128 / E-cred).  Exactly ONE builder now exists; the native spark_k8s
runner and the Airflow feed factory (via the ``/spark-submit`` endpoint)
both submit CR bodies produced HERE.

The builder is PURE: it reads no config, touches no network, takes explicit
``SparkK8sSettings`` — so tests assert the CR body actually produced, by
value, with no mocking of config machinery.

E-cred contract carried with the move: when ``secret_sink`` is a dict, the
credentials-bearing ``--feed-config`` JSON goes INTO the sink (the caller
creates a K8s Secret from it, BEFORE the CR, so the driver's secretKeyRef
resolves) and the CLI argument carries a credentials-REDACTED copy for
observability.  ``secret_sink=None`` embeds credentials inline (legacy
behaviour, kept for parity with old deployments that never created the
Secret RBAC).
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

SPARK_APP_GROUP = "sparkoperator.k8s.io"
SPARK_APP_VERSION = "v1beta2"
SPARK_APP_PLURAL = "sparkapplications"

#: Stamped on every CR and Secret this product creates so the reconciler can
#: LIST its own objects (and ONLY its own) with one label selector.
MANAGED_BY_KEY = "app.kubernetes.io/managed-by"
MANAGED_BY_VALUE = "querystudio"
MANAGED_BY_SELECTOR = f"{MANAGED_BY_KEY}={MANAGED_BY_VALUE}"
EXECUTION_ID_LABEL = "querystudio.io/execution-id"
ATTEMPT_LABEL = "querystudio.io/attempt"

# ── Credential handling (E-cred: keep secrets off the CLI arguments) ─────

SENSITIVE_KEYS = frozenset({
    "password", "passwd", "pwd",
    "secret_access_key", "aws_secret_access_key",
    "session_token", "aws_session_token",
    "private_key", "private_key_content", "passphrase", "key_pass",
    "private_key_passphrase", "key_passphrase",
    "client_secret", "api_key", "token",
})


def redact_credentials(obj):
    """Return a deep copy of ``obj`` with the values of any credential-like
    keys replaced by "".  Used to build a credentials-FREE ``--feed-config``
    CLI argument; the real values travel via a mounted K8s secret env var."""
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if isinstance(k, str) and k.lower() in SENSITIVE_KEYS and not isinstance(v, (dict, list)):
                out[k] = ""
            else:
                out[k] = redact_credentials(v)
        return out
    if isinstance(obj, list):
        return [redact_credentials(v) for v in obj]
    return obj


# ── Names ────────────────────────────────────────────────────────────────

_NAME_UNSAFE = re.compile(r"[^a-z0-9-]")

#: FR-ID-01/02 (2026-09-03) — the retry-attempt ceiling.  The feed-name
#: length limit (core/feed/identity.py, 47 chars) budgets a TWO-digit
#: attempt suffix ("-r99", 4 chars); at attempt 100 the suffix grows to
#: 5 chars and ``cr_name_for`` silently truncates even a compliant
#: 47-char name — which is exactly the silent sanitisation FR-ID-01
#: forbids.  So ``spark_k8s.max_retries`` is CLAMPED here, at the one
#: place every constructor of settings passes through, rather than
#: hoped-bounded in config.  99 retries of a Spark job is already an
#: operational absurdity; the clamp costs nothing real.
MAX_RETRIES_CLAMP = 99


#: Where spark/Dockerfile puts the image's log4j2.properties (Spark's own
#: logging at WARN so the driver log reads as the feed's story).  It is
#: deliberately NOT under /opt/spark/conf: spark-submit mounts the driver's
#: ConfigMap there in cluster mode and shadows the image's copy.  The CR
#: points driver and executors at it (2026-09-14).
LOG4J2_IMAGE_PATH = "/opt/spark/log4j2.properties"
LOG4J2_JAVA_OPTION = f"-Dlog4j2.configurationFile=file://{LOG4J2_IMAGE_PATH}"

#: The CR name budget: a 63-char DNS label minus ``-driver``.
CR_NAME_MAX = 56
#: Spark refuses ``spark.kubernetes.executor.podNamePrefix`` longer than
#: this (it appends ``-exec-<n>`` and must itself fit a DNS label).
EXECUTOR_PREFIX_MAX = 47
#: Execution ids are minted as ``feed-<16 hex>`` (api/feed_api.py,
#: feed_executor.py); the readable pod name carries the hex, not the
#: redundant ``feed-``.
_EXEC_ID_PREFIX = "feed-"


def _label_token(value) -> str:
    """Lower-case DNS-1123 material: [a-z0-9-], no leading/trailing '-'."""
    return _NAME_UNSAFE.sub("-", str(value or "").lower()).strip("-")


def short_execution_id(execution_id: str) -> str:
    """The identity half of a workload name: the execution id with ONE
    leading ``feed-`` removed (every id the API mints starts with it,
    so keeping it made every pod read ``feed-feed-...``)."""
    raw = str(execution_id or "")
    if raw.lower().startswith(_EXEC_ID_PREFIX) and len(raw) > len(_EXEC_ID_PREFIX):
        raw = raw[len(_EXEC_ID_PREFIX):]
    return _label_token(raw)


def _workload_base(execution_id: str, feed_name, budget: int) -> str:
    """``<feed-name>-<short-id>`` fitted into ``budget`` characters.

    The ID is never cut -- it is the idempotency key (a duplicate create
    409s into ADOPTION on the name) and the only thing that makes two
    runs of one feed distinct.  When the two together overflow, the
    readable NAME is shortened, deterministically, and that is by
    design rather than a silent truncation: the identity label and
    the execution row still carry the full feed name.
    """
    short = short_execution_id(execution_id) or "x"
    name = _label_token(feed_name)
    if not name:
        # No feed name known (a caller predating 2026-09-14): the old
        # shape minus its doubled prefix.
        name = "feed"
    keep = budget - len(short) - 1
    if keep < 1:
        return short[:budget].strip("-") or "x"
    if len(name) > keep:
        name = name[:keep].rstrip("-") or name[:1]
    return f"{name}-{short}"


def cr_name_for(execution_id: str, attempt: int = 0,
                feed_name=None) -> str:
    """DNS-1123-safe SparkApplication / driver-pod name for one execution
    attempt: ``<feed-name>-<short-execution-id>[-r{n}]``.

    2026-09-14 -- the operator could not find their run in ``kubectl get
    pods``: the name was ``feed-{execution_id}`` and execution ids already
    start with ``feed-``, so every driver read ``feed-feed-<hex>-driver``
    and the feed's NAME appeared nowhere on it.  Now the sanitized feed
    name comes FIRST (``spark-k8s-demo-oracle-ece6db55ca6b4e41``), the
    hex keeps the name unique, and executors share the prefix through
    ``spark.kubernetes.executor.podNamePrefix``.

    Kept from the old scheme: deterministic per (feed, execution,
    attempt) -- a duplicate create still 409s into ADOPTION; the 56-char
    cap so ``{name}-driver`` fits the 63-char DNS label; and the
    ``-r{n}`` retry suffix (attempt recoverable from the name alone,
    ``MAX_RETRIES_CLAMP`` bounds it to two digits).

    Dropped, deliberately: byte-identity with the historic Airflow
    factory's ``feed-{execution_id}``.  That factory has not created a
    CR since 2026-08-22 (the DAG delegates to ``/spark-submit``, which
    uses THIS builder), the reconciler and cancel read the name from the
    execution row's ``external_job_id`` rather than recomputing it, and
    the pre-upgrade sweep (``preupgrade.py``) still recognises the old
    unlabeled shape by its own prefix.  ``attempt_from_name`` parses
    either shape.
    """
    suffix = f"-r{int(attempt)}" if int(attempt) >= 1 else ""
    base = _workload_base(execution_id, feed_name, CR_NAME_MAX - len(suffix))
    return base + suffix


def executor_pod_name_prefix(execution_id: str, attempt: int = 0,
                             feed_name=None) -> str:
    """``spark.kubernetes.executor.podNamePrefix`` for the same attempt:
    the same ``<feed-name>-<short-id>`` fitted into Spark's 47-char
    prefix budget, so executors read ``<prefix>-exec-1`` beside their
    driver instead of Spark's ``querystudio-feed-...-<hash>-exec-1``.
    The short id stays whole here too -- two concurrent runs of one feed
    must never share an executor prefix (Spark numbers executors per
    app, so a shared prefix is a pod-name collision)."""
    suffix = f"-r{int(attempt)}" if int(attempt) >= 1 else ""
    base = _workload_base(execution_id, feed_name,
                          EXECUTOR_PREFIX_MAX - len(suffix))
    return base + suffix


def secret_name_for(execution_id: str, attempt: int = 0,
                    feed_name=None) -> str:
    """Per-attempt credentials Secret name, paired 1:1 with the CR name."""
    return "creds-" + cr_name_for(execution_id, attempt, feed_name)


_ATTEMPT_RE = re.compile(r"-r(\d+)$")


def attempt_from_name(cr_name: str) -> int:
    """Parse the attempt number back out of a CR name (0 when unsuffixed)."""
    m = _ATTEMPT_RE.search(str(cr_name or ""))
    return int(m.group(1)) if m else 0


# ── Settings ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class SparkK8sSettings:
    """Everything the manifest builder + runner need, resolved ONCE.

    Every field maps 1:1 onto a DECLARED ``spark_k8s.*`` key in
    ``core.config._DEFAULTS`` (see ``from_config``); the dataclass exists so
    the builder stays pure and tests inject values instead of patching
    config machinery.
    """
    namespace: str = "spark"
    #: "spark_application" (CR + spark-operator) | "driver_pod" (POST the
    #: driver pod ourselves and let Spark's own Kubernetes cluster
    #: manager create the executors — what spark-submit --deploy-mode
    #: cluster does, minus the CLI).  An operator is a wrapper around
    #: the same pod, not a requirement for running Spark on k8s.
    #: ``auto`` (the config default since 2026-09-14) resolves to one of
    #: the two at submit; the dataclass default stays the CR shape so a
    #: test that constructs settings directly holds a concrete mode.
    submit_mode: str = "spark_application"
    #: How Spark addresses the API server from inside the driver.
    master_url: str = "k8s://https://kubernetes.default.svc:443"
    #: Registry pull secret names for the driver pod.
    image_pull_secrets: tuple = ()
    #: "" = do not set runAsUser; let the OpenShift SCC assign one from
    #: the project range.  Pinning a UID outside that range is rejected
    #: at admission.
    driver_run_as_user: str = ""
    image: str = "querystudio/spark-etl:latest"
    image_pull_policy: str = "Always"
    service_account: str = "spark"
    callback_base_url: str = "http://querystudio-api:8000"
    #: how often the job reports progress (0 = never); 2026-10-14
    progress_interval_seconds: int = 30
    webhook_secret: str = ""
    creds_via_secret: bool = True
    driver_cores: int = 1
    driver_memory: str = "4g"
    executor_cores: int = 4
    executor_memory: str = "8g"
    num_executors: int = 4
    spark_conf: dict = field(default_factory=dict)
    # lifecycle knobs (consumed by runner/reconciler, carried here so ONE
    # object travels)
    max_retries: int = 1
    retry_backoff_seconds: int = 300
    #: D10 — expected life of a temporary credential; 0 disables.
    session_token_expected_ttl_seconds: int = 3600
    job_timeout_seconds: int = 7200
    #: H2 + FR-ARCH-03 — named execution profiles: ``{name:
    #: {job_timeout_seconds, driver_memory, executor_memory,
    #: executor_cores, num_executors}}`` — every knob optional, each
    #: falling through to the deployment default (see resolve_sizing).
    size_classes: dict = field(default_factory=dict)
    #: D9 — a CR still SUBMITTED (no driver) past this is NEVER-STARTED.
    pending_timeout_seconds: int = 900
    webhook_grace_seconds: int = 120
    adoption_grace_seconds: int = 120
    reconcile_interval_seconds: int = 15
    completed_cr_ttl_seconds: int = 3600
    status_poll_interval_seconds: int = 10
    poll_timeout_seconds: int = 7200
    # 2026-08-22 closeout: pre-upgrade unlabeled CR/Secret sweep gate
    # (core/spark_k8s/preupgrade.py).  The classifier vocabulary keys
    # (classifier_markers / cr_states) are deliberately NOT mirrored here:
    # the classifier reads them lazily so an operator's runtime config
    # change applies on the next classification without a settings rebuild.
    preupgrade_sweep_enabled: bool = True
    #: FR-ARCH-02 (2026-09-03) — the JDBC driver classes present on the
    #: Spark image's classpath.  The default (filled in ``__post_init__``
    #: from ``PINNED_IMAGE_DRIVER_CLASSES``) is DERIVED from the pinned
    #: image: spark/Dockerfile bakes exactly those five jars.  A custom
    #: image declares its own set by constructing settings with this
    #: field; an EMPTY tuple passed explicitly is normalised to the
    #: pinned default (use ``("*",)`` to declare "unknown image, skip
    #: the preflight").  The submit preflight
    #: (core/spark_k8s/jdbc.py::assert_driver_on_classpath) refuses
    #: BEFORE a pod is born instead of letting the detached driver die
    #: with ClassNotFoundException — the very marker classifier.py
    #: already classifies NON_RETRYABLE.
    image_driver_classes: tuple = ()

    def __post_init__(self):
        # ``spark_k8s.max_retries`` had NO upper clamp: at attempt 100 the
        # "-r{n}" suffix outgrows the two-digit budget the feed-name limit
        # (FR-ID-02) was derived from, and even a compliant 47-char name
        # silently truncates in the CR name.  Clamp at the chokepoint every
        # constructor passes through (config-resolved AND test-injected).
        if int(self.max_retries) > MAX_RETRIES_CLAMP:
            logger.warning(
                "[spark_k8s] max_retries=%s exceeds the clamp of %d (the "
                "retry-suffix budget the feed-name length limit FR-ID-02 "
                "is derived from) — clamped to %d.",
                self.max_retries, MAX_RETRIES_CLAMP, MAX_RETRIES_CLAMP)
            object.__setattr__(self, "max_retries", MAX_RETRIES_CLAMP)
        if not self.image_driver_classes:
            from core.spark_k8s.jdbc import PINNED_IMAGE_DRIVER_CLASSES
            object.__setattr__(self, "image_driver_classes",
                               tuple(PINNED_IMAGE_DRIVER_CLASSES))

    @property
    def callback_url(self) -> str:
        return f"{self.callback_base_url.rstrip('/')}/api/webhooks/feed-complete"

    @property
    def progress_url(self) -> str:
        """Where the job reports WHERE IT IS (core/feed/run_progress.py)."""
        return f"{self.callback_base_url.rstrip('/')}/api/webhooks/feed-progress"


def resolve_job_timeout_seconds(backend_config: Optional[dict],
                                settings: SparkK8sSettings) -> tuple:
    """H2 (2026-09-02) — the effective job timeout for ONE feed.

    A single global timeout cannot serve both a 40k-row feed and a 160M-row
    month-end.  With JDBC partition bounds unset, Spark performs a
    single-partition read: 160M rows down one connection at
    ``fetchsize=10000`` is roughly 1-1.5 h of pure pull, which sits JUST
    INSIDE the 7200s default -- so a month-end that runs long is killed and
    then retried once into the same wall.

    Precedence, documented because an undocumented precedence is a bug
    waiting to be argued about:

      1. an explicit ``backend_config.spark_job_timeout_seconds`` on the feed
      2. else the feed's named ``backend_config.spark_size_class``
      3. else the deployment default ``spark_k8s.job_timeout_seconds``

    An UNKNOWN class name falls back to the deployment default and says so in
    the returned reason -- never silently, or a typo in a size class becomes a
    2h cap on a 6h feed and looks exactly like a slow source.

    Returns ``(timeout_seconds, reason)``.  The reason travels onto the
    execution row so "why was my feed killed at 2h?" is answerable from the
    run, not from someone's memory of the config.
    """
    bc = backend_config or {}
    explicit = bc.get("spark_job_timeout_seconds")
    if explicit is not None:
        try:
            val = int(explicit)
        except (TypeError, ValueError):
            logger.error(
                "[spark_k8s] backend_config.spark_job_timeout_seconds=%r is "
                "not an integer — falling back to the deployment default "
                "(%ss)", explicit, settings.job_timeout_seconds)
        else:
            if val >= 0:
                return val, "feed override"
            logger.error(
                "[spark_k8s] backend_config.spark_job_timeout_seconds=%r is "
                "negative — falling back to the deployment default (%ss)",
                explicit, settings.job_timeout_seconds)

    name = bc.get("spark_size_class")
    if name:
        cls = (settings.size_classes or {}).get(str(name))
        if isinstance(cls, dict) and cls.get("job_timeout_seconds") is not None:
            return int(cls["job_timeout_seconds"]), f"size class '{name}'"
        logger.error(
            "[spark_k8s] size class %r is not declared in "
            "spark_k8s.size_classes (declared: %s) — falling back to the "
            "deployment default (%ss).  A typo here silently caps a long "
            "feed at the default.",
            name, sorted((settings.size_classes or {}).keys()),
            settings.job_timeout_seconds)
        return settings.job_timeout_seconds, f"unknown size class '{name}'"

    return settings.job_timeout_seconds, "deployment default"


#: FR-ARCH-03 (2026-09-03) — the sizing knobs a size class may carry,
#: mapped (settings-field / size-class key / per-feed backend_config key).
#: One vocabulary, so "raise every large feed by 8GB" is ONE size-class
#: row instead of an edit to every feed.
SIZING_KEYS = (
    ("driver_memory",   "driver_memory",   "spark_driver_memory"),
    ("executor_memory", "executor_memory", "spark_executor_memory"),
    ("executor_cores",  "executor_cores",  "spark_executor_cores"),
    ("num_executors",   "num_executors",   "spark_num_executors"),
)


def resolve_sizing(backend_config: Optional[dict],
                   settings: SparkK8sSettings) -> dict:
    """FR-ARCH-03 (2026-09-03) — per-feed pod sizing with the SAME 3-level
    precedence the job timeout already has:

      1. an explicit ``backend_config.spark_*`` override on the feed
      2. else the feed's named ``backend_config.spark_size_class``
      3. else the deployment default (``spark_k8s.*``)

    Before this, a size class carried ONLY a timeout: the section titled
    "Per-feed sizing" yielded identical pods for every class, and raising
    every large feed's executor memory meant editing every large feed.
    Now ``spark_k8s.size_classes.<name>`` may declare ``driver_memory``,
    ``executor_memory``, ``executor_cores`` and ``num_executors``
    alongside ``job_timeout_seconds``; any knob a class does not declare
    falls through to the deployment default, exactly like the timeout.

    An UNKNOWN class name falls back to the deployment defaults — loudly,
    in ``resolve_job_timeout_seconds`` (the shared reason path); this
    function stays quiet about it to avoid a duplicate error per knob.

    Returns ``{driver_memory, executor_memory, executor_cores,
    num_executors, reason}`` where ``reason`` maps each knob to which
    level supplied it (travels into logs, not the CR).
    """
    bc = backend_config or {}
    cls: dict = {}
    name = bc.get("spark_size_class")
    if name:
        candidate = (settings.size_classes or {}).get(str(name))
        if isinstance(candidate, dict):
            cls = candidate
    out: dict = {}
    reason: dict = {}
    for field_name, cls_key, bc_key in SIZING_KEYS:
        if bc.get(bc_key) is not None:
            out[field_name] = bc[bc_key]
            reason[field_name] = "feed override"
        elif cls.get(cls_key) is not None:
            out[field_name] = cls[cls_key]
            reason[field_name] = f"size class '{name}'"
        else:
            out[field_name] = getattr(settings, field_name)
            reason[field_name] = "deployment default"
    out["reason"] = reason
    return out


#: Keys whose presence means the credential is TEMPORARY and therefore has a
#: clock on it.  A long-lived access key has no session token.
SESSION_TOKEN_KEYS = frozenset({
    "session_token", "aws_session_token", "sessiontoken",
    "security_token", "aws_security_token",
})


def carries_temporary_credentials(obj) -> bool:
    """True when *obj* holds a session token anywhere in its structure.

    Walks the whole ``--feed-config`` payload rather than one known field,
    because the credential can arrive on the source connection, the
    destination connection, or a resolved plan side -- and a check that
    inspects only one of those reports "no session token" for a run that has
    one, which is the wrong answer in the unsafe direction.
    """
    if isinstance(obj, dict):
        for k, v in obj.items():
            if (isinstance(k, str) and k.strip().lower() in SESSION_TOKEN_KEYS
                    and isinstance(v, str) and v.strip()):
                return True
            if carries_temporary_credentials(v):
                return True
        return False
    if isinstance(obj, list):
        return any(carries_temporary_credentials(v) for v in obj)
    return False


def credential_lifetime_refusal(feed_conf: dict, timeout_seconds: int,
                                settings: SparkK8sSettings) -> Optional[str]:
    """D10 (2026-09-02) — refuse a run that will outlive its credentials.

    A 90-minute read on a one-hour STS token starts fine and then returns 403s
    part way through.  Those classify as retryable, so the reconciler
    resubmits -- into a token with the SAME lifetime, from a clock that has
    already advanced.  The feed spends its retries losing a race it cannot
    win, and the failure reads as an auth problem rather than a duration one.

    So it is refused AT SUBMIT, where the message can say what to change.

    Returns the refusal reason, or ``None`` when the run is safe.  Returns
    ``None`` (permits) whenever the check does not apply: no session token,
    an unbounded budget, or the check disabled -- an availability cost must
    never be paid for a risk that is not present.
    """
    ttl = int(getattr(settings, "session_token_expected_ttl_seconds", 0) or 0)
    if ttl <= 0:
        return None                       # declared off
    if timeout_seconds <= ttl:
        # Covers the unbounded budget too (job_timeout_seconds=0): an
        # unbounded budget cannot be compared against a TTL, and refusing
        # it would turn "governance deliberately off" into "nothing runs".
        return None
    if not carries_temporary_credentials(feed_conf):
        return None                       # long-lived credential, no clock
    return (
        f"this run's budget is {timeout_seconds}s but it uses TEMPORARY "
        f"credentials expected to last {ttl}s "
        f"(spark_k8s.session_token_expected_ttl_seconds).  A read that "
        f"outlives its token returns 403s, which classify as retryable, so "
        f"every retry hits the same expiry.  Use a long-lived credential or "
        f"a system account for this feed, lower its size class, or raise the "
        f"expected TTL if the tokens really do last longer."
    )


def settings_from_config() -> SparkK8sSettings:
    """Resolve ``SparkK8sSettings`` from the declared ``spark_k8s`` config
    section + ``feed_generation.webhook_secret`` (the HMAC secret is shared
    with the webhook receiver — one secret, both directions)."""
    from core.config import spark_k8s as _sk
    from core.config import get as _get
    return SparkK8sSettings(
        namespace=_sk.namespace,
        submit_mode=_sk.submit_mode,
        master_url=_sk.master_url,
        image_pull_secrets=tuple(_sk.image_pull_secrets),
        # 2026-10-17 -- was never passed: a custom image could not declare its
        # jars, so the preflight always assumed the pinned five
        image_driver_classes=tuple(_sk.image_driver_classes),
        driver_run_as_user=_sk.driver_run_as_user,
        image=_sk.image,
        image_pull_policy=_sk.image_pull_policy,
        service_account=_sk.service_account,
        callback_base_url=_sk.callback_base_url,
        progress_interval_seconds=_sk.progress_interval_seconds,
        webhook_secret=str(_get("feed_generation", "webhook_secret", "") or ""),
        creds_via_secret=_sk.creds_via_secret,
        driver_cores=_sk.driver_cores,
        driver_memory=_sk.driver_memory,
        executor_cores=_sk.executor_cores,
        executor_memory=_sk.executor_memory,
        num_executors=_sk.num_executors,
        spark_conf=_sk.spark_conf,
        max_retries=_sk.max_retries,
        retry_backoff_seconds=_sk.retry_backoff_seconds,
        job_timeout_seconds=_sk.job_timeout_seconds,
        size_classes=_sk.size_classes,
        pending_timeout_seconds=_sk.pending_timeout_seconds,
        session_token_expected_ttl_seconds=(
            _sk.session_token_expected_ttl_seconds),
        webhook_grace_seconds=_sk.webhook_grace_seconds,
        adoption_grace_seconds=_sk.adoption_grace_seconds,
        reconcile_interval_seconds=_sk.reconcile_interval_seconds,
        completed_cr_ttl_seconds=_sk.completed_cr_ttl_seconds,
        status_poll_interval_seconds=_sk.status_poll_interval_seconds,
        poll_timeout_seconds=_sk.poll_timeout_seconds,
        preupgrade_sweep_enabled=_sk.preupgrade_sweep_enabled,
    )


# ── The ONE builder ──────────────────────────────────────────────────────

# ── The conf travels OUT of argv (2026-10-11) ─────────────────────────────
#
# Found live on the owner's real case (tetb_real_e2e_proof --backend
# spark_k8s: two 460-column SQLs per side plus token bindings): EVERY run
# failed at submit -- "fork/exec /opt/spark/bin/spark-submit: argument list
# too long".  The whole credential-redacted conf rode in ``spec.arguments``
# as ``--feed-config <json>``, and Linux caps one argv string at
# MAX_ARG_STRLEN = 131072 bytes (the whole argv + env at ARG_MAX).  The
# same conf ALSO rode as ONE env string (``FEED_CONFIG_JSON`` from a
# secretKeyRef), which the driver container's own exec caps the same way
# -- it would have been the next failure.
#
# Now the Secret's ``FEED_CONFIG_JSON`` key (unchanged -- the reconciler's
# retry reads the prior attempt's conf from it) is MOUNTED as a file in the
# driver, in both shapes; argv carries a small REFERENCE (path, sha256,
# byte count, identity) the job verifies before it trusts the file; and
# two budgets are DECLARED and enforced at build: the conf must fit a
# Secret (etcd caps one at 1 MiB) and argv must stay far below the kernel.

#: Where the driver reads its conf: the Secret key as a file.
FEED_CONFIG_MOUNT_DIR = "/etc/querystudio/feed"
FEED_CONFIG_FILE_NAME = "feed_config.json"
FEED_CONFIG_FILE_PATH = f"{FEED_CONFIG_MOUNT_DIR}/{FEED_CONFIG_FILE_NAME}"
FEED_CONFIG_VOLUME = "qs-feed-config"
#: The Secret data key the conf lives under (the retry reads it back).
FEED_CONFIG_SECRET_KEY = "FEED_CONFIG_JSON"
#: The env var that tells the job where the file is.
FEED_CONFIG_FILE_ENV = "FEED_CONFIG_FILE"
#: A Secret's data may not exceed 1 MiB; the conf leaves room for the
#: webhook secret and base64 (4/3).
FEED_CONF_MAX_BYTES = 700_000
#: argv budgets: one string far below MAX_ARG_STRLEN (131072), the whole
#: argument list far below ARG_MAX.  A reference is ~300 bytes.
ARG_STRLEN_BUDGET = 32_768
ARGV_BUDGET_BYTES = 65_536


class SparkK8sConfTooLarge(ValueError):
    """The resolved conf cannot travel: it does not fit the transport that
    carries it.  A declared refusal BEFORE anything is created (a 422 at
    /spark-submit, a failed row in the engine), never a submit that dies
    with the kernel's E2BIG."""


def feed_config_reference(feed_conf_dict: dict, conf_json: str) -> str:
    """The small ``--feed-config`` argument: WHERE the conf is and HOW to
    know it is the right one.  Carries identity for the operator reading
    ``kubectl describe`` and nothing a credential could hide in."""
    import hashlib
    ref = {
        "feed_config_file": FEED_CONFIG_FILE_PATH,
        "sha256": hashlib.sha256(conf_json.encode("utf-8")).hexdigest(),
        "bytes": len(conf_json.encode("utf-8")),
        "feed_config_id": (feed_conf_dict or {}).get("feed_config_id"),
        "feed_name": (feed_conf_dict or {}).get("feed_name"),
        "execution_id": (feed_conf_dict or {}).get("execution_id"),
        "plan_version": ((feed_conf_dict or {}).get("source_plan") or {}).get("plan_version"),
    }
    return json.dumps(ref, separators=(",", ":"), default=str)


def argv_bytes(args) -> int:
    """What the kernel counts: every string's UTF-8 bytes plus its NUL."""
    return sum(len(str(a).encode("utf-8")) + 1 for a in (args or ()))


def assert_argv_within_budget(args, *, where: str) -> None:
    """Refuse an argument list the kernel might refuse (E2BIG) -- at build,
    where the message can name the cause, never at spark-submit."""
    total = argv_bytes(args)
    longest = max((len(str(a).encode("utf-8")) for a in (args or ())), default=0)
    if longest > ARG_STRLEN_BUDGET or total > ARGV_BUDGET_BYTES:
        raise SparkK8sConfTooLarge(
            f"{where}: the argument list is {total} bytes (longest argument "
            f"{longest} bytes); the budget is {ARGV_BUDGET_BYTES} total / "
            f"{ARG_STRLEN_BUDGET} per argument (Linux refuses one string over "
            f"131072 with 'argument list too long').  The conf must travel in "
            f"the per-run Secret (creds_via_secret) and reach the driver as a "
            f"file, never on argv.")


def build_spark_application_spec(
    feed_conf_dict: dict,
    execution_id: str,
    settings: SparkK8sSettings,
    *,
    secret_sink: Optional[dict] = None,
    attempt: int = 0,
    backend_config: Optional[dict] = None,
) -> dict:
    """Shape the SparkApplication CR body for one execution attempt.

    ``feed_conf_dict`` is the fully-resolved ``--feed-config`` payload
    (see ``feed_conf.build_feed_conf``).  ``backend_config`` carries the
    per-feed ``spark_*`` sizing overrides (falls back to ``settings``).

    ``secret_sink`` (E-cred): when a dict is supplied, credentials are
    moved OUT of the ``--feed-config`` CLI argument into ``secret_sink``
    (the caller mounts it as a K8s secret env var) and the driver env is
    wired to read ``FEED_CONFIG_JSON``.  ``None`` embeds the full config
    (incl. credentials) in the argument — legacy behaviour.
    """
    _feed_name = (feed_conf_dict.get("feed_name")
                  if isinstance(feed_conf_dict, dict) else None)
    cr_name = cr_name_for(execution_id, attempt, _feed_name)
    secret_name = secret_name_for(execution_id, attempt, _feed_name)

    driver_env: list = []
    driver_volume_mounts: list = []
    volumes: list = []
    if secret_sink is not None:
        conf_json = json.dumps(feed_conf_dict)
        conf_bytes = len(conf_json.encode("utf-8"))
        if conf_bytes > FEED_CONF_MAX_BYTES:
            raise SparkK8sConfTooLarge(
                f"the resolved feed conf for {execution_id} is {conf_bytes} bytes; "
                f"a Kubernetes Secret holds at most {FEED_CONF_MAX_BYTES} bytes of "
                f"conf (etcd caps a Secret at 1 MiB).  The plan's SQL text and "
                f"token bindings are what grow -- shorten the queries or split the "
                f"feed; the run was NOT submitted.")
        secret_sink[FEED_CONFIG_SECRET_KEY] = conf_json
        # argv carries a REFERENCE to the mounted file, never the conf.
        feed_conf = feed_config_reference(feed_conf_dict, conf_json)
        driver_env.append({"name": FEED_CONFIG_FILE_ENV,
                           "value": FEED_CONFIG_FILE_PATH})
        driver_volume_mounts.append({"name": FEED_CONFIG_VOLUME,
                                     "mountPath": FEED_CONFIG_MOUNT_DIR,
                                     "readOnly": True})
        volumes.append({"name": FEED_CONFIG_VOLUME,
                        "secret": {"secretName": secret_name,
                                   "items": [{"key": FEED_CONFIG_SECRET_KEY,
                                              "path": FEED_CONFIG_FILE_NAME}]}})
    else:
        # legacy: no Secret -- the whole conf, credentials included, on argv.
        # Bounded by the same budget: an oversize conf is refused here with
        # the remedy named, not by spark-submit with E2BIG.
        feed_conf = json.dumps(feed_conf_dict)

    # feed-seam — hand the Spark job the HMAC secret it must use to SIGN its
    # /api/webhooks/feed-complete callback.  Without it the server rejects
    # the callback (503/401) and completion is driven by the reconciler's
    # webhook-missing path instead.  Secret mode keeps it off the CLI.
    if settings.webhook_secret:
        if secret_sink is not None:
            secret_sink["FEED_WEBHOOK_SECRET"] = settings.webhook_secret
            driver_env.append({
                "name": "FEED_WEBHOOK_SECRET",
                "valueFrom": {
                    "secretKeyRef": {"name": secret_name, "key": "FEED_WEBHOOK_SECRET"},
                },
            })
        else:
            driver_env.append({
                "name": "FEED_WEBHOOK_SECRET", "value": settings.webhook_secret,
            })

    bc = backend_config or {}
    # FR-ARCH-03 — 3-level sizing precedence (feed override → size class
    # → deployment default), same shape as the job timeout.  Before this
    # the size class was consulted for the timeout ONLY and every class
    # produced identical pods.
    _sizing = resolve_sizing(bc, settings)
    # 2026-10-13 -- never a pod too small for what it reads: a JDBC driver
    # that buffers rows per connection needs heap by the read's WIDTH
    # (core/spark_k8s/jdbc_queue_floor.py).
    from core.spark_k8s.jdbc_queue_floor import apply_floor as _jdbc_floor
    _sizing = _jdbc_floor(_sizing, feed_conf_dict)
    driver_memory = _sizing["driver_memory"]
    executor_memory = _sizing["executor_memory"]
    executor_cores = _sizing["executor_cores"]
    num_executors = _sizing["num_executors"]
    extra_conf = bc.get("spark_extra_conf") or {}

    spark_conf = {
        "spark.sql.parquet.compression.codec": "snappy",
        "spark.hadoop.fs.s3a.impl": "org.apache.hadoop.fs.s3a.S3AFileSystem",
        # Executors carry the feed name too (see executor_pod_name_prefix).
        "spark.kubernetes.executor.podNamePrefix":
            executor_pod_name_prefix(execution_id, attempt, _feed_name),
        # Spark's JVM logging at WARN from the image's file (see
        # LOG4J2_IMAGE_PATH); an operator's spark_k8s.spark_conf may
        # replace either option below, deliberately.
        "spark.driver.extraJavaOptions": LOG4J2_JAVA_OPTION,
        "spark.executor.extraJavaOptions": LOG4J2_JAVA_OPTION,
        # an OpenShift-assigned UID has no account name (see
        # RESTRICTED_CONTAINER_SECURITY)
        "spark.kubernetes.driverEnv.SPARK_USER": SPARK_USER_NAME,
        "spark.kubernetes.driverEnv.HADOOP_USER_NAME": SPARK_USER_NAME,
        "spark.executorEnv.SPARK_USER": SPARK_USER_NAME,
        "spark.executorEnv.HADOOP_USER_NAME": SPARK_USER_NAME,
        # ...and a HOME that exists (found live under an assigned UID: the
        # entrypoint wrote the account as "anonymous uid" and Spark refused
        # to start, "basedir must be absolute: -anonymous uid}/.ivy2/local")
        **{f"spark.kubernetes.driverEnv.{k}": v for k, v in ARBITRARY_UID_ENV.items()},
        **{f"spark.executorEnv.{k}": v for k, v in ARBITRARY_UID_ENV.items()},
        "spark.jars.ivy": IVY_DIR,
    }
    spark_conf.update(settings.spark_conf or {})
    # FR-SRC-02 (2026-09-02) — an Iceberg feed's session must be BORN with
    # the Iceberg extensions + catalog conf (spark.sql.extensions cannot
    # be set after session creation), so the CR carries them.  Derived
    # from the SAME resolved read config the job executes
    # (query_params.iceberg, built by feed_conf) — one source of truth,
    # no second grammar.  The jars these keys name are baked into the
    # pinned image (spark/Dockerfile), never a PVC.
    _ice_cfg = ((feed_conf_dict.get("query_params") or {}).get("iceberg")
                if isinstance(feed_conf_dict, dict) else None)
    if _ice_cfg:
        from core.spark_k8s.iceberg import iceberg_spark_conf
        spark_conf.update(iceberg_spark_conf(_ice_cfg))
    spark_conf.update(extra_conf)
    # 2026-10-14 -- and never too little memory OUTSIDE the heap for how wide
    # the read is (the 460-column render was OOM-killed at 1g on the rig)
    from core.spark_k8s.jdbc_queue_floor import apply_overhead_floor as _overhead_floor
    spark_conf = _overhead_floor(spark_conf, feed_conf_dict or {}, executor_cores, executor_memory)

    arguments = [
        "--feed-config", feed_conf,
        "--execution-id", execution_id,
        "--callback-url", settings.callback_url,
    ]
    assert_argv_within_budget(arguments, where=f"SparkApplication {cr_name}")

    return {
        "apiVersion": f"{SPARK_APP_GROUP}/{SPARK_APP_VERSION}",
        "kind": "SparkApplication",
        "metadata": {
            "name": cr_name,
            "namespace": settings.namespace,
            "labels": {
                MANAGED_BY_KEY: MANAGED_BY_VALUE,
                EXECUTION_ID_LABEL: _NAME_UNSAFE.sub(
                    "-", str(execution_id).lower())[:63],
                ATTEMPT_LABEL: str(int(attempt)),
            },
        },
        "spec": {
            "type": "Python",
            "pythonVersion": "3",
            "mode": "cluster",
            "image": settings.image,
            "imagePullPolicy": settings.image_pull_policy,
            "mainApplicationFile": "local:///opt/spark/jobs/generic_feed.py",
            "arguments": arguments,
            "sparkConf": spark_conf,
            "driver": {
                "cores": settings.driver_cores,
                "memory": driver_memory,
                "serviceAccount": settings.service_account,
                # E-cred: credentials arrive through the per-run Secret --
                # the conf as a MOUNTED file (2026-10-11), the webhook HMAC
                # as a secretKeyRef env -- never on the process command
                # line.  Absent when secret_sink is None and no webhook
                # secret is configured.
                **({"env": driver_env} if driver_env else {}),
                **({"volumeMounts": driver_volume_mounts}
                   if driver_volume_mounts else {}),
                "securityContext": dict(RESTRICTED_CONTAINER_SECURITY),
                "podSecurityContext": restricted_pod_security(settings),
            },
            "executor": {
                "cores": executor_cores,
                "instances": num_executors,
                "memory": executor_memory,
                "securityContext": dict(RESTRICTED_CONTAINER_SECURITY),
                "podSecurityContext": restricted_pod_security(settings),
            },
            **({"volumes": volumes} if volumes else {}),
        },
    }


# ── OpenShift "restricted-v2" / Pod Security "restricted" (2026-10-13) ──
# The owner deploys to OpenShift only once this is production-ready.  Every
# Spark pod this product creates -- driver AND executors, both submit
# shapes -- carries what the restricted policy demands, explicitly (an SCC
# would default some of it; Pod Security admission defaults nothing):
# non-root, no privilege escalation, every capability dropped, the runtime's
# seccomp profile.  The UID is left to OpenShift (the project's range)
# unless ``spark_k8s.driver_run_as_user`` declares one.  Under an assigned
# UID the JVM has no account name, and Hadoop's login fails ("invalid null
# input: name"), so the user NAME travels as SPARK_USER / HADOOP_USER_NAME.
RESTRICTED_CONTAINER_SECURITY = {
    "allowPrivilegeEscalation": False,
    "capabilities": {"drop": ["ALL"]},
    "runAsNonRoot": True,
    "seccompProfile": {"type": "RuntimeDefault"},
}
#: the account name the job runs as, whatever UID the platform assigns
SPARK_USER_NAME = "spark"
#: what an assigned UID needs besides the user name: the account name the
#: image entrypoint writes into /etc/passwd, and a writable HOME
ARBITRARY_UID_ENV = {"SPARK_USER_NAME": SPARK_USER_NAME, "HOME": "/tmp"}
#: Spark's dependency cache, never under a HOME an assigned UID may not have
IVY_DIR = "/tmp/.ivy2"
#: executors of a DRIVER-POD submission are created by Spark itself from
#: this template, baked into the job image (spark/pod-templates/)
EXECUTOR_POD_TEMPLATE_PATH = "/opt/spark/pod-templates/executor-restricted.yaml"


def restricted_pod_security(settings) -> dict:
    """The pod-level securityContext of every Spark pod."""
    out = {"runAsNonRoot": True, "seccompProfile": {"type": "RuntimeDefault"}}
    if str(getattr(settings, "driver_run_as_user", "") or "").strip():
        out["runAsUser"] = int(settings.driver_run_as_user)
    return out


SUBMIT_MODE_CR = "spark_application"
SUBMIT_MODE_POD = "driver_pod"
#: The two SHAPES a workload can take.  Everything that builds, creates,
#: reads, lists or deletes a workload takes one of THESE -- never "auto".
SUBMIT_MODES = (SUBMIT_MODE_CR, SUBMIT_MODE_POD)
#: 2026-09-14 -- ``auto`` is a RESOLVER, not a third shape: at submit the
#: availability ladder probes whether the SparkApplication CRD is served
#: and the run takes the CR shape when it is, the driver-Pod shape when it
#: is NOT (404), and is REFUSED when that cannot be told (403, unreachable).
#: The resolved shape is then STORED on the execution row and every later
#: verb (status, cancel, reconcile, reap) reads it from there -- a run
#: submitted as a CR stays a CR even if the operator is uninstalled
#: mid-flight.  Resolve once, gate it, store it.
SUBMIT_MODE_AUTO = "auto"
KNOWN_SUBMIT_MODES = SUBMIT_MODES + (SUBMIT_MODE_AUTO,)


def assert_known_submit_mode(mode: str) -> str:
    """REFUSE an unknown submit_mode rather than defaulting to one.

    Silently falling back to the CR path on a cluster with no operator
    turns a typo into "the heavy lane is unavailable" with a reason that
    names the wrong cause.  ``auto`` is accepted here (it is a declared
    value) but is never a SHAPE -- see :func:`assert_concrete_submit_mode`
    for the seams that must hold one.
    """
    m = str(mode or "").strip().lower()
    if m not in KNOWN_SUBMIT_MODES:
        raise ValueError(
            "spark_k8s.submit_mode=%r is not one of %s.  %r posts a "
            "SparkApplication CR (needs spark-operator); %r posts the "
            "driver pod directly (needs no operator); %r probes the "
            "cluster at submit and takes whichever it can."
            % (mode, KNOWN_SUBMIT_MODES, SUBMIT_MODE_CR, SUBMIT_MODE_POD,
               SUBMIT_MODE_AUTO))
    return m


def assert_concrete_submit_mode(mode: str) -> str:
    """A workload SHAPE: one of ``SUBMIT_MODES``.  ``auto`` reaching a
    build/create/get/list/delete seam is a programming error (the
    resolver was skipped), and it is refused as one -- never treated as
    the CR mode by default."""
    m = str(mode or "").strip().lower()
    if m not in SUBMIT_MODES:
        raise ValueError(
            "workload shape must be one of %s; got %r.  'auto' is resolved "
            "at submit (runner.resolve_submit_mode) and stored on the "
            "execution row -- a caller holding 'auto' here skipped that."
            % (SUBMIT_MODES, mode))
    return m


def spark_submit_conf_args(spark_conf: dict) -> list:
    """Render an ALREADY-MERGED conf dict into ``--conf k=v`` arguments.

    Deliberately merges nothing itself: sizing, Iceberg conf and per-feed
    overrides are resolved once by the CR builder, and a second merge
    here would be a twin free to disagree with it.
    """
    out = []
    for key in sorted(spark_conf or {}):
        out.extend(["--conf", "%s=%s" % (key, spark_conf[key])])
    return out


def build_driver_pod_spec(
    feed_conf_dict: dict,
    execution_id: str,
    settings: SparkK8sSettings,
    *,
    secret_sink: Optional[dict] = None,
    attempt: int = 0,
    backend_config: Optional[dict] = None,
) -> dict:
    """The DRIVER POD body -- same contract as
    :func:`build_spark_application_spec`, and no operator required.

    ``spark-submit --deploy-mode cluster`` creates a driver pod and
    exits; the DRIVER then creates its own executors through Spark's
    Kubernetes cluster manager.  spark-operator is a convenience wrapper
    that produces that same pod from a CR.  So this posts the pod.

    Built ON the CR builder rather than beside it, deliberately: the
    arguments, the merged sparkConf, the env and the sizing are resolved
    ONCE and rendered twice.  Two resolutions would be a twin, which is
    this repository's dominant defect class.  The name, the labels and
    the credential Secret are identical, so the idempotency key, the
    ``-r{n}`` attempt parsing, every list/reap selector and the
    Secret-before-workload ordering all keep working untouched.

    Two conf entries are load-bearing rather than cosmetic:

    * ``spark.kubernetes.driver.pod.name`` -- makes Spark stamp
      ``ownerReferences`` on every executor it creates, so deleting the
      driver garbage-collects them.  Cancel and the reconciler's reap
      then work with NO new cleanup code; without it a cancelled run
      leaks executors nothing owns.
    * ``spark.driver.host`` from the pod's own IP -- executors dial the
      driver back.  Without it the driver advertises an address they
      cannot reach and the job hangs until its timeout.
    """
    cr = build_spark_application_spec(
        feed_conf_dict, execution_id, settings,
        secret_sink=secret_sink, attempt=attempt,
        backend_config=backend_config)
    pod_name = cr["metadata"]["name"]
    spec = cr["spec"]
    spark_conf = dict(spec.get("sparkConf") or {})
    driver = spec.get("driver") or {}
    executor = spec.get("executor") or {}

    spark_conf.update({
        "spark.master": settings.master_url,
        # client mode INSIDE the driver pod: the pod IS the driver, so
        # there is nothing left to submit anywhere else.
        "spark.submit.deployMode": "client",
        "spark.kubernetes.namespace": settings.namespace,
        "spark.kubernetes.container.image": settings.image,
        "spark.kubernetes.container.image.pullPolicy":
            settings.image_pull_policy,
        "spark.kubernetes.authenticate.driver.serviceAccountName":
            settings.service_account,
        "spark.kubernetes.driver.pod.name": pod_name,
        # REVIEWED 2026-09-13 (ruff S104).  This is the value Spark-on-K8s
        # documents and requires: the driver must LISTEN on all interfaces
        # inside its own pod or the executors cannot reach it.  The address
        # executors actually dial is spark.driver.host on the next line,
        # which resolves to the pod IP -- so "all interfaces" here means
        # "the pod's interfaces", not the cluster.
        "spark.driver.bindAddress": "0.0.0.0",
        "spark.driver.host": "$(SPARK_DRIVER_BIND_ADDRESS)",
        "spark.driver.port": "7078",
        "spark.driver.blockManager.port": "7079",
        "spark.driver.cores": str(driver.get("cores", settings.driver_cores)),
        "spark.driver.memory": str(driver.get("memory",
                                              settings.driver_memory)),
        "spark.executor.instances": str(
            executor.get("instances", settings.num_executors)),
        "spark.executor.cores": str(
            executor.get("cores", settings.executor_cores)),
        "spark.executor.memory": str(
            executor.get("memory", settings.executor_memory)),
    })
    if settings.image_pull_secrets:
        spark_conf["spark.kubernetes.container.image.pullSecrets"] = ",".join(
            settings.image_pull_secrets)

    # executors are created by Spark from the image's restricted template
    spark_conf.setdefault("spark.kubernetes.executor.podTemplateFile",
                          EXECUTOR_POD_TEMPLATE_PATH)
    spark_conf.setdefault("spark.kubernetes.executor.podTemplateContainerName",
                          "spark-kubernetes-executor")

    env = list(driver.get("env") or [])
    env.append({"name": "SPARK_DRIVER_BIND_ADDRESS",
                "valueFrom": {"fieldRef": {"fieldPath": "status.podIP"}}})
    for _k, _v in (("SPARK_USER", SPARK_USER_NAME), ("HADOOP_USER_NAME", SPARK_USER_NAME),
                   *ARBITRARY_UID_ENV.items()):
        if not any(e.get("name") == _k for e in env):
            env.append({"name": _k, "value": _v})

    args = ["driver"]
    args.extend(spark_submit_conf_args(spark_conf))
    args.append(spec.get("mainApplicationFile",
                         "local:///opt/spark/jobs/generic_feed.py"))
    args.extend(str(a) for a in (spec.get("arguments") or []))
    # The pod's args ARE the exec'd command line (no operator in between).
    assert_argv_within_budget(args, where=f"driver pod {pod_name}")

    container = {
        "name": "spark-kubernetes-driver",
        "image": settings.image,
        "imagePullPolicy": settings.image_pull_policy,
        "args": args,
        "env": env,
        "ports": [{"containerPort": 7078, "name": "driver-rpc"},
                  {"containerPort": 7079, "name": "block-manager"}],
        "securityContext": dict(RESTRICTED_CONTAINER_SECURITY),
    }
    # The conf's Secret-as-file mount, the SAME declaration the CR carries
    # (2026-10-11) -- rendered into the pod's own volume vocabulary.
    if driver.get("volumeMounts"):
        container["volumeMounts"] = [dict(m) for m in driver["volumeMounts"]]
    pod_spec = {
        "serviceAccountName": settings.service_account,
        # Spark supervises its own job.  A kubelet restart would re-run a
        # COMPLETED feed and re-deliver it to the counterparty.
        "restartPolicy": "Never",
        "containers": [container],
    }
    if spec.get("volumes"):
        pod_spec["volumes"] = [dict(v) for v in spec["volumes"]]
    if settings.image_pull_secrets:
        pod_spec["imagePullSecrets"] = [
            {"name": n} for n in settings.image_pull_secrets]
    # runAsUser only when DECLARED (restricted_pod_security): unset lets the
    # OpenShift SCC assign a UID from the project's range; a UID outside it
    # is rejected at admission, and this repo's own charts disagree (185 vs
    # 45646345), so guessing would be worse than saying nothing.
    pod_spec["securityContext"] = restricted_pod_security(settings)

    return {
        "apiVersion": "v1",
        "kind": "Pod",
        "metadata": {
            "name": pod_name,
            "namespace": settings.namespace,
            # IDENTICAL to the CR's labels: every selector, reaper and
            # adoption path keys off these and must not learn a second
            # vocabulary.
            "labels": dict(cr["metadata"]["labels"]),
        },
        "spec": pod_spec,
    }


def secret_body_for(execution_id: str, secret_sink: dict, settings: SparkK8sSettings,
                    *, attempt: int = 0, feed_name=None) -> dict:
    """Plain-dict V1Secret body (labelled, per-attempt) for the runner to
    create BEFORE the CR.  Dict form (not the typed kubernetes model) so the
    fake API in tests handles byte-identical input."""
    return {
        "apiVersion": "v1",
        "kind": "Secret",
        "metadata": {
            "name": secret_name_for(execution_id, attempt, feed_name),
            "namespace": settings.namespace,
            "labels": {
                MANAGED_BY_KEY: MANAGED_BY_VALUE,
                EXECUTION_ID_LABEL: _NAME_UNSAFE.sub(
                    "-", str(execution_id).lower())[:63],
                ATTEMPT_LABEL: str(int(attempt)),
            },
        },
        "type": "Opaque",
        "stringData": dict(secret_sink),
    }
