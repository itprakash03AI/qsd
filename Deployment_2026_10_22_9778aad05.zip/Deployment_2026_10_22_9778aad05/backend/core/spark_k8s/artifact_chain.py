"""The heavy lane's artifact chain — BRD 2026-09-02 §10.4.

Until now the ``spark_k8s`` branch marked a run ``completed`` straight
after execution: no control file, no checksum, no counterparty filename,
no row-count check.  The output was Spark part-files at
``s3a://…/{execution_id}/part-00000-*`` — unnamed, uncertified,
undeliverable.

This module is the QueryStudio-side half of the fix (the job-side half is
``generic_feed.py``'s manifest write).  The Spark job WRITES a
``manifest.json`` (PartsManifest schema v1, ``status="building"``) next
to its parts; QueryStudio — from the completion webhook or the reconciler
fallback — then:

1. **loads** the job's manifest (:func:`load_job_manifest`),
2. **certifies** it against an independent listing of what is actually in
   the store (:func:`certify_job_manifest`) — every part present, byte
   counts matching, no EXTRA data file the manifest does not name (the
   2026-08-22 lesson: partial enumeration + SUCCESS status is silent data
   loss), and the row total reconciled against the job-reported count,
3. **prepares** the deliverable (:func:`prepare_artifact_chain`): the
   counterparty filename through the real renderer, then the FIXED engine
   order ``package -> compress -> encrypt -> checksum``
   (``core.feed.delivery_hops.plan_artifact_steps`` — never a second
   opinion), the checksum taken over the bytes that are actually SENT
   (FR-ART-02), the sidecar, and the control file (§10.4: produced by a
   LATER STEP over the certified manifest, not inside the job).

What this module deliberately does NOT do:

* **deliver** — delivery is the hop runner's act over a certified
  manifest (H1 / foundation M).  Nothing here touches a counterparty,
  in either ``pod_side_delivery`` mode.

Encryption (FR-ART-06 / FR-SEC-08, 2026-09-03): the encrypt step is
REAL now — ``core.feed.pgp`` is the single chokepoint, and the checksum
still runs LAST so it attests the ENCRYPTED bytes the counterparty
receives.  On a deployment with no PGP backend the step raises a STATED
refusal naming what is missing (never a silent plaintext fallback), and
``delivery_hops`` independently refuses to hand a plaintext artifact to
any transport under a pgp contract.
"""
from __future__ import annotations

import logging
import tarfile
import zipfile
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

# _new_hasher is checksum.py's single FIPS-safe constructor chokepoint
# (md5/sha1 built with usedforsecurity=False — FR-ART-03).  Imported
# deliberately rather than re-spelling the form here: two spellings of
# "FIPS-safe" is how one of them silently isn't.
from core.feed.checksum import (
    _new_hasher,
    compute_file_checksum,
    normalise_algorithm,
)
from core.feed.compression import CompressionFormat, CompressionWriter
from core.feed.control_file import ControlFileRecord, ControlFileWriter
from core.feed.delivery_hops import (
    checksum_sidecar_line,
    plan_artifact_steps,
)
from core.feed.parts_manifest import (
    MANIFEST_NAME,
    PARTIAL_MANIFEST_NAME,
    PartsManifest,
)

logger = logging.getLogger(__name__)


class SparkArtifactError(ValueError):
    """The heavy lane's artifact chain refusing to certify or prepare.

    ``stage`` names where it refused (load | certify | prepare) so the
    operator knows whether the JOB's output is suspect or the CHAIN's
    input was."""

    def __init__(self, stage: str, message: str):
        self.stage = stage
        super().__init__(f"[{stage}] {message}")


# ── locating the output ───────────────────────────────────────────────────

def parse_output_path(output_path: str) -> tuple[str, str, str]:
    """``("s3", bucket, prefix)`` for s3/s3a URIs, ``("local", "", path)``
    for anything else.  Oracle/SFTP pseudo-URIs are REFUSED — those runs
    delivered inside the pod and have no artifact store to certify."""
    p = str(output_path or "")
    if p.startswith(("s3a://", "s3://")):
        rest = p.split("://", 1)[1]
        bucket, _, prefix = rest.partition("/")
        if not bucket:
            raise SparkArtifactError(
                "load", f"output path {output_path!r} has no bucket")
        return "s3", bucket, prefix.rstrip("/")
    if p.startswith(("oracle://", "sftp://")):
        raise SparkArtifactError(
            "load",
            f"output {output_path!r} is a counterparty destination, not an "
            f"artifact store — a run that delivered inside the pod has no "
            f"part files to certify (legacy deliver_in_job mode)")
    if not p:
        raise SparkArtifactError("load", "run has no output path")
    return "local", "", p


_EXCLUDED_NAMES = (MANIFEST_NAME, PARTIAL_MANIFEST_NAME)


def _is_data_file(name: str) -> bool:
    base = name.rsplit("/", 1)[-1]
    return (bool(base) and not base.startswith((".", "_"))
            and base not in _EXCLUDED_NAMES
            and not base.endswith(".crc"))


def list_output_parts(output_path: str, *,
                      s3_client=None) -> dict[str, int]:
    """Independent listing of the DATA files in the output store:
    ``{name: bytes}``.  Spark bookkeeping files (``_SUCCESS``, dotfiles,
    ``.crc``) and the manifest itself are excluded — they are not parts."""
    kind, bucket, prefix = parse_output_path(output_path)
    out: dict[str, int] = {}
    if kind == "s3":
        if s3_client is None:
            raise SparkArtifactError(
                "load", "listing an s3 output requires an s3_client")
        token = None
        while True:
            kwargs = {"Bucket": bucket, "Prefix": prefix + "/"}
            if token:
                kwargs["ContinuationToken"] = token
            resp = s3_client.list_objects_v2(**kwargs)
            for obj in resp.get("Contents") or []:
                name = obj["Key"].rsplit("/", 1)[-1]
                if _is_data_file(name):
                    out[name] = int(obj["Size"])
            if not resp.get("IsTruncated"):
                break
            token = resp.get("NextContinuationToken")
        return out
    root = Path(prefix)
    if not root.is_dir():
        raise SparkArtifactError(
            "load", f"local output dir {root} does not exist")
    for child in root.iterdir():
        if child.is_file() and _is_data_file(child.name):
            out[child.name] = child.stat().st_size
    return out


def load_job_manifest(output_path: str, *,
                      s3_client=None) -> PartsManifest:
    """Load the manifest the Spark job wrote next to its parts.

    ABSENT is a refusal, not a degrade: on this lane the manifest is the
    unit of certification (§10.4) — a run without one cannot be
    certified, so it must not be marked complete."""
    kind, bucket, prefix = parse_output_path(output_path)
    if kind == "s3":
        if s3_client is None:
            raise SparkArtifactError(
                "load", "loading an s3 manifest requires an s3_client")
        key = f"{prefix}/{MANIFEST_NAME}"
        try:
            body = s3_client.get_object(Bucket=bucket, Key=key)["Body"].read()
            text = body.decode("utf-8")
        except Exception as exc:
            raise SparkArtifactError(
                "load",
                f"no readable {MANIFEST_NAME} at s3://{bucket}/{key} "
                f"({type(exc).__name__}: {exc}) — the Spark job writes one "
                f"next to its parts; a heavy-lane run without a manifest "
                f"cannot be certified (§10.4)") from exc
    else:
        target = Path(prefix) / MANIFEST_NAME
        try:
            text = target.read_text(encoding="utf-8")
        except OSError as exc:
            raise SparkArtifactError(
                "load",
                f"no readable {MANIFEST_NAME} at {target} ({exc}) — the "
                f"Spark job writes one next to its parts; a heavy-lane run "
                f"without a manifest cannot be certified (§10.4)") from exc
    import json as _json
    try:
        return PartsManifest.from_dict(_json.loads(text))
    except Exception as exc:
        raise SparkArtifactError(
            "load",
            f"manifest at {output_path} is not a valid PartsManifest "
            f"({type(exc).__name__}: {exc})") from exc


# ── certification ─────────────────────────────────────────────────────────

def certify_job_manifest(manifest: PartsManifest,
                         listing: dict[str, int], *,
                         reported_rows: int | None = None
                         ) -> PartsManifest:
    """Certify the job's manifest against an INDEPENDENT listing.

    Every check is a refusal, and all failures are reported at once:

    * a part the manifest names that the listing lacks (lost file);
    * a byte-count mismatch (torn or replaced file);
    * a DATA file present in the store that the manifest does not name
      — the partial-enumeration tripwire.  A mutation that leaks an
      unmanifested file into the store must fail HERE, not pass because
      downstream never looks (2026-08-21: a leak passed all 8 tests
      until a tripwire row was added);
    * ``reported_rows`` (the job's callback metric) disagreeing with the
      manifest total — a count that does not reconcile is not a count.

    On success the manifest's status becomes ``"complete"`` — the state
    ``DeliveryHopRunner.require_certified`` demands — and the SAME object
    is returned."""
    problems: list[str] = []
    seen = set()
    for p in manifest.parts:
        seen.add(p.name)
        actual = listing.get(p.name)
        if actual is None:
            problems.append(
                f"part {p.name!r} ({p.rows} rows, {p.bytes} bytes) is in "
                f"the manifest but NOT in the store")
        elif int(actual) != int(p.bytes):
            problems.append(
                f"part {p.name!r}: manifest says {p.bytes} bytes, store "
                f"has {actual}")
    for name in sorted(listing):
        if name not in seen:
            problems.append(
                f"store holds data file {name!r} that the manifest does "
                f"not name — partial enumeration, refusing to certify")
    if reported_rows is not None \
            and int(reported_rows) != int(manifest.total_rows):
        problems.append(
            f"job callback reported {reported_rows} rows but the manifest "
            f"totals {manifest.total_rows} — a count that does not "
            f"reconcile is not a count")
    if not manifest.parts and (reported_rows or 0) > 0:
        problems.append(
            f"manifest names ZERO parts for a run that reported "
            f"{reported_rows} rows")
    if problems:
        bullets = "\n".join(f"  * {m}" for m in problems)
        raise SparkArtifactError(
            "certify",
            f"refusing to certify manifest "
            f"{manifest.version()} (build {manifest.build_id!r}):\n"
            f"{bullets}")
    manifest.status = "complete"
    return manifest


# ── the counterparty filename ─────────────────────────────────────────────

_EXT_MAP = {"csv": "csv", "parquet": "parquet", "json": "jsonl",
            "excel": "xlsx"}


def counterparty_filename(feed_config: dict, *, business_date=None,
                          run_id=None) -> str:
    """The contract filename, through the SAME renderer chokepoint the
    native lane uses (``core.feed.pipeline.render_filename_for_feed``:
    enterprise ``${FUNC()}`` tokens + legacy ``{name}/{date}/{ext}``) —
    never the Spark job's own token expander, which exists only for the
    legacy deliver-in-pod path."""
    from core.feed.pipeline import render_filename_for_feed
    template = (feed_config.get("output_filename_template")
                or "{name}_{date}.{ext}")
    fmt = str(feed_config.get("output_format") or "csv").lower()
    ext = _EXT_MAP.get(fmt, fmt)
    return render_filename_for_feed(
        template, ext, feed_config,
        business_date=business_date, run_id=run_id)


# ── preparation (package -> compress -> encrypt -> checksum) ──────────────

@dataclass
class ArtifactChainResult:
    """What the hop runner delivers.  ``deliverables`` are the final
    file(s) — post packaging/compression — under their counterparty
    names; every checksum in ``checksums`` was computed over those exact
    bytes (FR-ART-02)."""
    deliverables: list[Path]
    filename: str
    steps: tuple[str, ...]
    manifest_version: str
    row_count: int
    byte_size: int
    checksum_algorithm: str = ""
    checksums: dict[str, str] = field(default_factory=dict)
    sidecar_paths: list[Path] = field(default_factory=list)
    control_file_path: Path | None = None


def _artifact_options(feed_config: dict) -> dict[str, Any]:
    """The four artifact axes, read from the feed's ``output_options`` —
    the same bag the authoring-time contract validator reads.  Only the
    axes travel; engine knobs stay behind."""
    o = dict(feed_config.get("output_options") or {})
    return {
        "packaging": str(o.get("packaging") or "none").lower(),
        "codec": str(o.get("codec") or o.get("compression")
                     or "none").lower(),
        "encryption": str(o.get("encryption") or "none").lower(),
        "pgp_recipient": o.get("pgp_recipient"),
        "pgp_public_key": o.get("pgp_public_key"),
        "checksum": (o.get("checksum_algorithm") or o.get("checksum")
                     or None),
        "checksum_scope": str(o.get("checksum_scope") or "part").lower(),
        "sidecar": str(o.get("sidecar") or "none").lower(),
        "digest_line": str(o.get("digest_line") or "coreutils").lower(),
        # Passed THROUGH so an author-declared order that disagrees with
        # the engine's is REFUSED by plan_artifact_steps (FR-ART-02) —
        # dropping it here would silently ignore a wrong declaration.
        "step_order": o.get("step_order"),
    }


def parts_are_parquet(manifest: PartsManifest) -> bool:
    """Did the job leave PARQUET parts rather than the final format?

    Self-describing from the part names, deliberately: it must hold for
    a job built before this existed (which writes the final format) and
    one built after (which writes parquet), with no version flag to keep
    in step.  A flag would be a second thing to get wrong.
    """
    parts = list(manifest.parts or ())
    return bool(parts) and all(
        str(p.name or "").lower().endswith(".parquet") for p in parts)


def _render_parts_to_contract_format(
        manifest: PartsManifest, feed_config: dict, workdir: Path,
        fetch_part: Callable, filename: str) -> list:
    """Materialise the parts locally and RENDER the deliverable once.

    This is the convergence the two-implementation problem needed.

    QueryStudio and the Spark job each used to produce the final file,
    so every formatting DECISION was made twice — and the two answers
    drifted three times in two days (delimiter, then seven dialect
    terms, then the filename), each time invisibly, because both lanes
    reported success.  Patching the terms one at a time does not
    converge; a fourth term is always one release away.

    The bytes ALREADY pass through this pod: ``fetch_part`` downloads
    every part here to package, checksum and deliver it.  So having
    Spark write the final format buys nothing on this path — the data
    comes back regardless — while costing a second implementation of
    every format decision.  Rendering here instead costs decode+encode,
    no extra I/O, and leaves exactly ONE renderer in the product:
    ``core.feed.renderers``, the same one the native lane uses.

    Spark keeps what only Spark can do: the distributed READ and
    TRANSFORM.  Note that its distributed WRITE was never the benefit it
    appears to be — a single-file counterparty deliverable is
    single-process by nature, and the job's own SFTP path already
    materialised the whole DataFrame onto the driver to produce one
    file.

    Also removes a real limitation: N parquet parts render into ONE
    file, so ``multipart_naming`` stops being forced on a feed whose
    counterparty simply wants one CSV.
    """
    parts_dir = workdir / "_parts"
    parts_dir.mkdir(parents=True, exist_ok=True)
    for part in manifest.parts:
        fetch_part(part, parts_dir / part.name)
    # The parts are LOCAL now -- the manifest written next to them must say
    # so.  It kept the store's location (s3) and URI, and the reader refuses
    # an s3-resident part ("materialize parts locally"): every webhook-side
    # render from an S3 artifact store failed here (found 2026-10-07 by the
    # lane conformance matrix; the only store that worked was a local one,
    # which on a cluster is pod-local and unreadable).
    from dataclasses import replace as _replace
    manifest.parts = [_replace(p, location="local", uri=None)
                      for p in manifest.parts]

    # The job writes ``schema_b64: ""`` -- it has a Spark schema, not an
    # Arrow one, and serialising across that boundary would put a second
    # schema authority in the system.  The reader NEEDS one
    # (iter_manifest_batches presents every batch in the manifest's
    # unified schema), so it is taken from the parts themselves, which
    # are parquet and therefore self-describing.
    #
    # Deriving it here rather than asking the job for it means this
    # works for ANY producer that leaves parquet parts, and there is no
    # second place for the schema to be wrong.
    if not manifest.schema_b64:
        import base64
        import pyarrow.parquet as _pq
        first = parts_dir / manifest.parts[0].name
        schema = _pq.ParquetFile(str(first)).schema_arrow
        manifest.schema_b64 = base64.b64encode(
            schema.serialize().to_pybytes()).decode("ascii")
        logger.info(
            "[spark_k8s.artifact] manifest carried no schema — read it "
            "from %s (%d column(s))", first.name, len(schema))
    # The renderer reads a parts DIRECTORY through the same seam the
    # native write-ladder uses (``open_parquet_source`` -> _PartsSource),
    # streaming one batch at a time — so a 160M-row feed is bounded by
    # the largest batch, not by the result.
    manifest.write(parts_dir)

    from core.feed.renderers import get_renderer
    fmt = str(feed_config.get("output_format") or "csv").strip().lower()
    options = dict(feed_config.get("output_options") or {})
    dest = workdir / filename
    renderer = get_renderer(fmt)
    rows = renderer.render(str(parts_dir), str(dest), options)
    if rows != manifest.total_rows:
        raise SparkArtifactError(
            "prepare",
            f"rendered {rows} rows from a manifest holding "
            f"{manifest.total_rows} — refusing to deliver a count that "
            f"does not reconcile")
    logger.info(
        "[spark_k8s.artifact] rendered %d rows from %d parquet part(s) "
        "into one %s deliverable — one renderer, both lanes",
        rows, len(manifest.parts), fmt)
    return [dest]


def _stage_parts(manifest: PartsManifest, feed_config: dict,
                 workdir: Path, fetch_part: Callable, filename: str
                 ) -> list[Path]:
    """Materialise the certified parts locally under their COUNTERPARTY
    names.  One part → the contract filename.  Many parts → the
    ``_NNN_of_NNNN`` convention (FR-ART-08), which requires
    ``multipart_naming`` to be declared — N unnamed parts under one
    filename is inexpressible and is refused, not guessed."""
    n = len(manifest.parts)
    if n == 0:
        raise SparkArtifactError(
            "prepare", "certified manifest has no parts to prepare")
    staged: list[Path] = []
    if n == 1:
        dest = workdir / filename
        fetch_part(manifest.parts[0], dest)
        staged.append(dest)
        return staged
    options = _artifact_options(feed_config)
    multipart_ok = bool(
        (feed_config.get("output_options") or {}).get("multipart_naming"))
    if options["packaging"] == "none" and not multipart_ok:
        raise SparkArtifactError(
            "prepare",
            f"{n} parts but packaging=none and multipart_naming is not "
            f"declared — {n} files cannot ship under the single name "
            f"{filename!r}.  Declare packaging (zip/tar) to merge them, "
            f"or multipart_naming for _NNN_of_{n:04d} names (FR-ART-08)")
    stem, dot, ext = filename.rpartition(".")
    if not dot:
        stem, ext = filename, ""
    width = max(3, len(str(n)))
    for i, part in enumerate(manifest.parts, start=1):
        part_name = f"{stem}_{i:0{width}d}_of_{n:0{width}d}"
        if ext:
            part_name += f".{ext}"
        dest = workdir / part_name
        fetch_part(part, dest)
        staged.append(dest)
    return staged


def _package(staged: list[Path], packaging: str, filename: str,
             workdir: Path) -> list[Path]:
    stem = filename.rsplit(".", 1)[0]
    if packaging == "zip":
        archive = workdir / f"{stem}.zip"
        with zipfile.ZipFile(archive, "w", zipfile.ZIP_STORED) as zf:
            for p in staged:
                zf.write(p, arcname=p.name)
    elif packaging == "tar":
        archive = workdir / f"{stem}.tar"
        with tarfile.open(archive, "w") as tf:
            for p in staged:
                tf.add(p, arcname=p.name)
    else:
        raise SparkArtifactError(
            "prepare", f"unknown packaging {packaging!r} (none|zip|tar)")
    for p in staged:
        try:
            p.unlink()
        except OSError:
            pass
    return [archive]


def _compress(staged: list[Path], codec: str) -> list[Path]:
    fmt = CompressionFormat.from_str(codec)
    suffix = CompressionWriter.suffix_for(fmt)
    writer = CompressionWriter()
    out: list[Path] = []
    for p in staged:
        if suffix and p.name.endswith(suffix):
            # The Spark job already wrote codec-compressed parts (E-L2).
            # The bytes are ALREADY in their sent form; compressing again
            # would ship a double-wrapped file under a single-suffix name.
            logger.info(
                "[spark_k8s.artifact] %s already carries %s — compress "
                "step is a pass-through", p.name, suffix)
            out.append(p)
            continue
        out.append(Path(writer.compress(p, fmt).output_path))
    return out


def _encrypt(staged: list[Path], options: dict) -> list[Path]:
    """FR-ART-06 / FR-SEC-08 — encrypt every staged file to the
    recipient key via the single ``core.feed.pgp`` chokepoint.  Runs
    BEFORE the checksum (fixed order), so the digest attests the
    encrypted bytes that are actually sent.

    Every failure here raises — there is no path from this function to
    an unencrypted deliverable.  A missing backend or missing key is a
    STATED refusal from ``core.feed.pgp`` itself (the single chokepoint
    — no second copy of those checks here, so the two cannot drift),
    re-raised with the chain's stage label: refusing loudly beats
    delivering plaintext under a contract that promised PGP."""
    from core.feed import pgp as _pgp
    key = str(options.get("pgp_public_key") or "")
    try:
        return [_pgp.encrypt_file(p, key) for p in staged]
    except (_pgp.PgpUnavailable, _pgp.PgpKeyError, RuntimeError) as exc:
        raise SparkArtifactError(
            "prepare",
            f"PGP encryption failed (FR-ART-06 — the run FAILS; the "
            f"plaintext is never delivered): {exc}") from exc


def _whole_scope_digest(staged: list[Path], algo: str,
                        chunk_size: int = 1 << 20) -> str:
    """FR-ART-04 — ONE digest over the concatenated bytes of every staged
    file, in delivery order.

    Two defects lived in the inline predecessor:

    * ``hashlib.new(algo)`` with no ``usedforsecurity=False`` — which
      raises for md5/sha1 on exactly the FIPS hosts FR-ART-03 exists
      for.  The FIPS-safe constructor is ``core.feed.checksum``'s single
      chokepoint (``_new_hasher``), reused here rather than re-spelled.
    * ``crc32`` was silently SKIPPED — a feed declaring
      ``checksum=crc32, checksum_scope=whole`` shipped with no "whole"
      entry at all, a declared contract quietly not delivered.  crc32 is
      a running value, so it concatenates naturally: it is COMPUTED now,
      in ``compute_file_checksum``'s 8-hex-char zero-padded format.
    """
    if algo == "crc32":
        import zlib
        val = 0
        for p in staged:
            with open(p, "rb") as fh:
                for chunk in iter(lambda: fh.read(chunk_size), b""):
                    val = zlib.crc32(chunk, val)
        return f"{val & 0xFFFFFFFF:08x}"
    h = _new_hasher(algo)
    for p in staged:
        with open(p, "rb") as fh:
            for chunk in iter(lambda: fh.read(chunk_size), b""):
                h.update(chunk)
    return h.hexdigest()


def prepare_artifact_chain(
    manifest: PartsManifest,
    feed_config: dict,
    *,
    workdir,
    fetch_part: Callable,
    business_date=None,
    run_id=None,
    control_format_spec=None,
) -> ArtifactChainResult:
    """Run the fixed pipeline over a CERTIFIED manifest.

    ``fetch_part(part_info, dest_path)`` materialises one part locally
    (S3 download or file copy) — the only I/O seam.  Steps come from
    ``plan_artifact_steps`` (the engine's fixed order, §10.2); the
    checksum is computed LAST, over the final bytes, because a digest of
    anything else describes bytes the counterparty never receives
    (FR-ART-02)."""
    if manifest.status != "complete":
        raise SparkArtifactError(
            "prepare",
            f"manifest status is {manifest.status!r}, not 'complete' — the "
            f"chain consumes a CERTIFIED manifest (run "
            f"certify_job_manifest first)")
    workdir = Path(workdir)
    workdir.mkdir(parents=True, exist_ok=True)
    options = _artifact_options(feed_config)

    if options["encryption"] not in ("", "none", "pgp"):
        raise SparkArtifactError(
            "prepare",
            f"unknown encryption {options['encryption']!r} — only 'pgp' "
            f"is a supported encryption (FR-ART-06); refusing rather than "
            f"guessing what the contract meant")

    steps = plan_artifact_steps(options)
    filename = counterparty_filename(feed_config,
                                     business_date=business_date,
                                     run_id=run_id)

    # E-L2 interplay: the Spark job may ALREADY have written
    # codec-compressed parts (output_options.compression drives the
    # writers in generic_feed.py).  Those bytes are already in their
    # sent form — the compress step must not double-wrap them, and the
    # counterparty name must carry the codec suffix the bytes really
    # have.  Detected from the MANIFEST part names (the staged copies
    # are renamed to the contract name, so the suffix must be decided
    # before staging).
    if options["codec"] not in ("", "none"):
        _suffix = CompressionWriter.suffix_for(
            CompressionFormat.from_str(options["codec"]))
        if _suffix and manifest.parts \
                and all(p.name.endswith(_suffix) for p in manifest.parts):
            if not filename.endswith(_suffix):
                filename += _suffix
            logger.info(
                "[spark_k8s.artifact] parts are already %s-compressed by "
                "the job — compress step will pass through", options["codec"])

    # PARQUET parts mean the job left the rendering to us — the single
    # renderer path.  Final-format parts (what a pre-2026-09-03 job
    # writes) are staged as they are, unchanged.  The manifest itself
    # says which, so old and new jobs both work with no version flag.
    # 2026-10-07 (K1): PARQUET parts are RENDERED for a parquet contract too
    # -- through core.feed.renderers.ParquetRenderer, the native lane's:
    # N parts become ONE file (the job writes one part per Spark partition;
    # copying them as-is refused every multi-partition parquet feed unless
    # it declared packaging), in the native file schema, with the native
    # rules (a TIME as text).
    if parts_are_parquet(manifest):
        staged = _render_parts_to_contract_format(
            manifest, feed_config, workdir, fetch_part, filename)
    else:
        staged = _stage_parts(manifest, feed_config, workdir, fetch_part,
                              filename)

    # 2026-10-15 -- checksum_covers=uncompressed: the digests of the DATA
    # file, before the chain (core/feed/checksum_covers.py -- the native
    # engine calls the same capture).  None when the feed checksums what
    # it sends.
    from core.feed.checksum_covers import capture as _capture_digests
    data_digests = _capture_digests(feed_config, staged, control_format_spec)

    for step in steps:
        if step == "package":
            staged = _package(staged, options["packaging"], filename,
                              workdir)
        elif step == "compress":
            staged = _compress(staged, options["codec"])
        elif step == "encrypt":
            staged = _encrypt(staged, options)
        # checksum handled below, after the loop, so it ALWAYS sees the
        # final bytes even if a future step lands between.

    checksums: dict[str, str] = {}
    sidecars: list[Path] = []
    algo = ""
    if "checksum" in steps:
        algo = normalise_algorithm(str(options["checksum"]))
        per_file = {p.name: compute_file_checksum(p, algo) for p in staged}
        if options["checksum_scope"] in ("whole", "both") \
                and len(staged) > 1:
            checksums["whole"] = _whole_scope_digest(staged, algo)
        checksums.update(per_file)
        if options["sidecar"] == "per_file":
            for p in staged:
                d, named = ((data_digests.get(algo), data_digests.name)
                            if data_digests is not None else (per_file[p.name], p.name))
                line = (checksum_sidecar_line(d, named)
                        if options["digest_line"] == "coreutils"
                        else d)
                sc = p.with_name(p.name + f".{algo}")
                sc.write_text(line + "\n", encoding="ascii")
                sidecars.append(sc)
        elif options["sidecar"] == "manifest":
            lines = ([checksum_sidecar_line(data_digests.get(algo), data_digests.name)]
                     if data_digests is not None else
                     [checksum_sidecar_line(per_file[p.name], p.name) for p in staged])
            sc = workdir / f"{filename.rsplit('.', 1)[0]}.{algo}"
            sc.write_text("\n".join(lines) + "\n", encoding="ascii")
            sidecars.append(sc)

    total_bytes = sum(p.stat().st_size for p in staged)

    # Declare on the manifest what will ACTUALLY be handed to a
    # transport (transient, never serialized): the hop runner's
    # plaintext tripwire (delivery_hops, FR-ART-06) judges these names,
    # not the job's internal part names, which never carry the
    # packaging/compression/encryption suffixes the staged files do.
    manifest.delivered_names = [p.name for p in staged]

    control_path: Path | None = None
    wants_ctl = bool(feed_config.get("control_file_format_id")
                     or options["sidecar"] == "control_file"
                     or (feed_config.get("output_options") or {})
                     .get("control_file"))
    if wants_ctl:
        writer = (ControlFileWriter(spec=control_format_spec)
                  if control_format_spec is not None else ControlFileWriter())
        algos = writer.algorithms or (["sha256"] if not algo else [algo])
        # Control-file digests also cover the SENT bytes — same rule.
        first = staged[0]
        from core.feed.checksum import compute_all as _compute_all
        digests = ({a: data_digests.get(a) for a in algos} if data_digests is not None
                   else _compute_all(first, algos))
        record = ControlFileRecord(
            filename=first.name,
            row_count=int(manifest.total_rows),
            byte_size=int(total_bytes),
            business_date=business_date,
            feed_name=feed_config.get("name"),
            feed_id=feed_config.get("id"),
            checksum_md5=digests.get("md5"),
            checksum_sha1=digests.get("sha1"),
            checksum_sha256=digests.get("sha256"),
            checksum_sha512=digests.get("sha512"),
            checksum_crc32=digests.get("crc32"),
        )
        stem = first.name.rsplit(".", 1)[0]
        control_path = writer.write(record, workdir / f"{stem}.ctl")

    return ArtifactChainResult(
        deliverables=staged,
        filename=(staged[0].name if len(staged) == 1 else filename),
        steps=steps,
        manifest_version=manifest.version(),
        row_count=int(manifest.total_rows),
        byte_size=int(total_bytes),
        checksum_algorithm=algo,
        checksums=checksums,
        sidecar_paths=sidecars,
        control_file_path=control_path,
    )
