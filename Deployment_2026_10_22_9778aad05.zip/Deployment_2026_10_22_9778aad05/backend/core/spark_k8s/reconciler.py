"""The spark_k8s reconciler — QueryStudio's own job supervisor (2026-08-22).

WHY POLL, NOT WATCH (decided, not defaulted): a Kubernetes ``watch`` stream
must handle connection drops, resourceVersion expiry (410 Gone) and bookmark
resume correctly, and a single missed event silently recreates the exact
failure this component exists to remove — an execution row hung "running"
forever.  A poll is self-healing BY CONSTRUCTION: every tick re-derives the
whole picture from the two durable sources of truth (execution rows in the
DB, SparkApplication CRs on the cluster), so a missed tick delays by one
interval and loses nothing.  The workload is batch jobs measured in minutes
to hours; a 15-second status latency is irrelevant next to 30-90 s pod
spin-up, and the cost is ONE label-selected LIST per tick regardless of job
count.  A watch would be an optimisation on top of a correct poll — it can
be added later without changing any semantics; the reverse is not true.

ORPHAN RE-ADOPTION is therefore implicit: the reconciler holds no in-memory
job table.  A QueryStudio pod restart mid-flight changes nothing — the next
tick re-reads rows + CRs and carries on.  (The only in-memory state is retry
BACKOFF timing and first-seen timestamps; losing them on restart means one
retry may happen slightly early and a webhook grace restarts — never a lost
or double-submitted job, because the ATTEMPT COUNT lives in the CR name and
``external_job_id``.)

WHO RUNS IT: exactly one process — the holder of the scheduler LOCK
(``core.daemon_registry.holds_single_runner_role``), the same election every
other singleton duty uses.  No second mechanism (2026-10-18: it read the lease,
which a hybrid api pod held beside the scheduler pod's lock -- two reconcilers).

WEBHOOK vs RECONCILER: the Spark job's signed webhook remains the FAST and
RICH completion path (output path, row count, completeness verification).
The reconciler is the truth floor underneath it — the paths that never call
back (driver OOM, eviction, image-pull failure, operator deleting the CR,
the job dying before its callback) all previously hung the row "running"
forever; each now reaches a terminal state with a reason.
"""
from __future__ import annotations

import base64
import json
import logging
import threading
import time
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Optional

from core.spark_k8s import availability as _availability
from core.spark_k8s.completion import (
    LOOKUP_FOUND, LOOKUP_NOT_TERMINATED, REPORT_SOURCE_CLAIM,
    REPORT_SOURCE_TERMINATION_MESSAGE, finalize_failure, finalize_from_report,
    lookup_job_report, read_job_report,
)

#: How long past ``webhook_grace_seconds`` the reconciler keeps re-reading a
#: driver pod whose container has not terminated before it closes the row
#: UNVERIFIED (2026-10-11): unknown is not absent, but it is bounded.
REPORT_WAIT_GRACE_MULTIPLIER = 2


def _claim_age_seconds(claim: dict) -> float:
    """Seconds since the callback's claim was received (wall clock; a naive
    timestamp from SQLite is UTC)."""
    received = claim.get("received_at")
    if not isinstance(received, datetime):
        return float("inf")
    if received.tzinfo is None:
        received = received.replace(tzinfo=timezone.utc)
    return max(0.0, (datetime.now(timezone.utc) - received).total_seconds())
from core.spark_k8s.errors import SparkK8sApiError, SparkK8sUnreachable
from core.spark_k8s.manifest import (
    EXECUTION_ID_LABEL,
    MANAGED_BY_SELECTOR,
    SUBMIT_MODE_CR,
    SUBMIT_MODE_POD,
    SUBMIT_MODES,
    SparkK8sSettings,
    attempt_from_name,
    resolve_job_timeout_seconds,
    settings_from_config,
)
from core.spark_k8s.runner import (
    BACKEND_NAME,
    SparkK8sRunner,
    delete_workload,
    extract_cr_status,
    list_workloads,
    stored_submit_mode,
    workload_kind,  # noqa: F401 -- re-exported for the daemon log lines
    workload_name_for,
)

#: Stamped on every listed object so the sweep and the reaper delete it
#: through the verb of ITS shape -- an object knows what it is; a row
#: knows what it was submitted as (``stored_submit_mode``).
_SHAPE_KEY = "_qs_shape"

logger = logging.getLogger(__name__)

DAEMON_NAME = "spark_k8s_reconciler"

#: Loop-interval floor — a 0/negative configured interval must never
#: busy-loop the pod (0 == unlimited-speed is still a fold).  Module-level
#: DATA so tests can drive the real loop fast without weakening the
#: production floor.
_MIN_INTERVAL_SECONDS = 5

#: CR states that mean the job is over.  LEGACY literal view kept for
#: existing imports; runtime decisions use ``classify_cr_state`` phases so
#: the vocabulary stays config-extensible (core/spark_k8s/classifier.py).
TERMINAL_CR_STATES = frozenset({"COMPLETED", "FAILED", "SUBMISSION_FAILED"})
#: Execution-row states the reconciler drives.
ACTIVE_ROW_STATES = frozenset({"pending", "running"})


# ── Failure classification ───────────────────────────────────────────────
#
# 2026-08-22 (closeout): the vocabulary moved to ``core.spark_k8s.
# classifier`` as DATA — declared MarkerRule / state-phase tables with a
# required reason on every rule, extensible via config
# (``spark_k8s.classifier_markers``, ``spark_k8s.cr_states``) so a real
# cluster's spellings need no code change.  An unmatched failure or state
# is a DECLARED conservative verdict, never a silent one.  Symbols are
# re-exported here so existing imports keep working.

from core.spark_k8s.classifier import (  # noqa: F401  (re-exports)
    DEFAULT_MARKER_RULES,
    NEVER_STARTED_STATES,
    FailureClass,
    PHASE_FAILURE,
    PHASE_SUCCESS,
    VERDICT_NON_RETRYABLE,
    classify_cr_state,
    classify_failure,
)

#: Legacy grep anchor (config comments/docs name it).  DERIVED from the
#: declared table — the classifier module is the single source.
NON_RETRYABLE_MARKERS = tuple(
    r.marker for r in DEFAULT_MARKER_RULES
    if r.verdict == VERDICT_NON_RETRYABLE
)

#: A CR phase in this set means the job is over (reaper's business);
#: anything else — including an UNRECOGNISED state — is possibly live and
#: must never be reaped.
_TERMINAL_PHASES = frozenset({PHASE_SUCCESS, PHASE_FAILURE})


# ── The reconciler ───────────────────────────────────────────────────────

class SparkK8sReconciler:
    """One tick = drive every spark_k8s execution row toward a terminal
    state, propagate cancels, and reap finished CRs + Secrets.

    Stateless across restarts except backoff/first-seen timing (see module
    docstring).  ``now_fn`` is injectable for tests.
    """

    def __init__(self, db: Any, api: Any,
                 settings: Optional[SparkK8sSettings] = None,
                 now_fn: Callable[[], float] = time.time,
                 runner: Optional[SparkK8sRunner] = None,
                 ws_emit_fn: Optional[Callable[[dict], str]] = None):
        self._db = db
        self._api = api
        self._settings = settings or settings_from_config()
        self._now = now_fn
        self._runner = runner or SparkK8sRunner(
            db, api=api, settings=self._settings,
            availability_fn=_availability.current,
        )
        # Injectable UI-event seam (tests capture the payload VALUE); the
        # default routes through the EXISTING notification machinery — see
        # _emit_terminal_ws_event.
        self._ws_emit_fn = ws_emit_fn
        # exec_id -> monotonic-ish timestamps (in-memory only; see docstring)
        self._backoff_until: Dict[str, float] = {}
        self._completed_seen: Dict[str, float] = {}

    def update_settings(self, settings: SparkK8sSettings) -> None:
        """Refresh config-derived settings WITHOUT recreating the instance.

        The daemon loop re-reads config every tick, but the INSTANCE must
        survive across ticks: ``_backoff_until`` and ``_completed_seen``
        are the retry-backoff and webhook-grace memory.  (2026-08-22
        closeout P0: the loop used to construct a NEW reconciler per tick,
        which reset both dicts every tick — so a retryable failure
        re-entered "backoff scheduled" forever and a COMPLETED CR with a
        lost webhook re-entered its grace window forever.  Every lifecycle
        test held ONE instance across ticks, so the suite could not see
        it.)"""
        self._settings = settings
        self._runner.update_settings(settings)

    # ── Tick ─────────────────────────────────────────────────────────

    def tick(self) -> dict:
        """Run one reconcile pass.  Returns a small counters dict so the
        loop (and tests) can log/assert what actually happened — numbers,
        not adjectives."""
        counters = {"rows": 0, "finalized_success": 0, "finalized_failure": 0,
                    "retries": 0, "cancels_propagated": 0, "reaped_crs": 0,
                    "reaped_secrets": 0, "released_secrets": 0}
        ns = self._settings.namespace
        rows = self._db.list_active_feed_executions_for_backend(BACKEND_NAME)
        counters["rows"] = len(rows)
        crs = self._list_all_workloads(ns, rows)
        for row in rows:
            try:
                self._reconcile_row(row, crs, counters)
            except SparkK8sApiError as exc:
                logger.warning(
                    "[spark_k8s] reconcile of %s: cluster said no (%s) — "
                    "will retry next tick", row.get("execution_id"), exc,
                )
            # any OTHER exception propagates to the loop's bug handler —
            # a programming error must never be booked as an infra hiccup
        self._prune_timing_state(rows)
        self._sweep_terminal_rows(crs, counters)
        self._reap(crs, counters)
        return counters

    def _shapes_to_list(self, rows) -> tuple:
        """Which workload shapes this tick must LIST.

        The declared mode's shape (both under ``auto``), plus the stored
        shape of every active row -- so a config flipped after a run was
        submitted still lists that run's shape, and a pure CR deployment
        never touches a pod verb (it may not even hold pods RBAC)."""
        from core.spark_k8s.manifest import SUBMIT_MODE_AUTO, assert_known_submit_mode
        declared = assert_known_submit_mode(
            getattr(self._settings, "submit_mode", SUBMIT_MODE_CR))
        shapes = set(SUBMIT_MODES) if declared == SUBMIT_MODE_AUTO else {declared}
        for row in rows or ():
            shapes.add(stored_submit_mode(row, self._settings))
        return tuple(m for m in SUBMIT_MODES if m in shapes)

    def _list_all_workloads(self, ns: str, rows=()) -> Dict[str, dict]:
        """Every managed workload on the cluster, in every shape this
        tick needs (2026-09-14).

        With ``submit_mode=auto`` the history is mixed by design: runs
        submitted while the operator was installed are SparkApplications,
        runs submitted while it was absent are driver Pods, and the
        reconciler must see all of them in one tick.  Executors carry no
        managed-by label, so the pod listing sees drivers only.  A 404 on
        the SparkApplication listing means the CRD is not served right
        now -- "no CRs", not an error (a pure CR deployment never reaches
        this tick without the CRD: the ladder refused first).  Each
        object is stamped with its shape for the delete verbs.
        """
        crs: Dict[str, dict] = {}
        for mode in self._shapes_to_list(rows):
            try:
                listing = list_workloads(self._api, ns, mode,
                                         label_selector=MANAGED_BY_SELECTOR)
            except SparkK8sApiError as exc:
                if mode == SUBMIT_MODE_CR and exc.status == 404:
                    continue                     # CRD not served: no CRs
                raise
            for item in (listing.get("items") or []):
                name = (item.get("metadata") or {}).get("name") or ""
                if not name:
                    continue
                item[_SHAPE_KEY] = mode
                crs[name] = item
        return crs

    def _shape_of(self, obj: Optional[dict], row: Optional[dict] = None) -> str:
        """The verb family for one workload: the listed object's stamp,
        else the row's stored shape (``stored_submit_mode``)."""
        if obj and obj.get(_SHAPE_KEY) in SUBMIT_MODES:
            return str(obj[_SHAPE_KEY])
        return stored_submit_mode(row or {}, self._settings)

    def _prune_timing_state(self, rows) -> None:
        """Drop backoff/first-seen entries for executions no longer active.

        Needed since the daemon loop keeps ONE reconciler instance (the
        closeout P0 fix): the explicit pops fire only on the reconciler's
        OWN terminal paths, so an execution finished by its webhook or a
        user cancel mid-race would otherwise leave its stamp in these
        dicts for the life of the process."""
        active = {(r.get("execution_id") or "") for r in rows}
        for d in (self._backoff_until, self._completed_seen):
            for stale in [k for k in d if k not in active]:
                d.pop(stale, None)

    # ── Per-row state machine ────────────────────────────────────────

    def _reconcile_row(self, row: dict, crs: Dict[str, dict],
                       counters: dict) -> None:
        exec_id = row.get("execution_id") or ""
        cr_name = workload_name_for(self._db, row)
        cr = crs.get(cr_name)

        if cr is None:
            # Submit may be mid-flight on another pod (secret created, CR
            # create not yet landed) — grace before concluding anything.
            if self._row_age_seconds(row) < self._settings.adoption_grace_seconds:
                return
            self._fail_or_retry(
                row, state="MISSING",
                error=(f"{workload_kind(stored_submit_mode(row, self._settings))} {cr_name!r} not "
                       f"found on the cluster — it was never created, or "
                       f"was deleted outside QueryStudio"),
                fc=FailureClass(True, "cr_missing"),
                counters=counters,
            )
            return

        st = extract_cr_status(cr)
        phase = classify_cr_state(st.state)
        if phase == PHASE_SUCCESS:
            # Success normally arrives via the job's signed webhook (which
            # carries output path / row count / verification).  Only when
            # the webhook is DEMONSTRABLY missing — the CR finished a full
            # grace window ago and the row still says running — does the
            # reconciler finalize, honestly marked UNVERIFIED.
            first_seen = self._completed_seen.setdefault(exec_id, self._now())
            if (self._now() - first_seen) < self._settings.webhook_grace_seconds:
                return
            self._finalize_success_without_webhook(row, st, counters)
        elif phase == PHASE_FAILURE:
            fc = classify_failure(st.state, st.error_message)
            self._fail_or_retry(row, state=st.state, error=st.error_message,
                                fc=fc, counters=counters)
        else:
            # PHASE_IN_FLIGHT (SUBMITTED / RUNNING / FAILING / SUCCEEDING /
            # "" / ...) — or PHASE_UNKNOWN: a state the declared vocabulary
            # does not know, treated conservatively as possibly-live
            # (classifier logs it once, with the config key that extends
            # the vocabulary).  Either way the timeout gate below bounds it.
            age = self._row_age_seconds(row)

            # ── D9 (2026-09-02) — a pod that NEVER STARTS is its own failure.
            # Quota exhausted or an image pull failing leaves the CR SUBMITTED
            # with no driver pod.  The only gate used to be the job timeout, so
            # a 02:00 quota problem surfaced at 06:00 as "the feed was slow".
            pending_cap = int(self._settings.pending_timeout_seconds or 0)
            if (pending_cap > 0 and age > pending_cap
                    and self._is_pending_state(st.state)):
                self._delete_cr_and_secret(
                    cr_name, stored_submit_mode(row, self._settings))
                self._finalize_failure(
                    row, state=st.state or "SUBMITTED",
                    error=(f"spark_k8s job NEVER STARTED — "
                           f"{workload_kind(stored_submit_mode(row, self._settings))} "
                           f"{cr_name} was still '{st.state or 'SUBMITTED'}' "
                           f"after {int(age)}s (cap "
                           f"spark_k8s.pending_timeout_seconds={pending_cap}s). "
                           f"No driver pod ran: check the namespace quota, the "
                           f"image pull and the ServiceAccount"),
                    attempt=attempt_from_name(cr_name),
                    fc=FailureClass(False, "pod_never_started"),
                    counters=counters,
                )
                return

            # ── H2 (2026-09-02) — the timeout is PER FEED, not global.  The
            # feed-config read is gated on the floor so the common case (a
            # young row) costs nothing: no row can time out before the
            # shortest configured budget has elapsed.
            timeout = int(self._settings.job_timeout_seconds)
            reason = "deployment default"
            if age > self._timeout_floor_seconds():
                timeout, reason = self._resolve_row_timeout(row)
            _stop, _why = (False, "")
            if timeout > 0 and age > timeout:
                # 2026-10-14 -- a budget stops a STUCK run, never a moving
                # one: past it, a run whose progress counters still move
                # keeps going up to spark_k8s.job_ceiling_seconds
                # (core/feed/run_progress.budget_verdict).  The 40M pod run
                # was killed healthy, 37% through, by a 2-hour budget.
                from core.feed.run_progress import budget_verdict
                from core.config import spark_k8s as _sk_cfg
                _fresh_row = self._db.get_feed_execution(row["id"]) or row
                _stop, _why = budget_verdict(_fresh_row, age_seconds=age, budget_seconds=timeout,
                                             ceiling_seconds=int(_sk_cfg.job_ceiling_seconds))
                if not _stop:
                    logger.info("[spark_k8s] %s kept running: %s", cr_name, _why)
            if _stop:
                # A cap must throttle; a correctness gate must FAIL — this
                # is the gate against the forever-hung execution.
                self._delete_cr_and_secret(
                    cr_name, stored_submit_mode(row, self._settings))
                self._finalize_failure(
                    row, state=st.state or "RUNNING",
                    error=(f"spark_k8s job stopped: {_why} ({reason}) — "
                           f"{workload_kind(stored_submit_mode(row, self._settings))} "
                           f"{cr_name} deleted"),
                    attempt=attempt_from_name(cr_name),
                    fc=FailureClass(False, "job_timeout"),
                    counters=counters,
                )

    # ── Terminal transitions (all behind a fresh-row re-read) ────────

    def _fresh_active_row(self, row: dict) -> Optional[dict]:
        """Re-read the row IMMEDIATELY before acting.  The tick works from
        a listing snapshot; a user cancel (or the webhook) can land between
        the snapshot and our write, and acting on the stale row would
        resubmit a cancelled job or overwrite a webhook result."""
        fresh = self._db.get_feed_execution(row["id"])
        if not fresh:
            return None
        if (fresh.get("status") or "").lower() not in ACTIVE_ROW_STATES:
            return None
        return fresh

    #: CR states that mean "accepted, but no driver pod is running yet".
    #: ``""`` is included: a CR the operator has not yet stamped is also not
    #: running.  RUNNING and every terminal state are deliberately absent.
    PENDING_CR_STATES = frozenset({"", "submitted", "pending", "pendingrerun"})

    @classmethod
    def _is_pending_state(cls, state) -> bool:
        return str(state or "").strip().lower() in cls.PENDING_CR_STATES

    def _timeout_floor_seconds(self) -> int:
        """The shortest budget any feed could have.

        Below it no row can have timed out, so the per-row feed-config read in
        ``_resolve_row_timeout`` is skipped entirely -- the timeout gate stays
        free for every young row, which is almost all of them.  A cheaper gate
        that changes no verdict.
        """
        budgets = [int(self._settings.job_timeout_seconds or 0)]
        for cls_cfg in (self._settings.size_classes or {}).values():
            if isinstance(cls_cfg, dict) and cls_cfg.get("job_timeout_seconds"):
                budgets.append(int(cls_cfg["job_timeout_seconds"]))
        positive = [b for b in budgets if b > 0]
        return min(positive) if positive else 0

    def _resolve_row_timeout(self, row: dict) -> tuple:
        """``(timeout_seconds, reason)`` for one execution row.

        Fails OPEN to the deployment default when the feed config cannot be
        read: the alternative is either killing a job on a budget we could not
        verify, or never killing it at all.  The deployment default is the
        answer that was already in force before H2.
        """
        feed_id = row.get("feed_config_id")
        if feed_id is None:
            return int(self._settings.job_timeout_seconds), "deployment default"
        try:
            cfg = self._db.get_feed_config(int(feed_id)) or {}
        except Exception as exc:
            logger.warning(
                "[spark_k8s] could not read feed_config %s for its job "
                "timeout (%s) — using the deployment default (%ss)",
                feed_id, exc, self._settings.job_timeout_seconds)
            return int(self._settings.job_timeout_seconds), "deployment default"
        return resolve_job_timeout_seconds(
            cfg.get("backend_config") or {}, self._settings)

    #: Destinations the Spark job writes to ITSELF, before its webhook lands.
    #: Re-submitting such a job repeats an act that is visible outside this
    #: system.  ``s3`` / ``local`` are absent on purpose: both are
    #: ``mode("overwrite")`` and therefore idempotent.
    POD_SIDE_DELIVERY_DESTINATIONS = frozenset({"sftp", "oracle"})

    def _attempt_conf(self, row: dict) -> Optional[dict]:
        """The ``--feed-config`` payload THIS attempt ran with, read back
        from its Secret; None when it cannot be read (no Secret, no API, a
        malformed payload) -- the callers then fall back to their own rule."""
        try:
            sec = self._api.read_secret(
                self._settings.namespace, "creds-" + workload_name_for(self._db, row))
            raw = (sec.get("data") or {}).get("FEED_CONFIG_JSON")
            conf = json.loads(base64.b64decode(raw).decode("utf-8")) if raw else None
            return conf if isinstance(conf, dict) else None
        except Exception:                                   # noqa: BLE001 -- unknown = fall back
            return None

    def _pod_side_delivery_destination(self, row: dict) -> Optional[str]:
        """Return the destination type when this run delivers from inside the
        pod, else ``None``.

        Fail-CLOSED on an unreadable feed config: if we cannot tell whether a
        run delivers from the pod, we must not retry it.  A missed retry costs
        a manual re-run; a wrong retry costs a counterparty a duplicate
        regulatory file.
        """
        feed_id = row.get("feed_config_id")
        if feed_id is None:
            return None
        # WHO DELIVERS was decided ONCE, at submit, and stored in the attempt's
        # payload (``feed_conf.resolve_delivery_owner`` -> ``deliver_in_job``).
        # When it says QueryStudio delivers (parquet over SFTP, a declared
        # chain, a suppressed backfill, pod-side delivery off) the pod wrote
        # only to QueryStudio's own store, overwriting, and nothing left it:
        # the retry is safe.  Re-deciding from the destination type alone
        # refused those retries too (2026-10-14: a killed driver of a
        # parquet-over-SFTP feed, found on the rig).  An unreadable payload
        # keeps the destination rule below -- fail CLOSED.
        conf = self._attempt_conf(row)
        if conf is not None and conf.get("deliver_in_job") is False:
            return None
        try:
            cfg = self._db.get_feed_config(int(feed_id)) or {}
        except Exception as exc:
            logger.error(
                "[spark_k8s] could not read feed_config %s to decide retry "
                "safety (%s) — treating the run as pod-side delivery and "
                "REFUSING the retry rather than risk a duplicate delivery",
                feed_id, exc,
            )
            return "unknown"
        dest = str(cfg.get("destination_type") or "").strip().lower()
        return dest if dest in self.POD_SIDE_DELIVERY_DESTINATIONS else None

    def _fail_or_retry(self, row: dict, *, state: str, error: str,
                       fc: FailureClass, counters: dict) -> None:
        fresh = self._fresh_active_row(row)
        if fresh is None:
            return
        exec_id = fresh.get("execution_id") or ""
        cr_name = workload_name_for(self._db, fresh)
        attempt = attempt_from_name(cr_name)
        max_retries = int(self._settings.max_retries)
        # ── H1 (2026-09-02) — a run that DELIVERS FROM INSIDE THE POD is not
        # retryable, whatever the failure looked like.
        #
        # On this lane the Spark job delivers itself (generic_feed
        # ``_write_sftp`` / ``_write_oracle``) and only then reports through
        # its webhook.  A job that delivered and THEN died before the callback
        # landed -- driver OOM at callback, a network blip; the callback
        # swallows its own failure -- presents as FAILED.  Resubmitting it
        # delivers the file to the counterparty a SECOND time.
        #
        # No failure classification can prevent this, because the retry unit
        # (the whole pod) CONTAINS the non-idempotent act.  So the refusal is
        # keyed on the destination, not on the error.  S3 and local writes
        # stay retryable: they are mode("overwrite") and idempotent.
        #
        # This is the interim guard.  The structural fix is delivery leaving
        # the pod and becoming a manifest hop, which makes the pod retry-safe
        # by construction -- foundation M.
        # 2026-10-11 -- a job that NEVER STARTED (spark-submit itself failed:
        # SUBMISSION_FAILED) delivered nothing, so the duplicate-delivery
        # refusal below does not apply; the classifier's own verdict stands.
        # Found live: every owner-case run that died at submit with
        # "argument list too long" was labelled non_retryable:pod_side_
        # delivery, naming a delivery that could not have happened.
        _never_started = str(state or "").upper() in NEVER_STARTED_STATES
        _dest = (None if _never_started
                 else self._pod_side_delivery_destination(fresh))
        if _dest and fc.retryable and attempt < max_retries:
            logger.error(
                "[spark_k8s] %s attempt %d failed (%s: %.300s) — REFUSING the "
                "retry: this feed delivers over '%s' from inside the Spark "
                "pod, so the job may already have delivered before it died "
                "and a resubmit would deliver AGAIN.  Re-run it by hand once "
                "the counterparty side is confirmed.",
                exec_id, attempt, state, error, _dest,
            )
            fc = FailureClass(False, "non_retryable:pod_side_delivery",
                              f"delivery to '{_dest}' happens inside the job")
        if fc.retryable and attempt < max_retries:
            not_before = self._backoff_until.get(exec_id)
            if not_before is None:
                self._backoff_until[exec_id] = (
                    self._now() + int(self._settings.retry_backoff_seconds))
                logger.warning(
                    "[spark_k8s] %s attempt %d failed (%s: %.300s) — retry "
                    "%d/%d scheduled in %ds",
                    exec_id, attempt, state, error, attempt + 1, max_retries,
                    int(self._settings.retry_backoff_seconds),
                )
                return
            if self._now() < not_before:
                return
            self._retry(fresh, attempt + 1, prior_error=error,
                        counters=counters)
        else:
            self._finalize_failure(fresh, state=state, error=error,
                                   attempt=attempt, fc=fc, counters=counters)

    def _retry(self, row: dict, next_attempt: int, *, prior_error: str,
               counters: dict) -> None:
        exec_id = row.get("execution_id") or ""
        old_name = workload_name_for(self._db, row)
        ns = self._settings.namespace

        # Reuse the ORIGINAL attempt's exact --feed-config payload so every
        # attempt executes identical work (calendar tokens included, and the
        # read plan's pinned Iceberg snapshot / planned files).  None =
        # unreadable -> rebuilt below.
        conf_override: Optional[dict] = self._attempt_conf(row)

        self._delete_cr_and_secret(
            old_name, stored_submit_mode(row, self._settings))

        feed_config = self._db.get_feed_config(row.get("feed_config_id"))
        if not feed_config:
            self._finalize_failure(
                row, state="RETRY_ABORTED",
                error=f"feed config {row.get('feed_config_id')} no longer "
                      f"exists; prior error: {prior_error}",
                attempt=next_attempt - 1,
                fc=FailureClass(False, "feed_config_missing"),
                counters=counters)
            return
        run_date = None
        started = self._as_dt(row.get("started_at"))
        if started is not None:
            run_date = started.date()
        self._runner.submit(
            feed_config, row, attempt=next_attempt,
            feed_conf_override=conf_override, run_date=run_date,
        )
        self._backoff_until.pop(exec_id, None)
        counters["retries"] += 1
        logger.warning(
            "[spark_k8s] %s resubmitted as attempt %d (prior failure: "
            "%.300s)", exec_id, next_attempt, prior_error,
        )

    def _finalize_success_without_webhook(self, row: dict, st, counters: dict) -> None:
        fresh = self._fresh_active_row(row)
        if fresh is None:
            return
        # 2026-10-11 -- the job's REPORT outlives the callback: the same
        # payload it POSTs is written to the driver's termination message
        # (generic_feed.write_termination_report) and read from the pod
        # here (core/spark_k8s/completion.py).  With it, this finaliser
        # closes the row EXACTLY as the webhook would -- rows, delivery
        # verdict, merge record, webhook-side delivery, status by the one
        # verdict -- so whichever finaliser wins the race, the record is the
        # same.  Found live: 1 of 10 owner-case runs closed here with
        # cross_source == {} and total_rows unknown while its file was right.
        exec_id = fresh.get("execution_id") or ""
        # (a) The callback's durable CLAIM (spark_job_reports, 2026-10-11):
        # the webhook ACKed and finalises off the request.  Fresh = in
        # flight, defer; stale = the API pod died between ACK and
        # finalisation, finish it HERE from the persisted report (one
        # reader path, the same finaliser).
        claim = self._db.get_spark_job_report(exec_id)
        if claim is not None and not claim.get("finalized_at"):
            age = _claim_age_seconds(claim)
            if age < int(self._settings.webhook_grace_seconds):
                logger.info("[spark_k8s] %s: a callback was received %ds ago and its "
                            "finalisation is in flight -- deferring", exec_id, int(age))
                return
            claimed = dict(claim.get("report") or {})
            if str(claimed.get("state") or "").lower() == "success":
                logger.warning("[spark_k8s] %s: a callback was received %ds ago and never "
                               "finalised -- finalising from the persisted report",
                               exec_id, int(age))
                self._finalize_from_report(fresh, st, claimed, counters,
                                           source=REPORT_SOURCE_CLAIM)
                return
        # (b) The driver pod's termination message.  "Not terminated yet"
        # is UNKNOWN -- a report may still appear -- and is re-read on the
        # next tick, bounded; only "terminated with no report" / "pod gone"
        # is ABSENT.  Found live (2008/2009): the reader took one answer
        # for both and closed UNVERIFIED a run whose report was there.
        report = None
        report_note = "absent"
        try:
            lookup = lookup_job_report(
                self._api, self._settings.namespace,
                fresh.get("external_job_id") or workload_name_for(self._db, fresh),
                stored_submit_mode(fresh, self._settings))
        except SparkK8sApiError as exc:
            # The cluster REFUSED the pod read (a CR-only deployment may
            # hold no pods RBAC): the row must still close -- unverified,
            # as before -- and the record says the report was unreadable.
            logger.warning("[spark_k8s] %s: the driver pod could not be read for "
                           "the job's report (%s) -- finalising without it",
                           exec_id, exc)
            report_note = f"unreadable ({exc})"[:300]
        else:
            if lookup.status == LOOKUP_FOUND:
                report = lookup.report
            elif lookup.status == LOOKUP_NOT_TERMINATED:
                first_seen = self._completed_seen.get(exec_id, self._now())
                waited = self._now() - first_seen
                bound = REPORT_WAIT_GRACE_MULTIPLIER * int(self._settings.webhook_grace_seconds)
                if waited < bound:
                    logger.info("[spark_k8s] %s: the CR reads COMPLETED but the driver "
                                "container has not terminated (%s) -- re-reading next "
                                "tick (%ds of %ds)", exec_id, lookup.detail, int(waited), bound)
                    return
                report_note = f"not readable after {int(waited)}s ({lookup.detail})"[:300]
            else:
                report_note = f"absent ({lookup.detail})"[:300]
        if report is not None and str(report.get("state") or "").lower() == "success":
            self._finalize_from_report(fresh, st, report, counters)
            return
        if report is not None:
            logger.error(
                "[spark_k8s] %s: the CR reads COMPLETED but the job's own "
                "report says state=%s -- finalising UNVERIFIED, not from it",
                fresh.get("execution_id"), report.get("state"))
            report_note = f"contradictory (state={report.get('state')})"
        now = datetime.now(timezone.utc)
        fm = dict(fresh.get("files_metadata") or {})
        # ── D7 (2026-09-02) — "one job's webhook was lost" and "no webhook can
        # EVER be verified" are opposite investigations, and they used to look
        # identical.  With the shared HMAC secret unset or rotated, EVERY
        # success arrives down this path: the whole fleet silently degrades to
        # unverified while every row reads 'completed'.  That is exactly the
        # "could not tell counted as fine" the completeness rule forbids.
        systemic = not (self._settings.webhook_secret or "").strip()
        fm["spark_k8s"] = {
            "completed_via": "reconciler",
            "webhook": "impossible" if systemic else "missing",
            # A STRUCTURED verdict beside the prose, so a consumer can branch
            # on it instead of parsing a sentence.  'unverifiable' is its own
            # state -- never folded into success.
            "completeness_verdict": "unverifiable",
            "completeness": (
                "UNVERIFIED — the SparkApplication reached COMPLETED but "
                "its signed completion webhook never arrived, so the "
                "delivered output was not recounted"),
            "termination_time": st.termination_time,
        }
        if systemic:
            fm["spark_k8s"]["completeness"] = (
                "UNVERIFIABLE — feed_generation.webhook_secret is NOT SET, so "
                "the Spark job cannot sign its completion callback and NO run "
                "on this lane can be verified.  Every spark_k8s feed is "
                "completing without a recount until the secret is configured.")
            logger.error(
                "[spark_k8s] %s completed WITHOUT verification because "
                "feed_generation.webhook_secret is not set — this is FLEET-"
                "WIDE, not one lost callback: no spark_k8s run can be "
                "verified until the secret is configured.",
                fresh.get("execution_id"),
            )
        # ── FR-DEL-01/14 (2026-09-02) — NEVER STAMP A DELIVERY THAT DID
        # NOT HAPPEN.  This fallback runs NO hop plan and writes NO
        # delivery attempt rows.  On a chain-declared feed the job was
        # submitted deliver_in_job=false — it wrote artifacts ONLY, so
        # the delivery the old ``delivery_completed_at: now`` claimed
        # NEVER HAPPENED; on a deliver-in-job feed it may have happened,
        # but the one signal that could confirm it is exactly the webhook
        # that was lost.  Either way the field stays NULL — the row reads
        # "completed, delivery not confirmed" instead of green on every
        # signal — and the structured ``delivery`` key says which case
        # this is so an operator can re-deliver, not re-generate.
        _delivery = "unconfirmed"
        try:
            from core.spark_k8s.feed_conf import _declares_delivery_chain
            _feed_cfg = self._db.get_feed_config(fresh.get("feed_config_id"))
            if _feed_cfg and _declares_delivery_chain(_feed_cfg):
                _delivery = "not_performed"
        except Exception:
            # Cannot tell whether a chain was declared — "unconfirmed" is
            # the weaker, still-honest claim; the field stays NULL either
            # way, so nothing is over-claimed.
            _delivery = "unconfirmed"
        fm["spark_k8s"]["delivery"] = _delivery
        if _delivery == "not_performed":
            fm["spark_k8s"]["delivery_detail"] = (
                "this feed declares a delivery chain, so the job wrote "
                "artifacts ONLY (deliver_in_job=false) and the engine-side "
                "hop plan — which only the completion webhook triggers — "
                "never ran: NOTHING was delivered.  Re-deliver the stored "
                "artifacts; do not re-generate.")
            logger.error(
                "[spark_k8s] %s completed via the reconciler but its "
                "delivery chain NEVER RAN — the job wrote artifacts only "
                "and the webhook that triggers engine-side delivery was "
                "lost.  Nothing reached the counterparty; re-deliver the "
                "stored artifacts.",
                fresh.get("execution_id"),
            )
        else:
            fm["spark_k8s"]["delivery_detail"] = (
                "no webhook arrived, so whether the job's in-pod delivery "
                "happened was never confirmed; delivery_completed_at is "
                "deliberately left unset.")
        # 2026-09-15 -- THE ROW COUNT IS NOT KNOWN HERE, AND 0 IS NOT
        # "UNKNOWN".  The count reaches the row only on the completion
        # webhook; the execution row is CREATED with total_rows = 0, so a
        # run finalized by the reconciler kept that 0 forever.  Proved live:
        # a spark_k8s run whose driver logged "WRITE complete rows=500000"
        # and put 500,000 rows into Oracle showed ``completed`` with
        # ``total_rows = 0`` and ``file_size_bytes = 0`` -- indistinguishable
        # from a feed that legitimately produced nothing, and that is what
        # the row-count gate, the SLA scan and the dashboard all read.
        #
        # Same rule this function already applies to delivery_completed_at,
        # and the same shape ``core/feed/fanout.py`` uses for a partial run
        # (``total_rows if rows_known else None``): the field stays NULL and
        # the structured key says WHY, rather than a number that reads as a
        # measurement nobody took.
        fm["spark_k8s"]["rows"] = "unknown"
        fm["spark_k8s"]["rows_detail"] = (
            "the completion webhook carries the row count and never "
            "arrived, so no count was ever reported to the engine. "
            "total_rows is left unset rather than 0 -- 0 would be "
            "indistinguishable from a feed that produced no rows. The "
            "driver's own log has the number it wrote.")
        fm["spark_k8s"]["report"] = report_note
        if _delivery == "not_performed":
            # 2026-10-11 -- a delivery that NEVER RAN is a FAILED run, not a
            # completed one (the same verdict chain_verdict gives "no
            # outcomes at all"; memory: a run whose delivery failed must
            # never read completed).  The record above says what to do.
            _dest = str((_feed_cfg or {}).get("destination_type") or "local")
            _msg = (f"Feed {fresh.get('feed_config_id')} @ stage='deliver_{_dest}': "
                    f"{fm['spark_k8s']['delivery_detail']}")
            self._db.update_feed_execution(fresh["id"], {
                "status": "failed",
                "completed_at": now,
                "total_rows": None,
                "failed_stage": f"deliver_{_dest}",
                "error_message": _msg[:2000],
                "files_metadata": fm,
            })
            self._completed_seen.pop(fresh.get("execution_id") or "", None)
            counters["finalized_failure"] += 1
            logger.error("[spark_k8s] %s FAILED by the reconciler: %s",
                         fresh.get("execution_id"), _msg)
            self._after_terminal(fresh, success=False, detail=_msg)
            return
        self._db.update_feed_execution(fresh["id"], {
            "status": "completed",
            "completed_at": now,
            "total_rows": None,
            "files_metadata": fm,
        })
        self._completed_seen.pop(fresh.get("execution_id") or "", None)
        counters["finalized_success"] += 1
        logger.warning(
            "[spark_k8s] %s finalized COMPLETED by the reconciler — the "
            "job's webhook never arrived; completeness is UNVERIFIED",
            fresh.get("execution_id"),
        )
        self._after_terminal(fresh, success=True,
                             detail="completed (webhook missing)")

    def _finalize_from_report(self, fresh: dict, st, report: dict,
                              counters: dict,
                              source: str = REPORT_SOURCE_TERMINATION_MESSAGE) -> None:
        """Close the row from the job's own report through the ONE
        finaliser the webhook uses; stamp HOW it was closed and from what
        (the pod's termination message, or a callback's claim the API pod
        never finalised)."""
        exec_id = fresh.get("execution_id") or ""
        final = finalize_from_report(self._db, fresh, report, via="reconciler")
        try:
            latest = self._db.get_feed_execution(fresh["id"]) or fresh
            fm = dict(latest.get("files_metadata") or {})
            fm["spark_k8s"] = {
                "completed_via": "reconciler",
                "webhook": "missing" if source == REPORT_SOURCE_TERMINATION_MESSAGE
                           else "received, not finalised by the API pod",
                "report": source,
                "termination_time": st.termination_time,
            }
            self._db.update_feed_execution(fresh["id"], {"files_metadata": fm})
        except Exception as exc:                    # noqa: BLE001 -- observability only
            logger.warning("[spark_k8s] %s: completed_via stamp skipped: %s",
                           exec_id, exc)
        self._completed_seen.pop(exec_id, None)
        ok = final.get("status") == "completed"
        counters["finalized_success" if ok else "finalized_failure"] += 1
        logger.warning(
            "[spark_k8s] %s finalized %s by the reconciler from the job's own "
            "report (the webhook never arrived)", exec_id,
            "COMPLETED" if ok else "FAILED")
        self._after_terminal(
            fresh, success=ok,
            detail=("completed (webhook missing; report read from the pod)"
                    if ok else str(final.get("error_message") or "delivery failed")))

    def _finalize_failure(self, row: dict, *, state: str, error: str,
                          attempt: int, fc: FailureClass,
                          counters: dict) -> None:
        fresh = self._fresh_active_row(row)
        if fresh is None:
            return
        verdict = ("declared non-retryable" if not fc.retryable
                   else f"retries exhausted ({attempt}/{self._settings.max_retries})")
        # fc.detail carries the matched rule's declared REASON (classifier
        # table) so the operator reading a failed feed sees the argument.
        why = f" — {fc.detail}" if getattr(fc, "detail", "") else ""
        classification = f"{verdict}; classification={fc.reason}{why}"
        # 2026-10-11 -- the job's own report, when the driver got as far as
        # its except arm (the termination message: the JVM error, the
        # reported-rows record), closes the row through the SAME finaliser
        # the webhook uses.  A job that never started (SUBMISSION_FAILED)
        # has no pod -> no report -> the cluster's words.
        report = None
        # The callback's claim first (2026-10-11): a failed report the
        # webhook received but has not finalised yet is in flight (defer);
        # one it never finalised is finished here from the persisted copy.
        claim = self._db.get_spark_job_report(fresh.get("execution_id") or "")
        if claim is not None and not claim.get("finalized_at"):
            claimed = dict(claim.get("report") or {})
            if str(claimed.get("state") or "").lower() in ("failed", "error"):
                if _claim_age_seconds(claim) < int(self._settings.webhook_grace_seconds):
                    logger.info("[spark_k8s] %s: a failure callback was received and its "
                                "finalisation is in flight -- deferring",
                                fresh.get("execution_id"))
                    return
                report = claimed
        if report is None and str(state or "").upper() not in NEVER_STARTED_STATES:
            try:
                report = read_job_report(
                    self._api, self._settings.namespace,
                    fresh.get("external_job_id") or workload_name_for(self._db, fresh),
                    stored_submit_mode(fresh, self._settings))
            except SparkK8sApiError as exc:
                logger.warning("[spark_k8s] %s: the driver pod could not be read for "
                               "the job's failure report (%s)", fresh.get("execution_id"), exc)
            if report is not None and str(report.get("state") or "").lower() not in ("failed", "error"):
                logger.error("[spark_k8s] %s: the CR reads %s but the job's report says "
                             "state=%s -- not trusted", fresh.get("execution_id"), state,
                             report.get("state"))
                report = None
        update = finalize_failure(self._db, fresh, report, via="reconciler",
                                  cr_state=state, cr_error=error,
                                  classification=classification)
        if update and claim is not None and not claim.get("finalized_at"):
            try:
                self._db.mark_spark_job_report_finalized(
                    fresh.get("execution_id") or "", "reconciler")
            except Exception as exc:                # noqa: BLE001 -- bookkeeping
                logger.warning("[spark_k8s] %s: the report claim could not be stamped: %s",
                               fresh.get("execution_id"), exc)
        self._backoff_until.pop(fresh.get("execution_id") or "", None)
        if not update:
            return                                  # another finaliser closed it first
        message = str(update.get("error_message") or "")
        counters["finalized_failure"] += 1
        logger.error("[spark_k8s] %s FAILED terminally: %s",
                     fresh.get("execution_id"), message)
        self._after_terminal(fresh, success=False, detail=message)

    def _after_terminal(self, row: dict, *, success: bool, detail: str) -> None:
        """Best-effort bookkeeping for rows the RECONCILER (not an awaiting
        execute_feed coroutine) drove terminal: the UI completion event,
        feed_run sync + operator notifications.  Observability only — a
        failure here never undoes the terminal row state."""
        self._emit_terminal_ws_event(row, success=success, detail=detail)
        try:
            # Edge-case sweep 2026-09-24: the execution's OWN run (see
            # feed_run_for_execution) -- a manual Run Now has none, and it
            # used to finish the day's scheduled row.  And never a run that
            # is already terminal.
            fr = (self._db.feed_run_for_execution(row)
                  if hasattr(self._db, "feed_run_for_execution") else None)
            if fr and fr.get("status") in ("pending", "running"):
                self._db.update_feed_run(fr["id"], {
                    "status": "completed" if success else "failed",
                    "completed_at": datetime.now(timezone.utc),
                    **({} if success else {"error": detail[:2000]}),
                })
        except Exception as exc:
            logger.debug("[spark_k8s] feed_run sync skipped: %s", exc)
        try:
            from core.feed_engine import _send_notifications
            feed_config = self._db.get_feed_config(row.get("feed_config_id"))
            if feed_config:
                _send_notifications(
                    feed_config,
                    "success" if success else "failure",
                    {"feed_name": feed_config.get("name", ""),
                     "error": None if success else detail,
                     "detail": detail},
                    db=self._db,
                )
        except Exception as exc:
            logger.debug("[spark_k8s] notification dispatch skipped: %s", exc)

    def _emit_terminal_ws_event(self, row: dict, *, success: bool,
                                detail: str) -> None:
        """Tell the UI — the rows the reconciler finalizes are EXACTLY the
        ones whose submitting pod never got to broadcast (it is gone, or
        its webhook never fired), so without this the dashboard showed
        "running" until a manual refresh.

        Delivery routes through the EXISTING machinery, never a parallel
        path (core.notification_queue.emit_ws_event): the process-wired
        feed_engine broadcast when this pod has one (main.py pods — local
        WS + cross-pod event-bus relay), else the configured notification
        queue (Redis pub/sub, or the pending_notifications DB outbox every
        API pod's notification_poller drains with a per-pod cursor).  The
        payload shape mirrors feed_engine._notify's feed_completed /
        feed_failed events byte-for-byte plus ``completed_via:
        "reconciler"``.

        Emission is once-per-terminal-transition at the source (the
        transition itself is happen-once via _fresh_active_row) and the
        outbox drain is once-per-pod (monotonic cursor; a restarted pod
        starts at max id, so no replay).  SYSTEM-level delivery remains
        at-least-once per execution: an awaiting execute_feed coroutine
        that observes the terminal row emits its own event — the UI treats
        events as idempotent per execution_id (the fleet-routing contract
        declared in core/websocket_manager.py).

        Observability only: any failure here is WARNING-logged and never
        undoes the terminal row."""
        try:
            now = datetime.now(timezone.utc)
            started = self._as_dt(row.get("started_at"))
            payload: Dict[str, Any] = {
                "type": "feed_completed" if success else "feed_failed",
                "timestamp": now.isoformat(),
                "feed_id": row.get("feed_config_id"),
                "execution_id": row.get("execution_id"),
                "feed_name": "",
                "triggered_by": row.get("triggered_by") or "",
                "completed_via": "reconciler",
            }
            # Routing PARITY with the native path (2026-10-07): the SAME
            # audience the engine's own feed_completed/feed_failed reach --
            # THE function, core/feed/event_audience.py (the actor if a
            # person, the owner, the owner group).  It used to be the
            # actor alone, so a queue-worker run finalized here went to
            # "queue_worker" -- nobody -- and an unknown actor went to
            # EVERY browser.  An empty audience goes to nobody.
            fc = None
            try:
                fc = self._db.get_feed_config(row.get("feed_config_id"))
                payload["feed_name"] = (fc or {}).get("name", "")
            except Exception as exc:
                logger.debug("[spark_k8s] feed name lookup for the UI "
                             "event failed: %s", exc)
            # The execution's OWN run (feed_run_for_execution; a manual Run
            # Now owns none) names the person who ASKED for it.
            fr = None
            try:
                fr = (self._db.feed_run_for_execution(row)
                      if hasattr(self._db, "feed_run_for_execution") else None)
            except Exception as exc:
                logger.debug("[spark_k8s] run lookup for the UI event's "
                             "audience failed: %s", exc)
            from core.feed.event_audience import address, feed_event_audience
            address(payload, feed_event_audience(
                self._db, row.get("feed_config_id"),
                payload["triggered_by"] or None,
                feed=fc if isinstance(fc, dict) else None,
                run=fr if isinstance(fr, dict) else None))
            if success:
                payload["rows"] = row.get("total_rows") or 0
                payload["destination"] = row.get("destination_path") or ""
                payload["duration_seconds"] = (
                    round(now.timestamp() - started.timestamp(), 2)
                    if started is not None else None)
                payload["completeness"] = "UNVERIFIED"
            else:
                payload["error"] = (detail or "")[:2000]

            emit = self._ws_emit_fn
            if emit is None:
                local_fn = None
                try:
                    from core import feed_engine as _fe
                    local_fn = _fe._broadcast_fn
                except Exception:
                    local_fn = None  # feeds module absent → queue path
                from core.notification_queue import emit_ws_event

                def emit(p, _local=local_fn):
                    return emit_ws_event(
                        p,
                        session_factory=getattr(self._db, "SessionLocal",
                                                None),
                        local_broadcast_fn=_local,
                    )
            mode = emit(payload)
            logger.info("[spark_k8s] %s: %s event delivered via %s",
                        row.get("execution_id"), payload["type"], mode)
        except Exception as exc:
            # Loud, not silent — the execution row is terminal and correct;
            # only the LIVE push is lost (the dashboard catches up on
            # refetch).
            logger.warning(
                "[spark_k8s] %s: UI completion event NOT delivered (%s) — "
                "row state is already terminal and unaffected",
                row.get("execution_id"), exc)

    # ── Cancel propagation + reaping ─────────────────────────────────

    def _sweep_terminal_rows(self, crs: Dict[str, dict], counters: dict) -> None:
        """A row that is already terminal (cancelled by the API, failed by
        a poll timeout) must not keep a LIVE CR computing on the cluster.
        Covers the multi-pod cancel: the cancel endpoint's best-effort
        delete may have run on a pod with no cluster access.

        A COMPLETED row is the one case where a live CR is NORMAL for a
        moment: the job's LAST act is the signed webhook, sent before
        ``spark.stop()`` and exit, so the row turns ``completed`` while
        the driver is still shutting down.  Until 2026-09-13 this sweep
        deleted that CR on the next tick -- one second after the webhook
        on the first real cluster -- which killed the driver mid-shutdown
        and, with it, the driver log of EVERY successful run, while a
        failed run's CR and log stayed for ``completed_cr_ttl_seconds``.
        Two answers to "how long does a finished job's CR stay": 3600s
        declared, ~1s for the common case.  So a completed row gets the
        same ``webhook_grace_seconds`` the reverse case gets (a finished
        CR waiting for its webhook); a CR still live after that is a
        driver that did not exit, and deleting it is right.
        """
        for name, cr in list(crs.items()):
            st = extract_cr_status(cr)
            if classify_cr_state(st.state) in _TERMINAL_PHASES:
                continue  # not live; the reaper owns it
            exec_label = ((cr.get("metadata") or {}).get("labels") or {}).get(
                EXECUTION_ID_LABEL)
            if not exec_label:
                continue
            row = self._db.get_feed_execution_by_exec_id(exec_label)
            if row is None:
                continue  # unknown to this DB — leave it alone
            status = (row.get("status") or "").lower()
            if status in ACTIVE_ROW_STATES:
                continue
            if status == "completed" and self._within_exit_grace(row, cr):
                continue
            self._delete_cr_and_secret(name, self._shape_of(cr, row))
            counters["cancels_propagated"] += 1
            logger.info(
                "[spark_k8s] deleted live SparkApplication %s — its "
                "execution row is already %s", name, row.get("status"),
            )

    def _within_exit_grace(self, row: dict, cr: dict) -> bool:
        """Is this completed row's driver still inside the window it is
        allowed to take to exit on its own?

        Measured from the row's ``completed_at`` (the webhook stamps it);
        a row without one falls back to the CR's creation time -- both
        are durable, so a reconciler restart cannot restart the clock.
        With neither the answer is "not knowable", and the CR is left
        alone: deleting is the destructive action, and the job timeout
        still bounds a CR that never terminates.
        """
        ts = self._parse_iso(row.get("completed_at")) or self._parse_iso(
            ((cr.get("metadata") or {}).get("creationTimestamp")))
        if ts is None:
            return True
        return (self._now() - ts) < int(self._settings.webhook_grace_seconds)

    def _reap(self, crs: Dict[str, dict], counters: dict) -> None:
        """Completed/failed CRs and their credential Secrets must not
        accumulate: a Secret that outlives its job is a credential left
        lying around.  Reap terminal CRs older than the TTL, RELEASE the
        Secret of every run whose row is terminal (at once -- the TTL is
        for the driver log, not the password), then any managed Secret
        whose CR is gone."""
        ttl = int(self._settings.completed_cr_ttl_seconds)
        now = self._now()
        for name, cr in list(crs.items()):
            st = extract_cr_status(cr)
            # Phase, not literal states: an UNRECOGNISED state is
            # possibly-live by declaration and must never be reaped.
            if classify_cr_state(st.state) not in _TERMINAL_PHASES:
                continue
            ts = self._parse_iso(st.termination_time) or self._parse_iso(
                ((cr.get("metadata") or {}).get("creationTimestamp")))
            if ts is None or (now - ts) < ttl:
                continue
            self._delete_cr_and_secret(name, self._shape_of(cr))
            crs.pop(name, None)
            counters["reaped_crs"] += 1
        # Secrets orphaned from their CR (e.g. CR deleted by hand, or a
        # submit that died between Secret and CR creation long ago).
        try:
            secrets = self._api.list_secrets(
                self._settings.namespace, label_selector=MANAGED_BY_SELECTOR)
        except SparkK8sApiError as exc:
            logger.warning("[spark_k8s] secret reap listing failed: %s", exc)
            return
        items = secrets.get("items") or []
        released = self._release_terminal_credentials(items, counters)
        for item in items:
            meta = item.get("metadata") or {}
            name = meta.get("name") or ""
            if not name.startswith("creds-") or name in released:
                continue
            if name[len("creds-"):] in crs:
                continue  # its CR still exists
            created = self._parse_iso(meta.get("creationTimestamp"))
            if created is None or (now - created) < ttl:
                continue
            try:
                self._api.delete_secret(self._settings.namespace, name)
                counters["reaped_secrets"] += 1
            except SparkK8sApiError as exc:
                if exc.status != 404:
                    logger.warning("[spark_k8s] secret reap of %s failed: %s",
                                   name, exc)

    def _release_terminal_credentials(self, items, counters: dict) -> set:
        """Delete the credential Secret of every run whose ROW is terminal
        (completed / failed / cancelled -- anything not pending/running),
        leaving its CR or driver pod for ``completed_cr_ttl_seconds`` so
        the driver log survives.  2026-10-07 (D1): the Secret used to be
        reaped WITH the workload, so the source and destination passwords
        stayed on the cluster for an hour after every run.

        Keyed on the ROW, never on the workload's state: a FAILED CR whose
        row is still active is waiting for a retry, and ``_retry`` reads
        the prior attempt's ``FEED_CONFIG_JSON`` back from this very
        Secret.  The webhook releases it sooner when it can
        (``runner.release_run_credentials``); this pass is the guarantee,
        for every terminal transition and either workload shape -- the
        Secret is the same object for a CR and a driver Pod.  A Secret
        whose execution this DB does not know is left to the TTL reaper,
        exactly as before.  Returns the names released."""
        released: set = set()
        for item in items or ():
            hit = self._terminal_run_secret(item)
            if hit is None:
                continue
            name, exec_label, status = hit
            if not self._delete_secret_now(name):
                continue
            released.add(name)
            counters["released_secrets"] = counters.get(
                "released_secrets", 0) + 1
            logger.info("[spark_k8s] %s is %s -- credential Secret %s "
                        "deleted; its workload stays for the driver log",
                        exec_label, status, name)
        return released

    def _terminal_run_secret(self, item: dict) -> Optional[tuple]:
        """``(secret name, execution label, row status)`` when ``item`` is
        a run's credential Secret AND that run's row is terminal; None for
        anything else (not a creds Secret, no label, unknown to this DB,
        or a row still pending/running)."""
        meta = item.get("metadata") or {}
        name = meta.get("name") or ""
        exec_label = (meta.get("labels") or {}).get(EXECUTION_ID_LABEL)
        if not name.startswith("creds-") or not exec_label:
            return None
        row = self._db.get_feed_execution_by_exec_id(exec_label)
        status = str((row or {}).get("status") or "").lower()
        if row is None or status in ACTIVE_ROW_STATES:
            return None
        return name, exec_label, status

    def _delete_secret_now(self, name: str) -> bool:
        """True when the Secret is gone (deleted, or already absent)."""
        try:
            self._api.delete_secret(self._settings.namespace, name)
        except SparkK8sApiError as exc:
            if exc.status != 404:
                logger.warning("[spark_k8s] credential release of %s failed "
                               "(%s) -- next tick", name, exc)
                return False
        return True

    # ── Small helpers ────────────────────────────────────────────────

    def _delete_cr_and_secret(self, cr_name: str, mode: str) -> None:
        """Delete one workload through the verb of ITS shape (``mode`` =
        the object's stamp or the row's stored shape -- never a fresh
        probe) and its credential Secret."""
        ns = self._settings.namespace
        for op, target in (("cr", cr_name), ("secret", "creds-" + cr_name)):
            try:
                if op == "cr":
                    delete_workload(self._api, ns, target, mode)
                else:
                    self._api.delete_secret(ns, target)
            except SparkK8sApiError as exc:
                if exc.status != 404:
                    raise

    def _row_age_seconds(self, row: dict) -> float:
        started = self._as_dt(row.get("started_at"))
        if started is None:
            return 0.0
        return max(0.0, datetime.now(timezone.utc).timestamp()
                   - started.timestamp())

    @staticmethod
    def _as_dt(value) -> Optional[datetime]:
        if value is None:
            return None
        if isinstance(value, datetime):
            return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
        try:
            dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
            return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
        except ValueError:
            return None

    def _parse_iso(self, value) -> Optional[float]:
        dt = self._as_dt(value)
        return dt.timestamp() if dt is not None else None


# ── Daemon wiring (leader-gated loop) ────────────────────────────────────

_thread_lock = threading.Lock()
_thread: Optional[threading.Thread] = None
_stop = threading.Event()


def start_reconciler(db_manager: Any, *,
                     is_leader_fn: Optional[Callable[[], bool]] = None,
                     api_factory: Optional[Callable[[], Any]] = None) -> bool:
    """Start the reconciler loop thread (idempotent).  Returns True when a
    thread is running after the call.

    Gates, in order, every iteration (not just at start — leadership and
    availability both move at runtime):
      1. scheduler-lease leadership (exactly one pod reconciles),
      2. the availability ladder (each refusal logged with its declared
         reason, rate-limited to once per state change).
    """
    from core.config import spark_k8s as _sk
    if not _sk.enabled:
        logger.info("[spark_k8s] reconciler not started — "
                    "spark_k8s.enabled=false (declared)")
        return False

    global _thread
    with _thread_lock:
        if _thread is not None and _thread.is_alive():
            return True
        _stop.clear()

        if is_leader_fn is None:
            # THE single-runner election (the scheduler LOCK; 2026-10-18 -- the lease
            # made a hybrid api pod a second reconciler beside the scheduler pod)
            from core.daemon_registry import holds_single_runner_role

            def is_leader_fn() -> bool:  # type: ignore[misc]
                return holds_single_runner_role()

        def _loop() -> None:
            from core.spark_k8s import availability as _avail
            from core.spark_k8s.preupgrade import maybe_run_preupgrade_sweep
            api = None
            # ONE reconciler instance for the life of the loop — its
            # _backoff_until/_completed_seen dicts ARE the retry-backoff
            # and webhook-grace memory.  (Closeout P0 2026-08-22: this
            # used to construct a fresh instance per tick, resetting both
            # dicts, so retries and webhook-missing finalization could
            # never fire in production wiring — while every test held one
            # instance and passed.)
            rec: Optional[SparkK8sReconciler] = None
            preupgrade_state: dict = {}
            last_refusal = ""
            while not _stop.is_set():
                settings = settings_from_config()
                interval = max(_MIN_INTERVAL_SECONDS,
                               int(settings.reconcile_interval_seconds))
                try:
                    if not is_leader_fn():
                        _stop.wait(interval)
                        continue
                    av = _avail.current()
                    if not av.available:
                        if av.describe() != last_refusal:
                            logger.warning(
                                "[spark_k8s] reconciler idle — %s",
                                av.describe())
                            last_refusal = av.describe()
                        _stop.wait(interval)
                        continue
                    last_refusal = ""
                    if api is None:
                        if api_factory is not None:
                            api = api_factory()
                        else:
                            from core.spark_k8s.client import make_kube_api
                            api = make_kube_api()
                    if rec is None:
                        rec = SparkK8sReconciler(db_manager, api,
                                                 settings=settings)
                    else:
                        rec.update_settings(settings)
                    counters = rec.tick()
                    if any(counters[k] for k in
                           ("finalized_success", "finalized_failure",
                            "retries", "cancels_propagated", "reaped_crs",
                            "reaped_secrets", "released_secrets")):
                        logger.info("[spark_k8s] reconcile tick: %s", counters)
                    # Pre-upgrade unlabeled CR/Secret sweep — once per
                    # process start, then daily; SparkK8sApiError falls to
                    # the cluster-said-no handler below and retries next
                    # tick (next_due only advances on success).
                    maybe_run_preupgrade_sweep(db_manager, api, settings,
                                               preupgrade_state)
                except SparkK8sApiError as exc:
                    # the cluster said no — transient posture, next tick
                    logger.warning("[spark_k8s] reconcile tick failed at the "
                                   "cluster: %s", exc)
                except SparkK8sUnreachable as exc:
                    # 2026-10-07 (D3) -- nothing answered.  A cluster
                    # condition, not a reconciler bug (it used to land in
                    # the BUG handler below); the routing cache learns it
                    # now rather than at the end of its TTL, and the next
                    # probe brings the loop back when the cluster returns.
                    _avail.mark_unreachable(exc)
                    logger.warning("[spark_k8s] reconcile tick could not "
                                   "reach the cluster: %s -- idle until it "
                                   "answers", exc)
                except Exception:
                    # OUR code is wrong — say so, loudly, and keep the
                    # supervisor alive so one bug can't kill the fleet's
                    # only reconciler.
                    logger.error(
                        "[spark_k8s] reconciler BUG (not an infra "
                        "condition):", exc_info=True)
                _stop.wait(interval)

        _thread = threading.Thread(target=_loop, name="spark-k8s-reconciler",
                                   daemon=True)
        _thread.start()
        logger.info("[spark_k8s] reconciler loop started (leader-gated)")
        return True


def stop_reconciler() -> None:
    """Test/shutdown hook."""
    global _thread
    with _thread_lock:
        _stop.set()
        _thread = None


def register_reconciler_daemon(scheduler, db_manager) -> None:
    """daemon_registry-shaped registration (scheduler arg unused — this is
    a service loop, not a cron job; it self-gates on the scheduler lease)."""
    start_reconciler(db_manager)
