"""ONE finaliser for a Spark-lane run the job FINISHED (2026-10-11).

Three defects, found live on the Docker rig the day the lane first ran
the owner's merge feeds and the Starburst-shaped source, all in how a
``spark_k8s`` row is CLOSED:

* **A run whose delivery failed read ``completed``** (P0 class; memory
  ``bug_delivery_failed_run_says_completed_2026_09_15`` -- "one
  chain_verdict, both lanes read it").  The webhook wrote ``status:
  completed`` FIRST and then ran the webhook-side delivery, which
  recorded ``stage_timings.delivery_chain = {verdict: failed}`` and
  ``files_metadata.spark_delivery = {status: not_delivered}`` on a row
  nothing re-read.  Execution 1655: completed, destination_path empty,
  not_delivered.  Now the status is written LAST, from the ONE verdict
  (:func:`delivery_status_update`), on every finaliser.

* **Two finalisers, two answers.**  The webhook's success branch and the
  reconciler's "CR completed, no webhook" path were separate code; the
  reconciler's knew nothing the job reported (rows ``unknown``, no merge
  record, delivery ``unconfirmed``) and under load it won the race often
  enough to lose the audit record (1 of 10 owner-case runs had
  ``cross_source == {}``).  Now the job writes its completion REPORT -- the
  same payload it POSTs to the webhook -- to the driver's Kubernetes
  termination message (``/dev/termination-log``;
  ``generic_feed.write_termination_report``), which survives the driver
  and is read from the pod's ``containerStatuses[].state.terminated.
  message`` (:func:`job_report_lookup`).  BOTH finalisers hand that
  report to :func:`finalize_success`: the webhook with its body, the
  reconciler with what it read from the pod.  One writer of the report,
  one reader path, one status decision.

* The reconciler's no-report path (an older image, a message the kubelet
  did not keep) stays honest: rows unknown, completeness UNVERIFIED --
  and a chain-declared feed whose chain NEVER RAN is a FAILED run, not a
  completed one (the reconciler applies that there).

The kubelet keeps the LAST 4096 bytes of the termination file, so the job
writes at most :data:`JOB_REPORT_MAX_BYTES` and trims by priority
(``generic_feed._compact_report``): the counts, the verdict and the merge
record outlive the receipt's prose.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, Mapping, Optional

from core.spark_k8s.errors import SparkK8sApiError

logger = logging.getLogger(__name__)

#: The kubelet keeps the LAST 4096 bytes of ``/dev/termination-log``; the
#: job writes at most this many so the head (execution_id, state) survives.
JOB_REPORT_MAX_BYTES = 4000
#: The driver container's name under the spark-operator and in our own
#: driver-pod manifest (core/spark_k8s/manifest.py).
DRIVER_CONTAINER = "spark-kubernetes-driver"
#: What ``files_metadata.spark_k8s.report`` says when the reconciler
#: finalised from the pod's termination message.
REPORT_SOURCE_TERMINATION_MESSAGE = "driver termination message"


def driver_pod_name_for(external_job_id: str, mode: str) -> str:
    """The pod that ran the driver for a workload name: the operator
    derives ``{name}-driver`` from a SparkApplication; in driver_pod
    mode the workload IS the pod.  ``mode`` is the row's STORED shape
    (``stored_submit_mode``), never today's config -- under ``auto`` the
    two can differ for a run submitted before the operator changed."""
    from core.spark_k8s.manifest import SUBMIT_MODE_POD
    return external_job_id if mode == SUBMIT_MODE_POD else f"{external_job_id}-driver"


#: What a pod read said about the report (``JobReportLookup.status``).
LOOKUP_FOUND = "found"                   # the report, parsed
LOOKUP_NOT_TERMINATED = "not_terminated"  # the driver container has not exited yet: UNKNOWN, re-read
LOOKUP_NO_MESSAGE = "no_message"         # terminated, nothing parseable written: ABSENT (an older image)
LOOKUP_POD_MISSING = "pod_missing"       # the pod is gone: ABSENT
LOOKUP_NO_NAME = "no_name"               # the row names no workload: ABSENT
#: The statuses that mean "there is no report to wait for".
LOOKUP_ABSENT = frozenset({LOOKUP_NO_MESSAGE, LOOKUP_POD_MISSING, LOOKUP_NO_NAME})


class JobReportLookup:
    """One pod read, judged: ``report`` (a dict when ``found``) and
    ``status`` (one of the ``LOOKUP_*`` words).  "The container has not
    terminated" is UNKNOWN -- a report may still appear -- and is a
    different answer from "terminated with no report", which is ABSENT.
    The two used to collapse into one ``None`` (2026-10-11)."""

    __slots__ = ("status", "report", "detail")

    def __init__(self, status: str, report: Optional[Dict[str, Any]] = None,
                 detail: str = ""):
        self.status = status
        self.report = report
        self.detail = detail

    @property
    def absent(self) -> bool:
        return self.status in LOOKUP_ABSENT


def _pod_field(obj: Mapping[str, Any], camel: str, snake: str) -> Any:
    """The real client hands back ``V1Pod.to_dict()`` -- SNAKE_CASE keys
    (``container_statuses``, ``exit_code``) -- while a raw API object and
    ``kubectl get -o json`` spell them camelCase.  Found live (executions
    2008/2009): the reader knew only camelCase, so a pod whose termination
    message plainly carried the report read as "absent"."""
    if not isinstance(obj, Mapping):
        return None
    v = obj.get(camel)
    return v if v is not None else obj.get(snake)


def job_report_lookup(pod: Mapping[str, Any]) -> JobReportLookup:
    """Judge a driver pod object: the report, or WHY there is none."""
    statuses = list(_pod_field((pod or {}).get("status") or {},
                               "containerStatuses", "container_statuses") or [])
    if not statuses:
        return JobReportLookup(LOOKUP_NOT_TERMINATED, detail="no container statuses yet")
    statuses.sort(key=lambda c: 0 if (c or {}).get("name") == DRIVER_CONTAINER else 1)
    terminated_seen = False
    for cs in statuses:
        state = (cs or {}).get("state") or {}
        term = state.get("terminated") if isinstance(state, Mapping) else None
        if not term:
            continue
        terminated_seen = True
        msg = term.get("message")
        if not isinstance(msg, str) or not msg.strip():
            continue
        try:
            data = json.loads(msg)
        except ValueError:
            if len(msg) >= JOB_REPORT_MAX_BYTES:
                logger.warning(
                    "[spark_k8s] the driver's termination message (%d bytes) is not "
                    "JSON -- the kubelet keeps the last 4096 bytes, so a report over "
                    "%d bytes lost its head; the job trims to that budget "
                    "(generic_feed._compact_report)", len(msg), JOB_REPORT_MAX_BYTES)
            continue
        if isinstance(data, dict) and data.get("execution_id") and data.get("state"):
            return JobReportLookup(LOOKUP_FOUND, data)
    if terminated_seen:
        return JobReportLookup(LOOKUP_NO_MESSAGE, detail="the driver terminated without a report")
    return JobReportLookup(LOOKUP_NOT_TERMINATED, detail="the driver container has not terminated")


def lookup_job_report(api: Any, namespace: str, external_job_id: str,
                      mode: str) -> JobReportLookup:
    """One ``pods`` GET of the driver, judged.  A pod that is gone (404) is
    ABSENT; any other refusal propagates (``SparkK8sApiError``) so the tick
    retries instead of finalising blind."""
    if not external_job_id:
        return JobReportLookup(LOOKUP_NO_NAME, detail="the row names no workload")
    name = driver_pod_name_for(str(external_job_id), mode)
    try:
        pod = api.get_pod(namespace, name)
    except SparkK8sApiError as exc:
        if getattr(exc, "status", None) == 404:
            return JobReportLookup(LOOKUP_POD_MISSING, detail=f"pod {name!r} not found")
        raise
    return job_report_lookup(pod or {})


def read_job_report(api: Any, namespace: str, external_job_id: str,
                    mode: str) -> Optional[Dict[str, Any]]:
    """The report or None -- for a caller that does not distinguish
    "not yet" from "never" (the failure path, where the pod has exited)."""
    return lookup_job_report(api, namespace, external_job_id, mode).report


# ── the callback's durable claim ──────────────────────────────────────────

def finalize_from_report(db: Any, execution: Mapping[str, Any], report: Mapping[str, Any],
                         *, via: str) -> Dict[str, Any]:
    """Close the row from a report by its ``state`` -- success or failure
    through the ONE finaliser each -- and stamp the claim row
    (``spark_job_reports``) as finalised.  Never raises: the claim records
    the error instead, so the reconciler can see a finalisation that
    crashed and nothing is left half-done in silence."""
    exec_id = str(execution.get("execution_id") or report.get("execution_id") or "")
    state = str(report.get("state") or "").lower()
    error: Optional[str] = None
    final: Dict[str, Any] = {}
    try:
        if state == "success":
            final = finalize_success(db, execution, report, via=via)
        elif state in ("failed", "error"):
            final = finalize_failure(db, execution, report, via=via)
        else:
            error = f"report state {state!r} is not terminal -- nothing finalised"
            logger.warning("[spark_k8s] %s: %s", exec_id, error)
    except Exception as exc:                        # noqa: BLE001 -- recorded on the claim
        error = f"{type(exc).__name__}: {exc}"[:2000]
        logger.exception("[spark_k8s] %s: finalisation from the %s report failed", exec_id, via)
    marker = getattr(db, "mark_spark_job_report_finalized", None)
    if callable(marker):
        try:
            marker(exec_id, via, error)
        except Exception as exc:                    # noqa: BLE001 -- the row is closed; the stamp is bookkeeping
            logger.warning("[spark_k8s] %s: the report claim could not be stamped: %s", exec_id, exc)
    return final


def _as_int(v: Any) -> Optional[int]:
    return int(v) if isinstance(v, int) and not isinstance(v, bool) else None


def _fresh(db: Any, execution: Mapping[str, Any]) -> Dict[str, Any]:
    try:
        return dict(db.get_feed_execution(execution["id"]) or {})
    except Exception as exc:                        # noqa: BLE001 -- the snapshot is the fallback
        logger.warning("[spark_k8s] %s: fresh row unreadable (%s) -- using the snapshot",
                       execution.get("execution_id"), exc)
        return dict(execution)


def _merge_files_metadata(db: Any, execution: Mapping[str, Any],
                          fragment: Mapping[str, Any]) -> None:
    """RE-READ, never merge into a stale snapshot (2026-09-21): the
    engine's spark_k8s lane, awaiting this very completion, writes its own
    files_metadata onto the same row meanwhile."""
    fresh = _fresh(db, execution)
    fm = dict(fresh.get("files_metadata") or execution.get("files_metadata") or {})
    fm.update(fragment)
    db.update_feed_execution(execution["id"], {"files_metadata": fm})


#: ``files_metadata.spark_k8s.report`` when the report came in the callback.
REPORT_SOURCE_WEBHOOK = "completion webhook"
#: ... when the reconciler finished a callback's claim the API pod never did.
REPORT_SOURCE_CLAIM = "callback claim (finalised by the reconciler)"
#: The stage a Spark failure is booked at when nothing names a better one
#: (the engine's own stage word for this lane).
QUERY_STAGE = "query_spark_k8s"
#: The stage named when the job REFUSED on its reported-rows certification
#: (the native lane's stage word, core/feed/steps_view.py).
CERTIFY_STAGE = "certify_reported_rows"
_TERMINAL = frozenset({"completed", "failed", "cancelled"})


def failure_stage_for_report(report: Optional[Mapping[str, Any]]) -> str:
    """THE stage a failed Spark run is booked at, decided from the record's
    own verdict -- never from a stage string the job sends: a refused
    reported-rows certification (failures listed, or verdict mismatch /
    unreadable) is ``certify_reported_rows``, everything else the query
    stage."""
    rr = (report or {}).get("reported_rows_certification")
    if isinstance(rr, dict) and (rr.get("failures")
                                 or rr.get("verdict") in ("mismatch", "unreadable")):
        return CERTIFY_STAGE
    return QUERY_STAGE


def finalize_failure(db: Any, execution: Mapping[str, Any],
                     report: Optional[Mapping[str, Any]], *, via: str,
                     cr_state: Optional[str] = None, cr_error: Optional[str] = None,
                     classification: Optional[str] = None,
                     now: Optional[datetime] = None) -> Dict[str, Any]:
    """Close a ``spark_k8s`` row as FAILED from the job's report -- the
    webhook's body or the pod's termination message -- the SAME way on
    every road (2026-10-11).

    Found live (execution 1964): the reconciler saw the SparkApplication
    FAILED and wrote its own generic line; the webhook's failed branch had
    its own, richer record; and the engine's handler, when its await saw
    the row failed, re-wrote ``stage_timings`` from its own dict -- so the
    job's headline, its detail and its reported-rows record were simply
    gone.  Three writers, three answers.  Now: ONE headline
    (``failure_text.describe_job_failure`` over the job's ``error`` when
    there is a report, else the cluster's words), the detail kept under
    ``stage_timings.spark_job_failure``, the reported-rows record under its
    native key with the stage named from ITS verdict, and
    ``files_metadata.spark_k8s`` saying who closed the row and from what.
    Whoever writes first wins: a row already terminal is left alone and
    ``{}`` is returned.  ``classification`` is the reconciler's verdict
    text (``declared non-retryable; classification=...``), appended so an
    operator still sees why no retry followed."""
    from core.feed.reported_rows_certification import RECORD_KEY
    from core.spark_k8s.failure_text import (
        describe_job_failure, executors_lost_sentence, failure_detail, feed_connection_type,
    )
    now = now or datetime.now(timezone.utc)
    exec_id = str(execution.get("execution_id") or "")
    fresh = _fresh(db, execution)
    if str(fresh.get("status") or "").lower() in _TERMINAL:
        logger.info("[spark_k8s] %s is already %s -- the first finaliser's record "
                    "stands (%s did not write)", exec_id, fresh.get("status"), via)
        return {}
    report = dict(report) if isinstance(report, Mapping) else None
    raw_text = str((report or {}).get("error") or "")
    text = raw_text.strip()
    ct = feed_connection_type(db, execution.get("feed_config_id"))
    st = dict(fresh.get("stage_timings") or {})
    if text:
        headline = describe_job_failure(text, ct) or f"External system reported: {report.get('state') or 'failed'}"
        # the detail is the report AS SENT (the whole stack, byte for byte)
        # what Spark removed while it ran LEADS the headline: the innermost
        # exception of a job whose executors were OOM-killed is only "the
        # context was shut down" (2026-10-14)
        _lost = (report or {}).get("executors_lost")
        _lost_words = executors_lost_sentence(_lost)
        if _lost_words:
            headline = f"{_lost_words}; then: {headline}"
        st["spark_job_failure"] = {"headline": headline, "detail": failure_detail(raw_text),
                                   "reported_by": "job", "via": via,
                                   **({"executors_lost": list(_lost)} if _lost_words else {})}
        source = REPORT_SOURCE_WEBHOOK if via == "webhook" else REPORT_SOURCE_TERMINATION_MESSAGE
        if cr_state or cr_error:
            headline = f"{headline} [spark_k8s {cr_state or 'FAILED'}: {cr_error or '(no errorMessage on the CR)'}]"
    elif cr_state or cr_error:
        headline = f"spark_k8s {cr_state or 'FAILED'}: {cr_error or '(no errorMessage on the CR)'}"
        source = "absent"
    else:
        headline = f"External system reported: {(report or {}).get('state') or 'failed'}"
        source = "absent"
    if classification:
        headline = f"{headline} [{classification}]"
    rr = (report or {}).get("reported_rows_certification")
    if isinstance(rr, dict) and rr:
        st[RECORD_KEY] = dict(rr)
    fm = dict(fresh.get("files_metadata") or {})
    prior = fm.get("spark_k8s") if isinstance(fm.get("spark_k8s"), dict) else {}
    fm["spark_k8s"] = {**prior, "finalized": "failed", "via": via, "report": source}
    update: Dict[str, Any] = {
        "status": "failed",
        "completed_at": now,
        "error_message": headline[:2000],
        "failed_stage": failure_stage_for_report(report),
        "stage_timings": st,
        "files_metadata": fm,
    }
    db.update_feed_execution(execution["id"], update)
    logger.error("[spark_k8s] %s FAILED (%s): %s", exec_id, via, update["error_message"])
    _close_handed_steps(db, execution, update, report, via)
    return update


def delivery_status_update(fresh_row: Mapping[str, Any], feed_config: Optional[Mapping[str, Any]],
                           *, now: datetime) -> Dict[str, Any]:
    """THE terminal status of a run QueryStudio delivered on the job's
    behalf, read from the ONE verdict the hop runner recorded
    (``stage_timings.delivery_chain``, written by
    ``feed_engine.deliver_completed_spark_run`` through
    ``delivery_hops.chain_verdict``) -- the same rule the native engine
    applies when it raises ``DeliveryChainFailed``.

    delivered / suppressed -> ``completed`` (a suppressed run completes
    undelivered by design, FR-DEL-06); failed, or NO verdict recorded ->
    ``failed`` at ``deliver_<destination>`` with the chain's reason as the
    sentence (unknown is unsafe: a delivery nobody can vouch for is not
    a completed run).  Native's framing: ``Feed N @ stage='deliver_x': ...``.
    """
    from core.feed.delivery_hops import CHAIN_DELIVERED, CHAIN_SUPPRESSED
    st = fresh_row.get("stage_timings") if isinstance(fresh_row.get("stage_timings"), dict) else {}
    chain = st.get("delivery_chain") if isinstance(st.get("delivery_chain"), dict) else {}
    verdict = str(chain.get("verdict") or "").lower()
    if verdict in (CHAIN_DELIVERED, CHAIN_SUPPRESSED):
        return {"status": "completed", "completed_at": now}
    dest = str((feed_config or {}).get("destination_type") or "local").strip().lower() or "local"
    stage = f"deliver_{dest}"
    reason = chain.get("reason") if chain else None
    if not reason:
        sd = ((fresh_row.get("files_metadata") or {}).get("spark_delivery") or {})
        reason = sd.get("reason") or (
            "the webhook-side delivery recorded no verdict -- nothing is known "
            "to have reached the counterparty; re-deliver the stored artifacts, "
            "do not re-generate")
    fid = fresh_row.get("feed_config_id") or (feed_config or {}).get("id")
    return {
        "status": "failed",
        "completed_at": now,
        "failed_stage": stage,
        "error_message": f"Feed {fid} @ stage='{stage}': {str(reason)[:1800]}",
    }


def finalize_success(db: Any, execution: Mapping[str, Any], report: Mapping[str, Any],
                     *, via: str, now: Optional[datetime] = None) -> Dict[str, Any]:
    """Close a ``spark_k8s`` row from the job's SUCCESS report -- the webhook's
    body or the pod's termination message, the same dict either way.

    In order: what the job reported (rows, bytes, where it delivered, the
    job-side delivery verdict + receipt, the merge record); the server-side
    completeness verification (Flow B); the webhook-side delivery when the
    job wrote artifacts only; and LAST the status, by the one verdict.
    Returns the final status update applied.  Never raises for a
    verification or delivery failure (the job does not retry its callback;
    a refused delivery is a FAILED row, not a 500) -- a programming error
    propagates.
    """
    from core.feed.merge_by_name import CROSS_SOURCE_KEY
    from core.feed_engine import should_deliver_from_webhook

    now = now or datetime.now(timezone.utc)
    exec_id = str(execution.get("execution_id") or "")
    # Whoever writes first wins (2026-10-11): a row another finaliser
    # closed is left alone -- the webhook's off-request finalisation and
    # the reconciler's can now both hold the same report.
    if str(_fresh(db, execution).get("status") or "").lower() in _TERMINAL:
        logger.info("[spark_k8s] %s is already terminal -- the first finaliser's "
                    "record stands (%s did not write)", exec_id, via)
        return {}
    backend = str(execution.get("execution_backend") or "").lower()
    delivered_by_job = not should_deliver_from_webhook(report.get("delivered"))
    output_path = report.get("output_path") or execution.get("destination_path")
    rows = _as_int(report.get("output_row_count"))

    update_data: Dict[str, Any] = {"delivery_completed_at": now}
    if report.get("output_path") and delivered_by_job:
        # Where it WENT -- only when the job itself delivered.  A job that
        # wrote artifacts only reports its ARTIFACT STORE here, which is not
        # a destination; the webhook-side delivery records where the hops
        # put it (2026-10-07: a suppressed Spark backfill read as "delivered
        # to s3a://<artifact store>").
        update_data["destination_path"] = report["output_path"]
        # 2026-10-13 -- and WHICH FILE: the native lane records the name it
        # rendered; a job-delivered run left it empty, so the board's
        # delivery history said "file: none" for the owner's 1M month end
        # delivered by a Spark pod.
        if not execution.get("output_filename"):
            _name = str(report["output_path"]).rstrip("/").rsplit("/", 1)[-1]
            if _name:
                update_data["output_filename"] = _name
    if backend == "spark_k8s" and delivered_by_job and execution.get("delivery_suppressed"):
        logger.error(
            "[spark_k8s] %s: the run was SUPPRESSED (stored on the execution) but "
            "the Spark job reports it DELIVERED -- the job image predates "
            "suppress_delivery (spark/jobs/generic_feed.py); rebuild and roll the "
            "spark_k8s image. Recorded as delivered, because it was.", exec_id)
    if rows is not None:
        update_data["total_rows"] = rows
    if _as_int(report.get("output_size_bytes")) is not None:
        update_data["file_size_bytes"] = int(report["output_size_bytes"])
    if (backend in ("spark_k8s", "airflow") and delivered_by_job
            and report.get("lane_output_version") is None):
        logger.error(
            "[spark_k8s] %s: the Spark job image predates the feed lane contract "
            "(no lane_output_version in its report) -- its file was rendered by "
            "Spark's writer, not the native rules; rebuild and roll the spark_k8s "
            "image (spark/Dockerfile).", exec_id)
    if backend == "spark_k8s" and delivered_by_job:
        # 2026-10-03 -- the DELIVERY VERDICT in the slot every reader checks
        # (stage_timings.delivery_chain): the job's report that IT delivered
        # IS the verdict.  Merged over a FRESH read.
        st = dict(_fresh(db, execution).get("stage_timings") or {})
        st["delivery_chain"] = {
            "verdict": "delivered", "reason": None, "reported_by": "job",
            "detail": ("the Spark job delivered in-pod and reported success "
                       f"through its completion report ({via})")}
        st["artifact"] = {
            "retrievable": False, "path": None,
            "reason": (f"the Spark job delivered in-pod to "
                       f"{report.get('output_path') or 'its destination'}; QueryStudio "
                       f"holds no copy of the file (spark_k8s pod-side delivery)")}
        receipt = report.get("delivery_receipt")
        if isinstance(receipt, dict):
            st["delivery_verification"] = {
                "status": str(receipt.get("verification") or "absent"),
                "detail": str(receipt.get("verification_detail") or ""),
                "reported_by": "job",
            }
        delivered_rows = _as_int(report.get("delivered_rows"))
        if delivered_rows is not None:
            dropped = _as_int(report.get("dropped_rows")) or 0
            st["delivery_verification"] = {
                "status": "verified",
                "detail": (f"destination row accounting (reported by the job): "
                           f"{delivered_rows}/{rows} inserted, {dropped} rejected"),
                "delivered_rows": delivered_rows,
            }
            if dropped:
                st["delivery_verification"]["dropped_rows"] = dropped
                logger.warning(
                    "[spark_k8s] %s: destination REJECTED %s rows (delivered %s) "
                    "under max_error_percent -- the certificate reconciles against "
                    "the destination count", exec_id, dropped, delivered_rows)
        update_data["stage_timings"] = st
    db.update_feed_execution(execution["id"], update_data)

    # The per-side REPORTED-ROWS certification (2026-10-11), in the native
    # lane's slot (stage_timings), whichever finaliser closes the row --
    # the webhook body and the termination message carry the same field.
    rr = report.get("reported_rows_certification")
    if isinstance(rr, dict) and rr:
        try:
            from core.feed.reported_rows_certification import RECORD_KEY as _RR_KEY
            st_rr = dict(_fresh(db, execution).get("stage_timings") or {})
            st_rr[_RR_KEY] = dict(rr)
            db.update_feed_execution(execution["id"], {"stage_timings": st_rr})
        except Exception as exc:                # noqa: BLE001 -- recorded, never a 500
            logger.error("[spark_k8s] %s: the job's reported-rows certification could "
                         "not be stored (%s)", exec_id, exc)

    # The merge record (2026-10-10), in the native lane's slot.
    xs = report.get(CROSS_SOURCE_KEY)
    if isinstance(xs, dict) and xs:
        try:
            _merge_files_metadata(db, execution, {CROSS_SOURCE_KEY: dict(xs)})
        except Exception as exc:                    # noqa: BLE001 -- recorded, never a 500
            logger.error("[spark_k8s] %s: the job's cross-source merge record could not "
                         "be stored (%s)", exec_id, exc)

    # How each side was read by partition key (2026-10-14), in the native slot.
    pr = report.get("partitioned_read")
    if isinstance(pr, dict) and pr:
        try:
            _merge_files_metadata(db, execution, {"partitioned_read": dict(pr)})
        except Exception as exc:                    # noqa: BLE001 -- recorded, never a 500
            logger.error("[spark_k8s] %s: the job's partitioned-read record could not "
                         "be stored (%s)", exec_id, exc)

    # Flow-B completeness verification (2026-08-05): the delivered output
    # recounted server-side through the SAME certificate pipeline Flow A
    # uses.  Fail-open: verification never turns a finished run into an
    # error, the certificate itself fails closed to UNVERIFIED.
    try:
        from core.feed_perf import verify_webhook_completion
        fm_add = verify_webhook_completion(
            execution_id=exec_id, subject_id=execution["id"],
            output_path=output_path, reported_rows=rows,
            destination_rows=report.get("delivered_rows"),
            delivery_receipt=report.get("delivery_receipt"))
        if fm_add:
            _merge_files_metadata(db, execution, fm_add)
    except Exception as exc:                        # noqa: BLE001
        logger.warning("[spark_k8s] completion verification failed for %s (the "
                       "completion still lands): %s", exec_id, exc)

    if delivered_by_job:
        final = {"status": "completed", "completed_at": now}
        db.update_feed_execution(execution["id"], final)
        _close_handed_steps(db, execution, final, report, via)
        return final

    # H1 step B (2026-09-02): QueryStudio delivers when the job did not.
    # ``delivered is False`` is the EXPLICIT report; None (an older image)
    # means it delivered and nothing runs here.
    feed_config: Optional[Dict[str, Any]] = None
    try:
        from core import feed_engine as fe
        feed_config = db.get_feed_config(execution.get("feed_config_id")) or {}
        outcomes = fe.deliver_completed_spark_run(
            db, dict(execution), feed_config, output_path=output_path,
            rows=rows, size_bytes=report.get("output_size_bytes"))
        logger.info("[spark_k8s] %s: job wrote artifacts only; QueryStudio ran %d "
                    "delivery hop(s) (%s)", exec_id, len(outcomes or []), via)
    except Exception as exc:                        # noqa: BLE001 -- the verdict below says failed
        logger.error("[spark_k8s] webhook-side delivery for %s failed (%s) -- the "
                     "artifacts are stored; RE-DELIVER, do not re-generate.",
                     exec_id, exc)
    # THE status, LAST, from the one verdict -- a delivery that did not
    # happen is a failed run (2026-10-11; it used to read completed).
    final = delivery_status_update(_fresh(db, execution), feed_config, now=now)
    db.update_feed_execution(execution["id"], final)
    if final.get("status") == "failed":
        logger.error("[spark_k8s] %s: %s", exec_id, final.get("error_message"))
    _close_handed_steps(db, execution, final, report, via)
    return final


def _close_handed_steps(db: Any, execution: Mapping[str, Any], final: Mapping[str, Any],
                        report: Optional[Mapping[str, Any]], via: str) -> None:
    """The step rows the engine HANDED to the job at submit are closed from
    this finaliser's verdict (2026-10-18, core/feed/step_model/detached.py):
    completed with the job's evidence, or the failed step named and the
    rest not reached.  The same call on every road (webhook body, pod
    report, persisted claim); bookkeeping, never a finaliser failure."""
    try:
        from core.feed.step_model.detached import close_from_job
        close_from_job(db, _fresh(db, execution), final=final, report=report or {}, via=via)
    except Exception as exc:                            # noqa: BLE001
        logger.error("[spark_k8s] %s: the handed step rows were not closed (%s)",
                     execution.get("execution_id"), exc)
