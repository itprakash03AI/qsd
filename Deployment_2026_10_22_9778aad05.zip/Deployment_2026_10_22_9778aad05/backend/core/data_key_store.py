"""The data keys of envelope encryption, in the database (2026-10-17).

``core/crypto.py`` decides; this module only reads and writes the
``encryption_data_keys`` rows (``core.db.models.EncryptionDataKey``).  Every
write is small (a handful of rows, never a stored secret) and the one that
must not race -- the FIRST bootstrap -- runs under a PostgreSQL advisory lock
and only when the table is still empty, so two API containers starting
together cannot each create their own data keys.
"""
from __future__ import annotations

import logging
import socket
from datetime import datetime, timezone
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

#: pg_advisory_xact_lock key for every data-key write (an arbitrary constant)
_LOCK_KEY = 7_311_017_2026


def _who() -> str:
    try:
        return socket.gethostname()[:120]
    except Exception:                                        # noqa: BLE001
        return "unknown"


class DataKeyStore:
    """Rows of ``encryption_data_keys`` for one database."""

    def __init__(self, db):
        self._db = db

    # ── read ────────────────────────────────────────────────────────────
    def list(self) -> List[Dict[str, Any]]:
        from core.db.models import EncryptionDataKey as K
        with self._db.get_session(read_only=True) as s:
            rows = s.query(K).order_by(K.id).all()
            return [{"key_id": r.key_id, "wrapped": r.wrapped, "wrapped_by": r.wrapped_by,
                     "state": r.state, "origin": r.origin} for r in rows]

    # ── write ───────────────────────────────────────────────────────────
    def _locked(self, session) -> None:
        try:
            if session.bind is not None and session.bind.dialect.name == "postgresql":
                from sqlalchemy import text
                session.execute(text("SELECT pg_advisory_xact_lock(:k)"), {"k": _LOCK_KEY})
        except Exception as exc:                             # noqa: BLE001
            logger.warning("[encryption-key] advisory lock not taken (%s); the empty-table "
                           "check still guards the bootstrap", exc)

    def bootstrap(self, rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Insert ``rows`` ONLY when the table is empty, under the lock; return
        the table as it is afterwards (ours if we won, the other API's if we
        lost the race -- never both)."""
        from core.db.models import EncryptionDataKey as K
        with self._db.get_session() as s:
            self._locked(s)
            if s.query(K).count() == 0:
                for r in rows:
                    s.add(K(key_id=r["key_id"], wrapped=r["wrapped"], wrapped_by=r["wrapped_by"],
                            state=r["state"], origin=r.get("origin", "generated"), created_by=_who()))
                logger.warning("[encryption-key] data keys created: %s",
                               ", ".join(f"{r['key_id']} ({r['state']}, {r.get('origin')})" for r in rows))
        return self.list()

    def rewrap(self, key_id: str, wrapped: str, wrapped_by: str) -> None:
        from core.db.models import EncryptionDataKey as K
        with self._db.get_session() as s:
            self._locked(s)
            row = s.query(K).filter(K.key_id == key_id).first()
            if row is not None and row.wrapped_by != wrapped_by:
                row.wrapped, row.wrapped_by = wrapped, wrapped_by
                row.rewrapped_at = datetime.now(timezone.utc)

    def add_active(self, row: Dict[str, Any]) -> List[Dict[str, Any]]:
        """A data-key rotation: ``row`` becomes the ONE active key, every other
        key is retired (still decrypts what it encrypted)."""
        from core.db.models import EncryptionDataKey as K
        with self._db.get_session() as s:
            self._locked(s)
            for old in s.query(K).filter(K.state == "active").all():
                old.state = "retired"
            s.add(K(key_id=row["key_id"], wrapped=row["wrapped"], wrapped_by=row["wrapped_by"],
                    state="active", origin=row.get("origin", "generated"), created_by=_who()))
        return self.list()
