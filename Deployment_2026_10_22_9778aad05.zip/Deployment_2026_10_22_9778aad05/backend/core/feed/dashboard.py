"""The feed DASHBOARD -- runs for a business date, GROUPED by the defined
Feed Groups (2026-10-12, owner request R1: "look at how the OTG UI looks --
per system entity grouped, and per entity the business-event tasks with
their cloud and on-prem dependencies").

Nothing is hardcoded about what a group is: a group is a DEFINED Feed Group
(``feed_configs.feed_group_id``), which a template's group rule
(``feed_group_name: "{SYSTEM_ENTITY}"``) fills for every member, auto-
onboarded ones included.  A feed in no group is listed under ``No group``.

This module COMPOSES what is already recorded -- the date's runs, the feed
groups, each run's step rows (latest attempt), the variance holds -- into
one answer; it decides nothing new.  The task's dependency cards and steps
are read on demand from the routes that already answer them
(``task_detail``: the gate's verdicts + the arrivals on the ledger).

Status words, one per run, in the OTG's vocabulary:
  completed    the run completed and its file went (or a hold was released)
  held         completed, the file KEPT for the release group (variance hold)
  in_progress  running
  failed       failed / cancelled, or a held file was REJECTED
  not_started  pending, held at the dependency gate (WAIT)
  queued       pending, admitted (RUN) -- waiting for a worker slot
  skipped      the run's ACTION_CONDITION said SKIP
"""
from __future__ import annotations

import logging
from datetime import date
from typing import Any, Dict, Iterable, List, Mapping, Optional

logger = logging.getLogger(__name__)

STATUSES = ("completed", "held", "in_progress", "failed", "not_started", "queued", "skipped")
NO_GROUP = {"id": None, "name": "No group", "display_label": "No group"}
GROUP_BY = ("feed_group", "template", "status", "none")
STATUS_WORDS = {"failed": "Failed", "held": "Held for verification", "in_progress": "In progress",
                "not_started": "Waiting on dependencies", "queued": "Queued", "completed": "Completed",
                "skipped": "Skipped"}
STATUS_ORDER = {"failed": 0, "held": 1, "in_progress": 2, "not_started": 3, "queued": 4,
                "completed": 5, "skipped": 6}
#: a variance hold that still holds the file (core/feed/variance_hold.py
#: OPEN_STATUSES plus the moment of release)
OPEN_HOLD_STATUSES = ("held", "release_failed", "releasing")
#: how many missing feeds the answer NAMES (the count is always whole)
MISSING_SHOWN = 25


def task_status(run: Mapping[str, Any], hold: Optional[Mapping[str, Any]] = None) -> str:
    st = str(run.get("status") or "").lower()
    decision = str(run.get("action_decision") or "").upper()
    if hold is not None:
        hs = str(hold.get("status") or "")
        if hs in ("held", "release_failed", "releasing"):
            return "held"
        if hs == "rejected":
            return "failed"
    if st == "running":
        return "in_progress"
    if st == "completed":
        return "completed"
    if st in ("failed", "cancelled", "error"):
        return "failed"
    if decision == "SKIP" or st == "skipped":
        return "skipped"
    if st == "pending":
        return "not_started" if decision == "WAIT" else "queued"
    return "not_started"


def side_facts(ex: Mapping[str, Any]) -> Dict[str, Any]:
    """One execution's CLOUD (primary) / ON-PREM (secondary) story, from what
    the engine RECORDED -- the merge record (``cross_source``: rows per side),
    the per-side certification (read vs the message's ROW_COUNT) and
    ``failed_side``.  Nothing inferred from error text.  ``combined`` False
    for a single-source run (then only ``total``)."""
    st = ex.get("stage_timings") or {}
    fm = ex.get("files_metadata") or {}
    xs = (fm.get("cross_source") if isinstance(fm, dict) else None) or st.get("cross_source") or {}
    cert = st.get("reported_rows_certification") or {}
    csides = cert.get("sides") or {}
    out: Dict[str, Any] = {"total": ex.get("total_rows"), "status": ex.get("status"),
                           "failed_stage": ex.get("failed_stage"),
                           "failed_side": st.get("failed_side"),
                           "certification": cert.get("verdict"),
                           "combined": bool(xs) or bool(csides.get("secondary"))}
    # 2026-10-12 (the owner: "how come it becomes green if the count did not
    # match") -- the CHECKS' verdicts, not just "the step ran": the row-count
    # check's outcome as recorded, and whether the run was certified against
    # the upstream counts at all
    rc = st.get("row_count_check") if isinstance(st.get("row_count_check"), dict) else {}
    out["row_count_check"] = ({"breach": bool(rc.get("breach")), "action": rc.get("action"),
                               "skipped": bool(rc.get("skipped")), "skipped_reason": rc.get("skipped_reason"),
                               "delta_pct": rc.get("delta_pct"), "baseline_avg": rc.get("baseline_avg"),
                               "threshold_pct": rc.get("threshold_pct"), "direction": rc.get("direction"),
                               "reason": rc.get("reason"), "expect_zero": bool(rc.get("expect_zero"))}
                              if rc else None)
    out["certified"] = cert.get("verdict")
    for side, rows_key in (("primary", "primary_rows"), ("secondary", "secondary_rows")):
        c = csides.get(side) or {}
        read = xs.get(rows_key)
        if read is None:
            read = c.get("actual_rows")
        out[side] = {"rows": read, "reported": c.get("reported_rows"),
                     "verdict": c.get("verdict"), "reason": c.get("reason"),
                     "dependency": c.get("dependency")}
    return out


def off_the_board(run: Mapping[str, Any], feed: Optional[Mapping[str, Any]]) -> bool:
    """The board (and the SLA board) is the OPERATIONAL view of ACTIVE feeds
    (2026-10-12): a deleted / retired feed's tasks -- closed or run -- need no
    operation and leave it; the List and All executions keep them as the
    record.  (A deleted feed's run history crowding the day was what made the
    owner's board unreadable: proof feeds without dependencies, "No group".)"""
    return feed is not None and not feed.get("is_active", True)


def _counts(statuses: Iterable[str]) -> Dict[str, int]:
    out = {s: 0 for s in STATUSES}
    n = 0
    for s in statuses:
        out[s] = out.get(s, 0) + 1
        n += 1
    out["all"] = n
    return out


def calendar_of(feed: Mapping[str, Any]) -> Dict[str, Any]:
    """The business calendar this feed is on and WHERE that comes from
    (2026-10-13, the owner: "hope we use the business calendar per feed"):
    THE answer SOD uses (``SodTaskGenerator.effective_calendar_name``) --
    the feed's own, else its schedule declaration's, else the platform
    default; ``None`` name = no calendar anywhere."""
    from core.feed.sod_generator import SodTaskGenerator
    decl = feed.get("schedule_declaration")
    src = ("feed" if feed.get("calendar_name") else
           "schedule" if isinstance(decl, dict) and decl.get("calendar_name") else "default")
    name = SodTaskGenerator.effective_calendar_name(feed)
    return {"name": name, "from": src if name else None}


#: what a business date IS, per date rule (the words on a row and in the
#: run-date summary; the owner: "somewhere we should show the month-end date")
_RULE_WORDS = {"month_end": "Month end", "daily": "Business day", "workday_n": "Business day {n} of the month",
               "workdays": "Business day of the month", "cron": "Business day", "on_completion_of": "Upstream's date",
               "on_demand": "Business date"}


def date_label(feed: Mapping[str, Any]) -> Dict[str, Any]:
    """The feed's date RULE in a word or two ("Month end", "Business day"):
    the row says "Month end 30 Sep 2026", not just a date."""
    decl = feed.get("schedule_declaration") if isinstance(feed.get("schedule_declaration"), dict) else {}
    kind = str(decl.get("kind") or "")
    # the DATA's date names it first (2026-10-13): a month end run daily or
    # on workday 5 is still "Month end"
    if str(decl.get("business_date") or "") in ("month_end", "previous_month_end"):
        return {"rule": kind or None, "label": "Month end"}
    if not kind:
        return {"rule": None, "label": "Business day"}
    return {"rule": kind, "label": _RULE_WORDS.get(kind, "Business date").format(n=decl.get("n"))}


def _iso(d: Any) -> str:
    return d.isoformat() if hasattr(d, "isoformat") else str(d)


def _as_date(d: Any) -> date:
    return d if isinstance(d, date) else date.fromisoformat(str(d)[:10])


def build(db, business_date: Optional[date], *, visible_feed_ids: Optional[set] = None,
          search: str = "", status: str = "", page: int = 1, page_size: int = 50,
          now=None, group_by: str = "feed_group", run_date: Optional[date] = None,
          act_fn=None) -> Dict[str, Any]:
    """The Feed Run Status board for one business date (the OTG layout) --
    or, with ``run_date`` (2026-10-13, the owner: "one month-end date can
    have multiple run dates ... it should derive from the feed config and the
    calendar"), for one RUN date: every feed on the business date its OWN
    rule and calendar give for that run date
    (``SodTaskGenerator.current_business_date`` -- a month-end feed is on 30
    Sep for run dates 30 Sep .. 29 Oct; a daily feed on that day).  One row
    per feed; a re-send on a later run date is another DELIVERY of that row.
    A feed whose rule is not a date (on completion / on demand) is not on the
    run-date board.  Each task carries its ``business_date``; everything
    read per date (holds, decisions, dependencies, deliveries, alerts) is
    read for the task's own date.

    * KPI tiles count every visible task of the date (search applied, the
      status filter NOT -- a tile filters the list, the tiles keep totals),
      plus the SLA tiles (``sla_breached`` / ``sla_at_risk``) and ``held``.
    * PAGING IS OVER TASKS ("Displaying 1-50 of 885"), in (group, feed) order,
      ``No group`` last; a page's tasks are shown under their groups, and each
      group's counts are over the WHOLE group ("Failed 3/6"), not the page.
    * ``status`` filters by a status word or by ``sla_breached`` /
      ``sla_at_risk``.
    * ``act_fn(feed_config) -> bool`` (2026-10-17) stamps ``can_act`` on every
      task of the page -- whether the CALLER may re-run / skip / decide it
      (``permissions.can_act_on_feed``); None = everyone may (auth off).
    * ``missing`` (2026-10-17, unknown is not empty): the visible ACTIVE feeds
      that are DUE on the date by their own rule and calendar but have NO
      task row (run-date view: derived per feed, the same walk as the rows;
      business-date view: the date's open ``feed_sod_gaps``), with ``sod``
      saying whether start of day is on at all.  A feed that is simply absent
      looked exactly like "nothing due".
    """
    from datetime import datetime, timezone
    from core.feed import sla_board
    from core.feed.sla_tracker import SlaTracker
    now = now or datetime.now(timezone.utc)
    tracker = SlaTracker(db, now_fn=lambda: now)
    risk = sla_board.at_risk_minutes()
    derived: Dict[int, dict] = {}        # run-date view: feed id -> (its derived date, its name)
    listed: Dict[int, dict] = {}         # run-date view: the active configs, read ONCE
    if run_date is not None:
        from core.feed.sod_generator import SodTaskGenerator
        gen = SodTaskGenerator(db)
        cfgs = [fc for fc in (db.list_feed_configs(is_active=True) or [])
                if visible_feed_ids is None or int(fc["id"]) in visible_feed_ids]
        # 2026-10-17 -- ONE pass for every feed (calendars once per name, the
        # walk once per (declaration, calendar)): 4,000 feeds of one template
        # are one walk, not 4,000 (the per-feed pattern fixed for the
        # business-date view on 2026-10-12, found again here)
        dates_by_feed = gen.current_business_dates(cfgs, run_date)
        pairs = []
        for fc in cfgs:
            fid = int(fc["id"])
            listed[fid] = fc
            bd = dates_by_feed.get(fid)
            if bd is not None:
                pairs.append((fid, bd))
                derived[fid] = {"business_date": _iso(bd), "feed_name": fc.get("name")}
        runs = db.list_feed_runs_for_pairs(pairs) or []
    else:
        runs = db.list_feed_runs(business_date=business_date, limit=100000) or []
    groups = {int(g["id"]): g for g in (db.list_feed_groups() or [])}
    latest: Dict[tuple, dict] = {}
    for r in sorted(runs, key=lambda r: int(r.get("id") or 0)):
        fid = int(r.get("feed_config_id") or 0)
        if visible_feed_ids is not None and fid not in visible_feed_ids:
            continue
        latest[(fid, _iso(r.get("business_date")))] = r
    # 2026-10-12 -- only the date's feeds, read once (was every config --
    # 5,093 on the rig -- and then one get_feed_config per feed for its zone).
    want = sorted({k[0] for k in latest})
    # the run-date view already holds every config it listed: no second read
    feeds = ({f: listed[f] for f in want if f in listed} if run_date is not None
             else db.get_feed_configs_by_ids(want)) or {}
    tracker.seed_timezones(feeds)
    latest = {k: r for k, r in latest.items() if not off_the_board(r, feeds.get(k[0]))}
    q = (search or "").strip().lower()
    missing, missing_unavailable = _missing_tasks(db, business_date, run_date, derived, latest,
                                                  visible_feed_ids, q)
    dates = sorted({k[1] for k in latest}) if run_date is not None else [_iso(business_date)]
    holds: Dict[int, dict] = {}
    for d in dates:
        for h in db.list_variance_holds(business_date=_as_date(d), limit=100000) or []:
            if h.get("status") == "superseded":
                continue
            holds.setdefault(int(h.get("feed_run_id") or 0), h)   # newest first
    # the date's OPEN regeneration decisions, read once per date: a delivered
    # task whose re-send is HELD (a re-run hold, a restatement after close --
    # core/feed/restatement.py) is HELD on the board like a variance hold
    open_decisions = {d: _open_decisions(db, _as_date(d)) for d in dates}
    tasks: List[dict] = []
    for (fid, bd), r in latest.items():
        f = feeds.get(fid) or {}
        gid = f.get("feed_group_id")
        g = groups.get(int(gid)) if gid else None
        if q and q not in str(f.get("name") or "").lower() \
                and q not in str((g or {}).get("name") or "").lower():
            continue
        hold = holds.get(int(r["id"]))
        deadline = tracker.deadline_for(r) if r.get("sla_to") else None
        sla = sla_board.verdict_for(r, deadline, now, risk)
        st, ct = sla_board._aware(r.get("started_at")), sla_board._aware(r.get("completed_at"))
        tasks.append({
            "feed_id": fid, "feed_name": f.get("name"), "run_id": r.get("id"),
            "business_date": bd, "run_date": _iso(r.get("run_date")) if r.get("run_date") else None,
            "calendar": calendar_of(f),
            "date_rule": date_label(f),
            "group_id": int(gid) if g else None,
            "group_name": (g or NO_GROUP)["name"],
            "status": ("held" if r.get("status") == "completed" and _restatement_held(
                open_decisions.get(bd, {}).get(fid)) else task_status(r, hold)),
            "run_status": r.get("status"), "action_decision": r.get("action_decision"),
            "action_reason": r.get("action_reason"),
            "started_at": r.get("started_at"), "completed_at": r.get("completed_at"),
            "duration_seconds": (round((ct - st).total_seconds(), 1) if st and ct else None),
            "total_rows": r.get("total_rows"), "triggered_by": r.get("triggered_by"),
            "output_path": r.get("output_path"),
            "sla": {"verdict": sla["verdict"], "sla_to": r.get("sla_to"),
                    "sla_timezone": f.get("sla_timezone"),
                    "deadline_utc": deadline.isoformat() if deadline else None,
                    "minutes_vs_deadline": sla["minutes_vs_deadline"],
                    "alerted": bool(r.get("sla_breached"))},
            "variance_hold": ({"id": hold["id"], "status": hold["status"],
                               "actual_rows": hold.get("actual_rows"),
                               "baseline_rows": hold.get("baseline_rows"),
                               "baseline_business_date": hold.get("baseline_business_date"),
                               "delta_pct": hold.get("delta_pct"),
                               "direction": hold.get("direction")} if hold else None),
        })
    # ── the grouping the operator chose (2026-10-12: the List view's
    # "Group by" and the board's are ONE choice) ──────────────────────
    templates = {}
    if group_by == "template":
        templates = {int(x["id"]): x.get("name") for x in (db.list_feed_templates() or [])}
    for t in tasks:
        f = feeds.get(t["feed_id"]) or {}
        if group_by == "template":
            tid = f.get("template_id")
            t["group_key"] = f"t{tid}" if tid else "t-"
            t["group_label"] = templates.get(int(tid), f"template {tid}") if tid else "No template"
            t["group_last"] = not tid
        elif group_by == "status":
            t["group_key"] = f"s{t['status']}"
            t["group_label"] = STATUS_WORDS.get(t["status"], t["status"])
            t["group_last"] = False
        elif group_by == "none":
            t["group_key"], t["group_label"], t["group_last"] = "all", "All feeds", False
        else:
            t["group_key"] = f"g{t['group_id']}" if t["group_id"] is not None else "g-"
            t["group_label"] = t["group_name"]
            t["group_last"] = t["group_id"] is None
    kpis = _counts(t["status"] for t in tasks)
    kpis["sla_breached"] = sum(1 for t in tasks if t["sla"]["verdict"] in ("breached", "late"))
    kpis["sla_at_risk"] = sum(1 for t in tasks if t["sla"]["verdict"] == "at_risk")
    # 2026-10-17 -- the Variance holds popup lists VARIANCE holds; ``held``
    # also counts a re-send held by the restatement policy, so the popup's
    # button said "(2)" over one hold.  Its own count:
    kpis["variance_held"] = sum(1 for t in tasks if (t.get("variance_hold") or {}).get("status")
                                in OPEN_HOLD_STATUSES)
    group_counts: Dict[str, Dict[str, int]] = {}
    for gk in {t["group_key"] for t in tasks}:
        group_counts[gk] = _counts(t["status"] for t in tasks if t["group_key"] == gk)

    def _keep(t):
        if not status:
            return True
        if status == "sla_breached":
            return t["sla"]["verdict"] in ("breached", "late")
        if status == "sla_at_risk":
            return t["sla"]["verdict"] == "at_risk"
        return t["status"] == status
    shown = sorted((t for t in tasks if _keep(t)),
                   key=lambda t: (t["group_last"],
                                  (STATUS_ORDER.get(t["status"], 99) if group_by == "status" else 0),
                                  str(t["group_label"]).lower(), str(t["feed_name"] or ""),
                                  # run-date view: a feed's newest business date first
                                  -_as_date(t["business_date"]).toordinal()))
    size = max(1, min(int(page_size), 500))
    total = len(shown)
    pages = max(1, -(-total // size))
    page = min(max(1, int(page)), pages)
    page_tasks = shown[(page - 1) * size: page * size]
    for d in sorted({t["business_date"] for t in page_tasks}):
        enrich_page_tasks(db, [t for t in page_tasks if t["business_date"] == d], feeds,
                          _as_date(d), open_decisions=open_decisions.get(d, {}))
    # each run's steps IN THE ORDER THEY HAPPENED (the row's flow is
    # sequential) and their counts -- one read
    seqs = db.feed_run_step_sequences([t["run_id"] for t in page_tasks])
    # 2026-10-17 -- may the CALLER act on this task?  ONE verdict per
    # distinct feed (the same gate every action route applies); the board
    # offered Re-run / Skip / Re-run one side to everyone and let the
    # server refuse afterwards.
    acts: Dict[int, bool] = {}
    for t in page_tasks:
        fid = int(t["feed_id"])
        if fid not in acts:
            if act_fn is None:
                acts[fid] = True
            else:
                try:
                    acts[fid] = bool(act_fn(feeds.get(fid) or {}))
                except Exception as exc:                # noqa: BLE001 -- unknown = may not
                    logger.warning("[dashboard] act verdict for feed %s unreadable: %s", fid, exc)
                    acts[fid] = False
        t["can_act"] = acts[fid]
    for t in page_tasks:
        q = seqs.get(int(t["run_id"] or 0)) or []
        c: Dict[str, int] = {}
        for s in q:
            c[s["state"]] = c.get(s["state"], 0) + 1
        t["steps"] = {"total": len(q), "completed": c.get("completed", 0),
                      "failed": c.get("failed", 0) + c.get("refused", 0),
                      "running": c.get("running", 0), "not_started": c.get("not_started", 0),
                      "skipped": c.get("skipped", 0)}
        t["step_seq"] = [{"alias": s["alias"], "state": s["state"]} for s in q]
    out_groups: List[dict] = []
    for t in page_tasks:
        if not out_groups or out_groups[-1]["key"] != t["group_key"]:
            g = (groups.get(t["group_id"]) if group_by in ("feed_group", "") and t["group_id"] is not None
                 else None)
            out_groups.append({"key": t["group_key"],
                               "id": t["group_id"] if group_by in ("feed_group", "") else None,
                               "name": t["group_label"],
                               "display_label": (g or {}).get("display_label") or t["group_label"],
                               "counts": group_counts.get(t["group_key"]) or {},
                               "tasks": []})
        out_groups[-1]["tasks"].append(t)
    from core.feed.environments import public as _envs
    return {"business_date": _iso(business_date) if business_date else None,
            "run_date": _iso(run_date) if run_date else None,
            "date_kind": "run_date" if run_date is not None else "business_date",
            # run-date view: which business dates the feeds are on, by rule
            # ("Month end 2026-09-30: 12 feeds, Business day 2026-10-13: 40")
            "date_summary": _date_summary(tasks) if run_date is not None else None,
            "kpis": kpis, "group_by": group_by,
            "environments": _envs(),
            # feeds due on the date with NO task (unknown is not empty)
            "missing_count": len(missing) if missing is not None else None,
            "missing": (missing or [])[:MISSING_SHOWN],
            "missing_unavailable": missing_unavailable,
            "sod": _sod_state(),
            "groups": out_groups, "total_tasks": total, "page": page, "pages": pages,
            "page_size": size, "first": (page - 1) * size + 1 if total else 0,
            "last": (page - 1) * size + len(page_tasks)}


def _sod_state() -> Dict[str, Any]:
    """Is start of day creating tasks on this deployment at all?  An empty
    board with SOD off is "nothing is created", not "nothing is due"."""
    try:
        from core import config as _c
        return {"enabled": bool(_c.feed_generation.sod_enabled),
                "catchup_days": int(getattr(_c.feed_generation, "sod_catchup_days", 7) or 0)}
    except Exception as exc:                            # noqa: BLE001 -- unknown, said
        return {"enabled": None, "reason": f"{type(exc).__name__}: {exc}"}


def _missing_tasks(db, business_date: Optional[date], run_date: Optional[date],
                   derived: Mapping[int, dict], latest: Mapping[tuple, dict],
                   visible_feed_ids: Optional[set], q: str):
    """The visible active feeds DUE on the date with NO task row
    (2026-10-17).  Returns ``(missing, unavailable)``: a list of
    ``{feed_id, feed_name, business_date, reason}`` sorted by name, or
    ``(None, why)`` when it could not be read -- never ``[]`` for a failure.

    * run-date view: ``derived`` holds every visible active feed's own date
      (the same walk that found the rows); one with no row in ``latest`` is
      missing -- start of day never created it (SOD off, a gap, a feed made
      after the pass).
    * business-date view: the date's OPEN ``feed_sod_gaps`` rows -- what the
      SOD pass itself found due and could not create.
    """
    try:
        out: List[dict] = []
        if run_date is not None:
            have = {k[0] for k in latest}
            for fid, d in derived.items():
                if fid in have:
                    continue
                out.append({"feed_id": fid, "feed_name": d.get("feed_name"),
                            "business_date": d.get("business_date"),
                            "reason": "no task row -- start of day has not created it"})
        elif business_date is not None:
            gaps = db.list_feed_sod_gaps(open_only=True, business_date_from=business_date,
                                         business_date_to=business_date,
                                         feed_ids=sorted(visible_feed_ids) if visible_feed_ids is not None else None,
                                         limit=None) or []
            names = db.get_feed_configs_by_ids([g.get("feed_config_id") for g in gaps]) or {}
            for g in gaps:
                fid = int(g["feed_config_id"])
                fc = names.get(fid) or {}
                if not fc.get("is_active", True):
                    continue
                out.append({"feed_id": fid, "feed_name": fc.get("name"),
                            "business_date": _iso(g.get("business_date")),
                            "reason": g.get("reason") or "start of day found the date due and created no task"})
        if q:
            out = [m for m in out if q in str(m.get("feed_name") or "").lower()]
        out.sort(key=lambda m: str(m.get("feed_name") or ""))
        return out, None
    except Exception as exc:                            # noqa: BLE001 -- said, never []
        logger.warning("[dashboard] missing tasks unreadable: %s", exc)
        return None, f"{type(exc).__name__}: {exc}"


def _date_summary(tasks: List[dict]) -> List[Dict[str, Any]]:
    """The run-date view's business dates: one entry per (rule word, date),
    with how many feeds are on it, newest date first."""
    out: Dict[tuple, int] = {}
    for t in tasks:
        k = ((t.get("date_rule") or {}).get("label") or "Business day", t["business_date"])
        out[k] = out.get(k, 0) + 1
    return [{"label": k[0], "business_date": k[1], "feeds": n}
            for k, n in sorted(out.items(), key=lambda kv: (kv[0][1], kv[0][0]), reverse=True)]


def _open_decisions(db, business_date: date) -> Dict[int, List[dict]]:
    out: Dict[int, List[dict]] = {}
    try:
        for d in (db.list_regeneration_decisions(business_date=business_date.isoformat(),
                                                 status="open", limit=10000) or []):
            if d.get("feed_config_id") is not None:
                out.setdefault(int(d["feed_config_id"]), []).append(d)
    except Exception as exc:                            # noqa: BLE001 -- no claim when unreadable
        logger.warning("[dashboard] open decisions of %s unreadable: %s", business_date, exc)
    return out


def _restatement_held(decisions: Optional[List[dict]]) -> bool:
    from core.feed.restatement import is_held
    return any(is_held(d) for d in decisions or [])


def enrich_page_tasks(db, page_tasks: List[dict], feeds: Mapping[int, Mapping[str, Any]],
                      business_date: date, open_decisions: Optional[Dict[int, List[dict]]] = None
                      ) -> None:
    """What every task ON THE PAGE carries beyond its run row (2026-10-12):
    its dependencies with THE gate's verdict, its per-environment facts from
    its own execution (rows read / expected, failed side, checks' outcomes),
    the one-side re-run offer, and SUPERSEDED (a newer upstream message after
    delivery).  Read for the page only, in batches."""
    # 2026-10-12 (owner: "why no dependency tile per feed gen task") -- every
    # task ON THE PAGE carries its dependencies with THE gate's verdict
    # (run_preflight, the one answer the poller and the Run Now dialog read);
    # the messages stay on /task, read when a row is opened.
    from core.feed.etl_dependency import run_preflight
    for t in page_tasks:
        f = feeds.get(t["feed_id"])
        if not f:
            t["deps"], t["deps_unavailable"] = [], "feed not readable"
            continue
        pre = run_preflight(db, dict(f), business_date)
        t["deps_unavailable"] = pre.get("unavailable")
        t["deps"] = [{"name": v.get("dependency_name"), "side": _side(v.get("dependency_name") or ""),
                      "verdict": v.get("verdict"), "satisfies": v.get("satisfies"),
                      "action": v.get("action"), "reason": v.get("reason")}
                     for v in pre.get("verdicts") or []]
    # 2026-10-12 (owner: "not showing total row count n onprem count oncloud
    # count", "how will you decide on-prem failed or on-cloud failed") -- per
    # side, from the run's OWN execution (one batch for the page): rows read,
    # rows the upstream message REPORTED, the certification verdict, and the
    # side a failure belongs to (``failed_side``, recorded by the engine).
    from core.feed.step_model.store import execution_ids_for_runs
    from core.feed.run_progress import progress_view as _progress_view
    from core.feed.run_progress import stale_after_seconds as _stale_after
    try:
        eids = execution_ids_for_runs(db, [t["run_id"] for t in page_tasks])
        execs = db.get_feed_executions_by_exec_ids(eids.values())
    except Exception:                                   # noqa: BLE001 -- said per task
        eids, execs = {}, None
    for t in page_tasks:
        ex = (execs or {}).get(eids.get(int(t["run_id"] or 0)) or "")
        t["sides"] = side_facts(ex) if ex else None
        # a failed run that KEPT one side: may only the failed side re-run?
        t["side_rerun"] = None
        if ex and str(ex.get("status")) == "failed" and (ex.get("stage_timings") or {}).get("kept_side"):
            try:
                from core.feed import side_resume
                t["side_rerun"] = side_resume.offer(db, feeds.get(t["feed_id"]) or {}, ex, business_date)
            except Exception as exc:                    # noqa: BLE001 -- said, not hidden
                t["side_rerun"] = {"ok": False, "reason": f"could not be checked ({exc})"}
        t["sides_unavailable"] = None if execs is not None else "the run's execution could not be read"
        # 2026-10-14 -- WHERE a running task is (phase, Spark's task counters,
        # estimate, "no progress for N min"): core/feed/run_progress.py
        t["progress"] = (_progress_view(ex, stale_after_seconds=_stale_after())
                         if ex and str(ex.get("status")) in ("pending", "running") else None)
    # 2026-10-12 -- SUPERSEDED: a delivered run whose environment received a
    # NEWER message (a restatement).  The ledger already raises a
    # regeneration decision for it (core/feed/regeneration.py); the board
    # shows that decision with the versions from the run's UPSTREAM CONTRACT
    # (what it read) and the contract now -- one page, one query.
    _open = open_decisions if open_decisions is not None else _open_decisions(db, business_date)
    from core.feed import upstream_contract as _uc
    from core.feed.restatement import EVIDENCE_KEY as _RS
    for t in page_tasks:
        t["superseded"] = None
        decs = _open.get(int(t["feed_id"])) or []
        dec = decs[0] if decs else None
        ex = (execs or {}).get(eids.get(int(t["run_id"] or 0)) or "") if execs else None
        stored = ((ex or {}).get("stage_timings") or {}).get(_uc.RECORD_KEY)
        # the RUN delivered (``run_status``): the board's word for a delivered
        # task whose re-send is held is "held" -- exactly when the operator
        # needs to see what changed (found 2026-10-13: "changes": [] on the
        # 1M-row re-send while the hold asked a person to decide)
        changes = (_uc.superseding(db, stored, business_date)
                   if stored and t.get("run_status") == "completed" else [])
        if dec or changes:
            # what the feed's RESTATEMENT POLICY made of it (re-run / re-run
            # hold / after close / decide) -- the newest decision's verdict
            rs = ((decs[-1].get("evidence") or {}).get(_RS)) if decs else None
            t["superseded"] = {"decision_id": (dec or {}).get("id"),
                               "decision_ids": [int(x["id"]) for x in decs],
                               "dependency": (dec or {}).get("dependency_name"),
                               "raised_at": (dec or {}).get("raised_at"),
                               "changes": changes, "restatement": rs}
    # 2026-10-12 -- EVERY delivery of the task (the month-end business date
    # is delivered again on later run dates): run date, rows, file, the
    # definition version it ran; and the task's ALERTS with where each went
    # (core/feed/feed_alerts.py).  One query each for the page.
    from core.feed.feed_alerts import for_tasks
    from core.feed.rerun import run_date_of
    try:
        dels = db.list_feed_executions_for_date([t["feed_id"] for t in page_tasks], business_date)
    except Exception as exc:                            # noqa: BLE001 -- said per task
        logger.warning("[dashboard] deliveries of %s unreadable: %s", business_date, exc)
        dels = None
    try:
        alerts = for_tasks(db, [(t["feed_id"], business_date) for t in page_tasks])
    except Exception as exc:                            # noqa: BLE001
        logger.warning("[dashboard] alerts of %s unreadable: %s", business_date, exc)
        alerts = None
    for t in page_tasks:
        rows = (dels.get(int(t["feed_id"])) or []) if dels is not None else []
        t["deliveries"] = None if dels is None else [
            {"execution_id": e.get("execution_id"),
             "run_date": run_date_of(e.get("completed_at")).isoformat() if e.get("completed_at") else None,
             "completed_at": e.get("completed_at"), "rows": e.get("total_rows"),
             "file": e.get("output_filename"), "destination": e.get("destination_path"),
             # 2026-10-17 -- a completed execution is a DELIVERY only when
             # something reached a destination (``destination_path``, the
             # one write every reader of "it went" reads): a file HELD for
             # verification or a suppressed chain completed undelivered and
             # the row said "Delivered 2x" over one file sent
             "delivered": bool(e.get("destination_path")),
             "definition_version_id": e.get("pinned_version_id"),
             "trigger": e.get("trigger_type"), "triggered_by": e.get("triggered_by"),
             # 2026-10-13 (the owner: "for business date 30 Sep, if I have 10
             # run dates, how will you show it") -- what each delivery READ
             # and WHY it happened, in words
             "versions": delivery_versions(e),
             "why": delivery_why(e, first=(i == len(rows) - 1))}
            for i, e in enumerate(rows)]
        t["alerts"] = None if alerts is None else alerts.get((t["feed_id"], business_date.isoformat()), [])


def delivery_versions(execution: Mapping[str, Any]) -> List[Dict[str, Any]]:
    """The upstream version each environment's side READ for this delivery,
    from the contract the run recorded (core/feed/upstream_contract.py):
    [{environment, version}] in side order; [] when nothing was recorded."""
    from core.feed.upstream_contract import RECORD_KEY, SIDES
    rec = ((execution.get("stage_timings") or {}).get(RECORD_KEY)) or {}
    out = []
    for side in SIDES:
        c = rec.get(side) if isinstance(rec, Mapping) else None
        if not isinstance(c, Mapping):
            continue
        tok = c.get("tokens") or {}
        out.append({"environment": c.get("environment") or side,
                    "version": tok.get("version") if isinstance(tok, Mapping) else None})
    return out


def delivery_why(execution: Mapping[str, Any], *, first: bool) -> str:
    """Why this delivery happened, in a person's words."""
    trig = str(execution.get("trigger_type") or "")
    who = execution.get("triggered_by") or ""
    if first and trig not in ("restatement", "rerun"):
        return "First delivery"
    if trig == "restatement":
        return ("New upstream version — re-run by the re-send policy" if who in ("", "restatement")
                else f"New upstream version — re-run approved by {who}")
    if trig == "rerun":
        return f"Re-run by {who}" if who else "Re-run"
    if trig == "manual":
        return f"Run by hand ({who})" if who else "Run by hand"
    return "Scheduled run"


def _expected_message(db, name: str) -> Optional[Dict[str, Any]]:
    """The message a WAITING dependency expects, from a REAL message only:
    the last one this dependency received on any date (its CODE / STORE /
    SOURCE / EVENT do not change between dates).  None when it never
    received one -- the caller may then take the sibling environment's
    message of the same date (:func:`_from_sibling`); a dependency NAME is
    never read back into fields (a CODE such as ``E809906_4100_APAC``
    carries the separator -- that was a guess, found live 2026-10-12)."""
    try:
        last = db.latest_dependency_event(name)
    except Exception:                                   # noqa: BLE001 -- nothing to show
        return None
    if last:
        p = last.get("payload") or {}
        f = p.get("fields") if isinstance(p.get("fields"), dict) else p
        from core.feed.message_fields import identifying
        f = identifying(f if isinstance(f, dict) else None)
        if f:
            return {"fields": f, "from": "last_message", "business_date": last.get("business_date")}
    return None


def _from_sibling(cards: List[dict]) -> None:
    """A waiting card with no message of its own takes the fields of the
    SAME feed's other environment's message this date (same source, code,
    event) WITHOUT the field that names the environment (the configured
    ``message_field`` of each environment -- core/feed/environments.py)."""
    from core.feed.environments import environments
    from core.feed.message_fields import identifying
    env_fields = {str(e.get("message_field")).upper() for e in environments() if e.get("message_field")}
    donor = next((c["messages"][-1]["fields"] for c in cards if c.get("messages")), None)
    if not donor:
        return
    shared = {k: v for k, v in identifying(donor).items() if str(k).upper() not in env_fields}
    if not shared:
        return
    for c in cards:
        if not c.get("messages") and not c.get("expected"):
            c["expected"] = {"fields": shared, "from": "other_environment"}


def _side(name: str) -> Optional[str]:
    """The environment LABEL a dependency's name declares -- configured
    (core/feed/environments.py), never spelled here."""
    from core.feed.environments import label, side_of_dependency
    return label(side_of_dependency(name))


def task_detail(db, feed: Mapping[str, Any], business_date: date) -> Dict[str, Any]:
    """One task's dependency CARDS: THE gate's verdict per dependency
    (``etl_dependency.run_preflight``) plus what arrived on the ledger for
    the date -- the upstream message's fields (CODE, DATA_STORE, SOURCE,
    BUSINESS_EVENT, ROW_COUNT ...), its road and when.  The side (CLOUD /
    ON-PREM) is read from the message's own CLOUD_COMPLIANT when one
    arrived, else from the dependency's name."""
    from core.feed.etl_dependency import run_preflight
    pre = run_preflight(db, dict(feed), business_date)
    # the ROADS each dependency is declared to arrive by (2026-10-12): a
    # waiting tile says what it waits for -- the Kafka topic, the message
    # table -- instead of "not yet"
    roads_by_key: Dict[str, list] = {}
    try:
        from core.feed.etl_dependency import effective_etl_id
        for m in db.list_etl_dependency_mappings(effective_etl_id(dict(feed))) or []:
            roads_by_key[str(m.get("dependency_key"))] = [
                {"kind": s.get("kind"), "topic": s.get("topic"), "table": s.get("table")}
                for s in (m.get("arrival_sources") or []) if isinstance(s, dict)]
    except Exception:                                   # noqa: BLE001 -- the tile then names no road
        roads_by_key = {}
    cards = []
    for v in pre.get("verdicts") or []:
        name = v.get("dependency_name")
        try:
            arrivals = db.list_dependency_events(name, business_date) or []
        except Exception as exc:                        # noqa: BLE001 -- said, not hidden
            arrivals, err = None, f"{type(exc).__name__}: {exc}"
        else:
            err = None
        msgs = []
        side = _side(name)
        for a in arrivals or []:
            payload = a.get("payload") or {}
            fields = payload.get("fields") if isinstance(payload.get("fields"), dict) else payload
            from core.feed.environments import label as _env_label, side_of_message
            _ms = side_of_message(fields if isinstance(fields, dict) else None)
            if _ms:
                side = _env_label(_ms)
            msgs.append({"source": a.get("source"), "arrived_at": a.get("arrived_at"),
                         "reported_rows": a.get("reported_rows"),
                         "message_identity": a.get("message_identity"),
                         "fields": fields if isinstance(fields, dict) else {}})
        # WAITING: the message it EXPECTS (the reference board shows CODE /
        # STORE / SOURCE / EVENT on a waiting tile too) -- the last message
        # this dependency received on any date, else the fields its resolver
        # rule's template spells into the name
        expected = None
        if not msgs:
            expected = _expected_message(db, name)
        cards.append({"dependency_name": name, "side": side, "verdict": v.get("verdict"),
                      "expected": expected,
                      "satisfies": v.get("satisfies"), "reason": v.get("reason"),
                      "action": v.get("action"), "sources": v.get("sources"),
                      "messages": msgs, "message_count": len(msgs),
                      "messages_unreadable": err, "roads": roads_by_key.get(str(name)) or []})
    _from_sibling(cards)
    from core.feed.message_fields import shown
    return {"feed_id": feed.get("id"), "business_date": business_date.isoformat(),
            "admitted": pre.get("admitted"), "unavailable": pre.get("unavailable"),
            # the message fields a tile shows, in order -- DATA (feed_message_fields)
            "display_fields": shown("tile"),
            "dependencies": cards}
