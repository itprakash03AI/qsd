"""WHICH bytes a feed's checksum describes -- ONE decision for every lane
(2026-10-15).

The owner: "some extract creates MD5 or SHA checksum of file NOT on
compressed file".  A counterparty that unzips first and then verifies wants
the digest of the DATA file, not of the ``.gz`` it was sent.  Until this
date FR-ART-02 refused every such spelling (contract.py): a digest of bytes
the counterparty never receives cannot verify the transfer.  Both are true,
so the term is DECLARED per feed and the transfer is still verified on the
sent bytes:

  ``output_options.checksum_covers``
    ``sent`` (default)  the sidecar (``<file>.<algo>``) and the control
                        file's checksum fields describe the delivered file,
                        after packaging / compression / encryption -- every
                        feed's behaviour before this date
    ``uncompressed``    they describe the DATA file as rendered, BEFORE
                        packaging, compression and encryption: the bytes the
                        counterparty has after it unpacks.  The sidecar line
                        names that data file (``md5sum -c`` works after the
                        unzip).  Exactly ONE data file: a run with more
                        cannot say which file "the" checksum is of, and
                        FAILS saying so -- never a guess.

What is NOT changed: the delivery receipt / hop verification
(``delivery_hops.checksum_of_sent_bytes``) and the execution's certificate
always digest what was SENT -- the transfer is verified either way.

Read by the native engine (``feed_engine``, before packaging) and the Spark
artifact chain (``spark_k8s.artifact_chain``, before its package step) --
the same :func:`capture`, so the two lanes cannot disagree on what the
checksum covers.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable, List, Mapping, Optional

COVERS_SENT = "sent"
COVERS_UNCOMPRESSED = "uncompressed"
COVERS = (COVERS_SENT, COVERS_UNCOMPRESSED)
#: spellings a person types for the same two meanings
_ALIASES = {"delivered": COVERS_SENT, "sent": COVERS_SENT,
            "uncompressed": COVERS_UNCOMPRESSED}


class ChecksumCoversRefused(ValueError):
    """The declared coverage cannot be honoured for this run (said why)."""


def covers_of(feed_config: Mapping[str, Any]) -> str:
    """The feed's declared coverage; ``sent`` when undeclared.  An unknown
    spelling RAISES -- the authoring contract refuses it first."""
    opts = dict(feed_config.get("output_options") or {})
    raw = str(opts.get("checksum_covers") or COVERS_SENT).strip().lower()
    if raw not in _ALIASES:
        raise ChecksumCoversRefused(
            f"checksum_covers {raw!r} is not one of {COVERS}")
    return _ALIASES[raw]


def wants_control_file(feed_config: Mapping[str, Any]) -> bool:
    """Does this feed write a control file (the artifact chain's rule)."""
    opts = dict(feed_config.get("output_options") or {})
    return bool(feed_config.get("control_file_template")
                or feed_config.get("control_file_format_id")
                or str(opts.get("sidecar") or "").strip().lower() == "control_file"
                or opts.get("control_file"))


def needed_algorithms(feed_config: Mapping[str, Any], format_spec: Any = None) -> List[str]:
    """Every algorithm a sidecar or control file of this feed will print."""
    from core.feed.checksum import normalise_algorithm
    opts = dict(feed_config.get("output_options") or {})
    out: list = []
    if str(opts.get("sidecar") or "none").strip().lower() in ("per_file", "manifest"):
        a = normalise_algorithm(str(opts.get("checksum_algorithm") or opts.get("checksum") or ""))
        if a:
            out.append(a)
    if wants_control_file(feed_config):
        if format_spec is not None:
            algos = list(getattr(format_spec, "checksum_algorithms", None) or [])
        else:
            from core.feed.control_file import ControlFileWriter
            algos = list(ControlFileWriter().algorithms)
        out.extend(normalise_algorithm(a) for a in algos if a)
    seen: list = []
    for a in out:
        if a and a not in seen:
            seen.append(a)
    return seen


@dataclass
class DataDigests:
    """The digests of the uncompressed data file, taken before the chain."""
    name: str
    digests: dict = field(default_factory=dict)

    def get(self, algorithm: str) -> str:
        from core.feed.checksum import normalise_algorithm
        a = normalise_algorithm(algorithm)
        if a not in self.digests:
            raise ChecksumCoversRefused(
                f"no {a} digest of the uncompressed data file {self.name!r} was taken "
                f"(taken: {sorted(self.digests)})")
        return self.digests[a]

    def to_dict(self) -> dict:
        return {"covers": COVERS_UNCOMPRESSED, "file": self.name, "digests": dict(self.digests)}


def capture(feed_config: Mapping[str, Any], data_files: Iterable[Path],
            format_spec: Any = None) -> Optional[DataDigests]:
    """When the feed declares ``uncompressed``: the digests of its ONE data
    file, NOW (before packaging / compression / encryption), for every
    algorithm a sidecar or control file will print.  None for ``sent``.
    Raises :class:`ChecksumCoversRefused` naming the files when there is
    not exactly one."""
    if covers_of(feed_config) != COVERS_UNCOMPRESSED:
        return None
    files = [Path(p) for p in data_files]
    if len(files) != 1:
        raise ChecksumCoversRefused(
            f"checksum_covers=uncompressed needs exactly ONE data file to describe; this run "
            f"has {len(files)} ({', '.join(p.name for p in files[:5])}) -- declare "
            f"checksum_covers=sent, or produce one file")
    from core.feed.checksum import compute_all
    algos = needed_algorithms(feed_config, format_spec)
    return DataDigests(name=files[0].name, digests=compute_all(files[0], algos) if algos else {})
