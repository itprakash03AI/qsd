"""The SLA board -- every feed's SLA status for one business date
(2026-10-12, owner request R5: "SLA tracker? SLA breach alert?").

ONE verdict per run, from the same deadline the breach sweep uses
(``SlaTracker.deadline_for`` -- the board cannot call a run on time that the
sweep marks breached):

  met          delivered at or before the deadline
  late         delivered AFTER the deadline (breached, then delivered)
  breached     not delivered and the deadline has passed (or the sweep
               already flagged ``sla_breached``)
  at_risk      not delivered, the deadline within
               ``feed_generation.sla_at_risk_minutes`` (30)
  on_track     not delivered, the deadline further away
  not_due      nothing is due: the run was SKIPPED (a holiday, an
               ACTION_CONDITION SKIP) or CANCELLED -- the breach sweep
               never looks at it (``PENDING_OR_RUNNING``), so the board
               must not call it breached either (2026-10-17: a skipped
               month-end feed was "SLA breached" on the board for ever)
  no_sla       the run declares no SLA (a backfill never has one)
  invalid_sla  an SLA that cannot be read -- no breach clock exists (said)

"Delivered" is the run's recorded destination (``feed_runs.output_path``,
written only when something reached a destination; a variance hold sets it
on release).  ``alerted`` is the breach sweep's flag: a breach alert was
raised (Netcool / notifications through the sweep's notify hook and the SLA
watcher).  The board decides nothing else and writes nothing.
"""
from __future__ import annotations

from datetime import date, datetime, timezone
from typing import Any, Dict, List, Mapping, Optional

VERDICTS = ("breached", "at_risk", "late", "on_track", "met", "not_due", "no_sla", "invalid_sla")
_ORDER = {v: i for i, v in enumerate(VERDICTS)}

#: run states with NOTHING due -- the sweep's ``PENDING_OR_RUNNING`` never
#: holds them, so no breach alert can ever be raised for one
NOT_DUE_STATUSES = ("skipped", "cancelled")


def nothing_due(run: Mapping[str, Any]) -> bool:
    """A skipped or cancelled run, or one whose ACTION_CONDITION said SKIP:
    no file is owed, so no SLA clock runs."""
    st = str(run.get("status") or "").lower()
    return st in NOT_DUE_STATUSES or str(run.get("action_decision") or "").upper() == "SKIP"


def at_risk_minutes() -> int:
    try:
        from core import config as _c
        return int(_c.feed_generation.sla_at_risk_minutes)
    except Exception:                                   # noqa: BLE001
        return 30


def _aware(v) -> Optional[datetime]:
    if v is None or v == "":
        return None
    if isinstance(v, str):
        try:
            v = datetime.fromisoformat(v.replace("Z", "+00:00"))
        except ValueError:
            return None
    if isinstance(v, datetime):
        return v if v.tzinfo else v.replace(tzinfo=timezone.utc)
    return None


def verdict_for(run: Mapping[str, Any], deadline: Optional[datetime], now: datetime,
                risk_minutes: int) -> Dict[str, Any]:
    delivered = bool(run.get("output_path"))
    done_at = _aware(run.get("completed_at"))
    if nothing_due(run):
        return {"verdict": "not_due", "minutes_vs_deadline": None, "delivered": delivered,
                "delivered_at": done_at.isoformat() if (delivered and done_at) else None}
    if not run.get("sla_to"):
        v = "no_sla"
    elif deadline is None:
        v = "invalid_sla"
    elif delivered and done_at is not None:
        v = "met" if done_at <= deadline else "late"
    elif run.get("sla_breached") or now > deadline:
        v = "breached"
    elif (deadline - now).total_seconds() <= risk_minutes * 60:
        v = "at_risk"
    else:
        v = "on_track"
    minutes = None
    if deadline is not None:
        ref = done_at if (delivered and done_at is not None) else now
        minutes = int((ref - deadline).total_seconds() // 60)   # + = late, - = to spare
    return {"verdict": v, "minutes_vs_deadline": minutes, "delivered": delivered,
            "delivered_at": done_at.isoformat() if (delivered and done_at) else None}


def build(db, business_date: date, *, visible_feed_ids: Optional[set] = None,
          now: Optional[datetime] = None) -> Dict[str, Any]:
    from core.feed.sla_tracker import SlaTracker
    now = now or datetime.now(timezone.utc)
    tracker = SlaTracker(db, now_fn=lambda: now)
    risk = at_risk_minutes()
    latest: Dict[int, dict] = {}
    for r in sorted(db.list_feed_runs(business_date=business_date, limit=100000) or [],
                    key=lambda r: int(r.get("id") or 0)):
        fid = int(r.get("feed_config_id") or 0)
        if visible_feed_ids is None or fid in visible_feed_ids:
            latest[fid] = r
    # 2026-10-12 -- only the date's feeds, read once (was every config, and
    # then one get_feed_config per feed for its zone).
    feeds = db.get_feed_configs_by_ids(list(latest)) or {}
    tracker.seed_timezones(feeds)
    from core.feed.dashboard import off_the_board
    latest = {fid: r for fid, r in latest.items() if not off_the_board(r, feeds.get(fid))}
    rows: List[dict] = []
    for fid, r in latest.items():
        f = feeds.get(fid) or {}
        deadline = tracker.deadline_for(r) if r.get("sla_to") else None
        rows.append({
            "feed_id": fid, "feed_name": f.get("name"), "run_id": r.get("id"),
            "feed_group_id": f.get("feed_group_id"),
            "run_status": r.get("status"), "action_decision": r.get("action_decision"),
            "waiting_on": (r.get("action_reason") if str(r.get("action_decision") or "").upper() == "WAIT"
                           else None),
            "sla_to": r.get("sla_to"), "sla_timezone": f.get("sla_timezone"),
            "deadline_utc": deadline.isoformat() if deadline else None,
            "alerted": bool(r.get("sla_breached")),
            **verdict_for(r, deadline, now, risk)})
    rows.sort(key=lambda x: (_ORDER.get(x["verdict"], 99), x["deadline_utc"] or "~",
                             str(x["feed_name"] or "")))
    counts = {v: 0 for v in VERDICTS}
    for x in rows:
        counts[x["verdict"]] += 1
    counts["all"] = len(rows)
    return {"business_date": business_date.isoformat(), "now": now.isoformat(),
            "at_risk_minutes": risk, "counts": counts, "rows": rows}
