"""Feed output pipeline — Phase 130/2.

Glue layer that the feed engine calls AFTER the parquet → final-format
conversion.  Composes the per-class building blocks
(``FilenameRenderer`` / ``CompressionWriter`` / ``ControlFileWriter`` /
``BusinessCalendar``) into one ordered pipeline so the engine itself
stays small.

Design:
  - Stateless functions.  All inputs explicit; no module-level state.
  - Each step is gated independently so legacy feeds (no calendar,
    no enterprise tokens, no compression, no control file) keep
    rendering byte-for-byte identical output paths.
  - The caller still owns I/O — we accept ``Path`` inputs and return
    new paths; nothing reaches across DI boundaries.

Public surface:
  - ``render_filename_for_feed``  — picks legacy vs enterprise renderer
  - ``apply_compression``         — wraps the output file if configured
  - ``write_control_file``        — writes sidecar .ctl if configured
  - ``build_render_context``      — fills RenderContext from feed_config
"""
from __future__ import annotations

import logging
import re
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Mapping, Optional

from .calendar import BusinessCalendar, BusinessCalendarRepo
from .checksum import compute_all as _compute_checksums_all
from .compression import CompressionFormat, CompressionResult, CompressionWriter
from .control_file import ControlFileRecord, ControlFileWriter, ControlFormatSpec
from .filename_renderer import FilenameRenderer, RenderContext

logger = logging.getLogger(__name__)

# Heuristic — does this template use the enterprise token language?
# Three flavours supported by FilenameRenderer:
#   ${FUNC(FMT)}      — function call form, e.g. ${COB_PREV_EOM(YYYYMMDD)}
#   ${FMT}            — bare format-code form, e.g. ${YYYYMMDD}
#   {name:fmt}        — Python-style brace token, e.g. {run_date:YYYYMMDD}
_ENTERPRISE_TOKEN_RE = re.compile(r"\$\{[A-Za-z_][A-Za-z0-9_]*\s*(?:\([^)]+\))?\}")
_BRACE_TOKEN_RE      = re.compile(r"\{[A-Za-z_][A-Za-z0-9_]*\s*:[^}]+\}")


def template_uses_sequence(template: str) -> bool:
    """True if the template asks for a gapless sequence number.

    The engine checks this BEFORE rendering: allocating a number is a
    durable side effect that consumes state, so it must happen only for
    the feeds that actually declare one — never speculatively, or every
    feed in the estate would burn numbers it never uses and every
    sequence would be nothing but holes.
    """
    if not template:
        return False
    import re as _re
    return bool(_re.search(r"\$\{SEQ(?:UENCE)?(?:\([^)]*\))?\}",
                           str(template), _re.IGNORECASE))


# A plain ``{name}`` with no format suffix.
_PLAIN_BRACE_RE      = re.compile(r"\{([A-Za-z_][A-Za-z0-9_]*)\}")


def template_uses_enterprise_tokens(template: str) -> bool:
    """True if the template needs the enterprise FilenameRenderer.

    2026-09-13: also true for a PLAIN ``{name}`` outside the legacy five
    (``filename_renderer.LEGACY_TOKENS``).  The router used to decide by
    syntax alone, so ``balances_{business_date}.csv`` -- a name the typed
    renderer resolves -- went to the legacy ``str.format`` expander and
    the run failed with the reason ``'business_date'``.  The decision is
    now by TOKEN: a template made only of legacy names keeps its legacy
    expansion byte-for-byte; anything else is rendered by the one
    renderer that knows both vocabularies (the legacy five ride along as
    extras, see ``render_filename_for_feed``).
    """
    if not template:
        return False
    if _ENTERPRISE_TOKEN_RE.search(template) or _BRACE_TOKEN_RE.search(template):
        return True
    from .filename_renderer import LEGACY_TOKENS
    return any(m.group(1).lower() not in LEGACY_TOKENS
               for m in _PLAIN_BRACE_RE.finditer(template))


def _legacy_extras(feed_config: Mapping[str, Any], fmt_extension: str,
                   business_date: Optional[date] = None) -> Dict[str, str]:
    """The legacy five, from THE resolver the legacy expander uses
    (``filename_renderer.legacy_token_values``), so a mixed template
    (``{name}_{business_date}.{ext}``) renders the same ``{name}``,
    ``{date}`` and ``{ext}`` a legacy-only one does."""
    from .filename_renderer import legacy_token_values
    return legacy_token_values(feed_config.get("name", "feed"),
                               fmt_extension, business_date=business_date)


# ── 1. Filename rendering ──────────────────────────────────────────────


def build_render_context(
    feed_config: Mapping[str, Any],
    *,
    business_date: Optional[date] = None,
    run_date: Optional[date] = None,
    calendar: Optional[BusinessCalendar] = None,
    run_id: Optional[int] = None,
    extras: Optional[Mapping[str, str]] = None,
) -> RenderContext:
    """Build a RenderContext from a feed_config row + injected calendar.

    Calendar is optional — if absent we still set business_date but
    leave the COB_* helpers as None (the renderer raises on use, which
    is the correct behaviour: missing calendar should not silently
    rewrite to wrong dates).
    """
    today = datetime.now(timezone.utc).date()
    run_d = run_date or today

    # business_date defaults to the business day BEFORE run_date, so a
    # late-evening run that crosses midnight UTC doesn't use tomorrow's date.
    #
    # 2026-09-02 (D1) — the two branches below used to disagree by a full day.
    # ``BusinessCalendar.previous_business_day`` explicitly does NOT return
    # ``d`` even when ``d`` is a business day ("the business day before this
    # date"), so the calendared branch lands on run_date-1 or earlier; the
    # no-calendar branch returned run_date itself.  The same feed therefore
    # produced a DIFFERENT business date -- and so different filenames and
    # different SQL parameters -- depending only on whether a calendar
    # happened to be attached.  No error either way.
    #
    # With no calendar every day is a business day, so "the business day
    # before run_date" is run_date - 1.  That is what the comment always
    # promised and what the calendared branch has always done.
    if business_date is not None:
        biz_d = business_date
    elif calendar is not None:
        biz_d = calendar.previous_business_day(run_d)
    else:
        biz_d = run_d - timedelta(days=1)
        # Loud, because this is a correctness fallback and not a default an
        # author chose: an operator must be able to see WHICH feeds are
        # running without a calendar and what date they resolved to.
        logger.warning(
            "[feed_pipeline] feed %s (%s) has NO calendar — business_date "
            "falls back to run_date-1 (%s from run_date %s).  Attach a "
            "calendar so business days and holidays are honoured.",
            feed_config.get("id"), feed_config.get("name", ""),
            biz_d.isoformat(), run_d.isoformat(),
        )

    cob_eom = None
    cob_prev_bd = None
    if calendar is not None:
        try:
            cob_eom = calendar.previous_eom(run_d)
        except Exception as e:
            logger.warning("[feed_pipeline] previous_eom failed: %s", e)
        try:
            cob_prev_bd = calendar.previous_business_day(run_d)
        except Exception as e:
            logger.warning("[feed_pipeline] previous_business_day failed: %s", e)

    return RenderContext(
        run_date=run_d,
        business_date=biz_d,
        feed_name=str(feed_config.get("name", "feed")),
        feed_id=int(feed_config.get("id", 0) or 0),
        run_id=int(run_id) if run_id is not None else 0,
        cob_prev_eom=cob_eom,
        cob_prev_business_day=cob_prev_bd,
        extras=dict(extras) if extras else None,
    )


def render_filename_for_feed(
    template: str,
    fmt_extension: str,
    feed_config: Mapping[str, Any],
    *,
    calendar: Optional[BusinessCalendar] = None,
    business_date: Optional[date] = None,
    run_date: Optional[date] = None,
    run_id: Optional[int] = None,
    sequence_value: Optional[int] = None,
    legacy_renderer=None,
) -> str:
    """Render the output filename.

    Picks between the enterprise FilenameRenderer (when the template
    contains ${FUNC(FMT)} or {name:fmt} tokens) and the legacy
    {name}/{date}/{ext}/{timestamp}/{uuid} formatter.  Legacy callers
    pass ``legacy_renderer`` so the engine's own ``_build_filename``
    stays the source of truth for backwards compatibility.

    Sanitises the output to remove path-traversal characters.
    """
    rendered: str
    if template_uses_enterprise_tokens(template):
        ctx = build_render_context(
            feed_config,
            business_date=business_date,
            run_date=run_date,
            calendar=calendar,
            run_id=run_id,
            extras=_legacy_extras(feed_config, fmt_extension,
                                  business_date=business_date),
        )
        if sequence_value is not None:
            # dataclasses.replace, not mutation: RenderContext is frozen
            # so one context can be shared by the filename, the control
            # file and SQL binding without any of them surprising the
            # others.
            import dataclasses as _dc
            ctx = _dc.replace(ctx, sequence_value=int(sequence_value))
        rendered = FilenameRenderer().render(template, ctx)
    elif legacy_renderer is not None:
        rendered = legacy_renderer(template, feed_config, fmt_extension)
    else:
        # No legacy renderer injected: the Spark lane's counterparty
        # filename (core/spark_k8s/artifact_chain.counterparty_filename),
        # the control file, tests.  Phase 4 (2026-08-23): {name} is
        # sanitised EXACTLY like the engine's legacy data-filename builder
        # -- feed "FX Rates (EUR)" used to produce FX_Rates__EUR__*.csv
        # but "FX Rates (EUR)*.ctl", so consumers matching <base>.ctl to
        # <base>.csv never paired them.  2026-10-07: and {date} is the
        # BUSINESS date, from the same resolver (legacy_token_values).
        from .filename_renderer import legacy_token_values
        rendered = template.format(**legacy_token_values(
            feed_config.get("name", "feed"), fmt_extension,
            business_date=business_date))
    return _sanitise_filename(rendered)


def _sanitise_filename(name: str) -> str:
    """Strip leading slashes, ``..`` segments, and disallowed characters.

    We intentionally do NOT strip dots inside the filename (legitimate
    e.g. ``feed_20260515.dat`` has dots).  Only collapse traversal
    segments and reject NUL.
    """
    if "\x00" in name:
        raise ValueError("filename contains NUL byte")
    # Remove leading path components — keep only the last segment.
    # Enterprise templates SHOULDN'T put '/' in the filename but we
    # defend against accidentally embedded paths from a misconfigured
    # ``output_filename_template``.
    name = Path(name).name
    if name in ("", ".", ".."):
        raise ValueError(f"refusing invalid filename: {name!r}")
    return name


# ── 2. Compression ─────────────────────────────────────────────────────


def apply_compression(
    output_path: Path,
    compression: Optional[str],
    *,
    delete_input: bool = True,
) -> CompressionResult:
    """Optionally compress the output file.

    ``compression`` is the raw config string (``None`` / ``""`` /
    ``"none"`` are all no-ops; ``"gzip"``, ``"gz"``, ``"bzip2"``,
    ``"bz2"``, ``"zstd"``, ``"snappy"`` all recognised).  Returns the
    ``CompressionResult`` so the caller knows the final path / sizes.
    """
    fmt = CompressionFormat.from_str(compression)
    writer = CompressionWriter()
    return writer.compress(output_path, fmt, delete_input=delete_input)


# ── 2b. Packaging / encryption / sidecar — the native lane's halves of
#        the fixed artifact order (2026-09-03).
#
# The spark lane runs the whole order inside
# ``core.spark_k8s.artifact_chain``.  The native single-file lane runs
# its steps from feed_engine, which today calls only apply_compression
# and the control-file writer.  These helpers are the missing steps,
# built here so the engine wiring is ONE call each (anchor:
# feed_engine's compression block, between apply_compression and the
# control file — package -> compress happens naturally because a
# packaged file is not re-compressed; encryption runs AFTER compression
# and BEFORE the checksum/control file so every digest attests the SENT
# bytes, FR-ART-02/FR-SEC-08).  Until the engine calls apply_encryption,
# ``delivery_hops`` refuses to deliver a plaintext artifact under a pgp
# contract — loud failure, never silent plaintext.


def apply_packaging(output_path: Path, packaging: Optional[str], *,
                    delete_input: bool = True) -> Path:
    """§10.2 — the ARCHIVE axis for the native single-file lane: wrap
    the output in a zip/tar archive carrying its own name inside.
    ``None``/``""``/``"none"`` are no-ops (returns the input path)."""
    pack = str(packaging or "none").strip().lower()
    if pack in ("", "none"):
        return Path(output_path)
    src = Path(output_path)
    if pack == "zip":
        import zipfile
        dest = src.with_name(src.stem + ".zip")
        with zipfile.ZipFile(dest, "w", zipfile.ZIP_STORED) as zf:
            zf.write(src, arcname=src.name)
    elif pack == "tar":
        import tarfile
        dest = src.with_name(src.stem + ".tar")
        with tarfile.open(dest, "w") as tf:
            tf.add(src, arcname=src.name)
    else:
        raise ValueError(
            f"unknown packaging {packaging!r} — none|zip|tar (§10.2; "
            f"gzip and friends are the CODEC axis)")
    if delete_input:
        try:
            src.unlink()
        except OSError:
            logger.warning("[feed_pipeline] packaged %s but could not "
                           "remove the original", src)
    return dest


def apply_encryption(output_path: Path, feed_config: Mapping[str, Any], *,
                     delete_input: bool = True) -> Path:
    """FR-ART-06 / FR-SEC-08 — encrypt the native lane's output to the
    contract's recipient key via the single ``core.feed.pgp``
    chokepoint.  No-op when the contract declares no encryption.

    Every failure RAISES.  There is no path from "encryption declared"
    to "plaintext returned" — the caller either gets the ``.pgp`` path
    or an exception that fails the run loudly."""
    options = dict(feed_config.get("output_options") or {})
    enc = str(options.get("encryption") or "none").strip().lower()
    if enc in ("", "none"):
        return Path(output_path)
    if enc != "pgp":
        raise ValueError(
            f"unknown encryption {enc!r} — only 'pgp' is supported "
            f"(FR-ART-06)")
    from .pgp import encrypt_file
    key = str(options.get("pgp_public_key") or "")
    if not key.strip():
        raise ValueError(
            "encryption=pgp with no recipient public key "
            "(output_options.pgp_public_key) — there is nobody to "
            "encrypt to (FR-ART-06)")
    return encrypt_file(Path(output_path), key, delete_input=delete_input)


def write_checksum_sidecar_for_feed(
        output_path: Path, feed_config: Mapping[str, Any],
        precomputed: Any = None) -> Optional[Path]:
    """FR-ART-05 — the ``<file>.md5`` digest sidecar for the native
    lane, in the coreutils shape counterparties diff against.  Returns
    the sidecar path, or None when the contract declares none.  Must be
    called on the FINAL artifact (post compress/encrypt): the digest
    attests the sent bytes (FR-ART-02)."""
    options = dict(feed_config.get("output_options") or {})
    side = str(options.get("sidecar") or "none").strip().lower()
    if side not in ("per_file", "manifest"):
        return None
    from .checksum import compute_file_checksum, normalise_algorithm
    algo = normalise_algorithm(str(
        options.get("checksum_algorithm") or options.get("checksum") or ""))
    if not algo:
        raise ValueError(
            f"sidecar={side!r} declared with no checksum algorithm — a "
            f"digest sidecar with no digest is a contradiction (FR-ART-05)")
    src = Path(output_path)
    # 2026-10-15 -- checksum_covers=uncompressed: the digest of the DATA file
    # taken before the chain (core/feed/checksum_covers.py), and the line
    # names that file; the sidecar still travels beside the sent file.
    if precomputed is not None:
        digest, named = precomputed.get(algo), precomputed.name
    else:
        digest, named = compute_file_checksum(src, algo), src.name
    style = str(options.get("digest_line") or "coreutils").strip().lower()
    line = f"{digest}  {named}" if style == "coreutils" else digest
    sidecar = src.with_name(src.name + f".{algo}")
    sidecar.write_text(line + "\n", encoding="ascii")
    return sidecar


# ── 3. Control file ────────────────────────────────────────────────────


def _resolve_default_ctl_layout(
    style: Optional[str], delimiter: Optional[str]
) -> tuple:
    """Fill an unset control-file ``style`` / ``delimiter`` from the global
    ``feed_generation.control_file_style`` / ``control_file_delimiter``
    knobs (2026-09-02 — these were declared ghosts: an operator setting
    them got a 200, a saved value and a key_value file anyway).

    Only consulted when the feed has NO per-feed ``format_spec`` — a
    per-feed counterparty contract must always beat a global default.
    An argument the caller passed explicitly is never overridden.  The
    accessor fallbacks are ``"key_value"`` / ``"|"``, so a deployment
    that never set the knobs produces byte-for-byte today's output.
    Imported lazily so module import stays config-free.
    """
    if style is None or delimiter is None:
        from core.config import feed_generation as _fg_cfg
        if style is None:
            style = _fg_cfg.control_file_style
        if delimiter is None:
            delimiter = _fg_cfg.control_file_delimiter
    return style, delimiter


def write_control_file_for_feed(
    *,
    output_path: Path,
    output_filename: str,
    row_count: int,
    byte_size: int,
    feed_config: Mapping[str, Any],
    business_date: Optional[date] = None,
    run_date: Optional[date] = None,
    run_id: Optional[int] = None,
    calendar: Optional[BusinessCalendar] = None,
    style: Optional[str] = None,
    delimiter: Optional[str] = None,
    include_checksum: bool = True,
    format_spec: Optional[ControlFormatSpec] = None,
    precomputed: Any = None,
) -> Optional[Path]:
    """Render + write the sidecar control file.

    Skipped (returns ``None``) when ``feed_config.control_file_template``
    is empty.  When present, the template goes through the same
    FilenameRenderer pipeline so callers can use the enterprise tokens.

    Phase 130 hotfix-4 — when ``format_spec`` is supplied (resolved by
    the caller from the DB ``feed_control_file_formats`` table via
    ``feed_config.control_file_format_id``), the spec drives field
    layout + checksum algorithms.  Multiple checksums are computed in
    a single read pass over the data file.

    Layout precedence (2026-09-02 — the global knobs used to be GHOSTS:
    declared in config, read by nothing):

      1. ``format_spec`` (the feed's ``control_file_format_id`` DB row)
         wins absolutely — a global default must never override a
         per-feed contract with a counterparty.
      2. An explicit ``style`` / ``delimiter`` argument from the caller.
      3. ``feed_generation.control_file_style`` / ``control_file_delimiter``
         from global config (resolved here, at the single chokepoint
         every control file goes through).
      4. The accessor fallbacks ``"key_value"`` / ``"|"`` — byte-for-byte
         today's output, so a deployment that never set the knobs is
         unchanged.

    Best practice — checksum is computed AFTER compression so the
    digest matches what the recipient downloads.  ``output_path`` MUST
    be the final (post-compression) data file.
    """
    template = feed_config.get("control_file_template")
    if not template and format_spec is None:
        return None

    if template:
        ctl_name = render_filename_for_feed(
            template,
            "ctl",
            feed_config,
            calendar=calendar,
            business_date=business_date,
            run_date=run_date,
            run_id=run_id,
            legacy_renderer=None,
        )
    else:
        # Phase 4 (2026-08-23): a feed with control_file_format_id but no
        # template used to get NO ctl at all (the DataFlow blueprint and
        # the API said otherwise).  Default name pairs with the DATA file
        # -- <data-stem>.ctl -- the pairing every downstream watcher
        # matches on, and it can never drift from the data filename.
        ctl_name = Path(output_filename).stem + ".ctl"
    ctl_path = output_path.parent / ctl_name

    # Resolve which checksums to compute.  When a DB-driven spec is
    # supplied, that wins.  Otherwise: legacy behaviour = single SHA-256.
    if format_spec is not None:
        writer = ControlFileWriter(spec=format_spec)
        algorithms = list(format_spec.checksum_algorithms)
    else:
        # No per-feed format: an unset style/delimiter falls back to the
        # global feed_generation knobs (see precedence in the docstring).
        style, delimiter = _resolve_default_ctl_layout(style, delimiter)
        writer = ControlFileWriter(style=style, delimiter=delimiter)
        algorithms = list(writer.algorithms)  # ["sha256"]

    # Compute all requested algorithms in a single read pass.
    #
    # 2026-08-04 — FAIL-CLOSED (named default change: this used to warn and
    # ship the .ctl with its checksum fields silently EMPTY).  The control
    # file is the consumer's READY signal and the checksum is the only
    # integrity evidence it carries; a .ctl whose configured checksums are
    # missing is a READY signal that cannot be trusted, delivered as if it
    # could.  The checksum reads the file we JUST wrote — a failure here
    # means something is genuinely wrong (file vanished, disk error), and
    # the feed must fail loudly rather than certify with a hollow .ctl.
    digests: dict = {}
    if include_checksum and algorithms and precomputed is not None:
        # 2026-10-15 -- checksum_covers=uncompressed (checksum_covers.py)
        digests = {a: precomputed.get(a) for a in algorithms}
    elif include_checksum and algorithms:
        try:
            digests = _compute_checksums_all(output_path, algorithms)
        except Exception as e:
            raise RuntimeError(
                f"Control-file checksum computation failed for "
                f"{output_path} (algorithms={algorithms}): {e}.  Refusing "
                f"to ship a .ctl without its configured integrity fields — "
                f"the .ctl is the consumer's READY signal."
            ) from e

    record = ControlFileRecord(
        filename=output_filename,
        row_count=int(row_count),
        byte_size=int(byte_size),
        business_date=business_date,
        feed_name=str(feed_config.get("name", "feed")),
        feed_id=int(feed_config.get("id", 0) or 0),
        run_id=int(run_id) if run_id is not None else None,
        checksum_md5=digests.get("md5"),
        checksum_sha1=digests.get("sha1"),
        checksum_sha256=digests.get("sha256"),
        checksum_sha512=digests.get("sha512"),
        checksum_crc32=digests.get("crc32"),
        generated_at=datetime.now(timezone.utc),
    )
    writer.write(record, ctl_path)
    return ctl_path


# ── 4. Calendar resolution helper ──────────────────────────────────────


def resolve_calendar_for_feed(
    feed_config: Mapping[str, Any],
    repo: Optional[BusinessCalendarRepo],
) -> Optional[BusinessCalendar]:
    """Look up the BusinessCalendar named by ``feed_config.calendar_name``.

    Returns ``None`` when:
      - the feed has no ``calendar_name`` configured
      - the repo argument is ``None`` (caller chose not to wire it)
      - the named calendar does not resolve

    The third case is intentionally non-fatal: the rest of the
    pipeline tolerates a missing calendar (FilenameRenderer raises
    on COB_* usage, which is the correct loud-fail).
    """
    cal_name = feed_config.get("calendar_name")
    if not cal_name or repo is None:
        return None
    spec = repo.get(str(cal_name))
    if spec is None:
        logger.info(
            "[feed_pipeline] calendar %r not found in DB — leaving calendar None",
            cal_name,
        )
        return None
    return BusinessCalendar(spec)
