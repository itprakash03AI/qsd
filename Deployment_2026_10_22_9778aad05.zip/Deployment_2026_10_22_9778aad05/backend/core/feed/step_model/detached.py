"""Step rows of a run whose work continues ON A JOB after the engine's
coroutine ends (2026-10-18): the detached lanes, ``spark_k8s`` and
``airflow`` (which submits the same job).

Found on the rig (RP_POD_HIVE_SPARK): the engine submits, awaits the row,
and returns; its ``finally`` closed every step it never entered as
``skipped`` -- "the run ended 'ended' before this step started" -- while
the job was formatting, checking and DELIVERING the file.  The record said
delivery was skipped for a file the counterparty had; the board drew five
grey dots and said "7 of 7 steps done".  Two answers.

ONE model, declared on the step classes and read here:

* ``FeedPipelineStep.PERFORMED_BY_JOB_ON`` -- the lanes on which the JOB
  performs this step after the hand-off.  At submit, :func:`hand_to_job`
  moves each such planned row to ``running`` with ``executor`` = the lane
  and ``worker_node`` = the job's name: the board shows them running on the
  job, never skipped.
* ``FeedPipelineStep.NOT_PERFORMED_ON`` -- lane -> reason, for a step the
  lane genuinely does not do; closed ``skipped`` WITH that reason at the
  hand-off, so "not applicable" is said and never looks like "not
  reached".
* :func:`close_from_job` -- called by the ONE completion finaliser per state
  (``core/spark_k8s/completion.py``: the webhook's body, the reconciler's
  report, the persisted claim -- all roads): on success every handed step is
  ``completed`` with the evidence the job reported in the slots the native
  lane uses (rows, the destination and the delivery verdict, the receipt's
  verification, the count certification); on failure the step the run
  failed in is ``failed`` with the job's headline and the ones after it are
  ``skipped`` as not reached.
* :func:`settle_handed` -- the engine's own finalisation asks it: a job
  still running keeps its rows running (they are closed when it reports);
  an execution already terminal is closed through the same closer.

A step never handed (the native lane) is untouched by everything here.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Mapping, Optional

from core.db.models import FeedRunStep
from core.feed.step_model.contract import DETACHED_LANES
from core.feed.step_model.store import latest_attempts, run_id_for_execution

logger = logging.getLogger(__name__)

# THE CURRENT ATTEMPT (2026-10-18, the rig: RP_POD_PROGRESS run 40 attempt 3):
# every function here acts on the LATEST attempt of each step and, when the
# execution is known, only on rows stamped with THAT execution -- a re-run
# opens attempt N+1 under the new execution id (store.open_new_attempt), and
# a row of an earlier attempt is never touched.  ``executor`` is the lane's
# for the attempt that was handed; a fresh attempt is the engine's again
# (store._fresh_executor), so the hand-off eligibility reads the PLAN's
# executor through the class, never a previous attempt's marker.
#: ``outputs`` key stamped on a handed row (survives the close)
HANDED_KEY = "performed_by"
#: the stage word a refused reported-rows certification is booked at
#: (core/spark_k8s/completion.py::CERTIFY_STAGE) -> the step that owns it
_STAGE_TO_ALIAS = {"certify_reported_rows": "row_count_check"}
_TERMINAL = ("completed", "failed", "cancelled")


def _cls_for(step_type: str):
    try:
        from core.feed.step_model.registry import get_registry
        return type(get_registry().resolve(step_type))
    except Exception:                                   # noqa: BLE001 -- unknown class: not handed
        return None


def _job_words(lane: str, job_name: str) -> str:
    return f"performed by the {lane} job {job_name or '(unnamed)'}"


def hand_to_job(db, feed_run_id: int, *, execution_id: str, lane: str,
                job_name: str) -> Dict[str, List[str]]:
    """At submit: the planned steps the JOB performs become ``running`` on
    the job; the ones the lane never does are closed ``skipped`` with the
    lane's reason.  Idempotent (a row already past ``not_started`` is left
    alone).  Returns ``{"handed": [...], "not_performed": [...]}``."""
    handed: List[str] = []
    not_performed: List[str] = []
    now = datetime.now(timezone.utc)
    eid = str(execution_id or "").strip()
    with db.get_session() as session:
        rows = (session.query(FeedRunStep)
                .filter(FeedRunStep.feed_run_id == int(feed_run_id))
                .order_by(FeedRunStep.seq.asc(), FeedRunStep.attempt.desc()).all())
        seen = set()
        for row in rows:
            if row.alias in seen:
                continue                                # the latest attempt only
            seen.add(row.alias)
            if row.status != "not_started":
                continue
            if eid and row.execution_id and str(row.execution_id) != eid:
                # the latest attempt belongs to ANOTHER execution: no fresh
                # attempt was opened for this one -- handing it would write
                # this run onto that attempt's record
                logger.warning("[feed_steps] run %s step %s: the latest attempt (%s) is execution %s, "
                               "not %s -- not handed", feed_run_id, row.alias, row.attempt,
                               row.execution_id, eid)
                continue
            if row.executor != "engine":
                continue                                # a runner step is never the job's
            cls = _cls_for(row.step_type)
            if cls is None:
                continue
            if lane in tuple(getattr(cls, "PERFORMED_BY_JOB_ON", ()) or ()):
                row.status = "running"
                row.started_at = now
                row.ended_at = None
                row.error = None
                row.executor = str(lane)[:20]
                row.worker_node = str(job_name or "")[:255] or None
                if execution_id:
                    row.execution_id = execution_id
                row.outputs = {**dict(row.outputs or {}), HANDED_KEY: _job_words(lane, job_name)}
                handed.append(row.alias)
            else:
                reason = (getattr(cls, "NOT_PERFORMED_ON", {}) or {}).get(lane)
                if reason:
                    row.status = "skipped"
                    row.ended_at = now
                    row.error = str(reason)[:4000]
                    if execution_id:
                        row.execution_id = execution_id
                    not_performed.append(row.alias)
        session.flush()
    if handed or not_performed:
        logger.info("[feed_steps] run %s handed to the %s job %s: %s running on the job%s",
                    feed_run_id, lane, job_name, handed,
                    f"; not performed on this lane: {not_performed}" if not_performed else "")
    return {"handed": handed, "not_performed": not_performed}


def handed_rows(db, feed_run_id: int) -> List[Dict[str, Any]]:
    """The LATEST attempt of each step still RUNNING on a job (handed, not
    yet closed).  The latest attempt IS the current execution's: a re-run
    opens attempt N+1 before it submits (recorder.ensure_rows), and
    ``hand_to_job`` refuses a latest attempt stamped with another execution."""
    return [r for r in latest_attempts(db, int(feed_run_id))
            if r.get("status") == "running" and str(r.get("executor") or "") in DETACHED_LANES]


# ── the evidence per step, from what the job reported ──────────────────

def _evidence(alias: str, execution: Mapping[str, Any], report: Mapping[str, Any],
              final: Mapping[str, Any]) -> Dict[str, Any]:
    """``{"status", "rows_out", "outputs", "error"}`` for a handed step of a
    run that ENDED COMPLETED: the same facts the native lane records,
    read from the job's report and the row the finaliser wrote.  A step
    the job reported nothing about is ``skipped`` with that reason --
    never claimed."""
    st = execution.get("stage_timings") if isinstance(execution.get("stage_timings"), Mapping) else {}
    st = {**st, **(final.get("stage_timings") or {})} if isinstance(final.get("stage_timings"), Mapping) else st
    rows = report.get("output_row_count")
    rows = rows if isinstance(rows, int) and not isinstance(rows, bool) else (
        final.get("total_rows") if isinstance(final.get("total_rows"), int) else execution.get("total_rows"))
    dest = (final.get("destination_path") or execution.get("destination_path")
            or (report.get("output_path") if report.get("delivered") is not False else None))
    chain = st.get("delivery_chain") if isinstance(st.get("delivery_chain"), Mapping) else {}
    ver = st.get("delivery_verification") if isinstance(st.get("delivery_verification"), Mapping) else {}
    rr = report.get("reported_rows_certification") if isinstance(report.get("reported_rows_certification"), Mapping) else (
        st.get("reported_rows_certification") if isinstance(st.get("reported_rows_certification"), Mapping) else {})
    if alias == "format_output":
        name = str(dest or report.get("output_path") or "").rstrip("/").rsplit("/", 1)[-1]
        out = {k: v for k, v in {"formatted_file": name or None,
                                  "lane_output_version": report.get("lane_output_version")}.items() if v}
        return {"status": "completed", "rows_out": rows, "outputs": out, "error": None}
    if alias == "local_integrity":
        # ONLY what the JOB reported is evidence (2026-10-18, the rig: an 18M-row
        # Spark run had execution.file_size_bytes = 0 -- the column's default, the
        # job never sent a size -- and this step was marked completed on it)
        size = report.get("output_size_bytes")
        if size is None:
            if _table_delivery(report, dest):
                return {"status": "skipped", "rows_out": None, "outputs": {},
                        "error": ("not a file: the job delivered into a database table (rows inserted, "
                                  "counted by the destination) -- there is no local file to check")}
            return {"status": "skipped", "rows_out": None, "outputs": {},
                    "error": "the job reported no local integrity facts (no file size) for this run"}
        return {"status": "completed", "rows_out": rows,
                "outputs": {"size_bytes": size}, "error": None}
    if alias == "row_count_check":
        if not rr:
            return {"status": "skipped", "rows_out": rows, "outputs": {},
                    "error": ("the job compared no count: no upstream message count was declared "
                              "for this run (the previous-delivery variance check is a native-lane check)")}
        return {"status": "completed", "rows_out": rows,
                "outputs": {"certification": str(rr.get("verdict") or ""), "reported_by": "job"},
                "error": None}
    if alias == "deliver_artifact":
        verdict = str(chain.get("verdict") or ("delivered" if dest else "")) or None
        if not dest and verdict not in ("delivered", "suppressed"):
            return {"status": "skipped", "rows_out": None, "outputs": {},
                    "error": "the job reported no delivery for this run"}
        dr = report.get("delivered_rows")
        return {"status": "completed", "rows_out": rows,
                "outputs": {k: v for k, v in {"delivered": dest, "verdict": verdict,
                                              "reported_by": chain.get("reported_by") or "job",
                                              "delivered_rows": dr if isinstance(dr, int) and not isinstance(dr, bool) else None,
                                              "dropped_rows": report.get("dropped_rows") or None}.items() if v is not None},
                "error": None}
    if alias == "post_delivery_integrity":
        if not ver:
            return {"status": "skipped", "rows_out": None, "outputs": {},
                    "error": "the job reported no post-delivery verification (no receipt) for this run"}
        return {"status": "completed", "rows_out": None,
                "outputs": {"verification": str(ver.get("status") or ""), "detail": str(ver.get("detail") or "")[:500]},
                "error": None}
    # a step this module does not know by name: the job performed it and the
    # run completed -- completed, with what was reported
    return {"status": "completed", "rows_out": rows, "outputs": {}, "error": None}


def _table_delivery(report: Mapping[str, Any], dest: Any) -> bool:
    """The job delivered into a TABLE (an Oracle publish): it reports the rows
    the destination counted and a ``<scheme>://`` path that is no file."""
    if isinstance(report.get("delivered_rows"), int):
        return True
    return str(dest or report.get("output_path") or "").lower().startswith(("oracle://", "jdbc:"))


def _alias_for_stage(stage: str, rows: Iterable[Mapping[str, Any]]) -> Optional[str]:
    stage = str(stage or "")
    if not stage:
        return None
    if stage in _STAGE_TO_ALIAS:
        return _STAGE_TO_ALIAS[stage]
    for r in rows:
        cls = _cls_for(str(r.get("step_type") or ""))
        try:
            if cls is not None and cls.matches_engine_stage(stage):
                return r.get("alias")
        except Exception:                               # noqa: BLE001
            continue
    return None


def close_from_job(db, execution: Mapping[str, Any], *, final: Mapping[str, Any],
                   report: Optional[Mapping[str, Any]] = None, via: str = "") -> Dict[str, str]:
    """Close the handed rows of ``execution`` from the finaliser's verdict
    (``final``: the status update it applied -- status, error_message,
    failed_stage, stage_timings ...) and the job's report.  Idempotent and
    bookkeeping: never raises into the finaliser; returns
    ``{alias: status}`` of what it closed (empty = nothing handed)."""
    try:
        return _close_from_job(db, execution, final=final or {}, report=report or {}, via=via)
    except Exception as exc:                            # noqa: BLE001 -- the run's record stands
        logger.error("[feed_steps] the handed steps of %s could not be closed (%s): %s",
                     execution.get("execution_id"), via, exc, exc_info=True)
        return {}


def _close_from_job(db, execution, *, final, report, via) -> Dict[str, str]:
    exec_id = str(execution.get("execution_id") or "")
    run_id = run_id_for_execution(db, exec_id)
    if run_id is None:
        return {}
    open_rows = handed_rows(db, run_id)
    if not open_rows:
        return {}
    status = str(final.get("status") or execution.get("status") or "").lower()
    closed: Dict[str, str] = {}
    now = datetime.now(timezone.utc)
    with db.get_session() as session:
        if status == "completed":
            for r in open_rows:
                ev = _evidence(r["alias"], execution, report, final)
                _finish(session, r["id"], ev["status"], rows_out=ev["rows_out"],
                        outputs=ev["outputs"], error=ev["error"], now=now)
                closed[r["alias"]] = ev["status"]
        elif status == "failed":
            stage = str(final.get("failed_stage") or execution.get("failed_stage") or "")
            headline = str(final.get("error_message") or execution.get("error_message") or "the job failed")
            culprit = _alias_for_stage(stage, open_rows)
            culprit_seq = next((r["seq"] for r in open_rows if r["alias"] == culprit), None)
            job_succeeded = str(report.get("state") or "").lower() == "success"
            for r in open_rows:
                if r["alias"] == culprit:
                    _finish(session, r["id"], "failed", error=headline, now=now)
                    closed[r["alias"]] = "failed"
                elif culprit_seq is not None and r["seq"] < culprit_seq and job_succeeded:
                    # the job reported success and QueryStudio's own later
                    # step (a webhook-side delivery) failed: the job's steps
                    # before it stand, with their evidence
                    ev = _evidence(r["alias"], execution, report, final)
                    _finish(session, r["id"], ev["status"], rows_out=ev["rows_out"],
                            outputs=ev["outputs"], error=ev["error"], now=now)
                    closed[r["alias"]] = ev["status"]
                else:
                    where = f" at {stage}" if stage else ""
                    _finish(session, r["id"], "skipped", now=now,
                            error=f"not reached: the run failed{where} -- {headline}"[:4000])
                    closed[r["alias"]] = "skipped"
        elif status == "cancelled":
            for r in open_rows:
                _finish(session, r["id"], "cancelled", now=now,
                        error="the run was cancelled while this step was on the job")
                closed[r["alias"]] = "cancelled"
        else:
            return {}
        session.flush()
    logger.info("[feed_steps] %s: handed steps closed from the %s (%s): %s", exec_id, via or "finaliser",
                status, closed)
    return closed


def _finish(session, row_id: int, status: str, *, rows_out=None, outputs=None, error=None, now) -> None:
    row = session.get(FeedRunStep, int(row_id))
    if row is None:
        return
    row.status = status
    row.ended_at = now
    if row.started_at is not None:
        started = row.started_at if row.started_at.tzinfo else row.started_at.replace(tzinfo=timezone.utc)
        row.duration_seconds = round((now - started).total_seconds(), 3)
    if rows_out is not None and isinstance(rows_out, int) and not isinstance(rows_out, bool):
        row.rows_out = rows_out
    merged = dict(row.outputs or {})
    merged.update({k: str(v) for k, v in (outputs or {}).items() if v is not None})
    row.outputs = merged
    row.error = (str(error)[:4000] if error else None)


def settle_handed(db, feed_run_id: int, execution_id: str) -> List[str]:
    """The engine's finalisation: the handed rows of this run that must be
    LEFT OPEN because the job is still running (returned, by alias), after
    closing them when the execution is already terminal -- through the
    same closer the completion finalisers use, so whichever side comes
    last the record is the same."""
    try:
        open_rows = handed_rows(db, int(feed_run_id))
        if not open_rows:
            return []
        ex = db.get_feed_execution_by_exec_id(str(execution_id)) if execution_id else None
        if ex and str(ex.get("status") or "").lower() in _TERMINAL:
            closed = close_from_job(db, ex, final=dict(ex), report={}, via="engine finalisation")
            return [r["alias"] for r in open_rows if r["alias"] not in closed]
        return [r["alias"] for r in open_rows]
    except Exception as exc:                            # noqa: BLE001 -- leave them open rather than lie
        logger.error("[feed_steps] handed steps of run %s could not be settled: %s", feed_run_id, exc)
        return [r.get("alias") for r in (handed_rows(db, int(feed_run_id)) if db else [])]


__all__ = ["DETACHED_LANES", "HANDED_KEY", "hand_to_job", "handed_rows", "close_from_job", "settle_handed"]
