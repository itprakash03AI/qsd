"""Persistence for ``feed_run_steps`` — one row per step per ATTEMPT.

Every function here is fail-LOUD to its caller and the CALLER decides
what a failure costs.  Nothing in this module swallows an error on the
theory that a timeline is optional; the recorder does that, once, at the
one place where it is a deliberate choice (a run must not die because its
bookkeeping did), and it says so where it does it.

WHY AN ATTEMPT IS A ROW
-----------------------
OG kept ``RETRY_COUNT`` on the one row.  A retried step overwrote its own
record and what the first attempt did — how far it got, what it wrote,
how it failed — was gone.  Identity here is
``(feed_run_id, alias, attempt)``, so history is appended and never
overwritten.  "A replay reports the LATEST, never the SUM" is a rule
about reading these rows, and it only holds if both attempts survive to
be read.
"""
from __future__ import annotations

import logging
import socket
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Mapping, Optional

from core.db.models import (
    FEED_RUN_STEP_GREEN_STATUSES,
    FEED_RUN_STEP_STATUSES,
    FeedFlow,
    FeedFlowStep,
    FeedRunStep,
)

logger = logging.getLogger(__name__)


def _fresh_executor(template_executor: Any) -> str:
    """The executor a FRESH attempt row starts with (2026-10-18).  A step
    handed to a detached job carries the lane as its executor for THAT
    attempt only; the next attempt is the engine's again, to be handed (or
    not) by its own run.  Found on the rig: attempt 3 of RP_POD_PROGRESS
    copied ``spark_k8s`` from attempt 2, the hand-off saw a non-engine row
    and left it, and the engine's finally closed the job's steps as skipped
    while the pod delivered 2.6 GB."""
    from core.feed.step_model.contract import DETACHED_LANES
    ex = str(template_executor or "")
    return "engine" if ex in DETACHED_LANES else ex


#: PostgreSQL ``bigint`` bounds.  ``rows_in``/``rows_out`` are BigInteger,
#: but a caller can still hand us something absurd (a byte count where a
#: row count was meant), and a value the column cannot take would strand
#: the TERMINAL write — the step would finish and the row would say
#: ``running`` forever.  Clamped with a loud log, never silently.
_BIGINT_MAX = 9_223_372_036_854_775_807


def worker_node() -> str:
    """Which pod ran it.  We are multi-pod; without this a step record is
    unusable at 3am."""
    try:
        return socket.gethostname()[:120]
    except Exception:                              # noqa: BLE001
        return "unknown"


def _business_date(value: Any):
    """A business date may arrive as ``date`` or as the ISO string a
    ``to_dict()`` produced.

    Both callers that matter hand us the DICT form — the SOD generator
    passes what ``create_feed_run`` returned, and the engine passes what
    ``get_feed_run`` returned — so the string case is the NORMAL one, not
    an edge.  Coerced here rather than at each call site: a date column
    handed a string fails at INSERT, which is the whole row lost, not one
    field.

    Returns None for an uncoercible value and logs it.  The column is
    nullable and denormalised (the authority is ``feed_runs``), so a
    missing copy costs an index-only convenience — never the step record.
    """
    from datetime import date as _date, datetime as _dt
    if value is None or isinstance(value, _date) and not isinstance(value, _dt):
        return value
    if isinstance(value, _dt):
        return value.date()
    try:
        return _dt.fromisoformat(str(value)[:10]).date()
    except (TypeError, ValueError):
        logger.warning(
            "[feed-pipeline] business_date %r could not be coerced to a "
            "date; the step rows are written without their denormalised "
            "copy (feed_runs remains the authority)", value)
        return None


def _rows(value: Any, field: str, alias: str) -> Optional[int]:
    if value is None:
        return None
    try:
        n = int(value)
    except (TypeError, ValueError):
        logger.warning(
            "[feed-pipeline] step %s reported a non-numeric %s (%r) — "
            "recording NO count rather than a zero, because 'no count' "
            "and 'zero rows' are opposite findings", alias, field, value)
        return None
    if abs(n) > _BIGINT_MAX:
        logger.error(
            "[feed-pipeline] step %s reported %s=%s, outside the column's "
            "range — recording NO count.  A value the column cannot take "
            "would strand the terminal write and leave the step 'running' "
            "forever", alias, field, n)
        return None
    return n


def create_planned_steps(db_manager, feed_run: Mapping[str, Any],
                         plan, *, execution_id: str = "") -> int:
    """Write the plan as ``not_started`` rows.  Idempotent.

    Called at SOD, so the estate answers "what will run tonight, and what
    has not started" as a READ — the property that makes OG's Not-Started
    counts free rather than a separate feature.

    Idempotent by the unique key: a re-plan of a run that already has
    rows writes nothing and returns 0.  It does NOT update the existing
    rows: a run's plan is what it was PLANNED with, and quietly
    re-pointing it at today's registry is the same class of defect as a
    backfill executing today's definition.
    """
    run_id = int(feed_run["id"])
    with db_manager.get_session() as session:
        existing = {
            r.alias for r in session.query(FeedRunStep.alias)
            .filter(FeedRunStep.feed_run_id == run_id).all()
        }
        if existing:
            return 0
        for planned in plan.steps:
            session.add(FeedRunStep(
                feed_run_id=run_id,
                feed_config_id=feed_run.get("feed_config_id"),
                business_date=_business_date(
                    feed_run.get("business_date")),
                execution_id=execution_id or None,
                alias=planned.alias,
                step_type=planned.step_type,
                seq=planned.seq,
                level=planned.level,
                depends_on=list(planned.depends_on),
                executor=planned.executor,
                status="not_started",
                attempt=1,
                max_attempts=planned.max_attempts,
                # The MASKED copy: the record has to say what the
                # step ran with, and must not become a place
                # credentials accumulate.
                params=dict(planned.stored_params or {}),
            ))
        return len(plan.steps)


def open_new_attempt(db_manager, feed_run_id: int, *,
                     execution_id: str = "") -> Optional[int]:
    """When a run is executed AGAIN (the Today page's rerun, a retry),
    give every planned step a fresh ``not_started`` row at attempt
    max+1, stamped with the new execution -- and return that attempt.

    Returns None when there is nothing to open: no rows yet, the latest
    rows are all still ``not_started`` (the first execution has not
    begun), or the latest rows already belong to THIS execution.

    2026-09-14 -- without this, ``begin_attempt(attempt=None)`` found the
    previous execution's terminal row, returned it untouched, and
    ``finish_attempt`` then wrote the rerun's END time and duration onto
    the FIRST attempt's row: one row carrying the start of execution A
    and the finish of execution B, under A's execution id, and no
    attempt 2 anywhere.  Seen live on feed_run 14.  The model's promise
    is "a re-run appends, it never overwrites"; this is where a
    whole-run rerun keeps it.  Copies the same fields ``begin_attempt``
    copies for a per-step rerun, so the two attempt shapes cannot
    drift."""
    eid = str(execution_id or "").strip() or None
    with db_manager.get_session() as session:
        rows = (session.query(FeedRunStep)
                .filter(FeedRunStep.feed_run_id == int(feed_run_id))
                .order_by(FeedRunStep.seq, FeedRunStep.attempt).all())
        if not rows:
            return None
        latest: Dict[str, FeedRunStep] = {}
        for r in rows:
            prev = latest.get(r.alias)
            if prev is None or r.attempt >= prev.attempt:
                latest[r.alias] = r
        if all(r.status == "not_started" for r in latest.values()):
            return None                    # first execution, not begun
        if eid and any(r.execution_id == eid for r in latest.values()):
            return None                    # already this execution's
        new_attempt = max(r.attempt for r in latest.values()) + 1
        for template in sorted(latest.values(), key=lambda r: r.seq):
            session.add(FeedRunStep(
                feed_run_id=template.feed_run_id,
                feed_config_id=template.feed_config_id,
                business_date=template.business_date,
                execution_id=eid,
                alias=template.alias,
                step_type=template.step_type,
                seq=template.seq,
                level=template.level,
                depends_on=list(template.depends_on or []),
                executor=_fresh_executor(template.executor),
                status="not_started",
                attempt=new_attempt,
                max_attempts=template.max_attempts,
                params=dict(template.params or {}),
            ))
        session.flush()
        return int(new_attempt)


def list_run_steps(db_manager, feed_run_id: int) -> List[Dict[str, Any]]:
    """Every attempt of every step of one run, in (seq, attempt) order."""
    with db_manager.get_session(read_only=True) as session:
        rows = (session.query(FeedRunStep)
                .filter(FeedRunStep.feed_run_id == int(feed_run_id))
                .order_by(FeedRunStep.seq, FeedRunStep.attempt).all())
        return [r.to_dict() for r in rows]


def run_id_for_execution(db_manager, execution_id: str) -> Optional[int]:
    """The feed_run whose step rows were recorded under ``execution_id``,
    or None.

    ``feed_executions`` carries no ``feed_run_id`` and ``feed_runs`` no
    execution id; the recorder stamps the execution id on every step
    row it writes, so the rows ARE the link.  None means no run recorded
    steps for this execution -- true for a manual "Run Now", which runs
    with no feed_run row at all (feed_executor.run_feed only resolves a
    run when a business_date is supplied)."""
    eid = str(execution_id or "").strip()
    if not eid:
        return None
    with db_manager.get_session(read_only=True) as session:
        row = (session.query(FeedRunStep.feed_run_id)
               .filter(FeedRunStep.execution_id == eid)
               .order_by(FeedRunStep.feed_run_id.desc()).first())
        return int(row[0]) if row else None


def execution_id_for_run(db_manager, feed_run_id: int) -> Optional[str]:
    """The execution the run's LATEST attempt was recorded under, or
    None when no attempt has begun (planned rows carry no execution).

    The inverse of ``run_id_for_execution``.  Neither ``feed_runs`` nor
    ``feed_executions`` links the other; before 2026-09-14 the run
    screens answered "which execution" with the feed's NEWEST execution,
    so every run of a feed on a day wore the pod name of whichever run
    was last -- a false validation.  The recorder stamps the truth."""
    with db_manager.get_session(read_only=True) as session:
        row = (session.query(FeedRunStep.execution_id)
               .filter(FeedRunStep.feed_run_id == int(feed_run_id),
                       FeedRunStep.execution_id.isnot(None),
                       FeedRunStep.execution_id != "")
               .order_by(FeedRunStep.attempt.desc(), FeedRunStep.seq.asc())
               .first())
        return str(row[0]) if row and row[0] else None


def execution_ids_for_runs(db_manager, feed_run_ids) -> Dict[int, str]:
    """``execution_id_for_run`` for MANY runs in one query (2026-10-12).

    The run lists asked once per row -- 500 rows, 500 sessions, on the
    event loop: the API's watchdog caught a 14 s stall.  Same answer per
    run: the latest attempt's execution, the lowest seq within it."""
    ids = sorted({int(i) for i in (feed_run_ids or []) if i is not None})
    out: Dict[int, str] = {}
    if not ids:
        return out
    best: Dict[int, tuple] = {}
    with db_manager.get_session(read_only=True) as session:
        for chunk in range(0, len(ids), 900):
            rows = (session.query(FeedRunStep.feed_run_id, FeedRunStep.attempt,
                                  FeedRunStep.seq, FeedRunStep.execution_id)
                    .filter(FeedRunStep.feed_run_id.in_(ids[chunk:chunk + 900]),
                            FeedRunStep.execution_id.isnot(None),
                            FeedRunStep.execution_id != "")
                    .all())
            for rid, attempt, seq, eid in rows:
                key = (-(attempt or 0), seq if seq is not None else 0)
                if rid not in best or key < best[rid][0]:
                    best[rid] = (key, str(eid))
    return {rid: v[1] for rid, v in best.items()}


def latest_attempts(db_manager, feed_run_id: int) -> List[Dict[str, Any]]:
    """The LATEST attempt of each step — what the run screen shows."""
    latest: Dict[str, Dict[str, Any]] = {}
    for row in list_run_steps(db_manager, feed_run_id):
        prev = latest.get(row["alias"])
        if prev is None or row["attempt"] >= prev["attempt"]:
            latest[row["alias"]] = row
    return sorted(latest.values(), key=lambda r: (r["seq"], r["alias"]))


def begin_attempt(db_manager, feed_run_id: int, alias: str, *,
                  attempt: Optional[int] = None,
                  params: Optional[Mapping[str, Any]] = None,
                  execution_id: str = "",
                  triggered_by: Optional[str] = None,
                  rows_in: Optional[int] = None) -> Optional[int]:
    """Mark one step RUNNING; returns the row id.

    ``attempt=None`` means "the planned first attempt" — it updates the
    ``not_started`` row rather than adding a second.  An explicit attempt
    number APPENDS, which is what a re-run does.
    """
    now = datetime.now(timezone.utc)
    with db_manager.get_session() as session:
        if attempt is None:
            row = (session.query(FeedRunStep)
                   .filter(FeedRunStep.feed_run_id == int(feed_run_id),
                           FeedRunStep.alias == alias)
                   .order_by(FeedRunStep.attempt.desc()).first())
            if row is None:
                return None
            if row.status != "not_started":
                # Already ran in this attempt.  A second begin on the
                # same row would silently reset its start time and lose
                # what the first pass recorded.
                return int(row.id)
        else:
            template = (session.query(FeedRunStep)
                        .filter(FeedRunStep.feed_run_id == int(feed_run_id),
                                FeedRunStep.alias == alias)
                        .order_by(FeedRunStep.attempt.desc()).first())
            if template is None:
                return None
            row = FeedRunStep(
                feed_run_id=template.feed_run_id,
                feed_config_id=template.feed_config_id,
                business_date=template.business_date,
                alias=template.alias,
                step_type=template.step_type,
                seq=template.seq,
                level=template.level,
                depends_on=list(template.depends_on or []),
                executor=_fresh_executor(template.executor),
                max_attempts=template.max_attempts,
                attempt=int(attempt),
                params=dict(template.params or {}),
            )
            session.add(row)
        row.status = "running"
        row.started_at = now
        row.ended_at = None
        row.error = None
        row.worker_node = worker_node()
        if execution_id:
            row.execution_id = execution_id
        if triggered_by:
            row.triggered_by = triggered_by
        if params is not None:
            row.params = dict(params)
        if rows_in is not None:
            row.rows_in = _rows(rows_in, "rows_in", alias)
        session.flush()
        return int(row.id)


def finish_attempt(db_manager, row_id: int, status: str, *,
                   rows_out: Optional[int] = None,
                   outputs: Optional[Mapping[str, Any]] = None,
                   error: Optional[str] = None,
                   duration_seconds: Optional[float] = None) -> None:
    """Close one attempt.  ``status`` must be in the closed vocabulary."""
    if status not in FEED_RUN_STEP_STATUSES:
        raise ValueError(
            f"status {status!r} is not in the declared vocabulary "
            f"{list(FEED_RUN_STEP_STATUSES)} — a status the DB CHECK "
            f"constraint would reject must be refused here, where the "
            f"caller can still say something useful")
    now = datetime.now(timezone.utc)
    with db_manager.get_session() as session:
        row = session.get(FeedRunStep, int(row_id))
        if row is None:
            return
        row.status = status
        row.ended_at = now
        if duration_seconds is not None:
            row.duration_seconds = round(float(duration_seconds), 3)
        elif row.started_at is not None:
            started = row.started_at
            if started.tzinfo is None:
                started = started.replace(tzinfo=timezone.utc)
            row.duration_seconds = round((now - started).total_seconds(), 3)
        if rows_out is not None:
            row.rows_out = _rows(rows_out, "rows_out", row.alias)
        if outputs is not None:
            row.outputs = dict(outputs)
        if error is not None:
            row.error = str(error)[:4000]


def close_unfulfilled(db_manager, feed_run_id: int, *,
                      terminal_status: str, reason: str,
                      reasons: Optional[Mapping[str, str]] = None,
                      leave_open: Optional[Iterable[str]] = None) -> int:
    """At finalisation, close every step that never started.

    Two different findings, and they must not share a status:

    * the run FINISHED and a step never started — the engine's stage
      list is genuinely dynamic (per backend, per format, per integrity
      config), so this is ``skipped`` with the reason.  ``reasons``
      carries a PER-ALIAS explanation where the caller has one, which
      for a runner step is what it was still waiting on;
    * the run FAILED and later steps never started — those are
      ``skipped`` too, but the reason names the halt, because a step that
      never ran because an earlier one broke is not a step that did not
      apply.

    A row left at ``not_started`` forever reads as a hung step, and an
    operator cannot tell that from one the engine simply did not enter.

    ``leave_open`` (2026-10-18): aliases whose work continues ON A JOB
    after the engine returns (``detached.py``) -- still genuinely running,
    closed later from the job's report, never "stranded" here.
    """
    keep = {str(a) for a in (leave_open or ())}
    with db_manager.get_session() as session:
        rows = (session.query(FeedRunStep)
                .filter(FeedRunStep.feed_run_id == int(feed_run_id),
                        FeedRunStep.status.in_(("not_started", "running")))
                .all())
        n = 0
        for row in rows:
            if row.alias in keep:
                continue
            if row.status == "running":
                # It started and the run ended without it finishing.
                # That is a failure of the step, not a skip: pretending
                # otherwise would make a crashed pod look like a
                # deliberate omission.
                row.status = "failed"
                row.error = (row.error or
                             f"the run ended while this step was still "
                             f"running ({reason})")
            else:
                row.status = terminal_status
                # A PER-STEP reason when the caller has one ("waiting
                # on the step that produces its input, which failed"),
                # the generic one otherwise.  Deliberately not spelled
                # with a real step name -- the guard that forbids one in
                # this file is right, and it caught this comment.  The system logs what it DID and never what
                # it DECLINED to do; this is the answer to that for a
                # step that never got to run.
                row.error = (row.error
                             or (reasons or {}).get(row.alias)
                             or reason)
            row.ended_at = datetime.now(timezone.utc)
            n += 1
        return n


def first_not_green(steps: List[Mapping[str, Any]],
                    among: Optional[List[str]] = None):
    """The first step that is not green — RESUME, as a query.

    Not a feature with its own code path: if the per-step state is
    modelled properly, "re-run from the first non-green step" is a read
    over the latest attempts, in seq order.  ``among`` restricts the
    search to a dependency set, which is what the re-run gate needs (a
    step only cares about what it actually waited on, not about a
    sibling that ran beside it).
    """
    for row in sorted(steps, key=lambda r: (r.get("seq") or 0,
                                            r.get("alias") or "")):
        if among is not None and row.get("alias") not in among:
            continue
        if row.get("status") not in FEED_RUN_STEP_GREEN_STATUSES:
            return row
    return None


def resolve_flow_steps(db_manager, flow_id: Optional[int]) -> List[Dict[str, Any]]:
    """The enabled step rows of one flow, in seq order.

    Returns ``[]`` for ``flow_id=None`` — a feed mapped to no flow, which
    is every feed that exists today.  A flow_id that names NOTHING raises:
    "no flow" and "a flow that vanished" lead to opposite investigations,
    and the second must not quietly become the first.
    """
    if not flow_id:
        return []
    with db_manager.get_session(read_only=True) as session:
        flow = session.get(FeedFlow, int(flow_id))
        if flow is None:
            raise LookupError(
                f"feed is mapped to flow {flow_id}, which does not exist. "
                f"That is not the same as having no flow: the steps this "
                f"feed was configured to run cannot be resolved")
        if not flow.is_active:
            raise LookupError(
                f"flow {flow_id} ('{flow.name}') is INACTIVE.  Refusing "
                f"rather than planning the run without its steps")
        rows = (session.query(FeedFlowStep)
                .filter(FeedFlowStep.flow_id == int(flow_id),
                        FeedFlowStep.enabled == True)  # noqa: E712
                .order_by(FeedFlowStep.seq, FeedFlowStep.alias).all())
        return [r.to_dict() for r in rows]


__all__ = [
    "begin_attempt",
    "close_unfulfilled",
    "create_planned_steps",
    "finish_attempt",
    "first_not_green",
    "latest_attempts",
    "list_run_steps",
    "resolve_flow_steps",
    "worker_node",
]
