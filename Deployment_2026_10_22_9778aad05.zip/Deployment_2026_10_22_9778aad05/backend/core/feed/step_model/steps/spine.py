"""The engine's own work, DECLARED so it can be planned and recorded.

Every class here has ``EXECUTOR = "engine"``.  None of them executes
anything: ``core/feed_engine.py`` does the work exactly as it did before
this package existed, and ``core/feed/step_model/recorder.py`` maps the
stage the engine enters onto the planned row and flips it.

WHY DECLARE THEM AT ALL
-----------------------
Two reasons, and neither is decoration.

1. **The flow must show all of what happens.**  A screen that lists only
   the steps somebody added, with the extract and the delivery invisible,
   is a worse lie than the timing projection it replaces.
2. **The extension steps need something to depend on.**  A row-count
   floor declares ``REQUIRES = (row_count,)``; the only thing that
   produces ``row_count`` is the engine's query stage.  Without the spine
   there is no graph, and "run my check after the extract" would have to
   be written as a position — which is exactly the hardcoded list this
   design exists to avoid.

WHY THEY ARE NOT RE-RUNNABLE
-----------------------------
``RERUNNABLE = False``, stated, on every one.  Their state lives in
``execute_feed``'s local variables; there is nothing persisted to resume
from, so a per-step re-run button here would be a button that lies.
That is a real limitation of recording alone, and saying so is better
than papering over it — visibility is cheap, control is not, and they
are separate decisions.

The predicates are deliberately LOOSE.  The engine's stage list is
genuinely dynamic (per backend, per format, per destination, per
integrity config), and a step the engine did not enter is closed as
``skipped`` with that reason at finalisation rather than being predicted
here.  A predicate that tried to reproduce the engine's branch
conditions would be the same decision made twice, and the copy would be
the one that went stale.
"""
from __future__ import annotations

from core.dataflow.base import (
    CATEGORY_CONTROL,
    CATEGORY_QUALITY,
    CATEGORY_SINK,
    CATEGORY_SOURCE,
    CATEGORY_TRANSFORM,
    IDEMPOTENT_CONFIGURED,
    IDEMPOTENT_OVERWRITE,
    IDEMPOTENT_SAFE,
    IDEMPOTENT_UNSAFE,
)
from core.feed.step_model.contract import (
    ARTIFACT_ADMITTED,
    ARTIFACT_DELIVERED,
    ARTIFACT_EXTRACT,
    ARTIFACT_FORMATTED_FILE,
    ARTIFACT_ROW_COUNT,
    DETACHED_LANES as _DETACHED,
    FeedPipelineStep,
)


class _EngineStep(FeedPipelineStep):
    """Shared declaration for the spine.  NAME is empty so this is an
    abstract intermediate and never registers itself."""
    EXECUTOR = "engine"
    RERUNNABLE = False
    MAX_ATTEMPTS = 1


class RunAdmission(_EngineStep):
    """``status_running`` — the run is claimed, pinned and admitted.

    Also where the partition SHAPE is declared, which is why a refusal
    here costs only the admission and not the extract.
    """
    NAME = "run_admission"
    DISPLAY_NAME = "Run Admission"
    DESCRIPTION = ("The run is claimed and admitted: definition pinned, "
                   "partition shape declared, status flipped to running.")
    CATEGORY = CATEGORY_CONTROL
    PRODUCES = (ARTIFACT_ADMITTED,)
    IDEMPOTENCY = IDEMPOTENT_SAFE
    ENGINE_STAGE_TYPES = ("lifecycle", "partition", "fanout")


class SourceExtract(_EngineStep):
    """``query_{backend}`` — the extract, on whichever lane the router
    chose.  Produces the parquet AND the row count.

    The row count is an ARTIFACT, not a log line: the operator asked for
    "total record count if its Cloud to file" by name, and a count that
    only reaches a log cannot be read by the step that checks it.  We
    fixed a bug on 2026-09-05 where a row-cap disclosure was computed and
    thrown away, so a truncated feed certified VERIFIED — the same shape,
    and not one to rebuild.
    """
    NAME = "source_extract"
    DISPLAY_NAME = "Source Extract"
    DESCRIPTION = ("Runs the feed's query on the lane the router chose "
                   "(native, spark_k8s, spark_connect or airflow) and "
                   "writes the intermediate extract.")
    CATEGORY = CATEGORY_SOURCE
    REQUIRES = (ARTIFACT_ADMITTED,)
    PRODUCES = (ARTIFACT_EXTRACT, ARTIFACT_ROW_COUNT)
    IDEMPOTENCY = IDEMPOTENT_SAFE
    ENGINE_STAGE_TYPES = ("query", "spark")


class FormatOutput(_EngineStep):
    """``format_{output_format}`` — the extract becomes the deliverable
    in the contract's format, with its packaging, codec and checksum."""
    NAME = "format_output"
    DISPLAY_NAME = "Format Output"
    DESCRIPTION = ("Renders the extract into the contract's format and "
                   "runs the fixed artifact chain: package, compress, "
                   "encrypt, checksum.")
    CATEGORY = CATEGORY_TRANSFORM
    REQUIRES = (ARTIFACT_EXTRACT,)
    #: Produces the row count TOO, and that is not redundancy with
    #: SourceExtract -- it is which lane produced it.  On the heavy lane
    #: the extract reports its own count and returns before this stage
    #: exists; on the native lane the count is only known once the rows
    #: have been written, because the renderer is what counts them.
    #: Declaring both is how the graph stays true on BOTH lanes instead
    #: of on the one somebody happened to test.  Two producers of one
    #: artifact is already the normal case (OG's ConsolidateFiles waits
    #: on the _OnCloud AND _OnPrem extracts).
    PRODUCES = (ARTIFACT_FORMATTED_FILE, ARTIFACT_ROW_COUNT)
    IDEMPOTENCY = IDEMPOTENT_OVERWRITE
    ENGINE_STAGE_TYPES = ("format",)
    # the Spark job renders the file in-pod (spark/jobs/generic_feed.py)
    PERFORMED_BY_JOB_ON = _DETACHED


class LocalIntegrity(_EngineStep):
    """``integrity_local`` — an INDEPENDENT physical recount of the file
    we are about to send, before anybody receives it."""
    NAME = "local_integrity"
    DISPLAY_NAME = "Local Integrity"
    DESCRIPTION = ("Independently re-counts and re-measures the local "
                   "artifact before delivery — the engine's self-reported "
                   "row count is not evidence about the file.")
    CATEGORY = CATEGORY_QUALITY
    REQUIRES = (ARTIFACT_FORMATTED_FILE,)
    # 2026-10-12 -- the engine verifies the file BEFORE it is sent; without
    # this the plan put "deliver" first (both only required the file) and the
    # run screen showed the check AFTER the send (the owner: "what's the
    # sequence").  BEFORE, not REQUIRES: a delivery without this step is valid.
    BEFORE = ("deliver_artifact",)
    IDEMPOTENCY = IDEMPOTENT_SAFE
    ENGINE_STAGE_TYPES = ("integrity/local",)
    # the job reports the file's size / checksum with its completion
    PERFORMED_BY_JOB_ON = _DETACHED


class DeliverArtifact(_EngineStep):
    """``deliver_{dest_type}`` — the hop chain.

    ``IDEMPOTENT_UNSAFE``: a second delivery is a second file at the
    counterparty.  Re-delivery exists, but it is the hop runner's own
    audited path with its own retry policy, not a generic step re-run.
    """
    NAME = "deliver_artifact"
    DISPLAY_NAME = "Deliver"
    DESCRIPTION = ("Runs the delivery chain — each hop to its registered "
                   "endpoint, with that hop's retry policy.")
    CATEGORY = CATEGORY_SINK
    REQUIRES = (ARTIFACT_FORMATTED_FILE,)
    PRODUCES = (ARTIFACT_DELIVERED,)
    IDEMPOTENCY = IDEMPOTENT_UNSAFE
    ENGINE_STAGE_TYPES = ("delivery",)
    # delivered in-pod by the job, or webhook-side by QueryStudio from the
    # job's artifacts -- either way after the engine's hand-off
    PERFORMED_BY_JOB_ON = _DETACHED


class PostDeliveryIntegrity(_EngineStep):
    """``integrity_post_delivery`` — confirm what LANDED matches what we
    wrote.  Only meaningful for a remote destination."""
    NAME = "post_delivery_integrity"
    DISPLAY_NAME = "Post-Delivery Integrity"
    DESCRIPTION = ("Stats the delivered object and compares it with the "
                   "bytes written locally.")
    CATEGORY = CATEGORY_QUALITY
    REQUIRES = (ARTIFACT_DELIVERED,)
    IDEMPOTENCY = IDEMPOTENT_SAFE
    APPLIES_WHEN = {"destination_type": {"$ne": "local"}}
    ENGINE_STAGE_TYPES = ("integrity/post_delivery",)
    # the job's delivery receipt carries the verification
    PERFORMED_BY_JOB_ON = _DETACHED


class RowCountCheck(_EngineStep):
    """``row_count_check`` — the volume verdict against the baseline.

    ``IDEMPOTENT_CONFIGURED`` because what it DOES depends on
    ``row_count_action``: at ``fail`` it is a correctness gate, at
    ``warn`` it is an observation.  The two are identical in code and
    opposite in consequence, which is exactly the pair this codebase
    warns about.
    """
    NAME = "row_count_check"
    DISPLAY_NAME = "Row Count Check"
    DESCRIPTION = ("Compares the run's row count against the feed's "
                   "baseline and thresholds.")
    CATEGORY = CATEGORY_QUALITY
    REQUIRES = (ARTIFACT_ROW_COUNT,)
    # 2026-10-12 -- a count that FAILS (or HOLDS) must stop the send: the
    # engine runs it before delivery, and the plan now says so.
    BEFORE = ("deliver_artifact",)
    IDEMPOTENCY = IDEMPOTENT_CONFIGURED
    ENGINE_STAGE_TYPES = ("row_count_check",)
    # the job certifies the count against the upstream message's
    # (reported_rows_certification); the previous-delivery variance check
    # and its hold are native-lane checks (source_plan.BACKEND_CAPABILITIES
    # variance_hold) -- the evidence decides completed vs skipped
    PERFORMED_BY_JOB_ON = _DETACHED
