"""Permission resolver — Phase 130 hotfix-7 + hotfix-13.

Single source of truth for "who can act on this feed?".  Used by:
  - Per-row Rerun / Cancel buttons on the run-status dashboard
  - Bulk Trigger endpoint
  - Feed config edit / delete endpoints (when wired in)

Phase 130 hotfix-13 split the legacy ``can_act_on_feed`` into separate
view + edit gates so per-user ``resource_access_level`` ('read_only'
vs 'read_write') is honoured.  ``can_act_on_feed`` is kept as a
backwards-compatible alias for ``can_edit_feed``.

Precedence (each gate):
  1. Admin / super_admin role -> always allowed
  2. Support role -> view ONLY (never edit)
  3. Individual owner (feed_config.created_by == user.username) -> allowed
  4. Group ownership — current user is a member of owner_group_id
     - VIEW: any member, regardless of access level
     - EDIT: only members with resource_access_level='read_write'
  5. Otherwise -> denied

The functions are intentionally pure (no global state, no module
imports beyond the db).  Callers pass the resolved feed dict, the
user dict, and a db handle for the group-membership lookup.
"""
from __future__ import annotations

from typing import Mapping, Optional


def is_admin_user(user: Mapping) -> bool:
    """True for admin or super_admin.

    Delegates to the codebase-canonical ``core.roles.is_admin_like``
    which honours BOTH the ``role`` field AND a boolean ``is_admin``
    flag.
    """
    try:
        from core.roles import is_admin_like
        return is_admin_like(user)
    except Exception:
        role = (user.get("role") or "").lower()
        return role in ("admin", "super_admin") or bool(user.get("is_admin"))


def user_in_group(db, username: str, group_id: int) -> bool:
    """Cheap membership check.  Returns False on missing inputs."""
    if not username or not group_id or db is None:
        return False
    try:
        return bool(db.is_user_in_group(username, int(group_id)))
    except Exception:
        return False


def can_view_feed(feed: Optional[Mapping], user: Mapping, db) -> bool:
    """View authority — admin / support / owner / any group member."""
    if not feed or not user:
        return False
    try:
        from core.entitlements import can_view as _generic
        return _generic(feed, user, db=db)
    except Exception:
        # Defensive fallback to the legacy logic if entitlements module
        # is unavailable (test environments before db wiring).
        if is_admin_user(user):
            return True
        username = user.get("username")
        if username and feed.get("created_by") == username:
            return True
        group_id = feed.get("owner_group_id")
        return bool(group_id and user_in_group(db, username, int(group_id)))


def can_edit_feed(feed: Optional[Mapping], user: Mapping, db) -> bool:
    """Edit authority — admin / owner / read_write group member.
    Support role gets NO edit access (observe-only)."""
    if not feed or not user:
        return False
    try:
        from core.entitlements import can_edit as _generic
        return _generic(feed, user, db=db)
    except Exception:
        if is_admin_user(user):
            return True
        username = user.get("username")
        if username and feed.get("created_by") == username:
            return True
        # Fallback: degrade to plain membership (no access-level check)
        group_id = feed.get("owner_group_id")
        return bool(group_id and user_in_group(db, username, int(group_id)))


# Backwards-compat alias.  Pre-hotfix-13 callers used can_act_on_feed
# as the single gate for both view+edit; we keep that semantic for them
# by routing to the edit gate (the stricter of the two).  New code
# should pick view OR edit explicitly.
def can_act_on_feed(feed: Optional[Mapping], user: Mapping, db) -> bool:
    return can_edit_feed(feed, user, db)


def explain_denial(feed: Mapping, user: Mapping) -> str:
    """Human-readable string for the lock-icon tooltip."""
    owner = feed.get("created_by") or "unknown"
    group = feed.get("owner_group_id")
    if group:
        return (f"View-only.  Owner: {owner} (or read-write members of group #{group}).  "
                f"Ask an admin, the owner, or a read-write group member to act on this run.")
    return (f"View-only.  Owner: {owner}.  "
            f"Ask an admin or the owner to act on this run.")


def auth_is_on() -> bool:
    """True when the deployment authenticates (``auth.type`` != none).  With
    auth off there is no identity to gate on: every feed is visible and
    every action allowed, the posture every feed route already takes."""
    try:
        from core.config import auth as _auth_cfg
        return bool(_auth_cfg) and getattr(_auth_cfg, "type", "none") != "none"
    except Exception:                                   # noqa: BLE001
        return False


def sees_every_feed(user: Optional[Mapping]) -> bool:
    """THE rule for "this principal sees the whole feed estate" (2026-10-17,
    moved here from ``api.feed_api._sees_every_feed`` so the WebSocket layer
    asks the same question): a no-auth deployment, an admin-like role, or
    the observe-only support role.  Read grant only -- nothing here says
    the principal may ACT (``can_act_on_feed``)."""
    if not auth_is_on():
        return True
    try:
        from core.roles import is_admin_like as _adm
        if _adm(user):
            return True
        from core.entitlements import is_support as _is_support
        return bool(user) and bool(_is_support(user))
    except Exception:                                   # noqa: BLE001
        return False
