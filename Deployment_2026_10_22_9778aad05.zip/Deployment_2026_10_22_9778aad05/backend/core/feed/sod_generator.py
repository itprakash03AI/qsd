"""SodTaskGenerator — Phase 130/3.

Daily Start-Of-Day batch that creates one ``feed_runs`` row per active
``feed_configs`` row, evaluating each feed's ACTION_CONDITION to decide
RUN vs SKIP for the day.

Lifecycle:
  - APScheduler fires ``SodTaskGenerator.run_for_date`` at the time
    configured by ``feed_generation.sod_cron`` (default 00:00 UTC).
  - The generator:
        1. Loads all active feed_configs.
        2. For each:
            a. Resolves the named calendar (DB-driven).
            b. Computes business_date (calendar.previous_business_day_or_today).
            c. Checks valid_from / valid_until window — skip outside.
            d. Evaluates ACTION_CONDITION via ActionConditionEvaluator.
            e. Upserts a feed_runs row keyed by (feed_config_id, business_date).
        3. Returns a summary dict {created, skipped, ran_already}.

This class owns no module-level state.  Inputs come through the
constructor so unit tests can pass mocked repos without touching
real DB tables.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Any, Dict, Iterable, List, Mapping, Optional

from core.db.models import FEED_RUN_SOD_CATCHUP_TRIGGER, FEED_RUN_UPSTREAM_TRIGGER

from .action_condition import ActionConditionEvaluator
from .calendar import BusinessCalendar, BusinessCalendarRepo

logger = logging.getLogger(__name__)

#: The schedule kinds whose due-ness MEANS "business day" (2026-10-11): a
#: feed of one of these with no calendar anywhere is refused for the pass
#: (see ``SodTaskGenerator._calendar_problem``).
CALENDAR_BOUND_KINDS = frozenset({"month_end", "workday_n", "workdays"})

#: The kinds the catch-up can judge a MISSED date for.  ``cron`` is out (its
#: own fields are APScheduler's; due_on answers only the calendar half) and
#: so is ``on_completion_of`` (no date rule); an UNDECLARED feed keeps the
#: legacy path exactly -- due-ness is a declared-schedule concept.
CATCHUP_KINDS = frozenset({"daily", "month_end", "workday_n", "workdays"})


def _scope_text(scope: Mapping[str, Any]) -> str:
    """The scope for a log line: a long id list is a COUNT, not 4,000 ids."""
    if scope.get("all"):
        return "all"
    parts = []
    if scope.get("template_id") is not None:
        parts.append(f"template {scope['template_id']}")
    ids = scope.get("feed_ids")
    if ids is not None:
        parts.append(f"{len(ids)} feed id(s)" if len(ids) > 8 else f"feeds {list(ids)}")
    return ", ".join(parts) or "all"


def _cfg_int(key: str, fallback: int) -> int:
    """A ``feed_generation`` integer through the config object (declared in
    ``_DEFAULTS``; a bad value falls back to the declared default, said)."""
    try:
        from core.config import get as _get
        return max(0, int(_get("feed_generation", key, fallback)))
    except Exception:                              # noqa: BLE001
        logger.warning("[sod_generator] feed_generation.%s is not an integer -- "
                       "using %d", key, fallback)
        return fallback


@dataclass
class SodResult:
    """Per-run summary returned by ``SodTaskGenerator.run_for_date``.

    2026-10-11 additions: ``scope`` / ``considered`` (what a scoped run-now
    processed), the CATCH-UP counters (``catchup_created``, ``catchup_dates``
    = {business date: rows}) and the GAP record (``gaps`` = the DUE dates
    beyond the catch-up window with no run, ``gaps_new`` / ``gaps_resolved``
    this pass).  The pre-existing keys keep their names and meanings.
    """
    business_date: date
    total_feeds: int = 0
    created: int = 0
    already_existed: int = 0
    skipped_inactive: int = 0
    skipped_window: int = 0
    skipped_by_condition: int = 0
    errors: int = 0
    error_details: List[str] = field(default_factory=list)
    scope: dict = field(default_factory=lambda: {"template_id": None,
                                                 "feed_ids": None, "all": True})
    considered: int = 0
    catchup_created: int = 0
    catchup_dates: dict = field(default_factory=dict)
    gaps: List[dict] = field(default_factory=list)
    gaps_new: int = 0
    gaps_resolved: int = 0

    def to_dict(self) -> dict:
        return {
            "business_date": self.business_date.isoformat(),
            "total_feeds": self.total_feeds,
            "created": self.created,
            "already_existed": self.already_existed,
            "skipped_inactive": self.skipped_inactive,
            "skipped_window": self.skipped_window,
            "skipped_by_condition": self.skipped_by_condition,
            "errors": self.errors,
            "error_details": list(self.error_details),
            "scope": dict(self.scope),
            "considered": self.considered,
            "catchup_created": self.catchup_created,
            "catchup_dates": dict(self.catchup_dates),
            "gaps": [dict(g) for g in self.gaps],
            "gaps_new": self.gaps_new,
            "gaps_resolved": self.gaps_resolved,
        }


@dataclass
class _Pass:
    """What ONE pass resolves once and every feed in it reads (2026-10-11):
    the (feed, business date) keys that already have a run in the pass's
    date window (ONE query, or None when the db cannot list them and the
    per-feed read is used), the default calendar's name, the resolved
    calendars by name, and the due dates per (declaration, calendar)."""
    run_d: date
    window_from: date
    existing: Optional[set]
    default_calendar: Optional[str]
    catchup_days: int
    gap_scan_days: int
    calendars: dict = field(default_factory=dict)
    due_cache: dict = field(default_factory=dict)
    open_gaps: Optional[dict] = None


class SodTaskGenerator:
    """Creates ``feed_runs`` rows for every active feed for a business_date.

    Constructor parameters (dependency-injected — all optional for
    testability):
      - ``db``: DatabaseManager-shaped object with
        ``list_feed_configs``, ``get_feed_run_by_feed_date``,
        ``create_feed_run``, ``update_feed_run``.
      - ``calendar_repo``: ``BusinessCalendarRepo`` instance.
      - ``default_priority``: priority to use when the feed has no
        per-feed override.
    """

    def __init__(
        self,
        db,
        calendar_repo: Optional[BusinessCalendarRepo] = None,
        *,
        default_priority: int = 5,
    ) -> None:
        if db is None:
            raise ValueError("SodTaskGenerator requires a db manager")
        self._db = db
        self._cal_repo = calendar_repo or BusinessCalendarRepo(db)
        self._default_priority = int(default_priority)
        # 2026-10-11 -- the declared windows (feed_generation.*), read once
        # per generator through the config object; a pass may override them.
        self._catchup_days = _cfg_int("sod_catchup_days", 7)
        self._gap_scan_days = _cfg_int("sod_gap_scan_days", 45)

    # ── The calendar a feed is on: ONE answer (2026-10-11) ────────────

    @staticmethod
    def effective_calendar_name(fc: Mapping[str, Any]) -> Optional[str]:
        """THE calendar this feed is on: ``calendar_name``, else the one its
        schedule declaration names, else ``feed_generation.default_calendar``
        -- the SAME key the date tokens and report parameters resolve a bare
        calendar token on (core/business_calendar_tokens.py).  Until
        2026-10-11 SOD and ``due_on`` ignored the default while the tokens
        used it: two answers to "which calendar is this feed on", and a
        month-end feed with no calendar_name landed on Sat 31 while its
        ``{BUSINESSDATE}`` said Fri 30.  None = no calendar anywhere."""
        name = fc.get("calendar_name")
        if name:
            return str(name)
        decl = fc.get("schedule_declaration")
        if isinstance(decl, dict) and decl.get("calendar_name"):
            return str(decl.get("calendar_name"))
        return SodTaskGenerator._default_calendar_name()

    # ── The business date a feed is ON for a run date: ONE answer ──────

    #: how far back the walk looks for the last due date (a quarter-end or
    #: a yearly rule fits; a rule with no due date in a year has none)
    CURRENT_DATE_LOOKBACK_DAYS = 400

    def current_business_date(self, fc: Mapping[str, Any], run_d: date,
                              ctx: Optional["_Pass"] = None) -> Optional[date]:
        """The business date this feed is working on for run date ``run_d``
        (2026-10-13, the owner: "one month-end date can have multiple run
        dates ... it should derive from the feed config and the calendar"):
        the LATEST date on or before ``run_d`` that the feed's date rule
        makes due on its business calendar -- the date start of day creates
        its task for, read backwards.  A month-end feed is on 30 Sep for
        every run date from 30 Sep until its October month end; a daily feed
        is on ``run_d``'s business day.

        Starts from the same date SOD does (``previous_business_day_or_today``
        on the feed's calendar; ``run_d`` with no calendar) and asks the same
        ``due_on``.  A feed with no date rule (legacy) is on that start date;
        one whose rule is not a date (``on_completion_of`` / ``on_demand``)
        or that cannot be read returns None -- the caller says so."""
        from core.feed.schedule import Due, due_on, parse_schedule
        calendar = self._resolve_calendar(fc, ctx)
        try:
            start = calendar.previous_business_day_or_today(run_d) if calendar is not None else run_d
            sched = parse_schedule(fc.get("schedule_declaration"))
        except Exception as exc:                        # noqa: BLE001 -- unknown, said by the caller
            logger.info("[sod_generator] feed %s: no current business date for %s (%s)",
                        fc.get("id"), run_d, exc)
            return None
        if sched is None:
            return start
        from core.feed.schedule import business_date_for
        d = start
        try:
            for _ in range(self.CURRENT_DATE_LOOKBACK_DAYS):
                v = due_on(sched, d, calendar)
                if v is Due.EVENT_DRIVEN:
                    return None
                if v is Due.DUE:
                    # the last due RUN day -> the date its data is for
                    return business_date_for(sched, d, calendar)
                d -= timedelta(days=1)
        except Exception as exc:                        # noqa: BLE001 -- e.g. beyond the calendar's horizon
            logger.info("[sod_generator] feed %s: walk back from %s stopped (%s)", fc.get("id"), start, exc)
        return None

    def current_business_dates(self, feeds: Iterable[Mapping[str, Any]], run_d: date
                               ) -> Dict[int, Optional[date]]:
        """``current_business_date`` for MANY feeds in ONE pass (2026-10-17,
        the board by run date at the owner's 4,000 feeds): the calendars are
        resolved once per name (a pass context) and the walk is done once
        per (declaration, calendar) -- 4,000 feeds of one template share one
        answer, exactly as ``_due_dates`` memoises for the SOD pass.
        ``{feed id: date or None}``; the per-feed rule is unchanged."""
        import json as _json
        ctx = _Pass(run_d=run_d, window_from=run_d, existing=None,
                    default_calendar=self._default_calendar_name(), catchup_days=0,
                    gap_scan_days=0)
        memo: Dict[tuple, Optional[date]] = {}
        out: Dict[int, Optional[date]] = {}
        for fc in feeds:
            key = (_json.dumps(fc.get("schedule_declaration"), sort_keys=True, default=str),
                   self.effective_calendar_name(fc) or "")
            if key not in memo:
                memo[key] = self.current_business_date(fc, run_d, ctx)
            out[int(fc["id"])] = memo[key]
        return out

    @staticmethod
    def _default_calendar_name() -> Optional[str]:
        from core.business_calendar_tokens import default_calendar_name
        try:
            return default_calendar_name()
        except Exception:                          # noqa: BLE001 -- undeclared
            return None

    # ── Public entry point ────────────────────────────────────────────

    def feeds_in_scope(self, *, template_id: Optional[int] = None,
                       feed_ids: Optional[List[int]] = None,
                       is_active: Optional[bool] = True) -> List[dict]:
        """The feeds ONE pass processes: every (active) feed, narrowed to a
        template's members and/or an explicit id list (2026-10-11 -- a
        scoped run-now runs the SAME pass over fewer feeds).  One listing;
        the narrowing is in Python because both filters are exact matches
        on columns the listing already carries."""
        feeds = list(self._db.list_feed_configs(is_active=is_active) or [])
        if template_id is not None:
            tid = int(template_id)
            feeds = [f for f in feeds
                     if f.get("template_id") is not None
                     and int(f.get("template_id")) == tid]
        if feed_ids is not None:
            wanted = {int(x) for x in feed_ids}
            feeds = [f for f in feeds if int(f["id"]) in wanted]
        return feeds

    @staticmethod
    def scope_of(template_id: Optional[int], feed_ids: Optional[List[int]]) -> dict:
        """The ``scope`` a result echoes: what was asked, in one shape."""
        return {"template_id": (int(template_id) if template_id is not None else None),
                "feed_ids": ([int(x) for x in feed_ids] if feed_ids is not None else None),
                "all": template_id is None and feed_ids is None}

    def run_for_date(self, run_date: Optional[date] = None, *,
                     template_id: Optional[int] = None,
                     feed_ids: Optional[List[int]] = None,
                     progress=None,
                     catchup_days: Optional[int] = None,
                     gap_scan_days: Optional[int] = None) -> SodResult:
        """Generate today's feed_runs.  Idempotent — re-running on the
        same date does NOT duplicate rows (uniqueness enforced by the
        ``ux_feed_runs_one_per_feed_per_date`` constraint + the
        existence pre-check).

        2026-10-11: ``template_id`` / ``feed_ids`` narrow the pass to those
        feeds (the same rows, the same ``triggered_by``); ``progress(done,
        total)`` is called after each feed (a background job's heartbeat);
        the pass also CATCHES UP missed due dates and records GAPS (see
        ``_catch_up``); ``catchup_days`` / ``gap_scan_days`` override the
        declared config for one pass.
        """
        run_d = run_date or datetime.now(timezone.utc).date()
        feeds = self.feeds_in_scope(template_id=template_id, feed_ids=feed_ids)
        result = SodResult(business_date=run_d, total_feeds=len(feeds),
                           scope=self.scope_of(template_id, feed_ids),
                           considered=len(feeds))
        # Phase 4 (2026-08-23): skipped_inactive was a DEAD counter -- the
        # query above already filters to active feeds, so the field was
        # never incremented and the UI chip always read 0.  Count the
        # inactive feeds honestly (best-effort; a failure leaves 0).
        try:
            all_feeds = self.feeds_in_scope(template_id=template_id,
                                            feed_ids=feed_ids, is_active=None)
            result.skipped_inactive = max(0, len(all_feeds) - len(feeds))
        except Exception:
            pass

        ctx = self._begin_pass(run_d, feeds, catchup_days=catchup_days,
                               gap_scan_days=gap_scan_days)
        for i, fc in enumerate(feeds, 1):
            try:
                self._process_one(fc, run_d, result, ctx)
            except Exception as e:
                result.errors += 1
                msg = f"feed {fc.get('id')} ({fc.get('name')}): {e}"
                result.error_details.append(msg[:300])
                logger.warning("[sod_generator] %s", msg)
            if progress is not None:
                try:
                    progress(i, len(feeds))
                except Exception:              # noqa: BLE001 -- advisory
                    logger.debug("[sod_generator] progress callback failed",
                                 exc_info=True)

        self._catch_up(feeds, result, ctx)

        logger.info(
            "[sod_generator] %s — created=%d already=%d window=%d "
            "condition=%d inactive=%d errors=%d catchup=%d gaps=%d (of %d; scope %s)",
            run_d.isoformat(), result.created, result.already_existed,
            result.skipped_window, result.skipped_by_condition,
            result.skipped_inactive, result.errors, result.catchup_created,
            len(result.gaps), result.total_feeds, _scope_text(result.scope),
        )
        return result

    # ── The pass context (2026-10-11) ─────────────────────────────────

    def _begin_pass(self, run_d: date, feeds: List[dict], *,
                    catchup_days: Optional[int], gap_scan_days: Optional[int]) -> _Pass:
        """Resolve ONCE what every feed in the pass reads.

        The existence check is ONE query over the pass's whole date window
        (today's business date and the catch-up / gap window) instead of
        one ``get_feed_run_by_feed_date`` per feed per date: at the owner's
        4,000 feeds that was 4,000 round trips before a single row was
        written, and the catch-up would have multiplied it by the window.
        A db that cannot list the keys (an older seam, a test double) leaves
        ``existing`` None and the per-feed read is used -- same answer,
        slower, never a guess.
        """
        cd = self._catchup_days if catchup_days is None else max(0, int(catchup_days))
        sd = self._gap_scan_days if gap_scan_days is None else max(0, int(gap_scan_days))
        sd = max(sd, cd)
        window_from = run_d - timedelta(days=max(sd, 7))
        existing: Optional[set] = None
        try:
            ids = [int(f["id"]) for f in feeds]
            keys = self._db.list_feed_run_keys(window_from, run_d, feed_ids=ids)
            if isinstance(keys, (set, frozenset, list, tuple)):
                existing = {(int(k[0]), _coerce_date(k[1])) for k in keys}
        except AttributeError:
            existing = None
        except Exception as exc:                  # noqa: BLE001 -- said, then per-feed
            logger.warning("[sod_generator] the run keys could not be listed in one "
                           "query (%s) -- falling back to one read per feed", exc)
            existing = None
        return _Pass(run_d=run_d, window_from=window_from, existing=existing,
                     default_calendar=self._default_calendar_name(),
                     catchup_days=cd, gap_scan_days=sd)

    def _run_exists(self, ctx: Optional[_Pass], feed_id: int, business_date: date) -> bool:
        """The pass's existence answer for (feed, date): the batched set when
        the pass has one, else the DAO's per-feed read (the SAME filter --
        ``manual_run_excluded`` -- on both roads)."""
        # the batched set covers [window_from, run_d] only: a date before it
        # (a month end run daily is weeks back -- 2026-10-13) is UNKNOWN to
        # the set, not absent -- ask the database
        if ctx is not None and ctx.existing is not None and business_date >= ctx.window_from:
            return (int(feed_id), business_date) in ctx.existing
        return self._db.get_feed_run_by_feed_date(int(feed_id), business_date) is not None

    @staticmethod
    def _note_created(ctx: Optional[_Pass], feed_id: int, business_date: date) -> None:
        if ctx is not None and ctx.existing is not None:
            ctx.existing.add((int(feed_id), business_date))

    # ── CATCH-UP + GAPS (2026-10-11) ──────────────────────────────────
    #
    # A month-end missed because the scheduler was down at the cron time
    # was never created: the boot catch-up fires run_for_date() for TODAY,
    # and today is not month-end any more.  Nothing alerted; the consumer's
    # file was simply absent (the owner's ~4,000 monthly feeds).  Every pass
    # now ends here: each DUE date in the scan window with no run is either
    # CREATED (inside feed_generation.sod_catchup_days, triggered_by
    # sod_catchup) or SAID (a feed_sod_gaps row + an ERROR line) -- never
    # silent.  Due-ness is a DECLARED-schedule concept: an undeclared feed
    # keeps the legacy path exactly, a cron feed's fields are APScheduler's.

    def _catch_up(self, feeds: List[dict], result: SodResult, ctx: _Pass) -> None:
        if ctx.gap_scan_days <= 0:
            return
        scan_from = ctx.run_d - timedelta(days=ctx.gap_scan_days)
        catch_from = (ctx.run_d - timedelta(days=ctx.catchup_days)
                      if ctx.catchup_days > 0 else None)
        gaps: List[dict] = []
        for fc in feeds:
            try:
                self._catch_up_one(fc, result, ctx, scan_from, catch_from, gaps)
            except Exception as exc:               # noqa: BLE001 -- per feed, named
                result.errors += 1
                msg = (f"feed {fc.get('id')} ({fc.get('name')}): catch-up could not be "
                       f"judged ({type(exc).__name__}: {exc})")
                result.error_details.append(msg[:300])
                logger.warning("[sod_generator] %s", msg)
        self._record_gaps(feeds, result, ctx, gaps, scan_from)

    def _catch_up_one(self, fc: Mapping[str, Any], result: SodResult, ctx: _Pass,
                      scan_from: date, catch_from: Optional[date],
                      gaps: List[dict]) -> None:
        from core.feed.schedule import parse_schedule
        try:
            sched = parse_schedule(fc.get("schedule_declaration"))
        except Exception:                          # noqa: BLE001 -- said by _process_one
            return
        if sched is None or sched.kind not in CATCHUP_KINDS:
            return
        feed_id = int(fc["id"])
        born = _coerce_date(fc.get("created_at"))
        if born is None:
            # unknown is not "existed forever": a seam without created_at
            # (an older double) gets no catch-up rather than a guessed one
            logger.debug("[sod_generator] feed %s has no created_at -- no catch-up",
                         feed_id)
            return
        calendar = self._resolve_calendar(fc, ctx)
        if self._calendar_problem(fc, sched.kind, calendar):
            return                                 # refused + counted by _process_one
        from core.feed.schedule import business_date_for
        for run_day in self._due_dates(fc, sched, calendar, ctx, scan_from):
            # the DATA's date of that due run day (2026-10-13): a month end
            # run daily is ONE task for weeks of due days
            d = business_date_for(sched, run_day, calendar)
            if run_day < born or not self._in_window(fc, d) or self._run_exists(ctx, feed_id, d):
                continue
            if catch_from is not None and d >= catch_from:
                created, decision, _reason = self._create_run_row(
                    fc, calendar, d, ctx.run_d,
                    origin={"scheduled_time": datetime.combine(
                                d, datetime.min.time(), tzinfo=timezone.utc),
                            "triggered_by": FEED_RUN_SOD_CATCHUP_TRIGGER})
                self._note_created(ctx, feed_id, d)
                result.catchup_created += 1
                key = d.isoformat()
                result.catchup_dates[key] = result.catchup_dates.get(key, 0) + 1
                logger.warning(
                    "[sod_generator] CATCH-UP: feed %s (%s) was DUE on %s (%s) and had "
                    "no run -- created run %s (%s) on the %s pass, %d day(s) late",
                    feed_id, fc.get("name"), key, sched.kind,
                    (created or {}).get("id"), decision, ctx.run_d.isoformat(),
                    (ctx.run_d - d).days)
                continue
            gaps.append({
                "feed_config_id": feed_id, "feed_name": fc.get("name"),
                "created_by": fc.get("created_by"),
                "business_date": d, "schedule_kind": sched.kind,
                "catchup_days": ctx.catchup_days, "scan_days": ctx.gap_scan_days,
                "detected_on": ctx.run_d,
                "reason": (f"DUE on {d.isoformat()} by the {sched.kind} schedule; no run "
                           f"exists and the date is {(ctx.run_d - d).days} day(s) before "
                           f"{ctx.run_d.isoformat()}, beyond "
                           f"feed_generation.sod_catchup_days={ctx.catchup_days} -- "
                           f"backfill it (POST /api/feeds/{feed_id}/backfill) or widen "
                           f"the window"),
            })

    def _due_dates(self, fc: Mapping[str, Any], sched, calendar,
                   ctx: _Pass, scan_from: date) -> List[date]:
        """The DUE dates in ``[scan_from, run_d - 1]`` for this declaration on
        this calendar -- computed ONCE per (declaration, calendar) per pass
        (4,000 feeds from one template share one answer), through THE
        ``due_on``.  A date the calendar cannot judge (beyond its horizon)
        is not due and is logged once per cache key."""
        import json as _json
        from core.feed.schedule import Due, due_on
        key = (_json.dumps(fc.get("schedule_declaration"), sort_keys=True, default=str),
               self.effective_calendar_name(fc) or "", scan_from.isoformat())
        cached = ctx.due_cache.get(key)
        if cached is not None:
            return cached
        due: List[date] = []
        d = scan_from
        unjudged = 0
        while d < ctx.run_d:
            try:
                if due_on(sched, d, calendar) is Due.DUE:
                    due.append(d)
            except Exception:                      # noqa: BLE001 -- horizon etc.
                unjudged += 1
            d += timedelta(days=1)
        if unjudged:
            logger.warning("[sod_generator] %d date(s) in the catch-up window could "
                           "not be judged on calendar %r for schedule %s -- not due",
                           unjudged, key[1], key[0])
        ctx.due_cache[key] = due
        return due

    def _record_gaps(self, feeds: List[dict], result: SodResult, ctx: _Pass,
                     gaps: List[dict], scan_from: date) -> None:
        """Write the NEW gap rows (unique per (feed, date)), alert on each new
        one, resolve the open gaps whose date now has a run.  A db seam
        without the gap DAO (a test double) records nothing and says so at
        DEBUG; the result still carries the gaps it found."""
        for g in gaps:
            result.gaps.append({"feed_id": g["feed_config_id"], "feed_name": g["feed_name"],
                                "business_date": g["business_date"].isoformat(),
                                "schedule_kind": g["schedule_kind"], "reason": g["reason"]})
        ids = [int(f["id"]) for f in feeds]
        try:
            known = self._db.list_feed_sod_gaps(feed_ids=ids, open_only=False,
                                                business_date_from=scan_from,
                                                business_date_to=ctx.run_d, limit=None)
            known_keys = {(int(k["feed_config_id"]), _coerce_date(k["business_date"]))
                          for k in (known or [])}
        except Exception as exc:                   # noqa: BLE001 -- said; nothing recorded
            logger.debug("[sod_generator] gap records unavailable on this db seam (%s)", exc)
            return
        new = [g for g in gaps if (g["feed_config_id"], g["business_date"]) not in known_keys]
        if new:
            rows = [{k: v for k, v in g.items() if k not in ("feed_name", "created_by")}
                    for g in new]
            result.gaps_new = int(self._db.record_feed_sod_gaps(rows) or 0)
            for g in new:
                logger.error(
                    "[sod_generator] GAP: feed %s (%s) was DUE on %s (%s) and has NO run; "
                    "%s", g["feed_config_id"], g["feed_name"],
                    g["business_date"].isoformat(), g["schedule_kind"], g["reason"])
            self._bell_gaps(new, ctx)
        # resolve: an open gap whose date now has a run (a backfill, a widened
        # window's catch-up a moment ago)
        resolved_keys = [(int(k["feed_config_id"]), _coerce_date(k["business_date"]))
                         for k in (known or []) if k.get("resolved_at") is None]
        resolved_keys = [k for k in resolved_keys
                         if k[1] is not None and self._run_exists(ctx, k[0], k[1])]
        if resolved_keys:
            result.gaps_resolved = int(self._db.resolve_feed_sod_gaps(resolved_keys) or 0)
            logger.info("[sod_generator] %d gap record(s) resolved -- the date has a run now",
                        result.gaps_resolved)

    def _bell_gaps(self, new: List[dict], ctx: _Pass) -> None:
        """ONE bell row per feed OWNER per pass naming the new gaps (best
        effort, never raises).  Not one per gap: the owner's 4,000 feeds
        missing one month-end would be 4,000 rows for one person."""
        by_owner: dict = {}
        for g in new:
            owner = g.get("created_by")
            if owner:
                by_owner.setdefault(str(owner), []).append(g)
        for owner, items in by_owner.items():
            names = sorted({str(g["feed_name"]) for g in items})
            dates = sorted({g["business_date"].isoformat() for g in items})
            shown = ", ".join(names[:5]) + (f" (+{len(names) - 5} more)"
                                            if len(names) > 5 else "")
            try:
                self._db.log_notification(
                    event_type="feed_sod_gap", channel="websocket", recipient=owner,
                    status="sent",
                    title=f"{len(items)} due date(s) have no feed run",
                    message=(f"SOD on {ctx.run_d.isoformat()} found {len(items)} due "
                             f"date(s) with no run beyond its {ctx.catchup_days}-day "
                             f"catch-up window: {shown} on {', '.join(dates)}.  Backfill "
                             f"them or widen feed_generation.sod_catchup_days."),
                    payload={"feed_config_ids": sorted({int(g["feed_config_id"])
                                                        for g in items}),
                             "business_dates": dates, "href": "/feeds/sod"})
            except Exception:                      # noqa: BLE001 -- advisory
                logger.debug("[sod_generator] gap bell not recorded", exc_info=True)

    # ── Per-feed processing ───────────────────────────────────────────

    def _process_one(self, fc: Mapping[str, Any], run_d: date,
                     result: SodResult, ctx: Optional[_Pass] = None) -> None:
        feed_id = int(fc["id"])

        # 1. Resolve calendar (DB-driven).  May be None.
        calendar = self._resolve_calendar(fc, ctx)

        # 2. The RUN DAY.  Default: previous biz day from run_d when we
        # have a calendar (so a run at GMT 00:00 on Saturday is Fri's).
        # When no calendar, run_d itself.  The DATA's business date is the
        # run day unless the declaration says otherwise (2026-10-13:
        # ``business_date`` month_end / previous_month_end --
        # schedule.business_date_for, read once below).
        if calendar is not None:
            run_day = calendar.previous_business_day_or_today(run_d)
        else:
            run_day = run_d
        business_date = run_day
        try:
            from core.feed.schedule import business_date_for as _bd_for, parse_schedule as _ps
            _early = _ps(fc.get("schedule_declaration"))
            if _early is not None:
                business_date = _bd_for(_early, run_day, calendar)
        except Exception:                          # noqa: BLE001 -- refused loudly at 4b
            business_date = run_day

        # 3. Idempotency — bail out if a row exists for (feed, biz_date).
        if self._run_exists(ctx, feed_id, business_date):
            result.already_existed += 1
            return

        # 4. valid_from / valid_until window.
        if not self._in_window(fc, business_date):
            result.skipped_window += 1
            return

        # 4b. BRD 2.1 (2026-09-02) — the DECLARED schedule, when the feed
        # has one.  Until this existed the backend could only express
        # cron + timezone + calendar, so three of the five authorable
        # kinds (month-end, workday N, on completion of feed X) had no
        # representation at all and the property was 40% real.
        #
        # An UNDECLARED feed keeps today's path EXACTLY: parse_schedule
        # returns None for None and nothing below changes.  A DECLARATION
        # THAT CANNOT BE PARSED is refused loudly and the feed keeps its
        # legacy behaviour rather than silently never running -- the
        # schedule is validated at AUTHORING, so an unparseable one here
        # means the row predates the validator, and a feed that stops
        # producing with no signal is the worse of the two failures.
        try:
            from core.feed.schedule import Due, due_on, parse_schedule
            _sched = parse_schedule(fc.get("schedule_declaration"))
        except ImportError:
            _sched = None
        except Exception as _sc_exc:
            _sched = None
            logger.error(
                "[sod] feed %s has a schedule declaration that could not be "
                "parsed (%s) — falling back to its cron/condition rules. It "
                "will run on the LEGACY schedule, not the declared one.",
                feed_id, _sc_exc)
        if _sched is not None:
            _problem = self._calendar_problem(fc, _sched.kind, calendar)
            if _problem:
                raise ValueError(_problem)      # counted + named by the pass
            # due-ness is a property of the RUN DAY (workday 5, every
            # business day); the data's date was mapped above
            _verdict = due_on(_sched, run_day, calendar)
            if _verdict is Due.EVENT_DRIVEN:
                # Not a date rule at all: the dependency gate owns this
                # feed's trigger (BRD 6 -- "the trigger is a dependency,
                # not a schedule").  SOD writes no row; writing one would
                # make an event-driven feed look overdue every morning.
                logger.debug(
                    "[sod] feed %s has no date rule (%s%s) — no SOD row", feed_id,
                    _sched.kind, f" of {_sched.upstream_feed}" if getattr(_sched, "upstream_feed", None) else "")
                return
            if _verdict is Due.NOT_DUE:
                result.skipped_by_condition += 1
                return

        # 5-7. Decide (ACTION_CONDITION, dependencies) and insert -- THE
        # body every creator in this class shares (see _create_run_row).
        _created, initial_decision, _reason = self._create_run_row(
            fc, calendar, business_date, run_d,
            origin={
                "scheduled_time": datetime.combine(
                    run_d, datetime.min.time(), tzinfo=timezone.utc,
                ),
                "triggered_by": "sod",
            })
        self._note_created(ctx, feed_id, business_date)
        if initial_decision == "SKIP":
            result.skipped_by_condition += 1
        else:
            result.created += 1

    def _create_run_row(self, fc: Mapping[str, Any],
                        calendar: Optional[BusinessCalendar],
                        business_date: date, run_d: date, *,
                        origin: Mapping[str, Any],
                        forced_skip: Optional[str] = None):
        """Steps 5-7 of a run's birth: the ACTION_CONDITION, the creation-
        time dependency hold, the INSERT and the planned step rows.

        ONE body for the two scheduled-class creators in this class -- the
        daily SOD pass and the ON-COMPLETION trigger
        (``create_upstream_triggered_run``, 2026-10-03) -- so a run started
        because its upstream completed is decided exactly as SOD decides
        the day's run.  ``origin`` supplies what differs (who triggered it,
        when it is scheduled, its identity, the upstream it names) and is
        laid over the common row.  ``forced_skip`` is a SKIP already
        decided by the caller (a non-business day on the feed's calendar);
        the condition is then not asked.

        Returns ``(created_row, decision, reason)``.  Raises whatever the
        INSERT raises -- a lost uniqueness race is the CALLER's question.
        """
        if forced_skip is not None:
            initial_decision, initial_reason = "SKIP", forced_skip
        else:
            # 5. Evaluate ACTION_CONDITION.
            decision = self._evaluate_action_condition(fc, calendar, business_date)

            # 6. Phase 131-A: race-free dep check at creation time -- ONE
            # function shared with the backfill launcher and the cron fire
            # (core/feed/etl_dependency.py::hold_reason_at_creation), keyed on
            # the feed's EFFECTIVE etl_id.  Until 2026-09-27 this ran only
            # ``if fc["etl_id"] is not None`` while the authoring routes stored
            # a feed's dependencies under its own id when etl_id was NULL, so
            # a feed with UI-authored dependencies and no explicit etl_id was
            # written RUN every morning.  Only relevant when the decision is
            # RUN; SKIP stays SKIP.
            initial_decision = decision.decision
            initial_reason   = decision.reason
            if initial_decision == "RUN":
                hold = self._dependency_hold(fc, business_date)
                if hold:
                    initial_decision = "WAIT"
                    initial_reason = hold

        # 7. Insert the feed_run row.
        row = {
            "feed_config_id":  int(fc["id"]),
            "business_date":   business_date,
            "run_date":        run_d,
            "status":          "skipped" if initial_decision == "SKIP" else "pending",
            "priority":        int(fc.get("priority") or self._default_priority),
            "sla_from":        fc.get("sla_from"),
            "sla_to":          fc.get("sla_to"),
            "sla_breached":    False,
            "action_decision": initial_decision,
            "action_reason":   initial_reason,
            # FR-OPS-06 — the run CLASS, explicit (NULL = legacy scheduled).
            "run_type":        "scheduled",
        }
        row.update(origin)
        created = self._db.create_feed_run(row)
        # ── The STEP MODEL (2026-09-05) ────────────────────────────────
        # SOD already creates the run; the steps hang off the run it
        # creates, exactly as OG's RUN_DETAIL rows hang off its RUN.
        # Writing them HERE is what makes "what will run tonight, and
        # what has not started" a READ over feed_run_steps rather than a
        # feature -- the property that makes OG's Not-Started counts free.
        #
        # Fail-open, loudly: SOD is the daily materialisation for the
        # whole estate, and one feed whose plan cannot be built must not
        # stop the other four hundred from getting a run row.  A run with
        # no planned rows is not broken -- the engine writes them at
        # execute time if SOD did not.
        self._plan_steps_for_run(fc, created)
        return created, initial_decision, initial_reason

    # ── ON COMPLETION OF (2026-10-03) ─────────────────────────────────
    #
    # A feed declaring ``schedule_declaration = {"kind": "on_completion_of",
    # "feed": X}`` is EVENT-DRIVEN: SOD writes it no row (above), and it
    # runs when X's run completes AND delivers for a business date.  The
    # event is detected in core/feed/upstream_completion.py; the ROW is born
    # here, through the same window / calendar / ACTION_CONDITION /
    # dependency / insert / step-plan body SOD uses -- never a fourth way to
    # insert a run.

    #: ``feed_runs.triggered_by`` of a run started by its upstream's
    #: completion -- the ONE spelling, declared beside the model.
    UPSTREAM_TRIGGER = FEED_RUN_UPSTREAM_TRIGGER

    @staticmethod
    def upstream_build_id(business_date: date) -> str:
        """The DETERMINISTIC build id of the one upstream-triggered run per
        (feed, business_date).  It is the idempotency arbiter: the partial
        unique index ``ux_feed_runs_identity`` (feed, date, build_id) makes
        a second INSERT lose inside the database however many times, on
        however many pods, the upstream completes.  A NULL build id would
        not do -- the claim-time pin stamps a build on a NULL row, after
        which the legacy (feed, date) index no longer covers it."""
        return f"upstream-{business_date.isoformat()}"

    def create_upstream_triggered_run(self, fc: Mapping[str, Any],
                                      business_date: date, *,
                                      upstream: Mapping[str, Any]) -> dict:
        """Create the downstream run for ``business_date`` because its
        upstream completed and delivered.  Never raises; returns the
        outcome ``{"feed_id", "feed_name", "outcome", "run_id", "status",
        "action_decision", "reason"}`` where outcome is one of

        * ``created``        -- a new row (pending RUN / pending WAIT /
                                skipped by the condition or the calendar);
        * ``already_exists`` -- the feed already has its run for the date
                                (a rerun / regeneration / duplicate
                                completion of the upstream, or two pods);
        * ``outside_validity_window`` / ``beyond_calendar_horizon`` --
                                no row, the reason says why;
        * ``error``          -- the reason names it.

        ``upstream`` carries ``feed_name``, ``execution_id``,
        ``feed_run_id`` and ``run_type`` of the run that completed.
        """
        feed_id = int(fc["id"])
        out = {"feed_id": feed_id, "feed_name": fc.get("name"),
               "outcome": None, "run_id": None, "status": None,
               "action_decision": None, "reason": None}

        def _existing(row) -> dict:
            out.update(outcome="already_exists", run_id=row.get("id"),
                       status=row.get("status"),
                       action_decision=row.get("action_decision"),
                       reason=(f"run {row.get('id')} already exists for "
                               f"{business_date.isoformat()} "
                               f"({row.get('status')}, triggered by "
                               f"{row.get('triggered_by')}) -- one run per "
                               f"feed per business date"))
            return out

        try:
            existing = self._db.get_feed_run_by_feed_date(feed_id, business_date)
            if existing is not None:
                return _existing(existing)
            if not self._in_window(fc, business_date):
                out.update(outcome="outside_validity_window",
                           reason=(f"{business_date.isoformat()} is outside "
                                   f"valid_from/valid_until "
                                   f"({fc.get('valid_from')} .. "
                                   f"{fc.get('valid_until')})"))
                return out
            calendar, forced_skip, horizon = self._upstream_calendar_gate(
                fc, business_date, upstream)
            if horizon is not None:
                out.update(outcome="beyond_calendar_horizon", reason=horizon)
                return out
            now = datetime.now(timezone.utc)
            from_backfill = str(upstream.get("run_type") or "") == "backfill"
            origin = {
                "scheduled_time": now,
                "triggered_by": self.UPSTREAM_TRIGGER,
                "build_id": self.upstream_build_id(business_date),
                "upstream_feed_name": (str(upstream.get("feed_name") or "")
                                       [:255] or None),
                "upstream_execution_id": (str(upstream.get("execution_id")
                                              or "")[:100] or None),
                "upstream_feed_run_id": upstream.get("feed_run_id"),
            }
            if from_backfill:
                # A backfill deliberately has no breach clock; a run its
                # delivery cascades into must not page anyone about an
                # old date's SLA tonight either.
                origin.update(sla_from=None, sla_to=None)
            try:
                created, decision, reason = self._create_run_row(
                    fc, calendar, business_date, now.date(),
                    origin=origin, forced_skip=forced_skip)
            except Exception as ins_exc:   # noqa: BLE001 -- re-read below
                # The unique index arbitrated a race (another pod / another
                # completion inserted first): that row IS the answer.
                again = self._db.get_feed_run_by_feed_date(feed_id, business_date)
                if again is not None:
                    return _existing(again)
                raise ins_exc
            out.update(outcome="created", run_id=(created or {}).get("id"),
                       status=(created or {}).get("status"),
                       action_decision=decision, reason=reason)
            return out
        except Exception as exc:   # noqa: BLE001 -- the outcome names it
            logger.error("[sod_generator] on-completion run for feed %s (%s) "
                         "on %s could not be created: %s", feed_id,
                         fc.get("name"), business_date, exc)
            out.update(outcome="error", reason=f"{type(exc).__name__}: {exc}"[:500])
            return out

    def _upstream_calendar_gate(self, fc: Mapping[str, Any],
                                business_date: date,
                                upstream: Mapping[str, Any]):
        """The downstream feed's OWN calendar for the upstream's date:
        ``(calendar, forced_skip_reason, horizon_reason)``.

        A non-business day is a SKIP row (as SOD's daily translation
        ``CASE WHEN NOT IS_BUSINESS_DAY ... THEN 'SKIP'`` decides it), never
        a run.  A date beyond the calendar's populated horizon is neither
        (FR-SCH-02: an unloaded holiday and a working day are
        indistinguishable, so nothing is invented) -- ``horizon_reason``
        says so and no row is written."""
        fc_cal = self._with_declared_calendar(fc)
        calendar = self._resolve_calendar(fc_cal)
        if calendar is None:
            return None, None, None
        try:
            is_bd = calendar.is_business_day(business_date)
        except Exception as cal_exc:   # noqa: BLE001 -- returned as the reason
            return calendar, None, (
                f"calendar {fc_cal.get('calendar_name')!r} cannot say whether "
                f"{business_date.isoformat()} is a business day: {cal_exc}")
        if is_bd:
            return calendar, None, None
        return calendar, (
            f"not a business day on calendar {fc_cal.get('calendar_name')!r} "
            f"-- {upstream.get('feed_name')} completed for "
            f"{business_date.isoformat()}, and a holiday SKIP stays a skip"), None

    @staticmethod
    def _with_declared_calendar(fc: Mapping[str, Any]) -> Mapping[str, Any]:
        """The feed's ``calendar_name``, or the one its schedule DECLARATION
        names when the column is empty -- an on_completion_of declaration
        may carry its own calendar."""
        if fc.get("calendar_name"):
            return fc
        decl = fc.get("schedule_declaration")
        if isinstance(decl, dict) and decl.get("calendar_name"):
            return {**fc, "calendar_name": decl.get("calendar_name")}
        return fc

    def _plan_steps_for_run(self, fc, created_run) -> None:
        """Write this run's planned step rows (status not_started).

        Never raises.  ``created_run`` is the row ``create_feed_run``
        returned, so the plan is stamped against the run that actually
        exists rather than one this method looked up again.
        """
        if not created_run or not created_run.get("id"):
            return
        try:
            from core.feed.step_model.recorder import StepPlanRefused
            from core.feed.step_model.service import plan_for_feed
            from core.feed.step_model.store import create_planned_steps
            plan = plan_for_feed(self._db, dict(fc), created_run)
            if plan.refusals:
                # A refusal at SOD is INFORMATION, not a reason to skip
                # the feed: the engine re-plans at execute time and
                # refuses there if the feed actually declared steps.
                # Saying it now means the operator finds out in the
                # morning rather than at 3am.
                logger.error(
                    "[sod_generator] feed %s run %s: step plan REFUSED "
                    "-- %s", fc.get("id"), created_run.get("id"),
                    "; ".join(plan.refusals))
                return
            n = create_planned_steps(self._db, created_run, plan)
            if n:
                logger.debug(
                    "[sod_generator] feed %s run %s: %d planned step(s)",
                    fc.get("id"), created_run.get("id"), n)
        except Exception as exc:                   # noqa: BLE001
            logger.error(
                "[sod_generator] feed %s: planned step rows could not be "
                "written (%s: %s) -- the run itself is unaffected and the "
                "engine will write them at execute time",
                fc.get("id"), type(exc).__name__, exc)

    # ── Backfill (FR-OPS-06..09, 2026-09-02) ──────────────────
    #
    # "Re-run last month" used to mean ~20 hand-fired re-runs, EACH OF
    # WHICH DELIVERED.  A backfill is now a first-class run class:
    #   * calendar-aware: non-business days for the feed's own calendar
    #     are skipped (the same BusinessCalendar SOD uses — reused, not
    #     reimplemented);
    #   * declared ordering: oldest_first (default) or newest_first —
    #     rows are created with strictly increasing created_at/
    #     scheduled_time in the declared order, and the claim-time sort
    #     (claims.order_candidates) is FIFO within equal priority, so
    #     the declared order IS the execution order;
    #   * separate concurrency class: every row enters at
    #     claims.DEFAULT_BACKFILL_PRIORITY (the least important level)
    #     and any requested priority is clamped by
    #     claims.clamp_never_critical — a backfill can compete for
    #     general slots, age up one level short of critical, and NEVER
    #     take a reserved critical slot or outrank tonight's scheduled
    #     work at equal age;
    #   * delivery OFF by default: rows are created with
    #     suppress_delivery=True unless the launch explicitly (and
    #     auditedly, at the API) said deliver=True (FR-OPS-08);
    #   * preview-first: plan_backfill says exactly which dates WILL run
    #     and why the others will not; run_backfill executes that same
    #     plan and reports PER-ITEM outcomes, never one aggregate
    #     "done".

    BACKFILL_MAX_DAYS = 366          # a fat-fingered range must refuse
    BACKFILL_ORDERS = ("oldest_first", "newest_first")

    def plan_backfill(self, feed_id: int, start_date: date, end_date: date,
                      *, order: str = "oldest_first") -> dict:
        """The preview (FR-OPS-09): per-date verdicts in the declared
        execution order, computed WITHOUT writing anything.  Raises
        ValueError on an unusable request — the API maps it to 422."""
        if order not in self.BACKFILL_ORDERS:
            raise ValueError(
                f"order must be one of {self.BACKFILL_ORDERS}, got "
                f"{order!r}")
        if start_date > end_date:
            raise ValueError(
                f"start_date {start_date} is after end_date {end_date}")
        span = (end_date - start_date).days + 1
        if span > self.BACKFILL_MAX_DAYS:
            raise ValueError(
                f"range spans {span} days — the cap is "
                f"{self.BACKFILL_MAX_DAYS}.  Split the backfill; a "
                f"mistyped decade must refuse, not enqueue")
        fc = self._db.get_feed_config(int(feed_id))
        if not fc:
            raise ValueError(f"feed {feed_id} does not exist")
        if not fc.get("is_active", True):
            raise ValueError(
                f"feed {feed_id} ({fc.get('name')}) is INACTIVE — "
                f"re-activate it before backfilling; a backfill that "
                f"resurrects a decommissioned feed unnoticed is an "
                f"incident, not a convenience")

        calendar = self._resolve_calendar(fc)
        from datetime import timedelta as _td
        days = [start_date + _td(days=i) for i in range(span)]
        if order == "newest_first":
            days.reverse()

        items: List[dict] = []
        for d in days:
            items.append(self._plan_one_backfill_date(fc, calendar, d))
        will_run = sum(1 for i in items if i["verdict"] == "will_run")
        return {
            "feed_id": int(fc["id"]),
            "feed_name": fc.get("name"),
            # the calendar the plan was judged on -- the effective one (2026-10-11)
            "calendar_name": self.effective_calendar_name(fc),
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "order": order,
            "items": items,
            "summary": {
                "total_dates": len(items),
                "will_run": will_run,
                "skipped": len(items) - will_run,
            },
        }

    def _plan_one_backfill_date(self, fc: Mapping[str, Any], calendar,
                                d: date) -> dict:
        """One date's verdict.  Reuses the SAME per-date machinery SOD
        runs (calendar, validity window, ACTION_CONDITION) so the
        preview cannot disagree with what a scheduled run would have
        decided."""
        item = {"business_date": d.isoformat(), "verdict": "will_run",
                "reason": None, "prior_runs": 0, "active_run_id": None}
        if calendar is not None:
            try:
                _is_bd = calendar.is_business_day(d)
            except Exception as _cal_exc:
                # FR-SCH-02 — beyond the calendar's populated horizon it
                # cannot say.  Its OWN verdict, never folded into
                # "will_run": an unloaded holiday and an ordinary working
                # day are indistinguishable from here, and picking either
                # is the assumption the requirement forbids.
                item.update(verdict="beyond_calendar_horizon",
                            reason=str(_cal_exc))
                return item
            if not _is_bd:
                item.update(verdict="non_business_day",
                            reason="not a business day on calendar "
                                   f"{fc.get('calendar_name')!r}")
                return item
        if not self._in_window(fc, d):
            item.update(verdict="outside_validity_window",
                        reason=f"outside valid_from/valid_until "
                               f"({fc.get('valid_from')} .. "
                               f"{fc.get('valid_until')})")
            return item
        try:
            decision = self._evaluate_action_condition(fc, calendar, d)
            if decision.decision == "SKIP":
                item.update(verdict="condition_skip",
                            reason=decision.reason or
                                   "ACTION_CONDITION said SKIP")
                return item
        except Exception as e:
            item.update(verdict="error",
                        reason=f"ACTION_CONDITION failed: {e}"[:300])
            return item
        try:
            existing = self._db.list_feed_runs_for_feed_date(
                int(fc["id"]), d) or []
        except AttributeError:
            existing = []           # older db seam — plan without history
        item["prior_runs"] = len(existing)
        active = [r for r in existing
                  if r.get("status") in ("pending", "running")]
        if active:
            item.update(verdict="already_active",
                        active_run_id=active[0].get("id"),
                        reason=f"run {active[0].get('id')} is already "
                               f"{active[0].get('status')} for this date")
        return item

    def run_backfill(self, feed_id: int, start_date: date, end_date: date,
                     *, order: str = "oldest_first", deliver: bool = False,
                     priority: Optional[int] = None,
                     requested_by: Optional[str] = None) -> dict:
        """Execute the plan ``plan_backfill`` previewed — the launch IS
        the preview plus row creation, so the two cannot drift.  Returns
        the plan with per-item ``outcome``/``run_id`` added and a batch
        id grouping the created rows (FR-OPS-09: per-item outcomes,
        never one aggregate "done")."""
        from core.feed import claims as _claims
        from core.feed.pinning import new_build_id

        plan = self.plan_backfill(int(feed_id), start_date, end_date,
                                  order=order)
        # The plan validated the feed exists and is active; re-read the
        # row for the creation-time dependency check below.
        fc = self._db.get_feed_config(int(plan["feed_id"])) or {
            "id": int(plan["feed_id"])}
        if priority is not None:
            priority = _claims.validate_priority(priority,
                                                 where="backfill priority")
        eff_priority = _claims.clamp_never_critical(
            priority if priority is not None
            else _claims.DEFAULT_BACKFILL_PRIORITY)

        batch_id = f"bf-{new_build_id()}"[:40]
        base = datetime.now(timezone.utc)
        from datetime import timedelta as _td
        created = failed = 0
        seq = 0
        for item in plan["items"]:
            if item["verdict"] != "will_run":
                item["outcome"] = item["verdict"]
                continue
            # Strictly increasing created_at in the DECLARED order — the
            # claim-time sort is FIFO within equal priority, so this IS
            # the execution order (10ms steps keep it strict even when
            # the loop outruns the clock).
            stamp = base + _td(milliseconds=10 * seq)
            seq += 1
            bd = date.fromisoformat(item["business_date"])
            # 2026-09-27 — the SAME creation-time dependency check SOD
            # applies (one function, core/feed/etl_dependency.py).  Until
            # now every backfill row was written RUN unconditionally, so
            # a backfilled date whose upstream data never arrived just
            # ran -- and completed -- while the same date created by SOD
            # would have waited.  A held row keeps the batch id in its
            # reason so the batch stays traceable; the poller flips it to
            # RUN when the arrival lands, and the operator override
            # (POST /api/feed-runs/{id}/skip-dependencies) applies to it
            # exactly as to a scheduled row.
            hold = self._dependency_hold(fc, bd)
            row = {
                "feed_config_id":   int(plan["feed_id"]),
                "business_date":    bd,
                "run_date":         base.date(),
                "scheduled_time":   stamp,
                "created_at":       stamp,
                "status":           "pending",
                "priority":         eff_priority,
                # Deliberately NO sla_from/sla_to: a backfill of March
                # must not page anyone about March's SLA tonight.
                "sla_breached":     False,
                "action_decision":  "WAIT" if hold else "RUN",
                "action_reason":    (f"backfill {batch_id} -- {hold}" if hold
                                     else f"backfill {batch_id}"),
                "triggered_by":     "backfill",
                "triggered_by_user": requested_by,
                "run_type":         "backfill",
                "suppress_delivery": not deliver,
                "backfill_batch_id": batch_id,
                # NOT NULL build_id — the legacy partial unique index
                # allows one NULL-build row per (feed, date); a backfill
                # of an already-run date must not collide with it.
                "build_id":         new_build_id(),
            }
            try:
                out = self._db.create_feed_run(row)
                item["outcome"] = "created"
                item["run_id"] = (out.get("id")
                                  if isinstance(out, dict) else None)
                # Per-item honesty (FR-OPS-09): a created row that is
                # HELD says so, and on what, rather than reading as
                # "created" like the ones that will run right away.
                item["action_decision"] = row["action_decision"]
                if hold:
                    item["reason"] = row["action_reason"]
                created += 1
            except Exception as e:  # per-item: one bad date must not
                item["outcome"] = "error"   # void the other nineteen
                item["reason"] = str(e)[:300]
                failed += 1
        plan["batch_id"] = batch_id
        plan["deliver"] = bool(deliver)
        plan["suppress_delivery"] = not deliver
        plan["priority"] = eff_priority
        plan["requested_by"] = requested_by
        plan["summary"]["created"] = created
        plan["summary"]["errors"] = failed
        plan["summary"]["waiting_on_dependencies"] = sum(
            1 for i in plan["items"]
            if i.get("outcome") == "created"
            and i.get("action_decision") == "WAIT")
        logger.info(
            "[backfill] feed %s %s..%s (%s): created=%d errors=%d "
            "deliver=%s priority=%d batch=%s by=%s",
            plan["feed_id"], plan["start_date"], plan["end_date"], order,
            created, failed, deliver, eff_priority, batch_id, requested_by)
        return plan

    # ── Helpers ───────────────────────────────────────────────────────

    def _dependency_hold(self, fc: Mapping[str, Any],
                         business_date: date) -> Optional[str]:
        """The creation-time dependency verdict for one (feed, date):
        the WAIT reason, or None when the row may be written RUN.

        Both creators in this class (SOD and the backfill launcher) go
        through here, and here delegates to THE shared function the cron
        fire's create branch also calls -- one decision, three callers.
        """
        from core.feed.etl_dependency import hold_reason_at_creation
        return hold_reason_at_creation(self._db, fc, business_date)

    def _resolve_calendar(self, fc: Mapping[str, Any],
                          ctx: Optional[_Pass] = None) -> Optional[BusinessCalendar]:
        """The feed's :class:`BusinessCalendar`, by ``effective_calendar_name``
        (feed, declaration, then the deployment default -- ONE answer), cached
        per pass by name.  A NAMED calendar that does not exist is reported
        by ``_calendar_problem`` (the caller decides whether that refuses);
        here it resolves to None, as it always did."""
        cal_name = self.effective_calendar_name(fc)
        if not cal_name:
            return None
        if ctx is not None and cal_name in ctx.calendars:
            return ctx.calendars[cal_name]
        spec = self._cal_repo.get(str(cal_name))
        if spec is None:
            logger.info(
                "[sod_generator] feed %s: calendar %r not found — treating as no-calendar",
                fc.get("id"), cal_name,
            )
            cal = None
        else:
            cal = BusinessCalendar(spec)
        if ctx is not None:
            ctx.calendars[cal_name] = cal
        return cal

    def _calendar_problem(self, fc: Mapping[str, Any], kind: str,
                          calendar: Optional[BusinessCalendar]) -> Optional[str]:
        """Why a CALENDAR-BOUND schedule kind cannot be judged, or None.

        ``month_end`` / ``workday_n`` / ``workdays`` mean "business day" by
        definition; with no calendar anywhere the platform's
        ``BusinessCalendar(None)`` rule makes every day a business day and
        month-end becomes Sat 31 -- a file the counterparty does not expect.
        A correctness gate must fail, not guess (CLAUDE.md §4), so the feed
        is REFUSED for the pass, naming the key that fixes it.  ``daily`` and
        ``cron`` keep the every-day rule they always had.  Decided
        2026-10-11 over refusing at authoring: ``default_calendar`` is a
        deployment knob set after the feeds exist (the owner's 4,000 are
        rendered from a template with ``calendar_name: null``), so the
        gate belongs where the date is decided."""
        if kind not in CALENDAR_BOUND_KINDS or calendar is not None:
            return None
        name = self.effective_calendar_name(fc)
        if name:
            return (f"schedule kind {kind} needs a business calendar and "
                    f"calendar {name!r} does not exist (feed_configs.calendar_name / "
                    f"the declaration / feed_generation.default_calendar) -- no run "
                    f"is created until it does")
        return (f"schedule kind {kind} needs a business calendar: set "
                f"feed_configs.calendar_name on the feed or "
                f"feed_generation.default_calendar for the deployment -- without one "
                f"month-end would fall on the last CALENDAR day, so no run is created")

    @staticmethod
    def _in_window(fc: Mapping[str, Any], business_date: date) -> bool:
        """Honour valid_from / valid_until (inclusive)."""
        vf = _coerce_date(fc.get("valid_from"))
        vu = _coerce_date(fc.get("valid_until"))
        if vf is not None and business_date < vf:
            return False
        if vu is not None and business_date > vu:
            return False
        return True

    def _evaluate_action_condition(
        self,
        fc: Mapping[str, Any],
        calendar: Optional[BusinessCalendar],
        business_date: date,
    ):
        # When no calendar is configured the evaluator still works
        # (e.g. condition that just compares $business_date to a
        # literal).  Pass an empty BusinessCalendar so IS_BUSINESS_DAY
        # macros don't crash.
        cal = calendar or BusinessCalendar(None)
        evaluator = ActionConditionEvaluator(cal)
        return evaluator.evaluate(fc.get("action_condition_sql"), business_date)


def _coerce_date(v) -> Optional[date]:
    if v is None or v == "":
        return None
    if isinstance(v, date) and not isinstance(v, datetime):
        return v
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, str):
        try:
            return datetime.fromisoformat(v[:10]).date()
        except Exception:
            return None
    return None
