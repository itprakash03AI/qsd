"""Feed ALERTS -- one record per problem, and where it went (2026-10-12).

The owner: "where is netcool/email alert".  Alerts were raised in four
places, each its own way: the SLA watcher's Netcool events (per dependency),
the variance hold's bell rows, the engine's failure e-mail (recorded on the
execution), nothing at all for a re-sent month-end message.  Nobody could
answer "what was this task alerted for, and who was told" without reading
four stores.

THE alert is a ``feed_alerts`` row: kind, feed, business date, run date, the
words, and ``deliveries`` -- one entry per channel (bell / e-mail / Netcool)
with the recipients and the OUTCOME (sent, pending, failed, refused, not
routed), so the board shows exactly what happened.  Everything a raise does
is DATA:

* the KIND (``feed_alert_kinds``): title, severity (OMNIbus 0-5), the
  console's AlertGroup, which channels, and the CLEAR condition every alert
  must state;
* the RECIPIENTS: the bell reaches the feed's owner and its approver groups
  (``variance_hold.deciders_for`` -- the people who can ACT) plus every
  ``feed_alert_routes`` bell target of the feed's scopes; the e-mail reaches
  :func:`email_recipients` -- the feed's ``notify_emails``, its owner
  group's ``notification_email`` (the rule the engine's run e-mail always
  used, now read from here) and every e-mail route of the feed's scopes.

A raise is IDEMPOTENT on ``dedupe_key`` (one problem, one alert, however
many passes see it) and FAIL-OPEN (an alert must never fail a feed or an
arrival) but never silent: every channel that could not deliver says why
on the row.  E-mail is sent off the caller's thread; a send that did not
complete stays ``pending`` and the SLA watcher's pass retries it
(:func:`deliver_pending_email`).  A clear sends the Netcool RESOLUTION with
the same Identifier (FR-ALT-01).

THE SUBJECT (2026-10-17).  The road is no longer feeds-only: a published API
and a platform component raise through the SAME functions by passing an
:class:`~core.feed.alert_subject.AlertSubject` instead of ``feed=``.  The
row then carries ``subject_kind`` / ``subject_key`` (``feed_config_id``
NULL), the dedupe key defaults to ``<kind>:<key>:<alert kind>``, the bell
reaches the subject's ``owners`` plus the bell routes in its scope chain
(``feed_alert_routes`` keyed by ``scope`` + ``scope_key``), the e-mail its
``emails`` plus the e-mail routes, and Netcool keys the event on the
subject's ``key``.  Nothing here knows WHICH kinds exist; a feed's path is
byte-for-byte the one from 2026-10-12.
"""
from __future__ import annotations

import logging
import threading
import time
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Mapping, Optional, Union

from core.feed.alert_subject import AlertSubject, route_matches_subject

logger = logging.getLogger(__name__)

EVENT_PREFIX = "feed_alert_"
DELIVERED = ("sent", "queued")
_CACHE_SECONDS = 30.0
#: per DATABASE (keyed by the manager's identity): a cached vocabulary must
#: never answer for another database's rows (found 2026-10-12: a test on one
#: database filled it, another database's raise read "not declared")
_kinds_cache: Dict[int, tuple] = {}
_lock = threading.Lock()


def invalidate() -> None:
    with _lock:
        _kinds_cache.clear()


def kinds(db) -> Dict[str, dict]:
    """The alert-kind vocabulary (cached 30 s per database; an admin edit invalidates)."""
    key = id(db)
    with _lock:
        hit = _kinds_cache.get(key)
        if hit is not None and time.monotonic() - hit[0] < _CACHE_SECONDS:
            return hit[1]
    rows = {k["kind"]: k for k in db.list_feed_alert_kinds(active_only=True) or []}
    with _lock:
        _kinds_cache[key] = (time.monotonic(), rows)
    return rows


def _routes(db, about: Union[Mapping[str, Any], AlertSubject], kind: str, channel: str) -> List[str]:
    """The route targets of this channel that apply to ``about`` -- a feed
    (the feed scope chain) or an :class:`AlertSubject` (its own chain)."""
    from core.feed.feed_scope import matches
    try:
        rows = db.list_feed_alert_routes() or []
    except Exception as exc:                            # noqa: BLE001 -- said on the row
        logger.error("[feed_alerts] routes unreadable (%s)", exc)
        return []
    if isinstance(about, AlertSubject):
        applies = lambda r: route_matches_subject(r, about)          # noqa: E731
    else:
        applies = lambda r: r.get("scope_key") in (None, "") and matches(r, about)   # noqa: E731
    return [str(r["target"]) for r in rows
            if r.get("channel") == channel and (not r.get("kind") or r.get("kind") == kind)
            and applies(r)]


def _expand_bell_targets(db, targets: List[str]) -> set:
    """``group:<name>`` -> its members; anything else is a username."""
    names = set()
    for t in targets:
        if t.lower().startswith("group:"):
            g = db.get_user_group_by_name(t.split(":", 1)[1].strip())
            for m in (db.list_user_group_members(int(g["id"])) if g else []) or []:
                if m.get("username"):
                    names.add(str(m["username"]))
        else:
            names.add(t)
    return names


def subject_bell_recipients(db, subject: AlertSubject, kind: str) -> List[str]:
    """Who sees a SUBJECT's alert in the bell: its owners + the bell routes
    of its scope chain."""
    names = {str(o) for o in subject.owners if o}
    names |= _expand_bell_targets(db, _routes(db, subject, kind, "bell"))
    return sorted(names)


def subject_email_recipients(db, subject: AlertSubject, kind: str) -> List[str]:
    """A SUBJECT's e-mail recipients: its addresses + the e-mail routes of
    its scope chain, de-duplicated case-insensitively."""
    raw = [str(a) for a in subject.emails if a] + _routes(db, subject, kind, "email")
    out, seen = [], set()
    for a in raw:
        a = a.strip()
        if a and a.lower() not in seen:
            seen.add(a.lower())
            out.append(a)
    return out


def email_recipients(db, feed: Mapping[str, Any], kind: Optional[str] = None) -> List[str]:
    """THE e-mail recipients of a feed: ``notify_emails``, the owner group's
    ``notification_email`` and, for an alert ``kind``, every e-mail route of
    the feed's scopes -- de-duplicated case-insensitively, in that order."""
    raw: List[str] = [a for a in str(feed.get("notify_emails") or "").split(",")]
    if feed.get("owner_group_id") and db is not None:
        try:
            g = db.get_user_group(int(feed["owner_group_id"])) or {}
            raw += str(g.get("notification_email") or "").split(",")
        except Exception as exc:                        # noqa: BLE001
            logger.debug("[feed_alerts] owner group e-mail unreadable: %s", exc)
    if kind:
        raw += _routes(db, feed, kind, "email")
    out, seen = [], set()
    for a in raw:
        a = a.strip()
        if a and a.lower() not in seen:
            seen.add(a.lower())
            out.append(a)
    return out


def bell_recipients(db, feed: Mapping[str, Any], kind: str) -> List[str]:
    """Who sees it in the bell: the people who can ACT on the feed (owner +
    approver groups) and every bell route (a username or ``group:<name>``)."""
    from core.feed.variance_hold import deciders_for
    names = set()
    try:
        names.update(deciders_for(db, {"feed_config_id": feed.get("id")}))
    except Exception as exc:                            # noqa: BLE001
        logger.debug("[feed_alerts] deciders unreadable: %s", exc)
    names |= _expand_bell_targets(db, _routes(db, feed, kind, "bell"))
    return sorted(names)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _as_date(v) -> Optional[date]:
    if v is None or isinstance(v, date) and not isinstance(v, datetime):
        return v
    if isinstance(v, datetime):
        return v.date()
    return date.fromisoformat(str(v)[:10])


def raise_alert(db, kind: str, *, feed: Optional[Mapping[str, Any]] = None,
                subject: Optional[AlertSubject] = None, business_date=None, message: str,
                dedupe_key: Optional[str] = None, run_date=None, feed_run_id: Optional[int] = None,
                execution_id: Optional[str] = None, href: Optional[str] = None,
                email_async: bool = True) -> Optional[dict]:
    """Raise ONE alert (or return the open one with this key).  Never raises.

    About a FEED (``feed=``, the 2026-10-12 contract: ``dedupe_key`` and
    ``business_date`` required by the callers' convention) or about a
    SUBJECT (``subject=``: an :class:`AlertSubject`; ``dedupe_key`` defaults
    to ``<kind>:<key>:<alert kind>``, ``business_date`` is optional).  Exactly
    one of the two; both or neither is refused -- logged, None returned,
    nothing raised -- like an undeclared kind."""
    about = feed.get("name") if feed else (subject.key if subject else "?")
    try:
        if (feed is None) == (subject is None):
            logger.error("[feed_alerts] %s could NOT be raised: exactly one of feed= / subject= "
                         "must be given (feed=%r, subject=%r)", kind, feed is not None,
                         subject is not None)
            return None
        if subject is None and dedupe_key is None:
            logger.error("[feed_alerts] %s for feed %s @ %s could NOT be raised: a feed alert "
                         "needs a dedupe_key", kind, about, business_date)
            return None
        return _raise(db, kind, feed=feed, subject=subject, business_date=business_date,
                      message=message, dedupe_key=dedupe_key, run_date=run_date,
                      feed_run_id=feed_run_id, execution_id=execution_id, href=href,
                      email_async=email_async)
    except Exception as exc:                            # noqa: BLE001 -- an alert never fails the caller
        logger.error("[feed_alerts] %s for %s @ %s could NOT be raised: %s",
                     kind, about, business_date, exc, exc_info=True)
        return None


def _raise(db, kind, *, feed, subject, business_date, message, dedupe_key, run_date, feed_run_id,
           execution_id, href, email_async):
    k = kinds(db).get(kind)
    about_name = feed.get("name") if feed is not None else subject.name
    if k is None:
        logger.error("[feed_alerts] alert kind %r is not declared (or inactive) in "
                     "feed_alert_kinds -- NOT raised for %s @ %s: %s",
                     kind, about_name, business_date, message)
        return None
    bd = _as_date(business_date)
    title = f"{about_name}: {k['title']}"
    if subject is not None:
        key = dedupe_key or subject.dedupe_key(kind)
        who = subject.as_row_fields()
    else:
        key = dedupe_key
        who = {"feed_config_id": feed.get("id"), "feed_name": feed.get("name"),
               "subject_kind": None, "subject_key": None}
    row, created = db.open_feed_alert({
        "dedupe_key": str(key)[:255], "kind": kind, "severity": int(k["severity"]),
        **who,
        "business_date": bd, "run_date": _as_date(run_date), "feed_run_id": feed_run_id,
        "execution_id": execution_id, "title": title[:255], "message": message,
        "deliveries": [], "status": "open"})
    if not created:
        return row
    if subject is not None:
        link = href or subject.href or "/"
        bell_to = subject_bell_recipients(db, subject, kind)
        mail_to = subject_email_recipients(db, subject, kind)
        no_bell = (f"the {subject.kind} has no owner, and no bell route is mapped for "
                   f"{subject.kind} / {subject.key} / global")
        no_mail = (f"no address: the {subject.kind} declares no e-mail, and no e-mail route is "
                   f"mapped for {subject.kind} / {subject.key} / global")
        payload_who = {"subject_kind": subject.kind, "subject_key": subject.key}
    else:
        link = href or (f"/feeds/today?business_date={bd.isoformat()}&search={feed.get('name')}"
                        if bd else "/feeds/today")
        bell_to = bell_recipients(db, feed, kind)
        mail_to = email_recipients(db, feed, kind)
        no_bell = "the feed has no owner and no approver group, and no bell route is mapped"
        no_mail = ("no address: the feed has no notify e-mails, its owner group no "
                   "notification e-mail, and no e-mail route is mapped (Feed alerts -> Routes)")
        payload_who = {"feed_config_id": feed.get("id")}
    deliveries: List[dict] = []
    at = _now().isoformat()
    if k.get("to_bell"):
        told, failed = [], []
        for username in bell_to:
            try:
                db.log_notification(
                    event_type=EVENT_PREFIX + kind, channel="websocket", recipient=username,
                    status="sent", title=title, message=message,
                    payload={"alert_id": row["id"], **payload_who,
                             "business_date": bd.isoformat() if bd else None, "href": link},
                    execution_id=execution_id)
                told.append(username)
            except Exception as exc:                    # noqa: BLE001
                failed.append(f"{username}: {exc}")
        deliveries.append({"channel": "bell", "to": told, "at": at,
                           "status": "sent" if told else ("failed" if failed else "not_routed"),
                           "reason": ("; ".join(failed)[:500] if failed else
                                      None if told else no_bell)})
    if k.get("to_email"):
        deliveries.append({"channel": "email", "to": mail_to, "at": at,
                           "status": "pending" if mail_to else "not_routed",
                           "reason": None if mail_to else no_mail})
    if k.get("to_netcool"):
        obj = str(feed.get("name")) if feed is not None else str(subject.key)
        deliveries.append(_netcool(db, k, obj=obj, bd=bd, title=title, message=message,
                                   execution_id=execution_id, link=link,
                                   feed_name=str(feed.get("name")) if feed is not None else None))
    row = db.update_feed_alert(row["id"], {
        "deliveries": deliveries,
        "netcool_identifier": next((d.get("identifier") for d in deliveries
                                    if d["channel"] == "netcool" and d.get("identifier")), None)}) or row
    if subject is not None:
        _publish_subject(db, subject, row, bell_to, link)
    else:
        _publish(db, feed, row)
    if any(d["channel"] == "email" and d["status"] == "pending" for d in deliveries):
        if email_async:
            threading.Thread(target=_send_email_safe, args=(db, row["id"]),
                             name=f"feed-alert-mail-{row['id']}", daemon=True).start()
        else:
            _send_email_safe(db, row["id"])
    logger.warning("[feed_alerts] RAISED %s #%s %s @ %s: %s -- %s", kind, row["id"],
                   about_name, bd, message,
                   ", ".join(f"{d['channel']} {d['status']}" for d in deliveries) or "no channel")
    return row


def _netcool(db, k, *, obj: str, bd, title, message, execution_id, link,
             feed_name: Optional[str] = None) -> dict:
    """The Netcool event for a feed (``obj`` = the feed's name, QSFeed set)
    or for a subject (``obj`` = its key, QSFeed empty)."""
    from core.config import deploy_environment
    from core.feed import netcool as nc
    entry = {"channel": "netcool", "at": _now().isoformat()}
    try:
        env = deploy_environment()
        ev = nc.build_event(env=env, alert_type=k["kind"].upper(), obj=obj,
                            business_date=bd or _now().date(), severity=int(k["severity"]),
                            summary=f"{title} -- {message}", alert_group=k["alert_group"],
                            clears_when=k["clears_when"], run_id=execution_id,
                            feed=feed_name, url=link)
    except nc.NetcoolContractError as exc:
        return {**entry, "status": "refused", "reason": str(exc)[:500]}
    qid = nc.enqueue_event(db.SessionLocal, ev)
    if qid is None:
        return {**entry, "status": "failed", "identifier": ev.identifier,
                "reason": "the notification queue refused the event (logged: THIS ALERT IS LOST)"}
    return {**entry, "status": "queued", "identifier": ev.identifier, "queue_id": qid,
            "event": ev.to_dict()}


def _send_email_safe(db, alert_id: int) -> None:
    try:
        deliver_email(db, alert_id)
    except Exception as exc:                            # noqa: BLE001
        logger.error("[feed_alerts] e-mail of alert %s failed to run: %s", alert_id, exc)


def deliver_email(db, alert_id: int) -> Optional[dict]:
    """Send the pending e-mail of one alert through THE mailer and write the
    outcome on its delivery entry."""
    from core.email_service import NOT_CONFIGURED_REASON, is_email_enabled, send_email
    from core.email_service import last_send_failure_reason
    alert = db.get_feed_alert(int(alert_id))
    if alert is None:
        return None
    deliveries = list(alert.get("deliveries") or [])
    changed = False
    for d in deliveries:
        if d.get("channel") != "email" or d.get("status") != "pending":
            continue
        d["attempts"] = int(d.get("attempts") or 0) + 1
        d["at"] = _now().isoformat()
        if not is_email_enabled():
            d["status"], d["reason"] = "failed", NOT_CONFIGURED_REASON
        else:
            text = f"{alert['title']}\n\n{alert.get('message') or ''}\n\nBusiness date: " \
                   f"{alert.get('business_date')}   Run date: {alert.get('run_date') or '-'}"
            html = "<pre>" + text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;") + "</pre>"
            ok = bool(send_email(to_addresses=list(d.get("to") or []), subject=alert["title"],
                                 html_body=html, text_body=text))
            d["status"] = "sent" if ok else ("failed" if d["attempts"] >= 3 else "pending")
            d["reason"] = None if ok else last_send_failure_reason()
        changed = True
    if changed:
        return db.update_feed_alert(alert_id, {"deliveries": deliveries})
    return alert


def deliver_pending_email(db, limit: int = 20) -> int:
    """The retry: every open alert whose e-mail is still pending (a send
    that did not complete, a pod that died mid-send).  Ridden by the SLA
    watcher's pass -- one election, one interval, no second daemon."""
    n = 0
    for a in db.list_feed_alerts_owing_email(limit=limit) or []:
        deliver_email(db, a["id"])
        n += 1
    return n


def clear(db, *, by: str, dedupe_keys: Optional[List[str]] = None,
          feed_config_id: Optional[int] = None, business_date=None,
          kinds_: Optional[List[str]] = None, subject_kind: Optional[str] = None,
          subject_key: Optional[str] = None) -> List[dict]:
    """Clear OPEN alerts (by key, by feed + date + kinds, or by subject kind
    + key + kinds) and send each Netcool RESOLUTION with the raise's
    Identifier.  Never raises.  With no selector at all nothing is cleared
    (a clear of everything is never what a caller meant)."""
    if not any([dedupe_keys, feed_config_id is not None, business_date is not None,
                subject_kind, subject_key]):
        logger.error("[feed_alerts] clear (%s) refused: no selector (keys / feed / date / subject)", by)
        return []
    try:
        rows = db.clear_feed_alerts(dedupe_keys=dedupe_keys, feed_config_id=feed_config_id,
                                    business_date=_as_date(business_date), kinds=kinds_,
                                    subject_kind=subject_kind, subject_key=subject_key,
                                    cleared_by=by) or []
    except Exception as exc:                            # noqa: BLE001
        logger.error("[feed_alerts] clear (%s) failed: %s", by, exc)
        return []
    from core.feed import netcool as nc
    for r in rows:
        for d in r.get("deliveries") or []:
            if d.get("channel") == "netcool" and d.get("status") == "queued" and d.get("event"):
                e = d["event"]
                try:
                    ev = nc.NetcoolEvent(
                        identifier=e["Identifier"], node=e["Node"], alert_group=e["AlertGroup"],
                        alert_key=e["AlertKey"], severity=int(e["Severity"]), summary=e["Summary"],
                        type=int(e["Type"]), qs_run_id=e.get("QSRunId"), qs_feed=e.get("QSFeed"),
                        qs_business_date=e.get("QSBusinessDate"), qs_url=e.get("QSUrl"))
                    nc.enqueue_event(db.SessionLocal, nc.resolution_for(ev))
                except Exception as exc:                # noqa: BLE001
                    logger.error("[feed_alerts] resolution of %s not sent: %s", r.get("id"), exc)
        logger.info("[feed_alerts] CLEARED %s #%s %s @ %s by %s", r.get("kind"), r.get("id"),
                    r.get("feed_name"), r.get("business_date"), by)
    return rows


def _publish(db, feed: Mapping[str, Any], row: Mapping[str, Any]) -> None:
    """Tell the board live: a ``feed_status`` event to THE feed audience
    (core/feed/event_audience.py), through the durable outbox so it reaches
    the browser from any pod (the scheduler's included).  Advisory."""
    try:
        from core.feed.event_audience import address, feed_event_audience
        from core.notification_queue import emit_ws_event
        audience = feed_event_audience(db, feed.get("id"), None, run_id=row.get("feed_run_id"))
        if not audience:
            return
        from core import scheduler as _sch
        emit_ws_event(
            address({"type": "feed_status", "feed_id": feed.get("id"), "feed_name": feed.get("name"),
                     "business_date": row.get("business_date"),
                     "alert": {"id": row.get("id"), "kind": row.get("kind"), "title": row.get("title"),
                               "severity": row.get("severity")}}, audience),
            session_factory=getattr(db, "SessionLocal", None),
            local_broadcast_fn=getattr(_sch, "_broadcast_fn", None))
    except Exception as exc:                            # noqa: BLE001 -- the row is the record
        logger.debug("[feed_alerts] live event not sent: %s", exc)


def _publish_subject(db, subject: AlertSubject, row: Mapping[str, Any], audience,
                     link: Optional[str] = None) -> None:
    """Tell the people in the bell live: an ``alert_raised`` event addressed
    to the subject's bell recipients, through the durable outbox (any pod).
    Advisory; the row is the record."""
    try:
        names = sorted({str(a) for a in (audience or []) if a})
        if not names:
            return
        from core.feed.event_audience import address
        from core.notification_queue import emit_ws_event
        from core import scheduler as _sch
        emit_ws_event(
            address({"type": "alert_raised", "subject_kind": subject.kind,
                     "subject_key": subject.key, "subject_name": subject.name,
                     "href": link or subject.href,
                     "alert": {"id": row.get("id"), "kind": row.get("kind"), "title": row.get("title"),
                               "severity": row.get("severity")}}, names),
            session_factory=getattr(db, "SessionLocal", None),
            local_broadcast_fn=getattr(_sch, "_broadcast_fn", None))
    except Exception as exc:                            # noqa: BLE001 -- the row is the record
        logger.debug("[feed_alerts] live subject event not sent: %s", exc)


def for_tasks(db, pairs) -> Dict[tuple, List[dict]]:
    """{(feed_id, business_date iso): [alert, ...]} for a board page, one query."""
    out: Dict[tuple, List[dict]] = {}
    if not pairs:
        return out
    for a in db.list_feed_alerts(pairs=list(pairs), limit=2000) or []:
        out.setdefault((a.get("feed_config_id"), a.get("business_date")), []).append(public(a))
    return out


def public(a: Mapping[str, Any]) -> dict:
    """The board's shape: no Netcool body, the channels in words."""
    return {"id": a.get("id"), "kind": a.get("kind"), "title": a.get("title"),
            "message": a.get("message"), "severity": a.get("severity"),
            "status": a.get("status"), "raised_at": a.get("raised_at"),
            "cleared_at": a.get("cleared_at"), "cleared_by": a.get("cleared_by"),
            "run_date": a.get("run_date"),
            "subject_kind": a.get("subject_kind"), "subject_key": a.get("subject_key"),
            "feed_name": a.get("feed_name"),
            "deliveries": [{k: v for k, v in d.items() if k not in ("event", "queue_id")}
                           for d in a.get("deliveries") or []]}


def raise_component_alert(db, kind: str, *, component_id: str, label: str, message: str,
                          dedupe_key: str, href: Optional[str] = None,
                          email_async: bool = True) -> Optional[dict]:
    """A PLATFORM COMPONENT on THE alert road (2026-10-17, core/component_health/):
    a thin wrapper over :func:`raise_alert` with an :class:`AlertSubject` of
    kind ``component`` -- the same row, kinds table, deliveries, dedupe and
    routes as every other subject.  Who is told is DATA on the subject: the
    bell reaches the admin tier (``platform_event_audience``) plus every bell
    route of ``component`` / this component / ``global``; e-mail the e-mail
    routes of the same chain; Netcool the kind's console group.  Never raises."""
    owners: tuple = ()
    try:
        from core.feed.event_audience import platform_event_audience
        owners = tuple(platform_event_audience(db, role="admin"))
    except Exception as exc:                            # noqa: BLE001
        logger.debug("[feed_alerts] platform audience unreadable for %s: %s", component_id, exc)
    subject = AlertSubject(kind="component", key=str(component_id), name=str(label or component_id),
                           owners=owners,
                           href=href or f"/admin?section=componentHealth&component={component_id}")
    return raise_alert(db, kind, subject=subject, business_date=_now().date(), message=message,
                       dedupe_key=dedupe_key, email_async=email_async)
