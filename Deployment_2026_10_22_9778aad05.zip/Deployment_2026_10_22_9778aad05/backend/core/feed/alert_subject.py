"""The SUBJECT of an alert that is not a feed (2026-10-17).

THE alert road (core/feed/feed_alerts.py) raised alerts for feeds only: the
row keyed the feed, the recipients came from the feed's owner group and
approvers, and a route matched through the feed's scope chain.  Two other
areas now raise through the SAME road -- a published API (its error rate,
its latency, a dependency gone) and a platform component (down, degraded) --
and neither is a feed.  Rather than a second raise path per area, the road
takes an :class:`AlertSubject`: WHO it is (``kind`` + ``key``), WHAT to
call it, WHO is told (owners in the bell, addresses by e-mail), WHERE the
page is, and WHICH route scopes apply beyond the kind's own.

Nothing in this module knows a particular kind: ``published_api`` and
``component`` are strings the callers choose, and a third area needs no
change here.  A feed keeps its own path (``raise_alert(feed=...)``): its
recipients and scopes are feed rules that already exist.

Route scoping for a subject (``feed_alert_routes``): a route row matches when

* ``scope == subject.kind`` and ``scope_key`` is NULL      -> every subject of that kind
* ``scope == subject.kind`` and ``scope_key == subject.key`` -> this one subject
* ``scope == "global"``                                     -> everything (feeds too)
* ``(scope, scope_key)`` is in ``subject.scopes``           -> a scope the caller declares
  (an API's kind, a component's pod, ...)

``scope_id`` stays the FEED chain's integer key; subjects key routes by
``scope_key`` (a string), so the two chains never collide.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List, Mapping, Optional, Tuple

#: The scope every alert -- feed or subject -- is in.
SCOPE_GLOBAL = "global"


def default_dedupe_key(kind: str, key: str, alert_kind: str) -> str:
    """ONE open alert per (subject kind, subject key, alert kind) unless the
    caller names a finer problem (a threshold id, a dependency name)."""
    return f"{kind}:{key}:{alert_kind}"


@dataclass(frozen=True)
class AlertSubject:
    """What an alert is ABOUT when it is not a feed."""
    kind: str                                   # 'published_api' | 'component' | ... (never 'feed')
    key: str                                    # stable identity within the kind (a slug, a component name)
    name: str = ""                              # the words on the row and in the bell; defaults to key
    owners: Tuple[str, ...] = ()                # usernames told in the bell
    emails: Tuple[str, ...] = ()                # addresses told by e-mail
    href: Optional[str] = None                  # the page the bell opens
    scopes: Tuple[Tuple[str, Optional[str]], ...] = field(default_factory=tuple)  # extra (scope, scope_key) route scopes

    def __post_init__(self):
        if not str(self.kind or "").strip() or self.kind == "feed":
            raise ValueError("an AlertSubject needs a kind other than 'feed' (feeds use raise_alert(feed=...))")
        if not str(self.key or "").strip():
            raise ValueError(f"an AlertSubject of kind {self.kind!r} needs a key")
        if not self.name:
            object.__setattr__(self, "name", str(self.key))

    def chain(self) -> List[Tuple[str, Optional[str]]]:
        """The route scopes this subject is in, most specific first."""
        out: List[Tuple[str, Optional[str]]] = [(self.kind, str(self.key)), (self.kind, None)]
        for s in self.scopes:
            pair = (str(s[0]), None if s[1] is None else str(s[1]))
            if pair not in out:
                out.append(pair)
        out.append((SCOPE_GLOBAL, None))
        return out

    def dedupe_key(self, alert_kind: str) -> str:
        return default_dedupe_key(self.kind, self.key, alert_kind)

    def as_row_fields(self) -> dict:
        """The columns a ``feed_alerts`` row carries for a subject."""
        return {"subject_kind": str(self.kind)[:20], "subject_key": str(self.key)[:220],
                "feed_config_id": None, "feed_name": str(self.name)[:255]}


def route_matches_subject(route: Mapping[str, Any], subject: AlertSubject) -> bool:
    """Does this ``feed_alert_routes`` row apply to the subject?  A route
    with a feed ``scope_id`` never does (it names a feed chain)."""
    if route.get("scope_id") is not None:
        return False
    scope = route.get("scope")
    key = route.get("scope_key")
    if scope == SCOPE_GLOBAL:
        return key in (None, "")
    return (scope, None if key in (None, "") else str(key)) in subject.chain()


__all__ = ["AlertSubject", "SCOPE_GLOBAL", "default_dedupe_key", "route_matches_subject"]
