"""Policy resolution — turns (principal, connection, table) into the ordered
list of row + column policies that should apply.

The resolver is the ONE place that owns:
  * principal expansion (user → role → groups → "all")
  * table_pattern matching (exact + glob + qualified)
  * connection scoping (NULL = applies to all)
  * variable substitution in filter_sql

It is engine-agnostic — the same resolved policies feed the sqlglot rewriter,
the view materializer, and the Lake Formation translator.
"""
from __future__ import annotations

import fnmatch
import logging
import re
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ── Principal context ───────────────────────────────────────────────────────

@dataclass(frozen=True)
class UserContext:
    """Resolved principal context for a request.

    ``attrs`` is the freeform attribute bag exposed to ``${user.<attr>}``
    substitution.  Typically populated from the user dict + AD/LDAP groups
    + any external IDP claims.  Keys are lower-cased on read.
    """
    username: str
    role: str = "viewer"
    groups: Tuple[str, ...] = ()
    attrs: Dict[str, Any] = field(default_factory=dict)
    is_admin: bool = False
    #: True when this principal was FABRICATED rather than resolved -- an AD
    #: lookup that failed, a share token with no identity, a report with no
    #: recorded owner.
    #:
    #: 2026-08-19.  Three sites built such a context as
    #: ``{role: "viewer", groups: []}`` and documented it as least-privilege,
    #: one of them asserting it "can only ever restrict further (drop rows),
    #: never leak extra rows".  In THIS engine that is backwards.  Policies
    #: are bound to principals and an unmatched table is SKIPPED (left
    #: unfiltered), so dropping the groups drops the very bindings that were
    #: doing the restricting: a policy bound to ``group:emea-only`` stops
    #: matching and the table ships every region.  Stripping identity here
    #: ESCALATES.
    #:
    #: The flag lets the rewriter tell "this table has no policies" (fine,
    #: RLS simply is not configured for it) from "this table HAS policies and
    #: we could not tell whether they apply" (refuse).
    unresolved: bool = False

    def principal_ids(self) -> List[str]:
        """Return the list of principal identifiers a binding could match
        for this user, in canonical order.

        Example for ``alice`` (analyst, finance + audit groups):
            ["user:alice", "role:analyst", "group:finance",
             "group:audit", "all:*"]

        The ``all:*`` wildcard lets admins define org-wide defaults.
        """
        ids: List[str] = []
        if self.username:
            ids.append(f"user:{self.username}")
        if self.role:
            ids.append(f"role:{self.role}")
        for g in self.groups:
            if g:
                ids.append(f"group:{g}")
        ids.append("all:*")
        return ids


# ── Variable substitution ───────────────────────────────────────────────────

_VAR_RE = re.compile(r"\$\{user\.([a-zA-Z_][a-zA-Z0-9_]*)\}")


def _quote_sql_literal(v: Any) -> str:
    """Render ``v`` as a safe SQL literal.  Strings are single-quoted with
    embedded single quotes escaped.  Lists/tuples expand to ``(a,b,c)``.

    Note: this is NOT a parameter binding — we are emitting SQL text that
    DuckDB/Trino/Spark will parse.  Single-quote escaping is the canonical
    SQL string escape and is safe for the supported dialects.  The caller
    must still ensure the surrounding ``filter_sql`` template was reviewed
    by an admin (which is the policy creation contract).
    """
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, (list, tuple, set)):
        items = list(v)
        if not items:
            # Empty IN-list — DuckDB rejects `IN ()`.  Emit a never-match
            # sentinel that survives type checking.
            return "(NULL)"
        return "(" + ", ".join(_quote_sql_literal(x) for x in items) + ")"
    # Strings & everything else
    s = str(v).replace("'", "''")
    return f"'{s}'"


def substitute_vars(template: str, ctx: UserContext) -> str:
    """Replace ``${user.<attr>}`` tokens in ``template`` with quoted literals.

    Lookup order: explicit context fields first (``username``, ``role``,
    ``groups``), then ``ctx.attrs``.  Unknown tokens emit ``NULL`` and a
    warning so admins notice broken policies during dry-run.
    """
    if "${" not in template:
        return template

    def _replace(match: "re.Match[str]") -> str:
        key = match.group(1).lower()
        if key == "username":
            return _quote_sql_literal(ctx.username)
        if key == "role":
            return _quote_sql_literal(ctx.role)
        if key == "groups":
            return _quote_sql_literal(list(ctx.groups))
        if key == "is_admin":
            return _quote_sql_literal(ctx.is_admin)
        # Look in attrs (case-insensitive)
        for k, v in ctx.attrs.items():
            if k.lower() == key:
                return _quote_sql_literal(v)
        logger.warning(
            "row_security: unknown ${user.%s} in policy filter — substituting NULL",
            key,
        )
        return "NULL"

    return _VAR_RE.sub(_replace, template)


# ── Table-pattern matching ──────────────────────────────────────────────────

def _normalize_table_ref(table_ref: str) -> List[str]:
    """Return a list of candidate forms for matching against table_pattern.

    For a ``conn1.public.orders`` reference we try:
        - ``conn1.public.orders``  (exact qualified)
        - ``public.orders``        (drop top qualifier)
        - ``orders``               (bare name)

    Plus the original casing AND lower-cased variants.
    """
    if not table_ref:
        return []
    raw = table_ref.strip().strip('"').strip("`")
    parts = raw.split(".")
    forms: List[str] = []
    for n in range(len(parts), 0, -1):
        forms.append(".".join(parts[-n:]))
    # 2026-09-26 (F3 round 3) -- the LOGICAL name of a local table, a
    # materialized view or a federation view.  DuckDB knows them as the
    # views ``__lt__orders`` / ``__mv__orders`` / ``__fv__orders``
    # (core.virtual_ref_rewriter), and until today a policy written on
    # ``orders`` matched NONE of them: the interactive path and every
    # local parquet door read a governed local table unfiltered, under a
    # green status.  The prefixed form stays a candidate too, so a policy
    # authored on the view name keeps matching.
    for prefix in ("__lt__", "__mv__", "__fv__"):
        if parts[-1].startswith(prefix) and len(parts[-1]) > len(prefix):
            forms.append(parts[-1][len(prefix):])
            break
    # Add lower-cased variants for case-insensitive matching
    out: List[str] = []
    seen = set()
    for f in forms:
        for variant in (f, f.lower()):
            if variant not in seen:
                seen.add(variant)
                out.append(variant)
    return out


def table_matches_pattern(table_ref: str, pattern: str) -> bool:
    """True if ``table_ref`` matches ``pattern``.

    Pattern is a glob (``*``, ``?``) over one of the canonical table-ref
    forms.  Matching is case-insensitive.
    """
    if not pattern:
        return False
    pat = pattern.strip().strip('"').strip("`")
    candidates = _normalize_table_ref(table_ref)
    pat_lower = pat.lower()
    for c in candidates:
        if fnmatch.fnmatchcase(c.lower(), pat_lower):
            return True
    return False


# ── Strict-resolution window (2026-07-23 red-team C3) ───────────────────────
#
# Historically a resolver DB failure degraded to "no policies" — enforcement
# then ran UNFILTERED (availability over filtering for an inline, per-user
# query the user could only leak to themselves).  Under a SHAREABLE
# single-flight leader that posture is a cross-user leak vector: the Phase-5
# sandwich proves policy-set STABILITY, not enforcement OUTCOME, so an
# unfiltered blip result would be certified ``share_verified`` and fanned
# out.  The executor's sandwich arms this process-wide window for the
# duration of a shareable leader's execution; inside it a resolver DB
# failure RAISES (fail-closed — the query aborts, which is fail-open to
# CORRECT: a failed query is never wrong data).  Default (window off)
# behavior is byte-for-byte unchanged.

class StrictResolutionError(RuntimeError):
    """Policy resolution failed inside a strict window — the query MUST
    abort rather than run unfiltered."""


# DELIBERATELY PROCESS-GLOBAL (not thread-local / contextvar), and that is a
# SAFETY choice, not an oversight: while a shareable single-flight leader is
# executing, EVERY resolve in the process is strict (a DB failure ABORTS rather
# than silently running unfiltered).  Two reasons it must not be narrowed to the
# leader's thread/context:
#   1. Correctness floor — an inline query that runs unfiltered on a DB blip is
#      ALSO a data exposure (one user vs N), so failing closed process-wide is
#      MORE correct, not merely conservative (this is the row_security.
#      strict_resolution posture the red-team recommended).
#   2. A contextvar/threading.local can MISS the execution context — if the
#      resolve runs in a thread/context that did not inherit the var, strict
#      would silently not apply and the C3 unfiltered-share leak returns.
# The only cost is that a concurrent query may abort on a DB error during the
# (flag-gated, rare) window instead of degrading — which fails SAFE (a failed
# query is never wrong data).  Do NOT scope this to a thread/context.
_strict_lock = threading.Lock()
_strict_depth = 0


def push_strict_resolution() -> None:
    global _strict_depth
    with _strict_lock:
        _strict_depth += 1


def pop_strict_resolution() -> None:
    global _strict_depth
    with _strict_lock:
        _strict_depth = max(0, _strict_depth - 1)


def strict_resolution_active() -> bool:
    with _strict_lock:
        return _strict_depth > 0


# ── Resolver with cache ─────────────────────────────────────────────────────

class PolicyResolver:
    """Resolves policies for a (user, connection, table) triple.

    Cache key is (sorted principal_ids, connection_id, table_ref).  Entries
    expire after ``cache_seconds`` to give policy edits a bounded propagation
    window without paying DB cost on every query.
    """

    def __init__(self, db_manager, cache_seconds: int = 30):
        self._db = db_manager
        self._cache_seconds = max(0, int(cache_seconds))
        self._cache: Dict[Tuple, Tuple[float, Dict[str, List[dict]]]] = {}
        #: (connection_id, table_ref) -> (t, has_any_policy).  Separate from
        #: _cache because it is principal-INDEPENDENT.
        self._any_cache: Dict[Tuple, Tuple[float, bool]] = {}
        #: (connection_id, table_ref) -> (t, (has_any_row_policy, has_permissive)).
        #: FB-45: principal-INDEPENDENT facts about the table that decide the
        #: empty-set case (see core/row_security/composition.py).
        self._class_cache: Dict[Tuple, Tuple[float, Tuple[bool, bool]]] = {}
        self._lock = threading.RLock()

    def invalidate(self) -> None:
        with self._lock:
            self._cache.clear()
            self._any_cache.clear()
            self._class_cache.clear()

    def table_row_policy_classes(self, connection_id: Optional[int],
                                 table_ref: str) -> Tuple[bool, bool]:
        """``(has_any_row_policy, has_permissive_row_policy)`` for
        ``table_ref``, over EVERY principal's bindings.

        FB-45 (2026-09-20).  When a principal matches no row policy, what
        the table CARRIES decides the answer: a table with a permissive
        (grant) policy that this principal does not hold serves NO ROWS; a
        table with only restrictive (ceiling) policies is served
        unrestricted, as before.  Keyed on the classes present, never on
        the configured mode, so flipping the mode moves no unbound
        principal.

        Fails CLOSED on a lookup error: ``(True, True)`` -- "grants may
        exist and we could not check" must not become an unfiltered read.
        Inside a strict window the failure RAISES instead, like resolve().
        """
        key = (connection_id, table_ref)
        now = time.monotonic()
        if self._cache_seconds > 0 and not strict_resolution_active():
            with self._lock:
                hit = self._class_cache.get(key)
                if hit and (now - hit[0]) < self._cache_seconds:
                    return hit[1]
        lookup = getattr(self._db, "find_policies_any_principal", None)
        if not callable(lookup):
            # A store with no principal-independent lookup cannot carry a
            # class at all (every production store is the RowSecurityMixin,
            # which has it; this is a pre-FB-45 stand-in).  Such a store's
            # policies are all legacy, i.e. restrictive: no grants exist.
            logger.debug("row_security: %s has no find_policies_any_principal; "
                         "treating every policy as legacy/restrictive",
                         type(self._db).__name__)
            return False, False
        try:
            pols = lookup(connection_id, "row")
        except Exception as exc:
            if strict_resolution_active():
                raise StrictResolutionError(
                    "policy-class lookup failed under strict mode -- refusing "
                    f"to run unfiltered: {exc}") from exc
            logger.warning(
                "row_security: policy-class lookup failed for %s (%s) -- "
                "treating the table as carrying grants (fail closed)",
                table_ref, exc)
            return True, True
        from core.row_security.composition import PERMISSIVE, effective_class
        matched = [p for p in pols
                   if table_matches_pattern(table_ref, p.get("table_pattern", ""))]
        verdict = (bool(matched),
                   any(effective_class(p) == PERMISSIVE for p in matched))
        if self._cache_seconds > 0:
            with self._lock:
                self._class_cache[key] = (now, verdict)
                if len(self._class_cache) > 4000:
                    self._class_cache.clear()
        return verdict

    def table_has_any_policy(self, connection_id: Optional[int],
                             table_ref: str) -> bool:
        """Does ANY enabled policy target ``table_ref``, for any principal?

        Used only when the principal could not be resolved.  ``True`` means
        the table is governed and an unresolved principal must not read it
        unfiltered; ``False`` means RLS is not configured for this table and
        the query proceeds exactly as before.

        Fails CLOSED: if the lookup itself errors we report True, because
        "we could not check" is not "there is nothing to check".
        """
        key = (connection_id, table_ref)
        now = time.monotonic()
        if self._cache_seconds > 0:
            with self._lock:
                hit = self._any_cache.get(key)
                if hit and (now - hit[0]) < self._cache_seconds:
                    return hit[1]
        try:
            pols = (self._db.find_policies_any_principal(connection_id, "row")
                    + self._db.find_policies_any_principal(connection_id,
                                                           "column"))
        except Exception as exc:
            logger.warning(
                "row_security: policy-existence check failed for %s (%s) -- "
                "treating the table as governed", table_ref, exc)
            return True
        found = any(
            table_matches_pattern(table_ref, p.get("table_pattern", ""))
            for p in pols
        )
        if self._cache_seconds > 0:
            with self._lock:
                self._any_cache[key] = (now, found)
                if len(self._any_cache) > 4000:
                    self._any_cache.clear()
        return found

    def resolve(
        self,
        ctx: UserContext,
        connection_id: Optional[int],
        table_ref: str,
    ) -> Dict[str, List[dict]]:
        """Return ``{"row": [...], "column": [...]}`` policies, ordered by priority."""
        key = (tuple(ctx.principal_ids()), connection_id, table_ref)
        now = time.monotonic()
        # F3 (2026-07-25 red-team, C3 residual): inside a strict window
        # (shareable single-flight leader) the ≤cache_seconds-old cached
        # policy set may PRE-DATE a policy edit made just before enqueue —
        # the leader would then enforce pre-edit policies while the Phase-5
        # sandwich certifies the POST-edit fingerprint, sharing a result
        # the current policies forbid.  The leader must resolve FRESH; the
        # cache is an availability optimisation, never a correctness
        # authority.  Default (window off) behavior is unchanged.
        if self._cache_seconds > 0 and not strict_resolution_active():
            with self._lock:
                hit = self._cache.get(key)
                if hit and (now - hit[0]) < self._cache_seconds:
                    return hit[1]

        lookup_failed = False
        try:
            row_candidates = self._db.find_applicable_policies(
                ctx.principal_ids(), connection_id, "row"
            )
            col_candidates = self._db.find_applicable_policies(
                ctx.principal_ids(), connection_id, "column"
            )
        except Exception as exc:
            # C3 (2026-07-23): inside a strict window (shareable
            # single-flight leader) a DB failure must ABORT the query —
            # never render unfiltered enforcement a sandwich would certify.
            if strict_resolution_active():
                raise StrictResolutionError(
                    "policy resolution failed under strict mode — refusing "
                    f"to run unfiltered: {exc}"
                ) from exc
            logger.warning("row_security resolver DB lookup failed: %s", exc)
            row_candidates, col_candidates = [], []
            lookup_failed = True

        rows = [p for p in row_candidates
                if table_matches_pattern(table_ref, p.get("table_pattern", ""))]
        cols = [p for p in col_candidates
                if table_matches_pattern(table_ref, p.get("table_pattern", ""))]

        result = {"row": rows, "column": cols}
        if (row_candidates or col_candidates) and not lookup_failed:
            # 2026-10-16: a FRESH read found a policy -- tell the cache-scope
            # decision, whose memo may still say "no policies, share one slot"
            # (an edit on another pod); the rewrite and the cache key must not
            # disagree on the same request (core/row_security/cache_scope.py).
            try:
                from core.row_security.cache_scope import note_policies_exist
                note_policies_exist()
            except Exception as exc:                      # never break a resolve
                logger.debug("cache-scope note skipped: %s", exc)
        # C3 — NEVER cache a failed resolve: a transient blip must not
        # poison the cache window with an empty (unfiltered) policy set.
        if self._cache_seconds > 0 and not lookup_failed:
            with self._lock:
                self._cache[key] = (now, result)
                # Bound cache size — drop oldest 25% if it grows past 4000
                if len(self._cache) > 4000:
                    drop = sorted(self._cache.items(), key=lambda kv: kv[1][0])[:1000]
                    for k, _ in drop:
                        self._cache.pop(k, None)
        return result
