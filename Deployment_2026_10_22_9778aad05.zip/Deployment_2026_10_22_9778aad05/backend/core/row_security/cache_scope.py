"""ONE answer to "may this principal share the UNSCOPED cache slot?".

2026-09-26 (F0 of docs/FABLE_BRIEF_2026_09_26.html).  Row security is ON
by default from today.  Four caches had derived a per-principal scope from
``row_security.enabled`` alone -- the /api/execute result cache
(``core.query_cache.rls_user_scope``), the L1/L2 result cache
(``core.query_cache_integration._resolve_user_namespace``), the published
-view paged/bulk slots (``api.published_views.helpers._user_cache_scope``)
and the brain's sql-hash cache (``core.agg_cache.brain_cache_user_scope``).
Measured with the default flipped: every one of them stopped SHARING for
every deployment, including the common one with NO POLICY AUTHORED AT ALL
-- and the brain cache stopped serving outright for any caller it could
not name.  The flag says whether the engine is armed; it says nothing
about whether it would rewrite anything.

The rule, applied by every consumer above
-----------------------------------------
* row security OFF                      -> the legacy, shared key (bytes
  unchanged; nothing is invalidated by switching it off).
* ON, policy store READABLE and EMPTY   -> the SAME shared key.  With no
  enabled row or column policy anywhere the rewriter is a no-op for every
  principal, so every principal's bytes are identical and sharing is safe
  by construction (the theorem ``core/row_security/signature.py`` states).
* ON and any enabled policy exists      -> a PER-PRINCIPAL key that also
  folds :func:`policy_set_marker` -- the content digest of the whole
  policy set (``compute_policy_fingerprint``) -- so a policy edit on ANY
  pod moves every scoped slot within ``row_security.cache_resolver_seconds``,
  not only on the pod whose in-process ``current_policy_version`` bumped.
* ON and the store CANNOT be read       -> fail CLOSED: per-principal, and
  the marker says ``unverified`` so such a slot is disjoint from every slot
  written under a policy set that was read.  Never the shared slot: "could
  not read the policies" is not "there are no policies".

Why "any policy anywhere" and not "a policy on THIS table"
----------------------------------------------------------
Per-table resolution needs the query's table set, which two of the four
caches key BEFORE any SQL exists (a published view's filters, a saved
query id).  The dataset-scoped caches that do know their tables already
key on the RESOLVED predicate (``scope_signature``, the dataset result
cache's ``rls_policy_fingerprint``); this module is the coarse rule for
the ones that do not.  Coarse only ever loses sharing (a cap), never
collides two scopes (the gate).

Memoised on the in-process policy version with the resolver's own TTL, so
it inherits exactly the propagation bound the row-security layer already
declares rather than inventing a second one.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass
from typing import Any, Dict

logger = logging.getLogger(__name__)

__all__ = [
    "PolicySetState",
    "policy_set_state",
    "shared_slot_is_safe",
    "policy_set_marker",
    "reset_policy_set_memo",
    "note_policies_exist",
    "confirm_shared_slot",
]


@dataclass(frozen=True)
class PolicySetState:
    """What the row-security policy store looks like RIGHT NOW."""

    enabled: bool       # row_security.enabled
    readable: bool      # the store answered (lists came back as lists)
    empty: bool         # no ENABLED row or column policy exists (readable only)
    fingerprint: str    # compute_policy_fingerprint(), "" when unreadable
    version: int        # in-process current_policy_version()

    @property
    def shared_slot_is_safe(self) -> bool:
        """May every principal read one unscoped slot?  True when the
        engine is off, or armed over an empty policy set it could read."""
        return (not self.enabled) or (self.readable and self.empty)

    @property
    def marker(self) -> str:
        """The component a SCOPED key folds so a policy edit moves it.

        ``fp:<16 hex>`` names the policy set's content; ``unverified:v<n>``
        says the set could not be read (and still moves on a local edit).
        """
        if self.readable:
            return f"fp:{self.fingerprint[:16]}"
        return f"unverified:v{int(self.version)}"


_memo_lock = threading.Lock()
_memo: Dict[str, Any] = {"key": None, "at": 0.0, "state": None}


def _ttl_seconds() -> float:
    try:
        from core.config import row_security as _rs_cfg
        return float(max(0, int(_rs_cfg.cache_resolver_seconds)))
    except Exception:
        return 30.0


def _enabled() -> bool:
    # Through the module attribute: it is the seam every row-security test
    # pins (``monkeypatch.setattr(core.row_security.api, "_is_enabled", ...)``).
    from core.row_security import api as _rs_api
    return bool(_rs_api._is_enabled())


def _read_store(db: Any, version: int, enabled: bool) -> PolicySetState:
    if not enabled:
        return PolicySetState(enabled=False, readable=True, empty=True,
                              fingerprint="", version=version)
    if db is None:
        return PolicySetState(enabled=True, readable=False, empty=False,
                              fingerprint="", version=version)
    try:
        rows = db.list_row_policies(enabled_only=True)
        cols = db.list_column_policies(enabled_only=True)
        if not isinstance(rows, list) or not isinstance(cols, list):
            raise TypeError(
                f"policy listing answered {type(rows).__name__}/"
                f"{type(cols).__name__}, not lists")
        from core.identity.rls_predicates import compute_policy_fingerprint
        fingerprint = str(compute_policy_fingerprint(db))
    except Exception as exc:
        logger.warning(
            "row_security: policy set UNREADABLE (%s: %s) -- every cache "
            "keys per principal and unverified until it can be read",
            type(exc).__name__, exc)
        return PolicySetState(enabled=True, readable=False, empty=False,
                              fingerprint="", version=version)
    return PolicySetState(enabled=True, readable=True,
                          empty=(not rows and not cols),
                          fingerprint=fingerprint, version=version)


def policy_set_state(db: Any = None) -> PolicySetState:
    """The memoised state.  ``db`` defaults to the manager bound by
    ``core.row_security.set_db_manager`` at startup; ``None`` there is an
    UNREADABLE store, never an empty one."""
    from core.row_security import api as _rs_api
    if db is None:
        db = _rs_api._db_manager
    try:
        version = int(_rs_api.current_policy_version())
    except Exception:
        version = -1
    try:
        enabled = _enabled()
    except Exception:
        # Unreadable config must never silently count as "off".
        enabled = True
    key = (id(db), version, enabled)
    now = time.monotonic()
    with _memo_lock:
        if (_memo["key"] == key and _memo["state"] is not None
                and (now - float(_memo["at"] or 0.0)) < _ttl_seconds()):
            return _memo["state"]
        # 2026-10-07: the SAME key past its TTL, asked ON THE EVENT LOOP (the
        # query routes' cache-key decision): serve the memo while the lane
        # re-reads the store -- three DB reads inline on the loop stalled
        # every request on the pod (measured in-process).  Only the TTL
        # (cross-pod staleness) is stretched, by one read; a changed policy
        # VERSION or binding is a different key and is read right here.
        stale = (_memo["state"] if _memo["key"] == key
                 and _memo["state"] is not None else None)
    if stale is not None and _on_event_loop_thread():
        _refresh_soon(db, version, enabled, key)
        # 2026-10-16 (a CROSS-USER LEAK on the rig's clean release check): a
        # stale "EMPTY -> share" was served past its TTL -- policies created on
        # another pod never move this pod's version, so the old verdict outlived
        # them, every principal got ONE key, and lt_10 read the AFRICA rows lt_01
        # had cached.  Only the CLOSED direction may be served stale: while the
        # store is re-read, key per principal (a cache miss, never a leak).
        if stale.enabled and stale.shared_slot_is_safe:
            return PolicySetState(enabled=True, readable=False, empty=False,
                                  fingerprint="", version=version)
        return stale
    state = _read_store(db, version, enabled)
    with _memo_lock:
        _memo.update({"key": key, "at": now, "state": state})
    return state


_refreshing = threading.Event()


def _on_event_loop_thread() -> bool:
    try:
        import asyncio
        return asyncio._get_running_loop() is not None
    except Exception:
        return False


def _refresh_soon(db: Any, version: int, enabled: bool, key: Any) -> None:
    """Re-read the policy set on the ``config`` lane; one read in flight."""
    with _memo_lock:
        if _refreshing.is_set():
            return
        _refreshing.set()

    def _refresh() -> None:
        try:
            state = _read_store(db, version, enabled)
            with _memo_lock:
                if _memo["key"] == key:      # a newer key may have landed meanwhile
                    _memo.update({"at": time.monotonic(), "state": state})
        finally:
            _refreshing.clear()

    try:
        from core.interactive_lanes import submit_to_lane
        submit_to_lane("config", _refresh)
    except Exception:
        _refreshing.clear()


def note_policies_exist() -> None:
    """The REWRITER just read, fresh from the store, a policy that applies to
    a principal.  If the memo says the set is EMPTY (share one slot), it is
    stale -- another pod created the policy -- and the cache key and the
    rewrite would disagree on the same request: the rewrite filters, the key
    shares, and a FILTERED answer is written where every principal reads
    (2026-10-16, lt_01's AFRICA rows served to lt_10).  Drop the memo so the
    next decision reads the store.  Called by ``PolicyResolver.resolve``."""
    with _memo_lock:
        st = _memo.get("state")
        if st is not None and st.enabled and st.readable and st.empty:
            _memo.update({"key": None, "at": 0.0, "state": None})
            dropped = True
        else:
            dropped = False
    if dropped:
        logger.warning("row_security: the rewriter found a policy while the cache-scope "
                       "memo said the policy set is EMPTY (edited on another pod) -- "
                       "memo dropped, caches key per principal from now")


def confirm_shared_slot(db: Any = None) -> bool:
    """FRESH: may a result be WRITTEN into the unscoped (shared) slot now?

    For a caller that chose its key BEFORE the query ran and writes after it
    (the published-view slots, /api/execute's result cache): the decision at
    key time may predate a policy the query's own rewrite applied.  Reads the
    store (never the memo -- this runs off the event loop, after a query
    already paid for itself) and refreshes the memo with what it read.  Any
    failure answers False: an unconfirmed write is skipped, never shared."""
    try:
        # THE decision, made fresh: drop the memo and ask ``policy_set_state``
        # (off the event loop it reads the store inline and memoises what it
        # read, so the next request on the loop needs no read of its own) --
        # one function answers "is there a policy?", never a second reader.
        reset_policy_set_memo()
        return policy_set_state(db).shared_slot_is_safe
    except Exception as exc:
        logger.warning("row_security: shared-slot write not confirmed (%s) -- skipped", exc)
        return False


def shared_slot_is_safe(db: Any = None) -> bool:
    """May the caller use the legacy UNSCOPED cache key for every
    principal?  Any failure to decide answers False (fail closed)."""
    try:
        return policy_set_state(db).shared_slot_is_safe
    except Exception as exc:
        logger.warning("row_security: cache-scope decision failed (%s) -- "
                       "keying per principal", exc)
        return False


def policy_set_marker(db: Any = None) -> str:
    """The policy-set component every SCOPED key folds; see
    :attr:`PolicySetState.marker`.  Undecidable -> ``unverified``."""
    try:
        return policy_set_state(db).marker
    except Exception:
        return "unverified:v?"


def reset_policy_set_memo() -> None:
    """Drop the memo.  ``core.row_security.api.set_db_manager`` calls it
    when the store is (re)bound; a test that writes policies directly
    (without the admin API's ``invalidate_cache``) calls it to see them at
    once."""
    with _memo_lock:
        _memo.update({"key": None, "at": 0.0, "state": None})
