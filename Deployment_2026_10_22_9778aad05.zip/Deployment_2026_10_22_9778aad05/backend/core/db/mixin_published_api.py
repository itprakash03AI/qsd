"""DatabaseManager mixin -- the published-API numbers and their plumbing
(2026-10-17, core/published_api/): the ingest-health rows each access-log
writer reports, the rollup buckets and their watermark, the alert
thresholds, and the inventory's bulk lookups.  The hot path never calls
anything here: the call row goes through ``log_api_access_many`` (the
batcher's one INSERT); this mixin is what the daemon and the routes read.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class PublishedApiMixin:

    # ── ingest health: one row per access-log writer process ─────────────

    def upsert_published_api_ingest_health(self, row: Dict[str, Any]) -> None:
        """The batcher's minute report: counters since the process started.
        Keyed by (pod, pid); an UPDATE when the row exists."""
        from core.db.models import PublishedApiIngestHealth as H
        with self.get_session() as session:
            cur = (session.query(H).filter(H.pod == str(row["pod"])[:64], H.pid == int(row["pid"]))
                   .first())
            if cur is None:
                cur = H(pod=str(row["pod"])[:64], pid=int(row["pid"]),
                        started_at=row.get("started_at") or _utcnow())
                session.add(cur)
            for k in ("submitted", "written", "batches", "dropped_queue_full", "lost_write_failed", "queued"):
                if k in row:
                    setattr(cur, k, int(row[k] or 0))
            cur.reported_at = row.get("reported_at") or _utcnow()
            session.flush()

    # ── lifecycle (core/published_api/lifecycle.py) ───────────────────────

    def get_published_view_lifecycle(self, slug: str) -> Optional[Dict[str, Any]]:
        """A view's lifecycle row by slug in ANY state (the consumer routes'
        active-only lookup found nothing: is it retired, a draft, or gone?).
        One small SELECT, on the refused path only."""
        from core.db.models import PublishedView as V
        with self.get_session(read_only=True) as session:
            row = (session.query(V.id, V.slug, V.is_active, V.api_lifecycle_status, V.api_sunset_at,
                                 V.api_deprecation_note, V.api_successor, V.api_lifecycle_changed_at)
                   .filter(V.slug == str(slug)).first())
            if row is None:
                return None
            return {"id": int(row[0]), "slug": row[1], "offered": bool(row[2]),
                    "api_lifecycle_status": row[3], "api_sunset_at": row[4],
                    "api_deprecation_note": row[5], "api_successor": row[6],
                    "api_lifecycle_changed_at": row[7]}

    def set_api_lifecycle(self, model, api_id: int, fields: Dict[str, Any], *, offered: bool,
                          set_offered) -> Optional[Dict[str, Any]]:
        """Write the six lifecycle columns and let the kind's own flag follow
        (``set_offered(row, offered)``), in one transaction."""
        with self.get_session() as session:
            row = session.query(model).filter(model.id == int(api_id)).first()
            if row is None:
                return None
            for k, v in fields.items():
                setattr(row, k, v)
            set_offered(row, bool(offered))
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def list_api_lifecycle_sunsets(self, model) -> List[Dict[str, Any]]:
        """Deprecated rows of a kind with a sunset date (the daemon's sweep)."""
        with self.get_session(read_only=True) as session:
            rows = (session.query(model).filter(model.api_lifecycle_status == "deprecated",
                                                model.api_sunset_at.isnot(None)).all())
            return [r.to_dict() for r in rows]

    # ── a key's face ─────────────────────────────────────────────────────

    def update_api_key_identity(self, key_id: int, fields: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        from core.db.models import ApiKey
        with self.get_session() as session:
            row = session.query(ApiKey).filter(ApiKey.id == int(key_id)).first()
            if row is None:
                return None
            for k in ("consumer", "owner_username", "contact_email"):
                if k in fields:
                    v = fields[k]
                    setattr(row, k, (str(v)[:255] if v not in (None, "") else None))
            session.flush()
            session.refresh(row)
            return row.to_dict()

    # ── the rollup (core/published_api/rollup.py) ─────────────────────────

    def get_published_api_rollup_state(self, grain: str) -> Optional[Dict[str, Any]]:
        from core.db.models import PublishedApiRollupState as S
        with self.get_session(read_only=True) as session:
            row = session.query(S).filter(S.grain == str(grain)).first()
            return row.to_dict() if row else None

    def set_published_api_rollup_state(self, grain: str, **fields) -> Dict[str, Any]:
        from core.db.models import PublishedApiRollupState as S
        with self.get_session() as session:
            row = session.query(S).filter(S.grain == str(grain)).first()
            if row is None:
                row = S(grain=str(grain))
                session.add(row)
            for k in ("rolled_through", "last_tick_at", "last_tick_rows", "last_error", "bin_ratio"):
                if k in fields:
                    setattr(row, k, fields[k])
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def oldest_api_access_log_at(self):
        from sqlalchemy import func
        from core.db.models import ApiAccessLog as A
        with self.get_session(read_only=True) as session:
            return session.query(func.min(A.created_at)).scalar()

    def api_access_log_unresolved_slugs(self, start, end) -> List[str]:
        """The slugs of rows in [start, end) that carry no api_id (refusals
        raised before the view was read)."""
        from core.db.models import ApiAccessLog as A
        with self.get_session(read_only=True) as session:
            rows = (session.query(A.api_slug).filter(A.created_at >= start, A.created_at < end,
                                                     A.api_id.is_(None), A.view_id.is_(None),
                                                     A.api_slug.isnot(None)).distinct().all())
            return [str(r[0]) for r in rows if r[0]]

    def iter_api_access_log_rows(self, start, end) -> List[Dict[str, Any]]:
        """The raw rows of one bucket, the columns the fold needs (streamed)."""
        from core.db.models import ApiAccessLog as A
        cols = (A.api_kind, A.api_id, A.view_id, A.api_slug, A.consumer, A.endpoint, A.status_code, A.refusal,
                A.response_rows, A.response_bytes, A.cache_status, A.response_ms, A.created_at)
        names = ("api_kind", "api_id", "view_id", "api_slug", "consumer", "endpoint", "status_code", "refusal",
                 "response_rows", "response_bytes", "cache_status", "response_ms", "created_at")
        out = []
        with self.get_session(read_only=True) as session:
            q = session.query(*cols).filter(A.created_at >= start, A.created_at < end).order_by(A.id)
            for row in q.yield_per(5000):
                out.append(dict(zip(names, row)))
        return out

    def replace_published_api_rollup_bucket(self, grain: str, bucket_start, rows: List[Dict[str, Any]]) -> int:
        """ONE transaction: delete the bucket's rows of this grain, insert the
        new ones.  Idempotent per bucket."""
        from core.db.models import PublishedApiCallRollup as R
        with self.get_session() as session:
            session.query(R).filter(R.grain == str(grain), R.bucket_start == bucket_start).delete(synchronize_session=False)
            for r in rows:
                session.add(R(**r))
            session.flush()
            return len(rows)

    def list_published_api_rollups(self, grain: str, start, end, *, api_kind: Optional[str] = None,
                                   api_id: Optional[int] = None, consumer: Optional[str] = None,
                                   endpoint: Optional[str] = None) -> List[Dict[str, Any]]:
        from core.db.models import PublishedApiCallRollup as R
        with self.get_session(read_only=True) as session:
            q = session.query(R).filter(R.grain == str(grain), R.bucket_start >= start, R.bucket_start < end)
            if api_kind:
                q = q.filter(R.api_kind == str(api_kind))
            if api_id is not None:
                q = q.filter(R.api_id == int(api_id))
            if consumer:
                q = q.filter(R.consumer == str(consumer))
            if endpoint:
                q = q.filter(R.endpoint == str(endpoint))
            return [r.to_dict() for r in q.order_by(R.bucket_start, R.api_kind, R.api_id, R.consumer, R.endpoint).all()]

    def delete_published_api_rollups_before(self, grain: str, before) -> int:
        from core.db.models import PublishedApiCallRollup as R
        with self.get_session() as session:
            return int(session.query(R).filter(R.grain == str(grain), R.bucket_start < before)
                       .delete(synchronize_session=False) or 0)

    def published_api_rollup_numbers(self, grain: str, since) -> List[tuple]:
        """``(api_kind, api_id, MAX(last_call_at), SUM(calls))`` per API over the
        buckets since ``since`` (None = every bucket)."""
        from sqlalchemy import func
        from core.db.models import PublishedApiCallRollup as R
        with self.get_session(read_only=True) as session:
            q = session.query(R.api_kind, R.api_id, func.max(R.last_call_at), func.sum(R.calls)).filter(R.grain == str(grain))
            if since is not None:
                q = q.filter(R.bucket_start >= since)
            return [tuple(r) for r in q.group_by(R.api_kind, R.api_id).all()]

    def count_api_access_log_rows(self, api_kind: str, api_id: int, start, end, *, consumer: Optional[str] = None,
                                  endpoint: Optional[str] = None, api_slug: Optional[str] = None) -> int:
        from core.db.models import ApiAccessLog as A
        with self.get_session(read_only=True) as session:
            q = self._api_rows_query(session, A, api_kind, api_id, start, end, consumer, endpoint, api_slug)
            return int(q.count())

    def api_access_log_latencies(self, api_kind: str, api_id: int, start, end, *, consumer: Optional[str] = None,
                                 endpoint: Optional[str] = None, api_slug: Optional[str] = None) -> List[int]:
        from core.db.models import ApiAccessLog as A
        with self.get_session(read_only=True) as session:
            q = self._api_rows_query(session, A, api_kind, api_id, start, end, consumer, endpoint, api_slug)
            return [int(r[0]) if r[0] is not None else None for r in q.with_entities(A.response_ms).all()]

    @staticmethod
    def _api_rows_query(session, A, api_kind, api_id, start, end, consumer, endpoint, api_slug=None):
        """THE rows of one API in a range -- the same set the rollup folds
        (2026-10-18, found on the rig: exact p50 122 vs SQL 121): a row that
        carries the id; a refusal raised before the definition was read, which
        carries only the SLUG (``api_id`` NULL); and, for a view, a
        pre-2026-10-17 row that carries only ``view_id``.  Every recorded
        answer counts, refusals included -- the consumer waited for a 429 too
        -- so the histogram and the exact path read one set."""
        from sqlalchemy import and_, or_
        q = session.query(A).filter(A.created_at >= start, A.created_at < end)
        legs = [A.api_id == int(api_id)]
        if api_slug:
            legs.append(and_(A.api_id.is_(None), A.api_slug == str(api_slug)))
        if api_kind == "published_view":
            legs.append(and_(A.api_id.is_(None), A.view_id == int(api_id)))
            q = q.filter(or_(*legs))
        else:
            q = q.filter(A.api_kind == str(api_kind), or_(*legs))
        if consumer:
            q = q.filter(A.consumer == str(consumer))
        if endpoint:
            q = q.filter(A.endpoint == str(endpoint))
        return q

    def list_all_published_api_ingest_health(self) -> List[Dict[str, Any]]:
        """Every writer process's row, whatever its age -- the generic silence
        rule (core/published_api/ingest_health.py) decides live / down / retired."""
        from core.db.models import PublishedApiIngestHealth as H
        with self.get_session(read_only=True) as session:
            return [r.to_dict() for r in session.query(H).order_by(H.pod, H.pid).all()]

    def delete_published_api_ingest_health_row(self, pod: str, pid: int) -> int:
        """Drop ONE writer process's row (retired by the rule: superseded on
        its pod, or silent past the retire window)."""
        from core.db.models import PublishedApiIngestHealth as H
        with self.get_session() as session:
            return int(session.query(H).filter(H.pod == str(pod), H.pid == int(pid))
                       .delete(synchronize_session=False) or 0)

    def list_published_api_ingest_health(self, since_seconds: int = 300) -> List[Dict[str, Any]]:
        """Every writer process that reported within ``since_seconds``, and
        every one that stopped reporting (``stale`` = True) in the last day."""
        from core.db.models import PublishedApiIngestHealth as H
        now = _utcnow()
        cutoff = now - timedelta(seconds=int(since_seconds))
        day = now - timedelta(days=1)
        with self.get_session(read_only=True) as session:
            rows = session.query(H).filter(H.reported_at >= day).order_by(H.pod, H.pid).all()
            out = []
            for r in rows:
                d = r.to_dict()
                rep = r.reported_at
                if rep is not None and rep.tzinfo is None:
                    rep = rep.replace(tzinfo=timezone.utc)
                d["stale"] = rep is None or rep < cutoff
                out.append(d)
            return out

    # ── alerts (core/published_api/alerts.py): thresholds, verdicts, seeds ──

    def seed_published_api_alerting(self) -> Dict[str, int]:
        """The six API alert kinds MISSING BY NAME from ``feed_alert_kinds``
        (a non-empty table gets them; an edited row is never touched), with
        the configured AlertGroup; the default thresholds into an EMPTY
        thresholds table.  Idempotent; run at init."""
        from core.db.models import FeedAlertKind as K, PublishedApiAlertThreshold as T
        from core.published_api.alerts import ALERT_KINDS, DEFAULT_THRESHOLDS, SCOPE_GLOBAL, alert_group
        grp = alert_group()
        out = {"kinds": 0, "thresholds": 0}
        # the kinds ride THE one insert-missing-by-name seeder (mixin_feeds.
        # seed_missing_feed_alert_kinds, 2026-10-17); the thresholds are this
        # area's own table
        out["kinds"] = self.seed_missing_feed_alert_kinds(
            [dict(row, alert_group=grp) for row in ALERT_KINDS])
        with self.get_session() as session:
            if session.query(T.id).first() is None:
                for t in DEFAULT_THRESHOLDS:
                    session.add(T(**t, scope=SCOPE_GLOBAL, api_kind="", scope_key="", is_active=True,
                                  created_by="seed", updated_by="seed"))
                    out["thresholds"] += 1
            session.flush()
        return out

    def list_published_api_alert_thresholds(self, active_only: bool = False) -> List[Dict[str, Any]]:
        from core.db.models import PublishedApiAlertThreshold as T
        with self.get_session(read_only=True) as session:
            q = session.query(T)
            if active_only:
                q = q.filter(T.is_active == True)  # noqa: E712
            return [t.to_dict() for t in q.order_by(T.scope, T.api_kind, T.scope_key, T.metric, T.id).all()]

    def get_published_api_alert_threshold(self, threshold_id: int) -> Optional[Dict[str, Any]]:
        from core.db.models import PublishedApiAlertThreshold as T
        with self.get_session(read_only=True) as session:
            row = session.query(T).filter(T.id == int(threshold_id)).first()
            return None if row is None else row.to_dict()

    _THRESHOLD_FIELDS = ("name", "scope", "api_kind", "scope_key", "metric", "operator", "value", "window_minutes",
                         "min_calls", "clear_after_windows", "alert_kind", "is_active")

    def create_published_api_alert_threshold(self, data: Dict[str, Any], user: Optional[str] = None) -> Dict[str, Any]:
        """A new threshold row; a duplicate (scope, api_kind, scope_key, metric,
        name) is refused with ``ValueError`` naming the existing row."""
        from core.db.models import PublishedApiAlertThreshold as T
        with self.get_session() as session:
            dup = (session.query(T).filter(T.scope == data["scope"], T.api_kind == (data.get("api_kind") or ""),
                                           T.scope_key == (data.get("scope_key") or ""), T.metric == data["metric"],
                                           T.name == data["name"]).first())
            if dup is not None:
                raise ValueError(f"threshold #{dup.id} already has this scope, metric and name")
            row = T(**{k: data[k] for k in self._THRESHOLD_FIELDS if k in data},
                    created_by=user, updated_by=user)
            row.api_kind = row.api_kind or ""
            row.scope_key = row.scope_key or ""
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def update_published_api_alert_threshold(self, threshold_id: int, fields: Dict[str, Any],
                                             user: Optional[str] = None) -> Optional[Dict[str, Any]]:
        from core.db.models import PublishedApiAlertThreshold as T
        with self.get_session() as session:
            row = session.query(T).filter(T.id == int(threshold_id)).first()
            if row is None:
                return None
            for k in self._THRESHOLD_FIELDS:
                if k in fields:
                    setattr(row, k, fields[k])
            row.api_kind = row.api_kind or ""
            row.scope_key = row.scope_key or ""
            row.updated_by, row.updated_at = user, _utcnow()
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def delete_published_api_alert_threshold(self, threshold_id: int) -> bool:
        """The row and every verdict about it (the open alerts are cleared by
        the next tick's out-of-scope rule)."""
        from core.db.models import PublishedApiAlertState as S, PublishedApiAlertThreshold as T
        with self.get_session() as session:
            session.query(S).filter(S.threshold_id == int(threshold_id)).delete(synchronize_session=False)
            return bool(session.query(T).filter(T.id == int(threshold_id)).delete(synchronize_session=False))

    def list_published_api_alert_states(self, *, threshold_id: Optional[int] = None, api_kind: Optional[str] = None,
                                        api_id: Optional[int] = None) -> List[Dict[str, Any]]:
        from core.db.models import PublishedApiAlertState as S
        with self.get_session(read_only=True) as session:
            q = session.query(S)
            if threshold_id is not None:
                q = q.filter(S.threshold_id == int(threshold_id))
            if api_kind:
                q = q.filter(S.api_kind == str(api_kind))
            if api_id is not None:
                q = q.filter(S.api_id == int(api_id))
            return [s.to_dict() for s in q.order_by(S.threshold_id, S.api_kind, S.api_id).all()]

    def upsert_published_api_alert_state(self, row: Dict[str, Any]) -> None:
        from core.db.models import PublishedApiAlertState as S
        with self.get_session() as session:
            cur = (session.query(S).filter(S.threshold_id == int(row["threshold_id"]), S.api_kind == str(row["api_kind"]),
                                           S.api_id == int(row["api_id"])).first())
            if cur is None:
                cur = S(threshold_id=int(row["threshold_id"]), api_kind=str(row["api_kind"]), api_id=int(row["api_id"]))
                session.add(cur)
            for k in ("api_slug", "state", "value", "calls", "detail", "alert_id", "dedupe_key"):
                if k in row:
                    setattr(cur, k, row[k])
            for k in ("healthy_since", "breached_since", "evaluated_at"):
                if k in row:
                    v = row[k]
                    if isinstance(v, datetime) and v.tzinfo is not None:
                        v = v.astimezone(timezone.utc).replace(tzinfo=None)
                    setattr(cur, k, v)
            session.flush()

    def delete_published_api_alert_state(self, threshold_id: int, api_kind: str, api_id: int) -> bool:
        from core.db.models import PublishedApiAlertState as S
        with self.get_session() as session:
            return bool(session.query(S).filter(S.threshold_id == int(threshold_id), S.api_kind == str(api_kind),
                                                S.api_id == int(api_id)).delete(synchronize_session=False))
