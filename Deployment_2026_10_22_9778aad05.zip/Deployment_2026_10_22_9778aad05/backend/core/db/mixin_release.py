"""DatabaseManager mixin -- the configuration release header, the environment
mapping, and the ledger questions the release engine asks (2026-10-17,
core/release/engine.py).  The APPLY itself runs inside one session the
engine opens (``get_session()``), so every object and every ledger row land
together or not at all; this mixin is the bookkeeping around it.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class ReleaseMixin:

    # ── releases ────────────────────────────────────────────────────────
    def create_config_release(self, data: dict) -> dict:
        from core.db.models import ConfigRelease
        with self.get_session() as session:
            row = ConfigRelease(**data)
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict(with_package=True)

    def get_config_release(self, release_id: int, *, with_package: bool = False) -> Optional[dict]:
        from core.db.models import ConfigRelease
        with self.get_session(read_only=True) as session:
            row = session.query(ConfigRelease).filter(ConfigRelease.id == int(release_id)).first()
            return row.to_dict(with_package=with_package) if row else None

    def list_config_releases(self, environment: Optional[str] = None, limit: int = 100) -> List[dict]:
        from core.db.models import ConfigRelease
        with self.get_session(read_only=True) as session:
            q = session.query(ConfigRelease)
            if environment:
                q = q.filter(ConfigRelease.environment == str(environment))
            rows = q.order_by(ConfigRelease.id.desc()).limit(int(limit)).all()
            return [r.to_dict() for r in rows]

    def update_config_release(self, release_id: int, data: dict) -> Optional[dict]:
        from core.db.models import ConfigRelease
        with self.get_session() as session:
            row = session.query(ConfigRelease).filter(ConfigRelease.id == int(release_id)).first()
            if row is None:
                return None
            for k, v in data.items():
                if hasattr(row, k) and k != "id":
                    setattr(row, k, v)
            session.flush()
            session.refresh(row)
            return row.to_dict(with_package=True)

    # ── mappings ────────────────────────────────────────────────────────
    def list_release_mappings(self, environment: str) -> List[dict]:
        from core.db.models import ReleaseMapping
        with self.get_session(read_only=True) as session:
            rows = (session.query(ReleaseMapping)
                    .filter(ReleaseMapping.environment == str(environment))
                    .order_by(ReleaseMapping.kind, ReleaseMapping.from_value).all())
            return [r.to_dict() for r in rows]

    def upsert_release_mappings(self, environment: str, rows: List[dict],
                                created_by: Optional[str] = None) -> List[dict]:
        """Idempotent on (environment, kind, from_value); an empty ``to_value``
        DELETES the row (an unmapped value is honest, a blank target is not)."""
        from core.db.models import ReleaseMapping
        out: List[dict] = []
        with self.get_session() as session:
            for r in rows:
                kind, frm = str(r.get("kind") or "").strip(), str(r.get("from_value") or "").strip()
                if not kind or not frm:
                    raise ValueError("a mapping needs a kind and a from_value")
                to = r.get("to_value")
                row = (session.query(ReleaseMapping)
                       .filter(ReleaseMapping.environment == str(environment),
                               ReleaseMapping.kind == kind, ReleaseMapping.from_value == frm).first())
                if to in (None, ""):
                    if row is not None:
                        session.delete(row)
                    continue
                if row is None:
                    row = ReleaseMapping(environment=str(environment), kind=kind, from_value=frm,
                                         to_value=str(to), note=r.get("note"), created_by=created_by)
                    session.add(row)
                else:
                    row.to_value, row.note = str(to), r.get("note")
                    row.updated_at = datetime.now(timezone.utc)
                session.flush()
                out.append(row.to_dict())
        return out

    # ── ledger questions ────────────────────────────────────────────────
    def latest_deployment_by_key(self, environment: str) -> Dict[tuple, dict]:
        """``{(object_type, name): newest ledger row}`` -- the BASE of the
        three-way diff.  ``kept_prod`` / ``unchanged`` rows carry the
        definition the release left in force, so they count."""
        from core.db.models import ConfigDeployment
        with self.get_session(read_only=True) as session:
            rows = (session.query(ConfigDeployment)
                    .filter(ConfigDeployment.environment == str(environment))
                    .order_by(ConfigDeployment.id.desc()).all())
        latest: Dict[tuple, dict] = {}
        for row in rows:
            k = (row.object_type, row.name)
            if k not in latest:
                latest[k] = row.to_dict()
        return latest

    def list_release_ledger(self, release_id: int) -> List[dict]:
        from core.db.models import ConfigDeployment
        with self.get_session(read_only=True) as session:
            rows = (session.query(ConfigDeployment)
                    .filter(ConfigDeployment.release_id == int(release_id))
                    .order_by(ConfigDeployment.id).all())
            return [r.to_dict() for r in rows]

    def get_governed_object(self, object_type: str, object_id: Any) -> Optional[dict]:
        """A governed object's row as a dict, through the release registry
        (2026-10-17: every registered kind, not only ``feed``)."""
        from core.release.registry import load
        rtype = load().get(str(object_type))
        if rtype is None or object_id in (None, ""):
            return None
        with self.get_session(read_only=True) as session:
            row = session.query(rtype.model).filter(rtype.model.id == int(object_id)).first()
            if row is None:
                return None
            d = {c.name: getattr(row, c.name) for c in rtype.model.__table__.columns}
            d.setdefault("name", rtype.row_key(row))
            return d

    def list_governed_objects(self, object_type: str) -> List[dict]:
        from core.release.registry import load
        rtype = load().get(str(object_type))
        if rtype is None:
            return []
        with self.get_session(read_only=True) as session:
            out = []
            for row in rtype.rows(session):
                d = {c.name: getattr(row, c.name) for c in rtype.model.__table__.columns}
                d.setdefault("name", rtype.row_key(row))
                out.append(d)
            return out
