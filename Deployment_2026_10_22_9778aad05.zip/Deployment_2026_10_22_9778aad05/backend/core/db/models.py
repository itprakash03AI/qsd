"""
Database models for query storage and download management
Using SQLAlchemy ORM with SQLite
"""

from sqlalchemy import Column, Integer, BigInteger, String, DateTime, Date, Text, Boolean, JSON, Float, Numeric, Index, UniqueConstraint, ForeignKey, LargeBinary, text as sa_text, false as sa_false, true as sa_true
from sqlalchemy.orm import declarative_base, deferred
from core.secrets_at_rest import SecretJSON
from core.table_prefix import CanonicalPrefixMixin
from datetime import datetime, timezone
from typing import Optional, Dict, Any
import json

Base = declarative_base()


def _mask_proxy_url(url):
    """BF-519 (2026-05-28): lazy local wrapper around
    ``core.url_safety.mask_url_credentials`` so models.py doesn't pull
    in url_safety at import time (would create a cycle for code that
    imports models from inside url_safety in future).  Falls back to
    leaving the value unmasked on any import error so the schema
    endpoint never crashes — the masker is a UX improvement, not a
    security boundary (the real defense is not logging proxy_url
    elsewhere).
    """
    if not url:
        return url
    try:
        from core.url_safety import mask_url_credentials
        return mask_url_credentials(url)
    except Exception:
        # Absolute fallback: if the masker breaks, redact the whole
        # field rather than expose plaintext.
        return "***redacted***"


class SavedQuery(Base):
    """Model for saved queries"""
    __tablename__ = "saved_queries"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, index=True)
    description = Column(Text, nullable=True)
    query_config = Column(JSON, nullable=False)  # Stores QueryConfig as JSON
    created_by = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    is_active = Column(Boolean, default=True)
    is_favorite = Column(Boolean, default=False)
    is_shared = Column(Boolean, default=False)
    execution_count = Column(Integer, default=0)
    last_executed_at = Column(DateTime, nullable=True)
    workspace_id = Column(Integer, nullable=True, index=True)
    folder = Column(String(200), nullable=True, index=True)   # Phase 65: folder path
    tags = Column(JSON, nullable=True)                         # Phase 65: ["tag1", "tag2"]
    param_definitions = Column(JSON, nullable=True)            # Phase 86: List[ParamDef dicts]
    # 2026-10-17 -- the configuration-release identity of a row whose NAME is
    # not unique (core/release/types/reports.py): minted on first export,
    # carried in the package, stored in the target.  In _MIGRATIONS too.
    release_key = Column(String(160), nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary"""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "query_config": self.query_config,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "is_active": self.is_active,
            "is_favorite": self.is_favorite or False,
            "is_shared": self.is_shared or False,
            "execution_count": self.execution_count,
            "last_executed_at": self.last_executed_at.isoformat() if self.last_executed_at else None,
            "workspace_id": self.workspace_id,
            "folder": self.folder,
            "tags": self.tags or [],
            "param_definitions": self.param_definitions or [],
        }


class QueryExecution(Base):
    """Model for tracking query executions"""
    __tablename__ = "query_executions"
    
    id = Column(Integer, primary_key=True, index=True)
    query_id = Column(Integer, nullable=True)  # Reference to SavedQuery if applicable
    execution_id = Column(String(100), unique=True, nullable=False, index=True)
    query_config = Column(JSON, nullable=False)
    status = Column(String(50), default="pending")  # pending, processing, completed, failed
    started_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    completed_at = Column(DateTime, nullable=True)
    total_rows = Column(BigInteger, default=0)
    chunks_processed = Column(Integer, default=0)
    output_file = Column(String(500), nullable=True)
    file_size_bytes = Column(BigInteger, default=0)
    error_message = Column(Text, nullable=True)
    executed_by = Column(String(100), nullable=True)
    files_metadata = Column(JSON, nullable=True)  # File scan info: {table: {total, after_pruning, format, total_possible_rows}}
    # 2026-08-02 multi-pod correctness: durable cross-pod cancel request.
    # Set when a cancel API call lands on a pod that does NOT hold the
    # running task (multi-pod routing) — every pod's cancel watcher polls
    # this flag and the OWNING pod signals its local task.  Also makes the
    # terminal 'cancelled' status sticky against a late 'completed'/'failed'
    # write from the pod that kept running the query (see
    # DatabaseManager.update_execution).  Nullable + additive — NULL means
    # "no cross-pod cancel requested" (all pre-change rows / the N=1
    # local-hit fast path, which is byte-identical to before).
    cancel_requested = Column(Boolean, nullable=True, default=None)
    # 2026-09-27 -- WHICH ENGINE ANSWERED (core/engine_attribution.py keys:
    # duckdb / multi_worker / spark_connect / result_cache / trino / oracle
    # ...).  NULL = not recorded (rows written before the column, and paths
    # that stamp nothing) -- rendered as "not recorded", never as a default.
    # A new COLUMN does not self-create: see _MIGRATIONS["query_executions"].
    engine = Column(String(32), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary"""
        from core.engine_attribution import engine_label as _engine_label
        _fm = self.files_metadata
        if isinstance(_fm, str):
            try:
                import json as _json
                _fm = _json.loads(_fm)
            except Exception:
                _fm = None
        # Computed wall-clock duration — surfaces total query time to the
        # perf chip even when files_metadata.stage_history wasn't captured
        # (e.g. streaming path before stream_observability instrumentation).
        _dur: Optional[float] = None
        try:
            if self.completed_at and self.started_at:
                _dur = (self.completed_at - self.started_at).total_seconds()
        except Exception:
            _dur = None
        return {
            "id": self.id,
            "query_id": self.query_id,
            "execution_id": self.execution_id,
            "query_config": self.query_config,
            "status": self.status,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "duration_seconds": _dur,
            "total_rows": self.total_rows,
            "chunks_processed": self.chunks_processed,
            "output_file": self.output_file,
            "file_size_bytes": self.file_size_bytes,
            "error_message": self.error_message,
            "executed_by": self.executed_by,
            "files_metadata": _fm,
            "engine": self.engine,
            "engine_label": _engine_label(self.engine),
        }


class AuditLog(Base):
    """Immutable audit trail — who did what, when, from where."""
    __tablename__ = "audit_log"

    id            = Column(Integer, primary_key=True, index=True)
    timestamp     = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    username      = Column(String(100), nullable=False, index=True)
    action        = Column(String(100), nullable=False, index=True)  # execute_query, cancel_query, save_query…
    resource_type = Column(String(50),  nullable=True)               # query, execution, dashboard, connection
    resource_id   = Column(String(200), nullable=True)
    ip_address    = Column(String(50),  nullable=True)
    user_agent    = Column(String(500), nullable=True)
    details       = Column(JSON, nullable=True)                      # arbitrary extra context

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":            self.id,
            "timestamp":     self.timestamp.isoformat() if self.timestamp else None,
            "username":      self.username,
            "action":        self.action,
            "resource_type": self.resource_type,
            "resource_id":   self.resource_id,
            "ip_address":    self.ip_address,
            "details":       self.details,
        }


class DownloadFile(Base):
    """Model for tracking downloadable files"""
    __tablename__ = "download_files"
    
    id = Column(Integer, primary_key=True, index=True)
    file_id = Column(String(100), unique=True, nullable=False, index=True)
    execution_id = Column(String(100), nullable=True, index=True)
    filename = Column(String(255), nullable=False)
    file_path = Column(String(500), nullable=False)
    file_size_bytes = Column(BigInteger, default=0)
    status = Column(String(50), default="available")  # available, downloaded, expired, deleted
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at = Column(DateTime, nullable=True)
    download_count = Column(Integer, default=0)
    last_downloaded_at = Column(DateTime, nullable=True)
    created_by = Column(String(100), nullable=True)
    # 2026-08-30 — entitlement-aware sharing.  A download is a MATERIALISED
    # file filtered for ONE principal, so group sharing needs both the
    # source it came from (whose own read check honours group grants) and
    # the row-security scope it was generated under.  All three nullable:
    # an unstamped row is simply not shareable (creator-only, as before).
    source_kind = Column(String(40), nullable=True)
    source_id = Column(String(64), nullable=True)
    # The dataset the signature was resolved AGAINST, as a string so ""
    # can mean "global scope" (a report with no dataset) distinctly from
    # NULL = "not stamped".  Re-deriving it from the live report at read
    # time would drift: a consumer stamps from the published SNAPSHOT, and
    # a report can be repointed at another dataset after the export.
    source_dataset_id = Column(String(32), nullable=True)
    rls_signature = Column(String(80), nullable=True)
    # 2026-09-03 — FR-DEL-10.  A feed deliverable registered in the
    # Download Centre must carry the facts a counterparty asks about
    # when they query a file: WHICH business date it covers, WHICH build
    # produced it, and the checksum they were given to verify it with.
    # These were written by ``core.feed.archive.feed_download_registration``
    # from day one and DROPPED at the seam, because the columns did not
    # exist — the registration logged them as "pending schema" and moved
    # on.  All nullable: every non-feed download (report exports, query
    # results) leaves them NULL, which is what "not a dated artifact"
    # means, distinctly from an empty string.
    checksum = Column(String(128), nullable=True)
    checksum_algorithm = Column(String(32), nullable=True)
    business_date = Column(String(10), nullable=True, index=True)
    build_id = Column(String(100), nullable=True, index=True)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary"""
        return {
            "id": self.id,
            "file_id": self.file_id,
            "execution_id": self.execution_id,
            "filename": self.filename,
            "file_path": self.file_path,
            "file_size_bytes": self.file_size_bytes,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "download_count": self.download_count,
            "last_downloaded_at": self.last_downloaded_at.isoformat() if self.last_downloaded_at else None,
            "checksum": self.checksum,
            "checksum_algorithm": self.checksum_algorithm,
            "business_date": self.business_date,
            "build_id": self.build_id,
            "created_by": self.created_by,
            "source_kind": self.source_kind,
            "source_id": self.source_id,
            "source_dataset_id": self.source_dataset_id,
            "rls_signature": self.rls_signature,
        }


class SqlSavedQuery(Base):
    """Model for SQL queries executed against SQL connectors (Trino, Snowflake, Databricks)."""
    __tablename__ = "sql_saved_queries"

    id                     = Column(Integer,     primary_key=True, index=True)
    name                   = Column(String(255), nullable=False,   index=True)
    description            = Column(Text,        nullable=True)
    # Primary source
    primary_connection_id  = Column(Integer,     nullable=False)
    primary_sql            = Column(Text,        nullable=False)
    # Optional secondary source for cross-source joins
    secondary_connection_id = Column(Integer,    nullable=True)
    secondary_sql          = Column(Text,        nullable=True)
    # Join config: { how, left_on, right_on, suffixes }
    join_config            = Column(JSON,        nullable=True)
    # 2026-10-04: "join" | "union" | NULL (= join, the page's only mode before)
    combine_mode           = Column(String(20),  nullable=True)
    # Metadata
    created_by             = Column(String(100), nullable=True)
    created_at             = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at             = Column(DateTime,    default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    is_active              = Column(Boolean,     default=True)
    is_shared              = Column(Boolean,     default=False)
    execution_count        = Column(Integer,     default=0)
    last_executed_at       = Column(DateTime,    nullable=True)
    workspace_id           = Column(Integer,     nullable=True, index=True)
    # 2026-10-17 -- configuration-release identity (see SavedQuery.release_key)
    release_key            = Column(String(160), nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                      self.id,
            "name":                    self.name,
            "description":             self.description,
            "primary_connection_id":   self.primary_connection_id,
            "primary_sql":             self.primary_sql,
            "secondary_connection_id": self.secondary_connection_id,
            "secondary_sql":           self.secondary_sql,
            "join_config":             self.join_config,
            "combine_mode":            self.combine_mode,
            "created_by":              self.created_by,
            "created_at":              self.created_at.isoformat()  if self.created_at  else None,
            "updated_at":              self.updated_at.isoformat()  if self.updated_at  else None,
            "is_active":               self.is_active,
            "is_shared":               self.is_shared or False,
            "execution_count":         self.execution_count,
            "last_executed_at":        self.last_executed_at.isoformat() if self.last_executed_at else None,
            "workspace_id":            self.workspace_id,
        }


class SqlFile(Base):
    """Phase 122C: A .sql file stored on NFS, optionally linked to a connection."""
    __tablename__ = "sql_files"

    id              = Column(Integer,     primary_key=True, index=True)
    name            = Column(String(255), nullable=False,   index=True)
    description     = Column(Text,        nullable=True)
    file_path       = Column(String(500), nullable=False,   unique=True)
    connection_id   = Column(Integer,     nullable=True,    index=True)
    # Phase 124-B: Cross-connection support
    secondary_connection_id = Column(Integer, nullable=True, index=True)
    combine_mode    = Column(String(20),  nullable=True)    # "union" | "join" | null
    join_config     = Column(JSON,        nullable=True)    # {"how": "inner", "left_on": [...], "right_on": [...]}
    version         = Column(Integer,     default=1)
    content_hash    = Column(String(64),  nullable=True)
    file_size       = Column(Integer,     default=0)
    is_shared       = Column(Boolean,     default=False)
    is_active       = Column(Boolean,     default=True)
    tags            = Column(JSON,        nullable=True)
    created_by      = Column(String(100), nullable=True)
    created_at      = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime,    default=lambda: datetime.now(timezone.utc),
                             onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":              self.id,
            "name":            self.name,
            "description":     self.description,
            "file_path":       self.file_path,
            "connection_id":   self.connection_id,
            "secondary_connection_id": self.secondary_connection_id,
            "combine_mode":    self.combine_mode,
            "join_config":     self.join_config,
            "version":         self.version,
            "content_hash":    self.content_hash,
            "file_size":       self.file_size,
            "is_shared":       self.is_shared or False,
            "is_active":       self.is_active,
            "tags":            self.tags,
            "created_by":      self.created_by,
            "created_at":      self.created_at.isoformat()  if self.created_at  else None,
            "updated_at":      self.updated_at.isoformat()  if self.updated_at  else None,
        }


class Connection(Base):
    """Model for data source connections"""
    __tablename__ = "connections"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False, unique=True, index=True)
    connection_type = Column(String(50), nullable=False)
    config = Column(JSON, nullable=False)   # sensitive fields stored encrypted
    is_active = Column(Boolean, default=True)
    is_shared = Column(Boolean, default=False)  # shared with all users
    created_by = Column(String(100), nullable=True)
    last_tested_at = Column(DateTime, nullable=True)
    last_test_status = Column(String(50), nullable=True)  # 'success' or 'failed'
    last_test_message = Column(Text, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    workspace_id = Column(Integer, nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary (config may contain encrypted values)."""
        return {
            "id": self.id,
            "name": self.name,
            "connection_type": self.connection_type,
            "config": self.config,
            "is_active": self.is_active,
            "is_shared": self.is_shared or False,
            "created_by": self.created_by,
            "last_tested_at": self.last_tested_at.isoformat() if self.last_tested_at else None,
            "last_test_status": self.last_test_status,
            "last_test_message": self.last_test_message,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "workspace_id": self.workspace_id,
        }


class ConnectionAccess(Base):
    """Phase 102-E — per-connection access grants (ACLs).

    Adds granular per-user / per-role access control beyond the existing
    owner + is_shared model. Each row grants a single user or role a single
    permission level on a single connection.
    """
    __tablename__ = "connection_access"

    id            = Column(Integer, primary_key=True, index=True)
    connection_id = Column(Integer, nullable=False, index=True)
    grant_type    = Column(String(20), nullable=False)   # "user" | "role"
    grantee       = Column(String(100), nullable=False, index=True)
    permission    = Column(String(20), default="read")   # "read" | "execute" | "manage"
    created_by    = Column(String(100), nullable=True)
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "connection_id": self.connection_id,
            "grant_type": self.grant_type,
            "grantee": self.grantee,
            "permission": self.permission,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class Report(Base):
    """DECOMMISSIONED (FB-60, 2026-09-26) — the legacy parametric report.

    NOTHING in the product reads or writes this table any more; it is kept
    declared because ``create_all`` never drops and the rows belong to the
    operator: ``backend/migrate_reports.py`` turns each one into a finance
    report (``business_reports.data_source_type='raw_sql'``, keyed back by
    ``legacy_report_id``) or exports them, and ``core.reports.legacy_parametric``
    reports the unmigrated count at startup.  Drop the table only after
    ``migrate_reports.py --status`` shows 0 active unmigrated rows.  A guard
    (``tests/test_parametric_reports_decommissioned_2026_09_26.py``) fails
    the build if a production reference to this class reappears.
    """
    __tablename__ = "reports"

    id                 = Column(Integer,     primary_key=True, index=True)
    name               = Column(String(255), nullable=False,   index=True)
    description        = Column(Text,        nullable=True)

    # Exactly one source is set
    saved_query_id     = Column(Integer, nullable=True)        # → SavedQuery (parquet)
    sql_saved_query_id = Column(Integer, nullable=True)        # → SqlSavedQuery

    # Parameter schema: [{ name, label, type, required, default_value, description }]
    # type: string | number | date | boolean | select
    # If type == select, include options: ["val1", "val2", ...]
    parameters         = Column(JSON, nullable=False, default=list)

    # Optional SQL override (replaces source query's SQL at execution time)
    sql_override       = Column(Text, nullable=True)

    is_active          = Column(Boolean,     default=True)
    is_public          = Column(Boolean,     default=True)
    created_by         = Column(String(100), nullable=True)
    created_at         = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at         = Column(DateTime,    default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    execution_count    = Column(Integer,     default=0)
    last_executed_at   = Column(DateTime,    nullable=True)

    # Enterprise features
    cache_ttl_minutes      = Column(Integer,  default=0)          # 0 = no caching
    schedule_config        = Column(JSON,     nullable=True)      # { cron, recipients, format, enabled }

    # Phase 24A — optional direct connection override (SQL reports only)
    connection_override_id = Column(Integer,  nullable=True)      # → Connection.id; NULL = use query's default
    workspace_id           = Column(Integer,  nullable=True, index=True)
    # Phase 130 hotfix-13: entitlement group ownership.  When set, the
    # group's members can view (always) or edit (when their
    # resource_access_level='read_write') this report — same semantics
    # as feed_configs.owner_group_id.
    owner_group_id         = Column(Integer,  nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                      self.id,
            "name":                    self.name,
            "description":             self.description,
            "saved_query_id":          self.saved_query_id,
            "sql_saved_query_id":      self.sql_saved_query_id,
            "parameters":              self.parameters or [],
            "sql_override":            self.sql_override,
            "is_active":               self.is_active,
            "is_public":               self.is_public,
            "created_by":              self.created_by,
            "created_at":              self.created_at.isoformat()  if self.created_at  else None,
            "updated_at":              self.updated_at.isoformat()  if self.updated_at  else None,
            "execution_count":         self.execution_count,
            "last_executed_at":        self.last_executed_at.isoformat() if self.last_executed_at else None,
            "cache_ttl_minutes":       self.cache_ttl_minutes or 0,
            "schedule_config":         self.schedule_config,
            "connection_override_id":  self.connection_override_id,
            "workspace_id":            self.workspace_id,
            "owner_group_id":          self.owner_group_id,
        }


class LegacyReportMigrationJournal(Base):
    """What ``migrate_reports.py --execute`` MOVED, row by row (2026-09-26).

    Rollback moves back exactly these rows and nothing else.  Keying
    rollback on ``report_id = new_id`` would also move a row a user wrote
    against the finance report AFTER the migration (same number, honest
    owner) back onto the legacy id.  ``was_type`` is the discriminator value
    the row carried before the move (``parametric`` on the discriminated
    tables, NULL on the id-keyed ones, ``report`` on schedules /
    subscriptions / dashboard tiles) so rollback restores it verbatim.
    """
    __tablename__ = "legacy_report_migration_journal"

    id                 = Column(Integer, primary_key=True, autoincrement=True)
    legacy_report_id   = Column(Integer, nullable=False, index=True)
    business_report_id = Column(Integer, nullable=False, index=True)
    table_name         = Column(String(64), nullable=False)
    row_id             = Column(Integer, nullable=False)
    was_type           = Column(String(20), nullable=True)
    migrated_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class Schedule(Base):
    """Scheduled automatic query/report execution → downloads directory."""
    __tablename__ = "schedules"

    id              = Column(Integer,     primary_key=True, index=True)
    name            = Column(String(255), nullable=False,   index=True)
    description     = Column(Text,        nullable=True)
    is_active       = Column(Boolean,     default=True)
    is_shared       = Column(Boolean,     default=False)

    # Source type: "saved_query" | "sql_query" | "report"
    source_type     = Column(String(50),  nullable=False)
    source_id       = Column(Integer,     nullable=False)

    # Parameter values to pass to the source at run time
    param_values    = Column(JSON, nullable=True)

    # Trigger config:
    #   { "type": "cron",     "cron_expr": "0 8 * * 1-5" }
    #   { "type": "interval", "minutes": 60 }
    trigger_config  = Column(JSON, nullable=False)

    # Output filename template — {date} is replaced with YYYYMMDD_HHMMSS
    output_filename_template = Column(String(255), nullable=True)

    # APScheduler job ID (stored so we can pause/remove specific jobs)
    apscheduler_job_id = Column(String(100), nullable=True, unique=True)

    created_by      = Column(String(100), nullable=True)
    created_at      = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime,    default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    # Run tracking
    last_run_at     = Column(DateTime, nullable=True)
    last_run_status = Column(String(50), nullable=True)   # success | failed
    last_run_file_id= Column(String(100), nullable=True)
    last_error      = Column(Text, nullable=True)
    run_count       = Column(Integer, default=0)
    next_run_at     = Column(DateTime, nullable=True)

    # Email notifications — comma-separated list of addresses to notify on completion/failure
    notify_emails   = Column(Text, nullable=True)   # e.g. "alice@corp.com,bob@corp.com"
    # Webhook URL for Slack/Teams/generic HTTP POST notifications
    notify_webhook  = Column(Text, nullable=True)
    # Phase 60: Auto-evaluate alert rules after scheduled execution
    auto_evaluate_alerts = Column(Boolean, default=False, nullable=False)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":               self.id,
            "name":             self.name,
            "description":      self.description,
            "is_active":        self.is_active,
            "is_shared":        self.is_shared or False,
            "source_type":      self.source_type,
            "source_id":        self.source_id,
            "param_values":     self.param_values,
            "trigger_config":   self.trigger_config,
            "output_filename_template": self.output_filename_template,
            "apscheduler_job_id": self.apscheduler_job_id,
            "created_by":       self.created_by,
            "created_at":       self.created_at.isoformat() if self.created_at else None,
            "updated_at":       self.updated_at.isoformat() if self.updated_at else None,
            "last_run_at":      self.last_run_at.isoformat() if self.last_run_at else None,
            "last_run_status":  self.last_run_status,
            "last_run_file_id": self.last_run_file_id,
            "last_error":       self.last_error,
            "run_count":        self.run_count,
            "next_run_at":      self.next_run_at.isoformat() if self.next_run_at else None,
            "notify_emails":    self.notify_emails,
            "notify_webhook":   self.notify_webhook,
            "auto_evaluate_alerts": self.auto_evaluate_alerts or False,
        }


# ── New enterprise models ─────────────────────────────────────────────────────

class QueryCacheEntry(Base):
    """Disk-backed parquet cache keyed by sha256 of canonical query_config JSON."""
    __tablename__ = "query_result_cache"

    # 2026-06-09 — was VARCHAR(64); cache_key is ``base:`` (5 chars) +
    # sha256 hexdigest (64 chars) = 69 chars, which truncated and
    # failed every cache write with psycopg2.errors.StringData
    # RightTruncation.  Bumped to 128 for headroom (handles future
    # prefixes like ``rls:``, ``feed:`` without re-migration).  Paired
    # with explicit ALTER TABLE migration in database.py._auto_widen_
    # cache_key_column so existing prod DBs upgrade in place.
    cache_key           = Column(String(128), primary_key=True)
    file_path           = Column(String(500), nullable=False)
    row_count           = Column(BigInteger, default=0)
    file_size_bytes     = Column(BigInteger, default=0)
    created_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at          = Column(DateTime, nullable=True)
    query_config        = Column(JSON, nullable=True)
    connection_id       = Column(Integer, nullable=True, index=True)
    hit_count           = Column(Integer, default=0)
    # Phase 104 — partition-aware cache invalidation
    source_fingerprint  = Column(String(128), nullable=True)   # SHA-256 of combined table fingerprints (allow prefix headroom)
    source_tables_json  = Column(JSON, nullable=True)         # [{conn_id,table,format,snapshot_id,...}]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "cache_key":           self.cache_key,
            "file_path":           self.file_path,
            "row_count":           self.row_count,
            "file_size_bytes":     self.file_size_bytes,
            "created_at":          self.created_at.isoformat() if self.created_at else None,
            "expires_at":          self.expires_at.isoformat() if self.expires_at else None,
            "connection_id":       self.connection_id,
            "hit_count":           self.hit_count or 0,
            "query_config":        self.query_config,
            "source_fingerprint":  self.source_fingerprint,
            "source_tables_json":  self.source_tables_json,
        }


class SnapshotTracker(Base):
    """Tracks current snapshot/fingerprint per (connection_id, table_name) for cache invalidation."""
    __tablename__ = "snapshot_tracker"

    id              = Column(Integer, primary_key=True, index=True)
    connection_id   = Column(Integer, nullable=False, index=True)
    table_name      = Column(String(255), nullable=False, index=True)
    table_format    = Column(String(20), nullable=True)    # "iceberg" or "parquet"
    snapshot_id     = Column(String(50), nullable=True)    # Iceberg snapshot ID
    file_list_hash  = Column(String(64), nullable=True)    # SHA-256 of sorted parquet file list
    file_count      = Column(Integer, nullable=True)
    checked_at      = Column(DateTime, nullable=True)
    changed_at      = Column(DateTime, nullable=True)

    __table_args__ = (
        UniqueConstraint("connection_id", "table_name", name="uq_snapshot_tracker_conn_table"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "connection_id":  self.connection_id,
            "table_name":     self.table_name,
            "table_format":   self.table_format,
            "snapshot_id":    self.snapshot_id,
            "file_list_hash": self.file_list_hash,
            "file_count":     self.file_count,
            "checked_at":     self.checked_at.isoformat() if self.checked_at else None,
            "changed_at":     self.changed_at.isoformat() if self.changed_at else None,
        }


class PartitionCache(CanonicalPrefixMixin, Base):
    """Persistent cache for Iceberg partition metadata — survives restarts."""
    __tablename__ = "partition_cache"

    id              = Column(Integer, primary_key=True, index=True)
    connection_id   = Column(Integer, nullable=False)
    table_name      = Column(String(255), nullable=False)
    s3_prefix       = Column(String(512), nullable=False, default="")
    scan_type       = Column(String(10), default="fast")   # "fast" or "full"
    partition_data  = Column(JSON, nullable=False)          # full response payload
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_partition_cache_lookup', 'connection_id', 'table_name', 's3_prefix', 'scan_type', unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "connection_id":  self.connection_id,
            "table_name":     self.table_name,
            "s3_prefix":      self.s3_prefix or "",
            "scan_type":      self.scan_type,
            "partition_data": self.partition_data,
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "updated_at":     self.updated_at.isoformat() if self.updated_at else None,
        }


class IcebergFileCache(Base):
    """Persistent L2 cache for Iceberg data-file lists — avoids re-scanning S3 manifests."""
    __tablename__ = "iceberg_file_cache"

    id              = Column(Integer, primary_key=True, index=True)
    connection_id   = Column(Integer, nullable=False)
    table_name      = Column(String(255), nullable=False)
    filters_hash    = Column(String(512), nullable=False, default="")
    file_list       = Column(JSON, nullable=False)          # list of S3 file paths
    file_count      = Column(Integer, default=0)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_iceberg_file_cache_lookup', 'connection_id', 'table_name', 'filters_hash', unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "connection_id":  self.connection_id,
            "table_name":     self.table_name,
            "filters_hash":   self.filters_hash,
            "file_list":      self.file_list,
            "file_count":     self.file_count,
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "updated_at":     self.updated_at.isoformat() if self.updated_at else None,
        }


class SchedulerLease(Base):
    """BF-410.4 — Scheduler leader election lease.

    Single-row table (id=1) holding which scheduler pod currently owns the
    APScheduler-jobs lease.  Re-acquired periodically; expires if not renewed.
    Defined here so Base.metadata.create_all() handles it at startup (was
    previously created on-demand by SchedulerLease._ensure_table(), which
    risked a race when multiple scheduler pods start simultaneously on a
    fresh deploy — BF-410-AUDIT-FOLLOWUP).
    """
    __tablename__ = "scheduler_lease"

    id          = Column(Integer, primary_key=True)
    holder_id   = Column(String(200), nullable=False)
    acquired_at = Column(DateTime, nullable=False)
    expires_at  = Column(DateTime, nullable=False, index=True)


class UserSession(Base):
    """BF-408 — DB-backed user session for multi-worker support.

    Previously sessions lived in an in-memory dict (``core.sessions._sessions``)
    which broke with ``workers > 1`` because each uvicorn worker had its
    own dict — user logs into worker 1, next request hits worker 2 → 401
    → page reload → lost state.

    Moving to DB enables horizontal scaling AND survives backend restarts.
    Each ``get_session`` call still uses a thin in-memory LRU cache for
    performance (typical lookup is ~0.5ms, cached is ~0.01ms).
    """
    __tablename__ = "user_sessions"

    token      = Column(String(128), primary_key=True)
    user_data  = Column(JSON, nullable=False)         # full user dict
    expires_at = Column(DateTime, nullable=False, index=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "token":      self.token,
            "user":       self.user_data,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class BackgroundJobState(Base):
    """BF-320 — persisted state for background_jobs registry.

    Currently used to remember which jobs were paused by an admin
    so a pod restart doesn't auto-restart them.  Keyed on job name.
    """
    __tablename__ = "background_job_state"

    name        = Column(String(100), primary_key=True)
    paused      = Column(Boolean, default=False)
    paused_at   = Column(DateTime, nullable=True)
    paused_by   = Column(String(100), nullable=True)   # username if available
    updated_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name":       self.name,
            "paused":     bool(self.paused),
            "paused_at":  self.paused_at.isoformat() if self.paused_at else None,
            "paused_by":  self.paused_by,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class DaemonHeartbeat(Base):
    """2026-09-01 — what each pod's daemons are ACTUALLY doing, per pod.

    ``background_jobs._jobs`` is a module-level dict, so every pod could
    only ever report its own daemons.  The admin UI is served by the API
    pod and the daemons run on the scheduler/worker pod, so the fleet was
    invisible from the only place anyone looks at it, and an empty list
    read as "nothing is running".

    ``background_job_state`` cannot answer this: it records admin INTENT
    (paused / not paused) and is written by whoever clicked.  This records
    OBSERVED state and is written only by the pod that owns the daemon.
    Intent and observation disagreeing is exactly the condition an operator
    needs to see — a daemon that should be running and is not — so they are
    deliberately separate tables rather than more columns on one.

    A new table is also the only shape that self-creates on deploy; adding
    columns to an existing one needs a migration, and a migration that has
    not run yet is indistinguishable from a pod that never reported.

    Keyed (pod_id, name): the same daemon may legitimately be registered on
    several pods, and collapsing them would hide a duplicated singleton —
    the failure this table is most useful for catching.

    Rows go stale rather than being deleted, and staleness is what makes a
    dead pod detectable; the retention sweep GCs them like
    ``worker_health_state``.
    """
    __tablename__ = "daemon_heartbeat"

    pod_id        = Column(String(150), primary_key=True)
    name          = Column(String(100), primary_key=True)
    pod_role      = Column(String(20), nullable=True)   # api | worker | hybrid
    status        = Column(String(20), nullable=True)   # running | paused | ...
    running       = Column(Boolean, default=False)
    paused        = Column(Boolean, default=False)
    restart_count = Column(Integer, default=0)
    last_error    = Column(Text, nullable=True)
    updated_at    = Column(DateTime, nullable=False,
                            default=lambda: datetime.now(timezone.utc),
                            onupdate=lambda: datetime.now(timezone.utc),
                            server_default=sa_text("CURRENT_TIMESTAMP"))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "pod_id":        self.pod_id,
            "name":          self.name,
            "pod_role":      self.pod_role,
            "status":        self.status,
            "running":       bool(self.running),
            "paused":        bool(self.paused),
            "restart_count": self.restart_count or 0,
            "last_error":    self.last_error,
            "updated_at":    self.updated_at.isoformat() if self.updated_at else None,
        }


class BackgroundJobTick(Base):
    """2026-10-08 -- the background-job LEDGER, durable.

    ``core.background_job_contract.record_tick`` kept each job's recent
    ticks in a per-process ring.  For a ``per_process`` job (the snapshot
    listeners, the warm-on-commit, the fleet syncer, the per-pod
    prewarmer) the admin route answered from the API pod's ring -- which
    is EMPTY when the event fired on the scheduler pod -- so an operator
    (and the Docker proof) read ``last_tick: null`` for a warm that had
    just run.  One row per tick, written by the process that ran it,
    keyed by its ``pod_id``; every pod reads the same rows and they
    survive a restart.  The ring remains the in-process copy (and the
    fallback when no DB is reachable).

    A new table self-creates on deploy; the ledger is pruned per job on
    insert (``background_job_contract.DURABLE_TICKS_PER_JOB``), so it
    never grows past a few hundred rows.
    """
    __tablename__ = "background_job_ticks"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(100), nullable=False, index=True)
    pod_id      = Column(String(150), nullable=True)
    at          = Column(DateTime, nullable=False,
                         default=lambda: datetime.now(timezone.utc))
    trigger     = Column(String(20), nullable=True)    # run_now | scheduled | event
    outcome     = Column(String(20), nullable=False)   # ok | no_input | ...
    #: the ring record VERBATIM (at, trigger, outcome, reason, counts,
    #: duration_s, error, pod_id[, result]) -- so a durable read and an
    #: in-process read of the same tick are the same dict.
    record      = Column(JSON, nullable=False)

    __table_args__ = (
        Index("ix_background_job_ticks_name_at", "name", "at"),
    )

    def to_dict(self) -> Dict[str, Any]:
        rec = dict(self.record or {})
        rec.setdefault("pod_id", self.pod_id)
        return rec


class CustomBackgroundJob(Base):
    """BF-312 — admin-defined custom periodic jobs.

    Lets an admin schedule any of a small set of safe job types
    (webhook / sql_query / iceberg_sync / cache_clear) on a cron
    schedule, without writing Python code.  Runs are persisted so the
    admin UI can show last-run status + scheduled next run.
    """
    __tablename__ = "custom_background_jobs"

    id              = Column(Integer, primary_key=True, index=True)
    name            = Column(String(255), unique=True, nullable=False, index=True)
    description     = Column(Text, nullable=True)
    # One of: webhook | sql_query | iceberg_sync | cache_clear
    job_type        = Column(String(40), nullable=False)
    # Type-specific parameters (validated at create time)
    parameters      = Column(JSON, nullable=False, default=dict)
    # Standard 5-field cron (cronmaker.com format).  Validated on
    # write via croniter.is_valid().
    cron_expression = Column(String(100), nullable=False)
    enabled         = Column(Boolean, default=True)
    # Last-run telemetry
    last_run_at     = Column(DateTime, nullable=True)
    last_status     = Column(String(20), nullable=True)   # ok | error | skipped
    last_error      = Column(Text, nullable=True)
    last_duration_seconds = Column(Float, nullable=True)
    last_output     = Column(Text, nullable=True)
    # Scheduler state
    next_run_at     = Column(DateTime, nullable=True, index=True)
    run_count       = Column(Integer, default=0)
    error_count     = Column(Integer, default=0)
    # 2026-10-10 -- the RUN LEASE.  Set by the ONE claim both the scheduler
    # loop and POST /api/admin/custom-jobs/{id}/run-now go through
    # (DatabaseManager.claim_custom_job_run), cleared when the run's
    # outcome is recorded.  A job whose lease is held is not claimable
    # again until it is released or the lease ages out -- two pods, two
    # clicks, a click during a scheduled run: one run.  Declared in
    # ``_MIGRATIONS["custom_background_jobs"]`` (a COLUMN does not self-create).
    running_since   = Column(DateTime, nullable=True)
    # Audit
    created_by      = Column(String(100), nullable=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                    self.id,
            "name":                  self.name,
            "description":           self.description,
            "job_type":              self.job_type,
            "parameters":            self.parameters,
            "cron_expression":       self.cron_expression,
            "enabled":               bool(self.enabled),
            "last_run_at":           self.last_run_at.isoformat() if self.last_run_at else None,
            "last_status":           self.last_status,
            "last_error":            self.last_error,
            "last_duration_seconds": self.last_duration_seconds,
            "last_output":           self.last_output,
            "next_run_at":           self.next_run_at.isoformat() if self.next_run_at else None,
            "run_count":             self.run_count or 0,
            "error_count":           self.error_count or 0,
            "running_since":         self.running_since.isoformat() if self.running_since else None,
            "created_by":            self.created_by,
            "created_at":            self.created_at.isoformat() if self.created_at else None,
            "updated_at":            self.updated_at.isoformat() if self.updated_at else None,
        }


class WatchedIcebergTable(CanonicalPrefixMixin, Base):
    """BF-299 — tables the background sync job keeps fresh.

    Auto-populated when a query first reads from an Iceberg table.
    Admins can also pin tables explicitly via the admin API.  The
    sync scheduler iterates this registry every N minutes and runs
    the BF-296/298 cache reconciliation so the *first* user query
    against a hot table never waits for metadata.
    """
    __tablename__ = "watched_iceberg_tables"

    id              = Column(Integer, primary_key=True, index=True)
    connection_id   = Column(Integer, nullable=False)
    bucket          = Column(String(255), nullable=False)
    table_prefix    = Column(String(512), nullable=False)
    # snapshot_id last seen by the sync job
    last_snapshot_id  = Column(String(64), nullable=True)
    last_synced_at    = Column(DateTime, nullable=True)
    last_sync_status  = Column(String(32), default="pending")  # pending | ok | error
    last_sync_error   = Column(Text, nullable=True)
    last_sync_seconds = Column(Float, nullable=True)
    last_files_count  = Column(Integer, nullable=True)
    # When pinned=True, sync runs even on tables that haven't been
    # queried recently (admin override).  Auto-added rows have
    # pinned=False and may be evicted by retention policy.
    pinned            = Column(Boolean, default=False)
    enabled           = Column(Boolean, default=True)
    # BF-318 — per-table predownload rule.  When unset, falls back to
    # global iceberg.metadata_sync_predownload_* config.  Admin can
    # configure each watched table with a tailored rule, e.g.:
    #   {"strategy": "recent_dates", "partition_column": "business_close_date",
    #    "lookback_days": 60, "max_files": 500, "max_gb": 50}
    #   {"strategy": "top_n_by_record_count", "max_files": 10}
    #   {"strategy": "off"}                       (skip predownload for this table)
    #   {"strategy": "custom", "filters": [{"col":..., "op":..., "val":...}],
    #    "max_files": ..., "max_gb": ...}
    predownload_rule  = Column(JSON, nullable=True)
    # Per-table column-stats scan rule.  When NULL, falls back to the global
    # iceberg.column_stats_sync_* config.  When set, overrides per-table:
    #   {"enabled": false}                        (skip this table entirely)
    #   {"enabled": true, "max_files": 1000}      (cap scan size for this table)
    #   {"enabled": true, "workers": 8, "max_files": 2000, "columns": ["a", "b"]}
    # Recognised keys: enabled (bool), max_files (int, 0=unlimited),
    # workers (int), columns (list[str] of column names to scan; None=all).
    column_stats_rule = Column(JSON, nullable=True)
    created_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    last_queried_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_watched_iceberg_tables_lookup',
              'connection_id', 'bucket', 'table_prefix', unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                 self.id,
            "connection_id":      self.connection_id,
            "bucket":             self.bucket,
            "table_prefix":       self.table_prefix,
            "last_snapshot_id":   self.last_snapshot_id,
            "last_synced_at":     self.last_synced_at.isoformat() if self.last_synced_at else None,
            "last_sync_status":   self.last_sync_status,
            "last_sync_error":    self.last_sync_error,
            "last_sync_seconds":  self.last_sync_seconds,
            "last_files_count":   self.last_files_count,
            "pinned":             bool(self.pinned),
            "enabled":            bool(self.enabled),
            "predownload_rule":   self.predownload_rule,
            "column_stats_rule":  self.column_stats_rule,
            "created_at":         self.created_at.isoformat() if self.created_at else None,
            "last_queried_at":    self.last_queried_at.isoformat() if self.last_queried_at else None,
        }


class QueryScanPlan(Base):
    """Phase P (2026-06-08) — one row per executed query, holding the
    full PruneContext (per-table file counts, all gate Decisions, all
    Join probes).  Queryable via /api/admin/queries/scan-plan/{id}.

    Pre-Phase-P the per-table prune data was scattered across the
    in-memory ``_PRUNING`` ring + the ``query_pruning_history`` table
    (one row per iceberg-read).  The latter was wiped on every restart
    of the diagnostic store; neither captured the inter-table join
    plan or the full decision flow.

    QueryScanPlan is the durable single-row-per-query record.  Each
    row's ``plan`` JSON contains the entire PruneContext.to_dict()
    output — admin UI loads it directly without joining tables.
    """
    __tablename__ = "query_scan_plans"

    id                  = Column(Integer, primary_key=True, index=True)
    execution_id        = Column(String(64), nullable=False, index=True)
    raw_sql             = Column(Text, nullable=True)
    plan                = Column(JSON, nullable=False)
    total_files_before  = Column(Integer, default=0)
    total_files_after   = Column(Integer, default=0)
    created_at          = Column(DateTime,
                                  default=lambda: datetime.now(timezone.utc),
                                  index=True)
    completed_at        = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                  self.id,
            "execution_id":        self.execution_id,
            "raw_sql":             self.raw_sql,
            "plan":                self.plan,
            "total_files_before":  self.total_files_before,
            "total_files_after":   self.total_files_after,
            "created_at":          self.created_at.isoformat() if self.created_at else None,
            "completed_at":        self.completed_at.isoformat() if self.completed_at else None,
        }


class IcebergWatcherChange(CanonicalPrefixMixin, Base):
    """Phase K (2026-06-08) — DB-persisted log of every snapshot-id
    change detected by the iceberg_manifest_watcher.

    Pre-Phase-K the watcher kept a bounded in-memory ring
    (``_RECENT_CHANGES``) which was lost on pod restart.  User asked:
    "everything should be stored to db".  This table is the durable
    audit trail -- one row per detected change, queryable via
    ``/api/admin/iceberg-watcher/status?from_db=true``.

    Retention: caller decides (the admin endpoint defaults to LIMIT 100
    DESC; ops can prune older rows on a schedule via DELETE WHERE
    detected_at < ...).
    """
    __tablename__ = "iceberg_watcher_changes"

    id              = Column(Integer, primary_key=True, index=True)
    bucket          = Column(String(255), nullable=False)
    table_prefix    = Column(String(512), nullable=False)
    snap_old        = Column(String(64), nullable=True)
    snap_new        = Column(String(64), nullable=True)
    on_change_mode  = Column(String(32), nullable=True)    # invalidate|reconcile|both
    invalidated     = Column(JSON, nullable=True)          # {layer: count}
    detected_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                              index=True)

    __table_args__ = (
        Index('ix_iceberg_watcher_changes_lookup',
              'bucket', 'table_prefix', 'detected_at'),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "bucket":         self.bucket,
            "table_prefix":   self.table_prefix,
            "snap_old":       self.snap_old,
            "snap_new":       self.snap_new,
            "on_change_mode": self.on_change_mode,
            "invalidated":    self.invalidated,
            "detected_at":    self.detected_at.isoformat() if self.detected_at else None,
        }


class IcebergManifestCache(Base):
    """BF-298 — per-manifest-file content cache for incremental reconciliation.

    Iceberg manifest files are immutable: their S3 paths are unique per
    write commit (``manifest-{uuid}.avro``) and the bytes never change.
    When a writer appends to a table, the new snapshot reuses most of
    the prior snapshot's manifests verbatim and only writes one new
    manifest for the new data.

    Caching at the manifest-path granularity means a snapshot transition
    only fetches the *new* manifest from S3 — typically 1-2 files
    instead of hundreds.  After warm-up the hit ratio approaches 99 %
    for append-only tables.

    BF-296 (snapshot-keyed cache) is the fast path for unchanged
    snapshots; this manifest-keyed cache is the fast path for snapshot
    *transitions*.
    """
    __tablename__ = "iceberg_manifest_cache"

    id              = Column(Integer, primary_key=True, index=True)
    bucket          = Column(String(255), nullable=False)
    manifest_path   = Column(String(1024), nullable=False)
    # 2026-06-04 — DEFERRED so existence checks + recency-stamp lookups
    # don't pull the multi-MB JSONB payload into memory on every SELECT.
    # Slow-query log was showing 3–12s SELECTs on a 19-row table because
    # SQLAlchemy was loading the full ``entries`` column on every query.
    # With ``deferred()``, the column is loaded lazily — only when the
    # attribute is explicitly accessed.  Existence checks see ~1ms.
    # Callers that NEED the payload (the cache HIT branch in
    # ``get_iceberg_manifest_cache``) just access ``.entries`` and pay
    # the read cost once per actual hit.
    entries         = deferred(Column(JSON, nullable=False))   # decoded Avro records
    entry_count     = Column(Integer, default=0)
    bytes_stored    = Column(BigInteger, default=0)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    last_accessed   = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_iceberg_manifest_cache_lookup',
              'bucket', 'manifest_path', unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":            self.id,
            "bucket":        self.bucket,
            "manifest_path": self.manifest_path,
            "entry_count":   self.entry_count,
            "bytes_stored":  self.bytes_stored,
            "created_at":    self.created_at.isoformat() if self.created_at else None,
            "last_accessed": self.last_accessed.isoformat() if self.last_accessed else None,
        }


class IcebergSnapshotCache(CanonicalPrefixMixin, Base):
    """BF-296 — snapshot-keyed manifest contents cache.

    Two-layer Iceberg metadata cache.  Stores the *pre-filter* manifest-
    walk output keyed on the immutable Iceberg ``snapshot_id`` so any
    filter combination can be served from one cache entry by applying
    the filters in-Python (microseconds) instead of re-walking S3
    manifests (10+ minutes through corporate proxy).

    Why this works safely: every Iceberg snapshot is content-addressable
    and immutable — once a snapshot exists, the files it references can
    never change.  Cache invalidation reduces to "is this snapshot still
    current?" which a small short-TTL pointer cache answers in 1 S3 GET.
    """
    __tablename__ = "iceberg_snapshot_cache"

    id              = Column(Integer, primary_key=True, index=True)
    bucket          = Column(String(255), nullable=False)
    table_prefix    = Column(String(512), nullable=False)
    snapshot_id     = Column(String(64),  nullable=False)
    # JSON: [{"key": "...", "record_count": N, "size_bytes": M,
    #         "partition": {...}, "lower_bounds": {...},
    #         "upper_bounds": {...}, "null_value_counts": {...}}, ...]
    # 2026-06-04 — DEFERRED.  Same rationale as
    # IcebergManifestCache.entries above: the payload is often tens of
    # MB.  Existence checks + recency stamps don't need it.  Callers
    # that DO need it just access ``.files_data`` and pay one read.
    # 2026-07 per-file store: the blob is legacy.  In storage_mode='rows' the
    # per-file rows live in IcebergSnapshotFiles and this stays NULL (nullable
    # relaxed); the row acts as a header / completeness marker.
    files_data      = deferred(Column(JSON, nullable=True))
    storage_mode    = Column(String(8), default="blob", server_default="blob")  # "blob" | "rows"
    file_count      = Column(Integer, default=0)
    bytes_total     = Column(BigInteger, default=0)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    last_accessed   = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_iceberg_snapshot_cache_lookup',
              'bucket', 'table_prefix', 'snapshot_id', unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":            self.id,
            "bucket":        self.bucket,
            "table_prefix":  self.table_prefix,
            "snapshot_id":   self.snapshot_id,
            "file_count":    self.file_count,
            "bytes_total":   self.bytes_total,
            "created_at":    self.created_at.isoformat() if self.created_at else None,
            "last_accessed": self.last_accessed.isoformat() if self.last_accessed else None,
            "storage_mode":  self.storage_mode,
        }


class IcebergSnapshotFiles(CanonicalPrefixMixin, Base):
    """2026-07 — PER-FILE row store for iceberg snapshot enumeration.  ONE row
    per live data-file entry of a snapshot's DATA manifests (status==2 DELETED
    entries are never stored), replacing the 538 MB
    ``IcebergSnapshotCache.files_data`` single-JSON blob.

    Why: the blob can't be partition-filtered (must load+deserialize the WHOLE
    value to read any subset — defeats island-first), is re-serialized whole on
    every write (a 22s UPDATE), and approaches Postgres's ~1 GB single-value
    limit (→ "invalid memory alloc" → the store is SKIPPED → the manifest
    re-walks every query).  Per-file rows fix all three: enumeration is a
    partition-filtered indexed query (the island), writes are chunked bulk
    upserts, and no single value is ever huge.

    ``entry_data`` holds the SAME ``_encode_for_storage``-transformed avro entry
    the blob held ({"status", "data_file": {...}} with field-id-keyed raw-byte
    bounds), so the ENTIRE reader prune funnel / bloom / bound-providers / MoR
    flow run BYTE-IDENTICAL on rows fetched from here.  ``partition_values`` is
    the decoded-string island index (same convention as
    ``iceberg_file_stats_v3.partition_values``).  Complementary to v3, not
    merged: this table = *what files exist in snapshot X* (free, from the
    manifest walk); v3 = *what's inside each file* (opt-in, from footer scans).
    """
    __tablename__ = "iceberg_snapshot_files"

    id               = Column(Integer, primary_key=True, index=True)
    bucket           = Column(String(255),  nullable=False)
    table_prefix     = Column(String(512),  nullable=False)   # rstrip('/') canon (v3 parity)
    snapshot_id      = Column(String(64),   nullable=False)
    file_path        = Column(String(1024), nullable=False)   # data_file.file_path verbatim
    manifest_path    = Column(String(1024), nullable=True)    # provenance / debug
    status           = Column(Integer, default=1)             # 0=EXISTING 1=ADDED (2 never stored)
    record_count     = Column(BigInteger, default=0)
    file_size        = Column(BigInteger, default=0)
    # {partition_field_lower: token_str} for IDENTITY partition fields — the
    # island index (same convention as iceberg_file_stats_v3.partition_values).
    partition_values = Column(JSON, nullable=True)
    # FULL-FIDELITY _encode_for_storage()-transformed avro entry so the reader's
    # prune funnel runs unchanged on rows read from here.
    entry_data       = Column(JSON, nullable=False)
    created_at       = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_iceberg_snapshot_files_lookup',
              'bucket', 'table_prefix', 'snapshot_id', 'file_path', unique=True),
    )


class IcebergFilePartitionIndex(CanonicalPrefixMixin, Base):
    """2026-08-19 — the PARTITION-FIRST access path: seek the island, don't
    scan the ocean for it.

    ``iceberg_snapshot_files.partition_values`` and
    ``iceberg_file_stats_v3.partition_values`` already hold
    ``{col: value}`` per file, and the island carve already pushes
    ``partition_values[col] IN (...)`` down into SQL rather than filtering in
    Python.  But ``partition_values`` is a JSON column and appears in NO
    index anywhere in the schema, so that predicate is a POST-FILTER: the
    database seeks ``(bucket, table_prefix, snapshot_id)``, then walks every
    file row of the snapshot and JSON-extracts the key from each one.  A
    500k-file table answering a single-region query touches 500k rows and
    performs 500k JSON extractions to return a few thousand.

    That is why partition pruning felt slow even though it was "pushed
    down": the ocean was still materialised first and the island searched
    for inside it.

    A JSON expression index cannot fix this portably — Postgres and SQLite
    both index ONE extracted key per index, and the partition columns are
    not known when the schema is created.  So the value gets its own narrow,
    natively indexed row: one per (file, partition column).  The island
    becomes an index RANGE SEEK on
    ``(bucket, table_prefix, snapshot_id, part_key, part_value)`` that
    returns file paths directly, with no row scan and no JSON parsing.

    SAFETY.  This table is an ACCELERATOR, never an authority.  The reader
    consults it only when it can prove COMPLETE coverage for the snapshot
    (every file carries a row for the key being filtered); on anything less
    it returns nothing and the caller keeps today's behaviour byte for byte.
    A partial or stale index therefore costs a little time and can never
    drop a file — the failure mode that matters for a pruning structure.
    """
    __tablename__ = "iceberg_file_partition_index"

    id           = Column(Integer, primary_key=True, index=True)
    bucket       = Column(String(255),  nullable=False)
    table_prefix = Column(String(512),  nullable=False)   # rstrip('/') canon
    snapshot_id  = Column(String(64),   nullable=False)
    #: partition column name, LOWERCASED — matches the partition_values key
    #: convention so a filter built for either store works against this one.
    part_key     = Column(String(255),  nullable=False)
    #: the decoded token, as a string.  Partition values are compared as
    #: strings everywhere in the prune path (hive path segments are strings),
    #: so storing them typed would introduce a coercion this layer does not
    #: otherwise have.
    #:
    #: NULLABLE, and NULL means the NULL PARTITION — ``parse_hive_partition_
    #: values`` maps ``__HIVE_DEFAULT_PARTITION__`` and an empty token to
    #: ``None``.  Storing the row rather than skipping it matters: coverage is
    #: counted per key, so one null-partition file would otherwise drop the
    #: table below full coverage and silently disable the seek for EVERY
    #: query against it.  A NULL row also answers correctly — a file in the
    #: null partition genuinely does not match ``region IN ('eu-west')``.
    part_value   = Column(String(512),  nullable=True)
    file_path    = Column(String(1024), nullable=False)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        # Leading columns are exactly the seek key; file_path rides along so
        # the lookup is index-only and unique-per-file.
        Index('ix_iceberg_file_partition_seek',
              'bucket', 'table_prefix', 'snapshot_id',
              'part_key', 'part_value', 'file_path', unique=True),
    )


class SchemaCache(Base):
    """Persistent cache for registered table schemas — avoids repeated S3 metadata reads."""
    __tablename__ = "schema_cache"

    id              = Column(Integer, primary_key=True, index=True)
    connection_id   = Column(Integer, nullable=False)
    table_name      = Column(String(255), nullable=False)
    table_format    = Column(String(20), default="iceberg")     # iceberg, parquet, csv
    schema_data     = Column(JSON, nullable=False)              # full schema response payload
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_schema_cache_lookup', 'connection_id', 'table_name', unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "connection_id":  self.connection_id,
            "table_name":     self.table_name,
            "table_format":   self.table_format,
            "schema_data":    self.schema_data,
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "updated_at":     self.updated_at.isoformat() if self.updated_at else None,
        }


class CatalogTableColumn(Base):
    """LOCAL COLUMN CATALOG — one row per (connection, table), holding the
    authoritative column list QueryStudio has learned for that table.

    NOT another cache.  ``schema_cache`` (above) is populated only as a side
    effect of a *successful source read*, so it is empty precisely when
    Starburst / S3 is slow, unreachable or credential-expired — which is
    exactly when the user is staring at "could not read any columns"
    (operator report, 2026-08-22).  This table is a CATALOG: registering a
    table writes it, browsing a schema writes it, refreshing writes it, and
    reading it back NEVER requires the source.

    All writes go through ``core.schema_catalog.ColumnCatalog`` — the single
    chokepoint.  Never INSERT/UPDATE this table from anywhere else; two
    writers of the same fact is this codebase's dominant defect class.

    ``columns_json`` holds the API contract shape::

        [{"name": str, "data_type": str, "nullable": bool,
          "ordinal": int, "description": str|None}, ...]

    An EMPTY ``columns_json`` list is legal only for a failure marker row
    (``last_error`` set): "we tried to learn this table's columns and could
    not — here is why".  ``ColumnCatalog.record_columns`` refuses to record
    an empty column list as a success.

    Deployment note: this table reaches every pod via
    ``Base.metadata.create_all()`` at startup — Alembic is never auto-invoked
    in this deployment, so migration 020 is belt-and-braces for hand-run
    upgrades only.  ``ColumnCatalog`` additionally degrades to the legacy
    ``schema_cache`` table if this table is absent (create_all failed /
    DDL-less DB role), so the read path can never 500 on a missing table.
    """
    __tablename__ = "catalog_table_columns"

    id                = Column(Integer, primary_key=True, index=True)
    connection_id     = Column(Integer, nullable=False)
    #: normalized table name — virtual prefixes (``__registered__:`` etc.)
    #: stripped, same rule as SchemaReader's cache keys, so every write
    #: path lands on the same row.
    table_name        = Column(String(255), nullable=False)
    columns_json      = Column(JSON, nullable=False)
    #: where the columns came from — provenance, not behaviour:
    #: registration | schema_read | schema_browse | refresh | topup |
    #: backfill | migrated_cache | query_result
    source            = Column(String(32), nullable=False, default="unknown")
    table_format      = Column(String(20), nullable=True)   # iceberg, parquet, csv, trino, ...
    #: best-known row count.  NULL = unknown; 0 = genuinely zero rows.
    #: BigInteger — feeds here run to 70M+ rows.
    row_estimate      = Column(BigInteger, nullable=True)
    partition_columns = Column(JSON, nullable=True)
    #: when the columns were last CONFIRMED against a real source read
    #: (or the legacy cache row's own timestamp when migrated in).
    #: Staleness is computed from this and is ADVISORY — stale columns
    #: are served with ``stale: true``, never refused.
    last_refreshed_at = Column(DateTime, nullable=True)
    #: last failed refresh attempt, WITH the reason.  Kept alongside good
    #: columns (a failed refresh does not erase what we know).
    last_error        = Column(Text, nullable=True)
    last_error_at     = Column(DateTime, nullable=True)
    created_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_catalog_table_columns_lookup',
              'connection_id', 'table_name', unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                self.id,
            "connection_id":     self.connection_id,
            "table_name":        self.table_name,
            "columns":           self.columns_json,
            "source":            self.source,
            "table_format":      self.table_format,
            "row_estimate":      self.row_estimate,
            "partition_columns": self.partition_columns,
            "last_refreshed_at": self.last_refreshed_at.isoformat() if self.last_refreshed_at else None,
            "last_error":        self.last_error,
            "last_error_at":     self.last_error_at.isoformat() if self.last_error_at else None,
            "created_at":        self.created_at.isoformat() if self.created_at else None,
            "updated_at":        self.updated_at.isoformat() if self.updated_at else None,
        }


class IcebergMetadataKeyCache(Base):
    """Persistent cache for Iceberg ``_latest_metadata_key`` resolutions.

    The in-memory `_metadata_key_cache` in iceberg_reader.py works perfectly
    within a single process lifetime, but is lost on every restart / pod
    redeploy.  When a table has 15,000+ metadata files (overdue
    expire_snapshots) and no version-hint.text, the cold capped-LIST scan
    takes 25-30 seconds — which used to block the FastAPI worker thread
    inside POST /api/execute pre-validation.

    Persisting the (connection_id, cache_id) → metadata_key mapping in the DB
    means a fresh process or first-query-per-table can immediately serve the
    last-known-good key (and trigger a background refresh via the existing
    stale-while-revalidate path), avoiding the cold scan entirely.
    """
    __tablename__ = "iceberg_metadata_key_cache"

    id              = Column(Integer, primary_key=True, index=True)
    connection_id   = Column(Integer, nullable=False)
    # cache_id is the existing in-memory key shape: f"{bucket}/{meta_prefix}".
    # Stored as a single string so the DB lookup matches the in-memory lookup
    # one-to-one with no key-shape conversion.
    cache_id        = Column(String(512), nullable=False)
    metadata_key    = Column(String(512), nullable=False)
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                             onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_iceberg_metadata_key_cache_lookup',
              'connection_id', 'cache_id', unique=True),
        # BF-ICEBERG-CACHE-ANY-CONN: secondary index on cache_id alone so
        # connection_id=None lookups (post-restart, admin-tool paths, any
        # call site whose s3_client isn't tagged with _qs_connection_id)
        # use an index seek rather than a sequential scan.  Without this
        # index the unique (connection_id, cache_id) index can't be used
        # for the cache_id-only filter (leading-column rule).
        Index('ix_iceberg_metadata_key_cache_by_cache_id', 'cache_id'),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "connection_id":  self.connection_id,
            "cache_id":       self.cache_id,
            "metadata_key":   self.metadata_key,
            "updated_at":     self.updated_at.isoformat() if self.updated_at else None,
        }


class IcebergMetadataContentCache(Base):
    """Persistent cache for the BODIES of Iceberg metadata-chain S3 objects
    that are immutable once written: metadata.json files (UUID in name) and
    manifest-list Avro files (snapshot-id in path).

    Why: even after IcebergMetadataKeyCache (sibling above) gives us the
    latest metadata.json filename instantly, the BODY of that file is only
    cached in-memory (60s TTL).  Cold process / first query per snapshot
    re-fetches the body from S3.  Same for the manifest-list Avro that the
    body points at.  Both are tiny (1-50 KB) but every query that reaches
    them adds a S3 round-trip the user can feel through a corporate proxy
    or VPC endpoint.

    Iceberg writes these files once and never updates them; safe to cache
    forever keyed by full S3 path.  Eviction is by LRU + row-count cap so
    the table doesn't grow unbounded.

    ``content_kind`` distinguishes JSON (metadata.json) from Avro bytes
    (manifest-list) so the read path can decode appropriately.
    """
    __tablename__ = "iceberg_metadata_content_cache"

    id              = Column(Integer, primary_key=True, index=True)
    connection_id   = Column(Integer, nullable=False)
    # Full S3 key of the cached object — the immutable identity that makes
    # forever-caching safe.  Examples:
    #   metadata/12940-36c084f2-4f18-4be3-83d2-f181e631017b.metadata.json
    #   metadata/snap-2788254716930226868-1-{uuid}.avro
    object_key      = Column(String(1024), nullable=False)
    content_kind    = Column(String(16), default="json")  # "json" | "avro"
    # JSON body for metadata.json.  Avro bytes are stored hex-encoded as a
    # string in the same column; SQLite/Postgres BLOB compatibility varies
    # so we keep it portable.  Keeps schema migration trivial across DB
    # backends.
    content         = Column(JSON, nullable=False)
    content_size    = Column(Integer, default=0)  # bytes count for telemetry
    cached_at       = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    last_read_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                             onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_iceberg_metadata_content_cache_lookup',
              'connection_id', 'object_key', unique=True),
        Index('ix_iceberg_metadata_content_cache_lru', 'last_read_at'),
        # BF-ICEBERG-CACHE-ANY-CONN: see sibling note on
        # IcebergMetadataKeyCache.  Secondary index on object_key alone
        # so untagged-client / connection_id=None lookups hit an index.
        Index('ix_iceberg_metadata_content_cache_by_object_key', 'object_key'),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "connection_id":  self.connection_id,
            "object_key":     self.object_key,
            "content_kind":   self.content_kind,
            "content":        self.content,
            "content_size":   self.content_size,
            "cached_at":      self.cached_at.isoformat() if self.cached_at else None,
            "last_read_at":   self.last_read_at.isoformat() if self.last_read_at else None,
        }


class IcebergColumnStatsSupplement(CanonicalPrefixMixin, Base):
    """BF-COL-STATS — per-file column min/max/null cache for columns that the
    Iceberg writer DIDN'T track in manifest bounds.

    Iceberg writers only collect file-level lower_bound / upper_bound for
    columns explicitly marked via `write.metadata.metrics.column.<name>`.
    Columns left out get NO bounds — pruning is impossible for filters on
    them, forcing a full scan of every file in the snapshot.

    This table supplements the Iceberg manifest bounds by extracting min/
    max/null directly from each parquet file's footer (a 16 KB GET per
    file) and caching forever keyed on the immutable file_path +
    snapshot_id.  Iceberg files never change content, so the cache is
    safe permanently — eviction only kicks in when a snapshot is
    reconciled away by the metadata sync loop.

    BF-COL-STATS-V2: keyed on (bucket, table_prefix, snapshot_id, file_path,
    column_name) — content identity that's SHARED across QueryStudio
    connection rows.  Two connections (e.g. one VPC, one non-VPC) pointing
    at the same S3 bucket + table_prefix now read from the same supplement
    rows.  Scan once, both benefit.

    connection_id + table_name are kept as DENORMALIZED telemetry fields
    so the admin status endpoint can still attribute scans to a connection
    and the bulk-scan endpoint can iterate registered_tables on a
    connection.  They're nullable here — the unique key uses bucket /
    table_prefix.
    """
    # Renamed to _v2 to avoid an in-place schema migration on early-test
    # deployments — the v1 table (if it exists) is left untouched, the v2
    # table gets created fresh with the new shared-identity schema.
    # Admin can drop the v1 table manually after confirming v2 works.
    __tablename__ = "iceberg_column_stats_supplement_v2"

    id              = Column(Integer, primary_key=True, index=True)
    # BF-COL-STATS-V2: primary identity is (bucket, table_prefix) — the S3
    # location that's shared across multiple QueryStudio connections.
    bucket          = Column(String(255), nullable=False, default="")
    table_prefix    = Column(String(512), nullable=False, default="")
    snapshot_id     = Column(String(64),  nullable=False)
    file_path       = Column(String(1024), nullable=False)
    column_name     = Column(String(255), nullable=False)
    # Denormalized telemetry — last connection that scanned / queried.
    # Not part of the unique key; multiple connections can share a row.
    connection_id   = Column(Integer, nullable=True)
    table_name      = Column(String(255), nullable=True)
    # Bound values stored as strings — parquet stats can be int / string /
    # decimal / timestamp.  Read path coerces to filter type at compare time
    # using the column's iceberg type from metadata.json (same coercion the
    # existing _file_matches_column_stats uses for manifest bounds).
    lower_bound     = Column(String(512), nullable=True)
    upper_bound     = Column(String(512), nullable=True)
    # DATA-LOSS FIX (2026-07-17): NULLABLE with NO coercing default.  A stored
    # NULL means "the writer did not record a null count" (UNKNOWN) — distinct
    # from a concrete 0 ("provably zero nulls").  The IS NULL / IS NOT NULL
    # pruners keep the file on UNKNOWN.  A Python-side default=0 would make the
    # ORM overwrite an explicit None with 0 at INSERT, re-introducing the trap;
    # so it is intentionally omitted.  Backward-compat: rows written by the old
    # code already hold 0 and keep today's (prunable) behaviour until re-scan.
    null_count      = Column(BigInteger, nullable=True)
    row_count       = Column(BigInteger, default=0)
    scanned_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    # Phase 151 (2026-06-10) — format discriminator.  'iceberg' for the
    # historical pruning brain rows; 'parquet' for plain-parquet brain
    # rows (Phase 151).  Nullable + server_default keeps existing rows
    # interpretable without a backfill.
    format          = Column(String(32), nullable=False, default="iceberg",
                              server_default="iceberg")

    __table_args__ = (
        # One row per (file × column) within a snapshot, keyed on the
        # CONTENT-IDENTITY (bucket+prefix) so multiple connections share.
        Index('ix_iceberg_col_stats_lookup_v2',
              'bucket', 'table_prefix', 'snapshot_id',
              'file_path', 'column_name', unique=True),
        # Range-scan helper: list all stats for a given snapshot+column
        # to build a {file_path: (lower, upper)} dict for pruning.
        Index('ix_iceberg_col_stats_by_col_v2',
              'bucket', 'table_prefix', 'snapshot_id', 'column_name'),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":            self.id,
            "bucket":        self.bucket,
            "table_prefix":  self.table_prefix,
            "snapshot_id":   self.snapshot_id,
            "file_path":     self.file_path,
            "column_name":   self.column_name,
            "connection_id": self.connection_id,
            "table_name":    self.table_name,
            "lower_bound":   self.lower_bound,
            "upper_bound":   self.upper_bound,
            "null_count":    self.null_count,
            "row_count":     self.row_count,
            "scanned_at":    self.scanned_at.isoformat() if self.scanned_at else None,
        }


class IcebergFileStats(CanonicalPrefixMixin, Base):
    """2026-07-13 — per-FILE column statistics (Starburst / Iceberg-native
    grain).  ONE row per data file, holding EVERY column's min/max/null in a
    single JSON map — instead of the ``iceberg_column_stats_supplement_v2``
    (file × column) grain that stores one row per column per file.

    Motivation (user report): a 3000-file table with 40 columns produced
    ~120,000 rows in the v2 supplement (3000 × 40).  Iceberg manifests
    natively encode per-file stats as field-id-keyed maps (lower_bounds /
    upper_bounds / null_value_counts) — one entry per FILE carrying all
    columns.  Starburst reads them that way.  This table mirrors that grain:
    3000 files → 3000 rows, all columns packed into ``column_stats``.

    ``column_stats`` shape (column_name is lower-cased for case-insensitive
    lookup, matching the v2 read path)::

        {
          "order_date": {"lo": "2025-01-01", "hi": "2025-12-31", "nulls": 0},
          "amount":     {"lo": "0.00",       "hi": "9999.99",    "nulls": 3},
          ...
        }

    Bounds are stored as STRINGS exactly like v2 (parquet stats can be int /
    string / decimal / timestamp; the read path coerces to the filter's
    iceberg type at compare time).  Identity/keying is IDENTICAL to v2
    (bucket + table_prefix + snapshot_id + file_path) minus column_name, so
    both tables describe the same files under the same snapshot and a
    parity check is a straight per-file comparison.

    Additive + flag-gated: this table is written/read only when
    ``iceberg.file_stats_grain`` selects it (default keeps v2).  v2 is left
    untouched so a cutover is reversible.
    """
    __tablename__ = "iceberg_file_stats_v3"

    id              = Column(Integer, primary_key=True, index=True)
    bucket          = Column(String(255), nullable=False, default="")
    table_prefix    = Column(String(512), nullable=False, default="")
    snapshot_id     = Column(String(64),  nullable=False)
    file_path       = Column(String(1024), nullable=False)
    # Denormalized telemetry — last connection that scanned / queried.
    connection_id   = Column(Integer, nullable=True)
    table_name      = Column(String(255), nullable=True)
    # {column_name_lower: {"lo": str|None, "hi": str|None, "nulls": int}}
    # ALL columns for this file in one row (the whole point of v3).
    column_stats    = Column(JSON, nullable=False, default=dict)
    row_count       = Column(BigInteger, default=0)
    file_size       = Column(BigInteger, default=0)
    scanned_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    format          = Column(String(32), nullable=False, default="iceberg",
                             server_default="iceberg")
    # 2026-07 ISLAND-FIRST — TOP-LEVEL PARTITION INDEX (Level 1 of the
    # Starburst two-level model: partition index + per-file column_stats).
    # {partition_col_lower: token_str} for THIS file, captured generically
    # from the Hive ``col=value`` path segments (and, later, the manifest
    # ``data_file.partition`` tuple).  Lets a partition-filtered query carve
    # the ISLAND in SQL (``partition_values[col] IN (...)``) instead of
    # loading the whole table's stats and filtering in Python.
    # NULL = not yet captured (pre-upgrade row) → the island load ALWAYS
    # keeps such a file (fail-open superset); it can never cause row loss.
    # Plain JSON (portable SQLite + Postgres); queried via
    # ``partition_values[col].as_string()`` which SQLAlchemy renders as
    # json_extract (SQLite) / ->> (Postgres).
    partition_values = Column(JSON, nullable=True)

    __table_args__ = (
        # One row per FILE within a snapshot, keyed on content-identity
        # (bucket+prefix) so multiple connections share — same sharing
        # semantics as v2, minus the column_name axis.
        Index('ix_iceberg_file_stats_lookup_v3',
              'bucket', 'table_prefix', 'snapshot_id', 'file_path',
              unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":            self.id,
            "bucket":        self.bucket,
            "table_prefix":  self.table_prefix,
            "snapshot_id":   self.snapshot_id,
            "file_path":     self.file_path,
            "connection_id": self.connection_id,
            "table_name":    self.table_name,
            "column_stats":  self.column_stats or {},
            "row_count":     self.row_count,
            "file_size":     self.file_size,
            "scanned_at":    self.scanned_at.isoformat() if self.scanned_at else None,
            "format":        self.format,
            "partition_values": self.partition_values or None,
        }


class IcebergSupplementBuild(CanonicalPrefixMixin, Base):
    """Phase 4 (industrialization, 2026-07-23) — per-(table, snapshot, column)
    build marker for coverage-triggered within-island supplement builds.

    When a query's filter column has ZERO (or below-threshold) per-file
    bound coverage over the island survivors, the reader schedules a
    BACKGROUND per-file min/max build (the existing
    ``scan_files_to_supplement`` machinery).  This row is the SINGLE-FLIGHT
    claim + completeness marker for that build:

      * dedup — concurrent queries (any pod) racing to schedule the same
        (bucket, table_prefix, snapshot_id, column) build see the claimed
        row and do NOT stampede duplicate footer scans;
      * completeness — ``status='complete'`` records that the column's
        per-file bounds were fully materialized for the pinned snapshot, so
        later queries stop re-scheduling; a new snapshot is a NEW key
        (immutability) and triggers only an incremental delta build.

    CORRECTNESS INVARIANT (why this marker never gates the pruner): the
    supplement consume path is per-file fail-open — a file WITHOUT bounds
    is always KEPT — so a partial build can only under-prune, never drop a
    file.  The marker therefore only controls BUILD scheduling and
    observability, never keep/drop decisions.

    Portable SQLite + PostgreSQL: plain scalar columns, composite unique
    index (mirrors the v2/v3 stats tables' surrogate-id + unique-index
    pattern), no JSONB-only operations.
    """
    __tablename__ = "iceberg_supplement_build_v1"

    id              = Column(Integer, primary_key=True, index=True)
    # Content identity — shared across QueryStudio connections, mirrors
    # iceberg_file_stats_v3 keying (+ the column axis).
    bucket          = Column(String(255), nullable=False, default="")
    table_prefix    = Column(String(512), nullable=False, default="")
    snapshot_id     = Column(String(64),  nullable=False, default="")
    column_name     = Column(String(255), nullable=False)
    # running | partial | complete | failed
    status          = Column(String(16), nullable=False, default="running")
    requested_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    started_at      = Column(DateTime, nullable=True)
    finished_at     = Column(DateTime, nullable=True)
    files_total     = Column(Integer, default=0)
    files_scanned   = Column(Integer, default=0)
    files_failed    = Column(Integer, default=0)
    rows_inserted   = Column(Integer, default=0)
    # Why the build was scheduled (telemetry): e.g. "zero_coverage".
    trigger         = Column(String(32), nullable=True)
    error           = Column(Text, nullable=True)
    # Denormalized telemetry — connection that triggered the build.
    connection_id   = Column(Integer, nullable=True)
    table_name      = Column(String(255), nullable=True)

    __table_args__ = (
        Index('ix_iceberg_supplement_build_key_v1',
              'bucket', 'table_prefix', 'snapshot_id', 'column_name',
              unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":            self.id,
            "bucket":        self.bucket,
            "table_prefix":  self.table_prefix,
            "snapshot_id":   self.snapshot_id,
            "column_name":   self.column_name,
            "status":        self.status,
            "requested_at":  self.requested_at.isoformat() if self.requested_at else None,
            "started_at":    self.started_at.isoformat() if self.started_at else None,
            "finished_at":   self.finished_at.isoformat() if self.finished_at else None,
            "files_total":   int(self.files_total or 0),
            "files_scanned": int(self.files_scanned or 0),
            "files_failed":  int(self.files_failed or 0),
            "rows_inserted": int(self.rows_inserted or 0),
            "trigger":       self.trigger,
            "error":         self.error,
            "connection_id": self.connection_id,
            "table_name":    self.table_name,
        }


class IcebergBloomSidecar(CanonicalPrefixMixin, Base):
    """Phase 149.4 — per-file bloom filter for equality pruning.

    Supplements the column-stats supplement table (which carries min/max
    bounds — good for range filters but useless for sparse equality).
    For sparse-dimension-key filters like ``WHERE customer_id = 12345``,
    bound-based pruning matches every file; bloom can prove the value
    is NOT in a file and drop it cleanly.

    Storage stays cloud / DB-resident — bloom bytes live in this table
    as a BLOB, NOT on local disk.  Honours the Phase 149 ``no local
    copy`` constraint.

    Same content-identity model as IcebergColumnStatsSupplement:
    keyed on (bucket, table_prefix, snapshot_id, file_path, column_name)
    so multiple QueryStudio connections pointing at the same S3
    location share rows.  Scan once, both benefit.

    Bloom parameters (``bloom_num_bits``, ``bloom_k``) are stored per
    row because optimal bit-count depends on the file's distinct value
    count — narrow files get small blooms, wide files get larger ones.
    """
    __tablename__ = "iceberg_bloom_sidecar_v1"

    id              = Column(Integer, primary_key=True, index=True)
    bucket          = Column(String(255), nullable=False, default="")
    table_prefix    = Column(String(512), nullable=False, default="")
    snapshot_id     = Column(String(64),  nullable=False)
    file_path       = Column(String(1024), nullable=False)
    column_name     = Column(String(255), nullable=False)
    # Bloom bit-array.  Sized by ``bloom_num_bits / 8`` bytes; clamped
    # by ``optimal_num_bits`` (max 4 MiB).  Stored as LargeBinary so
    # SQLAlchemy maps to BLOB / BYTEA / VARBINARY per dialect.
    bloom_bits      = Column(LargeBinary, nullable=False)
    bloom_num_bits  = Column(Integer, nullable=False)
    bloom_k         = Column(Integer, nullable=False, default=7)
    distinct_count  = Column(BigInteger, nullable=False, default=0)
    # Denormalised telemetry — last connection that scanned this row.
    connection_id   = Column(Integer, nullable=True)
    table_name      = Column(String(255), nullable=True)
    scanned_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    # Phase 151 (2026-06-10) — same format discriminator as the
    # supplement table.  Bloom rows for plain-parquet brain land here
    # too once 151.C ships.
    format          = Column(String(32), nullable=False, default="iceberg",
                              server_default="iceberg")
    # 2026-07-15 type-parity DATA-LOSS guard — the parquet/arrow logical
    # type the bloom was BUILT from (parity string consumed by
    # ``iceberg_bloom_sidecar.probe_encoding_safe``, e.g. 'string',
    # 'long', 'double', 'date', 'timestamp', 'decimal(10,2)').  NULL on
    # legacy rows -> read paths that require build-encoding parity must
    # treat the type as UNKNOWN and KEEP the file (fail-open).
    column_type     = Column(String(64), nullable=True)

    __table_args__ = (
        # One row per (file × column) within a snapshot.  Same shape as
        # the column-stats supplement so we can join on the same lookup
        # key in queries.
        Index('ix_iceberg_bloom_lookup_v1',
              'bucket', 'table_prefix', 'snapshot_id',
              'file_path', 'column_name', unique=True),
        # Range-scan helper: list all blooms for a given (snapshot, col)
        # so the read path can fetch every file's bloom for a single
        # equality column in one query.
        Index('ix_iceberg_bloom_by_col_v1',
              'bucket', 'table_prefix', 'snapshot_id', 'column_name'),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "bucket":         self.bucket,
            "table_prefix":   self.table_prefix,
            "snapshot_id":    self.snapshot_id,
            "file_path":      self.file_path,
            "column_name":    self.column_name,
            "bloom_num_bits": self.bloom_num_bits,
            "bloom_k":        self.bloom_k,
            "distinct_count": self.distinct_count,
            "connection_id":  self.connection_id,
            "table_name":     self.table_name,
            "column_type":    self.column_type,
            "scanned_at":     self.scanned_at.isoformat() if self.scanned_at else None,
        }


class IcebergMirror(Base):
    """Phase 150 — read-side consolidated mirror of an iceberg snapshot.

    NOT an iceberg table.  Plain parquet + JSON manifest in QS-internal
    bucket.  Source iceberg metadata is consulted READ-only; never
    written.  Built when source has many small files and the same
    snapshot is read repeatedly — DuckDB scans 3 consolidated mirror
    files instead of 5000 source files.

    State machine:
        building → ready → stale → invalid → (deleted)
                       ↘ failed (terminal until manual retry)

    ``routing_enabled`` is a per-row toggle distinct from the global
    ``iceberg.mirror.routing_enabled`` config flag.  Both must be true
    for a query to be routed to this mirror.  Either being false keeps
    the query on source iceberg files — the safe default.

    Dual-run canary (Layer 3): the routing path samples 1% of queries
    and re-runs them against source + mirror, compares row count + a
    cheap aggregate hash.  Counters live on this row; per-divergence
    audit lives in ``iceberg_mirror_dual_run_v1``.  ``dual_run_max_
    divergences`` config (default 1) auto-flips routing_enabled to
    false on threshold breach.
    """
    __tablename__ = "iceberg_mirror_v1"

    id                       = Column(Integer, primary_key=True, index=True)
    # Source identity — (bucket, prefix, snapshot_id) is the unique key.
    source_bucket            = Column(String(255), nullable=False, default="")
    source_prefix            = Column(String(512), nullable=False, default="")
    source_snapshot_id       = Column(String(64),  nullable=False)
    # Deterministic schema fingerprint captured at build time.  Any
    # drift between this and the current source schema disqualifies
    # routing — see IcebergMirrorEngine._schema_hash.
    source_schema_hash       = Column(String(64),  nullable=False, default="")
    source_row_count         = Column(BigInteger, nullable=False, default=0)
    source_file_count        = Column(Integer,    nullable=False, default=0)
    source_total_bytes       = Column(BigInteger, nullable=False, default=0)
    # Where the mirror lives in QS-internal bucket.  Always s3://… so
    # callers don't have to know the bucket/prefix split.
    mirror_root_uri          = Column(String(1024), nullable=False, default="")
    mirror_manifest_uri      = Column(String(1024), nullable=False, default="")
    mirror_file_count        = Column(Integer,    nullable=False, default=0)
    mirror_total_bytes       = Column(BigInteger, nullable=False, default=0)
    mirror_row_count         = Column(BigInteger, nullable=False, default=0)
    # State machine.  building → ready → stale → invalid (or failed).
    status                   = Column(String(32),  nullable=False, default="building")
    # Per-row routing toggle.  Off by default — Stage 1 ships SHADOW
    # only.  Operator flips to true after observing zero divergence
    # for the table's 30-day soak period.
    routing_enabled          = Column(Boolean,     nullable=False, default=False)
    # Telemetry
    built_at                 = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    last_route_at            = Column(DateTime,    nullable=True)
    invalidated_at           = Column(DateTime,    nullable=True)
    build_duration_seconds   = Column(Float,       nullable=True)
    # Dual-run canary counters
    dual_run_samples         = Column(Integer,     nullable=False, default=0)
    dual_run_divergences     = Column(Integer,     nullable=False, default=0)
    dual_run_last_at         = Column(DateTime,    nullable=True)
    # Route stats
    route_hit_count          = Column(BigInteger,  nullable=False, default=0)
    # Last error (truncated) — surfaced in admin UI for failed mirrors.
    last_error               = Column(String(1024), nullable=False, default="")
    notes                    = Column(String(1024), nullable=False, default="")
    # Phase 151.E — source format discriminator.  'iceberg' for the
    # historical contract; 'parquet' for plain-parquet mirrors built by
    # PlainParquetMirrorEngine.  Nullable + server_default keeps
    # existing rows interpretable without a backfill.
    source_format            = Column(String(32),  nullable=False,
                                       default="iceberg",
                                       server_default="iceberg")
    # 2026-10-10 -- HOW the plain-parquet mirror was built, declared by the
    # build ("flat", "hive_partition_by:<cols>", "logical_manifest_only"),
    # so route_files decides from the declaration and the LISTED data-file
    # count, not from a "1 = just the manifest" convention.  NULL = built
    # before the column existed = unknown = not served.  Declared in
    # ``_MIGRATIONS["iceberg_mirror_v1"]`` (a new COLUMN does not self-create).
    consolidation_mode       = Column(String(64),  nullable=True)

    __table_args__ = (
        # One mirror per (bucket, prefix, snapshot).  Build + re-build
        # both target the SAME row — re-build replaces the file set
        # atomically via the JSON manifest rewrite.
        Index('ix_iceberg_mirror_lookup_v1',
              'source_bucket', 'source_prefix', 'source_snapshot_id',
              unique=True),
        # Lifecycle scan helper — cron cleanup walks stale + invalid.
        Index('ix_iceberg_mirror_status_v1',
              'status', 'routing_enabled'),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                      self.id,
            "source_bucket":           self.source_bucket,
            "source_prefix":           self.source_prefix,
            "source_snapshot_id":      self.source_snapshot_id,
            "source_schema_hash":      self.source_schema_hash,
            "source_row_count":        self.source_row_count,
            "source_file_count":       self.source_file_count,
            "source_total_bytes":      self.source_total_bytes,
            "mirror_root_uri":         self.mirror_root_uri,
            "mirror_manifest_uri":     self.mirror_manifest_uri,
            "mirror_file_count":       self.mirror_file_count,
            "mirror_total_bytes":      self.mirror_total_bytes,
            "mirror_row_count":        self.mirror_row_count,
            "status":                  self.status,
            "routing_enabled":         bool(self.routing_enabled),
            "built_at":                self.built_at.isoformat() if self.built_at else None,
            "last_route_at":           self.last_route_at.isoformat() if self.last_route_at else None,
            "invalidated_at":          self.invalidated_at.isoformat() if self.invalidated_at else None,
            "build_duration_seconds":  self.build_duration_seconds,
            "dual_run_samples":        self.dual_run_samples,
            "dual_run_divergences":    self.dual_run_divergences,
            "dual_run_last_at":        self.dual_run_last_at.isoformat() if self.dual_run_last_at else None,
            "route_hit_count":         self.route_hit_count,
            "last_error":              self.last_error,
            "notes":                   self.notes,
            "source_format":           self.source_format,
            "consolidation_mode":      self.consolidation_mode,
        }


class IcebergMirrorDualRunEvent(Base):
    """Phase 150 — Layer 3 dual-run canary divergence audit.

    Written when the canary samples a query and source vs mirror disagree
    (or matches, when ``diverged=False`` — we keep N most recent for
    eyeballing the soak period before flipping routing_enabled to true).

    Bounded retention via cleanup: the engine keeps the latest 200 events
    per mirror; older rows are deleted on each cleanup_stale tick.
    """
    __tablename__ = "iceberg_mirror_dual_run_v1"

    id                  = Column(Integer, primary_key=True, index=True)
    mirror_id           = Column(Integer, nullable=False, index=True)
    occurred_at         = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    diverged            = Column(Boolean, nullable=False, default=False)
    source_row_count    = Column(BigInteger, nullable=False, default=0)
    mirror_row_count    = Column(BigInteger, nullable=False, default=0)
    source_hash         = Column(String(64),  nullable=True)
    mirror_hash         = Column(String(64),  nullable=True)
    query_signature     = Column(String(255), nullable=True)
    notes               = Column(String(512), nullable=False, default="")

    __table_args__ = (
        Index('ix_iceberg_mirror_dual_run_lookup_v1',
              'mirror_id', 'occurred_at'),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                self.id,
            "mirror_id":         self.mirror_id,
            "occurred_at":       self.occurred_at.isoformat() if self.occurred_at else None,
            "diverged":          bool(self.diverged),
            "source_row_count":  self.source_row_count,
            "mirror_row_count":  self.mirror_row_count,
            "source_hash":       self.source_hash,
            "mirror_hash":       self.mirror_hash,
            "query_signature":   self.query_signature,
            "notes":             self.notes,
        }


class QueryVersion(Base):
    """Immutable snapshot of a SavedQuery before each update."""
    __tablename__ = "query_versions"

    id             = Column(Integer, primary_key=True, index=True)
    query_id       = Column(Integer, nullable=False, index=True)
    version_number = Column(Integer, nullable=False, default=1)
    name           = Column(String(255), nullable=True)
    description    = Column(Text, nullable=True)
    query_config   = Column(JSON, nullable=True)
    changed_by     = Column(String(100), nullable=True)
    changed_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    change_note    = Column(Text, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "query_id":       self.query_id,
            "version_number": self.version_number,
            "name":           self.name,
            "description":    self.description,
            "query_config":   self.query_config,
            "changed_by":     self.changed_by,
            "changed_at":     self.changed_at.isoformat() if self.changed_at else None,
            "change_note":    self.change_note,
        }


class QueryShare(Base):
    """Share token for a saved query — allows public access via /api/shared/{token}."""
    __tablename__ = "query_shares"

    id           = Column(Integer, primary_key=True, index=True)
    token        = Column(String(64), unique=True, nullable=False, index=True)
    query_id     = Column(Integer, nullable=False, index=True)
    created_by   = Column(String(100), nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at   = Column(DateTime, nullable=True)
    is_active    = Column(Boolean, default=True)
    access_count = Column(Integer, default=0)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "token":        self.token,
            "query_id":     self.query_id,
            "created_by":   self.created_by,
            "created_at":   self.created_at.isoformat() if self.created_at else None,
            "expires_at":   self.expires_at.isoformat() if self.expires_at else None,
            "is_active":    self.is_active,
            "access_count": self.access_count,
        }


class DashboardShare(Base):
    """Share token for a dashboard — allows public access via /api/shared-dashboard/{token}."""
    __tablename__ = "dashboard_shares"

    id           = Column(Integer, primary_key=True, index=True)
    token        = Column(String(64), unique=True, nullable=False, index=True)
    dashboard_id = Column(Integer, nullable=False, index=True)
    created_by   = Column(String(100), nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at   = Column(DateTime, nullable=True)
    is_active    = Column(Boolean, default=True)
    access_count = Column(Integer, default=0)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "token":        self.token,
            "dashboard_id": self.dashboard_id,
            "created_by":   self.created_by,
            "created_at":   self.created_at.isoformat() if self.created_at else None,
            "expires_at":   self.expires_at.isoformat() if self.expires_at else None,
            "is_active":    self.is_active,
            "access_count": self.access_count,
        }


class BusinessReportShareToken(Base):
    """Share token for a business report — public view link (Phase 58)."""
    __tablename__ = "business_report_share_tokens"

    id           = Column(Integer, primary_key=True, index=True)
    token        = Column(String(64), unique=True, nullable=False, index=True)
    report_id    = Column(Integer, nullable=False, index=True)
    created_by   = Column(String(100), nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at   = Column(DateTime, nullable=True)
    is_active    = Column(Boolean, default=True)
    access_count = Column(Integer, default=0)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "token":        self.token,
            "report_id":    self.report_id,
            "created_by":   self.created_by,
            "created_at":   self.created_at.isoformat() if self.created_at else None,
            "expires_at":   self.expires_at.isoformat() if self.expires_at else None,
            "is_active":    self.is_active,
            "access_count": self.access_count,
        }


class ReportEmbedToken(Base):
    """Embed token for a report — allows iframe embedding in external portals without login (27/58)."""
    __tablename__ = "report_embed_tokens"

    id             = Column(Integer, primary_key=True, index=True)
    token          = Column(String(64), unique=True, nullable=False, index=True)
    report_id      = Column(Integer, nullable=False, index=True)
    report_type    = Column(String(20), nullable=False, default="business")  # "business" | "parametric" (legacy rows)
    created_by     = Column(String(100), nullable=True)
    created_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    expires_at     = Column(DateTime, nullable=True)
    is_active      = Column(Boolean, default=True)
    access_count   = Column(Integer, default=0)
    allowed_params = Column(Text, nullable=True)  # JSON string
    # 2026-08-29 — PER-GROUP EMBED SCOPE.  Mirrors PublishedView.allowed_ad_groups
    # (Phase 82) so an external portal can show ONE report to several groups and
    # have row-security filter each group differently.
    #
    # Both are OPTIONAL and INDEPENDENT — an AD directory is not a precondition.
    # ``allowed_ad_groups``   : names from the AD/LDAP directory.
    # ``allowed_user_groups`` : names of QueryStudio-native ``user_groups`` rows,
    #                           for deployments with no AD (or groups that exist
    #                           only in the product).
    # Both land in the SAME ``UserContext.groups`` tuple because row-security
    # binds on ``group:<name>`` and does not care where a name came from; the two
    # columns exist so the mint-time validation can differ (a native group must
    # EXIST, a directory group cannot be verified from here).
    #
    # NULL/empty on BOTH == today's behaviour exactly: no group scope, the
    # consumer path keeps its unresolved low-privilege principal.
    allowed_ad_groups   = Column(JSON, nullable=True)
    allowed_user_groups = Column(JSON, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        import json as _json
        return {
            "id":             self.id,
            "token":          self.token,
            "report_id":      self.report_id,
            "report_type":    self.report_type or "business",
            "created_by":     self.created_by,
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "expires_at":     self.expires_at.isoformat() if self.expires_at else None,
            "is_active":      self.is_active,
            "access_count":   self.access_count,
            "allowed_params": _json.loads(self.allowed_params) if self.allowed_params else None,
            "allowed_ad_groups":   self.allowed_ad_groups or [],
            "allowed_user_groups": self.allowed_user_groups or [],
        }


class Dashboard(Base):
    """Named canvas that holds multiple report widgets."""
    __tablename__ = "dashboards"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(255), nullable=False, index=True)
    description = Column(Text, nullable=True)
    created_by  = Column(String(100), nullable=True)
    created_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    is_active   = Column(Boolean, default=True)
    workspace_id = Column(Integer, nullable=True, index=True)
    # 2026-09-25 -- dashboard-level filters [{name, label, type, default,
    # options}]; a filter binds by NAME to the parameters each tile declares
    # (core/dashboard_params.py).  A new COLUMN: declared in _MIGRATIONS too.
    filters     = Column(JSON, nullable=True)
    # 2026-10-17 -- configuration-release identity (see SavedQuery.release_key); in _MIGRATIONS too
    release_key = Column(String(160), nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":          self.id,
            "name":        self.name,
            "description": self.description,
            "filters":     self.filters or [],
            "created_by":  self.created_by,
            "created_at":  self.created_at.isoformat() if self.created_at else None,
            "updated_at":  self.updated_at.isoformat() if self.updated_at else None,
            "is_active":   self.is_active,
            "workspace_id": self.workspace_id,
        }


class DashboardWidget(Base):
    """Single widget on a dashboard canvas — references a saved query / SQL query / report."""
    __tablename__ = "dashboard_widgets"

    id           = Column(Integer, primary_key=True, index=True)
    dashboard_id = Column(Integer, nullable=False, index=True)
    # "saved_query" | "sql_query" | "report" | "business_report"
    widget_type  = Column(String(50), nullable=False)
    source_id    = Column(Integer, nullable=False)
    title        = Column(String(255), nullable=True)
    # react-grid-layout position: {x, y, w, h}
    layout       = Column(JSON, nullable=True)
    # "grid" | "bar" | "line" | "area" | "pie" | "scatter" | "metric"
    chart_type   = Column(String(50), default="grid")
    # chart config: axis fields, colors, aggregation
    chart_config = Column(JSON, nullable=True)
    # 2026-10-17 -- configuration-release identity of the widget (minted on export)
    release_key  = Column(String(160), nullable=True, index=True)
    # parameter overrides for report widgets
    param_values = Column(JSON, nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "dashboard_id": self.dashboard_id,
            "widget_type":  self.widget_type,
            "source_id":    self.source_id,
            "title":        self.title,
            "layout":       self.layout or {"x": 0, "y": 0, "w": 6, "h": 4},
            "chart_type":   self.chart_type or "grid",
            "chart_config": self.chart_config or {},
            "param_values": self.param_values or {},
            "created_at":   self.created_at.isoformat() if self.created_at else None,
            "updated_at":   self.updated_at.isoformat() if self.updated_at else None,
        }


class MaterializedView(Base):
    """Pre-downloaded S3 data for instant local DuckDB queries."""
    __tablename__ = "materialized_views"

    id                    = Column(Integer, primary_key=True, index=True)
    name                  = Column(String(255), nullable=False, unique=True, index=True)
    description           = Column(Text, nullable=True)
    connection_id         = Column(Integer, nullable=False)
    table_name            = Column(String(255), nullable=False)
    table_format          = Column(String(50), default="parquet")      # iceberg/parquet/csv
    partition_filter      = Column(JSON, nullable=True)                # {"date_col":"dt","from":"2025-01-01","to":"2025-12-31"}
    query_filter          = Column(Text, nullable=True)                # optional WHERE clause

    # Refresh state
    status                = Column(String(50), default="pending")      # pending/refreshing/ready/failed
    last_refresh_at       = Column(DateTime, nullable=True)
    last_refresh_duration = Column(Float, nullable=True)               # seconds
    row_count             = Column(BigInteger, default=0)
    file_count            = Column(Integer, default=0)
    size_bytes            = Column(BigInteger, default=0)
    last_error            = Column(Text, nullable=True)

    # Schedule (optional auto-refresh)
    schedule_config       = Column(JSON, nullable=True)                # {"type":"cron","cron_expr":"..."} or {"type":"interval","hours":N}
    apscheduler_job_id    = Column(String(100), nullable=True, unique=True)
    next_refresh_at       = Column(DateTime, nullable=True)

    # Metadata
    created_by            = Column(String(100), nullable=True)
    created_at            = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at            = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    is_active             = Column(Boolean, default=True)
    workspace_id          = Column(Integer, nullable=True, index=True)

    # BF-430A — per-MV reader override.  NULL = use the global s3_readers
    # config (default + per_connection mapping).  Set to a registered reader
    # name (e.g. "smart_predownload", "pyarrow_s3fs") to force a specific
    # reader for refresh runs of THIS MV without touching connection-wide
    # config.  Validated against the registry at write time + at the router.
    reader_override       = Column(String(64), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                    self.id,
            "name":                  self.name,
            "description":           self.description,
            "connection_id":         self.connection_id,
            "table_name":            self.table_name,
            "table_format":          self.table_format,
            "partition_filter":      self.partition_filter,
            "query_filter":          self.query_filter,
            "status":                self.status,
            "last_refresh_at":       self.last_refresh_at.isoformat() if self.last_refresh_at else None,
            "last_refresh_duration": self.last_refresh_duration,
            "row_count":             self.row_count,
            "file_count":            self.file_count,
            "size_bytes":            self.size_bytes,
            "last_error":            self.last_error,
            "schedule_config":       self.schedule_config,
            "apscheduler_job_id":    self.apscheduler_job_id,
            "next_refresh_at":       self.next_refresh_at.isoformat() if self.next_refresh_at else None,
            "created_by":            self.created_by,
            "created_at":            self.created_at.isoformat() if self.created_at else None,
            "updated_at":            self.updated_at.isoformat() if self.updated_at else None,
            "is_active":             self.is_active,
            "workspace_id":          self.workspace_id,
            "reader_override":       self.reader_override,
        }


class LocalTable(Base):
    """User-created local tables from downloads or file uploads, stored as parquet."""
    __tablename__ = "local_tables"

    id                = Column(Integer, primary_key=True, index=True)
    name              = Column(String(255), nullable=False, unique=True, index=True)
    description       = Column(Text, nullable=True)
    source_type       = Column(String(50), nullable=False)       # "download_promote" | "file_upload"
    source_file_id    = Column(String(100), nullable=True)       # DownloadFile.file_id if promoted
    original_filename = Column(String(500), nullable=True)

    # Storage
    storage_path      = Column(String(500), nullable=False)      # data/local_tables/{id}
    file_format       = Column(String(50), default="parquet")
    row_count         = Column(BigInteger, default=0)
    file_count        = Column(Integer, default=0)
    size_bytes        = Column(BigInteger, default=0)
    schema_json       = Column(JSON, nullable=True)              # cached column names/types

    # Visibility & lifecycle
    visibility        = Column(String(20), default="public")     # "public" | "private"
    is_active         = Column(Boolean, default=True)
    last_accessed_at  = Column(DateTime, nullable=True)
    auto_discard_days = Column(Integer, default=10)              # 0 = never discard

    # Status
    status            = Column(String(50), default="pending")    # pending/processing/ready/failed
    last_error        = Column(Text, nullable=True)

    # Metadata
    created_by        = Column(String(100), nullable=True)
    created_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    workspace_id      = Column(Integer, nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                self.id,
            "name":              self.name,
            "description":       self.description,
            "source_type":       self.source_type,
            "source_file_id":    self.source_file_id,
            "original_filename": self.original_filename,
            "storage_path":      self.storage_path,
            "file_format":       self.file_format,
            "row_count":         self.row_count,
            "file_count":        self.file_count,
            "size_bytes":        self.size_bytes,
            "schema_json":       self.schema_json,
            "visibility":        self.visibility,
            "is_active":         self.is_active,
            "last_accessed_at":  self.last_accessed_at.isoformat() if self.last_accessed_at else None,
            "auto_discard_days": self.auto_discard_days,
            "status":            self.status,
            "last_error":        self.last_error,
            "created_by":        self.created_by,
            "created_at":        self.created_at.isoformat() if self.created_at else None,
            "updated_at":        self.updated_at.isoformat() if self.updated_at else None,
            "workspace_id":      self.workspace_id,
        }


class PendingNotification(Base):
    """Cross-process notification queue.

    The scheduler worker writes notifications here (scheduled job started/completed/failed).
    The FastAPI process polls undelivered rows and broadcasts them via WebSocket,
    then marks them as delivered.  Used when scheduler.mode = "external".
    """
    __tablename__ = "pending_notifications"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    payload      = Column(JSON, nullable=False)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    delivered    = Column(Boolean, default=False, index=True)
    delivered_at = Column(DateTime, nullable=True)


class TaskQueue(Base):
    """Cross-process task queue for executor service.

    FastAPI enqueues tasks here (status='pending').
    Executor worker claims them (status='claimed'), runs them,
    and updates status to 'completed' or 'failed'.
    FastAPI polls for completed tasks and broadcasts WS notifications.
    Only used when executor.mode = "external".
    """
    __tablename__ = "task_queue"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    task_id         = Column(String(100), unique=True, nullable=False, index=True)
    task_type       = Column(String(50), nullable=False, index=True)
    status          = Column(String(20), default="pending", nullable=False, index=True)
    priority        = Column(Integer, default=5)
    payload         = Column(JSON, nullable=False)
    result          = Column(JSON, nullable=True)
    error_message   = Column(Text, nullable=True)
    progress_pct    = Column(Integer, default=0)
    progress_detail = Column(Text, nullable=True)
    execution_id    = Column(String(100), nullable=True, index=True)
    claimed_by      = Column(String(100), nullable=True)
    created_by      = Column(String(100), nullable=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    claimed_at      = Column(DateTime, nullable=True)
    started_at      = Column(DateTime, nullable=True)
    completed_at    = Column(DateTime, nullable=True)
    timeout_seconds = Column(Integer, default=1800)
    retry_count      = Column(Integer, default=0)
    max_retries      = Column(Integer, default=3)
    next_retry_at    = Column(DateTime, nullable=True, index=True)  # for backoff scheduling
    cancel_requested = Column(Integer, default=0)  # 0=no, 1=cancel requested

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "task_id": self.task_id,
            "task_type": self.task_type, "status": self.status,
            "priority": self.priority,
            "payload": self.payload, "result": self.result,
            "error_message": self.error_message,
            "progress_pct": self.progress_pct,
            "progress_detail": self.progress_detail,
            "execution_id": self.execution_id,
            "claimed_by": self.claimed_by,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "claimed_at": self.claimed_at.isoformat() if self.claimed_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "timeout_seconds": self.timeout_seconds,
            "retry_count": self.retry_count, "max_retries": self.max_retries,
            "next_retry_at": self.next_retry_at.isoformat() if self.next_retry_at else None,
            "cancel_requested": bool(self.cancel_requested),
        }


class DeadLetterQueue(Base):
    """Permanently failed tasks that exhausted all retries (Phase 22C)."""
    __tablename__ = "dead_letter_queue"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    task_id         = Column(String(100), unique=True, nullable=False, index=True)
    task_type       = Column(String(50), nullable=False)
    payload         = Column(JSON, nullable=False)
    execution_id    = Column(String(100), nullable=True, index=True)
    created_by      = Column(String(100), nullable=True)
    original_error  = Column(Text, nullable=True)
    retry_count     = Column(Integer, default=0)
    first_failed_at = Column(DateTime, nullable=True)
    dead_at         = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    resolved        = Column(Integer, default=0)   # 0=open, 1=resolved/requeued
    resolved_at     = Column(DateTime, nullable=True)
    resolved_by     = Column(String(100), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "task_id": self.task_id,
            "task_type": self.task_type,
            "payload": self.payload,
            "execution_id": self.execution_id,
            "created_by": self.created_by,
            "original_error": self.original_error,
            "retry_count": self.retry_count,
            "first_failed_at": self.first_failed_at.isoformat() if self.first_failed_at else None,
            "dead_at": self.dead_at.isoformat() if self.dead_at else None,
            "resolved": bool(self.resolved),
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
            "resolved_by": self.resolved_by,
        }


class QueryJob(Base):
    """Industrialization Phase 2 — the PG job-queue substrate row.

    One row per submitted query when ``industrialization.queue_mode`` is
    armed.  The API pod ENQUEUES (identity + RLS + passport captured **as
    data** — the executor never reads ambient request state / contextvars);
    executor pods CLAIM via ``FOR UPDATE SKIP LOCKED`` with a DB-time lease
    and a monotonically increasing **fencing token**; every post-claim
    write-back is fenced (``WHERE fencing_token = :mine``) so a reaped
    zombie executor can never overwrite live state.

    Portability: plain JSON **TEXT** payload columns (no JSONB-only
    operators) so the model round-trips on SQLite for dev/tests — the
    QUEUE itself only arms on PostgreSQL (fleet gate: SKIP LOCKED).

    Time: leases/heartbeats compare against **DB server time in UTC**
    evaluated in SQL (``now() at time zone 'utc'`` / ``datetime('now')``)
    — pod wall-clocks never participate in expiry math (clock-skew rule).

    ALL reads/writes of this table go through ``core.jobqueue.JobQueue``
    (the single chokepoint) — do not query it directly elsewhere.
    """
    __tablename__ = "query_jobs"

    id              = Column(String(36), primary_key=True)          # uuid4
    kind            = Column(String(50), nullable=False, default="execute_query", index=True)
    # Rolling-deploy schema skew: executors refuse jobs with a NEWER
    # payload_version than they understand (left for a newer executor).
    payload_version = Column(Integer, nullable=False, default=1)

    # ── Content address (plan_hash, snapshot_id, rls_key) ──────────────
    # Phase 2 fills plan_hash (canonical request hash) + rls_key (Phase 1
    # boundary when computable); snapshot_id arrives with Phase 3 passports.
    plan_hash       = Column(String(64),  nullable=False, default="")
    snapshot_id     = Column(String(128), nullable=False, default="")
    rls_key         = Column(String(64),  nullable=False, default="")

    # ── Captured-as-data payloads (plain JSON text — SQLite + PG safe) ──
    identity_payload = Column(Text, nullable=False)   # EffectiveIdentity.to_payload()
    rls_payload      = Column(Text, nullable=True)    # EffectiveRlsPredicates.canonical_json()
    passport_json    = Column(Text, nullable=True)    # QueryPassport.to_json() (Phase 3 fills)
    request_payload  = Column(Text, nullable=False)   # the job input (ExecuteQueryRequest dump)

    # ── State machine ───────────────────────────────────────────────────
    # queued → leased → running → succeeded | failed | cancelled
    status          = Column(String(16), nullable=False, default="queued", index=True)
    priority        = Column(Integer, nullable=False, default=100)    # lower = sooner (FIFO+age within)
    attempts        = Column(Integer, nullable=False, default=0)      # incremented at claim
    max_attempts    = Column(Integer, nullable=False, default=2)      # poison-job quarantine bound

    # ── Lease + fencing (DB-time only) ──────────────────────────────────
    lease_owner      = Column(String(128), nullable=True)             # "host:pid:uuid" of claimer
    lease_expires_at = Column(DateTime, nullable=True)                # DB UTC; set/compared in SQL only
    fencing_token    = Column(Integer, nullable=False, default=0)     # +1 on every claim
    heartbeat_at     = Column(DateTime, nullable=True)                # DB UTC
    executor_pid     = Column(Integer, nullable=True)                 # leaked-subprocess cleanup
    executor_host    = Column(String(128), nullable=True)

    # ── Cooperative cancellation ────────────────────────────────────────
    cancel_requested = Column(Boolean, nullable=False, default=False)

    # ── Phase 5 — single-flight + fleet admission/fairness ──────────────
    # lane: priority lane for the weighted-fair claim (interactive > feed >
    # background); attached_to: single-flight follower → leader job id
    # (follower rows use status='attached' and are never claimed);
    # rls_key_shareable: True ONLY when rls_key came from a successful
    # EffectiveRlsPredicates computation (HARD gate 1 — a fail-closed
    # per-job key is NEVER shareable); share_verified: set by the executor
    # after the pre/post-execution key re-verification sandwich passes —
    # follower results are served ONLY from verified leaders;
    # initiator_detached: the enqueueing user cancelled while live
    # followers remained (the execution continues for them — refcount);
    # admission_cost_mb: fleet-admission price from the Phase-3 passport
    # history (0 = unpriced/legacy).
    # rls_fingerprint: digest of the ENTIRE policy set (policies +
    # bindings) at the moment the rls_key was computed.  Attach requires
    # follower_fp == leader_fp and the executor's verification sandwich
    # requires it unchanged through execution — so every shared result is
    # provably computed under the exact policy set every participant's
    # key was rendered from (no key/enforcement TOCTOU window at all).
    lane             = Column(String(16), nullable=False, default="interactive")
    attached_to      = Column(String(36), nullable=True)
    rls_fingerprint  = Column(String(64), nullable=False, default="")
    rls_key_shareable = Column(Boolean, nullable=False, default=False)
    share_verified   = Column(Boolean, nullable=False, default=False)
    initiator_detached = Column(Boolean, nullable=False, default=False)
    admission_cost_mb = Column(Integer, nullable=False, default=0)

    # ── Outcome ─────────────────────────────────────────────────────────
    result_handle   = Column(String(255), nullable=True)  # execution_id (Phase 6: artifact address)
    response_json   = Column(Text, nullable=True)         # executor's submit-response (parity relay)
    error           = Column(Text, nullable=True)         # last failure diagnostic / HTTP-error JSON

    # ── Bookkeeping (ops visibility; identity_payload is authoritative) ─
    enqueued_by     = Column(String(100), nullable=True, index=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    started_at      = Column(DateTime, nullable=True)
    finished_at     = Column(DateTime, nullable=True)

    __table_args__ = (
        # The claim scan: status + priority + age (FIFO+age cannot starve).
        Index("ix_query_jobs_claim", "status", "priority", "created_at"),
        # The content address (Phase 5 single-flight / Phase 6 artifacts).
        Index("ix_query_jobs_address", "plan_hash", "snapshot_id", "rls_key"),
        # The reaper scan: live leases past expiry.
        Index("ix_query_jobs_lease", "status", "lease_expires_at"),
        # Phase 5 — follower propagation scan (leader terminal → followers).
        Index("ix_query_jobs_attached", "attached_to"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "kind": self.kind,
            "payload_version": self.payload_version,
            "plan_hash": self.plan_hash, "snapshot_id": self.snapshot_id,
            "rls_key": self.rls_key,
            # Phase 3 — plan-time cost estimate (telemetry; identity/RLS
            # payloads deliberately stay OUT of this surface).
            "passport_json": self.passport_json,
            "status": self.status, "priority": self.priority,
            "attempts": self.attempts, "max_attempts": self.max_attempts,
            "lease_owner": self.lease_owner,
            "lease_expires_at": self.lease_expires_at.isoformat() if self.lease_expires_at else None,
            "fencing_token": self.fencing_token,
            "heartbeat_at": self.heartbeat_at.isoformat() if self.heartbeat_at else None,
            "executor_pid": self.executor_pid, "executor_host": self.executor_host,
            "cancel_requested": bool(self.cancel_requested),
            # Phase 5 — single-flight + fairness surface
            "lane": self.lane,
            "attached_to": self.attached_to,
            "rls_fingerprint": self.rls_fingerprint,
            "rls_key_shareable": bool(self.rls_key_shareable),
            "share_verified": bool(self.share_verified),
            "initiator_detached": bool(self.initiator_detached),
            "admission_cost_mb": self.admission_cost_mb,
            "result_handle": self.result_handle,
            "error": self.error,
            "enqueued_by": self.enqueued_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "finished_at": self.finished_at.isoformat() if self.finished_at else None,
        }


class ResultArtifact(Base):
    """Industrialization Phase 6 — one content-addressed result artifact.

    The BYTES live in the pluggable artifact store (local FS or a QS-owned
    S3 prefix) as an Arrow IPC file; this row is the metadata + lifecycle
    record.  Portable SQLite+PG: the manifest is plain JSON TEXT (no
    JSONB-only operators).

    HARD gate 1: the address columns always carry the FULL
    ``(plan_hash, snapshot_id, rls_key)`` triple (an uncomputable rls_key
    is replaced by a per-job unique fail-closed key at publish) — but
    serving NEVER looks an artifact up by address: the only lookup key is
    ``execution_id``, so cross-user reuse flows exclusively through the
    Phase-5 single-flight grant chain.

    Lifecycle: ``published`` → (TTL expiry / orphan reap) → ``deleting``
    (invisible to lookups = unpublish-first) → bytes deleted (manifest
    first, then data) → row deleted.  ``active_readers`` +
    ``reader_lease_expires_at`` implement the reader refcount with a
    DB-time lease grace: GC never deletes an artifact a live reader holds,
    and a crashed reader can only delay collection by the grace.

    ALL reads/writes go through ``core.artifacts.ResultArtifactService``
    (single chokepoint) — do not query this table directly elsewhere.
    """
    __tablename__ = "result_artifacts"

    id            = Column(String(36), primary_key=True)             # uuid4
    execution_id  = Column(String(100), nullable=False, index=True)  # == query_jobs.result_handle
    job_id        = Column(String(36), nullable=False)

    # ── Content address (never less than the full triple) + salt ────────
    plan_hash     = Column(String(64),  nullable=False, default="")
    snapshot_id   = Column(String(128), nullable=False, default="")
    rls_key       = Column(String(64),  nullable=False, default="")
    salt          = Column(String(32),  nullable=False, default="")

    # ── Byte-store handle ───────────────────────────────────────────────
    backend       = Column(String(16),  nullable=False, default="local")  # "local" | "s3"
    locator       = Column(Text,        nullable=False)                   # path / s3://bucket/key
    manifest_json = Column(Text,        nullable=False)                   # rows/bytes/checksum/batch index/schema
    row_count     = Column(BigInteger,  nullable=False, default=0)
    byte_size     = Column(BigInteger,  nullable=False, default=0)
    checksum      = Column(String(64),  nullable=False, default="")

    # ── Lifecycle ───────────────────────────────────────────────────────
    status                  = Column(String(16), nullable=False, default="published", index=True)
    active_readers          = Column(Integer,    nullable=False, default=0)
    reader_lease_expires_at = Column(DateTime,   nullable=True)   # DB UTC; compared in SQL only
    last_read_at            = Column(DateTime,   nullable=True)
    expires_at              = Column(DateTime,   nullable=True)   # TTL

    created_by    = Column(String(100), nullable=True)
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)

    __table_args__ = (
        # The GC scans: expired published rows / deletable rows.
        Index("ix_result_artifacts_gc", "status", "expires_at"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "execution_id": self.execution_id,
            "job_id": self.job_id,
            "plan_hash": self.plan_hash, "snapshot_id": self.snapshot_id,
            "rls_key": self.rls_key, "salt": self.salt,
            "backend": self.backend, "locator": self.locator,
            "row_count": self.row_count, "byte_size": self.byte_size,
            "checksum": self.checksum, "status": self.status,
            "active_readers": self.active_readers,
            "reader_lease_expires_at": self.reader_lease_expires_at.isoformat() if self.reader_lease_expires_at else None,
            "last_read_at": self.last_read_at.isoformat() if self.last_read_at else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class MaterializedIsland(CanonicalPrefixMixin, Base):
    """Industrialization Phase 8 — a compacted, read-optimized DERIVED
    MIRROR of one frozen partition island (thousands of small source
    files -> a few large QS-owned parquet files), keyed to the EXACT raw
    file set it was built from.

    We do not own the source Iceberg table's writer, so this is never a
    rewrite of source data (no ``rewrite_data_files``, no source bucket
    write) -- purely an additive, QS-owned artifact the reader may
    SUBSTITUTE for the raw file list at query time.

    THE key (uniqueness + lookup): ``(bucket, table_prefix,
    source_snapshot_id, file_set_fingerprint)``.  ``file_set_fingerprint``
    is a SHA-256 over the SORTED raw island file paths -- since Iceberg
    snapshots are immutable, an exact fingerprint match means "this
    mirror was built from PRECISELY the files the current query's
    island-pruned enumeration just produced", which is the entire
    servability proof (row-equivalence is additionally certified via
    ``certificate_verdict`` at build time -- see
    ``core.materialized_islands``).  ``partition_tuple_json`` is
    informational (target-selection / admin display) and plays NO role
    in the serving lookup -- the fingerprint already encodes the exact
    file set, so a stale/mismatched partition_tuple can never cause a
    wrong serve.

    State machine::

        pending -> building -> ready -> stale -> (deleted)
                       \\-> refused_mor   (row-level deletes present -- see
                                          module docstring; FAIL-CLOSED,
                                          never compacted)
                       \\-> failed        (row-count / cert mismatch, I/O
                                          error -- terminal until a fresh
                                          build() call for the same key)

    ``stale_since`` is stamped the first tick the source snapshot no
    longer matches ``source_snapshot_id`` (immutable snapshots never
    change identity, only STOP being current); GC deletes bytes+row only
    after ``stale_since`` + a grace, giving in-flight readers time to
    finish.  A mirror is NEVER invalidated for its OWN snapshot -- only
    superseded when the table moves on.

    Portable SQLite+PG: ``partition_tuple_json`` / ``certificate_json`` /
    ``mirror_files_json`` are plain TEXT (no JSONB-only operators).

    ALL reads/writes go through ``core.materialized_islands`` (single
    chokepoint) -- do not query this table directly elsewhere.
    """
    __tablename__ = "materialized_islands"

    id                     = Column(Integer, primary_key=True, autoincrement=True)

    # ── Source identity (the funnel this mirror substitutes for) ────────
    bucket                 = Column(String(255), nullable=False, default="")
    table_prefix           = Column(String(512), nullable=False, default="")
    partition_tuple_json   = Column(Text,        nullable=False, default="{}")
    source_snapshot_id     = Column(String(128), nullable=False, default="")

    # ── THE servability key ──────────────────────────────────────────────
    file_set_fingerprint   = Column(String(64),  nullable=False, default="")

    # ── Raw island stats captured at build time (Layer-1 baseline) ──────
    source_file_count      = Column(Integer,    nullable=False, default=0)
    source_total_bytes     = Column(BigInteger, nullable=False, default=0)
    source_row_count       = Column(BigInteger, nullable=False, default=0)
    has_row_deletes        = Column(Boolean,    nullable=False, default=False)

    # ── Compacted mirror location + stats ────────────────────────────────
    backend                = Column(String(16),   nullable=False, default="local")  # "local" | "s3"
    mirror_root_uri        = Column(String(1024), nullable=False, default="")
    mirror_files_json       = Column(Text,        nullable=False, default="[]")     # [{"path","size_bytes"}]
    mirror_file_count      = Column(Integer,    nullable=False, default=0)
    mirror_total_bytes     = Column(BigInteger, nullable=False, default=0)
    mirror_row_count       = Column(BigInteger, nullable=False, default=0)

    # ── The servability proof (Completeness Certificate, Phase 8 gate) ──
    certificate_verdict    = Column(String(16),  nullable=False, default="UNVERIFIED")
    certificate_json       = Column(Text,        nullable=False, default="{}")

    # ── S-A hardening (2026-07-26): content-aware source manifest ───────
    # The path-only fingerprint above proves identity ONLY for files that
    # are provably immutable Iceberg snapshot data files (snapshot pinned
    # AND the path lives under ``{table_prefix}/data/``).  For every OTHER
    # source file (in-place-overwritable non-Iceberg parquet, cross-engine
    # / cross-bucket paths, local paths), this column records the per-file
    # content facets captured at build time::
    #
    #     {"algo": "cf1",
    #      "mutable": {path: {"sz": int|None, "rc": int|None,
    #                          "et": "etag:..|lm:..|mtime_ns:.."|None}},
    #      "content_fingerprint": "<sha256 over the sorted facet tokens>"}
    #
    # Serve time re-verifies CURRENT metadata against these facets and
    # FAILS CLOSED (raw island) on any mismatch or missing metadata — see
    # ``core.materialized_islands._verify_source_content``.  NULL/'' means
    # a legacy (pre-hardening) row: it may serve ONLY if every current
    # path classifies as provably immutable.  Plain TEXT — portable
    # SQLite + PG, no JSONB operators.  Nullable so
    # ``_auto_migrate_from_models`` can ADD COLUMN on existing DBs.
    source_content_json    = Column(Text, nullable=True)

    # ── State machine ─────────────────────────────────────────────────────
    status                 = Column(String(16),  nullable=False, default="pending", index=True)
    last_error             = Column(String(1024), nullable=False, default="")

    # ── Lifecycle timestamps (DB-time compared in SQL only) ──────────────
    requested_at           = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    built_at               = Column(DateTime, nullable=True)
    # L2-C1 (2026-07-25): build-lease stamp — set (DB-time) when
    # _claim_for_build wins 'building'; gc_tick reaps 'building' rows whose
    # lease is older than build_ttl_seconds back to 'failed' so a builder
    # crash mid-build can never wedge an island in 'building' forever.
    building_since         = Column(DateTime, nullable=True)
    stale_since            = Column(DateTime, nullable=True)
    last_routed_at         = Column(DateTime, nullable=True)
    route_hit_count        = Column(BigInteger, nullable=False, default=0)
    build_seconds          = Column(Float,    nullable=True)
    # ── S-C hardening (2026-07-26): serve-fence token ────────────────────
    # Monotonic publish counter — ``_mark_ready`` bumps it
    # (``COALESCE(publish_seq,0)+1``) on EVERY publish.  The serve
    # chokepoint's final conditional UPDATE (the fence) requires
    # ``status='ready' AND COALESCE(publish_seq,0)=<seq read at lookup>``:
    # a demote (stale/corrupt) OR a re-publish under the same key that
    # lands between the reader's row lookup and the file-list swap makes
    # the fence match zero rows, and the read FAILS CLOSED to the raw
    # island (loud).  Compared via COALESCE only — portable SQLite + PG;
    # nullable so ``_auto_migrate_from_models`` can ADD COLUMN.
    publish_seq            = Column(BigInteger, nullable=True)

    __table_args__ = (
        # ``status`` already carries index=True above; only the lookup
        # composite needs an explicit Index here.
        Index("ix_materialized_islands_lookup", "bucket", "table_prefix",
              "source_snapshot_id", "file_set_fingerprint", unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                    self.id,
            "bucket":                self.bucket,
            "table_prefix":          self.table_prefix,
            "partition_tuple":       json.loads(self.partition_tuple_json or "{}"),
            "source_snapshot_id":    self.source_snapshot_id,
            "file_set_fingerprint":  self.file_set_fingerprint,
            "source_file_count":     self.source_file_count,
            "source_total_bytes":    self.source_total_bytes,
            "source_row_count":      self.source_row_count,
            "has_row_deletes":       bool(self.has_row_deletes),
            "backend":               self.backend,
            "mirror_root_uri":       self.mirror_root_uri,
            "mirror_file_count":     self.mirror_file_count,
            "mirror_total_bytes":    self.mirror_total_bytes,
            "mirror_row_count":      self.mirror_row_count,
            "certificate_verdict":   self.certificate_verdict,
            "status":                self.status,
            "last_error":            self.last_error,
            "publish_seq":           int(self.publish_seq or 0),
            "has_content_manifest":  bool(self.source_content_json),
            "requested_at":          self.requested_at.isoformat() if self.requested_at else None,
            "built_at":              self.built_at.isoformat() if self.built_at else None,
            "stale_since":           self.stale_since.isoformat() if self.stale_since else None,
            "last_routed_at":        self.last_routed_at.isoformat() if self.last_routed_at else None,
            "route_hit_count":       self.route_hit_count,
            "build_seconds":         self.build_seconds,
        }


class PassportCalibration(CanonicalPrefixMixin, Base):
    """Industrialization Phase 9 -- calibration loop: EMA correction factor
    between the Phase-3 Query Passport's plan-time island-bytes estimate
    and the ACTUAL bytes scanned during execution (Trino/Presto
    History-Based-Optimization analogue).  An UNCALIBRATED cost model is a
    random number generator -- ``core.industrialization.calibration``
    blends this EMA toward neutral (1.0x, no correction) proportional to
    ``sample_count`` so a fresh table borrows the ``__global__`` row's
    correction until it earns its own history.

    Keyed by ``(bucket, table_prefix)`` only -- bytes-scanned-vs-estimated
    is a property of the TABLE/estimator, not of which venue executed the
    query, so venue is carried as an informational last-seen column, not
    part of the correction key.  ``spark_route_count`` / a Spark
    ``last_venue`` are the "estimator miss" instrumentation the plan asks
    for: every Spark route is a candidate worth reviewing (was the
    passport's size estimate why we went to Spark, and was it right?).

    Robust to outliers: ``core.industrialization.calibration`` only folds
    a sample into the EMA when its actual/estimate ratio falls inside a
    clamp band (``calibration_min_ratio``..``calibration_max_ratio``) -- a
    single cold-cache / proxy-hiccup run can't swing the estimator.

    Portable SQLite+PG: plain scalar columns, no JSON/JSONB anywhere.

    ALL reads/writes go through ``core.industrialization.calibration``
    (single chokepoint) -- do not query this table directly elsewhere.
    """
    __tablename__ = "passport_calibration"

    id                    = Column(Integer, primary_key=True, index=True)
    bucket                = Column(String(255), nullable=False, default="")
    table_prefix          = Column(String(512), nullable=False, default="")

    # EMA of actual_bytes / estimate_bytes; 1.0 = perfectly calibrated.
    bytes_ratio_ema        = Column(Float,   nullable=False, default=1.0)
    sample_count           = Column(Integer, nullable=False, default=0)

    # Diagnostics -- last folded sample.
    last_est_bytes          = Column(BigInteger, nullable=True)
    last_actual_bytes       = Column(BigInteger, nullable=True)
    last_venue               = Column(String(40), nullable=True)
    last_was_spark_route    = Column(Boolean, nullable=False, default=False)
    spark_route_count       = Column(Integer, nullable=False, default=0)

    first_seen_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    last_seen_at           = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                                     onupdate=lambda: datetime.now(timezone.utc),
                                     index=True)

    __table_args__ = (
        Index("ix_passport_calibration_lookup",
              "bucket", "table_prefix", unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                  self.id,
            "bucket":              self.bucket,
            "table_prefix":        self.table_prefix,
            "bytes_ratio_ema":     self.bytes_ratio_ema,
            "sample_count":        self.sample_count,
            "last_est_bytes":      self.last_est_bytes,
            "last_actual_bytes":   self.last_actual_bytes,
            "last_venue":          self.last_venue,
            "last_was_spark_route": bool(self.last_was_spark_route),
            "spark_route_count":   self.spark_route_count,
            "first_seen_at":       self.first_seen_at.isoformat() if self.first_seen_at else None,
            "last_seen_at":        self.last_seen_at.isoformat() if self.last_seen_at else None,
        }


class TableFavorite(Base):
    """User's favorited tables (any type: registered, MV, local, file)."""
    __tablename__ = "table_favorites"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    username      = Column(String(100), nullable=False, index=True)
    connection_id = Column(Integer, nullable=True)
    table_path    = Column(String(500), nullable=False)
    table_name    = Column(String(255), nullable=False)
    table_type    = Column(String(50), nullable=True)
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "username": self.username,
            "connection_id": self.connection_id,
            "table_path": self.table_path, "table_name": self.table_name,
            "table_type": self.table_type,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class NotificationLog(Base):
    """Persistent notification history with delivery tracking."""
    __tablename__ = "notification_log"

    id             = Column(Integer, primary_key=True, autoincrement=True)
    event_type     = Column(String(50), nullable=False, index=True)    # execution_completed, schedule_failed, etc.
    channel        = Column(String(20), nullable=False, index=True)    # websocket, email, webhook
    recipient      = Column(String(200), nullable=False, index=True)   # username, email addr, or webhook URL
    status         = Column(String(20), default="pending", index=True) # pending, sent, failed, delivered
    title          = Column(String(300), nullable=True)
    message        = Column(Text, nullable=True)
    payload        = Column(JSON, nullable=True)
    error_message  = Column(Text, nullable=True)
    attempt_count  = Column(Integer, default=0)
    max_attempts   = Column(Integer, default=3)
    execution_id   = Column(String(100), nullable=True, index=True)
    schedule_id    = Column(Integer, nullable=True)
    is_read        = Column(Integer, default=0)   # 0=unread, 1=read
    created_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    delivered_at   = Column(DateTime, nullable=True)
    read_at        = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "event_type": self.event_type,
            "channel": self.channel,
            "recipient": self.recipient,
            "status": self.status,
            "title": self.title,
            "message": self.message,
            "payload": self.payload,
            "error_message": self.error_message,
            "attempt_count": self.attempt_count,
            "execution_id": self.execution_id,
            "schedule_id": self.schedule_id,
            "is_read": bool(self.is_read),
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "delivered_at": self.delivered_at.isoformat() if self.delivered_at else None,
            "read_at": self.read_at.isoformat() if self.read_at else None,
        }


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 23: Enterprise Reporting Models (additive — existing models unchanged)
# ═══════════════════════════════════════════════════════════════════════════════


class ReportFolder(Base):
    """Folder for organizing reports into a hierarchy (23A)."""
    __tablename__ = "report_folders"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    name        = Column(String(255), nullable=False, index=True)
    description = Column(Text, nullable=True)
    parent_id   = Column(Integer, nullable=True, index=True)   # None = root folder
    icon        = Column(String(50),  nullable=True, default="folder")
    color       = Column(String(20),  nullable=True, default="#1976d2")
    created_by  = Column(String(100), nullable=True)
    created_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "name": self.name, "description": self.description,
            "parent_id": self.parent_id, "icon": self.icon or "folder",
            "color": self.color or "#1976d2", "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class ReportFolderAssignment(Base):
    """Maps a report to a folder. report_type discriminates parametric vs business (23A/58)."""
    __tablename__ = "report_folder_assignments"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    report_id   = Column(Integer, nullable=False, index=True)
    report_type = Column(String(20), nullable=False, default="business")  # "business" | "parametric" (legacy rows)
    folder_id   = Column(Integer, nullable=False, index=True)
    assigned_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        UniqueConstraint("report_id", "report_type", name="uq_folder_assign_report"),
    )


class ReportTag(Base):
    """Tag label for reports (23A)."""
    __tablename__ = "report_tags"

    id         = Column(Integer, primary_key=True, autoincrement=True)
    name       = Column(String(100), nullable=False, unique=True, index=True)
    color      = Column(String(20),  nullable=True, default="#666666")
    created_by = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "name": self.name, "color": self.color or "#666666",
                "created_by": self.created_by,
                "created_at": self.created_at.isoformat() if self.created_at else None}


class ReportTagAssignment(Base):
    """Many-to-many: report ↔ tag (23A/58)."""
    __tablename__ = "report_tag_assignments"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    report_id   = Column(Integer, nullable=False, index=True)
    report_type = Column(String(20), nullable=False, default="business")
    tag_id      = Column(Integer, nullable=False, index=True)


class ReportFavorite(Base):
    """User-level report favorite (23A/58)."""
    __tablename__ = "report_favorites"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    report_id   = Column(Integer, nullable=False, index=True)
    report_type = Column(String(20), nullable=False, default="business")
    username    = Column(String(100), nullable=False, index=True)
    created_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class ReportView(Base):
    """Recently-viewed tracker per user (23A/58). Kept at last N entries per user."""
    __tablename__ = "report_views"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    report_id   = Column(Integer, nullable=False, index=True)
    report_type = Column(String(20), nullable=False, default="business")
    username    = Column(String(100), nullable=False, index=True)
    viewed_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)


class RLSPolicy(Base):
    """DECOMMISSIONED (2026-09-26, F7 follow-up) — Phase 23G per-report RLS.

    Its docstring said "injected as extra WHERE at execution time"; nothing
    ever did.  The only reader was the preview route.  Row security is
    ``row_level_policies`` (core/row_security).  The routes and DB helpers
    are gone; the table stays declared (create_all never drops) and
    ``migrate_reports.py --export`` archives its rows.  Drop it with the
    legacy ``reports`` table.
    """
    __tablename__ = "rls_policies"

    id             = Column(Integer, primary_key=True, autoincrement=True)
    report_id      = Column(Integer, nullable=False, index=True)
    column_name    = Column(String(255), nullable=False)   # DB/Parquet column to filter
    # operator: = | != | IN | NOT IN | LIKE | >  < (for numeric ranges)
    operator       = Column(String(10),  nullable=False, default="=")
    # value_template: literal "sales" | token "{username}" | "{department}"
    value_template = Column(String(500), nullable=False)
    is_enabled     = Column(Boolean, default=True)
    description    = Column(String(500), nullable=True)
    created_by     = Column(String(100), nullable=True)
    created_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id,
            "column_name": self.column_name, "operator": self.operator,
            "value_template": self.value_template, "is_enabled": self.is_enabled,
            "description": self.description, "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class ReportBookmark(Base):
    """Named saved parameter set for a report, per user (23B)."""
    __tablename__ = "report_bookmarks"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    report_id    = Column(Integer, nullable=False, index=True)
    # 2026-09-26 (F7 follow-up): WHICH report family this row belongs to.
    # 'business' on every row written since the column existed (the ORM
    # default); NULL on rows written before it, which were written by the
    # legacy parametric routes and are what migrate_reports.py moves.  A
    # finance report and a legacy report share the numeric id space, so
    # report_id alone cannot say whose row this is -- this column can.
    report_type = Column(String(20), nullable=True, default="business")
    username     = Column(String(100), nullable=False, index=True)
    name         = Column(String(255), nullable=False)
    param_values = Column(JSON, nullable=False, default=dict)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id, "username": self.username,
            "name": self.name, "param_values": self.param_values or {},
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class ReportPDFConfig(Base):
    """PDF export layout configuration per report (23D)."""
    __tablename__ = "report_pdf_configs"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    # unique=True stays: the legacy row and the finance row of one id cannot
    # coexist here, so a finance pdf-config on an id that still carries a
    # legacy row is REFUSED (save_pdf_config) until the legacy row migrates.
    report_id     = Column(Integer, nullable=False, unique=True, index=True)
    # 2026-09-26 (F7 follow-up): WHICH report family this row belongs to.
    # 'business' on every row written since the column existed (the ORM
    # default); NULL on rows written before it, which were written by the
    # legacy parametric routes and are what migrate_reports.py moves.  A
    # finance report and a legacy report share the numeric id space, so
    # report_id alone cannot say whose row this is -- this column can.
    report_type = Column(String(20), nullable=True, default="business")
    orientation   = Column(String(20), default="landscape")   # landscape | portrait
    paper_size    = Column(String(10), default="A4")          # A4 | Letter | Legal
    include_cover = Column(Boolean, default=False)
    include_header = Column(Boolean, default=True)
    include_footer = Column(Boolean, default=True)
    logo_url      = Column(String(500), nullable=True)
    header_text   = Column(String(500), nullable=True)
    footer_text   = Column(String(500), nullable=True,
                           default="Generated by QueryStudio | Page {page} of {total}")
    font_size     = Column(Integer, default=11)
    max_rows      = Column(Integer, default=10000)
    updated_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                           onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "report_id": self.report_id, "orientation": self.orientation,
            "paper_size": self.paper_size, "include_cover": self.include_cover,
            "include_header": self.include_header, "include_footer": self.include_footer,
            "logo_url": self.logo_url, "header_text": self.header_text,
            "footer_text": self.footer_text, "font_size": self.font_size,
            "max_rows": self.max_rows,
        }


class BurstJob(Base):
    """Report burst job — distributes one report run per dimension value (23E)."""
    __tablename__ = "burst_jobs"

    id                = Column(Integer, primary_key=True, autoincrement=True)
    report_id         = Column(Integer, nullable=False, index=True)
    # 2026-09-26 (F7 follow-up): WHICH report family this row belongs to.
    # 'business' on every row written since the column existed (the ORM
    # default); NULL on rows written before it, which were written by the
    # legacy parametric routes and are what migrate_reports.py moves.  A
    # finance report and a legacy report share the numeric id space, so
    # report_id alone cannot say whose row this is -- this column can.
    report_type = Column(String(20), nullable=True, default="business")
    burst_column      = Column(String(255), nullable=False)      # column to split on
    base_params       = Column(JSON, nullable=True)              # shared params for all tasks
    output_format     = Column(String(10), default="pdf")        # pdf | excel | csv
    delivery_type     = Column(String(10), default="email")      # email | s3
    s3_prefix         = Column(String(500), nullable=True)       # "reports/{value}/"
    recipient_map     = Column(JSON, nullable=True)              # {"APAC": "apac@co.com", ...}
    default_recipient = Column(String(500), nullable=True)
    status            = Column(String(20), default="pending", index=True)
    total_tasks       = Column(Integer, default=0)
    done_tasks        = Column(Integer, default=0)
    failed_tasks      = Column(Integer, default=0)
    created_by        = Column(String(100), nullable=True)
    created_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    started_at        = Column(DateTime, nullable=True)
    completed_at      = Column(DateTime, nullable=True)
    error_message     = Column(Text, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id,
            "burst_column": self.burst_column, "base_params": self.base_params,
            "output_format": self.output_format, "delivery_type": self.delivery_type,
            "s3_prefix": self.s3_prefix, "recipient_map": self.recipient_map,
            "default_recipient": self.default_recipient, "status": self.status,
            "total_tasks": self.total_tasks, "done_tasks": self.done_tasks,
            "failed_tasks": self.failed_tasks, "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "error_message": self.error_message,
        }


class BurstTask(Base):
    """One task in a burst job — one row per distinct dimension value (23E)."""
    __tablename__ = "burst_tasks"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    burst_job_id    = Column(Integer, nullable=False, index=True)
    dimension_value = Column(String(500), nullable=False)   # e.g. "APAC", "Finance"
    recipient       = Column(String(500), nullable=True)    # email or S3 path
    output_file     = Column(String(500), nullable=True)
    status          = Column(String(20), default="pending", index=True)
    execution_id    = Column(String(100), nullable=True)
    error_message   = Column(Text, nullable=True)
    started_at      = Column(DateTime, nullable=True)
    completed_at    = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "burst_job_id": self.burst_job_id,
            "dimension_value": self.dimension_value, "recipient": self.recipient,
            "output_file": self.output_file, "status": self.status,
            "execution_id": self.execution_id, "error_message": self.error_message,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }


class AlertRule(Base):
    """Threshold alert rule on a report metric (23F)."""
    __tablename__ = "alert_rules"

    id                = Column(Integer, primary_key=True, autoincrement=True)
    report_id         = Column(Integer, nullable=False, index=True)
    # 2026-09-26 (F7 follow-up): WHICH report family this row belongs to.
    # 'business' on every row written since the column existed (the ORM
    # default); NULL on rows written before it, which were written by the
    # legacy parametric routes and are what migrate_reports.py moves.  A
    # finance report and a legacy report share the numeric id space, so
    # report_id alone cannot say whose row this is -- this column can.
    report_type = Column(String(20), nullable=True, default="business")
    name              = Column(String(255), nullable=False)
    column_name       = Column(String(255), nullable=False)
    aggregation       = Column(String(20), default="last")    # last | sum | avg | max | min | count
    operator          = Column(String(5),  nullable=False)    # > | < | >= | <= | = | !=
    threshold_value   = Column(Float, nullable=False)
    channels          = Column(JSON, nullable=False, default=list)  # ["email","slack"]
    recipients        = Column(Text, nullable=True)           # comma-separated emails
    slack_webhook     = Column(String(500), nullable=True)
    cooldown_minutes  = Column(Integer, default=60)
    is_enabled        = Column(Boolean, default=True)
    last_triggered_at = Column(DateTime, nullable=True)
    created_by        = Column(String(100), nullable=True)
    created_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id, "name": self.name,
            "column_name": self.column_name, "aggregation": self.aggregation,
            "operator": self.operator, "threshold_value": self.threshold_value,
            "channels": self.channels or [], "recipients": self.recipients,
            "slack_webhook": self.slack_webhook, "cooldown_minutes": self.cooldown_minutes,
            "is_enabled": self.is_enabled,
            "last_triggered_at": self.last_triggered_at.isoformat() if self.last_triggered_at else None,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class AlertHistory(Base):
    """Record of each alert trigger event (23F)."""
    __tablename__ = "alert_history"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    rule_id         = Column(Integer, nullable=False, index=True)
    triggered_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    actual_value    = Column(Float, nullable=True)
    threshold_value = Column(Float, nullable=True)
    channel         = Column(String(20), nullable=True)
    sent_to         = Column(String(500), nullable=True)
    was_suppressed  = Column(Boolean, default=False)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "rule_id": self.rule_id,
            "triggered_at": self.triggered_at.isoformat() if self.triggered_at else None,
            "actual_value": self.actual_value, "threshold_value": self.threshold_value,
            "channel": self.channel, "sent_to": self.sent_to,
            "was_suppressed": self.was_suppressed,
        }


class ConditionalFormatRule(Base):
    """Cell/row formatting rule per column on a report (23C)."""
    __tablename__ = "conditional_format_rules"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    report_id       = Column(Integer, nullable=False, index=True)
    # 2026-09-26 (F7 follow-up): WHICH report family this row belongs to.
    # 'business' on every row written since the column existed (the ORM
    # default); NULL on rows written before it, which were written by the
    # legacy parametric routes and are what migrate_reports.py moves.  A
    # finance report and a legacy report share the numeric id space, so
    # report_id alone cannot say whose row this is -- this column can.
    report_type = Column(String(20), nullable=True, default="business")
    column_name     = Column(String(255), nullable=False)
    rule_order      = Column(Integer, default=0)          # ascending priority
    # condition_type: value_range | equals | contains | not_null | is_null | top_n | bottom_n
    condition_type  = Column(String(30), nullable=False)
    condition_value = Column(JSON, nullable=True)         # {"min":0,"max":50} / {"text":"err"}
    bg_color        = Column(String(20), nullable=True)   # "#ff4444"
    text_color      = Column(String(20), nullable=True)   # "#ffffff"
    # icon: none | arrow_up | arrow_down | check | warning | danger | info
    icon            = Column(String(30), nullable=True, default="none")
    bold            = Column(Boolean, default=False)
    is_enabled      = Column(Boolean, default=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id, "column_name": self.column_name,
            "rule_order": self.rule_order, "condition_type": self.condition_type,
            "condition_value": self.condition_value, "bg_color": self.bg_color,
            "text_color": self.text_color, "icon": self.icon or "none",
            "bold": self.bold, "is_enabled": self.is_enabled,
        }


class CloudDeliveryConfig(Base):
    """Cloud storage delivery config per schedule (23H)."""
    __tablename__ = "cloud_delivery_configs"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    schedule_id     = Column(Integer, nullable=False, unique=True, index=True)
    provider        = Column(String(20), nullable=False)          # s3 | azure | gcs
    bucket          = Column(String(255), nullable=True)
    prefix_template = Column(String(500), nullable=True)          # "reports/{report_name}/{date}/"
    formats         = Column(JSON, nullable=False, default=list)  # ["pdf","excel","csv"]
    zip_bundle      = Column(Boolean, default=False)
    connection_id   = Column(Integer, nullable=True)              # reuse existing S3 connection creds
    is_enabled      = Column(Boolean, default=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "schedule_id": self.schedule_id, "provider": self.provider,
            "bucket": self.bucket, "prefix_template": self.prefix_template,
            "formats": self.formats or [], "zip_bundle": self.zip_bundle,
            "connection_id": self.connection_id, "is_enabled": self.is_enabled,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class DeliveryHistory(Base):
    """Log of every report delivery attempt (23H)."""
    __tablename__ = "delivery_history"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    schedule_id     = Column(Integer, nullable=True, index=True)
    burst_task_id   = Column(Integer, nullable=True, index=True)
    execution_id    = Column(String(100), nullable=True)
    delivery_type   = Column(String(20), nullable=False)   # email | s3 | azure | gcs | slack
    destination     = Column(String(500), nullable=True)
    file_format     = Column(String(10), nullable=True)    # pdf | excel | csv | zip
    file_size_bytes = Column(BigInteger, nullable=True)
    status          = Column(String(20), default="pending", index=True)
    error_message   = Column(Text, nullable=True)
    attempted_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    delivered_at    = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "schedule_id": self.schedule_id,
            "burst_task_id": self.burst_task_id, "execution_id": self.execution_id,
            "delivery_type": self.delivery_type, "destination": self.destination,
            "file_format": self.file_format, "file_size_bytes": self.file_size_bytes,
            "status": self.status, "error_message": self.error_message,
            "attempted_at": self.attempted_at.isoformat() if self.attempted_at else None,
            "delivered_at": self.delivered_at.isoformat() if self.delivered_at else None,
        }


class ConnectionProfile(Base):
    """Named environment profile for connection substitution (Phase 24B).

    One profile is active at a time. When active, its mappings redirect any
    matching connection to its target equivalent (e.g. dev_snowflake → prod_snowflake).
    """
    __tablename__ = "connection_profiles"

    id          = Column(Integer,     primary_key=True, autoincrement=True)
    name        = Column(String(255), nullable=False, unique=True, index=True)
    description = Column(Text,        nullable=True)
    is_active   = Column(Boolean,     default=False)
    created_by  = Column(String(100), nullable=True)
    created_at  = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at  = Column(DateTime,    default=lambda: datetime.now(timezone.utc),
                         onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":          self.id,
            "name":        self.name,
            "description": self.description,
            "is_active":   self.is_active,
            "created_by":  self.created_by,
            "created_at":  self.created_at.isoformat() if self.created_at else None,
            "updated_at":  self.updated_at.isoformat() if self.updated_at else None,
        }


class ConnectionProfileMapping(Base):
    """One source→target connection substitution rule within a ConnectionProfile (Phase 24B)."""
    __tablename__ = "connection_profile_mappings"

    id                   = Column(Integer, primary_key=True, autoincrement=True)
    profile_id           = Column(Integer, nullable=False, index=True)  # → ConnectionProfile.id
    source_connection_id = Column(Integer, nullable=False)              # → Connection.id (e.g. dev)
    target_connection_id = Column(Integer, nullable=False)              # → Connection.id (e.g. prod)
    description          = Column(String(500), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                   self.id,
            "profile_id":           self.profile_id,
            "source_connection_id": self.source_connection_id,
            "target_connection_id": self.target_connection_id,
            "description":          self.description,
        }


class Workspace(Base):
    """Named workspace / project for isolating team assets (Phase 25)."""
    __tablename__ = "workspaces"

    id          = Column(Integer,     primary_key=True, autoincrement=True)
    name        = Column(String(255), nullable=False, unique=True, index=True)
    slug        = Column(String(100), nullable=False, unique=True, index=True)
    description = Column(Text,        nullable=True)
    is_active   = Column(Boolean,     default=True)
    created_by  = Column(String(100), nullable=True)
    created_at  = Column(DateTime,    default=lambda: datetime.now(timezone.utc))
    updated_at  = Column(DateTime,    default=lambda: datetime.now(timezone.utc),
                         onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":          self.id,
            "name":        self.name,
            "slug":        self.slug,
            "description": self.description,
            "is_active":   self.is_active,
            "created_by":  self.created_by,
            "created_at":  self.created_at.isoformat() if self.created_at else None,
            "updated_at":  self.updated_at.isoformat() if self.updated_at else None,
        }


class WorkspaceMember(Base):
    """Member of a workspace with a role (Phase 25)."""
    __tablename__ = "workspace_members"

    id           = Column(Integer,     primary_key=True, autoincrement=True)
    workspace_id = Column(Integer,     nullable=False, index=True)  # → Workspace.id
    username     = Column(String(100), nullable=False, index=True)
    role         = Column(String(20),  nullable=False, default="member")  # owner/admin/member
    added_by     = Column(String(100), nullable=True)
    added_at     = Column(DateTime,    default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "workspace_id": self.workspace_id,
            "username":     self.username,
            "role":         self.role,
            "added_by":     self.added_by,
            "added_at":     self.added_at.isoformat() if self.added_at else None,
        }


class ScheduleRunStats(Base):
    """Per-run statistics for scheduled report anomaly detection (Phase 38)."""
    __tablename__ = "schedule_run_stats"

    id                = Column(Integer, primary_key=True, index=True)
    schedule_id       = Column(Integer, nullable=False, index=True)
    run_at            = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    row_count         = Column(BigInteger, default=0)
    execution_seconds = Column(Float, default=0.0)
    file_size_bytes   = Column(BigInteger, default=0)
    anomaly_type      = Column(String(50), nullable=True)    # null = normal
    anomaly_details   = Column(JSON, nullable=True)          # z_score, message, etc.

    def to_dict(self):
        return {
            "id": self.id,
            "schedule_id": self.schedule_id,
            "run_at": self.run_at.isoformat() if self.run_at else None,
            "row_count": self.row_count,
            "execution_seconds": self.execution_seconds,
            "file_size_bytes": self.file_size_bytes,
            "anomaly_type": self.anomaly_type,
            "anomaly_details": self.anomaly_details,
        }


class ExecutionCheckpoint(Base):
    """Checkpoint for in-progress query executions — survives server restarts (Phase 41)."""
    __tablename__ = "execution_checkpoints"
    execution_id = Column(String(36), primary_key=True)
    state = Column(String(20), nullable=False)  # "intent" | "running"
    query_config = Column(JSON, nullable=True)
    executed_by = Column(String(200), nullable=True)
    query_id = Column(Integer, nullable=True)
    timestamp = Column(Float, nullable=False)
    # 2026-08-02 multi-pod correctness: identity of the pod that OWNS this
    # execution (K8s pod name / hostname).  Startup recovery only reaps
    # checkpoints stamped with the recovering pod's own identity — before
    # this, EVERY pod boot (HPA scale-up, rolling deploy) marked every
    # in-flight execution across the whole fleet as failed.  Nullable +
    # additive: rows written by pre-change pods have NULL and are treated
    # as recoverable by any pod (exactly the old behaviour, so a rolling
    # deploy is never worse than before; converges once all pods upgrade).
    owner = Column(String(200), nullable=True)


class TableLineageEntry(Base):
    """Physical table referenced by a query — extracted via SQL parsing (Phase 49)."""
    __tablename__ = "table_lineage"

    id = Column(Integer, primary_key=True, index=True)
    query_type = Column(String(20), nullable=False, index=True)  # "sql_query" | "parquet_query" | "report"
    query_id = Column(Integer, nullable=False, index=True)
    connection_id = Column(Integer, nullable=True)
    table_catalog = Column(String(255), nullable=True)
    table_schema = Column(String(255), nullable=True)
    table_name = Column(String(255), nullable=False, index=True)
    access_type = Column(String(10), default="read")  # "read" | "write"
    extracted_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    extraction_method = Column(String(20), default="sqlglot")  # "sqlglot" | "regex_fallback"

    __table_args__ = (
        Index('ix_table_lineage_query', 'query_type', 'query_id'),
        Index('ix_table_lineage_table', 'table_catalog', 'table_schema', 'table_name'),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "query_type": self.query_type,
            "query_id": self.query_id,
            "connection_id": self.connection_id,
            "table_catalog": self.table_catalog,
            "table_schema": self.table_schema,
            "table_name": self.table_name,
            "access_type": self.access_type,
            "extracted_at": self.extracted_at.isoformat() if self.extracted_at else None,
            "extraction_method": self.extraction_method,
        }


class LineageSnapshot(Base):
    """Snapshot of lineage at query execution time (Phase 52)."""
    __tablename__ = "lineage_snapshots"

    id = Column(Integer, primary_key=True, index=True)
    execution_id = Column(String(36), nullable=False, index=True)
    query_type = Column(String(20), nullable=False, index=True)   # "sql_query" | "parquet_query"
    query_id = Column(Integer, nullable=False, index=True)
    snapshot_data = Column(Text, nullable=False)   # JSON blob of {tables, columns}
    captured_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)

    __table_args__ = (
        Index('ix_lineage_snapshot_query', 'query_type', 'query_id'),
    )

    def to_dict(self) -> Dict[str, Any]:
        try:
            data = json.loads(self.snapshot_data) if self.snapshot_data else {}
        except Exception:
            data = {}
        return {
            "id": self.id,
            "execution_id": self.execution_id,
            "query_type": self.query_type,
            "query_id": self.query_id,
            "snapshot_data": data,
            "captured_at": self.captured_at.isoformat() if self.captured_at else None,
        }


class DataFreshness(Base):
    """Per-table data freshness tracking (Phase 52)."""
    __tablename__ = "data_freshness"

    id = Column(Integer, primary_key=True, index=True)
    table_fqn = Column(String(512), nullable=False, index=True)  # catalog.schema.table or schema.table
    connection_id = Column(Integer, nullable=True)
    last_observed_at = Column(DateTime, nullable=True)   # last time a query read this table
    last_refresh_at = Column(DateTime, nullable=True)    # manually marked as refreshed
    freshness_status = Column(String(20), default="unknown")  # fresh | stale | unknown
    stale_threshold_hours = Column(Integer, default=24)

    __table_args__ = (
        Index('ix_data_freshness_lookup', 'table_fqn', 'connection_id', unique=True),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "table_fqn": self.table_fqn,
            "connection_id": self.connection_id,
            "last_observed_at": self.last_observed_at.isoformat() if self.last_observed_at else None,
            "last_refresh_at": self.last_refresh_at.isoformat() if self.last_refresh_at else None,
            "freshness_status": self.freshness_status,
            "stale_threshold_hours": self.stale_threshold_hours,
        }


class RestQueryDef(Base):
    """Saved REST API query definitions — each is a 'virtual table' for a REST connection (Phase 61)."""
    __tablename__ = "rest_query_defs"

    id = Column(Integer, primary_key=True, index=True)
    connection_id = Column(Integer, nullable=False, index=True)
    name = Column(String(255), nullable=False)
    description = Column(Text, nullable=True)
    http_method = Column(String(10), default="GET")
    endpoint_path = Column(String(1000), nullable=False)
    query_params = Column(JSON, nullable=True)
    request_body = Column(JSON, nullable=True)
    response_json_path = Column(String(500), default="")
    pagination_type = Column(String(20), default="none")
    pagination_config = Column(JSON, nullable=True)
    column_mapping = Column(JSON, nullable=True)
    created_by = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, onupdate=lambda: datetime.now(timezone.utc))
    is_active = Column(Boolean, default=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "connection_id": self.connection_id,
            "name": self.name,
            "description": self.description,
            "http_method": self.http_method,
            "endpoint_path": self.endpoint_path,
            "query_params": self.query_params,
            "request_body": self.request_body,
            "response_json_path": self.response_json_path,
            "pagination_type": self.pagination_type,
            "pagination_config": self.pagination_config,
            "column_mapping": self.column_mapping,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "is_active": self.is_active,
        }


class QueryUsageStat(Base):
    """Tracks table/column usage frequency for auto-suggest (Phase 46)."""
    __tablename__ = "query_usage_stats"

    id = Column(Integer, primary_key=True, index=True)
    object_type = Column(String(10), nullable=False, index=True)  # "table" | "column"
    object_name = Column(String(255), nullable=False, index=True)  # table name or "schema.table.column"
    table_name = Column(String(255), nullable=True, index=True)   # parent table (for columns)
    schema_name = Column(String(255), nullable=True)
    catalog_name = Column(String(255), nullable=True)
    connection_id = Column(Integer, nullable=True, index=True)
    use_count = Column(Integer, default=1)
    last_used_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_usage_stat_lookup', 'object_type', 'object_name', 'connection_id'),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "object_type": self.object_type,
            "object_name": self.object_name,
            "table_name": self.table_name,
            "schema_name": self.schema_name,
            "catalog_name": self.catalog_name,
            "connection_id": self.connection_id,
            "use_count": self.use_count,
            "last_used_at": self.last_used_at.isoformat() if self.last_used_at else None,
        }


class ColumnLineageEntry(Base):
    """Column-to-column lineage extracted from SQL (Phase 51)."""
    __tablename__ = "column_lineage"

    id = Column(Integer, primary_key=True, index=True)
    query_type = Column(String(20), nullable=False, index=True)   # "sql_query"
    query_id = Column(Integer, nullable=False, index=True)
    source_table = Column(String(255), nullable=True)
    source_column = Column(String(255), nullable=True)
    target_column = Column(String(255), nullable=False)
    transform_type = Column(String(20), default="direct")  # direct|renamed|computed|aggregated|casted|star_expansion
    transform_expr = Column(Text, nullable=True)
    extracted_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_col_lineage_query', 'query_type', 'query_id'),
        Index('ix_col_lineage_source', 'source_table', 'source_column'),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "query_type": self.query_type,
            "query_id": self.query_id,
            "source_table": self.source_table,
            "source_column": self.source_column,
            "target_column": self.target_column,
            "transform_type": self.transform_type,
            "transform_expr": self.transform_expr,
            "extracted_at": self.extracted_at.isoformat() if self.extracted_at else None,
        }


class NLFeedback(Base):
    """
    Stores user-confirmed NL→SQL pairs (thumbs-up feedback).
    The NL-to-SQL engine uses these as learned custom patterns.
    """
    __tablename__ = "nl_feedback"
    id           = Column(Integer, primary_key=True, autoincrement=True)
    question     = Column(String(500), nullable=False)
    sql          = Column(Text, nullable=False)
    connection_type = Column(String(50), default="duckdb")
    tables_hint  = Column(String(500), nullable=True)   # comma-separated table names used
    rating       = Column(Integer, default=1)            # 1 = thumbs-up, -1 = thumbs-down
    use_count    = Column(Integer, default=1)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                          onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self):
        return {
            "id": self.id,
            "question": self.question,
            "sql": self.sql,
            "connection_type": self.connection_type,
            "tables_hint": self.tables_hint,
            "rating": self.rating,
            "use_count": self.use_count,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class SuggestionCorrection(Base):
    """
    Stores user corrections to auto-suggested aggregation functions and join columns.

    correction_type = "agg":
      context_key   = column name (e.g. "trade_amount")
      original_value = originally suggested function (e.g. "SUM")
      corrected_value = user's chosen function (e.g. "AVG" or "COUNT_DISTINCT")
      context_extra = column DuckDB type

    correction_type = "join":
      context_key   = canonical sorted "left_table||right_table"
      original_value = "auto-matched" | "learned"
      corrected_value = JSON array of [{leftColumn, rightColumn}, ...]
      context_extra = connection_id as string
    """
    __tablename__ = "suggestion_corrections"

    id               = Column(Integer, primary_key=True, autoincrement=True)
    correction_type  = Column(String(10), nullable=False, index=True)
    context_key      = Column(String(500), nullable=False, index=True)
    original_value   = Column(Text, nullable=True)
    corrected_value  = Column(Text, nullable=False)
    context_extra    = Column(String(255), nullable=True)
    use_count        = Column(Integer, default=1)
    username         = Column(String(100), nullable=True)
    created_at       = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at       = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                              onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index('ix_sugg_corr_lookup', 'correction_type', 'context_key'),
    )

    def to_dict(self):
        return {
            "id": self.id,
            "correction_type": self.correction_type,
            "context_key": self.context_key,
            "original_value": self.original_value,
            "corrected_value": self.corrected_value,
            "context_extra": self.context_extra,
            "use_count": self.use_count,
            "username": self.username,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class UIComponentVisibility(Base):
    """
    Controls which UI pages/components are enabled per role.
    Defaults to all enabled; only explicit False rows disable a component.
    """
    __tablename__ = "ui_component_visibility"
    id             = Column(Integer, primary_key=True, autoincrement=True)
    component_key  = Column(String(100), nullable=False)   # e.g. "sql_editor"
    role           = Column(String(50),  nullable=False)   # admin / analyst / viewer
    enabled        = Column(Boolean, default=True, nullable=False)
    __table_args__ = (UniqueConstraint("component_key", "role", name="uq_ucv_key_role"),)

    def to_dict(self):
        return {
            "component_key": self.component_key,
            "role":          self.role,
            "enabled":       self.enabled,
        }


###############################################################################
# Phase 53 — Semantic Layer Models (BO Universe Equivalent)
###############################################################################

class BusinessDataset(Base):
    """A curated business subject (e.g. 'Sales', 'Orders') that abstracts
    physical tables into a friendly, role-aware semantic layer."""
    __tablename__ = "business_datasets"

    id             = Column(Integer, primary_key=True, autoincrement=True)
    name           = Column(String(200), nullable=False, unique=True)
    description    = Column(Text, default="")
    subject        = Column(String(100), nullable=False, index=True)   # Sales, HR, Finance, etc.
    owner          = Column(String(100), default="admin")              # creator username
    connection_ids = Column(JSON, nullable=False, default=list)        # list of connection IDs used
    source_tables  = Column(JSON, nullable=False, default=list)        # [{"connection_id":1, "table":"s3://bucket/file.parquet", "alias":"orders"}]
    base_query     = Column(Text, default="")                          # optional custom SQL for advanced users
    is_published   = Column(Boolean, default=False, nullable=False)    # visible to business users?
    # 2026-08-09 dataset self-service — group-based ownership parity with
    # BusinessReport.owner_group_id (Phase 131 deep-dive #10 pattern).  Any
    # user_group_members entry for this group grants owner-equivalent edit
    # rights on this dataset (subject to resource_access_level, resolved by
    # core.entitlements).  NULL = single-owner only.  Nullable so
    # auto-migrate on existing installs adds the column without a
    # server_default — the explicit _MIGRATIONS entry in core/database.py
    # covers every dialect.
    owner_group_id = Column(Integer, nullable=True, index=True)
    # 2026-08-09 dataset self-service — certification governance (mirrors
    # business_reports Phase 85 columns).  Self-service invites many private
    # datasets; certification is the ADMIN-issued signal that marks the few
    # models the org should standardize on (the anti-sprawl lever both
    # Power BI "endorsed/certified datasets" and Tableau "certified data
    # sources" converged on).  Only admins may flip it.
    is_certified   = Column(Boolean, default=False, nullable=False)
    certified_by   = Column(String(100), nullable=True)
    certified_at   = Column(DateTime, nullable=True)
    # 2026-09-05 progressive partition loading — the DATASET-level scan
    # declaration.  The table lane can hang this off the ``source_tables``
    # entry it describes, but a SQL-mode dataset has a ``base_query`` and
    # an EMPTY ``source_tables``, so that lane had NO home for it and a
    # custom-SQL dataset over a huge Starburst table — precisely the case
    # progressive loading exists for — could never declare a partition
    # column.  Dataset-level is also the scope the refusal rule has always
    # named: "one dataset has one partition plan".
    #
    # Nullable, and a new COLUMN does not self-create on this platform
    # (alembic is never invoked at runtime), so the explicit _MIGRATIONS
    # entry in core/database.py is what makes it exist on a deployed pod.
    partition_config = Column(JSON, nullable=True)
    # FB-49 (2026-09-20) -- the browser URL is /datasets/<slug>/query; the
    # REST API keeps the numeric id (every other dataset route, every
    # report's stored dataset_id, and every external consumer holds one).
    # Same contract as BusinessReport.slug: assigned ONCE at create
    # (core.slugs.unique_slug), NOT moved by a rename -- a URL that has been
    # pasted into a ticket must keep resolving.  Nullable because the column
    # ships to a table with rows; _ensure_dataset_slugs backfills and then
    # creates the unique index.  A new COLUMN does not self-create on this
    # platform, so the _MIGRATIONS entry in core/database.py is what makes
    # it exist on a deployed pod.
    slug           = Column(String(220), nullable=True, index=True)
    created_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                            onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "slug": self.slug,   # FB-49: every UI link is /datasets/<slug>/query
            "name": self.name,
            "description": self.description,
            "subject": self.subject,
            "owner": self.owner,
            "owner_group_id": self.owner_group_id,
            "connection_ids": self.connection_ids or [],
            "source_tables": self.source_tables or [],
            "base_query": self.base_query or "",
            # ``None`` when nothing is declared, never ``{}``: an empty
            # object reads as "declared, and empty", which is a third
            # answer nobody means.  Every reader treats both as
            # not-declared, and the wire says which one it is.
            "partition_config": self.partition_config or None,
            "is_published": self.is_published,
            "is_certified": bool(self.is_certified),
            "certified_by": self.certified_by,
            "certified_at": self.certified_at.isoformat() if self.certified_at else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class DatasetClass(Base):
    """Logical grouping of columns within a dataset (BO Universe Classes).
    E.g. 'Customer', 'Time', 'Product' — organises dimensions and measures."""
    __tablename__ = "dataset_classes"

    id         = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id = Column(Integer, nullable=False, index=True)
    name       = Column(String(200), nullable=False)           # e.g. "Customer"
    label      = Column(String(200), default="")               # display label
    icon       = Column(String(50), default="")                # optional MUI icon name
    sort_order = Column(Integer, default=0)
    __table_args__ = (
        UniqueConstraint("dataset_id", "name", name="uq_dsclass_ds_name"),
        Index("ix_dsclass_dataset", "dataset_id"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "name": self.name,
            "label": self.label or self.name,
            "icon": self.icon or "",
            "sort_order": self.sort_order,
        }


class DatasetColumn(Base):
    """A column in a business dataset — maps physical column to friendly name
    with dimension/measure/detail/kpi classification."""
    __tablename__ = "dataset_columns"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id      = Column(Integer, nullable=False, index=True)
    class_id        = Column(Integer, nullable=True)             # FK to DatasetClass.id (optional)
    physical_name   = Column(String(300), nullable=False)        # actual column name in source
    friendly_name   = Column(String(300), nullable=False)        # display label for business users
    column_type     = Column(String(20), nullable=False, default="dimension")  # dimension|measure|detail|kpi
    data_type       = Column(String(50), default="string")       # string|number|date|boolean
    aggregation     = Column(String(30), default="")             # sum|avg|count|min|max|count_distinct (for measures)
    format_pattern  = Column(String(100), default="")            # e.g. "$#,##0.00", "#,##0", "YYYY-MM-DD"
    description     = Column(Text, default="")
    synonyms        = Column(JSON, default=list)                 # ["revenue", "sales_amount", "net_rev"]
    role_whitelist  = Column(JSON, default=list)                 # [] = all roles; ["admin","analyst"] = restricted
    sort_order      = Column(Integer, default=0)
    is_hidden       = Column(Boolean, default=False, nullable=False)
    __table_args__ = (
        UniqueConstraint("dataset_id", "physical_name", name="uq_dscol_ds_phys"),
        Index("ix_dscol_dataset", "dataset_id"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "class_id": self.class_id,
            "physical_name": self.physical_name,
            "friendly_name": self.friendly_name,
            "column_type": self.column_type,
            "data_type": self.data_type,
            "aggregation": self.aggregation or "",
            "format_pattern": self.format_pattern or "",
            "description": self.description or "",
            "synonyms": self.synonyms or [],
            "role_whitelist": self.role_whitelist or [],
            "sort_order": self.sort_order,
            "is_hidden": self.is_hidden,
        }


class CalculatedMetric(Base):
    """A reusable calculated metric attached to a business dataset.
    SQL expression evaluated at query time by the federation engine."""
    __tablename__ = "calculated_metrics"

    id             = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id     = Column(Integer, nullable=False, index=True)
    name           = Column(String(200), nullable=False)
    expression     = Column(Text, nullable=False)          # e.g. "SUM(amount) / COUNT(DISTINCT customer_id)"
    description    = Column(Text, default="")
    format_pattern = Column(String(100), default="")       # e.g. "$#,##0.00"
    data_type      = Column(String(50), default="number")  # number|string|date
    depends_on     = Column(JSON, default=list)             # [physical_name, ...] for lineage
    is_active      = Column(Boolean, default=True, nullable=False)
    owner          = Column(String(100), default="system")
    created_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    __table_args__ = (
        UniqueConstraint("dataset_id", "name", name="uq_calcmet_ds_name"),
        Index("ix_calcmet_dataset", "dataset_id"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "name": self.name,
            "expression": self.expression,
            "description": self.description or "",
            "format_pattern": self.format_pattern or "",
            "data_type": self.data_type or "number",
            "depends_on": self.depends_on or [],
            "is_active": self.is_active,
            "owner": self.owner or "system",
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class DatasetRelationship(Base):
    """Defines how two datasets (or source tables within a dataset) join.
    Inspired by BO Universe joins."""
    __tablename__ = "dataset_relationships"

    id               = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id       = Column(Integer, nullable=False, index=True)
    left_table       = Column(String(300), nullable=False)       # alias or table ref
    right_table      = Column(String(300), nullable=False)
    join_type        = Column(String(20), default="inner")       # inner|left|right|full
    join_keys        = Column(JSON, nullable=False, default=list)  # [{"left":"order_id","right":"id"}]
    cardinality      = Column(String(20), default="many_to_one") # one_to_one|one_to_many|many_to_one|many_to_many

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "left_table": self.left_table,
            "right_table": self.right_table,
            "join_type": self.join_type,
            "join_keys": self.join_keys or [],
            "cardinality": self.cardinality,
        }


class DrillHierarchy(Base):
    """Drill-down hierarchy (e.g. Year → Quarter → Month → Day).
    Tableau-style click-to-expand in business reports."""
    __tablename__ = "drill_hierarchies"

    id         = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id = Column(Integer, nullable=False, index=True)
    name       = Column(String(200), nullable=False)                  # "Time Hierarchy"
    levels     = Column(JSON, nullable=False, default=list)           # [{"column_id":1,"label":"Year"},{"column_id":2,"label":"Quarter"},...]
    __table_args__ = (
        UniqueConstraint("dataset_id", "name", name="uq_drill_ds_name"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "name": self.name,
            "levels": self.levels or [],
        }


class PreDefinedCondition(Base):
    """Reusable WHERE-clause snippets business users can drag into a report
    filter panel (BO pre-defined condition equivalent)."""
    __tablename__ = "predefined_conditions"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id  = Column(Integer, nullable=False, index=True)
    name        = Column(String(200), nullable=False)             # "This Year", "Active Customers Only"
    label       = Column(String(200), default="")
    description = Column(Text, default="")
    where_clause = Column(Text, nullable=False)                   # SQL snippet e.g. "YEAR(order_date) = YEAR(CURRENT_DATE)"
    sort_order  = Column(Integer, default=0)
    __table_args__ = (
        UniqueConstraint("dataset_id", "name", name="uq_predef_ds_name"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "name": self.name,
            "label": self.label or self.name,
            "description": self.description or "",
            "where_clause": self.where_clause,
            "sort_order": self.sort_order,
        }


class AggregationAwareness(Base):
    """Maps a measure to a pre-aggregated table.  When the report requests
    this measure at a compatible grain, the engine uses the pre-agg table
    instead of scanning raw data."""
    __tablename__ = "aggregation_awareness"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id      = Column(Integer, nullable=False, index=True)
    measure_col_id  = Column(Integer, nullable=False)            # FK to DatasetColumn.id
    agg_table       = Column(String(300), nullable=False)        # pre-aggregated table/parquet path
    agg_dimensions  = Column(JSON, nullable=False, default=list) # dimensions already rolled up in agg_table
    connection_id   = Column(Integer, nullable=True)             # connection for the agg table
    is_enabled      = Column(Boolean, default=True, nullable=False)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "measure_col_id": self.measure_col_id,
            "agg_table": self.agg_table,
            "agg_dimensions": self.agg_dimensions or [],
            "connection_id": self.connection_id,
            "is_enabled": self.is_enabled,
        }


class FederationExecution(Base):
    """Tracks federated dataset query executions for audit and history."""
    __tablename__ = "federation_executions"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    execution_id    = Column(String(100), nullable=False, unique=True, index=True)
    dataset_id      = Column(Integer, nullable=False, index=True)
    merged_dataset_id = Column(Integer, nullable=True)          # set for merged queries
    # 2026-09-15: the business report this execution was run FOR (NULL for a
    # dataset-level run and for rows written before the column existed).
    # /results/{exec_id} binds the URL's report to it; a new COLUMN does not
    # self-create -- see DatabaseManager._MIGRATIONS["federation_executions"].
    report_id       = Column(Integer, nullable=True)
    sql_generated   = Column(Text, nullable=False, default="")
    column_ids      = Column(JSON, nullable=False, default=list)  # selected column IDs
    filters         = Column(JSON, nullable=False, default=list)
    condition_ids   = Column(JSON, nullable=False, default=list)
    output_path     = Column(String(500), nullable=True)
    total_rows      = Column(BigInteger, default=0)
    duration_seconds = Column(Float, default=0.0)
    status          = Column(String(20), nullable=False, default="running")  # running | completed | failed
    error_message   = Column(Text, nullable=True)
    executed_by     = Column(String(100), nullable=True)
    sources_used    = Column(JSON, nullable=False, default=list)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "execution_id": self.execution_id,
            "dataset_id": self.dataset_id,
            "merged_dataset_id": self.merged_dataset_id,
            "report_id": self.report_id,
            "sql_generated": self.sql_generated,
            "column_ids": self.column_ids or [],
            "filters": self.filters or [],
            "condition_ids": self.condition_ids or [],
            "output_path": self.output_path,
            "total_rows": self.total_rows,
            "duration_seconds": self.duration_seconds,
            "status": self.status,
            "error_message": self.error_message,
            "executed_by": self.executed_by,
            "sources_used": self.sources_used or [],
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class MergedDimension(Base):
    """Defines how two datasets are merged on shared dimensions (BO-style merge).

    When a business report uses two datasets, MergedDimension records declare
    which columns from each dataset form the merge key."""
    __tablename__ = "merged_dimensions"

    id                  = Column(Integer, primary_key=True, autoincrement=True)
    primary_dataset_id  = Column(Integer, nullable=False, index=True)
    secondary_dataset_id = Column(Integer, nullable=False, index=True)
    name                = Column(String(200), nullable=False)
    merge_keys          = Column(JSON, nullable=False, default=list)  # [{"left":"col","right":"col"}]
    merge_type          = Column(String(20), nullable=False, default="inner")  # inner|left|right|full
    is_active           = Column(Boolean, default=True, nullable=False)
    created_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        UniqueConstraint("primary_dataset_id", "secondary_dataset_id", "name",
                         name="uq_merged_dimension"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "primary_dataset_id": self.primary_dataset_id,
            "secondary_dataset_id": self.secondary_dataset_id,
            "name": self.name,
            "merge_keys": self.merge_keys or [],
            "merge_type": self.merge_type,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class AggCacheEntry(Base):
    """Pre-computed aggregation rollup parquet for sub-second query serving.

    Inspired by BO Aggregate Awareness (transparent routing to coarsest-grain
    pre-agg table), Power BI VertiPaq (pre-loaded compressed data), and Tableau
    Extracts (scheduled refresh with incremental option).

    Cache lifecycle:  pending → building → ready → stale → expired / failed
      - stale: past soft TTL but still serveable (serve + trigger background refresh)
      - expired: past hard expiry, must rebuild (never served)
    """
    __tablename__ = "agg_cache_entries"

    id                  = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id          = Column(Integer, nullable=False, index=True)
    name                = Column(String(200), nullable=False)
    description         = Column(Text, default="")

    # What this cache covers
    dimension_col_ids   = Column(JSON, nullable=False, default=list)   # [DatasetColumn.id, ...]
    measure_col_ids     = Column(JSON, nullable=False, default=list)   # [DatasetColumn.id, ...]
    grain_label         = Column(String(50), default="custom")         # yearly|quarterly|monthly|weekly|daily|custom
    condition_ids       = Column(JSON, nullable=False, default=list)   # pre-defined condition IDs baked in

    # Physical storage
    file_path           = Column(String(500), nullable=True)
    file_size_bytes     = Column(BigInteger, default=0)
    row_count           = Column(BigInteger, default=0)

    # Lifecycle
    status              = Column(String(20), default="pending")        # pending|building|ready|stale|expired|failed
    last_built_at       = Column(DateTime, nullable=True)
    last_served_at      = Column(DateTime, nullable=True)
    expires_at          = Column(DateTime, nullable=True)              # hard expiry
    stale_at            = Column(DateTime, nullable=True)              # soft expiry
    error_message       = Column(Text, nullable=True)
    build_duration_seconds = Column(Float, default=0.0)

    # Scheduling
    schedule_config     = Column(JSON, nullable=True)                  # {"type":"cron","cron_expr":"0 2 * * *"}
    is_enabled          = Column(Boolean, default=True, nullable=False)

    # Incremental refresh (Tableau-style)
    incremental_enabled = Column(Boolean, default=False, nullable=False)
    incremental_column  = Column(String(200), nullable=True)
    incremental_last_value = Column(String(500), nullable=True)

    # Stats
    hit_count           = Column(Integer, default=0)
    miss_count          = Column(Integer, default=0)

    # Phase 5 RLS-aware cubes (2026-08-09, target architecture §3.3).
    # All nullable/additive — legacy rows read back as NULL, which the serve
    # path treats as "open" (today's semantics: never served to an
    # RLS-scoped caller).  NOTE: matching entries exist in
    # core/database.py _MIGRATIONS["agg_cache_entries"] (house rule).
    #   rls_mode: None/"open"  — unscoped cube, today's semantics
    #             "security_dims" — policy-referenced columns baked into the
    #                               grain; served to scoped callers with the
    #                               caller's resolved predicates as a WHERE
    #             "scoped"        — built under ONE resolved scope; served
    #                               only on exact rls_signature equality
    rls_mode                   = Column(String(20), nullable=True)
    # DatasetColumn ids of the policy-referenced columns added to the
    # cube's GROUP BY (security dimensions) — separate from
    # dimension_col_ids so subset-routing semantics stay unchanged.
    security_dimension_col_ids = Column(JSON, nullable=True)
    # core.identity.rls_predicates.compute_policy_fingerprint at build time.
    # Serve-time equality with the CURRENT fingerprint is the drift GATE.
    policy_version             = Column(String(80), nullable=True)
    # core.row_security.signature.scope_signature — "scoped" mode only.
    rls_signature              = Column(String(80), nullable=True)

    created_by          = Column(String(100), default="admin")
    created_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                                 onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        UniqueConstraint("dataset_id", "name", name="uq_aggcache_ds_name"),
        Index("ix_aggcache_dataset_status", "dataset_id", "status"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "name": self.name,
            "description": self.description or "",
            "dimension_col_ids": self.dimension_col_ids or [],
            "measure_col_ids": self.measure_col_ids or [],
            "grain_label": self.grain_label,
            "condition_ids": self.condition_ids or [],
            "file_path": self.file_path,
            "file_size_bytes": self.file_size_bytes,
            "row_count": self.row_count,
            "status": self.status,
            "last_built_at": self.last_built_at.isoformat() if self.last_built_at else None,
            "last_served_at": self.last_served_at.isoformat() if self.last_served_at else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "stale_at": self.stale_at.isoformat() if self.stale_at else None,
            "error_message": self.error_message,
            "build_duration_seconds": self.build_duration_seconds,
            "schedule_config": self.schedule_config,
            "is_enabled": self.is_enabled,
            "incremental_enabled": self.incremental_enabled,
            "incremental_column": self.incremental_column,
            "incremental_last_value": self.incremental_last_value,
            "hit_count": self.hit_count or 0,
            "miss_count": self.miss_count or 0,
            "rls_mode": self.rls_mode,
            "security_dimension_col_ids": self.security_dimension_col_ids or [],
            "policy_version": self.policy_version,
            "rls_signature": self.rls_signature,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class AggCacheSuggestion(Base):
    """Auto-generated suggestion for a new agg cache based on query usage patterns.

    The usage analysis engine examines FederationExecution history to find
    frequently-used dimension+measure combos and creates suggestions that an
    admin can approve (creating an AggCacheEntry) or reject."""
    __tablename__ = "agg_cache_suggestions"

    id                  = Column(Integer, primary_key=True, autoincrement=True)
    dataset_id          = Column(Integer, nullable=False, index=True)
    dimension_col_ids   = Column(JSON, nullable=False, default=list)
    measure_col_ids     = Column(JSON, nullable=False, default=list)
    query_count         = Column(Integer, default=0)
    estimated_speedup   = Column(Float, default=0.0)
    status              = Column(String(20), default="pending")        # pending|approved|rejected|implemented
    created_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    reviewed_by         = Column(String(100), nullable=True)
    reviewed_at         = Column(DateTime, nullable=True)

    __table_args__ = (
        Index("ix_aggsuggest_dataset", "dataset_id"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dataset_id": self.dataset_id,
            "dimension_col_ids": self.dimension_col_ids or [],
            "measure_col_ids": self.measure_col_ids or [],
            "query_count": self.query_count,
            "estimated_speedup": self.estimated_speedup,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "reviewed_by": self.reviewed_by,
            "reviewed_at": self.reviewed_at.isoformat() if self.reviewed_at else None,
        }


class BusinessReport(Base):
    """Wizard-defined business report using semantic layer datasets.

    Stores the full report definition: selected columns, filters, conditions,
    section breaks with subtotals, running calculations (RunningSum, Rank,
    PercentOfTotal, PreviousValue), slicer columns, and drill hierarchy.
    Executed via FederationEngine; all post-query computations happen client-side.
    """
    __tablename__ = "business_reports"

    id                  = Column(Integer, primary_key=True, autoincrement=True)
    name                = Column(String(200), nullable=False)
    # 2026-09-20 -- the browser URL is /finance-reports/<slug>; the REST API
    # keeps the numeric id.  Assigned ONCE at create (core.slugs.unique_slug:
    # the name slugified, numeric suffix only on collision) and NOT moved by
    # a rename: a URL that changes under a bookmark or a share link is worse
    # than a URL that no longer matches the title.  Nullable so the ALTER
    # ships to a table with rows; _ensure_report_slugs backfills and then
    # creates the unique index.
    slug                = Column(String(220), nullable=True, index=True)
    description         = Column(Text, default="")
    dataset_id          = Column(Integer, nullable=False, index=True)
    merged_dataset_id          = Column(Integer, nullable=True)
    merge_config               = Column(JSON, nullable=True)          # {merge_keys, merge_type}
    merged_dataset_column_ids  = Column(JSON, nullable=True)          # Phase 81: [DatasetColumn.id, ...] from secondary dataset

    # Query definition
    column_ids          = Column(JSON, nullable=False, default=list)   # [DatasetColumn.id, ...]
    filter_specs        = Column(JSON, nullable=False, default=list)   # [{column_id, operator, value}]
    condition_ids       = Column(JSON, nullable=False, default=list)   # [PreDefinedCondition.id, ...]
    order_by            = Column(JSON, nullable=False, default=list)   # [{column_id, direction}]
    row_limit           = Column(Integer, default=50000)

    # Report layout
    section_definitions = Column(JSON, nullable=False, default=list)   # [{name, break_column_id, subtotal_measure_ids, show_count}]
    running_calculations = Column(JSON, nullable=False, default=list)  # [{name, calc_type, measure_col_id, partition_col_id, format_pattern}]
    slicer_column_ids   = Column(JSON, nullable=False, default=list)   # [col_id, ...]
    drill_hierarchy_id  = Column(Integer, nullable=True)
    layout_config       = Column(JSON, nullable=True)                  # {chart_type, pivot_config, column_widths}

    # Access control
    is_published        = Column(Boolean, default=False, nullable=False)
    #: 2026-09-18 -- a SAMPLE/demo report.  Hidden from the list by default so
    #: seeded demos and probe reports do not bury the real ones; the UI has a
    #: "Show samples" toggle.  A DECLARED flag rather than a name pattern:
    #: a pattern would hide a real report called "sample_pnl" and miss a demo
    #: called "q3".  Declared in database.py::_MIGRATIONS too -- a new TABLE
    #: self-creates, a new COLUMN does not.
    is_sample           = Column(Boolean, default=False, nullable=False,
                                 server_default=sa_false())
    # Publish lifecycle (2026-08-17) — draft | published | archived |
    # deprecated.  NULLABLE so auto-migrate adds the column to existing
    # installs without a server_default; NULL is DERIVED at read time
    # ("published" when is_published else "draft") so no backfill is needed
    # and a deploy that never runs the alembic migration behaves exactly as
    # before.  ``is_published`` stays the compat/visibility field every
    # existing query filters on; archived/deprecated do NOT flip it (direct
    # id stays resolvable for audit) — the listing chokepoints exclude them
    # from the published bucket instead.
    lifecycle_status    = Column(String(20), nullable=True)
    owner               = Column(String(100), nullable=False)
    role_whitelist      = Column(JSON, nullable=True)                  # ["viewer","analyst"]
    # Phase 131 deep-dive #10 — group-based ownership parity with
    # Report / FeedConfig / PublishedView.  Any user_group_members entry
    # for this group grants owner-equivalent permissions on this report
    # (rerun, edit, share, schedule).  NULL = single-owner only (legacy
    # behaviour preserved).  Nullable so auto-migrate on existing
    # SQLite installs adds the column without server_default.
    owner_group_id      = Column(Integer, nullable=True, index=True)

    # Phase 2 report-instance layer (2026-08-09, target arch §5.3) — BO
    # "Refresh When Open" parity.  False/NULL (default) = an open may serve
    # the latest matching ReportInstance when instance serving is enabled;
    # True = always execute on open (for reports whose freshness demands
    # it).  Nullable so auto-migrate on existing installs adds the column
    # without a server_default; the explicit _MIGRATIONS entry in
    # core/database.py carries "BOOLEAN DEFAULT 0" for every dialect.
    refresh_on_open     = Column(Boolean, nullable=True, default=False)

    # Stats
    execution_count     = Column(Integer, default=0)
    last_executed_at    = Column(DateTime, nullable=True)

    # Phase 58: Certification & Catalog
    is_certified        = Column(Boolean, default=False, nullable=False)
    certified_by        = Column(String(100), nullable=True)
    certified_at        = Column(DateTime, nullable=True)
    template_category   = Column(String(100), nullable=True, index=True)
    cloned_from_id      = Column(Integer, nullable=True)

    # Phase 93: Federation View data source / Phase 100: Published View data source
    data_source_type    = Column(String(30), default="saved_query", nullable=False)  # "saved_query" | "federation_view" | "published_view" | "raw_sql"
    federation_view_id  = Column(Integer, nullable=True)  # FK → federation_views.id
    published_view_id   = Column(Integer, nullable=True)  # Phase 100: FK → published_views.id

    # Phase 111: raw_sql source type (parametric report unification)
    # Only populated when data_source_type == "raw_sql"
    raw_saved_query_id      = Column(Integer, nullable=True)   # → saved_queries.id (parquet path)
    raw_sql_saved_query_id  = Column(Integer, nullable=True)   # → sql_saved_queries.id (SQL connector path)
    raw_sql_file_id         = Column(Integer, nullable=True)   # → sql_files.id (.sql file backing — Phase 131 deep-dive #13)
    raw_sql_override        = Column(Text,    nullable=True)   # inline SQL override
    raw_parameters_schema   = Column(JSON,    nullable=True)   # inline param schema [{name, label, type, required, default_value, options}]
    raw_schedule_config     = Column(JSON,    nullable=True)   # inline schedule {cron, recipients, format, enabled}
    raw_connection_override_id = Column(Integer, nullable=True)  # connection override for SQL reports
    legacy_report_id        = Column(Integer, nullable=True)   # original reports.id before migration (for audit trail)

    # ── Cross-CONNECTION overrides (2026-08-11) ────────────────────────────
    # A ``.sql`` file backing this report may itself be cross-connection: it
    # carries the ``-- ===SECONDARY===`` section plus
    # sql_files.secondary_connection_id / combine_mode / join_config.  THE
    # FILE IS THE SOURCE OF TRUTH; these three columns OVERRIDE it per report,
    # exactly as raw_connection_override_id overrides the file's primary
    # connection.  NULL = inherit from the file.
    #
    # Names deliberately mirror ``sql_files`` and ``feed_configs`` so a
    # cross-connection report and a cross-source feed read the same way.
    # join_config is JSON in the model, so it MUST be declared "JSON" in
    # _MIGRATIONS — PostgreSQL has no json->text assignment cast.
    secondary_connection_id = Column(Integer, nullable=True)
    combine_mode            = Column(String(20), nullable=True)  # 'union' | 'join'
    join_config             = Column(JSON, nullable=True)        # {how, left_on, right_on, suffixes}

    # 2026-10-17 -- the report's EXTERNAL-API lifecycle (core/published_api/
    # lifecycle.py; the report reached by embed / share tokens is the
    # published_report kind of the inventory).  Distinct from lifecycle_status
    # above, the INTERNAL publish lifecycle (draft / published / archived).
    # NULL = derived: active when published, retired otherwise.
    api_lifecycle_status     = Column(String(12), nullable=True)
    api_sunset_at            = Column(DateTime, nullable=True)
    api_deprecation_note     = Column(Text, nullable=True)
    api_successor            = Column(String(220), nullable=True)
    api_lifecycle_changed_by = Column(String(100), nullable=True)
    api_lifecycle_changed_at = Column(DateTime, nullable=True)

    created_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                                 onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        UniqueConstraint("name", "owner", name="uq_business_report_name_owner"),
        Index("ix_business_report_dataset", "dataset_id"),
        Index("ix_business_report_owner", "owner"),
        # 2026-08-09 metadata-scale audit finding 5 — the paginated list
        # (finding 1) filters on is_published and keyset-sorts on
        # (updated_at, id); without these every page is a full scan at 100k
        # rows.  Existing deployments get them via the fail-open index
        # migrations in core/database.py (_apply_sqlite_migrations /
        # _apply_postgresql_migrations) — keep both in sync.
        Index("ix_business_reports_updated_at", "updated_at"),
        Index("ix_business_reports_name", "name"),
        Index("ix_business_reports_published_updated", "is_published", "updated_at"),
        Index("ix_business_reports_owner_updated", "owner", "updated_at"),
    )

    def to_summary_dict(self) -> Dict[str, Any]:
        """LIST projection (2026-08-09, metadata-scale audit finding 1).

        ``to_dict()`` is a DETAIL payload — ~35 fields including
        ``filter_specs``, ``section_definitions``, ``layout_config`` and the
        full inline SQL ``raw_sql_override``.  Shipping that per row turned
        the list endpoint into an ~80-160 MB response at 100k reports, and
        shipping other users' inline SQL in a LIST is the same disclosure
        shape cabf95b7 closed on search.  This projection carries only what
        a list renders plus what the dict-only visibility trim needs
        (is_published / owner / owner_group_id / role_whitelist / id).
        The detail endpoint keeps using ``to_dict()`` — do NOT trim that.

        ``report_type`` is derived here ("pivot" | "tabular") so the UI's
        type chip does not need the full ``layout_config`` JSON.
        """
        try:
            _lc = self.layout_config or {}
            report_type = "pivot" if _lc.get("report_type") == "pivot" else "tabular"
        except Exception:
            report_type = "tabular"
        return {
            "id": self.id,
            "slug": self.slug,          # 2026-09-20: every list LINKS to /finance-reports/<slug>
            "name": self.name,
            "description": self.description or "",
            "dataset_id": self.dataset_id,
            "owner": self.owner,
            "owner_group_id": self.owner_group_id,
            "is_published": self.is_published,
            "is_sample": bool(self.is_sample),
            "api_lifecycle_status": self.api_lifecycle_status,
            "api_sunset_at": self.api_sunset_at.isoformat() if self.api_sunset_at else None,
            "api_deprecation_note": self.api_deprecation_note,
            "api_successor": self.api_successor,
            "api_lifecycle_changed_by": self.api_lifecycle_changed_by,
            "api_lifecycle_changed_at": self.api_lifecycle_changed_at.isoformat() if self.api_lifecycle_changed_at else None,
            # Effective lifecycle — NULL column derives from is_published so
            # pre-migration rows read correctly (compat, 2026-08-17).
            "lifecycle_status": (self.lifecycle_status
                                 or ("published" if self.is_published
                                     else "draft")),
            "role_whitelist": self.role_whitelist,
            "is_certified": self.is_certified or False,
            "certified_by": self.certified_by,
            "certified_at": self.certified_at.isoformat() if self.certified_at else None,
            "template_category": self.template_category,
            "data_source_type": self.data_source_type or "saved_query",
            "report_type": report_type,
            "execution_count": self.execution_count or 0,
            "last_executed_at": self.last_executed_at.isoformat() if self.last_executed_at else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "slug": self.slug,
            "name": self.name,
            "description": self.description or "",
            "dataset_id": self.dataset_id,
            "merged_dataset_id": self.merged_dataset_id,
            "merge_config": self.merge_config,
            "merged_dataset_column_ids": self.merged_dataset_column_ids or [],
            "column_ids": self.column_ids or [],
            "filter_specs": self.filter_specs or [],
            "condition_ids": self.condition_ids or [],
            "order_by": self.order_by or [],
            "row_limit": self.row_limit,
            "section_definitions": self.section_definitions or [],
            "running_calculations": self.running_calculations or [],
            "slicer_column_ids": self.slicer_column_ids or [],
            "drill_hierarchy_id": self.drill_hierarchy_id,
            "layout_config": self.layout_config,
            "is_published": self.is_published,
            "is_sample": bool(self.is_sample),
            "api_lifecycle_status": self.api_lifecycle_status,
            "api_sunset_at": self.api_sunset_at.isoformat() if self.api_sunset_at else None,
            "api_deprecation_note": self.api_deprecation_note,
            "api_successor": self.api_successor,
            "api_lifecycle_changed_by": self.api_lifecycle_changed_by,
            "api_lifecycle_changed_at": self.api_lifecycle_changed_at.isoformat() if self.api_lifecycle_changed_at else None,
            # Effective lifecycle — NULL column derives from is_published so
            # pre-migration rows read correctly (compat, 2026-08-17).
            "lifecycle_status": (self.lifecycle_status
                                 or ("published" if self.is_published
                                     else "draft")),
            "owner": self.owner,
            "owner_group_id": self.owner_group_id,
            "role_whitelist": self.role_whitelist,
            "refresh_on_open": bool(self.refresh_on_open or False),
            "execution_count": self.execution_count or 0,
            "last_executed_at": self.last_executed_at.isoformat() if self.last_executed_at else None,
            "is_certified": self.is_certified or False,
            "certified_by": self.certified_by,
            "certified_at": self.certified_at.isoformat() if self.certified_at else None,
            "template_category": self.template_category,
            "cloned_from_id": self.cloned_from_id,
            "data_source_type": self.data_source_type or "saved_query",
            "federation_view_id": self.federation_view_id,
            "published_view_id": self.published_view_id,
            # Phase 111: raw_sql fields (only populated when data_source_type == "raw_sql")
            "raw_saved_query_id": self.raw_saved_query_id,
            "raw_sql_saved_query_id": self.raw_sql_saved_query_id,
            "raw_sql_file_id": self.raw_sql_file_id,
            "raw_sql_override": self.raw_sql_override,
            "raw_parameters_schema": self.raw_parameters_schema or [],
            "raw_schedule_config": self.raw_schedule_config,
            "raw_connection_override_id": self.raw_connection_override_id,
            "legacy_report_id": self.legacy_report_id,
            # Cross-connection overrides (2026-08-11) — NULL = inherit from
            # the backing .sql file.  Mirrors sql_files / feed_configs.
            "secondary_connection_id": self.secondary_connection_id,
            "combine_mode": self.combine_mode,
            "join_config": self.join_config,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class BusinessReportVersion(Base):
    """An immutable snapshot of a business-report DEFINITION, minted at
    publish time (2026-08-17 publish lifecycle).

    THE core of the publish lifecycle: consumers execute the CURRENT
    published version's snapshot while the author edits the draft (the live
    ``business_reports`` row).  Before this table existed, ``PUT
    /api/business-reports/{id}`` mutated the ONLY copy of the definition, so
    an author's half-finished edit reached every consumer instantly.

    ``definition`` holds every field execution depends on (query config /
    source binding / columns / filters / layout / pivot / row_limit — see
    ``core.reports.versions.DEFINITION_FIELDS``); ``parameters`` holds the
    ``report_parameters`` rows as published (they live in their own table,
    so the definition JSON alone cannot cover them — the same gap the
    2026-08-10 semantic-version fix closed).  ACCESS fields (owner /
    role_whitelist / is_published / owner_group_id) are deliberately NOT
    snapshotted: authorization is always evaluated against the LIVE row, so
    revocation takes effect immediately on old versions too (fail-closed).

    ``semantic_version`` is the SAME content hash
    ``core.reports.instances.compute_semantic_version`` computes for the
    instance cache — one notion of "what changed", not two.  NULLABLE:
    backfilled v1 rows (alembic 017) cannot compute it offline and store
    NULL = unknown, which is disclosed, never coerced.

    Exactly one row per report has ``is_current=True`` while the report is
    published; republishing mints the next ``version_no`` and moves the
    flag.  Unpublish leaves the rows intact (explicit + reversible).
    """
    __tablename__ = "business_report_versions"

    id               = Column(Integer, primary_key=True, autoincrement=True)
    report_id        = Column(Integer, nullable=False, index=True)
    version_no       = Column(Integer, nullable=False)
    definition       = Column(JSON, nullable=False)         # DEFINITION_FIELDS snapshot
    parameters       = Column(JSON, nullable=True)          # report_parameters rows as published
    semantic_version = Column(String(64), nullable=True)    # instances.compute_semantic_version at publish; NULL = unknown (backfill)
    published_by     = Column(String(100), nullable=False)
    published_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    notes            = Column(Text, nullable=True)          # author's release notes
    is_current       = Column(Boolean, default=False, nullable=False)

    __table_args__ = (
        UniqueConstraint("report_id", "version_no",
                         name="uq_br_version_report_no"),
        Index("ix_br_version_current", "report_id", "is_current"),
    )

    def to_meta_dict(self) -> Dict[str, Any]:
        """Version metadata WITHOUT the definition payload — the list
        projection (a version list is not a detail payload)."""
        return {
            "id": self.id,
            "report_id": self.report_id,
            "version_no": self.version_no,
            "semantic_version": self.semantic_version,
            "published_by": self.published_by,
            "published_at": self.published_at.isoformat() if self.published_at else None,
            "notes": self.notes,
            "is_current": bool(self.is_current),
        }

    def to_dict(self) -> Dict[str, Any]:
        d = self.to_meta_dict()
        d["definition"] = self.definition
        d["parameters"] = self.parameters
        return d


class ReportParameter(Base):
    """Input control / cascading prompt for a business report.

    Supports dropdown (LOV from dataset column), text, date, date_range,
    numeric, and multi_select types.  Cascading chains are built via
    depends_on_param_id: when the parent param changes, the child's LOV
    is re-fetched with the parent's value as a filter.
    """
    __tablename__ = "report_parameters"

    id                       = Column(Integer, primary_key=True, autoincrement=True)
    report_id                = Column(Integer, nullable=False, index=True)
    name                     = Column(String(100), nullable=False)
    label                    = Column(String(200), nullable=False)
    parameter_type           = Column(String(20), nullable=False, default="dropdown")
    lov_column_id            = Column(Integer, nullable=True)     # the column this parameter FILTERS (and, by default, sources its values from)
    # 2026-08-31 — an author-curated value list.  When set, the dropdown
    # offers THESE instead of the column's distinct values.  Two different
    # questions were previously answered by one field: "what may the viewer
    # choose?" and "which column does the choice filter?".  lov_column_id
    # still answers the second — a static list with no column bound offers
    # choices that filter nothing — and this answers the first, for the
    # cases where distinct-from-data is wrong: a curated subset, a list the
    # data does not contain yet, or a column too large to scan for values.
    static_values            = Column(JSON, nullable=True)        # list[str] | None
    depends_on_param_id      = Column(Integer, nullable=True)     # parent parameter for cascade
    cascade_filter_column_id = Column(Integer, nullable=True)     # column to filter when parent changes
    default_value            = Column(String(500), nullable=True)
    # 2026-08-04: help text shown as a tooltip next to the parameter control.
    # The UI rendered ``p.description`` since Phase 85D-3 but no column /
    # model ever carried it — dead UI wired to a field nothing wrote.
    description              = Column(String(500), nullable=True)
    is_required              = Column(Boolean, default=True, nullable=False)
    sort_order               = Column(Integer, default=0)
    created_at               = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index("ix_report_param_report_order", "report_id", "sort_order"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "report_id": self.report_id,
            "name": self.name,
            "label": self.label,
            "parameter_type": self.parameter_type,
            "lov_column_id": self.lov_column_id,
            "static_values": self.static_values,
            "depends_on_param_id": self.depends_on_param_id,
            "cascade_filter_column_id": self.cascade_filter_column_id,
            "default_value": self.default_value,
            "description": self.description,
            "is_required": self.is_required,
            "sort_order": self.sort_order,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class ReportSubscription(Base):
    """Scheduled report delivery subscription — PDF/Excel/CSV to email recipients."""
    __tablename__ = "report_subscriptions"

    id               = Column(Integer, primary_key=True, autoincrement=True)
    report_id        = Column(Integer, nullable=False, index=True)
    report_type      = Column(String(50), nullable=False, default="business_report")  # business_report | parametric | query
    name             = Column(String(255), nullable=False)
    created_by       = Column(String(100), nullable=False, index=True)
    recipient_emails = Column(JSON, nullable=False, default=list)
    frequency        = Column(String(200), nullable=False)     # cron expression
    timezone         = Column(String(100), nullable=False, default="UTC")
    output_format    = Column(String(20), nullable=False, default="pdf")  # pdf | excel | csv
    param_values     = Column(JSON, nullable=True)
    is_active        = Column(Boolean, default=True, nullable=False)
    next_send_at     = Column(DateTime, nullable=True)
    last_sent_at     = Column(DateTime, nullable=True)
    unsubscribe_token = Column(String(100), nullable=True, unique=True, index=True)
    retry_count      = Column(Integer, default=0, nullable=False)
    created_at       = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at       = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                              onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index("ix_subscription_report", "report_id", "report_type"),
        Index("ix_subscription_next_send", "is_active", "next_send_at"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "report_id": self.report_id,
            "report_type": self.report_type,
            "name": self.name,
            "created_by": self.created_by,
            "recipient_emails": self.recipient_emails or [],
            "frequency": self.frequency,
            "timezone": self.timezone,
            "output_format": self.output_format,
            "param_values": self.param_values,
            "is_active": self.is_active,
            "next_send_at": self.next_send_at.isoformat() if self.next_send_at else None,
            "last_sent_at": self.last_sent_at.isoformat() if self.last_sent_at else None,
            "unsubscribe_token": self.unsubscribe_token,
            "retry_count": self.retry_count,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class SubscriptionDelivery(Base):
    """Individual delivery record for a subscription send attempt."""
    __tablename__ = "subscription_deliveries"

    id               = Column(Integer, primary_key=True, autoincrement=True)
    subscription_id  = Column(Integer, nullable=False, index=True)
    recipient_email  = Column(String(255), nullable=False)
    sent_at          = Column(DateTime, nullable=True)
    status           = Column(String(20), nullable=False, default="pending")  # pending | sent | failed | bounced
    error_message    = Column(Text, nullable=True)
    file_size_bytes  = Column(BigInteger, nullable=True)
    attempted_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "subscription_id": self.subscription_id,
            "recipient_email": self.recipient_email,
            "sent_at": self.sent_at.isoformat() if self.sent_at else None,
            "status": self.status,
            "error_message": self.error_message,
            "file_size_bytes": self.file_size_bytes,
            "attempted_at": self.attempted_at.isoformat() if self.attempted_at else None,
        }


class WorkerRegistration(Base):
    """Registry of active worker nodes for Phase 45C horizontal scaling."""
    __tablename__ = "worker_registry"

    worker_id      = Column(String(128), primary_key=True)
    worker_type    = Column(String(32), nullable=False, default="executor")
    hostname       = Column(String(256), nullable=True)
    info           = Column(JSON, nullable=True)
    last_heartbeat = Column(DateTime, nullable=True)
    expires_at     = Column(DateTime, nullable=True, index=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "worker_id": self.worker_id,
            "worker_type": self.worker_type,
            "hostname": self.hostname,
            "info": self.info,
            "last_heartbeat": self.last_heartbeat.isoformat() if self.last_heartbeat else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
        }


# ── Phase 75: Published Views API ────────────────────────────────────────────

class PublishedView(Base):
    """A saved query published as an external API endpoint."""
    __tablename__ = "published_views"

    id                = Column(Integer, primary_key=True, index=True)
    slug              = Column(String(100), unique=True, nullable=False, index=True)
    name              = Column(String(255), nullable=False)
    description       = Column(Text, nullable=True)
    query_id          = Column(Integer, nullable=True, index=True)    # FK → saved_queries.id (nullable for federation/sql_file/br source_types)
    connection_id     = Column(Integer, nullable=True)
    query_config      = Column(JSON, nullable=False)                  # frozen snapshot at publish time
    allowed_filters   = Column(JSON, nullable=True)                   # ["region", "year"] — columns consumers can filter
    default_limit     = Column(Integer, default=1000)
    max_limit         = Column(Integer, default=50000)
    is_active         = Column(Boolean, default=True)
    cache_ttl_seconds = Column(Integer, default=300)
    param_definitions  = Column(JSON, nullable=True)               # Phase 80: runtime parameter definitions
    allowed_ad_groups  = Column(JSON, nullable=True)               # Phase 82: AD groups allowed to access (null = API key only or open to all AD users when AD auth is used)
    source_type        = Column(String(20), default="saved_query", nullable=False)  # "saved_query" | "business_report" | "federation" | "sql_file"
    business_report_id = Column(Integer, nullable=True)            # Phase 91: FK → business_reports.id (when source_type="business_report")
    federation_view_id = Column(Integer, nullable=True)            # Phase 93: FK → federation_views.id (when source_type="federation")
    sql_file_id        = Column(Integer, nullable=True)            # Phase 122C: FK → sql_files.id (when source_type="sql_file")
    version           = Column(Integer, default=1)                  # Phase 98-D: auto-increment on query_config change
    query_hash        = Column(String(64), nullable=True, index=True) # Phase 98-D: SHA-256 of query_config JSON
    # Cache controls — consumers can freely choose real-time vs cached
    min_cache_age_seconds = Column(Integer, default=60)             # throttle guard (seconds) — prevents S3 hammering
    allow_cache_bypass    = Column(Boolean, default=True)           # consumers can always request fresh data
    cache_strategy        = Column(String(20), default="ttl")       # "ttl" (default) | "live" (always query S3)
    # Phase 146-A — Multi-engine: list of connection_ids the consumer may pick
    # via ?engine={id}.  NULL = legacy behaviour (single connection_id from above).
    # Stored as JSON for SQLite/Postgres portability — see migration row in
    # core/database.py::_MIGRATIONS["published_views"].
    allowed_engine_connections = Column(JSON, nullable=True)
    # BF-430A — per-PV reader override.  NULL = use the snapshotted
    # query_config's reader_override (which itself defaults to NULL = use
    # the global s3_readers config).  Set to a registered reader name to
    # force a specific reader for THIS view's runtime requests.  Validated
    # against the registry at write time + at the router.
    reader_override   = Column(String(64), nullable=True)
    # Phase 133-J — publisher-time choices that auto-resolve at consume time so
    # curl users never get a credential prompt.
    #   execution_connection_id : NULL = use snapshotted query_config's
    #     connection_id (legacy).  Non-null lets the publisher redirect
    #     execution at runtime (e.g. point at a system-account-backed
    #     shared connection without rebuilding the query).
    #   credential_mode         : "consumer" (default, legacy) | "publisher" |
    #     "shared".  Drives whose identity feeds the credential resolver.
    #     - consumer  → calling user's vault (current behaviour, structured 401 on miss)
    #     - publisher → resolved against publisher_username's vault
    #                   (acts as a trust delegation — publisher consents)
    #     - shared    → force is_shared=true so CredentialManager goes to
    #                   the connection's system_account, no per-user vault
    #   publisher_username      : captured at publish time from created_by so
    #     publisher-mode survives the publisher's session expiry.
    execution_connection_id = Column(Integer, nullable=True)
    # BF-513 (2026-05-28): server_default="consumer" so the SQLite auto-migrate
    # path can ADD this NOT NULL column on existing databases.  Python-side
    # ``default=`` is applied at INSERT time only — it does NOT appear in the
    # ALTER TABLE DDL, so SQLite would refuse the ADD COLUMN (NOT NULL + no
    # DEFAULT) and skip it with a startup WARNING.  The Alembic migration
    # already had server_default; mirror it on the model so deployments that
    # rely on auto-migrate stay safe.
    credential_mode   = Column(String(20), nullable=False, default="consumer",
                               server_default="consumer")
    publisher_username = Column(String(100), nullable=True)
    # 2026-10-17 -- the API LIFECYCLE (core/published_api/lifecycle.py):
    # draft | active | deprecated | retired, NULL = derived from is_active
    # (active / retired) so no row needs a backfill.  The same six columns
    # live on every published-API kind's table.
    api_lifecycle_status     = Column(String(12), nullable=True)
    api_sunset_at            = Column(DateTime, nullable=True)
    api_deprecation_note     = Column(Text, nullable=True)
    api_successor            = Column(String(220), nullable=True)
    api_lifecycle_changed_by = Column(String(100), nullable=True)
    api_lifecycle_changed_at = Column(DateTime, nullable=True)
    created_by        = Column(String(100), nullable=True)
    created_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                               onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "slug": self.slug,
            "api_lifecycle_status": self.api_lifecycle_status,
            "api_sunset_at": self.api_sunset_at.isoformat() if self.api_sunset_at else None,
            "api_deprecation_note": self.api_deprecation_note,
            "api_successor": self.api_successor,
            "api_lifecycle_changed_by": self.api_lifecycle_changed_by,
            "api_lifecycle_changed_at": self.api_lifecycle_changed_at.isoformat() if self.api_lifecycle_changed_at else None,
            "name": self.name,
            "description": self.description,
            "query_id": self.query_id,
            "connection_id": self.connection_id,
            "query_config": self.query_config,
            "allowed_filters": self.allowed_filters or [],
            "default_limit": self.default_limit,
            "max_limit": self.max_limit,
            "is_active": self.is_active,
            "cache_ttl_seconds": self.cache_ttl_seconds,
            "param_definitions": self.param_definitions or [],
            "allowed_ad_groups": self.allowed_ad_groups or [],
            "source_type": self.source_type or "saved_query",
            "business_report_id": self.business_report_id,
            "federation_view_id": self.federation_view_id,
            "sql_file_id": self.sql_file_id,
            "version": self.version if self.version is not None else 1,
            "query_hash": self.query_hash,
            "min_cache_age_seconds": self.min_cache_age_seconds if self.min_cache_age_seconds is not None else 60,
            "allow_cache_bypass": self.allow_cache_bypass if self.allow_cache_bypass is not None else True,
            "cache_strategy": self.cache_strategy or "ttl",
            "allowed_engine_connections": list(self.allowed_engine_connections or []),  # Phase 146-A
            "reader_override": self.reader_override,
            "execution_connection_id": self.execution_connection_id,
            "credential_mode": self.credential_mode or "consumer",
            "publisher_username": self.publisher_username,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class FeedConfig(Base):
    """Configuration for a feed file generation job (Phase 76)."""
    __tablename__ = "feed_configs"

    id                      = Column(Integer, primary_key=True, index=True)
    name                    = Column(String(255), nullable=False, index=True)
    # 2026-09-02 (FR-ID-01..03) — ``name`` is IDENTITY: unique per
    #   environment, bounded charset, immutable once the feed has run.
    #   A rename after the first run breaks every historical reference
    #   (archives, Netcool AlertKeys, rendered filenames, audit), so
    #   renaming means "create new, retire old".
    #   ``display_name`` is the LABEL: free text, editable, no rules.
    #   Separating the two is what lets people relabel a feed without
    #   breaking its identity — which is what makes the rename refusal
    #   acceptable rather than merely obstructive.
    display_name            = Column(String(255), nullable=True)
    description             = Column(Text, nullable=True)
    is_active               = Column(Boolean, default=True)

    # Source
    source_type             = Column(String(50), nullable=False)       # saved_query | published_view | raw_sql
    source_id               = Column(Integer, nullable=False)
    connection_id           = Column(Integer, nullable=True)
    query_params            = Column(JSON, nullable=True)              # runtime parameters / filters

    # Output
    output_format           = Column(String(20), default="csv")        # csv | parquet | json | excel
    output_filename_template = Column(String(500), nullable=True)
    output_options          = Column(JSON, nullable=True)              # delimiter, header, compression, etc.

    # Destination
    destination_type        = Column(String(20), default="local")      # local | s3 | sftp
    # SecretJSON (2026-10-13): secret values encrypted at rest (core/secrets_at_rest.py)
    destination_config      = Column(SecretJSON, nullable=False)       # bucket/path/host/creds
    # 2026-09-02 (BRD §11 / §14.2) — the authored multi-hop delivery
    # chain that core/feed/delivery_hops.build_hop_plan reads: a JSON
    # list of {"target": ..., "label": ..., "config": {...},
    # "requires": ..., "max_attempts": n} entries, in delivery order.
    # NULL = no chain declared = the legacy single-hop path built from
    # destination_type + destination_config, byte-for-byte unchanged.
    # Validated at AUTHORING by api/feed_api._refuse_invalid_delivery_chain
    # (unknown target / duplicate label / empty-but-present all 422).
    delivery_chain          = Column(SecretJSON, nullable=True)

    # Execution backend
    execution_backend       = Column(String(20), default="auto")       # auto | native | airflow | spark_livy
    backend_config          = Column(SecretJSON, nullable=True)
    size_threshold_rows     = Column(Integer, nullable=True)
    # Phase 131 deep-dive #13 (round 8) — size-based routing tracker.
    # last_row_count is set from the actual row count of the last
    # successful native run; estimated_row_count is an optional admin
    # override.  Either value feeds into _pick_backend_detailed so the
    # auto-router can hand large feeds to Airflow without a costly
    # pre-flight COUNT(*).
    last_row_count          = Column(BigInteger, nullable=True)
    estimated_row_count     = Column(BigInteger, nullable=True)

    # Schedule
    schedule_enabled        = Column(Boolean, default=False)
    cron_expression         = Column(String(100), nullable=True)
    # BRD 2.1 (2026-09-02) — the DECLARED schedule, one of five kinds:
    #   daily | month_end | workday_n | cron | on_completion_of.
    #   Until this existed the backend could express only cron + timezone
    #   + calendar, so three of the five authorable kinds had NO
    #   representation and the property was 40% real.
    #   NULL = the legacy cron-only path, untouched.  Parsed by
    #   core.feed.schedule.parse_schedule, which returns None for None.
    schedule_declaration    = Column(JSON, nullable=True)
    timezone                = Column(String(50), default="UTC")
    apscheduler_job_id      = Column(String(100), nullable=True, unique=True)
    # BF-473 (2026-05-19) — operator-facing categorization.  Open string
    # so admins can introduce new categories without a code change.
    # Suggested vocabulary (admin UI exposes these as a dropdown):
    #   sod        — Start-of-Day, runs before market open
    #   intraday   — mid-day refresh on a cron interval
    #   eod        — End-of-Day, runs after market close
    #   daily      — generic daily feed not tied to market windows
    #   monthly    — month-end / workday-N reporting
    #   custom     — bespoke schedule (workday calculation in
    #                ACTION_CONDITION)
    # NULL is allowed for legacy rows.  The actual firing schedule
    # is still controlled by cron_expression + action_condition_sql
    # — this column is informational metadata for filtering /
    # dashboards / reporting only.
    frequency_category      = Column(String(50), nullable=True, index=True)

    # Notifications
    notify_on_success       = Column(Boolean, default=False)
    notify_on_failure       = Column(Boolean, default=True)
    notify_emails           = Column(Text, nullable=True)
    notify_webhook          = Column(Text, nullable=True)

    # Retry
    max_retries             = Column(Integer, default=2)
    retry_delay_seconds     = Column(Integer, default=60)

    # Enterprise feed framework (Phase 130 — FEED_ENTERPRISE_PLAN.md).
    # Every column is nullable + has a sensible default so existing
    # feed_configs rows continue working unchanged.  The new behaviour
    # is flag-gated under ``feed_generation.sod_enabled`` in config.
    file_type_code          = Column(String(100), nullable=True)            # FILE_TYPE — grouping key for holiday lookups
    priority                = Column(Integer, default=5)                    # PRIORITY 1-9 — lower = higher priority (AUTHORITATIVE since 2026-09-02: runtime honours it via core/feed/claims.py; 1-2 = critical)
    valid_from              = Column(Date, nullable=True)                   # START_DATE — feed runs only when run_date >= this
    valid_until             = Column(Date, nullable=True)                   # END_DATE   — feed runs only when run_date <= this
    sla_from                = Column(String(20), nullable=True)             # SLA_FROM — "+HH:MM" offset from business_date
    sla_to                  = Column(String(20), nullable=True)             # SLA_TO   — same shape
    # 2026-09-03 (FR-SCH-06 / FR-SLA-06) — the SLA's EXPLICIT ZONE.  An SLA
    # is a LOCAL TIME PLUS A ZONE, resolved per business date; a bare hour
    # has two meanings the moment a feed serves APAC, and DST moves one of
    # them twice a year.  BOTH consumers (core/feed/acting_time.resolve_sla_at
    # for the alert ladder and core/feed/sla_tracker for the breach sweep)
    # read THIS column with the SAME meaning: sla_to is local time in this
    # zone.  NULL keeps the legacy contract — sla_to is a bare UTC offset —
    # in BOTH consumers, so existing feeds move nowhere.
    sla_timezone            = Column(String(50), nullable=True)
    # 2026-09-03 (FR-SLA-01) — the DECLARED runtime override, in seconds.
    # The decision deadline prefers the MEASURED p95 from
    # feed_runtime_profiles; this declaration is the fallback for a feed
    # with no history yet.  Until this column existed the fallback read a
    # field that existed on NO table — the ladder's deadline was None on
    # every production feed and only test doubles ever supplied it.
    expected_runtime_seconds = Column(Integer, nullable=True)
    calendar_name           = Column(String(100), nullable=True)            # FK → feed_calendars.name
    action_condition_sql    = Column(Text, nullable=True)                   # SQL CASE returning 'SKIP' or NULL
    control_file_template   = Column(String(500), nullable=True)            # CTL_FILE_NAME — sidecar .ctl filename mask

    # Cross-source combine — when secondary_connection_id is set the
    # feed pulls primary + secondary sides separately, then combines
    # via core.executors.cross_source_combine (UNION ALL BY NAME or
    # JOIN).  combine_mode = 'union' | 'join'; join_config carries the
    # JSON {how, left_on, right_on, suffixes} structure when joining.
    secondary_connection_id = Column(Integer, nullable=True)
    secondary_source_type   = Column(String(50), nullable=True)             # None → reuses source_type
    secondary_source_id     = Column(Integer, nullable=True)                # None → reuses source_id
    combine_mode            = Column(String(20), nullable=True)             # 'union' | 'join'
    join_config             = Column(JSON, nullable=True)                   # join params (when combine_mode='join')

    # Phase 130 hotfix-4 — DB-driven CTL format.  When set, the named
    # feed_control_file_formats row drives field layout + checksum
    # algorithm.  When NULL, the legacy control_file_template + default
    # field order is used (existing behaviour preserved).
    control_file_format_id  = Column(Integer, nullable=True)

    # Phase 130 hotfix-7 — group-based ownership.  Any user_group_members
    # entry for this group grants owner-equivalent permissions on this
    # feed (rerun, cancel, edit).  NULL = single-owner only.
    owner_group_id          = Column(Integer, nullable=True)

    # 2026-09-02 — OPERATIONAL grouping (feed_groups.id), a first-class
    # managed entity the operator ACTS ON ("rerun the group", "skip what
    # the group is waiting on").  Deliberately DISTINCT from
    # owner_group_id, which is an ACL attribute (user entitlement
    # groups): who may touch a feed and how it is operated together are
    # different questions, and folding them was exactly the dashboard
    # defect this column fixes.
    # ONE group per feed (FK column, not a join table) — a feed in two
    # groups makes "run the group" ambiguous, and that ambiguity would
    # surface at 04:30 as a double trigger.  Same shape as
    # calendar_name: a nullable reference to a managed entity, validated
    # at authoring (api/feed_api._require_valid_feed_group_id).
    # NULL = ungrouped (legacy rows unchanged).
    feed_group_id           = Column(Integer, nullable=True, index=True)

    # 2026-09-05 — the step FLOW this feed is mapped to (feed_flows.id).
    # "if someone using just map these steps".  NULL = mapped to no
    # flow, which is every feed that exists today: the planner still
    # derives and records the engine spine, and nothing extra runs.
    # Validated at authoring; no FK so deleting a flow leaves a feed
    # that REFUSES its plan by name rather than one that silently
    # loses its steps.
    flow_id                 = Column(Integer, nullable=True, index=True)

    # 2026-09-28 -- the feed's CONSUMER groups (user_groups ids, a JSON
    # list).  A member of any of them reads the feed's delivery RECEIPTS
    # on the My Feeds page (core/feed/consumer_receipts.py) and may
    # subscribe to delivered / late / failed notices -- and nothing else:
    # the declaration is deliberately NOT a view grant on the feed (the
    # Today board, the run surface and every /feeds route keep the
    # owner-group rule).  Distinct from owner_group_id (who may act) and
    # feed_group_id (who is operated together).  NULL / [] = no declared
    # consumers, so the feed has no receipt audience.  ALSO declared in
    # core/database.py::_MIGRATIONS["feed_configs"]: a new COLUMN never
    # reaches a deployed table via create_all.
    consumer_group_ids      = Column(JSON, nullable=True)
    # 2026-10-10 -- MEMBERSHIP of a feed TEMPLATE (feed_templates): the
    # feed was rendered from template ``template_id`` for the matrix row
    # keyed ``template_member_key`` ("GB01|EOM" -- the parameter values in
    # the template's parameter order).  Both NULL for a hand-authored feed.
    # A template re-apply finds its members by (template_id, member_key),
    # never by name.  Declared in core/database.py::_MIGRATIONS too; a
    # clone never copies them (a clone is a new, hand-owned feed).
    template_id             = Column(Integer, nullable=True, index=True)
    template_member_key     = Column(String(255), nullable=True)
    # 2026-10-11 -- token BINDINGS (core/feed/sql_tokens.py): a JSON list of
    # {side, column, literal, token, format} that rewrites a saved query's
    # LITERAL predicate (CODE = 'SAP-2504') to its token ({SYSTEM_ENTITY}) at
    # render time on every lane and both sides.  NULL / [] = none.  ALSO in
    # core/database.py::_MIGRATIONS["feed_configs"] (a new COLUMN never
    # reaches a deployed table via create_all).
    token_bindings          = Column(JSON, nullable=True)

    # Phase 131 — generic task_type.  A "task" is broader than a "feed":
    # it can produce a file (file_feed — the legacy default), push rows
    # to Oracle, fire an API call, or anything else.  Engine routing
    # branches on this value; default file_feed keeps every legacy
    # feed_config unchanged.
    # IMPORTANT: server_default is REQUIRED for auto-migrate-from-models
    # to add this column on existing SQLite DBs.  `default=` alone is
    # Python-side only and would cause auto-migrate to skip the column
    # (SQLite ALTER TABLE can't add NOT NULL without server_default).
    task_type               = Column(String(40), default="file_feed",
                                       server_default="file_feed",
                                       nullable=False)

    # Phase 131 controls — opt-in production safety gates (all NULL by
    # default; admin opts in per-feed via UI).
    # 131-A: generic ETL identifier — links this feed to etl_dependency_*
    #        tables.  Same id will FK into OTG_REPORT_DEPENDENCY_MAPPING
    #        when systems integrate.
    etl_id                  = Column(Integer, nullable=True, index=True)
    # 131-B: row-count threshold (% tolerance) and action.  NULL = inherit
    #        system default; row_count_action 'off' disables the check
    #        entirely on this feed.
    row_count_threshold_pct = Column(Numeric(5, 2), nullable=True)
    # 2026-09-02 (D3) — a NEWLY onboarded feed gets the volume check ON in
    #        warn mode.  It was "off", so every new feed shipped with no
    #        volume check unless someone remembered to turn one on -- and a
    #        collapse from 4M rows to 12 is mechanically perfect output.
    #        Existing rows keep whatever they already hold; NULL now means
    #        "inherit the system default" as documented above, resolved in
    #        row_count_check._load_defaults.
    row_count_action        = Column(String(20), default="warn")  # off | warn | fail
    # 2026-09-03 (FR-DEP-15) — the row-count check's missing SHAPE.  A single
    # percentage is wrong at both ends: a 5% drop on 10 rows is noise, a 5%
    # drop on 10M is an incident, and a feed that legitimately produces zero
    # rows had no way to say so.  ALL nullable, NO defaults — a feed with
    # only the percentage configured behaves byte-for-byte as before.
    #   row_count_min_rows: ABSOLUTE floor.  Fewer rows than this is a
    #     breach regardless of any percentage — and it works even before a
    #     baseline exists, because a collapse to 12 rows is mechanically
    #     perfect output that must not hide behind "insufficient samples".
    #     BIGINT: this codebase has already taken an outage from an INTEGER
    #     counter overflowing.
    row_count_min_rows      = Column(BigInteger, nullable=True)
    #   Independent UP / DOWN tolerances.  NULL for a direction = that
    #   direction keeps using the symmetric row_count_threshold_pct
    #   (or the system default) exactly as today.
    row_count_threshold_pct_up   = Column(Numeric(5, 2), nullable=True)
    row_count_threshold_pct_down = Column(Numeric(5, 2), nullable=True)
    #   Explicit expect-zero declaration: True = zero rows is a legitimate
    #   full answer for this feed (an empty region on a holiday), stated by
    #   the author rather than inferred from a zero baseline.
    row_count_expect_zero   = Column(Boolean, nullable=True)
    # 2026-10-12 (owner R2) -- WHAT today's count is compared with.
    #   NULL / 'baseline' = the rolling average (feed_row_count_baseline,
    #   unchanged); 'previous' = the rows the PREVIOUS business date's run
    #   DELIVERED ("today vs yesterday").  Read by core/feed/variance_hold.py.
    row_count_compare_to    = Column(String(20), nullable=True)
    # 2026-09-03 (FR-DEP-14) — maker/checker on dependency skips.  True =
    # a SKIP assertion releasing THIS feed requires a SECOND, DIFFERENT
    # approver before the tracking row is written (one person must not be
    # able to skip a dependency on a regulatory feed alone at 05:20).
    # NULL/False = single-approver skip, exactly as before — the control
    # is opt-in per feed, enforced in core/feed/dependency_skip.assert_skip.
    skip_requires_second_approver = Column(Boolean, nullable=True)
    # 131-C: per-feed integrity-check override.  NULL = inherit system
    #        default (integrity_check_enabled in system_settings).
    integrity_check_enabled = Column(Boolean, nullable=True)

    # Metadata
    created_by              = Column(String(100), nullable=True)
    created_at              = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at              = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                                     onupdate=lambda: datetime.now(timezone.utc))
    last_execution_id       = Column(Integer, nullable=True)
    next_run_at             = Column(DateTime, nullable=True)
    run_count               = Column(Integer, default=0)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "display_name": self.display_name,
            "description": self.description,
            "is_active": self.is_active,
            "source_type": self.source_type,
            "source_id": self.source_id,
            "connection_id": self.connection_id,
            "query_params": self.query_params,
            "output_format": self.output_format,
            "output_filename_template": self.output_filename_template,
            "output_options": self.output_options,
            "destination_type": self.destination_type,
            "destination_config": self.destination_config,
            "delivery_chain": self.delivery_chain,
            "schedule_declaration": self.schedule_declaration,
            "execution_backend": self.execution_backend,
            "backend_config": self.backend_config,
            "size_threshold_rows": self.size_threshold_rows,
            "last_row_count": self.last_row_count,
            "estimated_row_count": self.estimated_row_count,
            "schedule_enabled": self.schedule_enabled,
            "cron_expression": self.cron_expression,
            "timezone": self.timezone,
            "apscheduler_job_id": self.apscheduler_job_id,
            "notify_on_success": self.notify_on_success,
            "notify_on_failure": self.notify_on_failure,
            "notify_emails": self.notify_emails,
            "notify_webhook": self.notify_webhook,
            "max_retries": self.max_retries,
            "retry_delay_seconds": self.retry_delay_seconds,
            # Enterprise feed framework
            "file_type_code":        self.file_type_code,
            "frequency_category":    self.frequency_category,  # BF-473
            "priority":              self.priority,
            "valid_from":            self.valid_from.isoformat() if self.valid_from else None,
            "valid_until":           self.valid_until.isoformat() if self.valid_until else None,
            "sla_from":              self.sla_from,
            "sla_to":                self.sla_to,
            "sla_timezone":          self.sla_timezone,
            "expected_runtime_seconds": self.expected_runtime_seconds,
            "calendar_name":         self.calendar_name,
            "action_condition_sql":  self.action_condition_sql,
            "control_file_template": self.control_file_template,
            # Cross-source combine
            "secondary_connection_id": self.secondary_connection_id,
            "secondary_source_type":   self.secondary_source_type,
            "secondary_source_id":     self.secondary_source_id,
            "combine_mode":            self.combine_mode,
            "join_config":             self.join_config,
            "control_file_format_id":  self.control_file_format_id,
            "owner_group_id":          self.owner_group_id,
            "feed_group_id":           self.feed_group_id,
            "flow_id":                 self.flow_id,
            # 2026-09-28 -- always a list on the wire (None on the row =
            # no declared consumers), so a reader never branches on null.
            "template_id":             self.template_id,
            "template_member_key":     self.template_member_key,
            "token_bindings":          list(self.token_bindings or []),
            "consumer_group_ids":      [int(g) for g in (self.consumer_group_ids or [])
                                        if g is not None],
            # Phase 131 controls + generic task_type
            "task_type":               self.task_type,
            "etl_id":                  self.etl_id,
            "row_count_threshold_pct": float(self.row_count_threshold_pct) if self.row_count_threshold_pct is not None else None,
            "row_count_action":        self.row_count_action,
            # FR-DEP-15 shape (2026-09-03) — floor / asymmetric / expect-zero.
            "row_count_min_rows":      self.row_count_min_rows,
            "row_count_threshold_pct_up": (
                float(self.row_count_threshold_pct_up)
                if self.row_count_threshold_pct_up is not None else None),
            "row_count_threshold_pct_down": (
                float(self.row_count_threshold_pct_down)
                if self.row_count_threshold_pct_down is not None else None),
            "row_count_expect_zero":   self.row_count_expect_zero,
            "row_count_compare_to":    self.row_count_compare_to,
            # FR-DEP-14 (2026-09-03) — maker/checker skip control.
            "skip_requires_second_approver": self.skip_requires_second_approver,
            "integrity_check_enabled": self.integrity_check_enabled,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "last_execution_id": self.last_execution_id,
            "next_run_at": self.next_run_at.isoformat() if self.next_run_at else None,
            "run_count": self.run_count,
        }


class FeedCalendar(Base):
    """Named business calendar used by feed_configs.action_condition_sql
    and the business-date helper.  Phase 130 enterprise feed framework
    (FEED_ENTERPRISE_PLAN.md).

    A single calendar represents a set of non-business days (weekends
    + holiday dates).  Multiple feeds can share one calendar
    (``US_BANKING``) or a feed can have its own (``CLAUDE_MONTHEND``).
    """
    __tablename__ = "feed_calendars"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(100), unique=True, nullable=False, index=True)
    description = Column(Text, nullable=True)
    # ISO weekday numbers (Mon=1 … Sun=7) treated as weekend.
    # JSON list so admins can customise per-region (Middle East = Fri/Sat).
    weekend_days = Column(JSON, nullable=True)
    is_active   = Column(Boolean, default=True)
    created_by  = Column(String(100), nullable=True)
    # ── FR-SCH-01 (2026-09-03) ───────────────────────────────────────
    # A calendar is a NAMED, VERSIONED object with a DECLARED OWNER and
    # a POPULATED HORIZON.  Only the name existed.
    #
    # ``owner`` is not ``created_by``: whoever typed the row is rarely
    # who answers "is 2027-04-02 a holiday in this market?".  A calendar
    # with no owner is a calendar nobody maintains, and its horizon
    # quietly expires.
    #
    # ``horizon_end`` is the load-bearing one — the last date this
    # calendar has been POPULATED THROUGH.  Without it, asking about any
    # later date returns "not a holiday", which the caller reads as "a
    # business day": the platform assuming a business day because the
    # calendar does not say otherwise, which is precisely what FR-SCH-02
    # forbids.  NULL means UNDECLARED, and undeclared is stated at load
    # rather than treated as unbounded.
    #
    # ``version`` bumps whenever holidays change, so a run can record
    # WHICH calendar it was scheduled against — two runs of the same
    # date under different holiday data are not the same run.
    owner        = Column(String(100), nullable=True)
    horizon_end  = Column(Date, nullable=True)
    version      = Column(Integer, nullable=False, default=1)
    created_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                          onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            # No hardcoded fallback — when admin hasn't set weekend_days
            # the consumer (BusinessCalendar) reads the system-wide
            # default from feed_generation.default_weekend_days config.
            "weekend_days": self.weekend_days,
            "is_active": self.is_active,
            "created_by": self.created_by,
            # FR-SCH-01 — a column no to_dict() emits is a column the
            # application cannot see.  These were added, migrated and
            # written, and the DAO returned None for all three, so the
            # horizon never reached BusinessCalendar and the FR-SCH-02
            # refusal could not fire ANYWHERE in production.  Every unit
            # test passed because it built a CalendarSpec directly and
            # never crossed this seam.
            "owner": self.owner,
            "horizon_end": (self.horizon_end.isoformat()
                            if self.horizon_end else None),
            "version": self.version,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class FeedHoliday(Base):
    """Single holiday entry on a feed_calendar.  Phase 130."""
    __tablename__ = "feed_holidays"
    __table_args__ = (
        UniqueConstraint("calendar_id", "holiday_date", name="ux_feed_holidays_cal_date"),
    )

    id            = Column(Integer, primary_key=True, index=True)
    calendar_id   = Column(Integer, ForeignKey("feed_calendars.id", ondelete="CASCADE"),
                            nullable=False, index=True)
    holiday_date  = Column(Date, nullable=False, index=True)
    holiday_name  = Column(String(200), nullable=True)
    # When true, the date is interpreted as MM-DD and recurs every year
    # (e.g. Jan 1 New Year's Day).  When false, single-year only.
    recurring     = Column(Boolean, default=False)
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "calendar_id": self.calendar_id,
            "holiday_date": self.holiday_date.isoformat() if self.holiday_date else None,
            "holiday_name": self.holiday_name,
            "recurring": self.recurring,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class FeedGroup(Base):
    """Operational feed group — a first-class managed entity (2026-09-02).

    A NAMED grouping of feeds an operator administers and ACTS ON as one
    unit ("rerun the EOD_RISK group for 2026-09-01", "release everything
    the group is waiting on") — the way the OG ETL groups its workflows.

    NOT an ACL construct: entitlements stay on
    ``feed_configs.owner_group_id`` (user_groups).  This is the
    operational axis the dashboard groups by.

    Membership is ``feed_configs.feed_group_id`` — ONE group per feed
    (see the column comment there: two groups makes "run the group"
    ambiguous).  Modelled after FeedCalendar, the closest existing
    managed reference entity attached to feeds.
    """
    __tablename__ = "feed_groups"

    id            = Column(Integer, primary_key=True, index=True)
    #: Identity — unique per environment, referenced by operators and
    #: audit rows.  ``display_label`` is the free-text label.
    name          = Column(String(100), unique=True, nullable=False, index=True)
    display_label = Column(String(255), nullable=True)
    description   = Column(Text, nullable=True)
    is_active     = Column(Boolean, default=True)
    # 2026-09-27 -- where the group's DAILY CLOSE-OUT DIGEST goes
    # (core/feed/close_out_digest.py): comma-separated addresses.  NULL =
    # no digest for this group (it is listed in the admin preview as
    # "no recipients", never silently dropped).  Distinct from
    # user_groups.notification_email, which is the ACL group's alert
    # address.  Declared in core/database.py::_MIGRATIONS["feed_groups"]
    # too -- a new COLUMN never reaches a deployed table via create_all.
    notification_email = Column(String(500), nullable=True)
    created_by    = Column(String(100), nullable=True)
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                            onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "display_label": self.display_label,
            "description": self.description,
            "is_active": self.is_active,
            "notification_email": self.notification_email,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


#: 2026-09-15 — the feed_runs Idempotency-Key column's width and the name of
#: the partial UNIQUE index that arbitrates a replay.  Named once, here, so
#: the model, the PG migration and the route agree.  320 is the core's
#: ``occurrence.MAX_FIRE_KEY_LEN`` -- a Clockwork fire key always fits; a
#: longer caller key is refused (400), never truncated, because a truncated
#: key would collide two requests into one run.
FEED_RUN_IDEMPOTENCY_KEY_LEN = 320
FEED_RUN_IDEMPOTENCY_INDEX = "ux_feed_runs_idempotency_key"
#: 2026-10-03 — ``feed_runs.triggered_by`` of a run started because its
#: UPSTREAM feed's run completed and delivered (schedule kind
#: ``on_completion_of``; core/feed/upstream_completion.py).  ONE spelling:
#: the creator (core/feed/sod_generator.py), the queue's historical-date
#: admission (mixin_feeds.list_feed_runs) and the UI read this.  It must fit
#: the String(20) column.
FEED_RUN_UPSTREAM_TRIGGER = "upstream_completion"

#: ``feed_runs.triggered_by`` of a run the SOD generator created for a DUE
#: date it had MISSED (the scheduler was down at the cron time, 2026-10-11;
#: core/feed/sod_generator.py).  ONE spelling: the creator, the queue's
#: historical-date admission (mixin_feeds.list_feed_runs -- the row's date is
#: older than the lookback by definition), event_audience.SYSTEM_ACTORS and
#: the UI read this.  Fits the String(20) column.
FEED_RUN_SOD_CATCHUP_TRIGGER = "sod_catchup"


class FeedRun(Base):
    """One concrete execution of a feed for a specific business_date.

    Created by the SOD task generator (default cron ``0 0 * * *`` UTC)
    or by the external-trigger API.  This is the "today's tasks" view
    operations teams watch.  Status flow:
        pending → running → completed | failed | skipped | cancelled
    """
    __tablename__ = "feed_runs"
    # Foundation P (BRD 2026-09-02, FR-RUN-01 / D6) — run identity is
    # (feed_config_id, business_date, build_id).  The old contract was ONE
    # row per (feed_config_id, business_date) — which made a re-run or a
    # backfill of an already-run date impossible at the schema level.  Two
    # PARTIAL unique indexes replace it so BOTH contracts hold at once:
    #   * legacy creators (SOD generator, any unwired trigger path) write
    #     build_id=NULL and keep the exact old guarantee — one row per
    #     (feed, date);
    #   * build-aware creators get (feed, date, build_id) identity — two
    #     builds for the same date coexist, the SAME build_id twice still
    #     collides.
    # NOTE for deployed DBs: an index/constraint change never reaches an
    # existing table via create_all(); _apply_postgresql_migrations in
    # core/database.py performs the create-new-then-drop-old swap.
    __table_args__ = (
        Index(
            "ux_feed_runs_one_per_feed_per_date_legacy",
            "feed_config_id", "business_date",
            unique=True,
            postgresql_where=sa_text("build_id IS NULL"),
            sqlite_where=sa_text("build_id IS NULL"),
        ),
        Index(
            "ux_feed_runs_identity",
            "feed_config_id", "business_date", "build_id",
            unique=True,
            postgresql_where=sa_text("build_id IS NOT NULL"),
            sqlite_where=sa_text("build_id IS NOT NULL"),
        ),
        # 2026-09-15 — the caller's Idempotency-Key is UNIQUE per feed while
        # its run row exists, so a replay races safely: the second INSERT
        # loses inside the database and the route answers with the first
        # row.  Partial, so every row without a key (SOD, manual, rerun)
        # is untouched.  Existing PG tables get it from
        # core/database.py::_apply_postgresql_migrations (an index never
        # reaches an existing table via create_all).
        Index(
            FEED_RUN_IDEMPOTENCY_INDEX,
            "feed_config_id", "idempotency_key",
            unique=True,
            postgresql_where=sa_text("idempotency_key IS NOT NULL"),
            sqlite_where=sa_text("idempotency_key IS NOT NULL"),
        ),
    )

    id              = Column(Integer, primary_key=True, index=True)
    feed_config_id  = Column(Integer, ForeignKey("feed_configs.id", ondelete="CASCADE"),
                              nullable=False, index=True)
    # 2026-09-15 — the ``Idempotency-Key`` header the external trigger
    # (``POST /api/v1/feeds/{id}/trigger``) was called with; Clockwork's
    # ``qs_api`` type sends its fire key here on EVERY request.  Until this
    # column the route never read the header: it deduped on (feed,
    # business_date) only while a run was pending|running, so the same
    # fire key replayed after the run COMPLETED started a second run and a
    # second delivery -- a declaration of ``idempotent: true`` on the job
    # that the target made false.  NULL for every run not started through
    # that route.  Honoured for as long as this row exists (no TTL): the
    # key names ONE occurrence, a deliberate re-drive carries a fresh key,
    # and a window would re-open exactly where a late replay lands.
    # Declared in core/database.py::_MIGRATIONS["feed_runs"] too -- a new
    # COLUMN never reaches a deployed table via create_all.
    idempotency_key = Column(String(FEED_RUN_IDEMPOTENCY_KEY_LEN), nullable=True)
    # Phase 132.38 deep-dive — persist the WhereClauseMapping
    # consumer overrides passed at trigger time so a rerun can replay
    # them.  Nullable so SOD-created rows (no overrides) stay legacy.
    consumer_overrides = Column(JSON, nullable=True)
    # business_date may differ from run_date (e.g. weekend-rolled-back
    # date or month-end calculations).  Drives all filename / SQL
    # parameter substitution.
    business_date   = Column(Date, nullable=False, index=True)
    run_date        = Column(Date, nullable=False)
    scheduled_time  = Column(DateTime, nullable=True)
    started_at      = Column(DateTime, nullable=True)
    completed_at    = Column(DateTime, nullable=True)
    status          = Column(String(20), default="pending", index=True)
    priority        = Column(Integer, default=5, index=True)
    sla_from        = Column(String(20), nullable=True)
    sla_to          = Column(String(20), nullable=True)
    sla_breached    = Column(Boolean, default=False, index=True)
    # 'RUN' or 'SKIP' — the outcome of action_condition_sql.
    action_decision = Column(String(10), default="RUN")
    action_reason   = Column(Text, nullable=True)
    output_path     = Column(Text, nullable=True)
    control_file_path = Column(Text, nullable=True)
    total_rows      = Column(BigInteger, default=0)
    file_size_bytes = Column(BigInteger, default=0)
    error           = Column(Text, nullable=True)
    retry_count     = Column(Integer, default=0)
    # 'sod' / 'manual' / 'external' / 'scheduled'.  Tracks who created
    # this run so audit + filter-by-source works in the admin UI.
    triggered_by    = Column(String(20), default="sod")
    triggered_by_user = Column(String(100), nullable=True)
    # BF-594 (2026-05-30): `claimed_by` is set by the queue worker on
    # atomic claim — distinct from `triggered_by` (the original source).
    # The reset-to-pending-on-dispatch-failure path filters by
    # `claimed_by` so it doesn't trample a cross-pod claim, while
    # `triggered_by` continues to drive notification routing (preserving
    # lineage).  Nullable so legacy rows without a claim are unaffected.
    claimed_by      = Column(String(100), nullable=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    # ── Foundation P (BRD 2026-09-02, FR-RUN-01/03, FR-GOV-01) ──────────
    # ALL nullable so every pre-existing row stays valid and every unwired
    # creator keeps working (a NULL build_id row is governed by the legacy
    # partial index above, exactly the pre-P contract).
    # build_id: short, sortable, opaque attempt id — generated by
    # core/feed/pinning.py:new_build_id().  Run identity is
    # (feed_config_id, business_date, build_id).
    build_id          = Column(String(40), nullable=True, index=True)
    # Definition pin, written ONCE at claim time (core/feed/pinning.py):
    # pinned_version_id → feed_definition_versions.id (the snapshot row).
    # No FK on purpose: the pin must survive even if the version row is
    # archived; resolve_pinned() fails LOUD (never silently) when it
    # cannot load the version.
    pinned_version_id = Column(Integer, nullable=True)
    pinned_git_commit = Column(String(64), nullable=True)   # may be absent (no deploy stamp yet)
    pinned_image_tag  = Column(String(200), nullable=True)
    pinned_at         = Column(DateTime, nullable=True)
    # Heartbeat written by the executing worker while it holds the claim.
    # The orphan reaper (mixin_feeds.reap_orphaned_feed_runs) keys on THIS,
    # not on age alone — a healthy long run keeps beating and is never
    # reaped (FR-RUN-08 pattern, BRD §19 D6).
    heartbeat_at      = Column(DateTime, nullable=True)
    # ── FR-OPS-06..09 (2026-09-02) — BACKFILL ──────────────────────────
    # run_type: the CLASS of run — 'scheduled' (SOD/cron/manual paths) or
    # 'backfill' (an operator-declared date-range re-run).  NULL = legacy
    # row, read as 'scheduled'.  The class drives two behaviours: the
    # queue admits pending backfill rows outside its business-date
    # lookback window (a backfill's business_date is historical BY
    # DEFINITION), and backfills enter at the least important priority so
    # tonight's scheduled work always outranks them (core/feed/claims.py).
    run_type          = Column(String(20), nullable=True, index=True)
    # suppress_delivery: FR-OPS-08 — this run PRODUCES but must NOT
    # deliver.  Default for every backfill; turning delivery on is an
    # explicit, audited launch choice.  NULL/False = deliver (legacy).
    # Consulted by DeliveryHopRunner.execute_chain via
    # mixin_feeds.feed_run_delivery_suppressed — the suppressed hop rows
    # are still written, and an operator retry of one suppressed hop is
    # the deliberate, audited path to sending it later.
    suppress_delivery = Column(Boolean, nullable=True)
    # backfill_batch_id: groups every run of ONE backfill launch so the
    # API can report per-item outcomes and an operator can ask "how is
    # my backfill of last month doing?" with one filter.
    backfill_batch_id = Column(String(40), nullable=True, index=True)
    # ── 2026-10-03 — ON COMPLETION OF (core/feed/upstream_completion.py) ──
    # A run created because its UPSTREAM feed's run completed AND delivered
    # (``triggered_by='upstream_completion'``) names what started it, so the
    # Today page and the run detail can say "started because X completed".
    # NULL on every other run.  Declared in core/database.py::_MIGRATIONS
    # ["feed_runs"] too -- a new COLUMN never reaches a deployed table via
    # create_all.
    upstream_feed_name     = Column(String(255), nullable=True)
    upstream_execution_id  = Column(String(100), nullable=True)
    upstream_feed_run_id   = Column(Integer, nullable=True)
    # 2026-10-11 -- when the dependency gate RELEASED this run (WAIT -> RUN).
    # The queue worker's lookback measures the recency of the decision to run
    # (created_at / released_at), not the business date: a month-end run whose
    # data arrives a week late must still run.  NULL = never gated.
    released_at            = Column(DateTime, nullable=True)
    # 2026-10-12 -- the lane an operator's RE-RUN asked for (?backend=),
    # read by the queue worker that executes the re-queued run
    # (api/feed_api.py::_requeue_for_rerun).  NULL = the router decides.
    rerun_backend          = Column(String(20), nullable=True)
    # 2026-10-12 -- a re-run of ONLY the failed side carries the OTHER side's
    # kept record (core/feed/side_resume.py); the engine re-verifies it.
    # NULL = read every side.
    rerun_reuse            = Column(JSON, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "feed_config_id": self.feed_config_id,
            "rerun_backend": self.rerun_backend,
            "rerun_reuse": self.rerun_reuse,
            "business_date": self.business_date.isoformat() if self.business_date else None,
            "run_date": self.run_date.isoformat() if self.run_date else None,
            "scheduled_time": self.scheduled_time.isoformat() if self.scheduled_time else None,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "status": self.status,
            "priority": self.priority,
            "sla_from": self.sla_from,
            "sla_to": self.sla_to,
            "sla_breached": self.sla_breached,
            "action_decision": self.action_decision,
            "action_reason": self.action_reason,
            "output_path": self.output_path,
            "control_file_path": self.control_file_path,
            "total_rows": self.total_rows,
            "file_size_bytes": self.file_size_bytes,
            "error": self.error,
            "retry_count": self.retry_count,
            "triggered_by": self.triggered_by,
            "triggered_by_user": self.triggered_by_user,
            "claimed_by": self.claimed_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "consumer_overrides": self.consumer_overrides or None,
            # Foundation P — additive keys; None on every legacy row.
            "build_id": self.build_id,
            "pinned_version_id": self.pinned_version_id,
            "pinned_git_commit": self.pinned_git_commit,
            "pinned_image_tag": self.pinned_image_tag,
            "pinned_at": self.pinned_at.isoformat() if self.pinned_at else None,
            "heartbeat_at": self.heartbeat_at.isoformat() if self.heartbeat_at else None,
            # FR-OPS-06..09 — NULL run_type is a legacy scheduled-class row.
            "run_type": self.run_type or "scheduled",
            "suppress_delivery": bool(self.suppress_delivery),
            "backfill_batch_id": self.backfill_batch_id,
            "idempotency_key": self.idempotency_key,
            # 2026-10-03 — the upstream completion that started this run
            # (None unless triggered_by == 'upstream_completion').
            "upstream_feed_name": self.upstream_feed_name,
            "upstream_execution_id": self.upstream_execution_id,
            "upstream_feed_run_id": self.upstream_feed_run_id,
            "released_at": self.released_at.isoformat() if self.released_at else None,
        }


# Phase 130 hotfix-7 — Entitlement Groups (user_groups + user_group_members).
# Resources can be owned by a GROUP in addition to the individual
# created_by.  Any member of the group can act on the resource as the
# owner would.  Permission resolver lives in core/feed/permissions.py.


class UserGroup(Base):
    """Named entitlement group.  Members get permissions on resources
    marked with owner_group_id=this.id.  Phase 130 hotfix-13 added
    per-member ``resource_access_level`` (read_only / read_write) and
    a group-level ``notification_email`` for failure / SLA alerts.

    Group names are unique + indexed so the admin UI can look them up
    by name in pickers.  Roles within the group are tracked on
    user_group_members.role_in_group ('member' | 'owner' | 'admin') —
    group-level admins can manage membership without being a system
    admin.
    """
    __tablename__ = "user_groups"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(100), unique=True, nullable=False, index=True)
    description = Column(Text, nullable=True)
    is_active   = Column(Boolean, default=True)
    # Phase 130 hotfix-13: comma-separated list of emails to notify on
    # group-owned resource events (feed failure, SLA breach, etc.).
    # NULL = fall back to per-resource notification recipients.
    notification_email = Column(String(500), nullable=True)
    created_by  = Column(String(100), nullable=True)
    created_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                          onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "is_active": self.is_active,
            "notification_email": self.notification_email,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class UserGroupMember(Base):
    """Many-to-many user<->group membership.

    UNIQUE(group_id, username) means a user appears at most once in a
    given group.

    Two orthogonal authority dimensions:
      - ``role_in_group`` — GROUP-internal authority (membership mgmt):
          'member' / 'owner' / 'admin'.  Owners + admins can add/remove
          members.
      - ``resource_access_level`` — RESOURCE permission (Phase 130
          hotfix-13).  'read_only' members can view+download outputs
          of group-owned resources but cannot edit / rerun / cancel.
          'read_write' members get full owner-equivalent permission.
          Default 'read_write' for backwards-compat with the
          pre-hotfix behaviour where every member was full-access.
    """
    __tablename__ = "user_group_members"
    __table_args__ = (
        UniqueConstraint("group_id", "username", name="ux_user_group_members_group_user"),
    )

    id            = Column(Integer, primary_key=True, index=True)
    group_id      = Column(Integer, ForeignKey("user_groups.id", ondelete="CASCADE"),
                            nullable=False, index=True)
    username      = Column(String(100), nullable=False, index=True)
    role_in_group = Column(String(20), default="member")
    # Phase 130 hotfix-13: per-member resource access flavour.
    # 'read_only' | 'read_write'.  Defaults to 'read_write' so existing
    # memberships pre-hotfix keep their full-access behaviour.
    #
    # 2026-08-23 (plan §9.2): ``server_default`` added alongside ``default``.
    # ``default=`` is applied CLIENT-SIDE by the ORM at INSERT, so a fresh
    # CREATE TABLE and the whole test suite look healthy — but the online
    # auto-migrator (``database._auto_migrate_from_models``) SKIPS adding a
    # NOT NULL column with no ``server_default`` (SQLite cannot ALTER-ADD a
    # NOT NULL column without a DEFAULT), printing "Runtime INSERTs will
    # fail". On a pre-hotfix-13 SQLite DB the column then never appears, and
    # every read that SELECTs it (``list_groups_for_user``, the entitlement
    # membership check) raises ``no such column`` — which the entitlement
    # layer catches and turns into a SILENT fail-closed revocation of every
    # group member's access. ``server_default`` makes the ALTER render
    # ``NOT NULL DEFAULT 'read_write'`` and backfill existing rows, matching
    # the alembic intent (002_phase_130_hotfix_13).
    resource_access_level = Column(String(20), default="read_write",
                                   server_default="read_write", nullable=False)
    added_by      = Column(String(100), nullable=True)
    added_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "group_id": self.group_id,
            "username": self.username,
            "role_in_group": self.role_in_group,
            "resource_access_level": self.resource_access_level or "read_write",
            "added_by": self.added_by,
            "added_at": self.added_at.isoformat() if self.added_at else None,
        }


class FeedControlFileFormat(Base):
    """DB-driven control-file (.ctl) format template — Phase 130 hotfix-4.

    Each row defines ONE layout / checksum combination.  feed_configs
    references a row by id; the writer reads the spec and renders
    accordingly.  No hardcoded business defaults — admins seed,
    edit, clone freely via the admin UI.

    Style options:
      - ``key_value``  — ``FIELD=value`` one per line (default)
      - ``delimited``  — single line, fields joined by ``delimiter``
      - ``fixed_width``— each field padded to ``field_specs[name].width``

    Checksum algorithms:
      - ``md5``, ``sha1``, ``sha256``, ``sha512``, ``crc32``, ``none``
      - Multiple via ``checksum_algorithms`` JSON list (computed in a
        single read pass).  Single via ``checksum_algorithm`` string.

    Fields are an ORDERED JSON list of identifiers.  Per-field
    customisation lives in ``field_specs`` (JSON dict).  Recognised
    field names (writer maps these to ControlFileRecord fields):
      filename, row_count, byte_size, business_date, feed_name,
      feed_id, run_id, generated_at, plus
      checksum_md5 / checksum_sha1 / checksum_sha256 / checksum_sha512
      / checksum_crc32.
    """
    __tablename__ = "feed_control_file_formats"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(100), unique=True, nullable=False, index=True)
    description = Column(Text, nullable=True)
    style       = Column(String(20), default="key_value")
    delimiter   = Column(String(8), default="|")
    # Ordered list of field identifiers to render.  Example:
    #   ["filename", "row_count", "byte_size", "checksum_md5",
    #    "business_date", "generated_at"]
    fields      = Column(JSON, nullable=True)
    # Optional per-field overrides:
    #   {"filename": {"label": "FILE_NAME", "width": 40, "pad": "right"},
    #    "row_count": {"label": "TOTAL_ROWS"}, ...}
    field_specs = Column(JSON, nullable=True)
    # Single algorithm (back-compat shortcut).  When checksum_algorithms
    # is set, that wins.
    checksum_algorithm  = Column(String(20), default="sha256")
    checksum_algorithms = Column(JSON, nullable=True)
    date_format         = Column(String(50), default="%Y%m%d")
    datetime_format     = Column(String(50), default="%Y-%m-%dT%H:%M:%SZ")
    is_active           = Column(Boolean, default=True)
    is_default          = Column(Boolean, default=False)
    created_by          = Column(String(100), nullable=True)
    created_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                                  onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "style": self.style,
            "delimiter": self.delimiter,
            "fields": self.fields,
            "field_specs": self.field_specs,
            "checksum_algorithm": self.checksum_algorithm,
            "checksum_algorithms": self.checksum_algorithms,
            "date_format": self.date_format,
            "datetime_format": self.datetime_format,
            "is_active": self.is_active,
            "is_default": self.is_default,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


def delivery_verdict_of(stage_timings) -> Optional[str]:
    """``stage_timings.delivery_chain.verdict`` or None.  The verdict is
    written by ``core.feed.delivery_hops.chain_verdict`` (native / airflow),
    the webhook (spark job delivered) and the webhook-side delivery; this
    only READS the slot they all write."""
    if not isinstance(stage_timings, dict):
        return None
    chain = stage_timings.get("delivery_chain")
    if not isinstance(chain, dict):
        return None
    verdict = chain.get("verdict")
    return str(verdict) if verdict else None


def artifact_unavailable_reason_of(stage_timings) -> Optional[str]:
    """Why a run's produced file can NOT be downloaded, as the run recorded
    it (``stage_timings.artifact``, written by the Spark webhook-side path:
    pod-local artifacts, a multi-file output), or None."""
    if not isinstance(stage_timings, dict):
        return None
    art = stage_timings.get("artifact")
    if not isinstance(art, dict) or art.get("retrievable"):
        return None
    reason = art.get("reason")
    return str(reason) if reason else None


class FeedExecution(Base):
    """Execution history for a feed file generation job (Phase 76)."""
    __tablename__ = "feed_executions"

    id                    = Column(Integer, primary_key=True, index=True)
    feed_config_id        = Column(Integer, nullable=False, index=True)
    execution_id          = Column(String(100), unique=True, nullable=False, index=True)
    status                = Column(String(30), default="pending")       # pending | running | completed | failed | cancelled
    execution_backend     = Column(String(20), nullable=True)

    trigger_type          = Column(String(20), nullable=False)          # manual | scheduled | retry | webhook
    triggered_by          = Column(String(100), nullable=True)

    started_at            = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    query_completed_at    = Column(DateTime, nullable=True)
    delivery_completed_at = Column(DateTime, nullable=True)
    completed_at          = Column(DateTime, nullable=True)

    total_rows            = Column(BigInteger, default=0)
    file_size_bytes       = Column(BigInteger, default=0)
    output_format         = Column(String(20), nullable=True)
    output_filename       = Column(String(500), nullable=True)
    destination_path      = Column(String(1000), nullable=True)
    # 2026-10-07 -- the file the run PRODUCED, on the shared output volume
    # (feed_generation.output_dir), recorded whether or not it was
    # delivered.  ``destination_path`` stays "where it WENT" (empty when
    # nothing went).  A backfill without delivery used to complete with
    # neither: the file sat on the volume and Download answered 404.
    # Native / airflow lanes write it; a spark_k8s run's artifacts are in
    # the job's store, not here.  NULL on rows that predate it.
    artifact_path         = Column(String(1000), nullable=True)
    # 2026-10-07 -- "must this run NOT deliver?", decided ONCE when the
    # execution is created (from the bound feed_run's suppress_delivery: a
    # backfill launched without delivery) and READ by every lane after it:
    # the native hop runner, the spark_k8s job conf (deliver_in_job), the
    # Airflow conf and the Spark webhook-side delivery.  The webhook used
    # to ask "is a SUPPRESSED run still RUNNING for this date?", which
    # races the completed write.  NULL = no bound run (legacy / Run Now).
    delivery_suppressed   = Column(Boolean, nullable=True)

    external_job_id       = Column(String(200), nullable=True)
    # 2026-09-14 -- the workload SHAPE this execution was submitted as
    # ("spark_application" | "driver_pod"), written once by
    # core/spark_k8s/runner.py::submit and read by cancel, status and the
    # reconciler; NULL on rows that predate it (= spark_application).
    # ALSO declared in DatabaseManager._MIGRATIONS: create_all never adds
    # a column to a deployed table.
    submit_mode           = Column(String(24), nullable=True)
    error_message         = Column(Text, nullable=True)
    retry_count           = Column(Integer, default=0)
    retry_of_execution_id = Column(String(100), nullable=True)
    duration_seconds      = Column(Float, nullable=True)
    # Phase 130 hotfix-13 — CBQ-parity per-stage observability.
    # ``stage_timings`` is a dict ``{stage_name: seconds}`` populated
    # at completion / failure so the dashboard can show a per-stage
    # breakdown (mirror of the query_executions stage_history).
    stage_timings         = Column(JSON, nullable=True)
    # ``failed_stage`` names the stage where execution broke (set on
    # failure only).  Lets ops see the failure point at-a-glance
    # without parsing the traceback in error_message.
    failed_stage          = Column(String(50), nullable=True)
    # Phase 131 deep-dive #13 (round 16) — BQB-parity log+timeline.
    # Mirrors ``query_executions.files_metadata``: a JSON envelope
    # carrying ``stage_history`` (list of {stage, stage_label,
    # duration_seconds, files_done, bytes_done, in_flight}) +
    # ``log_lines`` (list of {ts, level, logger, msg, stage}) +
    # ``total_seconds``.  Populated at finalisation; surfaced via
    # /api/feed-executions/{id}/performance for the dashboard chip.
    files_metadata        = Column(JSON, nullable=True)
    # 2026-10-07 -- does the pod that EXECUTES this run stream its log
    # lines live ("live") or not ("none": the scheduler pod's relay, or no
    # broadcast at all)?  DECLARED by whoever installed the engine's
    # broadcast (core/feed/event_audience.py::run_log_stream_of) and
    # recorded when the engine claims the row; NULL = unrecorded (a row
    # older than this column, or not yet claimed).  The UI reads the
    # projection ``run_log`` (core/feed/run_log_view.py), never guesses.
    log_stream            = Column(String(12), nullable=True)

    # ── Foundation P (BRD 2026-09-02, FR-RUN-01/03, FR-GOV-01) ──────────
    # ALL nullable so every pre-existing row stays valid.  business_date
    # did not exist on this table at all before Foundation P — an
    # execution could not say WHICH date it produced, which is why the
    # old one-active index had to be per-feed (D6).
    business_date         = Column(Date, nullable=True, index=True)
    build_id              = Column(String(40), nullable=True, index=True)
    pinned_version_id     = Column(Integer, nullable=True)   # → feed_definition_versions.id
    pinned_git_commit     = Column(String(64), nullable=True)
    pinned_image_tag      = Column(String(200), nullable=True)
    # Heartbeat for the orphan reaper (reap_orphaned_feed_executions) —
    # keyed on the beat, not on age alone, so a healthy long run is never
    # reaped while a dead pod's claim is reclaimed and stops blocking the
    # one-active guard (BRD §19 D6 "blocks the feed permanently").
    heartbeat_at          = Column(DateTime, nullable=True)

    # D6 replacement (BRD §19; was BF-415) — the old single partial index
    # ``ux_feed_executions_one_active_per_feed`` enforced ONE ACTIVE
    # EXECUTION PER FEED, which forbade child runs and forbade backfilling
    # a date that had already run.  Three partial unique indexes replace
    # it WITHOUT losing the protection it provided:
    #   1. legacy rows (business_date IS NULL — every unwired creator,
    #      including create_feed_execution_atomic today) keep the EXACT
    #      old guard: one active execution per feed;
    #   2. date-aware rows get one ACTIVE execution per (feed, date) —
    #      two concurrent triggers for the same feed+date still collide
    #      with IntegrityError, while backfills of OTHER dates run
    #      concurrently and a completed row never blocks a re-run;
    #   3. run identity (feed, date, build_id) is unique across ALL
    #      statuses — the same build_id twice collides even after the
    #      first attempt completed (FR-RUN-01).
    # The DAO still translates IntegrityError to None (BF-415 contract).
    # Deployed DBs get the create-new-then-drop-old swap in
    # core/database.py::_apply_postgresql_migrations — create_all() never
    # alters an existing table.
    __table_args__ = (
        Index(
            "ux_feed_executions_one_active_legacy",
            "feed_config_id",
            unique=True,
            postgresql_where=sa_text(
                "status IN ('pending','running') AND business_date IS NULL"),
            sqlite_where=sa_text(
                "status IN ('pending','running') AND business_date IS NULL"),
        ),
        Index(
            "ux_feed_executions_one_active_per_date",
            "feed_config_id", "business_date",
            unique=True,
            postgresql_where=sa_text(
                "status IN ('pending','running') AND business_date IS NOT NULL"),
            sqlite_where=sa_text(
                "status IN ('pending','running') AND business_date IS NOT NULL"),
        ),
        Index(
            "ux_feed_executions_identity",
            "feed_config_id", "business_date", "build_id",
            unique=True,
            postgresql_where=sa_text(
                "build_id IS NOT NULL AND business_date IS NOT NULL"),
            sqlite_where=sa_text(
                "build_id IS NOT NULL AND business_date IS NOT NULL"),
        ),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "feed_config_id": self.feed_config_id,
            "execution_id": self.execution_id,
            "status": self.status,
            "execution_backend": self.execution_backend,
            "trigger_type": self.trigger_type,
            "triggered_by": self.triggered_by,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "query_completed_at": self.query_completed_at.isoformat() if self.query_completed_at else None,
            "delivery_completed_at": self.delivery_completed_at.isoformat() if self.delivery_completed_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "total_rows": self.total_rows,
            "file_size_bytes": self.file_size_bytes,
            "output_format": self.output_format,
            "output_filename": self.output_filename,
            "destination_path": self.destination_path,
            "artifact_path": self.artifact_path,
            "delivery_suppressed": self.delivery_suppressed,
            # why there is no downloadable file, when the run said so
            "artifact_unavailable_reason": artifact_unavailable_reason_of(
                self.stage_timings),
            # 2026-10-07 -- the delivery VERDICT (delivered / suppressed /
            # dry_run / failed) hoisted from stage_timings.delivery_chain,
            # so a screen can say "completed, NOT delivered" without
            # re-deriving it.  None = no verdict recorded (unknown, never
            # "delivered").
            "delivery_verdict": delivery_verdict_of(self.stage_timings),
            "external_job_id": self.external_job_id,
            # 2026-09-14 -- the STORED workload shape.  The column was added
            # and written first; this explicit list omitted it, so every
            # reader fell back to the legacy CR shape and a driver_pod run was
            # looked up as "<name>-driver".  A value stored and not read back.
            "submit_mode": self.submit_mode,
            "error_message": self.error_message,
            "retry_count": self.retry_count,
            "retry_of_execution_id": self.retry_of_execution_id,
            "duration_seconds": self.duration_seconds,
            "stage_timings": self.stage_timings,
            "failed_stage": self.failed_stage,
            "files_metadata": self.files_metadata,
            "log_stream": self.log_stream,
            # Foundation P — additive keys; None on every legacy row.
            "business_date": self.business_date.isoformat() if self.business_date else None,
            "build_id": self.build_id,
            "pinned_version_id": self.pinned_version_id,
            "pinned_git_commit": self.pinned_git_commit,
            "pinned_image_tag": self.pinned_image_tag,
            "heartbeat_at": self.heartbeat_at.isoformat() if self.heartbeat_at else None,
        }


class FeedTemplateApplyRequest(Base):
    """A feed template create / update / apply REQUESTED FROM SQL
    (2026-10-13; the owner: "5000 jobs ... can I do it directly from
    PostgreSQL, like an Oracle package?").  ``qs_feed_template_apply(...)``
    inserts a row; the scheduler's template-request job applies it through
    THE template routes (every authoring rule, background-safe) and writes
    the outcome back.  Never a direct write to feed_configs."""
    __tablename__ = "feed_template_apply_requests"

    id             = Column(Integer, primary_key=True, index=True)
    template_name  = Column(String(100), nullable=False, index=True)
    requested_by   = Column(String(100), nullable=True)
    parameters     = Column(JSON, nullable=True)     # None = keep the template's
    feed           = Column(SecretJSON, nullable=True)
    dependencies   = Column(JSON, nullable=True)
    matrix         = Column(JSON, nullable=True)
    retire_missing = Column(Boolean, nullable=False, default=False)
    dry_run        = Column(Boolean, nullable=False, default=False)
    #: pending -> running -> done | failed
    state          = Column(String(20), nullable=False, default="pending", index=True)
    template_id    = Column(Integer, nullable=True)
    counts         = Column(JSON, nullable=True)
    report         = Column(JSON, nullable=True)
    error          = Column(Text, nullable=True)
    requested_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    started_at     = Column(DateTime, nullable=True)
    finished_at    = Column(DateTime, nullable=True)


class FeedTemplate(Base):
    """A PARAMETERISED feed definition and the matrix it is applied to
    (2026-10-10, the owner's ~4,000 monthly (SYSTEM_ENTITY, EventCode)
    feeds).

    ``definition`` holds the feed body (a FeedConfigCreate-shaped dict whose
    string fields may carry ``{PARAM}`` tokens), the ``dependencies`` to
    declare on every member (their keys may carry tokens too) and the
    ordered ``parameters``; ``matrix`` is the list of parameter rows.
    Applying it renders one ``feed_configs`` row per matrix row
    (``core/feed/feed_template.py``), idempotently: a member is found by
    (``feed_configs.template_id``, ``template_member_key``), compared and
    left alone / updated / created; a template edit propagates to every
    member on the next apply.  N feed rows, not one feed with a fan-out:
    each combination is held on ITS OWN Kafka message, released, run,
    delivered and certified by itself -- "a feed run is a feed run".

    NEW TABLE: self-creates via create_all (listed in _MIGRATIONS as []).
    """
    __tablename__ = "feed_templates"

    id              = Column(Integer, primary_key=True, index=True)
    name            = Column(String(100), unique=True, nullable=False, index=True)
    description     = Column(Text, nullable=True)
    #: ordered parameter names, e.g. ["SYSTEM_ENTITY", "EventCode"]
    parameters      = Column(JSON, nullable=False)
    #: {"feed": {...tokens...}, "dependencies": [...]}
    definition      = Column(SecretJSON, nullable=False)
    #: [{"SYSTEM_ENTITY": "GB01", "EventCode": "EOM"}, ...]
    matrix          = Column(JSON, nullable=False)
    definition_hash = Column(String(64), nullable=True)
    is_active       = Column(Boolean, default=True)
    created_by      = Column(String(100), nullable=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                             onupdate=lambda: datetime.now(timezone.utc))
    last_applied_at = Column(DateTime, nullable=True)
    last_apply_report = Column(JSON, nullable=True)
    #: 2026-10-10 (later) -- the apply as a JOB (core/feed/feed_template.py):
    #: the claim (one apply at a time; a compare-and-swap on this column) and
    #: the job record a poller reads (state, done/total, heartbeat, report).
    #: Both in _MIGRATIONS["feed_templates"].
    apply_job_id    = Column(String(64), nullable=True)
    apply_status    = Column(JSON, nullable=True)
    #: 2026-10-11 -- AUTO-ONBOARDING (core/feed/auto_onboard.py): when a
    #: COMPLETE message names a system entity no feed declares, the template
    #: whose declaration matches the message creates that member itself.
    #: {"match": {"DATA_SOURCE": "finance_sl_balance"},
    #:  "params": {"SYSTEM_ENTITY": "CODE", "EventCode": "BUSINESS_EVENT"},
    #:  "events": ["EOD", "ME5"]   (optional: only these events)}
    #: None = this template never onboards.  In _MIGRATIONS["feed_templates"].
    auto_onboard    = Column(JSON, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "parameters": list(self.parameters or []),
            "definition": self.definition or {},
            "matrix": list(self.matrix or []),
            "definition_hash": self.definition_hash,
            "is_active": self.is_active,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "last_applied_at": (self.last_applied_at.isoformat()
                                if self.last_applied_at else None),
            "last_apply_report": self.last_apply_report,
            "apply_job_id": self.apply_job_id,
            "apply_status": self.apply_status,
            "auto_onboard": self.auto_onboard,
        }


class FeedOnboardingRequest(Base):
    """A new system entity a COMPLETE message named, and what became of it
    (2026-10-11, core/feed/auto_onboard.py).

    The owner's case: ~4,000 entities today, and a NEW one can appear in any
    month-end's Kafka / QS_KAFKA_MESSAGE traffic.  The arrival is recorded on
    the dependency ledger and marked UNMATCHED (no feed declares it); this row
    is the request to create that entity's feed from the template its
    DATA_SOURCE names -- written by the resolver, carried out by
    ``auto_onboard.process_requests``.  ONE row per (template, member): the
    entity's cloud and on-prem messages land on the same row.

    ``status``: pending -> onboarded (feed created / already present) |
    refused (the template's authoring rules said no, with the reason) |
    failed (an error, retried up to MAX_ATTEMPTS).  ``run`` says what SOD did
    for the message's business date (created / not_due / exists / error).

    NEW TABLE: self-creates via create_all (listed in _MIGRATIONS as []).
    """
    __tablename__ = "feed_onboarding_requests"
    __table_args__ = (
        UniqueConstraint("template_id", "member_key", name="ux_feed_onboarding_member"),
    )

    id              = Column(Integer, primary_key=True, index=True)
    template_id     = Column(Integer, ForeignKey("feed_templates.id", ondelete="CASCADE"),
                             nullable=False, index=True)
    member_key      = Column(String(400), nullable=False)
    #: the template parameter values taken from the message
    values          = Column(JSON, nullable=False)
    business_date   = Column(Date, nullable=True)
    dependency_name = Column(String(300), nullable=True)
    #: kafka | oracle_table, and the message's identity on that road
    source          = Column(String(30), nullable=True)
    message_identity = Column(String(300), nullable=True)
    status          = Column(String(20), nullable=False, default="pending", index=True)
    feed_config_id  = Column(Integer, nullable=True)
    run             = Column(String(30), nullable=True)
    detail          = Column(Text, nullable=True)
    attempts        = Column(Integer, nullable=False, default=0)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                             onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "template_id": self.template_id, "member_key": self.member_key,
            "values": dict(self.values or {}),
            "business_date": self.business_date.isoformat() if self.business_date else None,
            "dependency_name": self.dependency_name, "source": self.source,
            "message_identity": self.message_identity, "status": self.status,
            "feed_config_id": self.feed_config_id, "run": self.run, "detail": self.detail,
            "attempts": self.attempts,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


#: A variance hold's states (core/feed/variance_hold.py).  ``held`` -> the
#: release group decides: ``releasing`` (claimed, the file is being sent) ->
#: ``released`` | ``release_failed`` (may be released again); or
#: ``rejected``.  ``superseded``: a later execution of the same (feed,
#: business date) replaced this file before anyone decided.
FEED_VARIANCE_HOLD_STATUSES = ("held", "releasing", "released", "release_failed",
                               "rejected", "superseded")


class FeedVarianceHold(Base):
    """A produced file the row-count check HELD instead of delivering
    (2026-10-12, owner request R2; core/feed/variance_hold.py).

    The owner: "if the count increased or reduced between today and
    yesterday beyond the threshold we should not send files downstream via
    SFTP -- hold it for the RTB support team to verify, and only then send".
    A feed declaring ``row_count_action = 'hold'`` whose count breaches its
    threshold completes WITHOUT delivery (chain verdict ``held``); this row
    is the queue entry: the numbers, the kept file, and the decision.  The
    release sends THAT file -- never a regenerated one -- through the feed's
    delivery chain; only a member of the configured release group
    (``feed_generation.variance_hold_release_group``) may decide.

    NEW TABLE: self-creates via create_all (listed in _MIGRATIONS as []).
    """
    __tablename__ = "feed_variance_holds"
    __table_args__ = (
        UniqueConstraint("execution_db_id", name="ux_feed_variance_hold_execution"),
    )

    id               = Column(Integer, primary_key=True, index=True)
    feed_config_id   = Column(Integer, nullable=False, index=True)
    feed_name        = Column(String(255), nullable=True)
    feed_run_id      = Column(Integer, nullable=True, index=True)
    #: feed_executions.id and its execution_id text
    execution_db_id  = Column(Integer, nullable=False)
    execution_id     = Column(String(100), nullable=True)
    business_date    = Column(Date, nullable=True, index=True)
    actual_rows      = Column(BigInteger, nullable=True)
    #: what it was compared with: the previous business date's DELIVERED rows,
    #: or the rolling baseline average
    baseline_rows    = Column(BigInteger, nullable=True)
    baseline_kind    = Column(String(30), nullable=True)
    baseline_business_date = Column(Date, nullable=True)
    delta_pct        = Column(Numeric(12, 3), nullable=True)
    direction        = Column(String(10), nullable=True)
    threshold_pct    = Column(Numeric(7, 2), nullable=True)
    reason           = Column(String(60), nullable=True)
    #: the kept file (feed_executions.artifact_path) -- what a release sends
    artifact_path    = Column(String(1000), nullable=True)
    file_size_bytes  = Column(BigInteger, nullable=True)
    #: what the run would have handed its delivery chain, kept so the
    #: release sends EXACTLY that: filename, control_file_path, sidecar_path
    delivery_inputs  = Column(JSON, nullable=True)
    status           = Column(String(20), nullable=False, default="held", index=True)
    held_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    decided_by       = Column(String(100), nullable=True)
    decided_at       = Column(DateTime, nullable=True)
    decision_reason  = Column(Text, nullable=True)
    #: the release's delivery: the chain verdict, where it went, why it failed
    delivery_verdict = Column(String(30), nullable=True)
    delivered_uri    = Column(String(1000), nullable=True)
    release_error    = Column(Text, nullable=True)
    updated_at       = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                              onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        def _iso(v):
            return v.isoformat() if v is not None else None
        return {
            "id": self.id, "feed_config_id": self.feed_config_id,
            "feed_name": self.feed_name, "feed_run_id": self.feed_run_id,
            "execution_db_id": self.execution_db_id, "execution_id": self.execution_id,
            "business_date": _iso(self.business_date),
            "actual_rows": self.actual_rows, "baseline_rows": self.baseline_rows,
            "baseline_kind": self.baseline_kind,
            "baseline_business_date": _iso(self.baseline_business_date),
            "delta_pct": float(self.delta_pct) if self.delta_pct is not None else None,
            "direction": self.direction,
            "threshold_pct": (float(self.threshold_pct)
                              if self.threshold_pct is not None else None),
            "reason": self.reason, "artifact_path": self.artifact_path,
            "file_size_bytes": self.file_size_bytes, "status": self.status,
            "delivery_inputs": dict(self.delivery_inputs or {}),
            "held_at": _iso(self.held_at), "decided_by": self.decided_by,
            "decided_at": _iso(self.decided_at), "decision_reason": self.decision_reason,
            "delivery_verdict": self.delivery_verdict, "delivered_uri": self.delivered_uri,
            "release_error": self.release_error, "updated_at": _iso(self.updated_at),
        }


#: where a hold-approver mapping applies (core/feed/variance_hold.py)
HOLD_APPROVER_SCOPES = ("global", "feed_group", "template", "feed")


class FeedHoldApprover(Base):
    """Who, besides an admin and the feed's owner, may release or reject a
    HELD file (2026-10-12, the owner: "admin or feed owner ... need generic
    mapping also ... can't just hardcode").  A USER GROUP mapped at a scope:
    ``global`` (every feed), ``feed_group`` (e.g. one system entity's
    group), ``template`` (every member of one template) or ``feed``.
    Data, managed from the Variance holds popup -- never a config constant."""
    __tablename__ = "feed_hold_approvers"
    __table_args__ = (
        UniqueConstraint("scope", "scope_id", "user_group_id", name="ux_feed_hold_approver"),
    )

    id = Column(Integer, primary_key=True, index=True)
    scope = Column(String(20), nullable=False)
    scope_id = Column(Integer, nullable=True)          # NULL for global
    user_group_id = Column(Integer, nullable=False, index=True)
    created_by = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "scope": self.scope, "scope_id": self.scope_id,
                "user_group_id": self.user_group_id, "created_by": self.created_by,
                "created_at": self.created_at.isoformat() if self.created_at else None}


class FeedEnvironment(Base):
    """An ENVIRONMENT a combined feed reads -- DATA, not code (2026-10-12, the
    owner: "all db driven ... no hardcoded in code").  Which side of a feed it
    is, its label on every screen, how a dependency's NAME says it (endings)
    and how a MESSAGE says it (a payload field and its values).  Read by
    core/feed/environments.py; edited at /api/admin/feed-environments."""
    __tablename__ = "feed_environments"
    __table_args__ = (UniqueConstraint("side", name="ux_feed_environment_side"),)

    id = Column(Integer, primary_key=True, index=True)
    side = Column(String(20), nullable=False)             # primary | secondary
    label = Column(String(60), nullable=False)
    dependency_suffixes = Column(JSON, nullable=True)     # ["_CLOUD"]
    message_field = Column(String(120), nullable=True)    # CLOUD_COMPLIANT
    message_values = Column(JSON, nullable=True)          # ["true", "1"]
    sort_order = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    updated_by = Column(String(100), nullable=True)
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "side": self.side, "label": self.label,
                "dependency_suffixes": list(self.dependency_suffixes or []),
                "message_field": self.message_field, "message_values": list(self.message_values or []),
                "sort_order": self.sort_order, "is_active": bool(self.is_active),
                "updated_by": self.updated_by,
                "updated_at": self.updated_at.isoformat() if self.updated_at else None}


class FeedMessageToken(Base):
    """A SQL token whose value is a field of the environment's governing
    upstream message -- the UPSTREAM CONTRACT (core/feed/upstream_contract.py):
    ``{version}`` = the message's VERSION_NUMBER.  DATA (2026-10-12): a new
    token is a row, never code.  Edited at /api/admin/feed-message-tokens."""
    __tablename__ = "feed_message_tokens"
    __table_args__ = (UniqueConstraint("token", name="ux_feed_message_token"),)

    id = Column(Integer, primary_key=True, index=True)
    token = Column(String(60), nullable=False)            # lower case; matched case-insensitively
    message_field = Column(String(120), nullable=False)
    description = Column(String(500), nullable=True)
    is_active = Column(Boolean, default=True)
    updated_by = Column(String(100), nullable=True)
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "token": self.token, "message_field": self.message_field,
                "description": self.description, "is_active": bool(self.is_active),
                "updated_by": self.updated_by,
                "updated_at": self.updated_at.isoformat() if self.updated_at else None}


class FeedMessageField(Base):
    """A field of the upstream MESSAGE and where it is SHOWN (2026-10-12, the
    owner: "what columns are you showing from the Kafka message table" -- the
    tile's and the monitor's columns were spelled in code).  DATA: ``on_tile``
    = the dependency tile on Feed Run Status, ``on_monitor`` = the Upstream
    messages table.  Read by core/feed/message_fields.py; edited at
    /api/admin/feed-message-fields."""
    __tablename__ = "feed_message_fields"
    __table_args__ = (UniqueConstraint("field", name="ux_feed_message_field"),)

    id = Column(Integer, primary_key=True, index=True)
    field = Column(String(120), nullable=False)           # as the message spells it
    label = Column(String(60), nullable=False)
    sort_order = Column(Integer, default=0)
    on_tile = Column(Boolean, default=True)
    on_monitor = Column(Boolean, default=True)
    #: 2026-10-12 -- the field says WHAT the message is about (source, code,
    #: store, event) rather than THIS message (snapshot, version, state,
    #: rows): a WAITING dependency tile shows the identifying fields of the
    #: message it expects, never another message's snapshot
    identifies = Column(Boolean, nullable=True)
    is_active = Column(Boolean, default=True)
    updated_by = Column(String(100), nullable=True)
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "field": self.field, "label": self.label, "sort_order": self.sort_order,
                "on_tile": bool(self.on_tile), "on_monitor": bool(self.on_monitor),
                "identifies": bool(self.identifies),
                "is_active": bool(self.is_active), "updated_by": self.updated_by,
                "updated_at": self.updated_at.isoformat() if self.updated_at else None}


#: the owner's QS_KAFKA_MESSAGE columns, as a fresh database's starting rows
SEED_FEED_MESSAGE_FIELDS = (
    {"field": "DATA_SOURCE", "label": "Source", "sort_order": 10, "on_tile": True, "on_monitor": True, "identifies": True},
    {"field": "CODE", "label": "Code", "sort_order": 20, "on_tile": True, "on_monitor": True, "identifies": True},
    {"field": "DATA_STORE", "label": "Store", "sort_order": 30, "on_tile": True, "on_monitor": False, "identifies": True},
    {"field": "BUSINESS_EVENT", "label": "Event", "sort_order": 40, "on_tile": True, "on_monitor": True, "identifies": True},
    {"field": "BUSINESS_DATE", "label": "Business date", "sort_order": 50, "on_tile": False, "on_monitor": True},
    {"field": "CLOUD_COMPLIANT", "label": "Cloud compliant", "sort_order": 60, "on_tile": False, "on_monitor": True},
    {"field": "SNAP_VERSION", "label": "Snapshot", "sort_order": 70, "on_tile": True, "on_monitor": True},
    {"field": "VERSION_NUMBER", "label": "Version", "sort_order": 80, "on_tile": True, "on_monitor": True},
    {"field": "VERSION_STATE", "label": "State", "sort_order": 90, "on_tile": True, "on_monitor": True},
    {"field": "SOURCE_SYSTEM_NAME", "label": "Source system", "sort_order": 100, "on_tile": False, "on_monitor": False,
     "identifies": True},
    {"field": "ROW_COUNT", "label": "Rows", "sort_order": 110, "on_tile": False, "on_monitor": True},
)


#: what a fresh database starts with (seeded ONCE when the table is empty --
#: from then on the rows are the truth; an admin edits them)
SEED_FEED_ENVIRONMENTS = (
    {"side": "primary", "label": "CLOUD", "dependency_suffixes": ["_CLOUD"],
     "message_field": "CLOUD_COMPLIANT", "message_values": ["true", "1", "y", "yes"], "sort_order": 0},
    {"side": "secondary", "label": "ON-PREM", "dependency_suffixes": ["_ONPREM", "_ON_PREM"],
     "message_field": "CLOUD_COMPLIANT", "message_values": ["false", "0", "n", "no"], "sort_order": 1},
)
SEED_FEED_MESSAGE_TOKENS = (
    {"token": "version", "message_field": "VERSION_NUMBER",
     "description": "the version the environment's message announced"},
    {"token": "snapshot", "message_field": "SNAP_VERSION",
     "description": "the snapshot the environment's message announced"},
)


#: what a re-sent upstream message DOES for a delivered business date
#: (2026-10-12, the owner's month end): DATA mapped at a scope like the hold
#: approvers -- the most specific row wins
RESTATEMENT_ACTIONS = ("decide", "rerun", "hold")
RESTATEMENT_WINDOWS = ("next_business_date", "days", "open")


class FeedRestatementPolicy(Base):
    """What a NEW upstream message for an already-delivered business date
    does (core/feed/restatement.py).  The owner's month end: the month-end
    business date keeps receiving messages day after day; a new message on a
    LATER run date re-runs the business date (a new file named with its run
    date), a re-send on the SAME run date is HELD for an approver and
    alerted, and once the window closes nothing re-runs.  ``on_new_message``
    and ``same_run_date`` are one of ``decide`` (open a decision; a person
    chooses), ``rerun`` or ``hold``.  ``window`` = ``next_business_date``
    (until the feed's next scheduled business date), ``days`` (window_days
    after the business date) or ``open``.  Mapped at a scope (``global`` /
    ``feed_group`` / ``template`` / ``feed``); the most specific wins."""
    __tablename__ = "feed_restatement_policies"
    __table_args__ = (UniqueConstraint("scope", "scope_id", name="ux_feed_restatement_scope"),)

    id = Column(Integer, primary_key=True, index=True)
    scope = Column(String(20), nullable=False)
    scope_id = Column(Integer, nullable=True)
    name = Column(String(80), nullable=True)
    on_new_message = Column(String(20), nullable=False, default="decide")
    same_run_date = Column(String(20), nullable=False, default="decide")
    window = Column(String(30), nullable=False, default="next_business_date")
    window_days = Column(Integer, nullable=True)
    # 2026-10-15 -- the owner's WD1..WDn month end: ``window = workdays``
    # counts WD1..WDn on the feed's business calendar.  WHICH dependency's
    # new message re-runs is the feed's own dependency setting
    # (EtlDependencyMapping.reruns_delivered), never a name pattern here.
    window_workdays = Column(Integer, nullable=True)
    is_active = Column(Boolean, default=True)
    updated_by = Column(String(100), nullable=True)
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "scope": self.scope, "scope_id": self.scope_id, "name": self.name,
                "on_new_message": self.on_new_message, "same_run_date": self.same_run_date,
                "window": self.window, "window_days": self.window_days,
                "window_workdays": self.window_workdays,
                "is_active": bool(self.is_active), "updated_by": self.updated_by,
                "updated_at": self.updated_at.isoformat() if self.updated_at else None}


#: a fresh database keeps the behaviour every existing feed had: a re-send
#: opens a decision a person answers
SEED_FEED_RESTATEMENT_POLICIES = (
    {"scope": "global", "scope_id": None, "name": "Decide (default)", "on_new_message": "decide",
     "same_run_date": "decide", "window": "next_business_date", "window_days": None},
)


class FeedAlertKind(Base):
    """An ALERT a feed raises and where it goes -- DATA (2026-10-12, the
    owner: "where is netcool/email alert").  ``severity`` is OMNIbus's 0-5,
    ``alert_group`` the console's routing class (core/feed/netcool.py
    ALERT_GROUPS), ``to_bell`` / ``to_email`` / ``to_netcool`` the channels,
    ``clears_when`` the stated clear condition every alert must have.  Read
    by core/feed/feed_alerts.py; edited at /api/admin/feed-alert-kinds."""
    __tablename__ = "feed_alert_kinds"
    __table_args__ = (UniqueConstraint("kind", name="ux_feed_alert_kind"),)

    id = Column(Integer, primary_key=True, index=True)
    kind = Column(String(60), nullable=False)
    title = Column(String(120), nullable=False)
    severity = Column(Integer, nullable=False, default=3)
    alert_group = Column(String(40), nullable=False)
    to_bell = Column(Boolean, default=True)
    to_email = Column(Boolean, default=False)
    to_netcool = Column(Boolean, default=False)
    clears_when = Column(String(255), nullable=False)
    is_active = Column(Boolean, default=True)
    updated_by = Column(String(100), nullable=True)
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "kind": self.kind, "title": self.title, "severity": self.severity,
                "alert_group": self.alert_group, "to_bell": bool(self.to_bell),
                "to_email": bool(self.to_email), "to_netcool": bool(self.to_netcool),
                "clears_when": self.clears_when, "is_active": bool(self.is_active),
                "updated_by": self.updated_by,
                "updated_at": self.updated_at.isoformat() if self.updated_at else None}


SEED_FEED_ALERT_KINDS = (
    {"kind": "restatement_hold", "title": "Re-run hold: upstream re-sent on the same run date",
     "severity": 4, "alert_group": "FEED_DELIVERY", "to_bell": True, "to_email": True, "to_netcool": True,
     "clears_when": "an approver re-runs the business date or keeps the delivered file"},
    {"kind": "restatement_rerun", "title": "Restatement: a new upstream version is being delivered",
     "severity": 2, "alert_group": "FEED_DELIVERY", "to_bell": True, "to_email": False, "to_netcool": False,
     "clears_when": "the re-run of the business date delivers"},
    {"kind": "restatement_closed", "title": "Upstream re-sent after the business date closed",
     "severity": 3, "alert_group": "FEED_DELIVERY", "to_bell": True, "to_email": True, "to_netcool": True,
     "clears_when": "a person re-runs the business date or keeps the delivered file"},
    {"kind": "variance_hold", "title": "File held: row count outside the expected range",
     "severity": 4, "alert_group": "FEED_COMPLETENESS", "to_bell": True, "to_email": True, "to_netcool": True,
     "clears_when": "an approver releases or rejects the held file"},
    {"kind": "run_failed", "title": "Feed run failed",
     "severity": 4, "alert_group": "FEED_DELIVERY", "to_bell": True, "to_email": True, "to_netcool": True,
     "clears_when": "a later run of the business date delivers"},
    {"kind": "sla_at_risk", "title": "SLA at risk",
     "severity": 3, "alert_group": "FEED_SLA", "to_bell": True, "to_email": False, "to_netcool": False,
     "clears_when": "the run delivers or the SLA is breached"},
    {"kind": "sla_breached", "title": "SLA breached",
     "severity": 5, "alert_group": "FEED_SLA", "to_bell": True, "to_email": True, "to_netcool": True,
     "clears_when": "the run delivers"},
    # 2026-10-17 -- component health (core/component_health/): the subject is a
    # platform component, not a feed; PLATFORM is the console group.  Netcool
    # for down only by default; unknown after unknown_alert_after_seconds.
    {"kind": "component_down", "title": "Component down",
     "severity": 5, "alert_group": "PLATFORM", "to_bell": True, "to_email": True, "to_netcool": True,
     "clears_when": "the component reports healthy for clear_after_cycles consecutive cycles"},
    {"kind": "component_degraded", "title": "Component degraded",
     "severity": 3, "alert_group": "PLATFORM", "to_bell": True, "to_email": False, "to_netcool": False,
     "clears_when": "the component reports healthy for clear_after_cycles consecutive cycles"},
    {"kind": "component_unknown", "title": "Component state unknown",
     "severity": 4, "alert_group": "PLATFORM", "to_bell": True, "to_email": True, "to_netcool": False,
     "clears_when": "the component reports again (any known state)"},
)

FEED_ALERT_CHANNELS = ("bell", "email")


class FeedAlertRoute(Base):
    """WHO an alert reaches beyond the feed's owner and its approver groups
    (2026-10-12): an e-mail address (``channel = email``) or a username /
    ``group:<name>`` (``channel = bell``), for one kind or every kind
    (``kind`` NULL), mapped at a scope like the approvers.  DATA."""
    __tablename__ = "feed_alert_routes"
    __table_args__ = (UniqueConstraint("scope", "scope_id", "kind", "channel", "target",
                                       name="ux_feed_alert_route"),)

    id = Column(Integer, primary_key=True, index=True)
    scope = Column(String(20), nullable=False)
    scope_id = Column(Integer, nullable=True)
    # 2026-10-17 -- a route for an alert SUBJECT that is not a feed
    # (core/feed/alert_subject.py): ``scope`` = the subject kind
    # ('published_api', 'component', ...) and ``scope_key`` = one subject's
    # key, or NULL = every subject of that kind.  Feeds keep ``scope_id``.
    scope_key = Column(String(220), nullable=True)
    kind = Column(String(60), nullable=True)
    channel = Column(String(10), nullable=False)
    target = Column(String(255), nullable=False)
    created_by = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "scope": self.scope, "scope_id": self.scope_id,
                "scope_key": self.scope_key, "kind": self.kind,
                "channel": self.channel, "target": self.target, "created_by": self.created_by,
                "created_at": self.created_at.isoformat() if self.created_at else None}


class FeedAlert(Base):
    """ONE alert a feed raised and WHERE IT WENT (2026-10-12): the bell, the
    e-mail and the Netcool event, each with its outcome, in ``deliveries``.
    Keyed by ``dedupe_key`` (one alert per problem, never one per pass);
    ``status`` open -> cleared when its clear condition is met.  The board's
    per-task alert list reads this row (core/feed/feed_alerts.py)."""
    __tablename__ = "feed_alerts"
    __table_args__ = (UniqueConstraint("dedupe_key", name="ux_feed_alert_dedupe"),)

    id = Column(Integer, primary_key=True, index=True)
    dedupe_key = Column(String(255), nullable=False)
    kind = Column(String(60), nullable=False)
    severity = Column(Integer, nullable=False)
    feed_config_id = Column(Integer, nullable=True, index=True)
    feed_name = Column(String(255), nullable=True)
    # 2026-10-17 -- the SUBJECT when the alert is not about a feed
    # (core/feed/alert_subject.py::AlertSubject): its kind ('published_api',
    # 'component', ...) and its key.  NULL = a feed alert (feed_config_id set;
    # feed_name is then the subject's display name for every kind).
    subject_kind = Column(String(20), nullable=True, index=True)
    subject_key = Column(String(220), nullable=True)
    business_date = Column(Date, nullable=True, index=True)
    run_date = Column(Date, nullable=True)
    feed_run_id = Column(Integer, nullable=True)
    execution_id = Column(String(100), nullable=True)
    title = Column(String(255), nullable=False)
    message = Column(Text, nullable=True)
    deliveries = Column(JSON, nullable=True)
    netcool_identifier = Column(String(255), nullable=True)
    status = Column(String(20), nullable=False, default="open")
    raised_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    cleared_at = Column(DateTime, nullable=True)
    cleared_by = Column(String(255), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "dedupe_key": self.dedupe_key, "kind": self.kind,
                "severity": self.severity, "feed_config_id": self.feed_config_id,
                "feed_name": self.feed_name,
                "subject_kind": self.subject_kind, "subject_key": self.subject_key,
                "business_date": self.business_date.isoformat() if self.business_date else None,
                "run_date": self.run_date.isoformat() if self.run_date else None,
                "feed_run_id": self.feed_run_id, "execution_id": self.execution_id,
                "title": self.title, "message": self.message,
                "deliveries": list(self.deliveries or []),
                "netcool_identifier": self.netcool_identifier, "status": self.status,
                "raised_at": self.raised_at.isoformat() if self.raised_at else None,
                "cleared_at": self.cleared_at.isoformat() if self.cleared_at else None,
                "cleared_by": self.cleared_by}

class FeedSodGap(Base):
    """A DUE date the SOD generator found with NO run row and could not
    create -- it lies beyond ``feed_generation.sod_catchup_days`` (2026-10-11;
    core/feed/sod_generator.py).

    Found designing the owner's monthly case: a month-end missed because the
    scheduler was down at the cron time was never created and nothing said
    so -- the consumer's file was simply absent.  Within the catch-up window
    the pass CREATES the run (``triggered_by = sod_catchup``); beyond it the
    pass writes THIS row, once per (feed, business date), logs it at ERROR and
    serves it on ``GET /api/admin/feeds/sod/gaps``.  A later pass that finds a
    run for the date (a backfill, a widened window) stamps ``resolved_at``;
    the row stays as the record that the date was once missed.

    NEW TABLE: self-creates via create_all (listed in _MIGRATIONS as []).
    """
    __tablename__ = "feed_sod_gaps"
    __table_args__ = (
        UniqueConstraint("feed_config_id", "business_date",
                         name="ux_feed_sod_gaps_feed_date"),
    )

    id              = Column(Integer, primary_key=True, index=True)
    feed_config_id  = Column(Integer, ForeignKey("feed_configs.id", ondelete="CASCADE"),
                             nullable=False, index=True)
    business_date   = Column(Date, nullable=False, index=True)
    #: the declared kind that made the date due (month_end, workday_n, ...)
    schedule_kind   = Column(String(30), nullable=True)
    reason          = Column(Text, nullable=True)
    #: the windows the pass that found it was running with
    catchup_days    = Column(Integer, nullable=True)
    scan_days       = Column(Integer, nullable=True)
    detected_at     = Column(DateTime, nullable=False,
                             default=lambda: datetime.now(timezone.utc))
    #: the run day of the pass that found it
    detected_on     = Column(Date, nullable=True)
    resolved_at     = Column(DateTime, nullable=True)
    #: how it was resolved: ``run_exists`` (a row for the date appeared)
    resolved_how    = Column(String(40), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "feed_config_id": self.feed_config_id,
            "business_date": (self.business_date.isoformat()
                              if self.business_date else None),
            "schedule_kind": self.schedule_kind,
            "reason": self.reason,
            "catchup_days": self.catchup_days,
            "scan_days": self.scan_days,
            "detected_at": self.detected_at.isoformat() if self.detected_at else None,
            "detected_on": self.detected_on.isoformat() if self.detected_on else None,
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
            "resolved_how": self.resolved_how,
        }


class FeedDefinitionVersion(Base):
    """Foundation P (BRD 2026-09-02 §14.2) — pinned feed definition.

    One row per DISTINCT definition of a feed, deduplicated on
    ``definition_hash``: pinning the same unchanged definition twice
    reuses the existing version row.  Run/execution rows point at a
    version via ``pinned_version_id`` so a run that starts at 22:00 and
    finishes at 02:00 executes the definition it was ADMITTED with, and
    a re-run of an old business date can execute the definition that was
    live FOR THAT DATE (FR-RUN-03, FR-GOV-01).

    Rows are immutable once written (a snapshot that can drift is not a
    snapshot); updated_at/updated_by exist for the §14.1 audit-column
    convention only.

    NEW TABLE deliberately (BRD §14): it self-creates via
    ``Base.metadata.create_all()`` so the first deploy needs no
    migration step to be correct.
    """
    __tablename__ = "feed_definition_versions"
    __table_args__ = (
        UniqueConstraint("feed_config_id", "version",
                          name="ux_feed_definition_versions_feed_version"),
    )

    id              = Column(Integer, primary_key=True, index=True)
    feed_config_id  = Column(Integer, nullable=False, index=True)
    # Monotonic per feed, assigned by pin_feed_definition (max+1).  The
    # unique constraint is what makes two pods racing on max+1 safe: one
    # wins, the other re-reads.
    version         = Column(Integer, nullable=False)
    definition      = Column(SecretJSON, nullable=False)          # the snapshot itself
    definition_hash = Column(String(64), nullable=False, index=True)
    # Deploy provenance — nullable because no deploy stamp exists today
    # (QS_GIT_COMMIT / QS_IMAGE_TAG env); the field is modelled, the
    # value is never invented.
    git_commit      = Column(String(64), nullable=True)
    image_tag       = Column(String(200), nullable=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    created_by      = Column(String(100), nullable=True)
    updated_at      = Column(DateTime, nullable=True)
    updated_by      = Column(String(100), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "feed_config_id": self.feed_config_id,
            "version": self.version,
            "definition": self.definition,
            "definition_hash": self.definition_hash,
            "git_commit": self.git_commit,
            "image_tag": self.image_tag,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "created_by": self.created_by,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "updated_by": self.updated_by,
        }


# ── Phase 131 — Feed Generation Controls ────────────────────────────────

class FeedRowCountBaseline(Base):
    """Per-feed rolling-window row-count baseline (Phase 131-B).

    Updated by the daily baseline-refresh job.  When a feed completes,
    the new row_count is compared against ``avg_rows`` and the run is
    flagged when ``abs(actual - avg) / avg > row_count_threshold_pct``.
    """
    __tablename__ = "feed_row_count_baseline"

    feed_config_id      = Column(Integer, primary_key=True)
    rolling_window_days = Column(Integer, nullable=False, default=7)
    avg_rows            = Column(BigInteger, nullable=False, default=0)
    stdev_rows          = Column(BigInteger, nullable=True)
    min_rows            = Column(BigInteger, nullable=True)
    max_rows            = Column(BigInteger, nullable=True)
    sample_count        = Column(Integer, nullable=False, default=0)
    last_updated_at     = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "feed_config_id": self.feed_config_id,
            "rolling_window_days": self.rolling_window_days,
            "avg_rows": self.avg_rows,
            "stdev_rows": self.stdev_rows,
            "min_rows": self.min_rows,
            "max_rows": self.max_rows,
            "sample_count": self.sample_count,
            "last_updated_at": self.last_updated_at.isoformat() if self.last_updated_at else None,
        }


class FeedDefinitionTimeline(Base):
    """WHEN a saved definition change APPLIES (2026-10-12, the owner: "if
    query changes then ... ask user changes should be applicable from").
    One row per definition-changing save: the version it saved and
    ``applies_from`` -- a BUSINESS DATE (every run of that date or later,
    re-runs and restatements included, executes it) or NULL = "from the next
    run" (new runs execute it; a re-run of a business date already delivered
    before the save keeps the definition it was delivered with).  The newest
    declaration that applies to a run wins (core/feed/definition_timeline.py)."""
    __tablename__ = "feed_definition_timeline"

    id = Column(Integer, primary_key=True, index=True)
    feed_config_id = Column(Integer, nullable=False, index=True)
    version_id = Column(Integer, nullable=False)
    applies_from = Column(Date, nullable=True)
    saved_by = Column(String(100), nullable=True)
    saved_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    note = Column(String(500), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "feed_config_id": self.feed_config_id, "version_id": self.version_id,
                "applies_from": self.applies_from.isoformat() if self.applies_from else None,
                "saved_by": self.saved_by,
                "saved_at": self.saved_at.isoformat() if self.saved_at else None,
                "note": self.note}


class FeedRuntimeProfile(Base):
    """MEASURED runtime profile per feed — the producer the SLA decision
    ladder was missing (FR-SLA-01/05, 2026-09-03).

    One row per RECOMPUTE, append-only: the p95 of completed feed_runs
    durations over a rolling window, stored so the 60s watcher tick READS
    a profile instead of recomputing from scratch (FR-SLA-05), and so
    "what did we expect on the day we alerted" stays answerable — the
    latest row with ``computed_at <= alert time`` IS that answer.  Rows
    are never updated in place: touching ``computed_at`` forward on an
    unchanged row would move the as-of answer for the dates in between.

    ``p95_seconds`` is NULL when there were too few samples — a profile
    that SAYS it is weak, so the ladder falls back to the DECLARED
    runtime rather than trusting four data points (the FR-SLA-04
    pattern applied to runtimes).

    Fresh TABLE: self-creates via create_all; no _MIGRATIONS columns
    needed until one is added later.
    """
    __tablename__ = "feed_runtime_profiles"
    __table_args__ = (
        Index("ix_feed_runtime_profiles_feed_time",
              "feed_config_id", "computed_at"),
    )

    id             = Column(Integer, primary_key=True, index=True)
    feed_config_id = Column(Integer, nullable=False, index=True)
    window_days    = Column(Integer, nullable=False, default=90)
    sample_count   = Column(Integer, nullable=False, default=0)
    p50_seconds    = Column(Integer, nullable=True)
    p95_seconds    = Column(Integer, nullable=True)
    max_seconds    = Column(Integer, nullable=True)
    computed_at    = Column(DateTime, nullable=False,
                            default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "feed_config_id": self.feed_config_id,
            "window_days": self.window_days,
            "sample_count": self.sample_count,
            "p50_seconds": self.p50_seconds,
            "p95_seconds": self.p95_seconds,
            "max_seconds": self.max_seconds,
            "computed_at": self.computed_at.isoformat() if self.computed_at else None,
        }


class FeedRegenerationDecision(Base):
    """The regeneration decision as a FIRST-CLASS RECORD (FR-DEP-10/18/20,
    2026-09-03).

    Until this table existed, ``decision_raised`` / ``decision_resolved``
    were vocabulary constants with ZERO producers: an upstream replaying
    after a feed had already run produced a log-line suffix and nothing
    else.  A row here is RAISED by core/feed/regeneration.py when a REPLAY
    arrival lands for a dependency whose feed has already run (or is
    running) for that business date — carrying its evidence (what
    replayed, what had already been delivered) — and RESOLVED by a person
    with a reason.  Both transitions also append run_events rows
    (``decision_raised`` / ``decision_resolved``), so the audit trail is
    in the append-only ledger while THIS row is the current state.

    ``parent_decision_id`` is the FR-DEP-18 cascade: a decision raised on
    a downstream feed (schedule kind ``on_completion_of``) because its
    upstream's input replayed links back to the decision that caused it.

    Fresh TABLE: self-creates via create_all.
    """
    __tablename__ = "feed_regeneration_decisions"
    __table_args__ = (
        Index("ix_feed_regen_decisions_feed_date",
              "feed_config_id", "business_date"),
    )

    id                 = Column(Integer, primary_key=True, index=True)
    # No FK on purpose — the decision record must outlive a retired feed
    # (same rule as run_events; the audit has to stay answerable).
    feed_config_id     = Column(Integer, nullable=False, index=True)
    business_date      = Column(Date, nullable=False, index=True)
    dependency_name    = Column(String(500), nullable=False)
    build_id           = Column(String(40), nullable=True)
    parent_decision_id = Column(Integer, nullable=True, index=True)
    status             = Column(String(20), nullable=False, default="open")  # open | resolved
    evidence           = Column(JSON, nullable=True)
    raised_by          = Column(String(100), nullable=True)
    raised_at          = Column(DateTime, nullable=False,
                                default=lambda: datetime.now(timezone.utc))
    resolution         = Column(String(30), nullable=True)   # regenerate | no_regeneration
    resolved_by        = Column(String(100), nullable=True)
    resolved_at        = Column(DateTime, nullable=True)
    resolution_reason  = Column(String(1000), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "feed_config_id": self.feed_config_id,
            "business_date": self.business_date.isoformat() if self.business_date else None,
            "dependency_name": self.dependency_name,
            "build_id": self.build_id,
            "parent_decision_id": self.parent_decision_id,
            "status": self.status,
            "evidence": self.evidence,
            "raised_by": self.raised_by,
            "raised_at": self.raised_at.isoformat() if self.raised_at else None,
            "resolution": self.resolution,
            "resolved_by": self.resolved_by,
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
            "resolution_reason": self.resolution_reason,
        }


class FeedSkipApproval(Base):
    """One person's approval of ONE dependency skip (FR-DEP-14, 2026-09-03).

    The maker/checker record behind
    core/feed/dependency_skip.assert_skip: when any affected feed declares
    ``skip_requires_second_approver``, the skip proceeds only once TWO
    DISTINCT actors have a row here for the same
    (dependency_type_id, dependency_key, business_date).  The unique key
    makes re-approval by the same person idempotent — one person clicking
    twice is still one approver.

    Fresh TABLE: self-creates via create_all.
    """
    __tablename__ = "feed_skip_approvals"
    __table_args__ = (
        UniqueConstraint("dependency_type_id", "dependency_key",
                          "business_date", "actor",
                          name="ux_feed_skip_approvals_one_per_actor"),
    )

    id                 = Column(Integer, primary_key=True, index=True)
    dependency_type_id = Column(Integer, nullable=False, index=True)
    dependency_key     = Column(String(500), nullable=False, index=True)
    business_date      = Column(Date, nullable=False, index=True)
    actor              = Column(String(100), nullable=False)
    reason             = Column(String(1000), nullable=True)
    created_at         = Column(DateTime, nullable=False,
                                default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dependency_type_id": self.dependency_type_id,
            "dependency_key": self.dependency_key,
            "business_date": self.business_date.isoformat() if self.business_date else None,
            "actor": self.actor,
            "reason": self.reason,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class FeedSequenceAllocation(Base):
    """One number in a feed's gapless file sequence — FR-ART-07.

    A counterparty demanding ``FLX_TRADES_000123.csv`` is demanding
    STATE: the number must increase across runs, survive restarts, and
    never repeat.  That makes it a durable ledger, not a counter — and
    the ledger records numbers that were TAKEN AND NEVER SHIPPED just as
    carefully as delivered ones, because the party checking the sequence
    can see the hole either way and will ask about it.  A taken-but-dead
    allocation stays here so the operator can answer "why did 000124
    never arrive?" from the record instead of a log grep.

    The UNIQUE constraint is LOAD-BEARING, not hygiene.  Allocation is
    ``MAX(seq_value) + 1``, which is a read-modify-write: two runs
    starting together both compute 124, and without the constraint both
    would take it, producing two different files claiming one identity.
    With it, the loser gets an IntegrityError, which the DAO translates
    to ``SequenceConflict`` and ``SequenceAllocator.allocate`` retries at
    125.  Removing this constraint does not make the code slower — it
    makes it WRONG under exactly the concurrency it was built for.

    ``business_date`` is a string, not a Date: a sequence scope may be
    keyed by something that is not a calendar day at all (a batch label,
    a cycle id), and forcing it through a date type would either reject
    those or silently coerce them.

    Fresh TABLE: self-creates via create_all.
    """
    __tablename__ = "feed_sequence_allocations"
    __table_args__ = (
        UniqueConstraint("feed_config_id", "scope_key", "seq_value",
                          name="ux_feed_sequence_alloc_value"),
    )

    id             = Column(Integer, primary_key=True, index=True)
    feed_config_id = Column(Integer, nullable=False, index=True)
    #: "" is the default single stream; a feed that sequences per region
    #: or per partition puts that discriminator here.
    scope_key      = Column(String(200), nullable=False, default="")
    seq_value      = Column(Integer, nullable=False)
    #: taken | committed | abandoned — see core.feed.sequence.
    status         = Column(String(20), nullable=False, default="taken")
    business_date  = Column(String(32), nullable=True, index=True)
    run_id         = Column(String(100), nullable=True, index=True)
    taken_at       = Column(DateTime, nullable=False,
                            default=lambda: datetime.now(timezone.utc))
    committed_at   = Column(DateTime, nullable=True)
    #: Why an abandoned number will never ship.  Required to abandon —
    #: an unexplained abandonment is just a gap with extra steps.
    note           = Column(String(1000), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "feed_config_id": self.feed_config_id,
            "scope_key": self.scope_key or "",
            "seq_value": self.seq_value,
            "status": self.status,
            "business_date": self.business_date,
            "run_id": self.run_id,
            "taken_at": self.taken_at,
            "committed_at": self.committed_at,
            "note": self.note or "",
        }


class EtlDependencyType(Base):
    """Catalogue of dependency kinds — QS-side mirror of OTG_DEPENDENCY_TYPE
    (Phase 131-A).  Cross-walks by ``dependency_type`` name once both
    systems are integrated."""
    __tablename__ = "etl_dependency_types"

    id                = Column(Integer, primary_key=True, index=True)
    dependency_type   = Column(String(50), unique=True, nullable=False)   # KAFKA | ORACLE_TABLE | FILE | API
    description       = Column(String(500), nullable=True)
    server            = Column(String(300), nullable=True)
    param_value       = Column(String(500), nullable=True)
    is_active         = Column(Boolean, default=True)
    created_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                                onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dependency_type": self.dependency_type,
            "description": self.description,
            "server": self.server,
            "param_value": self.param_value,
            "is_active": self.is_active,
        }


class EtlDependencyMapping(Base):
    """Static mapping — for an etl_id, which dependencies must be ready
    before its feed can run.  An ETL with 3 Kafka topics has 3 rows."""
    __tablename__ = "etl_dependency_mappings"
    __table_args__ = (
        UniqueConstraint("etl_id", "dependency_type_id", "dependency_key",
                          name="ux_etl_dep_mapping"),
    )

    id                 = Column(Integer, primary_key=True, index=True)
    etl_id             = Column(Integer, nullable=False, index=True)
    dependency_type_id = Column(Integer, ForeignKey("etl_dependency_types.id"),
                                 nullable=False, index=True)
    dependency_key     = Column(String(500), nullable=False)
    description        = Column(String(500), nullable=True)
    # FR-DEP-08 (2026-09-02) — WHOSE CALENDAR governs this dependency:
    #   the upstream's, not ours.  When their calendar says today is not
    #   a business day for THEM, the gate reports NOT-EXPECTED rather
    #   than not-met — no alert, no skip, no incident, and nobody is
    #   paged at 04:19 to chase a message that was never going to be
    #   sent.  NULL means 'expected every run day': inferring
    #   not-expected from a MISSING calendar would silence a genuinely
    #   broken upstream, which is the worse failure of the two.
    calendar_name      = Column(String(100), nullable=True)
    # FR-DEP-24 / BRD 2.1 (2026-09-02) — the OPTIONAL expected row count.
    #   The gate has always been able to say "the message says COMPLETE
    #   but upstream loaded 60% of its rows" -- ``dependency_gate``
    #   compares ``expected_rows`` against ``reported_rows`` -- but
    #   NEITHER SIDE HAD A PRODUCER, so that comparison could not fire on
    #   any row ever written.  This is the author's side of it.
    #   NULL means NO CHECK.  Zero is REFUSED at authoring rather than
    #   stored: "expect at least 0 rows" is satisfied by every possible
    #   load, so a 0 typed into the form would read as a check while
    #   being incapable of failing.
    expected_rows      = Column(BigInteger, nullable=True)
    # 2026-09-27 — the DECLARED arrival sources (core/feed/arrival_sources.py).
    #   A JSON list of source specs, each ``{"kind": <vocabulary key>, ...}``
    #   (``kafka`` / ``etl`` / ``file`` / ``iceberg_commit`` / the reserved
    #   ``datasync``).  NULL or [] means "no declaration": the dependency
    #   keeps the legacy rule (any evidence — a tracking row or any ledger
    #   arrival by name — satisfies it).  With a declaration the ONE gate
    #   evaluates each source and combines them by ``require_mode``.
    arrival_sources    = Column(JSON, nullable=True)
    #   ``all`` (the default when NULL) or ``any``.  Under ``all`` an
    #   UNKNOWN source verdict is COULD NOT TELL, never met.
    require_mode       = Column(String(10), nullable=True)
    # 2026-10-11 -- which SIDE of the feed this dependency's reported row
    #   count certifies: 'primary' / 'secondary' / NULL (none).  The owner's
    #   message carries ROW_COUNT; a feed declares the cloud side's message
    #   certifies the primary and the on-prem side's the secondary, and
    #   core/feed/reported_rows_certification.py fails the run (both lanes,
    #   before any output) when a side's rows != that count.
    certifies_side     = Column(String(10), nullable=True)
    # 2026-10-15 -- does a NEW message of this dependency, for a business
    #   date the feed already DELIVERED, re-run it (core/feed/restatement.py)?
    #   NULL / true = yes (every dependency before this date); false = the
    #   message is recorded and re-runs nothing.  The owner's month end: SOD
    #   and ITD gate WD1 only, EOD re-runs WD2..WDn -- configured per feed.
    reruns_delivered   = Column(Boolean, nullable=True)
    is_active          = Column(Boolean, default=True)
    created_at         = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "etl_id": self.etl_id,
            "dependency_type_id": self.dependency_type_id,
            "dependency_key": self.dependency_key,
            "calendar_name": self.calendar_name,
            "expected_rows": self.expected_rows,
            "arrival_sources": self.arrival_sources,
            "require_mode": self.require_mode,
            "certifies_side": self.certifies_side,
            "reruns_delivered": self.reruns_delivered,
            "description": self.description,
            "is_active": self.is_active,
        }


class EtlDependencyTracking(Base):
    """Runtime gate.  An external Kafka consumer / OTG ETL writes
    ``action='COMPLETE'`` here when a dependency lands for a given
    business_date.  QS reads this to decide RUN vs WAIT."""
    __tablename__ = "etl_dependency_tracking"
    __table_args__ = (
        UniqueConstraint("dependency_type_id", "dependency_key", "business_date",
                          name="ux_etl_dep_tracking"),
    )

    id                 = Column(Integer, primary_key=True, index=True)
    dependency_type_id = Column(Integer, nullable=False, index=True)
    dependency_key     = Column(String(500), nullable=False, index=True)
    business_date      = Column(Date, nullable=False, index=True)
    # COMPLETE | SKIP | PENDING | RESET  — matches OTG_DEPENDENCY_TRACKING
    # so when systems integrate the values cross-walk one-for-one.
    action             = Column(String(20), nullable=False)
    comments           = Column(String(2000), nullable=True)
    created_at         = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at         = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                                  onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dependency_type_id": self.dependency_type_id,
            "dependency_key": self.dependency_key,
            "business_date": self.business_date.isoformat() if self.business_date else None,
            "action": self.action,
            "comments": self.comments,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


# ── Foundation L — append-only event ledger (BRD 2026-09-02 §7.2, §14.2) ──
# Both tables are APPEND-ONLY by design: a second arrival is a NEW ROW,
# never an upsert.  The BRD (§4) proves the point structurally — the old
# tracking row is unique on (type, key, business_date), so a second arrival
# is an upsert and "replay is undecidable in principle".  These are new
# TABLES rather than columns on existing ones because create_all() creates
# missing tables at startup but never ALTERs, and alembic is not invoked
# at runtime (BRD §14 non-negotiables).
from sqlalchemy import CheckConstraint  # additive import for the ledger tables

# Closed vocabulary for run_events.event_type (BRD §14.1: CHECK constraints,
# not free strings — "what states exist?" must be answerable without reading
# code, and a typo must not become a new state).  core/feed/ledger.py
# imports this tuple so the API refusal and the DB CHECK can never drift.
RUN_EVENT_TYPES = (
    # run lifecycle (§4.1)
    "run_created", "run_claimed", "run_started", "run_completed",
    "run_failed", "run_skipped", "run_cancelled",
    # §7.5 — a replay landed while the run was executing
    "run_flagged_read_during_reload",
    # step lifecycle
    "step_started", "step_completed", "step_failed", "step_retried",
    # dependency gate verdicts (§7.4 — not met, not expected, could not
    # tell are three DIFFERENT facts; silence must never imply one)
    "gate_evaluated", "dependency_met", "dependency_not_met",
    "dependency_not_expected", "dependency_could_not_tell",
    "dependency_skipped", "dependency_replay", "dependency_redelivery",
    # 2026-09-27 -- a manual Run Now that went although the gate said NOT
    # MET (operator intent, with a reason), and the 48 h WAIT escalation
    # (who was told, and how).  Adding a value here changes the CHECK for
    # NEW databases only; DatabaseManager._migrate_run_events_type_check
    # rewrites it on an existing one.
    "dependencies_overridden", "dependency_wait_escalated",
    # 2026-10-03 -- ON COMPLETION OF: recorded on the UPSTREAM run when it
    # reaches a terminal state and a feed declares ``on_completion_of`` it
    # -- which downstream runs were created, or why none was
    # (core/feed/upstream_completion.py).  The CHECK on an existing database
    # is rewritten by DatabaseManager._migrate_run_events_type_check.
    "downstream_triggered", "downstream_not_triggered",
    # decisions and delivery holds (§7.5, FR-DEP-10)
    "decision_raised", "decision_resolved",
    "delivery_held", "delivery_released",
)

# Closed vocabulary for dependency_events.source (§7.2).
# 2026-09-27 — ``iceberg_commit``: an arrival recorded by
# core/feed/iceberg_commit_source.py when a registered Iceberg table's new
# snapshot PROVES (from its own manifests) that data for the business date
# exists.  Adding a value here changes the CHECK constraint for NEW
# databases only; ``DatabaseManager._migrate_dependency_events_source_check``
# rewrites the constraint on an existing one, because a CHECK a deployed
# table already carries is not touched by create_all.
# 2026-10-11 -- 'oracle_table': a row of an upstream's Oracle table (the OG
# QS_KAFKA_MESSAGE landing table) read by core/feed/oracle_table_source.py
# and resolved through the SAME rules as a Kafka message.
DEPENDENCY_EVENT_SOURCES = ("kafka", "manual", "file", "iceberg_commit",
                            "oracle_table")


class RunEvent(Base):
    """Append-only ledger of run / step / decision events (Foundation L).

    One row per thing that HAPPENED.  There is no update path anywhere —
    state is always a projection over this log, never a column written in
    place (BRD §7.2: "a replay is an event, not an update").
    """
    __tablename__ = "run_events"
    __table_args__ = (
        # The operator screens filter on (feed, business_date) — the run
        # surface is the hottest read path in a run-the-bank system (§14.1).
        Index("ix_run_events_feed_date", "feed_config_id", "business_date"),
        CheckConstraint(
            "event_type IN ({})".format(
                ", ".join("'{}'".format(t) for t in RUN_EVENT_TYPES)),
            name="ck_run_events_event_type",
        ),
    )

    id              = Column(Integer, primary_key=True, index=True)
    # Deliberately NOT a ForeignKey: the audit ledger must outlive a
    # retired or deleted feed (FR-OPS-16) — an ondelete CASCADE would
    # erase exactly the history that has to stay answerable.
    feed_config_id  = Column(Integer, nullable=False, index=True)
    business_date   = Column(Date, nullable=False, index=True)
    # (feed, business_date, build_id) is the run key (§4.1); nullable
    # because gate/dependency events can precede any build existing.
    build_id        = Column(String(100), nullable=True)
    event_type      = Column(String(40), nullable=False)
    # A step alias, dependency name, decision id — what the event is about.
    subject         = Column(String(500), nullable=True)
    # Who caused it (username / 'system' / consumer id) — audit (§14.1).
    actor           = Column(String(100), nullable=True)
    payload         = Column(JSON, nullable=True)
    # server_default so the DATABASE fills it even for a raw INSERT —
    # a Python default= is not a DDL default (§14 non-negotiable).
    created_at      = Column(DateTime, nullable=False,
                             default=lambda: datetime.now(timezone.utc),
                             server_default=sa_text("CURRENT_TIMESTAMP"))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "feed_config_id": self.feed_config_id,
            "business_date": self.business_date.isoformat() if self.business_date else None,
            "build_id": self.build_id,
            "event_type": self.event_type,
            "subject": self.subject,
            "actor": self.actor,
            "payload": self.payload,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class DependencyEvent(Base):
    """Append-only arrival log — EVERY arrival, not just the first (§7.2).

    ``message_identity`` is the raw identity of the triggering message
    (e.g. ``kafka:topic/partition/offset``, a file path + mtime, or a
    manual actor + timestamp).  It is what makes a REPLAY (different
    identity, same (dependency, business_date)) distinguishable from a
    Kafka redelivery (identical identity) — BRD §7.5.  A current-state
    row cannot answer "did it arrive twice, and when?"; this log can.
    """
    __tablename__ = "dependency_events"
    __table_args__ = (
        Index("ix_dependency_events_dep_date", "dependency_name", "business_date"),
        CheckConstraint(
            "source IN ({})".format(
                ", ".join("'{}'".format(s) for s in DEPENDENCY_EVENT_SOURCES)),
            name="ck_dependency_events_source",
        ),
    )

    id               = Column(Integer, primary_key=True, index=True)
    dependency_name  = Column(String(200), nullable=False, index=True)
    # Dependency state is keyed by business date and joined on it —
    # never relax that join (FR-DEP-17: yesterday's COMPLETE must not
    # satisfy today's gate).
    business_date    = Column(Date, nullable=False, index=True)
    arrived_at       = Column(DateTime, nullable=False)
    source           = Column(String(20), nullable=False)   # kafka | manual | file
    message_identity = Column(String(500), nullable=False)
    payload          = Column(JSON, nullable=True)
    # FR-DEP-24 (2026-09-02) — rows the upstream SAYS it loaded, lifted out
    #   of the payload by the rule that named the field.  A typed column
    #   rather than a synthesised payload key: the payload is EVIDENCE and
    #   must stay byte-faithful to what arrived.  NULL means the message
    #   did not say -- never 0, which would read as a total upstream
    #   failure and fire the partial-load alarm on every message from an
    #   upstream that simply does not publish counts.
    reported_rows    = Column(BigInteger, nullable=True)
    # 2026-10-08 -- WHICH declared source of the dependency this arrival
    #   satisfies: ``kafka:<topic>``, ``iceberg:<bucket>/<prefix>``, a file
    #   declaration's spec key.  A dependency may declare SEVERAL sources of
    #   one kind (two Kafka topics, two Iceberg tables) and each evaluator
    #   must see only its own arrivals; until this column every
    #   ``iceberg_commit`` arrival satisfied every Iceberg source of the
    #   dependency (two tables, ALL: released on the first commit).  NULL =
    #   an arrival for the dependency as a whole (an operator's, a legacy
    #   row) -- counts for every source.  The ledger keys its REPLAY
    #   classification by it too: a second source's first arrival is not a
    #   replay of the first source.
    source_key       = Column(String(500), nullable=True)
    created_at       = Column(DateTime, nullable=False,
                              default=lambda: datetime.now(timezone.utc),
                              server_default=sa_text("CURRENT_TIMESTAMP"))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dependency_name": self.dependency_name,
            "business_date": self.business_date.isoformat() if self.business_date else None,
            "arrived_at": self.arrived_at.isoformat() if self.arrived_at else None,
            "source": self.source,
            "message_identity": self.message_identity,
            "payload": self.payload,
            "reported_rows": self.reported_rows,
            "source_key": self.source_key,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


# 2026-09-27 — what an Iceberg-commit inspection can conclude.  Three states,
# and they must stay three: PROVED (the snapshot's own metadata shows data
# for at least one date), NO_PROOF (read fine, proves no date in the window)
# and UNREADABLE (the metadata could not be read — the gate reports COULD
# NOT TELL for that source, never NOT MET and never MET).
ICEBERG_COMMIT_INSPECTION_STATUSES = ("proved", "no_proof", "unreadable")


class IcebergCommitInspection(CanonicalPrefixMixin, Base):
    """One inspection of one snapshot for one dependency (2026-09-27).

    The Iceberg-commit arrival source writes a row every time it looks at a
    new snapshot for a dependency that declared the table.  It is EVIDENCE,
    not a decision: the arrival itself goes to ``dependency_events`` (the
    same ledger the Kafka resolver writes) and the verdict is made once, in
    ``core/feed/dependency_gate.py``.  This row exists so the gate can tell
    "the last commit could not be read" (COULD NOT TELL) from "the last
    commit was read and carried no data for D" (NOT MET) — without it both
    would look like an empty ledger.  It is also the replay guard: one row
    per (dependency, snapshot) — a snapshot inspected twice is a no-op.
    """
    __tablename__ = "iceberg_commit_inspections"
    __table_args__ = (
        UniqueConstraint("dependency_name", "snapshot_id",
                         name="ux_iceberg_commit_inspection"),
        Index("ix_iceberg_commit_inspections_dep", "dependency_name",
              "inspected_at"),
        CheckConstraint(
            "status IN ({})".format(
                ", ".join("'{}'".format(s)
                          for s in ICEBERG_COMMIT_INSPECTION_STATUSES)),
            name="ck_iceberg_commit_inspections_status",
        ),
    )

    id               = Column(Integer, primary_key=True, index=True)
    dependency_name  = Column(String(200), nullable=False, index=True)
    connection_id    = Column(Integer, nullable=False)
    bucket           = Column(String(255), nullable=False)
    table_prefix     = Column(String(512), nullable=False)
    snapshot_id      = Column(String(64), nullable=False)
    date_column      = Column(String(200), nullable=False)
    status           = Column(String(20), nullable=False)
    # HOW the proof was made: ``partition:identity`` / ``partition:day`` /
    # ``bounds`` — or NULL when nothing was proved.
    method           = Column(String(40), nullable=True)
    # ISO dates proved present in the snapshot, within the lookback window.
    dates_proved     = Column(JSON, nullable=True)
    files_seen       = Column(Integer, nullable=True)
    reason           = Column(String(2000), nullable=True)
    # 2026-10-12 -- WHICH table (its registered name) and WHICH partition
    # the proof was for (the declared columns: business event, system entity
    # ...; the COB is dates_proved), and the data it saw there
    table_name       = Column(String(512), nullable=True)
    partition_values = Column(JSON, nullable=True)
    files_matched    = Column(Integer, nullable=True)
    rows_matched     = Column(BigInteger, nullable=True)
    inspected_at     = Column(DateTime, nullable=False,
                              default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dependency_name": self.dependency_name,
            "connection_id": self.connection_id,
            "bucket": self.bucket,
            "table_prefix": self.table_prefix,
            "snapshot_id": self.snapshot_id,
            "date_column": self.date_column,
            "status": self.status,
            "method": self.method,
            "dates_proved": self.dates_proved,
            "files_seen": self.files_seen,
            "reason": self.reason,
            "table_name": self.table_name,
            "partition_values": self.partition_values,
            "files_matched": self.files_matched,
            "rows_matched": self.rows_matched,
            "inspected_at": (self.inspected_at.isoformat()
                             if self.inspected_at else None),
        }


# 2026-10-07 — what the file-arrival watcher can conclude about one declared
# ``file`` source for one (dependency, business date).  Four states, and they
# must stay four: PRESENT (the files -- and the control file, when declared --
# are there; an arrival was recorded), ABSENT (listed fine, nothing matching),
# PARTIAL (listed fine, something is there but not enough: data without the
# declared control file, a control file without data, fewer than min_files)
# and UNREADABLE (the LIST failed, or stopped at its key budget before the
# requirement was met -- the gate reports COULD NOT TELL, never NOT MET).
FILE_ARRIVAL_OBSERVATION_STATUSES = ("present", "absent", "partial",
                                     "unreadable")


class FileArrivalObservation(Base):
    """The watcher's LATEST look at one declared file source (2026-10-07).

    Written by ``core/feed/file_arrival_source.py`` every time it lists the
    rendered location for a WAIT run.  It is EVIDENCE, not a decision: the
    arrival goes to ``dependency_events`` (source ``file``, the same ledger
    the Kafka and Iceberg-commit sources write) and the verdict is made once,
    in ``core/feed/dependency_gate.py``.  This row exists so the gate can tell
    "the last LIST failed" (COULD NOT TELL) from "the last LIST found nothing"
    (NOT MET) and say WHAT it is waiting for -- without it all three would
    look like an empty ledger.  ONE row per (dependency, business date,
    declared source), updated in place: it is the latest observation, not a
    history (the ledger is the history of what arrived).
    """
    __tablename__ = "file_arrival_observations"
    __table_args__ = (
        UniqueConstraint("dependency_name", "business_date", "spec_key",
                         name="ux_file_arrival_observation"),
        CheckConstraint(
            "status IN ({})".format(
                ", ".join("'{}'".format(s)
                          for s in FILE_ARRIVAL_OBSERVATION_STATUSES)),
            name="ck_file_arrival_observations_status",
        ),
    )

    id                = Column(Integer, primary_key=True, index=True)
    dependency_name   = Column(String(200), nullable=False, index=True)
    business_date     = Column(Date, nullable=False)
    # A digest of the declaration (connection, path, pattern, control file,
    # min_files) -- two file sources on one dependency are two rows.
    spec_key          = Column(String(64), nullable=False)
    connection_id     = Column(Integer, nullable=False)
    # The RENDERED location listed, e.g. ``s3://qs-data/landing/gl/20261007/``.
    location          = Column(String(1024), nullable=False)
    status            = Column(String(20), nullable=False)
    data_files        = Column(Integer, nullable=True)
    control_found     = Column(Boolean, nullable=True)
    reason            = Column(String(2000), nullable=True)
    # Object keys, sizes and LastModified of what matched (bounded).
    evidence          = Column(JSON, nullable=True)
    looks             = Column(Integer, nullable=False, default=1)
    first_observed_at = Column(DateTime, nullable=False,
                               default=lambda: datetime.now(timezone.utc))
    observed_at       = Column(DateTime, nullable=False,
                               default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "dependency_name": self.dependency_name,
            "business_date": (self.business_date.isoformat()
                              if self.business_date else None),
            "spec_key": self.spec_key,
            "connection_id": self.connection_id,
            "location": self.location,
            "status": self.status,
            "data_files": self.data_files,
            "control_found": self.control_found,
            "reason": self.reason,
            "evidence": self.evidence,
            "looks": self.looks,
            "first_observed_at": (self.first_observed_at.isoformat()
                                  if self.first_observed_at else None),
            "observed_at": (self.observed_at.isoformat()
                            if self.observed_at else None),
        }



# Closed vocabulary for kafka_messages.resolution (BRD §7.1, §14.1).
#   'landed'       — the consumer inserted the row; meaning not yet decided.
#   'resolved'     — the resolver mapped it onto a dependency arrival.
#   'unresolvable' — FR-DEP-20: it can never resolve (bad payload / no
#                    rule / bad date); the reason is ON the row and it is
#                    never retried.
#   'unmatched'    — 2026-10-10: a TEMPLATED rule rendered a dependency
#                    name from the payload (TETB_{SYSTEM_ENTITY}_{EventCode})
#                    and no active feed declares it.  The arrival IS on the
#                    dependency_events ledger (a feed onboarded later for
#                    that combination is met by it); the row carries the
#                    rendered name + date + the reason, so an operator can
#                    list which combinations arrived with no feed.  Never
#                    dropped, never 'resolved'.
# core/feed/kafka_arrivals.py mirrors these states so its refusals and
# the DB CHECK constraint can never drift.  An EXISTING database's CHECK
# is brought up to this tuple by
# DatabaseManager._migrate_kafka_messages_resolution_check at init.
# 2026-10-11 -- 'filtered': a rule for the topic SAW the message and its
# ``match`` filter excluded it (VERSION_STATE IN_PROGRESS where the rule
# wants COMPLETE).  Ordinary traffic in another state: recorded with the
# reason, never an alert, never an arrival.  Also the state of an Oracle-
# table row the oracle_table watcher read and excluded (same resolver).
KAFKA_MESSAGE_RESOLUTIONS = ("landed", "resolved", "unresolvable", "unmatched",
                             "filtered")


# ── Envelope encryption: the DATA keys (2026-10-17) ───────────────────────

class EncryptionDataKey(Base):
    """A data key that encrypts stored secrets, held ONLY wrapped by the
    deployment's master key (``QUERY_STUDIO_SECRET_KEY`` -- Vault, synced into
    a Kubernetes Secret by the Vault operator).

    Why (the owner, 2026-10-17: "api deployed on two container ... its updated
    in values in db ... completely blocking"): every component used to encrypt
    with its OWN copy of the key, and a start-up sweep re-encrypted every stored
    secret under it -- two containers holding different keys rewrote each
    other's values and waited on each other's row locks.  Now every component
    reads the SAME data keys from the database, so they cannot diverge; the
    master key only unwraps them.  A component whose master key cannot unwrap
    them says so and never writes.  Rotating the master key re-wraps these rows
    only -- no stored secret is touched.  ``core/crypto.py`` owns the rules.
    """
    __tablename__ = "encryption_data_keys"

    id = Column(Integer, primary_key=True, index=True)
    key_id = Column(String(40), nullable=False, unique=True)       # "dk-<fingerprint>"
    wrapped = Column(Text, nullable=False)                         # Fernet(master).encrypt(data key)
    wrapped_by = Column(String(32), nullable=False)                # the master key's fingerprint
    state = Column(String(16), nullable=False, default="active")   # active | retired
    origin = Column(String(32), nullable=False, default="generated")  # generated | legacy
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    created_by = Column(String(120), nullable=True)                # host / component
    rewrapped_at = Column(DateTime, nullable=True)


# ── Change control (BRD §15, §14.2) ────────────────────────────────────────

#: Governed object kinds.  A closed vocabulary, per §14.1: "what kinds exist?"
#: must be answerable without reading code, and a typo must not become a new
#: kind that nothing ever deploys.  2026-10-17: ONE declaration, in
#: core/release/vocabulary.py -- this tuple and governance.py's used to be
#: spelled separately and DISAGREED (a deploy of a type one side knew and the
#: other refused would have failed at the database).  An existing database's
#: CHECK is brought up to it by DatabaseManager._migrate_config_deployments_check.
from core.release.vocabulary import OBJECT_TYPES as GOVERNED_OBJECT_TYPES  # noqa: E402

#: config_releases.state -- a release's walk (core/release/engine.py).
CONFIG_RELEASE_STATES = ("uploaded", "previewed", "approved", "applying", "applied",
                         "applied_unverified", "verified", "failed", "rolled_back")


class ConfigDeployment(Base):
    """One governed object, applied to one environment, at one moment.

    "Which commit is running in prod?" must be answerable FROM THE DATABASE.
    Otherwise you have git, and you have prod, and no proof they agree — which
    is the whole point of §15 and the reason this row exists rather than a
    stamp on the runtime row alone.

    ``definition`` + ``definition_hash`` snapshot WHAT WAS DEPLOYED.  That is
    one column more than §14.2 named, and it is what makes the drift report
    answerable with field-level detail from the database alone, with no git
    access at report time — an operator asking "what changed?" at 3am should
    not need a checkout.

    Append-only in practice: a redeploy is a NEW ROW, never an update.  The
    history of what ran is exactly the thing this table exists to keep.
    """
    __tablename__ = "config_deployments"
    __table_args__ = (
        Index("ix_config_deployments_object",
              "environment", "object_type", "object_id", "deployed_at"),
        CheckConstraint(
            "object_type IN ('" + "','".join(GOVERNED_OBJECT_TYPES) + "')",
            name="ck_config_deployments_object_type"),
    )

    id              = Column(Integer, primary_key=True, index=True)
    environment     = Column(String(50), nullable=False, index=True)
    object_type     = Column(String(50), nullable=False)
    object_id       = Column(Integer, nullable=True)
    name            = Column(String(255), nullable=False, index=True)
    git_commit      = Column(String(64), nullable=False)
    jira_ticket     = Column(String(64), nullable=True)
    deployed_by     = Column(String(255), nullable=True)
    deployed_at     = Column(DateTime, nullable=False,
                             server_default=sa_text("CURRENT_TIMESTAMP"))
    definition      = Column(JSON, nullable=False)
    definition_hash = Column(String(64), nullable=False)
    # 2026-10-17 (config release): which RELEASE wrote this row, what it did
    # to the object (created / updated / unchanged / kept_prod / deactivated)
    # and the package the object came from.  New COLUMNS: declared in
    # core/database.py::_MIGRATIONS["config_deployments"] too.
    release_id       = Column(Integer, nullable=True, index=True)
    action           = Column(String(20), nullable=True)
    package_checksum = Column(String(80), nullable=True)
    # §14.1 audit columns.
    created_at      = Column(DateTime, server_default=sa_text("CURRENT_TIMESTAMP"))
    created_by      = Column(String(255), nullable=True)
    updated_at      = Column(DateTime, server_default=sa_text("CURRENT_TIMESTAMP"),
                             onupdate=lambda: datetime.now(timezone.utc))
    updated_by      = Column(String(255), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "environment": self.environment,
            "object_type": self.object_type,
            "object_id": self.object_id,
            "name": self.name,
            "git_commit": self.git_commit,
            "jira_ticket": self.jira_ticket,
            "deployed_by": self.deployed_by,
            "deployed_at": (self.deployed_at.isoformat()
                            if self.deployed_at else None),
            "definition": self.definition,
            "definition_hash": self.definition_hash,
            "release_id": self.release_id,
            "action": self.action,
            "package_checksum": self.package_checksum,
        }


class ConfigRelease(Base):
    """ONE configuration release to ONE environment (2026-10-17,
    docs/RELEASE_CONFIG_DESIGN_2026_10_17.html §3.6): the uploaded package,
    its preview (per object, per field), the recorded decisions, the mapping
    used, who uploaded / approved / applied and when, the SNAPSHOT of every
    touched object taken INSIDE the apply transaction (a rollback re-applies
    it), the verification, and the error when it failed.  Append-only: a
    rollback is a new row whose ``rollback_of`` names this one.
    """
    __tablename__ = "config_releases"
    __table_args__ = (
        Index("ix_config_releases_env_state", "environment", "state"),
        CheckConstraint("state IN ('" + "','".join(CONFIG_RELEASE_STATES) + "')",
                        name="ck_config_releases_state"),
    )

    id                  = Column(Integer, primary_key=True, index=True)
    environment         = Column(String(50), nullable=False, index=True)
    state               = Column(String(24), nullable=False, default="uploaded")
    package_id          = Column(String(80), nullable=True, index=True)
    package_checksum    = Column(String(80), nullable=False)
    source_environment  = Column(String(50), nullable=True)
    source_commit       = Column(String(64), nullable=True)
    source_exported_at  = Column(String(40), nullable=True)
    source_exported_by  = Column(String(255), nullable=True)
    scope               = Column(JSON, nullable=True)
    package             = Column(JSON, nullable=False)       # the uploaded package (secret-scanned)
    preview             = Column(JSON, nullable=True)        # per object: state, fields, missing
    decisions           = Column(JSON, nullable=True)        # {"kind|key": {"field.path": take_release|keep_prod}}
    options             = Column(JSON, nullable=True)        # {"first_release_overwrites": bool, ...}
    mapping_used        = Column(JSON, nullable=True)
    jira_ticket         = Column(String(64), nullable=True)
    ticket_validation   = Column(JSON, nullable=True)
    uploaded_by         = Column(String(255), nullable=True)
    uploaded_at         = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    approved_by         = Column(String(255), nullable=True)
    approved_at         = Column(DateTime, nullable=True)
    approval_note       = Column(Text, nullable=True)
    applied_by          = Column(String(255), nullable=True)
    applied_at          = Column(DateTime, nullable=True)
    snapshot            = Column(JSON, nullable=True)        # [{kind, key, definition, hash}] BEFORE the apply
    snapshot_checksum   = Column(String(80), nullable=True)
    created_objects     = Column(JSON, nullable=True)        # [{kind, key, object_id}] the apply CREATED
    verification        = Column(JSON, nullable=True)        # {state, items: [{kind, key, verdict}]}
    verified_at         = Column(DateTime, nullable=True)
    rollback_of         = Column(Integer, nullable=True, index=True)
    error               = Column(Text, nullable=True)
    created_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self, *, with_package: bool = False) -> Dict[str, Any]:
        def _ts(v):
            return v.isoformat() if v else None
        d = {
            "id": self.id, "environment": self.environment, "state": self.state,
            "package_id": self.package_id, "package_checksum": self.package_checksum,
            "source_environment": self.source_environment, "source_commit": self.source_commit,
            "source_exported_at": self.source_exported_at, "source_exported_by": self.source_exported_by,
            "scope": self.scope, "preview": self.preview, "decisions": self.decisions or {},
            "options": self.options or {}, "mapping_used": self.mapping_used,
            "jira_ticket": self.jira_ticket, "ticket_validation": self.ticket_validation,
            "uploaded_by": self.uploaded_by, "uploaded_at": _ts(self.uploaded_at),
            "approved_by": self.approved_by, "approved_at": _ts(self.approved_at),
            "approval_note": self.approval_note,
            "applied_by": self.applied_by, "applied_at": _ts(self.applied_at),
            "snapshot_checksum": self.snapshot_checksum,
            "created_objects": self.created_objects, "verification": self.verification,
            "verified_at": _ts(self.verified_at), "rollback_of": self.rollback_of,
            "error": self.error, "created_at": _ts(self.created_at),
            "item_count": len((self.package or {}).get("items") or []),
        }
        if with_package:
            d["package"] = self.package
            d["snapshot"] = self.snapshot
        return d


class ReleaseMapping(Base):
    """How a value of the SOURCE environment reads in THIS environment
    (2026-10-17): a connection name, an SFTP host, an e-mail address, a
    username, a path, a bucket, a URL.  Stored once in the target and reused
    by every release; ``to_value == from_value`` is an explicit "the same
    here".  Never a credential: a mapping maps NAMES."""
    __tablename__ = "release_mappings"
    __table_args__ = (
        UniqueConstraint("environment", "kind", "from_value", name="ux_release_mapping"),
    )

    id          = Column(Integer, primary_key=True, index=True)
    environment = Column(String(50), nullable=False, index=True)
    kind        = Column(String(30), nullable=False)
    from_value  = Column(String(500), nullable=False)
    to_value    = Column(String(500), nullable=False)
    note        = Column(String(500), nullable=True)
    created_by  = Column(String(255), nullable=True)
    created_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                         onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "environment": self.environment, "kind": self.kind,
                "from_value": self.from_value, "to_value": self.to_value, "note": self.note,
                "created_by": self.created_by,
                "created_at": self.created_at.isoformat() if self.created_at else None,
                "updated_at": self.updated_at.isoformat() if self.updated_at else None}


class KafkaMessage(Base):
    """Landed Kafka messages — replayable, auditable (BRD §7.1, §14.2).

    The table IS the contract between transport and meaning: a message
    that arrives while QueryStudio is restarting is still a row, and
    support can see what arrived and re-apply it without a Kafka client.
    The consumer only ever INSERTs here (FR-DEP-01 — validate, dedupe,
    insert; never act); the resolver loop in core/feed/kafka_arrivals.py
    reads 'landed' rows and decides what they mean.

    FR-DEP-03 — the dedupe key is THIS TABLE's unique constraint on
    (topic, partition, offset), not consumer logic: Kafka gives
    at-least-once delivery, and a uniqueness rule enforced only in
    Python is enforced only until two pods run (§14.1).  A rebalance
    redelivery hits the constraint and lands NOTHING — so a count-based
    gate can never be satisfied twice by transport noise.
    """
    __tablename__ = "kafka_messages"
    __table_args__ = (
        UniqueConstraint("topic", "partition", "offset",
                         name="uq_kafka_messages_topic_partition_offset"),
        # The resolver's hot read: WHERE resolution='landed' ORDER BY id.
        Index("ix_kafka_messages_resolution", "resolution"),
        # §14.1 — business date is first-class and indexed on every
        # tracking table (nullable here: known only after resolution).
        Index("ix_kafka_messages_business_date", "business_date"),
        Index("ix_kafka_messages_dependency", "dependency_name"),
        CheckConstraint(
            "resolution IN ({})".format(
                ", ".join("'{}'".format(s)
                          for s in KAFKA_MESSAGE_RESOLUTIONS)),
            name="ck_kafka_messages_resolution",
        ),
    )

    id                  = Column(Integer, primary_key=True, index=True)
    topic               = Column(String(500), nullable=False)
    partition           = Column(Integer, nullable=False)
    # Kafka offsets are 64-bit; a 32-bit column would overflow on a
    # long-lived busy topic (same class as 021_widen_counters_to_bigint).
    offset              = Column(BigInteger, nullable=False)
    message_key         = Column(String(500), nullable=True)
    # The RAW payload, exactly as landed (utf-8, replacement chars for
    # undecodable bytes).  Parsing happens in the RESOLVER — a payload
    # that is not JSON still LANDS, then is marked unresolvable WITH the
    # parse error (FR-DEP-20).
    payload             = Column(Text, nullable=True)
    landed_at           = Column(DateTime, nullable=False)
    resolution          = Column(String(20), nullable=False,
                                 default="landed", server_default="landed")
    unresolvable_reason = Column(String(1000), nullable=True)
    # Filled by the resolver on success — the support screen's join to
    # the dependency_events ledger without re-parsing payloads.
    dependency_name     = Column(String(200), nullable=True)
    business_date       = Column(Date, nullable=True)
    resolved_at         = Column(DateTime, nullable=True)
    # Audit columns (§14.1); server_default so the DATABASE fills
    # created_at even for a raw INSERT (a Python default= is not DDL).
    created_at          = Column(DateTime, nullable=False,
                                 default=lambda: datetime.now(timezone.utc),
                                 server_default=sa_text("CURRENT_TIMESTAMP"))
    created_by          = Column(String(100), nullable=True)
    updated_at          = Column(DateTime, nullable=True)
    updated_by          = Column(String(100), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "topic": self.topic,
            "partition": self.partition,
            "offset": self.offset,
            "message_key": self.message_key,
            "payload": self.payload,
            "landed_at": self.landed_at.isoformat() if self.landed_at else None,
            "resolution": self.resolution,
            "unresolvable_reason": self.unresolvable_reason,
            "dependency_name": self.dependency_name,
            "business_date": self.business_date.isoformat() if self.business_date else None,
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


# Closed vocabularies for delivery_attempts (Foundation M, BRD §11, §14.1).
# core/feed/delivery_hops.py imports these tuples so the runner's refusals
# and the DB CHECK constraints can never drift.
DELIVERY_ATTEMPT_STATUSES = (
    "running",     # transport in flight — an attempt stuck here is INDETERMINATE
    "succeeded",   # delivered, with evidence
    "failed",      # transport raised (or a human marked a running attempt lost)
    "refused",     # the runner declined to send (non-idempotent repeat, no transport)
    "suppressed",  # FR-DEL-06 — policy said no delivery in this environment
    "skipped",     # prerequisite hop had not succeeded
)

# FR-DEL-13 — whether the counterparty accepted the file, declared per
# target.  Today a rejected file's first signal is a phone call.
DELIVERY_ACK_STATES = ("expected", "received", "rejected", "not_required")


class DeliveryAttempt(Base):
    """One row per hop per attempt (Foundation M — BRD §14.2).

    The natural key is ``(manifest_version, target, attempt)`` — enforced
    in the DATABASE, because a uniqueness rule enforced only in Python is
    enforced only until two pods run (§14.1).  ``manifest_version`` names
    exactly which certified part list was sent (FR-DEL-04): a regeneration
    mints a new build id and therefore a new manifest version, so a
    re-delivery of different bytes can never hide under the same name.

    ``idempotent`` records the declaration that governed this attempt
    (FR-DEL-05) — audit must show what the runner believed, not what the
    registry says today.
    """
    __tablename__ = "delivery_attempts"
    __table_args__ = (
        UniqueConstraint("manifest_version", "target", "attempt",
                         name="uq_delivery_attempts_mv_target_attempt"),
        # Operator screens filter on (feed, business_date) — the hottest
        # read path in a run-the-bank system (§14.1).
        Index("ix_delivery_attempts_feed_date",
              "feed_config_id", "business_date"),
        CheckConstraint(
            "status IN ({})".format(
                ", ".join("'{}'".format(s) for s in DELIVERY_ATTEMPT_STATUSES)),
            name="ck_delivery_attempts_status",
        ),
        CheckConstraint(
            "acknowledgment IN ({})".format(
                ", ".join("'{}'".format(s) for s in DELIVERY_ACK_STATES)),
            name="ck_delivery_attempts_ack",
        ),
    )

    id                     = Column(Integer, primary_key=True, index=True)
    # Deliberately NOT a ForeignKey — the delivery record must outlive a
    # retired feed (same rationale as run_events above).
    feed_config_id         = Column(Integer, nullable=False, index=True)
    business_date          = Column(Date, nullable=False, index=True)
    build_id               = Column(String(100), nullable=True)
    # FR-DEL-04 — the identity of WHAT was sent.  Never rewritten
    # (mixin update path refuses); a new manifest means new rows.
    manifest_version       = Column(String(120), nullable=False, index=True)
    # The hop label (unique within a chain; two SFTP endpoints in one
    # chain carry two labels so their attempts cannot collide).
    target                 = Column(String(100), nullable=False, index=True)
    target_type            = Column(String(50), nullable=False)
    attempt                = Column(Integer, nullable=False)
    status                 = Column(String(20), nullable=False)
    # FR-DEL-05 — the idempotency declaration in force for THIS attempt.
    idempotent             = Column(Boolean, nullable=False)
    # FR-DEL-07 — named endpoint reference (never credentials).
    endpoint_ref           = Column(String(200), nullable=True)
    destination_uri        = Column(String(1000), nullable=True)
    bytes_sent             = Column(BigInteger, nullable=True)
    files_sent             = Column(Integer, nullable=True)
    # §10.2 — digest of the bytes actually SENT (post package/compress/
    # encrypt), never a pre-compression form.
    checksum               = Column(String(160), nullable=True)
    checksum_algorithm     = Column(String(20), nullable=True)
    verification           = Column(String(20), nullable=True)
    verification_detail    = Column(String(500), nullable=True)
    error_message          = Column(Text, nullable=True)
    # FR-DEL-13 — counterparty acknowledgment state.
    acknowledgment         = Column(String(20), nullable=False,
                                    default="not_required",
                                    server_default=sa_text("'not_required'"))
    acknowledged_at        = Column(DateTime, nullable=True)
    acknowledgment_detail  = Column(String(500), nullable=True)
    started_at             = Column(DateTime, nullable=True)
    completed_at           = Column(DateTime, nullable=True)
    # Audit columns on every governed table (§14.1).  server_default so
    # the DATABASE fills created_at even for a raw INSERT (§14).
    created_at             = Column(DateTime, nullable=False,
                                    default=lambda: datetime.now(timezone.utc),
                                    server_default=sa_text("CURRENT_TIMESTAMP"))
    created_by             = Column(String(100), nullable=True)
    updated_at             = Column(DateTime, nullable=True,
                                    onupdate=lambda: datetime.now(timezone.utc))
    updated_by             = Column(String(100), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "feed_config_id": self.feed_config_id,
            "business_date": self.business_date.isoformat() if self.business_date else None,
            "build_id": self.build_id,
            "manifest_version": self.manifest_version,
            "target": self.target,
            "target_type": self.target_type,
            "attempt": self.attempt,
            "status": self.status,
            "idempotent": self.idempotent,
            "endpoint_ref": self.endpoint_ref,
            "destination_uri": self.destination_uri,
            "bytes_sent": self.bytes_sent,
            "files_sent": self.files_sent,
            "checksum": self.checksum,
            "checksum_algorithm": self.checksum_algorithm,
            "verification": self.verification,
            "verification_detail": self.verification_detail,
            "error_message": self.error_message,
            "acknowledgment": self.acknowledgment,
            "acknowledged_at": self.acknowledged_at.isoformat() if self.acknowledged_at else None,
            "acknowledgment_detail": self.acknowledgment_detail,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "created_by": self.created_by,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "updated_by": self.updated_by,
        }


# ═══════════════════════════════════════════════════════════════════════════
# Foundation C — child file runs + connection claims (BRD 2026-09-02,
# §4.2/§4.3, FR-RUN-02/04/05/06/07/08) and the partition declaration
# store (§9.2/§9.3, FR-CMP-02).  All four are NEW TABLES (never new
# columns on existing ones): they self-create via create_all(), so the
# first deploy needs no migration step to be correct (§14.2).
# ═══════════════════════════════════════════════════════════════════════════

# Closed vocabulary (§14.1) — core/feed/fanout.py imports this tuple so the
# code's refusals and the DB CHECK constraint can never drift.
FEED_FILE_RUN_STATUSES = (
    "pending",    # declared, nothing executed yet (FR-RUN-05)
    "running",    # a worker holds the claim and is writing the part
    "completed",  # part written; part_path + row_count recorded
    "failed",     # retries exhausted; stays failed without touching siblings
    "cancelled",  # a human stopped it; terminal, never silently retried
)

#: Statuses a child can be re-run FROM ("re-run file 738", §4.3).  A
#: pending/running child is already on its way — resetting it would race
#: the worker that owns it.
FEED_FILE_RUN_TERMINAL_STATUSES = ("completed", "failed", "cancelled")

# What a connection claim is held FOR.  ``feed_run`` = the whole run
# (single-file feeds); ``file_run`` = one fanned-out child.  Part of the
# unique key because feed_runs.id and feed_file_runs.id are DIFFERENT id
# spaces — without the kind, a child claim could collide with (or worse,
# silently satisfy) an unrelated parent claim that happens to share the
# integer.
CONNECTION_CLAIM_RUN_KINDS = ("feed_run", "file_run")

# §9.3 — an empty partition list is a DECISION, not a no-op.
# core/feed/completeness.py declares the same vocabulary; the CHECK
# constraint below is built from THIS tuple so the DB can never accept a
# value the code would refuse.
PARTITION_DECLARATION_ON_EMPTY = ("fail", "skip")


class FeedFileRun(Base):
    """One child run per declared partition (Foundation C, FR-RUN-02).

    The reason a child is a ROW and not a loop iteration is
    addressability: a loop iteration cannot be re-run alone, and
    "re-run file 738 without touching the other 999" is a hard
    requirement (§4.3).  Identity is ``(feed_run_id, partition_key)`` —
    enforced in the DATABASE, because a uniqueness rule enforced only in
    Python is enforced only until two pods run (§14.1).

    The PARENT's status is DERIVED from these rows
    (core/feed/fanout.py:derive_parent_status) and never written directly
    (FR-RUN-04) — a directly-written parent is how a re-run of one child
    leaves a permanently failed parent, or how a parent reports complete
    while a child is still writing.
    """
    __tablename__ = "feed_file_runs"
    __table_args__ = (
        UniqueConstraint("feed_run_id", "partition_key",
                         name="uq_feed_file_runs_run_partition"),
        # Operator screens filter on (feed, business_date) and on
        # (run, status) — the hottest read paths (§14.1).
        Index("ix_feed_file_runs_run_status", "feed_run_id", "status"),
        Index("ix_feed_file_runs_feed_date", "feed_config_id", "business_date"),
        CheckConstraint(
            "status IN ({})".format(
                ", ".join("'{}'".format(s) for s in FEED_FILE_RUN_STATUSES)),
            name="ck_feed_file_runs_status",
        ),
    )

    id             = Column(Integer, primary_key=True, index=True)
    # CASCADE: a child names nothing without its parent run; the durable
    # audit trail lives in run_events + the parts manifest, not here.
    feed_run_id    = Column(Integer,
                            ForeignKey("feed_runs.id", ondelete="CASCADE"),
                            nullable=False, index=True)
    # Denormalised from the parent at fan-out time so operator screens
    # filter without a join — business date is a first-class indexed
    # column on every run table (§14.1).  Nullable: the parent is the
    # authority; these are display/filter copies.
    feed_config_id = Column(Integer, nullable=True, index=True)
    business_date  = Column(Date, nullable=True, index=True)
    partition_key  = Column(String(500), nullable=False)
    status         = Column(String(20), nullable=False, default="pending",
                            index=True)
    attempt_count  = Column(Integer, nullable=False, default=0)
    # Owner + heartbeat (§14.1 "claims and heartbeats carry a timestamp
    # and an owner") — the orphan reaper keys on heartbeat_at, never on
    # age alone.
    claimed_by     = Column(String(100), nullable=True)
    started_at     = Column(DateTime, nullable=True)
    completed_at   = Column(DateTime, nullable=True)
    heartbeat_at   = Column(DateTime, nullable=True)
    part_path      = Column(Text, nullable=True)
    row_count      = Column(BigInteger, nullable=True)
    error          = Column(Text, nullable=True)
    # §14.1 audit columns.
    created_at     = Column(DateTime, nullable=False,
                            default=lambda: datetime.now(timezone.utc),
                            server_default=sa_text("CURRENT_TIMESTAMP"))
    created_by     = Column(String(100), nullable=True)
    updated_at     = Column(DateTime, nullable=True,
                            onupdate=lambda: datetime.now(timezone.utc))
    updated_by     = Column(String(100), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "feed_run_id": self.feed_run_id,
            "feed_config_id": self.feed_config_id,
            "business_date": self.business_date.isoformat() if self.business_date else None,
            "partition_key": self.partition_key,
            "status": self.status,
            "attempt_count": self.attempt_count,
            "claimed_by": self.claimed_by,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "heartbeat_at": self.heartbeat_at.isoformat() if self.heartbeat_at else None,
            "part_path": self.part_path,
            "row_count": self.row_count,
            "error": self.error,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "created_by": self.created_by,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "updated_by": self.updated_by,
        }


class ConnectionConcurrencyBudget(Base):
    """Per-connection concurrency allowance (Foundation C, FR-RUN-06).

    The BRD sketches this as ``connections.max_concurrent_runs`` — a new
    COLUMN on an existing table, which its own §14 rule forbids (a new
    table self-creates; a new column needs a migration on every deployed
    pod).  A dedicated table keeps the first deploy correct with no
    migration step, and gives the reservation (FR-OPS-11) a home.

    NO ROW for a connection means UNBOUNDED — the pre-Foundation-C
    behaviour, so deploying this changes nothing until an admin declares
    a budget.  ``max_concurrent_runs = 0`` means PAUSED (zero slots) and
    NEVER "unlimited" — '0 means unlimited' has shipped 1M of 70M rows
    in this codebase before.
    """
    __tablename__ = "connection_concurrency_budgets"
    __table_args__ = (
        UniqueConstraint("connection_id",
                         name="uq_connection_budgets_connection"),
        CheckConstraint("max_concurrent_runs >= 0",
                        name="ck_connection_budgets_max_nonneg"),
        CheckConstraint("reserved_critical_slots >= 0",
                        name="ck_connection_budgets_reserved_nonneg"),
        # A reservation larger than the budget is a configuration that
        # can never be satisfied — refused by the DATABASE (§14.1).
        CheckConstraint("reserved_critical_slots <= max_concurrent_runs",
                        name="ck_connection_budgets_reserved_within_max"),
    )

    id                      = Column(Integer, primary_key=True, index=True)
    # No FK on purpose: the budget row must not vanish under CASCADE
    # while claims reference the connection id; stale budgets are inert.
    connection_id           = Column(Integer, nullable=False, index=True)
    max_concurrent_runs     = Column(Integer, nullable=False)
    # FR-OPS-11 — slots only claims at/above the critical priority
    # ceiling may use, so the highest-priority work always has a slot.
    reserved_critical_slots = Column(Integer, nullable=False, default=0)
    # §14.1 audit columns.
    created_at              = Column(DateTime, nullable=False,
                                     default=lambda: datetime.now(timezone.utc),
                                     server_default=sa_text("CURRENT_TIMESTAMP"))
    created_by              = Column(String(100), nullable=True)
    updated_at              = Column(DateTime, nullable=True,
                                     onupdate=lambda: datetime.now(timezone.utc))
    updated_by              = Column(String(100), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "connection_id": self.connection_id,
            "max_concurrent_runs": self.max_concurrent_runs,
            "reserved_critical_slots": self.reserved_critical_slots,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "created_by": self.created_by,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "updated_by": self.updated_by,
        }


class ConnectionClaim(Base):
    """Who holds a concurrency slot right now (Foundation C, FR-RUN-06..08).

    Today's cap is ``max_concurrent`` on the queue worker — a PER-PROCESS
    number, so three replicas allow three times the intended concurrency
    and nothing in the system knows.  This table moves the count into the
    DATABASE: one row per (connection, run) while the run holds the slot.

    Acquisition is ALL-OR-NOTHING across the run's whole connection set
    (FR-RUN-07, mixin_feeds.try_acquire_connection_claims): a feed's
    effective concurrency is the MINIMUM free budget across every source
    it touches.  Rows carry a pod owner and a heartbeat so a dead pod's
    slots are reclaimed on the same pattern as the run reaper (FR-RUN-08),
    not discovered by a human at 2am.
    """
    __tablename__ = "connection_claims"
    __table_args__ = (
        UniqueConstraint("connection_id", "run_kind", "run_id",
                         name="uq_connection_claims_conn_kind_run"),
        Index("ix_connection_claims_kind_run", "run_kind", "run_id"),
        CheckConstraint(
            "run_kind IN ({})".format(
                ", ".join("'{}'".format(k) for k in CONNECTION_CLAIM_RUN_KINDS)),
            name="ck_connection_claims_run_kind",
        ),
    )

    id             = Column(Integer, primary_key=True, index=True)
    connection_id  = Column(Integer, nullable=False, index=True)
    run_kind       = Column(String(20), nullable=False, default="feed_run")
    run_id         = Column(Integer, nullable=False, index=True)
    pod_id         = Column(String(100), nullable=False)
    # The EFFECTIVE priority the claim was granted at (after
    # anti-starvation aging) — diagnostics for "why is my feed waiting".
    priority       = Column(Integer, nullable=True)
    feed_config_id = Column(Integer, nullable=True, index=True)
    claimed_at     = Column(DateTime, nullable=False,
                            default=lambda: datetime.now(timezone.utc))
    heartbeat_at   = Column(DateTime, nullable=False,
                            default=lambda: datetime.now(timezone.utc))
    # §14.1 audit columns.
    created_at     = Column(DateTime, nullable=False,
                            default=lambda: datetime.now(timezone.utc),
                            server_default=sa_text("CURRENT_TIMESTAMP"))
    created_by     = Column(String(100), nullable=True)
    updated_at     = Column(DateTime, nullable=True,
                            onupdate=lambda: datetime.now(timezone.utc))
    updated_by     = Column(String(100), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "connection_id": self.connection_id,
            "run_kind": self.run_kind,
            "run_id": self.run_id,
            "pod_id": self.pod_id,
            "priority": self.priority,
            "feed_config_id": self.feed_config_id,
            "claimed_at": self.claimed_at.isoformat() if self.claimed_at else None,
            "heartbeat_at": self.heartbeat_at.isoformat() if self.heartbeat_at else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "created_by": self.created_by,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "updated_by": self.updated_by,
        }


class FeedPartitionDeclaration(Base):
    """The declared partition list, recorded WITH the run (FR-CMP-02).

    §9.2: with fan-out, the dangerous case is not a failed child — a
    failure is loud.  It is a child that NEVER EXISTED: the partition
    list was built from a query that returned 1,180 entities instead of
    1,240 because a reference table was mid-load.  Every child succeeds,
    every part certifies, and the feed is 60 entities short with every
    signal green.  Storing the IDENTITIES (not a count) is what lets the
    next run name the 60 missing entities exactly, with no threshold.

    One declaration per run (UNIQUE feed_run_id): the declaration is
    immutable evidence — a changed list means a re-run, which is a new
    run with a new build_id.
    """
    __tablename__ = "feed_partition_declarations"
    __table_args__ = (
        UniqueConstraint("feed_run_id",
                         name="uq_feed_partition_declarations_run"),
        # get_partition_declaration_before scans (feed, business_date).
        Index("ix_feed_partition_declarations_feed_date",
              "feed_config_id", "business_date"),
        CheckConstraint(
            "on_empty IN ({})".format(
                ", ".join("'{}'".format(v)
                          for v in PARTITION_DECLARATION_ON_EMPTY)),
            name="ck_feed_partition_declarations_on_empty",
        ),
    )

    id             = Column(Integer, primary_key=True, index=True)
    # No FK on purpose: the declaration is completeness EVIDENCE and must
    # outlive a purged run row — next year's "what was declared for date
    # D?" must still be answerable (§9.3 "shown again next year").
    feed_run_id    = Column(Integer, nullable=False, index=True)
    feed_config_id = Column(Integer, nullable=False, index=True)
    business_date  = Column(Date, nullable=False, index=True)
    # The LIST — identities, not a count (FR-CMP-02).
    identities     = Column(JSON, nullable=False)
    identity_count = Column(Integer, nullable=False)
    on_empty       = Column(String(10), nullable=False, default="fail")
    # e.g. the partition.values.sql text that produced the list.
    source         = Column(Text, nullable=True)
    declared_at    = Column(DateTime, nullable=False)
    # §14.1 audit columns.
    created_at     = Column(DateTime, nullable=False,
                            default=lambda: datetime.now(timezone.utc),
                            server_default=sa_text("CURRENT_TIMESTAMP"))
    created_by     = Column(String(100), nullable=True)
    updated_at     = Column(DateTime, nullable=True,
                            onupdate=lambda: datetime.now(timezone.utc))
    updated_by     = Column(String(100), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "feed_run_id": self.feed_run_id,
            "feed_config_id": self.feed_config_id,
            "business_date": self.business_date.isoformat() if self.business_date else None,
            "identities": list(self.identities or []),
            "identity_count": self.identity_count,
            "on_empty": self.on_empty,
            "source": self.source,
            "declared_at": self.declared_at.isoformat() if self.declared_at else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "created_by": self.created_by,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "updated_by": self.updated_by,
        }


class ApiKey(Base):
    """API key for external access to published views."""
    __tablename__ = "api_keys"

    id              = Column(Integer, primary_key=True, index=True)
    key_hash        = Column(String(128), unique=True, nullable=False, index=True)  # SHA-256
    key_prefix      = Column(String(12), nullable=False)                             # first 8 chars for display
    encrypted_key   = Column(String(512), nullable=True)                             # Fernet-encrypted raw key for admin retrieval
    name            = Column(String(255), nullable=False)
    created_by      = Column(String(100), nullable=True)
    scoped_view_ids = Column(JSON, nullable=True)       # [1,3,5] — empty/null = all views
    rate_limit      = Column(String(50), nullable=True)  # per-key override e.g. "120/minute"
    is_active       = Column(Boolean, default=True)
    expires_at      = Column(DateTime, nullable=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    last_used_at    = Column(DateTime, nullable=True)
    usage_count     = Column(Integer, default=0)
    # 2026-10-17 -- a key gets a FACE (the published-API inventory's consumer):
    # the team / system it represents, the person answerable (defaults to the
    # request's requested_by at approval, else created_by), a contact address.
    consumer        = Column(String(200), nullable=True)
    owner_username  = Column(String(100), nullable=True)
    contact_email   = Column(String(255), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "key_prefix": self.key_prefix,
            "name": self.name,
            "created_by": self.created_by,
            "consumer": self.consumer,
            "owner_username": self.owner_username,
            "contact_email": self.contact_email,
            "scoped_view_ids": self.scoped_view_ids or [],
            "rate_limit": self.rate_limit,
            "is_active": self.is_active,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "last_used_at": self.last_used_at.isoformat() if self.last_used_at else None,
            "usage_count": self.usage_count,
        }


class ApiKeyRequest(Base):
    """Self-service API key request — users request, admins approve/deny."""
    __tablename__ = "api_key_requests"

    id              = Column(Integer, primary_key=True, index=True)
    requested_by    = Column(String(100), nullable=False, index=True)
    status          = Column(String(20), default="pending", nullable=False, index=True)
    scoped_view_ids = Column(JSON, nullable=False)
    key_name        = Column(String(255), nullable=False)
    rate_limit      = Column(String(50), nullable=True)
    expires_hours   = Column(Integer, nullable=True)
    justification   = Column(Text, nullable=True)
    # 2026-10-17 -- who the key is FOR (copied onto the key at approval)
    consumer        = Column(String(200), nullable=True)
    contact_email   = Column(String(255), nullable=True)
    reviewed_by     = Column(String(100), nullable=True)
    reviewed_at     = Column(DateTime, nullable=True)
    review_note     = Column(Text, nullable=True)
    api_key_id      = Column(Integer, nullable=True, index=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "requested_by": self.requested_by,
            "status": self.status,
            "scoped_view_ids": self.scoped_view_ids or [],
            "key_name": self.key_name,
            "rate_limit": self.rate_limit,
            "expires_hours": self.expires_hours,
            "justification": self.justification,
            "consumer": self.consumer,
            "contact_email": self.contact_email,
            "reviewed_by": self.reviewed_by,
            "reviewed_at": self.reviewed_at.isoformat() if self.reviewed_at else None,
            "review_note": self.review_note,
            "api_key_id": self.api_key_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class ApiAccessLog(Base):
    """THE call record of every published API (2026-10-17,
    core/published_api/calls.py).  One row per call -- answered OR refused --
    written in batches off the request (core/access_log_batcher.py).

    Until 2026-10-17 this was the published VIEWS' usage row: a view id, a
    key id, rows, ms, status.  It now names the API by KIND
    (``api_kind`` published_view | published_report, ``api_id`` the kind's
    id, ``api_slug`` the path's slug kept even when no row matched), the
    CONSUMER (the admission identity: ``apikey:<id>``, a username,
    ``token:<8>``) and how it authenticated, the ENDPOINT and format, the
    cache status as a column, the bytes when measured (NULL = not measured,
    never 0) and the REFUSAL reason (rate_limit, key_concurrency, bulk_lane,
    memory_pressure, unauthenticated, forbidden, retired, ...).
    ``view_id`` is NULLABLE: a refusal raised before the view was read (the
    rate limit, by design) and a report's call have none.  Swept after
    ``published_views.access_log_retention_days``; folded into
    ``published_api_call_rollups`` by the rollup daemon."""
    __tablename__ = "api_access_log"
    __table_args__ = (
        Index("ix_api_access_log_api_created", "api_kind", "api_id", "created_at"),
        Index("ix_api_access_log_consumer_created", "consumer", "created_at"),
    )

    id              = Column(Integer, primary_key=True, index=True)
    api_key_id      = Column(Integer, nullable=True, index=True)
    view_id         = Column(Integer, nullable=True, index=True)
    execution_id    = Column(String(64), nullable=True)
    request_params  = Column(JSON, nullable=True)
    response_rows   = Column(BigInteger, nullable=True)
    response_ms     = Column(Integer, nullable=True)
    status_code     = Column(Integer, nullable=True)
    client_ip       = Column(String(45), nullable=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    # 2026-10-17 -- the columns the inventory dashboard needs (all nullable:
    # rows written before this date carry NULLs and read as published_view
    # when view_id is set -- the rollup says so)
    api_kind        = Column(String(30), nullable=True)
    api_id          = Column(Integer, nullable=True)
    api_slug        = Column(String(220), nullable=True)
    consumer        = Column(String(200), nullable=True)
    auth_method     = Column(String(20), nullable=True)
    endpoint        = Column(String(40), nullable=True)
    format          = Column(String(16), nullable=True)
    cache_status    = Column(String(10), nullable=True)
    response_bytes  = Column(BigInteger, nullable=True)
    refusal         = Column(String(40), nullable=True)
    pod             = Column(String(64), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "api_key_id": self.api_key_id,
            "view_id": self.view_id,
            "execution_id": self.execution_id,
            "request_params": self.request_params,
            "response_rows": self.response_rows,
            "response_ms": self.response_ms,
            "status_code": self.status_code,
            "client_ip": self.client_ip,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "api_kind": self.api_kind,
            "api_id": self.api_id,
            "api_slug": self.api_slug,
            "consumer": self.consumer,
            "auth_method": self.auth_method,
            "endpoint": self.endpoint,
            "format": self.format,
            "cache_status": self.cache_status,
            "response_bytes": self.response_bytes,
            "refusal": self.refusal,
            "pod": self.pod,
        }


class PublishedApiIngestHealth(Base):
    """ONE row per access-log WRITER PROCESS (2026-10-17): what it queued,
    wrote, dropped (queue full) and lost (write failed) since it started,
    reported once a minute by core/access_log_batcher.py.  It is what makes
    the dashboard's completeness a statement instead of a hope: a process
    that stopped reporting is named, a loss is a number.  RUNTIME."""
    __tablename__ = "published_api_ingest_health"
    __table_args__ = (UniqueConstraint("pod", "pid", name="ux_pub_api_ingest_pod_pid"),)

    id                 = Column(Integer, primary_key=True, autoincrement=True)
    pod                = Column(String(64), nullable=False)
    pid                = Column(Integer, nullable=False)
    started_at         = Column(DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    reported_at        = Column(DateTime, nullable=False, default=lambda: datetime.now(timezone.utc), index=True)
    submitted          = Column(BigInteger, nullable=False, default=0)
    written            = Column(BigInteger, nullable=False, default=0)
    batches            = Column(BigInteger, nullable=False, default=0)
    dropped_queue_full = Column(BigInteger, nullable=False, default=0)
    lost_write_failed  = Column(BigInteger, nullable=False, default=0)
    queued             = Column(Integer, nullable=False, default=0)

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "pod": self.pod, "pid": self.pid,
                "started_at": self.started_at.isoformat() if self.started_at else None,
                "reported_at": self.reported_at.isoformat() if self.reported_at else None,
                "submitted": self.submitted, "written": self.written, "batches": self.batches,
                "dropped_queue_full": self.dropped_queue_full,
                "lost_write_failed": self.lost_write_failed, "queued": self.queued}


class PublishedApiCallRollup(Base):
    """ONE bucket of published-API calls (2026-10-17, core/published_api/
    rollup.py): hourly or daily, per (API, consumer, endpoint) -- counts by
    status class and code, refusals by reason, rows, bytes (and how many
    calls measured them), cache hits / misses, latency sum / min / max and a
    log-spaced latency HISTOGRAM (26 bins, ratio
    ``published_views.rollup_latency_bin_ratio``) from which p50 / p95 / p99
    are read for any range.  ``api_kind`` '' + ``api_id`` 0 = a call whose
    slug named no API (``api_slug`` kept).  Written by the scheduler-pod
    daemon ``published_api_rollup``, replaced per bucket in one transaction;
    read by the dashboard.  RUNTIME: rebuilt from the call record."""
    __tablename__ = "published_api_call_rollups"
    __table_args__ = (
        Index("ix_pub_api_rollup_grain_bucket", "grain", "bucket_start"),
        Index("ix_pub_api_rollup_api", "api_kind", "api_id", "grain", "bucket_start"),
        Index("ix_pub_api_rollup_consumer", "consumer", "grain", "bucket_start"),
    )

    grain             = Column(String(6), primary_key=True)                  # hour | day
    bucket_start      = Column(DateTime, primary_key=True)                   # UTC, aligned
    api_kind          = Column(String(30), primary_key=True, default="")
    api_id            = Column(Integer, primary_key=True, default=0, autoincrement=False)
    consumer          = Column(String(200), primary_key=True, default="")
    endpoint          = Column(String(40), primary_key=True, default="")
    api_slug          = Column(String(220), nullable=True)
    calls             = Column(Integer, nullable=False, default=0)
    ok_2xx            = Column(Integer, nullable=False, default=0)
    redirect_3xx      = Column(Integer, nullable=False, default=0)
    client_4xx        = Column(Integer, nullable=False, default=0)
    server_5xx        = Column(Integer, nullable=False, default=0)
    by_status         = Column(JSON, nullable=True)
    refused           = Column(JSON, nullable=True)
    rows_sum          = Column(BigInteger, nullable=False, default=0)
    bytes_sum         = Column(BigInteger, nullable=False, default=0)
    bytes_known_calls = Column(Integer, nullable=False, default=0)
    cache_hit         = Column(Integer, nullable=False, default=0)
    cache_miss        = Column(Integer, nullable=False, default=0)
    cache_bypass      = Column(Integer, nullable=False, default=0)
    latency_ms_sum    = Column(BigInteger, nullable=False, default=0)
    latency_ms_min    = Column(Integer, nullable=True)
    latency_ms_max    = Column(Integer, nullable=True)
    latency_bins      = Column(JSON, nullable=True)
    last_call_at      = Column(DateTime, nullable=True)
    rolled_at         = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {"grain": self.grain, "bucket_start": self.bucket_start.isoformat() if self.bucket_start else None,
                "api_kind": self.api_kind, "api_id": self.api_id, "api_slug": self.api_slug,
                "consumer": self.consumer, "endpoint": self.endpoint, "calls": self.calls, "ok_2xx": self.ok_2xx,
                "redirect_3xx": self.redirect_3xx, "client_4xx": self.client_4xx, "server_5xx": self.server_5xx,
                "by_status": dict(self.by_status or {}), "refused": dict(self.refused or {}),
                "rows_sum": self.rows_sum, "bytes_sum": self.bytes_sum, "bytes_known_calls": self.bytes_known_calls,
                "cache_hit": self.cache_hit, "cache_miss": self.cache_miss, "cache_bypass": self.cache_bypass,
                "latency_ms_sum": self.latency_ms_sum, "latency_ms_min": self.latency_ms_min,
                "latency_ms_max": self.latency_ms_max, "latency_bins": list(self.latency_bins or []),
                "last_call_at": self.last_call_at.isoformat() if self.last_call_at else None,
                "rolled_at": self.rolled_at.isoformat() if self.rolled_at else None}


class PublishedApiRollupState(Base):
    """The rollup's WATERMARK per grain (2026-10-17): the newest bucket
    considered final, the last tick, the bin ratio the rows were built with
    (a changed ratio refuses to mix histograms).  What every dashboard answer
    shows as "numbers end at HH:MM".  RUNTIME."""
    __tablename__ = "published_api_rollup_state"

    grain          = Column(String(6), primary_key=True)
    rolled_through = Column(DateTime, nullable=True)
    last_tick_at   = Column(DateTime, nullable=True)
    last_tick_rows = Column(Integer, nullable=True)
    last_error     = Column(Text, nullable=True)
    bin_ratio      = Column(Float, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {"grain": self.grain,
                "rolled_through": self.rolled_through.isoformat() if self.rolled_through else None,
                "last_tick_at": self.last_tick_at.isoformat() if self.last_tick_at else None,
                "last_tick_rows": self.last_tick_rows, "last_error": self.last_error, "bin_ratio": self.bin_ratio}


class PublishedApiAlertThreshold(Base):
    """ONE alert threshold over the published APIs (2026-10-17, design §3.8;
    core/published_api/alerts.py): a METRIC over a WINDOW, for every API
    (``scope`` global), every API of a kind (``kind`` + ``api_kind``) or one
    API (``api`` + ``api_kind`` + ``scope_key`` = the API's key as the
    inventory shows it -- a view's slug, a report's id; the release type
    carries a report's release key, its slug, instead), a breach when ``value``
    ``operator`` the threshold, ``min_calls`` under which the window is
    INSUFFICIENT (never a breach), ``clear_after_windows`` consecutive healthy
    windows to clear, and the ``feed_alert_kinds`` row the breach raises.
    RELEASE configuration (``api_alert_threshold``); seeded once into an
    empty table; edited at /api/published-apis/alert-thresholds."""
    __tablename__ = "published_api_alert_thresholds"
    __table_args__ = (UniqueConstraint("scope", "api_kind", "scope_key", "metric", "name",
                                       name="ux_pub_api_threshold"),)

    id                  = Column(Integer, primary_key=True, index=True)
    name                = Column(String(120), nullable=False)
    scope               = Column(String(16), nullable=False, default="global")     # global | kind | api
    api_kind            = Column(String(30), nullable=False, default="")           # '' | published_view | published_report
    scope_key           = Column(String(220), nullable=False, default="")          # '' | the API's key
    metric              = Column(String(32), nullable=False)
    operator            = Column(String(2), nullable=False, default=">")
    value               = Column(Float, nullable=False)
    window_minutes      = Column(Integer, nullable=False, default=15)
    min_calls           = Column(Integer, nullable=False, default=50)
    clear_after_windows = Column(Integer, nullable=False, default=2)
    alert_kind          = Column(String(60), nullable=False)
    is_active           = Column(Boolean, nullable=False, default=True)
    created_by          = Column(String(100), nullable=True)
    created_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_by          = Column(String(100), nullable=True)
    updated_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "name": self.name, "scope": self.scope, "api_kind": self.api_kind or "",
                "scope_key": self.scope_key or "", "metric": self.metric, "operator": self.operator,
                "value": self.value, "window_minutes": self.window_minutes, "min_calls": self.min_calls,
                "clear_after_windows": self.clear_after_windows, "alert_kind": self.alert_kind,
                "is_active": bool(self.is_active), "created_by": self.created_by,
                "created_at": self.created_at.isoformat() if self.created_at else None,
                "updated_by": self.updated_by,
                "updated_at": self.updated_at.isoformat() if self.updated_at else None}


class PublishedApiAlertState(Base):
    """The last VERDICT of one threshold over one API (2026-10-17,
    core/published_api/alerts.py::evaluate_thresholds): the state (ok /
    breach / insufficient / unknown), the value and calls it was read from,
    the healthy and breached streaks (``clear_after_windows`` is judged on
    ``healthy_since``), the open alert and its dedupe key.  What the page
    shows as "the thresholds that apply and their current value".  RUNTIME:
    rebuilt by the next tick."""
    __tablename__ = "published_api_alert_state"

    threshold_id   = Column(Integer, primary_key=True, autoincrement=False)
    api_kind       = Column(String(30), primary_key=True)
    api_id         = Column(Integer, primary_key=True, autoincrement=False)
    api_slug       = Column(String(220), nullable=True)
    state          = Column(String(16), nullable=False)
    value          = Column(Float, nullable=True)
    calls          = Column(Integer, nullable=True)
    detail         = Column(String(255), nullable=True)
    healthy_since  = Column(DateTime, nullable=True)
    breached_since = Column(DateTime, nullable=True)
    alert_id       = Column(Integer, nullable=True)
    dedupe_key     = Column(String(255), nullable=True)
    evaluated_at   = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        def _iso(v):
            return v.isoformat() if v else None
        return {"threshold_id": self.threshold_id, "api_kind": self.api_kind, "api_id": self.api_id,
                "api_slug": self.api_slug, "state": self.state, "value": self.value, "calls": self.calls,
                "detail": self.detail, "healthy_since": _iso(self.healthy_since),
                "breached_since": _iso(self.breached_since), "alert_id": self.alert_id,
                "dedupe_key": self.dedupe_key, "evaluated_at": _iso(self.evaluated_at)}


###############################################################################
# Phase 134 — Query Performance Audit Log
###############################################################################

class QueryPerformanceLog(Base):
    """Per-query performance metrics for admin dashboards and cost attribution."""
    __tablename__ = "query_performance_log"

    id              = Column(Integer, primary_key=True, index=True)
    execution_id    = Column(String(100), nullable=True, index=True)
    username        = Column(String(100), nullable=False, index=True)
    connection_id   = Column(Integer, nullable=True, index=True)
    tables          = Column(JSON, nullable=True)                  # ["sales_2024", "inventory"]
    duration_ms     = Column(Integer, nullable=True)
    files_listed    = Column(Integer, nullable=True)
    files_after_partition_pruning = Column(Integer, nullable=True)
    files_after_footer_pruning    = Column(Integer, nullable=True)
    files_downloaded = Column(Integer, nullable=True)
    files_from_cache = Column(Integer, nullable=True)
    bytes_downloaded = Column(BigInteger, nullable=True)
    bytes_from_cache = Column(BigInteger, nullable=True)
    rows_returned   = Column(Integer, nullable=True)
    columns_requested = Column(Integer, nullable=True)
    cache_hit_rate  = Column(Float, nullable=True)
    partition_filters_used = Column(JSON, nullable=True)
    estimate_shown  = Column(Boolean, default=False)
    source          = Column(String(50), nullable=True)            # "cqb", "bqb", "pv_api", "stream"
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "execution_id": self.execution_id,
            "username": self.username,
            "connection_id": self.connection_id, "tables": self.tables,
            "duration_ms": self.duration_ms,
            "files_listed": self.files_listed,
            "files_after_partition_pruning": self.files_after_partition_pruning,
            "files_after_footer_pruning": self.files_after_footer_pruning,
            "files_downloaded": self.files_downloaded,
            "files_from_cache": self.files_from_cache,
            "bytes_downloaded": self.bytes_downloaded,
            "bytes_from_cache": self.bytes_from_cache,
            "rows_returned": self.rows_returned,
            "columns_requested": self.columns_requested,
            "cache_hit_rate": self.cache_hit_rate,
            "partition_filters_used": self.partition_filters_used,
            "estimate_shown": self.estimate_shown,
            "source": self.source,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


###############################################################################
# Phase 114 — Published View Webhooks, DQ Alerts, NL Conversations, Comments
###############################################################################

class PublishedViewSchemaVersion(Base):
    """One recorded SCHEMA of a published view -- the column list a consumer
    sees -- and, from the second version on, what changed since the last.

    2026-09-27.  ``published_views.version`` bumps on any query_config
    change, and nothing recorded which COLUMNS a consumer had been reading
    when a republish, a query update or an auto-detect on the dataset behind
    a report-sourced view renamed, added or removed one.  Consumers found
    out from a KeyError in their client.  Written by
    ``core/published_view_schema.py::record_schema`` only; a new TABLE
    self-creates through create_all.

    ``changes`` is ``{"added": [...], "removed": [...], "retyped": [...]}``
    (each entry ``{"name", "type"}`` / ``{"name", "from", "to"}``); empty on
    version 1.  ``notified`` records who was told and how -- the emailed
    addresses, the usernames that could not be routed, and the send verdict
    -- so "was anyone told" is answerable from the row, never from a log.
    """
    __tablename__ = "published_view_schema_versions"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    view_id      = Column(Integer, nullable=False, index=True)
    version_no   = Column(Integer, nullable=False)
    columns      = Column(JSON, nullable=False, default=list)   # [{"name","type"}]
    columns_hash = Column(String(64), nullable=False)
    changes      = Column(JSON, nullable=True)
    reason       = Column(String(40), nullable=False)           # publish | republish | query_update | update | dataset_auto_detect
    changed_by   = Column(String(100), nullable=True)
    notified     = Column(JSON, nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)

    __table_args__ = (
        UniqueConstraint("view_id", "version_no", name="ux_pv_schema_version"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "view_id": self.view_id,
            "version_no": self.version_no,
            "columns": list(self.columns or []),
            "columns_hash": self.columns_hash,
            # None on the baseline (version 1): there was nothing to diff
            # against, which is a different statement from "nothing changed"
            "changes": self.changes,
            "reason": self.reason,
            "changed_by": self.changed_by,
            "notified": self.notified,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class PublishedViewWebhook(Base):
    """Webhook subscriptions for Published View events."""
    __tablename__ = "published_view_webhooks"

    id              = Column(Integer, primary_key=True)
    view_id         = Column(Integer, nullable=True, index=True)  # null = all views
    url             = Column(String(1000), nullable=False)
    events          = Column(JSON, nullable=False)  # ["view_updated", "cache_invalidated"]
    secret          = Column(String(255), nullable=True)  # HMAC-SHA256 signing secret
    is_active       = Column(Boolean, default=True)
    retry_max       = Column(Integer, default=3)
    timeout_seconds = Column(Integer, default=10)
    created_by      = Column(String(100), nullable=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    last_triggered_at = Column(DateTime, nullable=True)
    last_status_code  = Column(Integer, nullable=True)

    def to_dict(self):
        return {
            "id": self.id, "view_id": self.view_id, "url": self.url,
            "events": self.events or [], "is_active": self.is_active,
            "retry_max": self.retry_max, "timeout_seconds": self.timeout_seconds,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "last_triggered_at": self.last_triggered_at.isoformat() if self.last_triggered_at else None,
            "last_status_code": self.last_status_code,
        }


class DataQualityAlert(Base):
    """Alert delivery records for data quality rule failures."""
    __tablename__ = "dq_alerts"

    id         = Column(Integer, primary_key=True)
    rule_id    = Column(Integer, nullable=False, index=True)
    result_id  = Column(Integer, nullable=True)
    channel    = Column(String(50), nullable=False)   # email, webhook, slack, websocket
    recipient  = Column(String(500), nullable=True)
    status     = Column(String(20), default="pending")  # pending, sent, failed
    sent_at    = Column(DateTime, nullable=True)
    error      = Column(Text, nullable=True)
    payload    = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self):
        return {
            "id": self.id, "rule_id": self.rule_id, "result_id": self.result_id,
            "channel": self.channel, "recipient": self.recipient,
            "status": self.status,
            "sent_at": self.sent_at.isoformat() if self.sent_at else None,
            "error": self.error,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class NLConversation(Base):
    """Cross-session conversation memory for the NL assistant."""
    __tablename__ = "nl_conversations"

    id         = Column(Integer, primary_key=True)
    user_id    = Column(String(100), nullable=False, index=True)
    title      = Column(String(255), nullable=True)
    messages   = Column(JSON, nullable=False, default=list)
    context    = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self):
        return {
            "id": self.id, "user_id": self.user_id, "title": self.title,
            "messages": self.messages or [],
            "context": self.context,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class ReportComment(Base):
    """Threaded comments on business reports."""
    __tablename__ = "report_comments"

    id          = Column(Integer, primary_key=True)
    report_id   = Column(Integer, nullable=False, index=True)
    parent_id   = Column(Integer, nullable=True, index=True)  # null = top-level
    username    = Column(String(100), nullable=False)
    text        = Column(Text, nullable=False)
    mentions    = Column(JSON, nullable=True)  # ["user1", "user2"]
    is_resolved = Column(Boolean, default=False)
    created_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self):
        return {
            "id": self.id, "report_id": self.report_id, "parent_id": self.parent_id,
            "username": self.username, "text": self.text,
            "mentions": self.mentions or [], "is_resolved": self.is_resolved,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class ReportChangeLog(Base):
    """Field-level change history for business reports."""
    __tablename__ = "report_change_log"

    id         = Column(Integer, primary_key=True)
    report_id  = Column(Integer, nullable=False, index=True)
    username   = Column(String(100), nullable=False)
    action     = Column(String(50), nullable=False)  # created, updated, published, unpublished
    changes    = Column(JSON, nullable=True)  # [{"field": ..., "old": ..., "new": ...}]
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self):
        return {
            "id": self.id, "report_id": self.report_id,
            "username": self.username, "action": self.action,
            "changes": self.changes or [],
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


###############################################################################
# Phase 83 — Production Stability Models
###############################################################################

class BusinessReportAsyncJob(Base):
    """Persistent async execution record for business reports. Phase 83A."""
    __tablename__ = "business_report_async_jobs"

    id           = Column(String(36), primary_key=True)   # UUID = execution_id
    report_id    = Column(Integer, nullable=False, index=True)
    status       = Column(String(20), default="running")  # running/completed/failed/cancelled
    progress_pct = Column(Integer, default=0)
    total_rows   = Column(BigInteger, nullable=True)
    output_path  = Column(String(500), nullable=True)
    error        = Column(Text, nullable=True)
    created_by   = Column(String(100), nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    completed_at = Column(DateTime, nullable=True)
    # 2026-09-28: a RUNNING job's non-terminal state.  ``waiting_for`` is a
    # vocabulary (today only "capacity": the run is admitted and waiting for
    # the pod's global query capacity); ``status_detail`` is the sentence
    # the status route shows for it.  Both are cleared when capacity is
    # obtained and on every terminal write.  Both are in _MIGRATIONS (a
    # column does not self-create).
    waiting_for   = Column(String(32), nullable=True)
    status_detail = Column(Text, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "execution_id": self.id,
            "report_id": self.report_id,
            "status": self.status,
            "progress_pct": self.progress_pct,
            "total_rows": self.total_rows,
            "output_path": self.output_path,
            "error": self.error,
            "waiting_for": self.waiting_for,
            "status_detail": self.status_detail,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }


class ReportInstance(Base):
    """A durable, addressable, permission-checked pointer to an execution
    artifact — the BusinessObjects "instance" model.  Phase 2 report-instance
    layer (2026-08-09, target architecture §5).

    An instance owns NO bytes: ``execution_id`` references the
    ``{execution_id}.parquet`` artifact every successful execution already
    writes (validated by ``core/reports/contract.py require_artifact``);
    artifact byte retention stays with today's execution-artifact
    lifecycle.  Deleting/expiring an instance deletes the ROW only.

    Serve key = (report_id, params_fingerprint, rls_signature,
    semantic_version) — all four are EXACT-match GATES (a mismatch is a
    MISS, never a wildcard).  ``rls_signature`` comes from
    ``core/row_security/signature.py scope_signature()`` and is recomputed
    live for the CALLER on every open, so a policy change structurally
    stops old instances from matching.  ``stale_at``/``expires_at`` are the
    temporal CAP (stale = served with an as-of banner, expired = miss).
    """
    __tablename__ = "report_instances"

    id                 = Column(Integer, primary_key=True, autoincrement=True)
    report_id          = Column(Integer, nullable=False, index=True)
    execution_id       = Column(String(64), nullable=False)    # -> the artifact
    artifact_path      = Column(String(500), nullable=True)    # convenience copy of the artifact location
    params_fingerprint = Column(String(64), nullable=False)    # signature.params_fingerprint()
    rls_signature      = Column(String(80), nullable=False)    # signature.scope_signature()
    semantic_version   = Column(String(64), nullable=False)    # report def + semantic model hash
    source_version     = Column(String(80), nullable=True)     # source snapshot id when derivable, else NULL (= freshness unknown, disclosed not coerced)
    status             = Column(String(20), default="ready")   # ready|stale|expired
    is_scheduled       = Column(Boolean, default=False)        # produced by a schedule (pre-warm)
    row_count          = Column(BigInteger, nullable=True)
    # 2026-08-09 adversarial cross-feature review D1/D2 — the truncation
    # facts are properties of the RUN that built the artifact, not of the
    # open that serves it.  Recomputing the verdict at serve time against
    # the BR-configured limit resurrected the silent-truncation defect
    # 122a8c30 killed (engine clamped at 100K, BR limit 500K → served
    # "truncated: false" for a definitely-cut result).  All three are
    # NULLABLE: NULL = UNKNOWN (pre-fix rows) and MUST be disclosed as
    # unknown on serve, never defaulted to False (correctness gate).
    row_limit          = Column(Integer, nullable=True)        # EFFECTIVE limit the run executed under (post engine clamp)
    truncated          = Column(Boolean, nullable=True)        # engine verdict at record time; NULL = unknown (tri-state preserved)
    unstable_truncation = Column(Boolean, nullable=True)       # cut with no ORDER BY → kept rows unstable; NULL = not disclosed/unknown
    created_by         = Column(String(100), nullable=False)
    created_at         = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    stale_at           = Column(DateTime, nullable=True)       # soft TTL — serve with banner past this
    expires_at         = Column(DateTime, nullable=True)       # hard TTL — miss past this

    __table_args__ = (
        # THE lookup: latest valid instance for (report, params, scope[, version])
        Index("ix_ri_lookup", "report_id", "params_fingerprint",
              "rls_signature", "semantic_version"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "report_id": self.report_id,
            "execution_id": self.execution_id,
            "artifact_path": self.artifact_path,
            "params_fingerprint": self.params_fingerprint,
            "rls_signature": self.rls_signature,
            "semantic_version": self.semantic_version,
            "source_version": self.source_version,
            "status": self.status,
            "is_scheduled": bool(self.is_scheduled),
            "row_count": self.row_count,
            # D1/D2 tri-state discipline: None stays None (UNKNOWN disclosed,
            # never coerced) — only a real stored verdict becomes a bool.
            "row_limit": self.row_limit,
            "truncated": (bool(self.truncated)
                          if self.truncated is not None else None),
            "unstable_truncation": (bool(self.unstable_truncation)
                                    if self.unstable_truncation is not None
                                    else None),
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "stale_at": self.stale_at.isoformat() if self.stale_at else None,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
        }


class ReportInstanceSignoff(Base):
    """A named person signing ONE report instance (2026-09-28).

    The finance controller signs a RUN, not a report: the row copies the
    instance's identity (execution id, params fingerprint, row-security
    signature, semantic version, source version, artifact path, row count)
    so the record stands on its own after the instance row is gone -- an
    auditor in March reads what was signed for 12 January from this row.

    ``rls_signature`` is the INSTANCE's scope (the scope the artifact was
    computed at), never the signer's: a sign-off on EMEA rows is a fact
    about EMEA rows and is shown only against instances of that scope
    (``core/reports/signoff.py::scope_visible``).

    An ACTIVE row LOCKS the instance: the artifact is exempt from the
    cleaner, the row survives retention pruning and cannot be expired or
    deleted (``core/db/mixin_datasets.py``).  Revoking is a status change
    with a reason, never a delete -- the history stays.
    """
    __tablename__ = "report_instance_signoffs"

    id                 = Column(Integer, primary_key=True, autoincrement=True)
    report_id          = Column(Integer, nullable=False, index=True)
    instance_id        = Column(Integer, nullable=False, index=True)
    execution_id       = Column(String(64), nullable=False)
    artifact_path      = Column(String(500), nullable=True)
    params_fingerprint = Column(String(64), nullable=False)
    rls_signature      = Column(String(80), nullable=False)
    semantic_version   = Column(String(64), nullable=False)
    source_version     = Column(String(80), nullable=True)
    row_count          = Column(BigInteger, nullable=True)
    business_date      = Column(String(10), nullable=True)     # ISO date the signer signed FOR
    role               = Column(String(20), nullable=False)    # preparer | reviewer | approver
    signed_by          = Column(String(100), nullable=False)
    signed_at          = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    note               = Column(Text, nullable=True)
    status             = Column(String(20), nullable=False, default="active")  # active | revoked
    revoked_by         = Column(String(100), nullable=True)
    revoked_at         = Column(DateTime, nullable=True)
    revoke_reason      = Column(Text, nullable=True)

    __table_args__ = (
        Index("ix_ris_instance_status", "instance_id", "status"),
        Index("ix_ris_report_key", "report_id", "params_fingerprint",
              "rls_signature"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "report_id": self.report_id,
            "instance_id": self.instance_id,
            "execution_id": self.execution_id,
            "artifact_path": self.artifact_path,
            "params_fingerprint": self.params_fingerprint,
            "rls_signature": self.rls_signature,
            "semantic_version": self.semantic_version,
            "source_version": self.source_version,
            "row_count": self.row_count,
            "business_date": self.business_date,
            "role": self.role,
            "signed_by": self.signed_by,
            "signed_at": self.signed_at.isoformat() if self.signed_at else None,
            "note": self.note,
            "status": self.status,
            "revoked_by": self.revoked_by,
            "revoked_at": self.revoked_at.isoformat() if self.revoked_at else None,
            "revoke_reason": self.revoke_reason,
        }


class ReportInstanceComment(Base):
    """A comment bound to ONE report instance (2026-09-28).

    Distinct from ``report_comments`` (a report-level thread every author
    of the report reads) because the visibility rule differs: this thread
    is scoped by the instance's ``rls_signature`` -- a note about EMEA rows
    is shown only to principals whose live scope resolves to those rows,
    and to admins with the scope labelled.  Mixing the two rules in one
    table would be two answers to "who may read this".

    ``anchor`` is what the note is about: ``{"kind": "instance"}``,
    ``{"kind": "row", "key": {...}}``, ``{"kind": "column", "column": c}``
    or ``{"kind": "cell", "key": {...}, "column": c}`` -- a row is named by
    its KEY-COLUMN VALUES, never by a row index, so the note survives
    re-sorting and paging.
    """
    __tablename__ = "report_instance_comments"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    report_id     = Column(Integer, nullable=False, index=True)
    instance_id   = Column(Integer, nullable=False, index=True)
    rls_signature = Column(String(80), nullable=False)
    business_date = Column(String(10), nullable=True)
    parent_id     = Column(Integer, nullable=True, index=True)
    username      = Column(String(100), nullable=False)
    text          = Column(Text, nullable=False)
    mentions      = Column(JSON, nullable=True)
    anchor        = Column(JSON, nullable=True)
    is_resolved   = Column(Boolean, default=False)
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "report_id": self.report_id,
            "instance_id": self.instance_id,
            "rls_signature": self.rls_signature,
            "business_date": self.business_date,
            "parent_id": self.parent_id,
            "username": self.username,
            "text": self.text,
            "mentions": self.mentions or [],
            "anchor": self.anchor or {"kind": "instance"},
            "is_resolved": bool(self.is_resolved),
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class CircuitBreakerState(Base):
    """Persistent circuit breaker state. Phase 83B."""
    __tablename__ = "circuit_breaker_states"

    connection_id   = Column(Integer, primary_key=True)
    state           = Column(String(20), default="CLOSED")  # CLOSED/OPEN/HALF_OPEN
    failure_count   = Column(Integer, default=0)
    opened_at       = Column(DateTime, nullable=True)
    last_failure    = Column(DateTime, nullable=True)
    connection_name = Column(String(200), nullable=True)
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class SchedulerLock(Base):
    """Distributed lock ensuring only one APScheduler instance runs. Phase 83C."""
    __tablename__ = "scheduler_lock"

    id           = Column(Integer, primary_key=True, default=1)  # only one row ever
    worker_id    = Column(String(100), nullable=False)            # hostname:pid
    acquired_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    heartbeat_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))


class RateLimitWindow(Base):
    """One fixed rate-limit window of one (action, identity) -- the SHARED
    limiter's counter (2026-10-03, ``core/rate_limiter.py``).

    The in-process limiter counted per PROCESS: with 2 published-api pods a
    300/minute key got ~600/minute, and every uvicorn worker multiplied it
    again.  Every pod already shares the metadata database, so the window
    lives here and is advanced by ONE atomic statement
    (``INSERT ... ON CONFLICT (key) DO UPDATE SET n = n + 1 WHERE n < limit
    RETURNING n``): a returned row is an admission, no row is a refusal --
    the fleet admits exactly ``limit`` per window, whatever the number of
    pods or processes.  ``window_start`` / ``expires_at`` are epoch seconds
    (the window is ``floor(now / window_seconds) * window_seconds``);
    ``expires_at`` is what the retention sweep ``rate_limit_window_cleanup``
    reads.  ``identity`` longer than the column is stored as a prefix plus
    a digest of the whole value (two identities can never share a row).
    """
    __tablename__ = "rate_limit_windows"

    action         = Column(String(64),  primary_key=True)
    identity       = Column(String(200), primary_key=True)
    window_seconds = Column(Integer,     primary_key=True, autoincrement=False)
    window_start   = Column(BigInteger,  primary_key=True, autoincrement=False)
    n              = Column(Integer,     nullable=False, default=0)
    expires_at     = Column(BigInteger,  nullable=False, index=True)


class SparkJobReport(Base):
    """The Spark job's completion report as RECEIVED by the callback -- the
    webhook's durable CLAIM (2026-10-11, core/db/mixin_spark_job_reports.py).

    The webhook verifies the signature, INSERTs here and ACKs; finalisation
    (core/spark_k8s/completion.py::finalize_from_report, the one finaliser
    per state) runs off the request and stamps ``finalized_at``.
    ``execution_id`` is UNIQUE: of two callbacks for one run (the job
    retries after a timeout) exactly one INSERT wins and only its request
    finalises.  A claim never stamped (the API pod died between ACK and
    finalisation) is finished by the reconciler from this row after
    ``spark_k8s.webhook_grace_seconds``; a fresh unstamped claim tells the
    reconciler a finalisation is in flight.  The report is the callback
    body as JSON text (the same dict the driver's termination message
    carries); credentials never travel in it.
    """
    __tablename__ = "spark_job_reports"

    id             = Column(Integer, primary_key=True, autoincrement=True)
    execution_id   = Column(String(128), nullable=False, unique=True, index=True)
    state          = Column(String(20), nullable=False)
    report         = Column(Text, nullable=False)
    received_via   = Column(String(32), nullable=False, default="webhook")
    received_at    = Column(DateTime, nullable=False, index=True,
                            default=lambda: datetime.now(timezone.utc))
    finalized_at   = Column(DateTime, nullable=True)
    finalized_via  = Column(String(32), nullable=True)
    finalize_error = Column(Text, nullable=True)


class PvBulkPrepareJob(Base):
    """One background bulk build of a published view (POST
    /api/v1/views/{slug}/bulk/prepare) -- the SHARED job registry
    (2026-10-03, ``api/published_views/bulk_jobs.py``).

    The registry was a dict in the process that took the POST, so a poll
    that reached a sibling process (another uvicorn worker, another pod)
    answered 404 "POST prepare again" -- and that second POST started a
    SECOND multi-hour build of the same dataset.  The building process
    mirrors the job here (status, progress, heartbeat); any process answers
    the poll from this row; a ``running`` row whose ``heartbeat_at`` stopped
    is reported failed (its process ended) instead of in flight forever.
    Times are epoch seconds; ``body`` is the JSON of the job's public fields.
    """
    __tablename__ = "pv_bulk_prepare_jobs"

    job_id       = Column(String(32),  primary_key=True)
    dataset_key  = Column(String(64),  nullable=False, index=True)
    view_id      = Column(Integer,     nullable=True)
    slug         = Column(String(255), nullable=False)
    status       = Column(String(16),  nullable=False)
    owner        = Column(String(200), nullable=True)
    created_at   = Column(Float,       nullable=False)
    heartbeat_at = Column(Float,       nullable=False)
    finished_at  = Column(Float,       nullable=True, index=True)
    body         = Column(Text,        nullable=True)


class PvBulkPrepareClaim(Base):
    """Which job builds one bulk DATASET (its cache slot) right now -- the
    cross-process "one build per dataset" claim (2026-10-03).  The PRIMARY
    KEY is the claim: the first INSERT wins; replacing a finished or dead
    job is a compare-and-swap on ``job_id``.  ``dataset_key`` is the sha256
    of the bulk slot's path, which every process of every pod computes
    identically on the shared cache volume."""
    __tablename__ = "pv_bulk_prepare_claims"

    dataset_key = Column(String(64), primary_key=True)
    job_id      = Column(String(32), nullable=False)
    claimed_at  = Column(Float,      nullable=False)


class PvMaterialiseFlight(Base):
    """ONE cold materialisation per published-view dataset across every
    process and pod (2026-10-04, ``api/published_views/cold_flight.py``).
    The PRIMARY KEY is the claim: the first INSERT leads, the rest follow
    the flight and read the cache file it publishes; taking over a
    finished, abandoned or stale (heartbeat older than
    ``published_views.cold_flight_stale_seconds``) flight is a
    compare-and-swap on ``flight_id``.  ``flight_key`` is the sha256 of the
    dataset's cache-slot PATH.  ``outcome`` is the HTTP answer of a failed
    leader (JSON: status_code, detail, headers) that its followers give."""
    __tablename__ = "pv_materialise_flights"

    flight_key   = Column(String(64),  primary_key=True)
    flight_id    = Column(String(32),  nullable=False)
    owner        = Column(String(255), nullable=False)
    status       = Column(String(16),  nullable=False)   # running|done|failed|abandoned
    slug         = Column(String(255), nullable=True)
    started_at   = Column(Float,       nullable=False)
    heartbeat_at = Column(Float,       nullable=False)
    finished_at  = Column(Float,       nullable=True)
    outcome      = Column(Text,        nullable=True)


class QueuedWaitCancel(Base):
    """A cancel of a run that is WAITING for a slot, addressed by the
    correlation id its client sent (2026-10-07, H1 item 4,
    ``core/queued_wait_cancels.py``).  A wait lives in the process that
    holds the execute POST; ``POST /api/execute/queued/cancel`` may land on
    ANY process or pod, so the one that cannot find the wait locally writes
    this row and the one holding it reads it on its next wait tick (one
    primary-key lookup per tick per process, only while it holds waiters).
    The key is (client_request_id, username): a row is honoured only for the
    user who wrote it.  Rows are short-lived -- read after
    ``TTL_SECONDS`` (120) they are ignored, and swept."""
    __tablename__ = "queued_wait_cancels"

    client_request_id = Column(String(64),  primary_key=True)
    username          = Column(String(255), primary_key=True)
    requested_at      = Column(Float,       nullable=False, index=True)


###############################################################################
# Phase 84 — Learning-Based NL Chatbot Models
###############################################################################

class NLQueryHistory(Base):
    """Learning history for NL-to-SQL. Phase 84."""
    __tablename__ = "nl_query_history"

    id                = Column(Integer, primary_key=True, index=True)
    nl_query          = Column(Text, nullable=False)
    generated_sql     = Column(Text, nullable=True)
    executed_sql      = Column(Text, nullable=True)   # may differ if user edited
    intent            = Column(String(100), nullable=True)
    schema_hash       = Column(String(32), nullable=True)  # MD5 of table/column names used
    was_edited        = Column(Boolean, default=False)     # user changed the SQL before running
    execution_success = Column(Boolean, nullable=True)
    feedback_score    = Column(Integer, nullable=True)     # +1 thumbs up, -1 thumbs down
    username          = Column(String(100), nullable=True)
    connection_id     = Column(Integer, nullable=True)
    created_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "nl_query": self.nl_query,
            "generated_sql": self.generated_sql,
            "executed_sql": self.executed_sql,
            "intent": self.intent,
            "schema_hash": self.schema_hash,
            "was_edited": self.was_edited,
            "execution_success": self.execution_success,
            "feedback_score": self.feedback_score,
            "username": self.username,
            "connection_id": self.connection_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class NLPattern(Base):
    """Scored NL pattern + SQL template. Phase 84."""
    __tablename__ = "nl_patterns"

    id            = Column(Integer, primary_key=True, index=True)
    pattern       = Column(Text, nullable=False)         # regex or keyword set
    template_sql  = Column(Text, nullable=False)         # parameterized SQL template
    intent        = Column(String(100), nullable=True)
    score         = Column(Float, default=1.0)
    hit_count     = Column(Integer, default=0)
    success_count = Column(Integer, default=0)
    is_learned    = Column(Boolean, default=False)       # True = auto-generated
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    last_used     = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "pattern": self.pattern,
            "template_sql": self.template_sql,
            "intent": self.intent,
            "score": self.score,
            "hit_count": self.hit_count,
            "success_count": self.success_count,
            "is_learned": self.is_learned,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "last_used": self.last_used.isoformat() if self.last_used else None,
        }


class SystemAccount(Base):
    """Service/system accounts for automated credential fetching. Phase 87.
    Credentials are encrypted at rest via core.crypto.

    Phase 154 (2026-06-25) -- vault-resolver fields added.  When
    ``use_vault=True`` AND vault is globally enabled, the username +
    password columns are IGNORED at resolution time -- the resolver
    fires QSClient with the per-account ref config below and
    returns the live secret (with TTL cache + last-known-good
    fallback identical to ETL/qs_credentials/resolver.py).

    Apply rule (Phase 154 single-chokepoint):
      * Use ``use_vault=False`` (default) for back-compat with the
        encrypted password column.  Direct passthrough.
      * Use ``use_vault=True`` for prod -- creds live in vault, this
        row stores only the LOOKUP metadata.  Same ref shape as
        ETL/qs_credentials/resolver.py so secrets registered for ETL can be
        reused by QueryStudio without re-onboarding.
    """
    __tablename__ = "system_accounts"

    id           = Column(Integer, primary_key=True, index=True)
    name         = Column(String(255), nullable=False, unique=True, index=True)
    account_type = Column(String(50), nullable=False)   # "aws_portal" | "snowflake_sso" | "s3_keys" | "db_account" | "ad_account" | "sftp_account" | "snowflake_keypair"
    username     = Column(String(255), nullable=False)
    password     = Column(Text, nullable=False)          # encrypted via crypto.py (legacy; ignored when use_vault=True)
    config       = Column(JSON, nullable=True)            # extra config (portal_url override, etc.)
    is_active    = Column(Boolean, default=True)
    last_used_at = Column(DateTime, nullable=True)
    last_status  = Column(String(50), nullable=True)     # "success" | "failed"
    last_error   = Column(Text, nullable=True)
    created_by   = Column(String(100), nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                          onupdate=lambda: datetime.now(timezone.utc))

    # ── Phase 154: vault-resolver fields (mirrors ETL/qs_credentials) ──
    # When use_vault=True, the resolver consults QSClient with the
    # config below INSTEAD of returning the encrypted password.
    # 2026-08-10 -- server_default was sa_text("0"), which renders literally
    # into the CREATE TABLE.  PostgreSQL REJECTS an integer default on a
    # boolean column ("column is of type boolean but default expression is of
    # type integer"), so Base.metadata.create_all() raised and left ZERO
    # tables -- a fresh PostgreSQL install could not boot at all.  SQLite
    # never complained (0 is a valid boolean affinity there), which is why it
    # shipped.  ``sa.false()`` renders FALSE on PG and 0 on SQLite.
    #
    # _pg_coltype already translates exactly this for the MIGRATION path;
    # the model's server_default never went through it.
    use_vault    = Column(Boolean, nullable=False,
                           default=False, server_default=sa_false())
    # Free-form ref name -- defaults to the row's ``name`` column at
    # resolution time when this field is blank (so existing accounts
    # don't need a separate ref name).  Stored explicitly when the
    # vault registers the secret under a DIFFERENT name than the
    # local account label (e.g. local name="prod-trino" but vault
    # ref="onprem-trino-svc-acct").
    secret_ref   = Column(String(255), nullable=True)
    # QSClient secret_type -- "DB_accounts" (user, password tuple)
    # | "AD_accounts" (same shape) | "kv_secrets" (dict of fields).
    # Driven by what kind of secret backs the upstream connector.
    secret_type  = Column(String(50), nullable=True)
    # Per-account vault refs -- exactly mirrors the ETL yaml-refs
    # shape so the same vault entries serve both pods.  All optional
    # at the model level; the resolver raises with an actionable
    # error when use_vault=True but required fields are blank.
    vault_auth_url    = Column(Text, nullable=True)
    vault_role_name   = Column(String(255), nullable=True)
    vault_role_type   = Column(String(50), nullable=True)
    vault_secret_url  = Column(Text, nullable=True)
    vault_rotate_url  = Column(Text, nullable=True)
    # 2026-07-13 — ETL PARITY: AppRole / JWT-step-up ref fields.  The vault
    # dance (qs_credentials.vault, byte-identical to ETL) reads these for
    # token_method="approle": step-up JWT login → generate secret_id → AppRole
    # login.  Previously the SystemAccount only carried the JWT-path fields, so
    # _row_to_ref built an incomplete ref vs ETL's vault_config.yaml and
    # AppRole could not work from QueryStudio.  All optional; only needed when
    # the account uses AppRole.
    vault_step_up_name          = Column(String(255), nullable=True)
    vault_step_up_auth_url      = Column(Text, nullable=True)
    vault_approle_secret_id_url = Column(Text, nullable=True)
    vault_approle_auth_url      = Column(Text, nullable=True)
    vault_role_id               = Column(String(255), nullable=True)  # AppRole role_id
    # 2026-09-10 — Clockwork plan v2 §3.2: which ENVIRONMENT this account
    # belongs to (PROD / NONPROD / a site's own vocabulary).  A scheduled
    # job whose account's environment does not match the deployment it
    # fires in is refused BEFORE the claim, naming both values.  The
    # default is the fail-closed UNSPECIFIED: it is refused at fire time
    # until an operator declares it.  Deliberately NOT ``NONPROD`` — the
    # FOREIGN-BUT-PRESENT lesson: a copied PROD row must never read as
    # non-prod because nobody filled the column in.  Migrated explicitly
    # in core/database.py::_MIGRATIONS["system_accounts"] (a new COLUMN
    # does not self-create).
    environment = Column(String(20), nullable=False, default="UNSPECIFIED",
                         server_default="UNSPECIFIED")

    def to_dict(self, include_password: bool = False) -> Dict[str, Any]:
        d = {
            "id":           self.id,
            "name":         self.name,
            "account_type": self.account_type,
            "environment":  self.environment or "UNSPECIFIED",
            "username":     self.username,
            "password":     self.password if include_password else "***",
            "config":       self.config,
            "is_active":    self.is_active,
            "last_used_at": self.last_used_at.isoformat() if self.last_used_at else None,
            "last_status":  self.last_status,
            "last_error":   self.last_error,
            "created_by":   self.created_by,
            "created_at":   self.created_at.isoformat() if self.created_at else None,
            "updated_at":   self.updated_at.isoformat() if self.updated_at else None,
            # Phase 154 vault-resolver surface — non-sensitive metadata is
            # ALWAYS safe to expose; the _url fields + role_id are only added
            # on the raw/internal path (include_password=True) below.
            "use_vault":        bool(self.use_vault),
            "secret_ref":       self.secret_ref,
            "secret_type":      self.secret_type,
            "vault_role_name":  self.vault_role_name,
            "vault_role_type":  self.vault_role_type,
        }
        # 2026-07-13 CORRECTNESS FIX: the resolver builds the vault ref from
        # THIS dict via get_system_account_raw (include_password=True).  The
        # _url fields were NEVER emitted, so _row_to_ref got an EMPTY
        # auth_url / secret_url → the vault call failed for ALL methods (JWT
        # included), not just AppRole.  Emit the full ref-building surface on
        # the raw/internal path ONLY (kept OUT of the masked API/list path so
        # sensitive URLs + role_id are never exposed to the UI table).
        if include_password:
            d.update({
                "vault_auth_url":              self.vault_auth_url,
                "vault_secret_url":            self.vault_secret_url,
                "vault_rotate_url":            self.vault_rotate_url,
                # ETL-parity AppRole / JWT-step-up ref fields.
                "vault_step_up_name":          self.vault_step_up_name,
                "vault_step_up_auth_url":      self.vault_step_up_auth_url,
                "vault_approle_secret_id_url": self.vault_approle_secret_id_url,
                "vault_approle_auth_url":      self.vault_approle_auth_url,
                "vault_role_id":               self.vault_role_id,
            })
        return d


class TableDescription(Base):
    """Admin-editable metadata and usage tracking for catalog tables. Phase 92."""
    __tablename__ = "table_descriptions"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    connection_id   = Column(Integer, nullable=False, index=True)
    table_name      = Column(String(255), nullable=False, index=True)
    description     = Column(Text, nullable=True)
    updated_by      = Column(String(100), nullable=True)
    updated_at      = Column(DateTime, nullable=True)
    preview_count   = Column(Integer, default=0)
    last_queried_at = Column(DateTime, nullable=True)

    __table_args__ = (UniqueConstraint("connection_id", "table_name", name="uq_table_desc"),)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "connection_id": self.connection_id,
            "table_name": self.table_name,
            "description": self.description,
            "updated_by": self.updated_by,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "preview_count": self.preview_count or 0,
            "last_queried_at": self.last_queried_at.isoformat() if self.last_queried_at else None,
        }


class NLSynonym(Base):
    """User vocabulary to schema column synonym mappings. Phase 84."""
    __tablename__ = "nl_synonyms"

    id          = Column(Integer, primary_key=True, index=True)
    user_term   = Column(String(200), nullable=False, index=True)
    schema_term = Column(String(200), nullable=False)
    column_id   = Column(Integer, nullable=True)
    score       = Column(Float, default=1.0)
    hit_count   = Column(Integer, default=0)
    created_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "user_term": self.user_term,
            "schema_term": self.schema_term,
            "column_id": self.column_id,
            "score": self.score,
            "hit_count": self.hit_count,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class FederationView(Base):
    """A named cross-connection query (JOIN/UNION of two S3 queries). Phase 93."""
    __tablename__ = "federation_views"

    id                = Column(Integer, primary_key=True, index=True)
    name              = Column(String(200), unique=True, nullable=False, index=True)
    description       = Column(Text, default="")
    primary_conn_id   = Column(Integer, nullable=False)
    primary_query     = Column(JSON, nullable=False)       # full QueryConfigModel-compatible dict
    secondary_conn_id = Column(Integer, nullable=False)
    secondary_query   = Column(JSON, nullable=False)       # full QueryConfigModel-compatible dict
    combine_mode      = Column(String(20), default="union", nullable=False)  # "join" | "union"
    join_on           = Column(JSON, default=list)         # [{"left": col, "right": col}]
    join_how          = Column(String(20), default="inner")  # inner | left | right | full
    output_columns    = Column(JSON, default=list)         # [] = all columns
    is_active         = Column(Boolean, default=True)
    created_by        = Column(String(100), nullable=True)
    created_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                               onupdate=lambda: datetime.now(timezone.utc))
    # ── Phase 97: Materialization state ──
    storage_path      = Column(String(500), nullable=True)
    status            = Column(String(30), default="virtual")  # virtual|materializing|ready|failed
    last_materialized = Column(DateTime, nullable=True)
    last_mat_duration = Column(Float, nullable=True)
    row_count         = Column(BigInteger, nullable=True)
    column_count      = Column(Integer, nullable=True)
    file_size_bytes   = Column(BigInteger, nullable=True)
    last_error        = Column(Text, nullable=True)
    # ── Phase 97: Schema cache (inline JSON — instant column lookups) ──
    schema_cache      = Column(JSON, nullable=True)       # [{name, type, nullable}, ...]
    schema_cached_at  = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description or "",
            "primary_conn_id": self.primary_conn_id,
            "primary_query": self.primary_query,
            "secondary_conn_id": self.secondary_conn_id,
            "secondary_query": self.secondary_query,
            "combine_mode": self.combine_mode or "union",
            "join_on": self.join_on or [],
            "join_how": self.join_how or "inner",
            "output_columns": self.output_columns or [],
            "is_active": self.is_active,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
            "storage_path": self.storage_path,
            "status": self.status or "virtual",
            "last_materialized": self.last_materialized.isoformat() if self.last_materialized else None,
            "last_mat_duration": self.last_mat_duration,
            "row_count": self.row_count,
            "column_count": self.column_count,
            "file_size_bytes": self.file_size_bytes,
            "last_error": self.last_error,
            "schema_cache": self.schema_cache,
            "schema_cached_at": self.schema_cached_at.isoformat() if self.schema_cached_at else None,
        }


# ── Phase 99: Data Quality Monitoring ────────────────────────────────────────

class DataQualityRule(Base):
    """A configurable data quality check rule."""
    __tablename__ = "dq_rules"

    id              = Column(Integer, primary_key=True, index=True)
    name            = Column(String(255), nullable=False)
    description     = Column(Text, nullable=True)
    rule_type       = Column(String(50), nullable=False)   # freshness, schema_drift, null_rate, row_count, custom_sql
    target_type     = Column(String(50), nullable=False, default="connection")  # connection, published_view, feed
    target_id       = Column(Integer, nullable=True)
    target_table    = Column(String(500), nullable=True)
    column_name     = Column(String(255), nullable=True)
    config          = Column(JSON, nullable=True)
    schedule_cron   = Column(String(100), nullable=True)
    enabled         = Column(Boolean, default=True)
    severity        = Column(String(20), default="warning")  # info, warning, critical
    created_by      = Column(String(100), nullable=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                             onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "name": self.name, "description": self.description,
            "rule_type": self.rule_type, "target_type": self.target_type,
            "target_id": self.target_id, "target_table": self.target_table,
            "column_name": self.column_name, "config": self.config or {},
            "schedule_cron": self.schedule_cron, "enabled": self.enabled,
            "severity": self.severity, "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class DataQualityResult(Base):
    """Result of a single DQ rule evaluation."""
    __tablename__ = "dq_results"

    id              = Column(Integer, primary_key=True, index=True)
    rule_id         = Column(Integer, nullable=False, index=True)
    passed          = Column(Boolean, nullable=False)
    #: 2026-09-17 (FB-8b) -- passed/failed/errored.  ``passed`` alone could
    #: not distinguish "this data is bad" from "this check never ran", and
    #: both arrived as {"passed": false, "severity": "critical"} -- so a
    #: misconfigured rule raised a critical data alert.  NULLABLE on purpose:
    #: rows written before this column existed have an UNKNOWN outcome, and
    #: back-filling them from ``passed`` would invent a distinction the old
    #: writer never made.  Declared in database.py::_MIGRATIONS too -- a new
    #: TABLE self-creates, a new COLUMN does not.
    outcome         = Column(String(16), nullable=True)
    severity        = Column(String(20), default="warning")
    metric_value    = Column(Float, nullable=True)
    threshold_value = Column(Float, nullable=True)
    details         = Column(JSON, nullable=True)
    execution_ms    = Column(Integer, nullable=True)
    checked_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    acknowledged    = Column(Boolean, default=False)
    acknowledged_by = Column(String(100), nullable=True)
    acknowledged_at = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "rule_id": self.rule_id, "passed": self.passed,
            "outcome": self.outcome,
            "severity": self.severity, "metric_value": self.metric_value,
            "threshold_value": self.threshold_value, "details": self.details or {},
            "execution_ms": self.execution_ms,
            "checked_at": self.checked_at.isoformat() if self.checked_at else None,
            "acknowledged": self.acknowledged, "acknowledged_by": self.acknowledged_by,
            "acknowledged_at": self.acknowledged_at.isoformat() if self.acknowledged_at else None,
        }


class UserPreference(Base):
    """Per-user key-value preferences (Phase 100: onboarding, UI settings)."""
    __tablename__ = "user_preferences"

    id         = Column(Integer, primary_key=True, autoincrement=True)
    user_id    = Column(String(100), nullable=False, index=True)
    pref_key   = Column(String(200), nullable=False)
    pref_value = Column(Text, nullable=True)
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                        onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        UniqueConstraint("user_id", "pref_key", name="uq_user_pref"),
        Index("ix_user_pref_user_key", "user_id", "pref_key"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "user_id": self.user_id,
            "pref_key": self.pref_key,
            "pref_value": self.pref_value,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class SuperAdmin(Base):
    """Phase 107-D: Break-glass admin account stored in SQLite.

    Works even when ``auth.type == "ad"`` and AD is unavailable. Bootstrapped
    via the ``python -m querystudio super-admin create`` CLI command. Auth
    flow checks this table FIRST, before falling through to none/local/ad.
    """
    __tablename__ = "super_admins"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    username      = Column(String(100), unique=True, nullable=False, index=True)
    password_hash = Column(String(200), nullable=False)  # PBKDF2-SHA256 from ad_auth.hash_password
    is_active     = Column(Boolean, default=True, nullable=False)
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    created_by    = Column(String(100), nullable=True)
    last_login_at = Column(DateTime, nullable=True)
    notes         = Column(Text, nullable=True)

    def to_dict(self, include_hash: bool = False) -> Dict[str, Any]:
        out = {
            "id": self.id,
            "username": self.username,
            "is_active": self.is_active,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "created_by": self.created_by,
            "last_login_at": self.last_login_at.isoformat() if self.last_login_at else None,
            "notes": self.notes,
        }
        if include_hash:
            out["password_hash"] = self.password_hash
        return out


class AgentDecisionLog(Base):
    """Phase 120: Audit trail for self-healing agent decisions."""
    __tablename__ = "agent_decisions"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    agent_name    = Column(String(50), nullable=False, index=True)
    event_type    = Column(String(50), nullable=False, index=True)
    execution_id  = Column(String(100), nullable=True, index=True)
    action        = Column(String(30), nullable=False)       # retry_with_fix, notify_user, etc.
    reason        = Column(Text, nullable=False)
    fix_applied   = Column(String(50), nullable=True)
    confidence    = Column(Float, default=1.0)
    success       = Column(Boolean, nullable=True)           # null=pending, True/False=outcome
    metadata_json = Column(Text, nullable=True)
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    completed_at  = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        import json as _json
        return {
            "id": self.id,
            "agent_name": self.agent_name,
            "event_type": self.event_type,
            "execution_id": self.execution_id,
            "action": self.action,
            "reason": self.reason,
            "fix_applied": self.fix_applied,
            "confidence": self.confidence,
            "success": self.success,
            "metadata": _json.loads(self.metadata_json) if self.metadata_json else {},
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }


# ── Phase 127 — ETL Pipeline Models ──────────────────────────────────────────

class EtlPipelineConfig(Base):
    """Configuration for an ETL pipeline (S3 → Spark/DuckDB transform → S3)."""
    __tablename__ = "etl_pipeline_configs"

    id                      = Column(Integer, primary_key=True, index=True)
    name                    = Column(String(255), nullable=False, unique=True, index=True)
    description             = Column(Text, nullable=True)
    is_active               = Column(Boolean, default=True)

    # Source
    source_connection_id    = Column(Integer, nullable=False, index=True)
    source_s3_prefix        = Column(String(1000), nullable=False)
    source_file_pattern     = Column(String(255), nullable=True)

    # Destination
    dest_s3_bucket          = Column(String(255), nullable=False)
    dest_s3_prefix          = Column(String(1000), nullable=False)
    dest_connection_id      = Column(Integer, nullable=True, index=True)
    dest_partition_columns  = Column(JSON, nullable=True)

    # Transform rules (JSON): {select, where, dedup, cast, custom_sql}
    transform_rules         = Column(JSON, nullable=True)

    # Processing mode: overwrite | append | merge | watermark
    processing_mode         = Column(String(20), default="overwrite")
    merge_key_columns       = Column(JSON, nullable=True)
    watermark_column        = Column(String(255), nullable=True)
    last_watermark_value    = Column(String(255), nullable=True)

    # Execution backend: auto | native | spark_submit | airflow
    execution_backend       = Column(String(20), default="auto")
    fallback_backend        = Column(String(20), nullable=True)
    size_thresholds         = Column(JSON, nullable=True)
    native_duckdb_memory_limit = Column(String(20), nullable=True)

    # Spark resources
    spark_driver_memory     = Column(String(20), nullable=True)
    spark_executor_memory   = Column(String(20), nullable=True)
    spark_executor_cores    = Column(Integer, nullable=True)
    spark_num_executors     = Column(Integer, nullable=True)
    spark_extra_conf        = Column(JSON, nullable=True)

    # Trigger: schedule | kafka | s3_sensor
    trigger_type            = Column(String(20), default="schedule")
    trigger_config          = Column(JSON, nullable=True)

    # Airflow
    airflow_dag_id          = Column(String(255), nullable=True)
    airflow_pool            = Column(String(100), nullable=True)

    # Dependencies — Phase 132-H: multi-parent trigger support
    depends_on_pipeline_id  = Column(Integer, nullable=True, index=True)
    depends_on_pipeline_ids = Column(JSON, nullable=True)  # List[int] for multi-parent
    trigger_mode            = Column(String(10), default="any")  # "any" or "all"
    dependency_wait_timeout_seconds = Column(Integer, default=3600)

    # SLA
    sla_deadline_time       = Column(String(10), nullable=True)
    sla_notify_emails       = Column(Text, nullable=True)
    sla_notify_webhook      = Column(Text, nullable=True)

    # Retry
    max_retries             = Column(Integer, default=3)
    retry_delay_seconds     = Column(Integer, default=120)

    # Status tracking
    last_execution_id       = Column(Integer, nullable=True)
    run_count               = Column(Integer, default=0)
    last_run_at             = Column(DateTime, nullable=True)
    last_row_count          = Column(BigInteger, nullable=True)
    estimated_row_count     = Column(BigInteger, nullable=True)
    apscheduler_job_id      = Column(String(100), nullable=True, unique=True)

    # Metadata
    created_by              = Column(String(100), nullable=True)
    created_at              = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at              = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                                     onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "is_active": self.is_active,
            "source_connection_id": self.source_connection_id,
            "source_s3_prefix": self.source_s3_prefix,
            "source_file_pattern": self.source_file_pattern,
            "dest_s3_bucket": self.dest_s3_bucket,
            "dest_s3_prefix": self.dest_s3_prefix,
            "dest_connection_id": self.dest_connection_id,
            "dest_partition_columns": self.dest_partition_columns,
            "transform_rules": self.transform_rules,
            "processing_mode": self.processing_mode,
            "merge_key_columns": self.merge_key_columns,
            "watermark_column": self.watermark_column,
            "last_watermark_value": self.last_watermark_value,
            "execution_backend": self.execution_backend,
            "fallback_backend": self.fallback_backend,
            "size_thresholds": self.size_thresholds,
            "native_duckdb_memory_limit": self.native_duckdb_memory_limit,
            "spark_driver_memory": self.spark_driver_memory,
            "spark_executor_memory": self.spark_executor_memory,
            "spark_executor_cores": self.spark_executor_cores,
            "spark_num_executors": self.spark_num_executors,
            "spark_extra_conf": self.spark_extra_conf,
            "trigger_type": self.trigger_type,
            "trigger_config": self.trigger_config,
            "airflow_dag_id": self.airflow_dag_id,
            "airflow_pool": self.airflow_pool,
            "depends_on_pipeline_id": self.depends_on_pipeline_id,
            "depends_on_pipeline_ids": self.depends_on_pipeline_ids,
            "trigger_mode": self.trigger_mode,
            "dependency_wait_timeout_seconds": self.dependency_wait_timeout_seconds,
            "sla_deadline_time": self.sla_deadline_time,
            "sla_notify_emails": self.sla_notify_emails,
            "sla_notify_webhook": self.sla_notify_webhook,
            "max_retries": self.max_retries,
            "retry_delay_seconds": self.retry_delay_seconds,
            "last_execution_id": self.last_execution_id,
            "run_count": self.run_count,
            "last_run_at": self.last_run_at.isoformat() if self.last_run_at else None,
            "last_row_count": self.last_row_count,
            "estimated_row_count": self.estimated_row_count,
            "apscheduler_job_id": self.apscheduler_job_id,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class EtlPipelineExecution(Base):
    """Execution history for an ETL pipeline run."""
    __tablename__ = "etl_pipeline_executions"

    id                    = Column(Integer, primary_key=True, index=True)
    pipeline_id           = Column(Integer, nullable=False, index=True)
    execution_id          = Column(String(100), unique=True, nullable=False, index=True)
    status                = Column(String(30), default="pending")
    trigger_type          = Column(String(20), nullable=False)
    triggered_by          = Column(String(100), nullable=True)

    # Execution backend used
    execution_backend_used = Column(String(20), nullable=True)

    # Airflow / Spark tracking
    airflow_dag_run_id    = Column(String(200), nullable=True)
    airflow_dag_id        = Column(String(255), nullable=True)
    spark_app_id          = Column(String(200), nullable=True)

    # Timing
    started_at            = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    spark_started_at      = Column(DateTime, nullable=True)
    completed_at          = Column(DateTime, nullable=True)
    duration_seconds      = Column(Float, nullable=True)

    # SLA
    sla_breached          = Column(Boolean, default=False)
    sla_deadline          = Column(DateTime, nullable=True)

    # Results
    input_row_count       = Column(BigInteger, nullable=True)
    output_row_count      = Column(BigInteger, nullable=True)
    output_file_count     = Column(Integer, nullable=True)
    output_size_bytes     = Column(BigInteger, nullable=True)
    output_path           = Column(String(1000), nullable=True)
    processing_mode_used  = Column(String(20), nullable=True)
    watermark_value_after = Column(String(255), nullable=True)

    # Error / Dead letter
    error_message         = Column(Text, nullable=True)
    error_stage           = Column(String(50), nullable=True)
    retry_count           = Column(Integer, default=0)
    bad_records_path      = Column(String(1000), nullable=True)

    # Worker claim (thundering herd prevention)
    claimed_by            = Column(String(200), nullable=True)
    claimed_at            = Column(DateTime, nullable=True)

    # Lineage
    source_s3_paths       = Column(JSON, nullable=True)
    dest_s3_paths         = Column(JSON, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "pipeline_id": self.pipeline_id,
            "execution_id": self.execution_id,
            "status": self.status,
            "trigger_type": self.trigger_type,
            "triggered_by": self.triggered_by,
            "execution_backend_used": self.execution_backend_used,
            "airflow_dag_run_id": self.airflow_dag_run_id,
            "airflow_dag_id": self.airflow_dag_id,
            "spark_app_id": self.spark_app_id,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "spark_started_at": self.spark_started_at.isoformat() if self.spark_started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "duration_seconds": self.duration_seconds,
            "sla_breached": self.sla_breached,
            "sla_deadline": self.sla_deadline.isoformat() if self.sla_deadline else None,
            "input_row_count": self.input_row_count,
            "output_row_count": self.output_row_count,
            "output_file_count": self.output_file_count,
            "output_size_bytes": self.output_size_bytes,
            "output_path": self.output_path,
            "processing_mode_used": self.processing_mode_used,
            "watermark_value_after": self.watermark_value_after,
            "error_message": self.error_message,
            "error_stage": self.error_stage,
            "retry_count": self.retry_count,
            "bad_records_path": self.bad_records_path,
            "claimed_by": self.claimed_by,
            "claimed_at": self.claimed_at.isoformat() if self.claimed_at else None,
            "source_s3_paths": self.source_s3_paths,
            "dest_s3_paths": self.dest_s3_paths,
        }


# ── Spark Connect — session audit ────────────────────────────────────────────

class SparkConnectSession(Base):
    """Audit record for a per-user Spark Connect gRPC session.

    One row per session lifetime.  Written at creation; updated at close.
    The in-memory session pool lives in spark_connect_session_manager.py;
    this table is for admin visibility and idle-eviction auditing only.
    """
    __tablename__ = "spark_connect_sessions"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    session_key     = Column(String(128), nullable=False, unique=True, index=True)
    username        = Column(String(100), nullable=False, index=True)
    connection_id   = Column(Integer, nullable=True, index=True)
    server_url      = Column(String(500), nullable=False)

    # Lifecycle
    status          = Column(String(20), nullable=False, default="active")  # active | closed | evicted
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    last_used_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    closed_at       = Column(DateTime, nullable=True)

    # Stats — updated on close
    queries_executed = Column(Integer, default=0)
    total_rows_returned = Column(Integer, default=0)
    close_reason    = Column(String(50), nullable=True)  # idle_evict | cred_rotation | quota | error | shutdown

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "session_key": self.session_key,
            "username": self.username,
            "connection_id": self.connection_id,
            "server_url": self.server_url,
            "status": self.status,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "last_used_at": self.last_used_at.isoformat() if self.last_used_at else None,
            "closed_at": self.closed_at.isoformat() if self.closed_at else None,
            "queries_executed": self.queries_executed,
            "total_rows_returned": self.total_rows_returned,
            "close_reason": self.close_reason,
        }


# ─────────────────────────────────────────────────────────────────────────────
# BF-352 — Agent configuration + rules in DB.
#
# Why DB-backed: file-based config (config.json) requires a deploy or pod
# restart to change.  Self-healing agents need to be tunable at runtime
# from the admin UI, and the rules they evaluate (regex patterns,
# thresholds, descriptions) must be editable without a code change.
#
# AgentConfig: simple key→JSON-value store, scoped by ``key`` (one row per
# setting).  PUT /api/admin/agents/config writes here; the engine reads
# from here (with config.json fallback) at every classification call so
# changes take effect immediately.
#
# AgentRule: unified table for both QUERY_FIX_RULES + DQ_RULES with a
# ``kind`` discriminator.  Seeded from the Python defaults the first time
# the table is empty so out-of-the-box behaviour matches the historical
# in-code list, but admins can disable / edit / add rows from there on.
# ─────────────────────────────────────────────────────────────────────────────


class AgentConfig(Base):
    """BF-352: per-key agent setting (one row per logical setting)."""
    __tablename__ = "agent_config"

    id          = Column(Integer, primary_key=True, autoincrement=True)
    key         = Column(String(120), nullable=False, unique=True, index=True)
    value_json  = Column(Text, nullable=False)            # JSON-serialized value
    description = Column(String(500), nullable=True)
    updated_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                          onupdate=lambda: datetime.now(timezone.utc))
    updated_by  = Column(String(80), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        try:
            value = json.loads(self.value_json) if self.value_json else None
        except Exception:
            value = self.value_json
        return {
            "id":          self.id,
            "key":         self.key,
            "value":       value,
            "description": self.description,
            "updated_at":  self.updated_at.isoformat() if self.updated_at else None,
            "updated_by":  self.updated_by,
        }


class AgentRule(Base):
    """BF-352: row-per-rule for QueryFix (regex→strategy) and DQ (metric→action).

    Single table with a ``kind`` discriminator avoids a second migration when
    we add more rule families (column-stats hints, schedule heuristics, etc.).
    Unused columns are NULL for the kind that doesn't need them.
    """
    __tablename__ = "agent_rules"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    kind          = Column(String(20), nullable=False, index=True)   # 'query_fix' | 'dq'
    enabled       = Column(Boolean, default=True, nullable=False, index=True)
    priority      = Column(Integer, default=0, nullable=False)        # lower = checked first
    name          = Column(String(80), nullable=True)                 # human label

    # Common
    description   = Column(String(500), nullable=False)
    severity      = Column(String(20), nullable=True)                 # info|warning|critical
    action        = Column(String(50), nullable=True)                 # alert|notify|none

    # query_fix-only
    pattern       = Column(Text, nullable=True)                       # regex string
    strategy      = Column(String(50), nullable=True)                 # auto-retry strategy
    max_retries   = Column(Integer, nullable=True)

    # dq-only
    metric        = Column(String(60), nullable=True)
    op            = Column(String(4), nullable=True)                  # > < >= <= ==
    threshold     = Column(Float, nullable=True)
    message       = Column(String(300), nullable=True)

    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                            onupdate=lambda: datetime.now(timezone.utc))
    updated_by    = Column(String(80), nullable=True)
    is_seed       = Column(Boolean, default=False, nullable=False)    # marker: from in-code defaults

    __table_args__ = (
        Index("ix_agent_rules_kind_enabled_priority", "kind", "enabled", "priority"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":          self.id,
            "kind":        self.kind,
            "enabled":     bool(self.enabled),
            "priority":    int(self.priority or 0),
            "name":        self.name,
            "description": self.description,
            "severity":    self.severity,
            "action":      self.action,
            "pattern":     self.pattern,
            "strategy":    self.strategy,
            "max_retries": self.max_retries,
            "metric":      self.metric,
            "op":          self.op,
            "threshold":   self.threshold,
            "message":     self.message,
            "is_seed":     bool(self.is_seed),
            "created_at":  self.created_at.isoformat() if self.created_at else None,
            "updated_at":  self.updated_at.isoformat() if self.updated_at else None,
            "updated_by":  self.updated_by,
        }


###############################################################################
# Phase 142 — Server-side draft persistence (enterprise context preservation)
###############################################################################

class UserDraft(Base):
    """Per-user JSON draft store — replaces scattered localStorage in the
    frontend.  Survives browser refresh, cache clear, laptop switch.

    Key naming convention (frontend uses these): ``<feature>.<id>``::

        cqb.sql.<connection_id>          — CQB raw SQL draft
        sqlpage.primary.<connection_id>  — SqlQueryPage primary SQL
        sqlpage.secondary.<connection_id>— SqlQueryPage secondary SQL
        bqb.<connection_id>              — BusinessQueryBuilder full state
        dashboard.<dashboard_id>         — DashboardEditor layout
        report.<report_id>               — BusinessReportEditor config
        ...

    Auto-cleanup runs daily via scheduler — drafts older than
    ``user_drafts.retention_days`` are deleted.  Per-user total size
    capped at ``user_drafts.per_user_max_mb`` to prevent abuse.
    """
    __tablename__ = "user_drafts"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    username      = Column(String(100), nullable=False, index=True)
    draft_key     = Column(String(200), nullable=False)
    content_json  = Column(JSON, nullable=False, default=dict)
    size_bytes    = Column(BigInteger, nullable=False, default=0)
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                            onupdate=lambda: datetime.now(timezone.utc),
                            index=True)

    __table_args__ = (
        UniqueConstraint("username", "draft_key", name="uq_user_drafts_user_key"),
        Index("ix_user_drafts_user_updated", "username", "updated_at"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "username":     self.username,
            "draft_key":    self.draft_key,
            "content":      self.content_json,
            "size_bytes":   int(self.size_bytes or 0),
            "created_at":   self.created_at.isoformat() if self.created_at else None,
            "updated_at":   self.updated_at.isoformat() if self.updated_at else None,
        }

    def to_summary(self) -> Dict[str, Any]:
        """Lightweight summary — omits content (for list endpoints)."""
        return {
            "draft_key":    self.draft_key,
            "size_bytes":   int(self.size_bytes or 0),
            "updated_at":   self.updated_at.isoformat() if self.updated_at else None,
        }


###############################################################################
# Phase 141 — Row & Column Security (Lake Formation-equivalent)
###############################################################################

class RowLevelPolicy(Base):
    """Row-level security policy applied as a WHERE filter during SQL rewrite.

    A policy matches a table by ``table_pattern`` (exact name, glob, or
    qualified ``connection.schema.table``).  ``filter_sql`` is an arbitrary
    SQL boolean expression that may reference ``${user.username}``,
    ``${user.role}``, ``${user.groups}``, or any ``${user.<attr>}`` resolved
    from the principal context.

    Bindings (see PolicyBinding) decide WHICH principals the policy applies to;
    a policy with no binding rows is effectively inactive.

    ``enforcement`` controls how the policy is realised:
      * ``rewrite`` — sqlglot AST rewrite at query time (default)
      * ``view``    — materialise CREATE VIEW <t>_secured at session start
      * ``native_lf``— delegate to AWS Lake Formation (engine-side filtering)
      * ``audit_only``— log what would be filtered, do not actually filter
    """
    __tablename__ = "row_level_policies"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    name            = Column(String(200), nullable=False, unique=True)
    description     = Column(Text, default="")
    source          = Column(String(40), nullable=False, default="manual")    # manual|lake_formation|ranger|imported
    table_pattern   = Column(String(500), nullable=False, index=True)         # "orders" | "db.*" | "conn1.public.orders"
    connection_id   = Column(Integer, nullable=True, index=True)              # NULL = all connections
    filter_sql      = Column(Text, nullable=False)                            # "region IN (${user.regions})"
    enforcement     = Column(String(20), nullable=False, default="rewrite")
    enabled         = Column(Boolean, default=True, nullable=False)
    priority        = Column(Integer, default=100, nullable=False)            # lower = applied first; AND-combined
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                              onupdate=lambda: datetime.now(timezone.utc))
    created_by      = Column(String(100), nullable=True)
    updated_by      = Column(String(100), nullable=True)
    # External-system identity for sync adapters (LF filter ARN, Ranger policy id, etc.)
    external_id     = Column(String(500), nullable=True, index=True)
    # FB-45 (2026-09-20) -- how this policy COMPOSES with others on the same
    # principal: ``permissive`` (a grant; OR'd with other grants) or
    # ``restrictive`` (a ceiling; AND'd).  NULL means "created before classes
    # existed" and composes as restrictive -- the pre-FB-45 AND semantics --
    # so an upgrade moves nobody's rows.  The startup backfill
    # (RowSecurityMixin._ensure_policy_classes) makes that explicit.  See
    # core/row_security/composition.py.
    policy_class    = Column(String(20), nullable=True)

    __table_args__ = (
        Index("ix_rls_table_conn", "table_pattern", "connection_id"),
        Index("ix_rls_enabled", "enabled"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "name":           self.name,
            "description":    self.description or "",
            "source":         self.source,
            "table_pattern":  self.table_pattern,
            "connection_id":  self.connection_id,
            "filter_sql":     self.filter_sql,
            "enforcement":    self.enforcement,
            "enabled":        bool(self.enabled),
            "priority":       int(self.priority or 100),
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "updated_at":     self.updated_at.isoformat() if self.updated_at else None,
            "created_by":     self.created_by,
            "updated_by":     self.updated_by,
            "external_id":    self.external_id,
            "policy_class":   self.policy_class,
        }


class ColumnPolicy(Base):
    """Column-level policy — controls which columns are visible (include/exclude)
    or how column values are masked.

    Three modes:
      * ``include`` — ``columns`` is an allowlist; everything else is dropped
      * ``exclude`` — ``columns`` is a denylist; listed columns are dropped
      * ``mask``    — for each column in ``columns``, replace value with
                       ``mask_expr`` (e.g. ``REGEXP_REPLACE(${col}, '@.*', '@***')``)
    """
    __tablename__ = "column_policies"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    name            = Column(String(200), nullable=False, unique=True)
    description     = Column(Text, default="")
    source          = Column(String(40), nullable=False, default="manual")
    table_pattern   = Column(String(500), nullable=False, index=True)
    connection_id   = Column(Integer, nullable=True, index=True)
    mode            = Column(String(10), nullable=False, default="exclude")   # include|exclude|mask
    columns         = Column(JSON, nullable=False, default=list)              # ["email","ssn"]
    mask_expr       = Column(Text, nullable=True)                              # used when mode='mask'
    enforcement     = Column(String(20), nullable=False, default="rewrite")
    enabled         = Column(Boolean, default=True, nullable=False)
    priority        = Column(Integer, default=100, nullable=False)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                              onupdate=lambda: datetime.now(timezone.utc))
    created_by      = Column(String(100), nullable=True)
    updated_by      = Column(String(100), nullable=True)
    external_id     = Column(String(500), nullable=True, index=True)

    __table_args__ = (
        Index("ix_colpol_table_conn", "table_pattern", "connection_id"),
        Index("ix_colpol_enabled", "enabled"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "name":           self.name,
            "description":    self.description or "",
            "source":         self.source,
            "table_pattern":  self.table_pattern,
            "connection_id":  self.connection_id,
            "mode":           self.mode,
            "columns":        self.columns or [],
            "mask_expr":      self.mask_expr,
            "enforcement":    self.enforcement,
            "enabled":        bool(self.enabled),
            "priority":       int(self.priority or 100),
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "updated_at":     self.updated_at.isoformat() if self.updated_at else None,
            "created_by":     self.created_by,
            "updated_by":     self.updated_by,
            "external_id":    self.external_id,
        }


class PolicyBinding(Base):
    """Binds a row or column policy to a principal (user / role / group / system_account).

    A policy with no binding rows is inactive — bindings are the
    'WHO does this policy apply to?' decision.  ``priority`` controls
    AND-combining order (lower applied first).
    """
    __tablename__ = "policy_bindings"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    policy_kind     = Column(String(10), nullable=False, index=True)          # row|column
    policy_id       = Column(Integer, nullable=False, index=True)
    principal_type  = Column(String(20), nullable=False)                       # user|role|group|system_account|all
    principal_id    = Column(String(200), nullable=False, index=True)         # "alice" | "analyst" | "finance_group" | "*"
    priority        = Column(Integer, default=100, nullable=False)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    created_by      = Column(String(100), nullable=True)

    __table_args__ = (
        UniqueConstraint("policy_kind", "policy_id", "principal_type", "principal_id",
                          name="uq_polbind_unique"),
        Index("ix_polbind_principal", "principal_type", "principal_id"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "policy_kind":    self.policy_kind,
            "policy_id":      self.policy_id,
            "principal_type": self.principal_type,
            "principal_id":   self.principal_id,
            "priority":       int(self.priority or 100),
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "created_by":     self.created_by,
        }


class RowSecurityAuditLog(Base):
    """Audit trail of row-security rewrite decisions.

    One row per (query, table) where a policy was applied OR would have been
    applied (audit_only).  Bounded retention via daily cleanup scheduler.
    """
    __tablename__ = "row_security_audit"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    ts              = Column(DateTime, default=lambda: datetime.now(timezone.utc), index=True)
    username        = Column(String(100), nullable=False, index=True)
    role            = Column(String(40), nullable=True)
    table_ref       = Column(String(500), nullable=False)
    connection_id   = Column(Integer, nullable=True)
    row_policies    = Column(JSON, nullable=False, default=list)              # [{"id":1,"name":"EU-only","filter":"..."},...]
    column_policies = Column(JSON, nullable=False, default=list)
    mode            = Column(String(20), nullable=False)                       # rewrite|audit_only|view|native_lf
    sql_before      = Column(Text, nullable=True)                              # original SQL (truncated)
    sql_after       = Column(Text, nullable=True)                              # rewritten SQL (truncated)
    request_id      = Column(String(64), nullable=True, index=True)            # ties to execution_id when known
    notes           = Column(Text, nullable=True)
    # FB-45 -- the row_security.policy_composition mode in force when this
    # decision was made, so a past result can be explained after the fact.
    composition     = Column(String(20), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":              self.id,
            "ts":              self.ts.isoformat() if self.ts else None,
            "username":        self.username,
            "role":            self.role,
            "table_ref":       self.table_ref,
            "connection_id":   self.connection_id,
            "row_policies":    self.row_policies or [],
            "column_policies": self.column_policies or [],
            "mode":            self.mode,
            "sql_before":      self.sql_before,
            "sql_after":       self.sql_after,
            "request_id":      self.request_id,
            "notes":           self.notes,
            "composition":     self.composition,
        }


###############################################################################
# Phase 130 hotfix-13 — Fleet worker health (per-pod heartbeats)
###############################################################################

class WorkerHealthState(Base):
    """Per-pod heartbeat for the feed queue worker.

    Each pod that polls the feed_runs queue writes its row every tick;
    the failover agent reads ALL rows so the multi-pod fleet health is
    aggregated (native is healthy iff AT LEAST ONE pod ticked recently).

    Rows are GC'd by the cleanup job after a few hours of staleness so
    dead pods don't keep claiming "native is healthy" forever.
    """
    __tablename__ = "worker_health_state"

    pod_id            = Column(String(150), primary_key=True)
    # BF-513 (2026-05-28): same auto-migrate fix as PublishedView.credential_mode
    # — Python ``default=`` does NOT render in ALTER TABLE DDL, so SQLite would
    # silently skip ADD COLUMN with NOT NULL + no DEFAULT.  ``CURRENT_TIMESTAMP``
    # is portable across SQLite + PostgreSQL.
    last_tick_at      = Column(DateTime, nullable=False,
                                default=lambda: datetime.now(timezone.utc),
                                onupdate=lambda: datetime.now(timezone.utc),
                                server_default=sa_text("CURRENT_TIMESTAMP"))
    last_tick_result  = Column(JSON, nullable=True)
    inflight_count    = Column(Integer, default=0)
    shard             = Column(String(20), nullable=True)  # e.g. "0/4"
    updated_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                                onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "pod_id":           self.pod_id,
            "last_tick_at":     self.last_tick_at.isoformat() if self.last_tick_at else None,
            "last_tick_result": self.last_tick_result or {},
            "inflight_count":   self.inflight_count or 0,
            "shard":            self.shard,
            "updated_at":       self.updated_at.isoformat() if self.updated_at else None,
        }


class DuckDBSubprocessCrash(Base):
    """BF-541 (2026-05-28): persisted subprocess crash events.

    The circuit breaker used to log subprocess crashes and trip after
    3 failures — but operators only saw the log lines, with no
    dashboard or 24-hour aggregate.  Persisting each event lets the
    admin UI render "10 crashes in the last hour, all OOM on pod-x"
    so the operator can size the pod correctly instead of debugging
    blindly.

    Rows are ephemeral (a background job will trim > N days old).
    Schema is small + columnar-friendly so a year of crashes still
    queries fast.
    """
    __tablename__ = "duckdb_subprocess_crashes"

    id              = Column(Integer, primary_key=True, index=True)
    execution_id    = Column(String(100), nullable=True, index=True)
    pod_id          = Column(String(150), nullable=True, index=True)
    connection_id   = Column(Integer, nullable=True, index=True)
    occurred_at     = Column(DateTime, nullable=False,
                              default=lambda: datetime.now(timezone.utc),
                              server_default=sa_text("CURRENT_TIMESTAMP"),
                              index=True)
    returncode      = Column(Integer, nullable=True)
    # Decoded cause string from _decode_subprocess_exit (e.g. "SIGKILL
    # (-9) — most likely OOM-killed by the cgroup.").  Human-readable
    # so dashboards don't need lookup tables.
    cause           = Column(String(500), nullable=True)
    stderr_tail     = Column(Text, nullable=True)
    wall_seconds    = Column(Float, nullable=True)
    # JSON payload for extension hooks: query bytes, memory_limit at
    # spawn, spill quota, etc.  Optional — keeps the model lean.
    extra           = Column(JSON, nullable=True)

    __table_args__ = (
        Index("ix_ddb_crash_pod_time", "pod_id", "occurred_at"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "execution_id":   self.execution_id,
            "pod_id":         self.pod_id,
            "connection_id":  self.connection_id,
            "occurred_at":    self.occurred_at.isoformat() if self.occurred_at else None,
            "returncode":     self.returncode,
            "cause":          self.cause,
            "stderr_tail":    (self.stderr_tail or "")[:2000],
            "wall_seconds":   self.wall_seconds,
            "extra":          self.extra or {},
        }


###############################################################################
# Phase 130 hotfix-13 — Generic admin-tunable runtime settings
###############################################################################

class SystemSetting(Base):
    """Key/value store for admin-tunable runtime configuration.

    Use sparingly — only for values an operator must be able to flip
    without a config-file edit + pod restart.  First user: feed
    generation backend override + failover thresholds.

    ``value`` is JSON-encoded so we can store strings, ints, bools,
    or small dicts without per-key table design.  ``updated_by`` +
    ``updated_at`` give an audit trail; deeper change history goes
    in ``audit_log`` as usual.
    """
    __tablename__ = "system_settings"

    key         = Column(String(128), primary_key=True)
    value       = Column(JSON, nullable=False)
    description = Column(String(500), nullable=True)
    updated_by  = Column(String(100), nullable=True)
    updated_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                          onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "key":         self.key,
            "value":       self.value,
            "description": self.description,
            "updated_by":  self.updated_by,
            "updated_at":  self.updated_at.isoformat() if self.updated_at else None,
        }


###############################################################################
# Phase 132 — Generic DataFlow Engine (NEW capability, totally additive)
#
# Six tables that model a generic dataflow execution platform.  Existing
# feed_gen / reports / BQB / CQB code is UNTOUCHED.  DataFlows are versioned
# (draft → active → archived), execute as a DAG of stages, support resume +
# rerun-single-stage, and feed a dedicated cron scheduler.
#
# Naming:
#   - dataflow_stage_types : catalogue of registered stage classes (populated
#                            by class-scanner at startup, like the agents
#                            registry pattern).
#   - dataflows            : dataflow definition rows, versioned by (name, version).
#   - dataflow_stages      : DAG nodes belonging to one dataflow.
#   - dataflow_runs        : per-execution rows.  A "feed" becomes a row here
#                            once Phase 1 of the migration is opted in.
#   - dataflow_run_stages  : per-execution per-stage status + outputs JSON.
#   - dataflow_schedules   : table-driven cron, polled by the dedicated
#                            DataFlowScheduler service.
###############################################################################


class DataFlowStageType(Base):
    """Registry row for one BaseStage subclass.

    Populated at startup by ``StageTypeRegistry.sync_to_db()`` so the admin
    UI can list available stage types without importing Python code.
    """
    __tablename__ = "dataflow_stage_types"

    name             = Column(String(80), primary_key=True)
    display_name     = Column(String(160), nullable=True)   # human-readable UI label
    category         = Column(String(40), nullable=False, index=True)   # source | transform | sink | control | quality
    class_path       = Column(String(255), nullable=False)
    description      = Column(Text, nullable=True)
    config_schema    = Column(JSON, nullable=True)
    inputs_schema    = Column(JSON, nullable=True)
    outputs_schema   = Column(JSON, nullable=True)
    is_control_flow  = Column(Boolean, default=False)
    is_active        = Column(Boolean, default=True)
    created_at       = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at       = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                              onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name":            self.name,
            "display_name":    self.display_name or (self.name or "").replace("_", " ").title(),
            "category":        self.category,
            "class_path":      self.class_path,
            "description":     self.description,
            "config_schema":   self.config_schema,
            "inputs_schema":   self.inputs_schema,
            "outputs_schema":  self.outputs_schema,
            "is_control_flow": bool(self.is_control_flow),
            "is_active":       bool(self.is_active),
            "created_at":      self.created_at.isoformat() if self.created_at else None,
            "updated_at":      self.updated_at.isoformat() if self.updated_at else None,
        }


class DataFlowCustomStageType(Base):
    """Admin-registered ETL bridge stage — DB-driven, no Python required.

    Phase 132.14 — letting admins create new stage types via the UI by
    pointing at an existing ETL step class.  At startup the registry
    queries this table and dynamically creates ``_EtlBridgeBase``
    subclasses for each row, so the new stages appear in the catalogue
    + Simple Job picker + DAG canvas without a code change or restart.

    Use cases: bridging a new ETL/steps/* class the user adds; reusing
    the same Python class with different default configs (e.g.
    ``oracle_to_s3_prod`` vs ``oracle_to_s3_dev``).
    """
    __tablename__ = "dataflow_custom_stage_types"

    id            = Column(Integer, primary_key=True, index=True)
    name          = Column(String(80), unique=True, nullable=False, index=True)
    category      = Column(String(40), nullable=False)
    description   = Column(Text, nullable=True)
    # The underlying ETL class to bridge to.  Both fields are required —
    # the registry uses them to importlib.import_module(etl_module) and
    # getattr(mod, etl_class) at startup.
    etl_module    = Column(String(255), nullable=False)
    etl_class     = Column(String(120), nullable=False)
    config_schema = Column(JSON, nullable=True)
    idempotency   = Column(String(20), default="configured")
    is_active     = Column(Boolean, default=True, index=True)
    created_by    = Column(String(100), nullable=True)
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                            onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":            self.id,
            "name":          self.name,
            "category":      self.category,
            "description":   self.description,
            "etl_module":    self.etl_module,
            "etl_class":     self.etl_class,
            "config_schema": self.config_schema or {},
            "idempotency":   self.idempotency,
            "is_active":     bool(self.is_active),
            "created_by":    self.created_by,
            "created_at":    self.created_at.isoformat() if self.created_at else None,
            "updated_at":    self.updated_at.isoformat() if self.updated_at else None,
        }


class DataFlow(Base):
    """A versioned dataflow definition.

    Each (name, version) pair is immutable once promoted to ``active``.
    Editing an active dataflow creates a new draft version; in-flight runs
    finish on their started version.
    """
    __tablename__ = "dataflows"

    id              = Column(Integer, primary_key=True, index=True)
    name            = Column(String(120), nullable=False, index=True)
    version         = Column(Integer, nullable=False, default=1)
    status          = Column(String(20), nullable=False, default="draft", index=True)   # draft | active | archived
    description     = Column(Text, nullable=True)
    trigger_type    = Column(String(40), default="manual")                              # manual | cron | event | upstream
    trigger_config  = Column(JSON, nullable=True)
    default_context = Column(JSON, nullable=True)
    # ── Template flags (DB-driven catalogue) ─────────────────────────────
    # Phase 132.14 — templates are no longer a hardcoded Python dict.
    # A DataFlow row with is_template=True shows up in the "From Template"
    # picker + the Simple Job builder's job-type catalogue.  Job types are
    # derived from template_category (grouped on the UI).  Admins create /
    # edit / archive templates through the same UI as any other DataFlow.
    is_template       = Column(Boolean, default=False, index=True)
    template_category = Column(String(60), nullable=True, index=True)
    template_label    = Column(String(160), nullable=True)
    # ── Phase 132.20 — pause + SLA + ops attributes ──────────────────────
    # is_paused: soft-pause that suppresses scheduler firing AND blocks
    #            new manual runs.  Separate from `status='archived'`, which
    #            removes the DataFlow from the catalogue entirely.
    # sla_seconds: optional wall-clock budget per run.  If the run exceeds
    #            it, the run is flagged sla_breached=True (not cancelled).
    is_paused       = Column(Boolean, default=False, index=True)
    sla_seconds     = Column(Integer, nullable=True)
    # ── Phase 132.26 — workspace scoping ─────────────────────────────────
    # workspace_id is NULL for global / unscoped DataFlows (visible to
    # everyone — matches the Connection.workspace_id NULL semantic).
    # When set, list endpoints filter to workspaces the requester
    # belongs to.
    workspace_id    = Column(Integer, nullable=True, index=True)
    # ── Phase 132.21 ────────────────────────────────────────────────────
    # tags: list[str] used to group DataFlows on the Ops Grid / notification
    #       policy scoping.  Example: ["sap", "monthly", "prod-critical"].
    # depends_on_previous: when True, the scheduler refuses to start a new
    #       run until the most recent run for this DataFlow has succeeded.
    #       Avoids overlapping monthly SAP runs that step on each other.
    tags                 = Column(JSON, nullable=True)
    depends_on_previous  = Column(Boolean, default=False)
    # ── Phase 132.25 ────────────────────────────────────────────────────
    # max_run_seconds: HARD cutoff (vs. sla_seconds which is a soft flag).
    #     When set, the dispatcher cancels the run once wall-clock exceeds
    #     this value.  Use case: stuck SAP downloads that should never
    #     exceed N hours regardless of partial progress.
    max_run_seconds      = Column(Integer, nullable=True)
    created_by      = Column(String(100), nullable=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                              onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        UniqueConstraint("name", "version", name="uq_dataflows_name_version"),
        Index("ix_dataflows_name_status", "name", "status"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":              self.id,
            "name":            self.name,
            "version":         self.version,
            "status":          self.status,
            "description":     self.description,
            "trigger_type":    self.trigger_type,
            "trigger_config":  self.trigger_config,
            "default_context": self.default_context,
            "is_template":     bool(self.is_template),
            "template_category": self.template_category,
            "template_label":  self.template_label,
            "is_paused":       bool(self.is_paused),
            "sla_seconds":     self.sla_seconds,
            "tags":            self.tags or [],
            "depends_on_previous": bool(self.depends_on_previous),
            "max_run_seconds": self.max_run_seconds,
            "workspace_id":    self.workspace_id,
            "created_by":      self.created_by,
            "created_at":      self.created_at.isoformat() if self.created_at else None,
            "updated_at":      self.updated_at.isoformat() if self.updated_at else None,
        }


class DataFlowStage(Base):
    """One stage (DAG node) belonging to a dataflow definition."""
    __tablename__ = "dataflow_stages"

    id                 = Column(Integer, primary_key=True, index=True)
    dataflow_id        = Column(Integer, nullable=False, index=True)         # FK→dataflows.id
    stage_alias        = Column(String(80), nullable=False)                  # unique-within-dataflow id
    stage_type         = Column(String(80), nullable=False)                  # FK→dataflow_stage_types.name
    seq                = Column(Integer, nullable=False)                     # natural ordering for linear runs
    predecessors       = Column(JSON, nullable=True)                         # list[str stage_alias] — DAG edges
    config             = Column(JSON, nullable=True)                         # stage-type-specific config
    retry_policy       = Column(JSON, nullable=True)                         # {max_attempts, backoff_seconds, retry_on}
    timeout_seconds    = Column(Integer, nullable=True)
    on_failure         = Column(String(20), default="halt")                  # halt | continue | branch_to
    on_failure_target  = Column(String(80), nullable=True)                   # stage_alias when on_failure='branch_to'

    __table_args__ = (
        UniqueConstraint("dataflow_id", "stage_alias", name="uq_dataflow_stages_alias"),
        Index("ix_dataflow_stages_dataflow_seq", "dataflow_id", "seq"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                self.id,
            "dataflow_id":       self.dataflow_id,
            "stage_alias":       self.stage_alias,
            "stage_type":        self.stage_type,
            "seq":               self.seq,
            "predecessors":      self.predecessors or [],
            "config":            self.config or {},
            "retry_policy":      self.retry_policy or {},
            "timeout_seconds":   self.timeout_seconds,
            "on_failure":        self.on_failure,
            "on_failure_target": self.on_failure_target,
        }


class DataFlowRun(Base):
    """One execution instance of a dataflow definition."""
    __tablename__ = "dataflow_runs"

    id                = Column(Integer, primary_key=True, index=True)
    dataflow_id       = Column(Integer, nullable=False, index=True)          # FK→dataflows.id
    dataflow_version  = Column(Integer, nullable=False)                      # snapshot at run start (immutable)
    dataflow_name     = Column(String(120), nullable=False, index=True)      # denormalised for dashboard listing
    status            = Column(String(20), nullable=False, default="pending", index=True)
    # pending | running | succeeded | failed | cancelled | partial
    triggered_by      = Column(String(100), nullable=True)
    # Phase 132.20 — when an admin/scheduler kicks off a run on behalf of
    # someone else, ``triggered_by`` holds the actor (who pressed the
    # button) while ``run_as`` holds the impersonated user used for
    # downstream auth/credential resolution + audit.  If null, the run
    # executes as ``triggered_by``.
    run_as            = Column(String(100), nullable=True, index=True)
    trigger_payload   = Column(JSON, nullable=True)
    context           = Column(JSON, nullable=True)                          # shared param bag, mutated by stages
    outputs           = Column(JSON, nullable=True)                          # final outputs (last stage's outputs)
    error             = Column(Text, nullable=True)
    started_at        = Column(DateTime, nullable=True)
    ended_at          = Column(DateTime, nullable=True)
    duration_seconds  = Column(Float, nullable=True)
    worker_node       = Column(String(120), nullable=True)
    parent_run_id     = Column(Integer, nullable=True, index=True)           # set when triggered by SubWorkflow stage
    # Phase 132.20 — SLA tracking: dispatcher snapshots
    # ``expected_completion_at = started_at + DataFlow.sla_seconds`` at run
    # start and flips ``sla_breached`` if the run exceeds it (run does NOT
    # auto-cancel; the flag drives badges/alerts).
    expected_completion_at = Column(DateTime, nullable=True)
    sla_breached      = Column(Boolean, default=False, index=True)
    created_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index("ix_dataflow_runs_dataflow_started", "dataflow_id", "started_at"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":               self.id,
            "dataflow_id":      self.dataflow_id,
            "dataflow_version": self.dataflow_version,
            "dataflow_name":    self.dataflow_name,
            "status":           self.status,
            "triggered_by":     self.triggered_by,
            "run_as":           self.run_as,
            "trigger_payload":  self.trigger_payload,
            "context":          self.context or {},
            "outputs":          self.outputs or {},
            "error":            self.error,
            "started_at":       self.started_at.isoformat() if self.started_at else None,
            "ended_at":         self.ended_at.isoformat() if self.ended_at else None,
            "duration_seconds": self.duration_seconds,
            "worker_node":      self.worker_node,
            "parent_run_id":    self.parent_run_id,
            "expected_completion_at": self.expected_completion_at.isoformat() if self.expected_completion_at else None,
            "sla_breached":     bool(self.sla_breached),
            "created_at":       self.created_at.isoformat() if self.created_at else None,
        }


class DataFlowRunStage(Base):
    """Per-run per-stage state row.  ``outputs`` JSON powers resume semantics —
    the dispatcher feeds prior stages' outputs into the StageContext so a
    resumed step can read upstream artefacts without re-running them.
    """
    __tablename__ = "dataflow_run_stages"

    id                = Column(Integer, primary_key=True, index=True)
    run_id            = Column(Integer, nullable=False, index=True)          # FK→dataflow_runs.id
    stage_alias       = Column(String(80), nullable=False)
    stage_type        = Column(String(80), nullable=False)
    seq               = Column(Integer, nullable=False)
    status            = Column(String(20), nullable=False, default="not_started")
    # not_started | running | succeeded | failed | skipped | cancelled
    attempts          = Column(Integer, default=0)
    inputs            = Column(JSON, nullable=True)
    outputs           = Column(JSON, nullable=True)
    error             = Column(Text, nullable=True)
    log_lines         = Column(JSON, nullable=True)                          # list[str], captured during execute()
    started_at        = Column(DateTime, nullable=True)
    ended_at          = Column(DateTime, nullable=True)
    duration_seconds  = Column(Float, nullable=True)
    worker_node       = Column(String(120), nullable=True)
    # Phase 132.22 — sensor reschedule: when status='reschedule', the
    # dispatcher will re-pick this row once now() >= next_check_at.
    next_check_at     = Column(DateTime, nullable=True, index=True)

    __table_args__ = (
        UniqueConstraint("run_id", "stage_alias", name="uq_dataflow_run_stages_alias"),
        Index("ix_dataflow_run_stages_run_seq", "run_id", "seq"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":               self.id,
            "run_id":           self.run_id,
            "stage_alias":      self.stage_alias,
            # 2026-09-20 -- consumers that read the step vocabulary's
            # ``stage_name`` (the feed step model spells it so) saw None
            # beside a populated status.  The alias IS the stage's name.
            "stage_name":       self.stage_alias,
            "stage_type":       self.stage_type,
            "seq":              self.seq,
            "status":           self.status,
            "attempts":         self.attempts or 0,
            "inputs":           self.inputs or {},
            "outputs":          self.outputs or {},
            "error":            self.error,
            "log_lines":        self.log_lines or [],
            "started_at":       self.started_at.isoformat() if self.started_at else None,
            "ended_at":         self.ended_at.isoformat() if self.ended_at else None,
            "duration_seconds": self.duration_seconds,
            "worker_node":      self.worker_node,
        }


class DataFlowApprovalRequest(Base):
    """Pending human-in-the-loop approval, written by HumanApprovalStage.

    The stage polls the row until ``status`` flips to ``approved`` or
    ``rejected``.  Admin acts via ``POST /api/dataflows/approvals/{id}/decide``.
    """
    __tablename__ = "dataflow_approval_requests"

    id            = Column(Integer, primary_key=True, index=True)
    run_id        = Column(Integer, nullable=False, index=True)
    stage_alias   = Column(String(80), nullable=False)
    dataflow_name = Column(String(120), nullable=False)
    title         = Column(String(255), nullable=True)
    description   = Column(Text, nullable=True)
    requested_by  = Column(String(100), nullable=True)
    decided_by    = Column(String(100), nullable=True)
    status        = Column(String(20), nullable=False, default="pending", index=True)
    # pending | approved | rejected | expired
    decision_notes = Column(Text, nullable=True)
    payload       = Column(JSON, nullable=True)             # arbitrary stage payload
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    decided_at    = Column(DateTime, nullable=True)
    expires_at    = Column(DateTime, nullable=True)

    __table_args__ = (
        Index("ix_dataflow_approval_run_stage", "run_id", "stage_alias"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "run_id":         self.run_id,
            "stage_alias":    self.stage_alias,
            "dataflow_name":  self.dataflow_name,
            "title":          self.title,
            "description":    self.description,
            "requested_by":   self.requested_by,
            "decided_by":     self.decided_by,
            "status":         self.status,
            "decision_notes": self.decision_notes,
            "payload":        self.payload or {},
            "created_at":     self.created_at.isoformat() if self.created_at else None,
            "decided_at":     self.decided_at.isoformat() if self.decided_at else None,
            "expires_at":     self.expires_at.isoformat() if self.expires_at else None,
        }


class DataFlowSchedule(Base):
    """Table-driven cron trigger for a dataflow.

    The dedicated ``DataFlowScheduler`` service polls this table every
    ``scheduler.workflow_poll_seconds`` (default 30 s) and starts a run
    whenever ``next_run_at <= now()``.  Independent from APScheduler so
    dataflows can be paused / resumed without touching APScheduler state.
    """
    __tablename__ = "dataflow_schedules"

    id                = Column(Integer, primary_key=True, index=True)
    dataflow_id       = Column(Integer, nullable=False, index=True)          # FK→dataflows.id
    name              = Column(String(120), nullable=False)
    # Exactly one of cron_expression or calendar_rule is populated.
    # cron_expression  — standard 5-field cron (UTC-by-default).
    # calendar_rule    — JSON: {"type":"daily"|"workday_n"|"month_end"|"sod"|
    #                            "eod"|"intraday", "calendar":"...","hour":N,
    #                            "minute":N, ...}.  Resolved by
    #                    ``core.dataflow.calendar_trigger.next_calendar_fire_at``
    #                    against the shared FeedCalendar / FeedHoliday tables.
    cron_expression   = Column(String(80), nullable=False, default="")
    calendar_rule     = Column(JSON, nullable=True)
    timezone          = Column(String(50), default="UTC")
    context_overrides = Column(JSON, nullable=True)                          # merged into default_context on fire
    is_active         = Column(Boolean, default=True, index=True)
    last_run_at       = Column(DateTime, nullable=True)
    next_run_at       = Column(DateTime, nullable=True, index=True)
    created_by        = Column(String(100), nullable=True)
    created_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                                onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                self.id,
            "dataflow_id":       self.dataflow_id,
            "name":              self.name,
            "cron_expression":   self.cron_expression or "",
            "calendar_rule":     self.calendar_rule or None,
            "timezone":          self.timezone,
            "context_overrides": self.context_overrides or {},
            "is_active":         bool(self.is_active),
            "last_run_at":       self.last_run_at.isoformat() if self.last_run_at else None,
            "next_run_at":       self.next_run_at.isoformat() if self.next_run_at else None,
            "created_by":        self.created_by,
            "created_at":        self.created_at.isoformat() if self.created_at else None,
            "updated_at":        self.updated_at.isoformat() if self.updated_at else None,
        }


# ── Phase 132.22 — Webhook triggers + Project variables ─────────────────


class DataFlowWebhookTrigger(Base):
    """Token-authenticated webhook that fires a DataFlow run when POSTed.

    External systems (Jenkins, GitLab, vendor) hit
        POST /api/webhooks/dataflow/<token>
    with an optional JSON body merged into the run's trigger_payload +
    context.  Each token is bound to ONE DataFlow.  Disable by setting
    ``is_active=False`` — the token stays in the table for audit.
    """
    __tablename__ = "dataflow_webhook_triggers"

    id           = Column(Integer, primary_key=True, index=True)
    dataflow_id  = Column(Integer, nullable=False, index=True)
    name         = Column(String(120), nullable=False)
    # Phase 132.25 — switched to hashed storage.
    # token        — LEGACY plaintext column.  Kept for backward compat
    #                 (auto-migrate adds token_hash to existing rows; new
    #                 rows leave token=null and rely on the hash path).
    # token_hash   — sha256 hex digest (64 chars) of the actual token.
    # token_prefix — first 8 chars of the token, shown to admins so they
    #                 can identify which webhook a leaked token came from
    #                 without seeing the full secret.
    token        = Column(String(64), nullable=True, unique=True, index=True)
    token_hash   = Column(String(64), nullable=True, unique=True, index=True)
    token_prefix = Column(String(8), nullable=True)
    is_active    = Column(Boolean, default=True, index=True)
    last_fired_at = Column(DateTime, nullable=True)
    fire_count   = Column(Integer, default=0)
    # Optional source-IP allowlist (CIDR strings).  Empty = any source.
    allowed_ips  = Column(JSON, nullable=True)
    # Phase 132.26 — HMAC body signature verification.  When set, the
    # public fire endpoint requires the caller to compute
    #   sig = HMAC-SHA256(signing_secret, raw_body).hexdigest()
    # and pass it as ``X-QueryStudio-Signature: sha256=<sig>``.  Stored
    # encrypted via core.crypto.encrypt_value (same pattern as
    # Connection.config secrets).  None = no signature check.
    signing_secret = Column(Text, nullable=True)
    created_by   = Column(String(100), nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":            self.id,
            "dataflow_id":   self.dataflow_id,
            "name":          self.name,
            # Token NEVER serialised by default — see secure_to_dict()
            "token_prefix":  self.token_prefix,
            "is_active":     bool(self.is_active),
            "last_fired_at": self.last_fired_at.isoformat() if self.last_fired_at else None,
            "fire_count":    self.fire_count or 0,
            "allowed_ips":   self.allowed_ips or [],
            # Don't leak the signing secret; just signal whether one is set.
            "has_signing_secret": bool(self.signing_secret),
            "created_by":    self.created_by,
            "created_at":    self.created_at.isoformat() if self.created_at else None,
        }

    def secure_to_dict(self, plaintext_token: Optional[str] = None) -> Dict[str, Any]:
        """Variant that includes the token — returned ONLY at creation time
        so admins can copy it.  Subsequent list/get calls use to_dict().
        Pass the plaintext from the create call site since the row only
        stores the hash."""
        d = self.to_dict()
        d["token"] = plaintext_token or self.token
        return d


class SapTaskConfig(Base):
    """Phase 132.29 — DB-driven SAP ETL task config.

    Single row per SAP feed (e.g. "sap_mebal_monthly", "sap_mebal_eod").
    Replaces the legacy ``sap_mebal_config.json`` for environments that
    want UI-managed SAP feeds.  Loaded by the Airflow standalone runner
    via ``--task_id`` flag; passed through the existing 5-step pipeline
    (SapOdataDownload → ConsolidateFiles → CompressFiles → CreateCTLFile
    → DeliverFiles) without changing the steps themselves.

    Credentials live on the referenced ``Connection`` row (encrypted via
    core.crypto), so the task config carries no plaintext secrets.
    Column mapping is the ONE thing that stays as a JSON file — schemas
    evolve and operators want to edit the file on NFS, not click through
    a UI.
    """
    __tablename__ = "sap_task_configs"

    id   = Column(Integer, primary_key=True, index=True)
    name = Column(String(120), nullable=False, unique=True, index=True)
    is_active = Column(Boolean, default=True, index=True)

    # Connection-backed credentials (encrypted at rest on the Connection row).
    # The Connection.config dict must expose: base_url, username, password.
    sap_connection_id = Column(Integer, nullable=False, index=True)

    # SAP OData paths
    odata_service_path    = Column(String(255), nullable=False)
    company_code_endpoint = Column(String(255), nullable=False)
    company_code_field    = Column(String(80), default="Companycode")
    # Phase 132.31 — OData entity set + filter style.
    # entity_set is the function-import name BEFORE the parameter block
    #   (e.g. "MEBALParameters", "TDBALQPRD0104Parameters").
    # filter_style: 'eq' = OR-of-Companycode-eq filters (no cross-group
    #   duplicates).  'range' = Companycode ge first AND le last
    #   (matches the SAP MEBAL Airflow original; requires contiguous
    #    groups).
    entity_set   = Column(String(120), default="MEBALParameters")
    filter_style = Column(String(20),  default="eq")

    # Period derivation:
    #   'current'                 — current_year + current_month
    #   'prev_eom'                — previous-month's year + previous-month
    #   'current_year_prev_poper' — current year + previous month
    #                                (Jan returns poper='012', no year rollback)
    #                                — matches user SAP MEBAL "p_gjahr is
    #                                  always current year, p_poper is
    #                                  most-recently-closed period"
    #   'explicit'                — admin-supplied p_gjahr + p_poper
    period_mode = Column(String(40), default="current")
    p_gjahr     = Column(String(8), nullable=True)
    p_poper     = Column(String(8), nullable=True)

    # Parallelism + pagination
    num_groups          = Column(Integer, default=5)
    max_parallel_groups = Column(Integer, default=3)
    page_size           = Column(Integer, default=100000)
    timeout_seconds     = Column(Integer, default=120)
    max_retries         = Column(Integer, default=3)
    retry_backoff       = Column(Integer, default=2)
    rate_limit_rps      = Column(Integer, default=5)
    verify_ssl          = Column(Boolean, default=True)
    proxy_url           = Column(String(255), nullable=True)

    # Output (always NFS for now — delivery_type=nfs default)
    output_dir              = Column(String(512), nullable=False)
    output_format           = Column(String(20), default="csv")
    consolidated_filename   = Column(String(200), default="MEBAL_{GJAHR}_{POPER}")
    group_history_path      = Column(String(512), nullable=True)
    delete_group_files      = Column(Boolean, default=True)
    column_mapping_path     = Column(String(512), nullable=True)

    # Compression
    gzip_level          = Column(Integer, default=6)
    gzip_chunk_size     = Column(Integer, default=67108864)
    delete_uncompressed = Column(Boolean, default=True)

    # CTL file
    ctl_template         = Column(Text, nullable=True)
    ctl_filename         = Column(String(200), nullable=True)
    ctl_custom_variables = Column(JSON, nullable=True)

    # Delivery
    delivery_type   = Column(String(20), default="nfs")
    nfs_dest_dir    = Column(String(512), nullable=True)
    sftp_connection_id = Column(Integer, nullable=True, index=True)
    sftp_remote_dir = Column(String(512), nullable=True)
    s3_connection_id = Column(Integer, nullable=True, index=True)
    s3_bucket       = Column(String(255), nullable=True)
    s3_prefix       = Column(String(255), nullable=True)

    # Notifications
    notify_emails   = Column(Text, nullable=True)  # comma-separated

    # ── Phase 132.33 — Live SAP passthrough API ─────────────────────────
    # Admin opts in; when enabled the /api/sap-passthrough/{id}/query
    # endpoint accepts consumer requests, builds the OData URL with
    # p_timestamp=now(), proxies the call, applies column_mapping, and
    # returns JSON.  Distinct from ETL (which lands data to NFS).
    passthrough_enabled            = Column(Boolean, default=False)
    # Partition filter — REQUIRED in every consumer request.  Target
    # column name (post column_mapping), e.g. "company_code".  The OData
    # source column is derived from the inverse column_mapping at runtime.
    passthrough_partition_field    = Column(String(80), default="company_code")
    # Additional REQUIRED filter columns (JSON list of target names).
    # Use this to force consumers to scope queries — e.g.
    # ["company_code", "fiscal_year"].
    passthrough_required_filters   = Column(JSON, nullable=True)
    # Rate limit: requests per minute per task (in-memory token bucket).
    # Protects SAP from one consumer overwhelming it.
    passthrough_rate_limit_rpm     = Column(Integer, default=60)
    # Per-request row cap.  Consumer's $top is clamped to this value so
    # a careless request doesn't pull millions of rows in one call.
    passthrough_max_rows           = Column(Integer, default=10000)

    created_by  = Column(String(100), nullable=True)
    created_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                          onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                    self.id,
            "name":                  self.name,
            "is_active":             bool(self.is_active),
            "sap_connection_id":     self.sap_connection_id,
            "odata_service_path":    self.odata_service_path,
            "company_code_endpoint": self.company_code_endpoint,
            "company_code_field":    self.company_code_field,
            "entity_set":            self.entity_set or "MEBALParameters",
            "filter_style":          self.filter_style or "eq",
            "period_mode":           self.period_mode,
            "p_gjahr":               self.p_gjahr,
            "p_poper":               self.p_poper,
            "num_groups":            self.num_groups,
            "max_parallel_groups":   self.max_parallel_groups,
            "page_size":             self.page_size,
            "timeout_seconds":       self.timeout_seconds,
            "max_retries":           self.max_retries,
            "retry_backoff":         self.retry_backoff,
            "rate_limit_rps":        self.rate_limit_rps,
            "verify_ssl":            bool(self.verify_ssl),
            # BF-519 (2026-05-28): proxy_url may contain inline
            # ``user:password@`` credentials.  Mask before serialising
            # so admins reading the schema endpoint / audit dump never
            # see the plaintext secret.  The mask is purely cosmetic —
            # the row still stores the real value for SAP HTTP calls.
            "proxy_url":             _mask_proxy_url(self.proxy_url),
            "output_dir":            self.output_dir,
            "output_format":         self.output_format,
            "consolidated_filename": self.consolidated_filename,
            "group_history_path":    self.group_history_path,
            "delete_group_files":    bool(self.delete_group_files),
            "column_mapping_path":   self.column_mapping_path,
            "gzip_level":            self.gzip_level,
            "gzip_chunk_size":       self.gzip_chunk_size,
            "delete_uncompressed":   bool(self.delete_uncompressed),
            "ctl_template":          self.ctl_template,
            "ctl_filename":          self.ctl_filename,
            "ctl_custom_variables":  self.ctl_custom_variables or {},
            "delivery_type":         self.delivery_type,
            "nfs_dest_dir":          self.nfs_dest_dir,
            "sftp_connection_id":    self.sftp_connection_id,
            "sftp_remote_dir":       self.sftp_remote_dir,
            "s3_connection_id":      self.s3_connection_id,
            "s3_bucket":             self.s3_bucket,
            "s3_prefix":             self.s3_prefix,
            "notify_emails":         self.notify_emails,
            "passthrough_enabled":            bool(self.passthrough_enabled),
            "passthrough_partition_field":    self.passthrough_partition_field or "company_code",
            "passthrough_required_filters":   self.passthrough_required_filters or [],
            "passthrough_rate_limit_rpm":     self.passthrough_rate_limit_rpm or 60,
            # 2026-08-20 -- third layer of the same fold; 0 = UNLIMITED.
            "passthrough_max_rows":           (10000 if self.passthrough_max_rows is None
                                               else int(self.passthrough_max_rows)),
            "created_by":            self.created_by,
            "created_at":            self.created_at.isoformat() if self.created_at else None,
            "updated_at":            self.updated_at.isoformat() if self.updated_at else None,
        }


class DataFlowRunAnnotation(Base):
    """Phase 132.23 — post-mortem notes attached to a specific run.

    Operators jot down what they found while debugging a failed run, or
    why they re-ran something.  Annotations are append-only — to retract
    a wrong note, post a follow-up.  Visible on the run detail page.
    """
    __tablename__ = "dataflow_run_annotations"

    id           = Column(Integer, primary_key=True, index=True)
    run_id       = Column(Integer, nullable=False, index=True)
    note         = Column(Text, nullable=False)
    severity     = Column(String(20), default="info")   # info | warning | resolution
    created_by   = Column(String(100), nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":         self.id,
            "run_id":     self.run_id,
            "note":       self.note,
            "severity":   self.severity,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class DataFlowVariable(Base):
    """Project-wide config values DAGs can read via ``{var.name}`` in
    stage_config strings.

    Scope:
    * dataflow_id IS NULL  → global (visible to every DataFlow)
    * dataflow_id  set      → per-DataFlow (overrides global with same name)

    Sensitive variables (``is_secret=True``) are encrypted at rest the same
    way Connection.config secrets are, and never returned in plaintext via
    the list/get endpoints — only resolved at stage execution.
    """
    __tablename__ = "dataflow_variables"

    id           = Column(Integer, primary_key=True, index=True)
    name         = Column(String(80), nullable=False, index=True)
    value        = Column(Text, nullable=True)
    dataflow_id  = Column(Integer, nullable=True, index=True)
    description  = Column(Text, nullable=True)
    is_secret    = Column(Boolean, default=False)
    created_by   = Column(String(100), nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                            onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        UniqueConstraint("name", "dataflow_id", name="uq_dataflow_variables_scope"),
    )

    def to_dict(self, include_value: bool = True) -> Dict[str, Any]:
        return {
            "id":          self.id,
            "name":        self.name,
            "value":       (self.value if (include_value and not self.is_secret)
                              else ("****" if self.is_secret else None)),
            "dataflow_id": self.dataflow_id,
            "description": self.description,
            "is_secret":   bool(self.is_secret),
            "created_by":  self.created_by,
            "created_at":  self.created_at.isoformat() if self.created_at else None,
            "updated_at":  self.updated_at.isoformat() if self.updated_at else None,
        }


# ── Phase 132.21 — Notification policies ────────────────────────────────


class DataFlowNotificationPolicy(Base):
    """Event-driven notification rules — fire email/Slack/webhook when a
    DataFlow run hits a configured event (failed / sla_breached / partial /
    succeeded).  Independent from the in-DAG ``send_email`` stage so ops
    don't have to wire notifications into every DAG.

    Scope:
    * ``dataflow_id IS NULL`` → fires for any DataFlow (global)
    * ``dataflow_id`` set      → fires for that DataFlow only
    * ``tag``         set      → fires for any DataFlow carrying that tag
      (NULL+NULL = global, dataflow_id wins over tag)

    Channels:
    * ``email``    : recipients live in ``config.to``  (uses core.email_service)
    * ``webhook``  : ``config.url`` + ``config.headers`` (POST JSON payload)
    * ``ws``       : broadcast a typed event to admin clients
    """
    __tablename__ = "dataflow_notification_policies"

    id            = Column(Integer, primary_key=True, index=True)
    name          = Column(String(120), nullable=False)
    # Scope
    dataflow_id   = Column(Integer, nullable=True, index=True)     # FK→dataflows.id (nullable = global)
    tag           = Column(String(60), nullable=True, index=True)  # match DataFlow.tags
    # Trigger
    event         = Column(String(40), nullable=False, index=True)
    # event: run_failed | run_succeeded | run_partial | sla_breached | run_cancelled | schedule_missed
    channel       = Column(String(20), nullable=False)             # email | webhook | ws
    config        = Column(JSON, nullable=True)                    # channel-specific (to/url/headers/...)
    is_active     = Column(Boolean, default=True, index=True)
    # Rate limiting: cool-down N seconds between fires for same (policy_id, dataflow_id, event)
    cooldown_seconds = Column(Integer, default=0)
    last_fired_at = Column(DateTime, nullable=True)
    created_by    = Column(String(100), nullable=True)
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                            onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index("ix_dataflow_notification_event_active", "event", "is_active"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":               self.id,
            "name":             self.name,
            "dataflow_id":      self.dataflow_id,
            "tag":              self.tag,
            "event":            self.event,
            "channel":          self.channel,
            "config":           self.config or {},
            "is_active":        bool(self.is_active),
            "cooldown_seconds": self.cooldown_seconds or 0,
            "last_fired_at":    self.last_fired_at.isoformat() if self.last_fired_at else None,
            "created_by":       self.created_by,
            "created_at":       self.created_at.isoformat() if self.created_at else None,
            "updated_at":       self.updated_at.isoformat() if self.updated_at else None,
        }


# ── Reconciliation (Phase 133) ────────────────────────────────────────
#
# Compares one source-side query (e.g. Starburst against the lake) against
# a destination-side query (e.g. Oracle warehouse) to detect breaks
# (row-count / sum mismatches).  A background scheduler runs the check
# every N hours; when a break is detected and auto-reload is enabled, an
# Oracle stored procedure is invoked on the OG-ETL Oracle connection to
# re-run the upstream ETL.  UI lets a user trigger a manual reload too.


class ReconciliationEntity(Base):
    """One configured source-vs-destination comparison.

    Three connections per entity (all FK to connections.id):
      * ``source_connection_id``  — typically Starburst / Trino
      * ``dest_connection_id``    — typically Oracle (destination warehouse)
      * ``etl_connection_id``     — typically Oracle (OG-ETL — runs the
                                     reload PL/SQL package)

    Two SQL strings (run against the connections above).  Both queries
    must return a single row with the comparison columns (typically a
    ``row_count`` and optionally a ``total_amount`` for a sum check).
    """
    __tablename__ = "reconciliation_entities"

    id          = Column(Integer, primary_key=True)
    name        = Column(String(255), nullable=False, unique=True)
    description = Column(Text, nullable=True)
    is_active   = Column(Boolean, default=True, nullable=False)

    # Three-connection contract.
    source_connection_id = Column(Integer,
                                   ForeignKey("connections.id"),
                                   nullable=False)
    dest_connection_id   = Column(Integer,
                                   ForeignKey("connections.id"),
                                   nullable=False)
    etl_connection_id    = Column(Integer,
                                   ForeignKey("connections.id"),
                                   nullable=True)

    # The reconciliation query.  Three shapes supported, in order of
    # precedence:
    #   1. ``sql_file_id`` (preferred) — pointer to a SqlFile row.  The
    #      runner loads SQL content from the .sql file on disk at run
    #      time, so edits to the file flow through automatically.  This
    #      is THE pattern the rest of the platform uses (feed_gen,
    #      published views, dataflow stages).  If the .sql file has the
    #      ``-- PRIMARY`` / ``-- SECONDARY`` cross-source markers we
    #      honour them: PRIMARY runs on source, SECONDARY on dest.
    #   2. ``query`` (inline) — ONE SQL string used on BOTH sides.
    #   3. ``source_query`` + ``dest_query`` — used when dialects differ
    #      (e.g. Trino vs Oracle date-arith syntax).
    # Calendar tokens (``{{business_date}}`` etc.) are resolved at run
    # time the same way the feed-engine resolver does.
    sql_file_id  = Column(Integer, ForeignKey("sql_files.id"),
                            nullable=True)
    # Phase 133-F UX — independent .sql file per side.  Higher
    # precedence than ``sql_file_id`` (single file w/ PRIMARY/SECONDARY
    # markers) so users who prefer two separate files don't have to
    # learn the marker syntax.  NULL on legacy rows = use the existing
    # paths (sql_file_id markers OR inline query OR pair).
    source_sql_file_id = Column(Integer, ForeignKey("sql_files.id"),
                                  nullable=True)
    dest_sql_file_id   = Column(Integer, ForeignKey("sql_files.id"),
                                  nullable=True)
    query        = Column(Text, nullable=True)
    source_query = Column(Text, nullable=True)
    dest_query   = Column(Text, nullable=True)

    # Comparison mode + tolerance.
    #   row_count        — just compare row_count column on each side
    #   row_count_sum    — row_count AND any numeric columns named in
    #                       ``comparison_columns``
    #   row_by_row       — match rows by ``key_columns``; flag rows
    #                       that are in one side only OR have
    #                       differing value columns.  Produces a per-row
    #                       diff for the recon-report UI panel.
    comparison_mode    = Column(String(40), default="row_count",
                                 nullable=False)
    comparison_columns = Column(JSON, default=list)   # list[str]
    key_columns        = Column(JSON, default=list)   # list[str]
    max_rows_compared  = Column(Integer, default=50000)
    tolerance          = Column(Float, default=0.0)   # absolute diff allowed
    tolerance_pct      = Column(Float, default=0.0)   # % diff allowed

    # Phase 133-E — dynamic parameterize via the shared
    # ``core.where_clause_mapping.WhereClauseMapping`` primitive (same
    # contract Published Views, Feed Generation, and DataFlow stages
    # use).  Each row: ``{column, operator, value, mode}`` where
    # ``mode`` is ``static`` (always applied) or ``dynamic``
    # (overrideable at trigger time via ``query_param_overrides`` on
    # the /check endpoint).  NULL on legacy rows = no parameterize;
    # the runner falls through to plain token substitution.
    where_clauses_mapping = Column(JSON, nullable=True)

    # Reload trigger — Oracle PL/SQL package.  When a break is detected
    # AND auto_reload_on_break is true (or the user clicks Reload), the
    # backend builds an anonymous block like:
    #
    #   BEGIN
    #     PKG_OTG_DEPENDENCY_RESOLUTION.PR_BULK_START_DAGS_WITH_DEPS(
    #       p_dag_ids       => :dag_ids,
    #       p_business_date => :biz_date,
    #       p_run_date      => :run_date
    #     );
    #   END;
    #
    # and runs it against the ``etl_connection_id``.
    dag_ids                  = Column(JSON, default=list)   # list[int|str]
    business_date_template   = Column(String(80),
                                       default="{{business_date}}")
    auto_reload_on_break     = Column(Boolean, default=False)
    reload_package_template  = Column(Text, nullable=True)  # optional override

    # Scheduling — the background job iterates active entities and runs
    # each whose ``last_checked_at + check_interval_hours`` <= now.
    schedule_enabled         = Column(Boolean, default=True)
    check_interval_hours     = Column(Integer, default=2)

    # Audit + bookkeeping.
    created_by  = Column(String(128), nullable=True)
    created_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                          nullable=False)
    updated_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                          onupdate=lambda: datetime.now(timezone.utc),
                          nullable=False)

    # Denormalised "current state" so the dashboard can query without
    # joining to the runs table.  Updated by the run-completion path.
    last_checked_at         = Column(DateTime, nullable=True)
    last_status             = Column(String(20), nullable=True)   # ok / break / error
    last_source_row_count   = Column(BigInteger, nullable=True)
    last_dest_row_count     = Column(BigInteger, nullable=True)
    last_break_details      = Column(JSON, default=dict)
    last_reload_triggered_at = Column(DateTime, nullable=True)

    __table_args__ = (
        Index("ix_reco_active_status", "is_active", "last_status"),
        Index("ix_reco_schedule",       "schedule_enabled",
              "check_interval_hours", "last_checked_at"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                       self.id,
            "name":                     self.name,
            "description":              self.description,
            "is_active":                bool(self.is_active),
            "source_connection_id":     self.source_connection_id,
            "dest_connection_id":       self.dest_connection_id,
            "etl_connection_id":        self.etl_connection_id,
            "sql_file_id":              self.sql_file_id,
            "source_sql_file_id":       self.source_sql_file_id,
            "dest_sql_file_id":         self.dest_sql_file_id,
            "query":                    self.query,
            "source_query":             self.source_query,
            "dest_query":               self.dest_query,
            "comparison_mode":          self.comparison_mode,
            "comparison_columns":       self.comparison_columns or [],
            "key_columns":              self.key_columns or [],
            # Phase 4 (2026-08-23): `or 50000` folded a stored 0
            # ("compare everything") back into the 50k cap before the
            # runner ever saw it -- the runner's own unlimited branch was
            # dead code through this path.
            "max_rows_compared":        (self.max_rows_compared
                                         if self.max_rows_compared is not None
                                         else 50000),
            "tolerance":                self.tolerance or 0,
            "tolerance_pct":            self.tolerance_pct or 0,
            "where_clauses_mapping":    self.where_clauses_mapping or [],
            "dag_ids":                  self.dag_ids or [],
            "business_date_template":   self.business_date_template,
            "auto_reload_on_break":     bool(self.auto_reload_on_break),
            "reload_package_template":  self.reload_package_template,
            "schedule_enabled":         bool(self.schedule_enabled),
            "check_interval_hours":     self.check_interval_hours or 2,
            "created_by":               self.created_by,
            "created_at":               self.created_at.isoformat()
                                          if self.created_at else None,
            "updated_at":               self.updated_at.isoformat()
                                          if self.updated_at else None,
            "last_checked_at":          self.last_checked_at.isoformat()
                                          if self.last_checked_at else None,
            "last_status":              self.last_status,
            "last_source_row_count":    self.last_source_row_count,
            "last_dest_row_count":      self.last_dest_row_count,
            "last_break_details":       self.last_break_details or {},
            "last_reload_triggered_at": self.last_reload_triggered_at.isoformat()
                                          if self.last_reload_triggered_at else None,
        }


class ReconciliationRun(Base):
    """One execution of a reconciliation check.  Audit log + history."""
    __tablename__ = "reconciliation_runs"

    id           = Column(Integer, primary_key=True)
    entity_id    = Column(Integer, ForeignKey("reconciliation_entities.id"),
                            nullable=False, index=True)
    triggered_by = Column(String(40), default="scheduler")  # scheduler | user | api
    triggered_by_user = Column(String(128), nullable=True)
    started_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                            nullable=False)
    finished_at  = Column(DateTime, nullable=True)
    status       = Column(String(20), default="running")
    # running | completed | failed

    # Result fields — populated by the runner.
    business_date        = Column(String(20), nullable=True)
    source_row_count     = Column(BigInteger, nullable=True)
    dest_row_count       = Column(BigInteger, nullable=True)
    source_sums          = Column(JSON, default=dict)  # {col: value}
    dest_sums            = Column(JSON, default=dict)
    break_detected       = Column(Boolean, default=False)
    break_details        = Column(JSON, default=dict)
    source_query_ms      = Column(Integer, nullable=True)
    dest_query_ms        = Column(Integer, nullable=True)
    reload_triggered     = Column(Boolean, default=False)
    reload_error         = Column(Text, nullable=True)
    error_message        = Column(Text, nullable=True)

    __table_args__ = (
        Index("ix_reco_run_entity_started", "entity_id", "started_at"),
        Index("ix_reco_run_break", "break_detected", "started_at"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                self.id,
            "entity_id":         self.entity_id,
            "triggered_by":      self.triggered_by,
            "triggered_by_user": self.triggered_by_user,
            "started_at":        self.started_at.isoformat() if self.started_at else None,
            "finished_at":       self.finished_at.isoformat() if self.finished_at else None,
            "status":            self.status,
            "business_date":     self.business_date,
            "source_row_count":  self.source_row_count,
            "dest_row_count":    self.dest_row_count,
            "source_sums":       self.source_sums or {},
            "dest_sums":         self.dest_sums or {},
            "break_detected":    bool(self.break_detected),
            "break_details":     self.break_details or {},
            "source_query_ms":   self.source_query_ms,
            "dest_query_ms":     self.dest_query_ms,
            "reload_triggered":  bool(self.reload_triggered),
            "reload_error":      self.reload_error,
            "error_message":     self.error_message,
        }


class QueryPruningHistory(CanonicalPrefixMixin, Base):
    """2026-06-04 — per-query pruning telemetry persisted for trend
    analysis.  Lets admins look back at "this query against this snapshot
    historically prunes from N→M files; why is today's run scanning
    everything?" and drill into the per-WHERE-clause breakdown.

    One row per call to iceberg_reader.get_iceberg_data_files that
    completed with an execution_id in scope.  Best-effort write — the
    query path NEVER blocks on this insert.
    """
    __tablename__ = "query_pruning_history"

    id              = Column(Integer, primary_key=True, autoincrement=True)
    execution_id    = Column(String(64), nullable=False, index=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                              nullable=False, index=True)

    bucket          = Column(String(255), nullable=True)
    table_prefix    = Column(String(512), nullable=True)
    snapshot_id     = Column(String(64),  nullable=True, index=True)

    files_before_prune = Column(Integer, nullable=True)
    files_after_prune  = Column(Integer, nullable=True)
    # 2026-10-08 -- what the engine actually READ, beside what the pruner
    # KEPT.  ``files_after_prune`` is deliberately the PRUNER's verdict
    # (before a mirror / island swap, before the LIMIT-only early stop);
    # live on real AWS a ``limit 100`` read 1 of 2,688 files and the row
    # said 2,688.  ``files_read`` is the objects handed to the engine (NULL
    # = unknown, never 0) and ``read_reason`` why it differs:
    # limit_early_stop / mirror / island / NULL (it does not).  Written
    # through the ONE writer (query_diagnostic_store.record_files_read).
    files_read         = Column(Integer, nullable=True)
    read_reason        = Column(String(32), nullable=True)

    # Stage-level drop counts — exposes which layer of the pruner did
    # the work (manifest partition prune, iceberg column stats,
    # supplement table, bloom filter).
    partition_drops    = Column(Integer, nullable=True)
    col_stats_drops    = Column(Integer, nullable=True)
    supplement_drops   = Column(Integer, nullable=True)
    bloom_drops        = Column(Integer, nullable=True)
    # 149-fix-1 (2026-06-09): DB-backed bloom sidecar drops (separate from
    # the BF-548 native S3 bloom counted in bloom_drops).  Without this
    # column, every 149.4 win is silently lost when the per-query row
    # persists — the diagnose UI shows it in-memory but historical /
    # aggregated dashboards see zero pruning from the sidecar.  Also
    # breaks 149.6's adaptive prefetcher feedback loop (it reads
    # history to decide what to scan next; bloom hits look invisible
    # there).
    bloom_sidecar_drops = Column(Integer, nullable=True)

    # Per-WHERE-clause breakdown as a JSON list of
    # {column, operator, value, support, support_reason}.
    filter_breakdown   = Column(JSON, nullable=True)

    # Stage timings (carried over from iceberg_timing) so trends in
    # cache latency are visible.
    metadata_seconds   = Column(Float, nullable=True)
    manifests_seconds  = Column(Float, nullable=True)

    # Source label — cache vs s3_fallback vs unknown.
    source             = Column(String(32), nullable=True)
    # Phase 151 (2026-06-10) — format discriminator.  'iceberg' for
    # iceberg-backed query rows; 'parquet' for plain-parquet brain
    # rows.  Brain components (CostModel / Skew / Forecaster /
    # WriterAdvisor) become parquet-aware automatically because they
    # key on (bucket, prefix) regardless of format.
    format             = Column(String(32), nullable=False, default="iceberg",
                                 server_default="iceberg")

    __table_args__ = (
        Index("ix_query_pruning_history_table_created",
              "bucket", "table_prefix", "created_at"),
    )

    def to_dict(self) -> dict:
        return {
            "id":                 self.id,
            "execution_id":       self.execution_id,
            "created_at":         self.created_at.isoformat() if self.created_at else None,
            "bucket":             self.bucket,
            "table_prefix":       self.table_prefix,
            "snapshot_id":        self.snapshot_id,
            "files_before_prune": self.files_before_prune,
            "files_after_prune":  self.files_after_prune,
            "files_read":         self.files_read,
            "read_reason":        self.read_reason,
            "partition_drops":     self.partition_drops,
            "col_stats_drops":     self.col_stats_drops,
            "supplement_drops":    self.supplement_drops,
            "bloom_drops":         self.bloom_drops,
            "bloom_sidecar_drops": self.bloom_sidecar_drops,
            "filter_breakdown":    self.filter_breakdown or [],
            "metadata_seconds":   self.metadata_seconds,
            "manifests_seconds":  self.manifests_seconds,
            "source":             self.source,
            # 2026-09-06 -- the Phase 151 format discriminator exists
            # so a consumer can tell an iceberg row from a plain-parquet
            # one; it was never in the dict, so every reader of
            # /api/admin/queries/pruning-history and of
            # get_pruning_history was blind to it.
            "format":             self.format,
        }


class PruningAlertEvent(CanonicalPrefixMixin, Base):
    """2026-09-07 — the durable record of every pruning alert DECISION.

    ``core.pruning_alerts``' docstring claimed since Phase 148.D that it
    "persists the dispatch to ``pruning_alert_events``".  The name existed
    in no model, no migration and no query: the only record was a
    process-local ``deque(maxlen=200)``, and a row was appended to it ONLY
    when a channel returned ok.  With both webhook URLs empty — the SHIPPED
    DEFAULT — a detected degradation was counted as an error and recorded
    NOWHERE, so "what did we fail to page?" answered "nothing", which is
    the opposite of the truth.  This table is that name, made real.

    ONE ROW PER ALERT THE DISPATCHER DECIDED IS REAL, whatever became of
    it.  ``delivery_status`` is the verdict, and the UNDELIVERED values are
    the point of the table:

      * ``delivered``    — at least one channel returned 2xx.
      * ``undelivered``  — channels were configured and ALL of them failed.
      * ``no_channel``   — the alert fired and there was nowhere to send it
                           (both webhook URLs empty: the shipped default).
      * ``suppressed``   — inside the dedup window; a real degradation that
                           was deliberately not re-sent.
      * ``capped``       — over ``max_alerts_per_tick``; detected, dropped.

    Writing is BEST-EFFORT and fail-open in both directions: the alert path
    observes the query path and must never break it, and a sink that cannot
    be written must not turn a dispatch into an exception.  A write that
    fails is logged and the in-memory ring still carries the event.
    """
    __tablename__ = "pruning_alert_events"

    id               = Column(Integer, primary_key=True, autoincrement=True)
    fired_at         = Column(DateTime,
                               default=lambda: datetime.now(timezone.utc),
                               nullable=False, index=True)
    #: "degradation" | "compaction_needed" | "test"
    kind             = Column(String(64), nullable=False, default="degradation")
    bucket           = Column(String(255), nullable=True)
    table_prefix     = Column(String(1024), nullable=True)
    #: The dedup identity this event was filed under — ``kind|bucket|prefix``.
    dedup_key        = Column(String(1400), nullable=True, index=True)

    #: delivered | undelivered | no_channel | suppressed | capped
    delivery_status  = Column(String(32), nullable=False, index=True)
    #: True only for ``delivered``.  A separate boolean so "show me
    #: everything we failed to page" is one indexed predicate and cannot
    #: drift from the status string.
    delivered        = Column(Boolean, nullable=False, default=False,
                               index=True)
    #: Why it was not delivered, in words.  NEVER empty for a non-delivered
    #: row: an undelivered alert with no reason is the failure this table
    #: was built to stop.
    reason           = Column(Text, nullable=True)

    #: The full ``PruningAlert.to_dict()`` payload as it would have been
    #: sent — so an operator can replay exactly what ops did not receive.
    payload          = Column(JSON, nullable=True)
    #: Per-channel results: ``[{"ok": bool, "channel": str, ...}, ...]``.
    channels         = Column(JSON, nullable=True)

    # Denormalised degradation numbers so the common admin query does not
    # have to open the JSON.
    current_avg_pct  = Column(Float, nullable=True)
    previous_avg_pct = Column(Float, nullable=True)
    delta_pct_points = Column(Float, nullable=True)
    threshold_pct    = Column(Float, nullable=True)

    __table_args__ = (
        Index("ix_pruning_alert_events_undelivered", "delivered", "fired_at"),
        Index("ix_pruning_alert_events_table", "bucket", "table_prefix",
              "fired_at"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":               self.id,
            "fired_at":         self.fired_at.isoformat() if self.fired_at else None,
            "kind":             self.kind,
            "bucket":           self.bucket,
            "table_prefix":     self.table_prefix,
            "dedup_key":        self.dedup_key,
            "delivery_status":  self.delivery_status,
            "delivered":        bool(self.delivered),
            "reason":           self.reason,
            "payload":          self.payload,
            "channels":         self.channels or [],
            "current_avg_pct":  self.current_avg_pct,
            "previous_avg_pct": self.previous_avg_pct,
            "delta_pct_points": self.delta_pct_points,
            "threshold_pct":    self.threshold_pct,
        }


# ── Phase 156 (2026-06-25) -- brain smarter ──────────────────────────


class BrainPruningMemo(CanonicalPrefixMixin, Base):
    """Phase 156.2 -- cached pruned file list keyed by SQL shape.

    Same SQL against the same snapshot prunes to the same surviving
    file list every time.  Manifest + supplement + bloom layers run
    ONCE per (sql_shape_hash, snapshot_id) pair; subsequent queries
    skip the work entirely and read the memoised list.

    Strategic shape:
      * Snapshot-pinned: when the watcher rolls the snapshot, the
        old memo is invalidated by the same Hook 1 that invalidates
        the brain sql-cache.
      * Bounded: cleanup daemon trims rows older than TTL or beyond
        a per-table cap to keep the table tiny.
      * Read-mostly: one row written per (sql_shape, snapshot); read
        many times.
    """
    __tablename__ = "brain_pruning_memo"

    id              = Column(Integer, primary_key=True, index=True)
    sql_hash        = Column(String(64), nullable=False)
    snapshot_id     = Column(String(128), nullable=False)
    bucket          = Column(String(255), nullable=False)
    table_prefix    = Column(String(512), nullable=False)
    # JSON list of surviving file keys.
    surviving_files = Column(Text, nullable=False)
    surviving_count = Column(Integer, nullable=False, default=0)
    # Diagnostic -- how many files the manifest/supplement/bloom layers
    # pruned, for the admin "what did the brain do?" chip.
    pruning_breakdown = Column(JSON, nullable=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                              index=True)
    hit_count       = Column(Integer, nullable=False, default=0)
    # Phase 156 deep-dive R8 -- index for the cleanup daemon's
    # ``WHERE last_hit_at < cutoff`` filter.  Without this the eviction
    # full-scans the memo table; with 100K rows that's measurable.
    last_hit_at     = Column(DateTime, nullable=True, index=True)

    __table_args__ = (
        Index("ix_brain_pruning_memo_lookup",
              "sql_hash", "snapshot_id", unique=True),
        Index("ix_brain_pruning_memo_table",
              "bucket", "table_prefix"),
    )

    def to_dict(self) -> dict:
        return {
            "id":                self.id,
            "sql_hash":          self.sql_hash,
            "snapshot_id":       self.snapshot_id,
            "bucket":            self.bucket,
            "table_prefix":      self.table_prefix,
            "surviving_count":   self.surviving_count,
            "pruning_breakdown": self.pruning_breakdown,
            "created_at":        self.created_at.isoformat() if self.created_at else None,
            "hit_count":         self.hit_count,
            "last_hit_at":       self.last_hit_at.isoformat() if self.last_hit_at else None,
        }


class BrainRouteOutcome(CanonicalPrefixMixin, Base):
    """Phase 156.3 -- per-route wall-clock history for outcome learning.

    Closes the brain's feedback loop.  When BrainRouter picks Spark
    for a SQL shape, this table records the actual wall-clock so the
    next decision on the same shape can flip back to local if Spark
    was slower in practice.

    Strategic shape:
      * Keyed by sql_hash (post-canonicalisation).  Different params
        on the same SQL share a row -- the brain decides on shape,
        not values.
      * Per-engine roll-up: stores a moving average per engine so
        the row size stays bounded (no append-only log).
      * Bounded by a cleanup daemon: rows untouched for N days are
        evicted.

    Read shape: BrainRouter calls a single helper that returns
    ``{engine: median_seconds}`` for a sql_hash + table.  When local
    is faster than Spark by > savings_factor, prefer local.
    """
    __tablename__ = "brain_route_outcome"

    id              = Column(Integer, primary_key=True, index=True)
    sql_hash        = Column(String(64), nullable=False)
    bucket          = Column(String(255), nullable=False)
    table_prefix    = Column(String(512), nullable=False)
    engine          = Column(String(40), nullable=False)
    # Rolling EMA of wall-clock seconds; smooths spikes.
    ema_seconds     = Column(Float, nullable=False, default=0.0)
    sample_count    = Column(Integer, nullable=False, default=0)
    # Latest sample for diagnostic display.
    last_seconds    = Column(Float, nullable=True)
    last_status     = Column(String(20), nullable=True)
    first_seen_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    last_seen_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                              onupdate=lambda: datetime.now(timezone.utc),
                              index=True)

    __table_args__ = (
        Index("ix_brain_route_outcome_lookup",
              "sql_hash", "bucket", "table_prefix", "engine", unique=True),
    )

    def to_dict(self) -> dict:
        return {
            "id":            self.id,
            "sql_hash":      self.sql_hash,
            "bucket":        self.bucket,
            "table_prefix":  self.table_prefix,
            "engine":        self.engine,
            "ema_seconds":   self.ema_seconds,
            "sample_count":  self.sample_count,
            "last_seconds":  self.last_seconds,
            "last_status":   self.last_status,
            "first_seen_at": self.first_seen_at.isoformat() if self.first_seen_at else None,
            "last_seen_at":  self.last_seen_at.isoformat() if self.last_seen_at else None,
        }


class IcebergFreshnessReliability(CanonicalPrefixMixin, Base):
    """2026-07-15 Adaptive Freshness (audit Finding #2) — per-table
    freshness-reliability record for the Iceberg pruning brain.

    One tiny row per (bucket, table_prefix):
      * ``hint_lied_count`` — how many times the resolved metadata pointer
        (version-hint.text / cache layers) disagreed with the newest
        metadata.json found by a capped LIST.  Once > 0 the table is
        cross-checked PERMANENTLY (a writer that doesn't maintain
        version-hint.text won't start maintaining it).
      * ``last_anomaly_at`` — the last time the Scan Ledger returned
        over_count/under_count for this table; arms the freshness
        cross-check for a configurable window (default 24h).

    Read-mostly, bounded by the number of distinct Iceberg tables.
    Created via Base.metadata.create_all() at startup like every other
    brain table.
    """
    __tablename__ = "iceberg_freshness_reliability"

    id              = Column(Integer, primary_key=True, index=True)
    bucket          = Column(String(255), nullable=False)
    table_prefix    = Column(String(512), nullable=False)
    hint_lied_count = Column(Integer, nullable=False, default=0)
    last_lied_at    = Column(DateTime, nullable=True)
    last_anomaly_at = Column(DateTime, nullable=True)
    created_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at      = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                              onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index("ix_iceberg_freshness_reliability_lookup",
              "bucket", "table_prefix", unique=True),
    )

    def to_dict(self) -> dict:
        return {
            "id":              self.id,
            "bucket":          self.bucket,
            "table_prefix":    self.table_prefix,
            "hint_lied_count": self.hint_lied_count,
            "last_lied_at":    self.last_lied_at.isoformat() if self.last_lied_at else None,
            "last_anomaly_at": self.last_anomaly_at.isoformat() if self.last_anomaly_at else None,
            "created_at":      self.created_at.isoformat() if self.created_at else None,
            "updated_at":      self.updated_at.isoformat() if self.updated_at else None,
        }


class IcebergWatcherCertificate(CanonicalPrefixMixin, Base):
    """2026-08-24 — the Iceberg watcher's published FRESHNESS CERTIFICATE.

    One row per (bucket, table_prefix).  Written by
    ``iceberg_manifest_watcher._check_one_table`` after EVERY successful
    poll -- including the unchanged case, which previously retained
    nothing at all.  Read by ``iceberg_reader._adaptive_freshness_refresh``
    to decide whether the per-query capped LIST can be skipped.

    Why this exists
    ===============
    The watcher polls ``metadata/`` on a fast cadence and already computes
    exactly what the query-path cross-check computes: which metadata.json
    is newest, and which snapshot it carries.  It then threw that away, so
    every query paid for the same LIST again in its own foreground -- on a
    table with many accumulated manifests that LIST dominates the query.

    This row is an OBSERVATION, not a decision:
      "at ``checked_at``, the newest metadata for this table was
       ``observed_metadata_key``, carrying ``observed_snapshot_id``."

    The READER decides what it is worth, and only ever trusts it on
    POSITIVE proof -- fresh enough, status ok, and the snapshot it names
    matching the pointer the query already resolved.  Every other case
    (no row, stale row, error row, disagreeing row) falls back to the
    capped LIST.  So a watcher that is stopped, disabled, crash-looping,
    or simply does not cover this table degrades to today's behaviour on
    its own, with no flag to remember to flip.

    Deliberately NOT stored on ``watched_iceberg_tables``: that table's
    ``last_snapshot_id`` drives ``iceberg_metadata_sync``'s "unchanged ->
    done" short-circuit, and a heartbeat writing it could make a genuine
    resync skip work.  Keeping the certificate separate means the watcher
    can heartbeat freely without touching the sync job's bookkeeping.

    Bounded by the number of distinct Iceberg tables; created via
    ``Base.metadata.create_all()`` at startup like every other brain table
    (a new COLUMN would have needed a migration these pods never run).
    """
    __tablename__ = "iceberg_watcher_certificate"

    id                    = Column(Integer, primary_key=True, index=True)
    bucket                = Column(String(255), nullable=False)
    table_prefix          = Column(String(512), nullable=False)
    # The connection the watcher polled through.  Advisory only -- the
    # certificate is keyed on the PHYSICAL table (bucket + prefix), because
    # two connections pointing at the same table observe the same snapshot.
    connection_id         = Column(Integer, nullable=True)
    # What the watcher SAW.  observed_snapshot_id is the value the reader
    # compares against the pointer the query already resolved; a mismatch
    # means something moved and the reader must not trust the row.
    observed_snapshot_id  = Column(String(64), nullable=True)
    observed_metadata_key = Column(String(1024), nullable=True)
    # ``ok`` only when the poll completed and produced a snapshot id.  Any
    # error path writes the reason and the reader refuses the row -- an
    # ERRORED watcher must never look like a fresh one.
    status                = Column(String(32), nullable=False, default="ok")
    error                 = Column(Text, nullable=True)
    # The heartbeat.  Age against the watcher's own interval decides
    # whether the observation is still worth anything.
    checked_at            = Column(DateTime, nullable=True)
    created_at            = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at            = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                                    onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index("ix_iceberg_watcher_certificate_lookup",
              "bucket", "table_prefix", unique=True),
    )

    def to_dict(self) -> dict:
        return {
            "id":                    self.id,
            "bucket":                self.bucket,
            "table_prefix":          self.table_prefix,
            "connection_id":         self.connection_id,
            "observed_snapshot_id":  self.observed_snapshot_id,
            "observed_metadata_key": self.observed_metadata_key,
            "status":                self.status,
            "error":                 self.error,
            "checked_at":  self.checked_at.isoformat() if self.checked_at else None,
            "created_at":  self.created_at.isoformat() if self.created_at else None,
            "updated_at":  self.updated_at.isoformat() if self.updated_at else None,
        }


class IcebergPrunabilityProfile(CanonicalPrefixMixin, Base):
    """2026-07-15 Prunability Profiles (audit Finding #3/#4) — per-column
    prunability evidence for the Iceberg pruning brain.

    The brain previously never reasoned about WHETHER a column is
    prunable: it waited for the background daemon to build a bloom
    sidecar after >=3 query-history hits.  Meanwhile
    ``system_id IN (...)`` scanned thousands of files because min/max
    bounds can't prune a high-cardinality unsorted id column.

    One tiny row per (bucket, table_prefix, column_name), built from
    evidence the manifest walk ALREADY computes (zero extra S3 I/O):

      * ``stats_coverage_pct``   — fraction of files with manifest OR
        supplement bounds for the column (value-independent).
      * ``bounds_overlap_ratio`` — fraction of bound-evaluated files
        whose [min,max] could NOT exclude the queried eq/in value
        (high == min/max pruning is useless for this column).
      * ``singleton_ratio``      — fraction of bounded files where
        min == max (well-clustered; bounds prune perfectly).
      * ``ndv_estimate``         — optional NDV hint (nullable; not
        populated by the query path today — reserved for the offline
        scanners).
      * ``sample_count``         — number of query observations merged
        into the running averages.

    CONSUMERS MAY ONLY use profiles to decide which artifacts to BUILD
    (bloom sidecars) and which diagnostics to emit — NEVER to change
    the keep/drop verdict of file pruning.  Read-mostly, bounded by
    (#tables × #filtered columns).  Created via
    Base.metadata.create_all() at startup like every other brain table.
    """
    __tablename__ = "iceberg_prunability_profile"

    id                   = Column(Integer, primary_key=True, index=True)
    bucket               = Column(String(255), nullable=False)
    table_prefix         = Column(String(512), nullable=False)
    column_name          = Column(String(255), nullable=False)
    stats_coverage_pct   = Column(Float, nullable=False, default=0.0)
    bounds_overlap_ratio = Column(Float, nullable=False, default=0.0)
    singleton_ratio      = Column(Float, nullable=False, default=0.0)
    ndv_estimate         = Column(BigInteger, nullable=True)
    sample_count         = Column(Integer, nullable=False, default=0)
    created_at           = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at           = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                                   onupdate=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index("ix_iceberg_prunability_lookup",
              "bucket", "table_prefix", "column_name", unique=True),
    )

    def to_dict(self) -> dict:
        return {
            "id":                   self.id,
            "bucket":               self.bucket,
            "table_prefix":         self.table_prefix,
            "column_name":          self.column_name,
            "stats_coverage_pct":   self.stats_coverage_pct,
            "bounds_overlap_ratio": self.bounds_overlap_ratio,
            "singleton_ratio":      self.singleton_ratio,
            "ndv_estimate":         self.ndv_estimate,
            "sample_count":         self.sample_count,
            "created_at":           self.created_at.isoformat() if self.created_at else None,
            "updated_at":           self.updated_at.isoformat() if self.updated_at else None,
        }


# ── Phase 157 (2026-06-26) -- Report Permissions ─────────────────────


class BusinessReportGrant(Base):
    """Per-user (or per-group) grant on a Business Report.

    Phase 157 -- replaces the all-or-nothing
    (owner | owner_group | role_whitelist | published) access model
    with explicit fine-grained grants:

      * ``view``     -- can see the report card + run with viewer prefs
      * ``runner``   -- can run + change filters/params + slicers
      * ``editor``   -- can edit the report definition itself
      * ``owner``    -- equivalent to the original owner (re-share, delete)

    Either ``username`` OR ``group_id`` is set (XOR -- enforced by the
    permission service, not a CHECK constraint, since SQLite + the
    auto-migrate path don't reliably enforce CHECKs).

    ``grant_until`` -- optional auto-expiry timestamp for contractor /
    time-bound access (Tier 3).  NULL = permanent.

    ``granted_by`` -- audit trail; who issued the grant.
    """
    __tablename__ = "business_report_grants"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    report_id     = Column(Integer, nullable=False, index=True)
    username      = Column(String(100), nullable=True, index=True)
    group_id      = Column(Integer, nullable=True, index=True)
    level         = Column(String(20), nullable=False, default="view")
    grant_until   = Column(DateTime, nullable=True)
    reason        = Column(Text, nullable=True)
    granted_by    = Column(String(100), nullable=False)
    granted_at    = Column(DateTime,
                            default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index("ix_br_grants_report_user", "report_id", "username"),
        Index("ix_br_grants_report_group", "report_id", "group_id"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":          self.id,
            "report_id":   self.report_id,
            "username":    self.username,
            "group_id":    self.group_id,
            "level":       self.level,
            "grant_until": self.grant_until.isoformat() if self.grant_until else None,
            "reason":      self.reason,
            "granted_by":  self.granted_by,
            "granted_at":  self.granted_at.isoformat() if self.granted_at else None,
        }


class BusinessReportAccessRequest(Base):
    """User-initiated request for access to a report they can't see.

    Phase 157 -- when a user clicks "Request access" on a 403'd report,
    a row lands here.  Owner sees it on their dashboard + approves /
    denies.  On approve, the service writes a ``BusinessReportGrant``
    row and resolves the request.
    """
    __tablename__ = "business_report_access_requests"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    report_id     = Column(Integer, nullable=False, index=True)
    requester     = Column(String(100), nullable=False, index=True)
    requested_level = Column(String(20), nullable=False, default="view")
    reason        = Column(Text, nullable=True)
    status        = Column(String(20), nullable=False, default="pending")
    # status in {pending, approved, denied, withdrawn}
    decided_by    = Column(String(100), nullable=True)
    decided_at    = Column(DateTime, nullable=True)
    decision_note = Column(Text, nullable=True)
    granted_id    = Column(Integer, nullable=True)  # FK -> BusinessReportGrant on approve
    created_at    = Column(DateTime,
                            default=lambda: datetime.now(timezone.utc))

    __table_args__ = (
        Index("ix_br_access_req_status", "report_id", "status"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":             self.id,
            "report_id":      self.report_id,
            "requester":      self.requester,
            "requested_level": self.requested_level,
            "reason":         self.reason,
            "status":         self.status,
            "decided_by":     self.decided_by,
            "decided_at":     self.decided_at.isoformat() if self.decided_at else None,
            "decision_note":  self.decision_note,
            "granted_id":     self.granted_id,
            "created_at":     self.created_at.isoformat() if self.created_at else None,
        }


class BusinessReportCertificationRequest(Base):
    """Approval workflow for the ``is_certified`` flag.

    Phase 157 -- replaces the manual admin-only flip of ``is_certified``
    with a request → review → approve loop.  Authors request, admins
    approve.  Audit trail preserved.
    """
    __tablename__ = "business_report_certification_requests"

    id            = Column(Integer, primary_key=True, autoincrement=True)
    report_id     = Column(Integer, nullable=False, index=True)
    requested_by  = Column(String(100), nullable=False)
    rationale     = Column(Text, nullable=True)
    status        = Column(String(20), nullable=False, default="pending")
    # pending, approved, denied, withdrawn
    reviewed_by   = Column(String(100), nullable=True)
    reviewed_at   = Column(DateTime, nullable=True)
    review_note   = Column(Text, nullable=True)
    created_at    = Column(DateTime,
                            default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "report_id":    self.report_id,
            "requested_by": self.requested_by,
            "rationale":    self.rationale,
            "status":       self.status,
            "reviewed_by":  self.reviewed_by,
            "reviewed_at":  self.reviewed_at.isoformat() if self.reviewed_at else None,
            "review_note":  self.review_note,
            "created_at":   self.created_at.isoformat() if self.created_at else None,
        }


class BusinessReportPermissionEvent(Base):
    """Audit log for every permission-affecting action.

    Phase 157 -- single source of truth for ``who did what when``
    on report permissions.  Granular events let the UI render a
    legible history per report (grants added/removed, certification
    requested/approved, shares created/revoked, access requested/
    decided).
    """
    __tablename__ = "business_report_permission_events"

    id           = Column(Integer, primary_key=True, autoincrement=True)
    report_id    = Column(Integer, nullable=False, index=True)
    event_type   = Column(String(40), nullable=False)
    # event_type in {grant_added, grant_removed, grant_expired,
    #                access_requested, access_approved, access_denied,
    #                certification_requested, certification_approved,
    #                certification_denied, share_token_created,
    #                share_token_revoked, embed_token_created,
    #                embed_token_revoked, owner_changed}
    actor        = Column(String(100), nullable=False)
    subject      = Column(String(100), nullable=True)
    # The user / group affected by the event (when applicable).
    metadata_json = Column(JSON, nullable=True)
    # Free-form details (level, expiry, token id, etc.).
    created_at   = Column(DateTime,
                           default=lambda: datetime.now(timezone.utc),
                           index=True)

    __table_args__ = (
        Index("ix_br_perm_events_report_time",
              "report_id", "created_at"),
    )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":         self.id,
            "report_id":  self.report_id,
            "event_type": self.event_type,
            "actor":      self.actor,
            "subject":    self.subject,
            "metadata":   self.metadata_json,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


# ═══════════════════════════════════════════════════════════════════════
#  Phase 146-B — Logical Tables (multi-engine PV name bridge)
# ═══════════════════════════════════════════════════════════════════════
#
# A logical table is a name that maps to different physical references
# per connection.  A single Published View can then use
# ``__logical__:orders`` and have it resolve to (say)
# ``MY_DB.PUBLIC.orders`` on Snowflake and ``__registered__:orders``
# on S3 -- ONE PV serves multiple engines.
#
# Design notes:
#   * ``logical_name`` is globally unique + case-preserving.  Case-
#     insensitive lookup happens at resolve time so operators can
#     write ``__logical__:Orders`` or ``__logical__:orders``.
#   * Each (logical_table, connection) binding stores a
#     ``physical_ref`` (e.g. ``schema.table`` for SQL or
#     ``__registered__:name`` for S3).  Substitution is textual at
#     execute time.
#   * Publish-time validation refuses a PV that references a logical
#     name lacking a binding on any member of
#     ``allowed_engine_connections``.  Prevents "consumer picks
#     ?engine=42 and hits an unbound logical".
#   * FK ``ON DELETE CASCADE`` on both sides so deleting a connection
#     doesn't leave orphan bindings (or vice versa).
#
# See Phase 146-A shipped in PublishedView.allowed_engine_connections;
# this layer is the second half.


class LogicalTable(Base):
    """A named table alias resolved per-connection at execute time."""
    __tablename__ = "logical_tables"

    id           = Column(Integer, primary_key=True, index=True)
    logical_name = Column(String(100), unique=True, nullable=False, index=True)
    description  = Column(Text, nullable=True)
    created_by   = Column(String(100), nullable=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                          onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "logical_name": self.logical_name,
            "description":  self.description,
            "created_by":   self.created_by,
            "created_at":   self.created_at.isoformat() if self.created_at else None,
            "updated_at":   self.updated_at.isoformat() if self.updated_at else None,
        }


class LogicalTableBinding(Base):
    """Per-connection resolution of a logical table.

    ``physical_ref`` shape is engine-specific:
      * SQL connectors: ``SCHEMA.TABLE`` (fully qualified) OR just
        ``TABLE`` when the connection's ``schema`` default is set.
      * S3:              ``__registered__:orders`` -- reused by the
                          existing S3 registered-tables layer.
      * Federation:      ``fed:{federation_view_id}:orders``.

    A single (logical_table_id, connection_id) is UNIQUE -- one binding
    per logical name per connection.  Deleting either parent CASCADES.
    """
    __tablename__ = "logical_table_bindings"
    __table_args__ = (
        UniqueConstraint(
            "logical_table_id", "connection_id",
            name="uq_logical_table_bindings",
        ),
    )

    id                = Column(Integer, primary_key=True, index=True)
    logical_table_id  = Column(
        Integer,
        ForeignKey("logical_tables.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    connection_id     = Column(
        Integer,
        ForeignKey("connections.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    physical_ref      = Column(String(500), nullable=False)
    created_by        = Column(String(100), nullable=True)
    created_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at        = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                                onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":                self.id,
            "logical_table_id":  self.logical_table_id,
            "connection_id":     self.connection_id,
            "physical_ref":      self.physical_ref,
            "created_by":        self.created_by,
            "created_at":        self.created_at.isoformat() if self.created_at else None,
            "updated_at":        self.updated_at.isoformat() if self.updated_at else None,
        }




# ══════════════════════════════════════════════════════════════════════
#  FEED PIPELINE STEPS (2026-09-05) — the row per STEP FeedGen never had
# ══════════════════════════════════════════════════════════════════════
#
# The gap these five tables close is stated in
# ``docs/FABLE_CONTEXT_STEPS_2026_09_05.html``: the feed engine performs
# named stages and stores them as ONE dict of DURATIONS
# (``FeedRun.stage_timings``), so the run screen renders logs rather than
# steps and ``started_at`` is null for every row.  OG's
# ``OTG_AIRFLOW_DAG_RUN_DETAIL`` has had a row per step for years.
#
# The shape is DELIBERATELY the dataflow one.  ``feed_step_types`` mirrors
# ``dataflow_stage_types`` and ``feed_custom_step_types`` mirrors
# ``dataflow_custom_stage_types`` COLUMN FOR COLUMN (plus the three feed
# declarations dataflow has no use for: REQUIRES / PRODUCES /
# APPLIES_WHEN), so one UI form renderer serves both catalogues and the
# idempotency vocabulary is imported from ``core/dataflow/base.py`` rather
# than declared twice.  What is NOT shared is the RUN model: a feed run is
# a feed run (BRD §2.2), and a feed author never composes a graph.
#
# Why they are separate TABLES from their dataflow twins: the two
# contracts differ at execute() — a dataflow stage receives a
# ``StageContext`` of inputs/outputs dicts, a feed step receives the
# artifact, the row count and the business date — and OG's run_id=969000
# incident is exactly what happens when a router cannot tell which
# vocabulary owns a step name.  One shape, two namespaces, no ambiguity.

#: Closed status vocabulary for a step attempt.  ``core/feed/step_model``
#: imports THIS tuple so the code's refusals and the DB CHECK constraint
#: can never drift -- the same arrangement FEED_FILE_RUN_STATUSES uses.
#: OG declared its status set as CHECK constraints on two tables with
#: DIFFERENT members; one vocabulary, one place.
FEED_RUN_STEP_STATUSES = (
    "not_started",   # planned, nothing executed yet -- OG's "Not Started"
    "running",       # a worker holds it
    "completed",     # green
    "failed",        # raised; the run halts here
    "refused",       # a correctness gate said no -- NOT the same as failed
    "skipped",       # its predicate did not apply on this run
    "cancelled",     # a human stopped the run
)

#: Statuses that count as GREEN for "may the next step run / may this one
#: be re-run".  ``refused`` is deliberately absent: a refusal is a
#: correctness verdict, and treating it as green is how a gate becomes a
#: cap.
FEED_RUN_STEP_GREEN_STATUSES = ("completed", "skipped")

#: Who executes a step.  ``engine`` = the work already lives inside
#: ``core/feed_engine.py`` and the row is a RECORD of it; ``runner`` =
#: ``core/feed/step_model/runner.py`` calls ``execute(ctx)``.  The
#: distinction is load-bearing for re-run: an engine step cannot be re-run
#: on its own because its state lives in the engine's local variables, and
#: saying so is better than offering a button that lies.
FEED_STEP_EXECUTORS = ("engine", "runner")


class FeedStepType(Base):
    """Catalogue row for one registered feed pipeline step.

    Written at boot by ``core.feed.step_model.registry.sync_to_db`` so the
    admin UI can list steps -- and RENDER THEIR PARAMETER FORM from
    ``config_schema`` -- without importing Python.  Same job, same
    columns, as ``dataflow_stage_types``.
    """
    __tablename__ = "feed_step_types"

    name             = Column(String(80), primary_key=True)
    display_name     = Column(String(160), nullable=True)
    category         = Column(String(40), nullable=False, index=True)
    class_path       = Column(String(255), nullable=False)
    description      = Column(Text, nullable=True)
    #: The parameter declaration.  THIS is what the UI renders, so a step
    #: registered from the database alone gets a working form with no
    #: frontend deploy.
    config_schema    = Column(JSON, nullable=True)
    #: Artifact kinds this step consumes / produces.  The planner derives
    #: the DAG from these two lists and nothing else -- which is why the
    #: planner contains no step name.
    requires         = Column(JSON, nullable=True)
    produces         = Column(JSON, nullable=True)
    #: The declarative predicate over the run PROFILE that decides whether
    #: this step is in scope.  JSON, not code, so a DB-registered plugin
    #: carries it too and the UI can show "why did this not run".
    applies_when     = Column(JSON, nullable=True)
    #: Ordering the artifact graph cannot express (list of step names).
    after            = Column(JSON, nullable=True)
    idempotency      = Column(String(20), nullable=False, default="unsafe")
    #: Tri-state ON PURPOSE.  NULL = the step never declared, which means
    #: NOT rerunnable -- OG defaulted RETRY_SAFE true and a
    #: non-idempotent step was retried into 50M duplicate rows.  A default
    #: of False here would look identical to a deliberate False and lose
    #: the "you forgot to declare" diagnosis.
    rerunnable       = Column(Boolean, nullable=True)
    executor         = Column(String(20), nullable=False, default="runner")
    max_attempts     = Column(Integer, nullable=False, default=1)
    #: builtin | discovered | plugin -- where the class came from.
    origin           = Column(String(20), nullable=True)
    is_active        = Column(Boolean, default=True)
    created_at       = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at       = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                              onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name":          self.name,
            "display_name":  self.display_name or (self.name or "").replace("_", " ").title(),
            "category":      self.category,
            "class_path":    self.class_path,
            "description":   self.description,
            "config_schema": self.config_schema or {},
            "requires":      list(self.requires or []),
            "produces":      list(self.produces or []),
            "applies_when":  self.applies_when or {},
            "after":         list(self.after or []),
            "idempotency":   self.idempotency,
            "rerunnable":    self.rerunnable,
            "executor":      self.executor,
            "max_attempts":  int(self.max_attempts or 1),
            "origin":        self.origin,
            "is_active":     bool(self.is_active),
            "created_at":    self.created_at.isoformat() if self.created_at else None,
            "updated_at":    self.updated_at.isoformat() if self.updated_at else None,
        }


class FeedCustomStepType(Base):
    """A step registered from the DATABASE -- the plugin path.

    "if new workflow comes .... we just need to install plugin etc".
    Make the module importable, insert one row: the registry importlib's
    it at boot and the step appears in the catalogue, in the planner and
    in the UI form with no engine change and no redeploy.

    Columns are ``dataflow_custom_stage_types``' columns.  ``step_module``
    / ``step_class`` are its ``etl_module`` / ``etl_class`` renamed for
    what they point AT: a ``FeedPipelineStep`` subclass, not an ETL step
    (several dataflow bridge rows point at ``ETL/steps/*`` classes that
    raise ``ModuleNotFoundError`` in this image -- registered is not
    runnable, and the two must not share a namespace).
    """
    __tablename__ = "feed_custom_step_types"

    id            = Column(Integer, primary_key=True, index=True)
    name          = Column(String(80), unique=True, nullable=False, index=True)
    category      = Column(String(40), nullable=False)
    description   = Column(Text, nullable=True)
    step_module   = Column(String(255), nullable=False)
    step_class    = Column(String(120), nullable=False)
    config_schema = Column(JSON, nullable=True)
    requires      = Column(JSON, nullable=True)
    produces      = Column(JSON, nullable=True)
    applies_when  = Column(JSON, nullable=True)
    after         = Column(JSON, nullable=True)
    idempotency   = Column(String(20), nullable=True)
    #: NULL means UNDECLARED means NOT rerunnable.  See FeedStepType.
    rerunnable    = Column(Boolean, nullable=True)
    max_attempts  = Column(Integer, nullable=True)
    is_active     = Column(Boolean, default=True, index=True)
    created_by    = Column(String(100), nullable=True)
    created_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at    = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                            onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":            self.id,
            "name":          self.name,
            "category":      self.category,
            "description":   self.description,
            "step_module":   self.step_module,
            "step_class":    self.step_class,
            "config_schema": self.config_schema or {},
            "requires":      list(self.requires or []),
            "produces":      list(self.produces or []),
            "applies_when":  self.applies_when or {},
            "after":         list(self.after or []),
            "idempotency":   self.idempotency,
            "rerunnable":    self.rerunnable,
            "max_attempts":  self.max_attempts,
            "is_active":     bool(self.is_active),
            "created_by":    self.created_by,
            "created_at":    self.created_at.isoformat() if self.created_at else None,
            "updated_at":    self.updated_at.isoformat() if self.updated_at else None,
        }


class FeedFlow(Base):
    """A named, reusable set of extra steps a feed can be MAPPED to.

    "if someone using just map these steps".  A feed names a flow; the
    flow names steps and their parameter values.  Changing the flow
    changes every feed that uses it -- which is the point, and why a flow
    is administered rather than authored per feed (BRD §2.2 rules out
    per-feed code, and a feed author selecting from a governed set is not
    a stage editor).

    The flow does NOT carry order.  Order is derived from the steps' own
    REQUIRES/PRODUCES declarations at plan time, so adding a step to a
    flow cannot put it in the wrong place -- OG's step_mapping.yaml was a
    VOCABULARY and the SEQ lived with the task; here the vocabulary is the
    registry and the order lives in the artifact graph.
    """
    __tablename__ = "feed_flows"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(120), unique=True, nullable=False, index=True)
    description = Column(Text, nullable=True)
    is_active   = Column(Boolean, default=True, index=True)
    created_by  = Column(String(100), nullable=True)
    created_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at  = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                          onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":          self.id,
            "name":        self.name,
            "description": self.description,
            "is_active":   bool(self.is_active),
            "created_by":  self.created_by,
            "created_at":  self.created_at.isoformat() if self.created_at else None,
            "updated_at":  self.updated_at.isoformat() if self.updated_at else None,
        }


class FeedFlowStep(Base):
    """One configured INSTANCE of a step inside a flow.

    Identity is ``(flow_id, alias)`` so the same step type can appear
    twice with different parameters -- a second row-count floor on a
    different column, two deliveries to two counterparties.  ``params``
    holds the values for that instance's ``config_schema``; calendar
    tokens (``{{business_date}}``) are resolved per run through
    ``core/feed/param_resolver.py`` -- the SAME resolver feed SQL uses,
    not a copy of it.

    ``seq`` is a TIE-BREAK, not the order.  Two steps the artifact graph
    leaves unordered run in the same level (they are independent, so they
    may run in parallel); seq only makes the numbering deterministic.
    """
    __tablename__ = "feed_flow_steps"
    __table_args__ = (
        UniqueConstraint("flow_id", "alias", name="uq_feed_flow_steps_alias"),
        Index("ix_feed_flow_steps_flow", "flow_id", "seq"),
    )

    id           = Column(Integer, primary_key=True, index=True)
    flow_id      = Column(Integer,
                          ForeignKey("feed_flows.id", ondelete="CASCADE"),
                          nullable=False, index=True)
    #: The registered step name (feed_step_types.name).  No FK: a step
    #: type can be un-registered by removing its class, and the flow row
    #: must survive to say WHY the plan refuses -- an UnknownStep refusal
    #: naming the row beats a silently vanished mapping.
    step_type    = Column(String(80), nullable=False)
    alias        = Column(String(80), nullable=False)
    params       = Column(JSON, nullable=True)
    seq          = Column(Integer, nullable=False, default=100)
    max_attempts = Column(Integer, nullable=True)
    enabled      = Column(Boolean, default=True)
    created_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at   = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                           onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":           self.id,
            "flow_id":      self.flow_id,
            "step_type":    self.step_type,
            "alias":        self.alias,
            "params":       self.params or {},
            "seq":          int(self.seq or 0),
            "max_attempts": self.max_attempts,
            "enabled":      bool(self.enabled),
            "created_at":   self.created_at.isoformat() if self.created_at else None,
            "updated_at":   self.updated_at.isoformat() if self.updated_at else None,
        }


class FeedRunStep(Base):
    """ONE ROW PER STEP PER ATTEMPT.  This is the table the operator asked
    for: "each steps will have start end time, total record count".

    Identity is ``(feed_run_id, alias, attempt)`` -- a re-run APPENDS.  OG
    kept a RETRY_COUNT counter on one row, so a retried step overwrote its
    own record and what the first attempt did was lost.  History is never
    overwritten here.

    ``rows_in`` / ``rows_out`` are BigInteger deliberately.  A measured
    counter typed Integer is a 2,147,483,647 ceiling, and the overflow
    strands the TERMINAL write -- the step would finish and the row would
    stay 'running' forever.
    """
    __tablename__ = "feed_run_steps"
    __table_args__ = (
        UniqueConstraint("feed_run_id", "alias", "attempt",
                         name="uq_feed_run_steps_attempt"),
        Index("ix_feed_run_steps_run_seq", "feed_run_id", "seq"),
        Index("ix_feed_run_steps_run_status", "feed_run_id", "status"),
        CheckConstraint(
            "status IN ({})".format(
                ", ".join("'{}'".format(s) for s in FEED_RUN_STEP_STATUSES)),
            name="ck_feed_run_steps_status",
        ),
    )

    id             = Column(Integer, primary_key=True, index=True)
    feed_run_id    = Column(Integer,
                            ForeignKey("feed_runs.id", ondelete="CASCADE"),
                            nullable=False, index=True)
    #: Denormalised so the estate-wide "what has not started today" screen
    #: needs no join -- the property that makes OG's Not Started counts
    #: free rather than a separate feature.
    feed_config_id = Column(Integer, nullable=True, index=True)
    business_date  = Column(Date, nullable=True, index=True)
    #: The execution this attempt belongs to (feed_executions.execution_id),
    #: so a step row can be tied back to its log capture.
    execution_id   = Column(String(100), nullable=True, index=True)

    alias          = Column(String(80), nullable=False)
    step_type      = Column(String(80), nullable=False)
    seq            = Column(Integer, nullable=False, default=0)
    #: Which parallel WAVE this step sits in.  Steps sharing a level have
    #: no declared dependency between them; the number is derived, and it
    #: is what makes "these three ran at once" visible instead of implied.
    level          = Column(Integer, nullable=False, default=0)
    #: Aliases this step waited on, from the artifact graph.  Stored so
    #: the re-run gate reads the plan THIS RUN used rather than re-deriving
    #: it from a registry that may have changed since.
    depends_on     = Column(JSON, nullable=True)
    executor       = Column(String(20), nullable=False, default="runner")

    status         = Column(String(20), nullable=False, default="not_started",
                            index=True)
    attempt        = Column(Integer, nullable=False, default=1)
    max_attempts   = Column(Integer, nullable=False, default=1)

    started_at     = Column(DateTime, nullable=True)
    ended_at       = Column(DateTime, nullable=True)
    duration_seconds = Column(Float, nullable=True)

    rows_in        = Column(BigInteger, nullable=True)
    rows_out       = Column(BigInteger, nullable=True)

    #: The step's OWN resolved parameters -- what it actually ran with,
    #: after calendar-token resolution, with secrets masked.  A value
    #: resolved for a decision and then thrown away will disagree with
    #: what the system did.
    params         = Column(JSON, nullable=True)
    #: Artifacts this attempt produced ({kind: value}); read by later
    #: steps and by the re-run.
    outputs        = Column(JSON, nullable=True)
    error          = Column(Text, nullable=True)
    #: Which pod ran it.  We are multi-pod; without this a step record is
    #: unusable at 3am.
    worker_node    = Column(String(120), nullable=True)
    #: Set on a re-run attempt so the audit trail says who asked.
    triggered_by   = Column(String(100), nullable=True)
    created_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id":               self.id,
            "feed_run_id":      self.feed_run_id,
            "feed_config_id":   self.feed_config_id,
            "business_date":    self.business_date.isoformat() if self.business_date else None,
            "execution_id":     self.execution_id,
            "alias":            self.alias,
            "step_type":        self.step_type,
            "seq":              int(self.seq or 0),
            "level":            int(self.level or 0),
            "depends_on":       list(self.depends_on or []),
            "executor":         self.executor,
            "status":           self.status,
            "attempt":          int(self.attempt or 1),
            "max_attempts":     int(self.max_attempts or 1),
            "started_at":       self.started_at.isoformat() if self.started_at else None,
            "ended_at":         self.ended_at.isoformat() if self.ended_at else None,
            "duration_seconds": self.duration_seconds,
            "rows_in":          self.rows_in,
            "rows_out":         self.rows_out,
            "params":           self.params or {},
            "outputs":          self.outputs or {},
            "error":            self.error,
            "worker_node":      self.worker_node,
            "triggered_by":     self.triggered_by,
            "created_at":       self.created_at.isoformat() if self.created_at else None,
        }


# ── Public API ──────────────────────────────────────────────────────────
# What this module DEFINES, determined from the SOURCE (module-level
# class/def/assignment) -- NOT from obj.__module__.  ``Base =
# declarative_base()`` is defined here but reports __module__ as
# sqlalchemy.orm.decl_api, so a runtime filter silently drops it, and
# dropping Base breaks Base.metadata.create_all() at startup.
#
# Names this module merely IMPORTS (Column, Boolean, Any, Dict, ...)
# stay out: a star import bound them too, but re-importing them into
# database.py -- which imports them itself -- is 44 redefinitions of
# symbols nobody meant to re-export.
###############################################################################
# Clockwork authoring plane — 2026-09-10
#
# docs/CLOCKWORK_PLATFORM_PLAN_V2_2026_09_10.html.  These are the
# QUERYSTUDIO-OWNED tables: what a person authors, requests, or reads.
# The FIRE LOG and the STEP rows are CLOCKWORK-OWNED and are deliberately
# NOT modelled here — ``core/clockwork/fire_log.py`` reflects them at
# runtime.  Two DDLs for one table is a drift defect.
#
# No secret material lives in any of these rows.  A job names a
# ``connections`` row; the connection carries its ``system_account_id``;
# the system account is the Vault mapping; ``connection_access`` is the
# ACL.  Nothing here duplicates that.
###############################################################################


def _utcnow():
    return datetime.now(timezone.utc)


class ClockworkJob(Base):
    """One scheduled job: identity + schedule + a JSON guarded sequence.

    ``steps`` is JSON on purpose (plan v2 §10): one row, one version, no
    torn read mid-edit.  ``version`` is the optimistic-concurrency token —
    a save carries ``expected_version`` and a mismatch is a 409, never a
    silent overwrite.  ``idempotent`` is TRI-STATE: NULL means "never
    declared", which renders as unknown and disables re-drive.
    ``authority`` names the deployment that may fire it (plan v1 §8);
    NULL is "not mine" on every deployment.
    """
    __tablename__ = "clockwork_jobs"

    id          = Column(Integer, primary_key=True, index=True)
    name        = Column(String(100), nullable=False, unique=True, index=True)
    description = Column(Text, nullable=True)
    tenant      = Column(String(40), nullable=False, default="querystudio",
                         server_default="querystudio")
    enabled     = Column(Boolean, nullable=False, default=False, server_default=sa_false())
    owner       = Column(String(100), nullable=True)
    owner_group_id = Column(Integer, nullable=True, index=True)

    cron        = Column(String(200), nullable=False)
    timezone    = Column(String(64), nullable=False, default="UTC", server_default="UTC")
    calendar_id = Column(Integer, nullable=True)
    weekend_days = Column(JSON, nullable=True)
    misfire_grace_seconds = Column(Integer, nullable=False, default=300, server_default="300")
    idempotent  = Column(Boolean, nullable=True)
    authority   = Column(String(100), nullable=True, index=True)

    connection_id = Column(Integer, nullable=True, index=True)
    steps       = Column(JSON, nullable=False, default=list)
    access      = Column(JSON, nullable=True)
    # 2026-09-10 — THE PROJECTION.  The definition in the dispatcher core's
    # grammar, derived from this row by core/clockwork/projection.py and
    # validated by the core's own validate_job, written by the ONE writer
    # of this row in the same transaction as the fields it derives from.
    # NULL = "this row cannot dispatch"; the clockwork_dispatch_jobs view
    # (core/clockwork/sql/CLOCKWORK_DISPATCH.sql) excludes it.  An ENABLED
    # job with NULL here is refused at the writer.
    # none_as_null=True: a Python None is stored as SQL NULL, never as the
    # JSON text 'null' -- the dispatch view's ``IS NOT NULL`` is what keeps
    # an unprojectable row out of the dispatcher's read, and a JSON 'null'
    # passes that test on every dialect (2026-09-10: the calendar
    # re-projection is the first writer to NULL an EXISTING row).
    dispatch_definition = Column(JSON(none_as_null=True), nullable=True)

    version     = Column(Integer, nullable=False, default=1, server_default="1")
    created_by  = Column(String(100), nullable=True)
    created_at  = Column(DateTime, default=_utcnow)
    updated_by  = Column(String(100), nullable=True)
    updated_at  = Column(DateTime, default=_utcnow, onupdate=_utcnow)

    def definition(self) -> Dict[str, Any]:
        """The AUTHORABLE definition — exactly what a version snapshot holds."""
        return {
            "name": self.name,
            "description": self.description or "",
            "enabled": bool(self.enabled),
            "tenant": self.tenant or "querystudio",
            "owner": self.owner or "",
            "cron": self.cron,
            "timezone": self.timezone or "UTC",
            "calendar_id": self.calendar_id,
            "weekend_days": self.weekend_days,
            "misfire_grace_seconds": self.misfire_grace_seconds,
            "idempotent": self.idempotent,
            "authority": self.authority,
            "connection_id": self.connection_id,
            "steps": list(self.steps or []),
            "access": self.access or {"edit": [], "enable": [], "fire": []},
        }

    def to_dict(self) -> Dict[str, Any]:
        d = self.definition()
        d.update({
            "id": self.id,
            "version": self.version,
            "owner_group_id": self.owner_group_id,
            "secrets": [],   # by design: no secret material on a job (plan v2 §3.1)
            # What the dispatcher would run, or null = "this row cannot
            # dispatch" (and is absent from the dispatch view).
            "dispatchable": self.dispatch_definition is not None,
            "dispatch_definition": self.dispatch_definition,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_by": self.updated_by,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        })
        return d


class ClockworkJobVersion(Base):
    """One snapshot per save.  Immutable; the diff view reads two of these."""
    __tablename__ = "clockwork_job_versions"
    __table_args__ = (UniqueConstraint("job_id", "version", name="uq_clockwork_job_version"),)

    id         = Column(Integer, primary_key=True, index=True)
    job_id     = Column(Integer, nullable=False, index=True)
    version    = Column(Integer, nullable=False)
    definition = Column(JSON, nullable=False)
    note       = Column(String(255), nullable=True)
    created_by = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=_utcnow)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "job_id": self.job_id, "version": self.version,
            "definition": self.definition, "note": self.note,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class ClockworkQueryTemplate(Base):
    """Plan v2 §5: an admin-authored, named, versioned scalar query a job
    references by id, supplying bind values only.  The only way SQL text
    reaches a job."""
    __tablename__ = "clockwork_query_templates"

    id              = Column(Integer, primary_key=True, index=True)
    name            = Column(String(100), nullable=False, unique=True, index=True)
    description     = Column(Text, nullable=True)
    connection_type = Column(String(50), nullable=False, default="oracle", server_default="oracle")
    sql_text        = Column(Text, nullable=False)
    binds           = Column(JSON, nullable=False, default=list)      # declared :bind names
    version         = Column(Integer, nullable=False, default=1, server_default="1")
    is_active       = Column(Boolean, nullable=False, default=True, server_default=sa_true())
    # 2026-09-11 (audit remainder, item 3) -- the author's DECLARATION that the
    # statement reaches no function, view, virtual column or VPD/FGA policy that
    # writes.  Carried by the projection as ``template_side_effect_free``; with
    # it the core records an execution-time error as FAILED instead of paging
    # UNKNOWN.  Default false = unknown = unsafe (the retry-safety rule).  A
    # COLUMN: ``database._MIGRATIONS["clockwork_query_templates"]`` adds it.
    side_effect_free = Column(Boolean, nullable=False, default=False, server_default=sa_false())
    created_by      = Column(String(100), nullable=True)
    created_at      = Column(DateTime, default=_utcnow)
    updated_by      = Column(String(100), nullable=True)
    updated_at      = Column(DateTime, default=_utcnow, onupdate=_utcnow)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "name": self.name, "description": self.description,
            "connection_type": self.connection_type, "sql_text": self.sql_text,
            "binds": list(self.binds or []), "version": self.version,
            "is_active": bool(self.is_active),
            "side_effect_free": bool(self.side_effect_free),
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_by": self.updated_by,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class ClockworkTaskType(Base):
    """Plan v2 §6: each deployment writes its routability verdict for every
    registered task type at boot.  The UI offers only types SOME live
    deployment reports routable, greying the rest WITH the reason.
    Written by Clockwork; QueryStudio only reads."""
    __tablename__ = "clockwork_task_types"
    __table_args__ = (UniqueConstraint("deployment_id", "task_type", name="uq_clockwork_task_type"),)

    id            = Column(Integer, primary_key=True, index=True)
    deployment_id = Column(String(100), nullable=False, index=True)
    task_type     = Column(String(60), nullable=False, index=True)
    routable      = Column(Boolean, nullable=False, default=False, server_default=sa_false())
    reason        = Column(Text, nullable=True)
    config_schema = Column(JSON, nullable=True)
    outputs       = Column(JSON, nullable=True)
    reported_at   = Column(DateTime, default=_utcnow)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "deployment_id": self.deployment_id, "task_type": self.task_type,
            "routable": bool(self.routable), "reason": self.reason,
            "config_schema": self.config_schema, "outputs": self.outputs,
            "reported_at": self.reported_at.isoformat() if self.reported_at else None,
        }


class ClockworkDeployment(Base):
    """A Clockwork deployment's heartbeat: who it is, which environment it
    declares, when it last ticked.  Written by Clockwork; read by the
    'why did this not run' computation (NOT_OBSERVED needs a last tick)."""
    __tablename__ = "clockwork_deployments"

    id            = Column(Integer, primary_key=True, index=True)
    deployment_id = Column(String(100), nullable=False, unique=True, index=True)
    environment   = Column(String(40), nullable=True)
    version       = Column(String(40), nullable=True)
    started_at    = Column(DateTime, nullable=True)
    last_tick_at  = Column(DateTime, nullable=True)
    detail        = Column(JSON, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "deployment_id": self.deployment_id, "environment": self.environment,
            "version": self.version, "authority": self.deployment_id,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "last_tick_at": self.last_tick_at.isoformat() if self.last_tick_at else None,
            "detail": self.detail,
        }


class ClockworkSetting(Base):
    """Plan v2 §6: everything that is not bootstrap becomes a UI-editable
    row — tick cadence, grace, stale-claim window, row caps."""
    __tablename__ = "clockwork_settings"

    key         = Column(String(128), primary_key=True)
    value       = Column(JSON, nullable=True)
    description = Column(Text, nullable=True)
    updated_by  = Column(String(100), nullable=True)
    updated_at  = Column(DateTime, default=_utcnow, onupdate=_utcnow)

    def to_dict(self) -> Dict[str, Any]:
        return {"key": self.key, "value": self.value, "description": self.description,
                "updated_by": self.updated_by,
                "updated_at": self.updated_at.isoformat() if self.updated_at else None}


#: 2026-09-11 -- THE MANUAL-REQUEST ARBITER.  A request's fire key is a
#: fresh nonce per button press, so the fire log's PRIMARY KEY arbitrates
#: nothing between two presses: two "run now" requests for one job were two
#: PENDING rows, two keys, two claims, two runs (proved on the memory
#: backend and on a real PostgreSQL before this existed).  The rule is
#: "at most ONE outstanding request per job", and it is a CONSTRAINT, not a
#: check: a partial UNIQUE index on ``job_id`` over the non-terminal
#: statuses.  PENDING and CLAIMED are outstanding; DONE / REFUSED / EXPIRED
#: free the slot.  The dispatcher's PENDING -> CLAIMED move keeps the row
#: inside the predicate, so the claim never trips it.  Fresh databases get
#: it from ``create_all``; existing ones from
#: ``core/clockwork/dispatch_views.ensure_views`` (an index on an existing
#: table is a COLUMN-shaped change: create_all skips the table).
MANUAL_OUTSTANDING_STATUSES = ("PENDING", "CLAIMED")
#: 2026-09-11 -- the ONE status the AUTHORING plane writes on a request:
#: a request stuck CLAIMED by a dead pod, retired by an admin's resolution
#: recorded on its fire (``mixin_clockwork.record_clockwork_fire_resolution``).
#: Outside the arbiter predicate, so it frees the slot; the dispatcher never
#: writes it and never reads it (contract section 3).
MANUAL_RESOLVED = "RESOLVED"
MANUAL_ARBITER_INDEX = "ux_clockwork_manual_requests_outstanding"
MANUAL_ARBITER_PREDICATE = "status IN ('PENDING', 'CLAIMED')"


class ClockworkManualRequest(Base):
    """A manual fire is a REQUEST ROW.  QueryStudio writes PENDING with a
    fire key it minted from immutable inputs (request id + requested
    time); the Clockwork deployment claims it under its own protocol.
    QueryStudio never executes a job — that would be a second claim
    protocol.  ``kind`` is ``run_now`` or ``resume`` (plan v2 §1: a resume
    is a NEW occurrence carrying the parent's key).

    At most ONE request per job may be outstanding (PENDING or CLAIMED):
    ``MANUAL_ARBITER_INDEX`` above, spelled once for both dialects the
    authoring plane runs on (PostgreSQL and SQLite both take a partial
    unique index)."""
    __tablename__ = "clockwork_manual_requests"
    __table_args__ = (
        Index(MANUAL_ARBITER_INDEX, "job_id", unique=True,
              postgresql_where=sa_text(MANUAL_ARBITER_PREDICATE),
              sqlite_where=sa_text(MANUAL_ARBITER_PREDICATE)),
    )

    id              = Column(Integer, primary_key=True, index=True)
    job_id          = Column(Integer, nullable=False, index=True)
    kind            = Column(String(20), nullable=False, default="run_now")
    fire_key        = Column(String(320), nullable=False, unique=True)
    # 2026-09-10 — the request's OWN identity fields, stored beside the key
    # they were minted into, so the dispatch view can project them and the
    # dispatcher can rebuild the key and REFUSE a request whose fields do
    # not reproduce it.  ``definition`` is the projection snapshot taken
    # when the person pressed the button (core grammar, core-validated).
    tenant          = Column(String(40), nullable=True)
    scope           = Column(String(100), nullable=True)
    definition      = Column(JSON, nullable=True)
    parent_fire_key = Column(String(320), nullable=True)
    from_step       = Column(Integer, nullable=True)
    job_version     = Column(Integer, nullable=True)
    requested_by    = Column(String(100), nullable=True)
    requested_at    = Column(DateTime, default=_utcnow)
    reason          = Column(Text, nullable=True)
    status          = Column(String(20), nullable=False, default="PENDING", index=True)
    claimed_by      = Column(String(100), nullable=True)
    claimed_at      = Column(DateTime, nullable=True)
    resolved_at     = Column(DateTime, nullable=True)
    detail          = Column(Text, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "job_id": self.job_id, "kind": self.kind, "fire_key": self.fire_key,
            "tenant": self.tenant, "scope": self.scope,
            "parent_fire_key": self.parent_fire_key, "from_step": self.from_step,
            "job_version": self.job_version, "requested_by": self.requested_by,
            "requested_at": self.requested_at.isoformat() if self.requested_at else None,
            "reason": self.reason, "status": self.status,
            "claimed_by": self.claimed_by,
            "claimed_at": self.claimed_at.isoformat() if self.claimed_at else None,
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
            "detail": self.detail,
        }


class ClockworkSchemaMigration(Base):
    """A RECORD of a Clockwork-owned DDL script this database had applied to
    it -- never the authority on what is there.

    The applier (``core/clockwork/schema_admin.py``) decides whether to run a
    script by READING THE DATABASE against the script's declared
    postcondition, not by consulting this table: a database restored from a
    backup, or patched by hand, must be read as it actually is.  What this
    table answers is the question a ledger CAN answer -- what was done, when,
    by whom, from which shipped text (``checksum``), and what happened
    (``status``: ``applied``, ``failed`` or ``refused``, with the reason in
    ``detail``).  The admin schema page shows it as history.

    A new TABLE self-creates through ``create_all``; nothing here is a column
    added to an existing table, so no ``_MIGRATIONS`` entry is needed."""
    __tablename__ = "clockwork_schema_migrations"

    id            = Column(Integer, primary_key=True, index=True)
    #: ``<dialect>/<file name>`` -- ``clockwork.ddl.Script.id``.
    script_id     = Column(String(200), nullable=False, index=True)
    dialect       = Column(String(20), nullable=False)
    filename      = Column(String(200), nullable=False)
    kind          = Column(String(20), nullable=False)
    #: sha256 of the shipped text, so "the script changed since it was
    #: applied here" is answerable rather than assumed.
    checksum      = Column(String(64), nullable=True)
    statements    = Column(Integer, nullable=False, default=0)
    status        = Column(String(20), nullable=False, index=True)
    applied_at    = Column(DateTime, default=_utcnow, index=True)
    applied_by    = Column(String(100), nullable=True)
    detail        = Column(Text, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "script_id": self.script_id, "dialect": self.dialect,
            "filename": self.filename, "kind": self.kind, "checksum": self.checksum,
            "statements": self.statements, "status": self.status,
            "applied_at": self.applied_at.isoformat() if self.applied_at else None,
            "applied_by": self.applied_by, "detail": self.detail,
        }


class ClockworkAlert(Base):
    """A durable refusal / anomaly, ONCE per (job, deployment, kind) with a
    count — plan v1 §10: the log line stays per tick, the fact lands in a
    table once, so a permanently bad row cannot storm."""
    __tablename__ = "clockwork_alerts"
    __table_args__ = (UniqueConstraint("job_id", "deployment_id", "kind", name="uq_clockwork_alert"),)

    id              = Column(Integer, primary_key=True, index=True)
    job_id          = Column(Integer, nullable=True, index=True)
    deployment_id   = Column(String(100), nullable=True, index=True)
    kind            = Column(String(60), nullable=False)
    message         = Column(Text, nullable=True)
    first_seen_at   = Column(DateTime, default=_utcnow)
    last_seen_at    = Column(DateTime, default=_utcnow)
    count           = Column(Integer, nullable=False, default=1, server_default="1")
    acknowledged_by = Column(String(100), nullable=True)
    acknowledged_at = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "job_id": self.job_id, "deployment_id": self.deployment_id,
            "kind": self.kind, "message": self.message,
            "first_seen_at": self.first_seen_at.isoformat() if self.first_seen_at else None,
            "last_seen_at": self.last_seen_at.isoformat() if self.last_seen_at else None,
            "count": self.count, "acknowledged_by": self.acknowledged_by,
            "acknowledged_at": self.acknowledged_at.isoformat() if self.acknowledged_at else None,
        }


class ClockworkJobHealth(Base):
    """Plan v2 §7: credential health MEASURED ON THE CLOCKWORK POD.  One row
    per (job, deployment).  'never probed' is a distinct state; it is never
    rendered as OK.  Written by Clockwork; read here."""
    __tablename__ = "clockwork_job_health"
    __table_args__ = (UniqueConstraint("job_id", "deployment_id", name="uq_clockwork_job_health"),)

    id            = Column(Integer, primary_key=True, index=True)
    job_id        = Column(Integer, nullable=False, index=True)
    deployment_id = Column(String(100), nullable=False)
    state         = Column(String(20), nullable=False, default="never_probed")
    reason        = Column(Text, nullable=True)
    checked_at    = Column(DateTime, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "job_id": self.job_id, "deployment_id": self.deployment_id,
            "state": self.state, "reason": self.reason,
            "checked_at": self.checked_at.isoformat() if self.checked_at else None,
            "checked_by": self.deployment_id,
        }


class ClockworkFireResolution(Base):
    """A human's recorded resolution of a stuck CLAIMED / UNKNOWN fire.
    QueryStudio-owned: it NEVER rewrites the fire log's status (plan v2
    §7) — the resolution sits beside the row, keyed by its fire key."""
    __tablename__ = "clockwork_fire_resolutions"

    fire_key    = Column(String(320), primary_key=True)
    job_id      = Column(Integer, nullable=True, index=True)
    verdict     = Column(String(40), nullable=False)
    note        = Column(Text, nullable=True)
    resolved_by = Column(String(100), nullable=True)
    resolved_at = Column(DateTime, default=_utcnow)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "fire_key": self.fire_key, "job_id": self.job_id, "verdict": self.verdict,
            "note": self.note or "", "resolved_by": self.resolved_by,
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
        }


class ClockworkAlertNotification(Base):
    """The DELIVERY ledger beside ``clockwork_alerts`` (2026-09-10).

    An alert is a FACT (the ``clockwork_alerts`` row, written by the
    dispatcher's publisher and by the authoring plane); a notification is a
    DELIVERY of that fact to a person.  Until this table existed the rows
    were written faithfully and consumed by nothing -- a job failing at
    02:00 was a row nobody saw until a human opened the page.

    One row per alert id.  ``alert_count`` / ``alert_acknowledged`` are what
    the notifier LAST SAW on the alert row, so it can tell a TRANSITION
    (first sighting; re-raised after a person acknowledged it) from a
    REPETITION (the same fact bumping its count every tick) and page once
    per identity, never once per tick.  The alert row itself is never
    written by the notifier; a delivery failure lands HERE, never on the
    fact.
    """
    __tablename__ = "clockwork_alert_notifications"

    id                 = Column(Integer, primary_key=True, index=True)
    alert_id           = Column(Integer, nullable=False, unique=True, index=True)
    job_id             = Column(Integer, nullable=True, index=True)
    kind               = Column(String(60), nullable=False)
    severity           = Column(String(20), nullable=False)
    #: the alert row's ``count`` / ``acknowledged_at is not None`` as last seen
    alert_count        = Column(Integer, nullable=False, default=0)
    alert_acknowledged = Column(Boolean, nullable=False, default=False, server_default=sa_false())
    #: {"emails": [...], "usernames": [...], "derived_from": [...]}
    recipients         = Column(JSON, nullable=True)
    #: sent | partial | failed | unrouted | exhausted | acknowledged |
    #: sending (2026-10-10: CLAIMED by one pass, delivery in flight -- the
    #: insert-first claim writes it BEFORE anything is sent)
    status             = Column(String(20), nullable=False, default="unrouted")
    attempts           = Column(Integer, nullable=False, default=0)
    error              = Column(Text, nullable=True)
    notified_at        = Column(DateTime, nullable=True)
    created_at         = Column(DateTime, default=_utcnow)
    updated_at         = Column(DateTime, default=_utcnow, onupdate=_utcnow)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "alert_id": self.alert_id, "job_id": self.job_id,
            "kind": self.kind, "severity": self.severity,
            "alert_count": self.alert_count, "alert_acknowledged": bool(self.alert_acknowledged),
            "recipients": self.recipients or {"emails": [], "usernames": [], "derived_from": []},
            "status": self.status, "attempts": self.attempts, "error": self.error,
            "notified_at": self.notified_at.isoformat() if self.notified_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


# ── 2026-09-28 — business-date READINESS on reports, and report SLOs ──────
#
# A report declares which dependencies must be MET for a business date, in
# the SAME vocabulary a feed uses (etl_dependency_types, a dependency_key,
# the upstream calendar, the declared arrival sources) -- but in a table of
# its OWN.  ``etl_dependency_mappings.etl_id`` is already two namespaces
# (an explicit OTG etl_id or the feed's own id); a report keyed into it
# would collide with the feed of the same number, and every feed reader
# (the poller's COALESCE join, the blocking index) would pick the report's
# rows up as a feed's.  The EVIDENCE stays shared: the tracking table and
# the arrival ledger are keyed by dependency, not by subject, so a Kafka
# message that releases a feed also completes the report that named it.
# The DECISION stays shared too: core/reports/readiness.py hands these rows
# to the one gate (core/feed/etl_dependency.py::evaluate_gate_over_rows).

class ReportReadinessSubject(Base):
    """One row per report that declares readiness: which of its parameters
    carries the business date (NULL = the first date-typed parameter, else
    today)."""
    __tablename__ = "report_readiness_subjects"

    id                  = Column(Integer, primary_key=True, index=True)
    report_id           = Column(Integer, nullable=False, unique=True, index=True)
    business_date_param = Column(String(100), nullable=True)
    updated_by          = Column(String(100), nullable=True)
    created_at          = Column(DateTime, default=_utcnow)
    updated_at          = Column(DateTime, default=_utcnow, onupdate=_utcnow)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id,
            "business_date_param": self.business_date_param,
            "updated_by": self.updated_by,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class ReportDependencyMapping(Base):
    """A dependency a report's data waits on -- the feed mapping's columns,
    keyed by report.  Same catalogue (``etl_dependency_types``), same key,
    same upstream calendar (FR-DEP-08), same expected rows (FR-DEP-24),
    same declared arrival sources and require_mode (2026-09-27)."""
    __tablename__ = "report_dependency_mappings"
    __table_args__ = (
        UniqueConstraint("report_id", "dependency_type_id", "dependency_key",
                         name="ux_report_dep_mapping"),
    )

    id                 = Column(Integer, primary_key=True, index=True)
    report_id          = Column(Integer, nullable=False, index=True)
    dependency_type_id = Column(Integer, ForeignKey("etl_dependency_types.id"),
                                nullable=False, index=True)
    dependency_key     = Column(String(500), nullable=False)
    description        = Column(String(500), nullable=True)
    calendar_name      = Column(String(100), nullable=True)
    expected_rows      = Column(BigInteger, nullable=True)
    arrival_sources    = Column(JSON, nullable=True)
    require_mode       = Column(String(10), nullable=True)
    is_active          = Column(Boolean, default=True, nullable=False)
    created_at         = Column(DateTime, default=_utcnow)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id,
            "dependency_type_id": self.dependency_type_id,
            "dependency_key": self.dependency_key,
            "description": self.description,
            "calendar_name": self.calendar_name,
            "expected_rows": self.expected_rows,
            "arrival_sources": self.arrival_sources,
            "require_mode": self.require_mode,
            "is_active": bool(self.is_active),
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class ReportReadinessRun(Base):
    """The readiness verdict a report RUN was served under -- one row per
    execution (sync, async, headless).  The SLO rule reads it: a report is
    met when a run for the business date completed with readiness
    ``complete`` by the promised time.  Unknown is never complete, so an
    ``unknown`` or ``partial`` row can never satisfy a promise."""
    __tablename__ = "report_readiness_runs"
    __table_args__ = (
        Index("ix_report_readiness_runs_report_date", "report_id", "business_date"),
    )

    id            = Column(Integer, primary_key=True, index=True)
    report_id     = Column(Integer, nullable=False, index=True)
    execution_id  = Column(String(100), nullable=True, index=True)
    business_date = Column(Date, nullable=False)
    #: complete | partial | unknown | undeclared
    state         = Column(String(20), nullable=False)
    summary       = Column(Text, nullable=True)
    #: interactive | interactive-async | headless
    surface       = Column(String(40), nullable=True)
    executed_by   = Column(String(100), nullable=True)
    evaluated_at  = Column(DateTime, nullable=False, default=_utcnow)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id,
            "execution_id": self.execution_id,
            "business_date": self.business_date.isoformat() if self.business_date else None,
            "state": self.state, "summary": self.summary,
            "surface": self.surface, "executed_by": self.executed_by,
            "evaluated_at": self.evaluated_at.isoformat() if self.evaluated_at else None,
        }


class ReportSlo(Base):
    """A report's promise: fresh and served by ``serve_by`` (a LOCAL time)
    in ``timezone``, on the business days of ``calendar_name`` (NULL =
    every calendar day).  Resolved per business date through THE clocks
    function (core/feed/acting_time.py::compute_clocks) -- never a bare
    hour, because DST moves a bare hour twice a year."""
    __tablename__ = "report_slos"

    id            = Column(Integer, primary_key=True, index=True)
    report_id     = Column(Integer, nullable=False, unique=True, index=True)
    serve_by      = Column(String(8), nullable=False)          # HH:MM local
    timezone      = Column(String(64), nullable=False)
    calendar_name = Column(String(100), nullable=True)
    is_active     = Column(Boolean, default=True, nullable=False)
    created_by    = Column(String(100), nullable=True)
    created_at    = Column(DateTime, default=_utcnow)
    updated_at    = Column(DateTime, default=_utcnow, onupdate=_utcnow)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id,
            "serve_by": self.serve_by, "timezone": self.timezone,
            "calendar_name": self.calendar_name,
            "is_active": bool(self.is_active),
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class ReportSloBreach(Base):
    """The breach LEDGER: one row per (report, business date) whose promise
    was missed, with its cause, kept after it is served late (``state``
    moves open -> served_late; the Netcool alert clears then).  A promise
    that could not be evaluated is not a breach and is not written here --
    the live status says ``could_not_evaluate`` with the reason."""
    __tablename__ = "report_slo_breaches"
    __table_args__ = (
        UniqueConstraint("report_id", "business_date", name="ux_report_slo_breach"),
    )

    id                 = Column(Integer, primary_key=True, index=True)
    report_id          = Column(Integer, nullable=False, index=True)
    business_date      = Column(Date, nullable=False, index=True)
    sla_at             = Column(DateTime, nullable=False)        # UTC
    detected_at        = Column(DateTime, nullable=False, default=_utcnow)
    #: data_not_ready | could_not_tell | no_run | no_readiness_declared
    cause              = Column(String(40), nullable=False)
    detail             = Column(Text, nullable=True)
    #: open | served_late
    state              = Column(String(20), nullable=False, default="open")
    served_at          = Column(DateTime, nullable=True)
    netcool_identifier = Column(String(300), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id, "report_id": self.report_id,
            "business_date": self.business_date.isoformat() if self.business_date else None,
            "sla_at": self.sla_at.isoformat() if self.sla_at else None,
            "detected_at": self.detected_at.isoformat() if self.detected_at else None,
            "cause": self.cause, "detail": self.detail, "state": self.state,
            "served_at": self.served_at.isoformat() if self.served_at else None,
            "netcool_identifier": self.netcool_identifier,
        }


# ═══════════════════════════════════════════════════════════════════════════════
# 2026-09-28 -- Delivery receipts + self-subscription for feed CONSUMERS
# (docs/FEATURE_STRATEGY_2026_09_28.html #3, core/feed/consumer_receipts.py,
# core/feed/consumer_notices.py).  Two fresh tables (create_all); the
# companion COLUMN feed_configs.consumer_group_ids is in _MIGRATIONS.
# ═══════════════════════════════════════════════════════════════════════════════

#: The events a consumer may subscribe to.  ONE spelling: the API's 422,
#: the notice ledger's ``event`` column and the frontend's checkboxes.
FEED_CONSUMER_EVENTS = ("delivered", "late", "failed")


class FeedConsumerSubscription(Base):
    """One consumer's "notify me" on one feed: which of the three events,
    and where (the bell is always on; e-mail only when an address is
    given -- a local user carries no address the platform could use).
    UNIQUE (feed, username): a PUT replaces the row, never stacks one."""
    __tablename__ = "feed_consumer_subscriptions"
    __table_args__ = (
        UniqueConstraint("feed_config_id", "username",
                         name="ux_feed_consumer_subscriptions_feed_user"),
    )

    id             = Column(Integer, primary_key=True, index=True)
    # No FK on purpose: a retired feed's subscription rows are cleaned by
    # the feed delete route, and a subscription must never block it.
    feed_config_id = Column(Integer, nullable=False, index=True)
    username       = Column(String(100), nullable=False, index=True)
    #: JSON list over FEED_CONSUMER_EVENTS.
    events         = Column(JSON, nullable=False)
    email          = Column(String(255), nullable=True)
    created_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                            onupdate=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "feed_config_id": self.feed_config_id,
            "username": self.username,
            "events": [str(e) for e in (self.events or [])],
            "email": self.email,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class FeedConsumerNotice(Base):
    """The notice LEDGER: one row per (feed, business date, event,
    subscriber, run key) that was told.  The UNIQUE constraint is the
    "once per event, not once per watcher pass" guarantee: the sender
    INSERTS FIRST and only a row that landed is followed by a bell, a
    mail and a socket push, so two pods ticking cannot tell one person
    twice.  ``run_key`` is the run id, or ``date`` for a late notice that
    belongs to the day rather than to one run."""
    __tablename__ = "feed_consumer_notices"
    __table_args__ = (
        UniqueConstraint("feed_config_id", "business_date", "event",
                         "username", "run_key",
                         name="ux_feed_consumer_notices_once"),
    )

    id             = Column(Integer, primary_key=True, index=True)
    feed_config_id = Column(Integer, nullable=False, index=True)
    business_date  = Column(Date, nullable=False, index=True)
    feed_run_id    = Column(Integer, nullable=True)
    event          = Column(String(20), nullable=False)
    username       = Column(String(100), nullable=False, index=True)
    run_key        = Column(String(40), nullable=False)
    #: ``{bell: {...}, email: {...}, socket: {...}}`` -- each channel's
    #: verdict, written after the send so the ledger says who was reached.
    channels       = Column(JSON, nullable=True)
    created_at     = Column(DateTime, default=lambda: datetime.now(timezone.utc),
                            index=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "feed_config_id": self.feed_config_id,
            "business_date": self.business_date.isoformat() if self.business_date else None,
            "feed_run_id": self.feed_run_id,
            "event": self.event,
            "username": self.username,
            "run_key": self.run_key,
            "channels": self.channels or {},
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


# ── Component health, one place (2026-10-17) ─────────────────────────────────
# docs/COMPONENT_HEALTH_DESIGN_2026_10_17.html §3.5.  Observed state is
# WRITTEN by its owner (the pod's reporter; the fleet watcher under the
# reserved pod_id "@fleet") and READ by anyone.  New TABLES self-create.

def _iso(v):
    return v.isoformat() if v else None


class ComponentHealth(Base):
    """One row per (pod, component): the owner's latest observation plus the
    confirmation bookkeeping the fleet watcher keeps on it.  Keyed by pod so
    a duplicated singleton is visible, never collapsed."""
    __tablename__ = "component_health"
    __table_args__ = (
        Index("ix_component_health_component", "component_id"),
        Index("ix_component_health_state", "state"),
    )

    pod_id           = Column(String(150), primary_key=True)
    component_id     = Column(String(200), primary_key=True)
    kind             = Column(String(20), nullable=False)
    scope            = Column(String(20), nullable=False)
    label            = Column(String(200), nullable=False)
    group            = Column(String(40), nullable=True)
    state            = Column(String(20), nullable=False)
    disposition      = Column(String(30), nullable=True)
    reason           = Column(Text, nullable=False)
    evidence         = Column(String(120), nullable=True)
    metrics          = Column(JSON, nullable=True)
    pod_role         = Column(String(20), nullable=True)
    build            = Column(String(120), nullable=True)
    checked_at       = Column(DateTime, nullable=False)
    reported_at      = Column(DateTime, nullable=False,
                              default=lambda: datetime.now(timezone.utc),
                              onupdate=lambda: datetime.now(timezone.utc),
                              server_default=sa_text("CURRENT_TIMESTAMP"))
    interval_seconds = Column(Integer, nullable=True)
    timeout_seconds  = Column(Float, nullable=True)
    probe_ms         = Column(Integer, nullable=True)
    #: the first checked_at of the CURRENT state (carried across upserts)
    state_since      = Column(DateTime, nullable=True)
    #: consecutive observations of the current state (confirmation)
    confirmations    = Column(Integer, nullable=True, default=1)
    #: the open intent that mutes this row's alerting, if any
    muted_by_intent  = Column(Integer, nullable=True)
    #: the open feed_alerts row raised for this component, if any
    alert_id         = Column(Integer, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "pod_id": self.pod_id, "component_id": self.component_id, "kind": self.kind,
            "scope": self.scope, "label": self.label, "group": self.group, "state": self.state,
            "disposition": self.disposition, "reason": self.reason, "evidence": self.evidence,
            "metrics": dict(self.metrics or {}), "pod_role": self.pod_role, "build": self.build,
            "checked_at": _iso(self.checked_at), "reported_at": _iso(self.reported_at),
            "interval_seconds": self.interval_seconds, "timeout_seconds": self.timeout_seconds,
            "probe_ms": self.probe_ms, "state_since": _iso(self.state_since),
            "confirmations": self.confirmations, "muted_by_intent": self.muted_by_intent,
            "alert_id": self.alert_id,
        }


class ComponentHealthEvent(Base):
    """Append-only: one row per CONFIRMED state transition (the watcher's
    confirmation rule, so flapping is a count, not a flood).  ``by`` names
    the person whose control caused it; ``alert_id`` the alert it raised."""
    __tablename__ = "component_health_events"
    __table_args__ = (Index("ix_component_health_events_component_at", "component_id", "at"),)

    id           = Column(Integer, primary_key=True, index=True)
    component_id = Column(String(200), nullable=False)
    pod_id       = Column(String(150), nullable=True)
    from_state   = Column(String(20), nullable=True)
    to_state     = Column(String(20), nullable=False)
    reason       = Column(Text, nullable=True)
    at           = Column(DateTime, nullable=False, default=lambda: datetime.now(timezone.utc), index=True)
    by           = Column(String(100), nullable=True)
    intent_id    = Column(Integer, nullable=True)
    alert_id     = Column(Integer, nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "component_id": self.component_id, "pod_id": self.pod_id,
                "from_state": self.from_state, "to_state": self.to_state, "reason": self.reason,
                "at": _iso(self.at), "by": self.by, "intent_id": self.intent_id,
                "alert_id": self.alert_id}


class ComponentIntent(Base):
    """A control is an INTENT ROW the owning pod applies and reports on.
    ``target_pod_id`` is a pod, or ``*`` for every pod that holds the thing
    (a circuit breaker lives in every process's memory).  Pause / resume of a
    daemon are NOT here: background_job_state stays their one home."""
    __tablename__ = "component_intents"
    __table_args__ = (Index("ix_component_intents_status", "status"),)

    id              = Column(Integer, primary_key=True, index=True)
    control         = Column(String(30), nullable=False)
    component_id    = Column(String(200), nullable=False, index=True)
    target_pod_id   = Column(String(150), nullable=False)
    requested_by    = Column(String(100), nullable=False)
    requested_at    = Column(DateTime, nullable=False, default=lambda: datetime.now(timezone.utc))
    reason          = Column(Text, nullable=False)
    expires_at      = Column(DateTime, nullable=True)
    status          = Column(String(20), nullable=False, default="pending")
    #: pod_id -> {"at", "outcome", "detail"}
    applied_by_pods = Column(JSON, nullable=True)
    consequence     = Column(Text, nullable=True)
    withdrawn_by    = Column(String(100), nullable=True)
    withdrawn_at    = Column(DateTime, nullable=True)
    audit_action    = Column(String(60), nullable=True)

    def to_dict(self) -> Dict[str, Any]:
        return {"id": self.id, "control": self.control, "component_id": self.component_id,
                "target_pod_id": self.target_pod_id, "requested_by": self.requested_by,
                "requested_at": _iso(self.requested_at), "reason": self.reason,
                "expires_at": _iso(self.expires_at), "status": self.status,
                "applied_by_pods": dict(self.applied_by_pods or {}),
                "consequence": self.consequence, "withdrawn_by": self.withdrawn_by,
                "withdrawn_at": _iso(self.withdrawn_at), "audit_action": self.audit_action}


__all__ = [
    "ComponentHealth",
    "ComponentHealthEvent",
    "ComponentIntent",
    "ClockworkAlert",
    "ClockworkAlertNotification",
    "ClockworkDeployment",
    "ClockworkFireResolution",
    "ClockworkJob",
    "ClockworkJobHealth",
    "ClockworkJobVersion",
    "ClockworkManualRequest",
    "ClockworkQueryTemplate",
    "ClockworkSetting",
    "ClockworkTaskType",
    "AgentConfig",
    "AgentDecisionLog",
    "AgentRule",
    "AggCacheEntry",
    "AggCacheSuggestion",
    "AggregationAwareness",
    "AlertHistory",
    "AlertRule",
    "ApiAccessLog",
    "ApiKey",
    "ApiKeyRequest",
    "AuditLog",
    "BackgroundJobState",
    "BackgroundJobTick",
    "Base",
    "BrainPruningMemo",
    "BrainRouteOutcome",
    "BurstJob",
    "BurstTask",
    "BusinessDataset",
    "BusinessReport",
    "BusinessReportAccessRequest",
    "BusinessReportAsyncJob",
    "BusinessReportCertificationRequest",
    "BusinessReportGrant",
    "BusinessReportPermissionEvent",
    "BusinessReportShareToken",
    "BusinessReportVersion",
    "CalculatedMetric",
    "CircuitBreakerState",
    "CloudDeliveryConfig",
    "ColumnLineageEntry",
    "ColumnPolicy",
    "ConditionalFormatRule",
    "Connection",
    "ConnectionAccess",
    "ConnectionProfile",
    "ConnectionProfileMapping",
    "CustomBackgroundJob",
    "Dashboard",
    "DashboardShare",
    "DashboardWidget",
    "DataFlow",
    "DataFlowApprovalRequest",
    "DataFlowCustomStageType",
    "DataFlowNotificationPolicy",
    "DataFlowRun",
    "DataFlowRunAnnotation",
    "DataFlowRunStage",
    "DataFlowSchedule",
    "DataFlowStage",
    "DataFlowStageType",
    "DataFlowVariable",
    "DataFlowWebhookTrigger",
    "DataFreshness",
    "DataQualityAlert",
    "DataQualityResult",
    "DataQualityRule",
    "DatasetClass",
    "DatasetColumn",
    "DatasetRelationship",
    "DeadLetterQueue",
    "DeliveryHistory",
    "DependencyEvent",
    "DownloadFile",
    "DrillHierarchy",
    "DuckDBSubprocessCrash",
    "EtlDependencyMapping",
    "EtlDependencyTracking",
    "EtlDependencyType",
    "EtlPipelineConfig",
    "EtlPipelineExecution",
    "ExecutionCheckpoint",
    "FederationExecution",
    "FederationView",
    "FeedCalendar",
    "FeedConfig",
    "FeedControlFileFormat",
    "FeedExecution",
    "FeedHoliday",
    "FeedRowCountBaseline",
    "FeedRun",
    "FeedRunStep",
    "FeedSodGap",
    "FEED_RUN_SOD_CATCHUP_TRIGGER",
    "FeedStepType",
    "FeedCustomStepType",
    "FeedFlow",
    "FeedFlowStep",
    "FEED_RUN_STEP_STATUSES",
    "FEED_RUN_STEP_GREEN_STATUSES",
    "FEED_STEP_EXECUTORS",
    "IcebergBloomSidecar",
    "IcebergColumnStatsSupplement",
    "IcebergFileCache",
    "IcebergFileStats",
    "IcebergFreshnessReliability",
    "IcebergManifestCache",
    "IcebergMetadataContentCache",
    "IcebergMetadataKeyCache",
    "IcebergMirror",
    "IcebergMirrorDualRunEvent",
    "IcebergPrunabilityProfile",
    "IcebergSnapshotCache",
    "IcebergSnapshotFiles",
    "IcebergSupplementBuild",
    "IcebergWatcherChange",
    "KafkaMessage",
    "LineageSnapshot",
    "LocalTable",
    "LogicalTable",
    "LogicalTableBinding",
    "MaterializedIsland",
    "MaterializedView",
    "MergedDimension",
    "NLConversation",
    "NLFeedback",
    "NLPattern",
    "NLQueryHistory",
    "NLSynonym",
    "NotificationLog",
    "PartitionCache",
    "PassportCalibration",
    "PendingNotification",
    "PolicyBinding",
    "PreDefinedCondition",
    "PruningAlertEvent",
    "PublishedApiAlertState",
    "PublishedApiAlertThreshold",
    "PublishedApiCallRollup",
    "PublishedApiIngestHealth",
    "PublishedApiRollupState",
    "PublishedView",
    "PublishedViewWebhook",
    "QueryCacheEntry",
    "QueryExecution",
    "QueryJob",
    "QueryPerformanceLog",
    "QueryPruningHistory",
    "QueryScanPlan",
    "QueryShare",
    "QueryUsageStat",
    "PvBulkPrepareClaim",
    "PvBulkPrepareJob",
    "PvMaterialiseFlight",
    "QueuedWaitCancel",
    "QueryVersion",
    "RLSPolicy",
    "RateLimitWindow",
    "ReconciliationEntity",
    "ReconciliationRun",
    "Report",
    "ReportBookmark",
    "ReportChangeLog",
    "ReportComment",
    "ReportEmbedToken",
    "ReportFavorite",
    "ReportFolder",
    "ReportDependencyMapping",
    "ReportFolderAssignment",
    "ReportInstance",
    "ReportReadinessRun",
    "ReportReadinessSubject",
    "ReportSlo",
    "ReportSloBreach",
    "ReportPDFConfig",
    "ReportParameter",
    "ReportSubscription",
    "ReportTag",
    "ReportTagAssignment",
    "ReportView",
    "RestQueryDef",
    "ResultArtifact",
    "RowLevelPolicy",
    "RowSecurityAuditLog",
    "RunEvent",
    "SapTaskConfig",
    "SavedQuery",
    "Schedule",
    "ScheduleRunStats",
    "SchedulerLease",
    "SchedulerLock",
    "SchemaCache",
    "SnapshotTracker",
    "SparkConnectSession",
    "SqlFile",
    "SqlSavedQuery",
    "SubscriptionDelivery",
    "SuggestionCorrection",
    "SuperAdmin",
    "SystemAccount",
    "SystemSetting",
    "TableDescription",
    "TableFavorite",
    "TableLineageEntry",
    "TaskQueue",
    "UIComponentVisibility",
    "UserDraft",
    "UserGroup",
    "UserGroupMember",
    "UserPreference",
    "UserSession",
    "WatchedIcebergTable",
    "WorkerHealthState",
    "WorkerRegistration",
    "Workspace",
    "WorkspaceMember",
    "FEED_CONSUMER_EVENTS",
    "FeedConsumerNotice",
    "FeedConsumerSubscription",
]
