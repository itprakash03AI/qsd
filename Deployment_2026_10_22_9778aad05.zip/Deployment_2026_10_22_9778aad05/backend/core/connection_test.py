"""THE connection test, by type -- the one function the Connections page's
Test button, ``POST /api/connections/{id}/test`` and the component-health
dependency probe all call.

2026-10-18, from the first rig run of the component-health proof: the probe
built its own test -- ``get_connector(...)`` for EVERY type -- and reported
every S3 connection DOWN with ``Unsupported connection type 's3'`` while the
Test button, which routes S3 / local through ``ConnectionManager`` and only
the SQL types through a connector, said OK.  Two answers to one question
(CLAUDE.md §4: a decision made twice is a bug).  The dispatch now lives
here, once; the routes and the probe differ only in WHERE the config comes
from (the browser's form with its ``***`` restored, or the stored row
DECRYPTED).

Also here: :func:`reach_endpoint`, a connect-level pre-check (resolve +
TCP connect within a budget).  A dependency whose host no longer resolves,
refuses, or does not complete a handshake is DOWN with that reason -- never
"probe exceeded" from a connector whose own timeout outlives the probe's
budget (found live: a stopped Trino container read as UNKNOWN for the whole
outage).
"""
from __future__ import annotations

import socket
import time
from typing import Any, Dict, Optional, Tuple
from urllib.parse import urlparse


def run_connection_test(connection_type: str, config: Dict[str, Any], *,
                        conn_manager: Any = None, db: Any = None,
                        connection_id: Optional[int] = None, connection_name: str = "") -> Dict[str, Any]:
    """``{"success": bool, "message": str, ...}`` for a connection type and
    its PLAINTEXT config.  SQL types open their connector and close it;
    every other type (s3, local, upload) asks ``ConnectionManager``.  The
    caller passes the manager it has, or the db a manager can be built on.

    ``connection_id`` (a SAVED connection) routes the SQL test through that
    connection's circuit breaker on THIS pod (``_wrap_with_circuit_breaker``):
    a failed test counts, an OPEN breaker fast-fails the test.  The form
    test (no id) and the fleet watcher's probe (the breaker is a per-pod
    query-path fact, not the watcher's) pass none.

    Raises what the connector raises: the two routes and the probe each turn
    that into their own answer (the route sanitises; the probe says DOWN).
    """
    from core.connectors import SQL_CONNECTOR_TYPES, get_connector
    ctype = str(connection_type or "")
    if ctype in SQL_CONNECTOR_TYPES:
        if connection_id is not None:
            connector = get_connector(ctype, dict(config or {}), connection_id=int(connection_id),
                                      connection_name=str(connection_name or ""))
        else:
            connector = get_connector(ctype, dict(config or {}))
        try:
            return connector.test_connection()
        finally:
            try:
                connector.close()
            except Exception:                              # noqa: BLE001 -- close is best effort
                pass
    cm = conn_manager
    if cm is None:
        if db is None:
            raise ValueError("run_connection_test needs a ConnectionManager or a db to build one")
        from core.connection_manager import ConnectionManager
        cm = ConnectionManager(db)
    return cm.test_connection(ctype, dict(config or {}))


# ── connect-level pre-check ──────────────────────────────────────────────────

#: the words a connect-level failure is classified into (the health rules and
#: the proof match on these, so they are declared, not improvised)
UNRESOLVABLE = "unresolvable"
REFUSED = "refused"
CONNECT_TIMED_OUT = "connect timed out"
UNREACHABLE = "unreachable"

_DEFAULT_PORTS = {"trino": 8080, "starburst": 8080, "oracle": 1521, "postgresql": 5432, "postgres": 5432,
                  "mysql": 3306, "sqlserver": 1433, "hive": 10000}


def endpoint_of(connection_type: str, config: Dict[str, Any]) -> Optional[Tuple[str, int]]:
    """The (host, port) a connection's test will reach first, or None when
    the type has no single endpoint we can name (an AWS-hosted S3 bucket, a
    Snowflake account behind its own resolver, a local engine)."""
    ctype = str(connection_type or "").lower()
    cfg = config or {}
    host = str(cfg.get("host") or cfg.get("hostname") or cfg.get("server") or "").strip()
    port_raw = cfg.get("port")
    if ctype in ("s3",):
        url = str(cfg.get("endpoint_url") or cfg.get("endpoint") or "").strip()
        if not url:
            return None                                   # AWS proper: many hosts, resolver-fronted
        return _from_url(url, 443)
    if ctype in ("rest", "rest_api"):
        url = str(cfg.get("base_url") or cfg.get("url") or "").strip()
        return _from_url(url, 443) if url else None
    if ctype in ("databricks",):
        url = str(cfg.get("server_hostname") or cfg.get("host") or "").strip()
        return (url, 443) if url else None
    if ctype in ("snowflake", "athena"):
        return None
    if not host:
        return None
    if host.startswith(("http://", "https://")):
        return _from_url(host, 443)
    try:
        port = int(port_raw) if port_raw not in (None, "") else None
    except (TypeError, ValueError):
        port = None
    if port is None:
        if ctype in ("trino", "starburst") and str(cfg.get("http_scheme") or cfg.get("protocol") or "").lower() == "https":
            port = 443
        else:
            port = _DEFAULT_PORTS.get(ctype)
    if port is None:
        return None
    return host, port


def _from_url(url: str, default_port: int) -> Optional[Tuple[str, int]]:
    try:
        u = urlparse(url if "://" in url else f"https://{url}")
    except Exception:                                      # noqa: BLE001
        return None
    if not u.hostname:
        return None
    port = u.port or (80 if u.scheme == "http" else default_port)
    return u.hostname, int(port)


def classify_connect_error(exc: BaseException) -> str:
    """One of the declared words for a connect-level failure."""
    if isinstance(exc, socket.gaierror):
        return UNRESOLVABLE
    if isinstance(exc, ConnectionRefusedError):
        return REFUSED
    if isinstance(exc, (socket.timeout, TimeoutError)):
        return CONNECT_TIMED_OUT
    return UNREACHABLE


#: a resolver that does not ANSWER within the budget is a different fact from
#: a name that does not exist (2026-10-18, the rebuilt rig: the stopped SFTP
#: container's name went to the upstream resolver and the probe sat in
#: ``getaddrinfo`` past its 4 s budget -- "probe exceeded", no word, for the
#: whole outage; on the first rig the same name was refused at once).  Both
#: are DOWN; the row says WHICH.
RESOLUTION_TIMED_OUT = "name resolution timed out"


def connect_within(host: str, port: int, budget_seconds: float
                   ) -> Tuple[Optional[socket.socket], Optional[Dict[str, Any]]]:
    """(an OPEN connected socket, None) when ``host:port`` resolves and
    accepts a TCP connection within the budget; else (None, {"kind",
    "detail", "ms"}) -- the reason a dependency is DOWN.  Name resolution is
    bounded too: ``getaddrinfo`` has no timeout of its own, so it runs on a
    helper thread and is abandoned at the budget.  The caller owns the
    socket (``reach_endpoint`` closes it at once; the SFTP probe reads the
    banner from it, so the name is resolved ONCE)."""
    import concurrent.futures
    budget = max(0.2, float(budget_seconds))
    t0 = time.monotonic()
    ex = concurrent.futures.ThreadPoolExecutor(max_workers=1, thread_name_prefix="qs-resolve")
    try:
        fut = ex.submit(socket.getaddrinfo, host, int(port), 0, socket.SOCK_STREAM)
        try:
            infos = fut.result(timeout=budget)
        except concurrent.futures.TimeoutError:
            return None, {"kind": RESOLUTION_TIMED_OUT,
                          "detail": f"the resolver gave no answer for {host} within {budget:.1f} s "
                                    f"(a name that does not exist is refused at once: that is 'unresolvable')",
                          "ms": int((time.monotonic() - t0) * 1000)}
        except socket.gaierror as exc:
            return None, {"kind": UNRESOLVABLE, "detail": f"{host}: {exc}", "ms": int((time.monotonic() - t0) * 1000)}
    finally:
        ex.shutdown(wait=False)
    left = max(0.2, budget - (time.monotonic() - t0))
    last: Optional[BaseException] = None
    for family, kind, proto, _canon, addr in infos[:3]:
        s = socket.socket(family, kind, proto)
        try:
            s.settimeout(left)
            s.connect(addr)
            return s, None
        except OSError as exc:
            last = exc
            try:
                s.close()
            except OSError:
                pass
    detail = f"{host}:{port}: {type(last).__name__}: {str(last)[:160]}" if last else f"{host}:{port}: no address"
    return None, {"kind": classify_connect_error(last) if last else UNREACHABLE, "detail": detail,
                  "ms": int((time.monotonic() - t0) * 1000)}


def reach_endpoint(host: str, port: int, budget_seconds: float) -> Optional[Dict[str, Any]]:
    """None when ``host:port`` is reachable within the budget, else the
    failure dict of :func:`connect_within`."""
    sock, failure = connect_within(host, port, budget_seconds)
    if sock is not None:
        try:
            sock.close()
        except OSError:
            pass
    return failure


__all__ = ["CONNECT_TIMED_OUT", "REFUSED", "RESOLUTION_TIMED_OUT", "UNREACHABLE", "UNRESOLVABLE",
           "classify_connect_error", "connect_within", "endpoint_of", "reach_endpoint", "run_connection_test"]
