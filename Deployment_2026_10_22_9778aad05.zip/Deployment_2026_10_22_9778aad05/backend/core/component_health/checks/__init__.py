"""The declared checks.  Importing a module here registers its checks; the
registry's ``load()`` imports all four once.  A new component is a new
``REGISTRY.register(HealthCheck(...))`` in one of these files (or a new
file imported by ``registry.load``), never an edit to the page."""
