"""``pod:self`` -- one row per pod, written by the pod itself.

The per-pod FACTS are gathered once per cycle (``gather_pod_facts``) and
shared with every other check through ``ProbeContext.facts``; each fact is
guarded on its own so one unreadable source costs one ``*_error`` key, never
the row.  The verdict rules are the design's §3.3 pod row.
"""
from __future__ import annotations

import os
import shutil
import time
from typing import Any, Dict, List

from core.component_health.contract import HealthCheck, Observation, ProbeContext
from core.component_health.registry import REGISTRY
from core.component_health.vocabulary import (
    CONTROL_DRAIN, CONTROL_RERUN_SELF_TEST, CONTROL_UNDRAIN, DEGRADED, DISPOSITION_DRAINING,
    DOWN, HEALTHY, KIND_POD, OWNER_EVERY_POD, SCOPE_PER_POD,
)

_STARTED_AT = time.time()


def build_identity() -> str:
    """version + the image / commit the environment stamps, when it does."""
    parts: List[str] = []
    try:
        from querystudio import __version__
        parts.append(str(__version__))
    except Exception:                                      # noqa: BLE001
        parts.append("?")
    for var in ("QS_GIT_COMMIT", "GIT_COMMIT", "QS_IMAGE_TAG", "IMAGE_TAG"):
        v = os.environ.get(var)
        if v:
            parts.append(f"{var.lower()}={v[:40]}")
    return " ".join(parts)[:120]


def _fact(facts: Dict[str, Any], key: str, fn) -> None:
    try:
        facts[key] = fn()
    except Exception as exc:                               # noqa: BLE001
        facts[key] = None
        facts[f"{key}_error"] = f"{type(exc).__name__}: {str(exc)[:200]}"


def gather_pod_facts(db: Any) -> Dict[str, Any]:
    """Everything a pod knows about itself, read once per cycle."""
    facts: Dict[str, Any] = {"uptime_seconds": int(time.time() - _STARTED_AT),
                             "build": build_identity()}

    def _role():
        from core.pod_role import current
        return str(current().role)

    def _workers():
        from core.worker_ledger import worker_ledger
        return worker_ledger()

    def _memory():
        from core.process_memory import (pod_memory_limit_bytes, process_memory_share_bytes,
                                         process_rss_bytes)
        rss, limit = process_rss_bytes(), pod_memory_limit_bytes()
        return {"rss_mb": None if rss is None else round(rss / 1048576),
                "limit_mb": None if limit is None else round(limit / 1048576),
                "share_mb": (None if process_memory_share_bytes(limit) is None
                             else round(process_memory_share_bytes(limit) / 1048576))}

    def _memory_guard():
        # the numbers the Operations Dashboard showed (folded 2026-10-17):
        # admission blocked / OK, available MB, in-flight queries + MB, blocks
        from core.memory_guard import watchdog_status
        s = watchdog_status() or {}
        return {"admission_blocked": bool(s.get("admission_blocked")),
                "admission_blocks_total": s.get("admission_blocks_total"),
                "running": s.get("running"),
                "last_sample_mb": s.get("last_sample_mb"),
                "inflight_count": s.get("inflight_count"),
                "inflight_total_mb": s.get("inflight_total_mb")}

    def _disk():
        from core.config import paths
        du = shutil.disk_usage(str(paths.data_dir))
        return {"free_gb": round(du.free / 1024 ** 3, 2),
                "used_pct": round(du.used / du.total * 100, 1)}

    def _db_health():
        from core.db_health_monitor import get_monitor
        s = get_monitor().snapshot() or {}
        return {"degraded": bool(s.get("degraded")), "p95_ms": s.get("recent_p95_ms"),
                "total_timeouts": s.get("total_timeouts")}

    def _db_pool():
        eng = getattr(db, "engine", None)
        pool = getattr(eng, "pool", None)
        out: Dict[str, Any] = {"dialect": getattr(getattr(eng, "dialect", None), "name", None)}
        for attr in ("size", "checkedout", "overflow"):
            fn = getattr(pool, attr, None)
            if callable(fn):
                try:
                    out[attr] = fn()
                except Exception:                          # noqa: BLE001
                    pass
        return out

    def _db_ping():
        t0 = time.monotonic()
        db.get_execution("__component_health_probe__")
        return {"ok": True, "ms": int((time.monotonic() - t0) * 1000)}

    def _config():
        from core.config import config_source
        s = config_source() or {}
        return {"file": s.get("config_file"), "exists": bool(s.get("config_file_exists")),
                "load_failed": bool(s.get("config_file_load_failed")), "via": s.get("config_file_via")}

    def _tls():
        from core.config import server as _server_cfg
        from core.server_tls import server_tls_kwargs
        return "active" if server_tls_kwargs(_server_cfg) else "plain"

    def _keys():
        from core.crypto import key_status
        s = key_status() or {}
        return {k: s.get(k) for k in ("source", "fingerprint", "available", "waiting", "owner",
                                       "mismatch", "refresh_error", "mode") if k in s}

    def _lock():
        from core import scheduler as _s
        return bool(_s._this_process_runs_apscheduler())

    def _lease():
        from core.scheduler_lease import get_active_lease
        lease = get_active_lease()
        return bool(lease is not None and lease.is_leader())

    def _scheduler_paused():
        from core.scheduler import get_scheduler_status
        return bool((get_scheduler_status() or {}).get("paused"))

    def _event_bus():
        from core import event_bus
        s = event_bus.stats() or {}
        return {"backend": s.get("backend"), "subscribers": s.get("subscriber_count")}

    def _breakers():
        from core.circuit_breaker import get_circuit_states
        # CircuitState values are lower case ('open'); the DB row says 'OPEN'
        return {str(b.get("connection_id")): {"state": str(b.get("state")).upper(),
                                              "failures": b.get("failure_count"),
                                              "last_error": (b.get("last_error") or "")[:200]}
                for b in (get_circuit_states() or []) if str(b.get("state")).lower() != "closed"}

    def _s3_breakers():
        from core.s3_circuit_breaker import get_s3_circuit_breaker
        return {str(k): {"state": v.get("state"), "failures": v.get("failure_count")}
                for k, v in (get_s3_circuit_breaker().get_all_states() or {}).items()
                if str(v.get("state")).lower() != "closed"}

    def _draining():
        from core.component_health.intents import effective_draining   # the readiness answer
        return effective_draining()

    def _processes():
        from core.process_topology import is_server_process, server_processes
        return {"server_process": bool(is_server_process()),
                "configured": server_processes() if is_server_process() else None}

    _fact(facts, "pod_role", _role)
    _fact(facts, "workers", _workers)
    _fact(facts, "memory", _memory)
    _fact(facts, "memory_guard", _memory_guard)
    _fact(facts, "disk", _disk)
    _fact(facts, "db_health", _db_health)
    _fact(facts, "db_pool", _db_pool)
    _fact(facts, "db_ping", _db_ping)
    _fact(facts, "config", _config)
    _fact(facts, "tls", _tls)
    _fact(facts, "keys", _keys)
    _fact(facts, "scheduler_lock_held", _lock)
    _fact(facts, "lease_held", _lease)
    _fact(facts, "scheduler_paused", _scheduler_paused)
    _fact(facts, "event_bus", _event_bus)
    _fact(facts, "open_breakers", _breakers)
    _fact(facts, "open_s3_breakers", _s3_breakers)
    _fact(facts, "draining", _draining)
    _fact(facts, "processes", _processes)
    return facts


def pod_self_probe(ctx: ProbeContext) -> Observation:
    f = ctx.facts or gather_pod_facts(ctx.db)
    problems: List[str] = []
    down: List[str] = []
    keys = f.get("keys") or {}
    if keys.get("mismatch"):
        down.append("encryption key MISMATCH: this pod's master key opens no stored data key "
                    f"(fingerprint {keys.get('fingerprint')})")
    if f.get("db_ping") is None:
        down.append(f"metadata database unreachable ({f.get('db_ping_error')})")
    if keys.get("waiting"):
        problems.append("encryption keys: WAITING for the owner to create the keyset")
    if keys.get("refresh_error"):
        problems.append(f"encryption keys: last re-read failed ({str(keys['refresh_error'])[:80]})")
    w = f.get("workers") or {}
    if w.get("known"):
        if (w.get("oom_kill") or 0) > 0:
            problems.append(f"cgroup oom_kill={w.get('oom_kill')} since start")
        if (w.get("respawns") or 0) > 0:
            problems.append(f"{w.get('respawns')} server process respawn(s)")
        if (w.get("died") or 0) > 0 and (w.get("alive") or 0) < (w.get("configured") or 1):
            problems.append(f"{w.get('alive')}/{w.get('configured')} server processes alive")
    mg = f.get("memory_guard") or {}
    if mg.get("admission_blocked"):
        problems.append("memory guard is refusing admissions")
    dbh = f.get("db_health") or {}
    if dbh.get("degraded"):
        problems.append(f"metadata DB degraded (p95 {dbh.get('p95_ms')} ms)")
    d = f.get("disk") or {}
    if d.get("free_gb") is not None and d["free_gb"] < 5.0:
        problems.append(f"disk: {d['free_gb']} GB free")
    cfg = f.get("config") or {}
    if cfg.get("load_failed"):
        problems.append(f"config file {cfg.get('file')} exists but failed to load: running on defaults")
    drain = f.get("draining") or {}
    disposition = DISPOSITION_DRAINING if drain.get("active") else None
    if drain.get("active"):
        problems.append(f"draining since {drain.get('since')} by {drain.get('by')}")
    metrics = {k: f.get(k) for k in ("uptime_seconds", "build", "workers", "memory", "memory_guard",
                                     "disk", "db_health", "db_pool", "db_ping", "config", "tls",
                                     "keys", "scheduler_lock_held", "lease_held", "scheduler_paused",
                                     "event_bus", "open_breakers", "open_s3_breakers", "draining",
                                     "processes")}
    metrics["fact_errors"] = {k: v for k, v in f.items() if k.endswith("_error")}
    if down:
        return Observation(DOWN, "; ".join(down), evidence="pod_facts", metrics=metrics,
                           disposition=disposition)
    if problems:
        return Observation(DEGRADED, "; ".join(problems), evidence="pod_facts", metrics=metrics,
                           disposition=disposition)
    return Observation(HEALTHY, f"reporting; role {f.get('pod_role')}, build {f.get('build')}, "
                                f"up {f.get('uptime_seconds')} s", evidence="pod_facts",
                       metrics=metrics, disposition=disposition)


REGISTRY.register(HealthCheck(
    component_id="pod:self", kind=KIND_POD, label="this pod", scope=SCOPE_PER_POD,
    owner=OWNER_EVERY_POD, probe=pod_self_probe, timeout_seconds=5.0, interval_seconds=15,
    controls=(CONTROL_DRAIN, CONTROL_UNDRAIN, CONTROL_RERUN_SELF_TEST), group="pods",
    legacy_routes=("/health", "/health/live", "/health/ready", "/api/admin/memory-guard/status",
                   "/api/admin/encryption-key", "/api/admin/database/status"),
    docs=("healthy: reporting every 15 s with no fault.  degraded: an OOM kill or a respawned "
          "server process, memory pressure refusing work, a degraded metadata DB, a key still "
          "WAITING, a disk under 5 GB, clock skew, or a drain in force.  down: the pod's master "
          "key opens no data key (mismatch), the metadata DB is unreachable, or the pod has not "
          "reported for pod_down_after_seconds.  unknown: not reported for stale_after_seconds.")))

__all__ = ["build_identity", "gather_pod_facts", "pod_self_probe"]
