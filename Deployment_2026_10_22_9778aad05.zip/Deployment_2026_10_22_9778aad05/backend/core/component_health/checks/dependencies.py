"""``dependency:connection:<id>`` and ``dependency:sftp:<host:port>`` --
DERIVED from the tables each watcher cycle (connections and feed
destinations come and go), probed once for everyone on the lock holder.

* a connection: THE connection test (``core.connection_test.run_connection_test``,
  the Test button's function, by type) on the DECRYPTED row, after a
  connect-level pre-check within the budget (unresolvable / refused / no
  handshake = ``down`` with that word), merged with every pod's breaker view
  (the pod rows' ``open_breakers`` / ``open_s3_breakers``) -- an OPEN breaker
  anywhere is ``down`` naming the pod; ``connections.last_test_*`` is written
  back so the Connections page says the same thing;
* an SFTP host: TCP connect + SSH banner, no login; a connect-level failure
  is ``down`` with its word; the last delivery outcome is passive evidence.

A connection type with no probe, or an excluded type, is a row that says
so (``unknown``), never a missing row.
"""
from __future__ import annotations

import logging
import socket
import time
from typing import Any, Dict, List, Optional, Set

from core.component_health.contract import HealthCheck, Observation, ProbeContext
from core.component_health.vocabulary import (
    CONTROL_PROBE_NOW, CONTROL_RESET_BREAKER, DEGRADED, DOWN, HEALTHY, KIND_DEPENDENCY,
    OWNER_FLEET_WATCHER, SCOPE_FLEET, UNKNOWN,
)

logger = logging.getLogger(__name__)

#: connection types the connector factory knows how to probe
PROBEABLE_TYPES = frozenset({"s3", "trino", "starburst", "oracle", "snowflake", "databricks", "athena",
                             "rest", "rest_api", "postgresql", "postgres", "mysql", "sqlserver", "hive"})
#: a local engine is not a dependency
LOCAL_TYPES = frozenset({"duckdb", "local", "sqlite", "file"})


def _probe_settings() -> Dict[str, Any]:
    try:
        from core.config import component_health as _cfg
        pc = _cfg.probe_connections or {}
    except Exception:                                      # noqa: BLE001
        pc = {}
    return {"mode": str(pc.get("mode") or "active"),
            "exclude_types": {str(t).lower() for t in (pc.get("exclude_types") or [])}}


def _budget(ctx: ProbeContext, cap: float) -> float:
    """Seconds left of the pool's deadline, capped; never below 0.3 s."""
    if ctx.deadline:
        return max(0.3, min(cap, ctx.deadline - time.time()))
    return cap


def _breakers_from_pods(db, connection_id: int) -> Dict[str, Dict[str, Any]]:
    """pod_id -> the open breaker entry for this connection, from the pod rows."""
    out: Dict[str, Dict[str, Any]] = {}
    try:
        for r in db.list_component_health(component_id="pod:self"):
            m = r.get("metrics") or {}
            for key in ("open_breakers", "open_s3_breakers"):
                hit = (m.get(key) or {}).get(str(connection_id))
                if hit:
                    out[str(r["pod_id"])] = dict(hit, registry=key)
    except Exception as exc:                               # noqa: BLE001
        logger.debug("[component_health] breaker view unreadable: %s", exc)
    return out


def connection_probe(conn: Dict[str, Any]):
    cid = int(conn["id"])
    ctype = str(conn.get("connection_type") or "").lower()
    name = str(conn.get("name") or cid)

    def _probe(ctx: ProbeContext) -> Observation:
        settings = _probe_settings()
        breakers = _breakers_from_pods(ctx.db, cid)
        metrics: Dict[str, Any] = {"connection_id": cid, "name": name, "type": ctype,
                                   "open_breakers": breakers}
        opened = [p for p, b in breakers.items() if str(b.get("state")).upper() == "OPEN"]
        half = [p for p, b in breakers.items() if str(b.get("state")).upper() == "HALF_OPEN"]
        if ctype in settings["exclude_types"]:
            if opened:
                return Observation(DOWN, f"circuit breaker OPEN on pod(s) {', '.join(opened)}",
                                   evidence="pod_facts:breakers", metrics=metrics)
            return Observation(UNKNOWN, f"type {ctype!r} is excluded by component_health.probe_connections",
                               evidence="config", metrics=metrics)
        if settings["mode"] == "none":
            if opened:
                return Observation(DOWN, f"circuit breaker OPEN on pod(s) {', '.join(opened)}",
                                   evidence="pod_facts:breakers", metrics=metrics)
            return Observation(UNKNOWN, "connection probes are off (component_health.probe_connections.mode=none)",
                               evidence="config", metrics=metrics)
        # The MASKED view (the browser's) names the secrets this process cannot
        # decrypt; the probe itself runs on the DECRYPTED row, exactly as the
        # Test button does (2026-10-18: it ran on the masked view and every
        # Oracle / Starburst connection with a password read DOWN "ORA-01017"
        # / "HTTP 401" while the Test button said OK).
        masked = ctx.db.get_connection(cid)
        if not masked:
            return Observation(UNKNOWN, "the connection row could not be read", evidence="connections", metrics=metrics)
        bad = list(masked.get("credential_problems") or [])
        if bad:
            return Observation(UNKNOWN, f"credentials unreadable ({', '.join(str(b) for b in bad)[:120]}): "
                                        f"the dependency cannot be probed from here", evidence="crypto",
                               metrics=metrics)
        full = ctx.db.get_connection_raw(cid)
        if not full:
            return Observation(UNKNOWN, "the connection row could not be read", evidence="connections", metrics=metrics)
        cfg = full.get("config") or {}
        ctype_stored = str(full.get("connection_type") or ctype)
        t0 = time.monotonic()
        # connect-level pre-check within the budget: unresolvable / refused /
        # no handshake is DOWN with that reason, never a connector that hangs
        # past the probe's budget and reads as "unknown: probe exceeded"
        from core.connection_test import endpoint_of, reach_endpoint, run_connection_test
        endpoint = endpoint_of(ctype_stored, cfg)
        if endpoint is not None:
            budget = _budget(ctx, 3.0)
            failure = reach_endpoint(endpoint[0], endpoint[1], budget)
            if failure is not None:
                metrics.update({"probe_ms": failure["ms"], "endpoint": f"{endpoint[0]}:{endpoint[1]}",
                                "connect_failure": failure["kind"]})
                reason = f"{failure['kind']}: {failure['detail']}"[:300]
                _write_back(ctx.db, cid, False, reason)
                return Observation(DOWN, reason, evidence="probe:tcp_connect", metrics=metrics)
            metrics["endpoint"] = f"{endpoint[0]}:{endpoint[1]}"
        try:
            result = run_connection_test(ctype_stored, cfg, db=ctx.db) or {}
        except Exception as exc:                           # noqa: BLE001
            ms = int((time.monotonic() - t0) * 1000)
            metrics["probe_ms"] = ms
            _write_back(ctx.db, cid, False, f"{type(exc).__name__}: {str(exc)[:200]}")
            return Observation(DOWN, f"{type(exc).__name__}: {str(exc)[:200]}", evidence="probe:test_connection",
                               metrics=metrics)
        ms = int((time.monotonic() - t0) * 1000)
        metrics["probe_ms"] = ms
        ok = bool(result.get("success", result.get("connected", False)))
        msg = str(result.get("message") or result.get("error") or "")[:200]
        _write_back(ctx.db, cid, ok, msg or ("ok" if ok else "failed"))
        if not ok:
            return Observation(DOWN, msg or "test_connection failed", evidence="probe:test_connection", metrics=metrics)
        if opened:
            return Observation(DOWN, f"probe ok but the circuit breaker is OPEN on pod(s) {', '.join(opened)}: "
                                     f"queries there fast-fail until it closes (reset it)",
                               evidence="pod_facts:breakers", metrics=metrics)
        problems: List[str] = []
        if half:
            problems.append(f"breaker HALF_OPEN on {', '.join(half)}")
        try:
            from core.config import component_health as _cfg
            if ms >= int(_cfg.slow_probe_ms):
                problems.append(f"probe took {ms} ms")
        except Exception:                                  # noqa: BLE001
            pass
        if problems:
            return Observation(DEGRADED, "; ".join(problems), evidence="probe:test_connection", metrics=metrics)
        return Observation(HEALTHY, f"test_connection ok in {ms} ms", evidence="probe:test_connection", metrics=metrics)
    _probe.__name__ = f"probe_connection_{cid}"
    return _probe


def _write_back(db, cid: int, ok: bool, message: str) -> None:
    """The Connections page shows the same answer (last_test_*)."""
    try:
        from datetime import datetime, timezone
        db.update_connection(cid, last_tested_at=datetime.now(timezone.utc),
                             last_test_status="success" if ok else "failed",
                             last_test_message=message[:500])
    except Exception as exc:                               # noqa: BLE001
        logger.debug("[component_health] last_test write-back failed for %s: %s", cid, exc)


def connection_checks(db) -> List[HealthCheck]:
    """One check per ACTIVE non-local connection, built from the table."""
    out: List[HealthCheck] = []
    try:
        rows = db.list_connections(active_only=True) or []
    except Exception as exc:                               # noqa: BLE001
        logger.warning("[component_health] connections unreadable: %s", exc)
        return out
    for conn in rows:
        ctype = str(conn.get("connection_type") or "").lower()
        if ctype in LOCAL_TYPES:
            continue
        cid = int(conn["id"])
        out.append(HealthCheck(
            component_id=f"dependency:connection:{cid}", kind=KIND_DEPENDENCY,
            label=f"{conn.get('name')} ({ctype})", scope=SCOPE_FLEET, owner=OWNER_FLEET_WATCHER,
            probe=connection_probe(conn), timeout_seconds=5.0, interval_seconds=30,
            controls=(CONTROL_RESET_BREAKER, CONTROL_PROBE_NOW),
            legacy_routes=("/api/admin/circuit-breakers", "/api/admin/s3/health",
                           f"/api/connections/{cid}/test"),
            group="connections",
            docs=("the connector's own test_connection, bounded; merged with every pod's breaker.  "
                  "down: refused / auth failed / an OPEN breaker anywhere; degraded: half-open or slow; "
                  "unknown: credentials unreadable, type excluded, probes off.")))
    return out


# ── sftp hosts ──────────────────────────────────────────────────────────────

def sftp_probe(host: str, port: int):
    def _probe(ctx: ProbeContext) -> Observation:
        budget = _budget(ctx, 3.0)
        t0 = time.monotonic()
        # resolve + connect within the budget, ONCE, resolution bounded
        # (core.connection_test.connect_within): a connect-level failure is
        # DOWN with its word -- the name no longer resolves (the service is
        # gone), the resolver gave no answer, the port refuses, the host is
        # unreachable -- we DETERMINED it, this is not unknown.  2026-10-18:
        # ``socket.create_connection`` resolved with no bound and the probe sat
        # in getaddrinfo past its budget, reading "unknown: probe exceeded".
        from core.connection_test import classify_connect_error, connect_within
        sock, failure = connect_within(host, port, budget)
        if failure is not None:
            return Observation(DOWN, f"{failure['kind']}: {failure['detail']}"[:300], evidence="probe:tcp_connect",
                               metrics={"host": host, "port": port, "connect_failure": failure["kind"]},
                               probe_ms=failure.get("ms"))
        left = max(0.3, budget - (time.monotonic() - t0))
        try:
            sock.settimeout(left)
            banner = sock.recv(128)
        except socket.timeout:
            return Observation(DOWN, f"connect timed out: {host}:{port} connected but sent no banner in {left:.1f} s",
                               evidence="probe:ssh_banner", metrics={"host": host, "port": port,
                                                                     "connect_failure": "connect timed out"})
        except OSError as exc:
            kind = classify_connect_error(exc)
            return Observation(DOWN, f"{kind}: {host}:{port}: {type(exc).__name__}: {str(exc)[:160]}",
                               evidence="probe:ssh_banner", metrics={"host": host, "port": port,
                                                                     "connect_failure": kind})
        finally:
            try:
                sock.close()
            except OSError:
                pass
        ms = int((time.monotonic() - t0) * 1000)
        text = banner.decode("ascii", "replace").strip()[:60]
        metrics = {"host": host, "port": port, "banner": text, "ms": ms}
        if not text.startswith("SSH-"):
            return Observation(DEGRADED, f"{host}:{port} answered but not with an SSH banner ({text!r})",
                               evidence="probe:ssh_banner", metrics=metrics)
        return Observation(HEALTHY, f"{text} in {ms} ms", evidence="probe:ssh_banner", metrics=metrics)
    _probe.__name__ = f"probe_sftp_{host}_{port}"
    return _probe


def sftp_hosts(db) -> Set[tuple]:
    out: Set[tuple] = set()
    try:
        feeds = db.list_feed_configs(is_active=True) or []
    except Exception as exc:                               # noqa: BLE001
        logger.warning("[component_health] feed destinations unreadable: %s", exc)
        return out
    for f in feeds:
        if str(f.get("destination_type") or "").lower() != "sftp":
            continue
        cfg = f.get("destination_config") or {}
        host = str(cfg.get("host") or cfg.get("hostname") or "").strip()
        if not host:
            continue
        try:
            port = int(cfg.get("port") or 22)
        except Exception:                                  # noqa: BLE001
            port = 22
        out.add((host, port))
    return out


def sftp_checks(db) -> List[HealthCheck]:
    out: List[HealthCheck] = []
    for host, port in sorted(sftp_hosts(db)):
        out.append(HealthCheck(
            component_id=f"dependency:sftp:{host}:{port}", kind=KIND_DEPENDENCY, label=f"SFTP {host}:{port}",
            scope=SCOPE_FLEET, owner=OWNER_FLEET_WATCHER, probe=sftp_probe(host, port), timeout_seconds=4.0,
            interval_seconds=30, controls=(CONTROL_PROBE_NOW,), group="delivery",
            docs="TCP connect + SSH banner, no login.  Derived from active feeds' SFTP destinations."))
    return out


def derived_checks(db) -> List[HealthCheck]:
    return connection_checks(db) + sftp_checks(db)


__all__ = ["LOCAL_TYPES", "PROBEABLE_TYPES", "connection_checks", "connection_probe", "derived_checks",
           "sftp_checks", "sftp_hosts", "sftp_probe"]
