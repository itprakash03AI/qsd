"""``daemon:<name>`` -- DERIVED: one check per declared daemon, nothing
hand-listed.  The inventory is ``daemon_registry.SCHEDULER_OWNED`` +
``background_job_contract.EXTRA_JOBS`` + ``PER_POD_DAEMONS``, i.e. exactly
``background_job_contract.declared_names()`` (+ the two component-health
daemons themselves).  A daemon added to the registry without a contract
already fails that module's guard; one with a contract appears here.

The probe runs on the pods that RUN the daemon (``daemon_runs_here``) and
reads first-hand evidence only: this process's ``background_jobs`` entry
(the coroutine's own started-event), the contract's ``status(db)``, the last
durable tick and its age against the daemon's cadence, the admin pause, the
job_control toggle, the singleton gate's outcome.  A pod that does not run
the daemon writes a ``deferred`` row (healthy, said), never a guess.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from core.component_health.contract import HealthCheck, Observation, ProbeContext
from core.component_health.registry import REGISTRY
from core.component_health.vocabulary import (
    CONTROL_PAUSE, CONTROL_RESUME, CONTROL_RUN_NOW, DEGRADED, DISPOSITION_DECLINED,
    DISPOSITION_DEFERRED, DISPOSITION_DISABLED, DISPOSITION_PAUSED, DOWN, HEALTHY, KIND_DAEMON,
    OWNER_PODS_RUNNING_PREFIX, SCOPE_PER_POD, SCOPE_SINGLETON, UNKNOWN,
)

logger = logging.getLogger(__name__)

#: the two component-health daemons are declared like every other one
REPORTER_NAME = "component_health_reporter"
WATCHER_NAME = "component_health_fleet_watcher"

#: the daemon's expected cadence when its contract does not say (seconds)
_DEFAULT_CADENCE_S = 3600

#: a daemon whose tick cadence is known from a DECLARED config key; every
#: other daemon's silence is judged against _DEFAULT_CADENCE_S (an hour
#: without a tick on a job that declares a job_id is degraded)
_CADENCE_KEYS = {
    REPORTER_NAME: ("component_health", "report_interval_seconds"),
    WATCHER_NAME: ("component_health", "report_interval_seconds"),
}

_GROUPS = (
    (("feed_", "sod", "etl_", "dq_", "dependency"), "feeds"),
    (("iceberg", "brain", "prefetch", "pruning", "mirror", "parquet", "bloom", "writer_advisor",
      "fleet_syncer", "partition", "output_gateway", "kafka_cache"), "brain"),
    (("spark",), "spark"),
    (("clockwork",), "clockwork"),
    (("component_health",), "platform"),
)


def group_of(name: str) -> str:
    for needles, group in _GROUPS:
        if any(n in name for n in needles):
            return group
    if "cleanup" in name or "retention" in name or "sweep" in name:
        return "retention"
    return "platform"


def idempotent_sweeps() -> frozenset:
    """The retention sweeps whose DUPLICATION IS BY DESIGN: ``main.py`` starts
    them as plain threads on every api / hybrid pod ("better to sweep twice
    than never", its ``_daemon_allowed`` docstring) AND the scheduler pod
    runs them as APScheduler jobs; each is an idempotent DELETE.  Declared
    from ``core.retention_daemons.JOB_IDS`` (the relocatable-daemon contract):
    the ``*_cleanup`` names.  A digest or a watcher in that list is NOT one --
    sent twice is a duplicate e-mail -- so the suffix, not the list, decides."""
    try:
        from core.retention_daemons import JOB_IDS
    except Exception:                                      # noqa: BLE001
        return frozenset()
    return frozenset(n for n in JOB_IDS if str(n).endswith("_cleanup"))


def duplication_by_design(name: str) -> bool:
    return name in idempotent_sweeps()


def _acts_here(name: str) -> bool:
    """Does THIS process ACT for ``name`` -- the one election
    (``daemon_registry.holds_single_runner_role``) for a singleton; always for
    a per-process job or an idempotent sweep.

    2026-10-18, the rebuilt rig's C5: after the scheduler pod was killed the
    hybrid api pod won the lock and the restarted scheduler pod started its
    leader-gated loops in STANDBY (alive, acting only if it wins the lock).
    Both reported "running" and the fleet said "running on more than one pod"
    for five daemons (alerts #105-#111).  A loop alive on a non-holder is
    standby, said so, never a second runner."""
    try:
        from core.background_job_contract import CONTRACTS, SCOPE_PER_PROCESS
        c = CONTRACTS.get(name)
        if c is not None and c.scope == SCOPE_PER_PROCESS:
            return True
    except Exception:                                      # noqa: BLE001
        pass
    if name in (REPORTER_NAME,) or duplication_by_design(name):
        return True
    try:
        from core.daemon_registry import holds_single_runner_role
        return bool(holds_single_runner_role())
    except Exception:                                      # noqa: BLE001
        return False


def _cadence_seconds(name: str) -> int:
    key = _CADENCE_KEYS.get(name)
    if key:
        try:
            from core.config import get as _get
            v = _get(key[0], key[1], None)
            if v:
                return max(5, int(float(v)))
        except Exception:                                  # noqa: BLE001
            pass
    return _DEFAULT_CADENCE_S


def _age(ts: Any) -> Optional[float]:
    from core.component_health.rules import parse_ts
    d = parse_ts(ts)
    return None if d is None else (datetime.now(timezone.utc) - d).total_seconds()


def daemon_probe(name: str):
    def _probe(ctx: ProbeContext) -> Observation:
        from core import background_jobs as _bj
        from core.background_job_contract import CONTRACTS, last_tick
        from core.daemon_registry import _SINGLETON_OUTCOMES, admin_disabled
        metrics: Dict[str, Any] = {"running": False}
        c = CONTRACTS.get(name)
        outcome = _SINGLETON_OUTCOMES.get(name)
        if outcome == "deferred":
            return Observation(HEALTHY, "not running here by design: deferred to the scheduler-lock "
                                        "holder", evidence="singleton_gate", metrics=metrics,
                               disposition=DISPOSITION_DEFERRED)
        if outcome == "declined":
            return Observation(HEALTHY, "the gate invoked it and it declined to start (feature off / "
                                        "transport none)", evidence="singleton_gate", metrics=metrics,
                               disposition=DISPOSITION_DECLINED)
        job = _bj.get_job(name)
        local = job.to_dict() if job is not None and not getattr(job, "remote", False) else None
        boot = _bj._boot_registered.get(name) if hasattr(_bj, "_boot_registered") else None
        paused = False
        try:
            paused = bool(_bj.is_paused(name))
        except Exception:                                  # noqa: BLE001
            pass
        disabled = False
        try:
            disabled = bool(admin_disabled(name))
        except Exception:                                  # noqa: BLE001
            pass
        tick = None
        try:
            tick = last_tick(name)
        except Exception as exc:                           # noqa: BLE001
            metrics["tick_error"] = f"{type(exc).__name__}: {str(exc)[:120]}"
        status: Dict[str, Any] = {}
        if c is not None:
            try:
                raw = c.status(ctx.db) or {}
                status = {k: v for k, v in raw.items() if isinstance(v, (str, int, float, bool, type(None)))}
            except Exception as exc:                       # noqa: BLE001
                status = {"status_error": f"{type(exc).__name__}: {str(exc)[:120]}"}
        running = bool(local and local.get("running")) or bool(boot and boot.get("running"))
        if status.get("running") is True or status.get("loop_alive_here") is True:
            running = True
        if status.get("running") is False and local is None and boot is None:
            running = False
        acts = _acts_here(name)
        metrics.update({"running": running, "paused": paused, "admin_disabled": disabled,
                        "last_tick": tick, "status": status, "acts": acts,
                        "liveness": (local or {}).get("liveness"),
                        "registered_how": (boot or {}).get("how")})
        cadence = _cadence_seconds(name)
        from core.config import component_health as _cfg
        silent_after = cadence * _cfg.daemon_silent_intervals
        if paused:
            return Observation(DEGRADED, f"paused by an admin (job_control / background_job_state)"
                                         + ("; " + str(local.get("paused_at")) if local and local.get("paused_at") else ""),
                               evidence="background_job_state", metrics=metrics,
                               disposition=DISPOSITION_PAUSED)
        if disabled:
            return Observation(HEALTHY, "switched off by an admin toggle (job_control)",
                               evidence="job_control", metrics=metrics, disposition=DISPOSITION_DISABLED)
        if not acts and (running or local is not None or boot is not None):
            # alive here, acting nowhere: STANDBY on a non-holder -- said, and
            # never counted as a runner (metrics.running=False, standby=True)
            holder = None
            try:
                from core.effective_posture import _scheduler_lock_row
                holder = (_scheduler_lock_row(ctx.db) or {}).get("worker_id")
            except Exception:                              # noqa: BLE001
                pass
            metrics.update({"running": False, "standby": True})
            return Observation(HEALTHY, "standby: alive here but only the single-runner acts"
                                        + (f" (the lock is held by {holder})" if holder else " (this process does not hold the lock)"),
                               evidence="single_runner_gate", metrics=metrics, disposition=DISPOSITION_DEFERRED)
        if status.get("refusal") and not running:
            return Observation(HEALTHY, f"not running: {str(status['refusal'])[:200]}",
                               evidence="module_status", metrics=metrics, disposition=DISPOSITION_DISABLED)
        if local is not None and local.get("status") in ("errored", "crashed") or (local or {}).get("last_error"):
            return Observation(DEGRADED, f"last error: {str((local or {}).get('last_error'))[:200]}",
                               evidence="background_jobs", metrics=metrics)
        if tick and tick.get("outcome") in ("error", "unreadable"):
            return Observation(DEGRADED, f"last tick {tick.get('outcome')}: {str(tick.get('reason') or '')[:200]}",
                               evidence="background_job_ticks", metrics=metrics)
        if status.get("transport_fault"):
            return Observation(DOWN, f"transport fault: {str(status['transport_fault'])[:200]}",
                               evidence="module_status", metrics=metrics)
        if local is not None and local.get("liveness") and local["liveness"].get("started") is False \
                and local.get("running"):
            return Observation(DOWN, "registered and 'running' but the coroutine never ran its first "
                                     "line (loop not running)", evidence="background_jobs", metrics=metrics)
        if not running and (local is not None or boot is not None):
            return Observation(DOWN, f"registered here but not running ({(local or boot or {}).get('status')})",
                               evidence="background_jobs", metrics=metrics)
        if tick:
            age = _age(tick.get("at"))
            metrics["last_tick_age_s"] = None if age is None else round(age)
            if age is not None and age > silent_after and c is not None and c.job_id:
                return Observation(DEGRADED, f"no tick for {age:.0f} s (cadence {cadence} s)",
                                   evidence="background_job_ticks", metrics=metrics)
        if not running and local is None and boot is None:
            return Observation(UNKNOWN, "this process has no record of the daemon (not registered, "
                                        "no gate outcome, no boot record)",
                               evidence="background_jobs", metrics=metrics)
        words = "running" if running else "registered"
        if tick:
            words += f"; last tick {tick.get('outcome')} {metrics.get('last_tick_age_s')} s ago"
        return Observation(HEALTHY, words, evidence="background_jobs", metrics=metrics)
    _probe.__name__ = f"probe_daemon_{name}"
    return _probe


def pausable_names() -> frozenset:
    """The daemons ``background_jobs`` knows on EVERY pod -- registered for
    real on the owner and as a remote placeholder everywhere else
    (``daemon_registry.register_remote_placeholders``): the registry's
    ``SCHEDULER_OWNED`` and ``API_OWNED`` names.

    2026-10-18, from the rig: ``pause daemon:feed_sod_generator`` answered
    404 "unknown background job".  An ``EXTRA_JOBS`` name (an APScheduler
    core job such as the SOD generator, a listener, a per-process loop) has
    NO ``background_jobs`` entry on any pod, and its tick does not read
    ``is_paused`` -- so a pause of it could never take effect.  A control
    that cannot work is not offered: those daemons declare ``run_now`` only
    (where their contract is runnable)."""
    from core.daemon_registry import API_OWNED, SCHEDULER_OWNED
    return frozenset(SCHEDULER_OWNED) | frozenset(API_OWNED)


def daemon_controls(name: str) -> tuple:
    from core.background_job_contract import CONTRACTS
    c = CONTRACTS.get(name)
    controls = []
    if name in pausable_names():
        controls += [CONTROL_PAUSE, CONTROL_RESUME]
    if c is not None and c.runnable:
        controls.append(CONTROL_RUN_NOW)
    if name in (REPORTER_NAME,):
        controls = [CONTROL_RUN_NOW]   # the reporter is non-controllable (a paused reporter
                                      # could never report its resume)
    return tuple(controls)


def declared_daemon_names() -> list:
    from core.background_job_contract import declared_names
    from core.daemon_registry import PER_POD_DAEMONS
    return sorted(set(declared_names()) | set(PER_POD_DAEMONS))


def _scope_of(name: str) -> str:
    from core.background_job_contract import CONTRACTS, SCOPE_PER_PROCESS
    from core.daemon_registry import PER_POD_DAEMONS
    c = CONTRACTS.get(name)
    if name in PER_POD_DAEMONS or (c is not None and c.scope == SCOPE_PER_PROCESS):
        return SCOPE_PER_POD
    if duplication_by_design(name):
        return SCOPE_PER_POD        # an idempotent sweep on every pod is never "more than one runner"
    return SCOPE_SINGLETON


def register_all() -> int:
    from core.background_job_contract import CONTRACTS
    n = 0
    for name in declared_daemon_names():
        c = CONTRACTS.get(name)
        REGISTRY.register(HealthCheck(
            component_id=f"daemon:{name}", kind=KIND_DAEMON, label=name.replace("_", " "),
            scope=_scope_of(name), owner=f"{OWNER_PODS_RUNNING_PREFIX}{name}",
            probe=daemon_probe(name), timeout_seconds=3.0, interval_seconds=15,
            controls=daemon_controls(name),
            legacy_routes=(f"/api/admin/background-jobs/{name}/status", "/api/admin/background-jobs"),
            group=group_of(name),
            docs=((c.note if c is not None else "") + "  healthy: running (or registered for its "
                  "cadence) on the expected pods, last tick ok / no_input.  degraded: paused, a "
                  "duplicated singleton, a last tick in error, or no tick for daemon_silent_intervals "
                  "x its cadence.  down: expected and running nowhere, a coroutine that never started, "
                  "or its owning pod down.  unknown: no report and the owner alive.")), replace=True)
        n += 1
    return n


register_all()

__all__ = ["REPORTER_NAME", "WATCHER_NAME", "daemon_controls", "daemon_probe", "declared_daemon_names",
           "duplication_by_design", "group_of", "idempotent_sweeps", "pausable_names", "register_all"]
