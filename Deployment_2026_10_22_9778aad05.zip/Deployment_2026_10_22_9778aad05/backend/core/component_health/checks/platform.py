"""The platform dependencies, probed ONCE for everyone by the fleet watcher
(``owner=fleet_watcher``): the metadata DB, the scheduler election, SMTP,
Netcool, Kafka, Vault, the Spark lanes, Airflow, Redis, the encryption
keys, and processes that have no reporter (probed by a declared URL).

Every probe is bounded by the pool; each returns a disposition
``disabled_by_config`` when the dependency is not configured -- a thing
that is off is not a thing that is broken, and it is said.
"""
from __future__ import annotations

import socket
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse

from core.component_health.contract import HealthCheck, Observation, ProbeContext
from core.component_health.registry import REGISTRY
from core.component_health.vocabulary import (
    CONTROL_PAUSE, CONTROL_PROBE_NOW, CONTROL_RESUME, DEGRADED, DISPOSITION_DISABLED,
    DISPOSITION_PAUSED, DOWN, HEALTHY, KIND_DEPENDENCY, KIND_POD, OWNER_FLEET_WATCHER,
    SCOPE_FLEET, UNKNOWN,
)


def _budget(ctx: ProbeContext, default: float = 3.0) -> float:
    if ctx.deadline:
        return max(0.2, min(default, ctx.deadline - time.time()))
    return default


def tcp_connect(host: str, port: int, timeout: float) -> Tuple[bool, str, int]:
    """(reachable, detail, ms).  A refused / timed-out connect is a statement
    about reachability, nothing more."""
    t0 = time.monotonic()
    try:
        with socket.create_connection((host, int(port)), timeout=timeout):
            return True, "connected", int((time.monotonic() - t0) * 1000)
    except socket.timeout:
        return False, f"connect timed out after {timeout:.1f} s", int((time.monotonic() - t0) * 1000)
    except OSError as exc:
        return False, f"{type(exc).__name__}: {str(exc)[:160]}", int((time.monotonic() - t0) * 1000)


def _slow(ms: int) -> bool:
    try:
        from core.config import component_health as _cfg
        return ms >= int(_cfg.slow_probe_ms)
    except Exception:                                      # noqa: BLE001
        return False


# ── postgres ─────────────────────────────────────────────────────────────────

def probe_postgres(ctx: ProbeContext) -> Observation:
    db = ctx.db
    t0 = time.monotonic()
    try:
        db.get_execution("__component_health_fleet_probe__")
    except Exception as exc:                               # noqa: BLE001
        return Observation(DOWN, f"SELECT failed: {type(exc).__name__}: {str(exc)[:200]}",
                           evidence="probe:select")
    ms = int((time.monotonic() - t0) * 1000)
    metrics: Dict[str, Any] = {"select_ms": ms, "dialect": None}
    try:
        metrics["dialect"] = db.engine.dialect.name
    except Exception:                                      # noqa: BLE001
        pass
    problems: List[str] = []
    try:
        from core.db_health_monitor import get_monitor
        s = get_monitor().snapshot() or {}
        metrics["degraded_here"] = bool(s.get("degraded"))
        metrics["p95_ms"] = s.get("recent_p95_ms")
        if s.get("degraded"):
            problems.append(f"the watcher's pod sees the DB degraded (p95 {s.get('recent_p95_ms')} ms)")
    except Exception:                                      # noqa: BLE001
        pass
    # the pods' own views (their pod rows), one query
    try:
        rows = db.list_component_health(component_id="pod:self")
        bad = [r["pod_id"] for r in rows if (r.get("metrics") or {}).get("db_health", {}) and
               (r.get("metrics") or {}).get("db_health", {}).get("degraded")]
        metrics["pods_reporting_degraded"] = bad
        if bad:
            problems.append("degraded on pod(s) " + ", ".join(bad[:5]))
    except Exception as exc:                               # noqa: BLE001
        metrics["pods_error"] = str(exc)[:120]
    try:
        if getattr(db, "is_postgresql", False):
            reps = db.get_replica_status() or []
            metrics["replicas"] = len(reps)
            unhealthy = [r for r in reps if not r.get("healthy")]
            if unhealthy:
                problems.append(f"{len(unhealthy)}/{len(reps)} replica(s) unhealthy")
    except Exception:                                      # noqa: BLE001
        pass
    if _slow(ms):
        problems.append(f"SELECT took {ms} ms")
    if problems:
        return Observation(DEGRADED, "; ".join(problems), evidence="probe:select", metrics=metrics)
    return Observation(HEALTHY, f"SELECT in {ms} ms", evidence="probe:select", metrics=metrics)


# ── the scheduler election ──────────────────────────────────────────────────

def scheduler_verdict(db) -> Observation:
    """Computed on read AND recorded by the watcher: who holds the lock (THE
    one election), how fresh, whether APScheduler is paused; the lease, when
    one is held, is a metric only."""
    from core.effective_posture import LOCK_STALE_AFTER_S, _scheduler_lock_row
    metrics: Dict[str, Any] = {}
    try:
        lock = _scheduler_lock_row(db)
    except Exception as exc:                               # noqa: BLE001
        return Observation(UNKNOWN, f"the scheduler lock could not be read ({type(exc).__name__}: "
                                    f"{str(exc)[:160]})", evidence="scheduler_lock")
    try:
        from core.scheduler_lease import current_holder
        metrics["lease_holder"] = current_holder(db)
    except Exception:                                      # noqa: BLE001
        metrics["lease_holder"] = None
    if lock is None:
        return Observation(DOWN, "no scheduler lock holder is recorded: no process runs APScheduler, "
                                 "so no feed gate, sweep or singleton ticks", evidence="scheduler_lock",
                           metrics=metrics)
    metrics.update({"lock_holder": lock.get("worker_id"), "lock_heartbeat_age_s": lock.get("heartbeat_age_seconds")})
    age = lock.get("heartbeat_age_seconds")
    if age is not None and age > LOCK_STALE_AFTER_S:
        return Observation(DOWN, f"the lock holder {lock.get('worker_id')} last heartbeat {age:.0f} s "
                                 f"ago (stale after {LOCK_STALE_AFTER_S} s): APScheduler is not "
                                 f"running anywhere until the lock is taken over",
                           evidence="scheduler_lock", metrics=metrics)
    paused: Optional[bool] = None
    try:
        rows = db.list_component_health(component_id="pod:self")
        for r in rows:
            m = r.get("metrics") or {}
            if m.get("scheduler_lock_held"):
                paused = bool(m.get("scheduler_paused"))
                metrics["holder_pod"] = r.get("pod_id")
    except Exception:                                      # noqa: BLE001
        pass
    if paused:
        return Observation(DEGRADED, f"APScheduler is PAUSED on the lock holder {lock.get('worker_id')} "
                                     f"(maintenance): no scheduled job fires", evidence="pod_facts",
                           metrics=metrics, disposition=DISPOSITION_PAUSED)
    # ONE election.  2026-10-18: the first rig run found the hybrid api pod
    # holding the BF-410.4 lease beside the scheduler pod's lock, with three
    # of main.py's duties gated on the lease -- a real double election, fixed
    # at the source (commit 452e51740: every single-runner duty is gated on
    # ``daemon_registry.holds_single_runner_role()`` = the lock;
    # ``is_scheduler_leader`` is gone).  main.py may still TAKE the lease, but
    # nothing gates on it any more, so a lease held elsewhere is a metric
    # here (``lease_holder``), never a second leader.  The verdict is the
    # lock's alone.
    lease = metrics.get("lease_holder")
    host = str(lock.get("worker_id") or "").split(":")[0]
    metrics["lock_host"] = host
    if lease:
        metrics["lease_host"] = str(lease).split("#")[0]
        metrics["lease_gates_nothing"] = True
    return Observation(HEALTHY, f"lock held by {lock.get('worker_id')}, heartbeat {age:.0f} s ago"
                       if age is not None else f"lock held by {lock.get('worker_id')}",
                       evidence="scheduler_lock", metrics=metrics)


def probe_scheduler(ctx: ProbeContext) -> Observation:
    return scheduler_verdict(ctx.db)


# ── smtp ─────────────────────────────────────────────────────────────────────

def probe_smtp(ctx: ProbeContext) -> Observation:
    from core.email_service import get_email_config, is_email_enabled, last_send_failure_reason
    cfg = get_email_config() or {}
    metrics = {"host": cfg.get("host"), "port": cfg.get("port"), "use_tls": cfg.get("use_tls"),
               "use_ssl": cfg.get("use_ssl")}
    if not is_email_enabled():
        return Observation(HEALTHY, "e-mail is not configured (email.host empty)",
                           evidence="config", metrics=metrics, disposition=DISPOSITION_DISABLED)
    budget = _budget(ctx)
    import smtplib
    t0 = time.monotonic()
    try:
        if cfg.get("use_ssl"):
            s = smtplib.SMTP_SSL(cfg["host"], int(cfg.get("port") or 465), timeout=budget)
        else:
            s = smtplib.SMTP(cfg["host"], int(cfg.get("port") or 587), timeout=budget)
        try:
            code, _ = s.ehlo()
            if cfg.get("use_tls") and not cfg.get("use_ssl"):
                s.starttls()
                code, _ = s.ehlo()
        finally:
            try:
                s.quit()
            except Exception:                              # noqa: BLE001
                pass
    except Exception as exc:                               # noqa: BLE001
        return Observation(DOWN, f"{cfg.get('host')}:{cfg.get('port')}: {type(exc).__name__}: {str(exc)[:160]}",
                           evidence="probe:smtp_ehlo", metrics=metrics)
    ms = int((time.monotonic() - t0) * 1000)
    metrics["ehlo_ms"] = ms
    fail = last_send_failure_reason()
    if fail:
        metrics["last_send_failure"] = str(fail)[:200]
        return Observation(DEGRADED, f"reachable (EHLO {code}) but the last send failed: {str(fail)[:160]}",
                           evidence="probe:smtp_ehlo", metrics=metrics)
    return Observation(HEALTHY, f"EHLO {code} in {ms} ms", evidence="probe:smtp_ehlo", metrics=metrics)


# ── netcool ──────────────────────────────────────────────────────────────────

def probe_netcool(ctx: ProbeContext) -> Observation:
    from core.feed import netcool_sender as ns
    cfg = ns.load_config()
    status = ns.get_status(getattr(ctx.db, "SessionLocal", None)) or {}
    metrics = {"transport": cfg.get("transport"), "endpoint": cfg.get("endpoint"),
               "queue_depth": status.get("queue_depth"), "dead_letter_count": status.get("dead_letter_count"),
               "retry_pending": status.get("retry_pending"), "last_heartbeat_at": status.get("last_heartbeat_at"),
               "environment": status.get("environment"), "sender_running_here": status.get("running")}
    if str(cfg.get("transport") or "none") == "none":
        return Observation(HEALTHY, "Netcool transport is 'none'", evidence="config", metrics=metrics,
                           disposition=DISPOSITION_DISABLED)
    problems: List[str] = []
    ep = str(cfg.get("endpoint") or "")
    host, port = None, None
    try:
        u = urlparse(ep if "://" in ep else f"tcp://{ep}")
        host, port = u.hostname, u.port
    except Exception:                                      # noqa: BLE001
        pass
    if host and port:
        ok, detail, ms = tcp_connect(host, port, _budget(ctx))
        metrics["connect_ms"] = ms
        if not ok:
            return Observation(DOWN, f"{host}:{port}: {detail}", evidence="probe:tcp", metrics=metrics)
    if (status.get("dead_letter_count") or 0) > 0:
        problems.append(f"{status['dead_letter_count']} dead letter(s)")
    hb = status.get("last_heartbeat_at")
    if hb:
        from core.component_health.rules import age_seconds
        age = age_seconds(hb)
        if age is not None and age > 3 * float(cfg.get("heartbeat_interval_seconds") or 300):
            problems.append(f"last heartbeat {age:.0f} s ago")
    if problems:
        return Observation(DEGRADED, "; ".join(problems), evidence="netcool_sender.get_status", metrics=metrics)
    return Observation(HEALTHY, f"transport {cfg.get('transport')} reachable; queue depth {status.get('queue_depth')}",
                       evidence="netcool_sender.get_status", metrics=metrics)


# ── kafka ────────────────────────────────────────────────────────────────────

def probe_kafka(ctx: ProbeContext) -> Observation:
    from core.feed import kafka_arrivals as ka
    cfg = ka.load_config()
    st = ka.get_status() or {}
    cache_cfg: Dict[str, Any] = {}
    try:
        from core.kafka_cache_consumer import get_status as _cache_status
        cache_cfg = _cache_status() or {}
    except Exception:                                      # noqa: BLE001
        pass
    metrics = {"bootstrap_servers": cfg.get("bootstrap_servers"), "arrivals_enabled": cfg.get("enabled"),
               "arrivals_running_here": st.get("running"), "transport_fault": st.get("transport_fault"),
               "cache_consumer_enabled": cache_cfg.get("enabled"), "topics": cfg.get("topics")}
    if not cfg.get("enabled") and not cache_cfg.get("enabled"):
        return Observation(HEALTHY, "no Kafka consumer is enabled", evidence="config", metrics=metrics,
                           disposition=DISPOSITION_DISABLED)
    servers = [s.strip() for s in str(cfg.get("bootstrap_servers") or "").split(",") if s.strip()]
    if not servers:
        return Observation(DOWN, "a Kafka consumer is enabled but bootstrap_servers is empty",
                           evidence="config", metrics=metrics)
    reach = []
    for srv in servers[:3]:
        host, _, port = srv.rpartition(":")
        ok, detail, ms = tcp_connect(host or srv, int(port or 9092), _budget(ctx) / max(1, min(3, len(servers))))
        reach.append((srv, ok, detail, ms))
    metrics["brokers"] = [{"server": s, "reachable": ok, "ms": ms} for s, ok, _d, ms in reach]
    if not any(ok for _s, ok, _d, _m in reach):
        return Observation(DOWN, "no broker reachable: " + "; ".join(f"{s}: {d}" for s, _ok, d, _m in reach),
                           evidence="probe:tcp", metrics=metrics)
    if st.get("transport_fault"):
        return Observation(DOWN, f"the consumer reports a transport fault: {str(st['transport_fault'])[:160]}",
                           evidence="kafka_arrivals.get_status", metrics=metrics)
    if cfg.get("enabled") and st.get("refusal"):
        return Observation(DEGRADED, f"arrivals consumer not running: {str(st['refusal'])[:160]}",
                           evidence="kafka_arrivals.get_status", metrics=metrics)
    down = [s for s, ok, _d, _m in reach if not ok]
    if down:
        return Observation(DEGRADED, "broker(s) unreachable: " + ", ".join(down), evidence="probe:tcp",
                           metrics=metrics)
    return Observation(HEALTHY, f"{len(reach)} broker(s) reachable", evidence="probe:tcp", metrics=metrics)


# ── vault ────────────────────────────────────────────────────────────────────

def probe_vault(ctx: ProbeContext) -> Observation:
    try:
        from core.config import get as _get
        enabled = bool(_get("secrets", "enabled", False))
    except Exception:                                      # noqa: BLE001
        enabled = False
    if not enabled:
        return Observation(HEALTHY, "Vault-backed system accounts are off (secrets.enabled=false)",
                           evidence="config", disposition=DISPOSITION_DISABLED)
    # the qsclient library the resolver calls reads the Vault address from
    # ITS environment; this probe reads the same variables and declares no
    # config key of its own (a key declared here and nowhere else would be
    # a second place to configure Vault).
    import os
    url = next((os.environ[v] for v in ("VAULT_ADDR", "QS_VAULT_ADDR", "QS_VAULT_URL") if os.environ.get(v)), None)
    metrics: Dict[str, Any] = {"url": url}
    if not url:
        return Observation(UNKNOWN, "secrets.enabled is true but no Vault address is in the environment "
                                    "(VAULT_ADDR / QS_VAULT_ADDR): reachability cannot be probed",
                           evidence="environment", metrics=metrics)
    u = urlparse(url)
    ok, detail, ms = tcp_connect(u.hostname or url, u.port or (443 if u.scheme == "https" else 8200), _budget(ctx))
    metrics["connect_ms"] = ms
    if not ok:
        return Observation(DOWN, f"{u.hostname}:{u.port}: {detail}", evidence="probe:tcp", metrics=metrics)
    return Observation(HEALTHY, f"reachable in {ms} ms (TCP; a token lookup is not attempted)",
                       evidence="probe:tcp", metrics=metrics)


# ── spark lanes + airflow ───────────────────────────────────────────────────

def probe_spark_k8s(ctx: ProbeContext) -> Observation:
    from core.config import spark_k8s as sk
    metrics = {"enabled": bool(sk.enabled), "submit_mode": sk.submit_mode, "namespace": sk.namespace}
    if not sk.enabled:
        return Observation(HEALTHY, "spark_k8s.enabled=false", evidence="config", metrics=metrics,
                           disposition=DISPOSITION_DISABLED)
    from core.feed.backend_router import lane_availability
    av = lane_availability("spark_k8s")
    metrics["describe"] = av.describe()
    if av.available:
        return Observation(HEALTHY, av.describe(), evidence="backend_router.lane_availability", metrics=metrics)
    return Observation(DOWN, av.describe(), evidence="backend_router.lane_availability", metrics=metrics)


def probe_spark_connect(ctx: ProbeContext) -> Observation:
    from core.config import spark_connect as sc
    metrics: Dict[str, Any] = {"enabled": bool(sc.enabled), "server_url": sc.server_url}
    if not sc.enabled:
        return Observation(HEALTHY, "spark_connect.enabled=false", evidence="config", metrics=metrics,
                           disposition=DISPOSITION_DISABLED)
    u = urlparse(sc.server_url)
    ok, detail, ms = tcp_connect(u.hostname or sc.server_url, u.port or 15002, _budget(ctx))
    metrics["connect_ms"] = ms
    try:
        from core.spark_connect_session_manager import get_session_stats
        metrics["sessions"] = get_session_stats()
    except Exception:                                      # noqa: BLE001
        pass
    if not ok:
        return Observation(DOWN, f"{u.hostname}:{u.port or 15002}: {detail}", evidence="probe:tcp", metrics=metrics)
    return Observation(HEALTHY, f"reachable in {ms} ms (TCP; no session opened)", evidence="probe:tcp",
                       metrics=metrics)


def probe_airflow(ctx: ProbeContext) -> Observation:
    from core.config import feed_generation as fg
    if not bool(getattr(fg, "airflow_enabled", False)):
        return Observation(HEALTHY, "feed_generation.airflow_enabled=false", evidence="config",
                           disposition=DISPOSITION_DISABLED)
    from core.feed.health import probe_airflow as _probe
    h = _probe(fg, timeout_seconds=_budget(ctx))
    metrics = dict(h.extras or {})
    return Observation(HEALTHY if h.healthy else DOWN, h.detail, evidence="feed.health.probe_airflow",
                       metrics=metrics)


# ── redis ────────────────────────────────────────────────────────────────────

def probe_redis(ctx: ProbeContext) -> Observation:
    from core.config import queue as _q
    if getattr(_q, "backend", "") != "redis":
        return Observation(HEALTHY, "queue.backend is not redis", evidence="config",
                           disposition=DISPOSITION_DISABLED)
    try:
        from core.task_queue import get_task_queue
        tq = get_task_queue()
        if hasattr(tq, "get_status"):
            tq.get_status()
    except Exception as exc:                               # noqa: BLE001
        return Observation(DOWN, f"{type(exc).__name__}: {str(exc)[:160]}", evidence="task_queue.get_status")
    return Observation(HEALTHY, "redis answers", evidence="task_queue.get_status")


# ── encryption keys (fleet) ─────────────────────────────────────────────────

_key_sweep_cache: Dict[str, Any] = {"at": 0.0, "value": None}


def probe_encryption_keys(ctx: ProbeContext) -> Observation:
    db = ctx.db
    rows = db.list_component_health(component_id="pod:self")
    fps: Dict[str, List[str]] = {}
    waiting, mismatch, refresh = [], [], []
    for r in rows:
        k = ((r.get("metrics") or {}).get("keys") or {})
        if not k:
            continue
        fps.setdefault(str(k.get("fingerprint")), []).append(str(r.get("pod_id")))
        if k.get("waiting"):
            waiting.append(str(r["pod_id"]))
        if k.get("mismatch"):
            mismatch.append(str(r["pod_id"]))
        if k.get("refresh_error"):
            refresh.append(str(r["pod_id"]))
    metrics: Dict[str, Any] = {"fingerprints": fps, "waiting": waiting, "mismatch": mismatch,
                               "refresh_error": refresh}
    # the stored-secret sweep, at most every key_sweep_interval_seconds
    try:
        from core.config import component_health as _cfg
        every = int(_cfg.key_sweep_interval_seconds)
    except Exception:                                      # noqa: BLE001
        every = 300
    now = time.time()
    if _key_sweep_cache["value"] is None or now - _key_sweep_cache["at"] > every:
        try:
            from core.encryption_key_rotation import sweep
            live = sweep(db, write=False) or {}
            _key_sweep_cache.update({"at": now, "value": {
                "current": live.get("current"), "needs_rotation": live.get("rotated"),
                "unreadable": live.get("unreadable"), "fix": live.get("fix")}})
        except Exception as exc:                           # noqa: BLE001
            _key_sweep_cache.update({"at": now, "value": {"error": f"{type(exc).__name__}: {str(exc)[:160]}"}})
    stored = dict(_key_sweep_cache["value"] or {})
    metrics["stored"] = stored
    unreadable = stored.get("unreadable")
    n_unreadable = len(unreadable) if isinstance(unreadable, (list, dict)) else (unreadable or 0)
    if mismatch:
        return Observation(DOWN, f"pod(s) {', '.join(mismatch)} hold a master key that opens no data key",
                           evidence="pod_facts+sweep", metrics=metrics)
    if n_unreadable:
        return Observation(DOWN, f"{n_unreadable} stored secret(s) no key of this deployment can read"
                                 + (f": {str(stored.get('fix'))[:200]}" if stored.get("fix") else ""),
                           evidence="encryption_key_rotation.sweep", metrics=metrics)
    problems: List[str] = []
    if len([f for f in fps if f and f != "None"]) > 1:
        problems.append(f"{len(fps)} key fingerprints in the fleet: "
                        + "; ".join(f"{fp[:12]}: {', '.join(p)}" for fp, p in fps.items()))
    if waiting:
        problems.append("WAITING on pod(s) " + ", ".join(waiting))
    if refresh:
        problems.append("re-read failing on pod(s) " + ", ".join(refresh))
    if stored.get("error"):
        problems.append(f"the stored-secret sweep could not run ({stored['error']})")
    nr = stored.get("needs_rotation")
    n_rot = len(nr) if isinstance(nr, (list, dict)) else (nr or 0)
    if n_rot:
        problems.append(f"{n_rot} secret(s) still under a retired key (run the re-encrypt job)")
    if problems:
        return Observation(DEGRADED, "; ".join(problems), evidence="pod_facts+sweep", metrics=metrics)
    if not fps:
        return Observation(UNKNOWN, "no pod has reported its key status yet", evidence="pod_facts", metrics=metrics)
    return Observation(HEALTHY, f"one fingerprint across {sum(len(p) for p in fps.values())} pod(s); "
                                f"{stored.get('current')} stored secrets readable", evidence="pod_facts+sweep",
                       metrics=metrics)


# ── multi-pod query workers (the folded Multi-Pod "pods" half) ─────────────

def _probe_worker_url(url: str, timeout: float) -> Dict[str, Any]:
    """One worker's /api/worker/health -- the probe the deleted Multi-Pod pods
    table made from the admin pod on every poll; now once per watcher tick."""
    import json as _json
    import urllib.request
    entry: Dict[str, Any] = {"url": url, "alive": False, "last_request": 0, "error": None}
    t0 = time.monotonic()
    try:
        with urllib.request.urlopen(urllib.request.Request(f"{url}/api/worker/health"), timeout=timeout) as r:   # noqa: S310 -- a discovered worker URL
            body = _json.loads(r.read() or b"{}")
            entry["alive"] = int(getattr(r, "status", 200) or 200) == 200
            entry["last_request"] = (body or {}).get("last_request", 0)
    except Exception as exc:                               # noqa: BLE001
        entry["error"] = f"{type(exc).__name__}: {str(exc)[:160]}"
    entry["ms"] = int((time.monotonic() - t0) * 1000)
    return entry


def multi_pod_verdict(state: Dict[str, Any], probed: List[Dict[str, Any]]) -> Observation:
    """The dispatcher's state (`multi_pod_dispatcher.multi_pod_state`) and
    each discovered worker's probe -> one observation.  Pure: tested with
    fabricated inputs."""
    metrics: Dict[str, Any] = {"state": state.get("state"), "strategy": state.get("strategy"),
                               "secret_configured": state.get("secret_configured"),
                               "pods": probed, "alive": sum(1 for p in probed if p.get("alive")),
                               "down": sum(1 for p in probed if not p.get("alive"))}
    if not state.get("configured_enabled", True) or state.get("state") == "disabled":
        return Observation(HEALTHY, "multi-pod dispatch is disabled (multi_pod.enabled=false)", evidence="config",
                           metrics=metrics, disposition=DISPOSITION_DISABLED)
    if state.get("state") == "inert" or not probed:
        reason = str(state.get("reason") or "enabled but no worker pod is discoverable")
        remedy = str(state.get("remedy") or "")
        return Observation(DEGRADED, reason + (f"; remedy: {remedy}" if remedy else ""),
                           evidence="multi_pod_dispatcher.multi_pod_state", metrics=metrics)
    down = [p for p in probed if not p.get("alive")]
    if down and len(down) == len(probed):
        return Observation(DOWN, "no worker pod answers: " + "; ".join(f"{p['url']}: {p.get('error')}" for p in down[:4]),
                           evidence="probe:worker_health", metrics=metrics)
    if down:
        return Observation(DEGRADED, f"{len(down)} of {len(probed)} worker pod(s) down: "
                                     + ", ".join(str(p["url"]) for p in down[:4]), evidence="probe:worker_health",
                           metrics=metrics)
    if not state.get("secret_configured", True):
        return Observation(DEGRADED, f"{len(probed)} worker(s) alive but no HMAC secret is set: workers refuse "
                                     f"unsigned chunks (set QS_WORKER_SECRET)", evidence="probe:worker_health", metrics=metrics)
    return Observation(HEALTHY, f"{len(probed)} worker pod(s) alive ({state.get('strategy')})",
                       evidence="probe:worker_health", metrics=metrics)


def probe_multi_pod_workers(ctx: ProbeContext, *, _probe=None) -> Observation:
    from core.multi_pod_dispatcher import multi_pod_state
    state = multi_pod_state() or {}
    urls = list(state.get("pods") or [])
    budget = _budget(ctx) / max(1, min(len(urls), 4)) if urls else _budget(ctx)
    probe = _probe or _probe_worker_url
    probed = [probe(u, budget) for u in urls[:8]]
    return multi_pod_verdict(state, probed)


# ── processes with no reporter: probed by URL ──────────────────────────────

def external_pod_probe(name: str, url: str):
    def _probe(ctx: ProbeContext) -> Observation:
        import urllib.request
        if not url:
            return Observation(UNKNOWN, f"no probe URL declared (component_health.external_pods.{name})",
                               evidence="config")
        t0 = time.monotonic()
        try:
            req = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(req, timeout=_budget(ctx)) as r:   # noqa: S310 -- an operator-declared URL
                code = int(getattr(r, "status", 200) or 200)
        except Exception as exc:                           # noqa: BLE001
            return Observation(DOWN, f"{url}: {type(exc).__name__}: {str(exc)[:160]}", evidence="probe:http",
                               metrics={"url": url})
        ms = int((time.monotonic() - t0) * 1000)
        if code >= 500:
            return Observation(DOWN, f"{url} answered {code}", evidence="probe:http", metrics={"url": url, "ms": ms})
        return Observation(HEALTHY, f"{url} answered {code} in {ms} ms", evidence="probe:http",
                           metrics={"url": url, "ms": ms, "status": code})
    _probe.__name__ = f"probe_external_{name}"
    return _probe


def register_external_pods(registry=REGISTRY) -> int:
    """From component_health.external_pods (name -> url); re-run by the
    watcher when the config changes.  The ui row exists even when no URL is
    declared, so its absence is SAID."""
    try:
        from core.config import component_health as _cfg
        declared = dict(_cfg.external_pods or {})
    except Exception:                                      # noqa: BLE001
        declared = {}
    names = set(declared) | {"ui"}
    n = 0
    for name in sorted(names):
        url = str(declared.get(name) or "")
        registry.register(HealthCheck(
            component_id=f"pod:{name}", kind=KIND_POD, label=name, scope=SCOPE_FLEET,
            owner=OWNER_FLEET_WATCHER, probe=external_pod_probe(name, url), timeout_seconds=3.0,
            interval_seconds=30, controls=(CONTROL_PROBE_NOW,), group="pods",
            docs=("A process with no reporter of its own, probed by the declared URL every "
                  "dependency_probe_interval_seconds.  unknown: no URL declared.")), replace=True)
        n += 1
    return n


# ── registration ─────────────────────────────────────────────────────────────

def _dep(cid: str, label: str, probe, *, controls=(CONTROL_PROBE_NOW,), legacy=(), docs="", group="platform",
         timeout: float = 3.0) -> HealthCheck:
    return HealthCheck(component_id=f"dependency:{cid}", kind=KIND_DEPENDENCY, label=label, scope=SCOPE_FLEET,
                       owner=OWNER_FLEET_WATCHER, probe=probe, timeout_seconds=timeout, interval_seconds=30,
                       controls=tuple(controls), legacy_routes=tuple(legacy), group=group, docs=docs)


REGISTRY.register(_dep("postgres", "metadata database (PostgreSQL / SQLite)", probe_postgres,
                       legacy=("/api/admin/database/status", "/health"), group="platform",
                       docs="healthy: SELECT answers; degraded: slow, a pod sees it degraded, a replica down; "
                            "down: the watcher cannot reach it (then nothing can -- the page answers 503)."))
REGISTRY.register(_dep("scheduler", "scheduler election (the lock)", probe_scheduler,
                       controls=(CONTROL_PAUSE, CONTROL_RESUME, CONTROL_PROBE_NOW),
                       legacy=("/api/admin/scheduler",), group="platform",
                       docs="healthy: one fresh lock holder; degraded: APScheduler paused, or lock and lease "
                            "disagree; down: no holder or a stale heartbeat (nothing scheduled fires)."))
REGISTRY.register(_dep("smtp", "SMTP (e-mail)", probe_smtp, group="delivery",
                       docs="EHLO without sending.  disabled when email.host is empty."))
REGISTRY.register(_dep("netcool", "Netcool", probe_netcool, group="delivery",
                       legacy=("/api/admin/background-jobs/feed_netcool_sender/status",),
                       docs="TCP to the transport endpoint + the sender's own ledger (dead letters, heartbeat)."))
REGISTRY.register(_dep("kafka", "Kafka brokers", probe_kafka, group="feeds",
                       legacy=("/api/admin/published-views/kafka-status",
                               "/api/admin/background-jobs/feed_kafka_arrivals/status"),
                       docs="TCP to each bootstrap server + the consumers' transport fault."))
REGISTRY.register(_dep("vault", "Vault (system-account secrets)", probe_vault, group="security",
                       legacy=("/api/admin/vault-config",), docs="TCP to the declared address; disabled when off."))
REGISTRY.register(_dep("spark_k8s", "Spark-on-K8s lane", probe_spark_k8s, group="spark",
                       legacy=("/api/admin/spark-pods/config",), docs="THE lane decision (backend_router)."))
REGISTRY.register(_dep("spark_connect", "Spark Connect", probe_spark_connect, group="spark",
                       legacy=("/api/admin/spark-connect/status",), docs="TCP to server_url; never a session."))
REGISTRY.register(_dep("airflow", "Airflow", probe_airflow, group="feeds",
                       legacy=("/api/admin/feed-generation/health",), timeout=5.0,
                       docs="core/feed/health.probe_airflow; disabled when airflow_enabled=false."))
REGISTRY.register(_dep("redis", "Redis (task queue)", probe_redis, group="platform",
                       docs="disabled unless queue.backend=redis."))
REGISTRY.register(_dep("multi_pod_workers", "multi-pod query workers", probe_multi_pod_workers, group="platform",
                       legacy=("/api/admin/multi-pod/pods",), timeout=6.0,
                       docs="the dispatcher's discovery state (disabled / inert with its remedy / active) and each "
                            "discovered worker's /api/worker/health (alive, last request).  Folded from the Multi-Pod "
                            "pods table (2026-10-17): the same probe, once per watcher tick instead of per admin poll."))
REGISTRY.register(_dep("encryption_keys", "encryption keys (envelope)", probe_encryption_keys,
                       controls=(), legacy=("/api/admin/encryption-key",), group="security", timeout=8.0,
                       docs="every pod's fingerprint agrees, none waiting / mismatched, zero unreadable "
                            "stored secrets (sweep every key_sweep_interval_seconds)."))
register_external_pods()

__all__ = ["external_pod_probe", "multi_pod_verdict", "probe_airflow", "probe_encryption_keys", "probe_kafka",
           "probe_multi_pod_workers", "probe_netcool", "probe_postgres", "probe_redis", "probe_scheduler",
           "probe_smtp", "probe_spark_connect", "probe_spark_k8s", "probe_vault", "register_external_pods",
           "scheduler_verdict", "tcp_connect"]
