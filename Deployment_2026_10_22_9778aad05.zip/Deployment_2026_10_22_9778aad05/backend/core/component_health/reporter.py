"""The per-pod REPORTER: this pod writes its own rows, every cycle.

Thread-shaped (the Netcool sender's shape: no event loop involved, so it
runs the same in main.py, scheduler_worker.py, feed_worker.py and
executor_worker.py), started once per process by ``start_reporter(db)``.
Each cycle:

1. gather the per-pod facts once (``checks.pods.gather_pod_facts``);
2. run every check this pod owns (``REGISTRY.checks_for_pod``) through the
   bounded pool -- a hung probe costs its own row, never the cycle;
3. apply the intents addressed to this pod (drain / undrain / breaker reset /
   self-test), keep the draining flag in step with the open drain;
4. write the rows in ONE upsert, claimed once per pod per interval across
   uvicorn workers (``rate_limiter.claim_once_per_window``);
5. ledger the cycle (``background_job_contract.record_event_tick``) so the
   reporter is observable through the same contract as every daemon.

The last rows stay in memory: the page's ``this_pod`` block is served from
them even when the table cannot be read.
"""
from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from core.component_health.contract import HealthCheck, Observation, ProbeContext
from core.component_health.vocabulary import (
    CONTROL_DRAIN, CONTROL_RERUN_SELF_TEST, CONTROL_RESET_BREAKER, CONTROL_UNDRAIN,
    DEGRADED, HEALTHY, UNKNOWN,
)

logger = logging.getLogger(__name__)

NAME = "component_health_reporter"

_lock = threading.Lock()
_thread: Optional[threading.Thread] = None
_stop = threading.Event()
_wake = threading.Event()
_db: Any = None
_last_rows: List[Dict[str, Any]] = []
_last_cycle: Dict[str, Any] = {}
_self_test: Dict[str, Any] = {}
_cycles = 0


def pod_id() -> str:
    from core.background_jobs import _this_pod_id
    return _this_pod_id()


def _pod_role() -> str:
    try:
        from core.pod_role import current
        return str(current().role)
    except Exception:                                      # noqa: BLE001
        return "unknown"


def _runs_daemon(name: str) -> bool:
    """The same answer background_job_contract.runs_here gives: a per-process
    job runs in every process; a scheduler-scope daemon runs where the gate
    that started it says (daemon_snapshots.daemon_runs_here)."""
    from core.component_health.checks.daemons import REPORTER_NAME
    if name == REPORTER_NAME:
        return True
    try:
        from core.background_job_contract import CONTRACTS, SCOPE_PER_PROCESS
        c = CONTRACTS.get(name)
        if c is not None and c.scope == SCOPE_PER_PROCESS:
            return True
    except Exception:                                      # noqa: BLE001
        pass
    from core.daemon_snapshots import daemon_runs_here
    if daemon_runs_here(name):
        return True
    # 2026-10-18 -- a daemon REGISTERED in this process (a leader-gated loop
    # alive on a non-holder, an APScheduler job on a scheduler that lost the
    # lock) is observed here too: its row says STANDBY (checks/daemons.py),
    # which also overwrites the stale "running" row this pod wrote before it
    # lost the role -- a stale row is not a second runner.
    try:
        from core import background_jobs as _bj
        job = _bj.get_job(name)
        if job is not None and not getattr(job, "remote", False):
            return True
        boot = getattr(_bj, "_boot_registered", {}).get(name)
        return bool(boot and boot.get("running"))
    except Exception:                                      # noqa: BLE001
        return False


def _redact(obs: Observation) -> Observation:
    try:
        from core.error_sanitizer import redact_structure
        obs.metrics = redact_structure(dict(obs.metrics or {}))
        obs.reason = str(redact_structure(obs.reason))
    except Exception as exc:                               # noqa: BLE001
        logger.debug("[component_health] redaction failed: %s", exc)
    return obs


def _row(check: HealthCheck, obs: Observation, facts: Dict[str, Any]) -> Dict[str, Any]:
    r = obs.to_row()
    r.update({"component_id": check.component_id, "kind": check.kind, "scope": check.scope,
              "label": check.label, "group": check.group, "pod_role": facts.get("pod_role"),
              "build": facts.get("build"), "interval_seconds": int(check.interval_seconds),
              "timeout_seconds": float(check.timeout_seconds)})
    return r


# ── intents this pod applies ──────────────────────────────────────────────────

def _apply_intent(intent: Dict[str, Any]) -> Dict[str, Any]:
    control = intent.get("control")
    me = pod_id()
    from core.component_health import intents as _in
    if control == CONTROL_DRAIN:
        _in.set_draining(True, by=intent.get("requested_by"), intent_id=intent.get("id"))
        return {"outcome": "ok", "detail": "readiness answers 503 draining; claiming stopped"}
    if control == CONTROL_UNDRAIN:
        _in.set_draining(False)
        return {"outcome": "ok", "detail": "readiness answers ready; claiming resumed"}
    if control == CONTROL_RESET_BREAKER:
        cid = str(intent.get("component_id") or "").rsplit(":", 1)[-1]
        done: List[str] = []
        try:
            from core.circuit_breaker import reset_circuit
            if reset_circuit(int(cid)) is not None:
                done.append("sql breaker closed")
            else:
                done.append("no sql breaker held here")
        except Exception as exc:                           # noqa: BLE001
            done.append(f"sql breaker: {type(exc).__name__}: {str(exc)[:80]}")
        try:
            from core.s3_circuit_breaker import get_s3_circuit_breaker
            get_s3_circuit_breaker().reset(cid)
            done.append("s3 breaker closed")
        except Exception as exc:                           # noqa: BLE001
            done.append(f"s3 breaker: {type(exc).__name__}: {str(exc)[:80]}")
        return {"outcome": "ok", "detail": f"{me}: " + "; ".join(done)}
    if control == CONTROL_RERUN_SELF_TEST:
        return {"outcome": "ok", "detail": run_self_tests()}
    return {"outcome": "not_applicable", "detail": f"{control} is not applied by a pod"}


def run_self_tests() -> str:
    """The existing read-only suites, run here, kept on this pod's row."""
    global _self_test
    try:
        from api.system_api import _PRUNING_SELF_TESTS, _SYSTEM_SELF_TESTS, _st_run, _summarise
        results = [dict(_st_run(i, f), suite="pruning") for i, f in _PRUNING_SELF_TESTS]
        results += [dict(_st_run(i, f), suite="system") for i, f in _SYSTEM_SELF_TESTS]
        s = _summarise(results)
        _self_test = {"at": s["timestamp"], "total": s["total"], "passed": s["passed"], "failed": s["failed"],
                      "failed_ids": [r["id"] for r in results if r["status"] != "pass"]}
        return f"{s['passed']}/{s['total']} passed"
    except Exception as exc:                               # noqa: BLE001
        _self_test = {"at": datetime.now(timezone.utc).isoformat(), "error": f"{type(exc).__name__}: {str(exc)[:200]}"}
        return f"self-test could not run: {type(exc).__name__}"


def _sync_drain(db, me: str) -> None:
    """The flag follows the open drain row: an expired / withdrawn drain is
    lifted, a drain applied before a restart is re-applied."""
    from core.component_health import intents as _in
    try:
        drain = _in.open_drain_for(db, me)
    except Exception as exc:                               # noqa: BLE001
        logger.debug("[component_health] drain row unreadable: %s", exc)
        return
    if drain is None and _in.is_draining():
        _in.set_draining(False)
    elif drain is not None and not _in.is_draining() and me in (drain.get("applied_by_pods") or {}):
        _in.set_draining(True, by=drain.get("requested_by"), intent_id=drain.get("id"))


# ── the cycle ────────────────────────────────────────────────────────────────

def cycle_once(db=None, *, write: bool = True) -> Dict[str, Any]:
    """ONE cycle: facts, checks, intents, one upsert.  The JobContract tick.
    Returns the counts the ledger classifies (``rows`` > 0 = ok)."""
    global _last_rows, _last_cycle, _cycles
    db = db if db is not None else _db
    if db is None:
        return {"status": "skipped", "reason": "no database manager bound to the reporter"}
    from core.component_health.probe_pool import pool
    from core.component_health.registry import load
    from core.component_health.checks.pods import gather_pod_facts
    from core.component_health import intents as _in
    t0 = time.monotonic()
    me = pod_id()
    reg = load()
    facts = gather_pod_facts(db)
    facts["pod_role"] = facts.get("pod_role") or _pod_role()
    applied = _in.apply_for_pod(db, me, _apply_intent)
    _sync_drain(db, me)
    # THE answer readiness gives (the flag OR the applied drain row) -- the pod row
    # said "reporting" while /health/ready said 503 draining (2026-10-18, the rig)
    facts["draining"] = _in.effective_draining(db, me)
    if _self_test:
        facts["self_test"] = dict(_self_test)
    ctx = ProbeContext(db=db, pod_id=me, pod_role=str(facts.get("pod_role")), facts=facts)
    rows: List[Dict[str, Any]] = []
    unknown = 0
    for check in reg.checks_for_pod(runs_daemon=_runs_daemon):
        try:
            obs = pool().run(check, ctx)
        except Exception as exc:                           # noqa: BLE001 -- the pool never raises; belt and braces
            obs = Observation(UNKNOWN, f"probe could not be run: {type(exc).__name__}: {str(exc)[:160]}",
                              evidence="reporter")
        if check.component_id == "pod:self" and _self_test:
            obs.metrics["self_test"] = dict(_self_test)
        obs = _redact(obs)
        if obs.state == UNKNOWN:
            unknown += 1
        rows.append(_row(check, obs, facts))
    # the reporter's own row rides the daemon family; make the pool visible on it
    stats = pool().stats()
    for r in rows:
        if r["component_id"] == f"daemon:{NAME}":
            r["metrics"] = dict(r.get("metrics") or {}, probe_pool=stats, cycles=_cycles + 1,
                                last_cycle_ms=_last_cycle.get("ms"), running=True)
            if stats.get("stuck"):
                r["state"], r["reason"] = DEGRADED, f"probe pool: {len(stats['stuck'])} stuck probe(s): " \
                    + ", ".join(stats["stuck"])
            elif r["state"] == UNKNOWN:
                r["state"], r["reason"] = HEALTHY, "reporting (this cycle)"
    written = 0
    claimed = True
    if write:
        try:
            from core.config import component_health as _cfg
            from core.rate_limiter import claim_once_per_window
            claimed = claim_once_per_window(f"component_health:{me}", int(_cfg.report_interval_seconds))
        except Exception as exc:                           # noqa: BLE001
            logger.debug("[component_health] claim failed, writing anyway: %s", exc)
            claimed = True
        if claimed:
            try:
                written = db.upsert_component_health(me, rows)
            except Exception as exc:                       # noqa: BLE001
                _last_rows = rows
                _last_cycle = {"at": datetime.now(timezone.utc).isoformat(), "ms": int((time.monotonic() - t0) * 1000),
                               "rows": len(rows), "written": 0, "status": "unreadable",
                               "input_error": f"{type(exc).__name__}: {str(exc)[:200]}"}
                logger.warning("[component_health] rows not written (%s); kept in memory", exc)
                return dict(_last_cycle)
    _cycles += 1
    _last_rows = rows
    _last_cycle = {"at": datetime.now(timezone.utc).isoformat(), "ms": int((time.monotonic() - t0) * 1000),
                   "rows": len(rows), "written": written, "unknown": unknown, "intents_applied": len(applied),
                   "claimed": claimed, "pod_id": me}
    return dict(_last_cycle)


def last_rows() -> List[Dict[str, Any]]:
    with _lock:
        return [dict(r) for r in _last_rows]


def last_cycle() -> Dict[str, Any]:
    return dict(_last_cycle)


def status(db=None) -> Dict[str, Any]:
    """The JobContract status reader."""
    from core.component_health.probe_pool import pool
    return {"running": bool(_thread is not None and _thread.is_alive()), "pod_id": pod_id(),
            "cycles": _cycles, "last_cycle": dict(_last_cycle), "rows_in_memory": len(_last_rows),
            "probe_pool": pool().stats()}


# ── the thread ───────────────────────────────────────────────────────────────

def _loop() -> None:
    from core.background_job_contract import record_event_tick
    from core.config import component_health as _cfg
    while not _stop.is_set():
        t0 = time.monotonic()
        try:
            raw = cycle_once()
            try:
                # the literal name: the per-process recorder guard reads it
                record_event_tick("component_health_reporter", raw, duration_s=time.monotonic() - t0)
            except Exception as exc:                       # noqa: BLE001
                logger.debug("[component_health] ledger write failed: %s", exc)
        except Exception as exc:                           # noqa: BLE001 -- the loop outlives any cycle
            logger.warning("[component_health] reporter cycle failed: %s", exc, exc_info=True)
            try:
                record_event_tick("component_health_reporter", None,
                                  error=f"{type(exc).__name__}: {str(exc)[:200]}")
            except Exception:                              # noqa: BLE001
                pass
        try:
            interval = int(_cfg.report_interval_seconds)
        except Exception:                                  # noqa: BLE001
            interval = 15
        _wake.clear()
        _wake.wait(interval)


def nudge() -> None:
    """Run the next cycle now (an intent arrived)."""
    _wake.set()


def _on_bus_event(event: Dict[str, Any]) -> None:
    try:
        from core.component_health.intents import INTENT_EVENT
        payload = event.get("payload") if isinstance(event.get("payload"), dict) else event
        if (event.get("event_type") == INTENT_EVENT or event.get("type") == INTENT_EVENT
                or (payload or {}).get("type") == INTENT_EVENT):
            nudge()
    except Exception:                                      # noqa: BLE001
        pass


def start_reporter(db) -> bool:
    """Start the reporter thread once per process.  Idempotent.  Returns
    True when it runs here (started now or already running)."""
    global _thread, _db
    try:
        from core.config import component_health as _cfg
        if not _cfg.enabled:
            logger.info("[component_health] reporter not started: component_health.enabled=false")
            return False
    except Exception:                                      # noqa: BLE001
        pass
    with _lock:
        _db = db
        if _thread is not None and _thread.is_alive():
            return True
        _stop.clear()
        _thread = threading.Thread(target=_loop, name="component-health-reporter", daemon=True)
        _thread.start()
    try:
        from core import background_jobs as _bj
        _bj.record_boot_registrations([NAME], "the per-pod component-health reporter thread (every pod)",
                                      running=True, status="registered")
    except Exception as exc:                               # noqa: BLE001
        logger.debug("[component_health] boot record failed: %s", exc)
    try:
        from core import event_bus
        event_bus.subscribe(_on_bus_event)
    except Exception as exc:                               # noqa: BLE001
        logger.debug("[component_health] bus subscription failed: %s", exc)
    logger.info("[component_health] reporter started for pod %s", pod_id())
    return True


def stop_reporter(timeout: float = 5.0) -> None:
    global _thread
    _stop.set()
    _wake.set()
    t = _thread
    if t is not None and t.is_alive():
        t.join(timeout)
    with _lock:
        _thread = None
    try:
        from core.component_health.probe_pool import shutdown_pool
        shutdown_pool()
    except Exception:                                      # noqa: BLE001
        pass


def reset_for_tests() -> None:
    global _last_rows, _last_cycle, _self_test, _cycles, _db
    stop_reporter(1.0)
    with _lock:
        _last_rows, _last_cycle, _self_test, _cycles, _db = [], {}, {}, 0, None


__all__ = ["NAME", "cycle_once", "last_cycle", "last_rows", "nudge", "pod_id", "reset_for_tests",
           "run_self_tests", "start_reporter", "status", "stop_reporter"]
