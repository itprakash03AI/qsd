"""Component health and controls, one place (2026-10-17,
docs/COMPONENT_HEALTH_DESIGN_2026_10_17.html).

ONE model for "is this component well?" across pods, daemons and
dependencies:

* ``vocabulary``   -- the leaf every other module imports: the four states,
                      their roll-up order, kinds, scopes, dispositions, the
                      closed control vocabulary and the alert kinds.
* ``contract``     -- ``HealthCheck`` (a declaration: id, kind, scope, owner,
                      a bounded probe, its controls) and ``Observation`` (one
                      state, a mandatory reason, evidence, metrics).
* ``registry``     -- the plugin registry; a check declares itself.  The
                      daemon family is DERIVED from core/daemon_registry.py +
                      core/background_job_contract.py, the dependency family
                      from the connections table.
* ``probe_pool``   -- every probe runs bounded, on a dedicated pool, never on
                      the event loop; a timeout or a raise is ``unknown``.
* ``rules``        -- silence thresholds, inheritance, duplication, roll-up,
                      confirmation -- stated once, applied by reader and
                      watcher alike.
* ``reporter``     -- the per-pod loop that WRITES this pod's rows.
* ``fleet_watcher``-- the scheduler-lock holder's job that probes dependencies
                      once for everyone, derives fleet rows, confirms
                      transitions, raises alerts, applies expiry and GC.
* ``intents``      -- a control is an INTENT ROW the owner applies.
* ``reader``       -- the page: one SELECT, grouped, with the silence rules.

Observed state is written by its owner and read by anyone (the Kubernetes
Conditions model; the product's own daemon_heartbeat / background_job_ticks
rule).  A probe never runs because a browser asked.
"""
