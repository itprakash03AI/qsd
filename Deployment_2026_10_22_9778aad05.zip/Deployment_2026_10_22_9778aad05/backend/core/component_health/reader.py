"""The page: ONE SELECT, grouped, with the silence rules applied -- never a
probe, never a proxy, never a write.  Cached per process for
``page_cache_seconds``; an ETag lets a polling browser get a 304.

Unknown is never an absence: a table that cannot be read is a response that
SAYS so (``read.ok=false`` + the reason, and ``this_pod`` from the local
reporter's memory); a fresh deployment with no rows yet says that too.
"""
from __future__ import annotations

import hashlib
import json
import re
import threading
import time
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional

from core.component_health.vocabulary import (
    DEGRADED, DOWN, FLEET_POD_ID, HEALTHY, KIND_DAEMON, KIND_DEPENDENCY, KIND_POD, SCOPE_SINGLETON,
    UNKNOWN, worst,
)

_cache_lock = threading.Lock()
_cache: Dict[str, Any] = {"at": 0.0, "body": None, "etag": None}


class TableUnreadable(RuntimeError):
    pass


def _this_pod() -> Dict[str, Any]:
    """This pod's in-memory rows -- JSON-safe, so the 503 path (a plain
    JSONResponse, no FastAPI encoder) can carry them."""
    from core.component_health import reporter
    from core.component_health.intents import draining_info
    rows = []
    for r in reporter.last_rows():
        rows.append({k: (v.isoformat() if isinstance(v, datetime) else v) for k, v in r.items()})
    return {"pod_id": reporter.pod_id(), "rows_from_memory": rows, "last_cycle": reporter.last_cycle(),
            "draining": draining_info()}


_DIGITS = re.compile(r"\d+")


def _etag_of(rows: List[Dict[str, Any]], intents: List[Dict[str, Any]]) -> str:
    """A WEAK ETag of what a poller cares about: which rows exist, each row's
    state, disposition, state_since, alert and its reason with its NUMBERS
    normalised -- not ``reported_at`` (every reporter cycle moves it) and not
    the ages inside a reason ("last tick ok 27 s ago").

    2026-10-18, the rebuilt rig's C10: 1,020 GETs in 10 s answered 304 only
    67 % of the time because the hash carried ``reported_at`` and the ages,
    so an UNCHANGED fleet produced a new ETag every reporter cycle and every
    poller re-downloaded the whole page.  An unchanged fleet now yields an
    unchanged ETag; a state, disposition, alert, intent or wording change
    still changes it."""
    h = hashlib.sha256()
    for r in rows:
        h.update(f"{r.get('pod_id')}|{r.get('component_id')}|{r.get('state')}|{r.get('disposition')}|"
                 f"{r.get('state_since')}|{r.get('alert_id')}|{_DIGITS.sub('#', str(r.get('reason') or ''))}"
                 .encode("utf-8", "replace"))
    for i in intents:
        h.update(f"{i.get('id')}|{i.get('status')}|{json.dumps(i.get('applied_by_pods') or {}, sort_keys=True)}"
                 .encode("utf-8", "replace"))
    return 'W/"' + h.hexdigest()[:32] + '"'


def cached_etag() -> Optional[str]:
    """The ETag of the page this process last built, while its cache is
    fresh -- lets the route answer 304 WITHOUT the thread hop and the body
    (the poller's common case under load)."""
    try:
        from core.config import component_health as _cfg
        cache_s = float(_cfg.page_cache_seconds or 0)
    except Exception:                                      # noqa: BLE001
        cache_s = 0.0
    with _cache_lock:
        if _cache["body"] is not None and time.monotonic() - _cache["at"] < cache_s:
            return _cache["etag"]
    return None


def _group(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    from core.component_health.rules import headline, summary
    pods: Dict[str, Dict[str, Any]] = {}
    fleet: List[Dict[str, Any]] = []
    for r in rows:
        pid = str(r.get("pod_id"))
        if pid == FLEET_POD_ID:
            fleet.append(r)
            continue
        pod = pods.setdefault(pid, {"pod_id": pid, "pod_role": r.get("pod_role"), "build": r.get("build"),
                                    "components": [], "state": None, "reason": None, "reported_at": None})
        pod["components"].append(r)
        if r.get("component_id") == "pod:self":
            pod.update({"state": r.get("state"), "reason": r.get("reason"), "reported_at": r.get("reported_at"),
                        "pod_role": r.get("pod_role") or pod["pod_role"], "build": r.get("build") or pod["build"],
                        "disposition": r.get("disposition"), "silent_seconds": r.get("silent_seconds"),
                        "metrics": r.get("metrics")})
    for pod in pods.values():
        if pod["state"] is None:
            pod["state"] = UNKNOWN
            pod["reason"] = "the pod has daemon rows but never wrote its pod:self row"
        pod["summary"] = summary(pod["components"])
        pod["components"].sort(key=lambda c: (c.get("kind"), c.get("component_id")))
    fleet.sort(key=lambda c: (c.get("kind"), c.get("group") or "", c.get("component_id")))
    # a daemon's PAGE row is its singleton fleet row when one exists, else its per-pod rows
    return {"pods": sorted(pods.values(), key=lambda p: p["pod_id"]), "fleet": fleet,
            "summary": summary(rows), "headline": headline(rows)}


def _filter(rows: Iterable[Dict[str, Any]], *, kind: Optional[str], state: Optional[str],
            pod: Optional[str], q: Optional[str]) -> List[Dict[str, Any]]:
    out = []
    ql = (q or "").strip().lower()
    for r in rows:
        if kind and r.get("kind") != kind:
            continue
        if state and r.get("state") != state:
            continue
        if pod and r.get("pod_id") != pod:
            continue
        if ql and ql not in (f"{r.get('component_id')} {r.get('label')} {r.get('reason')}").lower():
            continue
        out.append(r)
    return out


def collect(db, *, kind: Optional[str] = None, state: Optional[str] = None, pod: Optional[str] = None,
            q: Optional[str] = None, controls_allowed: bool = False, use_cache: bool = True) -> Dict[str, Any]:
    """The whole page.  Raises TableUnreadable (the route answers 503 with
    the reason and this_pod) when the table cannot be read."""
    from core.component_health.rules import Thresholds, apply_silence, inherit_from_pod, pod_states
    from core.config import component_health as _cfg
    now = datetime.now(timezone.utc)
    cache_s = float(_cfg.page_cache_seconds or 0)
    body = None
    with _cache_lock:
        if use_cache and _cache["body"] is not None and time.monotonic() - _cache["at"] < cache_s:
            body = _cache["body"]
    if body is None:
        try:
            raw = db.list_component_health()
            intents = db.list_component_intents(status=["pending", "applied", "partially_applied"], limit=200)
        except Exception as exc:                           # noqa: BLE001
            raise TableUnreadable(f"component_health could not be read: {type(exc).__name__}: {str(exc)[:200]}") from exc
        th = Thresholds.from_config()
        rows = [apply_silence(r, th, now) for r in raw]
        pods = pod_states(rows)
        rows = [inherit_from_pod(r, pods) for r in rows]
        grouped = _group(rows)
        body = {
            "checked_at": now.isoformat(),
            "read": {"ok": True, "reason": None if raw else "no pod has reported yet (reporters write every "
                                                             f"{_cfg.report_interval_seconds} s)"},
            "thresholds": {"stale_after_seconds": th.stale_after_seconds,
                           "pod_down_after_seconds": th.pod_down_after_seconds,
                           "report_interval_seconds": _cfg.report_interval_seconds,
                           "dependency_probe_interval_seconds": _cfg.dependency_probe_interval_seconds},
            "summary": grouped["summary"], "headline": grouped["headline"],
            "pods": grouped["pods"], "fleet": grouped["fleet"],
            "intents": intents, "_rows": rows,
        }
        body["etag"] = _etag_of(rows, intents)
        with _cache_lock:
            _cache.update({"at": time.monotonic(), "body": body, "etag": body["etag"]})
    out = {k: v for k, v in body.items() if k != "_rows"}
    if kind or state or pod or q:
        rows = _filter(body["_rows"], kind=kind, state=state, pod=pod, q=q)
        grouped = _group(rows)
        out.update({"pods": grouped["pods"], "fleet": grouped["fleet"], "summary": grouped["summary"],
                    "headline": grouped["headline"], "filtered": True})
    out["controls_allowed"] = bool(controls_allowed)
    out["this_pod"] = _this_pod()
    return out


def component_detail(db, component_id: str) -> Dict[str, Any]:
    from core.component_health.registry import load
    from core.component_health.rules import Thresholds, apply_silence
    th = Thresholds.from_config()
    now = datetime.now(timezone.utc)
    rows = [apply_silence(r, th, now) for r in db.list_component_health(component_id=component_id)]
    check = load().get(component_id)
    events = db.list_component_health_events(component_id=component_id, limit=50)
    intents = db.list_component_intents(component_id=component_id, limit=50)
    alert = None
    aid = next((r.get("alert_id") for r in rows if r.get("alert_id")), None)
    if aid:
        try:
            alert = db.get_feed_alert(int(aid))
        except Exception:                                  # noqa: BLE001
            alert = None
    return {"component_id": component_id, "declared": check.describe() if check else None,
            "state": worst(r.get("state") or UNKNOWN for r in rows) if rows else UNKNOWN,
            "rows": rows, "events": events, "intents": intents, "alert": alert,
            "note": None if rows else "no pod has reported this component"}


def invalidate_cache() -> None:
    with _cache_lock:
        _cache.update({"at": 0.0, "body": None, "etag": None})


__all__ = ["TableUnreadable", "cached_etag", "collect", "component_detail", "invalidate_cache"]
