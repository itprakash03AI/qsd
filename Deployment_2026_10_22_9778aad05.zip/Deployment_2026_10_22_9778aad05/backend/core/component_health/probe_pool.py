"""Every probe runs BOUNDED, on a dedicated pool, never on the event loop.

A probe that exceeds its declared ``timeout_seconds`` is ``unknown: probe
exceeded N s``; one that raises is ``unknown`` naming the exception; one
that returns something that is not an Observation is ``unknown`` too.  A
thread that will not die is counted, not waited for: when the pool has no
free worker the probe is refused at once with a reason, so one stuck
dependency can never queue the rest of the cycle behind it -- and the
reporter's own row says how many are stuck.

A health check can never take the API down: nothing here touches the loop,
nothing blocks longer than the ceiling, and nothing propagates.
"""
from __future__ import annotations

import logging
import threading
import time
from concurrent.futures import Future, ThreadPoolExecutor, TimeoutError as _FutureTimeout
from typing import Any, Dict, List, Optional

from core.component_health.contract import HealthCheck, Observation, ProbeContext
from core.component_health.vocabulary import PROBE_TIMEOUT_CEILING_S, UNKNOWN

logger = logging.getLogger(__name__)


class ProbePool:
    """A bounded pool with a ledger of the probes still running past their
    budget ("stuck").  One per process (``pool()``)."""

    def __init__(self, size: int = 4, name: str = "qs-health-probe") -> None:
        self.size = max(1, int(size))
        self._exec = ThreadPoolExecutor(max_workers=self.size, thread_name_prefix=name)
        self._lock = threading.Lock()
        self._stuck: Dict[str, float] = {}          # component_id -> started (monotonic)
        self._inflight: Dict[str, Future] = {}
        self.probes_run = 0
        self.timeouts = 0
        self.refused = 0

    # ── bookkeeping ──────────────────────────────────────────────────────
    def _reap(self) -> None:
        done = [cid for cid, f in self._inflight.items() if f.done()]
        for cid in done:
            self._inflight.pop(cid, None)
            self._stuck.pop(cid, None)

    def stuck(self) -> List[str]:
        with self._lock:
            self._reap()
            return sorted(self._stuck)

    def free_slots(self) -> int:
        with self._lock:
            self._reap()
            return max(0, self.size - len(self._inflight))

    def stats(self) -> Dict[str, Any]:
        with self._lock:
            self._reap()
            return {"size": self.size, "inflight": len(self._inflight), "stuck": sorted(self._stuck),
                    "probes_run": self.probes_run, "timeouts": self.timeouts, "refused": self.refused}

    # ── the one entry point ─────────────────────────────────────────────
    def run(self, check: HealthCheck, ctx: ProbeContext) -> Observation:
        timeout = min(float(check.timeout_seconds), PROBE_TIMEOUT_CEILING_S)
        with self._lock:
            self._reap()
            if check.component_id in self._inflight:
                self.refused += 1
                return Observation(UNKNOWN, f"the previous probe of this component is still running "
                                            f"(started {time.monotonic() - self._stuck.get(check.component_id, time.monotonic()):.0f} s ago)",
                                   evidence="probe_pool")
            if len(self._inflight) >= self.size:
                self.refused += 1
                return Observation(UNKNOWN, f"probe pool exhausted ({len(self._inflight)} stuck: "
                                            f"{', '.join(sorted(self._stuck))})",
                                   evidence="probe_pool")
            started = time.monotonic()
            ctx.deadline = time.time() + timeout
            fut = self._exec.submit(check.probe, ctx)
            self._inflight[check.component_id] = fut
            self._stuck[check.component_id] = started
            self.probes_run += 1
        try:
            result = fut.result(timeout=timeout)
        except _FutureTimeout:
            with self._lock:
                self.timeouts += 1
            logger.warning("[component_health] %s: probe exceeded %.1f s", check.component_id, timeout)
            return Observation(UNKNOWN, f"probe exceeded {timeout:.1f} s", evidence="probe_pool",
                               probe_ms=int(timeout * 1000))
        except Exception as exc:                          # noqa: BLE001 -- a probe never propagates
            self._finish(check.component_id)
            return Observation(UNKNOWN, f"probe raised {type(exc).__name__}: {str(exc)[:300]}",
                               evidence="probe_pool", probe_ms=int((time.monotonic() - started) * 1000))
        self._finish(check.component_id)
        elapsed_ms = int((time.monotonic() - started) * 1000)
        if not isinstance(result, Observation):
            return Observation(UNKNOWN, f"probe returned {type(result).__name__}, not an Observation",
                               evidence="probe_pool", probe_ms=elapsed_ms)
        if result.probe_ms is None:
            result.probe_ms = elapsed_ms
        return result

    def _finish(self, component_id: str) -> None:
        with self._lock:
            self._inflight.pop(component_id, None)
            self._stuck.pop(component_id, None)


_pool: Optional[ProbePool] = None
_pool_lock = threading.Lock()


def pool() -> ProbePool:
    global _pool
    with _pool_lock:
        if _pool is None:
            try:
                from core.config import component_health as _cfg
                size = int(_cfg.probe_pool_size)
            except Exception:                              # noqa: BLE001
                size = 4
            _pool = ProbePool(size=size)
        return _pool


def shutdown_pool() -> None:
    """Release the pool's threads (the reporter's stop; a lifespan end).  A
    stuck probe thread is daemon and cannot be joined; idle ones exit."""
    global _pool
    with _pool_lock:
        p, _pool = _pool, None
    if p is not None:
        try:
            p._exec.shutdown(wait=False, cancel_futures=True)
        except TypeError:                                  # Python < 3.9
            p._exec.shutdown(wait=False)
        except Exception:                                  # noqa: BLE001
            pass


def reset_pool_for_tests(size: Optional[int] = None) -> ProbePool:
    global _pool
    shutdown_pool()
    with _pool_lock:
        _pool = ProbePool(size=size or 4)
        return _pool


__all__ = ["ProbePool", "pool", "reset_pool_for_tests", "shutdown_pool"]
