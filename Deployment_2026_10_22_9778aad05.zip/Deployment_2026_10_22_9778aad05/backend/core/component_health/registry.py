"""The registry of health checks -- the plugin seam.

A check declares itself by being registered from ``core/component_health/
checks/*`` (imported here once).  Two families are DERIVED there rather than
listed: one daemon check per declared daemon (``daemon_registry`` +
``background_job_contract``) and one dependency check per active connection
(built per watcher cycle from the table, since connections come and go).
A new daemon or a new connection appears on the page by existing; the guard
``tests/test_component_health_registry_2026_10_17.py`` fails when a declared
daemon has no check.
"""
from __future__ import annotations

import logging
import threading
from typing import Dict, Iterable, List, Optional

from core.component_health.contract import ContractError, HealthCheck
from core.component_health.vocabulary import (
    OWNER_EVERY_POD, OWNER_FLEET_WATCHER, SCOPE_FLEET, SCOPE_SINGLETON,
)

logger = logging.getLogger(__name__)


class Registry:
    def __init__(self) -> None:
        self._checks: Dict[str, HealthCheck] = {}
        self._lock = threading.Lock()

    def register(self, check: HealthCheck, *, replace: bool = False) -> HealthCheck:
        if not isinstance(check, HealthCheck):
            raise ContractError(f"not a HealthCheck: {check!r}")
        with self._lock:
            if check.component_id in self._checks and not replace:
                raise ContractError(f"component {check.component_id!r} registered twice")
            self._checks[check.component_id] = check
        return check

    def unregister(self, component_id: str) -> bool:
        with self._lock:
            return self._checks.pop(component_id, None) is not None

    def get(self, component_id: str) -> Optional[HealthCheck]:
        with self._lock:
            return self._checks.get(component_id)

    def require(self, component_id: str) -> HealthCheck:
        c = self.get(component_id)
        if c is None:
            raise KeyError(f"unknown component {component_id!r}")
        return c

    def all(self) -> List[HealthCheck]:
        with self._lock:
            return sorted(self._checks.values(), key=lambda c: (c.kind, c.component_id))

    def ids(self) -> List[str]:
        return [c.component_id for c in self.all()]

    def checks_for_pod(self, *, runs_daemon) -> List[HealthCheck]:
        """What THIS process observes: every ``every_pod`` check and every
        ``pods_running:<daemon>`` check whose daemon runs here
        (``runs_daemon(name) -> bool``, i.e. daemon_snapshots.daemon_runs_here)."""
        out: List[HealthCheck] = []
        for c in self.all():
            if c.owner == OWNER_EVERY_POD:
                out.append(c)
            elif c.runs_daemon is not None:
                try:
                    here = bool(runs_daemon(c.runs_daemon))
                except Exception as exc:                 # noqa: BLE001
                    logger.debug("[component_health] runs_daemon(%s) raised: %s", c.runs_daemon, exc)
                    here = False
                if here:
                    out.append(c)
        return out

    def fleet_checks(self) -> List[HealthCheck]:
        return [c for c in self.all() if c.owner == OWNER_FLEET_WATCHER
                or c.scope in (SCOPE_FLEET, SCOPE_SINGLETON)]

    def controls_of(self, component_id: str) -> Iterable[str]:
        c = self.get(component_id)
        return tuple(c.controls) if c else ()

    def describe(self) -> List[dict]:
        return [c.describe() for c in self.all()]


REGISTRY = Registry()
_loaded = False
_load_lock = threading.Lock()


def load() -> Registry:
    """Import every check module once (they register on import).  Derived
    families register the DECLARED part here; the per-connection dependency
    checks are built by the fleet watcher each cycle from the table."""
    global _loaded
    with _load_lock:
        if not _loaded:
            from core.component_health.checks import daemons, dependencies, platform, pods  # noqa: F401
            _loaded = True
    return REGISTRY


def reset_for_tests() -> None:
    """Forget every registration and allow ``load()`` to run again."""
    global _loaded
    with _load_lock:
        with REGISTRY._lock:
            REGISTRY._checks.clear()
        _loaded = False


__all__ = ["REGISTRY", "Registry", "load", "reset_for_tests"]
