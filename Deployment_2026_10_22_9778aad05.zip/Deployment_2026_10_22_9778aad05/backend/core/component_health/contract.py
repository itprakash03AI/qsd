"""The component-health CONTRACT: a declaration and an observation.

A ``HealthCheck`` is what a component declares once (its id, kind, scope,
who probes it, a bounded probe, the controls it supports).  An
``Observation`` is what one probe run says: exactly one of the four states,
a mandatory reason, the evidence it was read from and the key numbers.
Anything else is refused at construction -- a row with a fifth state or an
empty reason cannot exist.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Optional, Tuple

from core.component_health.vocabulary import (
    CONTROLS, DISPOSITIONS, KINDS, OWNER_EVERY_POD, OWNER_FLEET_WATCHER,
    OWNER_PODS_RUNNING_PREFIX, PROBE_TIMEOUT_CEILING_S, SCOPES, STATES, UNKNOWN,
    unknown_reason,
)


class ContractError(ValueError):
    """A declaration or an observation that breaks the contract."""


def _now() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class Observation:
    """One probe's verdict.  ``metrics`` holds numbers and short strings
    only; the reporter redacts it before writing (a probe's exception text
    may carry a credential)."""
    state: str
    reason: str
    evidence: str = ""
    metrics: Dict[str, Any] = field(default_factory=dict)
    disposition: Optional[str] = None
    checked_at: datetime = field(default_factory=_now)
    probe_ms: Optional[int] = None

    def __post_init__(self) -> None:
        if self.state not in STATES:
            raise ContractError(f"state must be one of {STATES}, got {self.state!r}")
        if not (self.reason or "").strip():
            raise ContractError("an observation without a reason is not an observation")
        if self.state == UNKNOWN:
            self.reason = unknown_reason(self.reason)
        if self.disposition is not None and self.disposition not in DISPOSITIONS:
            raise ContractError(f"disposition must be one of {DISPOSITIONS}, got {self.disposition!r}")
        if not isinstance(self.metrics, dict):
            raise ContractError("metrics must be a dict")

    def to_row(self) -> Dict[str, Any]:
        return {"state": self.state, "reason": self.reason[:2000], "evidence": self.evidence[:120],
                "metrics": dict(self.metrics), "disposition": self.disposition,
                "checked_at": self.checked_at, "probe_ms": self.probe_ms}


@dataclass
class ProbeContext:
    """What a probe may read: the db, who this pod is, the per-pod facts
    gathered once per cycle (so ten probes do not each read the worker
    ledger), and a deadline it may consult.  A probe never spawns, never
    awaits, never touches the event loop."""
    db: Any
    pod_id: str
    pod_role: str
    facts: Dict[str, Any] = field(default_factory=dict)
    deadline: Optional[float] = None
    extra: Dict[str, Any] = field(default_factory=dict)


Probe = Callable[[ProbeContext], Observation]


@dataclass(frozen=True)
class HealthCheck:
    """One component's declaration.  Most are a declaration + a small probe
    function; the two derived families (daemons, connections) build theirs
    from the inventories they already have."""
    component_id: str
    kind: str
    label: str
    scope: str
    owner: str
    probe: Probe
    timeout_seconds: float = 3.0
    interval_seconds: int = 15
    controls: Tuple[str, ...] = ()
    legacy_routes: Tuple[str, ...] = ()
    group: str = ""
    docs: str = ""

    def __post_init__(self) -> None:
        cid = self.component_id or ""
        if ":" not in cid or not cid.split(":", 1)[0] or not cid.split(":", 1)[1]:
            raise ContractError(f"component_id must be '<kind>:<name>', got {cid!r}")
        if cid.split(":", 1)[0] != self.kind:
            raise ContractError(f"component_id {cid!r} does not start with its kind {self.kind!r}")
        if self.kind not in KINDS:
            raise ContractError(f"kind must be one of {KINDS}, got {self.kind!r}")
        if self.scope not in SCOPES:
            raise ContractError(f"scope must be one of {SCOPES}, got {self.scope!r}")
        if not (self.owner == OWNER_EVERY_POD or self.owner == OWNER_FLEET_WATCHER
                or (self.owner.startswith(OWNER_PODS_RUNNING_PREFIX)
                    and len(self.owner) > len(OWNER_PODS_RUNNING_PREFIX))):
            raise ContractError(f"owner must be every_pod, fleet_watcher or pods_running:<daemon>, "
                                f"got {self.owner!r}")
        if not callable(self.probe):
            raise ContractError(f"{cid}: probe is not callable")
        if not (0 < float(self.timeout_seconds) <= PROBE_TIMEOUT_CEILING_S):
            raise ContractError(f"{cid}: timeout_seconds must be in (0, {PROBE_TIMEOUT_CEILING_S}], "
                                f"got {self.timeout_seconds}")
        if int(self.interval_seconds) <= 0:
            raise ContractError(f"{cid}: interval_seconds must be positive")
        bad = [c for c in self.controls if c not in CONTROLS]
        if bad:
            raise ContractError(f"{cid}: undeclared control(s) {bad}; the vocabulary is {CONTROLS}")
        if not (self.label or "").strip():
            raise ContractError(f"{cid}: a label is required")

    @property
    def runs_daemon(self) -> Optional[str]:
        """The daemon whose runners own this check, or None."""
        if self.owner.startswith(OWNER_PODS_RUNNING_PREFIX):
            return self.owner[len(OWNER_PODS_RUNNING_PREFIX):]
        return None

    def describe(self) -> Dict[str, Any]:
        return {"component_id": self.component_id, "kind": self.kind, "label": self.label,
                "scope": self.scope, "owner": self.owner,
                "timeout_seconds": float(self.timeout_seconds),
                "interval_seconds": int(self.interval_seconds),
                "controls": list(self.controls), "legacy_routes": list(self.legacy_routes),
                "group": self.group, "docs": self.docs}


__all__ = ["ContractError", "HealthCheck", "Observation", "Probe", "ProbeContext"]
