"""The words component health is allowed to use -- a leaf module.

Four states, no fifth.  "paused", "disabled by config", "draining" are
DISPOSITIONS on a row, never a state: a paused queue worker with 300 pending
runs is ``degraded`` (work it should do is not being done), said with the
disposition that explains why.  ``unknown`` reasons carry
``core.verdict_vocabulary.COULD_NOT_DETERMINE`` -- the one word the posture
card, the queue probe, DataFlow and Clockwork already use for "we do not
know", so a reader or a guard keys on one prefix everywhere.
"""
from __future__ import annotations

from core.verdict_vocabulary import COULD_NOT_DETERMINE

HEALTHY = "healthy"
DEGRADED = "degraded"
DOWN = "down"
UNKNOWN = "unknown"
STATES = (HEALTHY, DEGRADED, DOWN, UNKNOWN)

#: Roll-up precedence: a known fault beats "we do not know", which beats
#: healthy -- so one unknown row never hides behind a green headline, and a
#: known fault is never softened to unknown.
WORST_FIRST = (DOWN, DEGRADED, UNKNOWN, HEALTHY)

KIND_POD = "pod"
KIND_DAEMON = "daemon"
KIND_DEPENDENCY = "dependency"
KINDS = (KIND_POD, KIND_DAEMON, KIND_DEPENDENCY)

#: per_pod rows are written by every pod that runs the thing; singleton and
#: fleet rows by the fleet watcher under FLEET_POD_ID.
SCOPE_PER_POD = "per_pod"
SCOPE_SINGLETON = "singleton"
SCOPE_FLEET = "fleet"
SCOPES = (SCOPE_PER_POD, SCOPE_SINGLETON, SCOPE_FLEET)

#: A pod that stopped reporting is DOWN only while it could still be part of
#: the deployment; superseded by a newer pod of its role, or silent past the
#: retire window, it is RETIRED -- an EVENT marker (to_state), never a row
#: state: its rows leave the table, its history stays.  What is DOWN then is
#: the ROLE with no live pod: the fleet row ``pod:role:<role>``.
RETIRED = "retired"
ROLE_ROW_PREFIX = "pod:role:"
#: The reserved pod_id of fleet rows.  Never a real pod's name (pod names
#: are hostnames; '@' cannot appear in one).
FLEET_POD_ID = "@fleet"

#: Who runs a check's probe.
OWNER_EVERY_POD = "every_pod"
OWNER_FLEET_WATCHER = "fleet_watcher"
OWNER_PODS_RUNNING_PREFIX = "pods_running:"   # + the daemon name

DISPOSITION_PAUSED = "paused"
DISPOSITION_DISABLED = "disabled_by_config"
DISPOSITION_DRAINING = "draining"
DISPOSITION_DEFERRED = "deferred"
DISPOSITION_DECLINED = "declined"
DISPOSITIONS = (DISPOSITION_PAUSED, DISPOSITION_DISABLED, DISPOSITION_DRAINING,
                DISPOSITION_DEFERRED, DISPOSITION_DECLINED)

#: The closed control vocabulary.  A check declares a SUBSET; the registry
#: refuses anything else at declaration, the route at request.
CONTROL_PAUSE = "pause"
CONTROL_RESUME = "resume"
CONTROL_RUN_NOW = "run_now"
CONTROL_DRAIN = "drain"
CONTROL_UNDRAIN = "undrain"
CONTROL_RESET_BREAKER = "reset_breaker"
CONTROL_RERUN_SELF_TEST = "rerun_self_test"
CONTROL_PROBE_NOW = "probe_now"
CONTROLS = (CONTROL_PAUSE, CONTROL_RESUME, CONTROL_RUN_NOW, CONTROL_DRAIN,
            CONTROL_UNDRAIN, CONTROL_RESET_BREAKER, CONTROL_RERUN_SELF_TEST,
            CONTROL_PROBE_NOW)

#: Controls that are an INTENT ROW applied by the owning pod (the rest are
#: applied through an existing mechanism: background_job_state, run_now).
INTENT_CONTROLS = (CONTROL_DRAIN, CONTROL_UNDRAIN, CONTROL_RESET_BREAKER,
                   CONTROL_RERUN_SELF_TEST, CONTROL_PROBE_NOW)

#: Intent statuses.
INTENT_PENDING = "pending"
INTENT_APPLIED = "applied"
INTENT_PARTIAL = "partially_applied"
INTENT_EXPIRED = "expired"
INTENT_REFUSED = "refused"
INTENT_WITHDRAWN = "withdrawn"
INTENT_STATUSES = (INTENT_PENDING, INTENT_APPLIED, INTENT_PARTIAL, INTENT_EXPIRED,
                   INTENT_REFUSED, INTENT_WITHDRAWN)

#: The target of a breaker reset: every pod that holds the breaker.
EVERY_POD_TARGET = "*"

#: The alert kinds (feed_alert_kinds rows, seeded) the fleet watcher raises
#: through core/feed/feed_alerts.py -- THE alert road, never a second one.
ALERT_COMPONENT_DOWN = "component_down"
ALERT_COMPONENT_DEGRADED = "component_degraded"
ALERT_COMPONENT_UNKNOWN = "component_unknown"
ALERT_KINDS = (ALERT_COMPONENT_DOWN, ALERT_COMPONENT_DEGRADED, ALERT_COMPONENT_UNKNOWN)

#: The alert row's subject columns (shared with the published-API inventory:
#: feed_alerts.subject_kind / subject_key).
SUBJECT_KIND_COMPONENT = "component"
SUBJECT_KIND_FEED = "feed"

#: feed_alerts.dedupe_key prefix: one open alert per component fleet-wide.
ALERT_DEDUPE_PREFIX = "component_health:"

#: The Netcool console group of platform alerts (core/feed/netcool.py).
GROUP_PLATFORM = "PLATFORM"

#: A probe may never be given more than this, whatever it declares.
PROBE_TIMEOUT_CEILING_S = 10.0


def unknown_reason(reason: str) -> str:
    """Prefix an undetermined verdict's reason once (idempotent)."""
    r = (reason or "").strip() or "no reason given"
    return r if r.startswith(COULD_NOT_DETERMINE) else f"{COULD_NOT_DETERMINE}: {r}"


def worst(states) -> str:
    """The headline of a set of states, WORST_FIRST; ``healthy`` for none."""
    seen = set(states)
    for s in WORST_FIRST:
        if s in seen:
            return s
    return HEALTHY


__all__ = [
    "ALERT_COMPONENT_DEGRADED", "ALERT_COMPONENT_DOWN", "ALERT_COMPONENT_UNKNOWN",
    "ALERT_DEDUPE_PREFIX", "ALERT_KINDS", "CONTROLS", "CONTROL_DRAIN", "CONTROL_PAUSE",
    "CONTROL_PROBE_NOW", "CONTROL_RERUN_SELF_TEST", "CONTROL_RESET_BREAKER",
    "CONTROL_RESUME", "CONTROL_RUN_NOW", "CONTROL_UNDRAIN", "COULD_NOT_DETERMINE",
    "DEGRADED", "DISPOSITIONS", "DISPOSITION_DECLINED", "DISPOSITION_DEFERRED",
    "DISPOSITION_DISABLED", "DISPOSITION_DRAINING", "DISPOSITION_PAUSED", "DOWN",
    "EVERY_POD_TARGET", "FLEET_POD_ID", "GROUP_PLATFORM", "HEALTHY", "INTENT_APPLIED",
    "INTENT_CONTROLS", "INTENT_EXPIRED", "INTENT_PARTIAL", "INTENT_PENDING",
    "INTENT_REFUSED", "INTENT_STATUSES", "INTENT_WITHDRAWN", "KINDS", "KIND_DAEMON",
    "KIND_DEPENDENCY", "KIND_POD", "OWNER_EVERY_POD", "OWNER_FLEET_WATCHER",
    "OWNER_PODS_RUNNING_PREFIX", "PROBE_TIMEOUT_CEILING_S", "RETIRED", "ROLE_ROW_PREFIX", "SCOPES", "SCOPE_FLEET",
    "SCOPE_PER_POD", "SCOPE_SINGLETON", "STATES", "SUBJECT_KIND_COMPONENT",
    "SUBJECT_KIND_FEED", "UNKNOWN", "WORST_FIRST", "unknown_reason", "worst",
]
