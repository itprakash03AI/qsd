"""Retiring the rows of processes that are GONE -- the rule, stated once.

2026-10-18, the rebuilt rig: every container was replaced (new hostnames),
and the OLD scheduler container stayed on the page as DOWN "no report for
1671 s" with an alert "feed sla watcher on 24dc88be6eeb: Component down".
In Kubernetes EVERY rollout replaces pods; modelled as before, every
release would page the platform team for pods that are simply gone, and
singletons would stay attributed to a dead pod.

The rule (generic -- the published-API ingest rows of dead processes use the
same one through :func:`silence_verdict`):

* a process that stopped reporting is LIVE while fresh, DOWN once silent past
  ``down_after_s`` -- but only while it could still be part of the
  deployment;
* it is RETIRED when a newer process of the SAME role has reported since
  (superseded), or when silent past ``retire_after_s``;
* a retired process is kept in history (one event per process,
  ``to_state=retired``), its rows leave the live table, nothing alerts on it
  and nothing inherits from it;
* what deserves DOWN + an alert is a ROLE with no live process (the fleet
  row ``pod:role:<role>``) and a singleton with no live holder -- never an
  individual process name.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional, Tuple

from core.component_health.vocabulary import (
    DOWN, FLEET_POD_ID, HEALTHY, KIND_POD, RETIRED, ROLE_ROW_PREFIX, UNKNOWN, unknown_reason,
)

logger = logging.getLogger(__name__)

LIVE = "live"
#: the three answers of :func:`silence_verdict`
SILENCE_VERDICTS = (LIVE, DOWN, RETIRED)


def silence_verdict(age_seconds: Optional[float], *, superseded: bool,
                    down_after_s: float, retire_after_s: float) -> str:
    """THE generic rule.  ``age_seconds`` is the time since the process last
    reported (None = never: retired only when superseded).  A process is
    retired when it is already past ``down_after_s`` AND (superseded or past
    ``retire_after_s``); a supersession never retires a FRESH process (two
    replicas of one role are both live)."""
    if age_seconds is None:
        return RETIRED if superseded else LIVE
    if age_seconds <= float(down_after_s):
        return LIVE
    if superseded or age_seconds > float(retire_after_s):
        return RETIRED
    return DOWN


def superseding_pod(pod: Dict[str, Any], live_pods: Iterable[Dict[str, Any]]) -> Optional[str]:
    """The id of a LIVE pod of the same role that reported after ``pod``
    last did, or None.  ``pod`` / ``live_pods`` are pod:self rows with
    ``pod_id``, ``pod_role``, ``reported_at`` (as the table returns them)."""
    from core.component_health.rules import parse_ts
    role = str(pod.get("pod_role") or "")
    last = parse_ts(pod.get("reported_at"))
    for cand in live_pods:
        if str(cand.get("pod_id")) == str(pod.get("pod_id")):
            continue
        if str(cand.get("pod_role") or "") != role or not role:
            continue
        cand_at = parse_ts(cand.get("reported_at"))
        if last is None or (cand_at is not None and cand_at > last):
            return str(cand.get("pod_id"))
    return None


def _pod_rows(rows: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return [r for r in rows if r.get("kind") == KIND_POD and r.get("component_id") == "pod:self"
            and r.get("pod_id") != FLEET_POD_ID]


def classify_pods(rows: Iterable[Dict[str, Any]], *, down_after_s: float, retire_after_s: float,
                  now: Optional[datetime] = None) -> Dict[str, Tuple[str, Optional[str], Optional[float]]]:
    """pod_id -> (verdict, superseded_by, age_seconds) for every pod:self row."""
    from core.component_health.rules import age_seconds
    now = now or datetime.now(timezone.utc)
    pods = _pod_rows(rows)
    ages = {str(p["pod_id"]): age_seconds(p.get("reported_at"), now) for p in pods}
    live = [p for p in pods if ages[str(p["pod_id"])] is not None and ages[str(p["pod_id"])] <= float(down_after_s)]
    out: Dict[str, Tuple[str, Optional[str], Optional[float]]] = {}
    for p in pods:
        pid = str(p["pod_id"])
        by = superseding_pod(p, live)
        out[pid] = (silence_verdict(ages[pid], superseded=by is not None, down_after_s=down_after_s,
                                    retire_after_s=retire_after_s), by, ages[pid])
    return out


def retire_pods(db, *, down_after_s: float, retire_after_s: float,
                now: Optional[datetime] = None) -> Dict[str, Any]:
    """Retire every pod the rule says is gone: ONE ``retired`` event per pod
    (from its last read state, naming why), its open component alerts
    cleared, its rows deleted.  Returns what happened, by value."""
    from core.component_health.rules import Thresholds, apply_silence
    now = now or datetime.now(timezone.utc)
    rows = db.list_component_health()
    verdicts = classify_pods(rows, down_after_s=down_after_s, retire_after_s=retire_after_s, now=now)
    retired: List[Dict[str, Any]] = []
    rows_deleted = 0
    alert_keys: List[str] = []
    for pid, (verdict, by, age) in verdicts.items():
        if verdict != RETIRED:
            continue
        pod_rows = [r for r in rows if str(r.get("pod_id")) == pid]
        self_row = next((r for r in pod_rows if r.get("component_id") == "pod:self"), {})
        role = str(self_row.get("pod_role") or "")
        if by:
            why = f"superseded by {by} (role {role or 'unknown'}); last report {age:.0f} s ago" if age is not None \
                else f"superseded by {by} (role {role or 'unknown'}); never reported a time"
        else:
            why = f"silent {age:.0f} s, past the retire window of {retire_after_s:.0f} s (role {role or 'unknown'})"
        try:
            th = Thresholds.from_config()
            last_state = apply_silence(self_row, th, now).get("state") if self_row else None
        except Exception:                                  # noqa: BLE001
            last_state = self_row.get("state") if self_row else None
        try:
            db.add_component_health_event({"component_id": "pod:self", "pod_id": pid, "from_state": last_state,
                                           "to_state": RETIRED, "reason": why, "at": now})
        except Exception as exc:                           # noqa: BLE001
            logger.debug("[component_health] retire event for %s not written: %s", pid, exc)
        from core.component_health.fleet_watcher import _alert_key   # the ONE key rule
        # only the keys that NAME this pod: a singleton daemon's alert is keyed fleet-wide
        # (no live holder) and may legitimately stand after this pod is gone
        alert_keys.extend(k for k in (_alert_key(r) for r in pod_rows if r.get("pod_id") != FLEET_POD_ID)
                          if k.endswith(f"@{pid}"))
        try:
            rows_deleted += int(db.delete_component_health(pod_id=pid) or 0)
        except Exception as exc:                           # noqa: BLE001
            logger.warning("[component_health] rows of retired pod %s not deleted: %s", pid, exc)
        retired.append({"pod_id": pid, "role": role, "why": why, "superseded_by": by, "age_seconds": age})
    cleared = 0
    if alert_keys:
        try:
            from core.feed import feed_alerts
            cleared = len(feed_alerts.clear(db, by="component_health_fleet_watcher:retired",
                                            dedupe_keys=sorted(set(alert_keys))) or [])
        except Exception as exc:                           # noqa: BLE001
            logger.warning("[component_health] alerts of retired pods not cleared: %s", exc)
    if retired:
        logger.info("[component_health] retired %d pod(s): %s", len(retired),
                    "; ".join(f"{r['pod_id']}: {r['why']}" for r in retired))
    return {"retired": retired, "rows_deleted": rows_deleted, "alerts_cleared": cleared}


# ── the ROLE row: what is down when pods are gone ────────────────────────────

def role_rows_known(rows: Iterable[Dict[str, Any]]) -> List[str]:
    """Roles the fleet already follows: a ``pod:role:<role>`` fleet row exists
    (written when the role had a live pod; it outlives the pods and says DOWN
    when none is left -- forgotten only by the dead-pod GC)."""
    return sorted({str(r["component_id"])[len(ROLE_ROW_PREFIX):] for r in rows
                   if r.get("pod_id") == FLEET_POD_ID and str(r.get("component_id") or "").startswith(ROLE_ROW_PREFIX)})


def roles_present(rows: Iterable[Dict[str, Any]]) -> List[str]:
    """Roles with a pod:self row (live or not) plus the roles already followed."""
    seen = {str(p.get("pod_role") or "") for p in _pod_rows(rows)} - {""}
    return sorted(seen | set(role_rows_known(rows)))


def role_verdict(role: str, rows: Iterable[Dict[str, Any]], *, down_after_s: float, stale_after_s: float,
                 now: Optional[datetime] = None) -> Tuple[str, str, Dict[str, Any]]:
    """(state, reason, metrics) of the ``pod:role:<role>`` row from the pod:self
    rows: healthy with N live pods; unknown when every pod of the role is
    merely stale; DOWN when no pod of the role is live."""
    from core.component_health.rules import age_seconds
    now = now or datetime.now(timezone.utc)
    pods = [p for p in _pod_rows(rows) if str(p.get("pod_role") or "") == role]
    ages = {str(p["pod_id"]): age_seconds(p.get("reported_at"), now) for p in pods}
    live = sorted(pid for pid, a in ages.items() if a is not None and a <= float(stale_after_s))
    stale = sorted(pid for pid, a in ages.items() if a is not None and float(stale_after_s) < a <= float(down_after_s))
    dead = sorted(pid for pid, a in ages.items() if a is None or a > float(down_after_s))
    metrics = {"role": role, "live_pods": live, "stale_pods": stale, "silent_pods": dead,
               "ages_seconds": {k: (None if v is None else round(v)) for k, v in ages.items()}}
    if live:
        return HEALTHY, f"{len(live)} live pod(s) of role {role}: {', '.join(live)}", metrics
    if stale:
        return UNKNOWN, unknown_reason(f"no pod of role {role} has reported for "
                                       f"{min(ages[p] for p in stale):.0f} s ({', '.join(stale)})"), metrics
    if dead:
        return DOWN, (f"no live pod of role {role}: {', '.join(dead)} silent "
                      f"{', '.join(f'{ages[p]:.0f} s' if ages[p] is not None else 'never reported' for p in dead)}"), metrics
    return DOWN, f"no live pod of role {role}: every pod of this role has been retired", metrics


__all__ = ["LIVE", "SILENCE_VERDICTS", "classify_pods", "retire_pods", "role_rows_known", "role_verdict",
           "roles_present", "silence_verdict", "superseding_pod"]
