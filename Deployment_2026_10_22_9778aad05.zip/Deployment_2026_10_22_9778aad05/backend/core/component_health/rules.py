"""The state rules, stated ONCE and applied by the reader and the watcher
alike (docs/COMPONENT_HEALTH_DESIGN_2026_10_17.html §3.6).

1. Silence has two thresholds: a row unheard for ``stale_after_seconds`` is
   ``unknown``; a POD row unheard for ``pod_down_after_seconds`` is ``down``.
2. Inheritance: a daemon whose every reporting pod is down is down, with the
   cause -- never unknown when the cause is known.
3. Duplication: a singleton reported running by more than one live pod is
   degraded naming them (per-pod daemons exempt).
4. Roll-up: worst first (down > degraded > unknown > healthy).
5. Dispositions never change the state word.
6. Confirmation: a transition counts after N consecutive observations.
7. Alerting: down -> component_down, degraded -> component_degraded, unknown
   past ``unknown_alert_after_seconds`` -> component_unknown; a muted row
   raises nothing.
8. Unknown is never an absence: a component expected and missing is a row
   that says so.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional, Tuple

from core.component_health.vocabulary import (
    ALERT_COMPONENT_DEGRADED, ALERT_COMPONENT_DOWN, ALERT_COMPONENT_UNKNOWN, DEGRADED,
    DISPOSITION_DEFERRED, DISPOSITION_DISABLED, DOWN, FLEET_POD_ID, HEALTHY, KIND_POD, UNKNOWN,
    unknown_reason, worst,
)


def parse_ts(v: Any) -> Optional[datetime]:
    if v is None:
        return None
    if isinstance(v, datetime):
        return v if v.tzinfo else v.replace(tzinfo=timezone.utc)
    try:
        d = datetime.fromisoformat(str(v))
    except Exception:                                      # noqa: BLE001
        return None
    return d if d.tzinfo else d.replace(tzinfo=timezone.utc)


def age_seconds(reported_at: Any, now: Optional[datetime] = None) -> Optional[float]:
    ts = parse_ts(reported_at)
    if ts is None:
        return None
    now = now or datetime.now(timezone.utc)
    return (now - ts).total_seconds()


class Thresholds:
    """The declared keys, read once per evaluation (never a raw dict)."""

    def __init__(self, *, stale_after_seconds: int, pod_down_after_seconds: int,
                 daemon_silent_intervals: int, unknown_alert_after_seconds: int,
                 transition_confirmations: int, clear_after_cycles: int,
                 pod_retire_after_seconds: int = 600) -> None:
        self.stale_after_seconds = int(stale_after_seconds)
        self.pod_down_after_seconds = int(pod_down_after_seconds)
        # a silent pod is RETIRED past this (or once a newer pod of its role
        # reports): rows gone, history kept, no alert -- retire.py
        self.pod_retire_after_seconds = max(int(pod_retire_after_seconds), int(pod_down_after_seconds))
        self.daemon_silent_intervals = int(daemon_silent_intervals)
        self.unknown_alert_after_seconds = int(unknown_alert_after_seconds)
        self.transition_confirmations = int(transition_confirmations)
        self.clear_after_cycles = int(clear_after_cycles)

    @classmethod
    def from_config(cls) -> "Thresholds":
        from core.config import component_health as c
        return cls(stale_after_seconds=c.stale_after_seconds,
                   pod_down_after_seconds=c.pod_down_after_seconds,
                   daemon_silent_intervals=c.daemon_silent_intervals,
                   unknown_alert_after_seconds=c.unknown_alert_after_seconds,
                   transition_confirmations=c.transition_confirmations,
                   clear_after_cycles=c.clear_after_cycles,
                   pod_retire_after_seconds=c.pod_retire_after_seconds)


# ── rule 1: silence ──────────────────────────────────────────────────────────

def apply_silence(row: Dict[str, Any], th: Thresholds,
                  now: Optional[datetime] = None) -> Dict[str, Any]:
    """Return the row as a READER sees it: the owner's observation when
    fresh, ``unknown`` when stale, ``down`` for a pod silent past the
    threshold.  The stored state is kept as ``observed_state``.  A report
    from the future (clock skew) is said, not trusted as fresh."""
    out = dict(row)
    out.setdefault("observed_state", row.get("state"))
    age = age_seconds(row.get("reported_at"), now)
    out["silent_seconds"] = None if age is None else round(age, 1)
    if age is None:
        out["state"] = UNKNOWN
        out["reason"] = unknown_reason("the row carries no report time")
        return out
    if age < -5:
        out["state"] = worst([row.get("state") or UNKNOWN, DEGRADED])
        out["reason"] = (f"clock skew: this pod's report is {abs(age):.0f} s in the reader's future; "
                         f"{row.get('reason') or ''}").strip()
        return out
    expected = int(row.get("interval_seconds") or 15)
    if row.get("kind") == KIND_POD and age > th.pod_down_after_seconds:
        out["state"] = DOWN
        out["reason"] = (f"no report for {age:.0f} s (expected every {expected} s; down after "
                         f"{th.pod_down_after_seconds} s)")
        return out
    if age > th.stale_after_seconds:
        out["state"] = UNKNOWN
        out["reason"] = unknown_reason(
            f"last reported {age:.0f} s ago, expected every {expected} s")
        return out
    return out


# ── rule 2: inheritance ──────────────────────────────────────────────────────

def pod_states(rows: Iterable[Dict[str, Any]]) -> Dict[str, str]:
    """pod_id -> the pod row's READ state (after apply_silence)."""
    out: Dict[str, str] = {}
    for r in rows:
        if r.get("kind") == KIND_POD and r.get("pod_id") != FLEET_POD_ID and r.get("component_id") == "pod:self":
            out[str(r["pod_id"])] = str(r.get("state") or UNKNOWN)
    return out

def inherit_from_pod(row: Dict[str, Any], pods: Dict[str, str]) -> Dict[str, Any]:
    """A non-pod row whose pod is DOWN is down with the cause."""
    if row.get("kind") == KIND_POD or row.get("pod_id") == FLEET_POD_ID:
        return row
    pod_state = pods.get(str(row.get("pod_id")))
    if pod_state == DOWN:
        out = dict(row)
        out["state"] = DOWN
        out["reason"] = f"owning pod {row.get('pod_id')} is down"
        out["inherited"] = True
        return out
    return row


# ── rule 3 (+2, +5): the singleton / fleet verdict of a daemon ───────────────

def daemon_fleet_verdict(component_id: str, pod_rows: List[Dict[str, Any]], *,
                         singleton: bool, enabled: Optional[bool] = True) -> Tuple[str, str, Optional[str], Dict[str, Any]]:
    """One (state, reason, disposition, metrics) for a daemon from every
    pod's READ row of it (silence already applied).

    * runners = live pods whose row says ``metrics.running`` (not deferred /
      declined / disabled rows);
    * a singleton with 2+ runners is degraded naming them;
    * no runner: disabled-by-config anywhere -> healthy + disposition;
      every pod down -> down (inherited); some pod unknown -> unknown;
      live pods all say not running while expected -> down;
    * else the worst of the runners' own states, with the worst runner's reason.
    """
    live = [r for r in pod_rows if r.get("state") != UNKNOWN or not r.get("silent_seconds")]
    # a RUNNER is a fresh row of a pod that ACTS (metrics.acts, the one
    # election -- checks/daemons._acts_here); a STANDBY row (alive on a
    # non-holder) and a row silence rewrote (observed_state != state) are not
    # runners, so a lock handover never reads as "more than one pod"
    # (2026-10-18, the rebuilt rig's alerts #105-#111)
    runners = [r for r in pod_rows
               if (r.get("metrics") or {}).get("running") and r.get("state") not in (UNKNOWN, DOWN)
               and r.get("disposition") not in (DISPOSITION_DEFERRED, DISPOSITION_DISABLED)
               and (r.get("metrics") or {}).get("acts", True) is not False
               and not (r.get("metrics") or {}).get("standby")
               and (r.get("observed_state") in (None, r.get("state")))]
    metrics = {"pods_reporting": sorted({str(r.get("pod_id")) for r in pod_rows}),
               "running_on": sorted({str(r.get("pod_id")) for r in runners})}
    if singleton and len(runners) > 1:
        return (DEGRADED, "running on more than one pod: " + ", ".join(metrics["running_on"]),
                None, metrics)
    if runners:
        state = worst([r.get("state") or HEALTHY for r in runners])
        bad = [r for r in runners if r.get("state") == state]
        reason = str(bad[0].get("reason") or "") if bad else "running"
        disp = next((r.get("disposition") for r in runners if r.get("disposition")), None)
        return state, reason, disp, metrics
    disabled = [r for r in pod_rows if r.get("disposition") == DISPOSITION_DISABLED]
    if disabled:
        return HEALTHY, str(disabled[0].get("reason") or "off by config"), DISPOSITION_DISABLED, metrics
    if not pod_rows:
        return (UNKNOWN, unknown_reason("never reported by any pod"), None, metrics)
    if all(r.get("state") == DOWN for r in pod_rows):
        return DOWN, str(pod_rows[0].get("reason") or "every reporting pod is down"), None, metrics
    if any(r.get("state") == UNKNOWN for r in pod_rows):
        u = next(r for r in pod_rows if r.get("state") == UNKNOWN)
        return UNKNOWN, str(u.get("reason")), None, metrics
    if enabled is False:
        return HEALTHY, "off by config", DISPOSITION_DISABLED, metrics
    deferred = [r for r in pod_rows if r.get("disposition") == DISPOSITION_DEFERRED]
    if deferred and len(deferred) == len(pod_rows):
        return (DOWN, "every reporting pod defers it to the scheduler-lock holder and no holder "
                      "reports it running", None, metrics)
    worst_live = worst([r.get("state") or HEALTHY for r in live]) if live else UNKNOWN
    if worst_live in (DOWN, DEGRADED):
        r = next(r for r in live if r.get("state") == worst_live)
        return worst_live, str(r.get("reason") or ""), r.get("disposition"), metrics
    return (DOWN, "expected to run and no live pod reports it running: "
                  + "; ".join(f"{r.get('pod_id')}: {str(r.get('reason') or '')[:120]}" for r in pod_rows[:4]),
            None, metrics)


# ── rule 4: roll-up ──────────────────────────────────────────────────────────

def summary(rows: Iterable[Dict[str, Any]]) -> Dict[str, int]:
    out = {HEALTHY: 0, DEGRADED: 0, DOWN: 0, UNKNOWN: 0}
    for r in rows:
        s = r.get("state")
        if s in out:
            out[s] += 1
    return out


def headline(rows: Iterable[Dict[str, Any]]) -> str:
    return worst(r.get("state") or UNKNOWN for r in rows)


# ── rules 6-7: confirmation and alerting ─────────────────────────────────────

def confirmed(row: Dict[str, Any], th: Thresholds) -> bool:
    """The row's CURRENT state has been observed enough times to count."""
    return int(row.get("confirmations") or 0) >= th.transition_confirmations


def alert_kind_for(state: str, *, unknown_for_seconds: Optional[float], th: Thresholds) -> Optional[str]:
    if state == DOWN:
        return ALERT_COMPONENT_DOWN
    if state == DEGRADED:
        return ALERT_COMPONENT_DEGRADED
    if state == UNKNOWN and unknown_for_seconds is not None \
            and unknown_for_seconds >= th.unknown_alert_after_seconds:
        return ALERT_COMPONENT_UNKNOWN
    return None


def clear_due(row: Dict[str, Any], th: Thresholds) -> bool:
    """A healthy row observed healthy for clear_after_cycles clears its alert."""
    return row.get("state") == HEALTHY and int(row.get("confirmations") or 0) >= th.clear_after_cycles


__all__ = ["Thresholds", "age_seconds", "alert_kind_for", "apply_silence", "clear_due", "confirmed",
           "daemon_fleet_verdict", "headline", "inherit_from_pod", "parse_ts", "pod_states", "summary"]
