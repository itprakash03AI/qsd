"""
Per-connection circuit breaker -- prevents cascading failures when a
SQL connector (Trino/Snowflake/Databricks/Oracle) is down.

States:
  CLOSED    -> normal operation, failures increment counter
  OPEN      -> fast-fail all requests for this connection
  HALF_OPEN -> allow 1 probe request to test recovery

Transitions:
  CLOSED  -> failure_count >= threshold     -> OPEN
  OPEN    -> cooldown_seconds elapsed       -> HALF_OPEN
  HALF_OPEN -> probe succeeds              -> CLOSED (reset counter)
  HALF_OPEN -> probe fails                 -> OPEN   (reset cooldown)

Phase 83B: OPEN states are persisted to DB and loaded on startup so
recent outages survive server restarts.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

# Phase 83B: DB manager reference for state persistence
_db_manager = None

# -- Configuration -------------------------------------------------------------
_enabled: bool = True
_failure_threshold: int = 3
_cooldown_seconds: int = 60
#: Ceiling on ``cooldown_seconds * backoff``.  See the config comment: the
#: party waiting out this timer is usually a person with a query open, and the
#: only manual override is an ADMIN endpoint they cannot call.
_max_cooldown_seconds: int = 300
_half_open_max_calls: int = 1
_broadcast_fn: Optional[Callable] = None


def init_circuit_breaker(enabled: bool = True, failure_threshold: int = 3,
                         cooldown_seconds: int = 60,
                         max_cooldown_seconds: int = 300) -> None:
    global _enabled, _failure_threshold, _cooldown_seconds, _max_cooldown_seconds
    _enabled = enabled
    _failure_threshold = failure_threshold
    _cooldown_seconds = cooldown_seconds
    # 0 or negative disables the ceiling (pure BF-552 behaviour).
    _max_cooldown_seconds = int(max_cooldown_seconds or 0)
    logger.info("[circuit_breaker] Initialised -- enabled=%s threshold=%d "
                "cooldown=%ds max_cooldown=%ds",
                _enabled, _failure_threshold, _cooldown_seconds,
                _max_cooldown_seconds)


def set_broadcast_fn(fn: Callable) -> None:
    global _broadcast_fn
    _broadcast_fn = fn


class CircuitState(str, Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"


class CircuitOpenError(Exception):
    """Raised when circuit is open and request is rejected."""
    def __init__(self, connection_id: int, connection_name: str, retry_after: float):
        self.connection_id = connection_id
        self.connection_name = connection_name
        self.retry_after = retry_after
        # 2026-08-20 — written for the PERSON who sees it.
        #
        # This text reaches the UI as the query's error ("S3 query failed:
        # Circuit breaker OPEN for connection 'duckdb_engine:conn-1'
        # (id=-200001). Retry after 173665s.").  A normal user cannot act on a
        # synthetic negative id or an internal state name, and nothing told
        # them the system recovers BY ITSELF — so the reasonable reading was
        # "raise a ticket", when the right action is "try again shortly".
        _secs = max(0, int(retry_after))
        _when = (f"{_secs}s" if _secs < 90
                 else f"about {max(1, round(_secs / 60))} minute(s)")
        super().__init__(
            f"'{connection_name}' is temporarily unavailable — repeated "
            f"failures have paused new queries against it so the source is "
            f"not hammered while it recovers. This clears ITSELF: just run "
            f"the query again in {_when}; no admin action is needed. "
            f"(connection id={connection_id}, retry_after={_secs}s)"
        )


@dataclass
class CircuitBreaker:
    connection_id: int
    connection_name: str
    state: CircuitState = CircuitState.CLOSED
    failure_count: int = 0
    success_count: int = 0
    last_failure_at: Optional[float] = None
    last_success_at: Optional[float] = None
    last_state_change: float = field(default_factory=time.time)
    #: 2026-08-20 -- COOLDOWN IS MEASURED ON A MONOTONIC CLOCK.
    #:
    #: ``last_state_change`` is a WALL-CLOCK stamp and stays one: it is what
    #: gets persisted, broadcast to the UI and rendered.  But wall clocks move
    #: BACKWARDS -- an NTP step, a VM snapshot resume, an operator fixing the
    #: date on a test box.  Subtracting one from ``time.time()`` then yields a
    #: NEGATIVE elapsed, ``cooldown - elapsed`` becomes enormous, and the
    #: breaker never reaches its HALF_OPEN probe.  Field-observed:
    #:
    #:     Circuit breaker OPEN ... Retry after 173665s.
    #:
    #: 173,665s is 48 hours -- arithmetically IMPOSSIBLE, because the effective
    #: cooldown is capped at ``cooldown_seconds * 32`` = 1920s at the default.
    #: The only way to print it is a state change stamped ~48h in the future,
    #: i.e. a clock that jumped back.  Nothing in the process could ever heal
    #: it: the breaker leaves OPEN only when the cooldown elapses, and it never
    #: would.  A breaker that cannot re-probe is not a breaker, it is an outage.
    #:
    #: ``time.monotonic()`` cannot go backwards, so elapsed is always sane.
    last_state_change_mono: float = field(default_factory=time.monotonic)
    last_error: Optional[str] = None
    _half_open_calls: int = 0

    def to_dict(self) -> dict:
        return {
            "connection_id": self.connection_id,
            "connection_name": self.connection_name,
            "state": self.state.value,
            "failure_count": self.failure_count,
            "success_count": self.success_count,
            "last_failure_at": self.last_failure_at,
            "last_success_at": self.last_success_at,
            "last_state_change": self.last_state_change,
            "last_error": self.last_error,
        }


class CircuitBreakerRegistry:
    def __init__(self):
        self._breakers: Dict[int, CircuitBreaker] = {}
        self._lock = threading.Lock()
        self._db_manager = None  # Phase 83B: set by load_circuit_breaker_states()

    def _get_or_create(self, connection_id: int, connection_name: str = "") -> CircuitBreaker:
        if connection_id not in self._breakers:
            self._breakers[connection_id] = CircuitBreaker(
                connection_id=connection_id,
                connection_name=connection_name,
            )
        return self._breakers[connection_id]

    def check(self, connection_id: int, connection_name: str = "") -> None:
        if not _enabled:
            return
        with self._lock:
            cb = self._get_or_create(connection_id, connection_name)
            now = time.time()

            if cb.state == CircuitState.CLOSED:
                return  # allow

            if cb.state == CircuitState.OPEN and self._adopt_remote_reset(cb, now):
                return  # another pod reset it; this process follows

            if cb.state == CircuitState.OPEN:
                # BF-552 (2026-05-29): exponential backoff between
                # successive OPEN→HALF_OPEN transitions.  Without this,
                # a permanently-broken service oscillates OPEN ↔
                # HALF_OPEN forever at fixed cadence, flooding logs and
                # adding overhead.  Each consecutive failed probe
                # doubles the cooldown (capped at 32× base) so a
                # genuinely-dead service backs off quickly.  Counter
                # resets on first successful probe.
                _cycles = getattr(cb, "_consec_open_cycles", 0)
                _backoff_mult = min(32, 2 ** max(0, _cycles - 1))
                _effective_cooldown = _cooldown_seconds * _backoff_mult
                # Ceiling — see _max_cooldown_seconds.  Without it the ladder
                # reaches 32x (32 minutes at the default base) and the only
                # escape is an admin-only reset endpoint.
                if _max_cooldown_seconds > 0:
                    _effective_cooldown = min(_effective_cooldown,
                                              _max_cooldown_seconds)
                # Monotonic, not wall-clock -- see last_state_change_mono.
                elapsed = time.monotonic() - cb.last_state_change_mono
                if elapsed >= _effective_cooldown:
                    # Transition to HALF_OPEN
                    cb.state = CircuitState.HALF_OPEN
                    cb.last_state_change = now
                    cb.last_state_change_mono = time.monotonic()
                    cb._half_open_calls = 0
                    logger.info("[circuit_breaker] %s (id=%d): OPEN -> HALF_OPEN "
                                "(cooldown elapsed; backoff mult=%d, cycles=%d)",
                                cb.connection_name, connection_id,
                                _backoff_mult, _cycles)
                    self._broadcast_state_change(cb)
                    return  # allow probe
                else:
                    # BELT AND BRACES.  This value is shown to users and is the
                    # basis of an HTTP Retry-After; it can never legitimately
                    # exceed the cooldown it is counting down.  If it does, the
                    # timer itself is wrong -- and a wrong timer must not
                    # outlive the cooldown, so re-anchor rather than serve it.
                    retry_after = _effective_cooldown - elapsed
                    if not (0.0 <= retry_after <= _effective_cooldown):
                        logger.warning(
                            "[circuit_breaker] %s (id=%d): implausible retry_after "
                            "%.0fs (cooldown=%ds) -- clock moved backwards or the "
                            "state was restored with a bad stamp; re-anchoring",
                            cb.connection_name, connection_id,
                            retry_after, _effective_cooldown)
                        cb.last_state_change_mono = time.monotonic()
                        cb.last_state_change = now
                        retry_after = float(_effective_cooldown)
                    raise CircuitOpenError(connection_id, cb.connection_name, retry_after)

            if cb.state == CircuitState.HALF_OPEN:
                if cb._half_open_calls >= _half_open_max_calls:
                    raise CircuitOpenError(connection_id, cb.connection_name, _cooldown_seconds)
                cb._half_open_calls += 1

    def record_success(self, connection_id: int) -> None:
        if not _enabled:
            return
        with self._lock:
            cb = self._breakers.get(connection_id)
            if not cb:
                return
            cb.success_count += 1
            cb.last_success_at = time.time()

            if cb.state == CircuitState.HALF_OPEN:
                # Recovery confirmed
                cb.state = CircuitState.CLOSED
                cb.failure_count = 0
                cb._half_open_calls = 0
                cb.last_state_change_mono = time.monotonic()
                # BF-552: reset the backoff counter on successful
                # recovery so a subsequent failure starts fresh.
                cb._consec_open_cycles = 0
                cb.last_state_change = time.time()
                logger.info("[circuit_breaker] %s (id=%d): HALF_OPEN -> CLOSED (recovery confirmed)",
                            cb.connection_name, connection_id)
                self._broadcast_state_change(cb)
                # Phase 83B: Remove persisted OPEN state
                self._persist_closed(connection_id)
            elif cb.state == CircuitState.CLOSED:
                # Reset failure count on success
                cb.failure_count = 0

    def record_failure(self, connection_id: int, error: str, connection_name: str = "") -> None:
        if not _enabled:
            return
        with self._lock:
            cb = self._get_or_create(connection_id, connection_name)
            cb.failure_count += 1
            cb.last_failure_at = time.time()
            cb.last_error = error[:500]  # Truncate long errors

            if cb.state == CircuitState.HALF_OPEN:
                # Probe failed -- back to OPEN
                cb.state = CircuitState.OPEN
                cb.last_state_change = time.time()
                cb.last_state_change_mono = time.monotonic()
                cb._half_open_calls = 0
                # BF-552: bump the consecutive-OPEN-cycles counter so
                # the next OPEN→HALF_OPEN transition uses an
                # exponentially-longer cooldown.
                cb._consec_open_cycles = getattr(cb, "_consec_open_cycles", 0) + 1
                logger.warning("[circuit_breaker] %s (id=%d): HALF_OPEN -> OPEN "
                               "(probe failed: %s; cycles=%d, next backoff=%dx)",
                               cb.connection_name, connection_id,
                               error[:100], cb._consec_open_cycles,
                               min(32, 2 ** max(0, cb._consec_open_cycles - 1)))
                self._broadcast_state_change(cb)
                # Phase 83B: Persist OPEN state
                self._persist_open(cb)
            elif cb.state == CircuitState.CLOSED and cb.failure_count >= _failure_threshold:
                cb.state = CircuitState.OPEN
                cb.last_state_change = time.time()
                cb.last_state_change_mono = time.monotonic()
                logger.warning("[circuit_breaker] %s (id=%d): CLOSED -> OPEN (failures=%d >= threshold=%d: %s)",
                               cb.connection_name, connection_id, cb.failure_count,
                               _failure_threshold, error[:100])
                self._broadcast_state_change(cb)
                # Phase 83B: Persist OPEN state
                self._persist_open(cb)

    def reset(self, connection_id: int) -> Optional[dict]:
        with self._lock:
            cb = self._breakers.get(connection_id)
            if not cb:
                return None
            old_state = cb.state
            cb.state = CircuitState.CLOSED
            cb.failure_count = 0
            cb._half_open_calls = 0
            cb.last_state_change = time.time()
            cb.last_state_change_mono = time.monotonic()
            # BF-552 follow-up: a manual reset is an operator saying "the
            # dependency is fixed".  Clear the backoff ladder too, or the very
            # next failure jumps straight back to a 32x cooldown.
            cb._consec_open_cycles = 0
            logger.info("[circuit_breaker] %s (id=%d): %s -> CLOSED (manual reset)",
                        cb.connection_name, connection_id, old_state.value)
            self._broadcast_state_change(cb)
            # 2026-08-20: and DELETE the persisted OPEN row.  Without this the
            # reset lived only in memory -- the row that reopened the breaker on
            # the last restart was still in the DB, so "I reset it" and "it came
            # back after a restart" were both true at the same time.
            self._persist_closed(connection_id)
            return cb.to_dict()

    def get_all_states(self) -> List[dict]:
        with self._lock:
            return [cb.to_dict() for cb in self._breakers.values()]

    def get_state(self, connection_id: int) -> Optional[dict]:
        with self._lock:
            cb = self._breakers.get(connection_id)
            return cb.to_dict() if cb else None

    #: how often an OPEN breaker re-reads its DB row (seconds)
    REMOTE_RESET_RECHECK_S = 5.0

    def _adopt_remote_reset(self, cb: CircuitBreaker, now: float) -> bool:
        """2026-10-17 (component health, defect 1).  ``reset`` closed THIS
        process's breaker and deleted the DB row -- every other pod's copy
        stayed OPEN until its cooldown (found designing the one health
        page).  An OPEN breaker now re-reads its row at most every
        REMOTE_RESET_RECHECK_S: no row = a reset made elsewhere, adopt it.
        Called under self._lock.  Fails to False (a DB blip keeps the
        breaker's own decision)."""
        # Three guards, because the evidence is an ABSENCE (the row a reset
        # deletes): (1) only a breaker whose OPEN was PERSISTED through THIS
        # registry's own db (load_circuit_breaker_states wires the process
        # singleton; a registry built without one never adopts); (2) only once
        # the async persist has had a whole recheck interval to land; (3) the
        # row must be absent on TWO consecutive rechecks an interval apart --
        # one missing read is a blip, two are a reset.
        if not getattr(cb, "_persisted_open", False) or not self._db_manager:
            return False
        if now - float(cb.last_state_change or now) < self.REMOTE_RESET_RECHECK_S:
            return False
        last = getattr(cb, "_remote_check_at", 0.0)
        if now - last < self.REMOTE_RESET_RECHECK_S:
            return False
        cb._remote_check_at = now
        try:
            rows = self._db_manager.get_circuit_breaker_states() or []
        except Exception as exc:                            # noqa: BLE001
            logger.debug("[circuit_breaker] remote-reset check failed: %s", exc)
            return False
        if any(int(r.get("connection_id", -1)) == int(cb.connection_id) and r.get("state") == "OPEN"
               for r in rows):
            cb._absent_rechecks = 0
            return False
        cb._absent_rechecks = int(getattr(cb, "_absent_rechecks", 0)) + 1
        if cb._absent_rechecks < 2:
            return False
        old = cb.state
        cb.state = CircuitState.CLOSED
        cb.failure_count = 0
        cb._half_open_calls = 0
        cb._consec_open_cycles = 0
        cb._persisted_open = False
        cb._absent_rechecks = 0
        cb.last_state_change = time.time()
        cb.last_state_change_mono = time.monotonic()
        logger.info("[circuit_breaker] %s (id=%d): %s -> CLOSED (reset made on another pod, adopted)",
                    cb.connection_name, cb.connection_id, old.value)
        self._broadcast_state_change(cb)
        return True

    def _persist_open(self, cb: CircuitBreaker) -> None:
        """Phase 83B: Best-effort persist OPEN state to DB (called in thread-locked context)."""
        db = self._db_manager or _db_manager
        if not db:
            return
        cb._persisted_open = True      # a reset elsewhere deletes this row (_adopt_remote_reset)
        try:
            import threading as _thr
            _thr.Thread(
                target=db.save_circuit_breaker_state,
                args=(cb.connection_id, "OPEN", cb.failure_count,
                      cb.last_failure_at, cb.last_failure_at, cb.connection_name),
                daemon=True,
            ).start()
        except Exception:
            pass

    def _persist_closed(self, connection_id: int) -> None:
        """Phase 83B: Best-effort remove persisted state on CLOSED transition."""
        db = self._db_manager or _db_manager
        if not db:
            return
        try:
            import threading as _thr
            _thr.Thread(
                target=db.delete_circuit_breaker_state,
                args=(connection_id,),
                daemon=True,
            ).start()
        except Exception:
            pass

    def _broadcast_state_change(self, cb: CircuitBreaker) -> None:
        if _broadcast_fn:
            try:
                from datetime import datetime, timezone
                _broadcast_fn({
                    "type": "circuit_breaker_state_change",
                    "connection_id": cb.connection_id,
                    "connection_name": cb.connection_name,
                    "state": cb.state.value,
                    "failure_count": cb.failure_count,
                    "last_error": cb.last_error,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                })
            except Exception as exc:
                logger.debug("[circuit_breaker] broadcast failed: %s", exc)


# -- Module-level singleton ----------------------------------------------------
_registry = CircuitBreakerRegistry()


def check_circuit(connection_id: int, connection_name: str = "") -> None:
    _registry.check(connection_id, connection_name)

def record_success(connection_id: int) -> None:
    _registry.record_success(connection_id)

def record_failure(connection_id: int, error: str, connection_name: str = "") -> None:
    _registry.record_failure(connection_id, error, connection_name)

def reset_circuit(connection_id: int) -> Optional[dict]:
    return _registry.reset(connection_id)

def get_circuit_states() -> List[dict]:
    return _registry.get_all_states()

def get_circuit_state(connection_id: int) -> Optional[dict]:
    return _registry.get_state(connection_id)


def load_circuit_breaker_states(db_manager) -> None:
    """Phase 83B: Load persisted OPEN circuit breaker states from DB at startup.

    Only restores states whose opened_at + cooldown_seconds > now
    (states that already cooled down would be HALF_OPEN by now, not OPEN).
    """
    global _db_manager
    _db_manager = db_manager
    # Also wire into the registry singleton
    _registry._db_manager = db_manager

    try:
        states = db_manager.get_circuit_breaker_states()
        now = time.time()
        restored = 0
        for row in states:
            conn_id = row.get("connection_id")
            state_str = row.get("state", "OPEN")
            if state_str != "OPEN":
                continue
            # Check if cooldown has NOT yet elapsed
            opened_at = row.get("opened_at")
            if opened_at is not None:
                if hasattr(opened_at, "timestamp"):
                    # SQLite returns naive datetimes; data was stored as UTC.
                    # Always treat naive datetimes as UTC to avoid local-tz offset.
                    from datetime import timezone as _tz2
                    if hasattr(opened_at, "tzinfo") and opened_at.tzinfo is None:
                        opened_ts = opened_at.replace(tzinfo=_tz2.utc).timestamp()
                    else:
                        opened_ts = opened_at.timestamp()
                else:
                    try:
                        from datetime import datetime as _dt
                        opened_ts = _dt.fromisoformat(str(opened_at)).timestamp()
                    except Exception:
                        continue
                if opened_ts + _cooldown_seconds <= now:
                    # Already cooled down — skip (don't restore)
                    continue
            with _registry._lock:
                cb = _registry._get_or_create(conn_id, row.get("connection_name", ""))
                cb.state = CircuitState.OPEN
                cb.failure_count = row.get("failure_count", 0)
                # Restore last_state_change so the cooldown timer is correct.
                #
                # 2026-08-20: this used RAW ``opened_at.timestamp()``, which on
                # a NAIVE datetime means "interpret as LOCAL time" -- exactly
                # the local-tz offset the skip-check above goes to the trouble
                # of avoiding.  The two branches therefore disagreed by the UTC
                # offset: one could call a breaker cooled-down while the other
                # restored it with a shifted timer.  One corrected value, used
                # by both.
                if opened_at is not None:
                    cb.last_state_change = opened_ts
                    # Anchor the MONOTONIC timer to the age the DB reports, so a
                    # restored breaker cools down from when it actually opened
                    # rather than from process start.  Clamped at 0 -- a stamp
                    # from the future must not extend the cooldown.
                    cb.last_state_change_mono = time.monotonic() - max(0.0, now - opened_ts)
                restored += 1
        if restored:
            logger.info("[circuit_breaker] Restored %d OPEN circuit breaker states from DB", restored)
    except Exception as exc:
        logger.warning("[circuit_breaker] Could not load persisted states: %s", exc)
