/**
 * Settings -- the DATA that decides what a feed does when its
 * upstream re-sends a delivered business date, and where every feed alert
 * goes (2026-10-12, the owner: "config should say everything as we're not
 * hardcoding anything").  A tab of Feed Run Status (one dashboard).
 *
 *   Re-send policies   per scope (every feed / a feed group / a template / one
 *                      feed; the most specific wins): a new message on a LATER
 *                      run date re-runs / holds / asks; on the SAME run date;
 *                      until when the business date stays open
 *   Alert kinds        each alert's title, severity (Netcool 0-5), console
 *                      group and channels (bell / e-mail / Netcool)
 *   Routes             who else hears: an e-mail address or a user / group:NAME
 *
 * Every row is the server's (/api/admin/feed-restatement-policies,
 * /feed-alert-kinds, /feed-alert-routes); the server validates.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Checkbox, IconButton, MenuItem, Paper, Stack, Table, TableBody, TableCell,
  TableHead, TableRow, TextField, Tooltip, Typography,
} from '@mui/material';
import { Delete as DeleteIcon, Save as SaveIcon } from '@mui/icons-material';
import api from '../../services/api';
import ListPager, { clientPage } from '../common/ListPager';

const SCOPES = [
  { value: 'global', label: 'Every feed' }, { value: 'feed_group', label: 'Feed group' },
  { value: 'template', label: 'Template' }, { value: 'feed', label: 'One feed' },
];
const ACTION_WORDS: Record<string, string> = {
  rerun: 'Re-run it (a new file for the run date)', hold: 'Hold the re-run, alert, an approver decides',
  decide: 'Ask a person (no alert)',
};
const WINDOW_WORDS: Record<string, string> = {
  next_business_date: "Until the feed's next scheduled business date", days: 'For N days after the business date',
  workdays: "For work days WD1..WDn after the business date (the feed's calendar)",
  open: 'Always',
};
const windowText = (p: any) => (WINDOW_WORDS[p.window] || p.window)
  + (p.window === 'days' ? ` (${p.window_days})` : '')
  + (p.window === 'workdays' ? ` (WD1..WD${p.window_workdays})` : '');
const scopeWord = (s: string) => SCOPES.find(x => x.value === s)?.label || s;

function Section({ title, help, children }: { title: string; help: string; children: React.ReactNode }) {
  return (
    <Paper variant="outlined" sx={{ p: 1.5, mb: 1.5 }}>
      <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>{title}</Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>{help}</Typography>
      {children}
    </Paper>
  );
}

export default function FeedAlertSettings() {
  const [policies, setPolicies] = useState<any[]>([]);
  const [kinds, setKinds] = useState<any[]>([]);
  const [groups, setGroups] = useState<string[]>([]);
  const [routes, setRoutes] = useState<any[]>([]);
  const [msgFields, setMsgFields] = useState<any[]>([]);
  const [envs, setEnvs] = useState<any[]>([]);
  const [tokens, setTokens] = useState<any[]>([]);
  const [newField, setNewField] = useState({ field: '', label: '' });
  const [newToken, setNewToken] = useState({ token: '', message_field: '' });
  // a policy / route may exist per feed (4,000 feeds): both lists PAGE
  const [polPage, setPolPage] = useState(1);
  const [polSize, setPolSize] = useState(25);
  const [rtPage, setRtPage] = useState(1);
  const [rtSize, setRtSize] = useState(25);
  const polPg = clientPage(policies, polPage, polSize);
  const rtPg = clientPage(routes, rtPage, rtSize);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [pol, setPol] = useState<any>({ scope: 'global', scope_id: '', on_new_message: 'rerun',
                                        same_run_date: 'hold', window: 'next_business_date', window_days: '' , name: '',
                                        window_workdays: '' });
  const [route, setRoute] = useState<any>({ scope: 'global', scope_id: '', kind: '', channel: 'email', target: '' });

  const load = useCallback(async () => {
    try {
      const [p, k, r, mf, ev, tk]: any = await Promise.all([api.restatementPolicies(), api.feedAlertKinds(),
        api.feedAlertRoutes(), api.feedMessageFields(), api.feedEnvironments(), api.feedMessageTokens()]);
      setPolicies(p.policies || []); setKinds(k.kinds || []); setGroups(k.alert_groups || []); setRoutes(r.routes || []);
      setMsgFields(mf.fields || []); setEnvs(ev.environments || []); setTokens(tk.tokens || []);
    } catch (e: any) {
      setMsg({ ok: false, text: e?.message || 'Could not read the alert settings' });
    }
  }, []);
  useEffect(() => { void load(); }, [load]);

  const act = async (fn: () => Promise<any>, ok: string) => {
    setMsg(null);
    try { await fn(); setMsg({ ok: true, text: ok }); await load(); }
    catch (e: any) { setMsg({ ok: false, text: e?.message || 'Refused' }); }
  };
  const sid = (v: any) => (v === '' || v == null ? null : Number(v));

  return (
    <Box data-testid="feed-alert-settings">
      {msg && <Alert severity={msg.ok ? 'success' : 'error'} onClose={() => setMsg(null)} sx={{ mb: 1 }}
                     data-testid="alert-settings-msg">{msg.text}</Alert>}

      <Section title="Re-send policies"
               help="What happens when the upstream sends a NEW version for a business date already delivered (month end: messages keep coming daily). The most specific scope wins.">
        <Table size="small" data-testid="restatement-policies">
          <TableHead><TableRow>
            <TableCell>Applies to</TableCell><TableCell>Name</TableCell><TableCell>New version, a later run date</TableCell>
            <TableCell>Re-sent the same run date</TableCell><TableCell>Open to re-sends</TableCell><TableCell />
          </TableRow></TableHead>
          <TableBody>
            {polPg.rows.map(p => (
              <TableRow key={p.id} data-testid="restatement-policy">
                <TableCell>{scopeWord(p.scope)}{p.scope_id != null ? ` #${p.scope_id}` : ''}</TableCell>
                <TableCell>{p.name}</TableCell>
                <TableCell>{ACTION_WORDS[p.on_new_message] || p.on_new_message}</TableCell>
                <TableCell>{ACTION_WORDS[p.same_run_date] || p.same_run_date}</TableCell>
                <TableCell>{windowText(p)}</TableCell>
                <TableCell padding="checkbox">
                  <Tooltip title="Remove this policy">
                    <IconButton size="small" aria-label={`Remove policy ${p.name || p.id}`}
                                onClick={() => act(() => api.deleteRestatementPolicy(p.id), 'Policy removed')}>
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <ListPager paging={polPg.paging} onPage={setPolPage} onPageSize={setPolSize} testid="restatement-policies-pager" />
        <Stack direction="row" useFlexGap sx={{ flexWrap: 'wrap', gap: 1, mt: 1 }} data-testid="restatement-policy-form">
          <TextField select size="small" label="Applies to" value={pol.scope} sx={{ width: 140 }}
                     onChange={e => setPol({ ...pol, scope: e.target.value })}>
            {SCOPES.map(s => <MenuItem key={s.value} value={s.value}>{s.label}</MenuItem>)}
          </TextField>
          {pol.scope !== 'global' && (
            <TextField size="small" label="Its id" value={pol.scope_id} sx={{ width: 90 }}
                       onChange={e => setPol({ ...pol, scope_id: e.target.value.replace(/\D/g, '') })} />
          )}
          <TextField size="small" label="Name" value={pol.name} sx={{ width: 150 }}
                     onChange={e => setPol({ ...pol, name: e.target.value })} />
          {(['on_new_message', 'same_run_date'] as const).map(k => (
            <TextField key={k} select size="small" sx={{ width: 250 }} value={pol[k]}
                       label={k === 'on_new_message' ? 'New version, a later run date' : 'Re-sent the same run date'}
                       onChange={e => setPol({ ...pol, [k]: e.target.value })}>
              {Object.entries(ACTION_WORDS).map(([v, l]) => <MenuItem key={v} value={v}>{l}</MenuItem>)}
            </TextField>
          ))}
          <TextField select size="small" label="Open to re-sends" value={pol.window} sx={{ width: 260 }}
                     onChange={e => setPol({ ...pol, window: e.target.value })}>
            {Object.entries(WINDOW_WORDS).map(([v, l]) => <MenuItem key={v} value={v}>{l}</MenuItem>)}
          </TextField>
          {pol.window === 'days' && (
            <TextField size="small" label="Days" value={pol.window_days} sx={{ width: 80 }}
                       onChange={e => setPol({ ...pol, window_days: e.target.value.replace(/\D/g, '') })} />
          )}
          {pol.window === 'workdays' && (
            <TextField size="small" label="Work days (N)" value={pol.window_workdays} sx={{ width: 120 }}
                       inputProps={{ 'data-testid': 'restatement-policy-workdays' }}
                       onChange={e => setPol({ ...pol, window_workdays: e.target.value.replace(/\D/g, '') })} />
          )}
          <Button variant="contained" size="small" startIcon={<SaveIcon />} data-testid="restatement-policy-save"
                  onClick={() => act(() => api.putRestatementPolicy({
                    ...pol, scope_id: pol.scope === 'global' ? null : sid(pol.scope_id),
                    window_days: pol.window === 'days' ? sid(pol.window_days) : null,
                    window_workdays: pol.window === 'workdays' ? sid(pol.window_workdays) : null }), 'Policy saved')}>
            Save policy
          </Button>
        </Stack>
      </Section>

      <Section title="Alert kinds"
               help="Every alert a feed raises, how severe it is (Netcool 0-5), which console group it routes to and where it goes. A change applies to the next alert.">
        <Table size="small" data-testid="alert-kinds">
          <TableHead><TableRow>
            <TableCell>Alert</TableCell><TableCell>Severity</TableCell><TableCell>Console group</TableCell>
            <TableCell>Bell</TableCell><TableCell>E-mail</TableCell><TableCell>Netcool</TableCell><TableCell>Clears when</TableCell>
          </TableRow></TableHead>
          <TableBody>
            {kinds.map(k => {
              const put = (patch: any) => act(() => api.putFeedAlertKind({ ...k, ...patch }), `${k.title}: saved`);
              return (
                <TableRow key={k.kind} data-testid="alert-kind" data-kind={k.kind}>
                  <TableCell><b>{k.title}</b><br /><Typography variant="caption" color="text.secondary">{k.kind}</Typography></TableCell>
                  <TableCell>
                    <TextField select size="small" value={k.severity} sx={{ width: 70 }}
                               inputProps={{ 'aria-label': `Severity of ${k.kind}` }}
                               onChange={e => put({ severity: Number(e.target.value) })}>
                      {[0, 1, 2, 3, 4, 5].map(n => <MenuItem key={n} value={n}>{n}</MenuItem>)}
                    </TextField>
                  </TableCell>
                  <TableCell>
                    <TextField select size="small" value={k.alert_group} sx={{ width: 170 }}
                               inputProps={{ 'aria-label': `Console group of ${k.kind}` }}
                               onChange={e => put({ alert_group: e.target.value })}>
                      {groups.map(g => <MenuItem key={g} value={g}>{g}</MenuItem>)}
                    </TextField>
                  </TableCell>
                  {(['to_bell', 'to_email', 'to_netcool'] as const).map(c => (
                    <TableCell key={c} padding="checkbox">
                      <Checkbox size="small" checked={!!k[c]} data-testid={`alert-kind-${c}`}
                                inputProps={{ 'aria-label': `${c.slice(3)} for ${k.kind}` }}
                                onChange={e => put({ [c]: e.target.checked })} />
                    </TableCell>
                  ))}
                  <TableCell><Typography variant="caption">{k.clears_when}</Typography></TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Section>

      <Section title="Who else hears (routes)"
               help="Beyond the feed's owner, its approver groups and its notify e-mails: an e-mail address, or a username / group:NAME in the bell — for one alert kind or all, at a scope.">
        <Table size="small" data-testid="alert-routes">
          <TableHead><TableRow>
            <TableCell>Applies to</TableCell><TableCell>Alert</TableCell><TableCell>Channel</TableCell><TableCell>To</TableCell><TableCell />
          </TableRow></TableHead>
          <TableBody>
            {routes.length === 0 && (
              <TableRow><TableCell colSpan={5}><Typography variant="body2" color="text.secondary">
                No routes: alerts reach the feed's owner, its approver groups and its notify e-mails.
              </Typography></TableCell></TableRow>
            )}
            {rtPg.rows.map(r => (
              <TableRow key={r.id} data-testid="alert-route">
                <TableCell>{scopeWord(r.scope)}{r.scope_id != null ? ` #${r.scope_id}` : ''}</TableCell>
                <TableCell>{r.kind || 'every alert'}</TableCell>
                <TableCell>{r.channel === 'email' ? 'E-mail' : 'Bell'}</TableCell>
                <TableCell>{r.target}</TableCell>
                <TableCell padding="checkbox">
                  <IconButton size="small" aria-label={`Remove route to ${r.target}`}
                              onClick={() => act(() => api.deleteFeedAlertRoute(r.id), 'Route removed')}>
                    <DeleteIcon fontSize="small" />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <ListPager paging={rtPg.paging} onPage={setRtPage} onPageSize={setRtSize} testid="alert-routes-pager" />
        <Stack direction="row" useFlexGap sx={{ flexWrap: 'wrap', gap: 1, mt: 1 }} data-testid="alert-route-form">
          <TextField select size="small" label="Applies to" value={route.scope} sx={{ width: 140 }}
                     onChange={e => setRoute({ ...route, scope: e.target.value })}>
            {SCOPES.map(s => <MenuItem key={s.value} value={s.value}>{s.label}</MenuItem>)}
          </TextField>
          {route.scope !== 'global' && (
            <TextField size="small" label="Its id" value={route.scope_id} sx={{ width: 90 }}
                       onChange={e => setRoute({ ...route, scope_id: e.target.value.replace(/\D/g, '') })} />
          )}
          <TextField select size="small" label="Alert" value={route.kind} sx={{ width: 220 }}
                     SelectProps={{ displayEmpty: true }} InputLabelProps={{ shrink: true }}
                     onChange={e => setRoute({ ...route, kind: e.target.value })}>
            <MenuItem value="">Every alert</MenuItem>
            {kinds.map(k => <MenuItem key={k.kind} value={k.kind}>{k.title}</MenuItem>)}
          </TextField>
          <TextField select size="small" label="Channel" value={route.channel} sx={{ width: 110 }}
                     onChange={e => setRoute({ ...route, channel: e.target.value })}>
            <MenuItem value="email">E-mail</MenuItem><MenuItem value="bell">Bell</MenuItem>
          </TextField>
          <TextField size="small" label={route.channel === 'email' ? 'E-mail address' : 'User or group:NAME'}
                     value={route.target} sx={{ width: 240 }}
                     onChange={e => setRoute({ ...route, target: e.target.value })} />
          <Button variant="contained" size="small" disabled={!route.target.trim()} data-testid="alert-route-add"
                  onClick={() => act(() => api.addFeedAlertRoute({
                    ...route, scope_id: route.scope === 'global' ? null : sid(route.scope_id),
                    kind: route.kind || null, target: route.target.trim() }), 'Route added')}>
            Add route
          </Button>
        </Stack>
      </Section>

      <Section title="Upstream message fields"
               help="The columns of the upstream message (Kafka / QS_KAFKA_MESSAGE): which ones a dependency tile shows, which ones the Upstream messages table shows, and which ones IDENTIFY what a message is about (a waiting tile shows those for the message it expects — never another message's snapshot or version).">
        <Table size="small" data-testid="message-fields">
          <TableHead><TableRow>
            <TableCell>Field</TableCell><TableCell>Label</TableCell><TableCell>On the tile</TableCell>
            <TableCell>In the messages table</TableCell><TableCell>Identifies the message</TableCell><TableCell>In use</TableCell>
          </TableRow></TableHead>
          <TableBody>
            {msgFields.map(f => {
              const put = (patch: any) => act(() => api.putFeedMessageField({ ...f, ...patch }), `${f.field}: saved`);
              return (
                <TableRow key={f.field} data-testid="message-field" data-field={f.field}>
                  <TableCell sx={{ fontFamily: 'monospace' }}>{f.field}</TableCell>
                  <TableCell>
                    <TextField size="small" defaultValue={f.label} sx={{ width: 150 }}
                               inputProps={{ 'aria-label': `Label of ${f.field}` }}
                               onBlur={e => { if (e.target.value.trim() && e.target.value !== f.label) put({ label: e.target.value.trim() }); }} />
                  </TableCell>
                  {(['on_tile', 'on_monitor', 'identifies', 'is_active'] as const).map(c => (
                    <TableCell key={c} padding="checkbox">
                      <Checkbox size="small" checked={!!f[c]} data-testid={`message-field-${c}`}
                                inputProps={{ 'aria-label': `${c} for ${f.field}` }}
                                onChange={e => put({ [c]: e.target.checked })} />
                    </TableCell>
                  ))}
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
        <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
          <TextField size="small" label="Field (as the message spells it)" value={newField.field} sx={{ width: 240 }}
                     onChange={e => setNewField({ ...newField, field: e.target.value })} />
          <TextField size="small" label="Label" value={newField.label} sx={{ width: 160 }}
                     onChange={e => setNewField({ ...newField, label: e.target.value })} />
          <Button variant="contained" size="small" disabled={!newField.field.trim() || !newField.label.trim()}
                  onClick={() => act(() => api.putFeedMessageField({ field: newField.field.trim(), label: newField.label.trim(),
                    sort_order: (msgFields.length + 1) * 10, on_tile: true, on_monitor: true, identifies: false }),
                    'Field added').then(() => setNewField({ field: '', label: '' }))}>
            Add field
          </Button>
        </Stack>
      </Section>

      <Section title="Environments"
               help="The sides a combined feed reads, their label on every screen, how a dependency NAME says it (endings) and how a MESSAGE says it (a field and its values).">
        <Table size="small" data-testid="environments">
          <TableHead><TableRow>
            <TableCell>Side</TableCell><TableCell>Label</TableCell><TableCell>Dependency name ends with</TableCell>
            <TableCell>Message field</TableCell><TableCell>Values meaning this side</TableCell><TableCell />
          </TableRow></TableHead>
          <TableBody>
            {envs.map(e => <EnvRow key={e.side} env={e} onSave={b => act(() => api.putFeedEnvironment(b), `${b.label}: saved`)} />)}
          </TableBody>
        </Table>
      </Section>

      <Section title="Message tokens in SQL"
               help="A token a feed's SQL may use, filled from the environment's governing message: {version} = its VERSION_NUMBER, {snapshot} = its SNAP_VERSION.">
        <Table size="small" data-testid="message-tokens">
          <TableHead><TableRow><TableCell>Token</TableCell><TableCell>Message field</TableCell><TableCell>In use</TableCell></TableRow></TableHead>
          <TableBody>
            {tokens.map(t => (
              <TableRow key={t.token} data-testid="message-token">
                <TableCell sx={{ fontFamily: 'monospace' }}>{`{${t.token}}`}</TableCell>
                <TableCell sx={{ fontFamily: 'monospace' }}>{t.message_field}</TableCell>
                <TableCell padding="checkbox">
                  <Checkbox size="small" checked={!!t.is_active} inputProps={{ 'aria-label': `In use: ${t.token}` }}
                            onChange={e => act(() => api.putFeedMessageToken({ ...t, is_active: e.target.checked }), `{${t.token}}: saved`)} />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <Stack direction="row" spacing={1} sx={{ mt: 1 }}>
          <TextField size="small" label="Token" value={newToken.token} sx={{ width: 140 }}
                     onChange={e => setNewToken({ ...newToken, token: e.target.value.replace(/[^A-Za-z0-9_]/g, '') })} />
          <TextField size="small" label="Message field" value={newToken.message_field} sx={{ width: 200 }}
                     onChange={e => setNewToken({ ...newToken, message_field: e.target.value })} />
          <Button variant="contained" size="small" disabled={!newToken.token || !newToken.message_field.trim()}
                  onClick={() => act(() => api.putFeedMessageToken({ token: newToken.token, message_field: newToken.message_field.trim() }),
                    'Token added').then(() => setNewToken({ token: '', message_field: '' }))}>
            Add token
          </Button>
        </Stack>
      </Section>
    </Box>
  );
}

function EnvRow({ env, onSave }: { env: any; onSave: (b: any) => void }) {
  const [e, setE] = useState({ ...env, suffixes: (env.dependency_suffixes || []).join(', '),
                               values: (env.message_values || []).join(', ') });
  const split = (v: string) => v.split(',').map(x => x.trim()).filter(Boolean);
  return (
    <TableRow data-testid="environment" data-side={env.side}>
      <TableCell>{env.side === 'primary' ? 'First side' : 'Second side'}</TableCell>
      <TableCell><TextField size="small" value={e.label} sx={{ width: 110 }} inputProps={{ 'aria-label': `Label of ${env.side}` }}
                            onChange={x => setE({ ...e, label: x.target.value })} /></TableCell>
      <TableCell><TextField size="small" value={e.suffixes} sx={{ width: 170 }} inputProps={{ 'aria-label': `Endings of ${env.side}` }}
                            onChange={x => setE({ ...e, suffixes: x.target.value })} /></TableCell>
      <TableCell><TextField size="small" value={e.message_field || ''} sx={{ width: 160 }} inputProps={{ 'aria-label': `Message field of ${env.side}` }}
                            onChange={x => setE({ ...e, message_field: x.target.value })} /></TableCell>
      <TableCell><TextField size="small" value={e.values} sx={{ width: 150 }} inputProps={{ 'aria-label': `Values of ${env.side}` }}
                            onChange={x => setE({ ...e, values: x.target.value })} /></TableCell>
      <TableCell>
        <Button size="small" startIcon={<SaveIcon />} aria-label={`Save ${env.side}`}
                onClick={() => onSave({ side: env.side, label: e.label, dependency_suffixes: split(e.suffixes),
                                        message_field: e.message_field || null, message_values: split(e.values),
                                        sort_order: env.sort_order ?? 0, is_active: env.is_active !== false })}>
          Save
        </Button>
      </TableCell>
    </TableRow>
  );
}
