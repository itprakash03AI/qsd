/**
 * Feed Run Status -- the Board (2026-10-12, owner R1).  The day's feed runs
 * GROUPED (by Feed group by default; Template / Status / None on the same
 * "Group by" the List view has), each run opening into what an operator
 * needs, in plain words:
 *
 *   tiles     Completed / In progress / Failed / Waiting / Queued / All /
 *             SLA breached / SLA at risk / Held -- a tile filters the list
 *   group     its name, "N feeds", how many are done / failed / waiting
 *   run       tick it (the page's Feed Control popup acts on the selection),
 *             status, step progress ("1 step failed (5 of 7 done)"), start ->
 *             end, SLA, HELD, run log, re-run
 *   opened    1. Dependencies: one tile per upstream (DependencyTiles)
 *             2. This run: run id, duration, records, lane, delivered to, SLA
 *             3. Steps: a timeline in plain words (utils/feedStepWords.ts) --
 *                what each step did, how long, how many rows, why it failed
 *
 * LIVE: feed events refresh it; "What changed" says what CHANGED between two
 * answers (SLA breached / met, dependencies arrived, done, failed, held).
 * Every verdict is the server's (GET /api/feed-dashboard, /task, /steps).
 */
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { createPortal } from 'react-dom';
import { alpha } from '@mui/material/styles';
import {
  Alert, Badge, Box, Button, Checkbox, Chip, CircularProgress, Collapse, Dialog, DialogActions,
  DialogContent, IconButton, LinearProgress, MenuItem, Paper, Popover, Stack, Table, TableBody, TableCell,
  TableHead, TableRow, TextField, ToggleButton, ToggleButtonGroup, Tooltip, Typography,
} from '@mui/material';
import {
  Refresh as RefreshIcon, ExpandMore, ChevronRight, Article as LogsIcon, Replay as RerunIcon,
  WarningAmber as WarnIcon, Close as CloseIcon, NotificationsActive as BellIcon, CheckCircle as DoneIcon, Cancel as FailIcon,
  RadioButtonUnchecked as TodoIcon, HourglassTop as RunningIcon, RemoveCircleOutline as SkippedIcon,
  Block as RefusedIcon, Autorenew as LiveRunIcon, Schedule as QueuedIcon, PauseCircle as HeldIcon,
  SkipNext as SkipIcon, ErrorOutline as ErrIcon, MarkEmailRead as MailIcon, Campaign as NetcoolIcon,
  History as HistoryIcon, Tune as ConfigIcon,
} from '@mui/icons-material';
import api from '../../services/api';
import { useWebSocket } from '../../context/WebSocketContext';
import FeedRunSkipDepsDialog, { type SkipRunTarget } from '../FeedRunSkipDepsDialog';
import FeedLiveLogDialog from '../FeedLiveLogDialog';
import FeedVarianceHoldsPage from '../FeedVarianceHoldsPage';
import DependencyTiles, { TONE_HEX, depBadge } from './DependencyTiles';
import { plainDuration } from '../../utils/feedStepWords';
import { ProcessFlow, MiniFlow, type RunSides, type SideRerun } from './ProcessFlow';
import { envLabel, setEnvironments, type Env } from './environments';
import FeedConfigSummaryDialog from './FeedConfigSummaryDialog';
import ListPager, { clientPage } from '../common/ListPager';
import RunProgressBar, { type RunProgress } from './RunProgressBar';

export { depBadge } from './DependencyTiles';

/** The page header's slot the board puts its status pills in (FeedTodayPage). */
export const BOARD_HEADER_SLOT = 'feed-run-board-header-slot';

export type TaskStatus = 'completed' | 'held' | 'in_progress' | 'failed' | 'not_started' | 'queued' | 'skipped';

export interface BoardTask {
  feed_id: number;
  feed_name: string | null;
  run_id: number;
  group_id: number | null;
  status: TaskStatus;
  run_status?: string | null;
  action_reason: string | null;
  started_at: string | null;
  completed_at: string | null;
  duration_seconds: number | null;
  total_rows: number | null;
  output_path?: string | null;
  /** the task's own business date (the run-date view mixes dates) */
  business_date?: string;
  run_date?: string | null;
  /** the business calendar the feed is on and where that comes from */
  calendar?: { name: string | null; from: 'feed' | 'schedule' | 'default' | null } | null;
  /** what the business date IS for this feed ("Month end", "Business day") */
  date_rule?: { rule: string | null; label: string } | null;
  steps?: { total: number; completed: number; failed: number; running: number; not_started: number; skipped: number };
  /** the gate's verdict per dependency (the page's tasks only) */
  deps?: { name: string; side: string | null; verdict: string; satisfies: boolean;
           action?: string | null; reason?: string | null }[];
  deps_unavailable?: string | null;
  /** per side, from the run's own execution (rows read / reported, failed side) */
  sides?: RunSides | null;
  /** a failed run that kept one side: may only the failed side re-run? */
  side_rerun?: SideRerun | null;
  /** delivered, then a NEWER upstream message arrived (a restatement) */
  superseded?: { decision_id: number | null; decision_ids?: number[]; dependency: string | null; raised_at: string | null;
                 changes: { side: string; environment: string | null; dependency: string;
                            was: Record<string, any>; now: Record<string, any> }[];
                 /** what the feed's restatement POLICY made of it (core/feed/restatement.py) */
                 restatement?: Restatement | null } | null;
  /** the steps in the order they happened (the row's flow is sequential) */
  step_seq?: { alias: string; state: string }[];
  /** every delivery of this business date -- one per run date */
  deliveries?: Delivery[] | null;
  /** the task's alerts and where each went (core/feed/feed_alerts.py) */
  alerts?: FeedAlert[] | null;
  /** live: the step the engine is in now (a feed_progress event), until the next answer */
  live_stage?: string | null;
  /** WHERE a running task is -- from the board answer and, live, from feed_progress (2026-10-14) */
  progress?: RunProgress | null;
  sla: { verdict: string; sla_to: string | null; sla_timezone: string | null; deadline_utc: string | null;
         minutes_vs_deadline: number | null; alerted: boolean };
  variance_hold: { id: number; status: string; actual_rows: number | null; baseline_rows: number | null;
                   baseline_business_date: string | null; delta_pct: number | null; direction: string | null } | null;
  /** 2026-10-17 -- may THIS caller act (re-run / skip / decide)?  The server's
   *  verdict (the same gate every action route applies); absent = an older
   *  server = allowed, the server still refuses. */
  can_act?: boolean;
}

export interface Restatement {
  action: 'rerun' | 'hold' | 'closed' | 'decide'; why: string; title: string;
  policy_name?: string | null; run_date: string; delivered_run_date?: string | null;
  window?: string | null; window_closes?: string | null;
}
export interface Delivery {
  execution_id: string; run_date: string | null; completed_at: string | null; rows: number | null;
  /** something reached a destination (a held / suppressed file completed UNDELIVERED) */
  delivered?: boolean;
  file: string | null; destination?: string | null; definition_version_id?: number | null;
  trigger?: string | null; triggered_by?: string | null;
  /** the upstream version each environment's side read for this delivery */
  versions?: { environment: string; version: string | null }[];
  /** why it happened, in words ("First delivery", "New upstream version ...") */
  why?: string | null;
}
export interface AlertDelivery { channel: 'bell' | 'email' | 'netcool'; status: string; to?: string[];
                                 reason?: string | null; identifier?: string | null; at?: string }
export interface FeedAlert {
  id: number; kind: string; title: string; message: string | null; severity: number; status: string;
  raised_at: string | null; cleared_at: string | null; cleared_by: string | null; run_date?: string | null;
  deliveries: AlertDelivery[];
}

/** A task's status as an icon + colour (the row reads at a glance; running turns). */
export const STATUS_ICON: Record<string, { Icon: any; hex: string; spin?: boolean }> = {
  completed: { Icon: DoneIcon, hex: '#2e7d32' }, in_progress: { Icon: LiveRunIcon, hex: '#1565c0', spin: true },
  failed: { Icon: FailIcon, hex: '#c62828' }, not_started: { Icon: RunningIcon, hex: '#546e7a' },
  queued: { Icon: QueuedIcon, hex: '#6a1b9a' }, held: { Icon: HeldIcon, hex: '#ef6c00' },
  skipped: { Icon: SkipIcon, hex: '#78909c' },
};

/** The row's SLA emphasis: breached / late red, at risk amber, else none.  Pure. */
export function slaEmphasis(sla?: BoardTask['sla']): 'breached' | 'at_risk' | null {
  if (!sla) return null;
  if (sla.verdict === 'breached' || sla.verdict === 'late') return 'breached';
  if (sla.verdict === 'at_risk') return 'at_risk';
  return null;
}

/** Apply one live feed event to the board in place (no round trip).  Pure:
 *  returns the new board, or the same object when nothing on it changed. */
/** percent from a live report's counters (the server's view computes the same) */
function pct(p: RunProgress): number | null {
  return p.tasks_total && p.tasks_done != null ? Math.round(1000 * p.tasks_done / p.tasks_total) / 10 : null;
}

export function applyLiveEvent(board: Board | null, m: any): Board | null {
  if (!board || !m) return board;
  const t = String(m.type || '');
  if (t !== 'feed_progress') return board;
  const fid = Number(m.feed_id), rid = m.feed_run_id != null ? Number(m.feed_run_id) : null;
  let changed = false;
  const groups = board.groups.map(g => {
    let gChanged = false;
    const tasks = g.tasks.map(x => {
      if (x.feed_id !== fid || (rid != null && x.run_id !== rid)) return x;
      gChanged = true; changed = true;
      return { ...x, status: 'in_progress' as TaskStatus, run_status: 'running', live_stage: String(m.stage || ''),
               // a detached run's report carries the counters; a native stage event keeps the last ones
               progress: m.progress ? { ...m.progress, seconds_since_report: 0, stale: false,
                                        percent: pct(m.progress), eta_seconds: x.progress?.eta_seconds ?? null }
                                    : x.progress };
    });
    return gChanged ? { ...g, tasks } : g;
  });
  return changed ? { ...board, groups } : board;
}

export interface BoardGroup {
  key?: string;
  id: number | null;
  name: string;
  display_label: string;
  counts: Record<string, number>;
  tasks: BoardTask[];
}

export interface Board {
  /** the configured environments (side -> label) */
  environments?: Env[];
  business_date: string | null;
  /** 2026-10-13 -- the run-date view: what was worked on that day */
  run_date?: string | null;
  date_kind?: 'business_date' | 'run_date';
  /** run-date view: the business dates the feeds are on, by rule */
  date_summary?: { label: string; business_date: string; feeds: number }[] | null;
  kpis: Record<string, number>;
  groups: BoardGroup[];
  total_tasks: number;
  page: number;
  pages: number;
  page_size: number;
  first: number;
  last: number;
  /** 2026-10-17 -- feeds DUE on the date with NO task (unknown is not empty) */
  missing_count?: number | null;
  missing?: { feed_id: number; feed_name: string | null; business_date: string | null; reason: string | null }[];
  missing_unavailable?: string | null;
  /** is start of day creating tasks on this deployment at all? */
  sod?: { enabled: boolean | null; catchup_days?: number; reason?: string } | null;
}

/** The deliveries that DELIVERED (an older server says nothing: counted). Pure. */
export function deliveredOf(d?: Delivery[] | null): Delivery[] {
  return (d || []).filter(x => x.delivered !== false);
}

/** A task's action gate: absent = allowed (an older server). Pure. */
export function mayAct(t: Pick<BoardTask, 'can_act'>): boolean {
  return t.can_act !== false;
}
export const VIEW_ONLY = 'View-only: the feed\'s owner, a read-write member of its group or an admin can act on this run';

/** "2026-09-30" -> "30 Sep 2026" (the date as written, no time zone shift) */
export function dayText(iso?: string | null): string {
  if (!iso) return '';
  const [y, m, d] = iso.slice(0, 10).split('-').map(Number);
  if (!y || !m || !d) return iso;
  // fixed month names: a browser's locale writes "Sept" or "Sep"
  return `${d} ${['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][m - 1]} ${y}`;
}

export const STATUS_LABEL: Record<string, string> = {
  completed: 'Completed', held: 'Held', in_progress: 'In progress', failed: 'Failed',
  not_started: 'Waiting', queued: 'Queued', skipped: 'Skipped', all: 'All',
  sla_breached: 'SLA breached', sla_at_risk: 'SLA at risk',
};
const STATUS_HELP: Record<string, string> = {
  not_started: 'Waiting on its dependencies (an upstream message, file or commit)',
  queued: 'Ready to run — waiting for a worker',
  held: 'Built but held for verification (row count moved beyond the threshold)',
};
const STATUS_COLOR: Record<string, 'success' | 'info' | 'error' | 'default' | 'warning' | 'secondary'> = {
  completed: 'success', in_progress: 'info', failed: 'error', not_started: 'default',
  queued: 'secondary', held: 'warning', skipped: 'default',
};
const TILE_HEX: Record<string, string> = {
  completed: '#2e7d32', in_progress: '#1565c0', failed: '#c62828', not_started: '#546e7a',
  queued: '#6a1b9a', all: '#37474f', sla_breached: '#b71c1c', sla_at_risk: '#e65100', held: '#ef6c00',
};
const TILES = ['completed', 'in_progress', 'failed', 'not_started', 'queued', 'all',
               'sla_breached', 'sla_at_risk', 'held'];
const GROUP_BY: { value: string; label: string }[] = [
  { value: 'feed_group', label: 'Feed group' }, { value: 'template', label: 'Template' },
  { value: 'status', label: 'Status' }, { value: 'none', label: 'No grouping' },
];

/** The step-state counts in words (tooltip): one per non-zero state. */
export function stepChips(s?: BoardTask['steps']): { label: string; color: 'success' | 'info' | 'error' | 'default' | 'warning' }[] {
  if (!s || !s.total) return [];
  const pct = (n: number) => `${n}/${s.total} (${Math.round((n * 100) / s.total)}%)`;
  const out: { label: string; color: 'success' | 'info' | 'error' | 'default' | 'warning' }[] = [];
  if (s.completed) out.push({ label: `Completed: ${pct(s.completed)}`, color: 'success' });
  if (s.running) out.push({ label: `In Progress: ${pct(s.running)}`, color: 'info' });
  if (s.failed) out.push({ label: `Failed: ${pct(s.failed)}`, color: 'error' });
  if (s.not_started) out.push({ label: `Not Started: ${pct(s.not_started)}`, color: 'default' });
  if (s.skipped) out.push({ label: `Skipped: ${pct(s.skipped)}`, color: 'warning' });
  return out;
}

/** "7 of 7 steps done" / "1 step failed (5 of 7 done)" / "5 of 7 steps done
 *  (2 skipped)" -- the row's progress.  ONE rule with the dots (2026-10-18):
 *  a skipped step is never "done" -- it is drawn grey and counted apart, with
 *  its reason on the step (not applicable on this lane, or not reached). */
export function stepsSummary(s?: BoardTask['steps']): string {
  if (!s || !s.total) return 'no steps recorded yet';
  const skipped = s.skipped ? ` (${s.skipped} skipped)` : '';
  if (s.failed) return `${s.failed} step${s.failed > 1 ? 's' : ''} failed (${s.completed} of ${s.total} done${skipped})`;
  if (s.running) return `running — ${s.completed} of ${s.total} steps done${skipped}`;
  return `${s.completed} of ${s.total} steps done${skipped}`;
}

/** Minutes in words a person reads at a glance: "45 m", "3 h 5 m", "12 d 9 h"
 *  (a month end worked in October is 17,834 minutes late -- nobody reads that). */
export function slaDuration(m: number | null | undefined): string {
  if (m == null) return '?';
  const a = Math.abs(m);
  if (a < 120) return `${a} m`;
  if (a < 2880) return `${Math.floor(a / 60)} h ${a % 60} m`;
  return `${Math.floor(a / 1440)} d ${Math.floor((a % 1440) / 60)} h`;
}

/** The SLA chip: the server's verdict in words, null when there is no SLA. */
export function slaChip(sla: BoardTask['sla'] | undefined):
    { label: string; color: 'success' | 'warning' | 'error' | 'default' } | null {
  if (!sla) return null;
  const m = sla.minutes_vs_deadline;
  switch (sla.verdict) {
    case 'met': return { label: 'SLA met', color: 'success' };
    case 'late': return { label: `SLA late ${slaDuration(m)}`, color: 'error' };
    case 'breached': return { label: `SLA breached${m != null ? ` +${slaDuration(m)}` : ''}`, color: 'error' };
    case 'at_risk': return { label: `SLA at risk ${m != null ? slaDuration(-m) : '?'} left`, color: 'warning' };
    case 'on_track': return { label: 'SLA on track', color: 'default' };
    case 'invalid_sla': return { label: 'SLA unreadable', color: 'error' };
    default: return null;
  }
}

/** What CHANGED between two answers -- the alert strip's lines.  Pure. */
export function boardTransitions(prev: Board | null, next: Board): { key: string; text: string; severity: 'error' | 'warning' | 'success' | 'info' }[] {
  if (!prev) return [];
  const before = new Map<number, BoardTask>();
  prev.groups.forEach(g => g.tasks.forEach(t => before.set(t.run_id, t)));
  const out: { key: string; text: string; severity: 'error' | 'warning' | 'success' | 'info' }[] = [];
  next.groups.forEach(g => g.tasks.forEach(t => {
    const b = before.get(t.run_id);
    if (!b) return;
    const n = t.feed_name;
    if (b.sla?.verdict !== t.sla?.verdict) {
      if (t.sla.verdict === 'breached') out.push({ key: `sla-b-${t.run_id}`, severity: 'error', text: `SLA BREACHED: ${n} (deadline ${t.sla.sla_to})` });
      if (t.sla.verdict === 'met') out.push({ key: `sla-m-${t.run_id}`, severity: 'success', text: `SLA met: ${n} delivered before ${t.sla.sla_to}` });
      if (t.sla.verdict === 'late') out.push({ key: `sla-l-${t.run_id}`, severity: 'warning', text: `Delivered LATE: ${n} (${slaDuration(t.sla.minutes_vs_deadline)} after ${t.sla.sla_to})` });
      if (t.sla.verdict === 'at_risk') out.push({ key: `sla-r-${t.run_id}`, severity: 'warning', text: `SLA at risk: ${n} (${t.sla.sla_to})` });
    }
    if (b.status !== t.status) {
      if (b.status === 'not_started' && ['queued', 'in_progress', 'completed'].includes(t.status)) {
        out.push({ key: `dep-${t.run_id}`, severity: 'info', text: `Dependencies met: ${n} released` });
      }
      if (t.status === 'completed') out.push({ key: `ok-${t.run_id}`, severity: 'success', text: `Completed: ${n}` });
      if (t.status === 'failed') out.push({ key: `ko-${t.run_id}`, severity: 'error', text: `Failed: ${n}` });
      if (t.status === 'held') out.push({ key: `hold-${t.run_id}`, severity: 'warning', text: `HELD for verification: ${n}` });
    }
  }));
  return out;
}

function hms(iso: string | null | undefined): string {
  return iso ? String(iso).replace('T', ' ').slice(11, 19) : '';
}

function useWebSocketIfAny() {
  try { return useWebSocket(); } catch { return null; }
}


/** "7 rows · cloud 3 · on-prem 4", and which side failed -- the run's record. */
export function rowCountWords(sides: RunSides | null | undefined, total: number | null | undefined): string {
  const f = (v: number | null | undefined) => (v == null ? '?' : Number(v).toLocaleString());
  if (!sides) return total ? `${f(total)} rows` : '';
  const tot = sides.status === 'completed' ? (sides.total ?? total) : null;
  if (!sides.combined) return tot != null ? `${f(tot)} rows` : '';
  const parts = [`cloud ${f(sides.primary.rows)}`, `on-prem ${f(sides.secondary.rows)}`];
  return tot != null ? `${f(tot)} rows · ${parts.join(' · ')}` : parts.join(' · ');
}
/** a side's configured label (feeds/environments.ts) */
export const sideWord = (side?: string | null) => envLabel(side);

function RowCounts({ sides, total, superseded }: { sides?: RunSides | null; total: number | null;
                                                     superseded?: BoardTask['superseded'] }) {
  const words = rowCountWords(sides, total);
  return (
    <>
      {words && (
        <Tooltip title={sides?.combined
          ? `Cloud read ${sides.primary.rows ?? '?'}${sides.primary.reported != null ? ` (upstream reported ${sides.primary.reported})` : ''}; `
            + `on-prem read ${sides.secondary.rows ?? '?'}${sides.secondary.reported != null ? ` (upstream reported ${sides.secondary.reported})` : ''}`
          : 'Rows delivered'}>
          <Typography variant="caption" sx={{ fontWeight: 600 }} data-testid="board-row-counts">{words}</Typography>
        </Tooltip>
      )}
      {superseded && (
        <Tooltip title={superseded.changes.map(c => `${c.environment || c.side}: read ${c.was.version ?? c.was.identity}, now ${c.now.version ?? c.now.identity}`).join('; ')
                        || 'a newer upstream message arrived after delivery'}>
          <Chip size="small" color="warning" sx={{ height: 18, fontSize: 10.5 }} data-testid="board-superseded"
                label={`Superseded${superseded.changes[0]?.now?.version ? `: new ${superseded.changes[0].environment || ''} version ${superseded.changes[0].now.version}` : ''}`} />
        </Tooltip>
      )}
      {sides?.failed_side && (
        <Chip size="small" color="error" variant="outlined" sx={{ height: 18, fontSize: 10.5 }}
              data-testid="board-failed-side" label={`Failed on ${sideWord(sides.failed_side)}`} />
      )}
    </>
  );
}

// ── a row's dependencies, one small tile each (the gate's verdict) ────────
function RowDeps({ task, onOpen }: { task: BoardTask; onOpen: () => void }) {
  if (task.deps_unavailable) {
    return (
      <Tooltip title={`Dependencies could not be read: ${task.deps_unavailable}`}>
        <Chip size="small" color="error" variant="outlined" label="Deps ?" data-testid="board-row-deps-unknown" />
      </Tooltip>
    );
  }
  const deps = task.deps || [];
  return (
    <Stack direction="row" spacing={0.5} sx={{ minWidth: 190, justifyContent: 'flex-end' }} data-testid="board-row-deps">
      {deps.length === 0 && (
        <Typography variant="caption" color="text.disabled">waits for nothing</Typography>
      )}
      {deps.map(d => {
        const b = depBadge(d);
        const hex = TONE_HEX[b.color];
        return (
          <Tooltip key={d.name} title={<>
            <b>{d.name}</b><br />{b.label}{d.reason ? ` — ${d.reason}` : ''}<br />Click to see the messages
          </>}>
            <Box role="button" tabIndex={0} aria-label={`Dependency ${d.name}: ${b.label}`}
                 data-testid="board-row-dep" data-verdict={d.verdict}
                 onClick={onOpen} onKeyDown={e => { if (e.key === 'Enter') onOpen(); }}
                 sx={{ cursor: 'pointer', px: 0.75, py: 0.1, borderRadius: 1, borderLeft: 3, borderLeftColor: hex,
                       bgcolor: (th) => alpha(hex, th.palette.mode === 'dark' ? 0.22 : 0.1), lineHeight: 1.1 }}>
              <Typography component="div" sx={{ fontSize: 9.5, fontWeight: 700, color: 'text.secondary' }}>
                {d.side || 'DEPENDENCY'}
              </Typography>
              <Typography component="div" sx={{ fontSize: 11, fontWeight: 700, color: hex, whiteSpace: 'nowrap' }}>
                {b.label}
              </Typography>
            </Box>
          </Tooltip>
        );
      })}
    </Stack>
  );
}

// ── every delivery of the business date (one per run date) ──────────────
// 2026-10-13 (the owner: "for business date 30 Sep, if I have 10 run dates,
// how will you show it ... for the same system entity") -- ONE task, and its
// deliveries as a table: newest first, each run date with its rows, the
// version each environment read, the file and WHY; the run date being viewed
// is marked; paged.
function Deliveries({ task, viewedRunDate }: { task: BoardTask; viewedRunDate?: string | null }) {
  const d = task.deliveries || [];
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  if (d.length === 0) return null;
  const pg = clientPage(d, page, pageSize);
  const sent = deliveredOf(d).length;
  const unsent = d.length - sent;
  return (
    <Box sx={{ mt: 1 }} data-testid="board-deliveries">
      <Typography variant="caption" sx={{ fontWeight: 700, color: 'text.secondary' }} data-testid="board-deliveries-title">
        {sent === 0 ? 'NOT DELIVERED YET' : sent === 1 ? 'DELIVERED ONCE' : `DELIVERED ${sent} TIMES`}
        {task.business_date ? ` FOR BUSINESS DATE ${dayText(task.business_date).toUpperCase()}` : ''}
        {unsent > 0 ? ` (${unsent} run${unsent === 1 ? '' : 's'} completed without delivering)` : ''}
      </Typography>
      <Table size="small" sx={{ '& td, & th': { py: 0.25, px: 1 } }}>
        <TableHead>
          <TableRow>
            <TableCell>Run date</TableCell>
            <TableCell align="right">Rows</TableCell>
            <TableCell>Versions read</TableCell>
            <TableCell>File</TableCell>
            <TableCell>Why</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {pg.rows.map((x, i) => {
            const latest = page === 1 && i === 0;
            const viewed = !!viewedRunDate && x.run_date === viewedRunDate;
            return (
              <TableRow key={x.execution_id} data-testid="board-delivery" data-viewed={viewed || undefined}
                        selected={viewed}>
                <TableCell sx={{ whiteSpace: 'nowrap', fontWeight: 600 }}>
                  {x.run_date ? dayText(x.run_date) : '?'}
                  {latest && d.length > 1 && <Chip size="small" label="latest" sx={{ ml: 0.75, height: 18, fontSize: 10.5 }} />}
                </TableCell>
                <TableCell align="right">{x.rows != null ? x.rows.toLocaleString() : '—'}</TableCell>
                <TableCell sx={{ whiteSpace: 'nowrap' }}>
                  {(x.versions || []).filter(v => v.version).map(v => `${v.environment} ${v.version}`).join(' · ') || '—'}
                </TableCell>
                <TableCell sx={{ fontFamily: 'monospace', fontSize: 12, maxWidth: 360, overflow: 'hidden',
                                 textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} title={x.destination || ''}>
                  {x.file ?? '—'}
                </TableCell>
                <TableCell sx={{ fontSize: 12 }}>
                  {x.delivered === false && <Chip size="small" color="warning" variant="outlined" label="not delivered"
                                                  sx={{ mr: 0.5, height: 18, fontSize: 10.5 }} data-testid="board-delivery-undelivered" />}
                  {x.why || x.trigger || '—'}
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
      {d.length > 10 && (
        <ListPager paging={pg.paging} onPage={setPage} onPageSize={setPageSize} testid="board-deliveries-pager" />
      )}
    </Box>
  );
}

const CHANNEL_ICON: Record<string, any> = { bell: BellIcon, email: MailIcon, netcool: NetcoolIcon };
const DELIVERY_HEX: Record<string, string> = { sent: '#2e7d32', queued: '#2e7d32', pending: '#1565c0',
                                               failed: '#c62828', refused: '#c62828', not_routed: '#ef6c00' };

// ── the task's alerts and WHERE each went (bell / e-mail / Netcool) ──────
function TaskAlerts({ task }: { task: BoardTask }) {
  const a = task.alerts || [];
  if (a.length === 0) return null;
  return (
    <Box sx={{ mt: 1 }} data-testid="board-task-alert-list">
      <Typography variant="caption" sx={{ fontWeight: 700, color: 'text.secondary' }}>ALERTS</Typography>
      {a.map(x => (
        <Stack key={x.id} direction="row" spacing={1} alignItems="center" data-testid="board-task-alert"
               data-kind={x.kind} data-status={x.status}
               sx={{ py: 0.4, borderBottom: 1, borderColor: 'divider', opacity: x.status === 'open' ? 1 : 0.6 }}>
          <ErrIcon fontSize="small" sx={{ color: x.status !== 'open' ? 'text.disabled' : x.severity >= 4 ? '#c62828' : '#ef6c00' }} />
          <Box sx={{ flexGrow: 1, minWidth: 0 }}>
            <Typography variant="body2" sx={{ fontWeight: 600 }}>{x.title}</Typography>
            <Typography variant="caption" color="text.secondary" component="div">
              {x.message}{' — '}raised {String(x.raised_at || '').replace('T', ' ').slice(0, 19)}
              {x.status !== 'open' ? `, cleared ${String(x.cleared_at || '').replace('T', ' ').slice(0, 19)} by ${x.cleared_by}` : ''}
            </Typography>
          </Box>
          {x.deliveries.map(d => {
            const Icon = CHANNEL_ICON[d.channel] || BellIcon;
            const hex = DELIVERY_HEX[d.status] || '#78909c';
            return (
              <Tooltip key={d.channel} title={`${d.channel}: ${d.status}${d.to?.length ? ` -> ${d.to.join(', ')}` : ''}`
                                               + `${d.identifier ? ` (${d.identifier})` : ''}${d.reason ? ` — ${d.reason}` : ''}`}>
                <Chip size="small" variant="outlined" data-testid={`board-alert-${d.channel}`} data-status={d.status}
                      icon={<Icon sx={{ color: `${hex} !important` }} />}
                      label={`${d.channel === 'netcool' ? 'Netcool' : d.channel === 'email' ? 'E-mail' : 'Bell'} ${d.status.replace('_', ' ')}`}
                      sx={{ height: 22, fontSize: 11, borderColor: hex, color: hex }} />
              </Tooltip>
            );
          })}
        </Stack>
      ))}
    </Box>
  );
}

// ── one opened run: dependencies, the run's facts, the steps ─────────────
function RunDetail({ task, businessDate, onSkip, onChanged, viewedRunDate }: {
  task: BoardTask; businessDate: string; onSkip: (dep: string) => void; onChanged: () => void;
  /** the run date the board is looking at (run-date view), marked in the deliveries */
  viewedRunDate?: string | null;
}) {
  const [steps, setSteps] = useState<any>(null);
  const [stepError, setStepError] = useState<string | null>(null);
  const [verdicts, setVerdicts] = useState<Record<string, { allowed: boolean; reason: string }>>({});
  const [deps, setDeps] = useState<{ met: number; total: number } | null>(null);
  const [stepMsg, setStepMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const load = useCallback(() => {
    api.getFeedRunSteps(task.run_id)
      .then((r: any) => setSteps(r))
      .catch((e: any) => setStepError(e?.message || 'Could not read the steps'));
    api.feedSteps.getRerunVerdicts(task.run_id)
      .then((r: any) => setVerdicts(Object.fromEntries((r.verdicts || []).map((v: any) => [v.alias, v]))))
      .catch(() => setVerdicts({}));
  }, [task.run_id]);
  useEffect(() => { load(); }, [load, task.status]);

  // a superseded delivery: the PERSON decides, with a reason; Regenerate then
  // re-queues the run, which reads the new version (its upstream contract)
  const decideRegeneration = async (action: 'rerun' | 'keep') => {
    const ids = task.superseded?.decision_ids?.length ? task.superseded.decision_ids
      : (task.superseded?.decision_id ? [task.superseded.decision_id] : []);
    if (!ids.length) return;
    const reason = window.prompt(action === 'rerun'
      ? 'Why re-run? (kept on record; at least two words)' : 'Why does the delivered file stand? (recorded)');
    if (!reason || !reason.trim()) return;
    setStepMsg(null);
    try {
      // ONE server action (who may, the reason, the re-queue, the alert
      // cleared).  A re-run answers the newest decision -- the delivery of the
      // current data closes the others; Keep answers every one.
      if (action === 'rerun') await api.answerDecision(ids[ids.length - 1], 'rerun', reason.trim());
      else for (const id of ids) await api.answerDecision(id, 'keep', reason.trim());
      setStepMsg({ ok: true, text: action === 'rerun'
        ? `${task.feed_name}: re-run queued — the new upstream version is read and delivered`
        : `${task.feed_name}: kept as delivered (recorded)` });
      onChanged();
    } catch (e: any) {
      setStepMsg({ ok: false, text: e?.message || 'The decision was refused' });
    }
  };
  const rerunSide = async () => {
    const r = task.side_rerun;
    const word = envLabel(r?.rerun_side);
    if (!window.confirm(`Re-run only the ${word} side of ${task.feed_name}? The other side's `
                        + `${r?.kept_rows ?? '?'} rows are reused.`)) return;
    setStepMsg(null);
    try {
      await api.rerunFailedSide(task.run_id);
      setStepMsg({ ok: true, text: `${task.feed_name}: the ${word} side re-run is queued — the other side's rows are reused` });
      onChanged();
    } catch (e: any) {
      setStepMsg({ ok: false, text: e?.message || 'The re-run was refused' });
    }
  };
  const rerunStep = async (alias: string, label: string) => {
    setStepMsg(null);
    try {
      const r: any = await api.feedSteps.rerunStep(task.run_id, alias);
      setStepMsg({ ok: true, text: `"${label}" re-ran (attempt ${r?.attempt ?? '?'})${r?.result?.status ? `: ${r.result.status}` : ''}` });
      load(); onChanged();
    } catch (e: any) {
      setStepMsg({ ok: false, text: e?.message || String(e) });
    }
  };

  const ex = steps?.execution;
  const sla = slaChip(task.sla);
  // 2026-10-17 -- a person who may only VIEW this feed gets no action here:
  // the server's verdict, not a guess (it used to offer every button and
  // refuse afterwards)
  const canAct = mayAct(task);
  // the run's facts as ONE compact row (the reference's "Run ID | Duration |
  // Records | ... | Dependencies"), then the dependency tiles, then the flow
  const fact = (k: string, v: React.ReactNode, title?: string, testid?: string) => (
    <Tooltip title={title || ''}>
      <Box data-testid={testid} sx={{ px: 1, py: 0.25, borderRadius: 1, bgcolor: 'action.hover', whiteSpace: 'nowrap',
                                      maxWidth: 320, overflow: 'hidden', textOverflow: 'ellipsis' }}>
        <Typography component="span" variant="body2" sx={{ fontWeight: 700 }}>{v}</Typography>
        <Typography component="span" variant="caption" color="text.secondary" sx={{ ml: 0.5 }}>{k}</Typography>
      </Box>
    </Tooltip>
  );
  return (
    <Box sx={{ px: 2, pb: 1.5, pt: 0.5 }} data-testid="board-task-body">
      <Stack direction="row" useFlexGap sx={{ flexWrap: 'wrap', gap: 0.75, mb: 1 }} data-testid="board-run-tiles">
        {fact('Run ID', `${task.run_id}`)}
        {fact('Duration', plainDuration(task.duration_seconds) || '-')}
        {fact('Records', task.total_rows != null ? task.total_rows.toLocaleString() : '-')}
        {fact('Ran on', ex?.execution_backend || '-')}
        {fact('Delivered', ex?.destination_path ? String(ex.destination_path).split('/').pop() : 'not yet',
              ex?.destination_path || undefined)}
        {fact('Dependencies', deps ? `${deps.met} of ${deps.total}` : (task.deps ? `${task.deps.filter(d => d.satisfies).length} of ${task.deps.length}` : '-'))}
        <Box data-testid="board-sla-tile" sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
          {fact('SLA', task.sla?.verdict === 'not_due' ? 'nothing due (skipped)'
                       : task.sla?.sla_to ? `by ${task.sla.sla_to} ${task.sla.sla_timezone || 'UTC'}` : 'none declared')}
          {sla && <Chip size="small" label={sla.label} color={sla.color} />}
          {task.sla?.alerted && <Typography variant="caption" color="error">alert raised</Typography>}
        </Box>
      </Stack>

      {!canAct && (
        <Typography variant="caption" color="text.secondary" component="div" sx={{ mb: 0.5 }} data-testid="board-view-only">
          {VIEW_ONLY}
        </Typography>
      )}
      <DependencyTiles feedId={task.feed_id} businessDate={businessDate} onSkip={canAct ? onSkip : undefined}
                       onCount={(met, total) => setDeps({ met, total })}
                       read={task.sides?.combined
                         ? { [envLabel('primary')]: task.sides.primary, [envLabel('secondary')]: task.sides.secondary }
                         : undefined} />

      {task.superseded && (() => {
        const rs = task.superseded.restatement;
        const auto = rs?.action === 'rerun';
        return (
        <Alert severity={rs?.action === 'hold' ? 'error' : 'warning'} sx={{ mt: 1 }} data-testid="board-superseded-banner"
               data-action={rs?.action || 'decide'}
               action={task.superseded.decision_id && !auto && canAct ? (
                 <Stack direction="row" spacing={1}>
                   <Button size="small" color="warning" variant="contained" data-testid="board-regenerate"
                           onClick={() => decideRegeneration('rerun')}>Re-run</Button>
                   <Button size="small" color="inherit" data-testid="board-keep-delivered"
                           onClick={() => decideRegeneration('keep')}>Keep as delivered</Button>
                 </Stack>) : undefined}>
          {rs && <Typography variant="body2" sx={{ fontWeight: 700 }} data-testid="board-restatement-title">
            {rs.title}</Typography>}
          {rs && <Typography variant="caption" component="div" data-testid="board-restatement-why">
            {rs.why}{rs.window_closes ? ` — re-sends accepted until ${rs.window_closes}` : ''}
            {rs.action === 'hold' ? ' — RTB alerted; an approver decides.' : ''}
            {auto ? ' — re-running by itself, as the re-send policy says.' : ''}</Typography>}
          Delivered, then the upstream sent a NEWER version:{' '}
          {task.superseded.changes.length
            ? task.superseded.changes.map(c => `${c.environment || c.side} read ${c.was.version ?? c.was.identity}, now ${c.now.version ?? c.now.identity}`
                                                + (c.now.expected_rows != null ? ` (${Number(c.now.expected_rows).toLocaleString()} rows expected)` : '')).join('; ')
            : (task.superseded.dependency || 'a dependency')}.
          {!auto && <>{' '}Re-run reads the new version and delivers again (a new file for today's run date);
            Keep records why the delivered file stands.</>}
        </Alert>);
      })()}
      <Deliveries task={task} viewedRunDate={viewedRunDate} />
      <TaskAlerts task={task} />
      {task.variance_hold && (
        <Alert severity="warning" icon={<WarnIcon />} sx={{ mt: 1 }} data-testid="board-task-hold">
          Held for verification: {task.variance_hold.actual_rows} rows vs {task.variance_hold.baseline_rows} delivered
          on {task.variance_hold.baseline_business_date ?? '?'}
          {task.variance_hold.delta_pct != null ? ` (${task.variance_hold.direction === 'down' ? '-' : '+'}${task.variance_hold.delta_pct}%)` : ''}.
          Open Variance holds to release or reject it.
        </Alert>
      )}

      <Box sx={{ mt: 1.5 }}>
        {stepError && <Alert severity="error">{stepError}</Alert>}
        {stepMsg && <Alert severity={stepMsg.ok ? 'success' : 'error'} onClose={() => setStepMsg(null)}
                           sx={{ mb: 1 }} data-testid="board-step-msg">{stepMsg.text}</Alert>}
        {!steps && !stepError && <CircularProgress size={16} />}
        {steps && (
          <ProcessFlow steps={steps.steps || []} deps={task.deps} sides={task.sides} error={steps.error}
                       sideRerun={task.side_rerun} onRerunSide={canAct ? () => rerunSide() : undefined}
                       verdicts={verdicts} onRerun={canAct ? rerunStep : undefined} />
        )}
      </Box>
    </Box>
  );
}

// ── the board ────────────────────────────────────────────────────────────
export default function FeedRunBoard({ businessDate, onBusinessDateChange, selectedIds, onToggleSelect,
                                       refreshNonce = 0 }: {
  businessDate: string;
  onBusinessDateChange: (d: string) => void;
  /** The page's selection -- its Feed Control popup acts on it.  The run
   *  travels with the tick: the page has not loaded the board's runs. */
  selectedIds?: Set<number>;
  onToggleSelect?: (runId: number, run?: any) => void;
  /** Bumped by the page when its actions changed runs (re-read the board). */
  refreshNonce?: number;
}) {
  const ws = useWebSocketIfAny();
  const [searchParams] = useSearchParams();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [groupBy, setGroupBy] = useState('feed_group');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);
  // 2026-10-13 (the owner: "how will we find the month-end feed for another
  // run date") -- the date is a BUSINESS date (the default) or a RUN date:
  // every task worked on that day, whatever its business date
  const [dateKind, setDateKind] = useState<'business' | 'run'>(searchParams.get('run_date') ? 'run' : 'business');
  const [runDate, setRunDate] = useState<string>(searchParams.get('run_date') || new Date().toISOString().slice(0, 10));
  const [configFeed, setConfigFeed] = useState<{ id: number; name: string | null } | null>(null);
  const [board, setBoard] = useState<Board | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [closedGroups, setClosedGroups] = useState<Set<string>>(new Set());
  const [openRuns, setOpenRuns] = useState<Set<number>>(new Set());
  const [alerts, setAlerts] = useState<{ key: string; text: string; severity: any; at: string }[]>([]);
  const [alertsAnchor, setAlertsAnchor] = useState<HTMLElement | null>(null);
  const [unseen, setUnseen] = useState(0);
  const [skip, setSkip] = useState<{ run: SkipRunTarget; dep: string } | null>(null);
  const [logExec, setLogExec] = useState<string | null>(null);
  const [holdsOpen, setHoldsOpen] = useState(searchParams.get('holds') === '1');
  const [notice, setNotice] = useState<{ ok: boolean; text: string } | null>(null);
  const [localSel, setLocalSel] = useState<Set<number>>(new Set());
  const sel = selectedIds ?? localSel;
  const toggleSel = onToggleSelect ?? ((id: number, _run?: any) => setLocalSel(s => {
    const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n;
  }));
  const prev = useRef<Board | null>(null);
  const reqSeq = useRef(0);
  const [lastEventAt, setLastEventAt] = useState<Date | null>(null);
  // 2026-10-17 -- feed events are addressed to a feed's owner and group,
  // never to every admin; the board WATCHES the estate while it is open
  // (wsService.watch -> server set_watch) and the server says whether it
  // may.  Refused = live for the caller's own feeds only; the chip says so.
  const [watchState, setWatchState] = useState<'estate' | 'refused' | null>(null);
  const [watchReason, setWatchReason] = useState<string | null>(null);
  // keyed on the stable delegate, not the context value (which changes on
  // every message): one watch per mount, one unwatch per unmount
  const watchFn = ws?.watch;
  useEffect(() => {
    const off = watchFn?.('feed_board');
    return () => { if (typeof off === 'function') off(); };
  }, [watchFn]);

  const load = useCallback(async () => {
    const mine = ++reqSeq.current;
    setLoading(true);
    try {
      const r = (await api.feedDashboard({ ...(dateKind === 'run' ? { run_date: runDate } : { business_date: businessDate }),
                                           search, status, page, page_size: pageSize, group_by: groupBy })) as Board;
      if (mine !== reqSeq.current) return;          // a newer request owns the screen
      const changes = boardTransitions(prev.current, r);
      if (changes.length) {
        const at = new Date().toLocaleTimeString();
        setAlerts(a => [...changes.map(c => ({ ...c, at })), ...a].slice(0, 30));
        setUnseen(n => n + changes.length);
      }
      prev.current = r;
      setEnvironments(r.environments);
      setBoard(r);
      setError(null);
    } catch (e: any) {
      if (mine === reqSeq.current) setError(e?.message || 'Could not read Feed Run Status');
    } finally {
      if (mine === reqSeq.current) setLoading(false);
    }
  }, [businessDate, runDate, dateKind, search, status, page, pageSize, groupBy]);

  // a new question (date / filter / page / grouping) is not a "change" to announce
  useEffect(() => { prev.current = null; }, [businessDate, runDate, dateKind, search, status, page, pageSize, groupBy]);
  useEffect(() => { const t = setTimeout(load, 250); return () => clearTimeout(t); }, [load]);
  useEffect(() => { if (refreshNonce) load(); }, [refreshNonce]);   // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    let pending: any = null;
    const kick = () => { if (!pending) pending = setTimeout(() => { pending = null; load(); }, 600); };
    let slow: any = null;
    const off = ws?.addListener?.((m: any) => {
      const t = String(m?.type || '');
      if (t === 'watching' && m.scope === 'feed_board') {
        if (m.on === false) return;
        setWatchState(m.ok ? 'estate' : 'refused');
        setWatchReason(m.ok ? null : String(m.reason || ''));
        return;
      }
      // LIVE (2026-10-12, the owner: "live websocket ... show what's running
      // ... faster not slow"): a step event patches its row IN PLACE at once
      // (no round trip); the steps' recorded states follow in one quiet
      // re-read a few seconds later, never one per event
      if (t === 'feed_progress') {
        setBoard(b => applyLiveEvent(b, m));
        setLastEventAt(new Date());
        if (!slow) slow = setTimeout(() => { slow = null; load(); }, 5000);
        return;
      }
      if (['feed_sla_breach', 'feed_dep_ready', 'feed_completed', 'feed_failed', 'feed_cancelled',
           'feed_dep_wait_escalated', 'feed_status'].includes(t)) { setLastEventAt(new Date()); kick(); }
    });
    const tick = setInterval(() => { if (document.visibilityState === 'visible') load(); }, 60_000);
    return () => { if (typeof off === 'function') off(); clearInterval(tick); if (pending) clearTimeout(pending);
                   if (slow) clearTimeout(slow); };
  }, [ws, load]);

  const toggleGroup = (k: string) => setClosedGroups(s => { const n = new Set(s); n.has(k) ? n.delete(k) : n.add(k); return n; });
  const toggleRun = (id: number) => setOpenRuns(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });

  const openLogs = async (t: BoardTask) => {
    try {
      const r: any = await api.getFeedRunSteps(t.run_id);
      const id = r?.execution?.id;
      if (id == null) setNotice({ ok: false, text: `${t.feed_name}: this run has not executed yet — there is no log` });
      else setLogExec(String(id));
    } catch (e: any) {
      setNotice({ ok: false, text: e?.message || 'Could not find the run log' });
    }
  };
  const rerun = async (t: BoardTask) => {
    if (!window.confirm(`Re-run ${t.feed_name} for business date ${t.business_date || businessDate}?`)) return;
    try {
      await api.rerunFeedRun(t.run_id);
      setNotice({ ok: true, text: `${t.feed_name}: re-run queued — a worker picks it up` });
      load();
    } catch (e: any) {
      setNotice({ ok: false, text: e?.message || 'The re-run was refused' });
    }
  };

  // the popup lists VARIANCE holds; ``held`` also counts re-send holds
  const held = board?.kpis?.variance_held ?? board?.kpis?.held ?? 0;
  // 2026-10-12 (owner: "arrange status bar somewhere") -- the status pills sit
  // in the page header's empty right side when the page offers the slot
  const [headerSlot, setHeaderSlot] = useState<HTMLElement | null>(null);
  useEffect(() => { setHeaderSlot(document.getElementById(BOARD_HEADER_SLOT)); }, []);
  const pills = (
        <Stack direction="row" useFlexGap sx={{ flexWrap: 'wrap', gap: 0.5 }} data-testid="board-kpis">
      {TILES.map(k => {
        const active = k === 'all' ? !status : status === k;
        const n = board?.kpis?.[k] ?? 0;
        const quiet = ['sla_breached', 'sla_at_risk', 'held'].includes(k) && !n;
        return (
          <Box key={k} role="button" tabIndex={0} aria-pressed={active}
               data-testid={`board-kpi-${k}`} title={STATUS_HELP[k] || `Show ${STATUS_LABEL[k].toLowerCase()}`}
               onClick={() => { setStatus(k === 'all' ? '' : k); setPage(1); }}
               onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { setStatus(k === 'all' ? '' : k); setPage(1); } }}
               sx={{ cursor: 'pointer', minWidth: 62, px: 1, py: 0.25, borderRadius: 1.5, textAlign: 'center',
                     color: quiet ? TILE_HEX[k] : '#fff',
                     bgcolor: quiet ? (t) => alpha(TILE_HEX[k], t.palette.mode === 'dark' ? 0.18 : 0.08) : TILE_HEX[k],
                     outline: active ? '2px solid' : 'none', outlineColor: TILE_HEX[k], outlineOffset: 2,
                     boxShadow: active ? 3 : 0, transition: 'box-shadow .15s' }}>
            <Typography component="div" sx={{ fontWeight: 800, fontSize: 17, lineHeight: 1.15 }}>
              {n.toLocaleString()}
            </Typography>
            <Typography component="div" sx={{ fontWeight: 700, fontSize: 9.5, letterSpacing: 0.4,
                                              textTransform: 'uppercase', lineHeight: 1.2, whiteSpace: 'nowrap' }}>
              {STATUS_LABEL[k]}
            </Typography>
          </Box>
        );
      })}
    </Stack>
  );

  return (
    <Box data-testid="feed-run-board">
      {/* 2026-10-12 (owner: "move status bar on top ... space utilisation") --
          ONE row: the question on the left (find, status, date, grouping),
          the answer on the right (the status pills; a pill filters, the
          totals stay).  Paging, what changed and the holds sit on a thin
          second row. */}
      <Stack direction="row" alignItems="center" useFlexGap sx={{ flexWrap: 'wrap', gap: 1, mb: 0.75 }}>
        <TextField size="small" placeholder="Find a feed or group" value={search}
                   onChange={e => { setSearch(e.target.value); setPage(1); }}
                   inputProps={{ 'data-testid': 'board-search', 'aria-label': 'Find a feed or group' }}
                   sx={{ width: 200 }} />
        <TextField select size="small" value={status} sx={{ width: 140 }}
                   onChange={e => { setStatus(String(e.target.value)); setPage(1); }}
                   SelectProps={{ displayEmpty: true }}
                   inputProps={{ 'data-testid': 'board-status', 'aria-label': 'Status' }}>
          <MenuItem value="">All statuses</MenuItem>
          {['completed', 'in_progress', 'failed', 'not_started', 'queued', 'held', 'skipped', 'sla_breached', 'sla_at_risk']
            .map(s => <MenuItem key={s} value={s}>{STATUS_LABEL[s]}</MenuItem>)}
        </TextField>
        <ToggleButtonGroup size="small" exclusive value={dateKind} aria-label="Which date"
                           data-testid="board-date-kind" sx={{ '& .MuiToggleButton-root': { py: 0.4, px: 1, textTransform: 'none' } }}
                           onChange={(_e, v) => { if (v) { setDateKind(v); setPage(1); } }}>
          <ToggleButton value="business">By business date</ToggleButton>
          <ToggleButton value="run">By run date</ToggleButton>
        </ToggleButtonGroup>
        <Tooltip title={dateKind === 'run'
          ? 'Each feed on the business date its schedule gives for this day — a month end shows every day until the next month end'
          : 'The feeds for this business date'}>
          <TextField type="date" size="small" value={dateKind === 'run' ? runDate : businessDate} sx={{ width: 150 }}
                     onChange={e => { if (dateKind === 'run') setRunDate(e.target.value); else onBusinessDateChange(e.target.value); setPage(1); }}
                     inputProps={{ 'data-testid': 'board-date', 'aria-label': dateKind === 'run' ? 'Run date' : 'Business date' }} />
        </Tooltip>
        <TextField select size="small" value={groupBy} sx={{ width: 190 }}
                   onChange={e => { setGroupBy(String(e.target.value)); setPage(1); }}
                   inputProps={{ 'data-testid': 'board-group-by', 'aria-label': 'Group by' }}>
          {GROUP_BY.map(g => <MenuItem key={g.value} value={g.value}>Group: {g.label}</MenuItem>)}
        </TextField>
        <Tooltip title={ws?.isConnected
          ? (watchState === 'estate'
              ? `LIVE: every feed's events update this board as they happen${lastEventAt ? ` (last ${lastEventAt.toLocaleTimeString()})` : ''}`
              : watchState === 'refused'
                ? `LIVE for your own feeds and your groups' (${watchReason || 'the estate watch was refused'}); other feeds refresh every minute`
                : `LIVE: your feeds' events update this board as they happen; the board also re-reads every minute${lastEventAt ? ` (last ${lastEventAt.toLocaleTimeString()})` : ''}`)
          : 'Not connected live — the board re-reads every minute'}>
          <Chip size="small" data-testid="board-live" data-live={ws?.isConnected ? 'on' : 'off'} data-watch={watchState || 'none'}
                label={ws?.isConnected ? 'LIVE' : 'OFFLINE'}
                icon={<Box component="span" sx={{ width: 8, height: 8, borderRadius: '50%', ml: '6px !important',
                                                  bgcolor: ws?.isConnected ? '#2e7d32' : '#9e9e9e',
                                                  animation: ws?.isConnected ? 'qsLive 1.6s ease-in-out infinite' : undefined,
                                                  '@keyframes qsLive': { '50%': { opacity: 0.25 } } }} />}
                sx={{ fontWeight: 800, fontSize: 10.5, height: 22,
                      color: ws?.isConnected ? '#2e7d32' : 'text.secondary' }} variant="outlined" />
        </Tooltip>
        <Tooltip title="Refresh now (it also refreshes itself on every feed event)">
          <IconButton size="small" aria-label="Refresh" onClick={load}>
            {loading ? <CircularProgress size={16} /> : <RefreshIcon fontSize="small" />}
          </IconButton>
        </Tooltip>
        <Box sx={{ flexGrow: 1 }} />
        {!headerSlot && pills}
      </Stack>

      <Stack direction="row" spacing={0.5} alignItems="center" sx={{ mb: 0.75 }}>
        <TextField select size="small" value={pageSize} onChange={e => { setPageSize(Number(e.target.value)); setPage(1); }}
                   inputProps={{ 'aria-label': 'Runs per page' }}
                   sx={{ width: 76, '& .MuiSelect-select': { py: 0.25 } }}>
          {[25, 50, 100, 200].map(n => <MenuItem key={n} value={n}>{n}</MenuItem>)}
        </TextField>
        <IconButton size="small" aria-label="Previous page" disabled={!board || board.page <= 1}
                    onClick={() => setPage(p => Math.max(1, p - 1))}><ChevronRight sx={{ transform: 'rotate(180deg)' }} /></IconButton>
        <Typography variant="body2" data-testid="board-page">{board ? `${board.page} / ${board.pages}` : '-'}</Typography>
        <IconButton size="small" aria-label="Next page" disabled={!board || board.page >= board.pages}
                    onClick={() => setPage(p => p + 1)}><ChevronRight /></IconButton>
        <Typography variant="body2" color="text.secondary" data-testid="board-displaying">
          {board ? (board.total_tasks ? `Showing ${board.first}-${board.last} of ${board.total_tasks.toLocaleString()} runs` : '') : ''}
        </Typography>
        <Box sx={{ flexGrow: 1 }} />
        <Tooltip title="What changed while you watched: SLA breached / met, dependencies arrived, done, failed, held">
          <IconButton size="small" aria-label="What changed" data-testid="board-alerts-button"
                      onClick={e => { setAlertsAnchor(e.currentTarget); setUnseen(0); }}>
            <Badge color="error" badgeContent={unseen} max={99}><BellIcon fontSize="small" /></Badge>
          </IconButton>
        </Tooltip>
        <Button size="small" variant={held ? 'contained' : 'outlined'} color="warning" startIcon={<WarnIcon />}
                onClick={() => setHoldsOpen(true)} data-testid="board-variance-holds" sx={{ py: 0 }}>
          Variance holds{held ? ` (${held})` : ''}
        </Button>
      </Stack>

      <Popover open={!!alertsAnchor} anchorEl={alertsAnchor} onClose={() => setAlertsAnchor(null)}
               anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
               transformOrigin={{ vertical: 'top', horizontal: 'right' }}>
        <Box sx={{ p: 1, width: 420, maxWidth: '90vw', maxHeight: 360, overflow: 'auto' }} data-testid="board-alerts">
          <Stack direction="row" alignItems="center" sx={{ mb: 0.5 }}>
            <Typography variant="subtitle2" sx={{ flexGrow: 1 }}>What changed</Typography>
            {alerts.length > 0 && <Button size="small" onClick={() => setAlerts([])}>Clear</Button>}
            <IconButton size="small" aria-label="Close what changed" onClick={() => setAlertsAnchor(null)}>
              <CloseIcon fontSize="small" />
            </IconButton>
          </Stack>
          {alerts.length === 0 && (
            <Typography variant="body2" color="text.secondary">Nothing has changed since the board opened.</Typography>
          )}
          {alerts.map(a => (
            <Alert key={`${a.key}-${a.at}`} severity={a.severity} sx={{ py: 0, mb: 0.25 }} data-testid="board-alert">
              {a.at} — {a.text}
            </Alert>
          ))}
        </Box>
      </Popover>
      {headerSlot && createPortal(pills, headerSlot)}
      {board?.date_kind === 'run_date' && (
        <Stack direction="row" alignItems="center" useFlexGap sx={{ flexWrap: 'wrap', gap: 0.75, mb: 0.75 }}
               data-testid="board-date-summary">
          <Typography variant="body2" sx={{ fontWeight: 700 }}>Run date {dayText(board.run_date)}:</Typography>
          {(board.date_summary || []).length === 0 && (
            <Typography variant="body2" color="text.secondary">no feed has a task for this run date</Typography>
          )}
          {(board.date_summary || []).map(s => (
            <Chip key={`${s.label}-${s.business_date}`} size="small" variant="outlined"
                  data-testid="board-date-summary-item"
                  label={`${s.label} ${dayText(s.business_date)} · ${s.feeds} feed${s.feeds === 1 ? '' : 's'}`} />
          ))}
        </Stack>
      )}
      {notice && <Alert severity={notice.ok ? 'success' : 'error'} onClose={() => setNotice(null)} sx={{ mb: 1 }}
                        data-testid="board-notice">{notice.text}</Alert>}
      {error && <Alert severity="error" sx={{ mb: 1 }} data-testid="board-error">{error}</Alert>}

      {board && (board.missing_count ?? 0) > 0 && (
        <Alert severity="warning" sx={{ mb: 1 }} data-testid="board-missing">
          <b>{board.missing_count} feed{board.missing_count === 1 ? ' is' : 's are'} due on this date with no task</b>
          {' — '}start of day has not created {board.missing_count === 1 ? 'it' : 'them'}
          {board.sod && board.sod.enabled === false ? ' (start of day is OFF on this deployment: feed_generation.sod_enabled)' : ''}:{' '}
          {(board.missing || []).map(m => m.feed_name || `feed ${m.feed_id}`).join(', ')}
          {(board.missing_count ?? 0) > (board.missing || []).length ? ` … and ${(board.missing_count ?? 0) - (board.missing || []).length} more` : ''}
        </Alert>
      )}
      {board?.missing_unavailable && (
        <Alert severity="error" sx={{ mb: 1 }} data-testid="board-missing-unknown">
          Could not check which feeds are due but have no task: {board.missing_unavailable}
        </Alert>
      )}
      {board && board.total_tasks === 0 && !error && (
        <Alert severity="info" data-testid="board-empty">
          {board.date_kind === 'run_date' ? `Nothing was worked on ${board.run_date}` : `No feed runs for ${board.business_date}`}
          {status ? ` with status ${STATUS_LABEL[status]}` : ''}{search ? ` matching "${search}"` : ''}.
          {board.sod && board.sod.enabled === false && !status && !search
            ? ' Start of day is OFF on this deployment (feed_generation.sod_enabled=false): no task is created for a date unless a per-feed schedule, Run Now or a backfill makes one.'
            : ''}
        </Alert>
      )}

      {board?.groups.map(g => {
        const gk = g.key ?? `${g.id}`;
        const open = !closedGroups.has(gk);
        const n = g.counts.all || 0;
        return (
          <Paper key={gk} variant="outlined" sx={{ mb: 1, overflow: 'hidden' }} data-testid="board-group">
            <Stack direction="row" alignItems="center" spacing={1}
                   sx={{ px: 1.25, py: 0.5, cursor: 'pointer', bgcolor: 'action.hover' }}
                   role="button" tabIndex={0} aria-expanded={open} aria-label={`Group ${g.name}`}
                   onClick={() => toggleGroup(gk)} onKeyDown={e => { if (e.key === 'Enter') toggleGroup(gk); }}>
              {open ? <ExpandMore fontSize="small" /> : <ChevronRight fontSize="small" />}
              <Typography sx={{ fontWeight: 700 }} data-testid="board-group-name">{g.display_label}</Typography>
              <Typography variant="body2" color="text.secondary">{n} feed{n === 1 ? '' : 's'}</Typography>
              <Box sx={{ flexGrow: 1 }} />
              {['failed', 'held', 'in_progress', 'not_started', 'queued', 'completed'].filter(k => g.counts[k]).map(k => (
                <Chip key={k} size="small" variant="outlined" color={STATUS_COLOR[k] as any} sx={{ height: 20 }}
                      data-testid={`board-group-count-${k}`} label={`${g.counts[k]} ${STATUS_LABEL[k].toLowerCase()}`} />
              ))}
            </Stack>
            <Collapse in={open}>
              {g.tasks.map(t => {
                const ropen = openRuns.has(t.run_id);
                const sla = slaChip(t.sla);
                const selected = sel.has(t.run_id);
                const emph = slaEmphasis(t.sla);
                const emphHex = emph === 'breached' ? '#c62828' : emph === 'at_risk' ? '#ef6c00' : null;
                const si = STATUS_ICON[t.status];
                const openAlerts = (t.alerts || []).filter(a => a.status === 'open');
                const s = t.steps;
                const pct = s && s.total ? Math.round((s.completed * 100) / s.total) : 0;
                return (
                  <Box key={t.run_id} data-testid="board-task" data-selected={selected || undefined}
                       data-sla={emph || undefined}
                       sx={{ borderTop: 1, borderColor: 'divider', borderLeft: 4,
                             // SLA breached / at risk is the first thing the eye finds
                             borderLeftColor: selected ? 'primary.main' : (emphHex || 'transparent'),
                             bgcolor: selected ? (th) => alpha(th.palette.primary.main, 0.08)
                               : emphHex ? (th) => alpha(emphHex, th.palette.mode === 'dark' ? 0.16 : 0.06) : 'transparent' }}>
                    {/* 2026-10-17 -- a phone (390px) wraps the row's cells instead
                        of scrolling the page sideways */}
                    <Stack direction="row" alignItems="center" useFlexGap
                           sx={{ px: 0.5, py: 0.25, gap: 1, flexWrap: { xs: 'wrap', lg: 'nowrap' } }}>
                      <Checkbox size="small" checked={selected} sx={{ p: 0.5 }}
                                onChange={() => toggleSel(t.run_id, {
                                  id: t.run_id, feed_config_id: t.feed_id, feed_name: t.feed_name,
                                  status: t.run_status ?? t.status, business_date: t.business_date || businessDate,
                                  action_reason: t.action_reason })}
                                inputProps={{ 'aria-label': `Select ${t.feed_name}` }} />
                      <IconButton size="small" aria-expanded={ropen} sx={{ p: 0.25 }}
                                  aria-label={`${ropen ? 'Close' : 'Open'} ${t.feed_name}`}
                                  onClick={() => toggleRun(t.run_id)}>
                        {ropen ? <ExpandMore fontSize="small" /> : <ChevronRight fontSize="small" />}
                      </IconButton>
                      <Box sx={{ minWidth: 0, flex: '1 1 260px' }}>
                        <Typography variant="body2" sx={{ fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                          {t.feed_name}
                        </Typography>
                        {(t.business_date || t.calendar?.name) && (
                          <Typography variant="caption" color="text.secondary" component="div" data-testid="board-task-dates"
                                      sx={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                            {t.business_date && <b>{t.date_rule?.label || 'Business date'} {dayText(t.business_date)}</b>}
                            {t.business_date && t.calendar?.name && ' · '}
                            {t.calendar?.name && `${t.calendar.name} calendar${t.calendar.from === 'default' ? ' (platform default)' : ''}`}
                          </Typography>
                        )}
                        <MiniFlow s={t.steps} seq={t.step_seq} deps={t.deps}
                                  title={stepChips(t.steps).map(c => c.label).join(' · ') || 'No step recorded yet'} />
                        <Stack direction="row" spacing={1} alignItems="center" useFlexGap sx={{ flexWrap: 'wrap' }}>
                          <Typography variant="caption" color="text.secondary" data-testid="board-task-steps">
                            {stepsSummary(t.steps)}
                          </Typography>
                          <RowCounts sides={t.sides} total={t.total_rows} superseded={t.superseded} />
                          {t.status === 'in_progress' && t.progress && (
                            <Box data-testid="board-run-progress"><RunProgressBar progress={t.progress} compact /></Box>
                          )}
                          {t.live_stage && t.status === 'in_progress' && !t.progress && (
                            <Typography variant="caption" sx={{ color: '#1565c0', fontWeight: 600 }} data-testid="board-live-stage">
                              now: {t.live_stage.replace(/_/g, ' ')}
                            </Typography>
                          )}
                          {deliveredOf(t.deliveries).length > 1 && (
                            <Tooltip title={(t.deliveries || []).map(d => `${dayText(d.run_date)}: ${d.rows != null ? d.rows.toLocaleString() : '?'} rows — ${d.delivered === false ? 'not delivered — ' : ''}${d.why || d.file || ''}`).join('\n')}>
                              <Chip size="small" icon={<HistoryIcon />} variant="outlined" sx={{ height: 18, fontSize: 10.5 }}
                                    data-testid="board-deliveries-count"
                                    label={`Delivered ${deliveredOf(t.deliveries).length}x${deliveredOf(t.deliveries)[0]?.run_date ? ` · last ${dayText(deliveredOf(t.deliveries)[0].run_date).replace(/ \d{4}$/, '')}` : ''}`} />
                            </Tooltip>
                          )}
                        </Stack>
                      </Box>
                      <RowDeps task={t} onOpen={() => { if (!ropen) toggleRun(t.run_id); }} />
                      <Typography variant="caption" color="text.secondary" sx={{ minWidth: 130, textAlign: 'right' }}>
                        {t.started_at ? `${hms(t.started_at)} → ${t.completed_at ? hms(t.completed_at) : '…'}` : 'not started'}
                        {t.duration_seconds != null && <><br />{plainDuration(t.duration_seconds)}</>}
                      </Typography>
                      <Box sx={{ minWidth: 120, textAlign: 'right' }}>
                        {sla && (
                          <Tooltip title={t.sla.deadline_utc ? `Deadline ${t.sla.sla_to} ${t.sla.sla_timezone || 'UTC'}${t.sla.alerted ? ' — breach alert raised' : ''}` : ''}>
                            <Chip size="small" variant="outlined" label={sla.label} color={sla.color} data-testid="board-sla" />
                          </Tooltip>
                        )}
                      </Box>
                      <Box sx={{ minWidth: 112, textAlign: 'right' }}>
                        {t.variance_hold ? (
                          <Chip size="small" color="warning" label="Held" onClick={() => setHoldsOpen(true)}
                                icon={<HeldIcon />} data-testid="board-held" />
                        ) : (
                          <Tooltip title={t.status === 'held' && t.superseded?.restatement
                            ? t.superseded.restatement.title : (t.action_reason || STATUS_HELP[t.status] || '')}>
                            <Chip size="small" label={t.status === 'held' && t.superseded?.restatement?.action === 'hold'
                                    ? 'Re-run hold' : (STATUS_LABEL[t.status] || t.status)}
                                  color={STATUS_COLOR[t.status] as any} data-testid="board-task-status"
                                  icon={si ? <si.Icon sx={si.spin ? { animation: 'qsSpin 1.2s linear infinite',
                                    '@keyframes qsSpin': { to: { transform: 'rotate(360deg)' } } } : undefined} /> : undefined} />
                          </Tooltip>
                        )}
                      </Box>
                      {openAlerts.length > 0 && (
                        <Tooltip title={openAlerts.map(a => a.title).join('\n')}>
                          <IconButton size="small" aria-label={`Alerts — ${t.feed_name}`} data-testid="board-task-alerts"
                                      onClick={() => { if (!ropen) toggleRun(t.run_id); }}>
                            <Badge color="error" badgeContent={openAlerts.length}><BellIcon fontSize="small" color="error" /></Badge>
                          </IconButton>
                        </Tooltip>
                      )}
                      <Tooltip title="Configuration: source, schedule, calendar, dependencies, file, delivery, checks and who changed it">
                        <IconButton size="small" aria-label={`Configuration — ${t.feed_name}`} data-testid="board-task-config"
                                    onClick={() => setConfigFeed({ id: t.feed_id, name: t.feed_name })}>
                          <ConfigIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title="Run log">
                        <IconButton size="small" aria-label={`Run log — ${t.feed_name}`} onClick={() => openLogs(t)}>
                          <LogsIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                      <Tooltip title={mayAct(t) ? 'Re-run this feed for the date' : VIEW_ONLY}>
                        <span>
                          <IconButton size="small" aria-label={`Re-run — ${t.feed_name}`} onClick={() => rerun(t)}
                                      disabled={!mayAct(t)} data-testid="board-task-rerun">
                            <RerunIcon fontSize="small" />
                          </IconButton>
                        </span>
                      </Tooltip>
                    </Stack>
                    {ropen && (
                      <RunDetail task={t} businessDate={t.business_date || board.business_date || businessDate} onChanged={load}
                                 viewedRunDate={board.date_kind === 'run_date' ? board.run_date : null}
                                 onSkip={dep => setSkip({ run: { id: t.run_id, feed_name: t.feed_name, feed_config_id: t.feed_id }, dep })} />
                    )}
                  </Box>
                );
              })}
            </Collapse>
          </Paper>
        );
      })}

      <FeedRunSkipDepsDialog run={skip?.run ?? null} knownDeps={skip ? [skip.dep] : null}
                             onClose={() => setSkip(null)} onDone={() => { setSkip(null); load(); }} />
      <FeedConfigSummaryDialog feedId={configFeed?.id ?? null} feedName={configFeed?.name}
                               onClose={() => setConfigFeed(null)} />
      {logExec && <FeedLiveLogDialog execDbId={logExec} onClose={() => setLogExec(null)} />}
      <Dialog open={holdsOpen} onClose={() => { setHoldsOpen(false); load(); }} maxWidth="lg" fullWidth>
        <DialogContent sx={{ p: 0 }}>
          <FeedVarianceHoldsPage />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => { setHoldsOpen(false); load(); }}>Close</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
