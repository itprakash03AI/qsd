/**
 * Component Health -- ONE place for every pod, daemon and dependency
 * (2026-10-17, docs/COMPONENT_HEALTH_DESIGN_2026_10_17.html).
 *
 * Source: GET /api/admin/component-health (core/component_health/reader.py):
 * one SELECT on the server, polled every 10 s here, never a probe because
 * this page asked.  The page is BUILT from the server's rows and the
 * registry's catalogue (controls per component) -- a new component appears
 * by existing, never by editing this file.
 *
 * Folded into this page (owner rule: one dashboard per area): System Health,
 * Operations Dashboard, Scheduler, Self-Test, the pods half of Multi-Pod,
 * Background Jobs (the "Daemon ticks" tab) and Effective Posture (the
 * "Posture" tab).  Their ?section= ids resolve here (AdminPage aliases).
 *
 * A viewer (the support role) sees everything and can act on nothing:
 * `controls_allowed` comes from the server and the API refuses regardless.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Button, Chip, CircularProgress, Collapse, Divider, Drawer, IconButton, Paper, Stack,
  Tab, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tabs, TextField, Tooltip,
  Typography,
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import CloseIcon from '@mui/icons-material/Close';
import { safeFetch } from '../../services/api/core';
import StatCard from './StatCard';
import BackgroundJobsSection from './BackgroundJobsSection';
import EffectivePostureSection from './EffectivePostureSection';
import StateChip from './componentHealth/StateChip';
import ControlDialog, { type ControlRequest } from './componentHealth/ControlDialog';
import ThisPodPanel from './componentHealth/ThisPodPanel';
import SelfTestPanel from './componentHealth/SelfTestPanel';
import SchedulerJobsPanel from './componentHealth/SchedulerJobsPanel';
import {
  CONTROL_LABELS, type DeclaredCheck, type HealthEvent, type HealthPage, type HealthRow,
  type HealthState, type Intent, type PodCard, fmtAge,
} from './componentHealth/types';

const POLL_MS = 10_000;
const BASE = '/api/admin/component-health';

type TabId = 'health' | 'thispod' | 'selftest' | 'ticks' | 'posture' | 'history' | 'alerts' | 'intents';

function shortBuild(b: string | null | undefined): string {
  return (b || '—').split(' ')[0];
}

function num(v: any, suffix = ''): string {
  return v === null || v === undefined ? '—' : `${v}${suffix}`;
}

// ── controls ─────────────────────────────────────────────────────────────────

const ControlButtons: React.FC<{
  row: { component_id: string; label: string; pod_id?: string; disposition?: string | null };
  controls: string[];
  allowed: boolean;
  onControl: (r: ControlRequest) => void;
  targetPod?: string | null;
}> = ({ row, controls, allowed, onControl, targetPod }) => {
  if (!controls.length) return null;
  const visible = controls.filter(c => {
    if (c === 'pause' && row.disposition === 'paused') return false;
    if (c === 'resume' && row.disposition !== 'paused') return false;
    if (c === 'drain' && row.disposition === 'draining') return false;
    if (c === 'undrain' && row.disposition !== 'draining') return false;
    return true;
  });
  return (
    <Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap>
      {visible.map(c => {
        const btn = (
          <Button key={c} size="small" variant="outlined" disabled={!allowed}
            data-testid={`control-${c}-${row.component_id}${targetPod ? '@' + targetPod : ''}`}
            onClick={() => onControl({ control: c, component_id: row.component_id, label: row.label,
                                       target_pod_id: targetPod ?? undefined })}>
            {CONTROL_LABELS[c] || c}
          </Button>
        );
        return allowed ? btn : (
          <Tooltip key={c} title="read-only (support): the API refuses controls for this role" arrow>
            <span>{btn}</span>
          </Tooltip>
        );
      })}
    </Stack>
  );
};

// ── one pod ──────────────────────────────────────────────────────────────────

const PodCardView: React.FC<{
  pod: PodCard; controlsOf: (id: string) => string[]; allowed: boolean;
  onControl: (r: ControlRequest) => void; onOpen: (id: string) => void;
}> = ({ pod, controlsOf, allowed, onControl, onOpen }) => {
  const [open, setOpen] = useState(false);
  const m = pod.metrics || {};
  const mem = m.memory || {};
  const workers = m.workers || {};
  const keys = m.keys || {};
  const self = pod.components.find(c => c.component_id === 'pod:self');
  return (
    <Paper variant="outlined" sx={{ p: 1.5, minWidth: 300, flex: '1 1 320px' }} data-testid={`pod-card-${pod.pod_id}`}>
      <Stack direction="row" justifyContent="space-between" alignItems="center">
        <Box>
          <Typography variant="subtitle1" fontWeight={700}>{pod.pod_id}</Typography>
          <Typography variant="caption" color="text.secondary">
            {pod.pod_role || '?'} · build {shortBuild(pod.build)} · reported {fmtAge(pod.reported_at)}
          </Typography>
        </Box>
        <StateChip state={pod.state} disposition={pod.disposition} reason={pod.reason} />
      </Stack>
      <Typography variant="body2" sx={{ mt: 0.5 }} data-testid={`pod-reason-${pod.pod_id}`}>{pod.reason}</Typography>
      <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap sx={{ mt: 1 }}>
        <Typography variant="caption">memory {num(mem.rss_mb)} / {num(mem.limit_mb)} MB</Typography>
        <Typography variant="caption">processes {num(workers.alive)}/{num(workers.configured)}{workers.oom_kill ? ` · oom ${workers.oom_kill}` : ''}</Typography>
        <Typography variant="caption">disk {num((m.disk || {}).free_gb, ' GB')} free</Typography>
        <Typography variant="caption">db {num((m.db_ping || {}).ms, ' ms')}</Typography>
        <Typography variant="caption">tls {m.tls || '—'}</Typography>
        <Typography variant="caption">key {keys.fingerprint ? String(keys.fingerprint).slice(0, 10) : '—'}{keys.waiting ? ' (waiting)' : ''}{keys.mismatch ? ' (MISMATCH)' : ''}</Typography>
        {m.scheduler_lock_held && <Chip size="small" label="scheduler lock" color="primary" variant="outlined" />}
      </Stack>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mt: 1 }}>
        <ControlButtons row={{ component_id: 'pod:self', label: pod.pod_id, disposition: pod.disposition }}
          controls={controlsOf('pod:self')} allowed={allowed} onControl={onControl} targetPod={pod.pod_id} />
        <Button size="small" onClick={() => setOpen(o => !o)} endIcon={open ? <ExpandLessIcon /> : <ExpandMoreIcon />}
          aria-label={`toggle components of ${pod.pod_id}`}>
          {pod.components.length} components · {pod.summary.down} down · {pod.summary.degraded} degraded · {pod.summary.unknown} unknown
        </Button>
      </Stack>
      <Collapse in={open}>
        <TableContainer sx={{ mt: 1, maxHeight: 360 }}>
          <Table size="small" stickyHeader aria-label={`components of ${pod.pod_id}`}>
            <TableHead>
              <TableRow>
                <TableCell>Component</TableCell><TableCell>State</TableCell><TableCell>Reason</TableCell>
                <TableCell>Checked</TableCell><TableCell>Controls</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {pod.components.map(c => (
                <TableRow key={c.component_id} hover>
                  <TableCell>
                    <Button size="small" variant="text" onClick={() => onOpen(c.component_id)} sx={{ textTransform: 'none' }}>
                      {c.label}
                    </Button>
                  </TableCell>
                  <TableCell><StateChip state={c.state} disposition={c.disposition} /></TableCell>
                  <TableCell sx={{ maxWidth: 420, fontSize: '0.78rem' }}>{c.reason}</TableCell>
                  <TableCell sx={{ fontSize: '0.78rem' }}>{fmtAge(c.checked_at)}</TableCell>
                  <TableCell>
                    {/* targetPod keeps the test id unique per pod (the fleet table carries the
                        same component); a daemon pause / resume is fleet-wide regardless */}
                    <ControlButtons row={c} controls={controlsOf(c.component_id).filter(x => x !== 'drain' && x !== 'undrain' && x !== 'rerun_self_test')}
                      allowed={allowed} onControl={onControl} targetPod={pod.pod_id} />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Collapse>
      {self?.metrics?.self_test && (
        <Typography variant="caption" color="text.secondary">
          self-test {self.metrics.self_test.passed}/{self.metrics.self_test.total} passed at {self.metrics.self_test.at}
        </Typography>
      )}
    </Paper>
  );
};

// ── a fleet table (dependencies or daemons) ─────────────────────────────────

const FleetTable: React.FC<{
  title: string; rows: HealthRow[]; controlsOf: (id: string) => string[]; allowed: boolean;
  onControl: (r: ControlRequest) => void; onOpen: (id: string) => void; showPods?: boolean;
}> = ({ title, rows, controlsOf, allowed, onControl, onOpen, showPods }) => (
  <Paper variant="outlined" sx={{ p: 1.5 }}>
    <Typography variant="subtitle1" fontWeight={700} sx={{ mb: 1 }}>{title} ({rows.length})</Typography>
    {rows.length === 0 ? (
      <Typography variant="body2" color="text.secondary">none reported yet</Typography>
    ) : (
      <TableContainer sx={{ maxHeight: 480 }}>
        <Table size="small" stickyHeader aria-label={title}>
          <TableHead>
            <TableRow>
              <TableCell>Component</TableCell><TableCell>State</TableCell><TableCell>Reason</TableCell>
              {showPods && <TableCell>Running on</TableCell>}
              <TableCell>Last checked</TableCell><TableCell>Probe</TableCell><TableCell>Controls</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map(r => (
              <TableRow key={`${r.pod_id}|${r.component_id}`} hover data-testid={`row-${r.component_id}`}>
                <TableCell>
                  <Button size="small" variant="text" onClick={() => onOpen(r.component_id)} sx={{ textTransform: 'none' }}>
                    {r.label}
                  </Button>
                  <Typography variant="caption" display="block" color="text.secondary">{r.group || r.kind}</Typography>
                </TableCell>
                <TableCell><StateChip state={r.state} disposition={r.disposition} /></TableCell>
                <TableCell sx={{ maxWidth: 480, fontSize: '0.78rem' }} data-testid={`reason-${r.component_id}`}>{r.reason}</TableCell>
                {showPods && (
                  <TableCell sx={{ fontSize: '0.78rem' }}>
                    {((r.metrics || {}).running_on || []).join(', ') || '—'}
                  </TableCell>
                )}
                <TableCell sx={{ fontSize: '0.78rem' }}>{fmtAge(r.checked_at)}</TableCell>
                <TableCell sx={{ fontSize: '0.78rem' }}>{r.probe_ms === null || r.probe_ms === undefined ? '—' : `${r.probe_ms} ms`}</TableCell>
                <TableCell>
                  <ControlButtons row={r} controls={controlsOf(r.component_id)} allowed={allowed} onControl={onControl} />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    )}
  </Paper>
);

// ── the detail drawer ───────────────────────────────────────────────────────

const DetailDrawer: React.FC<{ componentId: string | null; onClose: () => void }> = ({ componentId, onClose }) => {
  const [detail, setDetail] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => {
    setDetail(null); setErr(null);
    if (!componentId) return;
    safeFetch(`${BASE}/${encodeURIComponent(componentId)}`, { retryOnTimeout: false })
      .then(setDetail).catch((e: any) => setErr(e?.message || String(e)));
  }, [componentId]);
  return (
    <Drawer anchor="right" open={!!componentId} onClose={onClose} PaperProps={{ sx: { width: 560, p: 2 } }}>
      <Stack direction="row" justifyContent="space-between" alignItems="center">
        <Typography variant="h6">{componentId}</Typography>
        <IconButton onClick={onClose} aria-label="close detail"><CloseIcon /></IconButton>
      </Stack>
      {err && <Alert severity="error">Could not load the component: {err}</Alert>}
      {!detail && !err && <CircularProgress size={20} sx={{ mt: 2 }} />}
      {detail && (
        <Stack spacing={1.5} sx={{ mt: 1 }}>
          {detail.declared?.docs && <Alert severity="info"><Typography variant="body2">{detail.declared.docs}</Typography></Alert>}
          {componentId === 'dependency:scheduler' && <SchedulerJobsPanel />}
          <Typography variant="subtitle2">Per pod</Typography>
          {(detail.rows || []).map((r: HealthRow) => (
            <Paper key={r.pod_id} variant="outlined" sx={{ p: 1 }}>
              <Stack direction="row" justifyContent="space-between">
                <Typography variant="body2" fontWeight={700}>{r.pod_id}</Typography>
                <StateChip state={r.state} disposition={r.disposition} />
              </Stack>
              <Typography variant="body2">{r.reason}</Typography>
              <Typography variant="caption" color="text.secondary">evidence {r.evidence || '—'} · checked {fmtAge(r.checked_at)} · since {r.state_since || '—'} · {r.confirmations} obs</Typography>
              <Box component="pre" sx={{ fontSize: '0.7rem', m: 0, mt: 0.5, maxHeight: 160, overflow: 'auto' }}>
                {JSON.stringify(r.metrics, null, 1)}
              </Box>
            </Paper>
          ))}
          {detail.note && <Alert severity="warning">{detail.note}</Alert>}
          {detail.alert && <Alert severity="error">Open alert #{detail.alert.id}: {detail.alert.title}</Alert>}
          <Typography variant="subtitle2">History</Typography>
          {(detail.events || []).length === 0 && <Typography variant="body2" color="text.secondary">no confirmed transition yet</Typography>}
          {(detail.events || []).map((e: HealthEvent) => (
            <Typography key={e.id} variant="body2">{e.at}: {e.from_state || '∅'} → <b>{e.to_state}</b>{e.pod_id ? ` on ${e.pod_id}` : ''}{e.by ? ` by ${e.by}` : ''} — {e.reason}</Typography>
          ))}
          {(detail.intents || []).length > 0 && (
            <>
              <Typography variant="subtitle2">Intents</Typography>
              {(detail.intents || []).map((i: Intent) => (
                <Typography key={i.id} variant="body2">#{i.id} {i.control} → {i.target_pod_id}: <b>{i.status}</b> (by {i.requested_by}: {i.reason})</Typography>
              ))}
            </>
          )}
          {detail.declared?.legacy_routes?.length > 0 && (
            <>
              <Typography variant="subtitle2">Still answers</Typography>
              {detail.declared.legacy_routes.map((r: string) => <Typography key={r} variant="caption" display="block" sx={{ fontFamily: 'monospace' }}>{r}</Typography>)}
            </>
          )}
        </Stack>
      )}
    </Drawer>
  );
};

// ── the page ────────────────────────────────────────────────────────────────

const ComponentHealthSection: React.FC = () => {
  const [page, setPage] = useState<HealthPage | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [registry, setRegistry] = useState<Record<string, DeclaredCheck>>({});
  const [tab, setTab] = useState<TabId>('health');
  const [filter, setFilter] = useState('');
  const [stateFilter, setStateFilter] = useState<HealthState | ''>('');
  const [drawer, setDrawer] = useState<string | null>(null);
  const [control, setControl] = useState<ControlRequest | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [events, setEvents] = useState<HealthEvent[] | null>(null);
  const [alerts, setAlerts] = useState<any[] | null>(null);
  const [intents, setIntents] = useState<Intent[] | null>(null);

  const load = useCallback(async () => {
    try {
      const data = await safeFetch<HealthPage>(BASE, { retryOnTimeout: false, timeoutMs: 20_000 });
      setPage(data);
      setLoadError(data.read?.ok ? null : (data.read?.reason || 'the component table could not be read'));
    } catch (e: any) {
      // an unreadable table is a 503 WITH the reason; keep the last page on screen
      setLoadError(e?.message || String(e));
    }
  }, []);

  useEffect(() => {
    safeFetch(`${BASE}/registry`, { retryOnTimeout: false })
      .then((r: any) => {
        const map: Record<string, DeclaredCheck> = {};
        for (const c of r?.checks || []) map[c.component_id] = c;
        setRegistry(map);
      }).catch(() => { /* controls stay hidden until the catalogue loads */ });
  }, []);

  useEffect(() => {
    load();
    const t = setInterval(load, POLL_MS);
    return () => clearInterval(t);
  }, [load]);

  useEffect(() => {
    if (tab === 'history') safeFetch(`${BASE}/events?limit=200`, { retryOnTimeout: false }).then((r: any) => setEvents(r.events || [])).catch(() => setEvents([]));
    if (tab === 'alerts') safeFetch('/api/feed-alerts?subject_kind=component&page_size=200', { retryOnTimeout: false }).then((r: any) => setAlerts(r.alerts || [])).catch(() => setAlerts([]));
    if (tab === 'intents') safeFetch(`${BASE}/intents?limit=200`, { retryOnTimeout: false }).then((r: any) => setIntents(r.intents || [])).catch(() => setIntents([]));
  }, [tab, page?.checked_at]);

  const controlsOf = useCallback((id: string) => {
    const c = registry[id];
    if (c) return c.controls;
    // a per-connection check is registered by the watcher each cycle; the catalogue may lag
    if (id.startsWith('dependency:connection:')) return ['reset_breaker', 'probe_now'];
    if (id.startsWith('dependency:sftp:')) return ['probe_now'];
    return [];
  }, [registry]);

  const allowed = !!page?.controls_allowed;
  const match = (r: { label: string; component_id: string; reason: string; state: HealthState }) =>
    (!filter || `${r.label} ${r.component_id} ${r.reason}`.toLowerCase().includes(filter.toLowerCase()))
    && (!stateFilter || r.state === stateFilter);

  const { dependencies, daemons } = useMemo(() => {
    const fleet = page?.fleet || [];
    return {
      dependencies: fleet.filter(r => r.kind !== 'daemon').filter(match),
      daemons: fleet.filter(r => r.kind === 'daemon').filter(match),
    };
  }, [page, filter, stateFilter]);

  const onDone = (msg: string) => { setNotice(msg); load(); };

  return (
    <Box>
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1 }}>
        <Box>
          <Typography variant="h6">Component Health</Typography>
          <Typography variant="caption" color="text.secondary">
            every pod, daemon and dependency as ONE state with a reason · read {page ? fmtAge(page.checked_at) : '—'}
            {page?.this_pod?.pod_id ? ` · answered by ${page.this_pod.pod_id}` : ''}
            {page?.thresholds ? ` · unknown after ${page.thresholds.stale_after_seconds}s, a pod down after ${page.thresholds.pod_down_after_seconds}s` : ''}
          </Typography>
        </Box>
        <Button size="small" variant="outlined" startIcon={<RefreshIcon />} onClick={load} aria-label="Refresh component health">Refresh</Button>
      </Stack>

      {loadError && (
        <Alert severity="error" sx={{ mb: 1 }} data-testid="health-load-error">
          Could not read the component table: {loadError}
          {page ? ' — showing the last page that loaded.' : ''}
          {page?.this_pod?.rows_from_memory?.length ? ` This pod (${page.this_pod.pod_id}) has ${page.this_pod.rows_from_memory.length} rows in memory.` : ''}
        </Alert>
      )}
      {notice && <Alert severity="success" sx={{ mb: 1 }} onClose={() => setNotice(null)}>{notice}</Alert>}
      {!page && !loadError && <CircularProgress size={24} />}
      {page && !loadError && page.read?.reason && <Alert severity="info" sx={{ mb: 1 }}>{page.read.reason}</Alert>}

      {page && (
        <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap sx={{ mb: 2 }}>
          <Paper variant="outlined" sx={{ p: 2, flex: 1, minWidth: 140 }}>
            <Typography variant="caption" color="text.secondary">headline</Typography>
            <Box sx={{ mt: 0.5 }}><StateChip state={page.headline} size="medium" /></Box>
          </Paper>
          <StatCard label="healthy" value={page.summary.healthy} />
          <StatCard label="degraded" value={page.summary.degraded} warn={page.summary.degraded > 0} />
          <StatCard label="down" value={page.summary.down} warn={page.summary.down > 0} />
          <StatCard label="unknown" value={page.summary.unknown} warn={page.summary.unknown > 0} sub="unknown is not healthy" />
          <StatCard label="pods reporting" value={page.pods.length} />
          <StatCard label="open intents" value={(page.intents || []).filter(i => i.status === 'pending').length} />
          {!allowed && <StatCard label="your access" value="read-only" sub="the support role sees, admins act" />}
        </Stack>
      )}

      <Tabs value={tab} onChange={(_e, v) => setTab(v)} sx={{ mb: 1 }} aria-label="component health tabs">
        <Tab value="health" label="Health" />
        <Tab value="thispod" label="This pod" />
        <Tab value="selftest" label="Self-test" />
        <Tab value="ticks" label="Daemon ticks" />
        <Tab value="posture" label="Posture" />
        <Tab value="history" label="History" />
        <Tab value="alerts" label="Alerts" />
        <Tab value="intents" label="Intents" />
      </Tabs>

      {tab === 'health' && page && (
        <Stack spacing={2}>
          <Stack direction="row" spacing={1} alignItems="center">
            <TextField size="small" label="Filter" value={filter} onChange={e => setFilter(e.target.value)} inputProps={{ 'aria-label': 'filter components' }} />
            {(['', 'down', 'degraded', 'unknown', 'healthy'] as const).map(s => (
              <Chip key={s || 'all'} label={s || 'all'} size="small" variant={stateFilter === s ? 'filled' : 'outlined'}
                onClick={() => setStateFilter(s as HealthState | '')} />
            ))}
          </Stack>
          <Typography variant="subtitle1" fontWeight={700}>Pods ({page.pods.length})</Typography>
          <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
            {page.pods.filter(p => !stateFilter || p.state === stateFilter).map(p => (
              <PodCardView key={p.pod_id} pod={p} controlsOf={controlsOf} allowed={allowed} onControl={setControl} onOpen={setDrawer} />
            ))}
            {page.pods.length === 0 && <Typography variant="body2" color="text.secondary">no pod has reported yet</Typography>}
          </Stack>
          <FleetTable title="Dependencies" rows={dependencies} controlsOf={controlsOf} allowed={allowed} onControl={setControl} onOpen={setDrawer} />
          <FleetTable title="Daemons (fleet verdict)" rows={daemons} controlsOf={controlsOf} allowed={allowed} onControl={setControl} onOpen={setDrawer} showPods />
        </Stack>
      )}
      {tab === 'thispod' && <ThisPodPanel />}
      {tab === 'selftest' && <SelfTestPanel />}
      {tab === 'ticks' && <BackgroundJobsSection />}
      {tab === 'posture' && <EffectivePostureSection />}
      {tab === 'history' && (
        <Paper variant="outlined" sx={{ p: 1.5 }}>
          <Typography variant="subtitle1" fontWeight={700}>Confirmed transitions</Typography>
          {events === null ? <CircularProgress size={20} /> : events.length === 0 ? (
            <Typography variant="body2" color="text.secondary">no confirmed transition recorded</Typography>
          ) : events.map(e => (
            <Typography key={e.id} variant="body2">{e.at} · {e.component_id}{e.pod_id && e.pod_id !== '@fleet' ? ` on ${e.pod_id}` : ''}: {e.from_state || '∅'} → <b>{e.to_state}</b>{e.by ? ` by ${e.by}` : ''} — {e.reason}</Typography>
          ))}
        </Paper>
      )}
      {tab === 'alerts' && (
        <Paper variant="outlined" sx={{ p: 1.5 }}>
          <Typography variant="subtitle1" fontWeight={700}>Component alerts (the one alert road)</Typography>
          {alerts === null ? <CircularProgress size={20} /> : alerts.length === 0 ? (
            <Typography variant="body2" color="text.secondary">no component alert</Typography>
          ) : alerts.map(a => (
            <Typography key={a.id} variant="body2">#{a.id} <b>{a.status}</b> {a.kind} sev {a.severity}: {a.title} — {a.message} · {(a.deliveries || []).map((d: any) => `${d.channel} ${d.status}`).join(', ')}</Typography>
          ))}
        </Paper>
      )}
      {tab === 'intents' && (
        <Paper variant="outlined" sx={{ p: 1.5 }}>
          <Typography variant="subtitle1" fontWeight={700}>Intents (controls applied by their owner)</Typography>
          {intents === null ? <CircularProgress size={20} /> : intents.length === 0 ? (
            <Typography variant="body2" color="text.secondary">no intent recorded</Typography>
          ) : intents.map(i => (
            <Stack key={i.id} direction="row" spacing={1} alignItems="center" sx={{ py: 0.25 }}>
              <Typography variant="body2">#{i.id} <b>{i.control}</b> {i.component_id} → {i.target_pod_id}: <b>{i.status}</b> (by {i.requested_by} at {i.requested_at}: {i.reason}){i.expires_at ? ` · expires ${i.expires_at}` : ''} · applied on {Object.keys(i.applied_by_pods || {}).join(', ') || 'nobody yet'}</Typography>
              {i.status === 'pending' && (
                <Button size="small" disabled={!allowed} onClick={async () => {
                  try { await safeFetch(`${BASE}/intents/${i.id}`, { method: 'DELETE', retryOnTimeout: false }); onDone(`intent #${i.id} withdrawn`); setTab('intents'); }
                  catch (e: any) { setNotice(`withdraw failed: ${e?.message || e}`); }
                }}>Withdraw</Button>
              )}
            </Stack>
          ))}
        </Paper>
      )}

      <Divider sx={{ my: 2 }} />
      <Typography variant="caption" color="text.secondary">
        Pods write their own rows every {page?.thresholds?.report_interval_seconds ?? 15} s; dependencies are probed once for everyone on the scheduler-lock holder every {page?.thresholds?.dependency_probe_interval_seconds ?? 30} s; this page polls every {POLL_MS / 1000} s and never probes.
      </Typography>

      <DetailDrawer componentId={drawer} onClose={() => setDrawer(null)} />
      <ControlDialog request={control} onClose={() => setControl(null)} onDone={onDone} />
    </Box>
  );
};

export default ComponentHealthSection;
