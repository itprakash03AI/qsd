/**
 * The four states as four DISTINCT chips (never a fifth); a disposition
 * (paused / draining / disabled by config / deferred) is a word beside the
 * state, never a colour of its own.
 */
import React from 'react';
import { Chip, Tooltip } from '@mui/material';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import WarningIcon from '@mui/icons-material/Warning';
import ErrorIcon from '@mui/icons-material/Error';
import HelpOutlineIcon from '@mui/icons-material/HelpOutline';
import type { HealthState } from './types';

const META: Record<HealthState, { color: 'success' | 'warning' | 'error' | 'default'; icon: React.ReactElement; label: string }> = {
  healthy:  { color: 'success', icon: <CheckCircleIcon sx={{ fontSize: '14px !important' }} />, label: 'healthy' },
  degraded: { color: 'warning', icon: <WarningIcon sx={{ fontSize: '14px !important' }} />, label: 'degraded' },
  down:     { color: 'error',   icon: <ErrorIcon sx={{ fontSize: '14px !important' }} />, label: 'down' },
  unknown:  { color: 'default', icon: <HelpOutlineIcon sx={{ fontSize: '14px !important' }} />, label: 'unknown' },
};

const DISPOSITION_WORDS: Record<string, string> = {
  paused: 'paused', disabled_by_config: 'off by config', draining: 'draining',
  deferred: 'deferred', declined: 'declined',
};

const StateChip: React.FC<{ state: HealthState; disposition?: string | null; reason?: string | null; size?: 'small' | 'medium' }> =
  ({ state, disposition, reason, size = 'small' }) => {
    const m = META[state] ?? META.unknown;
    const chip = (
      <Chip size={size} icon={m.icon} label={m.label} color={m.color}
        variant={state === 'unknown' ? 'outlined' : 'filled'}
        data-state={state} data-disposition={disposition || undefined}
        sx={state === 'unknown' ? { borderColor: '#6e40c9', color: '#6e40c9' } : undefined} />
    );
    return (
      <span style={{ display: 'inline-flex', gap: 4, alignItems: 'center' }}>
        {reason ? <Tooltip title={reason} arrow>{chip}</Tooltip> : chip}
        {disposition && (
          <Chip size="small" variant="outlined" label={DISPOSITION_WORDS[disposition] || disposition}
            data-testid={`disposition-${disposition}`} />
        )}
      </span>
    );
  };

export default StateChip;
