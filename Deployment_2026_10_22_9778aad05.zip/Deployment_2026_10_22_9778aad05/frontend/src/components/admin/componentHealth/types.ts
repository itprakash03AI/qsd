/**
 * Component health, one place (2026-10-17) -- the server's shapes.
 * Source: GET /api/admin/component-health (core/component_health/reader.py).
 */
export type HealthState = 'healthy' | 'degraded' | 'down' | 'unknown';

export interface HealthRow {
  pod_id: string;
  component_id: string;
  kind: 'pod' | 'daemon' | 'dependency';
  scope: 'per_pod' | 'singleton' | 'fleet';
  label: string;
  group: string | null;
  state: HealthState;
  observed_state?: HealthState;
  disposition: string | null;
  reason: string;
  evidence: string | null;
  metrics: Record<string, any>;
  pod_role: string | null;
  build: string | null;
  checked_at: string | null;
  reported_at: string | null;
  interval_seconds: number | null;
  probe_ms: number | null;
  state_since: string | null;
  confirmations: number | null;
  muted_by_intent: number | null;
  alert_id: number | null;
  silent_seconds?: number | null;
  inherited?: boolean;
}

export interface PodCard {
  pod_id: string;
  pod_role: string | null;
  build: string | null;
  state: HealthState;
  reason: string | null;
  reported_at: string | null;
  disposition?: string | null;
  silent_seconds?: number | null;
  metrics?: Record<string, any>;
  summary: Record<HealthState, number>;
  components: HealthRow[];
}

export interface Intent {
  id: number;
  control: string;
  component_id: string;
  target_pod_id: string;
  requested_by: string;
  requested_at: string;
  reason: string;
  expires_at: string | null;
  status: string;
  applied_by_pods: Record<string, { at: string; outcome: string; detail: string }>;
  consequence: string | null;
}

export interface HealthPage {
  checked_at: string;
  read: { ok: boolean; reason: string | null };
  thresholds: Record<string, number>;
  summary: Record<HealthState, number>;
  headline: HealthState;
  pods: PodCard[];
  fleet: HealthRow[];
  intents: Intent[];
  controls_allowed: boolean;
  this_pod: { pod_id: string; rows_from_memory: HealthRow[]; last_cycle: Record<string, any>; draining: Record<string, any> };
  etag?: string;
  filtered?: boolean;
}

export interface DeclaredCheck {
  component_id: string;
  kind: string;
  label: string;
  scope: string;
  owner: string;
  timeout_seconds: number;
  interval_seconds: number;
  controls: string[];
  legacy_routes: string[];
  group: string;
  docs: string;
}

export interface HealthEvent {
  id: number;
  component_id: string;
  pod_id: string | null;
  from_state: HealthState | null;
  to_state: HealthState;
  reason: string | null;
  at: string;
  by: string | null;
  intent_id: number | null;
  alert_id: number | null;
}

export const STATE_ORDER: HealthState[] = ['down', 'degraded', 'unknown', 'healthy'];

export const CONTROL_LABELS: Record<string, string> = {
  pause: 'Pause', resume: 'Resume', run_now: 'Run now', drain: 'Drain', undrain: 'Undrain',
  reset_breaker: 'Reset breaker', rerun_self_test: 'Re-run self-test', probe_now: 'Probe now',
};

/** The controls that are an intent row the owner applies (202, pending). */
export const INTENT_CONTROLS = new Set(['drain', 'undrain', 'reset_breaker', 'rerun_self_test', 'probe_now']);

export function ageSeconds(iso: string | null | undefined): number | null {
  if (!iso) return null;
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return null;
  return Math.max(0, Math.round((Date.now() - t) / 1000));
}

export function fmtAge(iso: string | null | undefined): string {
  const s = ageSeconds(iso);
  if (s === null) return '—';
  if (s < 90) return `${s}s ago`;
  if (s < 5400) return `${Math.round(s / 60)}m ago`;
  return `${Math.round(s / 3600)}h ago`;
}
