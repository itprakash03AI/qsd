/**
 * Self-test -- the deleted Self-Test Diagnostics screen, kept whole (folded
 * 2026-10-17): Run pruning / Run system / Run all against
 * /api/health/self-test[/pruning|/system] (read-only suites, < 1 s, any
 * logged-in user), the summary, and one row per check with PASS / FAIL /
 * SKIP, suite, name, duration and details / error.  The suites run on the
 * pod that answers; "Re-run self-test" on a pod card runs them on THAT pod
 * through an intent and keeps the summary on its row.
 */
import React, { useCallback, useState } from 'react';
import {
  Alert, Button, Chip, CircularProgress, Paper, Stack, Table, TableBody, TableCell, TableContainer, TableHead,
  TableRow, Tooltip, Typography,
} from '@mui/material';
import { safeFetch } from '../../../services/api/core';

interface SelfTestResult {
  id: string; name: string; status: 'pass' | 'fail' | 'skip'; duration_ms: number;
  details?: string; error?: string; suite?: string;
}

const SelfTestPanel: React.FC = () => {
  const [results, setResults] = useState<SelfTestResult[]>([]);
  const [summary, setSummary] = useState<{ passed: number; failed: number; total: number; timestamp?: string } | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const runSuite = useCallback(async (suite: 'pruning' | 'system' | 'all') => {
    setBusy(suite); setError(null);
    try {
      const url = suite === 'all' ? '/api/health/self-test' : `/api/health/self-test/${suite}`;
      const resp: any = await safeFetch(url, { retryOnTimeout: false, timeoutMs: 30_000 });
      const tagged: SelfTestResult[] = (resp.tests || []).map((t: any) => ({ ...t, suite: t.suite || suite }));
      if (suite === 'all') setResults(tagged);
      else setResults(prev => [...prev.filter(r => !r.id.startsWith(`${suite}.`)), ...tagged]);
      setSummary({ passed: resp.passed, failed: resp.failed, total: resp.total, timestamp: resp.timestamp });
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setBusy(null);
    }
  }, []);

  const statusChip = (s: SelfTestResult['status']) =>
    s === 'pass' ? <Chip size="small" color="success" label="PASS" data-status="pass" />
      : s === 'fail' ? <Chip size="small" color="error" label="FAIL" data-status="fail" />
        : <Chip size="small" variant="outlined" label="SKIP" data-status="skip" />;

  return (
    <Paper variant="outlined" sx={{ p: 1.5 }} data-testid="self-test-panel">
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }} flexWrap="wrap" useFlexGap>
        <Typography variant="subtitle1" fontWeight={700}>Self-test diagnostics (this pod)</Typography>
        {/* describeChild: the tooltip DESCRIBES the button; without it MUI makes the
            title the button's accessible name and "Run pruning" disappears */}
        <Tooltip describeChild title="Run only the BF-600 pruning self-tests (boolean, NOT IN, decimal, LIKE prefix, IS NOT NULL, function-wrap, L1-L4)">
          <Button size="small" variant="outlined" disabled={!!busy} onClick={() => runSuite('pruning')}>Run pruning</Button>
        </Tooltip>
        <Tooltip describeChild title="Run the system self-tests (DuckDB engine, DB ping, per-worker memory, loop watchdog, httpfs prefix)">
          <Button size="small" variant="outlined" disabled={!!busy} onClick={() => runSuite('system')}>Run system</Button>
        </Tooltip>
        <Button size="small" variant="contained" disabled={!!busy} onClick={() => runSuite('all')}>Run all</Button>
        {busy && <CircularProgress size={16} />}
      </Stack>
      {error && <Alert severity="error">Self-test failed to run: {error}</Alert>}
      {summary && (
        <Alert severity={summary.failed === 0 ? 'success' : 'error'} sx={{ mb: 1 }} data-testid="self-test-summary">
          {summary.passed}/{summary.total} passed{summary.failed ? `, ${summary.failed} failed` : ''}
          {' · '}{Math.round(results.reduce((s, t) => s + (t.duration_ms || 0), 0))} ms total
          {summary.timestamp ? ` · ${summary.timestamp}` : ''}
        </Alert>
      )}
      {results.length === 0 ? (
        <Typography variant="body2" color="text.secondary">Click <strong>Run all</strong> to execute both suites.</Typography>
      ) : (
        <TableContainer sx={{ maxHeight: 480 }}>
          <Table size="small" stickyHeader aria-label="self-test results">
            <TableHead>
              <TableRow>
                <TableCell sx={{ width: 90 }}>Status</TableCell><TableCell sx={{ width: 90 }}>Suite</TableCell>
                <TableCell>Test</TableCell><TableCell align="right" sx={{ width: 100 }}>Duration</TableCell>
                <TableCell>Details / error</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {results.map(r => (
                <TableRow key={r.id} hover data-testid={`self-test-${r.id}`}
                  sx={{ backgroundColor: r.status === 'fail' ? 'rgba(207,34,46,0.08)' : undefined }}>
                  <TableCell>{statusChip(r.status)}</TableCell>
                  <TableCell><Chip size="small" variant="outlined" label={r.suite || r.id.split('.')[0]} /></TableCell>
                  <TableCell>
                    <Typography variant="body2">{r.name}</Typography>
                    <Typography variant="caption" color="text.secondary" sx={{ fontFamily: 'monospace' }}>{r.id}</Typography>
                  </TableCell>
                  <TableCell align="right"><Typography variant="caption">{(r.duration_ms ?? 0).toFixed(2)} ms</Typography></TableCell>
                  <TableCell sx={{ maxWidth: 380 }}>
                    <Typography variant="caption" color={r.error ? 'error' : 'text.secondary'}>{r.error || r.details || '—'}</Typography>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Paper>
  );
};

export default SelfTestPanel;
