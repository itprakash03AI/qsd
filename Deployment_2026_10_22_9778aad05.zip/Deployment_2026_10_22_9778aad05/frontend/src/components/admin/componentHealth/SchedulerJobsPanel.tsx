/**
 * Scheduler jobs -- the deleted Scheduler screen's table, kept whole (folded
 * 2026-10-17): status (Not Init / Paused / Running), job count, and every
 * APScheduler job (name, next run, paused / active) from
 * /api/admin/scheduler (proxied to the scheduler worker in external mode).
 * Pause / Resume are the dependency:scheduler row's controls on the page
 * (audited, with the consequence); this panel is the READ.
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Button, Chip, Paper, Stack, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography,
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import { safeFetch } from '../../../services/api/core';
import StatCard from '../StatCard';
import ListPager, { clientPage } from '../../common/ListPager';
import { fmtDate } from '../adminUtils';

const SchedulerJobsPanel: React.FC = () => {
  const [status, setStatus] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(50);

  const load = useCallback(async () => {
    try {
      setStatus(await safeFetch('/api/admin/scheduler', { retryOnTimeout: false, timeoutMs: 15_000 }));
      setError(null);
    } catch (e: any) {
      setError(e?.message || String(e));
    }
  }, []);
  useEffect(() => { load(); }, [load]);

  const jobs: any[] = status?.jobs || [];
  const paged = clientPage(jobs, page, size);
  return (
    <Paper variant="outlined" sx={{ p: 1.5 }} data-testid="scheduler-jobs-panel">
      <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1 }}>
        <Typography variant="subtitle1" fontWeight={700}>Scheduler jobs (/api/admin/scheduler)</Typography>
        <Button size="small" variant="outlined" startIcon={<RefreshIcon />} onClick={load} aria-label="Refresh scheduler jobs">Refresh</Button>
      </Stack>
      {error && <Alert severity="error">Could not read the scheduler: {error}</Alert>}
      {status && (
        <>
          <Stack direction="row" spacing={2} mb={1} flexWrap="wrap" useFlexGap>
            <StatCard label="Status" value={!status.initialized ? 'Not Init' : status.paused ? 'Paused' : 'Running'} warn={!!status.paused} />
            <StatCard label="Jobs" value={status.job_count ?? jobs.length} />
          </Stack>
          <Typography variant="caption" color="text.secondary">
            {status.paused ? 'All scheduled jobs are paused; running jobs finish normally. Resume from the scheduler row.'
              : 'Pause from the scheduler row stops new job triggers (audited).'}
          </Typography>
          {jobs.length > 0 && (
            <TableContainer sx={{ mt: 1 }}>
              <Table size="small" aria-label="scheduler jobs">
                <TableHead><TableRow><TableCell>Job</TableCell><TableCell>Next run</TableCell><TableCell>Paused?</TableCell></TableRow></TableHead>
                <TableBody>
                  {paged.rows.map((j: any) => (
                    <TableRow key={j.id || j.name} hover data-testid={`scheduler-job-${j.id || j.name}`}>
                      <TableCell sx={{ fontSize: '0.78rem' }}>{j.name || j.id}<Typography variant="caption" display="block" color="text.secondary" sx={{ fontFamily: 'monospace' }}>{j.id}</Typography></TableCell>
                      <TableCell sx={{ fontSize: '0.75rem' }}>{(j.next_run || j.next_run_time) ? fmtDate(j.next_run || j.next_run_time) : '—'}</TableCell>
                      <TableCell><Chip size="small" variant="outlined" label={j.paused ? 'Paused' : 'Active'} color={j.paused ? 'warning' : 'success'} /></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <ListPager paging={paged.paging} onPage={setPage} onPageSize={setSize} testid="scheduler-jobs-pager" />
            </TableContainer>
          )}
        </>
      )}
    </Paper>
  );
};

export default SchedulerJobsPanel;
