/**
 * "This pod" -- what the deleted System Health and Operations Dashboard
 * screens showed about the pod that answers the request, kept verbatim and
 * read from the same routes (folded 2026-10-17):
 *
 *   /health                         status word, DB ok/type, S3, Redis, disk,
 *                                   queries (active / global limit / per-user /
 *                                   queue waiting), workers ledger, db_health,
 *                                   degraded_reasons
 *   /api/admin/memory-guard/status  admission blocked / OK, available MB,
 *                                   in-flight queries + MB, blocks lifetime,
 *                                   the in-flight list
 *   /api/admin/circuit-breakers     EVERY connection's breaker (closed ones too)
 *
 * These are per-PROCESS facts of the serving pod; the fleet view of the same
 * numbers is on each pod's card (pod:self metrics).
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, Divider, Paper, Stack, Table, TableBody, TableCell, TableContainer, TableHead,
  TableRow, Typography,
} from '@mui/material';
import RefreshIcon from '@mui/icons-material/Refresh';
import { safeFetch } from '../../../services/api/core';
import StatCard from '../StatCard';
import StatusChip from '../StatusChip';

const ThisPodPanel: React.FC = () => {
  const [health, setHealth] = useState<any>(null);
  const [memGuard, setMemGuard] = useState<any>(null);
  const [breakers, setBreakers] = useState<any[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    const opts = { retryOnTimeout: false, timeoutMs: 15_000 };
    const [h, mg, cb] = await Promise.all([
      safeFetch('/health', opts).catch((e: any) => ({ __error: e?.message || String(e) })),
      safeFetch('/api/admin/memory-guard/status', opts).catch((e: any) => ({ __error: e?.message || String(e) })),
      safeFetch('/api/admin/circuit-breakers', opts).catch((e: any) => ({ __error: e?.message || String(e) })),
    ]);
    const errs = [h, mg, cb].filter((x: any) => x?.__error).map((x: any) => x.__error);
    setError(errs.length ? errs.join('; ') : null);
    if (!h?.__error) setHealth(h);
    if (!mg?.__error) setMemGuard(mg);
    if (!cb?.__error) {
      const list = Array.isArray(cb) ? cb : Array.isArray(cb?.circuit_breakers) ? cb.circuit_breakers
        : cb?.circuit_breakers ? Object.entries(cb.circuit_breakers).map(([k, v]: any) => ({ connection_id: k, ...(v || {}) })) : [];
      setBreakers(list);
    }
  }, []);

  useEffect(() => {
    load();
    const t = setInterval(load, 15_000);
    return () => clearInterval(t);
  }, [load]);

  const q = health?.queries || {};
  const w = health?.workers || {};
  return (
    <Stack spacing={2}>
      <Stack direction="row" justifyContent="space-between" alignItems="center">
        <Typography variant="subtitle1" fontWeight={700}>This pod (the one that answered)</Typography>
        <Button size="small" variant="outlined" startIcon={<RefreshIcon />} onClick={load} aria-label="Refresh this pod">Refresh</Button>
      </Stack>
      {error && <Alert severity="error" data-testid="this-pod-error">Could not read: {error}</Alert>}

      {health && (
        <Paper variant="outlined" sx={{ p: 1.5 }} data-testid="this-pod-health">
          <Typography variant="subtitle2" sx={{ mb: 1 }}>/health</Typography>
          <Stack direction="row" spacing={1} mb={1} flexWrap="wrap" useFlexGap>
            <StatusChip ok={health.status === 'healthy'} label={String(health.status || 'unknown').toUpperCase()} />
            <StatusChip ok={!!health.database?.ok} label={`DB: ${health.database?.ok ? 'OK' : 'Error'} (${health.database?.type || '?'})`} />
            <StatusChip ok={health.s3?.status === 'connected' || health.s3?.status === 'not_configured'} label={`S3: ${health.s3?.status || 'n/a'}`} />
            <StatusChip ok={health.redis?.status === 'connected' || health.redis?.status === 'not_configured'} label={`Redis: ${health.redis?.status || 'n/a'}`} />
            {health.disk?.warning && <Chip size="small" label="Low Disk" color="warning" />}
            {(health.degraded_reasons || []).map((r: string) => <Chip key={r} size="small" color="warning" variant="outlined" label={`degraded: ${r}`} />)}
          </Stack>
          <Stack direction="row" spacing={2} flexWrap="wrap" useFlexGap>
            <StatCard label="Active Queries" value={q.active ?? '—'} warn={(q.active ?? 0) >= (q.max_concurrent_global ?? 99)} />
            <StatCard label="Global Limit" value={q.max_concurrent_global ?? '—'} />
            <StatCard label="Per-User Limit" value={q.per_user_limit ?? '—'} />
            <StatCard label="Queue Waiting" value={q.queue_waiting_known === false ? 'unknown' : (q.queue_waiting ?? '—')}
              warn={(q.queue_waiting ?? 0) > 0} sub={q.queue_waiting_known === false ? 'this pod has no pool to ask' : `max queue ${q.max_queue_size ?? '—'}`} />
            <StatCard label="Disk Free" value={`${health.disk?.free_gb ?? '—'} GB`} warn={!!health.disk?.warning} sub={`${health.disk?.used_pct ?? '—'}% used`} />
            {w.known && <StatCard label="Server processes" value={`${w.alive ?? '—'}/${w.configured ?? '—'}`}
              warn={(w.died ?? 0) > 0 || (w.oom_kill ?? 0) > 0} sub={`died ${w.died ?? 0} · respawns ${w.respawns ?? 0} · oom_kill ${w.oom_kill ?? 0}`} />}
            {health.db_health && <StatCard label="DB latency p95" value={`${health.db_health.recent_p95_ms ?? '—'} ms`}
              warn={!!health.db_health.degraded} sub={health.db_health.degraded ? 'DEGRADED' : 'ok'} />}
          </Stack>
        </Paper>
      )}

      {memGuard && (
        <Paper variant="outlined" sx={{ p: 1.5 }} data-testid="this-pod-memory-guard">
          <Typography variant="subtitle2" sx={{ mb: 1 }}>Memory guard (/api/admin/memory-guard/status)</Typography>
          <Alert severity={memGuard.admission_blocked ? 'warning' : 'success'} sx={{ mb: 1 }}>
            <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
              <Typography variant="body2">
                {memGuard.admission_blocked
                  ? 'Memory_guard: admission BLOCKED — new queries refused until RAM recovers'
                  : 'Memory_guard: admission OK'}
              </Typography>
              <Chip size="small" label={`available: ${memGuard.last_sample_mb ?? '?'} MB`} />
              <Chip size="small" label={`inflight: ${memGuard.inflight_count ?? 0} queries (${memGuard.inflight_total_mb ?? 0} MB)`} />
              <Chip size="small" label={`blocks lifetime: ${memGuard.admission_blocks_total ?? 0}`} variant="outlined" />
              <Chip size="small" label={`watchdog ${memGuard.running ? 'running' : 'stopped'}`} variant="outlined" />
            </Stack>
          </Alert>
          {Array.isArray(memGuard.inflight_queries) && memGuard.inflight_queries.length > 0 && (
            <TableContainer sx={{ maxHeight: 240 }}>
              <Table size="small" stickyHeader aria-label="in-flight queries">
                <TableHead><TableRow>{Object.keys(memGuard.inflight_queries[0]).slice(0, 6).map(k => <TableCell key={k}>{k}</TableCell>)}</TableRow></TableHead>
                <TableBody>
                  {memGuard.inflight_queries.map((row: any, i: number) => (
                    <TableRow key={i}>{Object.keys(memGuard.inflight_queries[0]).slice(0, 6).map(k => (
                      <TableCell key={k} sx={{ fontSize: '0.75rem' }}>{typeof row[k] === 'object' ? JSON.stringify(row[k]) : String(row[k] ?? '—')}</TableCell>
                    ))}</TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </Paper>
      )}

      {breakers !== null && (
        <Paper variant="outlined" sx={{ p: 1.5 }} data-testid="this-pod-breakers">
          <Typography variant="subtitle2" sx={{ mb: 1 }}>Connection circuit breakers on this pod (/api/admin/circuit-breakers)</Typography>
          {breakers.length === 0 ? (
            <Typography variant="body2" color="text.secondary">No circuit breaker data yet (a breaker appears once a connection has been used)</Typography>
          ) : (
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
              {breakers.map((cb: any) => (
                <Chip key={cb.connection_id} size="small" variant="outlined"
                  label={`${cb.connection_name || `Conn #${cb.connection_id}`}: ${cb.state}${cb.failure_count ? ` (${cb.failure_count} failures)` : ''}`}
                  color={String(cb.state).toLowerCase() === 'closed' ? 'success' : String(cb.state).toLowerCase() === 'open' ? 'error' : 'warning'}
                  data-testid={`breaker-${cb.connection_id}`} />
              ))}
            </Box>
          )}
          <Divider sx={{ my: 1 }} />
          <Typography variant="caption" color="text.secondary">
            An OPEN breaker is reset from its connection's row in the Dependencies table (applied on every pod).
          </Typography>
        </Paper>
      )}
    </Stack>
  );
};

export default ThisPodPanel;
