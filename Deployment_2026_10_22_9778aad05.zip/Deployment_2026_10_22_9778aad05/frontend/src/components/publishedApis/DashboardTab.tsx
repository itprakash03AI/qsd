/**
 * The Published APIs DASHBOARD (2026-10-17, design §3.9): the numbers the
 * rollup daemon produced (GET /api/published-apis/metrics, /metrics/top,
 * /idle, /health), never the hot path.  Every tile says "to HH:MM" -- the
 * rollup's watermark -- and the percentile tiles say their METHOD (exact for
 * one small API, else the histogram with its bin).  A number that could not
 * be read is said as unknown with the reason, never shown as 0.
 */
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Alert, Box, Chip, CircularProgress, FormControl, InputLabel, MenuItem, Paper, Select, Stack, Table,
  TableBody, TableCell, TableHead, TableRow, ToggleButton, ToggleButtonGroup, Tooltip, Typography,
} from '@mui/material';
import {
  Bar, BarChart, CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip as ChartTip, XAxis, YAxis,
} from 'recharts';
import api from '../../services/api';
import { fmtBytes, fmtInt, fmtPct, numbersEndAt, type PublishedApiRow } from './types';

type Range = '24h' | '7d' | '30d';
const RANGE_HOURS: Record<Range, number> = { '24h': 24, '7d': 24 * 7, '30d': 24 * 30 };
const COLORS = ['#1976d2', '#9c27b0', '#ff9800', '#2e7d32', '#d32f2f', '#0288d1', '#7b1fa2', '#f57c00', '#388e3c', '#c2185b'];

interface Props {
  apis: PublishedApiRow[];
  /** the API picked from the inventory (?api=) */
  initialKind?: string | null;
  initialApi?: string | null;
}

const pct = (p: any) => (p && p.value_ms != null ? `${Math.round(p.value_ms)} ms` : '—');
const pctRes = (p: any) => (p && p.lo_ms != null ? `bin ${Math.round(p.lo_ms)}–${Math.round(p.hi_ms)} ms` : '');

function Tile({ label, value, sub, testid }: { label: string; value: React.ReactNode; sub?: string; testid?: string }) {
  return (
    <Paper variant="outlined" sx={{ p: 1.5, minWidth: 150, flex: '1 1 150px' }} data-testid={testid}>
      <Typography variant="caption" color="text.secondary">{label}</Typography>
      <Typography variant="h6" fontWeight={600} sx={{ lineHeight: 1.2 }}>{value}</Typography>
      {sub && <Typography variant="caption" color="text.secondary">{sub}</Typography>}
    </Paper>
  );
}

export default function DashboardTab({ apis, initialKind, initialApi }: Props) {
  const [range, setRange] = useState<Range>('24h');
  const [groupBy, setGroupBy] = useState<'api' | 'consumer' | 'none'>('api');
  const [kind, setKind] = useState<string>(initialKind || '');
  const [apiKey, setApiKey] = useState<string>(initialApi || '');
  const [consumer, setConsumer] = useState<string>('');
  const [series, setSeries] = useState<any>(null);
  const [top, setTop] = useState<any>(null);
  const [idle, setIdle] = useState<any>(null);
  const [health, setHealth] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const grain = range === '30d' ? 'day' : 'hour';
    const to = new Date();
    const from = new Date(to.getTime() - RANGE_HOURS[range] * 3600 * 1000);
    const params: Record<string, any> = { from: from.toISOString(), to: to.toISOString(), grain, group_by: groupBy };
    if (apiKey) { params.api = apiKey; params.kind = kind || 'published_view'; } else if (kind) params.kind = kind;
    if (consumer) params.consumer = consumer;
    const a: any = api;
    const [s, t, i, h] = await Promise.allSettled([
      a.publishedApiMetrics(params),
      a.publishedApiTop({ window: range, by: 'calls', n: 10 }),
      a.publishedApiIdle(),
      a.publishedApiHealth(),
    ]);
    if (s.status === 'fulfilled') setSeries(s.value); else { setSeries(null); setError(s.reason?.message || 'the numbers could not be read'); }
    setTop(t.status === 'fulfilled' ? t.value : { error: t.reason?.message || 'unreadable' });
    setIdle(i.status === 'fulfilled' ? i.value : { error: i.reason?.message || 'unreadable' });
    setHealth(h.status === 'fulfilled' ? h.value : { error: h.reason?.message || 'unreadable' });
    setLoading(false);
  }, [range, groupBy, kind, apiKey, consumer]);

  useEffect(() => { load(); }, [load]);

  const totals = series?.totals || null;
  const endAt = numbersEndAt(series?.watermark?.numbers_end_at);
  const wmState = series?.watermark?.state;

  // cells -> one row per bucket with a column per group
  const { chartRows, groups } = useMemo(() => {
    const cells: any[] = series?.cells || [];
    const byBucket = new Map<string, any>();
    const gs = new Set<string>();
    cells.forEach(c => {
      const b = String(c.bucket_start);
      const row = byBucket.get(b) || { bucket: b, label: new Date(b).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit' }), errors: 0, p95: null, calls_total: 0 };
      row[c.group] = (row[c.group] || 0) + (c.calls || 0);
      row.calls_total += c.calls || 0;
      row.errors += (c.client_4xx || 0) + (c.server_5xx || 0);
      if (c.p95 && c.p95.value_ms != null) row.p95 = Math.max(row.p95 || 0, c.p95.value_ms);
      gs.add(c.group);
      byBucket.set(b, row);
    });
    return { chartRows: Array.from(byBucket.values()), groups: Array.from(gs).slice(0, 10) };
  }, [series]);

  const consumers = useMemo(() => {
    const names = new Set<string>();
    apis.forEach(a => (a.consumers || []).forEach(c => c.identity && names.add(c.identity)));
    return Array.from(names).sort();
  }, [apis]);

  const refusals = totals?.refused ? Object.values(totals.refused as Record<string, number>).reduce((x: number, y: any) => x + Number(y || 0), 0) : null;

  return (
    <Box>
      <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" sx={{ mb: 2 }}>
        <ToggleButtonGroup size="small" exclusive value={range} onChange={(_, v) => v && setRange(v)} aria-label="range">
          <ToggleButton value="24h">24 h</ToggleButton>
          <ToggleButton value="7d">7 d</ToggleButton>
          <ToggleButton value="30d">30 d</ToggleButton>
        </ToggleButtonGroup>
        <ToggleButtonGroup size="small" exclusive value={groupBy} onChange={(_, v) => v && setGroupBy(v)} aria-label="group by">
          <ToggleButton value="api">by API</ToggleButton>
          <ToggleButton value="consumer">by consumer</ToggleButton>
          <ToggleButton value="none">total</ToggleButton>
        </ToggleButtonGroup>
        <FormControl size="small" sx={{ minWidth: 220 }}>
          <InputLabel id="dash-api-label">API</InputLabel>
          <Select labelId="dash-api-label" label="API" value={apiKey ? `${kind}:${apiKey}` : ''}
                  onChange={e => {
                    const v = String(e.target.value);
                    if (!v) { setKind(''); setApiKey(''); return; }
                    const i = v.indexOf(':');
                    setKind(v.slice(0, i)); setApiKey(v.slice(i + 1));
                  }}>
            <MenuItem value="">Every API</MenuItem>
            {apis.filter(a => !a.is_redacted).map(a => (
              <MenuItem key={`${a.api_kind}:${a.key}`} value={`${a.api_kind}:${a.key}`}>{a.name} ({a.key})</MenuItem>
            ))}
          </Select>
        </FormControl>
        <FormControl size="small" sx={{ minWidth: 180 }}>
          <InputLabel id="dash-consumer-label">Consumer</InputLabel>
          <Select labelId="dash-consumer-label" label="Consumer" value={consumer} onChange={e => setConsumer(String(e.target.value))}>
            <MenuItem value="">Every consumer</MenuItem>
            {consumers.map(c => <MenuItem key={c} value={c}>{c}</MenuItem>)}
          </Select>
        </FormControl>
        <Box sx={{ flex: 1 }} />
        <Tooltip title={series?.watermark?.rolled_through ? `rolled through ${series.watermark.rolled_through}; lag ${series.watermark.lag_seconds ?? '?'} s` : 'the rollup has not run yet'}>
          <Chip size="small" variant="outlined" data-testid="dash-watermark"
                color={wmState === 'ok' ? 'success' : wmState === 'error' ? 'error' : 'default'}
                label={series?.watermark ? `numbers to ${endAt}` : 'numbers: unknown'} />
        </Tooltip>
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }} data-testid="dash-error">The numbers could not be read: {error}</Alert>}
      {series?.restricted && <Alert severity="info" sx={{ mb: 2 }}>{series.restricted}</Alert>}
      {health?.ingest && health.ingest.state && health.ingest.state !== 'ok' && (
        <Alert severity={health.ingest.state === 'loss' ? 'error' : 'warning'} sx={{ mb: 2 }} data-testid="dash-ingest">
          Call record ingest: {health.ingest.state}
          {health.ingest.rows_lost_write_failed ? ` · ${health.ingest.rows_lost_write_failed} rows lost (write failed)` : ''}
          {health.ingest.rows_dropped_queue_full ? ` · ${health.ingest.rows_dropped_queue_full} rows dropped (queue full)` : ''}
          {health.ingest.stale_pods?.length ? ` · stopped reporting: ${health.ingest.stale_pods.join(', ')}` : ''}
          {health.ingest.reason ? ` · ${health.ingest.reason}` : ''}
        </Alert>
      )}

      {loading ? (
        <Box sx={{ textAlign: 'center', py: 4 }}><CircularProgress /></Box>
      ) : (
        <>
          <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap sx={{ mb: 2 }}>
            <Tile label={`Calls (to ${endAt})`} value={fmtInt(totals?.calls)} testid="tile-calls" />
            <Tile label="Error rate" value={fmtPct(totals?.error_rate)} sub={totals ? `${fmtInt((totals.client_4xx || 0) + (totals.server_5xx || 0))} of ${fmtInt(totals.calls)} answers 4xx/5xx` : undefined} testid="tile-error-rate" />
            <Tile label={`p50 · ${totals?.method || 'histogram'}`} value={pct(totals?.p50)} sub={totals?.method === 'exact' ? 'exact over the raw rows' : pctRes(totals?.p50)} testid="tile-p50" />
            <Tile label={`p95 · ${totals?.method || 'histogram'}`} value={pct(totals?.p95)} sub={totals?.method === 'exact' ? 'exact over the raw rows' : pctRes(totals?.p95)} testid="tile-p95" />
            <Tile label={`p99 · ${totals?.method || 'histogram'}`} value={pct(totals?.p99)} sub={totals?.method === 'exact' ? 'exact over the raw rows' : pctRes(totals?.p99)} testid="tile-p99" />
            <Tile label="Rows served" value={fmtInt(totals?.rows_sum)} testid="tile-rows" />
            <Tile label="Bytes served" value={fmtBytes(totals?.bytes_sum)} sub={totals ? `${fmtInt(totals.bytes_known_calls)} calls measured bytes` : undefined} testid="tile-bytes" />
            <Tile label="Cache hit rate" value={fmtPct(totals?.cache_hit_rate)} sub={totals ? `${fmtInt(totals.cache_hit)} hit · ${fmtInt(totals.cache_miss)} miss · ${fmtInt(totals.cache_bypass)} bypass` : undefined} testid="tile-cache" />
            <Tile label="Refusals" value={fmtInt(refusals)} sub={totals?.refused ? Object.entries(totals.refused).map(([k, v]) => `${k} ${v}`).join(' · ') : undefined} testid="tile-refusals" />
          </Stack>

          <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} sx={{ mb: 2 }}>
            <Paper variant="outlined" sx={{ p: 1.5, flex: 1, minHeight: 280 }}>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>Calls over time {groupBy === 'none' ? '' : `(stacked ${groupBy === 'api' ? 'by API' : 'by consumer'})`}</Typography>
              {chartRows.length === 0 ? (
                <Typography variant="caption" color="text.secondary">No call in this range{series?.watermark?.state === 'never_rolled' ? ' — the rollup has not run yet' : ''}.</Typography>
              ) : (
                <ResponsiveContainer width="100%" height={240}>
                  <BarChart data={chartRows}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="label" tick={{ fontSize: 10 }} />
                    <YAxis tick={{ fontSize: 10 }} />
                    <ChartTip />
                    {groups.length > 1 && <Legend />}
                    {groups.map((g, i) => <Bar key={g} dataKey={g} stackId="calls" fill={COLORS[i % COLORS.length]} />)}
                  </BarChart>
                </ResponsiveContainer>
              )}
            </Paper>
            <Paper variant="outlined" sx={{ p: 1.5, flex: 1, minHeight: 280 }}>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>Errors and p95 over time</Typography>
              {chartRows.length === 0 ? (
                <Typography variant="caption" color="text.secondary">Nothing to draw.</Typography>
              ) : (
                <ResponsiveContainer width="100%" height={240}>
                  <LineChart data={chartRows}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="label" tick={{ fontSize: 10 }} />
                    <YAxis yAxisId="left" tick={{ fontSize: 10 }} />
                    <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 10 }} unit=" ms" />
                    <ChartTip />
                    <Legend />
                    <Line yAxisId="left" type="monotone" dataKey="errors" stroke="#d32f2f" dot={false} name="4xx + 5xx" />
                    <Line yAxisId="right" type="monotone" dataKey="p95" stroke="#1976d2" dot={false} name="p95 ms (max of groups)" />
                  </LineChart>
                </ResponsiveContainer>
              )}
            </Paper>
          </Stack>

          <Stack direction={{ xs: 'column', md: 'row' }} spacing={2}>
            <Paper variant="outlined" sx={{ p: 1.5, flex: 1 }}>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>Busiest APIs ({range})</Typography>
              {top?.error ? <Typography variant="caption" color="error">unknown: {top.error}</Typography> : (
                <Table size="small" data-testid="top-apis">
                  <TableHead><TableRow><TableCell>API</TableCell><TableCell align="right">Calls</TableCell><TableCell align="right">Errors</TableCell><TableCell align="right">p95</TableCell><TableCell align="right">Rate-limited</TableCell></TableRow></TableHead>
                  <TableBody>
                    {(top?.apis || []).map((a: any) => (
                      <TableRow key={a.key}>
                        <TableCell><code style={{ fontSize: 12 }}>{a.api_slug || a.key}</code></TableCell>
                        <TableCell align="right">{fmtInt(a.calls)}</TableCell>
                        <TableCell align="right">{fmtInt(a.errors)}</TableCell>
                        <TableCell align="right">{pct(a.p95)}</TableCell>
                        <TableCell align="right">{fmtInt(a.rate_limited)}</TableCell>
                      </TableRow>
                    ))}
                    {(top?.apis || []).length === 0 && <TableRow><TableCell colSpan={5}><Typography variant="caption" color="text.secondary">No call in this window.</Typography></TableCell></TableRow>}
                  </TableBody>
                </Table>
              )}
              {top?.restricted && <Typography variant="caption" color="text.secondary">{top.restricted}</Typography>}
            </Paper>
            <Paper variant="outlined" sx={{ p: 1.5, flex: 1 }}>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>Busiest consumers ({range})</Typography>
              <Table size="small" data-testid="top-consumers">
                <TableHead><TableRow><TableCell>Consumer</TableCell><TableCell align="right">Calls</TableCell><TableCell align="right">Errors</TableCell><TableCell align="right">Bytes</TableCell></TableRow></TableHead>
                <TableBody>
                  {(top?.consumers || []).map((c: any) => (
                    <TableRow key={c.key}>
                      <TableCell><code style={{ fontSize: 12 }}>{c.key}</code></TableCell>
                      <TableCell align="right">{fmtInt(c.calls)}</TableCell>
                      <TableCell align="right">{fmtInt(c.errors)}</TableCell>
                      <TableCell align="right">{fmtBytes(c.bytes)}</TableCell>
                    </TableRow>
                  ))}
                  {(top?.consumers || []).length === 0 && <TableRow><TableCell colSpan={4}><Typography variant="caption" color="text.secondary">{top?.restricted || 'No call in this window.'}</Typography></TableCell></TableRow>}
                </TableBody>
              </Table>
            </Paper>
            <Paper variant="outlined" sx={{ p: 1.5, flex: 1 }}>
              <Typography variant="subtitle2" sx={{ mb: 1 }}>Retirement candidates — no call in {idle?.days ?? '?'} days</Typography>
              {idle?.error ? <Typography variant="caption" color="error">unknown: {idle.error}</Typography> : (
                <Table size="small" data-testid="idle-apis">
                  <TableHead><TableRow><TableCell>API</TableCell><TableCell>Owner</TableCell><TableCell>Last call</TableCell><TableCell align="right">Consumers</TableCell></TableRow></TableHead>
                  <TableBody>
                    {(idle?.items || []).map((a: any) => (
                      <TableRow key={`${a.api_kind}:${a.api_id}`}>
                        <TableCell>{a.name} <code style={{ fontSize: 11 }}>{a.key}</code></TableCell>
                        <TableCell>{a.owner || '—'}</TableCell>
                        <TableCell>{a.last_call?.at ? new Date(a.last_call.at).toLocaleDateString() : (a.last_call?.state === 'unknown' ? `unknown: ${a.last_call.reason}` : 'never')}</TableCell>
                        <TableCell align="right">{a.consumers}</TableCell>
                      </TableRow>
                    ))}
                    {(idle?.items || []).length === 0 && <TableRow><TableCell colSpan={4}><Typography variant="caption" color="text.secondary">None.</Typography></TableCell></TableRow>}
                  </TableBody>
                </Table>
              )}
            </Paper>
          </Stack>
        </>
      )}
    </Box>
  );
}
