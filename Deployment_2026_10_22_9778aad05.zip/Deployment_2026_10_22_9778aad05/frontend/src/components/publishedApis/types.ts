/**
 * The published-API inventory as the server answers it (2026-10-17,
 * api/published_api_api.py; core/published_api/contract.py::PublishedApi).
 * Every field another publisher may not see is ABSENT on a redacted row
 * (`is_redacted`), so every reader presence-guards.
 */
export type LifecycleStatus = 'draft' | 'active' | 'deprecated' | 'retired';
export type HealthState = 'active' | 'broken' | 'unknown';

export interface ApiConsumer {
  kind: 'api_key' | 'ad_group' | 'token' | 'every_ad_user' | 'dev_guest' | string;
  id: string;
  name: string;
  owner?: string | null;
  consumer?: string | null;
  contact?: string | null;
  scope?: 'this_api' | 'every_api' | string;
  is_active: boolean;
  expires_at?: string | null;
  last_used_at?: string | null;
  identity?: string;
  /** a key's limit as DECLARED and as ENFORCED (the operator's max_rate_limit cap) -- 2026-10-18 */
  rate_limit?: string | null;
  effective_rate_limit?: string | null;
  rate_limit_capped?: boolean | null;
  rate_limit_cap_reason?: string | null;
}

export interface ApiDependency {
  kind: string;
  id: number | null;
  name?: string | null;
  role?: string;
  state: 'ok' | 'missing' | 'inactive' | 'unpublished' | 'unknown';
  reason?: string | null;
  via?: string | null;
}

export interface ApiLifecycle {
  status: LifecycleStatus;
  stored?: string | null;
  sunset_at?: string | null;
  deprecation_note?: string | null;
  successor?: string | null;
  changed_by?: string | null;
  changed_at?: string | null;
  sunset_due?: boolean;
}

export interface PublishedApiRow {
  api_kind: 'published_view' | 'published_report' | string;
  api_id: number;
  key: string;
  name: string;
  description?: string | null;
  owner?: string | null;
  owner_group?: string | null;
  source?: { kind?: string; id?: number | null; name?: string | null; word?: string };
  connections?: { id: number; name?: string | null; role?: string }[];
  endpoints?: { method: string; path: string; formats: string[]; auth: string[] }[];
  parameters?: any[];
  filters?: string[];
  definition_version?: number | null;
  schema_version?: number | null;
  rls?: { mode?: string; policies?: any[]; reason?: string | null };
  consumers?: ApiConsumer[];
  lifecycle?: ApiLifecycle;
  health?: { state: HealthState; reasons: string[] };
  dependencies?: ApiDependency[];
  created_by?: string | null;
  created_at?: string | null;
  last_changed_by?: string | null;
  last_changed_at?: string | null;
  /** `{at, consumer, status}` or `{state: 'unknown', reason}` or `{}` = never called */
  last_call?: { at?: string | null; consumer?: string | null; status?: number | null; state?: string; reason?: string };
  calls_7d?: number | null;
  is_redacted?: boolean;
}

export interface InventoryAnswer {
  items: PublishedApiRow[];
  total?: number;
  count?: number;
  generated_at?: string;
  problems?: string[];
  numbers_error?: string | null;
  kinds?: string[];
  counts?: Record<string, any>;
}

export const apiRowKey = (kind: string, key: string | number) => `${kind}:${key}`;

export const KIND_WORDS: Record<string, string> = {
  published_view: 'view',
  published_report: 'report',
};

export const LIFECYCLE_COLOR: Record<string, 'success' | 'warning' | 'default' | 'info'> = {
  active: 'success', deprecated: 'warning', retired: 'default', draft: 'info',
};

/** The time an inventory number is good to -- the rollup's watermark. */
export const numbersEndAt = (iso?: string | null): string =>
  iso ? new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '?';

export const fmtInt = (n: number | null | undefined): string =>
  n === null || n === undefined ? '—' : Number(n).toLocaleString();

export const fmtPct = (ratio: number | null | undefined): string =>
  ratio === null || ratio === undefined ? '—' : `${(Number(ratio) * 100).toFixed(2)} %`;

export const fmtBytes = (n: number | null | undefined): string => {
  if (n === null || n === undefined) return '—';
  const v = Number(n);
  if (v < 1024) return `${v} B`;
  if (v < 1024 ** 2) return `${(v / 1024).toFixed(1)} KB`;
  if (v < 1024 ** 3) return `${(v / 1024 ** 2).toFixed(1)} MB`;
  return `${(v / 1024 ** 3).toFixed(2)} GB`;
};
