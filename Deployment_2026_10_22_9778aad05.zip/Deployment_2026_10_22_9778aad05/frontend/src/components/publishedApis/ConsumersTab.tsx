/**
 * Consumers & keys (2026-10-17, design §3.9): the API Keys page folded into
 * the Published APIs page (the /api-keys route redirects here), the pending
 * key REQUESTS to approve / deny, and the tokens of published reports listed
 * as consumers of their report.  Admin only -- the page offers this tab to
 * nobody else (never offer what the server refuses).
 */
import React, { useCallback, useEffect, useState } from 'react';
import {
  Alert, Box, Button, Chip, Paper, Stack, Table, TableBody, TableCell, TableHead, TableRow, TextField, Typography,
} from '@mui/material';
import { Check as ApproveIcon, Close as DenyIcon } from '@mui/icons-material';
import api from '../../services/api';
import ApiKeysPage from '../ApiKeysPage';
import type { PublishedApiRow } from './types';

interface Props { apis: PublishedApiRow[] }

export default function ConsumersTab({ apis }: Props) {
  const [pending, setPending] = useState<any[] | null>(null);
  const [pendingError, setPendingError] = useState<string | null>(null);
  const [notes, setNotes] = useState<Record<number, string>>({});
  const [busy, setBusy] = useState<number | null>(null);

  const loadPending = useCallback(async () => {
    try {
      const rows = await (api as any).listApiKeyRequests('pending');
      setPending(Array.isArray(rows) ? rows : []);
      setPendingError(null);
    } catch (e: any) {
      setPending(null);
      setPendingError(e?.message || 'the key requests could not be read');
    }
  }, []);

  useEffect(() => { loadPending(); }, [loadPending]);

  const decide = async (r: any, approve: boolean) => {
    setBusy(r.id);
    try {
      if (approve) await (api as any).approveApiKeyRequest(r.id, { note: notes[r.id] || undefined });
      else await (api as any).denyApiKeyRequest(r.id, { note: notes[r.id] || undefined });
      loadPending();
    } catch (e: any) {
      setPendingError(e?.message || 'the decision was refused');
    } finally {
      setBusy(null);
    }
  };

  const viewName = (id: any) => apis.find(a => a.api_kind === 'published_view' && a.api_id === Number(id))?.name || `#${id}`;
  const tokens = apis.filter(a => a.api_kind === 'published_report')
    .flatMap(a => (a.consumers || []).filter(c => c.kind === 'token').map(c => ({ ...c, report: a })));

  return (
    <Box>
      <ApiKeysPage embedded />

      <Box sx={{ mt: 4 }}>
        <Typography variant="h6" fontWeight={600} sx={{ mb: 1 }}>Key requests awaiting a decision</Typography>
        {pendingError && <Alert severity="error" sx={{ mb: 1 }}>{pendingError}</Alert>}
        <Paper variant="outlined">
          <Table size="small" data-testid="key-requests-table">
            <TableHead>
              <TableRow><TableCell>Requested by</TableCell><TableCell>Key name</TableCell><TableCell>Views</TableCell><TableCell>Justification</TableCell><TableCell>Note</TableCell><TableCell align="right">Decide</TableCell></TableRow>
            </TableHead>
            <TableBody>
              {(pending || []).map((r: any) => (
                <TableRow key={r.id}>
                  <TableCell>{r.requested_by || r.username || '-'}</TableCell>
                  <TableCell>{r.key_name}</TableCell>
                  <TableCell>{(r.scoped_view_ids || []).map((id: any) => <Chip key={String(id)} size="small" label={viewName(id)} sx={{ mr: 0.5 }} />)}</TableCell>
                  <TableCell><Typography variant="caption">{r.justification || '-'}</Typography></TableCell>
                  <TableCell><TextField size="small" placeholder="note (optional)" value={notes[r.id] || ''} onChange={e => setNotes({ ...notes, [r.id]: e.target.value })} /></TableCell>
                  <TableCell align="right">
                    <Stack direction="row" spacing={0.5} justifyContent="flex-end">
                      <Button size="small" color="success" startIcon={<ApproveIcon />} disabled={busy === r.id} onClick={() => decide(r, true)} aria-label={`Approve ${r.key_name}`}>Approve</Button>
                      <Button size="small" color="error" startIcon={<DenyIcon />} disabled={busy === r.id} onClick={() => decide(r, false)} aria-label={`Deny ${r.key_name}`}>Deny</Button>
                    </Stack>
                  </TableCell>
                </TableRow>
              ))}
              {pending !== null && pending.length === 0 && (
                <TableRow><TableCell colSpan={6}><Typography variant="caption" color="text.secondary">Nothing waiting.</Typography></TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </Paper>
      </Box>

      <Box sx={{ mt: 4 }}>
        <Typography variant="h6" fontWeight={600} sx={{ mb: 1 }}>Report tokens (consumers of published reports)</Typography>
        <Paper variant="outlined">
          <Table size="small" data-testid="report-tokens-table">
            <TableHead>
              <TableRow><TableCell>Report</TableCell><TableCell>Token</TableCell><TableCell>Owner</TableCell><TableCell>Last used</TableCell><TableCell>Expires</TableCell><TableCell>Status</TableCell></TableRow>
            </TableHead>
            <TableBody>
              {tokens.map(t => (
                <TableRow key={`${t.report.api_id}:${t.id}`}>
                  <TableCell>
                    <a href={`/finance-reports?report=${t.report.api_id}`} style={{ color: 'inherit' }}>{t.report.name}</a>
                  </TableCell>
                  <TableCell><code style={{ fontSize: 12 }}>{t.id}</code> <Typography variant="caption" color="text.secondary">{t.name}</Typography></TableCell>
                  <TableCell>{t.owner || '—'}</TableCell>
                  <TableCell><Typography variant="caption">{t.last_used_at ? new Date(t.last_used_at).toLocaleString() : 'never'}</Typography></TableCell>
                  <TableCell><Typography variant="caption">{t.expires_at ? new Date(t.expires_at).toLocaleDateString() : 'never'}</Typography></TableCell>
                  <TableCell><Chip size="small" label={t.is_active ? 'active' : 'revoked'} color={t.is_active ? 'success' : 'default'} /></TableCell>
                </TableRow>
              ))}
              {tokens.length === 0 && (
                <TableRow><TableCell colSpan={6}><Typography variant="caption" color="text.secondary">No report is served by a token.</Typography></TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </Paper>
      </Box>
    </Box>
  );
}
