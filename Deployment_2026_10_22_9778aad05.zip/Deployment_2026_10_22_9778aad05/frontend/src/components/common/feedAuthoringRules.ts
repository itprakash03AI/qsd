/**
 * BRD STEP 1 (2026-09-02) — "A FEED IS A FEED": the authoring-time rules,
 * mirrored from the backend modules that OWN them.  The UI refuses with
 * the SAME rules the backend enforces — never different ones — so a feed
 * author learns a refusal when it is typed, not at 3am inside the engine.
 *
 * Sources of truth (backend, read-only for this UI):
 *   - backend/core/feed/identity.py         — name rules (FR-ID-01..03)
 *   - backend/core/feed/partition_shape.py  — the SHAPE (query_params._partition)
 *   - backend/core/feed/contract.py         — contract terms + which are
 *     genuinely unsupported today (SEVERITY_UNSUPPORTED, BRD §10 "build")
 *   - backend/api/feed_api.py::FEED_OPTION_TO_CONTRACT_TERM — how a feed's
 *     output_options keys map onto contract terms.
 *
 * Where the backend is the authority (uniqueness, has-ever-run rename
 * refusal, full contract validation) the UI surfaces the SERVER's message;
 * these mirrors exist only so the author sees the refusal while typing.
 */

import { sftpConfigProblems } from '../feeds/sftpRules';

// ── Feed identity (core/feed/identity.py) ────────────────────────────────

/** The Netcool alert Identifier carries the name whole (OMNIbus varchar(255)
 *  with env, alert type and date) -- core/feed/identity.py.  Was 47, from a
 *  pod-name budget the pod name stopped needing on 2026-09-14. */
export const MAX_FEED_NAME_LEN = 128;

const NAME_CHARSET_RE = /^[A-Z0-9_]+$/;

/**
 * Mirror of identity.validate_feed_name — returns the refusal message,
 * or null when the name is acceptable.  Never rewrites the name
 * (FR-ID-01: refused at save time, not sanitised silently).
 */
export function validateFeedName(name: string): string | null {
  if (!name) {
    return 'Feed name is required. Use uppercase letters, digits and '
      + 'underscores, e.g. GL_EXTRACT_APAC.';
  }
  if (name.length > MAX_FEED_NAME_LEN) {
    return `Feed name is ${name.length} characters; the limit is `
      + `${MAX_FEED_NAME_LEN}. The name is carried whole into the Netcool `
      + 'alert Identifier, and names are never rewritten silently. '
      + 'Shorten the name; put detail in the description or '
      + 'display name.';
  }
  if (!NAME_CHARSET_RE.test(name)) {
    const bad = Array.from(new Set(
      name.split('').filter(c => !/[A-Z0-9_]/.test(c)))).sort();
    return `Feed name contains disallowed character(s) ${JSON.stringify(bad)}. `
      + 'Allowed characters are uppercase A-Z, digits 0-9 and underscore, '
      + 'e.g. GL_EXTRACT_APAC. The name is NOT rewritten for you — a '
      + 'silently-adjusted name would no longer match its archives, alerts '
      + 'and filenames — so please re-enter it in the allowed alphabet.';
  }
  if (name.startsWith('_') || name.endsWith('_')) {
    return 'Feed name must start and end with a letter or digit. A '
      + 'trailing underscore is stripped when the name is mapped to a '
      + 'DNS-safe Kubernetes pod name, so it would collide with the '
      + 'underscore-less spelling there.';
  }
  return null;
}

/**
 * 2026-10-03 — the NAME FIELD normalises as the author types, VISIBLY.
 *
 * The owner typed "snowflake test feed" and learned at save time that
 * eight characters were disallowed.  The backend rule stands (identity.py
 * refuses, never rewrites — a server-side silent rewrite would no longer
 * match the archives, alerts and filenames the author expects).  A FORM
 * that shows the exact name it will save is not a silent rewrite: the
 * field itself displays the normalised spelling and the helper text says
 * "Saved as ...".
 *
 * Rules: lower case → upper case; space, hyphen and dot → underscore;
 * every other character outside A-Z 0-9 _ is dropped; runs of
 * underscores collapse to one; a LEADING underscore is dropped.  A
 * TRAILING underscore is kept while typing (it is the separator before
 * the next word) and removed by ``feedNameForSave``.
 */
export function normalizeFeedNameInput(raw: string): string {
  return String(raw ?? '')
    .toUpperCase()
    .replace(/[\s.-]/g, '_')
    .replace(/[^A-Z0-9_]/g, '')
    .replace(/_+/g, '_')
    .replace(/^_/, '');
}

/** The exact name a save sends: the typed (already normalised) name
 *  without a trailing underscore, which identity.py would refuse. */
export function feedNameForSave(typed: string): string {
  // Normalising collapses underscore runs, so at most ONE trails.
  const n = normalizeFeedNameInput(typed);
  return n.endsWith('_') ? n.slice(0, -1) : n;
}

/** The helper line under every feed-name field — the rule AND the result. */
export const FEED_NAME_RULE_HINT =
  'Uppercase A-Z, digits and underscore. As you type, lower case becomes '
  + 'upper case, spaces, hyphens and dots become underscores, and other '
  + 'characters are dropped.';

// ── The consumer SLA (core/feed/acting_time.py::feed_sla_field_problem) ──
//
// sla_from / sla_to are a time of day, HH:MM on the 24-hour clock, read by
// BOTH the breach sweep (sla_tracker) and the alert ladder (acting_time).
// The form offers an hour and a minute picker, so it can only produce a
// value both readers evaluate; the server refuses anything else (422
// naming the field).

export const SLA_HOURS: string[] = Array.from(
  { length: 24 }, (_, i) => String(i).padStart(2, '0'));
export const SLA_MINUTES: string[] = Array.from(
  { length: 60 }, (_, i) => String(i).padStart(2, '0'));

export interface SlaTimeParts { hour: string; minute: string; }

/**
 * A stored SLA time → picker parts.  ``null`` = no SLA stored.  A stored
 * value the picker cannot represent EXACTLY (free text from before the
 * picker, seconds) is ``{ unrepresentable: <raw> }`` — the form shows it
 * read-only and never resends it.  ``+HH:MM`` (the enterprise spelling
 * both readers strip) is the same deadline as ``HH:MM``.
 */
export function parseSlaTime(
  stored: string | null | undefined,
): SlaTimeParts | null | { unrepresentable: string } {
  if (stored == null || stored === '') return null;
  const m = /^\+?(\d{1,2}):(\d{2})(?::00)?$/.exec(String(stored).trim());
  if (!m) return { unrepresentable: String(stored) };
  const h = Number(m[1]);
  const mi = Number(m[2]);
  if (h > 23 || mi > 59) return { unrepresentable: String(stored) };
  return { hour: String(h).padStart(2, '0'), minute: m[2] };
}

/** Picker parts → the stored spelling ("HH:MM"), or null for no SLA. */
export function formatSlaTime(hour: string, minute: string): string | null {
  if (!hour) return null;
  return `${hour}:${minute || '00'}`;
}

// ── The SHAPE (core/feed/partition_shape.py — query_params._partition) ───

export interface PartitionShapeDraft {
  /** The Switch: absent shape = single-file feed (the overwhelming
   *  majority).  An ABSENT shape and an EMPTY declaration are different
   *  things — see partition_shape.py. */
  enabled: boolean;
  columns: string[];
  /** Inline identities, one per line. */
  values: string;
  /** Or the SQL that yields them. */
  valuesSql: string;
  /** Kept as text so a cleared field is "unbounded", never 0. */
  maxParts: string;
  onEmpty: 'fail' | 'skip';
}

export const EMPTY_SHAPE_DRAFT: PartitionShapeDraft = {
  enabled: false, columns: [], values: '', valuesSql: '',
  maxParts: '', onEmpty: 'fail',
};

export function shapeValueLines(draft: PartitionShapeDraft): string[] {
  return draft.values.split('\n').map(s => s.trim()).filter(Boolean);
}

/**
 * Mirror of partition_shape.read_shape's refusals (ShapeError).  The
 * backend raises these at admission; the API does not yet validate the
 * shape at save time, so this is the author's only pre-run gate.
 */
export function partitionShapeErrors(draft: PartitionShapeDraft): string[] {
  if (!draft.enabled) return [];
  const errors: string[] = [];
  const values = shapeValueLines(draft);
  const valuesSql = draft.valuesSql.trim();
  if (values.length > 0 && valuesSql) {
    errors.push(
      '_partition declares BOTH values and values_sql — which one is '
      + 'authoritative cannot be guessed, and guessing wrong silently '
      + 'changes how many files the counterparty receives. Clear one of '
      + 'the two.');
  }
  if (draft.maxParts.trim() !== '') {
    const n = Number(draft.maxParts.trim());
    if (!Number.isInteger(n)) {
      errors.push(`_partition.max_parts must be an integer, got `
        + `'${draft.maxParts.trim()}'.`);
    } else if (n <= 0) {
      errors.push(`_partition.max_parts=${n} is refused — 0 does NOT `
        + 'mean unlimited. Leave max_parts empty to leave the '
        + 'declaration unbounded.');
    }
  }
  return errors;
}

/** Advisory (non-blocking — the backend accepts these shapes). */
export function partitionShapeHints(draft: PartitionShapeDraft): string[] {
  if (!draft.enabled) return [];
  const hints: string[] = [];
  const values = shapeValueLines(draft);
  if (values.length === 0 && !draft.valuesSql.trim()) {
    hints.push(
      'No values source declared — the run will see an EMPTY partition '
      + `list, which is a decision: on_empty=${draft.onEmpty} means the `
      + (draft.onEmpty === 'fail'
        ? 'run is refused.' : 'run is skipped without producing a file.'));
  }
  if (draft.columns.length === 0) {
    hints.push('No partition columns named — declare which column(s) the '
      + 'identities apply to.');
  }
  return hints;
}

/**
 * The `_partition` object for query_params, or null when no shape is
 * declared (absence = single-file feed, untouched).
 */
export function buildPartitionShape(
  draft: PartitionShapeDraft,
): Record<string, any> | null {
  if (!draft.enabled) return null;
  const out: Record<string, any> = {
    columns: draft.columns.map(c => c.trim()).filter(Boolean),
    on_empty: draft.onEmpty,
  };
  const values = shapeValueLines(draft);
  const valuesSql = draft.valuesSql.trim();
  // Declare exactly the source the author supplied.  Declaring
  // `values: []` when the author typed nothing would be a DECLARED
  // empty list (a decision, per §9.3) — so only ship the key the
  // author actually filled in.
  if (values.length > 0) out.values = values;
  if (valuesSql) out.values_sql = valuesSql;
  if (draft.maxParts.trim() !== '') {
    const n = Number(draft.maxParts.trim());
    if (Number.isInteger(n)) out.max_parts = n;
  }
  return out;
}

// ── The SCHEDULE declaration (core/feed/schedule.py) ─────────────────────
//
// BRD §2.1 — five authorable kinds.  The declaration rides the feed
// field `schedule_declaration` (the key core/feed/sod_generator.py
// reads); parse_schedule() is the backend authority and these mirrors
// refuse EXACTLY what it refuses, so the author learns at typing time.
// ABSENCE of a declaration keeps the feed on today's cron-only path,
// byte-for-byte unchanged — parse_schedule(None) returns None.

export const SCHEDULE_KINDS = [
  'daily', 'month_end', 'workday_n', 'workdays', 'cron',
  'on_completion_of', 'on_demand',
] as const;

/** 2026-10-13 -- the SECOND axis (schedule.py BUSINESS_DATES): which date the
 *  DATA is for on the day the task runs.  'run_day' sends nothing (the
 *  default; every feed before this). */
export const BUSINESS_DATE_RULES = ['run_day', 'month_end', 'previous_month_end'] as const;
export type BusinessDateRule = typeof BUSINESS_DATE_RULES[number];
export type ScheduleKind = typeof SCHEDULE_KINDS[number];

/** BRD §6: "N = 1…15 and negative from the end" (schedule.py bounds). */
export const WORKDAY_N_MIN = 1;
export const WORKDAY_N_MAX = 15;

export interface ScheduleDraft {
  /** The Switch: false = NO declaration is sent — the feed keeps the
   *  legacy cron + timezone + calendar path exactly as today. */
  declared: boolean;
  kind: ScheduleKind;
  /** Kept as text so a cleared field is "missing", never 0. */
  workdayN: string;
  /** kind == workdays only — which of its two authoring forms is in
   *  use.  ONE kind, two mutually-exclusive forms (schedule.py):
   *  a range {from,to} or a set {days}; both reduce server-side to the
   *  same membership, so the toggle here is authoring-only. */
  workdaysForm: 'range' | 'set';
  /** kind == workdays, form == range — inclusive, same-sign bounds. */
  workdaysFrom: string;
  workdaysTo: string;
  /** kind == workdays, form == set — comma-separated members. */
  workdaysDays: string;
  /** kind == cron only — the declaration's own 5-field expression. */
  cron: string;
  /** kind == on_completion_of only — the upstream feed NAME. */
  upstreamFeed: string;
  /** which date the data is for on a run day (not for on_completion_of /
   *  on_demand: their date comes from what starts them) */
  businessDate: BusinessDateRule;
}

export const EMPTY_SCHEDULE_DRAFT: ScheduleDraft = {
  declared: false, kind: 'daily', workdayN: '',
  workdaysForm: 'range', workdaysFrom: '', workdaysTo: '', workdaysDays: '',
  cron: '', upstreamFeed: '', businessDate: 'run_day',
};

/** Rebuild the draft from a stored declaration (edit mode).  A feed
 *  with no declaration hydrates to the untouched EMPTY draft. */
export function hydrateScheduleDraft(
  decl: Record<string, any> | null | undefined,
): ScheduleDraft {
  if (!decl || typeof decl !== 'object' || Array.isArray(decl)) {
    return EMPTY_SCHEDULE_DRAFT;
  }
  const kind = SCHEDULE_KINDS.includes(decl.kind)
    ? decl.kind as ScheduleKind : 'daily';
  const hasDays = Array.isArray(decl.days);
  return {
    declared: true,
    kind,
    workdayN: decl.n != null ? String(decl.n) : '',
    workdaysForm: hasDays ? 'set' : 'range',
    workdaysFrom: decl.from != null ? String(decl.from) : '',
    workdaysTo: decl.to != null ? String(decl.to) : '',
    workdaysDays: hasDays ? (decl.days as any[]).join(', ') : '',
    cron: typeof decl.cron === 'string' ? decl.cron : '',
    upstreamFeed: typeof decl.feed === 'string' ? decl.feed : '',
    businessDate: (BUSINESS_DATE_RULES as readonly string[]).includes(decl.business_date)
      ? decl.business_date as BusinessDateRule : 'run_day',
  };
}

/**
 * Mirror of schedule.py::parse_schedule's refusals for the fields this
 * editor exposes (the kind is a Select, so unknown-kind refusals cannot
 * occur here).  Every message says what to do instead, not just what is
 * wrong — the backend refuses with the same rules at save.
 */
/** One workdays member (a range bound or set element) — mirror of
 *  schedule.py::_validate_workday_member.  Returns an error string or
 *  null when the member is valid. */
function workdaysMemberError(raw: string, where: string): string | null {
  const v = Number(raw);
  if (!/^-?\d+$/.test(raw) || !Number.isInteger(v)) {
    return `workdays ${where} must be a whole number, got '${raw}'.`;
  }
  if (v === 0) {
    return `workdays ${where} = 0 is refused: there is no 0th business `
      + "day, and 0 does NOT mean 'every day' or 'the 1st'. Use 1 for "
      + 'the first business day or -1 for the last.';
  }
  if (Math.abs(v) > WORKDAY_N_MAX) {
    return `workdays ${where} = ${v} is out of range: |value| must be `
      + `between ${WORKDAY_N_MIN} and ${WORKDAY_N_MAX}.`;
  }
  return null;
}

export function scheduleDeclarationErrors(draft: ScheduleDraft): string[] {
  if (!draft.declared) return [];
  const errors: string[] = [];
  if (draft.kind === 'workday_n') {
    const raw = draft.workdayN.trim();
    if (raw === '') {
      errors.push(
        "workday_n requires 'n' — which business day of the month this "
        + 'feed runs on. Enter 1..15, or -1..-15 to count back from '
        + 'month end.');
    } else {
      const n = Number(raw);
      if (!Number.isInteger(n)) {
        errors.push(
          `workday_n 'n' must be a whole number, got '${raw}'. Enter `
          + '1..15, or -1..-15 to count back from month end.');
      } else if (n === 0) {
        errors.push(
          'workday_n n=0 is refused: there is no 0th business day, and '
          + "0 does NOT mean 'every day' or 'the 1st'. Use n=1 for the "
          + 'first business day or n=-1 for the last.');
      } else if (Math.abs(n) > WORKDAY_N_MAX) {
        errors.push(
          `workday_n n=${n} is out of range: |n| must be between `
          + `${WORKDAY_N_MIN} and ${WORKDAY_N_MAX}. Pick a business day `
          + 'within the first 15 of the month, or -1..-15 counting back '
          + 'from month end.');
      }
    }
  }
  if (draft.kind === 'workdays') {
    if (draft.workdaysForm === 'range') {
      const rawFrom = draft.workdaysFrom.trim();
      const rawTo = draft.workdaysTo.trim();
      if (!rawFrom || !rawTo) {
        errors.push(
          "workdays range requires BOTH 'from' and 'to' (inclusive "
          + 'bounds). Enter e.g. from=1 to=15 for the first fifteen '
          + 'business days, or switch to a discrete set of days.');
      } else {
        const eFrom = workdaysMemberError(rawFrom, "'from'");
        const eTo = workdaysMemberError(rawTo, "'to'");
        if (eFrom) errors.push(eFrom);
        if (eTo) errors.push(eTo);
        if (!eFrom && !eTo) {
          const lo = Number(rawFrom);
          const hi = Number(rawTo);
          if ((lo > 0) !== (hi > 0)) {
            errors.push(
              `workdays range from=${lo} to=${hi} mixes a `
              + 'count-from-start bound with a count-from-end bound — '
              + "which dates that covers depends on the month's length, "
              + "so it is refused. Use a 'days' set whose members are "
              + 'each independently well-defined.');
          } else if (lo > hi) {
            errors.push(
              `workdays range from=${lo} to=${hi} is reversed (from `
              + 'must be <= to) — refused, never silently swapped.');
          }
        }
      }
    } else {
      const raw = draft.workdaysDays.trim();
      const parts = raw
        ? raw.split(',').map(x => x.trim()).filter(Boolean) : [];
      if (parts.length === 0) {
        errors.push(
          "workdays 'days' is empty: a schedule with no due days is a "
          + 'feed that never runs, silently — enter e.g. 1, 10, 15.');
      } else {
        const memberErrors = parts
          .map(x => workdaysMemberError(x, "'days' member"))
          .filter((x): x is string => x != null);
        errors.push(...memberErrors);
        if (memberErrors.length === 0) {
          const nums = parts.map(Number);
          const dupes = [...new Set(nums.filter(
            (n, i) => nums.indexOf(n) !== i))].sort((a, b) => a - b);
          if (dupes.length > 0) {
            errors.push(
              "workdays 'days' contains duplicate member(s) "
              + `[${dupes.join(', ')}] — refused, never silently `
              + 'deduplicated: a duplicate usually means a typo.');
          }
        }
      }
    }
  }
  if (draft.kind === 'cron') {
    const expr = draft.cron.trim();
    if (!expr) {
      errors.push(
        'a cron declaration needs its expression — 5 fields: minute '
        + 'hour day month day_of_week, e.g. 0 6 * * *.');
    } else {
      const fields = expr.split(/\s+/);
      if (fields.length !== 5) {
        errors.push(
          `cron expression '${expr}' has ${fields.length} field(s); `
          + 'expected 5 (minute hour day month day_of_week). Add the '
          + 'missing field(s) — e.g. 0 6 * * * = daily at 06:00.');
      }
    }
  }
  if (draft.kind === 'on_completion_of') {
    if (!draft.upstreamFeed.trim()) {
      errors.push(
        'on_completion_of requires the upstream feed name — name the '
        + 'feed whose completion fires this one, e.g. GL_EXTRACT_APAC.');
    }
  }
  return errors;
}

/**
 * The `schedule_declaration` object, or null when none is declared
 * (absence = the legacy cron-only path, untouched).  Built FROM the
 * kind, never by merging drafts — switching kinds can therefore never
 * leave a stale field from the previous kind in the payload (a
 * cron key on a month_end declaration is refused by parse_schedule).
 */
export function buildScheduleDeclaration(
  draft: ScheduleDraft,
): Record<string, any> | null {
  if (!draft.declared) return null;
  const decl = buildRunDays(draft);
  if (decl && draft.businessDate !== 'run_day'
      && draft.kind !== 'on_completion_of' && draft.kind !== 'on_demand') {
    decl.business_date = draft.businessDate;
  }
  return decl;
}

function buildRunDays(draft: ScheduleDraft): Record<string, any> | null {
  switch (draft.kind) {
    case 'daily':      return { kind: 'daily' };
    case 'month_end':  return { kind: 'month_end' };
    case 'on_demand':  return { kind: 'on_demand' };
    case 'workday_n':  return { kind: 'workday_n', n: Number(draft.workdayN.trim()) };
    case 'workdays':
      // Built FROM the active form only — the other form's fields can
      // never leak into the payload (parse_schedule refuses both-forms).
      return draft.workdaysForm === 'range'
        ? {
          kind: 'workdays',
          from: Number(draft.workdaysFrom.trim()),
          to: Number(draft.workdaysTo.trim()),
        }
        : {
          kind: 'workdays',
          days: draft.workdaysDays.split(',')
            .map(x => x.trim()).filter(Boolean).map(Number),
        };
    case 'cron':       return { kind: 'cron', cron: draft.cron.trim() };
    case 'on_completion_of':
      return { kind: 'on_completion_of', feed: draft.upstreamFeed.trim() };
    default:           return null;
  }
}

// ── The CONTRACT (core/feed/contract.py via output_options) ──────────────
//
// A feed stores its contract as output_format + the output_options bag;
// api/feed_api.py::FEED_OPTION_TO_CONTRACT_TERM flattens it for the
// validator.  Where two spellings map to one term, we WRITE the spelling
// the ENGINE actually reads (compression, checksum, na_rep) so a saved
// term is never a lying knob.

export const QUOTING_VALUES = ['minimal', 'all', 'nonnumeric', 'none'] as const;
export const LINE_TERMINATORS = ['crlf', 'lf', 'cr'] as const;
export const PACKAGING_VALUES = ['none', 'zip', 'tar'] as const;
export const CODEC_VALUES = ['none', 'gzip', 'bzip2', 'zstd', 'snappy'] as const;
export const ENCRYPTION_VALUES = ['none', 'pgp'] as const;
export const CHECKSUM_ALGORITHMS = ['md5', 'sha1', 'sha256', 'sha512', 'crc32'] as const;
export const CHECKSUM_SCOPES = ['part', 'whole', 'both'] as const;
/** 2026-10-15 -- what the checksum describes (core/feed/checksum_covers.py):
 *  the SENT file (default) or the data file BEFORE compression. */
export const CHECKSUM_COVERS_VALUES = ['sent', 'uncompressed'] as const;
export const SIDECAR_VALUES = ['none', 'control_file', 'per_file', 'manifest'] as const;
export const DIGEST_LINE_VALUES = ['coreutils', 'bare'] as const;
export const SEQUENCING_VALUES = ['none', 'gapless'] as const;
export const REDELIVERY_VALUES = ['reuse', 'revision'] as const;
export const COMMON_ENCODINGS = ['utf-8', 'latin-1', 'cp1252', 'utf-8-sig'];

export interface ContractOpts {
  delimiter: string;
  header: boolean;
  nullMarker: string;          // na_rep
  /** A DISTINCT convention for "" vs NULL; '' = not declared
   *  (contract.py: empty_string_marker, default None). */
  emptyStringMarker: string;
  encoding: string;
  quoting: string;
  /** contract.py default '"' — any other value is recorded as an
   *  unsupported term today. */
  quotechar: string;
  /** '' = none (contract.py: escapechar, default None). */
  escapechar: string;
  lineTerminator: string;
  trailingDelimiter: boolean;
  packaging: string;
  codec: string;               // written as `compression` (the engine's key)
  encryption: string;
  pgpRecipient: string;
  checksumAlgorithm: string;   // '' = none; written as `checksum`
  checksumScope: string;
  /** 'sent' (default) | 'uncompressed' -- see CHECKSUM_COVERS_VALUES */
  checksumCovers: string;
  sidecar: string;
  digestLine: string;
  sequencing: string;
  multipartNaming: boolean;
  redeliveryNaming: string;
}

/** Engine defaults — a default contract validates clean (contract.py). */
export const CONTRACT_DEFAULTS: ContractOpts = {
  delimiter: ',', header: true, nullMarker: '', emptyStringMarker: '',
  encoding: 'utf-8',
  quoting: 'minimal', quotechar: '"', escapechar: '',
  lineTerminator: 'crlf', trailingDelimiter: false,
  packaging: 'none', codec: 'none', encryption: 'none', pgpRecipient: '',
  checksumAlgorithm: '', checksumScope: 'part', checksumCovers: 'sent', sidecar: 'none',
  digestLine: 'coreutils', sequencing: 'none', multipartNaming: false,
  redeliveryNaming: 'reuse',
};

/** Every output_options key this editor owns — both spellings, so a
 *  save can clear the ones it rewrites without dropping engine knobs
 *  it does not manage (sheet_name etc. pass through untouched). */
export const MANAGED_OPTION_KEYS = [
  'delimiter', 'header', 'na_rep', 'empty_string_marker', 'encoding',
  'quoting', 'quotechar', 'escapechar',
  'line_terminator', 'trailing_delimiter', 'packaging',
  'compression', 'codec', 'encryption', 'pgp_recipient',
  'checksum', 'checksum_algorithm', 'checksum_scope', 'checksum_covers',
  'sidecar', 'digest_line', 'sequencing', 'multipart_naming',
  'redelivery_naming',
];

export function hydrateContractOpts(
  options: Record<string, any> | null | undefined,
): ContractOpts {
  const o = options || {};
  const pick = (k: string, dflt: any) => (o[k] === undefined || o[k] === null ? dflt : o[k]);
  return {
    delimiter: String(pick('delimiter', CONTRACT_DEFAULTS.delimiter)),
    header: Boolean(pick('header', CONTRACT_DEFAULTS.header)),
    nullMarker: String(pick('na_rep', CONTRACT_DEFAULTS.nullMarker)),
    emptyStringMarker: String(pick('empty_string_marker', CONTRACT_DEFAULTS.emptyStringMarker)),
    encoding: String(pick('encoding', CONTRACT_DEFAULTS.encoding)),
    quoting: String(pick('quoting', CONTRACT_DEFAULTS.quoting)),
    quotechar: String(pick('quotechar', CONTRACT_DEFAULTS.quotechar)),
    escapechar: String(pick('escapechar', CONTRACT_DEFAULTS.escapechar)),
    lineTerminator: String(pick('line_terminator', CONTRACT_DEFAULTS.lineTerminator)),
    trailingDelimiter: Boolean(pick('trailing_delimiter', CONTRACT_DEFAULTS.trailingDelimiter)),
    packaging: String(pick('packaging', CONTRACT_DEFAULTS.packaging)),
    // The engine reads `compression`; the validator accepts both.
    codec: String(o.codec ?? o.compression ?? CONTRACT_DEFAULTS.codec) || 'none',
    encryption: String(pick('encryption', CONTRACT_DEFAULTS.encryption)),
    pgpRecipient: String(pick('pgp_recipient', CONTRACT_DEFAULTS.pgpRecipient)),
    checksumAlgorithm: String(o.checksum ?? o.checksum_algorithm ?? ''),
    checksumScope: String(pick('checksum_scope', CONTRACT_DEFAULTS.checksumScope)),
    checksumCovers: String(pick('checksum_covers', CONTRACT_DEFAULTS.checksumCovers)) === 'uncompressed'
      ? 'uncompressed' : 'sent',
    sidecar: String(pick('sidecar', CONTRACT_DEFAULTS.sidecar)),
    digestLine: String(pick('digest_line', CONTRACT_DEFAULTS.digestLine)),
    sequencing: String(pick('sequencing', CONTRACT_DEFAULTS.sequencing)),
    multipartNaming: Boolean(pick('multipart_naming', CONTRACT_DEFAULTS.multipartNaming)),
    redeliveryNaming: String(pick('redelivery_naming', CONTRACT_DEFAULTS.redeliveryNaming)),
  };
}

/**
 * Rebuild output_options: stored unmanaged keys survive untouched; a
 * term equal to the engine default is OMITTED (absent = engine default
 * = validates clean), so untouched feeds keep an unchanged bag.
 */
export function buildOutputOptions(
  opts: ContractOpts,
  stored: Record<string, any> | null | undefined,
): Record<string, any> {
  const out: Record<string, any> = {};
  for (const [k, v] of Object.entries(stored || {})) {
    if (!MANAGED_OPTION_KEYS.includes(k)) out[k] = v;
  }
  const d = CONTRACT_DEFAULTS;
  if (opts.delimiter !== d.delimiter) out.delimiter = opts.delimiter;
  if (opts.header !== d.header) out.header = opts.header;
  if (opts.nullMarker !== d.nullMarker) out.na_rep = opts.nullMarker;
  // '' = not declared — the validator's default (None) means "the ''
  // convention is whatever na_rep is"; only a typed marker is a term.
  if (opts.emptyStringMarker !== '') out.empty_string_marker = opts.emptyStringMarker;
  if (opts.encoding.trim().toLowerCase() !== 'utf-8') out.encoding = opts.encoding.trim();
  if (opts.quoting !== d.quoting) out.quoting = opts.quoting;
  // A cleared quotechar field reads as "back to the default", never as
  // "quote with the empty string" — only a real non-default char ships.
  if (opts.quotechar !== '' && opts.quotechar !== d.quotechar) out.quotechar = opts.quotechar;
  if (opts.escapechar !== '') out.escapechar = opts.escapechar;
  if (opts.lineTerminator !== d.lineTerminator) out.line_terminator = opts.lineTerminator;
  if (opts.trailingDelimiter) out.trailing_delimiter = true;
  if (opts.packaging !== 'none') out.packaging = opts.packaging;
  if (opts.codec !== 'none') out.compression = opts.codec;
  if (opts.encryption !== 'none') out.encryption = opts.encryption;
  if (opts.pgpRecipient.trim()) out.pgp_recipient = opts.pgpRecipient.trim();
  if (opts.checksumAlgorithm) out.checksum = opts.checksumAlgorithm;
  if (opts.checksumScope !== d.checksumScope) out.checksum_scope = opts.checksumScope;
  if (opts.checksumCovers === 'uncompressed') out.checksum_covers = 'uncompressed';
  if (opts.sidecar !== 'none') out.sidecar = opts.sidecar;
  if (opts.digestLine !== d.digestLine) out.digest_line = opts.digestLine;
  if (opts.sequencing !== 'none') out.sequencing = opts.sequencing;
  if (opts.multipartNaming) out.multipart_naming = true;
  if (opts.redeliveryNaming !== d.redeliveryNaming) out.redelivery_naming = opts.redeliveryNaming;
  return out;
}

/**
 * Mirror of contract.py's SEVERITY_ERROR findings that are reachable
 * through this editor (the closed vocabularies are Selects, so typo
 * errors cannot occur here).  These BLOCK the save — the API 422s on
 * them.
 */
export function contractErrors(opts: ContractOpts): string[] {
  const errors: string[] = [];
  if (opts.delimiter.length !== 1) {
    errors.push(`delimiter must be exactly one character, got `
      + `'${opts.delimiter}'.`);
  } else if (opts.delimiter === '\r' || opts.delimiter === '\n') {
    errors.push('a line-break character cannot be the field delimiter.');
  }
  if (opts.encryption === 'pgp' && !opts.pgpRecipient.trim()) {
    errors.push('encryption=pgp declared with no recipient key — there '
      + 'is nobody to encrypt to.');
  }
  if (opts.sidecar !== 'none' && !opts.checksumAlgorithm) {
    errors.push(`sidecar=${opts.sidecar} is declared with no checksum `
      + 'algorithm — a digest sidecar with no digest is a contradiction.');
  }
  return errors;
}

/**
 * Mirror of contract.py's SEVERITY_UNSUPPORTED findings — real
 * counterparty terms the platform cannot honour TODAY (BRD §10
 * "build").  The API records them and returns `contract_unsupported`
 * warnings; the save succeeds.  Shown live so the author is not
 * surprised by the response.
 */
export function contractUnsupportedHints(opts: ContractOpts): string[] {
  const hints: string[] = [];
  const enc = opts.encoding.trim().toLowerCase().replace(/_/g, '-');
  if (enc && enc !== 'utf-8' && enc !== 'utf8') {
    hints.push(`encoding=${opts.encoding}: the CSV renderer hardcodes `
      + 'utf-8 today (§10.1 build).');
  }
  if (opts.quoting !== 'minimal') {
    hints.push(`quoting=${opts.quoting}: the renderer uses Python csv's `
      + 'default (quote when necessary) today (§10.1 build).');
  }
  if (opts.quotechar !== '' && opts.quotechar !== '"') {
    hints.push(`quotechar='${opts.quotechar}': a custom quote character `
      + 'is not reachable today (§10.1 build).');
  }
  if (opts.escapechar !== '') {
    hints.push(`escapechar='${opts.escapechar}': a custom escape `
      + 'character is not reachable today (§10.1 build).');
  }
  if (opts.emptyStringMarker !== ''
      && opts.emptyStringMarker !== opts.nullMarker) {
    hints.push(`empty_string_marker='${opts.emptyStringMarker}': a `
      + 'distinct empty-string convention (vs null marker '
      + `'${opts.nullMarker}') — na_rep conflates NULL and "" today `
      + '(§10.1 partial).');
  }
  if (opts.lineTerminator !== 'crlf') {
    hints.push(`line_terminator=${opts.lineTerminator}: the renderer `
      + 'emits CRLF and the terminator is not configurable today '
      + '(§10.1 build).');
  }
  if (opts.trailingDelimiter) {
    hints.push('trailing_delimiter: not emitted today (§10.1 build).');
  }
  if (opts.packaging !== 'none') {
    hints.push(`packaging=${opts.packaging}: no packaging step exists in `
      + 'the artifact chain today — recorded, not yet honoured '
      + '(§10.2 build).');
  }
  if (opts.encryption === 'pgp') {
    hints.push('encryption=pgp: nothing encrypts the delivered file '
      + 'today (FR-ART-06 build) — recorded, not promised.');
  }
  if (opts.checksumScope === 'whole' || opts.checksumScope === 'both') {
    hints.push(`checksum_scope=${opts.checksumScope}: no whole-of-parts `
      + 'digest step exists today (FR-ART-04 build).');
  }
  if (opts.sidecar === 'per_file' || opts.sidecar === 'manifest') {
    hints.push(`sidecar=${opts.sidecar}: only the .ctl control file `
      + 'carries a digest today (FR-ART-05 build).');
  }
  if (opts.sequencing === 'gapless') {
    hints.push('sequencing=gapless: sequence numbers are state, and no '
      + 'cross-run sequence store exists today (FR-ART-07 build).');
  }
  if (opts.multipartNaming) {
    hints.push('multipart_naming: the filename renderer has no '
      + '_NNN_of_NNNN part tokens today (FR-ART-08 build).');
  }
  return hints;
}

// ── The DELIVERY chain (core/feed/delivery_hops.py via delivery_chain) ───
//
// BRD §11 / §14.2 — delivery as an ordered chain of independently
// retryable hops over the certified output.  The declaration rides the
// feed field `delivery_chain` (the key build_hop_plan reads);
// api/feed_api.py::_refuse_invalid_delivery_chain is the backend
// authority and these mirrors refuse EXACTLY what it refuses, so the
// author learns at typing time, not at 03:00 inside the engine.
// ABSENCE of a chain keeps the feed on today's single-destination path,
// byte-for-byte unchanged; explicit null on update reverts to it.
//
// Two whole refusal families are unreachable here BY CONSTRUCTION and
// so have no mirror function: the target picker is a closed Select over
// the four authorable transports (no unknown target, no empty target,
// and no `control_file` — that trait describes WHAT is sent, not WHERE,
// and the control file already ships alongside its data on every data
// hop), and hops are objects built by this editor (no non-dict entry,
// no non-list chain).

/** The authorable transports — DEFAULT_TARGET_TRAITS minus
 *  `control_file`, exactly the `authorable` list the API refuses
 *  against. */
export const DELIVERY_HOP_TARGETS = ['local', 's3', 'sftp', 'oracle'] as const;
export type DeliveryHopTarget = typeof DELIVERY_HOP_TARGETS[number];

/** `requires` Select sentinel: the key is OMITTED — build_hop_plan then
 *  defaults a non-local hop to the chain's first local hop (it sends
 *  the file that hop materialised), and a local hop to independence. */
export const REQUIRES_AUTO = '';
/** `requires` Select sentinel: explicit `"requires": null` — declared
 *  independence from every other hop. */
export const REQUIRES_INDEPENDENT = '__independent__';

export interface DeliveryHopDraft {
  target: DeliveryHopTarget;
  /** '' → the hop's label defaults to its target type, exactly
   *  build_hop_plan's resolution (`label or target_type`). */
  label: string;
  /** REQUIRES_AUTO | REQUIRES_INDEPENDENT | another hop's label. */
  requires: string;
  /** Kept as text so a cleared field is "default (1 attempt)", never 0. */
  maxAttempts: string;
  // Destination fields — exactly the dest_config keys the delivery
  // adapters read (the hop runner hands hop.config to the same
  // _deliver_to_destination seam the legacy single destination uses).
  path: string;                              // local
  bucket: string;                            // s3
  prefix: string;                            // s3
  host: string;                              // sftp
  port: string;                              // sftp
  username: string;                          // sftp
  password: string;                          // sftp
  remoteDir: string;                         // sftp
  connectionId: string;                      // oracle (connection_id)
  table: string;                             // oracle
  /** Edit mode: the stored label this hop came back under.  A PUT
   *  restores masked '***' credentials by LABEL (feed_api.py::
   *  _unmask_delivery_chain), so renaming orphans the stored secret. */
  storedLabel: string | null;
  /** Edit mode: the stored hop's password came back masked ('***'). */
  passwordMasked: boolean;
  /** 2026-09-24 -- every stored config key this draft does not model (an
   *  SFTP host key, key path, vault account, ...), carried through a save
   *  while the hop keeps the target it came from (``extraTarget``).  The
   *  draft used to rebuild the config from its own fields and DROP them. */
  extra: Record<string, any>;
  extraTarget: DeliveryHopTarget | null;
}

export interface DeliveryChainDraft {
  /** The Switch: off = today's single destination, unchanged, with NO
   *  delivery_chain key in the payload at all. */
  enabled: boolean;
  /** Declared order IS delivery order — a chain lands internally
   *  before it reaches a counterparty. */
  hops: DeliveryHopDraft[];
}

export const EMPTY_DELIVERY_CHAIN_DRAFT: DeliveryChainDraft = {
  enabled: false, hops: [],
};

export function emptyDeliveryHop(
  target: DeliveryHopTarget = 'local',
): DeliveryHopDraft {
  return {
    target, label: '', requires: REQUIRES_AUTO, maxAttempts: '',
    path: '', bucket: '', prefix: '',
    host: '', port: '22', username: '', password: '', remoteDir: '/',
    connectionId: '', table: '',
    storedLabel: null, passwordMasked: false,
    extra: {}, extraTarget: null,
  };
}

/** The config keys the hop draft models, per target -- everything else in a
 *  stored hop config rides in ``extra``. */
const MODELLED_HOP_KEYS = new Set([
  'path', 'bucket', 'prefix', 'host', 'port', 'username', 'password',
  'remote_dir', 'connection_id', 'table',
]);

/** The hop's effective identity — EXACTLY build_hop_plan's resolution:
 *  explicit label (trimmed, case preserved), else the target type. */
export function deliveryHopLabel(hop: DeliveryHopDraft): string {
  return hop.label.trim() || hop.target;
}

/** Rebuild the draft from a stored chain (edit mode).  A feed with no
 *  chain hydrates to the untouched EMPTY draft, so saving it keeps
 *  sending no delivery_chain key at all. */
export function hydrateDeliveryChainDraft(
  chain: Array<Record<string, any>> | null | undefined,
): DeliveryChainDraft {
  if (!Array.isArray(chain) || chain.length === 0) {
    return EMPTY_DELIVERY_CHAIN_DRAFT;
  }
  return {
    enabled: true,
    hops: chain.map((entry) => {
      const raw = String(entry?.target || entry?.target_type || '').toLowerCase();
      const target = (DELIVERY_HOP_TARGETS as readonly string[]).includes(raw)
        ? raw as DeliveryHopTarget : 'local';
      const cfg = (entry?.config && typeof entry.config === 'object')
        ? entry.config : {};
      const label = String(entry?.label || '') || target;
      return {
        target,
        label,
        requires: !('requires' in (entry || {}))
          ? REQUIRES_AUTO
          : (entry.requires == null
              ? REQUIRES_INDEPENDENT : String(entry.requires)),
        maxAttempts: entry?.max_attempts != null ? String(entry.max_attempts) : '',
        path: String(cfg.path ?? ''),
        bucket: String(cfg.bucket ?? ''),
        prefix: String(cfg.prefix ?? ''),
        host: String(cfg.host ?? ''),
        port: cfg.port != null ? String(cfg.port) : '22',
        username: String(cfg.username ?? ''),
        password: String(cfg.password ?? ''),
        remoteDir: String(cfg.remote_dir ?? '/'),
        connectionId: cfg.connection_id != null ? String(cfg.connection_id) : '',
        table: String(cfg.table ?? ''),
        storedLabel: label,
        passwordMasked: cfg.password === '***',
        extra: Object.fromEntries(
          Object.entries(cfg).filter(([k]) => !MODELLED_HOP_KEYS.has(k))),
        extraTarget: target,
      };
    }),
  };
}

/**
 * Mirror of _refuse_invalid_delivery_chain's refusals that are
 * REACHABLE through this editor — same rules, same reasons, plus what
 * to do instead.  The server is the backstop, not the only gate.
 */
export function deliveryChainErrors(draft: DeliveryChainDraft): string[] {
  if (!draft.enabled) return [];
  const errors: string[] = [];
  // 2026-09-24 -- an SFTP hop delivery would refuse (no pinned server key,
  // no credential for its sign-in method) is refused HERE, naming the hop:
  // it used to save cleanly and fail on every run.
  draft.hops.forEach((hop, i) => {
    if (hop.target !== 'sftp') return;
    sftpConfigProblems(buildHopConfig(hop)).forEach(p =>
      errors.push(`Hop ${i + 1} (${deliveryHopLabel(hop)}): ${p}`));
  });
  if (draft.hops.length === 0) {
    errors.push(
      'The delivery chain is on but has no hops. An empty chain is '
      + 'ambiguous — the engine would silently fall back to single-'
      + 'destination delivery — so the backend refuses it. Add at least '
      + 'one hop, or switch the chain off to keep single-destination '
      + 'delivery.');
    return errors;
  }
  const labels = draft.hops.map(deliveryHopLabel);
  const seen = new Set<string>();
  draft.hops.forEach((hop, i) => {
    const label = labels[i];
    if (seen.has(label)) {
      errors.push(
        `Hop ${i + 1} ('${label}') duplicates the label of an earlier `
        + 'hop. Delivery attempts are recorded against the label, so two '
        + 'hops sharing one make their attempt rows unattributable. Give '
        + 'each hop a distinct label.');
    }
    seen.add(label);
    if (hop.target === 's3' && !hop.bucket.trim()) {
      errors.push(
        `Hop ${i + 1} ('${label}'): an s3 hop has no destination — name `
        + 'the bucket it lands in. A destination-less hop can only fail '
        + 'at delivery time.');
    }
    if (hop.target === 'sftp' && !hop.host.trim()) {
      errors.push(
        `Hop ${i + 1} ('${label}'): an sftp hop has no destination — `
        + 'name the host it lands on. A destination-less hop can only '
        + 'fail at delivery time.');
    }
    if (hop.target === 'oracle' && !hop.connectionId.trim()) {
      errors.push(
        `Hop ${i + 1} ('${label}'): an oracle hop has no destination — `
        + 'pick the connection it loads through. A destination-less hop '
        + 'can only fail at delivery time.');
    }
    if (hop.target === 'oracle' && !hop.table.trim()) {
      errors.push(
        `Hop ${i + 1} ('${label}'): an oracle hop needs the table it `
        + 'inserts into. A destination-less hop can only fail at '
        + 'delivery time.');
    }
    const ma = hop.maxAttempts.trim();
    if (ma !== '' && !Number.isInteger(Number(ma))) {
      errors.push(
        `Hop ${i + 1} ('${label}'): max attempts must be a whole `
        + `number, got '${ma}'. Clear it for the default (1 attempt).`);
    }
    // `requires` is picked from a Select, but deleting or renaming the
    // hop it points at leaves a stale reference behind — and a hop
    // requiring a label not in this chain (or itself) would be SKIPPED
    // on every run, silently, forever.
    if (hop.requires !== REQUIRES_AUTO
        && hop.requires !== REQUIRES_INDEPENDENT) {
      if (hop.requires === label) {
        errors.push(
          `Hop ${i + 1} ('${label}') requires itself — it would be `
          + 'skipped on every run. Set "runs after" to automatic or '
          + "independent, or name another hop's label.");
      } else if (!labels.includes(hop.requires)) {
        errors.push(
          `Hop ${i + 1} ('${label}') requires '${hop.requires}', which `
          + 'is not a hop label in this chain any more — it would be '
          + 'skipped on every run. Point "runs after" at an existing '
          + 'hop, or set it to independent.');
      }
    }
  });
  return errors;
}

/**
 * The rename warning (advisory, shown the moment the label changes —
 * the save itself is legal).  The label is the identity delivery
 * attempts are recorded against, AND the key a PUT restores masked
 * credentials by (_unmask_delivery_chain matches hops BY LABEL), so a
 * rename both starts a fresh attempt history and orphans the stored
 * password.
 */
export function deliveryHopRenameWarning(hop: DeliveryHopDraft): string | null {
  if (hop.storedLabel == null) return null;
  if (deliveryHopLabel(hop) === hop.storedLabel) return null;
  let msg = `This hop's delivery history is recorded under `
    + `'${hop.storedLabel}' — the new label starts a fresh attempt `
    + 'history.';
  if (hop.passwordMasked && hop.password === '***') {
    msg += ' The stored password is keyed to the old label and will NOT '
      + 'carry over: re-enter it below, or this hop saves with no '
      + 'password at all.';
  }
  return msg;
}

/** One hop's `config` — exactly the dest_config keys its adapter
 *  reads, and nothing from any other target (switching targets can
 *  therefore never leave a stale field in the payload). */
function buildHopConfig(hop: DeliveryHopDraft): Record<string, any> {
  // Unmodelled stored keys survive while the hop keeps its target; a target
  // switch still starts clean, as before.
  const out: Record<string, any> = hop.extraTarget === hop.target
    ? Object.fromEntries(Object.entries(hop.extra || {})
        .filter(([, v]) => v !== undefined && v !== ''))
    : {};
  if (hop.target === 'local') {
    if (hop.path.trim()) out.path = hop.path.trim();
    return out;
  }
  if (hop.target === 's3') {
    out.bucket = hop.bucket.trim();
    if (hop.prefix.trim()) out.prefix = hop.prefix.trim();
    return out;
  }
  if (hop.target === 'sftp') {
    out.host = hop.host.trim();
    const port = parseInt(hop.port, 10);
    out.port = Number.isFinite(port) ? port : 22;
    if (hop.username.trim()) out.username = hop.username.trim();
    // GET masks a stored password to '***' and a PUT restores the real
    // value BY LABEL — so the mask may ride back ONLY under the exact
    // stored label it belongs to.  Under any other label (a renamed
    // hop, a new hop) there is nothing to restore and the literal
    // '***' would be STORED as the credential; drop it instead.
    if (hop.password
        && !(hop.password === '***'
             && deliveryHopLabel(hop) !== hop.storedLabel)) {
      out.password = hop.password;
    }
    out.remote_dir = hop.remoteDir.trim() || '/';
    return out;
  }
  // oracle
  if (hop.connectionId.trim()) out.connection_id = Number(hop.connectionId);
  if (hop.table.trim()) out.table = hop.table.trim();
  return out;
}

/**
 * The `delivery_chain` list, or null when no chain is declared
 * (absence = the legacy single-destination path, untouched; the caller
 * decides omit-vs-explicit-null exactly as for schedule_declaration).
 * Hop order in the list IS delivery order.
 */
export function buildDeliveryChain(
  draft: DeliveryChainDraft,
): Array<Record<string, any>> | null {
  if (!draft.enabled) return null;
  return draft.hops.map((hop) => {
    const entry: Record<string, any> = {
      target: hop.target,
      label: deliveryHopLabel(hop),
      config: buildHopConfig(hop),
    };
    if (hop.requires === REQUIRES_INDEPENDENT) entry.requires = null;
    else if (hop.requires !== REQUIRES_AUTO) entry.requires = hop.requires;
    const ma = hop.maxAttempts.trim();
    if (ma !== '' && Number.isInteger(Number(ma))) {
      entry.max_attempts = Number(ma);
    }
    return entry;
  });
}

// ── The ORACLE destination (core/feed_engine.py::_deliver_oracle) ───────
//
// The keys below are EXACTLY the ones the two delivery lanes read from
// `destination_config` when `destination_type = 'oracle'`:
//   _deliver_oracle (native)          connection_id, table, mode,
//                                     batch_size, max_error_percent
//   spark/jobs/generic_feed.py        connection_id (via feed_conf.py),
//     _write_oracle                   table, mode, batch_size
// `connection_id` and `table` are REQUIRED — the engine raises on either
// missing, and the table must match its identifier regex (SCHEMA.TABLE
// only; anything else is refused as injection).  Until 2026-09-14 the
// authoring page offered ORACLE in the dropdown and sent `{}` for it
// (recorded in docs/SPARK_K8S_LIVE_POD_2026_09_13.html §6): the PUT
// route accepted that and the feed refused at 03:00.  An option that
// cannot produce a runnable config must refuse at author time, with the
// field named.

export const ORACLE_DEST_MODES = ['append', 'truncate_insert'] as const;
export type OracleDestMode = typeof ORACLE_DEST_MODES[number];

/** Same regex as _deliver_oracle's identifier check — kept in step. */
export const ORACLE_TABLE_RE =
  /^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)?$/;

export interface OracleDestinationDraft {
  /** The QueryStudio connection the rows load through (connection_id). */
  connectionId: string;
  /** Target table, `TABLE` or `SCHEMA.TABLE`. */
  table: string;
  /** `append` (the engine default) or `truncate_insert`. */
  mode: OracleDestMode;
  /** Kept as text: blank = the platform default (oracle.batch_size). */
  batchSize: string;
}

export const EMPTY_ORACLE_DEST_DRAFT: OracleDestinationDraft = {
  connectionId: '', table: '', mode: 'append', batchSize: '',
};

/** Edit mode: the stored destination_config, as GET returns it. */
export function hydrateOracleDestinationDraft(
  cfg: Record<string, any> | null | undefined,
): OracleDestinationDraft {
  const c = cfg || {};
  const mode = String(c.mode ?? 'append');
  return {
    connectionId: c.connection_id != null ? String(c.connection_id) : '',
    table: String(c.table ?? ''),
    mode: (ORACLE_DEST_MODES as readonly string[]).includes(mode)
      ? (mode as OracleDestMode) : 'append',
    batchSize: c.batch_size != null ? String(c.batch_size) : '',
  };
}

/**
 * The refusals, each naming the field and the rule — the same ones the
 * engine raises at delivery time, shown while typing instead.
 *
 * `oracleConnectionIds` is the ids of the connections whose type is
 * `oracle`, or null when the list is not known (unknown is not empty:
 * a stored id is never refused on the strength of a list that failed
 * to load).
 */
export function oracleDestinationErrors(
  draft: OracleDestinationDraft,
  oracleConnectionIds: number[] | null = null,
): string[] {
  const errors: string[] = [];
  const cid = draft.connectionId.trim();
  if (!cid) {
    errors.push(
      'Oracle destination has no connection — pick the Oracle connection '
      + 'the rows load through (destination_config.connection_id). The '
      + 'engine refuses a destination without one at delivery time.');
  } else if (oracleConnectionIds && !oracleConnectionIds.includes(Number(cid))) {
    errors.push(
      `Connection #${cid} is not an Oracle connection. Delivery builds `
      + 'its DSN from the connection\'s host, port and service_name, '
      + 'which only an Oracle connection carries.');
  }
  const table = draft.table.trim();
  if (!table) {
    errors.push(
      'Oracle destination has no target table — name the table the rows '
      + 'insert into (destination_config.table), as TABLE or '
      + 'SCHEMA.TABLE.');
  } else if (!ORACLE_TABLE_RE.test(table)) {
    errors.push(
      `Target table '${table}' is not a valid Oracle identifier — the `
      + 'engine accepts TABLE or SCHEMA.TABLE (letters, digits and '
      + 'underscore, not starting with a digit) and refuses anything '
      + 'else as injection.');
  }
  const bs = draft.batchSize.trim();
  if (bs !== '' && (!Number.isInteger(Number(bs)) || Number(bs) <= 0)) {
    errors.push(
      `Batch size must be a positive whole number of rows, got '${bs}'. `
      + 'Clear it for the platform default.');
  }
  return errors;
}

/**
 * The `destination_config` for an Oracle destination — field for field
 * what `_deliver_oracle` and the Spark lane's `_write_oracle` read.
 * Optional keys are omitted when blank so the engine's own defaults
 * apply (an omitted key is "use the default"; a stored 0 would not be).
 */
export function buildOracleDestinationConfig(
  draft: OracleDestinationDraft,
): Record<string, any> {
  const out: Record<string, any> = {};
  if (draft.connectionId.trim()) out.connection_id = Number(draft.connectionId);
  if (draft.table.trim()) out.table = draft.table.trim();
  out.mode = draft.mode;
  const bs = draft.batchSize.trim();
  if (bs !== '' && Number.isInteger(Number(bs)) && Number(bs) > 0) {
    out.batch_size = Number(bs);
  }
  return out;
}

/** A partition key typed as "A, B" -> ["A", "B"] (blanks dropped). 2026-10-14. */
export function splitColumns(text: string | null | undefined): string[] {
  return String(text ?? '').split(',').map(s => s.trim()).filter(Boolean);
}

/** A stored key (one name, "A, B", or a list) as the text the field shows. */
export function columnsText(v: unknown): string {
  if (Array.isArray(v)) return v.map(x => String(x).trim()).filter(Boolean).join(', ');
  return splitColumns(v == null ? '' : String(v)).join(', ');
}
