/**
 * BF-469 (2026-05-19) — WebSocket as a module-level singleton service,
 * fully decoupled from the React component lifecycle.
 *
 * Why this exists
 * ----------------
 * BF-467 / BF-468 fixed two close-path bugs in the React-managed
 * WebSocket: the heartbeat watchdog (BF-467), and the conditional-
 * return unmounts in AppRoutes (BF-468).  Both fixes were correct
 * but the underlying ARCHITECTURE remained fragile — any future
 * contributor restructuring the route tree, adding a key prop to a
 * parent, or wrapping the providers in a new conditional could
 * silently re-introduce close/reconnect cycles.
 *
 * The permanent fix is to take the WebSocket OUT of React.  React is
 * a UI library; it should not own long-lived I/O connections.  This
 * module owns the WS for the entire browser tab lifetime.  React
 * components subscribe to it via the thin WebSocketContext wrapper,
 * but cannot accidentally tear it down.
 *
 * Same pattern as Redux store, Apollo Client, TanStack-Query — state
 * that must persist across the React tree lives at module scope.
 *
 * Public surface (used by WebSocketContext, useWebSocket consumers)
 * ----------------------------------------------------------------
 *   wsService.start()                     // idempotent; safe to call repeatedly
 *   wsService.isConnected                 // current state
 *   wsService.addListener(cb): unsubscribe
 *   wsService.subscribeToState(cb): unsubscribe   // notified on connect/disconnect
 *   wsService.send(msg)                   // best-effort, drops if not OPEN
 *   wsService.registerExecutionHeartbeat(id): unsubscribe
 *
 * Notification surface
 * --------------------
 * The service runs entirely outside React.  Components that want to
 * re-render on state change subscribe via subscribeToState().  This
 * is what the React Context wrapper uses.
 */
import { resolveApiBaseUrl } from './api/core';
// 2026-06-30 deep-dive #8: read apiUrl at connect() time, not at
// module import.  The WS service auto-starts before App mounts so
// its module-import-time snapshot of API_BASE_URL would freeze to
// the empty stub before /config.json's apiUrl landed.  WebSocket
// would then connect to the wrong origin (or current host with the
// wrong path) for the whole session.

export interface WsMessage {
  type: string;
  [key: string]: unknown;
}

const WS_USERNAME_KEY = 'qs_ws_username';
const QS_AUTH_EVENT = 'qs-auth-changed';

class WsService {
  private ws: WebSocket | null = null;
  private clientId = `client-${Date.now()}`;
  private listeners = new Set<(msg: WsMessage) => void>();
  private stateListeners = new Set<(state: WsState) => void>();
  private reconnectTimer: ReturnType<typeof setTimeout> | null = null;
  private reconnectAttempts = 0;
  private connectionError: string | null = null;
  private isConnectedFlag = false;
  // BF-471 (2026-05-19) — debounced "visual" state for the Live/Offline
  // indicator.  Flips to false only after the WS has been disconnected
  // for >= DEBOUNCE_OFFLINE_MS.  Brief reconnect cycles (1-2 s under
  // genuine network flap) don't visibly flip the indicator → app feels
  // stable instead of "blinking offline" during normal recovery.
  private visualConnectedFlag = false;
  private offlineDebounceTimer: ReturnType<typeof setTimeout> | null = null;
  private readonly DEBOUNCE_OFFLINE_MS = 5_000;
  private lastMessage: WsMessage | null = null;
  private recentDisconnects: number[] = [];
  private executionHeartbeats = new Set<string>();
  // 2026-10-17 -- scopes this tab WATCHES (the feed board): re-asked on
  // every (re)connect after identify, because the server keeps a watch on
  // the CONNECTION and a reconnect is a new one.
  private watches = new Set<string>();
  private heartbeatPingInterval: ReturnType<typeof setInterval> | null = null;
  private started = false;
  // 2026-07-15 reliability fix #1 — server-ping freshness watchdog.
  // The BACKEND sends an app-level {type:"ping"} every ~10s.  We record
  // when the last one ARRIVED; if none arrives for PING_STALE_MS while
  // the socket claims to be OPEN, the socket is half-open (upstream
  // dead, e.g. LB idle-killed, pod gone without FIN) — close it so the
  // existing onclose→reconnect path recovers.
  //
  // Deliberately DIFFERENT from the removed BF-467 watchdog: that one
  // was keyed on CLIENT timers (event-loop blocks stalled the timer AND
  // the freshness stamp asymmetrically → false-positive teardowns of
  // healthy sockets).  This one is keyed on SERVER pings RECEIVED —
  // after an event-loop block, queued ping message events are processed
  // BEFORE the queued interval callback, so lastServerPingAt is fresh
  // again by the time the check runs.  Immune to that failure mode.
  private lastServerPingAt = 0;
  private serverPingWatchdog: ReturnType<typeof setInterval> | null = null;
  private readonly PING_WATCHDOG_CHECK_MS = 30_000;
  // 3.5× the 10s server ping cadence — tolerates 3 dropped/late pings.
  private readonly PING_STALE_MS = 35_000;

  // ── Public API ──────────────────────────────────────────────────────────

  /** Start the singleton.  Idempotent — subsequent calls are no-ops. */
  start(): void {
    if (this.started) return;
    this.started = true;
    // BF-464v2 plumbing — re-identify when AuthContext writes the
    // qs_ws_username sessionStorage key post-login.
    if (typeof window !== 'undefined') {
      window.addEventListener(QS_AUTH_EVENT, this.handleAuthChanged);
    }
    // GAP-fix (BF-469 deep-dive #2): tab-refocus recovery.
    // Mobile browsers (and some desktop) close idle WS in background
    // tabs.  When the user returns to the tab, kick a forceReconnect
    // so they get live updates again immediately instead of waiting
    // for the next exponential-backoff tick (which may have given
    // up if the tab was hidden for long enough).
    if (typeof document !== 'undefined') {
      document.addEventListener('visibilitychange', this.handleVisibilityChange);
    }
    this.connect();
    this.startExecutionHeartbeatPinger();
    this.startServerPingWatchdog();
  }

  /** Current connection state — read-only snapshot.
   *  BF-471: ``isConnected`` returns the DEBOUNCED visual flag, not
   *  the raw socket state.  Brief reconnect cycles don't flip it.
   *  For raw socket state (e.g. before calling send()), use
   *  ``rawIsConnected``. */
  get isConnected(): boolean { return this.visualConnectedFlag; }
  get rawIsConnected(): boolean { return this.isConnectedFlag; }
  get currentError(): string | null { return this.connectionError; }
  get currentLastMessage(): WsMessage | null { return this.lastMessage; }
  /** 2026-07-15 reliability fix #4 — surfaced connection phase for the
   *  Layout chip.  'reconnecting' whenever the raw socket is down (the
   *  service now retries FOREVER, so 'gave_up' is kept in the type only
   *  for API compat — it is never emitted for visible tabs). */
  get connectionPhase(): WsPhase {
    return this.isConnectedFlag ? 'connected' : 'reconnecting';
  }

  /** Subscribe to incoming WS messages.  Returns unsubscribe fn. */
  addListener(cb: (msg: WsMessage) => void): () => void {
    this.listeners.add(cb);
    return () => { this.listeners.delete(cb); };
  }

  /** Subscribe to state changes (connect/disconnect/error/last-message
   *  updates).  Used by the React Context to drive re-renders.
   *  Returns unsubscribe fn. */
  subscribeToState(cb: (state: WsState) => void): () => void {
    this.stateListeners.add(cb);
    return () => { this.stateListeners.delete(cb); };
  }

  /** Send a message (best-effort).  Logs a warning if WS isn't open. */
  send(message: object): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(message));
    } else {
      console.warn('[wsService] send dropped — WebSocket not OPEN');
    }
  }

  /** Phase 139 honest-fix #1 — register an execution_id to be
   *  heartbeat-tracked.  While registered, the service pings the
   *  backend every 10 s.  Returns unsubscribe fn. */
  registerExecutionHeartbeat(executionId: string): () => void {
    if (!executionId) return () => {};
    this.executionHeartbeats.add(executionId);
    return () => { this.executionHeartbeats.delete(executionId); };
  }

  /** 2026-10-17 -- WATCH a scope ("feed_board": every feed's events for a
   *  principal who sees the whole estate -- core/websocket_manager.py
   *  ``set_watch``).  Sent now if the socket is open and again after every
   *  reconnect / re-identify; the server answers ``{type: 'watching', ok,
   *  reason}`` on the socket.  Returns the unwatch. */
  watch(scope: string): () => void {
    if (!scope) return () => {};
    this.watches.add(scope);
    this.sendWatch(scope, true);
    return () => {
      this.watches.delete(scope);
      this.sendWatch(scope, false);
    };
  }

  private sendWatch(scope: string, on: boolean): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      try { this.ws.send(JSON.stringify({ type: on ? 'watch' : 'unwatch', scope })); } catch { /* best-effort */ }
    }
  }

  private resendWatches(): void {
    this.watches.forEach(s => this.sendWatch(s, true));
  }

  // ── Internals ───────────────────────────────────────────────────────────

  private notifyState(): void {
    const snapshot: WsState = {
      // BF-471 — expose the DEBOUNCED state to subscribers so React
      // consumers don't visibly flip on brief reconnect cycles.  Raw
      // socket state is available separately for code that needs it.
      isConnected: this.visualConnectedFlag,
      lastMessage: this.lastMessage,
      connectionError: this.connectionError,
      phase: this.connectionPhase,
    };
    this.stateListeners.forEach(cb => {
      try { cb(snapshot); } catch (err) {
        console.error('[wsService] state listener threw:', err);
      }
    });
  }

  /** BF-471 — drive the debounced visual state.
   *  - onopen → flip visual to true IMMEDIATELY (users want the
   *    confirmation as soon as we're alive)
   *  - onclose → start a timer; flip visual to false ONLY if we're
   *    still disconnected after DEBOUNCE_OFFLINE_MS.  Any onopen
   *    within the window cancels the pending flip. */
  private updateVisualConnected(connected: boolean): void {
    if (connected) {
      if (this.offlineDebounceTimer) {
        clearTimeout(this.offlineDebounceTimer);
        this.offlineDebounceTimer = null;
      }
      if (!this.visualConnectedFlag) {
        this.visualConnectedFlag = true;
        this.notifyState();
      }
      return;
    }
    // Disconnected — schedule visual flip if not already pending.
    if (this.offlineDebounceTimer) return;  // already scheduled
    if (!this.visualConnectedFlag) return;  // already shown offline
    this.offlineDebounceTimer = setTimeout(() => {
      this.offlineDebounceTimer = null;
      if (!this.isConnectedFlag) {
        this.visualConnectedFlag = false;
        this.notifyState();
      }
    }, this.DEBOUNCE_OFFLINE_MS);
  }

  /** Public: force a fresh connect attempt.  Called by tab-refocus
   *  recovery and by code that wants to retry immediately instead of
   *  waiting for the next backoff tick.  Safe to call when already
   *  connected — does nothing. */
  forceReconnect(): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) return;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    // Reset attempts so backoff doesn't immediately give up again.
    this.reconnectAttempts = 0;
    this.connect();
  }

  private connect(): void {
    let ws: WebSocket | null = null;
    try {
      const apiBase = resolveApiBaseUrl() || `${window.location.protocol}//${window.location.host}`;
      const wsBase = apiBase.replace(/^http/, 'ws');
      const wsUrl = `${wsBase}/ws/${this.clientId}`;
      ws = new WebSocket(wsUrl);

      ws.onopen = () => {
        console.log(`[wsService:${this.clientId}] connected → ${wsUrl}`);
        this.isConnectedFlag = true;
        this.connectionError = null;
        this.reconnectAttempts = 0;
        // Fix #1 — a fresh connection starts "fresh": seed the server-ping
        // stamp so the watchdog doesn't judge a brand-new socket stale.
        this.lastServerPingAt = Date.now();
        // BF-471 — flip visual indicator to "Live" immediately.
        this.updateVisualConnected(true);
        // Identify if we already know the user
        try {
          const username = sessionStorage.getItem(WS_USERNAME_KEY) || '';
          if (username) {
            ws.send(JSON.stringify({ type: 'identify', username, token: this.getAuthToken() }));
            console.log(`[wsService:${this.clientId}] identified as '${username}'`);
          } else {
            console.log(`[wsService:${this.clientId}] anonymous (no qs_ws_username yet)`);
          }
        } catch { /* best-effort */ }
        // 2026-10-17 -- a watch lives on the CONNECTION: ask again, after identify
        this.resendWatches();
        // BF-567 (2026-05-29): re-attach to in-flight execution heartbeats
        // after reconnect.  Without this, a brief WS drop mid-query left
        // the registry warm on the client but the SERVER lost the
        // subscription — subsequent execution_complete events for that
        // execution_id would not reach this client.  Re-send identify
        // + a "reattach" message naming every active execution_id so the
        // backend re-binds them to this socket.
        try {
          if (this.executionHeartbeats.size > 0
              && this.ws && this.ws.readyState === WebSocket.OPEN) {
            const eids = Array.from(this.executionHeartbeats);
            this.ws.send(JSON.stringify({
              type: 'reattach_executions',
              execution_ids: eids,
            }));
            console.log(
              `[wsService:${this.clientId}] BF-567 reattached ${eids.length} ` +
              `in-flight execution(s) after reconnect`);
          }
        } catch (reattachErr) {
          console.warn('[wsService] BF-567 reattach failed:', reattachErr);
        }
        this.notifyState();
      };

      ws.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data) as WsMessage;
          // Server ping → pong back; don't fan out
          if (message.type === 'ping') {
            // Fix #1 — record freshness: this is the signal the
            // server-ping watchdog keys on.
            this.lastServerPingAt = Date.now();
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
              this.ws.send(JSON.stringify({ type: 'pong' }));
            }
            return;
          }
          // Per-user filter (BF-464v2): user-scoped messages skip
          // when they're addressed to a different user.  System-wide
          // messages (no username field) always pass.
          if (message.username) {
            try {
              const currentUser = sessionStorage.getItem(WS_USERNAME_KEY) || '';
              if (currentUser && message.username !== currentUser) return;
            } catch { /* pass through on read error */ }
          }
          this.lastMessage = message;
          this.notifyState();
          this.listeners.forEach(cb => {
            try { cb(message); } catch (err) {
              console.error('[wsService] listener threw — isolated:', err);
            }
          });
        } catch (err) {
          console.error('[wsService] message parse error:', err);
        }
      };

      ws.onerror = () => {
        this.connectionError = 'Connection error occurred';
        this.notifyState();
      };

      ws.onclose = (event) => {
        const now = Date.now();
        this.recentDisconnects = this.recentDisconnects.filter(t => now - t < 60_000);
        this.recentDisconnects.push(now);
        const burstCount = this.recentDisconnects.length;
        console.warn(
          `[wsService:${this.clientId}] DISCONNECTED · code=${event.code} · ` +
          `reason="${event.reason || ''}" · burst=${burstCount}/60s · ` +
          `attempt=${this.reconnectAttempts + 1}`,
        );
        if (burstCount >= 3) {
          console.error(
            `[wsService:${this.clientId}] DISCONNECT STORM — ${burstCount} in 60s.`,
          );
        }
        this.isConnectedFlag = false;
        this.ws = null;
        // BF-471 — schedule visual flip to "Offline" but only after
        // DEBOUNCE_OFFLINE_MS.  Brief reconnect cycles don't show.
        this.updateVisualConnected(false);
        this.notifyState();

        // 2026-07-15 reliability fix #3 — NEVER give up.  Exponential
        // backoff caps at 30s and keeps retrying forever (the 60s storm
        // cooldown below already prevents tight loops).  The old
        // 10-attempt give-up left long-lived tabs permanently offline
        // after ~1 minute of backend downtime.
        const STORM_THRESHOLD = 5;
        const STORM_COOLDOWN_MS = 60_000;
        let delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts), 30_000);
        if (burstCount >= STORM_THRESHOLD) {
          delay = STORM_COOLDOWN_MS;
          console.warn(
            `[wsService:${this.clientId}] STORM COOLDOWN — pausing reconnects ${delay}ms.`,
          );
        }
        // Fix #3 — ±20% jitter so a fleet of browsers doesn't reconnect
        // in lockstep after a pod restart (thundering herd).
        delay = Math.round(delay * (0.8 + Math.random() * 0.4));
        console.log(`[wsService:${this.clientId}] reconnect in ${delay}ms`);
        this.reconnectTimer = setTimeout(() => {
          this.reconnectAttempts += 1;
          this.connect();
        }, delay);
      };

      this.ws = ws;
    } catch (err) {
      // GAP-fix (BF-469 deep-dive #1): construction failure
      // (malformed URL, browser blocks WS, etc.) used to leave the
      // service permanently broken because no onclose ever fired
      // and no reconnect was scheduled.  Now: schedule a reconnect
      // with the same exponential backoff so a transient network
      // hiccup at app boot recovers.
      this.connectionError = (err as Error).message;
      console.error(`[wsService:${this.clientId}] connect() construction failed: ${this.connectionError}`);
      this.notifyState();
      // Fix #3 — retry forever here too, with the same jittered backoff.
      const delay = Math.round(
        Math.min(1000 * Math.pow(2, this.reconnectAttempts), 30_000)
        * (0.8 + Math.random() * 0.4));
      this.reconnectTimer = setTimeout(() => {
        this.reconnectAttempts += 1;
        this.connect();
      }, delay);
    }
  }

  private handleVisibilityChange = (): void => {
    // Only react on returning to foreground
    if (typeof document === 'undefined' || document.visibilityState !== 'visible') return;
    // If we're already connected, verify the connection is actually ALIVE
    // (Fix #1): an OPEN readyState with stale server pings is a half-open
    // socket — the old early-return here left the UI showing "Live" with
    // a frozen timeline forever.  Close it; onclose schedules the
    // reconnect (attempts reset → ~1s).
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      const pingAgeMs = this.lastServerPingAt > 0
        ? Date.now() - this.lastServerPingAt : 0;
      if (pingAgeMs > this.PING_STALE_MS) {
        console.warn(
          `[wsService:${this.clientId}] tab visible — socket OPEN but last ` +
          `server ping was ${Math.round(pingAgeMs / 1000)}s ago (stale > ` +
          `${this.PING_STALE_MS}ms). Treating as half-open; closing to force reconnect.`,
        );
        this.reconnectAttempts = 0;
        try { this.ws.close(); } catch { /* onclose still fires */ }
      }
      return;
    }
    // If we're CONNECTING, let it finish.
    if (this.ws && this.ws.readyState === WebSocket.CONNECTING) return;
    // Otherwise: closed / null / failed.  Force a fresh attempt
    // (resets the give-up counter too).
    console.log(`[wsService:${this.clientId}] tab visible — forcing reconnect`);
    this.forceReconnect();
  };

  /**
   * WS AUTH (2026-07-16): the current session token, read from the same
   * `qs_auth` localStorage entry the HTTP client uses for `Bearer`. Sent in
   * the identify frame so the server can bind this socket to the AUTHENTICATED
   * user instead of trusting a spoofable claimed username (cross-user
   * execution_progress snoop). Best-effort — undefined when logged out.
   */
  private getAuthToken(): string | undefined {
    try {
      const raw = localStorage.getItem('qs_auth');
      if (raw) {
        const parsed = JSON.parse(raw) as { token?: string };
        if (parsed && typeof parsed.token === 'string' && parsed.token) {
          return parsed.token;
        }
      }
    } catch { /* best-effort */ }
    return undefined;
  }

  private handleAuthChanged = (): void => {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
    try {
      const username = sessionStorage.getItem(WS_USERNAME_KEY) || '';
      if (username) {
        this.ws.send(JSON.stringify({ type: 'identify', username, token: this.getAuthToken() }));
        console.log(`[wsService:${this.clientId}] re-identified as '${username}' (auth resolved post-connect)`);
        // the server decides a watch from the IDENTIFIED principal: ask again
        this.resendWatches();
      }
    } catch { /* silently ignore */ }
  };

  private startExecutionHeartbeatPinger(): void {
    if (this.heartbeatPingInterval) return;
    this.heartbeatPingInterval = setInterval(() => {
      if (this.executionHeartbeats.size === 0) return;
      const wsOpen = !!this.ws && this.ws.readyState === WebSocket.OPEN;
      this.executionHeartbeats.forEach(eid => {
        if (wsOpen) {
          try {
            this.ws!.send(JSON.stringify({
              type: 'execution_heartbeat',
              execution_id: eid,
            }));
            return;
          } catch { /* fall through to HTTP */ }
        }
        // HTTP fallback (when WS is reconnecting) — preserves
        // smart-cancel signal end-to-end.  Phase 141 honest-fix.
        try {
          let authHeader = '';
          try {
            const raw = localStorage.getItem('qs_auth');
            if (raw) {
              const parsed = JSON.parse(raw) as { token?: string };
              if (parsed && typeof parsed.token === 'string' && parsed.token) {
                authHeader = `Bearer ${parsed.token}`;
              }
            }
          } catch { /* corrupt → no auth */ }
          // 2026-07-03 audit fix: prepend resolved apiUrl so
          // cross-origin Helm deploys hit the real backend instead of
          // the frontend's SPA catch-all.  Best-effort per prior
          // contract; no auth expiry side-effects wanted.
          const _base = resolveApiBaseUrl();
          const _url = `${_base}/api/execute/heartbeat/${encodeURIComponent(eid)}`;
          fetch(_url, {
            method: 'POST',
            headers: authHeader ? { Authorization: authHeader } : {},
          }).catch(() => {/* best-effort */});
        } catch {/* best-effort */}
      });
    }, 10_000);
  }

  /** 2026-07-15 reliability fix #1 — server-ping freshness watchdog.
   *
   *  Every PING_WATCHDOG_CHECK_MS, if the socket claims OPEN but no
   *  app-level server ping has ARRIVED for PING_STALE_MS, close the
   *  socket.  onclose fires → the existing reconnect/backoff path takes
   *  over (we deliberately do NOT call connect() here — racing a new
   *  socket against the closing one would let the old onclose null out
   *  this.ws under the new connection).
   *
   *  Not the banned BF-467 watchdog: keyed on SERVER pings RECEIVED
   *  (message events queued during an event-loop block are processed
   *  before this interval callback, so freshness self-heals), never on
   *  client-sent timers. */
  private startServerPingWatchdog(): void {
    if (this.serverPingWatchdog) return;
    this.serverPingWatchdog = setInterval(() => {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
      if (this.lastServerPingAt <= 0) return;
      const pingAgeMs = Date.now() - this.lastServerPingAt;
      if (pingAgeMs > this.PING_STALE_MS) {
        console.warn(
          `[wsService:${this.clientId}] server-ping watchdog — socket OPEN ` +
          `but no server ping for ${Math.round(pingAgeMs / 1000)}s ` +
          `(threshold ${this.PING_STALE_MS}ms). Half-open upstream; closing.`,
        );
        try { this.ws.close(); } catch { /* onclose still fires */ }
      }
    }, this.PING_WATCHDOG_CHECK_MS);
  }
}

/** 2026-07-15 reliability fix #4 — surfaced connection phase.
 *  'gave_up' is retained for type compat only; since fix #3 the service
 *  retries forever, so visible tabs never reach it. */
export type WsPhase = 'connected' | 'reconnecting' | 'gave_up';

export interface WsState {
  isConnected: boolean;
  lastMessage: WsMessage | null;
  connectionError: string | null;
  /** Additive (fix #4): raw connection phase for honest UI chips. */
  phase: WsPhase;
}

// THE singleton.  Imported by WebSocketContext (which exposes it to
// React via Context) and potentially by non-React code that wants to
// send a message or subscribe to events.
export const wsService = new WsService();

// Auto-start on module import.  This means the WS connects the moment
// the JS bundle loads, BEFORE any React tree mounts.  The connection
// is alive for the entire browser tab lifetime; no React state change
// can tear it down.
if (typeof window !== 'undefined') {
  wsService.start();
}

// GAP-fix (BF-469 deep-dive #3): Vite HMR safety.  In dev, when this
// module is hot-reloaded, the OLD wsService becomes orphaned but its
// WebSocket and timers keep running until GC eventually drops them
// — a memory + connection leak that accumulates during a dev session.
// import.meta.hot.dispose lets us tear down cleanly before the new
// module replaces this one.  No-op in production builds (Vite strips
// import.meta.hot for prod).
if (typeof import.meta !== 'undefined' && (import.meta as any).hot) {
  (import.meta as any).hot.dispose(() => {
    try {
      // Close the WebSocket and clear timers so the new module's
      // singleton starts clean.  React Context will re-subscribe to
      // the new singleton via the next render.
      const internal = wsService as unknown as {
        ws: WebSocket | null;
        reconnectTimer: ReturnType<typeof setTimeout> | null;
        heartbeatPingInterval: ReturnType<typeof setInterval> | null;
        serverPingWatchdog: ReturnType<typeof setInterval> | null;
      };
      if (internal.reconnectTimer) clearTimeout(internal.reconnectTimer);
      if (internal.heartbeatPingInterval) clearInterval(internal.heartbeatPingInterval);
      if (internal.serverPingWatchdog) clearInterval(internal.serverPingWatchdog);
      if (internal.ws) {
        try { internal.ws.close(); } catch { /* ignore */ }
      }
    } catch { /* best-effort cleanup */ }
  });
}
