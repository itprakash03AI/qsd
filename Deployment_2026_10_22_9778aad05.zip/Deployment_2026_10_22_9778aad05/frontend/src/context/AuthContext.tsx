import React, { createContext, useContext, useState, useEffect, useRef, ReactNode } from 'react';
import { getAuthHeader, setAuthHeader } from '../services/authState';
import { resolveApiBaseUrl } from '../services/api/core';
// 2026-06-30 deep-dive #8 fix: read apiUrl at REQUEST time, not at
// module import.  AuthContext mounts very early in the React tree --
// its health check + /auth/config fetch fire before the dynamically
// imported App settles.  Without this fix, when /config.js shipped
// the empty stub the apiUrl was '' at AuthContext module load, every
// auth check went same-origin -> SPA catch-all -> "Backend returned
// HTML instead of JSON" -> apiOffline=true -> login locked out.
import {
  encryptPassword, resetLoginCryptoCache,
  plaintextFallbackOf, plaintextRefusedSentence, PLAINTEXT_REFUSED_MESSAGE,
  type PlaintextFallback,
} from '../services/loginCrypto';

// Re-export for backward compatibility — existing importers use
// `import { getAuthHeader } from '../context/AuthContext'`
export { getAuthHeader } from '../services/authState';

interface User {
  username: string;
  display_name: string;
  email: string;
  groups: string[];
  is_admin: boolean;
  role: string;
}

interface AuthContextValue {
  user: User | null;
  authEnabled: boolean;
  /** 2026-09-26 -- the backend's login type ('ad' | 'local' | 'none' | ...),
   *  so the sign-in screen names the credentials it actually wants. */
  authType: string;
  /** 2026-10-18 -- the server REQUIRES a login but none is configured
   *  (/auth/config not_configured): only a super_admin can sign in. */
  loginNotConfigured: boolean;
  isLoading: boolean;
  /** BF-123: false when backend API is unreachable — gates all routes to show offline screen. */
  apiOnline: boolean;
  /** Deep-dive #8 (2026-06-30): bootstrap config-load status.  When
   *  not 'ok', the offline banner can show a precise reason
   *  ('config_js_404' = config file missing, 'config_json_html' =
   *  SPA catch-all hijacked, etc) instead of generic "backend down". */
  bootstrapStatus: string;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  /** BF-123: manually trigger API health re-check (retry button on offline screen). */
  retryConnection: () => void;
  /** Phase 107-I: convenience flag — true when current user has the super_admin role. */
  isSuperAdmin: boolean;
  /** BF-403: true when a 401 was caught mid-session — App renders a re-auth
   *  modal overlay WITHOUT unmounting the rest of the app, so the user
   *  doesn't lose their typed query / in-flight execution / open tabs. */
  reauthRequired: boolean;
  /** BF-403: caller (modal) invokes this after successful re-login. */
  clearReauthRequired: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export const useAuth = (): AuthContextValue => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};

const STORAGE_KEY = 'qs_auth';
const SESSION_TTL_MS = 8 * 60 * 60 * 1000; // 8 hours

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [authEnabled, setAuthEnabled] = useState(false);
  const [authType, setAuthType] = useState<string>('');
  const [loginNotConfigured, setLoginNotConfigured] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [apiOnline, setApiOnline] = useState(true);
  // Deep-dive #8 (2026-06-30): expose the bootstrap config-load
  // status so the offline banner can tell the operator WHY apiOnline
  // is false ("backend not configured" vs "backend not reachable").
  // setBootstrapStatus is unused (value never changes after mount)
  // but the setter destructure keeps the useState shape consistent.
  const [bootstrapStatus] = useState<string>(
    () => (typeof window !== 'undefined' && window.__QS_BOOTSTRAP_STATUS__) || 'ok'
  );
  // If config bootstrap failed in any non-'ok' / non-'empty' mode,
  // flip apiOnline=false right away so the offline screen shows
  // INSTEAD of the cryptic "Unexpected token '<'" errors a broken
  // apiUrl would otherwise produce.  'empty' is a soft state -- it
  // means same-origin assumed (Vite proxy / nginx); fetches may
  // still succeed.  Hard-fail modes ('config_js_404',
  // 'config_json_404', 'config_json_html', 'config_json_threw')
  // mean the user almost certainly cannot reach the backend.
  useEffect(() => {
    const hardFail = bootstrapStatus !== 'ok' && bootstrapStatus !== 'empty';
    if (hardFail) {
      console.warn(`[bootstrap] config failed with status=${bootstrapStatus}; ` +
                    `flipping apiOnline=false so the offline banner appears.`);
      setApiOnline(false);
    }
  }, [bootstrapStatus]);
  // BF-403: re-auth modal state — true when safeFetch caught a 401 mid-session
  const [reauthRequired, setReauthRequired] = useState(false);
  const clearReauthRequired = () => setReauthRequired(false);
  const expiryTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const failCountRef = useRef(0);
  // 2026-09-29 -- the server's policy for a plaintext login (/auth/config
  // `plaintext_fallback`).  A ref, not state: `login` reads it at submit
  // time and nothing renders from it.  'allow' until the server says
  // otherwise -- an older backend sends no field, and that is today's
  // behaviour.
  const plaintextFallbackRef = useRef<PlaintextFallback>('allow');
  const FAIL_THRESHOLD = 2; // 2 consecutive failures → mark offline

  // BF-464v2 — mirror username into sessionStorage so WebSocketContext can
  // pick it up without depending on this provider's React context (which
  // would force a re-render cascade and broke WS reconnect on the v1 fix).
  // Dispatches a CustomEvent so WS can re-identify mid-session when login
  // completes after the WS already opened.  No-op when running in non-DOM
  // contexts (unit tests).
  useEffect(() => {
    try {
      if (user?.username) {
        sessionStorage.setItem('qs_ws_username', user.username);
      } else {
        sessionStorage.removeItem('qs_ws_username');
      }
      window.dispatchEvent(new CustomEvent('qs-auth-changed'));
    } catch { /* SSR / sandboxed environments */ }
  }, [user?.username]);

  const clearSession = () => {
    setAuthHeader(null);
    setUser(null);
    // Phase 83G: use localStorage so auth persists across browser restarts
    localStorage.removeItem(STORAGE_KEY);
    sessionStorage.removeItem(STORAGE_KEY);  // also clear legacy sessionStorage
  };

  // Periodic expiry check — runs every 60s when auth is enabled
  useEffect(() => {
    if (!authEnabled || !user) return;
    expiryTimerRef.current = setInterval(() => {
      // Phase 83G: check localStorage
      const stored = localStorage.getItem(STORAGE_KEY) || sessionStorage.getItem(STORAGE_KEY);
      if (!stored) { clearSession(); return; }
      try {
        const { expiresAt } = JSON.parse(stored) as { token: string; expiresAt: number };
        if (expiresAt && Date.now() > expiresAt) {
          clearSession();
        }
      } catch { clearSession(); }
    }, 60_000);
    return () => { if (expiryTimerRef.current) clearInterval(expiryTimerRef.current); };
  }, [authEnabled, user]);

  // BF-123: Periodic health check — detects when backend goes down after init
  const checkHealth = async () => {
    try {
      const res = await fetch(`${resolveApiBaseUrl()}/health`, {
        method: 'GET',
        signal: AbortSignal.timeout(5000),
      });
      if (res.ok) {
        failCountRef.current = 0;
        setApiOnline(true);
      } else {
        failCountRef.current++;
      }
    } catch {
      failCountRef.current++;
    }
    if (failCountRef.current >= FAIL_THRESHOLD) setApiOnline(false);
  };

  // BF-414 — cross-tab auth sync.  Without this, logging out in tab A
  // leaves tab B authenticated until its next 401, and a stale tab keeps
  // using a revoked token.  Listen for ``storage`` events on STORAGE_KEY
  // and either re-hydrate the session (login in another tab) or clear it
  // (logout in another tab).  ``storage`` events fire ONLY in tabs that
  // didn't trigger the change, so this won't double-fire on the originator.
  useEffect(() => {
    const handler = async (ev: StorageEvent) => {
      if (ev.key !== STORAGE_KEY) return;
      if (ev.newValue == null) {
        // Removed in another tab → propagate logout here.
        setAuthHeader(null);
        setUser(null);
        return;
      }
      // Added/updated in another tab → re-hydrate header + user.
      try {
        const { token, expiresAt } = JSON.parse(ev.newValue) as {
          token: string; expiresAt?: number;
        };
        if (expiresAt && Date.now() > expiresAt) {
          setAuthHeader(null);
          setUser(null);
          return;
        }
        const bearerHeader = `Bearer ${token}`;
        setAuthHeader(bearerHeader);
        try {
          const meRes = await fetch(`${resolveApiBaseUrl()}/auth/me`, {
            headers: { Authorization: bearerHeader },
          });
          if (meRes.ok) {
            setUser(await meRes.json() as User);
          } else {
            // BF-414 follow-up — /auth/me rejected the cross-tab token
            // (revoked server-side, expired between tabs, role removed).
            // Clean up symmetrically so this tab doesn't stay half-
            // authenticated (header set, user null) until the next
            // safeFetch surfaces a 401.
            setAuthHeader(null);
            setUser(null);
            localStorage.removeItem(STORAGE_KEY);
            sessionStorage.removeItem(STORAGE_KEY);
          }
        } catch {
          // Network blip; periodic health check will recover.
        }
      } catch {
        // Malformed payload from another tab — clear to safe state.
        setAuthHeader(null);
        setUser(null);
      }
    };
    window.addEventListener('storage', handler);
    return () => window.removeEventListener('storage', handler);
  }, []);

  useEffect(() => {
    const id = setInterval(checkHealth, 30_000);
    // Phase 141: proactive signal from safeFetch — used to FORCE an
    // immediate health re-check instead of waiting for the 30s timer.
    // Critically we do NOT instantly flip apiOnline to false: a single
    // TypeError ("Failed to fetch") is common during long-running query
    // streaming through corporate proxies and is not a real outage.
    // The 5x FAIL_THRESHOLD on the periodic checker decides the real
    // state.  This preserves user context across transient blips.
    const offlineHandler = () => {
      checkHealth();
    };
    // BF-403: safeFetch dispatches this when it catches 401 mid-session.
    // We flip reauthRequired=true; App.tsx renders a modal OVERLAY without
    // unmounting the rest of the app, so the user keeps their typed
    // query / in-flight execution / open tabs.
    const expiredHandler = () => {
      setReauthRequired(true);
    };
    window.addEventListener('qs:api-offline', offlineHandler);
    window.addEventListener('qs:auth-expired', expiredHandler);
    return () => {
      clearInterval(id);
      window.removeEventListener('qs:api-offline', offlineHandler);
      window.removeEventListener('qs:auth-expired', expiredHandler);
    };
  }, []);

  const retryConnection = () => { checkHealth(); };

  useEffect(() => {
    const init = async () => {
      try {
        const res = await fetch(`${resolveApiBaseUrl()}/auth/config`);
        if (!res.ok) {
          // BF-AUTH-DI-RACE: backend up but auth subsystem not ready
          // (DI race during startup) — DO NOT silently fall through to
          // guest mode.  Treat the same as a hard network failure:
          // mark offline + force login screen.  Was previously defaulting
          // to setAuthEnabled(true) only, leaving apiOnline=true so the
          // offline screen never showed and the user got guest home.
          setAuthEnabled(true);
          setApiOnline(false);
          failCountRef.current = FAIL_THRESHOLD;
          setIsLoading(false);
          return;
        }
        const cfg = await res.json() as { type: string; plaintext_fallback?: string; not_configured?: boolean };
        const enabled = cfg.type !== 'none';
        setAuthType(String(cfg.type || ''));
        setLoginNotConfigured(cfg.not_configured === true);
        plaintextFallbackRef.current = plaintextFallbackOf(cfg);
        setAuthEnabled(enabled);
        if (!enabled) {
          // No auth -- the guest is an admin, but the BACKEND says which
          // one: a no-auth guest may be acting as a lesser role
          // (X-QS-Act-As-Role, the seam that makes a viewer session exist
          // on a rig with no users).  The hard-coded guest stays as the
          // fallback when /auth/me is unreachable, exactly as before.
          const guest = { username: 'guest', display_name: 'Guest', email: '', groups: [], is_admin: true, role: 'admin' };
          try {
            const meRes = await fetch(`${resolveApiBaseUrl()}/auth/me`);
            setUser(meRes.ok ? (await meRes.json() as User) : guest);
          } catch {
            setUser(guest);
          }
          setIsLoading(false);
          return;
        }

        // Phase 83G: Restore session from localStorage (persists across browser restarts)
        // Fall back to sessionStorage for backward compat with existing sessions
        const stored = localStorage.getItem(STORAGE_KEY) || sessionStorage.getItem(STORAGE_KEY);
        if (stored) {
          try {
            const { token, expiresAt } = JSON.parse(stored) as { token: string; expiresAt?: number };
            // Check client-side expiry before calling /auth/me
            if (expiresAt && Date.now() > expiresAt) {
              localStorage.removeItem(STORAGE_KEY);
              sessionStorage.removeItem(STORAGE_KEY);
            } else {
              const bearerHeader = `Bearer ${token}`;
              const meRes = await fetch(`${resolveApiBaseUrl()}/auth/me`, {
                headers: { Authorization: bearerHeader },
              });
              if (meRes.ok) {
                setAuthHeader(bearerHeader);
                setUser(await meRes.json() as User);
              } else {
                localStorage.removeItem(STORAGE_KEY);
                sessionStorage.removeItem(STORAGE_KEY);
              }
            }
          } catch {
            localStorage.removeItem(STORAGE_KEY);
            sessionStorage.removeItem(STORAGE_KEY);
          }
        }
      } catch {
        // Backend unreachable at startup (dev hot reload, API pod restart, network blip).
        // Phase 141: do NOT immediately set apiOnline=false — the
        // periodic health check will determine the real state after a
        // few attempts.  We render the app with the ConnectionBanner
        // showing instead of a full-screen takeover.  This preserves
        // user context if the backend comes back quickly.
        setAuthEnabled(true);
        // Bump the fail counter but don't hit threshold — give the
        // backend ~3 health checks (90s) to come back before we flip
        // apiOnline.  This matches typical pod-restart windows.
        failCountRef.current = Math.max(failCountRef.current, FAIL_THRESHOLD - 2);
      } finally {
        setIsLoading(false);
      }
    };
    init();
  }, []);

  const login = async (username: string, password: string) => {
    // ── Build the request body using the encrypted-password path when
    //    possible, plaintext fallback when not.  See services/loginCrypto.ts
    //    for the rationale (closes the "password visible in DevTools Network
    //    tab" gap; HTTPS still protects in-transit network-side).
    //
    // 2026-09-29 -- when the key could not be fetched or used AND the
    // server refuses plaintext (/auth/config plaintext_fallback=refuse),
    // NOTHING is sent: the password never leaves the form, and the form
    // shows the sentence.  Under "allow" the fallback is unchanged.
    const _buildBody = async (): Promise<string> => {
      const encrypted = await encryptPassword(password);
      if (encrypted) {
        return JSON.stringify({ username, ...encrypted });
      }
      if (plaintextFallbackRef.current === 'refuse') {
        throw new Error(PLAINTEXT_REFUSED_MESSAGE);
      }
      return JSON.stringify({ username, password });
    };

    let res = await fetch(`${resolveApiBaseUrl()}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: await _buildBody(),
    });

    // Stale-key one-shot recovery: backend rotated the keypair (pod
    // restart) between our cached fetch and this request.  Wipe the cache,
    // refetch + re-encrypt, retry exactly once.  Anything else → throw.
    if (res.status === 400) {
      const peek = await res.clone().json().catch(() => ({})) as { detail?: string };
      if ((peek.detail || '').startsWith('login_crypto_stale_key')) {
        resetLoginCryptoCache();
        res = await fetch(`${resolveApiBaseUrl()}/auth/login`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: await _buildBody(),
        });
      }
    }

    if (!res.ok) {
      const err = await res.json().catch(() => ({})) as { detail?: string };
      // A server that flipped to "refuse" after this page loaded answers
      // the plaintext with 400 login_plaintext_refused: show its sentence,
      // not the code.
      throw new Error(plaintextRefusedSentence(err.detail) || err.detail || 'Login failed');
    }
    const data = await res.json() as User & { session_token: string };
    const { session_token, ...userData } = data;
    setAuthHeader(`Bearer ${session_token}`);
    setUser(userData);
    // Phase 83G: Store only the opaque token in localStorage for cross-tab/restart persistence
    // Password is NEVER persisted
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      token: session_token,
      expiresAt: Date.now() + SESSION_TTL_MS,
    }));
  };

  const logout = () => {
    // Destroy server-side session
    const currentAuth = getAuthHeader();
    if (currentAuth) {
      fetch(`${resolveApiBaseUrl()}/auth/logout`, {
        method: 'POST',
        headers: { Authorization: currentAuth },
      }).catch(() => {});
    }
    clearSession();
  };

  return (
    <AuthContext.Provider value={{
      user, authEnabled, authType, loginNotConfigured, isLoading, apiOnline, bootstrapStatus,
      login, logout,
      retryConnection,
      isSuperAdmin: user?.role === 'super_admin',
      reauthRequired,
      clearReauthRequired,
    }}>
      {children}
    </AuthContext.Provider>
  );
};
