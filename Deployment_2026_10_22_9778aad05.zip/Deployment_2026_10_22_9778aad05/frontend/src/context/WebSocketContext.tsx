/**
 * BF-469 (2026-05-19) — WebSocketContext is now a THIN React wrapper
 * over the module-level wsService singleton.  The actual WebSocket
 * lives at module scope (services/wsService.ts) and is unaffected by
 * any React component lifecycle event — mount, unmount, conditional
 * return, error boundary, route change, StrictMode double-invoke,
 * etc.
 *
 * The full story:
 *   - BF-467 removed the client-side heartbeat watchdog (was tearing
 *     down healthy WS on event-loop blocks).
 *   - BF-468 hoisted <WebSocketProvider> above AppRoutes' conditional
 *     returns (was tearing down WS when isLoading or user state
 *     toggled).
 *   - BF-469 moved the WS connection out of React ENTIRELY so no
 *     future restructuring can re-introduce the close/reconnect bugs.
 *
 * Public API (unchanged from prior versions for consumer compat):
 *   useWebSocket() → { isConnected, lastMessage, connectionError,
 *                      connectionPhase, sendMessage, addListener,
 *                      registerExecutionHeartbeat }
 */
import React, { createContext, useContext, useEffect, useMemo, useState, ReactNode } from 'react';
import { wsService, type WsMessage, type WsState, type WsPhase } from '../services/wsService';

// BF-471 — module-level stable delegates so the Context value can
// reference them without recomputing on each render.  Components
// that destructure only methods (addListener, sendMessage, etc.)
// retain stable identity for their useEffect deps.
const _delegated = {
  sendMessage: (msg: object) => wsService.send(msg),
  addListener: (cb: (m: WsMessage) => void) => wsService.addListener(cb),
  registerExecutionHeartbeat: (eid: string) => wsService.registerExecutionHeartbeat(eid),
  // 2026-10-17 -- the feed board's estate-wide watch (services/wsService.ts)
  watch: (scope: string) => wsService.watch(scope),
};

interface WebSocketContextValue {
  isConnected: boolean;
  lastMessage: WsMessage | null;
  connectionError: string | null;
  /** 2026-07-15 reliability fix #4 — additive: raw connection phase so
   *  the UI can render an honest "Reconnecting…" state (the debounced
   *  isConnected deliberately hides brief blips). */
  connectionPhase: WsPhase;
  sendMessage: (message: object) => void;
  addListener: (callback: (message: WsMessage) => void) => () => void;
  registerExecutionHeartbeat: (executionId: string) => () => void;
  /** 2026-10-17 -- watch a scope on this connection (re-sent on reconnect); returns the unwatch */
  watch: (scope: string) => () => void;
}

const WebSocketContext = createContext<WebSocketContextValue | null>(null);

export const useWebSocket = (): WebSocketContextValue => {
  const ctx = useContext(WebSocketContext);
  if (!ctx) throw new Error('useWebSocket must be used within WebSocketProvider');
  return ctx;
};

/** The same context, or null outside a WebSocketProvider (2026-09-14).
 *  For a screen whose live updates are an ACCELERATION of a poll, not
 *  the only source of truth: the Feeds page re-fetches its execution
 *  list on every websocket event AND on a timer while a run is live,
 *  so without the provider it is merely slower, never wrong.  A screen
 *  where the websocket IS the mechanism must keep using useWebSocket
 *  and fail loudly. */
export const useOptionalWebSocket = (): WebSocketContextValue | null =>
  useContext(WebSocketContext);

/** WebSocketProvider — thin wrapper.  Does NOT own the WS connection.
 *  Subscribes to wsService state and re-renders consumers when it
 *  changes.  Mounting / unmounting this provider does NOT affect the
 *  underlying connection (which is started on module import). */
export const WebSocketProvider = ({ children }: { children: ReactNode }) => {
  const [state, setState] = useState<WsState>({
    isConnected: wsService.isConnected,
    lastMessage: wsService.currentLastMessage,
    connectionError: wsService.currentError,
    phase: wsService.connectionPhase,
  });

  useEffect(() => {
    // Subscribe to wsService state changes.  The cleanup ONLY removes
    // our subscription — it does NOT close the WebSocket.  That's the
    // whole point: WebSocketProvider unmount = stop reacting, NOT
    // disconnect.  The WS persists for the browser tab lifetime.
    return wsService.subscribeToState(setState);
  }, []);

  const value = useMemo<WebSocketContextValue>(() => ({
    isConnected: state.isConnected,
    lastMessage: state.lastMessage,
    connectionError: state.connectionError,
    connectionPhase: state.phase,
    // BF-471 — module-level stable delegates (defined above).
    // Identity never changes across renders → consumers using only
    // methods retain stable useEffect dependencies.
    sendMessage: _delegated.sendMessage,
    addListener: _delegated.addListener,
    registerExecutionHeartbeat: _delegated.registerExecutionHeartbeat,
    watch: _delegated.watch,
  }), [state.isConnected, state.lastMessage, state.connectionError, state.phase]);

  return (
    <WebSocketContext.Provider value={value}>
      {children}
    </WebSocketContext.Provider>
  );
};
