import { defineConfig, createLogger, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { mkdirSync, writeFileSync, readFileSync, readdirSync, statSync, existsSync } from 'fs';
import { join, relative } from 'path';
import { createHash } from 'crypto';

// FB-47 (2026-09-20): every build gets an id, stamped into the bundle
// (__QS_BUILD_ID__) AND written to build/version.json by the same build, so
// a running tab can tell whether the server it talks to is the build it was
// compiled from.  QS_BUILD_ID (a CI sha) wins; otherwise a HASH OF THE SOURCE
// (2026-10-18): it was a timestamp, so two builds of the SAME code -- an image
// rebuilt or re-pushed, two replicas from two builds behind one OpenShift route
// -- carried different ids, the page and /version.json came from different
// replicas, and every tab said "QueryStudio was updated" forever, even right
// after a reload.  Same source = same id; only a real code change moves it.
function sourceHash(): string {
  const h = createHash('sha256');
  const files: string[] = [];
  const walk = (dir: string) => {
    for (const name of readdirSync(dir).sort()) {
      if (name === 'node_modules' || name === '__tests__' || name.startsWith('.')) continue;
      const full = join(dir, name);
      if (statSync(full).isDirectory()) walk(full);
      else files.push(full);
    }
  };
  for (const d of ['src', 'public']) if (existsSync(d)) walk(d);
  for (const f of ['index.html', 'package.json', 'package-lock.json', 'vite.config.ts']) if (existsSync(f)) files.push(f);
  for (const f of files) {
    h.update(relative('.', f).split(String.fromCharCode(92)).join('/'));   // Windows separators -> '/', so every OS hashes alike
    h.update(readFileSync(f));
  }
  return h.digest('hex').slice(0, 16);
}
const BUILD_ID = process.env.QS_BUILD_ID || sourceHash();
function versionFile(outDir: string): Plugin {
  return {
    name: 'qs-version-json',
    apply: 'build',
    closeBundle() {
      mkdirSync(outDir, { recursive: true });
      writeFileSync(join(outDir, 'version.json'), JSON.stringify({ build_id: BUILD_ID }) + '\n');
    },
  };
}

// Suppress noisy WebSocket proxy disconnect errors (ECONNABORTED / ECONNRESET).
// These fire every time a browser tab closes or refreshes and are expected.
const logger = createLogger();
const _origError = logger.error.bind(logger);
logger.error = (msg, opts) => {
  if (msg.indexOf('ECONNABORTED') !== -1 || msg.indexOf('ECONNRESET') !== -1) return;
  _origError(msg, opts);
};

export default defineConfig({
  customLogger: logger,
  plugins: [react(), versionFile('build')],
  define: { __QS_BUILD_ID__: JSON.stringify(BUILD_ID) },
  server: {
    port: 4000,
    proxy: {
      '/api':     'http://localhost:8000',
      '/auth':    'http://localhost:8000',
      '/health':  'http://localhost:8000',
      '/metrics': 'http://localhost:8000',
      '/ws': {
        target: 'ws://localhost:8000',
        ws: true,
        configure: (proxy) => {
          proxy.on('error', (err: Error & { code?: string }) => {
            if (!err?.message) return;
            if (err.code === 'ECONNABORTED' || err.code === 'ECONNRESET') return;
            if (err.message.indexOf('ECONNABORTED') !== -1 || err.message.indexOf('ECONNRESET') !== -1) return;
            console.error('[ws proxy]', err.message);
          });
        },
      },
    },
  },
  build: {
    outDir: 'build',
    sourcemap: true,
    rollupOptions: {
      // Excel add-in (2026-09-28): three more HTML entries, built by the
      // same toolchain into the same image under build/addin/ -- the task
      // pane, the sign-in dialog it opens, and the browser harness (no
      // Office) the Docker proof drives.  spa-server.cjs serves a path with
      // an extension as a file, so /addin/taskpane.html needs no route.
      input: {
        main: join(__dirname, 'index.html'),
        addin_taskpane: join(__dirname, 'addin', 'taskpane.html'),
        addin_login: join(__dirname, 'addin', 'login.html'),
        addin_harness: join(__dirname, 'addin', 'harness.html'),
      },
      output: {
        manualChunks: {
          'vendor-mui': ['@mui/material', '@mui/icons-material'],
          'vendor-charts': ['recharts'],
          'vendor-flow': ['@xyflow/react'],
          'page-admin': ['./src/components/AdminPage'],
          'page-catalog': ['./src/components/ReportCatalogPage'],
          'page-lineage': ['./src/components/LineagePage'],
          'page-editor': ['./src/components/CompleteQueryBuilder'],
        },
      },
    },
  },
});
