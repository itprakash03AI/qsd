"""Phase 149.4 — iceberg_bloom_sidecar_v1 (per-file bloom filters).

Adds a new sidecar table that supplements the column-stats supplement.
Bounds prune RANGE filters but are useless for sparse equality
(``WHERE customer_id = 12345`` against [1, 1000000] bounds matches
every file).  Bloom filters PROVE a value is not in a file → drop it.

Storage is DB-resident (BLOB).  No local-disk component — honours the
Phase 149 ``no local copy`` constraint.

Same content-identity model as iceberg_column_stats_supplement_v2 so
multiple QueryStudio connections pointing at the same S3 location
share rows.

Revision ID: 007_phase_149_4_bloom_sidecar
Revises: 006_feed_run_claimed_by
Create Date: 2026-06-09
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "007_phase_149_4_bloom_sidecar"
down_revision: Union[str, None] = "006_feed_run_claimed_by"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _table_exists(name: str) -> bool:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    try:
        return name in insp.get_table_names()
    except Exception:
        return False


def upgrade() -> None:
    # Idempotent — safe to run even when the table was already added by
    # core.database._migrate_schema_safely (auto-create-from-Base path).
    if _table_exists("iceberg_bloom_sidecar_v1"):
        return

    op.create_table(
        "iceberg_bloom_sidecar_v1",
        sa.Column("id",             sa.Integer(),    nullable=False),
        sa.Column("bucket",         sa.String(255),  nullable=False, server_default=""),
        sa.Column("table_prefix",   sa.String(512),  nullable=False, server_default=""),
        sa.Column("snapshot_id",    sa.String(64),   nullable=False),
        sa.Column("file_path",      sa.String(1024), nullable=False),
        sa.Column("column_name",    sa.String(255),  nullable=False),
        sa.Column("bloom_bits",     sa.LargeBinary(),nullable=False),
        sa.Column("bloom_num_bits", sa.Integer(),    nullable=False),
        sa.Column("bloom_k",        sa.Integer(),    nullable=False, server_default="7"),
        sa.Column("distinct_count", sa.BigInteger(), nullable=False, server_default="0"),
        sa.Column("connection_id",  sa.Integer(),    nullable=True),
        sa.Column("table_name",     sa.String(255),  nullable=True),
        sa.Column("scanned_at",     sa.DateTime(),   nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_iceberg_bloom_lookup_v1",
        "iceberg_bloom_sidecar_v1",
        ["bucket", "table_prefix", "snapshot_id", "file_path", "column_name"],
        unique=True,
    )
    op.create_index(
        "ix_iceberg_bloom_by_col_v1",
        "iceberg_bloom_sidecar_v1",
        ["bucket", "table_prefix", "snapshot_id", "column_name"],
        unique=False,
    )


def downgrade() -> None:
    if not _table_exists("iceberg_bloom_sidecar_v1"):
        return
    try:
        op.drop_index("ix_iceberg_bloom_by_col_v1",
                       table_name="iceberg_bloom_sidecar_v1")
    except Exception:
        pass
    try:
        op.drop_index("ix_iceberg_bloom_lookup_v1",
                       table_name="iceberg_bloom_sidecar_v1")
    except Exception:
        pass
    op.drop_table("iceberg_bloom_sidecar_v1")
