"""Phase 131 — Generic task_type on feed_configs.

User direction: "Feed Name can we say task name... it can be feed or it
can push data to oracle... generic task name n we need to capture in
config".  A "task" is generic — it can produce a file (feed), push rows
to Oracle, fire an API, etc.  The UI is rebranded around "Task" and
the engine still routes file outputs through the existing pipeline,
but we capture the intent in config so future task types (oracle_push,
api_push) can branch on it without another schema change.

Adds:
  - feed_configs.task_type (string, default 'file_feed', nullable=False)

Default 'file_feed' preserves the existing behaviour for every legacy
feed_config — the engine ignores task_type for that value.

Revision ID: 004_task_type
Revises: 003_phase131
Create Date: 2026-05-16
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "004_task_type"
down_revision: Union[str, None] = "003_phase131"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _column_exists(table: str, column: str) -> bool:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    try:
        cols = {c["name"] for c in insp.get_columns(table)}
    except Exception:
        return False
    return column in cols


def upgrade() -> None:
    if not _column_exists("feed_configs", "task_type"):
        op.add_column(
            "feed_configs",
            sa.Column(
                "task_type",
                sa.String(40),
                nullable=False,
                server_default="file_feed",
            ),
        )


def downgrade() -> None:
    if _column_exists("feed_configs", "task_type"):
        with op.batch_alter_table("feed_configs") as batch:
            batch.drop_column("task_type")
