"""Phase 133-J — Publisher-time credential routing for Published Views.

The published API previously resolved S3 credentials against the *consumer's*
identity at execute time.  For private connections (auth_mode=portal,
is_shared=false) this failed for curl callers whose vault was empty, with no
way to recover.  Phase 133-J lets the publisher pick the execution connection
and the credential mode at publish time so consumer calls auto-resolve.

Adds to ``published_views``:
  - execution_connection_id (INTEGER, nullable) — optional override of the
    snapshotted query_config's connection_id.  NULL = legacy behaviour.
  - credential_mode (VARCHAR(20), default 'consumer') — drives whose
    identity feeds resolve_s3_credentials.  Values: consumer | publisher |
    shared.  'consumer' preserves existing behaviour for every legacy view.
  - publisher_username (VARCHAR(100), nullable) — frozen at publish time
    from the publisher's session so 'publisher' mode survives session
    expiry / restart.

Server-side default on credential_mode ensures every existing row gets
'consumer' on Postgres without a backfill.

Revision ID: 005_pv_credmode
Revises: 004_task_type
Create Date: 2026-05-26
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "005_pv_credmode"
down_revision: Union[str, None] = "004_task_type"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _column_exists(table: str, column: str) -> bool:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    try:
        cols = {c["name"] for c in insp.get_columns(table)}
    except Exception:
        return False
    return column in cols


def upgrade() -> None:
    if not _column_exists("published_views", "execution_connection_id"):
        op.add_column(
            "published_views",
            sa.Column("execution_connection_id", sa.Integer(), nullable=True),
        )
    if not _column_exists("published_views", "credential_mode"):
        op.add_column(
            "published_views",
            sa.Column(
                "credential_mode",
                sa.String(20),
                nullable=False,
                server_default="consumer",
            ),
        )
    if not _column_exists("published_views", "publisher_username"):
        op.add_column(
            "published_views",
            sa.Column("publisher_username", sa.String(100), nullable=True),
        )


def downgrade() -> None:
    with op.batch_alter_table("published_views") as batch:
        if _column_exists("published_views", "publisher_username"):
            batch.drop_column("publisher_username")
        if _column_exists("published_views", "credential_mode"):
            batch.drop_column("credential_mode")
        if _column_exists("published_views", "execution_connection_id"):
            batch.drop_column("execution_connection_id")
