"""2026-09-02 — widen every measured byte/row counter to bigint.

Operator report: a feed run died with
``psycopg2.errors.NumericValueOutOfRange: integer out of range`` on the
terminal ``UPDATE feed_executions``, so the run never reached a terminal
state at all — the outcome was lost and the row stranded 'running'.

Root cause is a class, not one column.  Every measured byte- and row-counter
in this schema was created ``Integer``, which on PostgreSQL caps at
2,147,483,647.  For a byte count that is **2 GB** — an ordinary size for a
feed file — and for a row count 2.1 bn.  33 columns across 18 tables share
the defect; the model now declares all of them ``BigInteger``.

Configuration CAPS are deliberately NOT widened: ``report_pdf_configs.max_rows``,
``feed_configs.size_threshold_rows`` and ``sap_task_configs.passthrough_max_rows``
are knobs an operator types, not values the engine measures.

DEPLOYMENT REALITY (the 2026-08-20 lesson): **Alembic is never auto-invoked in
this deployment — this migration alone cannot reach a pod.**  Worse than for a
new table: ``Base.metadata.create_all()`` creates missing tables and NEVER
alters an existing one, so a model type change reaches nothing at all.  The
widening actually reaches pods through
``DatabaseManager._int32_columns_needing_widening`` +
``_apply_postgresql_migrations``, which compares the live column type against
the model at startup and issues the same ALTERs under a 3s ``lock_timeout``.
``FeedsMixin.update_feed_execution`` / ``update_feed_run`` additionally survive
an overflow (drop the counter, record it in
``files_metadata.oversized_columns``, retry once) so a run reaches its terminal
state even where the ALTER is refused.

This file exists for hand-run ``alembic upgrade head`` environments and to keep
the migration chain truthful.

Revision ID: 021_widen_counters_to_bigint
Revises: 020_catalog_table_columns
Create Date: 2026-09-02
"""
from typing import Union

from alembic import op
import sqlalchemy as sa

revision: str = "021_widen_counters_to_bigint"
down_revision: Union[str, None] = "020_catalog_table_columns"
branch_labels: Union[str, None] = None
depends_on: Union[str, None] = None


# (table, column) — measured counters only.
COUNTERS = [
    ("query_executions",        "total_rows"),
    ("query_executions",        "file_size_bytes"),
    ("download_files",          "file_size_bytes"),
    ("query_result_cache",      "row_count"),
    ("query_result_cache",      "file_size_bytes"),
    ("materialized_views",      "row_count"),
    ("materialized_views",      "size_bytes"),
    ("local_tables",            "row_count"),
    ("local_tables",            "size_bytes"),
    ("delivery_history",        "file_size_bytes"),
    ("schedule_run_stats",      "row_count"),
    ("schedule_run_stats",      "file_size_bytes"),
    ("federation_executions",   "total_rows"),
    ("agg_cache_entries",       "file_size_bytes"),
    ("agg_cache_entries",       "row_count"),
    ("subscription_deliveries", "file_size_bytes"),
    ("feed_configs",            "last_row_count"),
    ("feed_configs",            "estimated_row_count"),
    ("feed_runs",               "total_rows"),
    ("feed_runs",               "file_size_bytes"),
    ("feed_executions",         "total_rows"),
    ("feed_executions",         "file_size_bytes"),
    ("api_access_log",          "response_rows"),
    ("business_report_async_jobs", "total_rows"),
    ("report_instances",        "row_count"),
    ("federation_views",        "row_count"),
    ("federation_views",        "file_size_bytes"),
    ("etl_pipeline_configs",    "last_row_count"),
    ("etl_pipeline_configs",    "estimated_row_count"),
    ("etl_pipeline_executions", "input_row_count"),
    ("etl_pipeline_executions", "output_row_count"),
    ("etl_pipeline_executions", "output_size_bytes"),
    ("user_drafts",             "size_bytes"),
]


def _existing_tables() -> set:
    return set(sa.inspect(op.get_bind()).get_table_names())


def _alter(new_type: sa.types.TypeEngine) -> None:
    bind = op.get_bind()
    # SQLite's INTEGER is already 64-bit and its ALTER cannot retype a column;
    # there is nothing to do and nothing that could fail.
    if bind.dialect.name == "sqlite":
        return
    tables = _existing_tables()
    for table, column in COUNTERS:
        if table not in tables:
            continue
        op.alter_column(table, column, type_=new_type, existing_nullable=True)


def upgrade() -> None:
    _alter(sa.BigInteger())


def downgrade() -> None:
    # Narrowing is genuinely lossy — any stored value above 2,147,483,647 (the
    # exact case this migration exists for) would fail the cast or be lost.
    # Refuse rather than corrupt.
    raise RuntimeError(
        "021_widen_counters_to_bigint is not reversible: narrowing bigint back "
        "to integer would fail or truncate any counter above 2,147,483,647, "
        "which is precisely the data this migration was written to store."
    )
