"""kafka_messages — the Kafka landing table (BRD 2026-09-02 §7.1, step 6).

Implements FR-DEP-01/03/20: the consumer is thin (validate, dedupe,
INSERT) and the table is the contract between transport and meaning:

* replayable and auditable — a message that arrives while QueryStudio is
  restarting is still a row, and support can see what arrived and
  re-apply it without a Kafka client;
* ``(topic, partition, offset)`` UNIQUE — FR-DEP-03: Kafka gives
  at-least-once delivery, and without this key a consumer rebalance
  re-delivers and the same dependency is satisfied twice, which for a
  count-based gate means a feed starts before its data is complete.
  The dedupe key belongs in the TABLE DEFINITION, not in consumer logic
  (a rule enforced only in Python is enforced only until two pods run);
* ``resolution`` is a closed vocabulary (CHECK): landed -> resolved, or
  landed -> unresolvable WITH the parse error (FR-DEP-20 — poison is
  marked once and never retried);
* ``offset`` is BigInteger: Kafka offsets are 64-bit (same class as
  021_widen_counters_to_bigint).

NOTE (repo rule, §14): alembic is NOT invoked at runtime — nothing runs
``alembic upgrade head`` on boot.  kafka_messages is a FRESH table that
self-creates via ``Base.metadata.create_all()`` on startup, so a
deployed pod is correct without this file.  The DDL here is idempotent
with that path for deployments that run alembic first.

Revision ID: 024_kafka_messages
Revises: 023_child_runs_and_claims
Create Date: 2026-09-02
"""
from collections.abc import Sequence

import sqlalchemy as sa

from alembic import op

revision: str = "024_kafka_messages"
down_revision: str | None = "023_child_runs_and_claims"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _table_exists(table: str) -> bool:
    try:
        return table in set(sa.inspect(op.get_bind()).get_table_names())
    except Exception:  # noqa: BLE001 — introspection failure = treat as absent
        return False


# Closed vocabulary — kept as literals HERE (not imported from the
# models) so the migration is self-contained and replayable even if the
# model tuple gains values later; the model CHECK stays the live truth.
_RESOLUTIONS = "'landed', 'resolved', 'unresolvable'"


def upgrade() -> None:
    if not _table_exists("kafka_messages"):
        op.create_table(
            "kafka_messages",
            sa.Column("id", sa.Integer(), primary_key=True),
            sa.Column("topic", sa.String(500), nullable=False),
            sa.Column("partition", sa.Integer(), nullable=False),
            sa.Column("offset", sa.BigInteger(), nullable=False),
            sa.Column("message_key", sa.String(500), nullable=True),
            # The RAW payload, exactly as landed — parsing happens in
            # the resolver, so a poison payload still lands (FR-DEP-20).
            sa.Column("payload", sa.Text(), nullable=True),
            sa.Column("landed_at", sa.DateTime(), nullable=False),
            sa.Column("resolution", sa.String(20), nullable=False,
                      server_default="landed"),
            sa.Column("unresolvable_reason", sa.String(1000), nullable=True),
            sa.Column("dependency_name", sa.String(200), nullable=True),
            sa.Column("business_date", sa.Date(), nullable=True),
            sa.Column("resolved_at", sa.DateTime(), nullable=True),
            sa.Column("created_at", sa.DateTime(), nullable=False,
                      server_default=sa.text("CURRENT_TIMESTAMP")),
            sa.Column("created_by", sa.String(100), nullable=True),
            sa.Column("updated_at", sa.DateTime(), nullable=True),
            sa.Column("updated_by", sa.String(100), nullable=True),
            sa.UniqueConstraint(
                "topic", "partition", "offset",
                name="uq_kafka_messages_topic_partition_offset"),
            sa.CheckConstraint(
                f"resolution IN ({_RESOLUTIONS})",
                name="ck_kafka_messages_resolution"),
        )
        op.create_index("ix_kafka_messages_resolution", "kafka_messages",
                        ["resolution"])
        op.create_index("ix_kafka_messages_business_date", "kafka_messages",
                        ["business_date"])
        op.create_index("ix_kafka_messages_dependency", "kafka_messages",
                        ["dependency_name"])


def downgrade() -> None:
    # Deliberately retained.  The landing table is the AUDIT of what
    # arrived (§7.1 "replayable, auditable") and the input for support
    # re-application; dropping it on downgrade is a data-loss operation,
    # and the old code ignores unknown tables — same posture as 023.
    pass
