"""Foundation C — child file runs, connection claims, partition
declarations (BRD 2026-09-02).

Implements FR-RUN-02/04/05 (child runs), FR-RUN-06..08 + FR-OPS-10..12
(per-connection concurrency claims + fair share) and FR-CMP-02 (the
partition declaration store):

* ``feed_file_runs`` — one row per declared partition,
  ``(feed_run_id, partition_key)`` UNIQUE.  A child is a ROW, not a loop
  iteration, because "re-run file 738 without touching the other 999"
  must be addressable.
* ``connection_claims`` — who holds a concurrency slot right now,
  ``(connection_id, run_kind, run_id)`` UNIQUE, with pod owner +
  heartbeat so a dead pod's slots are reclaimable.
* ``connection_concurrency_budgets`` — the per-connection allowance +
  the critical reservation.  A NEW TABLE rather than a column on
  ``connections`` (§14: a new table self-creates; a new column needs a
  verified migration on every deployed pod).
* ``feed_partition_declarations`` — the declared IDENTITIES recorded
  with the run (one per run), so "the split for business date D" can be
  shown again next year and the 60 missing entities of §9.2 can be
  named exactly.

NOTE (repo rule, §14): alembic is NOT invoked at runtime — nothing runs
``alembic upgrade head`` on boot.  All four tables are FRESH tables that
self-create via ``Base.metadata.create_all()`` on startup, so a deployed
pod is correct without this file.  The DDL here is idempotent with that
path for deployments that run alembic first.

Revision ID: 023_child_runs_and_claims
Revises: 022_feed_build_id_and_pinning
Create Date: 2026-09-02
"""
from collections.abc import Sequence

import sqlalchemy as sa

from alembic import op

revision: str = "023_child_runs_and_claims"
down_revision: str | None = "022_feed_build_id_and_pinning"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _table_exists(table: str) -> bool:
    try:
        return table in set(sa.inspect(op.get_bind()).get_table_names())
    except Exception:  # noqa: BLE001 — introspection failure = treat as absent
        return False


# Closed vocabularies — kept as literals HERE (not imported from the
# models) so the migration is self-contained and replayable even if the
# model tuples gain values later; the model CHECKs stay the live truth.
_FILE_RUN_STATUSES = "'pending', 'running', 'completed', 'failed', 'cancelled'"
_RUN_KINDS = "'feed_run', 'file_run'"
_ON_EMPTY = "'fail', 'skip'"


def upgrade() -> None:
    if not _table_exists("feed_file_runs"):
        op.create_table(
            "feed_file_runs",
            sa.Column("id", sa.Integer(), primary_key=True),
            sa.Column("feed_run_id", sa.Integer(),
                      sa.ForeignKey("feed_runs.id", ondelete="CASCADE"),
                      nullable=False),
            sa.Column("feed_config_id", sa.Integer(), nullable=True),
            sa.Column("business_date", sa.Date(), nullable=True),
            sa.Column("partition_key", sa.String(500), nullable=False),
            sa.Column("status", sa.String(20), nullable=False,
                      server_default="pending"),
            sa.Column("attempt_count", sa.Integer(), nullable=False,
                      server_default="0"),
            sa.Column("claimed_by", sa.String(100), nullable=True),
            sa.Column("started_at", sa.DateTime(), nullable=True),
            sa.Column("completed_at", sa.DateTime(), nullable=True),
            sa.Column("heartbeat_at", sa.DateTime(), nullable=True),
            sa.Column("part_path", sa.Text(), nullable=True),
            sa.Column("row_count", sa.BigInteger(), nullable=True),
            sa.Column("error", sa.Text(), nullable=True),
            sa.Column("created_at", sa.DateTime(), nullable=False,
                      server_default=sa.text("CURRENT_TIMESTAMP")),
            sa.Column("created_by", sa.String(100), nullable=True),
            sa.Column("updated_at", sa.DateTime(), nullable=True),
            sa.Column("updated_by", sa.String(100), nullable=True),
            sa.UniqueConstraint("feed_run_id", "partition_key",
                                name="uq_feed_file_runs_run_partition"),
            sa.CheckConstraint(
                f"status IN ({_FILE_RUN_STATUSES})",
                name="ck_feed_file_runs_status"),
        )
        op.create_index("ix_feed_file_runs_run_status", "feed_file_runs",
                        ["feed_run_id", "status"])
        op.create_index("ix_feed_file_runs_feed_date", "feed_file_runs",
                        ["feed_config_id", "business_date"])
        op.create_index("ix_feed_file_runs_feed_run_id", "feed_file_runs",
                        ["feed_run_id"])
        op.create_index("ix_feed_file_runs_status", "feed_file_runs",
                        ["status"])
        op.create_index("ix_feed_file_runs_business_date", "feed_file_runs",
                        ["business_date"])

    if not _table_exists("connection_concurrency_budgets"):
        op.create_table(
            "connection_concurrency_budgets",
            sa.Column("id", sa.Integer(), primary_key=True),
            sa.Column("connection_id", sa.Integer(), nullable=False),
            sa.Column("max_concurrent_runs", sa.Integer(), nullable=False),
            sa.Column("reserved_critical_slots", sa.Integer(),
                      nullable=False, server_default="0"),
            sa.Column("created_at", sa.DateTime(), nullable=False,
                      server_default=sa.text("CURRENT_TIMESTAMP")),
            sa.Column("created_by", sa.String(100), nullable=True),
            sa.Column("updated_at", sa.DateTime(), nullable=True),
            sa.Column("updated_by", sa.String(100), nullable=True),
            sa.UniqueConstraint("connection_id",
                                name="uq_connection_budgets_connection"),
            sa.CheckConstraint("max_concurrent_runs >= 0",
                               name="ck_connection_budgets_max_nonneg"),
            sa.CheckConstraint("reserved_critical_slots >= 0",
                               name="ck_connection_budgets_reserved_nonneg"),
            sa.CheckConstraint(
                "reserved_critical_slots <= max_concurrent_runs",
                name="ck_connection_budgets_reserved_within_max"),
        )
        op.create_index("ix_connection_budgets_connection",
                        "connection_concurrency_budgets", ["connection_id"])

    if not _table_exists("connection_claims"):
        op.create_table(
            "connection_claims",
            sa.Column("id", sa.Integer(), primary_key=True),
            sa.Column("connection_id", sa.Integer(), nullable=False),
            sa.Column("run_kind", sa.String(20), nullable=False,
                      server_default="feed_run"),
            sa.Column("run_id", sa.Integer(), nullable=False),
            sa.Column("pod_id", sa.String(100), nullable=False),
            sa.Column("priority", sa.Integer(), nullable=True),
            sa.Column("feed_config_id", sa.Integer(), nullable=True),
            sa.Column("claimed_at", sa.DateTime(), nullable=False),
            sa.Column("heartbeat_at", sa.DateTime(), nullable=False),
            sa.Column("created_at", sa.DateTime(), nullable=False,
                      server_default=sa.text("CURRENT_TIMESTAMP")),
            sa.Column("created_by", sa.String(100), nullable=True),
            sa.Column("updated_at", sa.DateTime(), nullable=True),
            sa.Column("updated_by", sa.String(100), nullable=True),
            sa.UniqueConstraint("connection_id", "run_kind", "run_id",
                                name="uq_connection_claims_conn_kind_run"),
            sa.CheckConstraint(f"run_kind IN ({_RUN_KINDS})",
                               name="ck_connection_claims_run_kind"),
        )
        op.create_index("ix_connection_claims_connection",
                        "connection_claims", ["connection_id"])
        op.create_index("ix_connection_claims_kind_run",
                        "connection_claims", ["run_kind", "run_id"])
        op.create_index("ix_connection_claims_run_id",
                        "connection_claims", ["run_id"])

    if not _table_exists("feed_partition_declarations"):
        op.create_table(
            "feed_partition_declarations",
            sa.Column("id", sa.Integer(), primary_key=True),
            # No FK on purpose: completeness EVIDENCE must outlive a
            # purged run row (§9.3 "shown again next year").
            sa.Column("feed_run_id", sa.Integer(), nullable=False),
            sa.Column("feed_config_id", sa.Integer(), nullable=False),
            sa.Column("business_date", sa.Date(), nullable=False),
            sa.Column("identities", sa.JSON(), nullable=False),
            sa.Column("identity_count", sa.Integer(), nullable=False),
            sa.Column("on_empty", sa.String(10), nullable=False,
                      server_default="fail"),
            sa.Column("source", sa.Text(), nullable=True),
            sa.Column("declared_at", sa.DateTime(), nullable=False),
            sa.Column("created_at", sa.DateTime(), nullable=False,
                      server_default=sa.text("CURRENT_TIMESTAMP")),
            sa.Column("created_by", sa.String(100), nullable=True),
            sa.Column("updated_at", sa.DateTime(), nullable=True),
            sa.Column("updated_by", sa.String(100), nullable=True),
            sa.UniqueConstraint("feed_run_id",
                                name="uq_feed_partition_declarations_run"),
            sa.CheckConstraint(
                f"on_empty IN ({_ON_EMPTY})",
                name="ck_feed_partition_declarations_on_empty"),
        )
        op.create_index("ix_feed_partition_declarations_feed_date",
                        "feed_partition_declarations",
                        ["feed_config_id", "business_date"])
        op.create_index("ix_feed_partition_declarations_run",
                        "feed_partition_declarations", ["feed_run_id"])
        op.create_index("ix_feed_partition_declarations_business_date",
                        "feed_partition_declarations", ["business_date"])


def downgrade() -> None:
    # connection_claims is EPHEMERAL state (live slots) — safe to drop.
    if _table_exists("connection_claims"):
        op.drop_table("connection_claims")
    # The other three hold DATA a live system depends on:
    # * feed_file_runs — run history + re-run addressability;
    # * feed_partition_declarations — completeness evidence (§9.3:
    #   "shown again next year");
    # * connection_concurrency_budgets — admin-declared configuration.
    # Dropping them on downgrade is a data-loss operation, and the old
    # code ignores unknown tables — so, like 022's columns, they are
    # deliberately retained.
