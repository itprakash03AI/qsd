"""2026-07 — island-first pruning: partition_values on iceberg_file_stats_v3.

Adds the TOP-LEVEL PARTITION INDEX (Level 1 of the Starburst two-level model:
partition index + per-file column_stats).  ``partition_values`` holds
``{partition_col_lower: token_str}`` for the file, captured generically from
the Hive ``col=value`` path segments.  A partition-filtered query can then
carve the ISLAND in SQL (``partition_values[col] IN (...)``) instead of loading
the whole table's stats and filtering in Python.

Nullable + additive — old rows stay NULL and the island load ALWAYS keeps a
NULL-partition file (fail-open superset), so this can never drop a row.  Plain
JSON for SQLite+Postgres portability (queried via json_extract / ->>).  The
runtime ``_auto_migrate_from_models`` also adds this column from the model on
Postgres/SQLite; this migration is the formal/CI parity + idempotency net.

Revision ID: 016_iceberg_file_stats_partition_values
Revises: 015_system_account_approle_fields
Create Date: 2026-07
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "016_iceberg_file_stats_partition_values"
down_revision: Union[str, None] = "015_system_account_approle_fields"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _table_exists(name: str) -> bool:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    try:
        return name in insp.get_table_names()
    except Exception:
        return False


def _column_exists(table: str, col: str) -> bool:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    try:
        return any(c["name"] == col for c in insp.get_columns(table))
    except Exception:
        return False


def upgrade() -> None:
    # Idempotent — safe when auto-migrate-from-Base already added the column.
    if not _table_exists("iceberg_file_stats_v3"):
        return
    if not _column_exists("iceberg_file_stats_v3", "partition_values"):
        op.add_column(
            "iceberg_file_stats_v3",
            sa.Column("partition_values", sa.JSON(), nullable=True),
        )


def downgrade() -> None:
    if not _table_exists("iceberg_file_stats_v3"):
        return
    if _column_exists("iceberg_file_stats_v3", "partition_values"):
        try:
            op.drop_column("iceberg_file_stats_v3", "partition_values")
        except Exception:
            pass
