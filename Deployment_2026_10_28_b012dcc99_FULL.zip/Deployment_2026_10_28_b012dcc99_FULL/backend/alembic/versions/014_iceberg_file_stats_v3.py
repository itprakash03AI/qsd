"""2026-07-13 — iceberg_file_stats_v3 (per-FILE column statistics).

User report: the v2 supplement (iceberg_column_stats_supplement_v2) stores
ONE ROW PER (file × column) — a 3000-file table with 40 columns produces
~120,000 rows.  Iceberg manifests / Starburst encode per-file stats as
one entry per FILE (field-id-keyed maps of all columns).  This table
mirrors that grain: ONE ROW PER FILE, every column's min/max/null packed
into a JSON ``column_stats`` map → 3000 rows instead of 120,000.

Additive + flag-gated (``iceberg.file_stats_grain``): default "v2" leaves
v2 as the sole read/write path.  "both" dual-writes this table (v2 still
read) to validate parity; "v3" reads/writes per-file only.  v2 is left
untouched so a cutover is fully reversible.

Same content-identity model as v2 (bucket + table_prefix) so multiple
QueryStudio connections pointing at the same S3 location share rows.

Revision ID: 014_iceberg_file_stats_v3
Revises: 013_phase_154_system_account_vault_refs
Create Date: 2026-07-13
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "014_iceberg_file_stats_v3"
down_revision: Union[str, None] = "013_phase_154_system_account_vault_refs"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _table_exists(name: str) -> bool:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    try:
        return name in insp.get_table_names()
    except Exception:
        return False


def upgrade() -> None:
    # Idempotent — safe even when core.database's auto-create-from-Base
    # path already materialised the table.
    if _table_exists("iceberg_file_stats_v3"):
        return

    op.create_table(
        "iceberg_file_stats_v3",
        sa.Column("id",            sa.Integer(),    nullable=False),
        sa.Column("bucket",        sa.String(255),  nullable=False, server_default=""),
        sa.Column("table_prefix",  sa.String(512),  nullable=False, server_default=""),
        sa.Column("snapshot_id",   sa.String(64),   nullable=False),
        sa.Column("file_path",     sa.String(1024), nullable=False),
        sa.Column("connection_id", sa.Integer(),    nullable=True),
        sa.Column("table_name",    sa.String(255),  nullable=True),
        # All columns' stats for this file: {col_lower: {"lo","hi","nulls"}}
        sa.Column("column_stats",  sa.JSON(),       nullable=False),
        sa.Column("row_count",     sa.BigInteger(), nullable=True, server_default="0"),
        sa.Column("file_size",     sa.BigInteger(), nullable=True, server_default="0"),
        sa.Column("scanned_at",    sa.DateTime(),   nullable=True),
        sa.Column("format",        sa.String(32),   nullable=False, server_default="iceberg"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        "ix_iceberg_file_stats_lookup_v3",
        "iceberg_file_stats_v3",
        ["bucket", "table_prefix", "snapshot_id", "file_path"],
        unique=True,
    )


def downgrade() -> None:
    if not _table_exists("iceberg_file_stats_v3"):
        return
    try:
        op.drop_index("ix_iceberg_file_stats_lookup_v3",
                       table_name="iceberg_file_stats_v3")
    except Exception:
        pass
    op.drop_table("iceberg_file_stats_v3")
