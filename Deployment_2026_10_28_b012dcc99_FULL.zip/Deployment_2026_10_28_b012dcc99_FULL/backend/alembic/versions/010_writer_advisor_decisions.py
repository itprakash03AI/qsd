"""Phase 149 Writer Advisor — decisions ledger.

The Writer Advisor's ``record_decision`` originally created the
``writer_advisor_decisions`` table via raw ``CREATE TABLE IF NOT
EXISTS`` issued lazily on the first DB call.  That SQL used
``AUTOINCREMENT`` which is SQLite-specific — Oracle deployments would
have failed silently at write time.

This migration creates the table portably so production deployments
managed by alembic get the right shape from the start.  The lazy
create-if-not-exists path stays in writer_advisor.py as a dev-safety
net for fresh databases that haven't run migrations yet.

Revision ID: 010_writer_advisor_decisions
Revises: 009_phase_150_iceberg_mirror
Create Date: 2026-06-10
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "010_writer_advisor_decisions"
down_revision: Union[str, None] = "009_phase_150_iceberg_mirror"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _table_exists(name: str) -> bool:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    try:
        return name in insp.get_table_names()
    except Exception:
        return False


def upgrade() -> None:
    # Idempotent — safe to run even when the lazy ``CREATE TABLE IF
    # NOT EXISTS`` path in writer_advisor._ensure_decision_table_exists
    # already created the table on a fresh dev DB.
    if _table_exists("writer_advisor_decisions"):
        return

    op.create_table(
        "writer_advisor_decisions",
        sa.Column("id", sa.Integer(), nullable=False),
        # (bucket, prefix, column, kind) is the dedup key the advisor
        # uses to check "has this been accepted/dismissed before?"
        sa.Column("bucket",        sa.String(255), nullable=False,
                  server_default=""),
        sa.Column("table_prefix",  sa.String(512), nullable=False,
                  server_default=""),
        sa.Column("column_name",   sa.String(255), nullable=False,
                  server_default=""),
        sa.Column("kind",          sa.String(64),  nullable=False,
                  server_default=""),
        # Lifecycle: pending | accepted | dismissed | shadow
        sa.Column("status",        sa.String(32),  nullable=False,
                  server_default="pending"),
        # ISO timestamp — string so it stores identically on SQLite
        # (no TZ) and Oracle (TIMESTAMP WITH TZ) without driver
        # conversions tripping the comparator.
        sa.Column("decided_at",    sa.String(64),  nullable=False,
                  server_default=""),
        sa.Column("decided_by",    sa.String(128), nullable=True),
        sa.Column("reason",        sa.String(512), nullable=True),
        # Free-form JSON blob (proposed_transform + leverage estimate
        # at decision time).  Stored as TEXT so it survives the
        # SQLite/Oracle split with no driver-specific JSON type.
        sa.Column("details",       sa.Text(),      nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )

    # Dedup-key lookup — every record_decision check + every
    # compute_all() walk hits this index.
    op.create_index(
        "ix_writer_advisor_decisions_dedup",
        "writer_advisor_decisions",
        ["bucket", "table_prefix", "column_name", "kind"],
        unique=False,
    )
    # decided_at sort — list_decisions returns newest-first.
    op.create_index(
        "ix_writer_advisor_decisions_decided_at",
        "writer_advisor_decisions",
        ["decided_at"],
        unique=False,
    )


def downgrade() -> None:
    op.drop_index(
        "ix_writer_advisor_decisions_decided_at",
        table_name="writer_advisor_decisions",
    )
    op.drop_index(
        "ix_writer_advisor_decisions_dedup",
        table_name="writer_advisor_decisions",
    )
    op.drop_table("writer_advisor_decisions")
