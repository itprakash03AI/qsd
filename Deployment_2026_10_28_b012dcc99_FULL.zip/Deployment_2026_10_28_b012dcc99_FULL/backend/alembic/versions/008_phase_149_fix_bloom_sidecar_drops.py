"""Phase 149 deep-dive fix #1 — query_pruning_history.bloom_sidecar_drops.

Pre-fix: 149.4 emitted ``stage_drops["bloom_sidecar"]`` into _out_meta
but the QueryPruningHistory schema had no column for it.  Every per-
query row silently DROPPED the bloom-sidecar count when persisted.

Symptoms:
  * Diagnose UI showed bloom_sidecar correctly (reads in-memory ring)
  * Aggregated dashboards / historical trend queries saw zero pruning
    from the 149.4 sidecar
  * 149.6 adaptive prefetcher's feedback loop was blind to the
    sidecar effectiveness, so it couldn't tell which scans were
    actually helping

Fix: new ``bloom_sidecar_drops`` nullable Integer column.  Persisted
alongside the existing ``bloom_drops`` (BF-548 native S3 bloom) so
both prune sources are visible separately in history.

Same idempotent migration pattern as the BF-594 column add.

Revision ID: 008_bloom_sidecar_drops
Revises: 007_phase_149_4_bloom_sidecar
Create Date: 2026-06-09
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "008_bloom_sidecar_drops"
down_revision: Union[str, None] = "007_phase_149_4_bloom_sidecar"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _column_exists(table: str, column: str) -> bool:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    try:
        cols = {c["name"] for c in insp.get_columns(table)}
    except Exception:
        return False
    return column in cols


def upgrade() -> None:
    if not _column_exists("query_pruning_history", "bloom_sidecar_drops"):
        op.add_column(
            "query_pruning_history",
            sa.Column("bloom_sidecar_drops", sa.Integer(), nullable=True),
        )


def downgrade() -> None:
    if _column_exists("query_pruning_history", "bloom_sidecar_drops"):
        op.drop_column("query_pruning_history", "bloom_sidecar_drops")
