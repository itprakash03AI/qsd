"""Foundation P — build_id + definition pinning (BRD 2026-09-02).

Implements FR-RUN-01/03, FR-GOV-01 and defect D6:

* ``feed_runs`` / ``feed_executions`` gain ``build_id`` plus the
  claim-time pin columns (definition version pointer, git commit, image
  tag) and a reaper ``heartbeat_at``.  ALL nullable — every existing row
  stays valid on a live system.
* ``feed_definition_versions`` — one immutable row per distinct
  definition of a feed, ``(feed_config_id, version)`` unique.  (This
  table also self-creates via ``Base.metadata.create_all()``; the DDL
  here is idempotent for deployments that run alembic first.)
* D6: the partial unique index
  ``ux_feed_executions_one_active_per_feed`` enforced ONE ACTIVE
  EXECUTION PER FEED — forbidding child runs and forbidding a backfill
  of a date that has already run, and letting an orphaned claim block
  the feed permanently.  It is replaced by guards keyed on the new run
  identity ``(feed_config_id, business_date, build_id)`` — created
  FIRST, old dropped LAST, so the protection window never opens.
  ``ux_feed_runs_one_per_feed_per_date`` on feed_runs is split the same
  way (legacy NULL-build rows keep the exact old one-per-date rule).

NOTE (repo rule, §14): alembic is NOT invoked at runtime — nothing runs
``alembic upgrade head`` on boot.  The startup path in
``core.database._apply_postgresql_migrations`` / ``_apply_sqlite_migrations``
performs the same column adds and the same index swap, so a deployed pod
is corrected without this file.  Both are idempotent with each other.

Revision ID: 022_feed_build_id_and_pinning
Revises: 021_widen_counters_to_bigint
Create Date: 2026-09-02
"""
from collections.abc import Sequence

import sqlalchemy as sa

from alembic import op

revision: str = "022_feed_build_id_and_pinning"
down_revision: str | None = "021_widen_counters_to_bigint"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _insp():
    return sa.inspect(op.get_bind())


def _table_exists(table: str) -> bool:
    try:
        return table in set(_insp().get_table_names())
    except Exception:  # noqa: BLE001 — introspection failure = treat as absent
        return False


def _column_exists(table: str, column: str) -> bool:
    try:
        cols = {c["name"] for c in _insp().get_columns(table)}
    except Exception:  # noqa: BLE001 — introspection failure = treat as absent
        return False
    return column in cols


def _add_column_if_missing(table: str, column: sa.Column) -> None:
    if _table_exists(table) and not _column_exists(table, column.name):
        op.add_column(table, column)


# The replacement guards.  Partial unique indexes — valid on PostgreSQL
# and SQLite (3.8+).  Kept as plain-column partials (no COALESCE
# expressions) so the DDL is dialect-portable.
_NEW_INDEXES = (
    ("feed_executions",
     ("CREATE UNIQUE INDEX IF NOT EXISTS ux_feed_executions_one_active_legacy "
     "ON feed_executions (feed_config_id) "
     "WHERE status IN ('pending','running') AND business_date IS NULL")),
    ("feed_executions",
     ("CREATE UNIQUE INDEX IF NOT EXISTS "
     "ux_feed_executions_one_active_per_date "
     "ON feed_executions (feed_config_id, business_date) "
     "WHERE status IN ('pending','running') AND business_date IS NOT NULL")),
    ("feed_executions",
     ("CREATE UNIQUE INDEX IF NOT EXISTS ux_feed_executions_identity "
     "ON feed_executions (feed_config_id, business_date, build_id) "
     "WHERE build_id IS NOT NULL AND business_date IS NOT NULL")),
    ("feed_runs",
     ("CREATE UNIQUE INDEX IF NOT EXISTS "
     "ux_feed_runs_one_per_feed_per_date_legacy "
     "ON feed_runs (feed_config_id, business_date) "
     "WHERE build_id IS NULL")),
    ("feed_runs",
     ("CREATE UNIQUE INDEX IF NOT EXISTS ux_feed_runs_identity "
     "ON feed_runs (feed_config_id, business_date, build_id) "
     "WHERE build_id IS NOT NULL")),
)


def upgrade() -> None:
    bind = op.get_bind()
    is_pg = bind.dialect.name == "postgresql"

    # ── 1. Columns (all nullable — every existing row stays valid) ──────
    _add_column_if_missing(
        "feed_runs", sa.Column("build_id", sa.String(40), nullable=True))
    _add_column_if_missing(
        "feed_runs", sa.Column("pinned_version_id", sa.Integer,
                               nullable=True))
    _add_column_if_missing(
        "feed_runs", sa.Column("pinned_git_commit", sa.String(64),
                               nullable=True))
    _add_column_if_missing(
        "feed_runs", sa.Column("pinned_image_tag", sa.String(200),
                               nullable=True))
    _add_column_if_missing(
        "feed_runs", sa.Column("pinned_at", sa.DateTime, nullable=True))
    _add_column_if_missing(
        "feed_runs", sa.Column("heartbeat_at", sa.DateTime, nullable=True))

    _add_column_if_missing(
        "feed_executions", sa.Column("business_date", sa.Date,
                                     nullable=True))
    _add_column_if_missing(
        "feed_executions", sa.Column("build_id", sa.String(40),
                                     nullable=True))
    _add_column_if_missing(
        "feed_executions", sa.Column("pinned_version_id", sa.Integer,
                                     nullable=True))
    _add_column_if_missing(
        "feed_executions", sa.Column("pinned_git_commit", sa.String(64),
                                     nullable=True))
    _add_column_if_missing(
        "feed_executions", sa.Column("pinned_image_tag", sa.String(200),
                                     nullable=True))
    _add_column_if_missing(
        "feed_executions", sa.Column("heartbeat_at", sa.DateTime,
                                     nullable=True))

    # ── 2. feed_definition_versions (idempotent — also self-creates) ────
    if not _table_exists("feed_definition_versions"):
        op.create_table(
            "feed_definition_versions",
            sa.Column("id", sa.Integer, primary_key=True),
            sa.Column("feed_config_id", sa.Integer, nullable=False,
                      index=True),
            sa.Column("version", sa.Integer, nullable=False),
            sa.Column("definition", sa.JSON, nullable=False),
            sa.Column("definition_hash", sa.String(64), nullable=False,
                      index=True),
            sa.Column("git_commit", sa.String(64), nullable=True),
            sa.Column("image_tag", sa.String(200), nullable=True),
            sa.Column("created_at", sa.DateTime, nullable=True),
            sa.Column("created_by", sa.String(100), nullable=True),
            sa.Column("updated_at", sa.DateTime, nullable=True),
            sa.Column("updated_by", sa.String(100), nullable=True),
            sa.UniqueConstraint(
                "feed_config_id", "version",
                name="ux_feed_definition_versions_feed_version"),
        )

    # ── 3. D6 index swap — create new FIRST, drop old LAST ──────────────
    # Live data is clean by construction for every new index: the old
    # guards were strictly stricter, and the new columns are NULL on
    # every pre-existing row.
    for table, stmt in _NEW_INDEXES:
        if _table_exists(table):
            op.execute(stmt)

    if _table_exists("feed_executions"):
        op.execute(
            "DROP INDEX IF EXISTS ux_feed_executions_one_active_per_feed")
    if _table_exists("feed_runs"):
        if is_pg:
            op.execute("ALTER TABLE feed_runs DROP CONSTRAINT IF EXISTS "
                       "ux_feed_runs_one_per_feed_per_date")
        # Some DBs carry it as a bare index (and on SQLite a table-inline
        # UNIQUE constraint cannot be dropped without a rebuild — the
        # legacy partial index above still matches its behaviour).
        op.execute("DROP INDEX IF EXISTS ux_feed_runs_one_per_feed_per_date")


def downgrade() -> None:
    bind = op.get_bind()
    is_pg = bind.dialect.name == "postgresql"

    # Restore the old guards ONLY if the live data still satisfies them
    # (post-P data may legitimately hold several builds per feed+date —
    # recreating the strict old unique index would then fail; leave the
    # new shape in place rather than abort the downgrade).
    for stmt in (
        "DROP INDEX IF EXISTS ux_feed_executions_one_active_legacy",
        "DROP INDEX IF EXISTS ux_feed_executions_one_active_per_date",
        "DROP INDEX IF EXISTS ux_feed_executions_identity",
        "DROP INDEX IF EXISTS ux_feed_runs_one_per_feed_per_date_legacy",
        "DROP INDEX IF EXISTS ux_feed_runs_identity",
    ):
        op.execute(stmt)
    import logging
    _log = logging.getLogger(__name__)
    try:
        op.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS "
            "ux_feed_executions_one_active_per_feed "
            "ON feed_executions (feed_config_id) "
            "WHERE status IN ('pending','running')")
    except Exception as exc:  # noqa: BLE001 — see docstring: never abort downgrade
        _log.warning(
            "downgrade: could not restore the old one-active-per-feed "
            "index (live data may hold several builds per feed): %s", exc)
    try:
        if is_pg:
            op.execute(
                "ALTER TABLE feed_runs ADD CONSTRAINT "
                "ux_feed_runs_one_per_feed_per_date "
                "UNIQUE (feed_config_id, business_date)")
        else:
            op.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS "
                "ux_feed_runs_one_per_feed_per_date "
                "ON feed_runs (feed_config_id, business_date)")
    except Exception as exc:  # noqa: BLE001 — see docstring: never abort downgrade
        _log.warning(
            "downgrade: could not restore ux_feed_runs_one_per_feed_per_date "
            "(live data may hold several builds per feed+date): %s", exc)

    # Columns are left in place on purpose: dropping a column on a live
    # table is a data-loss operation and the old code ignores unknown
    # columns.  feed_definition_versions is likewise retained (audit).
