"""2026-08-22 — LOCAL COLUMN CATALOG: create catalog_table_columns.

Operator report: "Create Dataset — could not read any columns for the
selected tables: why you are connecting to starburst or s3 to get
columns... we should have saved all columns in our local db".

``schema_cache`` was only ever populated as a side effect of a successful
source read — a cache, not a catalog.  ``catalog_table_columns`` is the
durable record: one row per (connection, table), columns in the API
contract shape, with provenance (``source``), staleness
(``last_refreshed_at``) and per-table failure reasons (``last_error``).
All access goes through ``core.schema_catalog.ColumnCatalog``.

DEPLOYMENT REALITY (the 2026-08-20 lesson): **Alembic is never
auto-invoked in this deployment — this migration alone cannot reach a
pod.**  The table actually reaches pods via ``Base.metadata.create_all()``
at startup (fresh model in ``core/db/models.py``), and
``ColumnCatalog`` degrades to the legacy ``schema_cache`` table when the
table is absent.  This file exists for hand-run ``alembic upgrade head``
environments and to keep the migration chain truthful.

Data backfill (migrating existing ``schema_cache`` rows in) is NOT done
here — it happens lazily on read (``ColumnCatalog.get_entry`` migrates
legacy rows on sight) and eagerly via
``scripts/backfill_column_catalog.py``, both of which work regardless of
how the table was created.

Revision ID: 020_catalog_table_columns
Revises: 019_repair_partition_seek_index
Create Date: 2026-08-22
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "020_catalog_table_columns"
down_revision: Union[str, None] = "019_repair_partition_seek_index"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_TABLE = "catalog_table_columns"
_INDEX = "ix_catalog_table_columns_lookup"
_INDEX_COLS = ["connection_id", "table_name"]


def _inspector():
    return sa.inspect(op.get_bind())


def upgrade() -> None:
    insp = _inspector()
    if _TABLE not in insp.get_table_names():
        op.create_table(
            _TABLE,
            sa.Column("id", sa.Integer(), primary_key=True),
            sa.Column("connection_id", sa.Integer(), nullable=False),
            sa.Column("table_name", sa.String(length=255), nullable=False),
            sa.Column("columns_json", sa.JSON(), nullable=False),
            sa.Column("source", sa.String(length=32), nullable=False,
                      server_default="unknown"),
            sa.Column("table_format", sa.String(length=20), nullable=True),
            sa.Column("row_estimate", sa.BigInteger(), nullable=True),
            sa.Column("partition_columns", sa.JSON(), nullable=True),
            sa.Column("last_refreshed_at", sa.DateTime(), nullable=True),
            sa.Column("last_error", sa.Text(), nullable=True),
            sa.Column("last_error_at", sa.DateTime(), nullable=True),
            sa.Column("created_at", sa.DateTime(), nullable=True),
            sa.Column("updated_at", sa.DateTime(), nullable=True),
        )
        op.create_index(_INDEX, _TABLE, _INDEX_COLS, unique=True)
        return

    # Table exists (create_all beat us to it, or a re-run).  A
    # table-existence check is NOT an index-shape check (019's lesson):
    # verify the unique lookup index really is (connection_id, table_name)
    # unique, and repair it when it is not.
    insp = _inspector()
    found = None
    for ix in insp.get_indexes(_TABLE):
        if ix.get("name") == _INDEX:
            found = ix
            break
    if found is not None:
        cols = [c for c in (found.get("column_names") or []) if c]
        if cols == _INDEX_COLS and bool(found.get("unique")):
            return  # already correct
        op.drop_index(_INDEX, table_name=_TABLE)
    op.create_index(_INDEX, _TABLE, _INDEX_COLS, unique=True)


def downgrade() -> None:
    insp = _inspector()
    if _TABLE in insp.get_table_names():
        op.drop_table(_TABLE)
