"""2026-07-13 — SystemAccount AppRole / JWT-step-up vault fields (ETL parity).

The backend qs_credentials vault dance is byte-identical to ETL's, but the
SystemAccount model only carried the JWT-path ref fields.  So AppRole could
not work from QueryStudio, AND (the deeper bug) to_dict never emitted the
_url fields, so the resolver's ref had an empty auth_url/secret_url — vault
failed for every method.  This migration adds the 5 columns so _row_to_ref
can build the SAME complete ref ETL's vault_config.yaml provides.

All nullable — only used when the account authenticates via AppRole; JWT
accounts leave them blank.

Revision ID: 015_system_account_approle_fields
Revises: 014_iceberg_file_stats_v3
Create Date: 2026-07-13
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "015_system_account_approle_fields"
down_revision: Union[str, None] = "014_iceberg_file_stats_v3"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


_COLUMNS = [
    ("vault_step_up_name",          sa.String(255)),
    ("vault_step_up_auth_url",      sa.Text()),
    ("vault_approle_secret_id_url", sa.Text()),
    ("vault_approle_auth_url",      sa.Text()),
    ("vault_role_id",               sa.String(255)),
]


def _existing_cols() -> set:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    try:
        return {c["name"] for c in insp.get_columns("system_accounts")}
    except Exception:
        return set()


def upgrade() -> None:
    have = _existing_cols()
    if not have:
        return  # table absent (fresh DB) — create_all/auto-migrate handles it
    for name, coltype in _COLUMNS:
        if name not in have:
            op.add_column("system_accounts",
                          sa.Column(name, coltype, nullable=True))


def downgrade() -> None:
    have = _existing_cols()
    for name, _ in _COLUMNS:
        if name in have:
            try:
                op.drop_column("system_accounts", name)
            except Exception:
                pass
