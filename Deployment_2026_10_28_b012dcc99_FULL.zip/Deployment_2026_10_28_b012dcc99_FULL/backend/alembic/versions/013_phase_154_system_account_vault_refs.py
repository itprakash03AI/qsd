"""Phase 154 -- system_accounts vault-resolver fields.

Operator 2026-06-25: "we have secret resolver in etl folder...we need
here at query studio also in case of if any system account used for
aws s3 or trino or any source so we need to capture and store those
required details in databse table for each system account so at
runtime we can fetch credentials".

Mirrors the ETL/qs_credentials/resolver.py vault_config.yaml refs shape so
the SAME vault entries serve both pods (ETL + QueryStudio).  Adds
6 nullable columns to ``system_accounts``:

  * use_vault          BOOLEAN  default false (opt-in per account)
  * secret_ref         VARCHAR(255)  (vault ref name; defaults to
                        system_accounts.name when blank)
  * secret_type        VARCHAR(50)   ("DB_accounts" | "AD_accounts" |
                        "kv_secrets")
  * vault_auth_url     TEXT
  * vault_role_name    VARCHAR(255)
  * vault_role_type    VARCHAR(50)
  * vault_secret_url   TEXT
  * vault_rotate_url   TEXT

Nullable + server_default false on use_vault means historical rows
keep working unchanged (no backfill needed) -- only operator-flipped
accounts route through the resolver.

Revision ID: 013_phase_154_system_account_vault_refs
Revises:    012_phase_151_e_mirror_source_format
Create Date: 2026-06-25
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "013_phase_154_system_account_vault_refs"
down_revision: Union[str, None] = "012_phase_151_e_mirror_source_format"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _column_exists(table: str, column: str) -> bool:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    try:
        return any(c["name"] == column for c in insp.get_columns(table))
    except Exception:
        return False


def upgrade() -> None:
    table = "system_accounts"

    # use_vault -- opt-in toggle per account.  Default false so the
    # encrypted-password path stays the legacy/historic shape.
    if not _column_exists(table, "use_vault"):
        op.add_column(table, sa.Column(
            "use_vault", sa.Boolean(),
            nullable=False, server_default=sa.text("0"),
        ))

    # Ref-lookup metadata (mirrors ETL vault_config.yaml refs shape).
    for col_name, col_type in (
        ("secret_ref",       sa.String(255)),
        ("secret_type",      sa.String(50)),
        ("vault_auth_url",   sa.Text()),
        ("vault_role_name",  sa.String(255)),
        ("vault_role_type",  sa.String(50)),
        ("vault_secret_url", sa.Text()),
        ("vault_rotate_url", sa.Text()),
    ):
        if not _column_exists(table, col_name):
            op.add_column(table, sa.Column(
                col_name, col_type, nullable=True,
            ))


def downgrade() -> None:
    table = "system_accounts"
    for col in (
        "vault_rotate_url", "vault_secret_url", "vault_role_type",
        "vault_role_name", "vault_auth_url", "secret_type",
        "secret_ref", "use_vault",
    ):
        if _column_exists(table, col):
            try:
                op.drop_column(table, col)
            except Exception:
                # Some sqlite versions / older drivers cannot drop a
                # column; in that case the downgrade is a soft-fail
                # (the columns are nullable + harmless when ignored).
                pass
