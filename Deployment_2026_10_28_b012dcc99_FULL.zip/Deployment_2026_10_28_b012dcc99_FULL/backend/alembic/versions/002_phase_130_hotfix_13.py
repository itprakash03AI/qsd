"""Phase 130 hotfix-13 — Enterprise failover + entitlements + scale.

Adds:
  - system_settings (key/value runtime config; admin-tunable from UI)
  - worker_health_state (per-pod heartbeat for multi-pod fleet probe)
  - user_groups.notification_email + user_group_members.resource_access_level
  - reports.owner_group_id (entitlement parity with feeds)

All operations are idempotent (``if_not_exists=True`` for tables, plus
column-existence guards for the ALTER cases) so re-running this
migration on a partially-applied database is safe.

Revision ID: 002_hotfix13
Revises: 001_initial
Create Date: 2026-05-16
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "002_hotfix13"
down_revision: Union[str, None] = "001_initial"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _column_exists(table: str, column: str) -> bool:
    """Idempotency helper — Alembic's add_column doesn't have an
    if_not_exists flag, so we inspect the live schema first."""
    bind = op.get_bind()
    insp = sa.inspect(bind)
    try:
        cols = {c["name"] for c in insp.get_columns(table)}
    except Exception:
        return False
    return column in cols


def upgrade() -> None:
    # ── system_settings (generic admin-tunable runtime config) ────────────
    op.create_table(
        "system_settings",
        sa.Column("key", sa.String(128), primary_key=True),
        sa.Column("value", sa.JSON, nullable=False),
        sa.Column("description", sa.String(500), nullable=True),
        sa.Column("updated_by", sa.String(100), nullable=True),
        sa.Column("updated_at", sa.DateTime, nullable=True),
        if_not_exists=True,
    )

    # ── worker_health_state (per-pod heartbeat for fleet probe) ───────────
    op.create_table(
        "worker_health_state",
        sa.Column("pod_id", sa.String(150), primary_key=True),
        sa.Column("last_tick_at", sa.DateTime, nullable=False),
        sa.Column("last_tick_result", sa.JSON, nullable=True),
        sa.Column("inflight_count", sa.Integer, default=0),
        sa.Column("shard", sa.String(20), nullable=True),
        sa.Column("updated_at", sa.DateTime, nullable=True),
        if_not_exists=True,
    )

    # ── user_groups.notification_email (group-wide alert recipients) ──────
    if not _column_exists("user_groups", "notification_email"):
        op.add_column(
            "user_groups",
            sa.Column("notification_email", sa.String(500), nullable=True),
        )

    # ── user_group_members.resource_access_level (read_only / read_write) ─
    # Defaults to 'read_write' so existing memberships keep their pre-
    # hotfix full-access semantics.  Admins downgrade specific users
    # to 'read_only' via the admin UI.
    if not _column_exists("user_group_members", "resource_access_level"):
        op.add_column(
            "user_group_members",
            sa.Column(
                "resource_access_level",
                sa.String(20),
                nullable=False,
                server_default="read_write",
            ),
        )

    # ── reports.owner_group_id (entitlement parity with feed_configs) ─────
    if not _column_exists("reports", "owner_group_id"):
        op.add_column(
            "reports",
            sa.Column("owner_group_id", sa.Integer, nullable=True, index=True),
        )

    # ── feed_executions.stage_timings + failed_stage (CBQ-parity obs) ─────
    if not _column_exists("feed_executions", "stage_timings"):
        op.add_column(
            "feed_executions",
            sa.Column("stage_timings", sa.JSON, nullable=True),
        )
    if not _column_exists("feed_executions", "failed_stage"):
        op.add_column(
            "feed_executions",
            sa.Column("failed_stage", sa.String(50), nullable=True),
        )


def downgrade() -> None:
    # Reverse in dependency order.  Column drops use server_default-aware
    # patterns where SQLite supports them; older SQLite may need batch ops.
    if _column_exists("feed_executions", "failed_stage"):
        with op.batch_alter_table("feed_executions") as batch:
            batch.drop_column("failed_stage")
    if _column_exists("feed_executions", "stage_timings"):
        with op.batch_alter_table("feed_executions") as batch:
            batch.drop_column("stage_timings")

    if _column_exists("reports", "owner_group_id"):
        with op.batch_alter_table("reports") as batch:
            batch.drop_column("owner_group_id")

    if _column_exists("user_group_members", "resource_access_level"):
        with op.batch_alter_table("user_group_members") as batch:
            batch.drop_column("resource_access_level")

    if _column_exists("user_groups", "notification_email"):
        with op.batch_alter_table("user_groups") as batch:
            batch.drop_column("notification_email")

    op.drop_table("worker_health_state", if_exists=True)
    op.drop_table("system_settings", if_exists=True)
