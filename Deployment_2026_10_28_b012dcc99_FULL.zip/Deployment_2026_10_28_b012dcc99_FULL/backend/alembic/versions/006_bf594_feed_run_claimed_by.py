"""BF-594 / BF-597 — FeedRun.claimed_by column.

Adds a dedicated ``claimed_by`` column to ``feed_runs`` so the
queue-worker's atomic claim no longer OVERWRITES the original
``triggered_by`` (which downstream notification routing / SLA scanner
/ notify-stage all read for lineage).

Pre-BF-594 behaviour: ``claim_pending_feed_run`` wrote
``triggered_by='queue_worker'`` on every claim, silently destroying
the original source ("external" / "rerun" / "sod" / "manual" /
username).  Notification routing saw ``triggered_by='queue_worker'``
for every claimed row.

BF-594 fix: new ``claimed_by VARCHAR(100), nullable`` column.  Claim
writes ``claimed_by``; ``triggered_by`` is left untouched.
``reset_feed_run_to_pending_if_owned`` filters by ``claimed_by``
primarily, with a back-compat fallback to ``triggered_by`` so rows
in flight at deploy time (no ``claimed_by`` value yet) still work.

This migration is REQUIRED for any DB engine where
``core.database._migrate_schema_safely`` does NOT auto-add columns
(or for any deployment that disabled the auto-migration path).  On
sqlite + postgres the auto-add path runs at startup and is a no-op
when this migration has already run.

Revision ID: 006_feed_run_claimed_by
Revises: 005_pv_credmode
Create Date: 2026-05-30
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "006_feed_run_claimed_by"
down_revision: Union[str, None] = "005_pv_credmode"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _column_exists(table: str, column: str) -> bool:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    try:
        cols = {c["name"] for c in insp.get_columns(table)}
    except Exception:
        return False
    return column in cols


def upgrade() -> None:
    # Idempotent — safe to run even when the column was already added
    # by core.database._migrate_schema_safely (sqlite + postgres path).
    if not _column_exists("feed_runs", "claimed_by"):
        op.add_column(
            "feed_runs",
            sa.Column("claimed_by", sa.String(length=100), nullable=True),
        )
        # No backfill — NULL means "claimed by something pre-BF-594".
        # reset_feed_run_to_pending_if_owned's back-compat fallback
        # covers those rows via the ``claimed_by IS NULL AND
        # triggered_by = owned_by`` branch.


def downgrade() -> None:
    if _column_exists("feed_runs", "claimed_by"):
        op.drop_column("feed_runs", "claimed_by")
