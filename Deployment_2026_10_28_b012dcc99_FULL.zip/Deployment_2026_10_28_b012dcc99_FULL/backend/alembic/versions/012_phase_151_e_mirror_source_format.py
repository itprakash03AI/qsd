"""Phase 151.E — mirror source_format discriminator.

Adds a nullable ``source_format`` column to ``iceberg_mirror_v1`` so
PlainParquetMirrorEngine rows live in the same table as iceberg
mirror rows, distinguished by the discriminator.  Default 'iceberg'
via server_default keeps historical rows interpretable without a
backfill.

Same strategic shape Phase 151.A used for supplement / bloom /
pruning_history: ONE table, format-discriminated reads + writes.

Revision ID: 012_phase_151_e_mirror_source_format
Revises:    011_phase_151_plain_parquet_format
Create Date: 2026-06-10
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "012_phase_151_e_mirror_source_format"
down_revision: Union[str, None] = "011_phase_151_plain_parquet_format"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _column_exists(table: str, column: str) -> bool:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    try:
        cols = {c["name"] for c in insp.get_columns(table)}
        return column in cols
    except Exception:
        return False


def upgrade() -> None:
    if not _column_exists("iceberg_mirror_v1", "source_format"):
        op.add_column(
            "iceberg_mirror_v1",
            sa.Column(
                "source_format",
                sa.String(32),
                nullable=False,
                server_default="iceberg",
            ),
        )


def downgrade() -> None:
    try:
        op.drop_column("iceberg_mirror_v1", "source_format")
    except Exception:
        pass
