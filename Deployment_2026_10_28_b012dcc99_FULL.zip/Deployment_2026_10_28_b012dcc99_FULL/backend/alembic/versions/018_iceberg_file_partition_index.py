"""2026-08-19 — iceberg_file_partition_index: seek the island, don't scan for it.

``partition_values`` (migration 016) put ``{col: value}`` on every file row and
let the island carve push ``partition_values[col] IN (...)`` down into SQL.
That removed the transfer cost but not the scan: ``partition_values`` is a JSON
column and appears in NO index in the schema, so the predicate is a
POST-FILTER.  The database seeks ``(bucket, table_prefix, snapshot_id)``, walks
every file row of the snapshot, and JSON-extracts the key from each one.  A
500k-file table answering a single-region query touches 500k rows and performs
500k JSON extractions to return a few thousand.

A JSON expression index cannot fix this portably — Postgres and SQLite both
index one EXTRACTED KEY per index, and the partition columns are not known when
the schema is created.  So the value gets its own natively indexed row: one per
(file, partition column).  The island then resolves as an index RANGE SEEK on
``(bucket, table_prefix, snapshot_id, part_key, part_value)`` returning file
paths, with no row scan and no JSON parsing.

Additive and idempotent.  Nothing reads this table until it has been populated,
and the reader uses it only when it can prove COMPLETE coverage for the
snapshot — so an empty, partial or stale index costs a little time and can
never drop a file.

Revision ID: 018_iceberg_file_partition_index
Revises: 017_business_report_publish_lifecycle
Create Date: 2026-08-19
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "018_iceberg_file_partition_index"
down_revision: Union[str, None] = "017_business_report_publish_lifecycle"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_TABLE = "iceberg_file_partition_index"
_INDEX = "ix_iceberg_file_partition_seek"


def _table_exists(name: str) -> bool:
    try:
        return name in sa.inspect(op.get_bind()).get_table_names()
    except Exception:
        return False


def upgrade() -> None:
    # Idempotent — safe when core.database's auto-create-from-Base path has
    # already materialised the table from the model.
    if _table_exists(_TABLE):
        return

    op.create_table(
        _TABLE,
        sa.Column("id",           sa.Integer(),    nullable=False),
        sa.Column("bucket",       sa.String(255),  nullable=False),
        sa.Column("table_prefix", sa.String(512),  nullable=False),
        sa.Column("snapshot_id",  sa.String(64),   nullable=False),
        sa.Column("part_key",     sa.String(255),  nullable=False),
        sa.Column("part_value",   sa.String(512),  nullable=True),   # NULL = the null partition
        sa.Column("file_path",    sa.String(1024), nullable=False),
        sa.Column("created_at",   sa.DateTime(),   nullable=True),
        sa.PrimaryKeyConstraint("id"),
    )
    # Leading columns ARE the seek key; file_path rides along so the lookup is
    # index-only and unique per file.
    op.create_index(
        _INDEX, _TABLE,
        ["bucket", "table_prefix", "snapshot_id",
         "part_key", "part_value", "file_path"],
        unique=True,
    )


def downgrade() -> None:
    if not _table_exists(_TABLE):
        return
    try:
        op.drop_index(_INDEX, table_name=_TABLE)
    except Exception:
        pass
    op.drop_table(_TABLE)
