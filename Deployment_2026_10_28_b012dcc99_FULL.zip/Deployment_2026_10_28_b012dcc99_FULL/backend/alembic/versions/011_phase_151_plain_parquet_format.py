"""Phase 151 — plain parquet brain: format discriminator column.

Adds a nullable ``format`` column to the three brain-keyed tables:
  * iceberg_column_stats_supplement_v2
  * iceberg_bloom_sidecar_v1
  * query_pruning_history

Default 'iceberg' via server_default so existing rows interpret
correctly without a backfill (the brain has been iceberg-only until
2026-06-10).  New plain-parquet rows insert with format='parquet'.

The ``snapshot_id`` column stays load-bearing for the dedup key —
plain parquet rows use a synthetic snapshot_id of the form
``parquet:<file-list-sha256>`` so the (bucket, prefix, snapshot_id,
file, column) unique index still works.  No new indexes needed; the
format column is metadata + filter discriminator only.

Strategy: ONE migration adds the column to all three tables in one
revision so partial-apply doesn't leave the brain in a split state.

Revision ID: 011_phase_151_plain_parquet_format
Revises:    010_writer_advisor_decisions
Create Date: 2026-06-10
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "011_phase_151_plain_parquet_format"
down_revision: Union[str, None] = "010_writer_advisor_decisions"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _column_exists(table: str, column: str) -> bool:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    try:
        cols = {c["name"] for c in insp.get_columns(table)}
        return column in cols
    except Exception:
        return False


def _add_format_column(table: str) -> None:
    """Idempotent ADD COLUMN with server_default='iceberg'.

    Skipping when the column is already present makes the migration
    safe to re-run + safe to apply on top of a DB where
    core.database._migrate_schema_safely already added the column from
    the SQLAlchemy model definition.
    """
    if _column_exists(table, "format"):
        return
    op.add_column(
        table,
        sa.Column(
            "format",
            sa.String(32),
            nullable=False,
            server_default="iceberg",
        ),
    )


def upgrade() -> None:
    _add_format_column("iceberg_column_stats_supplement_v2")
    _add_format_column("iceberg_bloom_sidecar_v1")
    _add_format_column("query_pruning_history")


def downgrade() -> None:
    # SQLite < 3.35 doesn't support DROP COLUMN.  We attempt the drop
    # on dialects that do; otherwise the column stays (harmless since
    # it has a default).
    for table in (
        "query_pruning_history",
        "iceberg_bloom_sidecar_v1",
        "iceberg_column_stats_supplement_v2",
    ):
        try:
            op.drop_column(table, "format")
        except Exception:
            pass
