"""2026-08-20 — repair ix_iceberg_file_partition_seek when it is missing file_path.

WHAT WENT WRONG IN THE FIELD
----------------------------
A UAT pod logged this every few seconds, forever::

    iceberg_snapshot_files batch flush failed: (psycopg2.errors.UniqueViolation)
    duplicate key value violates unique constraint "ix_iceberg_file_partition_seek"
    DETAIL:  Key (bucket, table_prefix, snapshot_id, part_key, part_value)=(uat...

Read the DETAIL column list: **five** columns.  The model and migration 018 both
declare **six** — the same five plus ``file_path``.  The deployed index was the
five-column one, which asserts "at most ONE FILE per partition value".  A
partition normally holds hundreds of files, so the SECOND file of every
partition violated it, on every table, on every batch.

That alone would only cost the seek index.  What made it an outage is that the
index rows were being written in the SAME session as the ``iceberg_snapshot_
files`` rows, so the violation rolled the file rows back too — the snapshot file
store never populated, every query re-walked the manifests from S3, and the
re-walk re-attempted the same doomed insert.  A self-sustaining loop, ending in
DuckDB engine failures and an open circuit breaker.  That half is fixed in
``core/database.py`` (the mirror now writes in its own transaction and can fail
without taking the file rows with it).  This migration fixes the index itself.

WHY 018 COULD NOT SELF-HEAL
---------------------------
018 opens with ``if _table_exists(_TABLE): return`` — correct for the table, but
it takes the INDEX with it.  Any deployment whose table was materialised by
core.database's auto-create-from-Base path (against a Base that declared the
index differently) keeps that index forever: the migration sees the table, calls
itself done, and never looks at what it is repairing.

**A table-existence check is not an index-shape check.**  This migration
inspects the actual deployed columns and rebuilds only when they differ, so it
is a no-op on a correct database and a repair on a wrong one.

SAFETY
------
The six-column unique index is strictly WEAKER than the five-column one — every
row set the old index permitted is also permitted by the new one — so the
rebuild cannot fail on existing data, and no rows are deleted.

Revision ID: 019_repair_partition_seek_index
Revises: 018_iceberg_file_partition_index
Create Date: 2026-08-20
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "019_repair_partition_seek_index"
down_revision: Union[str, None] = "018_iceberg_file_partition_index"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_TABLE = "iceberg_file_partition_index"
_INDEX = "ix_iceberg_file_partition_seek"
_WANT = ["bucket", "table_prefix", "snapshot_id",
         "part_key", "part_value", "file_path"]


def _inspector():
    return sa.inspect(op.get_bind())


def upgrade() -> None:
    try:
        insp = _inspector()
        if _TABLE not in insp.get_table_names():
            return  # 018 creates it correctly; nothing deployed to repair
        found = None
        for ix in insp.get_indexes(_TABLE):
            if ix.get("name") == _INDEX:
                found = ix
                break
        # Column ORDER matters as much as membership: the leading columns are
        # the seek key, and a reordered index answers the range seek far worse
        # even when it is unique over the right set.
        if found is not None:
            cols = [c for c in (found.get("column_names") or []) if c]
            if cols == _WANT and bool(found.get("unique")):
                return  # already correct
            op.drop_index(_INDEX, table_name=_TABLE)
        op.create_index(_INDEX, _TABLE, _WANT, unique=True)
    except Exception:
        # Never block a deployment on an accelerator index.  A missing or wrong
        # index makes queries slower, not wrong — the reader uses the seek only
        # when it can prove COMPLETE coverage for the snapshot.
        pass


def downgrade() -> None:
    # No downgrade: the previous shape is a defect, not a schema version.
    pass
