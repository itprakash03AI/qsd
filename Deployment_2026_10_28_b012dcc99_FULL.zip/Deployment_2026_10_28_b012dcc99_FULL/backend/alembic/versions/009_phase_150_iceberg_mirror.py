"""Phase 150 — iceberg_mirror_v1 + iceberg_mirror_dual_run_v1.

Read-side consolidated mirror of an iceberg snapshot.  Plain parquet +
JSON manifest in QS-internal bucket — NEVER an iceberg table.  Source
iceberg metadata is consulted READ-only; never written.

Mirror routing is OFF by default at every level:
  * iceberg.mirror.enabled         (global build kill-switch)
  * iceberg.mirror.routing_enabled (global route kill-switch)
  * routing_enabled per-row toggle (per-table opt-in)
All three must be true for a query to be served from a mirror.

Companion table iceberg_mirror_dual_run_v1 carries Layer 3 canary
divergence audit rows.  Bounded retention via the engine cleanup.

Revision ID: 009_phase_150_iceberg_mirror
Revises: 008_bloom_sidecar_drops
Create Date: 2026-06-09

2026-07-13: corrected ``down_revision`` from the non-existent
``008_phase_149_fix_bloom_sidecar_drops`` to 008's ACTUAL revision id
``008_bloom_sidecar_drops`` — the mismatch created a second Alembic head
and broke ``alembic upgrade head`` (the app itself migrates via
Base.metadata.create_all(), which is why it kept running).  Only the
down-pointer changed; no revision id was renamed, so any recorded
``alembic_version`` is unaffected.
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "009_phase_150_iceberg_mirror"
down_revision: Union[str, None] = "008_bloom_sidecar_drops"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _table_exists(name: str) -> bool:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    try:
        return name in insp.get_table_names()
    except Exception:
        return False


def upgrade() -> None:
    # ── iceberg_mirror_v1 ──────────────────────────────────────────────
    if not _table_exists("iceberg_mirror_v1"):
        op.create_table(
            "iceberg_mirror_v1",
            sa.Column("id",                     sa.Integer(),    nullable=False),
            sa.Column("source_bucket",          sa.String(255),  nullable=False, server_default=""),
            sa.Column("source_prefix",          sa.String(512),  nullable=False, server_default=""),
            sa.Column("source_snapshot_id",     sa.String(64),   nullable=False),
            sa.Column("source_schema_hash",     sa.String(64),   nullable=False, server_default=""),
            sa.Column("source_row_count",       sa.BigInteger(), nullable=False, server_default="0"),
            sa.Column("source_file_count",      sa.Integer(),    nullable=False, server_default="0"),
            sa.Column("source_total_bytes",     sa.BigInteger(), nullable=False, server_default="0"),
            sa.Column("mirror_root_uri",        sa.String(1024), nullable=False, server_default=""),
            sa.Column("mirror_manifest_uri",    sa.String(1024), nullable=False, server_default=""),
            sa.Column("mirror_file_count",      sa.Integer(),    nullable=False, server_default="0"),
            sa.Column("mirror_total_bytes",     sa.BigInteger(), nullable=False, server_default="0"),
            sa.Column("mirror_row_count",       sa.BigInteger(), nullable=False, server_default="0"),
            sa.Column("status",                 sa.String(32),   nullable=False, server_default="building"),
            sa.Column("routing_enabled",        sa.Boolean(),    nullable=False, server_default=sa.text("0")),
            sa.Column("built_at",               sa.DateTime(),   nullable=True),
            sa.Column("last_route_at",          sa.DateTime(),   nullable=True),
            sa.Column("invalidated_at",         sa.DateTime(),   nullable=True),
            sa.Column("build_duration_seconds", sa.Float(),      nullable=True),
            sa.Column("dual_run_samples",       sa.Integer(),    nullable=False, server_default="0"),
            sa.Column("dual_run_divergences",   sa.Integer(),    nullable=False, server_default="0"),
            sa.Column("dual_run_last_at",       sa.DateTime(),   nullable=True),
            sa.Column("route_hit_count",        sa.BigInteger(), nullable=False, server_default="0"),
            sa.Column("last_error",             sa.String(1024), nullable=False, server_default=""),
            sa.Column("notes",                  sa.String(1024), nullable=False, server_default=""),
            sa.PrimaryKeyConstraint("id"),
        )
        op.create_index(
            "ix_iceberg_mirror_lookup_v1",
            "iceberg_mirror_v1",
            ["source_bucket", "source_prefix", "source_snapshot_id"],
            unique=True,
        )
        op.create_index(
            "ix_iceberg_mirror_status_v1",
            "iceberg_mirror_v1",
            ["status", "routing_enabled"],
            unique=False,
        )

    # ── iceberg_mirror_dual_run_v1 ────────────────────────────────────
    if not _table_exists("iceberg_mirror_dual_run_v1"):
        op.create_table(
            "iceberg_mirror_dual_run_v1",
            sa.Column("id",                sa.Integer(),    nullable=False),
            sa.Column("mirror_id",         sa.Integer(),    nullable=False),
            sa.Column("occurred_at",       sa.DateTime(),   nullable=True),
            sa.Column("diverged",          sa.Boolean(),    nullable=False, server_default=sa.text("0")),
            sa.Column("source_row_count",  sa.BigInteger(), nullable=False, server_default="0"),
            sa.Column("mirror_row_count",  sa.BigInteger(), nullable=False, server_default="0"),
            sa.Column("source_hash",       sa.String(64),   nullable=True),
            sa.Column("mirror_hash",       sa.String(64),   nullable=True),
            sa.Column("query_signature",   sa.String(255),  nullable=True),
            sa.Column("notes",             sa.String(512),  nullable=False, server_default=""),
            sa.PrimaryKeyConstraint("id"),
        )
        op.create_index(
            "ix_iceberg_mirror_dual_run_lookup_v1",
            "iceberg_mirror_dual_run_v1",
            ["mirror_id", "occurred_at"],
            unique=False,
        )


def downgrade() -> None:
    if _table_exists("iceberg_mirror_dual_run_v1"):
        try:
            op.drop_index("ix_iceberg_mirror_dual_run_lookup_v1",
                          table_name="iceberg_mirror_dual_run_v1")
        except Exception:
            pass
        op.drop_table("iceberg_mirror_dual_run_v1")
    if _table_exists("iceberg_mirror_v1"):
        try:
            op.drop_index("ix_iceberg_mirror_status_v1",
                          table_name="iceberg_mirror_v1")
        except Exception:
            pass
        try:
            op.drop_index("ix_iceberg_mirror_lookup_v1",
                          table_name="iceberg_mirror_v1")
        except Exception:
            pass
        op.drop_table("iceberg_mirror_v1")
