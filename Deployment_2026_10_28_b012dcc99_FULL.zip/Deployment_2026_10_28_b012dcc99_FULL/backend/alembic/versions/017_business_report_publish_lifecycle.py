"""2026-08-17 — Business-report PUBLISH lifecycle: version snapshots.

Creates ``business_report_versions`` (immutable publish-time snapshots of a
report's definition + parameters — see ``core/reports/versions.py``) and adds
``business_reports.lifecycle_status`` (draft | published | archived |
deprecated; NULL derives from ``is_published`` at read time, so existing rows
need NO backfill for the column).

BACKFILL (the part that keeps the lights on): every report that is
``is_published=True`` at upgrade time gets **version 1** snapshotted from its
CURRENT definition and marked current, so on deploy every consumer keeps
executing exactly the bytes they executed yesterday — no report goes dark.
``semantic_version`` is stored NULL (= unknown, disclosed): it cannot be
computed offline (it folds live dataset/parameter state via the app's
DatabaseManager).  The first real republish stamps it.

Additive + idempotent: reruns skip existing tables/columns/rows, and the
runtime auto-migrate (create_all + ``_MIGRATIONS`` in core/database.py) may
already have created both — this migration is the formal/CI parity + the ONE
place the backfill happens.  Installs that never run alembic stay SAFE too:
a published report with no version row executes the draft, byte-identical to
pre-lifecycle behaviour (``core.reports.versions.resolve_execution_report``
falls open to the draft).

ROLLBACK (downgrade): drops the versions table and the lifecycle_status
column.  ``business_reports`` rows are otherwise untouched — ``is_published``
was never rewritten, so after downgrade every report is exactly as visible
and executable as before the upgrade.  Version history is lost on downgrade
(it exists only in the dropped table); that is the stated cost.

Revision ID: 017_business_report_publish_lifecycle
Revises: 016_iceberg_file_stats_partition_values
Create Date: 2026-08-17
"""
import json
from datetime import datetime, timezone
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "017_business_report_publish_lifecycle"
down_revision: Union[str, None] = "016_iceberg_file_stats_partition_values"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _table_exists(name: str) -> bool:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    try:
        return name in insp.get_table_names()
    except Exception:
        return False


def _column_exists(table: str, col: str) -> bool:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    try:
        return any(c["name"] == col for c in insp.get_columns(table))
    except Exception:
        return False


# Must mirror core/reports/versions.DEFINITION_FIELDS — every field
# execution depends on.  Kept literal here (a migration must not import app
# code): if the list drifts, the app-side publish path simply snapshots more
# than this backfill did, which is safe (backfilled v1 = the live row at
# upgrade time, and missing keys fall back to the live row on apply).
_DEFINITION_FIELDS = (
    "name", "description",
    "dataset_id", "merged_dataset_id", "merge_config",
    "merged_dataset_column_ids", "column_ids", "filter_specs",
    "condition_ids", "order_by", "row_limit", "section_definitions",
    "running_calculations", "slicer_column_ids", "drill_hierarchy_id",
    "layout_config", "data_source_type", "federation_view_id",
    "published_view_id", "raw_saved_query_id", "raw_sql_saved_query_id",
    "raw_sql_file_id", "raw_sql_override", "raw_parameters_schema",
    "raw_connection_override_id",
    "secondary_connection_id", "combine_mode", "join_config",
    "refresh_on_open",
)

_PARAM_FIELDS = (
    "id", "report_id", "name", "label", "parameter_type", "lov_column_id",
    "depends_on_param_id", "cascade_filter_column_id", "default_value",
    "description", "is_required", "sort_order",
)


# The model's JSON columns — the ONLY fields _j may decode.  Scalar string
# columns (name, description, default_value, raw_sql_override, ...) must be
# passed through VERBATIM: a default_value of "123" or a description that
# happens to start with "[" is data, not JSON.
_JSON_FIELDS = frozenset((
    "merge_config", "merged_dataset_column_ids", "column_ids",
    "filter_specs", "condition_ids", "order_by", "section_definitions",
    "running_calculations", "slicer_column_ids", "layout_config",
    "raw_parameters_schema", "join_config",
))


def _j(field: str, v):
    """JSON columns reflect as TEXT on SQLite — decode those strings; every
    other field passes through untouched."""
    if field not in _JSON_FIELDS:
        return v
    if isinstance(v, (bytes, bytearray)):
        v = v.decode("utf-8", errors="replace")
    if isinstance(v, str):
        try:
            return json.loads(v)
        except Exception:
            return v
    return v


def _brv_table() -> sa.sql.TableClause:
    return sa.table(
        "business_report_versions",
        sa.column("report_id", sa.Integer),
        sa.column("version_no", sa.Integer),
        sa.column("definition", sa.JSON),
        sa.column("parameters", sa.JSON),
        sa.column("semantic_version", sa.String),
        sa.column("published_by", sa.String),
        sa.column("published_at", sa.DateTime),
        sa.column("notes", sa.Text),
        sa.column("is_current", sa.Boolean),
    )


def upgrade() -> None:
    bind = op.get_bind()

    # 1. The versions table (idempotent vs runtime create_all).
    if not _table_exists("business_report_versions"):
        op.create_table(
            "business_report_versions",
            sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
            sa.Column("report_id", sa.Integer, nullable=False),
            sa.Column("version_no", sa.Integer, nullable=False),
            sa.Column("definition", sa.JSON(), nullable=False),
            sa.Column("parameters", sa.JSON(), nullable=True),
            sa.Column("semantic_version", sa.String(64), nullable=True),
            sa.Column("published_by", sa.String(100), nullable=False),
            sa.Column("published_at", sa.DateTime(), nullable=True),
            sa.Column("notes", sa.Text(), nullable=True),
            sa.Column("is_current", sa.Boolean(), nullable=False,
                      server_default=sa.false()),
            sa.UniqueConstraint("report_id", "version_no",
                                name="uq_br_version_report_no"),
        )
        op.create_index("ix_business_report_versions_report_id",
                        "business_report_versions", ["report_id"])
        op.create_index("ix_br_version_current",
                        "business_report_versions",
                        ["report_id", "is_current"])

    # 2. The lifecycle column (idempotent vs runtime _MIGRATIONS sweep).
    #    Nullable, no default: NULL derives from is_published at read time.
    if _table_exists("business_reports") and not _column_exists(
            "business_reports", "lifecycle_status"):
        op.add_column("business_reports",
                      sa.Column("lifecycle_status", sa.String(20),
                                nullable=True))

    # 3. BACKFILL — v1 for every currently-published report, so nothing goes
    #    dark on deploy.  Skips reports that already have any version row
    #    (rerun-safe, and safe when the app published before alembic ran).
    if not _table_exists("business_reports"):
        return
    meta = sa.MetaData()
    br_t = sa.Table("business_reports", meta, autoload_with=bind)
    have = {
        int(r[0]) for r in bind.execute(sa.text(
            "SELECT DISTINCT report_id FROM business_report_versions"))
    }
    published = bind.execute(
        sa.select(br_t).where(br_t.c.is_published == sa.true())
    ).mappings().all()

    params_by_report: dict = {}
    if _table_exists("report_parameters"):
        rp_t = sa.Table("report_parameters", meta, autoload_with=bind)
        for p in bind.execute(sa.select(rp_t)).mappings().all():
            row = {k: p.get(k) for k in _PARAM_FIELDS if k in p.keys()}
            params_by_report.setdefault(int(p["report_id"]), []).append(row)

    now = datetime.now(timezone.utc)
    inserts = []
    for r in published:
        rid = int(r["id"])
        if rid in have:
            continue
        definition = {f: _j(f, r.get(f)) for f in _DEFINITION_FIELDS
                      if f in r.keys()}
        inserts.append({
            "report_id": rid,
            "version_no": 1,
            "definition": definition,
            "parameters": sorted(
                params_by_report.get(rid, []),
                key=lambda p: (p.get("sort_order") or 0,
                               str(p.get("name") or ""))),
            "semantic_version": None,   # unknowable offline — disclosed NULL
            "published_by": str(r.get("owner") or ""),
            "published_at": now,
            "notes": "backfill: snapshot of the live definition at "
                     "migration 017 (publish lifecycle rollout)",
            "is_current": True,
        })
    if inserts:
        op.bulk_insert(_brv_table(), inserts)


def downgrade() -> None:
    # Version history lives ONLY in this table — dropping it is the stated
    # downgrade cost.  business_reports rows are untouched beyond removing
    # the (NULL-derived) lifecycle column, so visibility and execution
    # return to exact pre-upgrade behaviour.
    if _table_exists("business_report_versions"):
        try:
            op.drop_index("ix_br_version_current",
                          table_name="business_report_versions")
        except Exception:
            pass
        try:
            op.drop_index("ix_business_report_versions_report_id",
                          table_name="business_report_versions")
        except Exception:
            pass
        op.drop_table("business_report_versions")
    if _table_exists("business_reports") and _column_exists(
            "business_reports", "lifecycle_status"):
        try:
            op.drop_column("business_reports", "lifecycle_status")
        except Exception:
            pass
