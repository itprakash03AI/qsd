"""Phase 131 — Feed Generation Controls.

Adds:
  - feed_configs.etl_id                       — generic ETL identifier (opt-in)
  - feed_configs.row_count_threshold_pct      — opt-in row-count tolerance %
  - feed_configs.row_count_action             — 'off' | 'warn' | 'fail'
  - feed_configs.integrity_check_enabled      — overrides system default per-feed
  - feed_row_count_baseline                   — rolling baseline per feed
  - etl_dependency_types                      — QS-side mirror of OTG_DEPENDENCY_TYPE
  - etl_dependency_mappings                   — links etl_id -> required dep type+id
  - etl_dependency_tracking                   — runtime arrival log per business_date

All operations idempotent (column-existence guards) so re-running this
migration on a partially-applied database is safe.

Revision ID: 003_phase131
Revises: 002_hotfix13
Create Date: 2026-05-16
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "003_phase131"
down_revision: Union[str, None] = "002_hotfix13"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _column_exists(table: str, column: str) -> bool:
    bind = op.get_bind()
    insp = sa.inspect(bind)
    try:
        cols = {c["name"] for c in insp.get_columns(table)}
    except Exception:
        return False
    return column in cols


def upgrade() -> None:
    # ── feed_configs: etl_id (generic dependency key) ────────────────────
    if not _column_exists("feed_configs", "etl_id"):
        op.add_column(
            "feed_configs",
            sa.Column("etl_id", sa.Integer, nullable=True, index=True),
        )

    # ── feed_configs: opt-in row-count threshold (131-B) ─────────────────
    if not _column_exists("feed_configs", "row_count_threshold_pct"):
        op.add_column(
            "feed_configs",
            sa.Column("row_count_threshold_pct", sa.Numeric(5, 2), nullable=True),
        )
    if not _column_exists("feed_configs", "row_count_action"):
        op.add_column(
            "feed_configs",
            sa.Column(
                "row_count_action",
                sa.String(20),
                nullable=False,
                server_default="off",
            ),
        )

    # ── feed_configs: per-feed integrity check override (131-C) ──────────
    # NULL = inherit system default; true/false explicit override.
    if not _column_exists("feed_configs", "integrity_check_enabled"):
        op.add_column(
            "feed_configs",
            sa.Column("integrity_check_enabled", sa.Boolean, nullable=True),
        )

    # ── feed_row_count_baseline ──────────────────────────────────────────
    op.create_table(
        "feed_row_count_baseline",
        sa.Column("feed_config_id", sa.Integer, primary_key=True),
        sa.Column("rolling_window_days", sa.Integer, nullable=False, server_default="7"),
        sa.Column("avg_rows", sa.BigInteger, nullable=False, server_default="0"),
        sa.Column("stdev_rows", sa.BigInteger, nullable=True),
        sa.Column("min_rows", sa.BigInteger, nullable=True),
        sa.Column("max_rows", sa.BigInteger, nullable=True),
        sa.Column("sample_count", sa.Integer, nullable=False, server_default="0"),
        sa.Column("last_updated_at", sa.DateTime, nullable=True),
        if_not_exists=True,
    )

    # ── etl_dependency_types ─────────────────────────────────────────────
    # Mirror of OTG_DEPENDENCY_TYPE — when OTG integrates, we cross-walk
    # by this row's name (KAFKA / ORACLE_TABLE / FILE / API).
    op.create_table(
        "etl_dependency_types",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column("dependency_type", sa.String(50), nullable=False, unique=True),
        sa.Column("description", sa.String(500), nullable=True),
        sa.Column("server", sa.String(300), nullable=True),
        sa.Column("param_value", sa.String(500), nullable=True),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime, nullable=True),
        sa.Column("updated_at", sa.DateTime, nullable=True),
        if_not_exists=True,
    )

    # ── etl_dependency_mappings ──────────────────────────────────────────
    # Links an etl_id to one required dependency.  An ETL with three Kafka
    # topics has three rows here.
    op.create_table(
        "etl_dependency_mappings",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column("etl_id", sa.Integer, nullable=False, index=True),
        sa.Column("dependency_type_id", sa.Integer, nullable=False, index=True),
        # dependency_key uniquely identifies the dependency instance
        # (e.g. the Kafka topic name, or the Oracle table.partition).
        sa.Column("dependency_key", sa.String(500), nullable=False),
        sa.Column("description", sa.String(500), nullable=True),
        sa.Column("is_active", sa.Boolean, nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime, nullable=True),
        sa.UniqueConstraint(
            "etl_id", "dependency_type_id", "dependency_key",
            name="ux_etl_dep_mapping",
        ),
        if_not_exists=True,
    )

    # ── etl_dependency_tracking ──────────────────────────────────────────
    # Runtime gate.  An external producer (Kafka consumer / OTG ETL)
    # writes a row with action='COMPLETE' when the dependency lands for
    # a given business_date.  QS reads this to decide RUN vs WAIT.
    op.create_table(
        "etl_dependency_tracking",
        sa.Column("id", sa.Integer, primary_key=True, autoincrement=True),
        sa.Column("dependency_type_id", sa.Integer, nullable=False, index=True),
        sa.Column("dependency_key", sa.String(500), nullable=False, index=True),
        sa.Column("business_date", sa.Date, nullable=False, index=True),
        sa.Column("action", sa.String(20), nullable=False),
        sa.Column("comments", sa.String(2000), nullable=True),
        sa.Column("created_at", sa.DateTime, nullable=True),
        sa.Column("updated_at", sa.DateTime, nullable=True),
        sa.UniqueConstraint(
            "dependency_type_id", "dependency_key", "business_date",
            name="ux_etl_dep_tracking",
        ),
        if_not_exists=True,
    )


def downgrade() -> None:
    op.drop_table("etl_dependency_tracking", if_exists=True)
    op.drop_table("etl_dependency_mappings", if_exists=True)
    op.drop_table("etl_dependency_types", if_exists=True)
    op.drop_table("feed_row_count_baseline", if_exists=True)

    if _column_exists("feed_configs", "integrity_check_enabled"):
        with op.batch_alter_table("feed_configs") as batch:
            batch.drop_column("integrity_check_enabled")
    if _column_exists("feed_configs", "row_count_action"):
        with op.batch_alter_table("feed_configs") as batch:
            batch.drop_column("row_count_action")
    if _column_exists("feed_configs", "row_count_threshold_pct"):
        with op.batch_alter_table("feed_configs") as batch:
            batch.drop_column("row_count_threshold_pct")
    if _column_exists("feed_configs", "etl_id"):
        with op.batch_alter_table("feed_configs") as batch:
            batch.drop_column("etl_id")
