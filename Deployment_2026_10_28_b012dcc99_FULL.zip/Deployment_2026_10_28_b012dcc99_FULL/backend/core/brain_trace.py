"""Brain trace — per-query reasoning log for the iceberg / DuckDB
hot path.

Why this exists
---------------
The brain has many decision points: which cache layer hit, was the
trust window engaged, did the watcher just invalidate, did VPC
presign fire vs predownload, how many files survived pruning, etc.
Operators previously saw only "query took 8s" — opaque.

This module accumulates a structured trace of brain decisions for
each query and surfaces it via the execution metadata
(`query_executions.files_metadata.brain_trace`).  Frontend / admin
endpoints can render "why was this query slow" by reading the trace
instead of grepping pod logs.

Design properties
-----------------
- **ContextVar-scoped**: one async execution = one trace.  The trace
  set in the orchestrator's coroutine context propagates ACROSS
  ``asyncio.to_thread`` calls into the sync DuckDB / reader code,
  back into the coroutine for collection.  ContextVar is the right
  primitive for this — threading.local would be lost on each
  to_thread boundary.
- **Non-raising**: never crashes a query.  Trace failures are
  swallowed silently — observability infra must not fail the
  thing it observes.
- **No-op when not started**: if ``begin()`` wasn't called for the
  current async context, every ``trace()`` call returns instantly.
  Lets us instrument code paths that run BOTH inside a query
  (where trace is active) and outside (admin sync, background
  tasks) without conditionals at every site.
- **Bounded**: each trace caps at 200 entries to prevent a runaway
  loop from filling the execution metadata blob.
"""
from __future__ import annotations

import logging
import time
from contextvars import ContextVar
from typing import Any, Dict, List, Optional


logger = logging.getLogger(__name__)


# ContextVar so the trace propagates across asyncio.to_thread.
# Default ``None`` = trace inactive; ``begin()`` creates a fresh list
# in the current context.
_TRACE_VAR: ContextVar[Optional[List[Dict[str, Any]]]] = ContextVar(
    "brain_trace", default=None,
)
_T0_VAR: ContextVar[Optional[float]] = ContextVar(
    "brain_trace_t0", default=None,
)
_MAX_ENTRIES = 200


def begin() -> None:
    """Start a trace for the current async context.  Call ONCE per
    query at the orchestrator boundary (execute_api before SQL
    setup).  Safe to call multiple times — the second call discards
    the prior trace and resets the clock."""
    _TRACE_VAR.set([])
    _T0_VAR.set(time.monotonic())


def is_active() -> bool:
    return _TRACE_VAR.get() is not None


def trace(stage: str, decision: str, **metrics: Any) -> None:
    """Record one brain decision.

    Args:
        stage:    Coarse bucket — ``"cache_check"``, ``"snapshot"``,
                  ``"vpc_route"``, ``"pruning"``, ``"predown"``,
                  ``"watcher_tick"``, ``"freshness"``.
        decision: Short string — ``"trusted"``, ``"verified_match"``,
                  ``"pointer_advanced"``, ``"presigned"``, ``"native"``,
                  ``"pre_download"``, ``"verify_failed"``, etc.
        metrics:  Free-form structured data — file_count, cache_id,
                  table_name, age_seconds, etc.  Each value is
                  rendered as-is into the JSON metadata, so prefer
                  primitives (str/int/float/bool).

    No-op when ``begin()`` wasn't called.
    """
    current = _TRACE_VAR.get()
    if current is None:
        return
    try:
        if len(current) >= _MAX_ENTRIES:
            # 2026-06-25 bug fix (brain deep dive): the cap was a
            # silent drop -- operators saw 200 entries and assumed
            # that was the entire trace.  Add ONE marker entry the
            # first time we hit the cap so the operator knows the
            # tail is missing.  The marker itself is suppressed from
            # the cap test below to prevent recursive bloat.
            if not current or current[-1].get("stage") != "_truncated":
                current.append({
                    "stage":        "_truncated",
                    "decision":     "max_entries_reached",
                    "t_ms":         int((time.monotonic() -
                                          (_T0_VAR.get() or time.monotonic())) * 1000),
                    "dropped_after": _MAX_ENTRIES,
                    "note": (
                        f"brain_trace stopped recording after "
                        f"{_MAX_ENTRIES} entries.  Subsequent decisions "
                        f"during this query were NOT captured.  Raise "
                        f"_MAX_ENTRIES if you need a deeper trace."
                    ),
                })
            return
        t0 = _T0_VAR.get() or time.monotonic()
        entry: Dict[str, Any] = {
            "stage":    stage,
            "decision": decision,
            "t_ms":     int((time.monotonic() - t0) * 1000),
        }
        if metrics:
            entry.update(metrics)
        current.append(entry)
    except Exception as exc:
        logger.debug("brain_trace.trace non-fatal: %s", exc)


def collect() -> List[Dict[str, Any]]:
    """Return the current trace WITHOUT clearing it.  Useful for
    progress reporting mid-query."""
    current = _TRACE_VAR.get()
    return list(current) if current is not None else []


def end() -> List[Dict[str, Any]]:
    """Finish the trace, return its entries, and reset state.

    Call at execute_api's query-completion boundary; pass the result
    into ``query_executions.files_metadata['brain_trace']``."""
    current = _TRACE_VAR.get()
    entries = list(current) if current is not None else []
    _TRACE_VAR.set(None)
    _T0_VAR.set(None)
    return entries


def summary(entries: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """One-paragraph diagnostic summary suitable for the admin chip
    or the execution-detail view.  Aggregates the trace into:

      - stage counts (how many cache_check / vpc_route / etc.)
      - cache-hit ratio
      - any snapshot advances (a cache invalidation event)
      - VPC routing decisions
      - total brain time-in-decisions (sum of t_ms of all entries)

    Pass ``entries`` explicitly when you've already called ``end()``;
    omit to summarise the live trace."""
    if entries is None:
        entries = collect()
    stage_counts: Dict[str, int] = {}
    cache_hits = 0
    cache_misses = 0
    snapshot_advances = 0
    vpc_routes: Dict[str, int] = {}
    for e in entries:
        stage = e.get("stage") or "?"
        stage_counts[stage] = stage_counts.get(stage, 0) + 1
        if stage == "cache_check":
            dec = e.get("decision")
            if dec in ("trusted", "verified_match", "trusted_cross_pod"):
                cache_hits += 1
            elif dec in ("verify_failed", "pointer_advanced",
                         "live_resolve", "fresh_resolve"):
                cache_misses += 1
        elif stage == "snapshot" and e.get("decision") == "advanced":
            snapshot_advances += 1
        elif stage == "vpc_route":
            d = e.get("decision") or "?"
            vpc_routes[d] = vpc_routes.get(d, 0) + 1
    total_cache = cache_hits + cache_misses
    hit_ratio = (cache_hits / total_cache) if total_cache else None
    return {
        "entries":             len(entries),
        "stage_counts":        stage_counts,
        "cache_hits":          cache_hits,
        "cache_misses":        cache_misses,
        "cache_hit_ratio":     hit_ratio,
        "snapshot_advances":   snapshot_advances,
        "vpc_routes":          vpc_routes,
    }


def reset_for_tests() -> None:
    """Clear ContextVar state.  For test isolation only."""
    _TRACE_VAR.set(None)
    _T0_VAR.set(None)
