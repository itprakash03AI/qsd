"""Plan-shape probe + measured decode ratio — the two numbers spill
admission was missing.

WHY THIS MODULE EXISTS
----------------------
``core.spill_admission`` (stage 1, parent-side) compares a projected working
set against the memory+spill budget, but it had to GUESS two inputs:

  1. ``has_blocking_operator`` — it defaulted to True, so every query was
     treated as if it materialises its input.  A scan→filter→project→write
     pipeline is O(1) in memory REGARDLESS of result size; refusing one is
     the unforgivable direction.
  2. ``expansion_factor`` — a configured 8.0, documented as a guess.

Both are measurable in the CHILD, where a live DuckDB connection exists:

  * the physical plan (``EXPLAIN (FORMAT JSON)`` — planning only, no data
    read) names every operator, so "streaming-shaped" is a fact, not a
    regex over SQL text;
  * the parquet footer carries ``total_uncompressed_size`` per column
    chunk, so the decode ratio is one metadata read on ONE island file,
    not a guess.

MEASURED (2026-08-04, DuckDB 1.5.2) — the facts this module encodes:

  * Our own SQL wraps add NO operator to the physical plan.  The RLS wrap
    (``SELECT * FROM (q) __rls_wrap WHERE …``), the reports auto-filter
    (``FROM (q) _auto_filtered WHERE …``) and ``union_by_name=true`` all
    flatten to the bare scan: ``['SEQ_SCAN']`` — the optimizer unnests the
    derived table.  The ONE wrap that ever broke this was the MoR
    pos-delete anti-join building its hash on the BIG side (fixed
    2026-08-04 in ``iceberg_mor.build_mor_view_sql``).  The probe exists
    so the NEXT wrap that regresses this is caught by a logged plan, not
    a 40 GB spill.
  * 900 cols × 120k rows (736 MB parquet, ~1.9 GB decoded), streaming
    COPY at the width-floor ``memory_limit=1260MB``: completes, spill
    high-water 0.0 MB.  The same data with ``ORDER BY``: OOM at
    1.1 GiB/1.1 GiB even with a 6 GB spill quota (unspillable per-column
    sort buffers — the ×2 ORDER BY width floor is real).
  * ``preserve_insertion_order`` is visible in the plan: ``true`` plans
    ``BATCH_COPY_TO_FILE`` (order-preserving batch buffer), ``false``
    plans ``COPY_TO_FILE`` (streaming writer).  Seeing
    ``BATCH_COPY_TO_FILE`` therefore means the child's
    ``SET preserve_insertion_order=false`` did NOT apply — it is
    classified blocking so that regression is loud.
  * Footer decode ratio on mixed 900-col data: 2.55× (uncompressed/
    compressed).  True in-memory Arrow size ran ~1.26× above the footer
    figure (validity/offset overhead), so callers should keep headroom —
    but 2.55×headroom is still far below the guessed 8.0, i.e. the
    measured number UNDER-refuses relative to today, never over.

CLASSIFICATION CONTRACT
-----------------------
``streaming`` is claimed ONLY when every operator in the physical plan is
in the known-streaming set.  An operator this module has never seen makes
the plan NOT streaming (conservative: no bounded-memory guarantee is
claimed for it) but is recorded in ``detail`` so the set can be extended
deliberately.  Failure of the probe itself returns ``known=False`` — "we
could not look" is never collapsed into either answer.

DESIGNED, NOT BUILT (recorded here so it is not re-derived):
  * HASH_JOIN memory is O(build side), not O(input).  The MoR anti-join
    with its (now) small MATERIALIZED delete-side CTE is effectively
    streaming for the probe side, but this module still classifies it
    blocking.  The refinement — walking ``extra_info["Estimated
    Cardinality"]`` of the build-side subtree and treating a small build
    as non-blocking — is designed but deliberately not shipped: an
    optimizer cardinality UNDER-estimate would flip a genuinely blocking
    plan to "streaming" and waive its admission check, which is the
    data-loss-shaped direction.  Extend only with a measured guard.
  * Chunked completion for genuinely-too-big BLOCKING plans — BUILT
    2026-08-04: ``core.blocking_completion_route`` (chunked sorted /
    partial runs) + ``core.sorted_run_merge`` (the k-way streaming
    merge lane).  Admission now ROUTES an enforce-mode refusal through
    it when ``spill_admission.completion_route`` is enabled; refusal
    remains the fallback when no route applies.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from typing import List, Optional, Tuple

logger = logging.getLogger(__name__)

LOG_TAG = "[plan-shape]"

# Operators whose memory is O(1)-ish in their input size (pipeline
# operators, bounded buffers).  Names as DuckDB 1.5.x prints them in
# EXPLAIN (FORMAT JSON) "name" fields (upper snake).
STREAMING_OPS = frozenset({
    # sources
    "SEQ_SCAN", "READ_PARQUET", "PARQUET_SCAN", "TABLE_SCAN",
    "COLUMN_DATA_SCAN", "DELIM_SCAN", "CTE_SCAN", "READ_CSV", "READ_CSV_AUTO",
    "EMPTY_RESULT", "DUMMY_SCAN", "EXPRESSION_SCAN",
    # pure pipeline
    "PROJECTION", "FILTER", "UNION", "STREAMING_LIMIT", "LIMIT",
    "STREAMING_WINDOW", "SAMPLE",
    # bounded accumulators: O(k) or O(#aggregates), not O(rows)
    "TOP_N", "UNGROUPED_AGGREGATE",
    # writers — COPY_TO_FILE is the streaming writer DuckDB plans when
    # preserve_insertion_order=false (measured; see module docstring).
    "COPY_TO_FILE",
    # utility
    "RESULT_COLLECTOR", "EXPLAIN", "VERIFY",
})

# Operators that materialise their (or their build-side's) input before
# emitting.  These are the spill producers.
BLOCKING_OPS = frozenset({
    "ORDER_BY", "HASH_GROUP_BY", "PERFECT_HASH_GROUP_BY", "WINDOW",
    "HASH_JOIN", "PIECEWISE_MERGE_JOIN", "NESTED_LOOP_JOIN", "IE_JOIN",
    "ASOF_JOIN", "BLOCKWISE_NL_JOIN", "CROSS_PRODUCT", "POSITIONAL_JOIN",
    "LEFT_DELIM_JOIN", "RIGHT_DELIM_JOIN", "DELIM_JOIN", "CTE",
    "RECURSIVE_CTE", "MATERIALIZED_CTE", "INSERT", "CREATE_TABLE_AS",
    # BATCH_COPY_TO_FILE = preserve_insertion_order=true writer: an
    # order-preserving batch buffer.  Its presence means our
    # `SET preserve_insertion_order=false` did not apply — treat as
    # blocking so that regression is visible, not silent.
    "BATCH_COPY_TO_FILE",
})


@dataclass(frozen=True)
class PlanShape:
    """What the physical plan says about memory behaviour.

    ``known=False`` means the probe could not run/parse — no claim either
    way.  ``streaming`` is meaningful only when ``known`` is True.
    """
    known: bool
    streaming: bool = False
    operators: Tuple[str, ...] = ()
    blocking: Tuple[str, ...] = ()
    unknown_ops: Tuple[str, ...] = ()
    detail: str = ""

    def describe(self) -> str:
        if not self.known:
            return f"plan shape UNKNOWN ({self.detail})"
        if self.streaming:
            return ("plan shape STREAMING (scan->filter->project->write; "
                    "bounded memory regardless of result size)")
        parts = []
        if self.blocking:
            parts.append("blocking=" + ",".join(self.blocking))
        if self.unknown_ops:
            parts.append("unclassified=" + ",".join(self.unknown_ops))
        return "plan shape BLOCKING (" + "; ".join(parts) + ")"


def classify_operators(names: List[str]) -> PlanShape:
    """Pure classification of a physical-operator list.

    Split from the probe so the conservative-on-unknown rule is testable
    without a connection.  An operator in NEITHER set forfeits the
    streaming claim (no guarantee for code we have never measured) but is
    reported separately from known-blocking ones.
    """
    ops = tuple(str(n or "").strip().upper() for n in names if n)
    blocking = tuple(n for n in ops if n in BLOCKING_OPS)
    unknown = tuple(n for n in ops
                    if n not in BLOCKING_OPS and n not in STREAMING_OPS)
    streaming = not blocking and not unknown and bool(ops)
    detail = ""
    if unknown:
        detail = ("unclassified operator(s) forfeit the streaming claim: "
                  + ",".join(sorted(set(unknown))))
    return PlanShape(known=True, streaming=streaming, operators=ops,
                     blocking=blocking, unknown_ops=unknown, detail=detail)


def _walk_names(node, acc: List[str]) -> None:
    if not isinstance(node, dict):
        return
    name = node.get("name")
    if name:
        acc.append(str(name))
    for child in node.get("children", []) or []:
        _walk_names(child, acc)


def probe_plan_shape(con, sql: str) -> PlanShape:
    """EXPLAIN ``sql`` on a live connection and classify the physical plan.

    Planning only — DuckDB binds and optimizes but reads no row data.
    NEVER raises; a failed probe returns ``known=False`` (no claim).
    Works on full ``COPY (…) TO …`` statements as well as bare SELECTs
    (measured: EXPLAIN of a COPY yields the writer operator too, which is
    exactly what we want to see).
    """
    if not sql or not str(sql).strip():
        return PlanShape(known=False, detail="empty SQL")
    try:
        rows = con.execute(f"EXPLAIN (FORMAT JSON) {sql}").fetchall()
        plan_txt = None
        for key, val in rows:
            if "physical" in str(key).lower():
                plan_txt = val
                break
        if plan_txt is None and rows:
            plan_txt = rows[-1][1]
        if not plan_txt:
            return PlanShape(known=False, detail="EXPLAIN returned no plan")
        data = json.loads(plan_txt)
        acc: List[str] = []
        for node in (data if isinstance(data, list) else [data]):
            _walk_names(node, acc)
        if not acc:
            return PlanShape(known=False, detail="no operators in plan JSON")
        return classify_operators(acc)
    except Exception as exc:
        # A diagnostic must never break the query it is diagnosing.
        logger.debug("%s probe failed (no claim): %s", LOG_TAG, exc)
        return PlanShape(known=False,
                         detail=f"{type(exc).__name__}: {exc}")


# ── Measured decode ratio ────────────────────────────────────────────────

# Quoted SQL string whose content mentions ".parquet" — matches local
# paths, s3:// URIs and presigned https URLs (where ".parquet" sits before
# the query string).  '' is SQL's escaped quote.
_PARQUET_REF_RE = re.compile(r"'((?:[^']|'')*?\.parquet(?:[^']|'')*?)'",
                             re.IGNORECASE)

# The footer figure excludes Arrow validity/offset overhead — measured
# ~1.26x above footer on mixed-type data — so the measured ratio carries
# headroom before it replaces the configured guess.
MEASURED_EXPANSION_HEADROOM = 1.5
_RATIO_MIN, _RATIO_MAX = 1.0, 64.0


def sample_parquet_ref(*sql_texts: str) -> str:
    """First parquet file reference found in the given SQL texts.

    Returns the un-escaped path/URL, or ``""`` when none is present.  One
    file is enough: the island's files come from the same table + writer,
    so their encodings are homogeneous — and this is a HINT feeding an
    admission verdict, where one real footer beats zero.
    """
    for txt in sql_texts:
        if not txt:
            continue
        m = _PARQUET_REF_RE.search(txt)
        if m:
            return m.group(1).replace("''", "'")
    return ""


def measured_expansion_factor(con, parquet_ref: str
                              ) -> Optional[Tuple[float, float]]:
    """Decode ratio of ONE parquet file from its footer, or ``None``.

    Returns ``(factor_with_headroom, raw_footer_ratio)`` where the footer
    ratio is ``sum(total_uncompressed_size) / sum(total_compressed_size)``
    over all column chunks — one metadata read (footer only), no row data.
    Clamped to [1, 64].  NEVER raises.
    """
    if not parquet_ref:
        return None
    try:
        safe = parquet_ref.replace("'", "''")
        row = con.execute(
            "SELECT sum(total_compressed_size), "
            "sum(total_uncompressed_size) "
            f"FROM parquet_metadata('{safe}')").fetchone()
        if not row or not row[0] or not row[1]:
            return None
        comp, uncomp = float(row[0]), float(row[1])
        if comp <= 0 or uncomp <= 0:
            return None
        raw = uncomp / comp
        factor = max(_RATIO_MIN,
                     min(_RATIO_MAX, raw * MEASURED_EXPANSION_HEADROOM))
        return factor, raw
    except Exception as exc:
        logger.debug("%s footer ratio unavailable for %r: %s",
                     LOG_TAG, parquet_ref[:120], exc)
        return None
