"""
Error detection utilities — S3 auth errors, connection errors, JSON-safe value conversion.

Extracted from main.py to keep the main module focused on app wiring.
"""
from __future__ import annotations

import decimal
import logging
import re
from datetime import date as _date_type, datetime

from fastapi import HTTPException

logger = logging.getLogger(__name__)


# ── JSON-safe value conversion ───────────────────────────────────────────────

def jsonify_value(v):
    """Convert a single value to a JSON-safe type."""
    if v is None:
        return None
    if isinstance(v, (datetime, _date_type)):
        return v.isoformat()
    if isinstance(v, (bytes, bytearray)):
        return v.hex()
    if isinstance(v, decimal.Decimal):
        return float(v)
    if isinstance(v, (list, tuple)):
        return [jsonify_value(x) for x in v]
    return v


def jsonify_rows(rows: list):
    """In-place convert non-JSON-safe values in a list of dicts."""
    for row in rows:
        for k, v in row.items():
            row[k] = jsonify_value(v)


# ── S3 auth error detection ─────────────────────────────────────────────────

S3_EXPIRED_PATTERNS = (
    'expiredtoken', 'expired token', 'requestexpired', 'token has expired',
    'security token included in the request is expired',
    'the provided token has expired',
)


def is_s3_auth_error(exc: Exception) -> bool:
    """Detect expired / invalid AWS credentials from DuckDB httpfs or boto3 errors."""
    from core.s3_storage import TokenExpiredError
    if isinstance(exc, TokenExpiredError):
        return True
    msg = str(exc).lower()
    return any(p in msg for p in S3_EXPIRED_PATTERNS)


def raise_if_s3_auth_error(exc: Exception):
    """Raise HTTP 401 with TOKEN_EXPIRED code if the exception is an AWS credential issue."""
    if is_s3_auth_error(exc):
        raise HTTPException(
            status_code=401,
            detail={
                "message": "Your AWS session credentials have expired. Please update your connection with fresh credentials.",
                "error_code": "TOKEN_EXPIRED",
            },
        )


# ── Broad connection error detection (stale-result fallback) ────────────────

CONN_ERROR_PATTERNS = (
    # AWS / S3 auth
    'expiredtoken', 'expired token', 'requestexpired', 'token has expired',
    'security token included in the request is expired',
    'the provided token has expired', 'invalidclienttokenid',
    'accessdenied', 'access denied', 'nosuchbucket', 'invalidaccesskeyid',
    # General network
    'connection refused', 'connection timed out', 'connection reset',
    'network unreachable', 'name resolution failed', 'could not connect',
    'failed to connect', 'socket timeout', 'ssl: certificate_verify_failed',
    'no route to host', 'broken pipe',
    # HTTP auth (specific status codes only — avoid matching 404 not-found)
    'http 401', 'http 403', 'status code: 401', 'status code: 403',
    '401 unauthorized', '403 forbidden',
    # Snowflake / Databricks / Trino
    'authentication failed', 'jwt token is invalid or expired',
    'token is expired', 'login failed', 'incorrect username or password',
    # DuckDB httpfs
    'failed to download', 'could not open remote file',
    'curl error', 'could not resolve host',
)


def is_connection_error(exc: Exception) -> bool:
    """True if the exception indicates a network or auth failure (not a query/data error).
    Used to decide whether a stale cached result can be served as a fallback.
    """
    from core.s3_storage import TokenExpiredError
    if isinstance(exc, TokenExpiredError):
        return True
    msg = str(exc).lower()
    return any(p in msg for p in CONN_ERROR_PATTERNS)


# ── DuckDB query error classification ─────────────────────────────────────

def classify_duckdb_error(exc: Exception, *, sql: str | None = None,
                          connection_id: int | None = None,
                          connection: dict | None = None) -> str:
    """Return a user-friendly error message for common DuckDB query errors.

    Translates raw DuckDB exceptions into actionable guidance.
    Returns the original error string if no classification matches.
    All output is sanitized to strip proxy credentials.

    ``sql`` / ``connection_id`` / ``connection`` (2026-10-07, F9) let an
    unknown column name its table and an unknown table list the
    connection's registered tables -- see ``unknown_column_message`` and
    ``unknown_table_message``.  Callers that have none pass nothing and the
    wording says what could not be determined.
    """
    from core.proxy_utils import sanitize_proxy_error
    msg = sanitize_proxy_error(str(exc))
    msg_lower = msg.lower()

    # Binder Error: an unknown column -- lead with the column and DuckDB's
    # own candidates (F9).  The SAME sentence the pre-validation 400 gives.
    unknown_column = unknown_column_message(msg, sql=sql)
    if unknown_column:
        return unknown_column

    # Binder Error: column not found — most common on on-prem S3
    if 'binder error' in msg_lower and 'not found' in msg_lower:
        # Extract the column name from the error for context
        import re
        col_match = re.search(r'column\s+"?([^"]+)"?\s+not found', msg, re.IGNORECASE)
        col_name = col_match.group(1) if col_match else '(unknown)'
        return (
            f"Column '{col_name}' not found in the query result. "
            f"This can happen when: (1) the column was removed or renamed in the data source, "
            f"(2) a hive partition column (like year, month) is not detected from pre-signed URLs "
            f"on on-prem S3 — check backend logs for URL encoding details, "
            f"(3) the EXCLUDE clause references a stale column. "
            f"Try re-selecting the table or removing the missing column from your query."
        )

    # Catalog Error: a table the query names is not there (F9).  This used
    # to tell a business user to "check backend logs"; it now names the
    # table and lists what the connection DOES have.  Any other catalog
    # error (an unknown function, say) is no longer called a missing table.
    if is_unknown_table_error(msg):
        return unknown_table_message(
            msg, connection_id=connection_id, connection=connection)

    # Path-resolution failures (__local__: / __registered__: / __materialized__:)
    resolved = _classify_missing_files(msg, msg_lower)
    if resolved:
        return resolved

    # S3 credential expiry and object-not-found families
    s3_fault = _classify_s3_access_failure(msg_lower)
    if s3_fault:
        return s3_fault

    # IO Error: general file access issues
    if 'io error' in msg_lower or 'httpfs' in msg_lower:
        return (
            f"Failed to read data from S3. This may be a network, SSL, or credential issue. "
            f"For on-prem S3: verify endpoint URL, SSL settings, and path_style configuration. "
            f"Original error: {msg}"
        )

    # On-prem S3 registration/listing failure (no glob fallback) — already user-friendly
    if 'on-prem s3' in msg_lower and ('failed to' in msg_lower or 'no parquet files' in msg_lower):
        return msg

    # Signature mismatch (common on on-prem S3)
    if 'signaturedoesnotmatch' in msg_lower or 'signature' in msg_lower and 'match' in msg_lower:
        return (
            f"S3 signature mismatch. For on-prem S3 (MinIO/NetApp/Ceph), ensure 'path_style' is "
            f"enabled in the connection config. Check that the endpoint URL uses the correct protocol "
            f"(https:// or http://). Original error: {msg}"
        )

    # Default: return original with DuckDB prefix stripped
    cleaned = msg
    for prefix in ('RuntimeError: DuckDB query error: ', 'DuckDB query error: '):
        if cleaned.startswith(prefix):
            cleaned = cleaned[len(prefix):]
    return cleaned



def _classify_missing_files(msg: str, msg_lower: str) -> str | None:
    """Explain a DuckDB "no files found" error, or None if it is not one.

    The three pseudo-schemes each mean a different broken link, so each
    gets its own remedy rather than one generic "file missing".
    """
    # IO Error: no files found (often __local__: or __registered__: path not resolved)
    if 'no files found that match the pattern' in msg_lower:
        import re as _re
        path_match = _re.search(r'pattern\s+"([^"]+)"', msg, _re.IGNORECASE)
        bad_path = path_match.group(1) if path_match else ''
        if '__local__:' in bad_path:
            tname = bad_path.split('__local__:')[-1]
            return (
                f"Local table '{tname}' could not be resolved. "
                f"The table may have been deleted or its uploaded data is missing. "
                f"Try re-uploading the table or removing it from your query."
            )
        if '__registered__:' in bad_path:
            tname = bad_path.split('__registered__:')[-1]
            return (
                f"Registered table '{tname}' could not be resolved. "
                f"The S3 view registration may have failed — check that the "
                f"S3 connection is active and the table prefix is correct."
            )
        if '__materialized__:' in bad_path:
            tname = bad_path.split('__materialized__:')[-1]
            return (
                f"Materialized view '{tname}' could not be resolved. "
                f"The view may not be ready yet or its data files are missing. "
                f"Check the materialized views admin page for status."
            )
        return (
            f"No data files found at the specified path. "
            f"Verify the file exists and the path is correct. "
            f"If using S3, check that the connection is active and the bucket/prefix are valid. "
            f"Original error: {msg}"
        )
    return None


def _classify_s3_access_failure(msg_lower: str) -> str | None:
    """Explain an expired-token / 404 / access-denied S3 error, or None.

    Checked in this order because a stale-metadata 404 and a plain
    NoSuchKey need different remedies and the messages overlap.
    """
    # BF-49: ExpiredToken / InvalidToken — clear user-facing message
    if 'expiredtoken' in msg_lower or 'token has expired' in msg_lower or 'expired token' in msg_lower:
        return (
            "Your AWS session token has expired. "
            "Please refresh your credentials in the Connection Manager "
            "(edit the connection → update the session token or re-authenticate). "
            "If using assume_role auth mode, the token will auto-refresh on next query."
        )

    # BF-413: HeadObject 404 / NoSuchKey — file referenced by table doesn't
    # exist in S3 anymore.  Common causes: stale Iceberg metadata cache
    # (snapshot drift), manual file deletion, manifest pointing to
    # compacted/expired files.  Provide actionable guidance.
    if (('headobject' in msg_lower or 'getobject' in msg_lower or 'head_object' in msg_lower)
        and ('404' in msg_lower or 'not found' in msg_lower or 'nosuchkey' in msg_lower)):
        return (
            "A file referenced by your registered table doesn't exist in S3 "
            "anymore (HeadObject 404). Most common causes: "
            "(1) Iceberg metadata cache is stale — go to "
            "Admin → Iceberg Metadata Sync and click 'Refresh' for this table, "
            "(2) the file was manually deleted or compacted away in S3, "
            "(3) the registered table prefix was changed.  "
            "Retry the query after refreshing the metadata cache."
        )
    if 'nosuchkey' in msg_lower or ('404' in msg_lower and ('s3://' in msg_lower or 'amazonaws' in msg_lower or 'bucket' in msg_lower)):
        return (
            "An S3 object referenced by your query was not found (404). "
            "The file may have been deleted, or the Iceberg metadata cache may be stale. "
            "Refresh the metadata via Admin → Iceberg Metadata Sync and retry."
        )

    # AccessDenied — might be expired creds or missing permissions
    if 'accessdenied' in msg_lower or 'access denied' in msg_lower or 'invalidaccesskeyid' in msg_lower:
        return (
            "AWS access denied. Your credentials may have expired or lack the required permissions. "
            "Check the connection's access key, secret key, and session token in Connection Manager. "
            "For IAM role auth, verify the role has S3 read permissions on the target bucket."
        )
    return None


# ── Unknown table / unknown column: the words a business user reads ─────────
#
# 2026-10-07 (F9, live BQB audit as a non-admin on an S3 connection).  An
# unknown table read "The S3 view registration may have failed silently --
# check backend logs for 'Could not register' warnings", and an unknown
# column was DuckDB's raw binder text with OUR pre-validation prefix echoed
# back ("LINE 1: EXPLAIN select ...").  A business user can read neither the
# logs nor our internals.  These functions are the ONE wording for both
# errors: the pre-validation 400 (``api.execute_api._pre_validate_raw_sql``)
# and the background ``execution_failed`` road (``classify_duckdb_error``)
# both call them.  The engine's own text is kept, second, after
# "Engine said:".

_ENGINE_PREFIXES = ('RuntimeError: DuckDB query error: ', 'DuckDB query error: ')

#: How many registered table names an unknown-table message lists.
REGISTERED_TABLES_LISTED = 20

_REFERENCED_COLUMN = re.compile(
    r'Referenced column\s+"(?P<col>[^"]+)"\s+not found in FROM clause', re.IGNORECASE)
_TABLE_HAS_NO_COLUMN = re.compile(
    r'Table\s+"(?P<tbl>[^"]+)"\s+does not have a column named\s+"(?P<col>[^"]+)"',
    re.IGNORECASE)
_CANDIDATE_BINDINGS = re.compile(r'Candidate bindings:[ \t:]*(?P<list>[^\n]*)', re.IGNORECASE)
_UNKNOWN_TABLE = re.compile(
    r'Catalog Error:\s*(?:Table|View)\s+(?!Function)(?:with name\s+)?'
    r'(?P<name>"[^"]+"|\'[^\']+\'|.+?)\s+does not exist',
    re.IGNORECASE)
_UNKNOWN_TABLE_SHAPE = re.compile(
    r'Catalog Error:\s*(?:Table|View)\b(?!\s+Function)[^\n]*does not exist', re.IGNORECASE)
_INTERNAL_EXPLAIN = 'EXPLAIN '


def _engine_text(msg: str) -> str:
    """The engine's message minus our own wrapper prefixes."""
    cleaned = (msg or '').strip()
    for prefix in _ENGINE_PREFIXES:
        if cleaned.startswith(prefix):
            cleaned = cleaned[len(prefix):]
    return cleaned


def strip_internal_explain(msg: str) -> str:
    """Remove the ``EXPLAIN `` OUR pre-validation put in front of the user's SQL.

    DuckDB echoes the statement it was given ("LINE 1: EXPLAIN select ...")
    with a caret under the failing token.  The user never typed EXPLAIN, so
    it is removed from the echo and the caret line moves left by the same
    width so it still points at the token.  Only line 1 can carry it.
    """
    if not msg or _INTERNAL_EXPLAIN not in msg:
        return msg
    lines = msg.split('\n')
    marker = 'LINE 1: ' + _INTERNAL_EXPLAIN
    for i, line in enumerate(lines):
        if line.startswith(marker):
            lines[i] = 'LINE 1: ' + line[len(marker):]
            nxt = i + 1
            if nxt < len(lines) and lines[nxt].strip() == '^':
                caret = lines[nxt]
                pad = len(caret) - len(caret.lstrip(' '))
                lines[nxt] = caret[min(pad, len(_INTERNAL_EXPLAIN)):]
            break
    return '\n'.join(lines)


def _single_table_of(sql: str | None) -> str | None:
    """The one table ``sql`` reads, or None (none, several, or unparseable)."""
    if not sql or not sql.strip():
        return None
    try:
        import sqlglot
        from sqlglot import exp
        tree = sqlglot.parse_one(sql, read='duckdb')
        ctes = {c.alias_or_name.lower() for c in tree.find_all(exp.CTE)}
        names = {t.name for t in tree.find_all(exp.Table)
                 if t.name and t.name.lower() not in ctes}
    except Exception:
        return None
    return next(iter(names)) if len(names) == 1 else None


def unknown_column_message(msg: str, *, sql: str | None = None) -> str | None:
    """``Column 'x' is not in <table>. Did you mean: ...?`` -- or None.

    None when ``msg`` is not DuckDB's unknown-column binder error.  The
    candidates are the ones DuckDB itself listed ("Candidate bindings");
    none listed -> no "Did you mean".  The table is the one DuckDB named
    (``Table "o" does not have a column named ...``), else the single table
    ``sql`` reads, else "the query's tables" -- never a guess.
    """
    if not msg:
        return None
    named = _TABLE_HAS_NO_COLUMN.search(msg)
    referenced = None if named else _REFERENCED_COLUMN.search(msg)
    if not (named or referenced):
        return None
    column = (named or referenced).group('col')
    if named:
        where = f"'{named.group('tbl')}'"
    else:
        table = _single_table_of(sql)
        where = f"'{table}'" if table else "the query's tables"
    sentence = f"Column '{column}' is not in {where}."
    cands = _CANDIDATE_BINDINGS.search(msg)
    names = re.findall(r'"([^"]+)"', cands.group('list')) if cands else []
    if names:
        sentence += f" Did you mean: {', '.join(names[:8])}?"
    return f"{sentence} Engine said: {_engine_text(msg)}"


def is_unknown_table_error(msg: str) -> bool:
    """True for DuckDB's "Table with name X does not exist" catalog error."""
    return bool(msg) and bool(_UNKNOWN_TABLE_SHAPE.search(msg))


def unknown_table_name(msg: str) -> str | None:
    """The table name DuckDB's catalog error names, unquoted, or None."""
    m = _UNKNOWN_TABLE.search(msg or '')
    if not m:
        return None
    name = m.group('name').strip()
    if len(name) >= 2 and name[0] == name[-1] and name[0] in '"\'':
        name = name[1:-1]
    return name or None


def _registered_names(connection: dict) -> list[str] | None:
    """The connection's registered table NAMES; None when they cannot be read."""
    config = connection.get('config')
    if not isinstance(config, dict):
        return None
    regs = config.get('registered_tables')
    if regs is None:
        return []
    if not isinstance(regs, list):
        return None
    names = []
    for entry in regs:
        name = entry.get('name') if isinstance(entry, dict) else entry
        if isinstance(name, str) and name:
            names.append(name)
    return names


def _listed(names: list[str]) -> str:
    shown = ', '.join(names[:REGISTERED_TABLES_LISTED])
    extra = len(names) - REGISTERED_TABLES_LISTED
    return f"{shown} (+{extra} more)" if extra > 0 else shown


def unknown_table_message(msg: str, *, connection_id: int | None = None,
                          connection: dict | None = None) -> str:
    """``Table 'x' is not registered on connection 'C'. Registered tables: ...``

    ``connection`` is the connection record (``name`` + ``config``); only
    the registered table NAMES are read from it.  What cannot be determined
    is said plainly: an unnamed table, a connection that could not be read,
    or a query with no connection at all.  A table that IS registered but
    did not open is said to be exactly that, not "not registered".
    """
    table = unknown_table_name(msg)
    subject = f"Table '{table}'" if table else (
        "A table the query names (the engine's error did not say which)")
    engine = f" Engine said: {_engine_text(msg)}"
    if connection is None:
        if connection_id is None:
            return f"{subject} does not exist.{engine}"
        return (f"{subject} was not found on connection {connection_id}. The "
                f"connection could not be read, so its registered tables cannot "
                f"be listed.{engine}")
    cname = connection.get('name') or (
        f"#{connection_id}" if connection_id is not None else "(unnamed)")
    names = _registered_names(connection)
    if names is None:
        return (f"{subject} is not registered on connection '{cname}'. Its "
                f"registered tables could not be read.{engine}")
    if table:
        wanted = {table.lower(), table.rsplit('.', 1)[-1].lower()}
        if any(n.lower() in wanted for n in names):
            return (f"Table '{table}' is registered on connection '{cname}' but "
                    f"could not be opened for this query. Run it again; if it "
                    f"keeps failing, ask an administrator to check the table's "
                    f"registration.{engine}")
    if not names:
        return (f"{subject} is not registered on connection '{cname}', which "
                f"has no registered tables.{engine}")
    return (f"{subject} is not registered on connection '{cname}'. Registered "
            f"tables: {_listed(names)}.{engine}")
