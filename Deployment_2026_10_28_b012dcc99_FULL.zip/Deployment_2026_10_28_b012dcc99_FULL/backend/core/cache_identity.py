"""ONE answer to "whose cached result is this?".

2026-09-07.  Three caches in this product each derived a per-principal
cache scope, and each did it slightly differently:

  * ``core.query_cache.rls_user_scope``            -> sha256({u, g})[:16]
  * ``api.published_views.helpers._user_cache_scope`` -> sha256({u, g})[:16]
  * ``core.query_cache_integration._resolve_user_namespace`` -> the bare
    username, gated on a config flag that an operator had to remember

The first two computed a BYTE-IDENTICAL token from a byte-identical JSON
payload -- two copies of one answer.  The third was the odd one out and
had already produced the defect its own comment records (row-security on,
``per_user_namespacing`` off => two principals sharing one slot).

This module owns the token.  The POLICY around it -- when a scope is
required, whether an admin may share the unscoped slot, what a missing
principal means -- stays with each surface, because those genuinely
differ.  Only the derivation is shared.

Nothing here reads config, so no flag can turn identity off.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, Iterable, Optional

__all__ = [
    "principal_fields",
    "scope_token_for_fields",
    "principal_scope_token",
    "NO_PRINCIPAL",
    "UNSCOPED_INTERNAL",
]

#: A surface that knows a scope is required but was handed no principal.
#: A real token can never collide with it (real tokens are 16 hex chars).
NO_PRINCIPAL = "__no_user__"

#: An internal caller running with NO row-security context at all
#: (``user_ctx=None``): agg-cache materialisation and friends, which
#: deliberately build UNRESTRICTED result sets.  Such a result must never
#: land in a slot a scoped consumer can read, and vice versa.
UNSCOPED_INTERNAL = "__unscoped_internal__"


def principal_fields(user: Any) -> tuple[str, list]:
    """Return ``(username, sorted_groups)`` from any principal spelling.

    Accepts the dict shapes this product passes around (``username`` or
    ``name``; ``groups`` or ``ad_groups``) and a bare string.  Returns
    ``("", [])`` for None/empty so callers can decide what that means --
    this function never decides policy.
    """
    if not user:
        return "", []
    if isinstance(user, dict):
        username = str(user.get("username") or user.get("name") or "")
        raw_groups: Optional[Iterable] = (user.get("groups")
                                          or user.get("ad_groups") or [])
        try:
            groups = sorted(str(g) for g in (raw_groups or []))
        except Exception:
            groups = []
        return username, groups
    return str(user), []


def scope_token_for_fields(username: str, groups: list) -> str:
    """THE derivation.  ``sha256(json({"u": username, "g": groups}))[:16]``.

    Kept separate from :func:`principal_scope_token` so the two existing
    surfaces (``query_cache.rls_user_scope`` and published-views'
    ``_user_cache_scope``) can keep their OWN "when is a scope required"
    policy while sharing this -- their previous inline copies produced
    exactly this string, and a test pins that they still do.
    """
    payload = json.dumps({"u": str(username or ""), "g": list(groups or [])},
                         sort_keys=True)
    return hashlib.sha256(payload.encode()).hexdigest()[:16]


def principal_scope_token(user: Any) -> str:
    """The stable 16-hex identity of a principal FOR CACHE KEYING.

    Two principals share a token exactly when they have the same username
    and the same group set -- which is exactly when ``secure_sql`` would
    produce the same rewrite, so sharing a cached body is correct.

    Returns :data:`NO_PRINCIPAL` when there is no principal at all, so a
    caller that needs a scope always GETS one: there is no ``None`` return
    that a caller could fold into "share with everybody".  That fold is
    how a groupless API-key principal came to share an AD user's slot.

    2026-09-07 -- **A USERNAME-LESS PRINCIPAL KEEPS ITS GROUPS.**

    This function used to return :data:`NO_PRINCIPAL` for ANY empty
    username, which DISCARDED the group set: ``{"groups": ["region-EMEA"]}``
    and ``{"groups": ["region-APAC"]}`` produced a byte-identical token, so
    two consumers the rewriter treats differently shared one cache slot.

    ``_user_cache_scope`` -- in this module's other consumer, on the very
    surface this module was created to de-duplicate -- had always hashed
    the fields it was given without consulting the username first, so the
    two answers to "whose result is this" disagreed inside the module whose
    entire purpose is that there be one.  They now agree: the sentinel
    means "no principal AT ALL", which is the only case where there is
    genuinely nothing to hash.

    Not known to be reachable on a report road today (every report-road
    principal builder -- ``execution_principal``, ``_embed_token_group_scope``,
    ``_fv_principal``, ``_background_principal`` -- guarantees a non-empty
    username), and the fix is made anyway: a latent collision in a
    SECURITY key is one caller away from being a live one, and the caller
    that would introduce it has no way to see the discard.
    """
    username, groups = principal_fields(user)
    if not username and not groups:
        return NO_PRINCIPAL
    return scope_token_for_fields(username, groups)
