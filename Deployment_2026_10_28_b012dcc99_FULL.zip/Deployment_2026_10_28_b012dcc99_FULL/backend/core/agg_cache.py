"""
Aggregation Cache Engine -- Pre-computed rollup parquets with smart routing.

Inspired by:
  - BO Aggregate Awareness: transparent routing to coarsest-grain pre-agg table
  - Power BI VertiPaq: pre-loaded compressed columnar data for sub-second queries
  - Tableau Extracts: scheduled refreshes with incremental option

Architecture:
  1. AggCacheEntry DB records define rollup rules (which dims + measures)
  2. build_cache_entry() executes the aggregation query via FederationEngine
  3. check_cache_hit() intercepts federation queries BEFORE live SQL
  4. Smart routing picks the COARSEST grain cache (fewest dims) that satisfies
  5. Scheduled refresh via APScheduler (cron/interval triggers)
  6. Usage analysis generates suggestions from FederationExecution history

Cache lifecycle:  pending -> building -> ready -> stale -> expired
  - stale: past soft TTL but still serveable (serve + trigger background refresh)
  - expired: past hard expiry, must rebuild (never served)
"""

from __future__ import annotations

import hashlib
import json
import logging
import math
import os
import re
import shutil
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

logger = logging.getLogger(__name__)

# ── Module-level singletons (populated at startup) ─────────────────────────
_db_manager = None
_federation_engine = None
_cache_dir: Optional[Path] = None
_enabled: bool = True
_build_locks: Dict[int, threading.Lock] = {}   # entry_id -> lock
_global_lock = threading.Lock()                 # protects _build_locks dict

# Phase 155 (2026-06-25) -- brain-aware sql-hash memoisation.
# Separate from the BO-style aggregate-aware cache (which keys on
# dataset_id + dimension_col_ids).  This index keys on
# ``(sql_hash, snapshot_id)`` so the brain_router can short-circuit
# repeat queries against a frozen snapshot.  Entries auto-invalidate
# when the snapshot rolls forward (via brain_freshness ledger).
#
# Storage: in-memory dict only (per-pod).  Each entry points at a
# parquet on disk; eviction is LRU-ish.  No DB persistence -- the
# brain re-learns within minutes of restart from prod query traffic.
_BRAIN_SQL_CACHE: Dict[str, Dict[str, Any]] = {}
_BRAIN_SQL_CACHE_LOCK = threading.Lock()
_BRAIN_SQL_CACHE_MAX = 200          # entries
_BRAIN_SQL_CACHE_TTL_SECONDS = 600  # 10-minute soft TTL (snapshot
                                    # invalidation is the hard signal)


# ═══════════════════════════════════════════════════════════════════════════════
# Initialisation
# ═══════════════════════════════════════════════════════════════════════════════

def init_agg_cache(db_manager, federation_engine, cache_dir: str,
                   enabled: bool = True) -> None:
    """Initialize the aggregation cache engine.  Called once at startup."""
    global _db_manager, _federation_engine, _cache_dir, _enabled
    _db_manager = db_manager
    _federation_engine = federation_engine
    _cache_dir = Path(cache_dir)
    _enabled = enabled
    _cache_dir.mkdir(parents=True, exist_ok=True)
    logger.info("[agg_cache] Initialised -- dir=%s enabled=%s", _cache_dir, _enabled)


# ═══════════════════════════════════════════════════════════════════════════════
# Smart Routing — BO Aggregate Awareness
# ═══════════════════════════════════════════════════════════════════════════════

class CacheHitResult:
    """Result of a successful cache lookup."""

    #: Phase 7 (2026-08-09) — candidate kind, used for telemetry/labels only.
    #: DISPATCH is polymorphic (``load_df``/``describe``/``sources_used``),
    #: never an if/elif on this string.
    kind = "parquet_cube"

    def __init__(self, entry_id: int, file_path: str, row_count: int,
                 cache_age_seconds: float, was_stale: bool, grain_label: str):
        self.entry_id = entry_id
        self.file_path = file_path
        self.row_count = row_count
        self.cache_age_seconds = cache_age_seconds
        self.was_stale = was_stale
        self.grain_label = grain_label

    def to_dict(self) -> Dict[str, Any]:
        return {
            "entry_id": self.entry_id,
            "file_path": self.file_path,
            "row_count": self.row_count,
            "cache_age_seconds": round(self.cache_age_seconds, 1),
            "was_stale": self.was_stale,
            "grain_label": self.grain_label,
        }

    # ── Phase 7 (2026-08-09): polymorphic serve seam ─────────────────────
    # The federation engine consumes ANY winning candidate through these
    # three methods, so a candidate backed by something other than a local
    # parquet (e.g. a customer pre-aggregate TABLE) plugs in without the
    # consumer caring.  The base implementations reproduce the pre-Phase-7
    # behaviour byte-for-byte.

    def load_df(self, *, execution_id: str = "",
                requested_dims: Optional[List[Tuple[int, str]]] = None,
                requested_measures: Optional[List[Tuple[int, str, str]]] = None,
                ) -> pd.DataFrame:
        return pd.read_parquet(self.file_path)

    def describe(self) -> str:
        return (f"-- Served from aggregation cache "
                f"(entry={self.entry_id}, grain={self.grain_label})")

    def sources_used(self) -> List[Dict[str, Any]]:
        return [{"type": "agg_cache",
                 "entry_id": self.entry_id,
                 "grain": self.grain_label}]


def _bypass_for_refresh(candidates: list, dataset_id: int, *, lane: str) -> None:
    """FB-36 (2026-09-19): the caller asked for a LIVE answer
    (``force_refresh`` -- the viewer's Refresh button).  The cube that would
    have answered is not served; the coarsest matching parquet entry is
    sent for a background rebuild so the next open is fresh, and its miss
    counter records the decline.  Returns None -- the MISS the callers act
    on.

    THE DECISION, written down once.  ``force_refresh`` is documented as "a
    caller-requested one-off LIVE run" (business_reports_api
    ReportExecuteRequest) and ``_wants_instance_serve`` bypasses INSTANCE
    serving for it -- but the aggregation cube is a second serve layer and
    this function had no parameter to see the flag, so on any report a cube
    could satisfy, Refresh returned the same entry, the same age, the same
    rows, in the same 15 ms (measured with the source STOPPED: an
    818-second-old cube served as the answer to "refresh").  Two fixes were
    defensible: bypass the cube (correct for "I distrust this number",
    expensive) or rebuild-and-disclose-age (cheap, but the first press
    still returns the distrusted number).  Bypass is chosen because it is
    what the flag's own contract says, and because a user who presses
    Refresh on a number they distrust must get the source's answer, not a
    promise about the next press.  The cube is rebuilt in the background so
    the cost is paid once per press, not on every later open.
    """
    if not candidates:
        logger.info("[agg_cache] force_refresh: no cube matched dataset %d "
                    "(%s lane) -- live path", dataset_id, lane)
        return None
    winner = sorted(candidates, key=lambda c: c[1])[0][0]
    logger.info("[agg_cache] force_refresh: cube entry %s (grain=%s) would "
                "have answered dataset %d (%s lane) -- BYPASSED for a live "
                "run; background rebuild triggered",
                winner.get("id"), winner.get("grain_label"), dataset_id, lane)
    try:
        _trigger_background_refresh(winner["id"])
    except Exception as exc:                             # noqa: BLE001
        logger.warning("[agg_cache] force_refresh: rebuild trigger for entry %s "
                       "failed (live run proceeds): %s", winner.get("id"), exc)
    try:
        _db_manager.increment_agg_cache_miss(winner["id"])
    except Exception:                                    # noqa: BLE001
        pass
    return None


def check_cache_hit(
    *,
    dataset_id: int,
    requested_dimension_col_ids: List[int],
    requested_measure_col_ids: List[int],
    requested_dims: Optional[List[Tuple[int, str]]] = None,
    requested_measures: Optional[List[Tuple[int, str, str]]] = None,
    filter_columns: Optional[List[str]] = None,
    condition_ids: Optional[List[int]] = None,
    dataset: Optional[Dict[str, Any]] = None,
    has_metrics: bool = False,
    bypass: bool = False,
) -> Optional[CacheHitResult]:
    """Check if any pre-computed cache can satisfy this query.

    Smart Routing Algorithm (BO Aggregate Awareness):
      1. All requested measures must be present in the cache entry's measure set
      2. The requested dimension set must EQUAL the cache entry's dimension set
         (2026-08-20 — was "subset": this plain serve path does load->filter->
         limit->project with NO re-aggregation, so a finer-grain cube hit
         returned duplicate group keys with un-rolled-up measures.  The RLS
         path re-aggregates and may keep subset routing; this one must not.)
      2b. The query's condition_ids must EQUAL the entry's condition_ids —
         a cube built without a condition cannot answer a query that carries
         one (the raw where_clause would be silently dropped), and a cube
         built WITH conditions is a filtered subset an unconditioned query
         must never be served from.
      3. Among matches, pick the COARSEST grain (fewest dimensions = smallest parquet)
      4. If status='stale' and stale_serve is enabled, serve it + trigger background refresh
      5. If status='expired' or no match, return None (fall through to live)

    Phase 7 (2026-08-09): the optional kwargs carry the request context the
    CANDIDATE-SOURCE REGISTRY needs (customer pre-aggregate tables via
    ``AggregationAwareness``).  Legacy callers that omit them lose nothing —
    external sources simply cannot judge eligibility and stay silent, and
    with ``agg_cache.agg_awareness_serving_enabled`` OFF (the shipped
    default) routing is byte-identical to before.

    ``bypass`` (FB-36, 2026-09-19): the caller wants a LIVE answer.  The
    matching cube is not served (its rebuild is triggered instead) and the
    result is a MISS.  See ``_bypass_for_refresh`` for the decision.
    """
    if not _enabled or not _db_manager:
        return None

    from core import config
    if not config.agg_cache.enabled:
        return None
    if not config.semantic_layer.aggregation_awareness_enabled:
        return None

    now = datetime.now(timezone.utc)
    entries = _db_manager.list_agg_cache_entries(dataset_id=dataset_id)

    req_dims = set(requested_dimension_col_ids)
    req_measures = set(requested_measure_col_ids)

    candidates: List[Tuple[Dict, int]] = []   # (entry_dict, dimension_count)

    for entry in entries:
        if not entry.get("is_enabled"):
            continue
        # Phase 5 RLS-aware cubes (2026-08-09): entries built FOR the
        # secured serve path carry a finer grain (security dimensions and
        # avg SUM/COUNT pairs) or a per-scope parquet ("scoped").  This
        # PLAIN path neither re-aggregates nor scope-checks, so it must
        # never touch them — serving a finer-grain cube here would return
        # un-re-aggregated rows (silent wrong numbers), and serving a
        # scoped cube here would serve one caller's rows to everyone.
        # Fail-closed both ways: only "open"/legacy entries are visible.
        if (entry.get("rls_mode") or "open") != "open":
            continue
        if entry["status"] not in ("ready", "stale"):
            continue
        if not entry.get("file_path") or not os.path.isfile(entry["file_path"]):
            continue

        cache_dims = set(entry.get("dimension_col_ids") or [])
        cache_measures = set(entry.get("measure_col_ids") or [])

        # All requested measures must be in cache
        if not req_measures.issubset(cache_measures):
            continue

        # Dimensions must match EXACTLY (2026-08-20 — was subset, "cache can
        # have MORE dims").  The serve block in federation_engine does NOT
        # re-aggregate, so a cube at a finer grain than the request would be
        # returned with duplicate group keys and un-rolled-up measures —
        # silent wrong numbers.  The module comment above (Phase 5) names
        # this exact failure for RLS entries; the plain path had it too.
        if req_dims != cache_dims:
            continue

        # The query's pre-defined conditions must equal the ones baked into
        # the cube (2026-08-20).  Condition where_clauses are raw SQL the
        # serve path cannot apply to the parquet; a mismatch either drops
        # the caller's condition (over-serve) or serves a conditioned cube
        # to an unconditioned query (under-serve).  Either way: MISS.
        if set(condition_ids or []) != set(entry.get("condition_ids") or []):
            continue

        # Check hard expiry
        expires_at = entry.get("expires_at")
        if expires_at:
            exp_dt = _parse_dt(expires_at)
            if now > exp_dt:
                _db_manager.increment_agg_cache_miss(entry["id"])
                continue

        candidates.append((entry, len(cache_dims)))

    if bypass:
        # FB-36: a forced live run.  Decided BEFORE the registry candidates
        # (customer pre-aggregate tables) are consulted -- they are a cube
        # too, and Refresh must not be answered from either.
        return _bypass_for_refresh(candidates, dataset_id, lane="plain")

    # ── Phase 7 (2026-08-09): additional candidate sources (registry) ────
    # Customer pre-aggregate tables compete on the same coarsest-grain rule.
    # Any failure in collection is a MISS for the external sources only —
    # never for the parquet path.
    aa_hit: Optional[CacheHitResult] = None
    aa_grain: Optional[int] = None
    try:
        aa_hit, aa_grain = _best_registry_candidate(CandidateContext(
            dataset_id=dataset_id, dataset=dataset,
            requested_dims=requested_dims, requested_measures=requested_measures,
            filter_columns=filter_columns, condition_ids=condition_ids,
            rls_predicates=[], rls_open=True, has_metrics=has_metrics))
    except Exception as _src_exc:
        logger.info("[agg_cache] external candidate collection failed "
                    "(MISS for external sources only): %s", _src_exc)

    if not candidates:
        if aa_hit is not None:
            _record_aa_serve(aa_hit)
            return aa_hit
        return None

    # Pick coarsest grain (fewest dimensions)
    candidates.sort(key=lambda x: x[1])
    winner, _winner_grain = candidates[0]

    # A STRICTLY coarser customer pre-aggregate beats the parquet cube;
    # on ties the parquet wins (local file, no external query, no external
    # trust needed).  Precedence-on-tie mirrors Power BI's explicit
    # aggregation Precedence arbitration.
    if aa_hit is not None and aa_grain is not None and aa_grain < _winner_grain:
        _record_aa_serve(aa_hit)
        return aa_hit

    # Determine staleness
    was_stale = False
    stale_at = winner.get("stale_at")
    if stale_at:
        stale_dt = _parse_dt(stale_at)
        if now > stale_dt:
            was_stale = True
            if not config.agg_cache.stale_serve_enabled:
                _db_manager.increment_agg_cache_miss(winner["id"])
                return None
            # Trigger background refresh (non-blocking)
            _trigger_background_refresh(winner["id"])

    # Calculate cache age
    built_at = winner.get("last_built_at")
    if built_at:
        built_dt = _parse_dt(built_at)
        cache_age = (now - built_dt).total_seconds()
    else:
        cache_age = 0.0

    _db_manager.increment_agg_cache_hit(winner["id"])

    return CacheHitResult(
        entry_id=winner["id"],
        file_path=winner["file_path"],
        row_count=winner.get("row_count", 0),
        cache_age_seconds=cache_age,
        was_stale=was_stale,
        grain_label=winner.get("grain_label", "custom"),
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 5 (2026-08-09) — RLS-aware cube serving
# (target architecture §3.2-3.4; industry research §2 — the Power BI rule:
#  "it would be insecure to answer queries from the aggregation table if
#  the RLS filter can't be applied", and MicroStrategy KB30711: the
#  security-filter attribute must be PRESENT in the cube.)
#
# ELIGIBILITY RULE, as implemented — a cube may answer an RLS-scoped query
# only when ALL of:
#   1. flag `agg_cache.rls_serving_enabled` is ON (ships OFF);
#   2. the caller's scope RESOLVES with certainty (identity verifiable,
#      policy store readable, dataset tables collectable) to pure
#      rewrite-mode row predicates — opaque enforcement (native_lf/view)
#      and column-masking policies make the caller ineligible;
#   3. the requested dims/measures route to the entry (existing subset
#      logic, over dims ∪ security-dims);
#   4. mode gate: "security_dims" requires stored policy_version ==
#      CURRENT compute_policy_fingerprint (drift ⇒ demote + MISS);
#      "scoped" requires exact rls_signature equality with the caller's
#      live scope_signature; "open" entries serve only UNFILTERED callers;
#   5. every column referenced by every resolved predicate is one of the
#      cube's GROUPING columns (dimension ∪ security-dimension physical
#      names) — re-checked at serve time, never assumed from build time;
#   6. every requested measure re-aggregates exactly at the requested
#      grain: SUM/MIN/MAX/COUNT compose; AVG requires the stored
#      `col__sum`/`col__cnt` pair; COUNT DISTINCT is ineligible whenever
#      the requested grain is coarser than the cube's own;
#   7. the cube parquet's actual schema carries every column the serve
#      SQL will touch.
# Every uncertainty at any step is a MISS (fall through to the live path,
# where SqlRewriter enforces RLS at source) — never a refusal, never an
# unfiltered serve.
# ═══════════════════════════════════════════════════════════════════════════════

#: Aggregations that re-aggregate exactly when cube rows are rolled up to a
#: coarser grain.  COUNT composes as SUM of stored per-group counts.  AVG is
#: handled via its stored SUM/COUNT pair; COUNT_DISTINCT never composes.
_ROLLUP_SAFE_AGGS = frozenset({"sum", "min", "max", "count"})

_AVG_SUM_SUFFIX = "__sum"
_AVG_CNT_SUFFIX = "__cnt"

# In-process policy-version observation (hygiene only — the serve-time
# policy_version / rls_signature equality checks are the GATE).  The
# admin API calls core.row_security.api.invalidate_cache() on every policy
# CRUD, which bumps current_policy_version(); observing a bump here lets
# us demote secured entries eagerly instead of lazily at first serve.
_last_seen_policy_version: Optional[int] = None
_policy_obs_lock = threading.Lock()


class _RlsCubeIneligible(Exception):
    """Internal verdict: this caller / predicate / cube combination cannot
    be served from a shared cube.  SECURITY: always mapped to a cache MISS
    (run live under the rewriter) — never to an unfiltered serve, never to
    a user-facing refusal."""


class SecuredCacheHit(CacheHitResult):
    """A cache hit that must be served through the secured DuckDB path:
    the caller's resolved predicates applied as a WHERE over the cube
    parquet, re-aggregated to the requested grain when the cube's grain is
    finer (security dimensions)."""

    def __init__(self, *, entry_id: int, file_path: str, row_count: int,
                 cache_age_seconds: float, was_stale: bool, grain_label: str,
                 predicates: List[str], grouping_phys: List[str],
                 needs_regroup: bool, rls_mode: str):
        super().__init__(entry_id, file_path, row_count, cache_age_seconds,
                         was_stale, grain_label)
        self.predicates = list(predicates)          # qualifier-stripped, rendered
        self.grouping_phys = list(grouping_phys)    # cube grouping cols (dims ∪ sec dims)
        self.needs_regroup = needs_regroup
        self.rls_mode = rls_mode

    kind = "parquet_cube_rls"

    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({
            "rls_mode": self.rls_mode,
            "needs_regroup": self.needs_regroup,
            "predicate_count": len(self.predicates),
        })
        return d

    # Phase 7 polymorphic serve seam — behaviour identical to the direct
    # read_secured_cube call the engine made before.
    def load_df(self, *, execution_id: str = "",
                requested_dims: Optional[List[Tuple[int, str]]] = None,
                requested_measures: Optional[List[Tuple[int, str, str]]] = None,
                ) -> pd.DataFrame:
        return read_secured_cube(self, requested_dims=requested_dims or [],
                                 requested_measures=requested_measures or [])

    def describe(self) -> str:
        return (f"-- Served from RLS-aware aggregation "
                f"cache (entry={self.entry_id}, "
                f"grain={self.grain_label}, "
                f"mode={self.rls_mode})")

    def sources_used(self) -> List[Dict[str, Any]]:
        return [{"type": "agg_cache",
                 "entry_id": self.entry_id,
                 "grain": self.grain_label,
                 "rls_mode": self.rls_mode,
                 "rls_predicates_applied": len(self.predicates)}]


def _rls_feature_enabled() -> bool:
    """The rollout flag.  Unreadable config keeps the feature OFF — the
    flag is an access WIDENER, so its fail mode is closed."""
    try:
        from core import config
        return bool(config.agg_cache.rls_serving_enabled)
    except Exception:
        return False


def _row_security_enabled() -> bool:
    try:
        from core.row_security.api import _is_enabled
        return bool(_is_enabled())
    except Exception:
        return False


def _current_policy_fingerprint() -> str:
    """CURRENT policy-set fingerprint — the drift GATE's right-hand side.
    STRICT: raises on any error (an unreadable policy store must never
    look like 'nothing changed')."""
    from core.identity.rls_predicates import compute_policy_fingerprint
    return compute_policy_fingerprint(_db_manager)


def _caller_scope_signature(user_ctx: Any, dataset_id: int) -> str:
    """The caller's LIVE scope signature (scoped-mode matching).  Raises
    ScopeSignatureError on any uncertainty — mapped to MISS by callers."""
    from core.row_security.signature import scope_signature
    return scope_signature(user_ctx, dataset_id=dataset_id, db=_db_manager)


def _resolve_caller_scope(user_ctx: Any, dataset: Dict[str, Any]) -> Tuple[List[str], bool]:
    """Resolve the caller's row-security scope against the dataset's base
    relations via the SAME strict machinery the instance layer uses
    (``core/row_security/signature.py`` — one notion of scope, no drift).

    Returns ``(predicate_texts, is_open)`` where ``predicate_texts`` is the
    ordered, deduped list of RENDERED row-filter SQL texts and ``is_open``
    is True when row security changes nothing for this caller (admin
    bypass / no matching policies).

    Raises (⇒ MISS): identity unverifiable, policy store unreadable,
    dataset tables uncollectable, OPAQUE enforcement anywhere in scope
    (engine-side per-principal filtering we cannot replicate over a
    parquet), or any COLUMN policy in scope (masking cannot be applied to
    a cube without re-implementing the rewriter's projection — refused).
    """
    from core.identity.rls_predicates import EffectiveRlsComputer
    from core.row_security.signature import _dataset_table_refs, _to_identity

    identity = _to_identity(user_ctx)              # raises ScopeSignatureError
    computer = EffectiveRlsComputer(_db_manager, enabled_fn=lambda: True)
    refs, conn_ids = _dataset_table_refs(dataset, _db_manager, computer)
    if not refs:
        raise _RlsCubeIneligible(
            "dataset exposes no resolvable base relations — unknown table "
            "scope cannot be certified for cube serving")

    predicate_texts: List[str] = []
    all_unfiltered = True
    for cid in conn_ids:
        preds = computer.compute_for_tables(refs, identity=identity,
                                            connection_id=cid)
        if preds.is_unfiltered:
            continue
        all_unfiltered = False
        if preds.principal_scope:
            raise _RlsCubeIneligible(
                "opaque enforcement (native_lf/view) in scope — engine-side "
                "per-principal filtering cannot be replicated over a cube")
        for tp in preds.tables:
            if tp.opaque:
                raise _RlsCubeIneligible(
                    f"table {tp.table_ref!r} enforced opaquely — cube ineligible")
            if tp.column_rules:
                raise _RlsCubeIneligible(
                    f"column policy applies to {tp.table_ref!r} — masking "
                    "cannot be applied over a cube, cube ineligible")
            for rf in tp.row_filters:
                txt = (rf.rendered_sql or "").strip()
                if txt and txt not in predicate_texts:
                    predicate_texts.append(txt)
    return predicate_texts, all_unfiltered


def _predicate_serve_form(pred_sql: str) -> Tuple[str, List[str]]:
    """Parse ONE rendered predicate; return ``(serve_sql, columns)`` where
    ``serve_sql`` has table/db/catalog qualifiers stripped (the cube is a
    single flat relation) and ``columns`` are the lower-cased column names
    it references.

    Raises :class:`_RlsCubeIneligible` (⇒ MISS) on: parse failure, any
    subquery / SELECT / EXISTS (references relations beyond the cube),
    any ``*``, or an unnamed column node.
    """
    try:
        import sqlglot
        from sqlglot import exp
    except Exception as exc:                      # pragma: no cover - hard dep
        raise _RlsCubeIneligible(f"sqlglot unavailable: {exc}")
    try:
        tree = sqlglot.parse_one(pred_sql, dialect="duckdb")
    except Exception as exc:
        raise _RlsCubeIneligible(f"predicate does not parse: {exc}")
    if tree is None:
        raise _RlsCubeIneligible("predicate parsed to nothing")
    for cls, label in ((exp.Select, "subquery"), (exp.Subquery, "subquery"),
                       (exp.Star, "star")):
        if next(iter(tree.find_all(cls)), None) is not None:
            raise _RlsCubeIneligible(
                f"predicate contains a {label} — cannot be applied over a "
                "cube parquet")
    cols: List[str] = []
    for col in tree.find_all(exp.Column):
        name = str(col.name or "").strip().lower()
        if not name:
            raise _RlsCubeIneligible("predicate contains an unnamed column")
        if name not in cols:
            cols.append(name)
        # The cube is one flat relation — source-table qualifiers would
        # fail to bind (and could never mean anything else).
        col.set("table", None)
        col.set("db", None)
        col.set("catalog", None)
    return tree.sql(dialect="duckdb"), cols


def _parquet_columns(file_path: str) -> Optional[List[str]]:
    """Actual column names in the cube parquet (footer metadata only —
    no data read).  None = unreadable ⇒ the candidate is skipped."""
    try:
        import pyarrow.parquet as _pq
        return list(_pq.ParquetFile(file_path).schema_arrow.names)
    except Exception as exc:
        logger.debug("[agg_cache] cube schema unreadable for %s: %s",
                     file_path, exc)
        return None


def _demote_drifted_entry(entry_id: int) -> None:
    """Policy drift detected at serve time — demote + queue rebuild.
    Hygiene only; the fingerprint equality check already MISSed."""
    try:
        _db_manager.update_agg_cache_entry(entry_id, status="stale")
        _trigger_background_refresh(entry_id)
    except Exception as exc:
        logger.warning("[agg_cache] demote of drifted entry %d failed: %s",
                       entry_id, exc)


def invalidate_rls_entries(reason: str = "policy_change") -> int:
    """Demote every secured (non-open) cube entry to 'stale'.  Called on
    policy-version bumps (see :func:`_observe_policy_version`); callable
    directly by policy CRUD.  Hygiene, not the gate — the serve-time
    policy_version / rls_signature equality checks are what make a
    drifted cube unserveable."""
    if not _db_manager:
        return 0
    count = 0
    try:
        entries = _db_manager.list_agg_cache_entries()
    except Exception as exc:
        logger.warning("[agg_cache] invalidate_rls_entries listing failed: %s", exc)
        return 0
    for entry in entries:
        if (entry.get("rls_mode") or "open") == "open":
            continue
        if entry["status"] in ("ready", "building"):
            _db_manager.update_agg_cache_entry(entry["id"], status="stale")
            count += 1
    if count:
        logger.info("[agg_cache] Invalidated %d RLS-scoped cube entries (%s)",
                    count, reason)
    return count


def _observe_policy_version() -> None:
    """Compare the in-process row-security policy version against the last
    one seen; on a bump, demote secured entries.  First observation only
    records the baseline (process start must not demote)."""
    global _last_seen_policy_version
    try:
        from core.row_security.api import current_policy_version
        v = current_policy_version()
    except Exception:
        return
    with _policy_obs_lock:
        changed = (_last_seen_policy_version is not None
                   and v != _last_seen_policy_version)
        _last_seen_policy_version = v
    if changed:
        try:
            invalidate_rls_entries("policy_version bump")
        except Exception as exc:
            logger.warning("[agg_cache] policy-version invalidation failed: %s", exc)


def check_cache_hit_rls(
    *,
    dataset_id: int,
    requested_dims: List[Tuple[int, str]],
    requested_measures: List[Tuple[int, str, str]],
    user_ctx: Any,
    dataset: Optional[Dict[str, Any]] = None,
    filter_columns: Optional[List[str]] = None,
    condition_ids: Optional[List[int]] = None,
    has_metrics: bool = False,
    bypass: bool = False,
) -> Optional[CacheHitResult]:
    """RLS-aware cache routing — the eligibility gate documented at the top
    of this section.

    ``bypass`` (FB-36, 2026-09-19): a forced live run -- the matching cube
    is not served, its rebuild is triggered, MISS.  Same decision as the
    plain path (``_bypass_for_refresh``); a Refresh under RLS is still a
    Refresh.

    ``requested_dims``     — [(DatasetColumn.id, physical_name)]
    ``requested_measures`` — [(DatasetColumn.id, physical_name,
                              aggregation.lower())] with any per-request
                              aggregation OVERRIDES already applied (the
                              gate must judge the aggregation that will
                              actually be computed).
    ``dataset``            — the already-loaded ``get_dataset_full`` dict
                              (avoids a second load); fetched if omitted.

    Returns a :class:`SecuredCacheHit`, an :class:`AggTableHit` (Phase 7 —
    a customer pre-agg table whose dimensions cover every resolved
    predicate), or None.  NEVER raises: every uncertainty is logged and
    mapped to None (MISS ⇒ live path).
    """
    if not _enabled or not _db_manager:
        return None
    from core import config
    if not config.agg_cache.enabled:
        return None
    if not config.semantic_layer.aggregation_awareness_enabled:
        return None
    if not _rls_feature_enabled():
        return None

    _observe_policy_version()

    # ── caller scope (gate 2) ────────────────────────────────────────────
    try:
        ds = dataset or _db_manager.get_dataset_full(dataset_id)
        if not ds:
            raise _RlsCubeIneligible(f"dataset {dataset_id} not found")
        predicates, is_open = _resolve_caller_scope(user_ctx, ds)
    except Exception as exc:
        # ScopeSignatureError / RlsComputationError / _RlsCubeIneligible /
        # anything else: uncertainty ⇒ MISS, run live under the rewriter.
        logger.info("[agg_cache] RLS cube MISS (scope unresolvable): %s", exc)
        return None

    # ── current policy fingerprint (gate 4's right-hand side) ───────────
    try:
        current_fp = _current_policy_fingerprint()
    except Exception as exc:
        logger.info("[agg_cache] RLS cube MISS (policy fingerprint "
                    "unavailable): %s", exc)
        return None

    ds_cols = {c["id"]: c for c in (ds.get("columns") or [])}
    req_dim_ids = {cid for cid, _ in requested_dims}
    req_measure_ids = {cid for cid, _, _ in requested_measures}
    req_dim_phys_lower = {str(p).lower() for _, p in requested_dims}

    now = datetime.now(timezone.utc)
    try:
        entries = _db_manager.list_agg_cache_entries(dataset_id=dataset_id)
    except Exception as exc:
        logger.info("[agg_cache] RLS cube MISS (entry listing failed): %s", exc)
        return None

    caller_sig: Optional[str] = None
    candidates: List[Tuple[Dict, int, List[str], List[str], bool]] = []

    for entry in entries:
        if not entry.get("is_enabled"):
            continue
        if entry["status"] not in ("ready", "stale"):
            continue
        if not entry.get("file_path") or not os.path.isfile(entry["file_path"]):
            continue

        mode = entry.get("rls_mode") or "open"
        cache_dims = set(entry.get("dimension_col_ids") or [])
        sec_dims = set(entry.get("security_dimension_col_ids") or [])
        cache_measures = set(entry.get("measure_col_ids") or [])
        grouping_ids = cache_dims | sec_dims

        # Routing (gate 3): subset logic over dims ∪ security-dims.
        if not req_measure_ids.issubset(cache_measures):
            continue
        if not req_dim_ids.issubset(grouping_ids):
            continue

        # Hard expiry (as the plain path).
        expires_at = entry.get("expires_at")
        if expires_at and now > _parse_dt(expires_at):
            _db_manager.increment_agg_cache_miss(entry["id"])
            continue

        # ── mode gate (gate 4) ───────────────────────────────────────────
        if mode == "security_dims":
            if not entry.get("policy_version") or entry["policy_version"] != current_fp:
                # Policies changed since this cube was built — its baked
                # security-dimension set may no longer cover the policies.
                logger.info("[agg_cache] entry %d: policy_version drift — "
                            "demoting + MISS", entry["id"])
                _db_manager.increment_agg_cache_miss(entry["id"])
                _demote_drifted_entry(entry["id"])
                continue
        elif mode == "scoped":
            try:
                if caller_sig is None:
                    caller_sig = _caller_scope_signature(user_ctx, dataset_id)
            except Exception as exc:
                logger.info("[agg_cache] entry %d: caller signature "
                            "uncomputable (%s) — MISS", entry["id"], exc)
                _db_manager.increment_agg_cache_miss(entry["id"])
                continue
            if not entry.get("rls_signature") or entry["rls_signature"] != caller_sig:
                # scope_signature folds the policy fingerprint, so equality
                # also certifies the policy set is unchanged since build.
                _db_manager.increment_agg_cache_miss(entry["id"])
                continue
        else:
            # "open"/legacy cube: full unscoped data, no baked security
            # grain, no policy_version stamp.  Only an UNFILTERED caller
            # (admin bypass / no matching policies) may be served from it —
            # the design authorises scoped serving only from cubes built
            # for it (§3.3).
            if predicates or not is_open:
                continue

        # ── grouping physical names ──────────────────────────────────────
        grouping_phys: Optional[List[str]] = []
        for cid in sorted(grouping_ids):
            col = ds_cols.get(cid)
            if col is None or not col.get("physical_name"):
                grouping_phys = None       # unknown column id — uncertainty
                break
            grouping_phys.append(str(col["physical_name"]))
        if grouping_phys is None:
            _db_manager.increment_agg_cache_miss(entry["id"])
            continue
        grouping_phys_lower = {p.lower() for p in grouping_phys}

        # ── predicate-column coverage (gate 5) ───────────────────────────
        # Scoped cubes were MATERIALISED under the caller's exact scope —
        # no WHERE is applied (the parquet already holds only their rows).
        serve_preds: List[str] = []
        if mode != "scoped" and predicates:
            eligible = True
            for pred in predicates:
                try:
                    serve_sql, pred_cols = _predicate_serve_form(pred)
                except _RlsCubeIneligible as exc:
                    logger.info("[agg_cache] entry %d: predicate ineligible "
                                "(%s) — MISS", entry["id"], exc)
                    eligible = False
                    break
                if not set(pred_cols).issubset(grouping_phys_lower):
                    missing = sorted(set(pred_cols) - grouping_phys_lower)
                    logger.info("[agg_cache] entry %d: predicate references "
                                "non-grouping column(s) %s — MISS",
                                entry["id"], missing)
                    eligible = False
                    break
                serve_preds.append(serve_sql)
            if not eligible:
                _db_manager.increment_agg_cache_miss(entry["id"])
                continue

        # ── measure decomposability (gate 6) + schema reality (gate 7) ───
        needs_regroup = req_dim_phys_lower != grouping_phys_lower
        schema_names = _parquet_columns(entry["file_path"])
        if schema_names is None:
            _db_manager.increment_agg_cache_miss(entry["id"])
            continue
        schema_lower = {s.lower() for s in schema_names}

        if not req_dim_phys_lower.issubset(schema_lower):
            _db_manager.increment_agg_cache_miss(entry["id"])
            continue
        if not grouping_phys_lower.issubset(schema_lower):
            # Metadata says a grouping column exists that the parquet does
            # not carry (e.g. built before this feature, or by write-
            # through) — the WHERE could silently not-filter.  MISS.
            _db_manager.increment_agg_cache_miss(entry["id"])
            continue

        measures_ok = True
        for _cid, phys, agg in requested_measures:
            a = (agg or "").lower()
            p_lower = str(phys).lower()
            if needs_regroup:
                if a in _ROLLUP_SAFE_AGGS:
                    if p_lower not in schema_lower:
                        measures_ok = False
                        break
                elif a == "avg":
                    pair = {p_lower + _AVG_SUM_SUFFIX, p_lower + _AVG_CNT_SUFFIX}
                    if not pair.issubset(schema_lower):
                        measures_ok = False   # no SUM/COUNT pair ⇒ AVG cannot re-aggregate
                        break
                else:
                    # count_distinct (never composes across groups) or an
                    # unknown aggregation: coarser grain ⇒ ineligible.
                    measures_ok = False
                    break
            else:
                # Exact grain: stored values are exact for surviving rows
                # (a WHERE on grouping columns removes whole groups, never
                # splits one) — but only KNOWN aggregations are certified.
                if p_lower not in schema_lower:
                    measures_ok = False
                    break
                if a not in ("sum", "avg", "count", "min", "max",
                             "count_distinct"):
                    measures_ok = False
                    break
        if not measures_ok:
            _db_manager.increment_agg_cache_miss(entry["id"])
            continue

        candidates.append((entry, len(grouping_ids), serve_preds,
                           grouping_phys, needs_regroup))

    if bypass:
        # FB-36: a forced live run -- decided before the registry candidates.
        return _bypass_for_refresh(candidates, dataset_id, lane="rls")

    # ── Phase 7 (2026-08-09): customer pre-agg tables under RLS ──────────
    # Power BI's rule applies unchanged: the mapping is eligible ONLY when
    # the caller's resolved predicates can be applied AT the agg table —
    # i.e. every predicate column is one of the table's rolled-up
    # dimensions (which the customer must have put there).  A table without
    # the security columns is INELIGIBLE; every uncertainty is a MISS.
    aa_hit: Optional[CacheHitResult] = None
    aa_grain: Optional[int] = None
    try:
        aa_hit, aa_grain = _best_registry_candidate(CandidateContext(
            dataset_id=dataset_id, dataset=ds,
            requested_dims=requested_dims, requested_measures=requested_measures,
            filter_columns=filter_columns, condition_ids=condition_ids,
            rls_predicates=list(predicates), rls_open=bool(is_open),
            has_metrics=has_metrics))
    except Exception as _src_exc:
        logger.info("[agg_cache] external candidate collection failed under "
                    "RLS (MISS for external sources only): %s", _src_exc)

    if not candidates:
        if aa_hit is not None:
            _record_aa_serve(aa_hit)
            return aa_hit
        return None

    # Coarsest grain wins (fewest grouping columns = smallest parquet).
    candidates.sort(key=lambda x: x[1])
    winner, _n, serve_preds, grouping_phys, needs_regroup = candidates[0]

    if aa_hit is not None and aa_grain is not None and aa_grain < _n:
        # Strictly coarser customer pre-aggregate wins; parquet wins ties.
        _record_aa_serve(aa_hit)
        return aa_hit

    # Staleness (temporal CAP — the correctness gates above already passed).
    from core import config as _cfg
    was_stale = False
    stale_at = winner.get("stale_at")
    if stale_at and now > _parse_dt(stale_at):
        was_stale = True
        if not _cfg.agg_cache.stale_serve_enabled:
            _db_manager.increment_agg_cache_miss(winner["id"])
            return None
        _trigger_background_refresh(winner["id"])

    built_at = winner.get("last_built_at")
    cache_age = (now - _parse_dt(built_at)).total_seconds() if built_at else 0.0

    _db_manager.increment_agg_cache_hit(winner["id"])

    return SecuredCacheHit(
        entry_id=winner["id"],
        file_path=winner["file_path"],
        row_count=winner.get("row_count", 0),
        cache_age_seconds=cache_age,
        was_stale=was_stale,
        grain_label=winner.get("grain_label", "custom"),
        predicates=serve_preds,
        grouping_phys=grouping_phys,
        needs_regroup=needs_regroup,
        rls_mode=winner.get("rls_mode") or "open",
    )


def read_secured_cube(
    hit: SecuredCacheHit,
    *,
    requested_dims: List[Tuple[int, str]],
    requested_measures: List[Tuple[int, str, str]],
) -> pd.DataFrame:
    """Serve a :class:`SecuredCacheHit`: one bounded DuckDB query over the
    cube parquet — the caller's resolved predicates as a WHERE, re-grouped
    to the requested grain when the cube's grain is finer.  AVG re-derives
    from its stored SUM/COUNT pair (Power BI's documented decomposition);
    COUNT rolls up as SUM of stored per-group counts.

    Never pandas-materialises the whole cube (the federation_engine:593
    defect this path replaces); uses the same bounded-connection posture as
    ``core.reports.microcube``.

    Raises on any failure — the federation caller's existing exception
    fence maps that to fall-through-to-live (MISS semantics).
    """
    from core.reports.microcube import (
        DEFAULT_MEMORY_LIMIT, DEFAULT_THREADS, _artifact_src, _connect,
    )
    from core.reports.pagination import _quote_ident

    try:
        from core import config as _cfg
        threads = _cfg.business_reports.microcube_threads
        memory_limit = _cfg.business_reports.microcube_memory_limit
    except Exception:
        threads, memory_limit = DEFAULT_THREADS, DEFAULT_MEMORY_LIMIT

    dim_parts = [_quote_ident(str(phys)) for _, phys in requested_dims]
    select_parts = list(dim_parts)
    for _cid, phys, agg in requested_measures:
        a = (agg or "").lower()
        q = _quote_ident(str(phys))
        if hit.needs_regroup:
            if a == "sum" or a == "count":
                select_parts.append(f"SUM({q}) AS {q}")
            elif a == "min":
                select_parts.append(f"MIN({q}) AS {q}")
            elif a == "max":
                select_parts.append(f"MAX({q}) AS {q}")
            elif a == "avg":
                qs = _quote_ident(str(phys) + _AVG_SUM_SUFFIX)
                qc = _quote_ident(str(phys) + _AVG_CNT_SUFFIX)
                select_parts.append(f"SUM({qs}) / NULLIF(SUM({qc}), 0) AS {q}")
            else:
                # The eligibility gate refuses these; reaching here is a
                # programming error — fail loud, mapped to MISS upstream.
                raise ValueError(
                    f"measure {phys!r} agg {a!r} is not re-aggregable at a "
                    "coarser grain (gate should have refused this cube)")
        else:
            select_parts.append(q)

    sql = (f"SELECT {', '.join(select_parts)} "
           f"FROM {_artifact_src(Path(hit.file_path))}")
    if hit.predicates:
        sql += " WHERE " + " AND ".join(f"({p})" for p in hit.predicates)
    if hit.needs_regroup and dim_parts:
        sql += " GROUP BY " + ", ".join(dim_parts)

    con = _connect(threads, memory_limit)
    try:
        return con.execute(sql).fetchdf()
    finally:
        try:
            con.close()
        except Exception:
            pass


def _template_columns(template: str) -> Optional[List[str]]:
    """Column names referenced by a policy ``filter_sql`` TEMPLATE (build
    time — pre-substitution).  ``${user.attr}`` tokens are replaced with a
    neutral literal so the template parses; substitution only ever renders
    LITERALS, so the column set is invariant under it.  None = the columns
    cannot be determined with certainty (⇒ the cube stays 'open')."""
    import re as _re
    t = _re.sub(r"'\$\{[^}]*\}'", "'0'", template or "")
    t = _re.sub(r"\$\{[^}]*\}", "'0'", t)
    if not t.strip():
        return []
    try:
        _serve_sql, cols = _predicate_serve_form(t)
        return cols
    except Exception:
        return None


def _compute_security_dimensions(ds: Dict[str, Any]) -> Optional[List[int]]:
    """Build-time security-dimension extraction: the DatasetColumn ids of
    every column referenced by any enabled ROW policy targeting any of the
    dataset's base relations (binding-INDEPENDENT — any principal's
    predicates come from these templates).

    Returns the sorted id list, or None when the cube CANNOT be certified
    (⇒ built as 'open', never served to scoped callers):
      * an opaque-mode (native_lf/view) policy targets a dataset table;
      * a policy template does not parse / contains a subquery;
      * a referenced column is not modeled on the dataset, or is not a
        dimension/detail column (grouping by an aggregated measure would
        change what the predicate means).

    UNDER-collection here is harmless (a missed column ⇒ serve-time
    coverage check MISSes — lost hit, never a leak); the serve-time check
    is the gate, this is the enabler.
    """
    if not _db_manager:
        return None
    try:
        from core.identity.rls_predicates import EffectiveRlsComputer
        from core.row_security.resolver import table_matches_pattern
        from core.row_security.signature import _dataset_table_refs

        computer = EffectiveRlsComputer(_db_manager, enabled_fn=lambda: True)
        refs, _conn_ids = _dataset_table_refs(ds, _db_manager, computer)
        if not refs:
            return None

        list_rows = getattr(_db_manager, "list_row_policies", None)
        if callable(list_rows):
            pols = list_rows(enabled_only=True) or []
        else:
            # Test doubles without the listing API: wildcard-principal
            # sweep.  May UNDER-collect (specifically-bound policies) —
            # safe, see docstring.
            pols = _db_manager.find_applicable_policies(
                ["all:*"], None, "row") or []

        matching = [
            p for p in pols
            if p.get("enabled") is not False
            and any(table_matches_pattern(r, p.get("table_pattern", ""))
                    for r in refs)
        ]

        phys_to_col: Dict[str, Dict[str, Any]] = {}
        for c in (ds.get("columns") or []):
            key = str(c.get("physical_name") or "").strip().lower()
            if key and key not in phys_to_col:
                phys_to_col[key] = c

        col_ids: set = set()
        for p in matching:
            if str(p.get("enforcement") or "").lower() in ("native_lf", "view"):
                logger.info("[agg_cache] security-dims: opaque policy %r on "
                            "dataset %s — cube stays 'open'",
                            p.get("id"), ds.get("id"))
                return None
            tpl = str(p.get("filter_sql") or "").strip()
            if not tpl:
                continue
            cols = _template_columns(tpl)
            if cols is None:
                logger.info("[agg_cache] security-dims: policy %r template "
                            "unparseable — cube stays 'open'", p.get("id"))
                return None
            for name in cols:
                col = phys_to_col.get(name)
                if col is None:
                    logger.info("[agg_cache] security-dims: policy %r column "
                                "%r not modeled on dataset %s — cube stays "
                                "'open'", p.get("id"), name, ds.get("id"))
                    return None
                if col.get("column_type") not in ("dimension", "detail"):
                    logger.info("[agg_cache] security-dims: policy %r column "
                                "%r is a %s — grouping by it would change "
                                "predicate semantics; cube stays 'open'",
                                p.get("id"), name, col.get("column_type"))
                    return None
                col_ids.add(col["id"])
        return sorted(col_ids)
    except Exception as exc:
        logger.warning("[agg_cache] security-dimension extraction failed "
                       "(%s) — cube stays 'open'", exc)
        return None


# ═══════════════════════════════════════════════════════════════════════════════
# Phase 7 (2026-08-09) — candidate-source registry + customer pre-agg tables
# (target architecture §7 Phase 7; industry research §1 — BO aggregate
#  awareness / Power BI user-defined aggregations / Looker aggregate
#  awareness: transparent routing of a covered-grain query to a
#  pre-aggregated table the CUSTOMER owns.)
#
# The registry is the routing seam's plugin point (house pattern: one class
# + one _REGISTRY entry — FileFormatAdapter precedent).  The built-in
# parquet-cube logic stays inline in check_cache_hit / check_cache_hit_rls
# (byte-compatibility mandate); every OTHER backing registers here and
# competes on the same coarsest-grain rule.  Consumption is polymorphic
# (CacheHitResult.load_df / describe / sources_used) — never an if/elif on
# candidate kind.
#
# ★ THE GATE.  An ``AggregationAwareness`` row points at numbers QueryStudio
# does not control and cannot verify by construction.  Therefore a mapping
# NEVER serves until a verification probe has POSITIVELY passed:
#   * on registration (datasets_api runs the probe at create time);
#   * on a schedule (interval sweep registered in
#     register_scheduled_refreshes + TTL-based lazy re-verification at
#     routing time — a stale verdict stops serving until re-proven);
#   * probe = for each mapped measure, the grand total (the coarsest shared
#     grain, always shared) computed by rolling the agg table up
#     (SUM / SUM-of-counts / MIN / MAX) versus the same total computed LIVE
#     from raw via the federation engine.
# MISMATCH ⇒ the mapping is DISABLED (is_enabled=False, persisted) + an
# ERROR log carrying both numbers.  Probe error / unverifiable aggregation
# (avg, count_distinct — a rollup probe cannot certify them) ⇒ the mapping
# simply never serves (fail-closed) but the admin's row is left enabled so
# a later successful probe can activate it.  Trust is verified, not
# assumed.
#
# RLS (do not reopen what Phase 5 closed): under a resolved caller scope a
# customer table is INELIGIBLE unless every predicate column is one of the
# table's OWN rolled-up dimensions (the customer must have put the security
# columns there — MicroStrategy KB30711 / Power BI's "insecure to answer
# from the aggregation table if the RLS filter can't be applied").  The
# predicates are then applied as a WHERE at the table itself.  Every
# uncertainty is a MISS.
# ═══════════════════════════════════════════════════════════════════════════════

#: Aggregations a customer pre-agg table can serve.  The stored value is a
#: per-group rollup, so serving ALWAYS re-aggregates (GROUP BY requested
#: dims): sum→SUM, count→SUM (counts roll up as sums), min→MIN, max→MAX.
#: avg and count_distinct are NEVER servable from a customer table — they
#: neither compose nor can the grand-total probe verify them.
_AA_SERVABLE_AGGS = frozenset({"sum", "count", "min", "max"})
_AA_ROLLUP_FN = {"sum": "SUM", "count": "SUM", "min": "MIN", "max": "MAX"}

#: table / schema.table / db.schema.table — anything else is refused
#: (the reference is embedded in generated SQL).
_AA_TABLE_RE = re.compile(r"^[A-Za-z_][\w$]*(\.[A-Za-z_][\w$]*){0,2}$")

# Verification ledger — in-process, per-pod.  A mapping serves ONLY while a
# fresh positive verdict for its CURRENT definition (fingerprint) sits
# here; restarts and TTL expiry therefore force re-verification before the
# next serve.  The DISABLE on mismatch is persisted to the DB.
_AA_LEDGER: Dict[int, Dict[str, Any]] = {}
_AA_LEDGER_LOCK = threading.Lock()
_AA_VERIFY_INFLIGHT: set = set()

# Serve telemetry (in-process; AggregationAwareness has no counter columns).
_AA_TELEMETRY: Dict[str, Any] = {"serves": 0, "by_mapping": {}}
_AA_TELEMETRY_LOCK = threading.Lock()


def _aa_serving_enabled() -> bool:
    """Phase 7 rollout flag — ships OFF.  It changes the NUMBERS a report
    serves (to numbers from a table we do not control), so its unreadable-
    config fail mode is OFF."""
    try:
        from core import config
        return bool(config.get("agg_cache", "agg_awareness_serving_enabled",
                               False))
    except Exception:
        return False


def _aa_reverify_seconds() -> float:
    try:
        from core import config
        return max(1, int(config.get("agg_cache", "agg_awareness_reverify_hours",
                                     24))) * 3600.0
    except Exception:
        return 24 * 3600.0


def _aa_tolerance() -> float:
    try:
        from core import config
        return float(config.get("agg_cache", "agg_awareness_tolerance", 1e-6))
    except Exception:
        return 1e-6


def _aa_quote(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


def _aa_table_expr(agg_table: str) -> Tuple[str, bool]:
    """Return ``(from_expression, is_local_file)`` for an agg_table
    reference, or raise on anything that cannot be embedded safely."""
    t = str(agg_table or "").strip()
    if not t:
        raise ValueError("empty agg_table reference")
    if t.lower().endswith(".parquet"):
        if not os.path.isfile(t):
            raise ValueError(f"agg_table parquet not found: {t}")
        return "read_parquet('" + t.replace("'", "''") + "')", True
    if not _AA_TABLE_RE.match(t):
        raise ValueError(
            f"agg_table {t!r} is not a plain table reference "
            "(expected table, schema.table or db.schema.table)")
    return t, False


def _aa_fingerprint(row: Dict[str, Any]) -> str:
    """Definition fingerprint — a verdict is valid only for the exact
    mapping it was computed for (edits invalidate it)."""
    payload = json.dumps([
        str(row.get("agg_table") or ""),
        row.get("connection_id"),
        sorted(str(d).lower() for d in (row.get("agg_dimensions") or [])),
        row.get("measure_col_id"),
        row.get("dataset_id"),
    ], default=str)
    # usedforsecurity=False (2026-09-13 security-hotspot triage, ruff
    # S324): CONTENT-ADDRESSING, not a gate.  This names a mapping
    # DEFINITION so an edit invalidates its verdict; it never decides who
    # may read what, and its inputs are admin-authored agg mappings rather
    # than caller text.  A collision costs a stale verdict, which the next
    # recompute corrects.  The flag is also the FIPS fix (a FIPS-strict
    # image rejects unflagged SHA-1) and does not change the digest, so no
    # stored fingerprint moves.  The serve-key hashes that DO gate --
    # params_fingerprint / semantic_version -- were moved to SHA-256 the
    # same day; this one deliberately was not, because moving it would
    # invalidate every stored verdict for no security gain.
    return hashlib.sha1(payload.encode("utf-8"),
                        usedforsecurity=False).hexdigest()[:16]


class CandidateContext:
    """The request context a candidate source may inspect.
    ``requested_dims``/``requested_measures`` use the RLS-path shapes:
    ``[(col_id, physical_name)]`` / ``[(col_id, physical_name, agg_lower)]``
    (aggregation AFTER any per-request overrides — sources must judge what
    will actually be computed).  ``rls_open`` False + predicates carries a
    resolved caller scope; sources must refuse anything they cannot apply."""

    __slots__ = ("dataset_id", "dataset", "requested_dims",
                 "requested_measures", "filter_columns", "condition_ids",
                 "rls_predicates", "rls_open", "has_metrics")

    def __init__(self, *, dataset_id: int,
                 dataset: Optional[Dict[str, Any]],
                 requested_dims: Optional[List[Tuple[int, str]]],
                 requested_measures: Optional[List[Tuple[int, str, str]]],
                 filter_columns: Optional[List[str]],
                 condition_ids: Optional[List[int]],
                 rls_predicates: List[str],
                 rls_open: bool,
                 has_metrics: bool):
        self.dataset_id = dataset_id
        self.dataset = dataset
        self.requested_dims = requested_dims
        self.requested_measures = requested_measures
        self.filter_columns = filter_columns
        self.condition_ids = condition_ids
        self.rls_predicates = list(rls_predicates or [])
        self.rls_open = rls_open
        self.has_metrics = has_metrics


class AggTableHit(CacheHitResult):
    """A winning candidate whose backing is a customer-owned pre-aggregated
    TABLE, executed through the federation engine instead of read from a
    cached parquet.  Serving always re-aggregates (GROUP BY the requested
    dims) so a duplicate-grain table can never double-serve rows, and RLS
    predicates (already certified against the table's dimensions) apply as
    a WHERE at the table itself."""

    kind = "customer_agg_table"

    def __init__(self, *, dataset_id: int, aa_ids: List[int], agg_table: str,
                 connection_id: Optional[int], dims_phys: List[str],
                 measures: List[Tuple[str, str]], predicates: List[str],
                 grain_size: int):
        super().__init__(None, "", 0, 0.0, False, "agg_awareness")
        self.dataset_id = dataset_id
        self.aa_ids = list(aa_ids)
        self.agg_table = agg_table
        self.connection_id = connection_id
        self.dims_phys = list(dims_phys)
        self.measures = [(str(p), str(a or "").lower()) for p, a in measures]
        self.predicates = list(predicates)
        self.grain_size = int(grain_size)
        # Attributes the engine's secured-serve logging reads on any hit.
        self.rls_mode = "customer_agg"
        self.needs_regroup = False
        self.grouping_phys = list(dims_phys)

    def build_sql(self) -> str:
        expr, _is_file = _aa_table_expr(self.agg_table)
        sel = [_aa_quote(d) for d in self.dims_phys]
        for phys, agg in self.measures:
            fn = _AA_ROLLUP_FN.get(agg)
            if fn is None:
                # The eligibility gate refuses these; reaching here is a
                # programming error — fail loud (mapped to MISS upstream).
                raise ValueError(
                    f"measure {phys!r} agg {agg!r} is not servable from a "
                    "customer pre-aggregate table")
            sel.append(f"{fn}({_aa_quote(phys)}) AS {_aa_quote(phys)}")
        sql = f"SELECT {', '.join(sel)} FROM {expr}"
        if self.predicates:
            sql += " WHERE " + " AND ".join(f"({p})" for p in self.predicates)
        if self.dims_phys:
            sql += " GROUP BY " + ", ".join(_aa_quote(d) for d in self.dims_phys)
        return sql

    def load_df(self, *, execution_id: str = "",
                requested_dims: Optional[List[Tuple[int, str]]] = None,
                requested_measures: Optional[List[Tuple[int, str, str]]] = None,
                ) -> pd.DataFrame:
        eng = _federation_engine
        if eng is None:
            raise RuntimeError("agg_cache not initialised with a federation engine")
        sql = self.build_sql()
        _expr, is_file = _aa_table_expr(self.agg_table)
        exec_id = execution_id or f"agg_awareness_{uuid.uuid4().hex[:8]}"
        if is_file:
            return eng._execute_duckdb_plain(sql, exec_id)
        if self.connection_id is None:
            raise RuntimeError(
                f"agg_table {self.agg_table!r} has no connection and is not "
                "a local parquet — cannot execute")
        conn = _db_manager.get_connection_raw(self.connection_id)
        if not conn:
            raise RuntimeError(
                f"connection {self.connection_id} for agg_table "
                f"{self.agg_table!r} not found")
        if eng._get_connection_type(conn) == "s3":
            raise RuntimeError(
                "S3-backed agg tables are not supported by the serve path")
        return eng._execute_sql_connector(sql, {self.connection_id: conn},
                                          exec_id)

    def describe(self) -> str:
        return (f"-- Served from customer pre-aggregate table "
                f"(agg_table={self.agg_table}, mappings={self.aa_ids})")

    def sources_used(self) -> List[Dict[str, Any]]:
        return [{"type": "agg_awareness",
                 "agg_table": self.agg_table,
                 "aa_ids": list(self.aa_ids),
                 "connection_id": self.connection_id,
                 "rls_predicates_applied": len(self.predicates)}]

    def to_dict(self) -> Dict[str, Any]:
        d = super().to_dict()
        d.update({"kind": self.kind, "agg_table": self.agg_table,
                  "aa_ids": list(self.aa_ids),
                  "connection_id": self.connection_id})
        return d


class AggAwarenessTableSource:
    """Candidate source over ``AggregationAwareness`` rows.

    A candidate exists per (agg_table, connection_id) group when ALL of:
      * flag `agg_cache.agg_awareness_serving_enabled` ON (ships OFF);
      * full request context available (legacy callers without it get no
        external candidates — fail closed);
      * no calculated metrics, no pre-defined conditions (neither can be
        replicated against a foreign table);
      * every filter lands on a REQUESTED dimension (post-serve df
        filtering silently skips missing columns — that would be silent
        wrong numbers, so anything else is ineligible);
      * every requested measure is mapped to THIS table and its
        (override-resolved) aggregation is rollup-safe (sum/count/min/max);
      * requested dims ⊆ the table's rolled-up dimensions (grain covered —
        Power BI: below-grain "reverts to DirectQuery");
      * RLS: caller scope resolved open, OR every predicate parses and
        references only the table's dimensions (applied as WHERE);
      * ★ every mapped row has a FRESH POSITIVE verification verdict for
        its current definition; anything else triggers a background
        re-verification and MISSes now.
    """

    name = "customer_agg_table"

    def find_candidates(self, ctx: CandidateContext) -> List[AggTableHit]:
        if not _aa_serving_enabled():
            return []
        if (ctx.requested_dims is None or ctx.requested_measures is None
                or not ctx.requested_measures):
            return []
        if ctx.has_metrics:
            return []
        if ctx.condition_ids:
            return []
        if not ctx.rls_open and not ctx.rls_predicates:
            # Scoped caller whose predicates we were not handed — refuse.
            return []

        req_dim_phys = [str(p) for _, p in ctx.requested_dims]
        req_dim_lower = {p.lower() for p in req_dim_phys}
        for f in (ctx.filter_columns or []):
            if str(f).lower() not in req_dim_lower:
                return []

        rows = _db_manager.list_aggregation_awareness(ctx.dataset_id) or []
        groups: Dict[Tuple[str, Optional[int]], List[Dict[str, Any]]] = {}
        for r in rows:
            if not r.get("is_enabled"):
                continue
            groups.setdefault((str(r.get("agg_table") or ""),
                               r.get("connection_id")), []).append(r)

        out: List[AggTableHit] = []
        for (table, conn_id), grp in groups.items():
            mapped = {r["measure_col_id"]: r for r in grp}
            if not all(mcid in mapped
                       for mcid, _p, _a in ctx.requested_measures):
                continue

            # The table's dimension set: intersection across the mapped
            # rows for the requested measures (they describe one physical
            # table and should agree; intersection is the fail-closed read).
            dim_sets = [
                {str(d).lower() for d in
                 (mapped[mcid].get("agg_dimensions") or [])}
                for mcid, _p, _a in ctx.requested_measures
            ]
            table_dims_lower = set.intersection(*dim_sets) if dim_sets else set()
            if not req_dim_lower.issubset(table_dims_lower):
                continue

            if any((agg or "").lower() not in _AA_SERVABLE_AGGS
                   for _cid, _p, agg in ctx.requested_measures):
                continue

            # RLS predicate coverage — the whole Phase-5 rule, applied at
            # the customer's table.
            serve_preds: List[str] = []
            eligible = True
            for pred in ctx.rls_predicates:
                try:
                    serve_sql, pred_cols = _predicate_serve_form(pred)
                except Exception as exc:
                    logger.info("[agg_cache] agg_table %r: RLS predicate "
                                "ineligible (%s) — MISS", table, exc)
                    eligible = False
                    break
                if not set(pred_cols).issubset(table_dims_lower):
                    missing = sorted(set(pred_cols) - table_dims_lower)
                    logger.info("[agg_cache] agg_table %r: RLS predicate "
                                "references column(s) %s the table does not "
                                "roll up — INELIGIBLE (Phase-5 rule)",
                                table, missing)
                    eligible = False
                    break
                serve_preds.append(serve_sql)
            if not eligible:
                continue

            try:
                _aa_table_expr(table)
            except Exception as exc:
                logger.warning("[agg_cache] agg_table %r unusable: %s",
                               table, exc)
                continue

            # ★ THE GATE — no positive fresh verdict, no serve.
            if not all(_aa_is_serveable(mapped[mcid])
                       for mcid, _p, _a in ctx.requested_measures):
                continue

            out.append(AggTableHit(
                dataset_id=ctx.dataset_id,
                aa_ids=sorted(mapped[mcid]["id"]
                              for mcid, _p, _a in ctx.requested_measures),
                agg_table=table,
                connection_id=conn_id,
                dims_phys=req_dim_phys,
                measures=[(p, a) for _cid, p, a in ctx.requested_measures],
                predicates=serve_preds,
                grain_size=len(table_dims_lower),
            ))
        return out


#: The registry — plugin point for additional candidate backings.
_CANDIDATE_SOURCE_REGISTRY: Dict[str, Any] = {}


def register_candidate_source(source) -> None:
    _CANDIDATE_SOURCE_REGISTRY[source.name] = source


register_candidate_source(AggAwarenessTableSource())


def _best_registry_candidate(ctx: CandidateContext,
                             ) -> Tuple[Optional[CacheHitResult], Optional[int]]:
    """Collect candidates from every registered source; return the
    coarsest-grain one (and its grain) or ``(None, None)``.  A source
    failure silences that source only."""
    best: Optional[CacheHitResult] = None
    best_grain: Optional[int] = None
    for name, source in _CANDIDATE_SOURCE_REGISTRY.items():
        try:
            cands = source.find_candidates(ctx) or []
        except Exception as exc:
            logger.info("[agg_cache] candidate source %r failed (skipped): %s",
                        name, exc)
            continue
        for hit in cands:
            grain = int(getattr(hit, "grain_size", 1 << 30))
            if best_grain is None or grain < best_grain:
                best, best_grain = hit, grain
    return best, best_grain


def _record_aa_serve(hit) -> None:
    try:
        with _AA_TELEMETRY_LOCK:
            _AA_TELEMETRY["serves"] += 1
            for aa_id in getattr(hit, "aa_ids", []) or []:
                m = _AA_TELEMETRY["by_mapping"].setdefault(
                    aa_id, {"serves": 0, "last_served_at": None})
                m["serves"] += 1
                m["last_served_at"] = datetime.now(timezone.utc).isoformat()
    except Exception:
        pass


# ── Phase 7 verification (the gate itself) ──────────────────────────────────

def _aa_is_serveable(row: Dict[str, Any]) -> bool:
    """True only while a FRESH positive verdict for the row's CURRENT
    definition exists.  Anything else queues a background verification and
    refuses NOW (fail-closed: a wrong number must never reach a caller
    while trust is unproven)."""
    aa_id = row.get("id")
    if aa_id is None:
        return False
    with _AA_LEDGER_LOCK:
        rec = _AA_LEDGER.get(aa_id)
    if (rec and rec.get("status") == "verified"
            and rec.get("fingerprint") == _aa_fingerprint(row)
            and (time.time() - rec.get("checked_at", 0)) < _aa_reverify_seconds()):
        return True
    _trigger_background_aa_verify(aa_id)
    return False


def _trigger_background_aa_verify(aa_id: int) -> None:
    with _AA_LEDGER_LOCK:
        if aa_id in _AA_VERIFY_INFLIGHT:
            return
        _AA_VERIFY_INFLIGHT.add(aa_id)

    def _run():
        try:
            verify_agg_awareness(aa_id)
        except Exception as exc:                        # pragma: no cover
            logger.warning("[agg_cache] background verification of "
                           "agg-awareness %d failed: %s", aa_id, exc)
        finally:
            with _AA_LEDGER_LOCK:
                _AA_VERIFY_INFLIGHT.discard(aa_id)

    try:
        threading.Thread(target=_run, daemon=True,
                         name=f"aa_verify_{aa_id}").start()
    except Exception:
        with _AA_LEDGER_LOCK:
            _AA_VERIFY_INFLIGHT.discard(aa_id)


def _aa_norm_value(v) -> Optional[float]:
    if v is None:
        return None
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    if math.isnan(f):
        return None
    return f


def _aa_values_match(raw_value, agg_value, rel_tol: float) -> bool:
    a = _aa_norm_value(raw_value)
    b = _aa_norm_value(agg_value)
    if a is None and b is None:
        return True
    if a is None or b is None:
        # SUM over an empty relation is NULL on some engines and 0 on a
        # customer table with a zero row — accept NULL≈0, nothing else.
        other = b if a is None else a
        return other == 0.0
    return math.isclose(a, b, rel_tol=rel_tol, abs_tol=1e-9)


def _aa_probe_agg_side(row: Dict[str, Any], measure_phys: str,
                       agg: str) -> Any:
    """Grand-total probe over the CUSTOMER's table, rolled up with the
    measure's rollup function (counts roll up as SUM)."""
    eng = _federation_engine
    if eng is None:
        raise RuntimeError("agg_cache not initialised with a federation engine")
    fn = _AA_ROLLUP_FN[agg]
    expr, is_file = _aa_table_expr(row.get("agg_table"))
    sql = f"SELECT {fn}({_aa_quote(measure_phys)}) AS probe_value FROM {expr}"
    exec_id = f"aa_verify_agg_{row.get('id')}_{uuid.uuid4().hex[:6]}"
    if is_file:
        df = eng._execute_duckdb_plain(sql, exec_id)
    else:
        conn_id = row.get("connection_id")
        if conn_id is None:
            raise RuntimeError(
                f"agg_table {row.get('agg_table')!r} has no connection and "
                "is not a local parquet")
        conn = _db_manager.get_connection_raw(conn_id)
        if not conn:
            raise RuntimeError(f"connection {conn_id} not found")
        if eng._get_connection_type(conn) == "s3":
            raise RuntimeError("S3-backed agg tables are not supported")
        df = eng._execute_sql_connector(sql, {conn_id: conn}, exec_id)
    if df is None or len(df) == 0:
        return None
    return df.iloc[0, 0]


def _aa_probe_raw_side(row: Dict[str, Any]) -> Any:
    """The SAME total computed live from raw, through the standard dataset
    path (measure only, no dims ⇒ grand total; no user_ctx ⇒ unscoped, the
    correct basis for comparing against an unscoped customer table).  With
    no dimensions requested, every cache path inside is skipped by
    construction — the probe can never be answered by the thing it is
    checking."""
    eng = _federation_engine
    if eng is None:
        raise RuntimeError("agg_cache not initialised with a federation engine")
    result = eng.execute_dataset_query(
        dataset_id=row["dataset_id"],
        column_ids=[row["measure_col_id"]],
        limit=10,
        execution_id=f"aa_verify_raw_{row.get('id')}_{uuid.uuid4().hex[:6]}",
        user_role="admin",
        user_ctx=None,
    )
    if not result.output_path or not os.path.isfile(result.output_path):
        raise RuntimeError("raw-side probe returned no output file")
    try:
        df = pd.read_parquet(result.output_path)
        return df.iloc[0, 0] if len(df) else None
    finally:
        try:
            os.remove(result.output_path)
        except OSError:
            pass


def verify_agg_awareness(aa_id: int) -> Dict[str, Any]:
    """★ THE GATE.  Verify one mapping's agg table against raw at the
    coarsest shared grain (the grand total of the mapped measure).

    Verdicts (all recorded in the in-process ledger; only "verified"
    permits serving):
      * ``verified``     — totals agree (within relative tolerance).
      * ``failed``       — totals DISAGREE ⇒ ``is_enabled=False`` is
                           PERSISTED and an ERROR log carries both numbers.
                           A wrong table must never serve again silently.
      * ``unverifiable`` — the measure's aggregation (avg/count_distinct/
                           unknown) cannot be certified by a rollup probe ⇒
                           never serves; the row stays enabled for the
                           admin to fix.
      * ``error``        — a probe failed (connection down, bad column…) ⇒
                           never serves; row stays enabled; re-tried on the
                           next sweep / routing touch.
    """
    if not _db_manager:
        return {"id": aa_id, "status": "error", "detail": "db not initialised"}
    row = _db_manager.get_aggregation_awareness(aa_id)
    if not row:
        return {"id": aa_id, "status": "error", "detail": "mapping not found"}

    fingerprint = _aa_fingerprint(row)

    def _ledger(status: str, detail: str = "", **extra) -> Dict[str, Any]:
        rec = {"status": status, "detail": detail,
               "checked_at": time.time(),
               "checked_at_iso": datetime.now(timezone.utc).isoformat(),
               "fingerprint": fingerprint,
               "agg_table": row.get("agg_table"), **extra}
        with _AA_LEDGER_LOCK:
            _AA_LEDGER[aa_id] = rec
        return {"id": aa_id, **rec}

    ds = _db_manager.get_dataset_full(row["dataset_id"])
    if not ds:
        return _ledger("error", f"dataset {row['dataset_id']} not found")
    col = next((c for c in (ds.get("columns") or [])
                if c.get("id") == row.get("measure_col_id")), None)
    if col is None or not col.get("physical_name"):
        return _ledger("error",
                       f"measure column {row.get('measure_col_id')} not "
                       "modeled on the dataset")

    agg = str(col.get("aggregation") or "sum").lower()
    if agg not in _AA_SERVABLE_AGGS:
        rec = _ledger("unverifiable",
                      f"aggregation {agg!r} cannot be certified by a rollup "
                      "probe — mapping will never serve")
        logger.warning("[agg_cache] agg-awareness %d (%s → %s): %s",
                       aa_id, col["physical_name"], row.get("agg_table"),
                       rec["detail"])
        return rec

    try:
        agg_value = _aa_probe_agg_side(row, col["physical_name"], agg)
        raw_value = _aa_probe_raw_side(row)
    except Exception as exc:
        rec = _ledger("error", f"probe failed: {exc}")
        logger.warning("[agg_cache] agg-awareness %d verification errored "
                       "(mapping will not serve): %s", aa_id, exc)
        return rec

    if _aa_values_match(raw_value, agg_value, _aa_tolerance()):
        rec = _ledger("verified", "totals agree",
                      raw_value=_aa_norm_value(raw_value),
                      agg_value=_aa_norm_value(agg_value))
        logger.info("[agg_cache] agg-awareness %d VERIFIED: %s(%s) raw=%s "
                    "agg_table=%s value=%s", aa_id, agg,
                    col["physical_name"], raw_value, row.get("agg_table"),
                    agg_value)
        return rec

    # ── MISMATCH — disable loudly and persistently. ──────────────────────
    rec = _ledger("failed",
                  "agg table disagrees with raw at the probe grain",
                  raw_value=_aa_norm_value(raw_value),
                  agg_value=_aa_norm_value(agg_value))
    try:
        _db_manager.update_aggregation_awareness(aa_id, is_enabled=False)
    except Exception as exc:                            # pragma: no cover
        logger.error("[agg_cache] could not persist disable for "
                     "agg-awareness %d: %s", aa_id, exc)
    logger.error(
        "[agg_cache] ★ AGG-AWARENESS VERIFICATION FAILED — mapping %d "
        "DISABLED.  Measure %s (%s) over agg_table=%r returns %s but raw "
        "returns %s.  A pre-aggregate that disagrees with raw would "
        "silently serve wrong numbers to every routed report; it will not "
        "serve again until fixed, re-enabled and re-verified.",
        aa_id, col["physical_name"], agg, row.get("agg_table"),
        agg_value, raw_value)
    return rec


def verify_all_agg_awareness() -> Dict[str, Any]:
    """Scheduled sweep — re-verify every ENABLED mapping.  Registered as an
    interval job by :func:`register_scheduled_refreshes`; also invocable
    from the admin API."""
    if not _db_manager:
        return {"checked": 0}
    try:
        rows = _db_manager.list_aggregation_awareness() or []
    except Exception as exc:
        logger.warning("[agg_cache] agg-awareness sweep listing failed: %s", exc)
        return {"checked": 0, "error": str(exc)}
    summary = {"checked": 0, "verified": 0, "failed": 0,
               "unverifiable": 0, "error": 0}
    for row in rows:
        if not row.get("is_enabled"):
            continue
        verdict = verify_agg_awareness(row["id"])
        summary["checked"] += 1
        summary[verdict.get("status", "error")] = \
            summary.get(verdict.get("status", "error"), 0) + 1
    if summary["checked"]:
        logger.info("[agg_cache] agg-awareness verification sweep: %s", summary)
    return summary


def get_agg_awareness_status(dataset_id: Optional[int] = None) -> Dict[str, Any]:
    """Admin-screen payload: every mapping with its live verification
    verdict and serve telemetry."""
    if not _db_manager:
        return {"mappings": [], "serving_enabled": False}
    rows = _db_manager.list_aggregation_awareness(dataset_id) or []
    with _AA_LEDGER_LOCK:
        ledger = {k: dict(v) for k, v in _AA_LEDGER.items()}
    with _AA_TELEMETRY_LOCK:
        telem = {k: dict(v) for k, v in _AA_TELEMETRY["by_mapping"].items()}
        total_serves = _AA_TELEMETRY["serves"]
    for r in rows:
        rec = ledger.get(r["id"])
        if rec and rec.get("fingerprint") != _aa_fingerprint(r):
            rec = None      # verdict is for an older definition
        r["verification"] = rec or {"status": "unverified"}
        r["serves"] = telem.get(r["id"], {}).get("serves", 0)
        r["last_served_at"] = telem.get(r["id"], {}).get("last_served_at")
    return {
        "mappings": rows,
        "serving_enabled": _aa_serving_enabled(),
        "reverify_hours": _aa_reverify_seconds() / 3600.0,
        "total_serves": total_serves,
    }


def reset_agg_awareness_state_for_tests() -> None:
    with _AA_LEDGER_LOCK:
        _AA_LEDGER.clear()
        _AA_VERIFY_INFLIGHT.clear()
    with _AA_TELEMETRY_LOCK:
        _AA_TELEMETRY["serves"] = 0
        _AA_TELEMETRY["by_mapping"] = {}


# ═══════════════════════════════════════════════════════════════════════════════
# Cache Building — Power BI Import + Tableau Extract
# ═══════════════════════════════════════════════════════════════════════════════

def build_cache_entry(entry_id: int, force: bool = False) -> bool:
    """Build (or rebuild) a single aggregation cache entry.

    1. Lock to prevent concurrent builds of the same entry
    2. Load entry + dataset metadata from DB
    3. Execute aggregation query via FederationEngine
    4. For incremental: merge new data with existing parquet (dedup on dims)
    5. Save parquet to cache dir
    6. Update entry: status=ready, file_path, timestamps, TTL

    Returns True on success, False on failure.
    """
    if not _db_manager or not _federation_engine:
        logger.warning("[agg_cache] Not initialised — cannot build entry %d", entry_id)
        return False

    # Acquire per-entry lock to prevent duplicate concurrent builds
    lock = _get_entry_lock(entry_id)
    if not lock.acquire(blocking=False):
        logger.info("[agg_cache] Build already in progress for entry %d", entry_id)
        return False

    try:
        return _build_cache_entry_locked(entry_id, force)
    finally:
        lock.release()


def _build_cache_entry_locked(entry_id: int, force: bool) -> bool:
    """Internal build logic (called while holding the entry lock)."""
    from core import config

    entry = _db_manager.get_agg_cache_entry(entry_id)
    if not entry:
        logger.warning("[agg_cache] Entry %d not found", entry_id)
        return False

    if not entry.get("is_enabled") and not force:
        logger.info("[agg_cache] Entry %d is disabled, skipping build", entry_id)
        return False

    # Skip if already ready and not forced and not stale/expired
    if entry["status"] == "ready" and not force:
        stale_at = entry.get("stale_at")
        if stale_at:
            stale_dt = _parse_dt(stale_at)
            if datetime.now(timezone.utc) < stale_dt:
                logger.debug("[agg_cache] Entry %d is fresh, skipping build", entry_id)
                return True

    dataset_id = entry["dataset_id"]
    ds = _db_manager.get_dataset_full(dataset_id)
    if not ds:
        _db_manager.update_agg_cache_entry(entry_id, status="failed",
                                            error_message="Dataset not found")
        return False

    # Mark as building
    _db_manager.update_agg_cache_entry(entry_id, status="building", error_message=None)

    t_start = time.monotonic()

    try:
        all_columns = ds.get("columns", [])
        col_map = {c["id"]: c for c in all_columns}

        dim_col_ids = entry.get("dimension_col_ids") or []
        measure_col_ids = entry.get("measure_col_ids") or []

        dim_cols = [col_map[cid] for cid in dim_col_ids if cid in col_map]
        measure_cols = [col_map[cid] for cid in measure_col_ids if cid in col_map]

        if not dim_cols and not measure_cols:
            raise ValueError("No valid dimension or measure columns for cache entry")

        # Phase 5 RLS-aware cubes (2026-08-09, target architecture §3.3):
        # when the serve flag is ON and row security is enabled, bake the
        # policy-referenced columns into the cube's grain (MicroStrategy
        # KB30711: the security-filter attribute must be PRESENT in the
        # cube) and emit SUM/COUNT pairs for avg measures so averages
        # re-aggregate exactly (Power BI's decomposition).  The policy
        # fingerprint the cube was built under is stamped for the
        # serve-time drift gate.  Any uncertainty ⇒ the cube is built
        # exactly as today and marked 'open' (never served to scoped
        # callers).  Flag OFF ⇒ this whole block is inert and the fields
        # are reset to NULL (metadata stays truthful to the parquet).
        rls_mode: Optional[str] = None
        rls_policy_version: Optional[str] = None
        sec_dim_ids: List[int] = []
        decompose_avg = False
        if _rls_feature_enabled() and _row_security_enabled():
            sec = _compute_security_dimensions(ds)
            if sec is None:
                rls_mode = "open"
            else:
                try:
                    rls_policy_version = _current_policy_fingerprint()
                    rls_mode = "security_dims"
                    sec_dim_ids = [cid for cid in sec if cid in col_map]
                    decompose_avg = True
                except Exception as _fp_exc:
                    logger.warning("[agg_cache] policy fingerprint unavailable "
                                   "at build (%s) — entry %d stays 'open'",
                                   _fp_exc, entry_id)
                    rls_mode = "open"
                    rls_policy_version = None
                    sec_dim_ids = []
        # Security columns not already in the requestable dims join the
        # GROUP BY (they stay OUT of dimension_col_ids — routing semantics
        # unchanged; the secured path groups over the union).
        sec_extra_ids = [cid for cid in sec_dim_ids if cid not in set(dim_col_ids)]
        sec_extra_cols = [col_map[cid] for cid in sec_extra_ids]

        # Build the aggregation SQL
        sql = _build_aggregation_sql(
            dataset=ds,
            dimension_cols=dim_cols,
            measure_cols=measure_cols,
            condition_ids=entry.get("condition_ids") or [],
            incremental_column=entry.get("incremental_column") if entry.get("incremental_enabled") else None,
            incremental_last_value=entry.get("incremental_last_value"),
            security_dimension_cols=sec_extra_cols,
            decompose_avg=decompose_avg,
        )

        logger.info("[agg_cache] Building entry %d (dataset %d): %s",
                     entry_id, dataset_id, sql[:200])

        # Execute via federation engine (leverages DuckDB named secrets, connections)
        build_exec_id = f"agg_cache_{entry_id}_{uuid.uuid4().hex[:8]}"
        result = _federation_engine.execute_dataset_query(
            dataset_id=dataset_id,
            column_ids=dim_col_ids + sec_extra_ids + measure_col_ids,
            condition_ids=entry.get("condition_ids") or [],
            limit=config.federation.max_result_rows,
            execution_id=build_exec_id,
            user_role="admin",
            decompose_avg=decompose_avg,
        )

        if not result.output_path or not os.path.isfile(result.output_path):
            raise RuntimeError("Federation engine returned no output file")

        # 2026-08-20 — a BUILD is a CORRECTNESS GATE, not a delivery: a cube
        # is served later as COMPLETE, so a build result cut at any limit
        # must REFUSE, never persist.  federation.max_result_rows is an
        # interactive-delivery throttle (ships 0 = unlimited); an operator
        # who sets it would otherwise turn every rebuild into a silent
        # partial aggregate.  The engine stamps the EFFECTIVE limit on the
        # result (row_limit) and an explicit verdict when it has one
        # (truncated); total_rows >= row_limit is the same "limit hit" test
        # the disclosure path uses — at exactly-the-limit we cannot know the
        # result is complete, so we refuse there too.
        _eff_limit = getattr(result, "row_limit", None)
        _truncated = getattr(result, "truncated", None)
        if _truncated or (_eff_limit and _eff_limit > 0
                          and result.total_rows >= _eff_limit):
            raise RuntimeError(
                f"cube build was cut at {result.total_rows} rows "
                f"(effective row limit {_eff_limit}, truncated={_truncated}) "
                f"— refusing to persist a partial aggregate as a complete "
                f"cube. federation.max_result_rows is an interactive "
                f"throttle; set it <= 0 to let cube builds run unbounded.")

        ds_cache_dir = _cache_dir / str(dataset_id)
        ds_cache_dir.mkdir(parents=True, exist_ok=True)
        cache_path = str(ds_cache_dir / f"entry_{entry_id}.parquet")

        # Phase 154 strategic chokepoint -- agg-cache save path.
        # Non-incremental: federation_engine already wrote the parquet
        # via the bounded streaming chokepoint; cache save is just a
        # file copy (zero DataFrame load).  Incremental: load + merge
        # is intrinsic (pandas merge needs both sides in memory), then
        # write via the bounded streaming writer.
        is_incremental = (entry.get("incremental_enabled")
                          and entry.get("file_path")
                          and os.path.isfile(entry["file_path"]))
        if is_incremental:
            df = pd.read_parquet(result.output_path)
            # Security dims are part of the grain — dedup must include them
            # or an incremental merge would collapse distinct scope rows.
            dim_phys = [c["physical_name"] for c in dim_cols + sec_extra_cols]
            df = _merge_incremental(entry["file_path"], df, dim_phys)
            from core.connector_to_parquet import df_to_parquet_streaming
            df_to_parquet_streaming(df, cache_path, compression="snappy")
            row_count = len(df)
        else:
            # Fast path -- direct file copy avoids loading the entire
            # federation result into memory just to save it elsewhere.
            #
            # 2026-06-25 zero-risk audit: shutil.copyfile raises
            # SameFileError when src and dst resolve to the same path.
            # That can happen if federation_engine ever writes directly
            # into the agg_cache dir (current paths differ -- downloads
            # vs agg_cache -- but no invariant forbids future overlap).
            # Guard with os.path.samefile so the build still succeeds.
            import shutil
            try:
                _same_file = (
                    os.path.exists(cache_path)
                    and os.path.samefile(result.output_path, cache_path)
                )
            except OSError:
                _same_file = False
            if not _same_file:
                shutil.copyfile(result.output_path, cache_path)
            # Row count via parquet metadata -- no full materialisation.
            import pyarrow.parquet as _pq_meta
            row_count = _pq_meta.ParquetFile(cache_path).metadata.num_rows
            df = None

        file_size = os.path.getsize(cache_path)
        duration = time.monotonic() - t_start

        # Compute TTL timestamps
        now = datetime.now(timezone.utc)
        ttl_hours = config.agg_cache.default_ttl_hours
        hard_hours = config.agg_cache.hard_expiry_hours
        stale_at = now + timedelta(hours=ttl_hours)
        expires_at = now + timedelta(hours=hard_hours)

        # Determine new incremental_last_value
        inc_last = entry.get("incremental_last_value")
        if (entry.get("incremental_enabled")
                and entry.get("incremental_column")
                and df is not None):
            inc_col = entry["incremental_column"]
            if inc_col in df.columns and len(df) > 0:
                inc_last = str(df[inc_col].max())

        _db_manager.update_agg_cache_entry(entry_id,
            status="ready",
            file_path=cache_path,
            file_size_bytes=file_size,
            row_count=row_count,
            last_built_at=now,
            stale_at=stale_at,
            expires_at=expires_at,
            build_duration_seconds=round(duration, 3),
            error_message=None,
            incremental_last_value=inc_last,
            # Phase 5: metadata stays truthful to THIS parquet — flag off
            # (or RLS off) resets the fields, so a cube rebuilt without the
            # security grain can never be mistaken for one that has it.
            rls_mode=rls_mode,
            security_dimension_col_ids=sec_dim_ids,
            policy_version=rls_policy_version,
            rls_signature=None,
        )

        # Clean up temporary federation output
        try:
            if result.output_path != cache_path and os.path.isfile(result.output_path):
                os.remove(result.output_path)
        except OSError:
            pass

        logger.info("[agg_cache] Entry %d built: %d rows, %.1fs, %s",
                     entry_id, row_count, duration,
                     _fmt_size(file_size))
        return True

    except Exception as exc:
        duration = time.monotonic() - t_start
        logger.error("[agg_cache] Build failed for entry %d: %s", entry_id, exc)
        _db_manager.update_agg_cache_entry(entry_id,
            status="failed",
            error_message=str(exc)[:2000],
            build_duration_seconds=round(duration, 3),
        )
        return False


def _build_aggregation_sql(
    dataset: Dict[str, Any],
    dimension_cols: List[Dict[str, Any]],
    measure_cols: List[Dict[str, Any]],
    condition_ids: List[int] = None,
    incremental_column: str = None,
    incremental_last_value: str = None,
    security_dimension_cols: List[Dict[str, Any]] = None,
    decompose_avg: bool = False,
) -> str:
    """Generate aggregation SQL for a cache entry.

    SELECT dim1, dim2, SUM(measure1) AS measure1, AVG(measure2) AS measure2
    FROM <source>
    [WHERE incremental_col > last_value]
    [AND pre-defined conditions]
    GROUP BY dim1, dim2

    Phase 5 (2026-08-09): ``security_dimension_cols`` join the SELECT and
    GROUP BY (policy-referenced columns baked into the grain); with
    ``decompose_avg`` every avg measure ADDITIONALLY emits
    ``SUM(x) AS x__sum, COUNT(x) AS x__cnt`` so the average re-aggregates
    exactly at serve time (an AVG cannot be re-derived from stored
    averages — Power BI's documented decomposition).
    """
    from core.federation_engine import VALID_AGGREGATIONS

    select_parts = []
    group_by_parts = []

    # Dimensions (security dimensions are part of the grain)
    for col in list(dimension_cols) + list(security_dimension_cols or []):
        phys = f'"{col["physical_name"]}"'
        if phys in group_by_parts:
            continue
        select_parts.append(phys)
        group_by_parts.append(phys)

    # Measures with aggregation
    for col in measure_cols:
        phys = f'"{col["physical_name"]}"'
        agg = (col.get("aggregation") or "SUM").upper()
        if agg not in VALID_AGGREGATIONS:
            agg = "SUM"
        if agg == "COUNT_DISTINCT":
            select_parts.append(f"COUNT(DISTINCT {phys}) AS {phys}")
        else:
            select_parts.append(f"{agg}({phys}) AS {phys}")
            if agg == "AVG" and decompose_avg:
                base = col["physical_name"]
                select_parts.append(
                    f'SUM({phys}) AS "{base}{_AVG_SUM_SUFFIX}"')
                select_parts.append(
                    f'COUNT({phys}) AS "{base}{_AVG_CNT_SUFFIX}"')

    if not select_parts:
        raise ValueError("No columns to select for aggregation cache")

    # WHERE clauses
    where_parts = []

    # Incremental filter
    if incremental_column and incremental_last_value:
        where_parts.append(f'"{incremental_column}" > \'{incremental_last_value}\'')

    # Pre-defined conditions
    if condition_ids:
        conditions = dataset.get("conditions", [])
        for cond in conditions:
            if cond.get("id") in condition_ids and cond.get("where_clause"):
                where_parts.append(f"({cond['where_clause']})")

    # Build final SQL (the federation engine will wrap this as needed)
    sql = f"SELECT {', '.join(select_parts)}"
    if where_parts:
        sql += f" WHERE {' AND '.join(where_parts)}"
    if group_by_parts:
        sql += f" GROUP BY {', '.join(group_by_parts)}"

    return sql


def _merge_incremental(existing_path: str, new_df: pd.DataFrame,
                       dimension_cols: List[str]) -> pd.DataFrame:
    """Merge incremental refresh data with existing cache.

    New data replaces old for matching dimension keys; new rows are appended.

    2026-08-20 — this merge FAILS LOUD instead of degrading.  It used to
    ``except -> return new_df``: one unreadable parquet or one missing
    dimension column and the cube quietly became "this increment only",
    then got marked built with row_count=len(new_df) and served as
    complete.  A raise here fails the BUILD (entry -> 'failed', the old
    parquet stays in place and keeps serving until it expires) — the
    correct degradation for a correctness gate.
    """
    existing_df = pd.read_parquet(existing_path)   # unreadable => build fails

    if not dimension_cols:
        # Grain-less cube (global aggregate): the increment is an aggregate
        # of NEW rows only — there is no key to merge on and no agg metadata
        # here to compose with, so any "merge" is a wrong number.
        raise ValueError(
            "incremental merge requires dimension columns — a grain-less "
            "aggregate cannot compose with an increment; disable "
            "incremental_enabled for this entry or add dimensions")

    missing_old = [c for c in dimension_cols if c not in existing_df.columns]
    missing_new = [c for c in dimension_cols if c not in new_df.columns]
    if missing_old or missing_new:
        raise ValueError(
            f"incremental merge dimension column(s) missing — existing cube "
            f"lacks {missing_old}, increment lacks {missing_new}; the entry "
            f"definition and its parquet have drifted, refusing to merge")

    if set(existing_df.columns) != set(new_df.columns):
        raise ValueError(
            f"incremental merge schema drift — existing cube columns "
            f"{sorted(existing_df.columns)} != increment columns "
            f"{sorted(new_df.columns)}; a merge would fabricate or drop "
            f"columns, refusing")

    # The dedup below keeps ONE row per dimension key.  If either side
    # carries duplicate keys, the passed grain is NARROWER than the data's
    # real grain and drop_duplicates would collapse distinct rows into an
    # arbitrary survivor — silent row loss dressed as a merge.
    if existing_df.duplicated(subset=dimension_cols).any():
        raise ValueError(
            f"incremental merge grain mismatch — existing cube has multiple "
            f"rows per key {dimension_cols}; its real grain is finer than "
            f"the merge key, a dedup would collapse distinct rows")
    if new_df.duplicated(subset=dimension_cols).any():
        raise ValueError(
            f"incremental merge grain mismatch — increment has multiple "
            f"rows per key {dimension_cols}")

    # Concat and deduplicate, keeping new data
    combined = pd.concat([existing_df, new_df], ignore_index=True)
    combined = combined.drop_duplicates(subset=dimension_cols, keep="last")
    return combined


def _trigger_background_refresh(entry_id: int) -> None:
    """Schedule a non-blocking background refresh for a stale cache entry."""
    try:
        t = threading.Thread(
            target=build_cache_entry,
            args=(entry_id, True),
            name=f"agg_cache_refresh_{entry_id}",
            daemon=True,
        )
        t.start()
        logger.info("[agg_cache] Background refresh triggered for entry %d", entry_id)
    except Exception as exc:
        logger.warning("[agg_cache] Failed to trigger background refresh for %d: %s",
                       entry_id, exc)


# ═══════════════════════════════════════════════════════════════════════════════
# Usage Analysis — Power BI Auto-Aggregations
# ═══════════════════════════════════════════════════════════════════════════════

def _collect_usage_patterns(dataset_id: int = None) -> List[Dict[str, Any]]:
    """Phase 6 (2026-08-09) — SHARED derivation of (dataset, grain) usage
    patterns from REAL execution history.  One derivation feeds both the
    suggestion persister (:func:`analyze_usage_patterns`) and the ranked
    recommendation surface (:func:`get_cube_recommendations`) so they can
    never drift apart.

    What "real" means here:
      * only ``status='completed'`` executions inside the analysis window;
      * executions already answered by a cache (sources_used carries
        ``agg_cache`` / ``agg_awareness``) are EXCLUDED — their duration
        measures the cache, not the live cost a cube would save;
      * the fetch depth is a config knob
        (``agg_cache.recommendation_history_limit``, default 2000) — the
        old implicit LIMIT 50 silently analysed only the last 50 runs.

    Benefit metric (the ranking key): ``query_count × avg live duration``
    = total live seconds this pattern burned in the window — the measured
    stand-in for "rows scanned saved" (FederationExecution does not record
    scanned rows; ``total_rows`` is RESULT rows, which for aggregate
    queries is tiny precisely when the scan is biggest, so duration is the
    honest proxy).  ``rows_returned_total`` is reported alongside.
    """
    if not _db_manager:
        return []
    from core import config
    window_days = config.agg_cache.suggestion_analysis_window_days
    fetch_limit = int(config.get("agg_cache", "recommendation_history_limit",
                                 2000))
    cutoff = datetime.now(timezone.utc) - timedelta(days=window_days)

    all_execs = _db_manager.list_federation_executions(limit=fetch_limit)
    recent = []
    for e in all_execs:
        if e.get("status") != "completed":
            continue
        if not e.get("created_at") or _parse_dt(e["created_at"]) < cutoff:
            continue
        srcs = e.get("sources_used") or []
        if any(isinstance(s, dict)
               and s.get("type") in ("agg_cache", "agg_awareness")
               for s in srcs):
            continue
        recent.append(e)
    if dataset_id is not None:
        recent = [e for e in recent if e.get("dataset_id") == dataset_id]

    pattern_groups: Dict[Tuple, List[Dict]] = {}
    for ex in recent:
        key = (ex.get("dataset_id"), tuple(sorted(ex.get("column_ids") or [])))
        pattern_groups.setdefault(key, []).append(ex)

    ds_cache: Dict[int, Dict[str, Any]] = {}
    entries_cache: Dict[int, List[Dict[str, Any]]] = {}
    sugg_cache: Dict[int, List[Dict[str, Any]]] = {}
    patterns: List[Dict[str, Any]] = []

    for (ds_id, col_ids), executions in pattern_groups.items():
        if ds_id is None or not col_ids:
            continue
        ds = ds_cache.get(ds_id)
        if ds is None:
            ds = _db_manager.get_dataset_full(ds_id)
            if not ds:
                continue
            ds_cache[ds_id] = ds

        col_map = {c["id"]: c for c in ds.get("columns", [])}
        dim_ids, measure_ids = [], []
        for cid in col_ids:
            col = col_map.get(cid)
            if not col:
                continue
            if col.get("column_type") in ("dimension", "detail"):
                dim_ids.append(cid)
            elif (col.get("column_type") in ("measure", "kpi")
                    and col.get("aggregation")):
                measure_ids.append(cid)
        if not dim_ids or not measure_ids:
            continue

        # Coverage — an existing entry already answers this pattern.
        if ds_id not in entries_cache:
            entries_cache[ds_id] = _db_manager.list_agg_cache_entries(
                dataset_id=ds_id) or []
        req_dims, req_measures = set(dim_ids), set(measure_ids)
        # 2026-08-20: dims compare by EQUALITY, mirroring check_cache_hit —
        # a finer-grain entry no longer serves this pattern, so it must not
        # suppress the suggestion either.  Measures stay subset (extra
        # measures in an entry never hurt serving).
        already_covered = any(
            req_measures.issubset(set(ent.get("measure_col_ids") or []))
            and req_dims == set(ent.get("dimension_col_ids") or [])
            for ent in entries_cache[ds_id]
        )

        # An actionable suggestion row, if one exists (rejected ones do not
        # block re-suggestion — pre-existing semantics, preserved).
        if ds_id not in sugg_cache:
            sugg_cache[ds_id] = _db_manager.list_agg_cache_suggestions(
                dataset_id=ds_id) or []
        suggestion = next(
            (s for s in sugg_cache[ds_id]
             if set(s.get("dimension_col_ids") or []) == req_dims
             and set(s.get("measure_col_ids") or []) == req_measures
             and s.get("status") in ("pending", "approved", "implemented")),
            None)

        durations = [float(e.get("duration_seconds") or 0.0)
                     for e in executions]
        avg_duration = sum(durations) / len(executions) if executions else 0.0
        last_at = max((e.get("created_at") for e in executions
                       if e.get("created_at")), default=None)

        patterns.append({
            "dataset_id": ds_id,
            "dataset_name": ds.get("name", ""),
            "dimension_col_ids": sorted(dim_ids),
            "measure_col_ids": sorted(measure_ids),
            "dimension_names": [col_map[c].get("physical_name")
                                for c in sorted(dim_ids)],
            "measure_names": [col_map[c].get("physical_name")
                              for c in sorted(measure_ids)],
            "query_count": len(executions),
            "avg_duration_seconds": round(avg_duration, 3),
            "benefit_seconds_per_window": round(sum(durations), 3),
            "rows_returned_total": sum(int(e.get("total_rows") or 0)
                                       for e in executions),
            "last_executed_at": last_at,
            "already_covered": already_covered,
            "suggestion": suggestion,
        })
    return patterns


def analyze_usage_patterns(dataset_id: int = None) -> List[Dict[str, Any]]:
    """Analyze FederationExecution history to find frequently-used patterns
    and PERSIST them as :class:`AggCacheSuggestion` rows an admin can act
    on.  Derivation is shared with :func:`get_cube_recommendations` via
    :func:`_collect_usage_patterns`."""
    if not _db_manager:
        return []

    from core import config
    if not config.agg_cache.suggestion_enabled:
        return []

    min_queries = config.agg_cache.suggestion_min_queries
    new_suggestions = []
    for p in _collect_usage_patterns(dataset_id):
        if p["query_count"] < min_queries:
            continue
        if p["already_covered"] or p["suggestion"] is not None:
            continue
        avg_duration = p["avg_duration_seconds"]
        estimated_speedup = (round(avg_duration / 0.1, 1)
                             if avg_duration > 0.1 else 1.0)
        suggestion = _db_manager.create_agg_cache_suggestion(
            dataset_id=p["dataset_id"],
            dimension_col_ids=p["dimension_col_ids"],
            measure_col_ids=p["measure_col_ids"],
            query_count=p["query_count"],
            estimated_speedup=estimated_speedup,
        )
        new_suggestions.append(suggestion)
        logger.info("[agg_cache] Created suggestion for dataset %d: %d dims, %d measures, "
                     "%d queries, %.1fx estimated speedup",
                     p["dataset_id"], len(p["dimension_col_ids"]),
                     len(p["measure_col_ids"]), p["query_count"], estimated_speedup)

    return new_suggestions


def get_cube_recommendations(dataset_id: int = None,
                             persist: bool = True) -> Dict[str, Any]:
    """Phase 6 (2026-08-09) — the adoption surface.  Ranked, actionable
    cube recommendations derived from real execution history, plus the
    hit-rate telemetry that shows whether adopted cubes are earning their
    keep.

    Ranking: ``benefit_seconds_per_window`` DESC (query_count × avg live
    duration — see :func:`_collect_usage_patterns` for why duration is the
    measured proxy for rows scanned), tie-broken by query_count.

    ``persist=True`` first runs :func:`analyze_usage_patterns` so every
    qualifying pattern has a suggestion row — which makes each
    recommendation ACCEPTABLE IN ONE CALL (POST the ``suggestion_id`` to
    the approve endpoint → entry created → build triggered → serves).
    A recommendation nobody can act on is not a feature.

    This function only ADVISES.  Building happens on explicit accept, or —
    only when ``agg_cache.auto_adopt_enabled`` is ON (ships OFF) — via the
    scheduled :func:`_auto_adopt_job`.
    """
    if not _db_manager:
        return {"recommendations": [], "new_suggestions": 0, "stats": {}}
    from core import config

    new_count = 0
    if persist:
        try:
            new_count = len(analyze_usage_patterns(dataset_id))
        except Exception as exc:
            logger.warning("[agg_cache] suggestion persist during "
                           "recommendations failed: %s", exc)

    min_queries = config.agg_cache.suggestion_min_queries
    recs: List[Dict[str, Any]] = []
    for p in _collect_usage_patterns(dataset_id):
        if p["query_count"] < min_queries:
            continue
        if p["already_covered"]:
            continue
        s = p.pop("suggestion")
        if s is not None and s.get("status") != "pending":
            # approved/implemented — an entry already exists or is building.
            continue
        p.pop("already_covered", None)
        p["suggestion_id"] = s["id"] if s else None
        p["actionable"] = s is not None
        p["estimated_speedup"] = (s or {}).get("estimated_speedup")
        recs.append(p)

    recs.sort(key=lambda r: (r["benefit_seconds_per_window"],
                             r["query_count"]), reverse=True)

    stats: Dict[str, Any] = {}
    try:
        stats = get_cache_stats(dataset_id)
    except Exception as exc:
        logger.debug("[agg_cache] stats unavailable for recommendations: %s", exc)

    return {
        "recommendations": recs,
        "new_suggestions": new_count,
        "stats": stats,
        "window_days": config.agg_cache.suggestion_analysis_window_days,
        "ranking": ("benefit_seconds_per_window = query_count × avg live "
                    "duration_seconds, measured from FederationExecution "
                    "history (cache-served runs excluded)"),
        "auto_adopt_enabled": bool(config.get("agg_cache",
                                              "auto_adopt_enabled", False)),
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }


def auto_adopt_recommendations(max_new: int = None,
                               created_by: str = "auto_adopt") -> List[Dict[str, Any]]:
    """Accept the top-ranked recommendations (bounded).  Called by the
    admin 'adopt top N' endpoint (explicit human intent) and by
    :func:`_auto_adopt_job` (only when ``agg_cache.auto_adopt_enabled`` is
    ON — that flag ships OFF, so no build ever surprises an operator).

    The per-dataset entry cap is a CAP: reaching it skips that dataset's
    recommendation with a log line — it never raises."""
    if not _db_manager:
        return []
    from core import config
    if max_new is None:
        max_new = int(config.get("agg_cache", "auto_adopt_max_per_run", 3))
    adopted: List[Dict[str, Any]] = []
    recs = get_cube_recommendations(persist=True).get("recommendations", [])
    for r in recs:
        if len(adopted) >= max_new:
            break
        sid = r.get("suggestion_id")
        if sid is None:
            continue
        try:
            existing = _db_manager.list_agg_cache_entries(
                dataset_id=r["dataset_id"]) or []
            if len(existing) >= config.agg_cache.max_entries_per_dataset:
                logger.info("[agg_cache] adopt: dataset %d at entry cap "
                            "(%d) — skipping suggestion %d",
                            r["dataset_id"], len(existing), sid)
                continue
            entry = approve_suggestion(sid, created_by=created_by)
            if entry:
                adopted.append(entry)
                logger.info("[agg_cache] adopted suggestion %d → entry %d "
                            "(benefit %.1fs/window over %d queries)",
                            sid, entry["id"],
                            r.get("benefit_seconds_per_window", 0.0),
                            r.get("query_count", 0))
        except Exception as exc:
            logger.warning("[agg_cache] adopt of suggestion %s failed: %s",
                           sid, exc)
    return adopted


def _auto_adopt_job() -> None:
    """Scheduled wrapper — a no-op unless the operator explicitly enabled
    automatic adoption.  Flag read at RUN time so toggling needs no
    restart."""
    try:
        from core import config
        if not bool(config.get("agg_cache", "auto_adopt_enabled", False)):
            return
        adopted = auto_adopt_recommendations()
        if adopted:
            logger.info("[agg_cache] auto-adopt created %d entries: %s",
                        len(adopted), [e["id"] for e in adopted])
    except Exception as exc:
        logger.warning("[agg_cache] auto-adopt job failed: %s", exc)


def approve_suggestion(suggestion_id: int, schedule_config: dict = None,
                       created_by: str = "admin") -> Optional[Dict[str, Any]]:
    """Convert a suggestion into an AggCacheEntry and trigger initial build."""
    if not _db_manager:
        return None

    suggestion = _db_manager.list_agg_cache_suggestions()
    match = None
    for s in suggestion:
        if s["id"] == suggestion_id:
            match = s
            break
    if not match:
        return None

    # Create the cache entry
    entry = _db_manager.create_agg_cache_entry(
        dataset_id=match["dataset_id"],
        name=f"Auto-suggested rollup #{suggestion_id}",
        description=f"Auto-generated from {match['query_count']} queries "
                    f"(est. {match['estimated_speedup']}x speedup)",
        dimension_col_ids=match["dimension_col_ids"],
        measure_col_ids=match["measure_col_ids"],
        grain_label="custom",
        schedule_config=schedule_config,
        is_enabled=True,
        created_by=created_by,
    )

    # Update suggestion status
    _db_manager.update_agg_cache_suggestion(
        suggestion_id,
        status="approved",
        reviewed_by=created_by,
        reviewed_at=datetime.now(timezone.utc),
    )

    # Trigger initial build in background
    _trigger_background_refresh(entry["id"])

    return entry


def reject_suggestion(suggestion_id: int, reviewed_by: str = "admin") -> Optional[Dict[str, Any]]:
    """Mark a suggestion as rejected."""
    if not _db_manager:
        return None
    return _db_manager.update_agg_cache_suggestion(
        suggestion_id,
        status="rejected",
        reviewed_by=reviewed_by,
        reviewed_at=datetime.now(timezone.utc),
    )


# ═══════════════════════════════════════════════════════════════════════════════
# Lifecycle Management
# ═══════════════════════════════════════════════════════════════════════════════

def cleanup_expired() -> int:
    """Remove hard-expired cache entries: delete parquet files, update status."""
    if not _db_manager:
        return 0

    now = datetime.now(timezone.utc)
    entries = _db_manager.list_agg_cache_entries()
    cleaned = 0

    for entry in entries:
        expires_at = entry.get("expires_at")
        if not expires_at:
            continue
        exp_dt = _parse_dt(expires_at)
        if now <= exp_dt:
            continue
        if entry["status"] in ("expired", "pending"):
            continue

        # Remove parquet file
        fp = entry.get("file_path")
        if fp and os.path.isfile(fp):
            try:
                os.remove(fp)
            except OSError as exc:
                logger.warning("[agg_cache] Failed to remove expired file %s: %s", fp, exc)

        _db_manager.update_agg_cache_entry(entry["id"], status="expired", file_path=None,
                                            file_size_bytes=0, row_count=0)
        cleaned += 1

    # Also mark stale entries
    for entry in entries:
        if entry["status"] != "ready":
            continue
        stale_at = entry.get("stale_at")
        if not stale_at:
            continue
        stale_dt = _parse_dt(stale_at)
        if now > stale_dt:
            _db_manager.update_agg_cache_entry(entry["id"], status="stale")

    if cleaned:
        logger.info("[agg_cache] Cleaned %d expired entries", cleaned)
    return cleaned


def enforce_storage_quota() -> int:
    """LRU eviction when total cache size exceeds max_storage_mb."""
    if not _db_manager:
        return 0

    from core import config
    max_bytes = config.agg_cache.max_storage_mb * 1024 * 1024

    entries = _db_manager.list_agg_cache_entries()
    total_size = sum(e.get("file_size_bytes") or 0 for e in entries)

    if total_size <= max_bytes:
        return 0

    # Sort by last_served_at ASC (oldest served first = LRU victims)
    eviction_candidates = [
        e for e in entries
        if e.get("file_path") and e.get("file_size_bytes", 0) > 0
    ]
    eviction_candidates.sort(
        key=lambda e: _parse_dt(e["last_served_at"]) if e.get("last_served_at") else datetime.min.replace(tzinfo=timezone.utc)
    )

    evicted = 0
    for entry in eviction_candidates:
        if total_size <= max_bytes:
            break

        fp = entry.get("file_path")
        size = entry.get("file_size_bytes", 0)
        if fp and os.path.isfile(fp):
            try:
                os.remove(fp)
            except OSError:
                continue

        _db_manager.update_agg_cache_entry(entry["id"], status="expired",
                                            file_path=None, file_size_bytes=0, row_count=0)
        total_size -= size
        evicted += 1

    if evicted:
        logger.info("[agg_cache] Evicted %d entries for storage quota enforcement", evicted)
    return evicted


def invalidate_by_dataset(dataset_id: int) -> int:
    """Mark all cache entries for a dataset as stale (called when dataset changes)."""
    if not _db_manager:
        return 0

    entries = _db_manager.list_agg_cache_entries(dataset_id=dataset_id)
    count = 0
    for entry in entries:
        if entry["status"] in ("ready", "building"):
            _db_manager.update_agg_cache_entry(entry["id"], status="stale")
            count += 1
    if count:
        logger.info("[agg_cache] Invalidated %d entries for dataset %d", count, dataset_id)
    return count


# ════════════════════════════════════════════════════════════════════
# Phase 155 -- brain-aware sql-hash memoisation
# ════════════════════════════════════════════════════════════════════


def make_sql_hash(sql: str) -> str:
    """Canonical hash for the brain's sql-hash cache.

    2026-08-20 -- literal-preserving normalisation.  The old body ran
    ``" ".join(sql.lower().split())`` over the WHOLE string, so string
    LITERALS were case-folded into the key: ``region='EMEA'`` and
    ``region='emea'`` -- different result sets on any case-sensitive
    source (Trino/Snowflake varchar, S3 hive partition values) --
    produced ONE hash, and every consumer keyed on it (result memo,
    pruning memo, route history) treated them as the same query.

    Delegates to ``core.result_cache.normalize_sql`` (the fix shipped
    there for the identical defect): quoted spans are copied VERBATIM
    (doubled-quote escape handled); lower-casing + whitespace collapse
    + comment stripping apply only to the code BETWEEN them.
    Semantically-identical SQL (keyword case/spacing) still shares a
    hash; different literals no longer do.  Entries keyed by the old
    spelling become unreachable = one-off cold cache (safe direction).

    Not cryptographic -- SHA-1 is plenty for a 200-entry per-pod cache,
    and ``usedforsecurity=False`` says so to ruff S324 and to OpenSSL in
    FIPS mode (2026-09-13 triage).  Reviewed as CONTENT-ADDRESSING: this
    keys a per-pod plan/route memo, never result BYTES and never access.
    Row visibility is enforced in the SQL the plan produces, so two
    queries colliding here would pick a wrong PLAN, not see each other's
    rows -- and at 200 entries over 64 bits that is ~1e-15.  The digest is
    unchanged by the flag, so no cache entry moves.
    """
    if not sql:
        return ""
    try:
        from core.result_cache import normalize_sql as _normalize_sql
        normalised = _normalize_sql(sql)
        return hashlib.sha1(normalised.encode("utf-8"),
                            usedforsecurity=False).hexdigest()[:16]
    except Exception:
        return ""


def brain_cache_user_scope(
    username: Optional[str] = None,
) -> Tuple[bool, Optional[str]]:
    """(cache_allowed, user_scope) for the brain sql-hash RESULT cache.

    2026-08-20 -- the brain result cache had NO principal in its key,
    so two principals running identical SQL against an RLS-scoped
    connection shared one unfiltered parquet.  Follows the
    ``core.query_cache.rls_user_scope`` pattern:

      * row-security DISABLED -> (True, None): the legacy shared key,
        byte-identical to the pre-fix form -- existing entries stay
        reachable, nothing is invalidated.
      * row-security ENABLED + principal known -> (True, scope-hash):
        per-principal namespace.
      * row-security ENABLED + principal UNKNOWN -> (False, None):
        UNKNOWN = UNSAFE -- the cache is disabled for this call
        rather than guessed.

    ``username`` falls back to the request-scoped contextvar
    (``core.user_context``) the auth middleware sets, so the read side
    (brain_router -> get_cached_result) needs no signature threading.

    2026-09-26 (F0) -- with row security ON by default, "enabled" alone
    disabled this cache for every caller the request could not name.  The
    shared/legacy branch is now taken whenever ``core.row_security.
    cache_scope`` says the unscoped slot is safe (engine off, or a readable
    and EMPTY policy set); per principal otherwise, and OFF for a principal
    it cannot name (unknown = unsafe, unchanged).
    """
    from core.row_security.cache_scope import shared_slot_is_safe
    if shared_slot_is_safe():
        return True, None
    _uname = (username or "").strip()
    if not _uname:
        try:
            from core.user_context import get_current_username
            _uname = (get_current_username() or "").strip()
        except Exception:
            _uname = ""
    if not _uname:
        return False, None
    try:
        from core.query_cache import rls_user_scope
        _scope = rls_user_scope(_uname)
    except Exception:
        return False, None
    if not _scope:
        return False, None
    return True, _scope


def _brain_cache_key(sql_hash: str, snapshot_id: str,
                     user_scope: Optional[str]) -> str:
    """Key layout: ``sql_hash:snapshot`` (legacy, RLS off) or
    ``sql_hash:snapshot:scope:pvN`` (RLS on).  The row-security policy
    VERSION is mixed into scoped keys so an admin policy edit
    (``row_security.api.invalidate_cache`` bumps it) makes every scoped
    entry unreachable immediately -- same as published-views."""
    key = f"{sql_hash}:{snapshot_id or '*'}"
    if user_scope:
        try:
            from core.row_security.api import current_policy_version as _pv
            key = f"{key}:{user_scope}:pv{int(_pv())}"
        except Exception:
            key = f"{key}:{user_scope}:pv?"
        # 2026-09-26 (F0) -- the policy SET's digest too, so a sibling
        # pod's edit moves the slot within the resolver TTL (the in-process
        # version above cannot see it).
        from core.row_security.cache_scope import policy_set_marker
        key = f"{key}:{policy_set_marker()}"
    return key


def get_cached_result(
    sql_hash: str,
    snapshot_id: str = "",
    username: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """Brain-router consumer: return a cached result for this
    (sql_hash, snapshot_id[, principal]) tuple, or None.

    Output shape:
        {"file_path": str, "row_count": int, "age_seconds": float}

    Auto-expires when:
      * Soft TTL (10 min default) exceeds.
      * The snapshot_id no longer matches what we cached against.

    2026-08-20 -- principal-aware: with row-security ENABLED the key is
    scoped per principal (+ policy version); with it enabled and the
    principal UNRESOLVABLE this is a guaranteed MISS (unknown = unsafe).
    With row-security disabled the key is unchanged (legacy form).
    """
    if not sql_hash:
        return None
    # 2026-10-08 -- an UNKNOWN snapshot is never a hit.  The live defect
    # read (and wrote) ``<hash>:*`` because the raw-SQL road never
    # surfaced the table's snapshot: a "hit" asserted without it would
    # serve a pre-commit result for the whole TTL (the 2026-10-07
    # staleness incident's rule: an entry with no fingerprint is evicted,
    # not served).  Unknown = unsafe, for every layout.
    if not snapshot_id:
        return None
    _allowed, _scope = brain_cache_user_scope(username)
    if not _allowed:
        return None
    key = _brain_cache_key(sql_hash, snapshot_id, _scope)
    now = time.time()
    with _BRAIN_SQL_CACHE_LOCK:
        entry = _BRAIN_SQL_CACHE.get(key)
        if entry is None:
            return None
        age = now - entry.get("created_at", now)
        if age > _BRAIN_SQL_CACHE_TTL_SECONDS:
            # Soft expired -- evict + miss.
            _BRAIN_SQL_CACHE.pop(key, None)
            return None
        file_path = entry.get("file_path") or ""
    if file_path and not os.path.isfile(file_path):
        with _BRAIN_SQL_CACHE_LOCK:
            _BRAIN_SQL_CACHE.pop(key, None)
        return None
    return {
        "file_path":   file_path,
        "row_count":   int(entry.get("row_count") or 0),
        "age_seconds": round(age, 1),
    }


def put_cached_result(
    sql_hash: str,
    snapshot_id: str,
    file_path: str,
    row_count: int = 0,
    username: Optional[str] = None,
) -> None:
    """Brain-router callback after a successful query: store the
    result parquet's path in the brain's sql-hash cache.

    2026-08-20 -- principal-aware (see get_cached_result): with
    row-security ENABLED and no resolvable principal the write is
    SKIPPED -- an unattributed result parquet must never enter a store
    another principal could read."""
    if not sql_hash or not file_path:
        return
    # 2026-10-08 -- no snapshot, no entry (see get_cached_result): a
    # result filed under ``<hash>:*`` can only ever be served stale.
    if not snapshot_id:
        return
    _allowed, _scope = brain_cache_user_scope(username)
    if not _allowed:
        return
    key = _brain_cache_key(sql_hash, snapshot_id, _scope)
    with _BRAIN_SQL_CACHE_LOCK:
        # LRU-ish eviction: when at cap, drop oldest 10%.
        if len(_BRAIN_SQL_CACHE) >= _BRAIN_SQL_CACHE_MAX:
            stale = sorted(
                _BRAIN_SQL_CACHE.items(),
                key=lambda kv: kv[1].get("created_at", 0),
            )[: max(1, _BRAIN_SQL_CACHE_MAX // 10)]
            for k, _ in stale:
                _BRAIN_SQL_CACHE.pop(k, None)
        _BRAIN_SQL_CACHE[key] = {
            "file_path":  file_path,
            "row_count":  row_count,
            "created_at": time.time(),
        }


# ── 2026-10-08: SERVED, or not ROUTED on -- the one object both sides read ──
#
# Live on Docker against real AWS: the router decided "agg_cache hit" and
# routed to SINGLE; the executor then read all 2,688 files (245 s against a
# 42 s cold multi-worker run).  Two decisions about one question.  Now the
# CALLER that can serve resolves ONE ``BrainCacheHit`` (``lookup_brain_
# cache``), hands it to the router through ``QueryFeatures.cached_result``
# (the router says ROUTE_CACHE only for a hit it was handed) and serves
# that same object (``serve_brain_cache_hit``).  A snapshot the caller
# does not know is never a hit (``get_cached_result`` refuses it).


class BrainCacheHit:
    """A resolved brain-cache entry: what the router routes on and the
    dispatcher serves.  ``snapshot_id`` is never empty."""
    __slots__ = ("sql_hash", "snapshot_id", "file_path", "row_count",
                 "age_seconds", "username")

    def __init__(self, sql_hash: str, snapshot_id: str, file_path: str,
                 row_count: int, age_seconds: float,
                 username: Optional[str] = None) -> None:
        self.sql_hash = str(sql_hash)
        self.snapshot_id = str(snapshot_id)
        self.file_path = str(file_path)
        self.row_count = int(row_count or 0)
        self.age_seconds = float(age_seconds or 0.0)
        self.username = username

    def __repr__(self) -> str:                       # pragma: no cover
        return (f"BrainCacheHit(sql_hash={self.sql_hash!r}, "
                f"snapshot={self.snapshot_id!r}, rows={self.row_count}, "
                f"age={self.age_seconds:.1f}s)")


def lookup_brain_cache(
    sql_hash: str,
    snapshot_id: Optional[str],
    username: Optional[str] = None,
) -> Optional["BrainCacheHit"]:
    """THE lookup.  ``None`` for an empty hash, an UNKNOWN snapshot
    (``""``/``None`` -- the live ``snapshot=?``), an unresolvable
    principal under RLS, a soft-expired entry, or a vanished file."""
    if not sql_hash or not snapshot_id:
        return None
    hit = get_cached_result(sql_hash, str(snapshot_id), username=username)
    if not hit or not hit.get("file_path"):
        return None
    return BrainCacheHit(
        sql_hash=sql_hash, snapshot_id=str(snapshot_id),
        file_path=hit["file_path"], row_count=int(hit.get("row_count") or 0),
        age_seconds=float(hit.get("age_seconds") or 0.0), username=username,
    )


def _evict_brain_cache_hit(hit: "BrainCacheHit") -> None:
    try:
        _allowed, _scope = brain_cache_user_scope(hit.username)
        key = _brain_cache_key(hit.sql_hash, hit.snapshot_id, _scope)
        with _BRAIN_SQL_CACHE_LOCK:
            _BRAIN_SQL_CACHE.pop(key, None)
    except Exception:
        pass


def serve_brain_cache_hit(
    hit: Optional["BrainCacheHit"],
    output_file: str,
    execution_id: str = "",
) -> Optional[Dict[str, Any]]:
    """Serve ``hit`` into ``output_file``: the cached result parquet is
    COPIED, no data file is read, and the execution's pruning record says
    ``served_from=brain_cache`` with ``files_after_prune=0``.

    Returns the dispatcher-shaped success dict (``total_rows``,
    ``file_size_bytes``, ``worker_count=0``, ``files_total=0``,
    ``from_brain_cache=True``) or ``None`` when the entry's file vanished
    between the decision and the serve -- the entry is then evicted so
    the caller's re-decision cannot route on it again.  Never raises."""
    if hit is None or not output_file:
        return None
    t0 = time.monotonic()
    try:
        src = hit.file_path
        if not src or not os.path.isfile(src):
            _evict_brain_cache_hit(hit)
            return None
        dst = str(output_file)
        if os.path.abspath(src) != os.path.abspath(dst):
            os.makedirs(os.path.dirname(dst) or ".", exist_ok=True)
            shutil.copyfile(src, dst)
        size = int(os.path.getsize(dst))
    except Exception as exc:
        logger.warning("[brain-cache] serve of %s failed (%s) -- entry "
                       "evicted, the query runs", hit, exc)
        _evict_brain_cache_hit(hit)
        return None
    elapsed = time.monotonic() - t0
    if execution_id:
        try:
            from core.query_diagnostic_store import record_pruning
            record_pruning(str(execution_id), {
                "served_from":              "brain_cache",
                "files_after_prune":        0,
                "brain_cache_snapshot":     hit.snapshot_id,
                "brain_cache_age_seconds":  round(hit.age_seconds, 1),
                "brain_cache_rows":         hit.row_count,
            })
        except Exception as exc:
            logger.debug("[brain-cache] serve record skipped: %s", exc)
        try:
            from core.execution_stage import add_extras
            add_extras(str(execution_id), brain_cache_served=True,
                       files_to_scan=0)
        except Exception:
            pass
    logger.info("[brain-cache] SERVED sql_hash=%s snapshot=%s rows=%d "
                "age=%.1fs -> %s (0 data files read, %.3fs) exec=%s",
                hit.sql_hash, hit.snapshot_id, hit.row_count,
                hit.age_seconds, output_file, elapsed, execution_id or "n/a")
    return {
        "total_rows":        hit.row_count,
        "file_size_bytes":   size,
        "worker_count":      0,
        "files_total":       0,
        "elapsed_s":         round(elapsed, 3),
        "merge_strategy":    "brain_cache",
        "from_brain_cache":  True,
        "cache_age_seconds": round(hit.age_seconds, 1),
        "snapshot_id":       hit.snapshot_id,
    }


def brain_snapshot_key_from_ids(snaps: Optional[Dict[str, Any]]) -> str:
    """The brain-cache snapshot for a run that read these Iceberg tables:
    their snapshot ids joined by ``,`` in table-name order (a JOIN over
    two tables keys on both; ``invalidate_brain_cache_for_snapshot`` on
    either member evicts it).  ``""`` when nothing is known."""
    if not isinstance(snaps, dict) or not snaps:
        return ""
    parts = [str(snaps[k]) for k in sorted(snaps) if snaps.get(k) not in (None, "")]
    if len(parts) != len(snaps):
        return ""
    return ",".join(parts)


def brain_snapshot_from_query_config(qcd: Optional[Dict[str, Any]]) -> str:
    """The ONE reader of the snapshot the brain cache keys on, used by the
    dispatcher call site (lookup) and the completion hook (store) alike.
    ``_brain_snapshot_key`` is set by the execute road from the snapshots
    resolved BEFORE the run; ``_iceberg_snapshot_id`` is the view setup's
    / published-view's stamp."""
    if not isinstance(qcd, dict):
        return ""
    v = qcd.get("_brain_snapshot_key")
    if v in (None, ""):
        v = qcd.get("_iceberg_snapshot_id")
    return str(v) if v not in (None, "") else ""


def invalidate_brain_cache_for_snapshot(snapshot_id: str) -> int:
    """Hook for brain_freshness: when a snapshot rolls forward,
    invalidate every cache entry pinned to that snapshot.  Returns
    the count of evicted entries."""
    if not snapshot_id:
        return 0
    # 2026-08-20 -- keys may now carry a ``:scope:pvN`` suffix (see
    # _brain_cache_key), so the old ``endswith(":<snap>")`` test would
    # MISS every scoped entry and serve stale results across a snapshot
    # roll.  The snapshot is always key part [1] (sql_hash is 16 hex
    # chars, never contains ':').
    # 2026-10-08 -- part [1] may be a COMPOSITE ``id1,id2`` (one member
    # per Iceberg table the query read); any member matching evicts.
    _snap = str(snapshot_id)
    with _BRAIN_SQL_CACHE_LOCK:
        keys = [k for k in _BRAIN_SQL_CACHE
                if len(k.split(":")) >= 2
                and _snap in k.split(":")[1].split(",")]
        for k in keys:
            _BRAIN_SQL_CACHE.pop(k, None)
    return len(keys)


def invalidate_brain_cache_all() -> int:
    """Clear the ENTIRE brain SQL-hash RESULT cache.

    Used when new per-file column stats land: this cache is keyed
    ``sql_hash:snapshot_id`` with NO table identity, and for a JOIN the
    snapshot is first-iceberg-table-wins — so a per-snapshot clear can't
    reliably target a stats change on a JOINED table.  The cache is tiny
    (<=200 entries, 10-min TTL, per-pod), so a full clear is cheap and always
    correctness-safe (worst case = a few queries recompute instead of serving
    a possibly-stale result parquet)."""
    with _BRAIN_SQL_CACHE_LOCK:
        n = len(_BRAIN_SQL_CACHE)
        _BRAIN_SQL_CACHE.clear()
    return n


def reset_brain_cache_for_tests() -> None:
    with _BRAIN_SQL_CACHE_LOCK:
        _BRAIN_SQL_CACHE.clear()


def get_brain_cache_stats() -> Dict[str, Any]:
    """Diagnostic snapshot for admin UI."""
    with _BRAIN_SQL_CACHE_LOCK:
        return {
            "entries":     len(_BRAIN_SQL_CACHE),
            "max_entries": _BRAIN_SQL_CACHE_MAX,
            "ttl_seconds": _BRAIN_SQL_CACHE_TTL_SECONDS,
        }


def get_cache_stats(dataset_id: int = None) -> Dict[str, Any]:
    """Return aggregated cache statistics."""
    if not _db_manager:
        return {}
    from core import config
    stats = _db_manager.get_agg_cache_stats(dataset_id=dataset_id)
    stats["quota_mb"] = config.agg_cache.max_storage_mb
    stats["usage_percent"] = round(
        stats.get("total_size_mb", 0) / config.agg_cache.max_storage_mb * 100, 1
    ) if config.agg_cache.max_storage_mb else 0
    return stats


def maybe_write_through(dataset_id: int, column_ids: List[int],
                        output_path: str, total_rows: int, *,
                        row_limit: Optional[int],
                        filter_count: int,
                        condition_ids: Optional[List[int]],
                        truncated: Optional[bool] = None) -> None:
    """Optionally populate an existing cache entry after a live query (write-through).

    Only updates entries that are stale/expired and match the query pattern.
    Does NOT auto-create new entries.

    2026-08-20 — a cube copy discloses NOTHING and serves everyone as
    complete, so only a COMPLETE, UNFILTERED live result may become one.
    The caller MUST thread the facts (keyword-only, no safe-looking
    defaults — a new caller that cannot supply them gets a TypeError, not
    a silent unsafe write):

      * ``row_limit``     — the EFFECTIVE limit the execution ran under
                            (None/<=0 = unlimited).  ``total_rows >=
                            row_limit`` is the same limit-hit verdict the
                            truncation disclosure uses: at or above the
                            limit the result may be clipped — refuse.
                            This is the 56dd9fff "CUBE SILENTLY REBUILT
                            FROM 10K ROWS" defect on the write-through
                            path: an interactive query defaults to
                            semantic_layer.default_row_limit.
      * ``filter_count``  — ad-hoc filters applied in the live SQL make
                            the result a SUBSET — refuse when > 0.
      * ``condition_ids`` — pre-defined conditions applied in the live
                            SQL: same, refuse when non-empty.
      * ``truncated``     — the engine's explicit verdict, when stamped.

    Entries that define their own condition_ids are also skipped: their
    cube is a conditioned build only the governed build path can produce.
    """
    if not _db_manager:
        return
    from core import config
    if not config.agg_cache.write_through_enabled:
        return

    # ── Completeness gate (2026-08-20) — refuse partial/filtered results ──
    if truncated:
        logger.info("[agg_cache] write-through refused (dataset %d): result "
                    "marked truncated", dataset_id)
        return
    if row_limit and row_limit > 0 and total_rows >= row_limit:
        logger.info("[agg_cache] write-through refused (dataset %d): result "
                    "hit its row limit (%d rows >= limit %d) — possibly "
                    "clipped, a cube must be complete", dataset_id,
                    total_rows, row_limit)
        return
    if filter_count:
        logger.info("[agg_cache] write-through refused (dataset %d): live "
                    "result carried %d ad-hoc filter(s)", dataset_id,
                    filter_count)
        return
    if condition_ids:
        logger.info("[agg_cache] write-through refused (dataset %d): live "
                    "result carried condition_ids %s", dataset_id,
                    list(condition_ids))
        return

    entries = _db_manager.list_agg_cache_entries(dataset_id=dataset_id)
    col_set = set(column_ids)

    for entry in entries:
        if entry["status"] not in ("stale", "expired", "pending"):
            continue
        # 2026-08-20: an entry that defines pre-conditions is a FILTERED
        # cube by definition — this live result ran without them (the gate
        # above refused any conditioned query), so the copy would hold MORE
        # rows than the cube's contract.  Governed build only.
        if entry.get("condition_ids"):
            continue
        # 2026-08-20: an incremental entry with merge history is keyed by
        # incremental_last_value, which a bare copy does NOT update.  The
        # copy itself is complete, but the NEXT incremental build would
        # filter on the stale last_value and its merge would replace
        # complete per-key aggregates with partial re-aggregates (row
        # loss).  A never-built incremental entry (no last_value) is safe:
        # its next build runs unfiltered.
        if entry.get("incremental_enabled") and entry.get("incremental_last_value"):
            continue
        # Phase 5 RLS-aware cubes: secured entries are populated ONLY by
        # their governed build path.  A live execution's parquet lacks the
        # security-dimension grain and avg SUM/COUNT pairs
        # ("security_dims") or would overwrite one caller's scoped rows
        # with another's ("scoped") — populating them here would corrupt
        # or widen them.  Fail-closed: skip.
        if (entry.get("rls_mode") or "open") != "open":
            continue
        cache_cols = set((entry.get("dimension_col_ids") or []) +
                         (entry.get("measure_col_ids") or []))
        if cache_cols == col_set:
            # Exact match — copy the output as cache
            ds_cache_dir = _cache_dir / str(dataset_id)
            ds_cache_dir.mkdir(parents=True, exist_ok=True)
            cache_path = str(ds_cache_dir / f"entry_{entry['id']}.parquet")
            try:
                shutil.copy2(output_path, cache_path)
                file_size = os.path.getsize(cache_path)
                now = datetime.now(timezone.utc)
                ttl_hours = config.agg_cache.default_ttl_hours
                hard_hours = config.agg_cache.hard_expiry_hours
                _db_manager.update_agg_cache_entry(entry["id"],
                    status="ready",
                    file_path=cache_path,
                    file_size_bytes=file_size,
                    row_count=total_rows,
                    last_built_at=now,
                    stale_at=now + timedelta(hours=ttl_hours),
                    expires_at=now + timedelta(hours=hard_hours),
                    error_message=None,
                )
                logger.info("[agg_cache] Write-through populated entry %d (dataset %d)",
                            entry["id"], dataset_id)
            except Exception as exc:
                logger.warning("[agg_cache] Write-through failed for entry %d: %s",
                               entry["id"], exc)
            break


# ═══════════════════════════════════════════════════════════════════════════════
# Scheduler Integration
# ═══════════════════════════════════════════════════════════════════════════════

def register_scheduled_refreshes(scheduler) -> int:
    """Register APScheduler jobs for all enabled entries with schedule_config.

    Called at startup.  Returns count of jobs registered.
    """
    if not _db_manager:
        return 0

    entries = _db_manager.list_agg_cache_entries()
    count = 0
    for entry in entries:
        if not entry.get("is_enabled") or not entry.get("schedule_config"):
            continue
        if register_cache_entry_schedule(scheduler, entry["id"]):
            count += 1

    logger.info("[agg_cache] Registered %d scheduled refresh jobs", count)

    # Phase 7 (2026-08-09): the scheduled half of the verification GATE —
    # every enabled AggregationAwareness mapping is re-probed against raw
    # on an interval, so a customer table that silently drifts wrong stops
    # serving within one sweep (routing-time TTL re-verification covers the
    # window in between).  Fail-open registration: a scheduler hiccup must
    # not block startup — serving still requires a fresh verdict, so a
    # missing sweep only means lazier re-verification, never a wrong serve.
    try:
        from core import config
        hours = max(1, int(config.get("agg_cache",
                                      "agg_awareness_reverify_hours", 24)))
        scheduler.add_job(
            func=verify_all_agg_awareness,
            trigger="interval", hours=hours,
            id="__agg_awareness_verify__",
            name="Agg Awareness verification sweep",
            replace_existing=True, misfire_grace_time=3600,
            coalesce=True, max_instances=1,
        )
        # Phase 6: scheduled auto-adoption.  The JOB is always registered;
        # it exits immediately unless `agg_cache.auto_adopt_enabled` is ON
        # (ships OFF) — suggestions stay advice unless an operator opts in.
        scheduler.add_job(
            func=_auto_adopt_job,
            trigger="interval",
            hours=max(1, int(config.get("agg_cache",
                                        "auto_adopt_interval_hours", 24))),
            id="__agg_cache_auto_adopt__",
            name="Agg Cache auto-adoption (flag-gated)",
            replace_existing=True, misfire_grace_time=3600,
            coalesce=True, max_instances=1,
        )
    except Exception as exc:
        logger.warning("[agg_cache] could not register verification/adoption "
                       "jobs: %s", exc)
    return count


def register_cache_entry_schedule(scheduler, entry_id: int) -> bool:
    """Register/update the APScheduler job for a single cache entry."""
    if not _db_manager:
        return False

    entry = _db_manager.get_agg_cache_entry(entry_id)
    if not entry or not entry.get("schedule_config"):
        return False

    try:
        from core.scheduler import _build_trigger
        trigger = _build_trigger(entry["schedule_config"])
        job_id = f"__agg_cache_refresh_{entry_id}__"

        scheduler.add_job(
            func=build_cache_entry,
            trigger=trigger,
            id=job_id,
            args=[entry_id, True],
            name=f"Agg Cache: {entry.get('name', entry_id)}",
            replace_existing=True,
            misfire_grace_time=300,
            coalesce=True,
            max_instances=1,
        )
        logger.info("[agg_cache] Registered schedule for entry %d: %s",
                     entry_id, entry["schedule_config"])
        return True
    except Exception as exc:
        logger.warning("[agg_cache] Failed to register schedule for entry %d: %s",
                       entry_id, exc)
        return False


def unregister_cache_entry_schedule(scheduler, entry_id: int) -> bool:
    """Remove the APScheduler job for a cache entry."""
    job_id = f"__agg_cache_refresh_{entry_id}__"
    try:
        scheduler.remove_job(job_id)
        return True
    except Exception:
        return False


# ═══════════════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _parse_dt(val) -> datetime:
    """Parse a datetime value (string or datetime) into timezone-aware datetime."""
    if isinstance(val, str):
        dt = datetime.fromisoformat(val)
    elif isinstance(val, datetime):
        dt = val
    else:
        return datetime.min.replace(tzinfo=timezone.utc)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


def _get_entry_lock(entry_id: int) -> threading.Lock:
    """Get or create a per-entry build lock."""
    with _global_lock:
        if entry_id not in _build_locks:
            _build_locks[entry_id] = threading.Lock()
        return _build_locks[entry_id]


def _fmt_size(size_bytes: int) -> str:
    """Human-readable file size."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"
