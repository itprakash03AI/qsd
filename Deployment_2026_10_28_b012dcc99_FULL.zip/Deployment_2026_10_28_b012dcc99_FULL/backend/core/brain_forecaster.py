"""Workload forecaster — time-of-day / day-of-week pattern detector.

The problem:

The adaptive prefetch daemon ranks targets by "recent query frequency"
— that's REACTIVE.  A monthly-close report that runs every 30th of
the month at 9am produces ZERO signal for the prefetcher between
runs, so the first query each month hits cold supplement + bloom and
pays the full footer-read cost.

The detection:

For each (bucket, prefix), bin the last 28 days of pruning_history
by (day_of_week, hour_of_day).  Compute the expected query count for
each bin.  When the current hour's expected count is materially above
the baseline, surface a ``PredictedSpike`` so the prefetcher pre-warms
state ahead of time.

Strategic shape: ONE class — ``WorkloadForecaster`` — pure read-only
on history.  Plugs into the adaptive prefetch cron via a `next_24h
_predictions()` capability the prefetcher consumes to bias target
ranking.

Falls back to noop when:
  * Fewer than ``min_observations_per_table`` rows over the lookback
    window (cold start)
  * Variance is so high that the bin estimate is meaningless
"""
from __future__ import annotations

import logging
import threading
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ── Config ────────────────────────────────────────────────────────────


def _cfg(key: str, fallback: Any) -> Any:
    try:
        from core.config import get as _g
        return _g("brain_forecaster", key, fallback)
    except Exception:
        return fallback


def enabled() -> bool:
    return bool(_cfg("enabled", True))


def lookback_days() -> int:
    """How far back to read history for pattern detection.  Default 28
    days — covers a full month of monthly-close cycles."""
    return int(_cfg("lookback_days", 28) or 28)


def min_observations_per_table() -> int:
    return int(_cfg("min_observations_per_table", 20) or 20)


def spike_multiplier_threshold() -> float:
    """Bin must be at least this many × the table's mean rate before
    we flag a spike.  Default 3× — high enough to suppress noise."""
    return float(_cfg("spike_multiplier_threshold", 3.0) or 3.0)


def max_lookahead_hours() -> int:
    """How many hours forward to project.  Default 24h — same as one
    adaptive prefetch interval."""
    return int(_cfg("max_lookahead_hours", 24) or 24)


# ── Dataclasses ──────────────────────────────────────────────────────


@dataclass
class PredictedSpike:
    bucket:                 str
    table_prefix:           str
    hours_ahead:            int      # 0 = current hour
    day_of_week:            int      # 0..6 (Mon..Sun, ISO)
    hour_of_day:            int      # 0..23 UTC
    expected_queries:       float
    baseline_queries_per_hour: float
    spike_ratio:            float
    confidence:             float
    rationale:              str
    generated_at:           str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat(),
    )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ── The forecaster ───────────────────────────────────────────────────


class WorkloadForecaster:
    """Singleton — reads pruning_history; emits spike predictions."""

    _instance_lock = threading.Lock()
    _instance: Optional["WorkloadForecaster"] = None

    def __init__(self, db_manager: Any) -> None:
        self._db = db_manager

    @classmethod
    def get_default(cls, db_manager: Any) -> "WorkloadForecaster":
        # 2026-06-10 audit fix — wrap lazy-init in a lock so two
        # concurrent admin / coordinator calls don't race.
        with cls._instance_lock:
            if cls._instance is None:
                cls._instance = cls(db_manager)
            return cls._instance

    def next_24h_predictions(
        self, bucket_filter: Optional[str] = None,
    ) -> List[PredictedSpike]:
        """Return predicted spikes within the next ``max_lookahead_hours``
        ranked by spike_ratio desc.  Empty list when forecaster is
        disabled or the lookback window has insufficient data."""
        if not enabled():
            return []
        try:
            from core.db.models import QueryPruningHistory
            since = datetime.now(timezone.utc) - timedelta(
                days=lookback_days(),
            )
            with self._db.get_session(read_only=True) as session:
                q = session.query(
                    QueryPruningHistory.bucket,
                    QueryPruningHistory.table_prefix,
                    QueryPruningHistory.created_at,
                ).filter(
                    QueryPruningHistory.created_at >= since,
                )
                if bucket_filter:
                    q = q.filter(
                        QueryPruningHistory.bucket == bucket_filter,
                    )
                rows = q.limit(100_000).all()
        except Exception as exc:
            logger.debug("WorkloadForecaster: history read failed: %s", exc)
            return []

        # Bin by (bucket, prefix, dow, hour)
        per_table: Dict[Tuple[str, str], int] = defaultdict(int)
        per_bin: Dict[Tuple[str, str, int, int], int] = defaultdict(int)
        for (bucket, prefix, created_at) in rows:
            if not bucket or not prefix or not created_at:
                continue
            ts = created_at
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=timezone.utc)
            norm_prefix = (prefix or "").rstrip("/")
            key = (bucket, norm_prefix)
            per_table[key] += 1
            per_bin[(bucket, norm_prefix,
                     ts.weekday(), ts.hour)] += 1

        if not per_table:
            return []

        out: List[PredictedSpike] = []
        threshold = spike_multiplier_threshold()
        # 28 days × 7-day cycle = 4 occurrences of each (dow, hour) bin
        # over the window.  Mean rate = per_table_total / (lookback_days
        # × 24).
        lookback_h = max(1, lookback_days() * 24)
        now = datetime.now(timezone.utc)
        for hours_ahead in range(0, max_lookahead_hours()):
            future = now + timedelta(hours=hours_ahead)
            dow  = future.weekday()
            hour = future.hour
            for (bucket, prefix), total_obs in per_table.items():
                if total_obs < min_observations_per_table():
                    continue
                baseline_per_hour = total_obs / lookback_h
                bin_count = per_bin.get((bucket, prefix, dow, hour), 0)
                # Bin appeared 4 times in the lookback (28 days = 4
                # weeks); expected per occurrence = bin_count / 4
                expected = bin_count / max(1, lookback_days() // 7)
                if baseline_per_hour <= 0:
                    continue
                ratio = expected / baseline_per_hour
                if ratio < threshold:
                    continue
                # Confidence: more historical occurrences → higher.
                confidence = min(1.0, bin_count
                                  / max(1, min_observations_per_table()))
                out.append(PredictedSpike(
                    bucket            = bucket,
                    table_prefix      = prefix,
                    hours_ahead       = hours_ahead,
                    day_of_week       = dow,
                    hour_of_day       = hour,
                    expected_queries  = round(expected, 1),
                    baseline_queries_per_hour =
                        round(baseline_per_hour, 3),
                    spike_ratio       = round(ratio, 2),
                    confidence        = round(confidence, 2),
                    rationale         = (
                        f"Historical (dow={dow}, h={hour:02d}) bin "
                        f"averaged {expected:.1f} queries/occurrence "
                        f"vs table baseline {baseline_per_hour:.2f}/h "
                        f"({ratio:.1f}×).  Pre-warming state."
                    ),
                ))
        out.sort(key=lambda s: -s.spike_ratio)
        return out

    def forecasted_targets(
        self, bucket_filter: Optional[str] = None,
    ) -> List[Tuple[str, str]]:
        """Convenience: unique (bucket, prefix) tuples likely to spike
        in the next forecast window.  Consumed by the adaptive prefetcher
        to bias target ranking."""
        seen: set = set()
        out: List[Tuple[str, str]] = []
        for sp in self.next_24h_predictions(bucket_filter=bucket_filter):
            k = (sp.bucket, sp.table_prefix)
            if k in seen:
                continue
            seen.add(k)
            out.append(k)
        return out


__all__ = [
    "WorkloadForecaster", "PredictedSpike",
    "enabled", "lookback_days", "min_observations_per_table",
    "spike_multiplier_threshold", "max_lookahead_hours",
]
