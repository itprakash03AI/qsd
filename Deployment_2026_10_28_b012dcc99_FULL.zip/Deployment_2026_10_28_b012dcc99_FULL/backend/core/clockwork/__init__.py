"""Clockwork authoring plane — QueryStudio's side of the scheduler.

2026-09-10.  Plan: ``docs/CLOCKWORK_PLATFORM_PLAN_V2_2026_09_10.html`` (the
contract) and ``docs/CLOCKWORK_PLATFORM_PLAN_2026_09_10.html`` (tenancy,
migration, authority).

What lives here is AUTHORING and OBSERVATION only:

* ``scope``        — the one predicate for "a scheduler-scoped principal sees
                     the scheduler and nothing else" (API middleware + the
                     frontend's visibility map both read it).
* ``catalogue``    — the declared task-type vocabulary the validator checks a
                     job against, and the routability merge.
* ``placeholders`` — the date-placeholder vocabulary, Oracle format masks, and
                     a resolver that is a PURE function of the scheduled time.
* ``validation``   — ``validate_job``: the same shape check the UI's 400 and
                     the per-row pre-claim check must agree on.
* ``fire_log``     — REFLECTS Clockwork's own ``clockwork_fire_log`` /
                     ``clockwork_fire_steps`` tables.  Never models them: two
                     DDLs for one table is a drift defect.
* ``explain``      — "why did this not run?", computed from rows, never from
                     silence.
* ``core_bridge``  — the ONE lazy import of the Clockwork core package
                     (plan v2 §6): its ``validate_job``, catalogue and
                     settings schema.  Unavailable = a scoped 503, never a
                     boot failure.
* ``projection``   — the authored job -> the definition the dispatcher runs
                     (the core's grammar), validated by the CORE's own
                     ``validate_job`` and stored on the row by its one writer.
* ``dispatch_views`` / ``sql/CLOCKWORK_DISPATCH.sql`` — the two views the
                     dispatcher's postgres backend reads (``clockwork_dispatch_jobs``,
                     ``clockwork_dispatch_manual``), projected from the authoring
                     tables.  ONE DDL, created at API start; contract in
                     ``clockwork/clockwork/sql/postgres/DISPATCH_CONTRACT.md``.

QueryStudio NEVER executes a job.  A manual fire is a REQUEST ROW that the
Clockwork deployment claims under its own protocol (2026-09-10: it now
does -- the request is projected through ``clockwork_dispatch_manual``, and
the dispatcher moves it PENDING -> CLAIMED in the claim's own transaction,
or REFUSED / EXPIRED with the reason); a second claim protocol here would
be the duplicate-fire hazard the whole design exists to prevent.
"""
