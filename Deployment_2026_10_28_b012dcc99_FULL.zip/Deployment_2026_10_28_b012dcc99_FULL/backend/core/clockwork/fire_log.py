"""Read Clockwork's fire log and step rows by REFLECTION.

``clockwork_fire_log`` and ``clockwork_fire_steps`` are CLOCKWORK-OWNED.
Their DDL ships with the Clockwork backend for the database it claims in;
QueryStudio never models them in SQLAlchemy metadata (``create_all`` would
then make a second, drifting spelling of the same table) and never writes
them.  This module reflects them at runtime and reads.

UNKNOWN IS NOT EMPTY.  A database where the DDL has not been applied yet
answers "not available, because ..." — never ``[]``.  The route turns that
into a 503 with the reason; a UI that showed "no runs" for a table that
does not exist would be the silent-404 class of defect this repo keeps
finding.  Likewise a table that IS present but lacks a column this reader
depends on is reported by name: pin the surface, not the bytes.

Column names are the PostgreSQL DDL Clockwork ships
(``clockwork/clockwork/sql/postgres/CLOCKWORK_FIRE_LOG.sql`` and
``CLOCKWORK_FIRE_STEPS.sql``); ``tests/test_clockwork_integration_2026_09_10.py``
pins every REQUIRED column below to those files, and the HTTP suite runs
the reader against tables created FROM those files.
The reader is tolerant of the RECORD columns (``placeholders``,
``calendar_version`` -- plan v2 §4, shipped by the core on 2026-09-11 and
written IN the claim INSERT) and strict about the required ones.

UNKNOWN IS NOT EMPTY, again, for the record: a row whose ``placeholders``
is NULL -- older than the columns, or a table that predates them -- reads
as ``placeholders: None`` with ``placeholders_recorded: False``, and the UI
says "not recorded".  Only a row that carries the record reads as a dict;
a step in it with ``sent: []`` is "no placeholders" and that is a
different finding.  Until 2026-09-11 this reader returned ``{}`` for both,
so every run in the history showed an empty placeholder set.
"""
from __future__ import annotations

import json
import logging
import threading
from datetime import datetime
from typing import Any, Dict, List, Mapping, Optional, Tuple

logger = logging.getLogger(__name__)

FIRE_LOG_TABLE = "clockwork_fire_log"
FIRE_STEPS_TABLE = "clockwork_fire_steps"

#: The columns a fire-log reader cannot do without.
REQUIRED_FIRE_COLUMNS = ("fire_key", "job_id", "job_scope", "scheduled_fire",
                         "task_type", "status", "claimed_at")
#: What the steps reader needs to attach a row to its fire.
REQUIRED_STEP_COLUMNS = ("fire_key",)

#: Aliases a Clockwork DDL may use for the same fact.  First present wins.
_STEP_ALIASES: Dict[str, Tuple[str, ...]] = {
    "seq": ("seq", "step_index", "step_no", "position", "step_seq"),
    "name": ("name", "step_name"),
    "task_type": ("task_type",),
    "status": ("status",),
    "started_at": ("started_at", "claimed_at"),
    "ended_at": ("ended_at", "completed_at", "finished_at"),
    "params": ("params", "resolved_params", "params_json"),
    "outputs": ("outputs", "outputs_json"),
    "detail": ("detail", "message"),
    "guard": ("guard", "guard_json", "when"),
}


class FireLogUnavailable(RuntimeError):
    """The fire log cannot be read; ``reason`` says why."""

    def __init__(self, reason: str, code: str = "table_missing"):
        super().__init__(reason)
        self.reason = reason
        self.code = code


_lock = threading.Lock()
_reflected: Dict[Tuple[int, str], Any] = {}


def _table(engine, name: str, required: Tuple[str, ...]):
    """Reflect ``name``'s COLUMN NAMES once per engine; raise
    :class:`FireLogUnavailable` when absent or missing a required column.

    Names, not types.  The reader pins the surface (which columns exist)
    and reads values as the driver returns them: on PostgreSQL a
    ``timestamptz`` arrives as an aware datetime, on SQLite (the test
    suite, running the SAME shipped DDL) as the text that was inserted.
    A full ``Table(autoload)`` reflection assigned SQLite's NUMERIC
    affinity to ``timestamptz`` and its result processor then raised
    ``TypeError: must be real number, not str`` on every row -- a type it
    had guessed, applied to a value it had not.
    """
    import sqlalchemy as sa
    key = (id(engine), name)
    with _lock:
        t = _reflected.get(key)
    if t is not None:
        return t
    insp = sa.inspect(engine)
    if not insp.has_table(name):
        raise FireLogUnavailable(
            f"table {name!r} is not present in this database: Clockwork's DDL has not been "
            f"applied here (it ships with the Clockwork backend; QueryStudio never creates it)",
            code="table_missing")
    names = [str(c["name"]) for c in insp.get_columns(name)]
    cols = {n.lower() for n in names}
    missing = [c for c in required if c not in cols]
    if missing:
        raise FireLogUnavailable(
            f"table {name!r} is present but lacks column(s) {', '.join(missing)}; the reader "
            f"pins that surface and will not guess", code="column_missing")
    t = sa.table(name, *[sa.column(n) for n in names])
    with _lock:
        _reflected[key] = t
    return t


def reset_reflection_cache() -> None:
    """Tests rebind engines between modules; drop what was reflected."""
    with _lock:
        _reflected.clear()


def availability(engine) -> Dict[str, Any]:
    """``{"available": bool, "reason": str, "steps_available": bool}`` —
    stated, so a list response can say why ``last_fire`` is null."""
    code = None
    try:
        _table(engine, FIRE_LOG_TABLE, REQUIRED_FIRE_COLUMNS)
        fire_ok, reason = True, ""
    except FireLogUnavailable as exc:
        fire_ok, reason, code = False, exc.reason, exc.code
    except Exception as exc:                          # noqa: BLE001
        fire_ok, reason, code = False, f"reflection failed: {exc}", "reflection_failed"
    steps_ok = False
    if fire_ok:
        try:
            _table(engine, FIRE_STEPS_TABLE, REQUIRED_STEP_COLUMNS)
            steps_ok = True
        except Exception:                             # noqa: BLE001
            steps_ok = False
    # ``code`` distinguishes "not deployed yet" (table_missing: nothing to
    # protect) from "cannot be read" (unknown, and unknown is unsafe) --
    # the run-now gate needs the difference, a reason string cannot give it.
    return {"available": fire_ok, "reason": reason, "steps_available": steps_ok, "code": code}


def _col(t, name: str):
    for c in t.columns:
        if c.name.lower() == name:
            return c
    return None


def _iso(v: Any) -> Any:
    if isinstance(v, datetime):
        return v.isoformat()
    return v


def _json(v: Any) -> Any:
    if isinstance(v, (dict, list)) or v is None:
        return v
    if isinstance(v, (bytes, bytearray)):
        v = v.decode("utf-8", "replace")
    if isinstance(v, str):
        s = v.strip()
        if s[:1] in ("{", "["):
            try:
                return json.loads(s)
            except ValueError:
                return v
    return v


def _row_dict(row) -> Dict[str, Any]:
    m = row._mapping if hasattr(row, "_mapping") else dict(row)
    return {str(k).lower(): v for k, v in dict(m).items()}


def _normalise_fire(raw: Mapping[str, Any]) -> Dict[str, Any]:
    d = dict(raw)
    key = str(d.get("fire_key") or "")
    parts = key.split("|")
    tenant = d.get("tenant") or (parts[0] if len(parts) >= 4 else None)
    out = {
        "fire_key": key,
        "tenant": tenant,
        "job_id": d.get("job_id"),
        "scope": d.get("job_scope"),
        "scheduled_fire": _iso(d.get("scheduled_fire")),
        "cron_expression": d.get("cron_expression"),
        "task_type": d.get("task_type"),
        "task_ref": d.get("task_ref"),
        "status": d.get("status"),
        "claimed_by": d.get("claimed_by"),
        "deployment_id": d.get("deployment_id") or d.get("claimed_by"),
        "claimed_at": _iso(d.get("claimed_at")),
        "completed_at": _iso(d.get("completed_at")),
        "detail": d.get("detail"),
        "job_version": d.get("job_version"),
        "trigger": d.get("trigger") or ("manual" if (d.get("job_scope") or "").startswith("manual:")
                                        else "resume" if (d.get("job_scope") or "").startswith("resume:")
                                        else "schedule"),
        "parent_fire_key": d.get("parent_fire_key"),
        "resume_from_step": d.get("resume_from_step"),
        "calendar_version": d.get("calendar_version"),
    }
    out.update(_record_fields(d.get("placeholders")))
    return out


def _record_fields(raw: Any) -> Dict[str, Any]:
    """The RECORD as three fields: ``placeholders`` (the parsed record, a
    dict, or ``None``), ``placeholders_recorded`` (was anything written)
    and ``placeholders_problem`` (why a written value could not be read).

    NULL / absent column -> not recorded.  JSON that parses to an object
    -> recorded.  Anything else that was written (a core this reader does
    not know, or a bounded rendering that still failed) is REPORTED, not
    rendered as empty: ``placeholders`` stays ``None`` and the problem
    names what was found.
    """
    if raw is None or (isinstance(raw, (str, bytes, bytearray)) and not str(raw).strip()):
        return {"placeholders": None, "placeholders_recorded": False,
                "placeholders_problem": None}
    parsed = _json(raw)
    if isinstance(parsed, dict):
        return {"placeholders": parsed, "placeholders_recorded": True,
                "placeholders_problem": None}
    text = raw.decode("utf-8", "replace") if isinstance(raw, (bytes, bytearray)) else str(raw)
    return {"placeholders": None, "placeholders_recorded": True,
            "placeholders_problem": (f"the row carries a placeholders value this reader "
                                     f"cannot parse as a record: {text[:120]!r}")}


def _normalise_step(raw: Mapping[str, Any]) -> Dict[str, Any]:
    d = dict(raw)
    out: Dict[str, Any] = {"fire_key": d.get("fire_key")}
    for target, aliases in _STEP_ALIASES.items():
        val = None
        for a in aliases:
            if a in d and d[a] is not None:
                val = d[a]
                break
        if target in ("params", "outputs", "guard"):
            val = _json(val)
        elif target in ("started_at", "ended_at"):
            val = _iso(val)
        out[target] = val
    s, e = d.get("started_at"), (d.get("ended_at") or d.get("completed_at") or d.get("finished_at"))
    if isinstance(s, datetime) and isinstance(e, datetime):
        out["duration_seconds"] = round((e - s).total_seconds(), 3)
    else:
        out["duration_seconds"] = None
    out["raw"] = {k: _iso(v) for k, v in d.items()}
    return out


def list_fires(engine, tenant: str, job_id: Any, *, limit: int = 50,
               offset: int = 0) -> Tuple[List[Dict[str, Any]], int]:
    """Fires for one job, newest scheduled first, with steps nested.

    Filtered by the fire-key prefix ``tenant|job_id|`` — which is how the
    key is built on both sides — so the reader works whether or not the
    DDL carries a separate ``tenant`` column.
    """
    import sqlalchemy as sa
    t = _table(engine, FIRE_LOG_TABLE, REQUIRED_FIRE_COLUMNS)
    fk = _col(t, "fire_key")
    prefix = f"{tenant}|{job_id}|"
    with engine.connect() as conn:
        total = conn.execute(
            sa.select(sa.func.count()).select_from(t).where(fk.like(prefix.replace("%", r"\%") + "%"))
        ).scalar() or 0
        rows = conn.execute(
            sa.select(t).where(fk.like(prefix.replace("%", r"\%") + "%"))
            .order_by(_col(t, "scheduled_fire").desc()).limit(int(limit)).offset(int(offset))
        ).fetchall()
        fires = [_normalise_fire(_row_dict(r)) for r in rows]
        keys = [f["fire_key"] for f in fires]
        steps_by_key: Dict[str, List[Dict[str, Any]]] = {k: [] for k in keys}
        if keys:
            try:
                st = _table(engine, FIRE_STEPS_TABLE, REQUIRED_STEP_COLUMNS)
                sfk = _col(st, "fire_key")
                srows = conn.execute(sa.select(st).where(sfk.in_(keys))).fetchall()
                for r in srows:
                    s = _normalise_step(_row_dict(r))
                    steps_by_key.setdefault(str(s["fire_key"]), []).append(s)
                for k in steps_by_key:
                    steps_by_key[k].sort(key=lambda s: (s.get("seq") is None, s.get("seq") or 0))
            except FireLogUnavailable as exc:
                logger.debug("[clockwork] steps table unavailable: %s", exc.reason)
    for f in fires:
        f["steps"] = steps_by_key.get(f["fire_key"], [])
    return fires, int(total)


def get_fire(engine, fire_key: str) -> Optional[Dict[str, Any]]:
    import sqlalchemy as sa
    t = _table(engine, FIRE_LOG_TABLE, REQUIRED_FIRE_COLUMNS)
    with engine.connect() as conn:
        row = conn.execute(sa.select(t).where(_col(t, "fire_key") == fire_key)).fetchone()
        if row is None:
            return None
        fire = _normalise_fire(_row_dict(row))
        fire["steps"] = []
        try:
            st = _table(engine, FIRE_STEPS_TABLE, REQUIRED_STEP_COLUMNS)
            srows = conn.execute(sa.select(st).where(_col(st, "fire_key") == fire_key)).fetchall()
            steps = [_normalise_step(_row_dict(r)) for r in srows]
            steps.sort(key=lambda s: (s.get("seq") is None, s.get("seq") or 0))
            fire["steps"] = steps
        except FireLogUnavailable:
            pass
    return fire


def latest_fire(engine, tenant: str, job_id: Any) -> Optional[Dict[str, Any]]:
    fires, _ = list_fires(engine, tenant, job_id, limit=1)
    return fires[0] if fires else None


__all__ = ["FireLogUnavailable", "availability", "list_fires", "get_fire", "latest_fire",
           "reset_reflection_cache", "FIRE_LOG_TABLE", "FIRE_STEPS_TABLE"]
