"""``validate_job`` — every problem with a job definition, by path.

Plan v2 §1 (the guarded sequence), §2 (the catalogue), §4 (placeholders),
§5 (no free SQL), §6 ("validation in two places, from one parser").

The function is PURE over the definition and a :class:`ValidationContext`
of lookups the caller supplies, so the API layer, the enable gate, the
manual-fire gate and a unit test all run the identical rule set.  It
returns a list of ``{"path": ..., "message": ...}`` — never raises for a
bad definition, only for a broken context.

Everything here REFUSES rather than guesses:

* a value carrying a date placeholder with no format mask is refused —
  there is no default mask (operator decision, 2026-09-10);
* a guard referencing a step that itself has a guard is refused — the
  alternative is inventing a truthiness for "did not run";
* a guard referencing an output the type does not declare is refused,
  listing the valid refs;
* a connection the AUTHOR cannot see is reported as not visible — the
  message does not say whether it exists;
* more than :data:`MAX_STEPS`, a non-linear shape, a bind type other than
  VARCHAR2, free SQL, a two-digit-year mask: refused.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from core.clockwork import catalogue as _cat
from core.clockwork import placeholders as _ph
from core.clockwork import query_templates as _qt
# The projection's own regexes: what the dispatcher can bind WHOLE, and what
# merely CONTAINS a placeholder.  Imported, not re-spelled, so the save-time
# rule and the projection's refusal are one decision.
from core.clockwork.projection import _PLACEHOLDER_ANY_RE, _PLACEHOLDER_ONLY_RE

Problem = Dict[str, str]

_NAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_\-]{0,99}$")
# The CORE's rule (``clockwork.registry.NAME_RE``, applied by
# ``job_definition._step_name`` and ``_REF_RE``): a step name is how a guard
# refers to the step and how the step row is named, and the core refuses any
# other shape.  ``^[A-Za-z][A-Za-z0-9_]{0,59}$`` here let ``Main`` save and be
# refused at ENABLE under path ``dispatch`` (2026-09-10 coverage audit, the
# same class as the ``QS-Prod`` tenant).  Pinned equal to the core by test.
_STEP_NAME_RE = re.compile(r"^[a-z][a-z0-9_]{0,38}$")
# The CORE's identifier rule (``clockwork.params._IDENT_RE``): letter-first,
# <=30 characters per part, at most three parts.  These values are
# concatenated into SQL by the dispatcher and it refuses any other shape;
# ``[A-Za-z_]...{0,127}`` here let ``_T`` and a 31-character name save and
# be refused at enable (2026-09-10 coverage audit).
_IDENT_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_$#]{0,29}$")
_QUALIFIED_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_$#]{0,29}(\.[A-Za-z][A-Za-z0-9_$#]{0,29}){0,2}$")
# Letter-first, <=30: the core's ``params.unqualified_identifier`` (a leading
# underscore saved here and was refused at enable).
_BIND_NAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]{0,29}$")
_URL_RE = re.compile(r"^https?://[^\s/@]+(:\d+)?(/[^\s]*)?$", re.I)
# The CORE's predicate compares for EQUALITY only (``projection._sql_scalar``
# refuses any other op: "cannot be projected").  Five more operators were
# accepted here until 2026-09-10 -- a save the dispatcher could never run.
_PREDICATE_OPS = ("=",)
# The CORE's HTTP rules (``clockwork.tasks.http_request``): a header name is
# an RFC 7230 token, three headers are the sender's, and a JSON path is
# dotted identifiers (``$.`` stripped by the projection; no array index).
_HEADER_TOKEN_RE = re.compile(r"^[A-Za-z0-9!#$%&'*+.^_`|~-]+$")
_RESERVED_HEADERS = frozenset({"idempotency-key", "host", "content-length"})
_CREDENTIAL_HEADERS = frozenset({"authorization", "proxy-authorization", "cookie", "x-api-key"})
_JSON_PATH_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*$")
#: The one output name every http_request step has before any expect entry.
_HTTP_STATUS_OUTPUT = "status_code"
# The CORE's rule (``clockwork.occurrence.parse_tenant`` / ``registry.NAME_RE``):
# the tenant is the first field of the fire key and the dispatcher REFUSES any
# other shape per row, so accepting a wider shape here was a save the
# dispatcher could never run (2026-09-10 audit: ``QS-Prod`` saved 201, fired
# 202, refused on every tick).
_TENANT_RE = re.compile(r"^[a-z][a-z0-9_]{0,38}$")
_AUTHORITY_RE = re.compile(r"^[A-Za-z0-9_\-.]{1,100}$")

MAX_GRACE_SECONDS = 7 * 24 * 3600


@dataclass
class ValidationContext:
    """What the validator needs from the outside world, as callables so the
    API layer, the gates and the tests supply them the same way."""
    #: id -> masked connection dict (or None).  Only ``connection_type`` and
    #: ``config.system_account_id`` are read.
    connection_lookup: Callable[[int], Optional[Mapping[str, Any]]] = lambda _id: None
    #: ids -> subset the AUTHOR may not use (``core.entitlements.denied_connection_ids``).
    denied_connections: Callable[[Sequence[int]], Sequence[int]] = lambda ids: list(ids)
    #: id -> query template dict (or None).
    template_lookup: Callable[[int], Optional[Mapping[str, Any]]] = lambda _id: None
    #: id -> feed calendar dict (or None).
    calendar_lookup: Callable[[int], Optional[Mapping[str, Any]]] = lambda _id: None
    #: task type name -> declaration (built-in unless a deployment reported).
    task_types: Mapping[str, Mapping[str, Any]] = field(
        default_factory=lambda: dict(_cat.BUILTIN_TASK_TYPES))
    #: system account id -> dict (``environment``, ``is_active``, ``use_vault``).
    system_account_lookup: Callable[[int], Optional[Mapping[str, Any]]] = lambda _id: None
    #: The environment the job would fire in (its authority deployment's, or
    #: this pod's).  Empty = undeclared; the comparison is then skipped and
    #: only UNSPECIFIED accounts are reported.
    fire_environment: str = ""
    #: The ONE schedule-expression parser: ``text -> (problems, warnings)``.
    #: The API supplies the core's ``schedule.check_expression`` so a
    #: five-field cron and ``wd N HH:MM`` mean the same thing here as in the
    #: dispatcher; the default is cron-only and REFUSES a working-day
    #: expression it cannot validate rather than guessing.
    schedule_check: Callable[[Any], Any] = field(default=None)  # type: ignore[assignment]


def _p(path: str, message: str) -> Problem:
    return {"path": path, "message": message}


def _is_int(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool)


# ── Top level ────────────────────────────────────────────────────────────


def validate_job(definition: Mapping[str, Any],
                 ctx: Optional[ValidationContext] = None,
                 *, for_enable: bool = False) -> List[Problem]:
    """Every problem with ``definition``.  Empty list == valid.

    ``for_enable`` adds the gates an ENABLED job must pass and a saved
    draft need not: an authority, and a fire-environment match for every
    system account the job's connections bind.
    """
    ctx = ctx or ValidationContext()
    problems: List[Problem] = []
    if not isinstance(definition, Mapping):
        return [_p("", "definition must be a JSON object")]
    d = definition

    name = d.get("name")
    if not isinstance(name, str) or not _NAME_RE.fullmatch(name.strip() or ""):
        problems.append(_p("name", "name is required: letters, digits, '_' or '-', "
                                   "starting with a letter, at most 100 characters"))

    desc = d.get("description", "")
    if desc is not None and not isinstance(desc, str):
        problems.append(_p("description", "description must be text"))

    enabled = d.get("enabled", False)
    if not isinstance(enabled, bool):
        problems.append(_p("enabled", "enabled must be true or false"))

    tenant = d.get("tenant", "querystudio")
    if not isinstance(tenant, str) or not _TENANT_RE.fullmatch(tenant):
        problems.append(_p("tenant", "tenant must be lower-case letters, digits and '_', starting with a letter, at most 39 characters (the dispatcher's own rule for the first field of the fire key)"))

    owner = d.get("owner", "")
    if owner is not None and not isinstance(owner, str):
        problems.append(_p("owner", "owner must be a username or team name"))
    elif isinstance(owner, str) and owner.strip():
        # ``owner`` IS A DELIVERY ADDRESS.  ``core/clockwork/notifier.py``
        # reads it as an email when it contains ``@`` and hands it to the
        # organisation's own SMTP server, so "must be a string" meant a
        # non-admin author could choose who the organisation writes to, and
        # make it write by failing the job.  The notifier is the authority
        # (it gates the DOMAIN against the operator's list, which only the
        # server knows); this refuses the shapes that are wrong wherever
        # they are read, so the author is told at SAVE and not by silence.
        problems.extend(_owner_problems(owner.strip()))

    # ── schedule ────────────────────────────────────────────────────
    cron = d.get("cron")
    if not isinstance(cron, str) or not cron.strip():
        problems.append(_p("cron", "a schedule expression is required: a five-field cron, or "
                                   "'wd N HH:MM' for the N-th working day of the month"))
    else:
        schedule_problems, _warnings = (ctx.schedule_check or cron_only_schedule_check)(cron)
        problems.extend(_p("cron", m) for m in schedule_problems)

    tz = d.get("timezone", "UTC")
    if not isinstance(tz, str) or not tz.strip():
        problems.append(_p("timezone", "timezone is required (an IANA zone such as UTC or Europe/London)"))
    else:
        try:
            ZoneInfo(tz)
        except (ZoneInfoNotFoundError, ValueError, KeyError):
            problems.append(_p("timezone", f"{tz!r} is not a known IANA timezone"))

    cal_id = d.get("calendar_id")
    wd = d.get("weekend_days")
    if cal_id is None and wd is None:
        problems.append(_p("calendar_id", "a job must bind a calendar OR declare its weekend days "
                                          "explicitly; Clockwork must not guess"))
    elif cal_id is not None and wd is not None:
        problems.append(_p("weekend_days", "declare a calendar OR weekend days, not both"))
    elif cal_id is not None:
        if not _is_int(cal_id):
            problems.append(_p("calendar_id", "calendar_id must be an integer"))
        elif ctx.calendar_lookup(int(cal_id)) is None:
            problems.append(_p("calendar_id", f"calendar {cal_id} is not visible"))
    else:
        problems.extend(_validate_weekend_days(wd))

    grace = d.get("misfire_grace_seconds", 300)
    if not _is_int(grace) or grace < 0 or grace > MAX_GRACE_SECONDS:
        problems.append(_p("misfire_grace_seconds",
                           f"misfire_grace_seconds must be an integer between 0 and {MAX_GRACE_SECONDS}"))

    idem = d.get("idempotent", None)
    if idem is not None and not isinstance(idem, bool):
        problems.append(_p("idempotent", "idempotent is tri-state: true, false or null (unknown)"))

    authority = d.get("authority")
    if authority is not None and (not isinstance(authority, str) or not _AUTHORITY_RE.fullmatch(authority)):
        problems.append(_p("authority", "authority must be a deployment id (1-100 chars) or null"))
    if for_enable and not authority:
        problems.append(_p("authority", "an ENABLED job must name the deployment that has authority "
                                        "for it; null is 'not mine' on every deployment"))

    # ── job-level connection ────────────────────────────────────────
    job_conn = d.get("connection_id")
    conn_ids: List[int] = []
    if job_conn is not None:
        if not _is_int(job_conn):
            problems.append(_p("connection_id", "connection_id must be an integer or null"))
        else:
            conn_ids.append(int(job_conn))

    # ── access lists ────────────────────────────────────────────────
    access = d.get("access", {"edit": [], "enable": [], "fire": []})
    if not isinstance(access, Mapping):
        problems.append(_p("access", "access must be an object with edit / enable / fire lists"))
    else:
        for k in ("edit", "enable", "fire"):
            v = access.get(k, [])
            if not isinstance(v, list) or any(not isinstance(x, str) or not x.strip() for x in v):
                problems.append(_p(f"access.{k}", f"access.{k} must be a list of usernames"))
        for k in access:
            if k not in ("edit", "enable", "fire"):
                problems.append(_p(f"access.{k}", f"unknown access list {k!r}; valid: edit, enable, fire"))

    # ── steps ───────────────────────────────────────────────────────
    steps = d.get("steps")
    if not isinstance(steps, list) or not steps:
        problems.append(_p("steps", "at least one step is required"))
        steps = []
    elif len(steps) > _cat.MAX_STEPS:
        problems.append(_p("steps", f"at most {_cat.MAX_STEPS} steps; {len(steps)} given.  The chain is "
                                    f"linear by design — a longer sequence belongs in a dataflow"))
    seen_names: Dict[str, int] = {}
    #: step name -> {output name: type}, in the core's vocabulary, so a guard
    #: literal is checked against the output's DECLARED type at save.
    outputs_by_step: Dict[str, Dict[str, str]] = {}
    guarded_steps: set = set()
    for i, step in enumerate(steps):
        path = f"steps[{i}]"
        if not isinstance(step, Mapping):
            problems.append(_p(path, "step must be an object"))
            continue
        sname = step.get("name")
        if not isinstance(sname, str) or not _STEP_NAME_RE.fullmatch(sname):
            problems.append(_p(f"{path}.name", "step name: lower-case letters, digits, '_' — starting with a "
                                               "letter, at most 39 characters (the dispatcher's own rule: a "
                                               "guard refers to the step by it)"))
            sname = f"step{i}"
        elif sname in seen_names:
            problems.append(_p(f"{path}.name", f"step name {sname!r} is already used by step {seen_names[sname]}"))
        seen_names.setdefault(sname, i)

        ttype = step.get("task_type")
        decl = ctx.task_types.get(ttype) if isinstance(ttype, str) else None
        if decl is None:
            problems.append(_p(f"{path}.task_type",
                               f"unknown task type {ttype!r}; valid: {', '.join(sorted(ctx.task_types))}"))
            params = step.get("params") if isinstance(step.get("params"), Mapping) else {}
            outputs_by_step[sname] = {}
        else:
            params = step.get("params")
            if params is None:
                params = {}
            if not isinstance(params, Mapping):
                problems.append(_p(f"{path}.params", "params must be an object"))
                params = {}
            problems.extend(_validate_params(ttype, params, f"{path}.params", ctx, job_conn, conn_ids))
            outputs_by_step[sname] = _cat.declared_output_types(ttype, params, decl)

        when = step.get("when")
        if when is not None:
            guarded_steps.add(sname)
            problems.extend(_validate_guard(when, f"{path}.when", i, steps, outputs_by_step, guarded_steps))

        for k in step:
            if k not in ("name", "task_type", "params", "when"):
                problems.append(_p(f"{path}.{k}", f"unknown step field {k!r}; a step is (name, task_type, params, when)"))

    # ── entitlement on every connection the job would use ───────────
    uniq = sorted({c for c in conn_ids if _is_int(c)})
    if uniq:
        denied = set(int(x) for x in (ctx.denied_connections(uniq) or []))
        for cid in uniq:
            if cid in denied:
                problems.append(_p("connection_id" if cid == job_conn else "steps",
                                   f"connection {cid} is not visible to you"))
    # ── environment gate (enable / fire) ────────────────────────────
    if for_enable:
        problems.extend(_validate_environments(uniq, ctx))

    # ── unknown top-level keys are refused: a typo must not vanish ──
    for k in d:
        if k not in _KNOWN_TOP_KEYS:
            problems.append(_p(k, f"unknown field {k!r}"))
    return problems


def cron_only_schedule_check(text: Any) -> Any:
    """The fallback when the core is not loadable: a cron is checked with
    croniter; a working-day expression is REFUSED by name, because only the
    core's parser can say what it means and a guess here would be a second
    parser.  Returns ``(problems, warnings)`` like the core's."""
    expr = str(text or "").strip()
    if expr.lower().startswith("wd"):
        return ([f"{expr!r} is a working-day schedule; it can only be validated by the "
                 f"Clockwork core, which is not loadable here"], [])
    try:
        from croniter import croniter
    except ImportError:                          # pragma: no cover - dependency guard
        return (["croniter is not installed; cannot validate"], [])
    if len(expr.split()) != 5 or not croniter.is_valid(expr):
        return ([f"{expr!r} is not a valid cron expression"], [])
    return ([], [])


def schedule_warnings(definition: Mapping[str, Any],
                      ctx: Optional[ValidationContext] = None) -> List[Problem]:
    """The warnings a VALID schedule expression carries -- cron's ORed
    day-of-month and day-of-week above all.  Returned beside every validate
    and save so the case is never silent; a refusal is the validator's."""
    ctx = ctx or ValidationContext()
    cron = definition.get("cron") if isinstance(definition, Mapping) else None
    if not isinstance(cron, str) or not cron.strip():
        return []
    _problems, warnings = (ctx.schedule_check or cron_only_schedule_check)(cron)
    return [_p("cron", w) for w in warnings]


_KNOWN_TOP_KEYS = frozenset({
    "name", "description", "enabled", "tenant", "owner", "cron", "timezone",
    "calendar_id", "weekend_days", "misfire_grace_seconds", "idempotent",
    "authority", "connection_id", "steps", "access", "expected_version",
    # read-only echoes a client may send back unchanged
    "id", "version", "secrets", "created_by", "created_at", "updated_by", "updated_at",
    "owner_group_id", "can_edit", "can_enable", "can_fire",
})

#: The AUTHORABLE keys — what a version snapshot holds and what the gates
#: validate.  A stored row's to_dict() carries more (id, version, flags).
DEFINITION_KEYS: tuple = (
    "name", "description", "enabled", "tenant", "owner", "cron", "timezone",
    "calendar_id", "weekend_days", "misfire_grace_seconds", "idempotent",
    "authority", "connection_id", "steps", "access",
)


def definition_of(job: Mapping[str, Any]) -> Dict[str, Any]:
    """Project a stored job dict onto its authorable definition."""
    return {k: job.get(k) for k in DEFINITION_KEYS if k in job}


def _validate_weekend_days(wd: Any) -> List[Problem]:
    if not isinstance(wd, list):
        return [_p("weekend_days", "weekend_days must be a list of ISO weekday numbers (Mon=1 .. Sun=7)")]
    out: List[Problem] = []
    for i, x in enumerate(wd):
        if not _is_int(x) or x < 1 or x > 7:
            out.append(_p(f"weekend_days[{i}]", f"{x!r} is not an ISO weekday number (Mon=1 .. Sun=7)"))
    if len(set(wd)) != len(wd):
        out.append(_p("weekend_days", "weekend_days repeats a day"))
    if len(wd) >= 7:
        out.append(_p("weekend_days", "every day cannot be a weekend"))
    return out


# ── Guards ───────────────────────────────────────────────────────────────


def _validate_guard(when: Any, path: str, index: int, steps: list,
                    outputs_by_step: Mapping[str, Mapping[str, str]],
                    guarded: set) -> List[Problem]:
    out: List[Problem] = []
    if not isinstance(when, list) or not when:
        return [_p(path, "when must be a non-empty list of clauses, or null for unconditional")]
    earlier = [s.get("name") for s in steps[:index] if isinstance(s, Mapping)]
    valid_refs = [f"{s}.{o}" for s in earlier if s not in guarded for o in outputs_by_step.get(s, {})]
    for j, clause in enumerate(when):
        cp = f"{path}[{j}]"
        if not isinstance(clause, Mapping):
            out.append(_p(cp, "clause must be an object {ref, op, value}"))
            continue
        ref = clause.get("ref")
        op = clause.get("op")
        if op not in _cat.GUARD_OPS:
            out.append(_p(f"{cp}.op", f"op must be one of {', '.join(_cat.GUARD_OPS)}"))
        value = clause.get("value")
        value_ok = "value" in clause and _cat.output_type_of(value) != ""
        if not value_ok:
            out.append(_p(f"{cp}.value", "value must be a string, number or boolean"))
        if not isinstance(ref, str) or "." not in ref:
            out.append(_p(f"{cp}.ref", f"ref must be '<earlier step>.<output>'; valid: "
                                       f"{', '.join(valid_refs) or '(none — no earlier unconditional step declares an output)'}"))
            continue
        sname, _, oname = ref.partition(".")
        if sname not in earlier:
            out.append(_p(f"{cp}.ref", f"{ref!r} does not name an EARLIER step; valid: "
                                       f"{', '.join(valid_refs) or '(none)'}"))
        elif sname in guarded:
            out.append(_p(f"{cp}.ref", f"{ref!r} references step {sname!r} which itself has a guard; a guard "
                                       f"may only read an UNCONDITIONAL earlier step — otherwise 'did not "
                                       f"run' needs an invented truthiness"))
        elif oname not in outputs_by_step.get(sname, {}):
            out.append(_p(f"{cp}.ref", f"step {sname!r} declares no output {oname!r}; valid: "
                                       f"{', '.join(valid_refs) or '(none)'}"))
        else:
            # The CORE's rule (``job_definition._condition``): a guard
            # compares like with like.  ``"0"`` against a number output --
            # what the editor produces when a person types 0 into a text
            # field -- saved 201 and was refused at ENABLE until 2026-09-10.
            # An untyped output ("" -- an expect entry with no valid type)
            # is refused by the HTTP rules; nothing is invented here.
            expected = outputs_by_step[sname][oname]
            actual = _cat.output_type_of(value)
            if value_ok and expected and actual != expected:
                out.append(_p(f"{cp}.value",
                              f"value {value!r} is {actual}, but {ref} is declared {expected}.  "
                              f"A guard compares like with like; a cross-type comparison is "
                              f"refused rather than coerced (the dispatcher's own rule)"))
            elif expected == _cat.OUT_BOOLEAN and op in _cat.GUARD_OPS \
                    and op not in _cat.GUARD_BOOLEAN_OPS:
                out.append(_p(f"{cp}.op", f"op {op!r} is not meaningful on a boolean output; use "
                                          f"one of {', '.join(_cat.GUARD_BOOLEAN_OPS)}"))
        for k in clause:
            if k not in ("ref", "op", "value"):
                out.append(_p(f"{cp}.{k}", f"unknown clause field {k!r}"))
    return out


# ── Per-type params ──────────────────────────────────────────────────────


def _validate_params(ttype: str, params: Mapping[str, Any], path: str,
                     ctx: ValidationContext, job_conn: Any,
                     conn_ids: List[int]) -> List[Problem]:
    out: List[Problem] = []
    decl = ctx.task_types.get(ttype, {})
    schema = decl.get("config_schema", {}) or {}
    for k in params:
        if k not in schema:
            out.append(_p(f"{path}.{k}", f"unknown parameter {k!r} for {ttype}; valid: "
                                         f"{', '.join(sorted(schema)) or '(none)'}"))
    for k, spec in schema.items():
        if spec.get("required") and (k not in params or params.get(k) in (None, "")):
            out.append(_p(f"{path}.{k}", f"{k} is required for {ttype}"))

    step_conn = params.get("connection_id")
    if step_conn is not None and not _is_int(step_conn):
        out.append(_p(f"{path}.connection_id", "connection_id must be an integer"))
        step_conn = None
    effective_conn = step_conn if step_conn is not None else (job_conn if _is_int(job_conn) else None)
    if _is_int(step_conn):
        conn_ids.append(int(step_conn))

    if ttype in ("oracle_proc", "oracle_proc_cursor"):
        # 2026-09-11 audit: the cursor type had NO branch here, so its
        # procedure, binds and connection TYPE went unchecked at authoring
        # and the core refused them at enable.  It shares all three with
        # oracle_proc; only its cursor_param/status_column/message_column
        # differ, and the schema check above already governs those.
        out.extend(_validate_oracle_proc(params, path, ctx, effective_conn))
    elif ttype == "sql_scalar":
        out.extend(_validate_sql_scalar(params, path, ctx, effective_conn))
    elif ttype == "http_request":
        out.extend(_validate_http(params, path, ctx))
    elif ttype == "airflow_trigger":
        out.extend(_validate_airflow(params, path, ctx))
    elif ttype == "qs_api":
        out.extend(_validate_qs_api(params, path))
    # journal: nothing to validate; unknown keys already refused above.
    return out


#: A username / team name: no ``@``, no separator a mail header reads.
_OWNER_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._\- ]{0,99}$")
#: A single email address, conservatively.  ONE address -- a comma, a
#: semicolon, a newline or a ``<...>`` display name would each let one
#: ``owner`` value become several recipients or an injected header.
_OWNER_EMAIL_RE = re.compile(r"^[A-Za-z0-9._%+\-]{1,64}@[A-Za-z0-9.\-]{1,190}\.[A-Za-z]{2,24}$")


def _owner_problems(owner: str) -> List[Problem]:
    """``owner`` as the notifier reads it: a username, or ONE address."""
    if "@" in owner:
        if not _OWNER_EMAIL_RE.fullmatch(owner):
            return [_p("owner", "owner contains '@' and is therefore read as an EMAIL "
                                "ADDRESS by the alert notifier; it must be exactly one "
                                "address (no display name, no comma or semicolon list, "
                                "no newline), or a username with no '@'")]
        return []
    if not _OWNER_NAME_RE.fullmatch(owner):
        return [_p("owner", "owner must be a username or team name: letters, digits, "
                            "'.', '_', '-' and spaces, at most 100 characters -- or one "
                            "email address")]
    return []


def _egress_name_refusal(url: str) -> str:
    """Why this URL's HOST may never be a scheduled target, or ``''``.

    ONE implementation, and it is the dispatcher's: ``clockwork.egress``.
    Imported lazily through the bridge for the reason ``core_bridge`` states
    -- a task module that fails to import must be a scoped 503, never a boot
    failure of QueryStudio.  When the core is not importable at all the
    answer here is ``''``: a save that could not be checked against the
    dispatcher is already refused as not dispatchable by ``_dispatch_verdict``
    and by the row's writer, so this must not invent a second verdict out of
    an absence.
    """
    from core.clockwork import core_bridge as _cb
    try:
        egress = _cb.load_core().egress
    except _cb.CoreUnavailable:
        return ""
    return egress.name_refusal(egress.host_of(url))


def _conn_type(ctx: ValidationContext, cid: Optional[int]) -> Optional[str]:
    if cid is None:
        return None
    row = ctx.connection_lookup(int(cid))
    if not row:
        return None
    return str(row.get("connection_type") or "").lower()


def _placeholder_problems(value: Any, path: str, fmt: Any, *, needs_format: bool = True) -> List[Problem]:
    """Placeholder + mask checks for one BOUND scalar value (an Oracle bind,
    a predicate value, a template bind) -- the core's rules, at save:

    * a placeholder is bound WHOLE (``projection._placeholder_of``): text
      around one cannot be sent as one bind;
    * a date placeholder needs its mask (unless the caller says the
      dispatcher binds it as a real DATE), and the mask must be valid;
    * a LITERAL carries no mask -- it is sent exactly as typed, and the core
      refuses ``format`` on it ("a literal carries no format").  Until
      2026-09-10 a mask on a literal was merely checked for validity here.
    """
    out: List[Problem] = []
    fmt_path = path.rsplit(".", 1)[0] + ".format" if "." in path else path
    unknown = _ph.unknown_placeholders(value)
    if unknown:
        out.append(_p(path, f"unknown placeholder(s) {', '.join('{'+u+'}' for u in unknown)}; "
                            f"valid: {', '.join('{'+n+'}' for n in _ph.PLACEHOLDERS)}"))
    if isinstance(value, str) and _PLACEHOLDER_ANY_RE.search(value) \
            and not _PLACEHOLDER_ONLY_RE.fullmatch(value):
        out.append(_p(path, f"the dispatcher binds a placeholder WHOLE; {value!r} embeds one in "
                            f"other text and cannot be sent as one bind"))
    if _ph.date_placeholders_in(value):
        if not needs_format:
            return out
        if fmt is None or (isinstance(fmt, str) and not fmt.strip()):
            out.append(_p(fmt_path,
                          "format mask is REQUIRED when the value carries a date placeholder; "
                          "there is no default — an implicit mask is how a wrong-century date ships"))
        else:
            ok, why = _ph.mask_is_valid(str(fmt))
            if not ok:
                out.append(_p(fmt_path, why))
    elif fmt not in (None, ""):
        out.append(_p(fmt_path, f"a literal carries no format (got {fmt!r}); it is sent exactly as "
                                f"typed, so a mask applies only to a value carrying a date "
                                f"placeholder (the dispatcher refuses a mask on a literal)"))
    return out


def _validate_oracle_proc(params: Mapping[str, Any], path: str,
                          ctx: ValidationContext, conn: Optional[int]) -> List[Problem]:
    out: List[Problem] = []
    if conn is None:
        out.append(_p(f"{path}.connection_id", "oracle_proc needs a connection: the job's or the step's"))
    else:
        ct = _conn_type(ctx, conn)
        if ct is not None and ct != "oracle":
            out.append(_p(f"{path}.connection_id", f"connection {conn} is {ct!r}, not oracle"))
    proc = params.get("procedure")
    if not isinstance(proc, str) or not _QUALIFIED_RE.fullmatch(proc.strip() or ""):
        out.append(_p(f"{path}.procedure", "procedure must be an identifier such as PKG.PROC (no arguments, no SQL)"))
    binds = params.get("binds")
    if binds is None:
        binds = []
    if not isinstance(binds, list):
        return out + [_p(f"{path}.binds", "binds must be a list")]
    names: set = set()
    for i, b in enumerate(binds):
        bp = f"{path}.binds[{i}]"
        if not isinstance(b, Mapping):
            out.append(_p(bp, "bind must be an object {name, value, type, direction, format}"))
            continue
        n = b.get("name")
        if not isinstance(n, str) or not _BIND_NAME_RE.fullmatch(n):
            out.append(_p(f"{bp}.name", "bind name must be an identifier (e.g. p_business_date)"))
        elif n.lower() in names:
            out.append(_p(f"{bp}.name", f"bind {n!r} is declared twice"))
        else:
            names.add(n.lower())
        t = str(b.get("type", "") or "").upper()
        direction = str(b.get("direction", "IN") or "IN").upper()
        if direction not in _cat.ORACLE_BIND_DIRECTIONS:
            out.append(_p(f"{bp}.direction", "direction must be IN or OUT"))
        # IN: VARCHAR2 by decision (a procedure RECEIVES text).  OUT: what
        # comes BACK is compared by a guard, so NUMBER is allowed too --
        # the core's ``OUT_BIND_TYPES`` (2026-09-10 completion round).
        if direction == "OUT":
            if t not in _cat.ORACLE_OUT_BIND_TYPES:
                out.append(_p(f"{bp}.type", f"an OUT bind is VARCHAR2 (text) or NUMBER (compared "
                                            f"numerically by a guard); got {b.get('type')!r}"))
        elif t not in _cat.ORACLE_BIND_TYPES:
            out.append(_p(f"{bp}.type", f"bind type must be VARCHAR2 (every procedure parameter is VARCHAR2 "
                                        f"by decision; got {b.get('type')!r})"))
        if "format" not in b:
            out.append(_p(f"{bp}.format", "format is a required field: a mask for a date placeholder, "
                                          "or null for a value that carries none"))
        val = b.get("value")
        if direction == "IN":
            if val is None or (isinstance(val, str) and not val.strip()):
                out.append(_p(f"{bp}.value", "an IN bind needs a value (a literal or a {PLACEHOLDER})"))
            elif not isinstance(val, (str, int, float)) or isinstance(val, bool):
                out.append(_p(f"{bp}.value", "bind value must be text or a number (it is sent as VARCHAR2)"))
            else:
                out.extend(_placeholder_problems(val, f"{bp}.value", b.get("format")))
        elif direction == "OUT":
            # Only a VALID direction reaches a value rule: an unknown direction
            # is refused above, and used to be told "an OUT bind carries no
            # value" as well -- two refusals that contradicted each other.
            if val not in (None, ""):
                out.append(_p(f"{bp}.value", "an OUT bind carries no value"))
        for k in b:
            if k not in ("name", "value", "type", "direction", "format"):
                out.append(_p(f"{bp}.{k}", f"unknown bind field {k!r}"))
    return out


def _validate_sql_scalar(params: Mapping[str, Any], path: str,
                         ctx: ValidationContext, conn: Optional[int]) -> List[Problem]:
    out: List[Problem] = []
    if conn is None:
        out.append(_p(f"{path}.connection_id", "sql_scalar needs a connection: the job's or the step's"))
    else:
        # The core's ``sql_scalar`` requires ``oracle_sessions`` and its
        # session provider refuses any other connection kind BEFORE the
        # claim; until 2026-09-10 a Trino connection saved 201 here and the
        # job was refused on every tick.
        ct = _conn_type(ctx, conn)
        if ct is not None and ct != "oracle":
            out.append(_p(f"{path}.connection_id", f"connection {conn} is {ct!r}, not oracle; the "
                                                    f"dispatcher's sql_scalar reads through an Oracle "
                                                    f"session only"))
    if "sql" in params or "query" in params:
        out.append(_p(f"{path}.sql", "free SQL typed into a job is refused; use a declared query "
                                     "template or a structured predicate"))
    tmpl = params.get("template_id")
    pred = params.get("predicate")
    if (tmpl is None) == (pred is None):
        out.append(_p(path, "sql_scalar takes EXACTLY one of template_id or predicate"))
        return out
    if tmpl is not None:
        if not _is_int(tmpl):
            out.append(_p(f"{path}.template_id", "template_id must be an integer"))
            return out
        row = ctx.template_lookup(int(tmpl))
        if not row:
            out.append(_p(f"{path}.template_id", f"query template {tmpl} is not visible"))
            return out
        if not row.get("is_active", True):
            out.append(_p(f"{path}.template_id", f"query template {tmpl} is inactive"))
        # The dispatcher runs a template on an Oracle session only, and
        # applies the statement rules before the claim: the same rules, at
        # save, so a template that predates a rule is refused HERE with the
        # reason rather than at enable (``_qt`` is pinned equal to the core).
        want = str(row.get("connection_type") or "").lower()
        if want not in _qt.TEMPLATE_CONNECTION_TYPES:
            out.append(_p(f"{path}.template_id", f"template {tmpl} is declared for {want!r} connections; "
                                                  f"the dispatcher runs a template on an Oracle session only"))
        for why in _qt.statement_problems(row.get("sql_text")):
            out.append(_p(f"{path}.template_id", f"template {tmpl}: {why}"))
        # The binds the STATEMENT carries decide; the row's stored list is
        # the same function's output at create time, shown to the UI.
        declared = _qt.bind_names_of(str(row.get("sql_text") or ""))
        folded = {d.upper(): d for d in declared}
        bv = params.get("bind_values")
        if bv is None:
            bv = {}
        if not isinstance(bv, Mapping):
            out.append(_p(f"{path}.bind_values", "bind_values must be an object {bind: value}"))
            return out
        supplied = {str(k).upper() for k in bv}
        for b in declared:
            if b.upper() not in supplied:
                out.append(_p(f"{path}.bind_values.{b}", f"template declares bind :{b}; a value is required"))
        seen_folded: Dict[str, str] = {}
        for k, v in bv.items():
            kp = f"{path}.bind_values.{k}"
            if not isinstance(k, str) or not _BIND_NAME_RE.fullmatch(k):
                out.append(_p(kp, "bind name must be an identifier (letter-first, <=30)"))
                continue
            if k.upper() not in folded:
                out.append(_p(kp, f"template declares no bind :{k}; declared: "
                                  f"{', '.join(declared) or '(none)'}"))
                continue
            # Oracle folds bind names: ``run_date`` and ``RUN_DATE`` are ONE
            # bind, and the core refuses a bind supplied twice.
            if k.upper() in seen_folded:
                out.append(_p(kp, f"bind :{k} is already supplied as {seen_folded[k.upper()]!r} (Oracle "
                                  f"folds bind names, so these are ONE bind supplied twice)"))
                continue
            seen_folded[k.upper()] = k
            # The same rule as a predicate condition: the mapping form
            # carries a REQUIRED ``format`` key -- null binds a date
            # placeholder as a real DATE, a mask compares as text -- and a
            # bare scalar is a literal or a text placeholder (a date
            # placeholder needs the mapping form to say its mask, or null).
            if isinstance(v, Mapping):
                for extra in v:
                    if extra not in ("value", "format"):
                        out.append(_p(f"{kp}.{extra}", f"unknown bind field {extra!r}; a bind value is "
                                                        f"{{value, format}}"))
                if "format" not in v:
                    out.append(_p(f"{kp}.format", "format is a required field: a mask to bind a date "
                                                   "placeholder as TEXT, or null to bind it as a real DATE "
                                                   "(and for a value that carries none)"))
                val = v.get("value")
                if val is None or isinstance(val, (dict, list, bool)) or (isinstance(val, str) and not val.strip()):
                    out.append(_p(f"{kp}.value", "value must be text or a number (passed as a driver bind); "
                                                  "an empty literal would bind a NULL the query did not ask for"))
                else:
                    out.extend(_placeholder_problems(val, f"{kp}.value", v.get("format"),
                                                     needs_format=v.get("format") is not None))
            elif v is None or isinstance(v, (dict, list, bool)) or (isinstance(v, str) and not v.strip()):
                out.append(_p(f"{kp}.value", "value must be text or a number (passed as a driver bind); "
                                              "an empty literal would bind a NULL the query did not ask for"))
            else:
                # A bare scalar carries no mask, so a date placeholder in
                # it is a real DATE bind (what the projection sends).
                out.extend(_placeholder_problems(v, f"{kp}.value", None, needs_format=False))
        return out
    # structured predicate
    if not isinstance(pred, Mapping):
        return out + [_p(f"{path}.predicate", "predicate must be {table, conditions: [{column, op, value, format}]}")]
    table = pred.get("table")
    if not isinstance(table, str) or not _QUALIFIED_RE.fullmatch(table.strip() or ""):
        out.append(_p(f"{path}.predicate.table", "table must be an identifier (SCHEMA.TABLE)"))
    conds = pred.get("conditions")
    if not isinstance(conds, list) or not conds:
        out.append(_p(f"{path}.predicate.conditions", "at least one condition is required"))
        conds = []
    for i, c in enumerate(conds):
        cp = f"{path}.predicate.conditions[{i}]"
        if not isinstance(c, Mapping):
            out.append(_p(cp, "condition must be {column, op, value, format}"))
            continue
        col = c.get("column")
        if not isinstance(col, str) or not _IDENT_RE.fullmatch(col.strip()):
            out.append(_p(f"{cp}.column", "column must be an identifier"))
        if c.get("op", "=") not in _PREDICATE_OPS:
            out.append(_p(f"{cp}.op", f"op must be one of {', '.join(_PREDICATE_OPS)} (the dispatcher's "
                                      f"predicate compares for EQUALITY only)"))
        v = c.get("value")
        if v is None or isinstance(v, (dict, list, bool)) or (isinstance(v, str) and not v.strip()):
            # An empty literal is refused by the core too: "a NULL the
            # procedure did not ask for", never sent.
            out.append(_p(f"{cp}.value", "value must be text or a number (passed as a driver bind); "
                                         "an empty literal would bind a NULL the query did not ask for"))
        else:
            if "format" not in c:
                out.append(_p(f"{cp}.format", "format is a required field: a mask to compare as "
                                              "TEXT, or null to bind a date placeholder as a "
                                              "real DATE (and for a value that carries none)"))
            # A predicate's date placeholder with format null is bound as a
            # real DATE by the dispatcher -- no mask, no NLS parse, the safe
            # comparison against a DATE column.  A mask means "compare as
            # text" and must then be a valid one.  (An oracle_proc BIND is
            # different: every procedure parameter is VARCHAR2 by decision,
            # so there a date placeholder REQUIRES its mask.)
            out.extend(_placeholder_problems(v, f"{cp}.value", c.get("format"),
                                             needs_format=c.get("format") is not None))
        for k in c:
            if k not in ("column", "op", "value", "format", "cast_date_mask"):
                out.append(_p(f"{cp}.{k}", f"unknown condition field {k!r}"))
    for k in pred:
        if k not in ("table", "conditions"):
            out.append(_p(f"{path}.predicate.{k}", f"unknown predicate field {k!r}"))
    return out


def _validate_http(params: Mapping[str, Any], path: str, ctx: ValidationContext) -> List[Problem]:
    out: List[Problem] = []
    url = params.get("url")
    if not isinstance(url, str) or not _URL_RE.fullmatch(url.strip() or ""):
        out.append(_p(f"{path}.url", "url must be http(s)://host[:port]/path with no userinfo"))
    else:
        # THE EGRESS HOST RULE, and it is the CORE's own function -- not a
        # copy of it (``clockwork.egress.name_refusal``, reached through the
        # bridge).  A copy would be a second answer to "may this pod address
        # that host", and this repo has paid for one of those.  The DNS half
        # of the policy and the operator's allow-list are pod configuration
        # and are applied before the claim, which the authoring plane cannot
        # see; this half needs neither and is therefore checkable at save.
        refusal = _egress_name_refusal(str(url).strip())
        if refusal:
            out.append(_p(f"{path}.url", refusal))
    method = str(params.get("method", "POST") or "").upper()
    if method not in _cat.HTTP_METHODS:
        out.append(_p(f"{path}.method", f"method must be one of {', '.join(_cat.HTTP_METHODS)}"))
    headers = params.get("headers")
    if headers is not None:
        if not isinstance(headers, Mapping):
            out.append(_p(f"{path}.headers", "headers must be an object"))
        else:
            seen_headers: Dict[str, str] = {}
            for k, v in headers.items():
                hp = f"{path}.headers.{k}"
                lk = str(k).strip().lower()
                if lk in _CREDENTIAL_HEADERS:
                    out.append(_p(hp, f"header {k!r} carries a credential; bind a REST "
                                      f"connection with a system account instead"))
                # The CORE's header rules (``http_request.validate_params``),
                # each of which let a job save and refused it at enable
                # until 2026-09-10.
                elif not _HEADER_TOKEN_RE.fullmatch(str(k).strip()):
                    out.append(_p(hp, f"header name {k!r} is not a valid header token"))
                elif lk in _RESERVED_HEADERS:
                    out.append(_p(hp, f"header {k!r} is owned by the sender and may not be set on a job "
                                      f"(Idempotency-Key carries the fire key; Host and Content-Length "
                                      f"are computed from the request)"))
                elif lk in seen_headers:
                    out.append(_p(hp, f"header {k!r} repeats {seen_headers[lk]!r} (header names are "
                                      f"case-insensitive)"))
                seen_headers.setdefault(lk, str(k))
                if not isinstance(v, str):
                    out.append(_p(hp, "header values must be text"))
                elif _PLACEHOLDER_ANY_RE.search(v):
                    # The projection's rule: the dispatcher sends header
                    # values as typed and resolves nothing in them.
                    out.append(_p(hp, "the dispatcher sends header values as typed; a placeholder "
                                      "in a header is not resolved"))
    body = params.get("body")
    if body is not None and not isinstance(body, (Mapping, list)):
        out.append(_p(f"{path}.body", "body must be a JSON object or array"))
    elif body is not None and method not in _cat.HTTP_BODY_METHODS:
        # The core's rule (``tasks.http_request.validate_params``): a GET or
        # DELETE carries no body.  Saved here, refused at enable until 2026-09-10.
        out.append(_p(f"{path}.body", f"body is set but method {method} carries no body; only "
                                      f"{', '.join(_cat.HTTP_BODY_METHODS)} do"))
    ejp = params.get("expect_json_paths")
    if ejp is not None:
        if not isinstance(ejp, list):
            out.append(_p(f"{path}.expect_json_paths", "expect_json_paths must be a list of {name, path}"))
        else:
            seen: set = set()
            for i, e in enumerate(ejp):
                ep = f"{path}.expect_json_paths[{i}]"
                if not isinstance(e, Mapping) or not isinstance(e.get("name"), str) \
                        or not _STEP_NAME_RE.fullmatch(e.get("name") or "") or not isinstance(e.get("path"), str):
                    out.append(_p(ep, "each entry is {name: lower-case identifier, path: '$.a.b', "
                                      "type: number|text|boolean}"))
                    continue
                if e["name"] == _HTTP_STATUS_OUTPUT:
                    out.append(_p(f"{ep}.name", f"output {_HTTP_STATUS_OUTPUT!r} is built in (the HTTP "
                                                f"status); choose another name"))
                elif e["name"] in seen:
                    out.append(_p(f"{ep}.name", f"output {e['name']!r} declared twice"))
                seen.add(e["name"])
                # The CORE's rules (``http_request``): the path is dotted
                # identifiers (the projection strips ``$.``; an array index
                # is refused), and every output declares its type so a
                # later guard compares like with like.
                dotted = e["path"].strip()
                dotted = dotted[2:] if dotted.startswith("$.") else ("" if dotted == "$" else dotted)
                if not _JSON_PATH_RE.fullmatch(dotted):
                    out.append(_p(f"{ep}.path", f"path {e['path']!r} must be a dotted path of identifiers, "
                                                f"e.g. $.data.run_id (objects only, no array indexing)"))
                if e.get("type") not in _cat.OUTPUT_TYPES:
                    out.append(_p(f"{ep}.type", f"output {e['name']!r} must declare its type: one of "
                                                f"{', '.join(_cat.OUTPUT_TYPES)} (the dispatcher needs it "
                                                f"so a later guard compares like with like)"))
    cid = params.get("connection_id")
    if _is_int(cid):
        ct = _conn_type(ctx, int(cid))
        if ct is not None and ct not in ("rest", "rest_api", "http"):
            out.append(_p(f"{path}.connection_id", f"connection {cid} is {ct!r}, not a REST connection"))
    return out


def _timeout_problems(params: Mapping[str, Any], path: str) -> List[Problem]:
    """The core's ``positive_int`` on ``timeout_seconds`` (both HTTP-shaped
    pass-through types declare it, default 30)."""
    t = params.get("timeout_seconds")
    if t is not None and (not _is_int(t) or t <= 0):
        return [_p(f"{path}.timeout_seconds", "timeout_seconds must be a positive integer (seconds)")]
    return []


def _validate_airflow(params: Mapping[str, Any], path: str, ctx: ValidationContext) -> List[Problem]:
    """The core's ``airflow_trigger`` rules.  No ``connection_id``: the
    remote is a deployment property (``CLOCKWORK_REMOTE_AIRFLOW_*``); the
    built-in form asked for one until 2026-09-10 and the core refused every
    such job at enable as an unknown key."""
    out: List[Problem] = []
    dag = params.get("dag_id")
    if not isinstance(dag, str) or not re.fullmatch(_cat.AIRFLOW_DAG_ID_RE, dag or ""):
        out.append(_p(f"{path}.dag_id", "dag_id must be an Airflow DAG id (letters, digits, '_', '.', "
                                        "'-'; <= 250 characters)"))
    conf = params.get("conf")
    if conf is not None and not isinstance(conf, Mapping):
        out.append(_p(f"{path}.conf", "conf must be a JSON object"))
    out.extend(_timeout_problems(params, path))
    return out


def _validate_qs_api(params: Mapping[str, Any], path: str) -> List[Problem]:
    out: List[Problem] = []
    if params.get("action") not in _cat.QS_API_ACTIONS:
        out.append(_p(f"{path}.action", f"action must be one of {', '.join(_cat.QS_API_ACTIONS)}"))
    tid = params.get("target_id")
    # The core's ``target_validator``: the id is placed in a URL path, so
    # it is validated rather than escaped (a space saved here until
    # 2026-09-10 and was refused at enable).
    if not isinstance(tid, (str, int)) or isinstance(tid, bool) or not str(tid).strip():
        out.append(_p(f"{path}.target_id", "target_id is required"))
    elif not re.fullmatch(_cat.QS_API_TARGET_RE, str(tid)):
        out.append(_p(f"{path}.target_id", "target_id is placed in a URL path: letters, digits, '_', "
                                           "'.', '-' only (<= 200 characters)"))
    p = params.get("parameters")
    if p is not None and not isinstance(p, Mapping):
        out.append(_p(f"{path}.parameters", "parameters must be a JSON object"))
    out.extend(_timeout_problems(params, path))
    return out


# ── Environment gate ─────────────────────────────────────────────────────


def _validate_environments(conn_ids: Sequence[int], ctx: ValidationContext) -> List[Problem]:
    """Plan v2 §3.2: the account's declared environment must match the
    environment the job fires in.  ``UNSPECIFIED`` (the fail-closed
    migration default) is always a problem: it is refused at fire time."""
    out: List[Problem] = []
    want = str(ctx.fire_environment or "").strip().upper()
    for cid in conn_ids:
        conn = ctx.connection_lookup(int(cid))
        if not conn:
            continue
        cfg = conn.get("config") if isinstance(conn.get("config"), Mapping) else {}
        sa = cfg.get("system_account_id")
        if sa in (None, ""):
            continue
        try:
            acct = ctx.system_account_lookup(int(sa))
        except (TypeError, ValueError):
            acct = None
        if not acct:
            out.append(_p("connection_id", f"connection {cid} names system account {sa!r} which does not exist"))
            continue
        env = str(acct.get("environment") or "UNSPECIFIED").strip().upper()
        if env == "UNSPECIFIED":
            out.append(_p("connection_id",
                          f"system account {acct.get('name', sa)!r} (connection {cid}) has environment "
                          f"UNSPECIFIED; it would be refused at fire time.  Declare PROD or NONPROD on the account"))
        elif want and env != want:
            out.append(_p("connection_id",
                          f"system account {acct.get('name', sa)!r} (connection {cid}) is declared for "
                          f"{env}; this job would fire in {want} — refused before the claim"))
        if acct.get("is_active") is False:
            out.append(_p("connection_id", f"system account {acct.get('name', sa)!r} (connection {cid}) is inactive"))
    return out


def evaluate_guard(clauses: Sequence[Mapping[str, Any]], outputs: Mapping[str, Any]) -> bool:
    """Conjunction of comparisons over ``outputs`` (``{"step.out": value}``).
    Numeric when both sides parse as numbers, else string comparison.
    Exposed so the same rule can be pinned here and in the executor's
    parity test."""
    for c in clauses:
        left = outputs.get(c["ref"])
        right = c.get("value")
        op = c["op"]
        try:
            l, r = float(left), float(right)      # noqa: E741
        except (TypeError, ValueError):
            l, r = str(left), str(right)          # noqa: E741
        ok = {
            "==": l == r, "!=": l != r, ">": l > r, ">=": l >= r, "<": l < r, "<=": l <= r,
        }[op]
        if not ok:
            return False
    return True


__all__ = ["ValidationContext", "validate_job", "evaluate_guard", "MAX_GRACE_SECONDS",
           "DEFINITION_KEYS", "definition_of", "schedule_warnings",
           "cron_only_schedule_check"]
