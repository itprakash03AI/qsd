"""Placeholders, Oracle date masks, and the resolver — plan v2 §4.

Every placeholder is a PURE function of (the occurrence's scheduled time,
the job's timezone, a calendar).  There is no clock read in this module,
and a source guard asserts it: an identity that derives from the observing
pod's clock lets two pods either side of a boundary compute different
values and both fire.

THE MASK IS LOAD-BEARING.  Every Oracle procedure parameter is VARCHAR2
(operator decision, 2026-09-10), so a date reaches Oracle as text and the
procedure parses it with whatever mask it was written against.  A value
rendered through the wrong mask does not raise — it is silently a different
date (this repo has shipped ``2025-09-30`` as ``25-SEP-2030`` once).  So a
bind that carries a date placeholder REQUIRES a mask, with NO default, and
two-digit-year masks (``RR``, ``YY``) are refused outright: they are the
wrong-century incident waiting to recur.

Calendar arithmetic is NOT re-implemented here: ``core.feed.calendar``
already owns "previous business day" for the feed platform, and a decision
made twice is a bug.  A job with no calendar declares its weekend days
explicitly; that becomes a ``CalendarSpec`` with no holidays and no horizon.
"""
from __future__ import annotations

import calendar as _calmod
import re
from dataclasses import dataclass, field
from datetime import date as _date, datetime, timedelta, timezone
from typing import Any, Dict, Iterable, List, Mapping, Optional, Tuple
from zoneinfo import ZoneInfo

from core.feed.calendar import BusinessCalendar, CalendarHorizonError, CalendarSpec

#: ``{NAME}`` inside a bind value / predicate value / template bind.
PLACEHOLDER_RE = re.compile(r"\{([A-Z][A-Z0-9_]*)\}")

#: The vocabulary.  ``kind`` is ``date`` (needs a mask) or ``text``.
PLACEHOLDERS: Dict[str, Dict[str, str]] = {
    "SCHEDULED_DATE": {
        "kind": "date",
        "doc": "The occurrence's scheduled date in the job's timezone.",
    },
    "PREV_WORKING_DATE": {
        "kind": "date",
        "doc": "The business day before the scheduled date (walks back over "
               "weekend days and, with a calendar, holidays).",
    },
    "PREV_MONTH_LAST_WORKING_DATE": {
        "kind": "date",
        "doc": "The last business day of the month BEFORE the scheduled date's "
               "month.  Sep 1 (Mon) -> Aug 31; Jun 1 -> May 29 (May 31 is a "
               "Sunday); Mar 1 -> Feb 27 (Feb 28 is a Saturday).",
    },
    "CURRENT_MONTH_FIRST_DAY": {
        "kind": "date",
        "doc": "The first calendar day of the scheduled date's month.",
    },
    "CURRENT_MONTH_LAST_DAY": {
        "kind": "date",
        "doc": "The last calendar day of the scheduled date's month.",
    },
    "FIRE_KEY": {
        "kind": "text",
        "doc": "The occurrence's fire key — the idempotency identity a target "
               "may use to de-duplicate.",
    },
    "JOB_ID": {
        "kind": "text",
        "doc": "The job's id as the dispatcher sees it (the row id, as text).",
    },
    "SCOPE": {
        "kind": "text",
        "doc": "The occurrence's scope: '-' for a scheduled fire, "
               "'manual:<nonce>' for a manual one.",
    },
}

#: Oracle date-mask tokens -> renderer.  Longest token first when scanning.
_TOKENS: Tuple[Tuple[str, Any], ...] = (
    ("YYYY",  lambda d: f"{d.year:04d}"),
    ("MONTH", lambda d: _calmod.month_name[d.month].upper()),
    ("Month", lambda d: _calmod.month_name[d.month]),
    ("MON",   lambda d: _calmod.month_abbr[d.month].upper()),
    ("Mon",   lambda d: _calmod.month_abbr[d.month]),
    ("MM",    lambda d: f"{d.month:02d}"),
    ("DD",    lambda d: f"{d.day:02d}"),
)
_SEPARATORS = set("-/. ,")

#: Refused outright: two-digit years and anything below day grain.
_REFUSED_TOKEN_RE = re.compile(r"(?<!Y)YY(?!YY)|RR|HH|MI|SS|FF|TZ", re.I)

#: The masks the UI offers.  Any mask the tokenizer accepts is valid; these
#: are the documented set with examples rendered from a FIXED date, so the
#: endpoint that lists them reads no clock either.
DOCUMENTED_MASKS: Tuple[Tuple[str, str], ...] = (
    ("YYYY-MM-DD", "ISO — what TO_DATE(:x, 'YYYY-MM-DD') expects"),
    ("DD-MON-YYYY", "Oracle's classic 4-digit-year form, e.g. 01-SEP-2026"),
    ("YYYYMMDD", "compact ISO"),
    ("DD/MM/YYYY", "day-first with slashes"),
    ("MM/DD/YYYY", "month-first with slashes"),
    ("DD-MM-YYYY", "day-first with dashes"),
    ("YYYY/MM/DD", "ISO with slashes"),
    ("DD-Mon-YYYY", "mixed-case month abbreviation"),
)
_EXAMPLE_DATE = _date(2026, 8, 31)


class MaskError(ValueError):
    """A format mask this resolver refuses to render through."""


def parse_mask(mask: str) -> List[Any]:
    """Tokenize an Oracle date mask into renderers and literal separators.

    Raises :class:`MaskError` for an empty mask, a two-digit-year token, a
    time token, or any character that is neither a known token nor a
    separator.  A mask that parses renders EXACTLY what it says.
    """
    m = str(mask or "")
    if not m.strip():
        raise MaskError("format mask is required for a date placeholder and has no default")
    if _REFUSED_TOKEN_RE.search(m):
        raise MaskError(
            f"format mask {m!r} is refused: two-digit years (RR/YY) and time "
            f"tokens are not accepted — a two-digit year is the wrong-century "
            f"incident, use YYYY"
        )
    out: List[Any] = []
    i = 0
    has_year = has_month = has_day = False
    while i < len(m):
        matched = False
        for tok, fn in _TOKENS:
            if m.startswith(tok, i):
                out.append(fn)
                i += len(tok)
                matched = True
                has_year = has_year or tok == "YYYY"
                has_month = has_month or tok in ("MONTH", "Month", "MON", "Mon", "MM")
                has_day = has_day or tok == "DD"
                break
        if matched:
            continue
        ch = m[i]
        if ch in _SEPARATORS:
            out.append(ch)
            i += 1
            continue
        raise MaskError(f"format mask {m!r}: unrecognised token at position {i} ({ch!r})")
    if not (has_year and has_month and has_day):
        raise MaskError(f"format mask {m!r} must carry a year (YYYY), a month and a day")
    if m not in {mask for mask, _doc in DOCUMENTED_MASKS}:
        # The dispatcher renders through a CLOSED set (it will not send a
        # mask it cannot prove renders the day it names), and that set is
        # pinned equal to DOCUMENTED_MASKS by test.  Accepting more here
        # would let a job save and then be refused at enable in the core's
        # words -- the seam defect this closes.
        raise MaskError(
            f"format mask {m!r} is not one of the documented masks "
            f"{[mask for mask, _doc in DOCUMENTED_MASKS]}; the dispatcher renders "
            f"through that closed set only")
    return out


def render_date(d: _date, mask: str) -> str:
    parts = parse_mask(mask)
    return "".join(p if isinstance(p, str) else p(d) for p in parts)


def mask_is_valid(mask: str) -> Tuple[bool, str]:
    try:
        parse_mask(mask)
        return True, ""
    except MaskError as exc:
        return False, str(exc)


def documented_masks() -> List[Dict[str, Any]]:
    return [{"mask": m, "example": render_date(_EXAMPLE_DATE, m), "doc": doc}
            for m, doc in DOCUMENTED_MASKS]


def vocabulary() -> List[Dict[str, Any]]:
    return [{"name": n, "kind": v["kind"], "doc": v["doc"]} for n, v in PLACEHOLDERS.items()]


def placeholders_in(value: Any) -> List[str]:
    """Placeholder names referenced by a scalar value (``str`` only)."""
    if not isinstance(value, str):
        return []
    return PLACEHOLDER_RE.findall(value)


def unknown_placeholders(value: Any) -> List[str]:
    return [n for n in placeholders_in(value) if n not in PLACEHOLDERS]


def date_placeholders_in(value: Any) -> List[str]:
    return [n for n in placeholders_in(value) if PLACEHOLDERS.get(n, {}).get("kind") == "date"]


# ── Calendars ────────────────────────────────────────────────────────────


def weekend_only_spec(weekend_days: Iterable[int]) -> CalendarSpec:
    """A calendar for a job that declared its weekend explicitly and binds
    no holiday calendar.  No holidays, no horizon (nothing to expire)."""
    days = sorted({int(d) for d in weekend_days})
    return CalendarSpec(
        id=0, name="(explicit weekend days)", weekend_days=days,
        holidays_explicit=set(), holidays_recurring_md=set(),
        horizon_end=None, owner="", version=0,
    )


def spec_of(cal: BusinessCalendar) -> Optional[CalendarSpec]:
    """The CalendarSpec behind a BusinessCalendar (``spec`` is a property
    on the feed platform's class; tolerate a method-shaped double)."""
    s = getattr(cal, "spec", None)
    return s() if callable(s) else s


# ── The resolver ─────────────────────────────────────────────────────────


@dataclass(frozen=True)
class ResolvedPlaceholders:
    """Every placeholder's resolved value for ONE occurrence, plus what the
    fire row should record (calendar version)."""
    scheduled_fire_utc: datetime
    scheduled_local: datetime
    values: Dict[str, Any] = field(default_factory=dict)       # name -> date | str
    calendar_version: Optional[int] = None
    calendar_name: Optional[str] = None


def resolve_all(scheduled_fire_utc: datetime, tz_name: str,
                cal: BusinessCalendar, fire_key: str = "", job_id: Any = "",
                scope: str = "-") -> ResolvedPlaceholders:
    """Resolve the whole vocabulary for one occurrence.

    ``scheduled_fire_utc`` must be timezone-aware.  A calendar horizon
    refusal propagates as :class:`CalendarHorizonError` — the caller
    records it per occurrence; it is never swallowed into a guessed date.
    """
    if scheduled_fire_utc.tzinfo is None:
        raise ValueError("scheduled_fire_utc must be timezone-aware")
    local = scheduled_fire_utc.astimezone(ZoneInfo(tz_name))
    d = local.date()
    first = d.replace(day=1)
    last = d.replace(day=_calmod.monthrange(d.year, d.month)[1])
    prev_month_end = first - timedelta(days=1)
    values: Dict[str, Any] = {
        "SCHEDULED_DATE": d,
        "CURRENT_MONTH_FIRST_DAY": first,
        "CURRENT_MONTH_LAST_DAY": last,
        "PREV_WORKING_DATE": cal.previous_business_day(d),
        "PREV_MONTH_LAST_WORKING_DATE": cal.previous_business_day_or_today(prev_month_end),
        "FIRE_KEY": fire_key,
        "JOB_ID": str(job_id if job_id is not None else ""),
        "SCOPE": scope,
    }
    spec = spec_of(cal)
    return ResolvedPlaceholders(
        scheduled_fire_utc=scheduled_fire_utc.astimezone(timezone.utc),
        scheduled_local=local,
        values=values,
        calendar_version=getattr(spec, "version", None) if spec else None,
        calendar_name=getattr(spec, "name", None) if spec else None,
    )


def render_value(value: Any, resolved: ResolvedPlaceholders, mask: Optional[str]) -> Any:
    """Substitute every placeholder in ``value``.

    A date placeholder renders through ``mask`` — required, refused if
    absent.  A text placeholder substitutes as-is.  Non-string values are
    returned unchanged.
    """
    if not isinstance(value, str):
        return value

    def _sub(m: re.Match) -> str:
        name = m.group(1)
        decl = PLACEHOLDERS.get(name)
        if decl is None:
            raise MaskError(f"unknown placeholder {{{name}}}; valid: {', '.join(PLACEHOLDERS)}")
        v = resolved.values.get(name)
        if decl["kind"] == "date":
            return render_date(v, mask or "")
        return str(v if v is not None else "")

    return PLACEHOLDER_RE.sub(_sub, value)


def next_occurrences(cron_expr: str, tz_name: str, start_utc: datetime,
                     count: int) -> List[datetime]:
    """The next ``count`` scheduled fires strictly after ``start_utc``, as
    aware UTC datetimes.  ``start_utc`` is supplied by the caller — the
    route is the only place a clock is read."""
    from croniter import croniter
    if start_utc.tzinfo is None:
        raise ValueError("start_utc must be timezone-aware")
    tz = ZoneInfo(tz_name)
    it = croniter(cron_expr, start_utc.astimezone(tz))
    out: List[datetime] = []
    for _ in range(max(0, int(count))):
        nxt = it.get_next(datetime)
        if nxt.tzinfo is None:
            nxt = nxt.replace(tzinfo=tz)
        out.append(nxt.astimezone(timezone.utc).replace(microsecond=0))
    return out


def most_recent_occurrence(cron_expr: str, tz_name: str, at_utc: datetime) -> datetime:
    """The latest scheduled fire at or before ``at_utc`` (UTC, aware).
    Mirrors Clockwork's own rule: an exact boundary counts as due."""
    from croniter import croniter
    tz = ZoneInfo(tz_name)
    it = croniter(cron_expr, at_utc.astimezone(tz) + timedelta(microseconds=1))
    prev = it.get_prev(datetime)
    if prev.tzinfo is None:
        prev = prev.replace(tzinfo=tz)
    return prev.astimezone(timezone.utc).replace(microsecond=0)


def fire_key_for(tenant: str, job_id: Any, scope: str, scheduled_fire_utc: datetime) -> str:
    """``tenant|job_id|scope|YYYY-MM-DDTHH:MM:SSZ`` — plan v1 §4: the tenant
    is IN the key, not beside it."""
    stamp = scheduled_fire_utc.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return f"{tenant}|{job_id}|{scope}|{stamp}"


__all__ = [
    "PLACEHOLDERS", "MaskError", "CalendarHorizonError", "ResolvedPlaceholders",
    "parse_mask", "render_date", "mask_is_valid", "documented_masks", "vocabulary",
    "placeholders_in", "unknown_placeholders", "date_placeholders_in",
    "weekend_only_spec", "resolve_all", "render_value", "next_occurrences",
    "most_recent_occurrence", "fire_key_for",
]
