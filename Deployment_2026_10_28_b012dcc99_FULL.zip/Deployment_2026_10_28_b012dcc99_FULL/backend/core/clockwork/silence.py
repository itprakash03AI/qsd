"""The DEAD-POD half of the deployment watchdog.

WHY THIS EXISTS, AND WHY IT CANNOT LIVE IN CLOCKWORK
----------------------------------------------------
``clockwork/clockwork/watchdog.py`` alarms when a pod's own tick loop stalls:
a second thread notices that no tick completed within N intervals and raises
``clockwork_deployment_stalled``.  That is real coverage and it is not
enough, because **a pod that died, or that never started, raises nothing at
all**.  A dead process cannot alarm about itself.

The only witness to that is an OUTSIDE reader of
``clockwork_deployments.last_tick_at``, and QueryStudio is the only thing
positioned to be one.  ``core/clockwork/explain.py`` already reads that
column — but only when a human opens the "why did this not run" screen, and
nobody opens it at 02:00.  So the fact has to be raised whether or not
anyone is looking.

WHAT IT WRITES, AND WHY IT WRITES A FACT RATHER THAN A MESSAGE
--------------------------------------------------------------
An alert is a FACT; a notification is a DELIVERY.  This module raises a
``clockwork_deployment_silent`` row through the same
``raise_clockwork_alert`` the rest of the platform uses, and
``core/clockwork/notifier.py`` delivers it through the path it already owns
— severity, recipients, the once-per-identity rule and the delivery ledger.
Nothing here sends anything, and nothing here writes a notification.

THE REPEAT TRAP, WHICH IS THE WHOLE DIFFICULTY
-----------------------------------------------
``raise_clockwork_alert`` bumps ``count`` on a repeat AND CLEARS THE
ACKNOWLEDGEMENT (``mixin_clockwork.raise_clockwork_alert``).  The notifier's
once-per-identity rule re-pages precisely when an alert was acknowledged and
then re-raised.  So calling this every pass for a deployment that is STILL
silent would clear the ack every pass and page somebody every minute —
which is how alerting gets muted, and then ignored.

The transition is therefore derived from the alert row itself, not from
memory that a restart would lose:

  * no row for (kind, deployment)            -> raise.  This is the entry
                                                into silence.
  * a row that a human ACKNOWLEDGED          -> raise.  They looked, it is
                                                still silent, tell them again.
  * a row that is still unacknowledged       -> do NOTHING.  It is already
                                                pending in front of someone.
  * the deployment ticks again               -> acknowledge it as recovered,
                                                so the NEXT silence re-pages.

WHAT IS DELIBERATELY NOT ALARMED
--------------------------------
A deployment with no enabled job assigned to its authority.  A retired pod
whose row lingers is not an incident, and alarming on it forever is how a
real alarm gets lost among false ones.  ``silent_deployments`` states that
by returning only deployments that something actually depends on.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Mapping, Optional

logger = logging.getLogger(__name__)

LOG_PREFIX = "[clockwork.silence]"

#: The kind this module raises.  ``notifier.KIND_SEVERITY`` classifies it
#: CRITICAL: a scheduler nobody is driving is not a warning.
KIND_DEPLOYMENT_SILENT = "clockwork_deployment_silent"

#: Who the acknowledgement is attributed to on recovery, so the audit does
#: not imply a person looked.
RECOVERED_BY = "system: deployment resumed ticking"


def _aware(value: Any) -> Optional[datetime]:
    """Naive timestamps are stored UTC by this platform; make that explicit.

    ACCEPTS A STRING, and that is the whole point of this function existing
    rather than an ``isinstance`` at the call site.  2026-09-11: it did not,
    and the module's ONLY input --
    ``ClockworkDeployment.to_dict()`` (``core/db/models.py``) -- renders
    ``last_tick_at`` and ``started_at`` as ISO **strings**.  So a deployment
    that had ticked one second ago was read as ``None`` and reported as
    "has NEVER completed a tick": a false CRITICAL for every healthy
    deployment on the first notifier pass, and -- because it then stayed in
    ``still_silent`` for ever -- the recovery branch never ran and a REAL
    silence could never be distinguished from the false one.  The feature
    was worse than absent.

    It survived its own tests because the fixture built deployment rows from
    ``datetime`` objects while the product builds them from ``to_dict()``: a
    fixture kinder than reality, which is the trap this platform's skill
    already names.  The tests now go through ``to_dict()``.

    Returns None only for a value that carries NO instant at all (None, or
    text that is not a timestamp), so "never ticked" stays a caller's
    decision rather than a coercion that silently succeeds.
    """
    if isinstance(value, datetime):
        parsed: Optional[datetime] = value
    elif isinstance(value, str) and value.strip():
        raw = value.strip()
        # `to_dict()` uses isoformat(); tolerate a trailing Z, which is what
        # every other reader of these columns already accepts.
        if raw.endswith("Z"):
            raw = raw[:-1] + "+00:00"
        try:
            parsed = datetime.fromisoformat(raw)
        except ValueError:
            return None
    else:
        return None
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def authorities_with_enabled_jobs(jobs: List[Mapping[str, Any]]) -> Dict[str, int]:
    """``{authority: how many enabled jobs depend on it}``.

    A job with no authority is counted against no deployment: nothing can be
    said about which pod was supposed to run it, and inventing one would be
    a guess in an alarm.
    """
    out: Dict[str, int] = {}
    for job in jobs:
        if not job.get("enabled"):
            continue
        authority = job.get("authority")
        if not authority:
            continue
        out[str(authority)] = out.get(str(authority), 0) + 1
    return out


def silent_deployments(deployments: List[Mapping[str, Any]],
                       depended_on: Mapping[str, int],
                       now: datetime,
                       silent_seconds: int) -> List[Dict[str, Any]]:
    """Deployments that something depends on and that have gone quiet.

    A deployment that has NEVER ticked is silent from ``started_at`` — it is
    the "never started properly" case, and reporting it as "no data" would
    be the empty-versus-unknown confusion this codebase keeps paying for.
    """
    cutoff = now - timedelta(seconds=int(silent_seconds))
    out: List[Dict[str, Any]] = []

    # A deployment row is written BY THE POD AT BOOT.  So an authority that
    # enabled jobs name and that has NO row at all is a pod that never
    # started, or a typo in the authority -- and iterating only the rows
    # could never see it.  2026-09-11: this module's own docstring claimed
    # "died OR NEVER STARTED" while covering only the first half.  Nothing
    # else raises it either: explain.py answers NOT_OBSERVED, but only when
    # a person opens the screen.
    known = {str(d.get("deployment_id") or "") for d in deployments}
    for authority, waiting in sorted(depended_on.items()):
        if authority in known or int(waiting) <= 0:
            continue
        out.append({"deployment_id": authority, "jobs_waiting": int(waiting),
                    "last_tick_at": None, "silent_for_seconds": None,
                    "never_ticked": True, "never_registered": True})

    for dep in deployments:
        deployment_id = str(dep.get("deployment_id") or "")
        if not deployment_id:
            continue
        jobs_waiting = int(depended_on.get(deployment_id, 0))
        if jobs_waiting <= 0:
            continue
        last_tick = _aware(dep.get("last_tick_at"))
        since = last_tick or _aware(dep.get("started_at"))
        if since is None:
            # No tick AND no start instant: the row says nothing about when
            # it was last alive.  Unknown is not "fine" — report it, and say
            # that the row itself is the reason.
            out.append({"deployment_id": deployment_id, "jobs_waiting": jobs_waiting,
                        "last_tick_at": None, "silent_for_seconds": None,
                        "never_ticked": True})
            continue
        if since > cutoff:
            continue
        out.append({
            "deployment_id": deployment_id,
            "jobs_waiting": jobs_waiting,
            "last_tick_at": last_tick,
            "silent_for_seconds": int((now - since).total_seconds()),
            "never_ticked": last_tick is None,
        })
    return out


def describe(entry: Mapping[str, Any], silent_seconds: int) -> str:
    """The alert's message.  It has to be readable by somebody woken up."""
    deployment_id = entry.get("deployment_id")
    waiting = entry.get("jobs_waiting")
    if entry.get("never_registered"):
        return (f"No Clockwork deployment has ever registered as {deployment_id!r}, "
                f"and {waiting} enabled job(s) name it as their authority. Nothing "
                f"is dispatching them and nothing ever has. Either no pod is running "
                f"with CLOCKWORK_DEPLOYMENT_ID={deployment_id!r}, or the jobs name an "
                f"authority that does not exist -- check the spelling against the "
                f"deployments the scheduler page lists.")
    if entry.get("never_ticked"):
        seen = entry.get("silent_for_seconds")
        when = (f"has NEVER completed a tick (known for {seen}s)" if seen is not None
                else "has NEVER completed a tick, and its row carries no start time either")
        return (f"Clockwork deployment {deployment_id!r} {when}, and {waiting} enabled "
                f"job(s) name it as their authority. Nothing is dispatching them. "
                f"Check the pod is running and that it can reach this database; "
                f"`python -m clockwork --check` reports per job why it cannot fire.")
    return (f"Clockwork deployment {deployment_id!r} has not completed a tick for "
            f"{entry.get('silent_for_seconds')}s (threshold {silent_seconds}s), and "
            f"{waiting} enabled job(s) name it as their authority. Their occurrences "
            f"are NOT being claimed. A pod that died cannot alarm about itself, which "
            f"is why this is raised from QueryStudio rather than by the deployment.")


class SilenceWatch:
    """Raises the fact.  Delivery is the notifier's; this never sends."""

    def __init__(self, db: Any, *, silent_seconds: int = 600,
                 clock: Any = None) -> None:
        self.db = db
        self.silent_seconds = int(silent_seconds)
        self._clock = clock or (lambda: datetime.now(timezone.utc))

    def run_once(self) -> Dict[str, int]:
        """One pass.  NEVER raises — a watcher that breaks a caller is worse
        than one that is quiet, but it must say so rather than pass silently.

        Counters: ``silent`` seen, ``raised`` (a transition), ``pending``
        (already in front of someone), ``recovered`` (acknowledged), and
        ``errors`` (this module's own).
        """
        counters = {k: 0 for k in ("silent", "raised", "pending", "recovered", "errors")}
        if self.silent_seconds <= 0:
            return counters
        try:
            deployments = self.db.list_clockwork_deployments()
            jobs = self.db.list_clockwork_jobs()
            alerts = [a for a in self.db.list_clockwork_alerts()
                      if a.get("kind") == KIND_DEPLOYMENT_SILENT]
        except Exception as exc:  # noqa: BLE001 - fail open, but never silently
            logger.error("%s could not read the deployment rows: %s: %s -- no silence "
                         "checked this pass", LOG_PREFIX, type(exc).__name__, exc)
            counters["errors"] += 1
            return counters

        by_deployment = {str(a.get("deployment_id") or ""): a for a in alerts}
        now = self._clock()
        entries = silent_deployments(
            deployments, authorities_with_enabled_jobs(jobs), now, self.silent_seconds)
        still_silent = {e["deployment_id"] for e in entries}

        for entry in entries:
            counters["silent"] += 1
            deployment_id = entry["deployment_id"]
            existing = by_deployment.get(deployment_id)
            # The repeat trap: raising again clears the acknowledgement, and
            # the notifier re-pages on ack-then-raise.  So raise ONLY on a
            # transition -- first sighting, or a human acked and it is STILL
            # silent.  An unacknowledged row is already in front of someone.
            if existing is not None and not existing.get("acknowledged_at"):
                counters["pending"] += 1
                continue
            try:
                self.db.raise_clockwork_alert(
                    kind=KIND_DEPLOYMENT_SILENT,
                    message=describe(entry, self.silent_seconds),
                    job_id=None, deployment_id=deployment_id)
                counters["raised"] += 1
                logger.error("%s deployment %s is silent: %s", LOG_PREFIX,
                             deployment_id, describe(entry, self.silent_seconds))
            except Exception as exc:  # noqa: BLE001
                counters["errors"] += 1
                logger.error("%s could not raise the silence alert for %s: %s: %s",
                             LOG_PREFIX, deployment_id, type(exc).__name__, exc)

        # Recovery: acknowledge, so the NEXT silence is a transition again.
        # Without this a pod that died, was fixed, and died again would be an
        # unacknowledged row throughout and would never page a second time.
        for deployment_id, alert in by_deployment.items():
            if deployment_id in still_silent or alert.get("acknowledged_at"):
                continue
            try:
                self.db.acknowledge_clockwork_alert(int(alert["id"]), by=RECOVERED_BY)
                counters["recovered"] += 1
                logger.info("%s deployment %s is ticking again; its silence alert is "
                            "acknowledged so a future silence pages again",
                            LOG_PREFIX, deployment_id)
            except Exception as exc:  # noqa: BLE001
                counters["errors"] += 1
                logger.error("%s could not acknowledge the recovery for %s: %s: %s",
                             LOG_PREFIX, deployment_id, type(exc).__name__, exc)
        return counters
