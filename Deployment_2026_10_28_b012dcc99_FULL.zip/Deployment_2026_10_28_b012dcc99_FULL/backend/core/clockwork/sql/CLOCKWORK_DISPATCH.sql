-- The DISPATCH PROJECTION -- QueryStudio's implementation of the contract
-- in clockwork/clockwork/sql/postgres/DISPATCH_CONTRACT.md.  ONE DDL, run at API
-- startup by core/clockwork/dispatch_views.py on every dialect the API
-- runs on (PostgreSQL in production; SQLite in tests, where the suite
-- reads the same views the dispatcher would).
--
-- WHY VIEWS.  The authoring tables are the ONE source of truth.  A view
-- has no second copy of `enabled`, `authority` or `cron` to drift from the
-- row a person edits, so "anything that should stop a fire changes the
-- projection's OUTPUT" holds by construction: disable the job and the row
-- leaves the view; delete it and the row is gone; a job whose definition
-- never passed the dispatcher's own validator (dispatch_definition NULL)
-- is never projected at all.
--
-- WHY ONLY PORTABLE SQL.  No `::` casts, no jsonb functions, no
-- CREATE OR REPLACE: the same text must run on SQLite so the backend
-- suite proves the projection's rows, not a re-spelling of them.  The
-- definition is assembled in Python (core/clockwork/projection.py) and
-- stored on the row, because the translation from the authoring grammar
-- to the core's is not expressible portably in SQL.
--
-- Every statement is idempotent: DROP VIEW IF EXISTS, then CREATE.

DROP VIEW IF EXISTS clockwork_dispatch_jobs;

CREATE VIEW clockwork_dispatch_jobs AS
SELECT j.tenant                     AS tenant,
       CAST(j.id AS VARCHAR(100))   AS job_id,
       j.cron                       AS cron_expression,
       NULL                         AS scope,
       j.dispatch_definition        AS definition,
       j.authority                  AS authority,
       j.enabled                    AS enabled
  FROM clockwork_jobs j
 WHERE j.enabled
   AND j.dispatch_definition IS NOT NULL;

DROP VIEW IF EXISTS clockwork_dispatch_manual;

-- A manual request carries its OWN identity (fire_key, scope, tenant) and
-- a SNAPSHOT of the projection taken when the person pressed the button;
-- the job's cron and authority are read LIVE so a hand-off of authority
-- moves the request with the job.  Only PENDING rows are exposed, and ONLY
-- for a job that exists and is ENABLED (2026-09-10 audit: this was a LEFT
-- JOIN filtered on status alone, so disabling a job did not remove its
-- pending request from the dispatcher's read -- the one rule of this file
-- broken by its second view).  The request row of a disabled or deleted
-- job is retired by the job's writer in the same transaction
-- (mixin_clockwork), so nothing spins PENDING; and even if that write were
-- missed, this WHERE is what decides, not a flag the dispatcher never reads.

CREATE VIEW clockwork_dispatch_manual AS
SELECT r.id                          AS request_id,
       r.tenant                      AS tenant,
       CAST(r.job_id AS VARCHAR(100)) AS job_id,
       j.cron                        AS cron_expression,
       r.scope                       AS scope,
       r.fire_key                    AS fire_key,
       r.definition                  AS definition,
       j.authority                   AS authority,
       r.kind                        AS kind,
       r.from_step                   AS from_step,
       r.parent_fire_key             AS parent_fire_key,
       r.status                      AS status
  FROM clockwork_manual_requests r
  JOIN clockwork_jobs j ON j.id = r.job_id
 WHERE r.status = 'PENDING'
   AND j.enabled;
