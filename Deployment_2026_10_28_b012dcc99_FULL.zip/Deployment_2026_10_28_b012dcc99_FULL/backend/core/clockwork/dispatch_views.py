"""The dispatch projection's SQL half: create the views, and say whether
they exist.

``sql/CLOCKWORK_DISPATCH.sql`` is the ONE DDL for ``clockwork_dispatch_jobs``
and ``clockwork_dispatch_manual`` -- the relations the Clockwork postgres
backend reads (its ``jobs_table`` / ``manual_view`` parameters; contract in
``clockwork/clockwork/sql/postgres/DISPATCH_CONTRACT.md``).  ``create_all`` never
creates a view, and alembic is never invoked at runtime, so the views are
made HERE, at every API start, after the tables and the column migrations:
DROP VIEW IF EXISTS + CREATE VIEW, idempotent, on every dialect.

Never fatal -- a view that failed to create must not take the API down --
but never silent either: the failure is logged at ERROR and
:func:`availability` reports it, so ``/api/clockwork/health`` says
"nothing can dispatch, because ...", which is the honest state.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, Dict, List

from core.db import models as _models

logger = logging.getLogger(__name__)

DDL_PATH = Path(__file__).resolve().parent / "sql" / "CLOCKWORK_DISPATCH.sql"

#: The two relations the DDL creates -- what the dispatcher reads.
DISPATCH_JOBS_VIEW = "clockwork_dispatch_jobs"
DISPATCH_MANUAL_VIEW = "clockwork_dispatch_manual"
DISPATCH_CREDENTIALS_VIEW = "clockwork_dispatch_credentials"
#: The views the portable DDL file creates.
PORTABLE_VIEWS = (DISPATCH_JOBS_VIEW, DISPATCH_MANUAL_VIEW)
#: Every view the projection consists of.
VIEWS = PORTABLE_VIEWS + (DISPATCH_CREDENTIALS_VIEW,)

#: THE CREDENTIALS VIEW (contract section 5) -- the ONE view that cannot be
#: portable SQL, because a connection's ``system_account_id`` and its target
#: live INSIDE the ``connections.config`` JSON column and every dialect
#: spells a JSON path differently.  It is rendered per dialect from this one
#: template: ``{T:key}`` is the config's ``key`` as text, ``{I:key}`` as an
#: integer.  Neither dialect's rendering carries a secret: the password key
#: is never extracted, and the whole config is never exposed.
#:
#: An account may be named by id (``system_account_id``) or by name
#: (``system_account_name``); both are honoured and a connection matching
#: two accounts projects two rows, which the dispatcher refuses as
#: ambiguous rather than picking one.
CREDENTIALS_TEMPLATE = """
DROP VIEW IF EXISTS clockwork_dispatch_credentials;
CREATE VIEW clockwork_dispatch_credentials AS
SELECT c.id                          AS connection_id,
       c.name                        AS connection_name,
       c.connection_type             AS connection_type,
       c.is_active                   AS connection_active,
       {T:dsn}                       AS target_dsn,
       {T:host}                      AS target_host,
       {T:port}                      AS target_port,
       {T:service_name}              AS target_service_name,
       {T:sid}                       AS target_sid,
       s.id                          AS account_id,
       s.name                        AS account_name,
       s.is_active                   AS account_active,
       s.environment                 AS account_environment,
       s.use_vault                   AS account_use_vault,
       s.secret_ref                  AS secret_ref,
       s.secret_type                 AS secret_type,
       s.vault_auth_url              AS vault_auth_url,
       s.vault_role_name             AS vault_role_name,
       s.vault_role_type             AS vault_role_type,
       s.vault_secret_url            AS vault_secret_url,
       s.vault_rotate_url            AS vault_rotate_url,
       s.vault_step_up_name          AS vault_step_up_name,
       s.vault_step_up_auth_url      AS vault_step_up_auth_url,
       s.vault_approle_secret_id_url AS vault_approle_secret_id_url,
       s.vault_approle_auth_url      AS vault_approle_auth_url,
       s.vault_role_id               AS vault_role_id
  FROM connections c
  LEFT JOIN system_accounts s
    ON s.id = {I:system_account_id}
    OR s.name = {T:system_account_name};
"""

_JSON_SPELLINGS: Dict[str, Dict[str, str]] = {
    "postgresql": {"T": "(c.config->>'{key}')",
                   "I": "CAST(NULLIF(c.config->>'{key}', '') AS INTEGER)"},
    "sqlite": {"T": "json_extract(c.config, '$.{key}')",
               "I": "CAST(json_extract(c.config, '$.{key}') AS INTEGER)"},
}


def credentials_ddl(dialect: str) -> str:
    """The credentials view for ``dialect``, or ``ValueError`` naming the
    dialect -- a dialect this file cannot spell must not silently get no
    credentials view, because then every Oracle step is refused with a
    reason that points at the wrong place."""
    spelling = _JSON_SPELLINGS.get(dialect)
    if spelling is None:
        raise ValueError(
            f"the credentials view has no JSON spelling for dialect {dialect!r} "
            f"(known: {sorted(_JSON_SPELLINGS)}); without it no Oracle step can "
            f"resolve its connection")
    import re

    def render(m: "re.Match[str]") -> str:
        return spelling[m.group(1)].format(key=m.group(2))
    return re.sub(r"\{([TI]):(\w+)\}", render, CREDENTIALS_TEMPLATE)


def statements(text: str) -> List[str]:
    """The DDL's statements: comment lines dropped, split on ``;``."""
    code = "\n".join(line for line in text.splitlines()
                     if not line.strip().startswith("--"))
    return [s.strip() for s in code.split(";") if s.strip()]


def ddl_text() -> str:
    return DDL_PATH.read_text(encoding="utf-8")


#: THE MANUAL-REQUEST ARBITER (2026-09-11), for a database whose
#: ``clockwork_manual_requests`` table predates it.  ``create_all`` skips an
#: existing table, so an index declared on the model reaches a deployed
#: database only through a statement run at startup -- the same reason the
#: views are made here.  One spelling for both dialects: PostgreSQL and
#: SQLite both accept ``CREATE UNIQUE INDEX IF NOT EXISTS ... WHERE``.  The
#: name, column and predicate are the MODEL's (``core/db/models.py``), so a
#: fresh database and a migrated one carry the same index.
MANUAL_ARBITER_DDL = (
    f"CREATE UNIQUE INDEX IF NOT EXISTS {_models.MANUAL_ARBITER_INDEX} "
    f"ON {_models.ClockworkManualRequest.__tablename__} (job_id) "
    f"WHERE {_models.MANUAL_ARBITER_PREDICATE}"
)


def manual_arbiter(engine) -> Dict[str, Any]:
    """``{"present": bool, "reason": str}`` -- whether the partial unique
    index that makes "one outstanding request per job" a constraint exists,
    READ FROM THE CATALOGUE.  The fire routes ask before writing a request:
    a request nothing arbitrates must not be written as if it were
    arbitrated (fail closed, 424 with this reason)."""
    import sqlalchemy as sa
    table = _models.ClockworkManualRequest.__tablename__
    try:
        names = {ix.get("name") for ix in sa.inspect(engine).get_indexes(table)}
    except Exception as exc:                            # noqa: BLE001
        return {"present": False,
                "reason": f"the indexes of {table} could not be read: {type(exc).__name__}: {exc}"}
    if _models.MANUAL_ARBITER_INDEX not in names:
        return {"present": False,
                "reason": (f"index {_models.MANUAL_ARBITER_INDEX} is not on {table}; the API "
                           f"creates it at startup (dispatch_views.ensure_views) -- without it two "
                           f"'run now' requests for one job would both be claimed and both run")}
    return {"present": True, "reason": ""}


def ensure_views(engine) -> Dict[str, Any]:
    """Run the portable DDL, then the credentials view rendered for the
    engine's dialect, then the manual-request arbiter index.  Returns
    ``{"ok": bool, "error": str, "statements": n}`` and never raises."""
    import sqlalchemy as sa
    ran = 0
    try:
        with engine.begin() as conn:
            for stmt in statements(ddl_text()):
                conn.execute(sa.text(stmt))
                ran += 1
            for stmt in statements(credentials_ddl(engine.dialect.name)):
                conn.execute(sa.text(stmt))
                ran += 1
            conn.execute(sa.text(MANUAL_ARBITER_DDL))
            ran += 1
    except Exception as exc:                            # noqa: BLE001 - reported, never fatal
        logger.error("[clockwork] the dispatch projection could NOT be created after %d "
                     "statement(s): %s -- NOTHING will dispatch until it exists "
                     "(DDL: %s)", ran, exc, DDL_PATH, exc_info=True)
        return {"ok": False, "error": f"{type(exc).__name__}: {exc}", "statements": ran}
    logger.info("[clockwork] dispatch projection ready: %s (%d statements from %s)",
                ", ".join(VIEWS), ran, DDL_PATH.name)
    return {"ok": True, "error": "", "statements": ran}


def availability(engine) -> Dict[str, Any]:
    """``{"available": bool, "reason": str, "views": [...]}`` -- read from the
    database, not from the last ``ensure_views`` result."""
    import sqlalchemy as sa
    try:
        insp = sa.inspect(engine)
        present = set(insp.get_view_names())
    except Exception as exc:                            # noqa: BLE001
        return {"available": False, "reason": f"could not read the catalogue: {exc}",
                "views": []}
    missing = [v for v in VIEWS if v not in present]
    if missing:
        # 2026-09-15 -- this message is RIGHT and stays as it is.  A first
        # attempt made it dialect-aware ("Clockwork ships no SQLite DDL"),
        # which was wrong twice over: these views are PORTABLE SQL and are
        # created on every dialect, so their absence really can mean a failed
        # startup step -- and on SQLite that branch swallowed a genuinely
        # broken DDL, which test_clockwork_integration_2026_09_10 caught.
        # The dialect fact belongs to the Clockwork-OWNED DDL (the fire log),
        # which is where schema_admin reports it.  One reason per cause.
        return {"available": False,
                "reason": (f"dispatch view(s) {', '.join(missing)} are not present; the API "
                           f"creates them at startup from {DDL_PATH.name} -- check the "
                           f"startup log for the failure.  Nothing dispatches without them"),
                "views": sorted(present & set(VIEWS))}
    return {"available": True, "reason": "", "views": list(VIEWS)}


__all__ = ["DDL_PATH", "DISPATCH_JOBS_VIEW", "DISPATCH_MANUAL_VIEW",
           "DISPATCH_CREDENTIALS_VIEW", "PORTABLE_VIEWS", "CREDENTIALS_TEMPLATE",
           "credentials_ddl", "VIEWS", "MANUAL_ARBITER_DDL", "manual_arbiter",
           "statements", "ddl_text", "ensure_views", "availability"]
