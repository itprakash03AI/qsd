"""The PROJECTION: an authored job -> the definition the dispatcher runs.

═══════════════════════════════════════════════════════════════════════════
WHY THIS MODULE EXISTS (2026-09-10)
═══════════════════════════════════════════════════════════════════════════

Two trees built two ends of one relation under one name.  The authoring
plane's ``clockwork_jobs`` is an integer-keyed row with the UI's grammar in
its ``steps`` JSON; the dispatcher's ``clockwork_jobs`` was a
``(tenant, job_id)`` row with a jsonb ``definition`` in the CORE's grammar.
``create_all`` made the first, the dispatcher SELECTed the second's columns,
and nothing would ever have dispatched.

Plan v1 §4 draws two relations: the authoring tables PROJECT INTO a generic
dispatch contract.  This module is the projection's Python half — the
translation from the authoring grammar (what the editor sends and
``validation.validate_job`` checks) into the core grammar (what
``clockwork.job_definition.validate_job`` accepts) — and the SQL half is the
view in ``sql/CLOCKWORK_DISPATCH.sql``, which exposes the translated
definition beside the row's own ``enabled``, ``authority`` and ``cron`` so
those can never disagree between two copies.

═══════════════════════════════════════════════════════════════════════════
THE CORE'S VALIDATOR IS THE AUTHORITY.  THIS MODULE DOES NOT RE-VALIDATE.
═══════════════════════════════════════════════════════════════════════════

The translation is STRUCTURAL: key renames, the guard shape, the weekday
numbering, one placeholder key instead of ``{X}`` in a string.  Every rule
the core owns — the placeholder vocabulary, the closed set of masks, step
names, bind types, guard typing — is left to ``clockwork.job_definition
.validate_job``, called here on the translated result, and its problems are
returned in ITS words.  Copying those rules would be a second answer to one
question; the recorded failure mode is the two answers drifting.

The only problems this module raises itself are the things the core CANNOT
express, so that an author learns "the dispatcher has no such thing" rather
than a puzzling core message: a non-equality predicate, a placeholder
embedded in other text, an HTTP output with no declared type, an array path
-- and a query template that cannot be READ here (missing, inactive, or
declared for a connection type the dispatcher's Oracle session cannot be).

A QUERY TEMPLATE TRAVELS AS DATA (2026-09-10, completion round).  Until
then this module refused ``template_id`` -- "not executable by the
dispatcher" -- while the table, the routes, the validator and the form
field all existed: a surface a person could author that nothing could run.
Now the template row's ``sql_text``, ``name`` and ``version`` are inlined
into the step's params (``template_sql`` / ``template_name`` /
``template_version``) and the job's ``bind_values`` become
``template_binds``, typed exactly like predicate values.  The core's
``sql_scalar`` validates the statement and matches every ``:name`` to one
bind before the claim.  Like the calendar, the snapshot is re-derived when
the template changes (``mixin_clockwork.reproject_clockwork_jobs_for_template``).

THE CALENDAR TRAVELS AS DATA (plan v2 section 4, built 2026-09-10).  A
bound feed calendar is projected WHOLE -- weekend days, every holiday,
recurring holidays, horizon, version -- into the definition's ``calendar``
object, and the core walks it.  The preview and the fire therefore resolve
the same day, holidays included; a calendar the projection cannot read is a
refusal, never a weekend-only guess.

THE STEP'S CONNECTION travels as ``connection_id`` on every Oracle step (the
step's own, else the job's): the core resolves it through the dispatch
credentials relation and qsvault in its RESOLVE phase, before the claim.

THE SCHEDULE EXPRESSION is checked by the core's ONE parser (``cron`` may be
a five-field cron or ``wd N HH:MM``); its warnings -- cron's ORed
day-of-month/day-of-week -- travel back as ``Projection.warnings``.

═══════════════════════════════════════════════════════════════════════════
WHERE THE RESULT LIVES, AND WHO WRITES IT
═══════════════════════════════════════════════════════════════════════════

``ClockworkJob.dispatch_definition`` — written by the ONE writer of the
authoring row (``mixin_clockwork``) in the same transaction as the fields it
derives from.  NULL means "this row cannot dispatch", and the view excludes
it.  An ENABLED job with no projection is refused at that writer, so an
enabled row is always a dispatchable row.  A manual request snapshots the
projection onto the request row at request time.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple

from core.clockwork.core_bridge import CoreUnavailable, load_core

Problem = Dict[str, str]

#: The authoring guard operators -> the core's spellings.
GUARD_OP_MAP: Dict[str, str] = {
    "==": "eq", "!=": "ne", ">": "gt", ">=": "ge", "<": "lt", "<=": "le",
}

#: A value that IS a placeholder and nothing else -- the only form the core
#: binds (``placeholder: NAME``); ``"{X}_suffix"`` cannot be sent.
_PLACEHOLDER_ONLY_RE = re.compile(r"^\s*\{([A-Z][A-Z0-9_]*)\}\s*$")
_PLACEHOLDER_ANY_RE = re.compile(r"\{([A-Z][A-Z0-9_]*)\}")

#: Task types this module knows how to translate.  Anything else is handed
#: to the core as-is, and the core's "not a registered task type" is the
#: answer (it names the registered ones).
_TRANSLATED_TYPES = ("journal", "oracle_proc", "oracle_proc_cursor",
                     "sql_scalar", "http_request")


@dataclass(frozen=True)
class Projection:
    """What the dispatcher would run, or why it cannot -- and what it warns
    about (a valid schedule that may not mean what its author thinks)."""
    definition: Optional[Dict[str, Any]]
    problems: List[Problem] = field(default_factory=list)
    warnings: List[Problem] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.definition is not None and not self.problems


def _p(path: str, message: str) -> Problem:
    return {"path": path, "message": message}


def _is_int(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool)


# ── the translation ────────────────────────────────────────────────────


def translate(definition: Mapping[str, Any], *,
              calendar: Optional[Mapping[str, Any]] = None,
              templates: Optional[Mapping[int, Optional[Mapping[str, Any]]]] = None
              ) -> Tuple[Dict[str, Any], List[Problem]]:
    """Authoring grammar -> core grammar.  Returns the translated definition
    and the problems only THIS side can see (an empty list means "hand it
    to the core").  Pure; no I/O.

    ``calendar`` is the bound feed calendar as the mixin's
    ``clockwork_projection_calendar`` returns it (``name``, ``weekend_days``
    in ISO numbers, ``holidays``, ``recurring_holidays``, ``horizon_end``,
    ``version``) when the job binds one (``calendar_id``), else None.
    ``templates`` maps every ``template_id`` a step names to its
    ``clockwork_query_templates`` row (``to_dict`` shape), or None when the
    row could not be read; ``project`` fills it through ``template_lookup``.
    """
    problems: List[Problem] = []
    templates = templates or {}
    out: Dict[str, Any] = {"timezone": definition.get("timezone") or "UTC"}

    if definition.get("calendar_id") is not None:
        out["calendar"] = _calendar(definition, calendar, problems)
    else:
        out["weekend_days"] = _weekend_days(definition.get("weekend_days"))
    out["idempotent"] = definition.get("idempotent")
    # THE JOB'S OWN GRACE WINDOW travels (2026-09-10 audit: authored,
    # validated, stored, shown -- and never dispatched; the tick used the
    # deployment default while why-not-run read this value).  Carried
    # as-is: the authoring validator bounds it, the core validates it.
    if definition.get("misfire_grace_seconds") is not None:
        out["misfire_grace_seconds"] = definition.get("misfire_grace_seconds")
    job_conn = definition.get("connection_id")

    steps_out: List[Dict[str, Any]] = []
    for i, step in enumerate(definition.get("steps") or []):
        path = f"steps[{i}]"
        if not isinstance(step, Mapping):
            problems.append(_p(path, "step must be an object"))
            continue
        ttype = step.get("task_type")
        params = step.get("params") if isinstance(step.get("params"), Mapping) else {}
        entry: Dict[str, Any] = {"name": step.get("name"), "task_type": ttype}
        if ttype == "journal":
            entry["params"] = {}
        elif ttype == "oracle_proc":
            entry["params"] = _oracle_proc(params, f"{path}.params", problems)
            entry["params"]["connection_id"] = _connection(params, job_conn)
        elif ttype == "oracle_proc_cursor":
            # 2026-09-11 audit: this type fell to the `else` below, so its
            # params travelled untouched and NO connection_id was injected.
            # It saved, it enabled, and the dispatcher refused it on EVERY
            # tick with "names no connection (connection_id 0)" -- the same
            # authored-but-unrunnable class this round closed for templates.
            # It shares proc_name/binds with oracle_proc and adds three keys
            # of its own, which travel as authored.
            entry["params"] = _oracle_proc(params, f"{path}.params", problems)
            for key in ("cursor_param", "status_column", "message_column"):
                if params.get(key) is not None:
                    entry["params"][key] = params.get(key)
            entry["params"]["connection_id"] = _connection(params, job_conn)
        elif ttype == "sql_scalar":
            entry["params"] = _sql_scalar(params, f"{path}.params", problems, templates)
            entry["params"]["connection_id"] = _connection(params, job_conn)
        elif ttype == "http_request":
            entry["params"] = _http_request(params, f"{path}.params", problems)
        else:
            # Unknown to the translation: the core says "not a registered
            # task type" and names the registered ones.  Its params travel
            # untouched so the message is about the TYPE, not the shape.
            entry["params"] = dict(params)
        when = step.get("when")
        if when is not None:
            entry["when"] = _guard(when)
        steps_out.append(entry)
    out["steps"] = steps_out
    return out, problems


def _weekend_days(raw: Any) -> Optional[List[int]]:
    """ISO weekday numbers (Mon=1..Sun=7) -> the core's Monday=0..Sunday=6.
    A shape the authoring validator refuses projects as None."""
    if raw is None or not isinstance(raw, (list, tuple)):
        return None
    days: List[int] = []
    for d in raw:
        if _is_int(d) and 1 <= d <= 7:
            days.append(d - 1)
        else:
            return None                  # not this module's refusal
    return sorted(set(days))


def _calendar(definition: Mapping[str, Any], calendar: Optional[Mapping[str, Any]],
              problems: List[Problem]) -> Optional[Dict[str, Any]]:
    """The bound calendar as the core's ``calendar`` object.  Unreadable or
    inactive is a REFUSAL: a job cannot fire against a calendar nobody can
    read, and a weekend-only guess is the pattern not to copy."""
    cal_id = definition.get("calendar_id")
    if calendar is None:
        problems.append(_p("calendar_id",
                           f"calendar {cal_id} could not be read (missing, or its holidays "
                           f"are unreadable), so it cannot be projected for the dispatcher"))
        return None
    if calendar.get("inactive"):
        problems.append(_p("calendar_id", f"calendar {calendar.get('name', cal_id)!r} is inactive"))
        return None
    weekend = _weekend_days(calendar.get("weekend_days"))
    if weekend is None:
        problems.append(_p("calendar_id",
                           f"calendar {calendar.get('name', cal_id)!r} declares no weekend days; "
                           f"the dispatcher must not guess them"))
        return None
    return {
        "weekend_days": weekend,
        "holidays": list(calendar.get("holidays") or []),
        "recurring_holidays": list(calendar.get("recurring_holidays") or []),
        "horizon_end": calendar.get("horizon_end"),
        "name": str(calendar.get("name") or f"calendar {cal_id}"),
        "version": int(calendar.get("version") or 0),
    }


def _connection(params: Mapping[str, Any], job_conn: Any) -> int:
    """The step's connection, else the job's, else 0 (which the core's
    postgres backend refuses before the claim -- and the authoring validator
    has already refused at save)."""
    step_conn = params.get("connection_id")
    if _is_int(step_conn):
        return int(step_conn)
    if _is_int(job_conn):
        return int(job_conn)
    return 0


def _guard(when: Any) -> Any:
    """``[{ref, op, value}]`` -> ``{"all": [{ref, op: eq|ne|..., value}]}``.
    A shape the core would refuse is passed through so the core refuses it
    in its own words."""
    if not isinstance(when, list):
        return when
    clauses = []
    for c in when:
        if not isinstance(c, Mapping):
            clauses.append(c)
            continue
        clause = dict(c)
        clause["op"] = GUARD_OP_MAP.get(str(c.get("op")), c.get("op"))
        clauses.append(clause)
    return {"all": clauses}


def _placeholder_of(value: Any) -> Tuple[Optional[str], bool]:
    """``(name, embedded)``: the placeholder a value IS, or whether it merely
    CONTAINS one (which the core cannot bind)."""
    if not isinstance(value, str):
        return None, False
    m = _PLACEHOLDER_ONLY_RE.fullmatch(value)
    if m:
        return m.group(1), False
    return None, bool(_PLACEHOLDER_ANY_RE.search(value))


def _typed_value(value: Any, fmt: Any, path: str,
                 problems: List[Problem]) -> Dict[str, Any]:
    """ONE rule for "a typed value from the occurrence" -- a predicate
    condition and a template bind are the same shape to the core: a
    placeholder bound WHOLE (a DATE bind when no mask, VARCHAR2 text under
    the mask when one is given), a numeric literal as NUMBER, anything
    else as VARCHAR2 text."""
    entry: Dict[str, Any] = {}
    name, embedded = _placeholder_of(value)
    if name:
        entry["placeholder"] = name
        entry["type"] = "VARCHAR2" if fmt not in (None, "") else "DATE"
    elif embedded:
        problems.append(_p(f"{path}.value",
                           f"the dispatcher binds a placeholder WHOLE; {value!r} embeds "
                           f"one in other text"))
        entry["type"] = "VARCHAR2"
    elif isinstance(value, (int, float)) and not isinstance(value, bool):
        entry["type"] = "NUMBER"
        entry["value"] = str(value)
    else:
        entry["type"] = "VARCHAR2"
        entry["value"] = "" if value is None else str(value)
    if fmt not in (None, ""):
        entry["format"] = str(fmt)
    return entry


def _oracle_proc(params: Mapping[str, Any], path: str,
                 problems: List[Problem]) -> Dict[str, Any]:
    out: Dict[str, Any] = {"proc_name": params.get("procedure"), "binds": []}
    binds = params.get("binds")
    if not isinstance(binds, list):
        out["binds"] = binds
        return out
    for i, b in enumerate(binds):
        bp = f"{path}.binds[{i}]"
        if not isinstance(b, Mapping):
            out["binds"].append(b)
            continue
        entry: Dict[str, Any] = {
            "name": b.get("name"),
            "type": str(b.get("type") or "VARCHAR2").upper(),
            "direction": str(b.get("direction") or "IN").upper(),
        }
        if entry["direction"] == "IN":
            value = b.get("value")
            name, embedded = _placeholder_of(value)
            if name:
                entry["placeholder"] = name
            elif embedded:
                problems.append(_p(f"{bp}.value",
                                   f"the dispatcher binds a placeholder WHOLE; {value!r} embeds "
                                   f"one in other text and cannot be sent as one bind"))
            else:
                entry["value"] = "" if value is None else str(value)
            fmt = b.get("format")
            if fmt not in (None, ""):
                entry["format"] = str(fmt)
        out["binds"].append(entry)
    return out


def _sql_scalar(params: Mapping[str, Any], path: str, problems: List[Problem],
                templates: Mapping[int, Optional[Mapping[str, Any]]]) -> Dict[str, Any]:
    if params.get("template_id") is not None:
        return _sql_template(params, path, problems, templates)
    pred = params.get("predicate")
    if not isinstance(pred, Mapping):
        return {"table": None, "where": []}
    out: Dict[str, Any] = {"table": pred.get("table"), "where": []}
    conds = pred.get("conditions")
    if not isinstance(conds, list):
        return out
    for i, c in enumerate(conds):
        cp = f"{path}.predicate.conditions[{i}]"
        if not isinstance(c, Mapping):
            out["where"].append(c)
            continue
        op = c.get("op", "=")
        if op != "=":
            problems.append(_p(f"{cp}.op",
                               f"the dispatcher's predicate compares for EQUALITY only; "
                               f"{op!r} cannot be projected"))
        entry: Dict[str, Any] = {"column": c.get("column")}
        entry.update(_typed_value(c.get("value"), c.get("format"), cp, problems))
        out["where"].append(entry)
    return out


def _sql_template(params: Mapping[str, Any], path: str, problems: List[Problem],
                  templates: Mapping[int, Optional[Mapping[str, Any]]]) -> Dict[str, Any]:
    """The template row INLINED: its statement, name and version, and the
    job's ``bind_values`` as typed ``template_binds``.  A row that cannot be
    read, is inactive, or is declared for a connection type the core's
    Oracle session cannot be, is a REFUSAL here in the authoring plane's
    words; the statement and bind rules are the core's, applied by it."""
    tid = params.get("template_id")
    row = templates.get(int(tid)) if _is_int(tid) else None
    if row is None:
        problems.append(_p(f"{path}.template_id",
                           f"query template {tid!r} could not be read (missing, or not an "
                           f"integer id), so it cannot be projected for the dispatcher"))
        return {"table": None, "where": []}
    if not row.get("is_active", True):
        problems.append(_p(f"{path}.template_id",
                           f"query template {row.get('name', tid)!r} is inactive; the "
                           f"dispatcher must not run a retired statement"))
    ctype = str(row.get("connection_type") or "").lower()
    if ctype != "oracle":
        problems.append(_p(f"{path}.template_id",
                           f"query template {row.get('name', tid)!r} is declared for "
                           f"{ctype!r} connections; the dispatcher runs a template on an "
                           f"Oracle session only"))
    out: Dict[str, Any] = {
        "template_name": str(row.get("name") or ""),
        "template_version": int(row.get("version") or 0),
        "template_sql": str(row.get("sql_text") or ""),
        "template_binds": [],
        # the author's declaration travels with the statement (2026-09-11):
        # the core's sql_scalar reads it to record an execution-time error
        # as FAILED rather than page UNKNOWN.  Absent = false = unsafe.
        "template_side_effect_free": row.get("side_effect_free") is True,
    }
    bv = params.get("bind_values")
    if bv is None:
        bv = {}
    if not isinstance(bv, Mapping):
        out["template_binds"] = bv           # the core refuses the shape in its words
        return out
    for name, v in bv.items():
        bp = f"{path}.bind_values.{name}"
        if isinstance(v, Mapping):
            value, fmt = v.get("value"), v.get("format")
        else:
            value, fmt = v, None
        entry: Dict[str, Any] = {"name": str(name)}
        entry.update(_typed_value(value, fmt, bp, problems))
        out["template_binds"].append(entry)
    return out


def template_ids_of(definition: Mapping[str, Any]) -> List[int]:
    """Every ``template_id`` a definition's steps name -- what the mixin
    re-projects when a template changes, and what ``project`` looks up."""
    out: List[int] = []
    for step in definition.get("steps") or []:
        if not isinstance(step, Mapping) or step.get("task_type") != "sql_scalar":
            continue
        params = step.get("params") if isinstance(step.get("params"), Mapping) else {}
        tid = params.get("template_id")
        if _is_int(tid) and int(tid) not in out:
            out.append(int(tid))
    return out


def _http_request(params: Mapping[str, Any], path: str,
                  problems: List[Problem]) -> Dict[str, Any]:
    out: Dict[str, Any] = {
        "method": str(params.get("method") or "POST").upper(),
        "url": params.get("url"),
    }
    headers = params.get("headers")
    if isinstance(headers, Mapping):
        out["headers"] = []
        for k, v in headers.items():
            if isinstance(v, str) and _PLACEHOLDER_ANY_RE.search(v):
                problems.append(_p(f"{path}.headers.{k}",
                                   "the dispatcher sends header values as typed; a "
                                   "placeholder in a header is not resolved"))
            out["headers"].append({"name": str(k), "value": v})
    body = params.get("body")
    if body is not None:
        out["body"] = json.dumps(body, sort_keys=True) if isinstance(body, (Mapping, list)) else body
        out["content_type"] = "application/json"
    ejp = params.get("expect_json_paths")
    if isinstance(ejp, list):
        out["expect"] = []
        for i, e in enumerate(ejp):
            ep = f"{path}.expect_json_paths[{i}]"
            if not isinstance(e, Mapping):
                out["expect"].append(e)
                continue
            entry: Dict[str, Any] = {"name": e.get("name"), "path": _dotted(e.get("path"), ep, problems)}
            if "type" in e:
                entry["type"] = e.get("type")
            else:
                problems.append(_p(f"{ep}.type",
                                   f"output {e.get('name')!r} declares no type; the dispatcher "
                                   f"needs number, text or boolean so a later guard compares "
                                   f"like with like (add \"type\" to the entry)"))
            out["expect"].append(entry)
    return out


def _dotted(raw: Any, path: str, problems: List[Problem]) -> Any:
    """``$.a.b`` -> ``a.b``; an array index is refused (objects only)."""
    if not isinstance(raw, str):
        return raw
    text = raw.strip()
    if text.startswith("$."):
        text = text[2:]
    elif text == "$":
        text = ""
    if "[" in text or "]" in text:
        problems.append(_p(f"{path}.path",
                           f"{raw!r}: the dispatcher reads dotted object paths only, no array "
                           f"indexing"))
    return text


# ── the projection: translate, then the core's own validator ─────────


def project(definition: Mapping[str, Any], *,
            calendar_lookup: Optional[Callable[[int], Optional[Mapping[str, Any]]]] = None,
            template_lookup: Optional[Callable[[int], Optional[Mapping[str, Any]]]] = None
            ) -> Projection:
    """Translate and validate with the core.  Raises :class:`CoreUnavailable`
    when the core cannot be imported -- the caller decides whether that is a
    503 (a save or a fire) or a stored NULL (a draft).

    ``template_lookup`` reads a ``clockwork_query_templates`` row by id; a
    step naming a template with no lookup given projects as "could not be
    read" -- never as a template the core runs blind."""
    calendar = None
    cal_id = definition.get("calendar_id")
    if cal_id is not None and calendar_lookup is not None:
        try:
            calendar = calendar_lookup(int(cal_id))
        except (TypeError, ValueError):
            calendar = None
    templates: Dict[int, Optional[Mapping[str, Any]]] = {}
    for tid in template_ids_of(definition):
        templates[tid] = template_lookup(tid) if template_lookup is not None else None
    translated, problems = translate(definition, calendar=calendar, templates=templates)
    core = load_core()
    schedule_problems, schedule_warnings = core.schedule.check_expression(
        definition.get("cron"))
    problems += [_p("cron", p) for p in schedule_problems]
    warnings = [_p("cron", w) for w in schedule_warnings]
    if problems:
        return Projection(None, problems, warnings)
    try:
        core.validate_job(translated, core.catalogue())
    except core.error as exc:
        return Projection(None, [_p("dispatch", p) for p in exc.problems], warnings)
    return Projection(translated, [], warnings)


def project_or_reasons(definition: Mapping[str, Any], *,
                       calendar_lookup: Optional[Callable[[int], Optional[Mapping[str, Any]]]] = None,
                       template_lookup: Optional[Callable[[int], Optional[Mapping[str, Any]]]] = None
                       ) -> Projection:
    """``project`` with an unavailable core rendered as a problem instead of
    an exception -- for callers that store a draft and must not fail."""
    try:
        return project(definition, calendar_lookup=calendar_lookup,
                       template_lookup=template_lookup)
    except CoreUnavailable as exc:
        return Projection(None, [_p("dispatch", exc.reason)])


__all__ = ["GUARD_OP_MAP", "Projection", "translate", "project", "project_or_reasons",
           "template_ids_of", "CoreUnavailable"]
