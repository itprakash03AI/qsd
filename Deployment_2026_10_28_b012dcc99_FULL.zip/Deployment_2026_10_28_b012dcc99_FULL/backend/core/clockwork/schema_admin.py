"""Apply the CLOCKWORK-OWNED DDL, and say what the schema state is.

WHY QUERYSTUDIO DOES THIS AND CLOCKWORK DOES NOT.  Exactly-once rests on
the fire log's PRIMARY KEY, so the Clockwork pod PROVES that constraint at
boot and REFUSES TO START when it is not there.  A service that created the
constraint it then "proved" would be proving its own assumption, so that
refusal stays exactly as it is.  What was left over was a manual step --
``psql -f`` two files and any ``ALTER_*`` upgrade -- which an operator meets
two commands later as a startup refusal pointing at a file they have never
heard of.  QueryStudio owns this database and already makes the dispatch
views and the arbiter index at every API start; this module extends that
pattern to the DDL Clockwork owns.

ONE DEFINITION.  The SQL is read from the INSTALLED ``clockwork`` package
(``clockwork/sql/*``, located through ``core_bridge``), never copied here.
Two DDLs for one table is the drift defect this build has already paid for.

WHAT DECIDES WHETHER A SCRIPT RUNS: THE DATABASE, NOT THE LEDGER.  Each
script in ``clockwork.ddl.MANIFEST`` declares a POSTCONDITION -- the table,
the columns and the indexes it must leave behind -- and this module reads
the catalogue and compares.  A database restored from a backup, or patched
by hand, is therefore read as it actually is.  ``clockwork_schema_migrations``
records what was DONE (when, by whom, from which text) and is shown as
history; it is never consulted to decide.

ORDER comes from the manifest's tuple order, which is authored, not
inferred from file names.  The state is RE-READ between scripts, so the
record-columns ALTER is skipped on a fresh database (the CREATE already
carries those columns) and runs on an old one.

NEVER DESTRUCTIVE.  A statement carrying a destructive keyword
(``clockwork.ddl.destructive``) is refused, not run.  A table that exists in
a shape the shipped CREATE does not describe is a ``conflict``: reported by
name, never "fixed".  Nothing here DROPs or rewrites anything.

FAIL LOUDLY.  Every outcome is a named status with a reason -- and "the
catalogue could not be read" (``unknown``) is deliberately a different
answer from "the table is not there" (``missing``).  Unknown is not empty.
"""
from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence, Set, Tuple

logger = logging.getLogger(__name__)

#: SQLAlchemy dialect name -> the Clockwork DDL dialect.  A dialect absent
#: from this map has no Clockwork DDL shipped for it, which is reported as
#: a reason rather than passing silently -- SQLite (the test and
#: single-developer database) is the live example.
DIALECTS: Dict[str, str] = {"postgresql": "postgres", "oracle": "oracle"}

STATUS_SATISFIED = "satisfied"
STATUS_MISSING = "missing"
STATUS_CONFLICT = "conflict"
STATUS_MANUAL = "manual"
STATUS_UNKNOWN = "unknown"

#: The script kind that MAKES a table -- pinned equal to
#: ``clockwork.ddl.CREATE`` by the test suite, so the two trees share one
#: vocabulary rather than two spellings of it.
KIND_CREATE = "create"

#: Ledger statuses.  ``satisfied`` never reaches the ledger: a startup that
#: found everything in place did nothing, and a row per start would bury the
#: rows that mean something.
LEDGER_APPLIED = "applied"
LEDGER_FAILED = "failed"
LEDGER_REFUSED = "refused"

#: The object a statement creates, so a script can be applied per object:
#: a CREATE whose table is already there runs only its missing indexes, and
#: a CREATE TABLE is never re-issued against an existing table.  Matched on
#: Clockwork's OWN shipped files, whose shape ``clockwork/tests`` pins.
_CREATE_TABLE = re.compile(r"^\s*CREATE\s+TABLE\s+(\w+)", re.IGNORECASE)
_CREATE_INDEX = re.compile(r"^\s*CREATE\s+(?:UNIQUE\s+)?INDEX\s+(\w+)", re.IGNORECASE)


class CoreMissing(RuntimeError):
    """The ``clockwork`` package is not importable, so its DDL cannot be
    read.  The reason is the core bridge's own."""


@dataclass
class State:
    """What the catalogue says, folded to lower case.  ``ok`` False means
    it could not be read -- which is not the same as "nothing is there"."""
    ok: bool = True
    reason: str = ""
    tables: Dict[str, Dict[str, Set[str]]] = field(default_factory=dict)

    def has_table(self, name: str) -> bool:
        return name.lower() in self.tables

    def columns(self, name: str) -> Set[str]:
        return self.tables.get(name.lower(), {}).get("columns", set())

    def indexes(self, name: str) -> Set[str]:
        return self.tables.get(name.lower(), {}).get("indexes", set())


def statement_object(statement: str) -> Tuple[str, str]:
    """``("table"|"index"|"", name)`` for a shipped statement.  A statement
    with no object ("" ) is gated by its script's postcondition instead."""
    found = _CREATE_TABLE.match(statement)
    if found:
        return "table", found.group(1).lower()
    found = _CREATE_INDEX.match(statement)
    if found:
        return "index", found.group(1).lower()
    return "", ""


def dialect_of(engine) -> Optional[str]:
    """The Clockwork DDL dialect for ``engine``, or None."""
    return DIALECTS.get(getattr(getattr(engine, "dialect", None), "name", ""))


def _core_ddl():
    """The installed core's ``ddl`` module, or :class:`CoreMissing`."""
    from core.clockwork import core_bridge
    try:
        core_bridge.load_core()
    except core_bridge.CoreUnavailable as exc:
        raise CoreMissing(exc.reason) from exc
    try:
        from clockwork import ddl as cw_ddl
    except ImportError as exc:                          # noqa: BLE001
        raise CoreMissing(
            f"the installed clockwork package has no DDL manifest ({exc}); it predates "
            f"2026-09-11, when the .sql files moved inside the package.  Upgrade the "
            f"clockwork package, or apply the DDL by hand from its sql/ directory") from exc
    return cw_ddl


def read_state(engine, tables: Sequence[str]) -> State:
    """The catalogue for ``tables``, case-insensitively.  A read that fails
    is ``ok=False`` with the reason -- never an empty state, which would be
    reported as "not present" and send an operator to apply DDL that is
    already there."""
    import sqlalchemy as sa
    try:
        insp = sa.inspect(engine)
        present = {name.lower() for name in insp.get_table_names()}
    except Exception as exc:                            # noqa: BLE001
        return State(ok=False,
                     reason=f"the table catalogue could not be read: "
                            f"{type(exc).__name__}: {exc}")
    state = State()
    for table in tables:
        key = table.lower()
        if key not in present or key in state.tables:
            continue
        try:
            columns = {c["name"].lower() for c in insp.get_columns(table)}
            indexes = {(ix.get("name") or "").lower() for ix in insp.get_indexes(table)}
            pk = insp.get_pk_constraint(table) or {}
            if pk.get("name"):
                indexes.add(str(pk["name"]).lower())
        except Exception as exc:                        # noqa: BLE001
            return State(ok=False,
                         reason=f"table {table} exists but its columns could not be "
                                f"read: {type(exc).__name__}: {exc}")
        state.tables[key] = {"columns": columns, "indexes": indexes}
    return state


def required_columns(script, later) -> Tuple[str, ...]:
    """The columns ``script`` alone must leave behind: its declared columns
    minus those a LATER script in the manifest supplies for the same table.

    Without this a fire log created before 2026-09-11 would read as a
    ``conflict`` against the CREATE (which now carries the record columns)
    instead of as work for the ALTER that follows it.
    """
    supplied: Set[str] = set()
    for entry in later:
        if entry.table.lower() == script.table.lower() and not entry.manual_only:
            supplied |= {c.lower() for c in entry.columns}
    return tuple(c for c in script.columns if c.lower() not in supplied)


def evaluate(script, later, state: State) -> Dict[str, Any]:
    """One script's status against ``state`` -- PURE, and the whole decision.

    ``manual`` (never applied, with the reason) · ``unknown`` (the catalogue
    could not be read) · ``satisfied`` · ``conflict`` (the table is there but
    a CREATE's own columns are not, and no later script supplies them -- a
    shape to report, never to rewrite) · ``missing``.
    """
    base = {"id": script.id, "dialect": script.dialect, "filename": script.filename,
            "kind": script.kind, "table": script.table, "purpose": script.purpose,
            "relative_path": script.relative_path,
            "missing_columns": [], "missing_indexes": []}
    if script.manual_only:
        return {**base, "status": STATUS_MANUAL, "reason": script.manual_reason}
    if not state.ok:
        return {**base, "status": STATUS_UNKNOWN,
                "reason": f"whether this is applied cannot be told: {state.reason}"}
    needed = required_columns(script, later)
    if not state.has_table(script.table):
        return {**base, "status": STATUS_MISSING,
                "missing_columns": list(needed),
                "missing_indexes": list(script.indexes),
                "reason": f"table {script.table} is not in this database"}
    have_columns = state.columns(script.table)
    have_indexes = state.indexes(script.table)
    absent_columns = [c for c in needed if c.lower() not in have_columns]
    absent_indexes = [i for i in script.indexes if i.lower() not in have_indexes]
    out = {**base, "missing_columns": absent_columns, "missing_indexes": absent_indexes}
    if not absent_columns and not absent_indexes:
        return {**out, "status": STATUS_SATISFIED,
                "reason": f"table {script.table} carries every column and index this "
                          f"script declares"}
    if absent_columns and script.kind == KIND_CREATE:
        return {**out, "status": STATUS_CONFLICT,
                "reason": (f"table {script.table} exists but does not carry "
                           f"{', '.join(absent_columns)}, which this CREATE declares and "
                           f"no later Clockwork script supplies.  A CREATE cannot be "
                           f"re-run against an existing table and nothing here rewrites "
                           f"one: compare the table with the shipped DDL and decide by "
                           f"hand")}
    parts = []
    if absent_columns:
        parts.append(f"column(s) {', '.join(absent_columns)}")
    if absent_indexes:
        parts.append(f"index(es) {', '.join(absent_indexes)}")
    return {**out, "status": STATUS_MISSING,
            "reason": f"table {script.table} is missing {' and '.join(parts)}"}


def _psql_command(engine, script) -> str:
    """The hand command, with NO password in it.  An operator without the
    UI -- or without the API running -- does it this way."""
    url = getattr(engine, "url", None)
    path = str(script.path)
    if script.dialect == "oracle":
        user = getattr(url, "username", None) or "<user>"
        host = getattr(url, "host", None) or "<host>"
        return f'sqlplus {user}@{host} @"{path}"'
    bits = ["psql", "-v", "ON_ERROR_STOP=1"]
    for flag, value in (("-h", getattr(url, "host", None)),
                        ("-p", getattr(url, "port", None)),
                        ("-U", getattr(url, "username", None)),
                        ("-d", getattr(url, "database", None))):
        if value:
            bits += [flag, str(value)]
    bits += ["-f", f'"{path}"']
    return " ".join(bits)


def plan(engine, dialect: Optional[str] = None) -> Dict[str, Any]:
    """The schema state: every Clockwork-owned script, in apply order, with
    its status, its reason, the EXACT SQL and the hand command.

    ``dialect`` overrides the engine's own -- the live-proof harness and the
    tests use it to run the shipped PostgreSQL DDL against SQLite, which
    takes it verbatim.  Nothing in the product passes it.
    """
    key = dialect or dialect_of(engine)
    out: Dict[str, Any] = {"dialect": key, "engine_dialect": getattr(
        getattr(engine, "dialect", None), "name", ""), "scripts": [],
        "available": False, "reason": ""}
    if key is None:
        out["reason"] = (
            f"Clockwork ships no DDL for dialect "
            f"{out['engine_dialect'] or 'unknown'!r} (it ships "
            f"{', '.join(sorted(DIALECTS.values()))}); its fire log must be created by "
            f"hand on such a database, and the scheduler will refuse to start until it is")
        return out
    try:
        cw_ddl = _core_ddl()
    except CoreMissing as exc:
        out["reason"] = str(exc)
        return out
    scripts = cw_ddl.scripts_for(key)
    state = read_state(engine, [s.table for s in scripts])
    rows = []
    for index, script in enumerate(scripts):
        row = evaluate(script, scripts[index + 1:], state)
        text = script.text()
        row["sql"] = text
        row["checksum"] = hashlib.sha256(text.encode("utf-8")).hexdigest()
        row["statements"] = cw_ddl.statements(text)
        row["path"] = str(script.path)
        row["command"] = _psql_command(engine, script)
        row["manual_only"] = bool(script.manual_only)
        rows.append(row)
    out["scripts"] = rows
    out["available"] = True
    out["counts"] = {status: sum(1 for r in rows if r["status"] == status)
                     for status in (STATUS_SATISFIED, STATUS_MISSING, STATUS_CONFLICT,
                                    STATUS_MANUAL, STATUS_UNKNOWN)}
    return out


def _record(recorder, script, status: str, statements: int, checksum: str,
            actor: str, detail: str) -> None:
    if recorder is None:
        return
    try:
        recorder({"script_id": script.id, "dialect": script.dialect,
                  "filename": script.filename, "kind": script.kind,
                  "checksum": checksum, "statements": statements,
                  "status": status, "applied_by": actor, "detail": detail[:4000]})
    except Exception as exc:                            # noqa: BLE001 - the record is not the work
        logger.error("[clockwork.schema] %s %s but the ledger row could not be written: "
                     "%s: %s", script.id, status, type(exc).__name__, exc)


def apply(engine, script_ids: Optional[Sequence[str]] = None, actor: str = "startup",
          recorder: Optional[Callable[[Dict[str, Any]], Any]] = None,
          dialect: Optional[str] = None) -> Dict[str, Any]:
    """Apply what is missing, in manifest order.  Never raises.

    Returns ``{"ok", "reason", "dialect", "applied": [...], "results": [...]}``.
    Each result carries the script id, the outcome and the reason verbatim.
    A script that FAILS or is REFUSED stops the run for that dialect: the
    ones after it may depend on it, and "carry on and see" is how a
    half-applied schema gets reported as success.  (Proved on a live
    PostgreSQL: with a conflicting fire log the CREATE was refused and the
    record ALTER then ran against that foreign table and reported success.)
    A ``manual`` script stops nothing -- it is a runbook, not a dependency.
    """
    key = dialect or dialect_of(engine)
    result: Dict[str, Any] = {"ok": False, "reason": "", "dialect": key,
                              "applied": [], "results": []}
    if key is None:
        # 2026-09-15 -- SAY WHAT IT MEANS, not just what is absent.  This read
        # "Clockwork ships no DDL for dialect 'sqlite'", which is true and
        # leaves the operator to work out the consequence themselves -- and
        # the consequence is the whole point.  QueryStudio's own tables are
        # created on every dialect by ``create_all``, INCLUDING the Clockwork
        # AUTHORING tables (clockwork_jobs, _settings, _task_types ...), so a
        # SQLite database shows most of the clockwork_* names present and the
        # fire log absent.  That looks like a broken startup step and is not
        # one: a job can be authored here and will never fire, because the
        # fire log -- whose PRIMARY KEY is what makes a fire exactly-once --
        # only exists on the engines Clockwork ships DDL for.
        _name = getattr(getattr(engine, "dialect", None), "name", "")
        result["reason"] = (
            f"Clockwork ships no DDL for dialect {_name!r} -- it ships "
            f"{', '.join(sorted(DIALECTS))} only.  The fire log and the step "
            f"table are therefore ABSENT and nothing can dispatch on this "
            f"database; the Clockwork AUTHORING tables are present anyway "
            f"(create_all makes them on every dialect), so a job saved here "
            f"will never fire.  Exactly-once rests on the fire log's primary "
            f"key, which is why there is no portable spelling.  Point the "
            f"metadata database at PostgreSQL or Oracle to schedule anything.")
        return result
    try:
        cw_ddl = _core_ddl()
    except CoreMissing as exc:
        result["reason"] = str(exc)
        return result
    import sqlalchemy as sa

    scripts = list(cw_ddl.scripts_for(key))
    wanted = None if script_ids is None else set(script_ids)
    if wanted is not None:
        unknown = wanted - {s.id for s in scripts}
        if unknown:
            result["reason"] = (f"no Clockwork script is declared as "
                                f"{', '.join(sorted(unknown))} for dialect {key}")
            return result
    stopped = False
    for index, script in enumerate(scripts):
        if wanted is not None and script.id not in wanted:
            continue
        if stopped:
            result["results"].append({"id": script.id, "outcome": "not_attempted",
                                      "reason": "an earlier script in the manifest failed; "
                                                "order matters, so this was not attempted"})
            continue
        text = script.text()
        checksum = hashlib.sha256(text.encode("utf-8")).hexdigest()
        state = read_state(engine, [s.table for s in scripts])
        verdict = evaluate(script, scripts[index + 1:], state)
        status = verdict["status"]
        if status == STATUS_SATISFIED:
            result["results"].append({"id": script.id, "outcome": "skipped",
                                      "reason": verdict["reason"]})
            continue
        if status == STATUS_MANUAL:
            # Nothing was done, so nothing is recorded and nothing is wrong:
            # the manifest declares this one as a person's judgement and the
            # admin page shows it with the reason and the command.
            result["results"].append({"id": script.id, "outcome": "manual",
                                      "reason": verdict["reason"]})
            continue
        if status in (STATUS_CONFLICT, STATUS_UNKNOWN):
            # A refusal STOPS the rest, exactly as a failure does.  Proved on
            # a live PostgreSQL on 2026-09-11: with a conflicting
            # clockwork_fire_log the CREATE was refused (right) and the
            # record ALTER then ran against that foreign table and reported
            # SUCCESS (wrong).  When the shape is not what the manifest
            # describes, no later script in the manifest may act on it.
            result["results"].append({"id": script.id, "outcome": "refused",
                                      "reason": verdict["reason"]})
            _record(recorder, script, LEDGER_REFUSED, 0, checksum, actor, verdict["reason"])
            logger.error("[clockwork.schema] REFUSED %s: %s", script.id, verdict["reason"])
            stopped = True
            continue
        runnable: List[str] = []
        blocked = ""
        for statement in cw_ddl.statements(text):
            word = cw_ddl.destructive(statement)
            if word:
                blocked = (f"statement {len(runnable) + 1} of {script.relative_path} carries "
                           f"{word}; nothing here may DROP or rewrite an existing object, so "
                           f"the whole script was refused and NOTHING was applied")
                break
            kind, name = statement_object(statement)
            if kind == "table" and state.has_table(name):
                continue
            if kind == "index" and name in state.indexes(script.table):
                continue
            runnable.append(statement)
        if blocked:
            result["results"].append({"id": script.id, "outcome": "refused", "reason": blocked})
            _record(recorder, script, LEDGER_REFUSED, 0, checksum, actor, blocked)
            logger.error("[clockwork.schema] REFUSED %s: %s", script.id, blocked)
            stopped = True
            continue
        if not runnable:
            reason = (f"{script.relative_path} has no statement left to run, yet "
                      f"{verdict['reason']}.  This is a shape to look at by hand, not "
                      f"something to force")
            result["results"].append({"id": script.id, "outcome": "refused", "reason": reason})
            _record(recorder, script, LEDGER_REFUSED, 0, checksum, actor, reason)
            logger.error("[clockwork.schema] REFUSED %s: %s", script.id, reason)
            stopped = True
            continue
        try:
            with engine.begin() as conn:
                for statement in runnable:
                    conn.execute(sa.text(statement))
        except Exception as exc:                        # noqa: BLE001 - reported, never fatal
            reason = (f"{script.relative_path} could not be applied: {type(exc).__name__}: "
                      f"{exc}.  Nothing from it was committed.  Apply it by hand as the "
                      f"owner of the schema: {_psql_command(engine, script)}")
            result["results"].append({"id": script.id, "outcome": "failed", "reason": reason})
            _record(recorder, script, LEDGER_FAILED, 0, checksum, actor, reason)
            logger.error("[clockwork.schema] FAILED %s: %s", script.id, reason, exc_info=True)
            stopped = True
            continue
        after = evaluate(script, scripts[index + 1:],
                         read_state(engine, [s.table for s in scripts]))
        if after["status"] != STATUS_SATISFIED:
            reason = (f"{script.relative_path} ran ({len(runnable)} statement(s)) and its "
                      f"postcondition still does not hold: {after['reason']}")
            result["results"].append({"id": script.id, "outcome": "failed", "reason": reason})
            _record(recorder, script, LEDGER_FAILED, len(runnable), checksum, actor, reason)
            logger.error("[clockwork.schema] FAILED %s: %s", script.id, reason)
            stopped = True
            continue
        detail = f"ran {len(runnable)} statement(s): {verdict['reason']}"
        result["applied"].append(script.id)
        result["results"].append({"id": script.id, "outcome": "applied", "reason": detail})
        _record(recorder, script, LEDGER_APPLIED, len(runnable), checksum, actor, detail)
        logger.info("[clockwork.schema] applied %s (%d statement(s)) -- %s",
                    script.id, len(runnable), verdict["reason"])
    result["ok"] = not any(r["outcome"] in ("failed", "refused") for r in result["results"])
    if not result["ok"]:
        result["reason"] = "; ".join(f"{r['id']}: {r['reason']}" for r in result["results"]
                                     if r["outcome"] in ("failed", "refused"))
    return result


def ensure_schema(engine, recorder: Optional[Callable[[Dict[str, Any]], Any]] = None
                  ) -> Dict[str, Any]:
    """Run at every API start, beside ``dispatch_views.ensure_views``.

    Never raises and never takes the API down; a failure is an ERROR line
    naming the script and the hand command, and the admin schema page says
    the same thing.  A dialect with no shipped DDL is logged once at INFO --
    it is a fact about this database, not a fault.
    """
    try:
        outcome = apply(engine, actor="startup", recorder=recorder)
    except Exception as exc:                            # noqa: BLE001
        logger.error("[clockwork.schema] the Clockwork DDL could not be applied: %s: %s",
                     type(exc).__name__, exc, exc_info=True)
        return {"ok": False, "reason": f"{type(exc).__name__}: {exc}",
                "applied": [], "results": [], "dialect": None}
    if outcome["dialect"] is None:
        logger.info("[clockwork.schema] %s", outcome["reason"] or "no Clockwork DDL here")
    elif not outcome["ok"]:
        logger.error("[clockwork.schema] the Clockwork-owned DDL is NOT fully applied -- "
                     "the scheduler will refuse to start: %s", outcome["reason"])
    elif outcome["applied"]:
        logger.info("[clockwork.schema] applied %s", ", ".join(outcome["applied"]))
    else:
        # 2026-09-15 -- SAY SO WHEN THERE IS NOTHING TO DO.  Every other
        # outcome logged; "already satisfied" logged NOTHING, so a healthy
        # start was indistinguishable from this step never running -- which
        # is exactly what it looked like ("why is the API not creating the
        # Clockwork tables at startup?").  It was creating them: on an empty
        # database all 14 tables appear.  What was missing was the evidence.
        # Silence is not a status; this module's own docstring says unknown
        # is not empty, and that cuts both ways.
        _n = len(outcome.get("results") or ())
        logger.info(
            "[clockwork.schema] %d Clockwork-owned script(s) already "
            "satisfied on %s -- nothing to apply", _n, outcome["dialect"])
    return outcome


__all__ = ["DIALECTS", "CoreMissing", "State", "STATUS_SATISFIED", "STATUS_MISSING",
           "STATUS_CONFLICT", "STATUS_MANUAL", "STATUS_UNKNOWN", "KIND_CREATE",
           "LEDGER_APPLIED",
           "LEDGER_FAILED", "LEDGER_REFUSED", "dialect_of", "read_state",
           "required_columns", "evaluate", "statement_object", "plan", "apply",
           "ensure_schema"]
