"""The ONE place QueryStudio imports the Clockwork core — lazily.

Plan v2 §6: "QueryStudio takes clockwork as a library dependency and calls
the same ``validate_job()`` the dispatcher calls."  And §10: "The library
dependency cuts both ways.  QueryStudio importing clockwork means a bad
task module could break QueryStudio's startup.  The import must be lazy and
its failure must be a scoped 503, not a boot failure."

So nothing here runs at import time.  ``load_core()`` imports the package on
first use, discovers its task-type catalogue once, and hands back the four
things the authoring plane needs: the validator, its error type, the
catalogue and the settings schema.  A missing package is ``CoreUnavailable``
— the caller turns that into a 503 with the reason, and a save that could
not be checked against the dispatcher's own validator is never stored as
dispatchable.

WHERE THE PACKAGE COMES FROM.  In the API image it is installed
(``Dockerfile.api`` copies ``clockwork/`` and pip-installs it with
``--no-deps``).  On a developer's machine and in the test suite the
package sits beside ``backend/`` in the same checkout; that sibling is
found from this file's own location and put on ``sys.path`` — the same
derivation ``tests/_paths.py`` uses for the repo root — and
``QUERYSTUDIO_CLOCKWORK_CORE_PATH`` overrides it for any other layout.
An installed package always wins over the sibling.
"""
from __future__ import annotations

import logging
import os
import sys
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, Mapping, Optional

logger = logging.getLogger(__name__)

#: Overrides the sibling-checkout lookup: the directory that CONTAINS the
#: ``clockwork`` package (i.e. the repo's ``clockwork/`` folder).
CORE_PATH_ENV = "QUERYSTUDIO_CLOCKWORK_CORE_PATH"


class CoreUnavailable(RuntimeError):
    """The Clockwork core cannot be imported here; ``reason`` says why."""

    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


@dataclass(frozen=True)
class Core:
    """What the authoring plane uses from the dispatcher's package."""
    #: ``validate_job(raw, catalogue) -> JobDefinition``; raises ``error``.
    validate_job: Callable[..., Any]
    #: ``JobDefinitionError`` — carries ``.problems``, the whole list.
    error: type
    #: ``{task type name: TaskDeclaration}`` — every REGISTERED type.
    catalogue: Callable[[], Mapping[str, Any]]
    #: ``config.SETTINGS_SCHEMA`` — the ONE settings schema.
    settings_schema: Any
    #: ``config.coerce_text`` — text -> declared type, the way the pod does it.
    coerce_text: Callable[..., Dict[str, Any]]
    #: ``params.ParamError`` — what the schema raises.
    param_error: type
    #: ``config.ConfigError`` — what ``coerce_text`` raises.
    config_error: type
    version: str
    location: str
    #: The core's ``schedule`` module: ``parse_schedule``, ``check_expression``
    #: (problems, warnings), ``most_recent``, ``next_occurrences``, ``grammar``.
    #: ONE parser for the schedule expression -- the preview, the validator
    #: and the dispatcher all ask it, so a working-day expression means the
    #: same thing on every side of the seam.
    schedule: Any = None
    #: The core's ``calendar`` module: ``parse_calendar`` for the projected
    #: calendar object.
    calendar: Any = None
    #: The core's ``placeholders`` module: the vocabulary and the resolver
    #: the dispatcher itself runs, so a preview shows what will be sent.
    placeholders: Any = None
    #: The core's ``occurrence`` module: ``most_recent_instant`` / the fire key.
    occurrence: Any = None
    #: The core's ``egress`` module: WHERE a pod may send an outbound request.
    #: ``name_refusal`` is the pure half of that policy -- no DNS, no pod
    #: configuration -- and the authoring plane applies THAT FUNCTION at save
    #: time rather than a copy of its rules, so a job whose host the
    #: dispatcher would refuse is never stored as dispatchable.
    egress: Any = None


_lock = threading.Lock()
_core: Optional[Core] = None
_failure: Optional[str] = None


def _sibling_checkout() -> Optional[Path]:
    """``<repo>/clockwork`` for this file at ``<repo>/backend/core/clockwork/``."""
    override = (os.environ.get(CORE_PATH_ENV) or "").strip()
    if override:
        return Path(override)
    return Path(__file__).resolve().parents[3] / "clockwork"


def _is_real_package(module: Any) -> bool:
    """The core, not a NAMESPACE package.  With the repo root on ``sys.path``
    (pytest puts it there) ``import clockwork`` resolves to the project
    FOLDER ``<repo>/clockwork`` -- a namespace package with no ``__file__``
    whose ``.config`` does not exist.  That is not the core; it is the
    directory the core lives in."""
    file = getattr(module, "__file__", None)
    return bool(file) and (Path(file).resolve().parent / "job_definition.py").is_file()


def _forget_namespace_package() -> None:
    for name in [n for n in sys.modules if n == "clockwork" or n.startswith("clockwork.")]:
        del sys.modules[name]


def _import_package():
    first: Optional[BaseException] = None
    try:
        import clockwork  # noqa: F401  (installed in the image)
        if _is_real_package(clockwork):
            return clockwork
        _forget_namespace_package()
    except ImportError as exc:
        first = exc
    candidate = _sibling_checkout()
    if candidate is None or not (candidate / "clockwork" / "__init__.py").is_file():
        raise CoreUnavailable(
            f"the clockwork package is not installed ({first or 'a namespace package shadows it'}) "
            f"and no checkout was found at {candidate} (set {CORE_PATH_ENV} to the directory "
            f"that contains the 'clockwork' package).  Until it is present, a job cannot be "
            f"checked against the dispatcher's validator and will not be stored as dispatchable.")
    text = str(candidate)
    if text in sys.path:
        sys.path.remove(text)
    sys.path.insert(0, text)          # the real package must win the search
    try:
        import clockwork  # noqa: F401
    except ImportError as second:
        raise CoreUnavailable(
            f"the clockwork checkout at {candidate} could not be imported: {second}")
    if not _is_real_package(clockwork):
        raise CoreUnavailable(
            f"'clockwork' still resolves to {getattr(clockwork, '__path__', None)} rather than "
            f"the package at {candidate}")
    return clockwork


def load_core() -> Core:
    """The core, imported once.  Raises :class:`CoreUnavailable`.

    A failed first attempt is remembered only as its reason: a later call
    tries again, so installing the package fixes a running pod on the next
    request rather than after a restart.
    """
    global _core, _failure
    with _lock:
        if _core is not None:
            return _core
        try:
            package = _import_package()
            from clockwork import calendar as cw_calendar
            from clockwork import egress as cw_egress
            from clockwork import occurrence as cw_occurrence
            from clockwork import placeholders as cw_placeholders
            from clockwork import schedule as cw_schedule
            from clockwork.config import SETTINGS_SCHEMA, ConfigError, coerce_text
            from clockwork.job_definition import JobDefinitionError, validate_job
            from clockwork.main import catalogue, discover
            from clockwork.params import ParamError
            discover()
        except CoreUnavailable as exc:
            _failure = exc.reason
            raise
        except Exception as exc:                        # noqa: BLE001 - scoped 503, never a boot failure
            _failure = f"the clockwork core failed to load: {type(exc).__name__}: {exc}"
            logger.error("[clockwork] %s", _failure, exc_info=True)
            raise CoreUnavailable(_failure) from exc
        _core = Core(
            validate_job=validate_job, error=JobDefinitionError, catalogue=catalogue,
            settings_schema=SETTINGS_SCHEMA, coerce_text=coerce_text, param_error=ParamError,
            config_error=ConfigError,
            version=str(getattr(package, "__version__", "") or ""),
            location=str(Path(package.__file__).resolve().parent),
            schedule=cw_schedule, calendar=cw_calendar,
            placeholders=cw_placeholders, occurrence=cw_occurrence,
            egress=cw_egress,
        )
        _failure = None
        logger.info("[clockwork] core %s loaded from %s (task types: %s)",
                    _core.version or "?", _core.location, sorted(catalogue()))
        return _core


def core_status() -> Dict[str, Any]:
    """``{"available": bool, "reason": str, "version": str, "location": str}``
    — stated, so a health screen can say WHY validation is off."""
    try:
        core = load_core()
    except CoreUnavailable as exc:
        return {"available": False, "reason": exc.reason, "version": "", "location": ""}
    return {"available": True, "reason": "", "version": core.version, "location": core.location}


def reset_for_tests() -> None:
    global _core, _failure
    with _lock:
        _core = None
        _failure = None


__all__ = ["Core", "CoreUnavailable", "CORE_PATH_ENV", "load_core", "core_status",
           "reset_for_tests"]
