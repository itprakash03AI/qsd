"""Query templates -- the authoring plane's spelling of the core's rules.

Plan v2 section 5, shape 2: an admin-authored, named, versioned SELECT a
job references by id, supplying bind values only.  Built on the authoring
side in the first pass (table, routes, validator, form field) and NOT on
the dispatcher's -- ``projection.py`` refused ``template_id`` outright --
so a template was a surface a person could author that nothing could run.
2026-09-10 (completion round): the dispatcher's ``sql_scalar`` runs one,
and the template's SQL travels INSIDE the projected definition as data
(the core cannot read QueryStudio's tables).

What lives here is the AUTHORING copy of the two rules the core applies
before the claim (``clockwork.tasks.sql_scalar.statement_problems`` and
``bind_names_of``), so that a template refused by the dispatcher is refused
at template CREATE and at job SAVE under the same words.  Pinned EQUAL to
the core's over a probe set by ``tests/test_clockwork_authored_but_
unrunnable_2026_09_10.py``; the core's copy is the authority.

Why a copy rather than an import: the template routes must answer when
the core package is not loadable (``core_bridge`` makes that a scoped
503, never a boot failure), and a rule that runs at CREATE cannot depend
on a package the deployment may not ship.  Two spellings pinned equal is
the seam's established pattern (masks, placeholders, the identifier
rules).
"""
from __future__ import annotations

import re
from typing import Any, Dict, List

#: The ONLY connection type a template can run on: the core's
#: ``sql_scalar`` requires ``oracle_sessions``, and its session provider
#: refuses any other connection kind BEFORE the claim.  Nine types were
#: accepted here until 2026-09-10 -- a Trino template saved 201 and would
#: have been refused on every tick.
TEMPLATE_CONNECTION_TYPES: tuple = ("oracle",)

TEMPLATE_NAME_RE = re.compile(r"[A-Za-z][A-Za-z0-9_\-]{0,99}")

# ── the core's statement rules, spelled once more (pinned equal) ─────────

_STRING_LITERAL_RE = re.compile(r"'(?:[^']|'')*'")
_BIND_TOKEN_RE = re.compile(r"(?<!:):([A-Za-z0-9_$#]+)")
_BIND_NAME_RE = re.compile(r"[A-Za-z][A-Za-z0-9_]{0,29}")
_STATEMENT_START_RE = re.compile(r"\s*(SELECT|WITH)\b", re.IGNORECASE)


def without_string_literals(sql: str) -> str:
    return _STRING_LITERAL_RE.sub("''", sql)


def bind_names_of(sql: str) -> List[str]:
    """Every ``:name`` the statement carries, once each, in order of first
    appearance, spelled as the SQL spells it (literals set aside)."""
    out: List[str] = []
    for name in _BIND_TOKEN_RE.findall(without_string_literals(sql)):
        if name not in out:
            out.append(name)
    return out


def statement_problems(sql: Any) -> List[str]:
    """Why this text is not a template statement the dispatcher will run;
    empty means it is.  The core's words, verbatim."""
    text = str(sql or "")
    if not text.strip():
        return ["template_sql is empty"]
    problems: List[str] = []
    if not _STATEMENT_START_RE.match(text):
        problems.append(
            "template_sql must be a single SELECT (or WITH ... SELECT) "
            "statement; it is the one shape a read-only pre-check takes")
    bare = without_string_literals(text)
    if ";" in bare:
        problems.append(
            "template_sql must be ONE statement: ';' is refused (a second "
            "statement would run under the pre-check's session)")
    if "--" in bare or "/*" in bare:
        problems.append(
            "template_sql may not carry a comment ('--' or '/*'): a comment "
            "can hide text from the statement checks, so it is refused "
            "rather than parsed")
    seen_folded: Dict[str, str] = {}
    for name in bind_names_of(text):
        if not _BIND_NAME_RE.fullmatch(name):
            problems.append(
                f"template_sql carries ':{name}', which is not a bind name "
                f"(letter-first, letters/digits/'_', <=30); Oracle would "
                f"refuse it at execute, so it is refused here")
            continue
        folded = name.upper()
        if folded in seen_folded and seen_folded[folded] != name:
            problems.append(
                f"template_sql spells one bind two ways (:{seen_folded[folded]} "
                f"and :{name}); Oracle folds them to ONE bind and the driver "
                f"would be handed two values for it")
        seen_folded.setdefault(folded, name)
    return problems


__all__ = ["TEMPLATE_CONNECTION_TYPES", "TEMPLATE_NAME_RE", "bind_names_of",
           "statement_problems", "without_string_literals"]
