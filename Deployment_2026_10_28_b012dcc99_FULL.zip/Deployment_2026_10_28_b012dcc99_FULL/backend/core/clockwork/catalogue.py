"""The task-type vocabulary the authoring plane validates against.

Plan v2 §2.  Six types, each with a parameter schema (rendered by the UI's
form) and DECLARED outputs (so a guard reference is checked at save, not
discovered at 02:00).

WHO OWNS THE DECLARATION.  The Clockwork task modules are the origin of
truth for what a type accepts and emits.  Each deployment writes its
verdict per registered type into ``clockwork_task_types`` at boot (plan
v2 §6), and that row carries the type's schema and outputs as the
DEPLOYMENT sees them — in the CORE's grammar (``proc_name``, ``binds``
with a ``placeholder`` key, ...).

TWO GRAMMARS, ONE SEAM (2026-09-10).  The editor and this validator are
built against the AUTHORING grammar (``procedure``, ``{PLACEHOLDER}`` in a
value, ...), and ``core/clockwork/projection.py`` TRANSLATES it into the
core's.  So for a type the projection translates, the reported schema must
NOT displace the built-in form: it would make every existing job fail
"unknown parameter 'procedure'" the moment a deployment first reported —
the exact failure this catalogue existed to prevent.  For those types the
built-in schema stays the form and the reported one is served beside it as
``dispatch_schema`` (what the executor sees).  For a type this image does
not know — a plugin only a deployment ships — the projection passes its
parameters through untouched, so the reported schema IS the form.

Routability is never assumed: a type is routable iff some live deployment
reported it so.  "No deployment has reported" is stated as the reason.

Routability is never assumed: a type is routable iff some live deployment
reported it so.  "No deployment has reported" is stated as the reason.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Iterable, List, Mapping, Optional

logger = logging.getLogger(__name__)

#: Bind types the Oracle procedure step accepts.  OPERATOR DECISION
#: (2026-09-10): every procedure parameter is VARCHAR2.  A date reaches
#: Oracle as TEXT, which is why the per-bind ``format`` mask is required
#: and has no default.
ORACLE_BIND_TYPES: tuple = ("VARCHAR2",)
#: An OUT bind is different (2026-09-10, completion round): its whole
#: purpose is to be COMPARED by a later guard, the core accepts ``NUMBER``
#: (``oracle_proc.OUT_BIND_TYPES``), and the "all VARCHAR2" decision was
#: about what a procedure RECEIVES.  Forcing VARCHAR2 on an OUT bind made a
#: numeric guard on one unauthorable from this plane.
ORACLE_OUT_BIND_TYPES: tuple = ("VARCHAR2", "NUMBER")
ORACLE_BIND_DIRECTIONS: tuple = ("IN", "OUT")

HTTP_METHODS: tuple = ("GET", "POST", "PUT", "PATCH", "DELETE")
#: The methods that carry a body (the core's ``http_request.BODY_METHODS``).
HTTP_BODY_METHODS: tuple = ("POST", "PUT", "PATCH")

#: EXACTLY the core's ``qs_api.ACTION_NAMES`` (pinned by test).  Three, not
#: four: ``run_maintenance`` named a route that restarts a daemon on that
#: pod behind ``require_admin`` -- authorable, never runnable -- and was
#: removed rather than widened (2026-09-10 completion round).
QS_API_ACTIONS: tuple = ("run_report", "start_feed", "launch_dataflow")
#: The core's ``qs_api._TARGET_RE``: a target id is placed in a URL path.
QS_API_TARGET_RE = r"[A-Za-z0-9_.\-]{1,200}"
#: The core's ``airflow_trigger._DAG_ID_RE``.
AIRFLOW_DAG_ID_RE = r"[A-Za-z0-9_.\-]{1,250}"

#: Comparison operators a guard clause may use (plan v2 §1).
GUARD_OPS: tuple = ("==", "!=", ">", ">=", "<", "<=")
#: The only operators meaningful on a BOOLEAN output (the core's
#: ``job_definition._BOOLEAN_OPS``); an order on true/false is refused.
GUARD_BOOLEAN_OPS: tuple = ("==", "!=")

#: The output-type vocabulary, EXACTLY the core's (``tasks._base.OUTPUT_TYPES``).
#: A guard compares a literal against an output and the core refuses a
#: cross-type comparison rather than coercing, so the authoring side must
#: know each output's type in the same words.  2026-09-10: the built-in
#: catalogue said ``scalar`` / ``VARCHAR2`` / ``integer`` / ``json`` -- four
#: spellings the core has never used -- and the validator compared nothing,
#: so ``value: "0"`` against a number output saved 201 and was refused at
#: enable (the sixth instance of the ``QS-Prod`` class).
OUT_NUMBER = "number"
OUT_TEXT = "text"
OUT_BOOLEAN = "boolean"
OUTPUT_TYPES: tuple = (OUT_NUMBER, OUT_TEXT, OUT_BOOLEAN)
#: The type word a dynamic declaration carries: the concrete type comes
#: from the step's own params (an OUT bind's ``type``, an expect entry's
#: ``type``), resolved by :func:`declared_output_types`.
OUT_DECLARED = "declared"


def output_type_of(value: Any) -> str:
    """Which vocabulary word a guard literal belongs to, or ``""``.  Mirrors
    the core's ``tasks._base.output_type_of``: ``bool`` is checked FIRST
    because a Python bool is an int."""
    if isinstance(value, bool):
        return OUT_BOOLEAN
    if isinstance(value, (int, float)):
        return OUT_NUMBER
    if isinstance(value, str):
        return OUT_TEXT
    return ""

#: Plan v2 §1: linear only, max 8 steps, refused at save.
MAX_STEPS = 8


def _out(name: str, typ: str, doc: str, dynamic: Optional[str] = None) -> Dict[str, Any]:
    return {"name": name, "type": typ, "doc": doc, "dynamic": dynamic}


BUILTIN_TASK_TYPES: Dict[str, Dict[str, Any]] = {
    "oracle_proc": {
        "doc": "Call an Oracle stored procedure with N named binds.  Every bind "
               "is VARCHAR2; a date placeholder is rendered through the bind's "
               "own format mask before it is sent as text.  Scalar OUT binds "
               "are this step's outputs, by bind name.",
        "config_schema": {
            "connection_id": {"type": "integer", "required": False,
                              "label": "Connection",
                              "help": "Oracle connection.  Defaults to the job's connection."},
            "procedure": {"type": "string", "required": True, "label": "Procedure",
                          "help": "PACKAGE.PROCEDURE or PROCEDURE.  No arguments here — they are the binds."},
            "binds": {"type": "oracle_binds", "required": True, "label": "Binds",
                      "help": "name / value / type (VARCHAR2) / direction (IN|OUT) / format "
                              "(required when the value carries a date placeholder)."},
        },
        "outputs": [_out("*", OUT_DECLARED, "every OUT bind, by its name: text for VARCHAR2, number "
                                            "for NUMBER (an OUT bind may declare either)",
                         dynamic="oracle_out_binds")],
    },
    "oracle_proc_cursor": {
        "doc": "Call an Oracle stored procedure that reports through a "
               "SYS_REFCURSOR OUT parameter.  The rows are fetched BEFORE the "
               "commit (a commit can empty a temp table the cursor selects "
               "from) and the status column decides the outcome; an EMPTY "
               "cursor is UNKNOWN, never success.",
        "config_schema": {
            "connection_id": {"type": "integer", "required": False,
                              "label": "Connection",
                              "help": "Oracle connection.  Defaults to the job's connection."},
            "procedure": {"type": "string", "required": True, "label": "Procedure",
                          "help": "PACKAGE.PROCEDURE or PROCEDURE.  No arguments here — they are the binds."},
            "binds": {"type": "oracle_binds", "required": True, "label": "Binds",
                      "help": "name / value / type (VARCHAR2) / direction (IN|OUT) / format "
                              "(required when the value carries a date placeholder)."},
            "cursor_param": {"type": "string", "required": True, "label": "Cursor parameter",
                             "help": "The FORMAL name of the SYS_REFCURSOR OUT parameter the "
                                     "procedure reports through."},
            "status_column": {"type": "string", "required": False, "label": "Status column",
                              "help": "Column in the cursor carrying the procedure's own verdict. "
                                      "An unrecognised word is UNKNOWN, never success."},
            "message_column": {"type": "string", "required": False, "label": "Message column",
                               "help": "Optional column carrying the procedure's explanation, "
                                       "recorded on the outcome."},
        },
        "outputs": [_out("*", OUT_DECLARED, "every scalar OUT bind, by its name: text for "
                                            "VARCHAR2, number for NUMBER",
                         dynamic="oracle_out_binds")],
    },
    "sql_scalar": {
        "doc": "A read returning exactly one row and one column holding a "
               "number, on an Oracle connection.  Either a declared query "
               "template (admin-authored; the job supplies bind values only) "
               "or a structured COUNT predicate.  Free SQL typed into a job "
               "is refused.",
        "config_schema": {
            "connection_id": {"type": "integer", "required": False, "label": "Connection"},
            "template_id": {"type": "template", "required": False, "label": "Query template",
                            "help": "A declared, versioned Oracle template (Admin -> Clockwork templates); "
                                    "its SQL travels to the dispatcher as data and the job supplies "
                                    "bind values only.  Exactly one of template or predicate."},
            "bind_values": {"type": "object", "required": False, "label": "Template binds",
                            "help": "One entry per :bind the template's SQL carries.  A {DATE_PLACEHOLDER} "
                                    "with no mask is bound as a real DATE; with a mask, as text under it."},
            "predicate": {"type": "predicate", "required": False, "label": "Count predicate",
                          "help": "table + AND-ed column comparisons, rendered as "
                                  "SELECT COUNT(*) ... WHERE col = :b0 with driver binds."},
        },
        "outputs": [_out("value", OUT_NUMBER, "the COUNT(*) the predicate returned")],
    },
    "http_request": {
        "doc": "One HTTP request carrying Idempotency-Key: <fire_key>.  "
               "Redirects are never followed; there is no retry loop.  5xx is "
               "UNKNOWN, 4xx is FAILED, a failure before the request left is "
               "FAILED, a failure after it left is UNKNOWN.",
        "config_schema": {
            "connection_id": {"type": "integer", "required": False, "label": "REST connection",
                              "help": "Supplies the bearer / client credentials.  Never put a "
                                      "credential in a header here."},
            "url": {"type": "string", "required": True, "label": "URL"},
            "method": {"type": "string", "required": True, "label": "Method",
                       "choices": list(HTTP_METHODS), "default": "POST"},
            "headers": {"type": "headers", "required": False, "label": "Headers"},
            "body": {"type": "json", "required": False, "label": "JSON body"},
            "expect_json_paths": {"type": "json_paths", "required": False,
                                  "label": "Outputs from the response",
                                  "help": "[{name, path}] — each becomes an output of this step."},
        },
        "outputs": [_out("status_code", OUT_NUMBER, "the HTTP status"),
                    _out("*", OUT_DECLARED, "each declared JSON path, by name, with the type the "
                                            "entry declares (number, text or boolean)",
                         dynamic="http_json_paths")],
    },
    # The two PASS-THROUGH types: the projection carries their params
    # untouched, so the built-in form's keys are EXACTLY the core's schema
    # names (pinned by test).  Until 2026-09-10 the airflow form demanded a
    # REST ``connection_id`` the core does not declare -- the remote is a
    # deployment property (``CLOCKWORK_REMOTE_AIRFLOW_*``, plan v2 section
    # 3.6) -- so every job authored on the built-in form was refused at
    # enable with "unknown key", and neither form offered ``timeout_seconds``.
    "airflow_trigger": {
        "doc": "http_request specialised for Airflow: dag_run_id = fire_key, so a "
               "409 Conflict is a positive 'already triggered'.  Where Airflow is, "
               "and who this pod is to it, are DEPLOYMENT properties "
               "(CLOCKWORK_REMOTE_AIRFLOW_BASE_URL / _AUTHORIZATION), not a "
               "connection on the job.",
        "config_schema": {
            "dag_id": {"type": "string", "required": True, "label": "DAG id",
                       "help": "POST /api/v1/dags/<dag_id>/dagRuns on the deployment's Airflow."},
            "conf": {"type": "json", "required": False, "label": "DAG conf",
                     "help": "Forwarded verbatim as the DagRun's conf; its keys are the DAG's."},
            "timeout_seconds": {"type": "integer", "required": False, "label": "Timeout (s)",
                                "default": 30,
                                "help": "Socket timeout.  A timeout during connect is FAILED; while "
                                        "reading the response it is UNKNOWN (Airflow may hold the run)."},
        },
        "outputs": [_out("run_id", OUT_TEXT, "the dag_run_id Airflow accepted")],
    },
    "qs_api": {
        "doc": "Calls QueryStudio's own API as the Clockwork pod (X-API-Key): run a "
               "report, start a feed, launch a dataflow.  Each route has its own "
               "opt-in gate for a service key; a 401/403 names the gate.",
        "config_schema": {
            "action": {"type": "string", "required": True, "label": "Action",
                       "choices": list(QS_API_ACTIONS)},
            "target_id": {"type": "string", "required": True, "label": "Target id",
                          "help": "The report id, the feed id or name, or the dataflow name."},
            "parameters": {"type": "json", "required": False, "label": "Parameters"},
            "timeout_seconds": {"type": "integer", "required": False, "label": "Timeout (s)",
                                "default": 30,
                                "help": "Socket timeout.  A timeout during connect is FAILED; while "
                                        "reading the response it is UNKNOWN (the run may exist)."},
        },
        "outputs": [_out("execution_id", OUT_TEXT, "the execution / run id QueryStudio returned")],
    },
    "journal": {
        "doc": "Records and reports SUCCESS.  Proves the seam.",
        "config_schema": {},
        # The core's journal declares ``scheduled_date`` (text).  This
        # catalogue said ``[]`` until 2026-09-10, so a guard on it -- which
        # the dispatcher accepts -- was refused at save.
        "outputs": [_out("scheduled_date", OUT_TEXT, "the occurrence's scheduled date, ISO")],
    },
}


def builtin_names() -> List[str]:
    return list(BUILTIN_TASK_TYPES.keys())


def declared_output_types(task_type: str, params: Mapping[str, Any],
                          decl: Optional[Mapping[str, Any]] = None) -> Dict[str, str]:
    """``{output name: type}`` for ONE step, in the core's vocabulary.

    Dynamic declarations are expanded from the step's own params: an
    ``oracle_proc`` exposes its OUT bind names (VARCHAR2 -> text, NUMBER ->
    number, as the core's ``oracle_proc.declared_outputs`` does), an
    ``http_request`` its declared JSON-path names with the ``type`` each
    entry declares.  An entry whose type is missing or not in
    :data:`OUTPUT_TYPES` maps to ``""`` -- "untyped" -- so the guard check
    can decline rather than invent; the HTTP validator refuses the entry
    itself.  Unknown task type -> no outputs (the validator has already
    refused the type).  A reported (deployment-only) type's outputs carry
    ``{name, type}`` in the same vocabulary.
    """
    decl = decl or BUILTIN_TASK_TYPES.get(task_type)
    if not decl:
        return {}
    types: Dict[str, str] = {}
    for o in decl.get("outputs", []):
        dyn = o.get("dynamic")
        if dyn == "oracle_out_binds":
            for b in (params.get("binds") or []):
                if isinstance(b, Mapping) and str(b.get("direction", "IN")).upper() == "OUT":
                    n = str(b.get("name", "") or "").strip()
                    if n:
                        types[n] = (OUT_NUMBER if str(b.get("type", "") or "").upper() == "NUMBER"
                                    else OUT_TEXT)
        elif dyn == "http_json_paths":
            for p in (params.get("expect_json_paths") or []):
                if isinstance(p, Mapping):
                    n = str(p.get("name", "") or "").strip()
                    if n:
                        t = p.get("type")
                        types[n] = t if t in OUTPUT_TYPES else ""
        elif dyn:
            continue
        else:
            t = o.get("type")
            types[str(o.get("name"))] = t if t in OUTPUT_TYPES else ""
    return types


def declared_outputs(task_type: str, params: Mapping[str, Any],
                     decl: Optional[Mapping[str, Any]] = None) -> List[str]:
    """The concrete output NAMES one step exposes to later guards -- the
    keys of :func:`declared_output_types`, in declaration order."""
    return list(declared_output_types(task_type, params, decl))


#: Types whose authoring parameters the projection TRANSLATES into the
#: core's grammar.  Their FORM is the built-in schema; a reported schema is
#: the executor's view and is served beside it.  Pinned equal to
#: ``projection._TRANSLATED_TYPES`` by test.
TRANSLATED_TYPES: tuple = ("journal", "oracle_proc", "oracle_proc_cursor",
                           "sql_scalar", "http_request")
#: Built-in types the projection passes through UNTOUCHED: the built-in
#: form's keys must be exactly the core's schema names, or a job authored
#: on the form is refused at enable with "unknown key".  Pinned by test.
PASSTHROUGH_TYPES: tuple = ("airflow_trigger", "qs_api")


def merged_catalogue(reported_rows: Iterable[Mapping[str, Any]],
                     deployments: Iterable[Mapping[str, Any]]) -> List[Dict[str, Any]]:
    """Built-in declarations + what live deployments reported.

    ``reported_rows`` are ``clockwork_task_types`` dicts
    (deployment_id, task_type, routable, reason, config_schema, outputs,
    reported_at).  ``deployments`` are ``clockwork_deployments`` dicts.
    A type reported by a deployment that is NOT in ``deployments`` still
    counts as reported — the row is the fact; liveness is shown beside it.
    """
    by_type: Dict[str, List[Mapping[str, Any]]] = {}
    for r in reported_rows or []:
        t = str(r.get("task_type") or "")
        if t:
            by_type.setdefault(t, []).append(r)

    names = list(BUILTIN_TASK_TYPES.keys())
    for t in by_type:
        if t not in names:
            names.append(t)          # a type this image does not know — still listed

    out: List[Dict[str, Any]] = []
    for name in names:
        builtin = BUILTIN_TASK_TYPES.get(name, {})
        rows = by_type.get(name, [])
        routable_rows = [r for r in rows if bool(r.get("routable"))]
        # Prefer the most recently reported routable row's declaration.
        chosen: Optional[Mapping[str, Any]] = None
        for r in sorted(rows, key=lambda x: str(x.get("reported_at") or ""), reverse=True):
            if r.get("config_schema") or r.get("outputs"):
                chosen = r
                break
        translated = name in TRANSLATED_TYPES
        if translated or not chosen:
            # The authoring FORM: the built-in schema for a type the
            # projection translates (or when nothing was reported).
            config_schema = builtin.get("config_schema", {})
            outputs = builtin.get("outputs", [])
        else:
            # A type only a deployment ships: its parameters pass through
            # the projection untouched, so the reported schema IS the form.
            config_schema = chosen.get("config_schema") or builtin.get("config_schema", {})
            outputs = chosen.get("outputs") or builtin.get("outputs", [])
        dispatch_schema = (chosen.get("config_schema") if chosen else None)
        dispatch_outputs = (chosen.get("outputs") if chosen else None)
        if routable_rows:
            reason = ""
        elif rows:
            reason = "; ".join(
                f"{r.get('deployment_id')}: {r.get('reason') or 'unroutable'}" for r in rows
            )
        else:
            reason = "no deployment has reported this type"
        out.append({
            "name": name,
            "doc": builtin.get("doc", "") or (chosen or {}).get("doc", "") or "",
            "config_schema": config_schema,
            "outputs": outputs,
            # What the EXECUTOR declared (the core's grammar), when a
            # deployment has reported: for display and for the UI agent,
            # never the form for a translated type.
            "dispatch_schema": dispatch_schema,
            "dispatch_outputs": dispatch_outputs,
            "reported_by": sorted({str(r.get("deployment_id")) for r in rows}),
            "routable": bool(routable_rows),
            "routable_reason": reason,
            "routable_deployments": sorted({str(r.get("deployment_id")) for r in routable_rows}),
            "known_to_this_image": name in BUILTIN_TASK_TYPES,
        })
    return out
