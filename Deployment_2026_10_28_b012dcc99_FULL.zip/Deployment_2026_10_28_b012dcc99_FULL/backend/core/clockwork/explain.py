"""'Why did this not run?' — plan v2 §7, the screen that earns the project.

Server-computed from the cron, joined to the fire log, the deployment
heartbeats, the alert rows and the job row, yielding EXACTLY ONE of:

  FIRED (status) · REFUSED (reason) · SKIPPED_MISSED (late by N, grace G)
  · DECLINED (authority X) · NOT_OBSERVED (no deployment with that
  authority has ticked since ...) · DISABLED (since version N, by whom)
  · CLAIMED (and still running)

Every state is backed by a ROW named in ``evidence``; nothing is inferred
from silence.  When the fire log itself cannot be read, that fact is in
the evidence and FIRED / CLAIMED / SKIPPED_MISSED cannot be claimed.

Pure over the inputs it is handed — the route gathers rows and the clock,
this module decides.  ``now`` is a parameter so a test can pin a verdict.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List, Mapping, Optional

from core.clockwork import placeholders as _ph

STATES = ("FIRED", "REFUSED", "SKIPPED_MISSED", "DECLINED", "NOT_OBSERVED", "DISABLED", "CLAIMED")


def _parse_dt(v: Any) -> Optional[datetime]:
    if v is None:
        return None
    if isinstance(v, datetime):
        return v if v.tzinfo else v.replace(tzinfo=timezone.utc)
    try:
        d = datetime.fromisoformat(str(v).replace("Z", "+00:00"))
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except ValueError:
        return None


def explain(job: Mapping[str, Any], *, now: datetime,
            fire_row: Optional[Mapping[str, Any]],
            fire_log_reason: str,
            deployments: List[Mapping[str, Any]],
            alerts: List[Mapping[str, Any]],
            expected_at: Optional[datetime] = None,
            expected_key: Optional[str] = None,
            expected_problem: str = "") -> Dict[str, Any]:
    """Compute the verdict for the most recent expected occurrence.

    ``expected_key`` is the fire key the route computed through the CORE;
    for a working-day schedule it carries the month anchor, not the due
    instant, so the key is never re-derived here from ``expected_at``.

    ``expected_problem`` is WHY the route could not compute an occurrence
    through the core, in the core's words (2026-09-15: a cron naming a day
    that does not exist).  With it the verdict is REFUSED carrying that
    reason; without it the cron-only fallback below is consulted, whose
    failure used to surface as a bare ``CroniterBadDateError``.

    ``fire_row`` is the fire-log row under the expected occurrence's key
    (None when absent or unreadable — ``fire_log_reason`` says which).
    ``deployments`` are ``clockwork_deployments`` dicts; ``alerts`` are
    unacknowledged alert dicts for this job.
    """
    cron = str(job.get("cron") or "")
    tz = str(job.get("timezone") or "UTC")
    tenant = str(job.get("tenant") or "querystudio")
    grace = int(job.get("misfire_grace_seconds") or 0)
    evidence: Dict[str, Any] = {"fire_log": fire_log_reason or "read"}

    if expected_at is None and expected_problem:
        evidence["cron_error"] = expected_problem
        evidence["job_row"] = {"id": job.get("id"), "cron": cron, "timezone": tz}
        return _verdict(job, now, None, "REFUSED", evidence)
    if expected_at is None:
        try:
            expected_at = _ph.most_recent_occurrence(cron, tz, now)
        except Exception as exc:                                  # noqa: BLE001
            evidence["cron_error"] = f"{type(exc).__name__}: {exc}"
            evidence["job_row"] = {"id": job.get("id"), "cron": cron, "timezone": tz}
            return _verdict(job, now, None, "REFUSED", evidence)
    if expected_key is None:
        expected_key = _ph.fire_key_for(tenant, job.get("id"), "-", expected_at)
    evidence["expected_fire_key"] = expected_key

    if not job.get("enabled"):
        evidence["job_row"] = {
            "id": job.get("id"), "enabled": False, "version": job.get("version"),
            "updated_by": job.get("updated_by"), "updated_at": job.get("updated_at"),
        }
        return _verdict(job, now, expected_at, "DISABLED", evidence)

    if fire_row:
        status = str(fire_row.get("status") or "").upper()
        evidence["fire_row"] = {
            "fire_key": fire_row.get("fire_key"), "status": status,
            "claimed_by": fire_row.get("claimed_by"), "claimed_at": fire_row.get("claimed_at"),
            "completed_at": fire_row.get("completed_at"), "detail": fire_row.get("detail"),
        }
        if status == "CLAIMED":
            return _verdict(job, now, expected_at, "CLAIMED", evidence)
        if status == "SKIPPED_MISSED":
            claimed = _parse_dt(fire_row.get("claimed_at"))
            late = (claimed - expected_at).total_seconds() if claimed else None
            evidence["late_by_seconds"] = late
            evidence["grace_seconds"] = grace
            return _verdict(job, now, expected_at, "SKIPPED_MISSED", evidence)
        if status in ("REFUSED",):
            return _verdict(job, now, expected_at, "REFUSED", evidence)
        return _verdict(job, now, expected_at, "FIRED", evidence)

    # No row.  An alert written since the occurrence is a recorded refusal.
    recent = [a for a in alerts
              if (_parse_dt(a.get("last_seen_at")) or now) >= expected_at]
    if recent:
        a = sorted(recent, key=lambda x: str(x.get("last_seen_at") or ""))[-1]
        evidence["alert_row"] = {"id": a.get("id"), "kind": a.get("kind"),
                                 "message": a.get("message"), "deployment_id": a.get("deployment_id"),
                                 "last_seen_at": a.get("last_seen_at"), "count": a.get("count")}
        return _verdict(job, now, expected_at, "REFUSED", evidence)

    authority = job.get("authority")
    if not authority:
        evidence["job_row"] = {"id": job.get("id"), "authority": None}
        evidence["reason"] = "authority is null — 'not mine' on every deployment; the row is refused and alerted"
        return _verdict(job, now, expected_at, "REFUSED", evidence)

    by_id = {str(d.get("deployment_id")): d for d in deployments}
    dep = by_id.get(str(authority))
    if dep is None:
        evidence["job_row"] = {"id": job.get("id"), "authority": authority}
        evidence["deployments"] = sorted(by_id)
        if by_id:
            evidence["reason"] = (f"authority {authority!r} matches no deployment that has ever reported; "
                                  f"every live deployment declines it")
            return _verdict(job, now, expected_at, "DECLINED", evidence)
        evidence["reason"] = "no deployment has ever reported to this database"
        return _verdict(job, now, expected_at, "NOT_OBSERVED", evidence)

    last_tick = _parse_dt(dep.get("last_tick_at"))
    evidence["deployment_row"] = {"deployment_id": dep.get("deployment_id"),
                                  "environment": dep.get("environment"),
                                  "last_tick_at": dep.get("last_tick_at")}
    if last_tick is None or last_tick < expected_at:
        evidence["reason"] = (f"deployment {authority!r} has not ticked since "
                              f"{last_tick.isoformat() if last_tick else 'ever'}; the occurrence "
                              f"at {expected_at.isoformat()} has not been observed")
        return _verdict(job, now, expected_at, "NOT_OBSERVED", evidence)

    within_grace = (now - expected_at).total_seconds() <= grace
    evidence["within_grace"] = within_grace
    evidence["reason"] = (
        "the deployment has ticked since the occurrence and is within grace; the next tick should claim it"
        if within_grace else
        "the deployment ticked after the occurrence and wrote NO row for it — neither a claim, a skip "
        "nor an alert.  That is unaccounted for and should be raised with the Clockwork operator"
    )
    return _verdict(job, now, expected_at, "NOT_OBSERVED", evidence)


def _verdict(job: Mapping[str, Any], now: datetime, expected_at: Optional[datetime],
             state: str, evidence: Dict[str, Any]) -> Dict[str, Any]:
    assert state in STATES
    return {
        "job_id": job.get("id"),
        "job_name": job.get("name"),
        "computed_at": now.astimezone(timezone.utc).isoformat(),
        "expected_at": expected_at.astimezone(timezone.utc).isoformat() if expected_at else None,
        "state": state,
        "evidence": evidence,
    }


__all__ = ["explain", "STATES"]
