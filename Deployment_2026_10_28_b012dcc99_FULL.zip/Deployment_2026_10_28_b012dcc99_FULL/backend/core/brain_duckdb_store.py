"""Brain DuckDB store — Phase 160 (2026-07-01).

Purpose
-------
The pruning brain reads three flavours of metadata on the query hot
path today, and every read hits the primary transactional DB:

  * per-file min/max column bounds (``iceberg_col_stats_supplement``)
  * per-snapshot manifest cache (avro bytes, file count, partition
    summary)
  * per-table hot / column-usage aggregates (derived from
    ``query_pruning_history`` and ``query_executions``)

At 10K queries/day these lookups are the second-biggest cost after
S3 IO.  Primary DB is a row-store optimised for transactional writes
— it is not the right substrate for repeated columnar / analytical
reads keyed by (bucket, prefix, snapshot_id).

This module builds a **columnar, disk-resident, brain-only DuckDB
store** that sits in front of the primary DB.  Multiple DuckDB tables
inside one file:

  * ``col_stats``                — per-file column bounds mirror
  * ``manifest_summary``         — per-snapshot summary (file_count,
                                    total_bytes, partition_summary_json)
  * ``snapshot_pointer``         — current snapshot per (bucket, prefix)
  * ``hot_tables``               — 7-day / 24-hour query counts
  * ``hot_columns``              — 7-day column-usage counts
  * ``mirror_state``             — daemon self-diagnosis
  * ``_meta``                    — schema version + last-writer-id

Multi-writer safety
-------------------
DuckDB files can be opened by ONE writer at a time.  Every reader
opens read-only (N concurrent readers OK, no locks).  The single
writer is the mirror daemon (see :mod:`core.brain_duckdb_mirror`)
which runs on the scheduler pod (or wherever the pod acquires the
``SchedulerLease``).  This mirrors the QS ``iceberg_manifest_watcher``
model — one writer, N readers, coordinated via lease.

Fail-open contract
------------------
Every public method is **fail-open**: if the store is disabled, the
file is missing, the schema is stale, the read raises — the method
returns an EMPTY answer + logs debug.  Callers then fall through to
their existing primary-DB path.  The store must never break a query.

Read-through pattern
--------------------
Callers should consult the store first, then the primary DB on
miss.  This module ships the store; the wire-in helper
:func:`get_col_stats_for_snapshot_via_store` demonstrates the
canonical read-through with brain_trace instrumentation.  Other
callers migrate incrementally — the primary-DB API is preserved.

Config
------
Reads ``brain_store.enabled`` + ``brain_store.path`` from
``core.config``.  Defaults (see ``_DEFAULTS`` in ``core/config.py``):
  * enabled:         True   (Phase 160 brain-defaults-ON per operator
                             directive)
  * path:            derived from ``paths.data_dir`` — override with
                     ``QS_BRAIN_STORE_DIR`` env or config.json
"""
from __future__ import annotations

import logging
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple


logger = logging.getLogger(__name__)


# Schema version — bump when the table shape changes.  On mismatch
# the writer rebuilds the store from scratch; readers see an empty
# result and fall through to the primary DB.
#
# History:
#   v1 (2026-07-01, Phase 160 base) — 7 tables listed below
#   v2 (2026-07-01, Slice 3)        — added mirror_opt_in
_SCHEMA_VERSION = 2


# Canonical table names — locked here so the CI contract test can
# guarantee no site invents a parallel table.
STORE_TABLES = (
    "_meta",
    "col_stats",
    "manifest_summary",
    "snapshot_pointer",
    "hot_tables",
    "hot_columns",
    "mirror_state",
    "mirror_opt_in",
)


# ── config helpers ────────────────────────────────────────────────────────


def _config_enabled() -> bool:
    """Read ``brain_store.enabled`` with a safe True default.

    Fail-safe: any config lookup error returns True.  The individual
    methods are already fail-open on missing file / open error, so a
    True default here just means "attempt the store".  Operators
    who explicitly want the store off can set
    ``brain_store.enabled=false`` in config.json.
    """
    # Env override — for smoke-tests / kill-switch
    _env = (os.environ.get("QS_BRAIN_STORE_ENABLED") or "").strip().lower()
    if _env in ("false", "0", "no", "off"):
        return False
    if _env in ("true", "1", "yes", "on"):
        return True
    try:
        from core import config as _cfg
        # Prefer the typed accessor once it exists
        _bs = getattr(_cfg, "brain_store", None)
        if _bs is not None and hasattr(_bs, "enabled"):
            return bool(_bs.enabled)
        # Fall back to raw get() for early-import ordering safety
        return bool(_cfg.get("brain_store", "enabled", True))
    except Exception:
        return True


def _config_path() -> Path:
    """Resolve the store file path.

    Priority: ``QS_BRAIN_STORE_DIR`` env  >  ``brain_store.dir`` config
    >  ``<paths.data_dir>/brain_store``.
    The file itself is always ``brain_store.duckdb`` inside that dir.
    """
    dir_env = (os.environ.get("QS_BRAIN_STORE_DIR") or "").strip()
    dir_cfg: str = ""
    try:
        from core import config as _cfg
        dir_cfg = str(_cfg.get("brain_store", "dir", "") or "").strip()
    except Exception as _cfg_exc:                                     # pragma: no cover
        # 2026-07-02 -- config module not importable OR key missing.
        # Fall through to env / default path; debug-log so bad
        # config keys are greppable during ops investigations.
        logger.debug(
            "brain_store: config.get('brain_store', 'dir') raised "
            "%s: %s -- falling back to env / default path",
            type(_cfg_exc).__name__, _cfg_exc,
        )
    if dir_env:
        base = Path(dir_env)
    elif dir_cfg:
        base = Path(dir_cfg)
    else:
        try:
            from core import config as _cfg
            base = Path(str(_cfg.paths.data_dir)) / "brain_store"
        except Exception:
            base = Path.cwd() / "brain_store"
    return base / "brain_store.duckdb"


# ── schema DDL ────────────────────────────────────────────────────────────


_DDL = {
    "_meta": """
        CREATE TABLE IF NOT EXISTS _meta (
            schema_version    INTEGER      NOT NULL,
            created_at        TIMESTAMP    NOT NULL,
            last_writer_id    VARCHAR      NOT NULL,
            last_writer_at    TIMESTAMP    NOT NULL
        );
    """,
    "col_stats": """
        CREATE TABLE IF NOT EXISTS col_stats (
            bucket            VARCHAR      NOT NULL,
            table_prefix      VARCHAR      NOT NULL,
            format            VARCHAR      NOT NULL,
            snapshot_id       VARCHAR      NOT NULL,
            file_path         VARCHAR      NOT NULL,
            column_name       VARCHAR      NOT NULL,
            column_name_lower VARCHAR      NOT NULL,
            lower_bound       VARCHAR,
            upper_bound       VARCHAR,
            -- DATA-LOSS FIX (2026-07-17): NULLABLE.  NULL = writer never
            -- recorded a null count (UNKNOWN); a concrete 0 = provably zero
            -- nulls.  A NOT NULL DEFAULT 0 would collapse UNKNOWN into 0 and
            -- let IS NULL pruning drop a file that actually holds null rows.
            null_count        BIGINT,
            row_count         BIGINT       NOT NULL DEFAULT 0,
            scanned_at        TIMESTAMP    NOT NULL,
            PRIMARY KEY (bucket, table_prefix, format, file_path,
                         column_name_lower)
        );
    """,
    "manifest_summary": """
        CREATE TABLE IF NOT EXISTS manifest_summary (
            bucket                 VARCHAR   NOT NULL,
            table_prefix           VARCHAR   NOT NULL,
            snapshot_id            VARCHAR   NOT NULL,
            file_count             BIGINT    NOT NULL DEFAULT 0,
            total_bytes            BIGINT    NOT NULL DEFAULT 0,
            partition_summary_json VARCHAR,
            built_at               TIMESTAMP NOT NULL,
            PRIMARY KEY (bucket, table_prefix, snapshot_id)
        );
    """,
    "snapshot_pointer": """
        CREATE TABLE IF NOT EXISTS snapshot_pointer (
            bucket              VARCHAR   NOT NULL,
            table_prefix        VARCHAR   NOT NULL,
            current_snapshot_id VARCHAR   NOT NULL,
            metadata_key        VARCHAR,
            updated_at          TIMESTAMP NOT NULL,
            PRIMARY KEY (bucket, table_prefix)
        );
    """,
    "hot_tables": """
        CREATE TABLE IF NOT EXISTS hot_tables (
            bucket           VARCHAR   NOT NULL,
            table_prefix     VARCHAR   NOT NULL,
            queries_7d       BIGINT    NOT NULL DEFAULT 0,
            queries_24h      BIGINT    NOT NULL DEFAULT 0,
            avg_seconds_7d   DOUBLE    NOT NULL DEFAULT 0.0,
            last_query_at    TIMESTAMP,
            updated_at       TIMESTAMP NOT NULL,
            PRIMARY KEY (bucket, table_prefix)
        );
    """,
    "hot_columns": """
        CREATE TABLE IF NOT EXISTS hot_columns (
            bucket            VARCHAR   NOT NULL,
            table_prefix      VARCHAR   NOT NULL,
            column_name       VARCHAR   NOT NULL,
            column_name_lower VARCHAR   NOT NULL,
            usage_count_7d    BIGINT    NOT NULL DEFAULT 0,
            last_used_at      TIMESTAMP,
            updated_at        TIMESTAMP NOT NULL,
            PRIMARY KEY (bucket, table_prefix, column_name_lower)
        );
    """,
    "mirror_state": """
        CREATE TABLE IF NOT EXISTS mirror_state (
            component            VARCHAR   NOT NULL PRIMARY KEY,
            last_run_at          TIMESTAMP,
            last_success_at      TIMESTAMP,
            rows_upserted_total  BIGINT    NOT NULL DEFAULT 0,
            last_error           VARCHAR
        );
    """,
    # Phase 160 Slice 3 (2026-07-01) — persistent operator opt-in
    # state for mirror candidates.  Phase 2 advisor ranks tables;
    # this table stores which ones the admin explicitly opted in.
    # Phase 3 executor (when built) reads THIS table to decide what
    # to build, NOT the advisor's ranked list.  Separation-of-
    # concerns: advisor recommends, opt-in decides, executor acts.
    "mirror_opt_in": """
        CREATE TABLE IF NOT EXISTS mirror_opt_in (
            bucket           VARCHAR   NOT NULL,
            table_prefix     VARCHAR   NOT NULL,
            enabled          BOOLEAN   NOT NULL DEFAULT TRUE,
            opted_in_by      VARCHAR,
            opted_in_at      TIMESTAMP NOT NULL,
            note             VARCHAR,
            PRIMARY KEY (bucket, table_prefix)
        );
    """,
}


# ── BrainDuckDBStore ─────────────────────────────────────────────────────


class BrainDuckDBStore:
    """DuckDB-backed brain metadata store.

    ONE instance per pod, held by :func:`get_store`.  Do NOT construct
    directly except in tests.

    Read methods open a read-only connection per call (cheap in
    DuckDB).  Write methods route through :meth:`writer` which
    acquires an inter-thread lock and requires the caller to be the
    designated writer for the process (see ``brain_duckdb_mirror``).
    """

    def __init__(self, *, path: Optional[Path] = None,
                 writer_id: Optional[str] = None) -> None:
        self._path: Path = Path(path) if path is not None else _config_path()
        # ``writer_id`` tags rows written by this instance in
        # ``_meta.last_writer_id`` for cross-pod diagnosis.
        self._writer_id: str = writer_id or f"pod-{os.getpid()}"
        self._writer_lock = threading.Lock()
        # Cached "store is initialised" flag — set once we've verified
        # or created the schema.  Any error resets to False so the
        # next call retries.
        self._schema_ready = False
        self._schema_lock = threading.Lock()

    # ── path & lifecycle ────────────────────────────────────────────────

    @property
    def path(self) -> Path:
        return self._path

    def is_available(self) -> bool:
        """True if the store file exists and can be opened read-only.

        Used by readers to short-circuit BEFORE calling get_* — avoids
        the DuckDB import cost when the file is missing.
        """
        if not _config_enabled():
            return False
        try:
            return self._path.exists() and self._path.stat().st_size > 0
        except Exception:
            return False

    # ── schema ──────────────────────────────────────────────────────────

    def ensure_schema(self) -> bool:
        """Create tables if missing; recreate on schema-version mismatch.

        Must be called by the WRITER on daemon startup.  Readers must
        never call this — they should see the schema built by the
        writer.  Returns True on success, False on any failure
        (fail-open — caller falls back to primary DB).
        """
        if not _config_enabled():
            return False
        with self._schema_lock:
            if self._schema_ready:
                return True
            try:
                self._path.parent.mkdir(parents=True, exist_ok=True)
            except Exception as exc:
                logger.warning("brain_store: mkdir failed at %s: %s",
                               self._path.parent, exc)
                return False
            try:
                import duckdb                                   # noqa: F401
            except Exception as exc:                            # pragma: no cover
                logger.warning("brain_store: duckdb not importable: %s", exc)
                return False
            try:
                with self._open_writer() as con:
                    self._apply_ddl(con)
                    self._verify_or_reset_version(con)
                self._schema_ready = True
                return True
            except Exception as exc:
                logger.warning("brain_store: ensure_schema failed: %s", exc)
                return False

    def _apply_ddl(self, con: Any) -> None:
        """Idempotent CREATE TABLE IF NOT EXISTS for every canonical
        table.  Safe to run on every writer startup."""
        for tbl in STORE_TABLES:
            con.execute(_DDL[tbl])

    def _verify_or_reset_version(self, con: Any) -> None:
        """If ``_meta`` shows an older schema version, drop + recreate
        every non-``_meta`` table.  The mirror will refill on the next
        tick.  Never drops ``_meta`` itself so ``created_at`` survives
        across schema upgrades."""
        row = con.execute("SELECT schema_version FROM _meta LIMIT 1").fetchone()
        now = datetime.now(timezone.utc)
        if row is None:
            con.execute(
                "INSERT INTO _meta VALUES (?, ?, ?, ?)",
                [_SCHEMA_VERSION, now, self._writer_id, now],
            )
            return
        version = int(row[0])
        if version == _SCHEMA_VERSION:
            con.execute(
                "UPDATE _meta SET last_writer_id = ?, last_writer_at = ?",
                [self._writer_id, now],
            )
            return
        logger.info(
            "brain_store: schema version %d != current %d — dropping tables",
            version, _SCHEMA_VERSION,
        )
        for tbl in STORE_TABLES:
            if tbl == "_meta":
                continue
            try:
                con.execute(f"DROP TABLE IF EXISTS {tbl}")
            except Exception as exc:
                logger.warning("brain_store: drop %s failed: %s", tbl, exc)
        self._apply_ddl(con)
        con.execute(
            "UPDATE _meta SET schema_version = ?, last_writer_id = ?, "
            "last_writer_at = ?",
            [_SCHEMA_VERSION, self._writer_id, now],
        )

    # ── connection helpers ──────────────────────────────────────────────

    def _open_reader(self) -> "_ReaderCtx":
        """Open a read-only DuckDB connection wrapped in a context
        manager that closes on exit (silently, with debug-level
        logging on any close failure).  Multiple readers can coexist.

        2026-07-02 strategic refactor -- was ``def _open_reader() ->
        Any`` which returned a bare connection and forced every
        caller to write ``con=None ... try/finally: try:
        con.close() except: pass`` boilerplate (9 sites).  The
        context-manager form matches the shape of ``_open_writer``
        + eliminates 9 silent-pass sites in one move.
        """
        return _ReaderCtx(self._path)

    def _open_writer(self) -> "_WriterCtx":
        """Open a writer connection guarded by the process-local
        writer lock.  Returns a context manager that closes the
        connection on exit."""
        return _WriterCtx(self._path, self._writer_lock)

    # ── READ API ────────────────────────────────────────────────────────

    def get_col_stats_for_snapshot(
        self,
        bucket: str,
        table_prefix: str,
        snapshot_id: str,
        column_names: List[str],
        file_paths: Optional[List[str]] = None,
        format: str = "iceberg",
    ) -> Dict[str, Dict[str, Tuple[Optional[str], Optional[str], int, int]]]:
        """Same shape as
        :meth:`DatabaseManager.iceberg_col_stats_get_for_snapshot`.

        Returns ``{}`` on any error / missing file / missing rows —
        caller falls back to the primary DB.  ``snapshot_id`` is
        ADVISORY (matches BF-370 semantics — column stats are content-
        addressable, not snapshot-scoped).

        Case-insensitive column matching (BF-374 parity).
        """
        if not self.is_available() or not column_names:
            return {}
        cols_lower = [str(c).lower() for c in column_names if c]
        if not cols_lower:
            return {}
        _ = snapshot_id  # advisory only, mirrors DB API
        try:
            with self._open_reader() as con:
                base_sql = (
                    "SELECT file_path, column_name_lower, lower_bound, "
                    "upper_bound, null_count, row_count "
                    "FROM col_stats WHERE bucket = ? AND table_prefix = ? "
                    "AND format = ? AND column_name_lower IN "
                    f"({','.join('?' * len(cols_lower))})"
                )
                params: List[Any] = [bucket, table_prefix, format, *cols_lower]

                out: Dict[str, Dict[str, Tuple[Optional[str], Optional[str], int, int]]] = {}
                if file_paths:
                    # Chunk to keep the IN-list bounded.  DuckDB handles
                    # 10k+ but limiting is polite to memory + planner.
                    CHUNK = 800
                    files_list = [f for f in file_paths if f]
                    for start in range(0, len(files_list), CHUNK):
                        chunk = files_list[start:start + CHUNK]
                        sql = base_sql + f" AND file_path IN ({','.join('?' * len(chunk))})"
                        rows = con.execute(sql, params + chunk).fetchall()
                        for r in rows:
                            (fp, col_lower, lo, up, nc, rc) = r
                            out.setdefault(fp, {})[col_lower] = (
                                lo, up, (None if nc is None else int(nc)), int(rc or 0),
                            )
                else:
                    rows = con.execute(base_sql, params).fetchall()
                    for r in rows:
                        (fp, col_lower, lo, up, nc, rc) = r
                        out.setdefault(fp, {})[col_lower] = (
                            lo, up, (None if nc is None else int(nc)), int(rc or 0),
                        )
                return out
        except Exception as exc:
            logger.debug("brain_store: get_col_stats failed: %s", exc)
            return {}

    def get_manifest_summary(
        self,
        bucket: str,
        table_prefix: str,
        snapshot_id: str,
    ) -> Optional[Dict[str, Any]]:
        """Return a manifest summary row or None on miss.

        Shape: ``{"file_count": int, "total_bytes": int,
        "partition_summary_json": str | None, "built_at": iso}``.
        """
        if not self.is_available():
            return None
        try:
            with self._open_reader() as con:
                row = con.execute(
                    "SELECT file_count, total_bytes, partition_summary_json, built_at "
                    "FROM manifest_summary WHERE bucket = ? AND table_prefix = ? "
                    "AND snapshot_id = ? LIMIT 1",
                    [bucket, table_prefix, str(snapshot_id)],
                ).fetchone()
                if row is None:
                    return None
                file_count, total_bytes, partition_json, built_at = row
                return {
                    "file_count":            int(file_count or 0),
                    "total_bytes":           int(total_bytes or 0),
                    "partition_summary_json": partition_json,
                    "built_at":              built_at.isoformat() if built_at else None,
                }
        except Exception as exc:
            logger.debug("brain_store: get_manifest_summary failed: %s", exc)
            return None

    def get_snapshot_pointer(
        self, bucket: str, table_prefix: str,
    ) -> Optional[Dict[str, Any]]:
        """Return current snapshot pointer or None on miss.

        Shape: ``{"current_snapshot_id": str, "metadata_key": str|None,
        "updated_at": iso}``.
        """
        if not self.is_available():
            return None
        try:
            with self._open_reader() as con:
                row = con.execute(
                    "SELECT current_snapshot_id, metadata_key, updated_at "
                    "FROM snapshot_pointer WHERE bucket = ? AND table_prefix = ? "
                    "LIMIT 1",
                    [bucket, table_prefix],
                ).fetchone()
                if row is None:
                    return None
                snap, key, updated_at = row
                return {
                    "current_snapshot_id": snap,
                    "metadata_key":        key,
                    "updated_at":          updated_at.isoformat() if updated_at else None,
                }
        except Exception as exc:
            logger.debug("brain_store: get_snapshot_pointer failed: %s", exc)
            return None

    def get_hot_tables(self, top_k: int = 20) -> List[Dict[str, Any]]:
        """Return the top-K hottest tables by 7-day query count.

        Consumed by :mod:`core.query_history_prefetcher` +
        Phase 2 mirror-advisor UI.  Empty list on any error.
        """
        if not self.is_available() or top_k <= 0:
            return []
        try:
            with self._open_reader() as con:
                rows = con.execute(
                    "SELECT bucket, table_prefix, queries_7d, queries_24h, "
                    "avg_seconds_7d, last_query_at, updated_at "
                    "FROM hot_tables ORDER BY queries_7d DESC LIMIT ?",
                    [int(top_k)],
                ).fetchall()
                out = []
                for r in rows:
                    (bucket, prefix, q7, q24, avg_s, last_q, updated) = r
                    out.append({
                        "bucket":         bucket,
                        "table_prefix":   prefix,
                        "queries_7d":     int(q7 or 0),
                        "queries_24h":    int(q24 or 0),
                        "avg_seconds_7d": float(avg_s or 0.0),
                        "last_query_at":  last_q.isoformat() if last_q else None,
                        "updated_at":     updated.isoformat() if updated else None,
                    })
                return out
        except Exception as exc:
            logger.debug("brain_store: get_hot_tables failed: %s", exc)
            return []

    def get_hot_columns_for(
        self, bucket: str, table_prefix: str, top_k: int = 10,
    ) -> List[Dict[str, Any]]:
        """Return the top-K most-used predicate columns for a table.

        Feeds the adaptive-sort choice in the future Phase 3 mirror
        builder (ORDER BY hot_columns before writing consolidated
        parquet).  Empty list on any error.
        """
        if not self.is_available() or top_k <= 0:
            return []
        try:
            with self._open_reader() as con:
                rows = con.execute(
                    "SELECT column_name, usage_count_7d, last_used_at "
                    "FROM hot_columns WHERE bucket = ? AND table_prefix = ? "
                    "ORDER BY usage_count_7d DESC LIMIT ?",
                    [bucket, table_prefix, int(top_k)],
                ).fetchall()
                out = []
                for r in rows:
                    (name, cnt, last_used) = r
                    out.append({
                        "column_name":    name,
                        "usage_count_7d": int(cnt or 0),
                        "last_used_at":   last_used.isoformat() if last_used else None,
                    })
                return out
        except Exception as exc:
            logger.debug("brain_store: get_hot_columns_for failed: %s", exc)
            return []

    def get_mirror_opt_in(
        self, bucket: str, table_prefix: str,
    ) -> Optional[Dict[str, Any]]:
        """Return the opt-in record for one (bucket, prefix) or None.

        Shape: ``{"enabled": bool, "opted_in_by": str, "opted_in_at":
        iso, "note": str|None}``.
        """
        if not self.is_available():
            return None
        try:
            with self._open_reader() as con:
                row = con.execute(
                    "SELECT enabled, opted_in_by, opted_in_at, note "
                    "FROM mirror_opt_in WHERE bucket = ? AND table_prefix = ? "
                    "LIMIT 1",
                    [bucket, table_prefix],
                ).fetchone()
                if row is None:
                    return None
                enabled, by, at, note = row
                return {
                    "enabled":     bool(enabled),
                    "opted_in_by": by,
                    "opted_in_at": at.isoformat() if at else None,
                    "note":        note,
                }
        except Exception as exc:
            logger.debug("brain_store: get_mirror_opt_in failed: %s", exc)
            return None

    def list_mirror_opt_in(
        self, *, enabled_only: bool = True,
    ) -> List[Dict[str, Any]]:
        """List every opted-in mirror table.

        When ``enabled_only=True`` (default), only rows with
        enabled=TRUE come back — Phase 3 executor consumes this
        directly.  Set False to include disabled rows for admin
        audit views.
        """
        if not self.is_available():
            return []
        try:
            with self._open_reader() as con:
                sql = (
                    "SELECT bucket, table_prefix, enabled, opted_in_by, "
                    "opted_in_at, note FROM mirror_opt_in"
                )
                if enabled_only:
                    sql += " WHERE enabled = TRUE"
                sql += " ORDER BY opted_in_at DESC"
                rows = con.execute(sql).fetchall()
                out = []
                for r in rows:
                    bucket, prefix, enabled, by, at, note = r
                    out.append({
                        "bucket":       bucket,
                        "table_prefix": prefix,
                        "enabled":      bool(enabled),
                        "opted_in_by":  by,
                        "opted_in_at":  at.isoformat() if at else None,
                        "note":         note,
                    })
                return out
        except Exception as exc:
            logger.debug("brain_store: list_mirror_opt_in failed: %s", exc)
            return []

    def set_mirror_opt_in(
        self,
        *,
        bucket: str,
        table_prefix: str,
        enabled: bool,
        opted_in_by: str = "",
        note: Optional[str] = None,
    ) -> bool:
        """Insert or update an opt-in row.  Returns True on success.

        Idempotent — calling with ``enabled=False`` on an existing row
        flips it off (Phase 3 executor will drain and stop
        mirroring); calling again with ``enabled=True`` re-enables.
        """
        if not _config_enabled() or not self.ensure_schema():
            return False
        if not (bucket and table_prefix):
            return False
        try:
            with self._open_writer() as con:
                con.execute(
                    "INSERT OR REPLACE INTO mirror_opt_in VALUES "
                    "(?, ?, ?, ?, ?, ?)",
                    [
                        bucket, table_prefix,
                        bool(enabled),
                        str(opted_in_by or ""),
                        datetime.now(timezone.utc),
                        note,
                    ],
                )
            return True
        except Exception as exc:
            logger.warning("brain_store: set_mirror_opt_in failed: %s", exc)
            return False

    def get_mirror_state(self, component: str) -> Optional[Dict[str, Any]]:
        """Return diagnostic state for a mirror component or None."""
        if not self.is_available():
            return None
        try:
            with self._open_reader() as con:
                row = con.execute(
                    "SELECT last_run_at, last_success_at, rows_upserted_total, "
                    "last_error FROM mirror_state WHERE component = ? LIMIT 1",
                    [component],
                ).fetchone()
                if row is None:
                    return None
                last_run, last_ok, upserted, err = row
                return {
                    "component":            component,
                    "last_run_at":          last_run.isoformat() if last_run else None,
                    "last_success_at":      last_ok.isoformat() if last_ok else None,
                    "rows_upserted_total":  int(upserted or 0),
                    "last_error":           err,
                }
        except Exception as exc:
            logger.debug("brain_store: get_mirror_state failed: %s", exc)
            return None

    # ── WRITE API (writer-only; mirror daemon consumes) ─────────────────

    def upsert_col_stats(self, records: Iterable[Dict[str, Any]]) -> int:
        """Bulk upsert col_stats rows.  Same record shape as
        :meth:`DatabaseManager.iceberg_col_stats_upsert_batch`.

        Returns number of rows written.  Fail-open: any error logs +
        returns 0; caller (mirror daemon) records the error in
        ``mirror_state.last_error``.
        """
        if not _config_enabled():
            return 0
        if not self.ensure_schema():
            return 0
        rows = list(records)
        if not rows:
            return 0
        now = datetime.now(timezone.utc)
        payload = []
        seen: Dict[Tuple[str, str, str, str, str], Dict[str, Any]] = {}
        for r in rows:
            bucket = str(r.get("bucket") or "")
            prefix = str(r.get("table_prefix") or "")
            fmt    = str(r.get("format") or "iceberg")
            fp     = str(r.get("file_path") or "")
            name   = str(r.get("column_name") or "")
            if not (bucket and prefix and fp and name):
                continue
            key = (bucket, prefix, fmt, fp, name.lower())
            # Last-write-wins within one batch — dedup before upsert
            # since PRIMARY KEY collision would otherwise fail on the
            # second INSERT of the same key inside a transaction.
            seen[key] = r
        for key, r in seen.items():
            bucket, prefix, fmt, fp, name_lower = key
            payload.append((
                bucket, prefix, fmt,
                str(r.get("snapshot_id") or ""),
                fp,
                str(r.get("column_name") or ""),
                name_lower,
                r.get("lower_bound"),
                r.get("upper_bound"),
                # Preserve UNKNOWN (None) — do not coerce to 0.
                (None if r.get("null_count") is None
                 else int(r.get("null_count"))),
                int(r.get("row_count") or 0),
                now,
            ))
        if not payload:
            return 0
        try:
            with self._open_writer() as con:
                con.executemany(
                    "INSERT OR REPLACE INTO col_stats VALUES "
                    "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    payload,
                )
            return len(payload)
        except Exception as exc:
            logger.warning("brain_store: upsert_col_stats failed: %s", exc)
            return 0

    def upsert_manifest_summary(
        self,
        *,
        bucket: str,
        table_prefix: str,
        snapshot_id: str,
        file_count: int,
        total_bytes: int,
        partition_summary_json: Optional[str] = None,
    ) -> bool:
        """Upsert one manifest-summary row.  Returns True on success."""
        if not _config_enabled() or not self.ensure_schema():
            return False
        try:
            with self._open_writer() as con:
                con.execute(
                    "INSERT OR REPLACE INTO manifest_summary VALUES "
                    "(?, ?, ?, ?, ?, ?, ?)",
                    [
                        bucket, table_prefix, str(snapshot_id),
                        int(file_count or 0), int(total_bytes or 0),
                        partition_summary_json,
                        datetime.now(timezone.utc),
                    ],
                )
            return True
        except Exception as exc:
            logger.warning("brain_store: upsert_manifest_summary failed: %s", exc)
            return False

    def upsert_snapshot_pointer(
        self,
        *,
        bucket: str,
        table_prefix: str,
        current_snapshot_id: str,
        metadata_key: Optional[str] = None,
    ) -> bool:
        if not _config_enabled() or not self.ensure_schema():
            return False
        try:
            with self._open_writer() as con:
                con.execute(
                    "INSERT OR REPLACE INTO snapshot_pointer VALUES "
                    "(?, ?, ?, ?, ?)",
                    [
                        bucket, table_prefix,
                        str(current_snapshot_id),
                        metadata_key,
                        datetime.now(timezone.utc),
                    ],
                )
            return True
        except Exception as exc:
            logger.warning("brain_store: upsert_snapshot_pointer failed: %s", exc)
            return False

    def upsert_hot_tables(self, rows: Iterable[Dict[str, Any]]) -> int:
        """Bulk upsert hot_tables rows.  Each row:
        ``{bucket, table_prefix, queries_7d, queries_24h,
        avg_seconds_7d, last_query_at}``.  Returns count written."""
        if not _config_enabled() or not self.ensure_schema():
            return 0
        now = datetime.now(timezone.utc)
        payload = []
        for r in rows:
            bucket = str(r.get("bucket") or "")
            prefix = str(r.get("table_prefix") or "")
            if not (bucket and prefix):
                continue
            payload.append((
                bucket, prefix,
                int(r.get("queries_7d") or 0),
                int(r.get("queries_24h") or 0),
                float(r.get("avg_seconds_7d") or 0.0),
                r.get("last_query_at"),
                now,
            ))
        if not payload:
            return 0
        try:
            with self._open_writer() as con:
                con.executemany(
                    "INSERT OR REPLACE INTO hot_tables VALUES "
                    "(?, ?, ?, ?, ?, ?, ?)",
                    payload,
                )
            return len(payload)
        except Exception as exc:
            logger.warning("brain_store: upsert_hot_tables failed: %s", exc)
            return 0

    def upsert_hot_columns(self, rows: Iterable[Dict[str, Any]]) -> int:
        """Bulk upsert hot_columns rows.  Each row:
        ``{bucket, table_prefix, column_name, usage_count_7d,
        last_used_at}``.  Returns count written."""
        if not _config_enabled() or not self.ensure_schema():
            return 0
        now = datetime.now(timezone.utc)
        payload = []
        for r in rows:
            bucket = str(r.get("bucket") or "")
            prefix = str(r.get("table_prefix") or "")
            name   = str(r.get("column_name") or "")
            if not (bucket and prefix and name):
                continue
            payload.append((
                bucket, prefix, name, name.lower(),
                int(r.get("usage_count_7d") or 0),
                r.get("last_used_at"),
                now,
            ))
        if not payload:
            return 0
        try:
            with self._open_writer() as con:
                con.executemany(
                    "INSERT OR REPLACE INTO hot_columns VALUES "
                    "(?, ?, ?, ?, ?, ?, ?)",
                    payload,
                )
            return len(payload)
        except Exception as exc:
            logger.warning("brain_store: upsert_hot_columns failed: %s", exc)
            return 0

    def record_mirror_state(
        self,
        *,
        component: str,
        success: bool,
        rows_upserted: int = 0,
        error: Optional[str] = None,
    ) -> None:
        """Record one mirror-tick outcome.  Called at the end of every
        mirror pass.  Never raises."""
        if not _config_enabled():
            return
        if not self.ensure_schema():
            return
        now = datetime.now(timezone.utc)
        try:
            with self._open_writer() as con:
                existing = con.execute(
                    "SELECT rows_upserted_total FROM mirror_state "
                    "WHERE component = ? LIMIT 1",
                    [component],
                ).fetchone()
                total = (int(existing[0]) if existing else 0) + int(rows_upserted or 0)
                last_ok = now if success else None
                # Truncate error message to keep the row size sane
                err_msg = (str(error)[:2000]) if error else None
                if existing:
                    if success:
                        con.execute(
                            "UPDATE mirror_state SET last_run_at = ?, "
                            "last_success_at = ?, rows_upserted_total = ?, "
                            "last_error = NULL WHERE component = ?",
                            [now, now, total, component],
                        )
                    else:
                        con.execute(
                            "UPDATE mirror_state SET last_run_at = ?, "
                            "rows_upserted_total = ?, last_error = ? "
                            "WHERE component = ?",
                            [now, total, err_msg, component],
                        )
                else:
                    con.execute(
                        "INSERT INTO mirror_state VALUES (?, ?, ?, ?, ?)",
                        [component, now, last_ok, total, err_msg],
                    )
        except Exception as exc:
            logger.debug("brain_store: record_mirror_state failed: %s", exc)


# ── writer context manager (process-lock protected) ─────────────────────


class _ReaderCtx:
    """Guarded reader connection.  Symmetric with ``_WriterCtx`` for
    shape parity so every ``_BrainStore`` reader method drops the
    ``con=None ... try/finally con.close()`` boilerplate.

    Close failures are logged at DEBUG so investigations aren't
    entirely blind, but they never mask the caller's own exception
    or return value.  2026-07-02 strategic refactor.
    """

    def __init__(self, path: Path) -> None:
        self._path = path
        self._con: Any = None

    def __enter__(self) -> Any:
        import duckdb
        self._con = duckdb.connect(str(self._path), read_only=True)
        return self._con

    def __exit__(self, exc_type, exc, tb) -> None:
        if self._con is None:
            return
        try:
            self._con.close()
        except Exception as close_exc:                                # pragma: no cover
            logger.debug(
                "brain_store _ReaderCtx close raised %s: %s -- "
                "suppressed (would otherwise mask the caller's own "
                "exception during teardown)",
                type(close_exc).__name__, close_exc,
            )


class _WriterCtx:
    """Guarded writer connection.  Holds a process-local lock so two
    threads in the same pod don't step on each other.  Cross-pod
    exclusion relies on the SchedulerLease upstream — only the
    scheduler-elect pod runs the mirror daemon."""

    def __init__(self, path: Path, lock: threading.Lock) -> None:
        self._path = path
        self._lock = lock
        self._con: Any = None

    def __enter__(self) -> Any:
        self._lock.acquire()
        import duckdb
        try:
            self._con = duckdb.connect(str(self._path), read_only=False)
            return self._con
        except Exception:
            self._lock.release()
            raise

    def __exit__(self, exc_type, exc, tb) -> None:
        try:
            if self._con is not None:
                try:
                    self._con.close()
                except Exception as close_exc:                        # pragma: no cover
                    # 2026-07-02 -- was ``except Exception: pass`` which
                    # tripped the silent-cap tripwire.  Debug-level
                    # log so investigations have a breadcrumb without
                    # promoting a close-failure to WARN spam.
                    logger.debug(
                        "brain_store _WriterCtx close raised %s: %s "
                        "-- suppressed",
                        type(close_exc).__name__, close_exc,
                    )
        finally:
            self._lock.release()


# ── singleton ───────────────────────────────────────────────────────────


_singleton: Optional[BrainDuckDBStore] = None
_singleton_lock = threading.Lock()


def get_store() -> BrainDuckDBStore:
    """Return the process-wide store singleton."""
    global _singleton
    if _singleton is None:
        with _singleton_lock:
            if _singleton is None:
                _singleton = BrainDuckDBStore()
    return _singleton


def reset_store_for_tests(*, path: Optional[Path] = None) -> BrainDuckDBStore:
    """Test hook: drop the singleton + reset any cached path.
    Optionally construct a fresh store at ``path`` so tests can point
    at a tmp file."""
    global _singleton
    with _singleton_lock:
        _singleton = BrainDuckDBStore(path=path) if path else None
    return _singleton  # type: ignore[return-value]


# ── read-through helper (canonical chokepoint for the read hot path) ────


# ────────────────────────────────────────────────────────────────────────
#  Prometheus counters (2026-07-03)
#
#  Phase 160 shipped ``brain_trace`` events (structured per-query logs)
#  for store hit / miss / error / disabled.  Great for debugging one
#  query.  Insufficient for the strategic question:
#
#      "What % of column-stat reads hit the store this week?"
#
#  Three unlabeled counters answer it fleet-wide.  Fail-open: if
#  ``prometheus_client`` isn't installed or registration races, the
#  helpers become no-ops.  Same pattern as
#  ``brain_latency_breakdown._maybe_register_prom_histograms``.
# ────────────────────────────────────────────────────────────────────────

_prom_counters: Dict[str, Any] = {}
_prom_ready = False
_PROM_LOCK = threading.Lock()


def _maybe_register_prom_counters() -> Dict[str, Any]:
    """Idempotently register 3 counters + return them.  Fail-open at
    every step -- if prometheus_client is missing or the metric names
    are already registered by a prior process run, we look up the
    existing collectors and reuse them so ``.inc()`` calls still land."""
    global _prom_ready
    with _PROM_LOCK:
        if _prom_ready:
            return _prom_counters
        _prom_ready = True
        try:
            from prometheus_client import Counter, REGISTRY  # type: ignore
        except Exception as exc:                             # pragma: no cover
            logger.debug("prometheus_client unavailable: %s", exc)
            return _prom_counters
        specs = [
            ("hits",     "qs_brain_store_hits_total",
             "Phase 160 columnar brain-store col_stats read hits (fell "
             "through to DuckDB store, primary DB not touched)."),
            ("misses",   "qs_brain_store_misses_total",
             "Phase 160 columnar brain-store col_stats read misses (store "
             "returned empty, request fell through to primary DB)."),
            ("errors",   "qs_brain_store_errors_total",
             "Phase 160 columnar brain-store col_stats read errors (store "
             "raised; request fell through to primary DB)."),
        ]
        for key, metric_name, docstring in specs:
            existing = _lookup_existing_prom_metric(REGISTRY, metric_name)
            if existing is not None:
                _prom_counters[key] = existing
                continue
            try:
                _prom_counters[key] = Counter(metric_name, docstring)
            except Exception as exc:
                existing = _lookup_existing_prom_metric(REGISTRY, metric_name)
                if existing is not None:
                    _prom_counters[key] = existing
                else:                                         # pragma: no cover
                    logger.debug("prom counter %s not created: %s",
                                 metric_name, exc)
        return _prom_counters


def _lookup_existing_prom_metric(registry: Any, name: str) -> Optional[Any]:
    """Walk the registry's private index (there's no public lookup in
    prometheus_client).  Returns the collector or None; if the private
    API shape changes across versions, caller re-registers."""
    try:
        names_to_collectors = getattr(registry, "_names_to_collectors", None)
        if names_to_collectors is None:
            return None
        return names_to_collectors.get(name)
    except Exception:                                         # pragma: no cover
        return None


def _prom_inc(key: str) -> None:
    """Best-effort increment.  Never raises."""
    try:
        counters = _maybe_register_prom_counters()
        c = counters.get(key)
        if c is not None:
            c.inc()
    except Exception:                                         # pragma: no cover
        pass


def get_col_stats_for_snapshot_via_store(
    db_manager: Any,
    bucket: str,
    table_prefix: str,
    snapshot_id: str,
    column_names: List[str],
    file_paths: Optional[List[str]] = None,
    format: str = "iceberg",
) -> Dict[str, Dict[str, Tuple[Optional[str], Optional[str], int, int]]]:
    """Store-first, DB-fallback read for iceberg column stats.

    Callers on the read hot path (iceberg_reader / iceberg_manifest_prune /
    iceberg_bloom_sidecar / iceberg_pyiceberg_reader /
    plain_parquet_brain_hooks / duckdb_views / query_feature_builder)
    should route through this chokepoint instead of calling
    ``db_manager.iceberg_col_stats_get_for_snapshot`` directly.

    Behaviour:
      1. Attempt the DuckDB store.  If it returns anything, use it
         + trace ``store_hit`` — the primary DB is not touched.
      2. Miss (empty result) → fall through to primary DB + trace
         ``store_miss``.
      3. Any store error → also fall through + trace ``store_error``.
      4. Store disabled → straight to DB + trace ``store_disabled``.

    The tracing lets operators see the store hit-rate per query via
    ``brain_trace``.
    """
    # Delayed import so this helper has no hard dep on brain_trace.
    try:
        from core.brain_trace import trace as _bt_trace
    except Exception:                                       # pragma: no cover
        _bt_trace = lambda *a, **k: None                    # noqa: E731

    # 2026-07-13 — SINGLE grain-routing chokepoint.  Under the per-file grain
    # (iceberg.file_stats_grain=="v3") every column-stats reader that routes
    # through this helper reads the per-FILE table (iceberg_file_stats_v3),
    # whose get returns the SAME {file_path:{col:(lo,hi,nulls,rc)}} shape.
    # The legacy v2 (file×column) supplement + its DuckDB store mirror are
    # skipped entirely.  Fail-open: if the v3 read errors we fall through to
    # the v2 store/DB path below (never a hard failure).
    try:
        from core import config as _qs_cfg_grain
        _fs_grain = _qs_cfg_grain.iceberg_file_stats_grain()
    except Exception:
        _fs_grain = "v3"
    if _fs_grain == "v3":
        _v3fn = getattr(db_manager, "iceberg_file_stats_get_for_snapshot", None)
        if _v3fn is not None:
            try:
                _v3res = _v3fn(
                    bucket=bucket, table_prefix=table_prefix,
                    snapshot_id=snapshot_id, column_names=column_names,
                    file_paths=file_paths, format=format,
                )
                # SEAMLESS MIGRATION: only trust v3 when it actually has rows
                # for this table.  An EMPTY v3 read (table not yet scanned
                # under the per-file grain, e.g. right after cutover) FALLS
                # THROUGH to the legacy v2 store/DB below — so existing v2
                # data keeps pruning until v3 is populated (by the next scan
                # or backfill_from_v2).  v3 bounds win the moment they exist.
                if _v3res:
                    _bt_trace("brain_store", "v3_read",
                              bucket=bucket, table_prefix=table_prefix,
                              files=len(_v3res))
                    return _v3res
                _bt_trace("brain_store", "v3_empty_fallback_v2",
                          bucket=bucket, table_prefix=table_prefix)
            except Exception as exc:
                _bt_trace("brain_store", "v3_error",
                          bucket=bucket, table_prefix=table_prefix,
                          err=str(exc)[:200])
                # fall through to v2 store/DB (fail-open)

    store = get_store()
    used_store = False
    result: Dict[str, Dict[str, Tuple[Optional[str], Optional[str], int, int]]] = {}

    if store.is_available():
        try:
            result = store.get_col_stats_for_snapshot(
                bucket=bucket,
                table_prefix=table_prefix,
                snapshot_id=snapshot_id,
                column_names=column_names,
                file_paths=file_paths,
                format=format,
            )
            # 2026-07-13 CORRECTNESS FIX: a store hit is valid ONLY if it
            # covers EVERY requested column.  Previously ``used_store =
            # bool(result)`` accepted a PARTIAL mirror (e.g. the store was
            # synced before ``system_id`` was scanned) and returned it
            # WITHOUT consulting the authoritative primary DB — so a column
            # whose bounds DO exist in the DB read back as "no details found"
            # and pruning silently ignored it.  If any requested column is
            # entirely absent from the store result, treat it as a miss and
            # fall through to the DB (which is authoritative + complete).
            if result and column_names:
                _want = {str(c).split(".")[-1].lower() for c in column_names}
                _have: set = set()
                for _cols in result.values():
                    _have.update((k or "").lower() for k in (_cols or {}))
                if not _want.issubset(_have):
                    _bt_trace("brain_store", "store_partial_miss",
                              bucket=bucket, table_prefix=table_prefix,
                              missing=",".join(sorted(_want - _have))[:200])
                    result = {}   # force authoritative DB fallback
            used_store = bool(result)
        except Exception as exc:
            _bt_trace("brain_store", "store_error",
                      bucket=bucket, table_prefix=table_prefix, err=str(exc)[:200])
            _prom_inc("errors")
            result = {}
    else:
        _bt_trace("brain_store", "store_disabled",
                  bucket=bucket, table_prefix=table_prefix)

    if used_store:
        _bt_trace("brain_store", "store_hit",
                  bucket=bucket, table_prefix=table_prefix,
                  files=len(result))
        _prom_inc("hits")
        return result

    # Fall through to primary DB.
    _bt_trace("brain_store", "store_miss",
              bucket=bucket, table_prefix=table_prefix)
    _prom_inc("misses")
    try:
        fn = getattr(db_manager, "iceberg_col_stats_get_for_snapshot", None)
        if fn is None:
            return {}
        return fn(
            bucket=bucket,
            table_prefix=table_prefix,
            snapshot_id=snapshot_id,
            column_names=column_names,
            file_paths=file_paths,
            format=format,
        )
    except Exception as exc:
        logger.debug("brain_store: DB fallback failed: %s", exc)
        return {}


__all__ = [
    "STORE_TABLES", "BrainDuckDBStore",
    "get_store", "reset_store_for_tests",
    "get_col_stats_for_snapshot_via_store",
]
