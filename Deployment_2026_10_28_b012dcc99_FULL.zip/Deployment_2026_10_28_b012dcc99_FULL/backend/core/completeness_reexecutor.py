"""core/completeness_reexecutor.py — the SHADOW RE-EXECUTOR (Tier-3 wrong-prune
catcher), wired at last.

2026-07-17.  ``core.completeness_control`` ships the whole Tier-3 apparatus —
the bounded background sampler, deterministic per-exec sampling, divergence
incidents, auto-quarantine, and the Sentinel escalation on divergence — but it
was INERT because nothing ever called ``set_reexecutor()``.  Without a
registered re-executor ``get_reexecutor()`` is always ``None`` and the reader's
Tier-3 enqueue block is skipped, so the advertised empirical wrong-prune check
never ran.  This module supplies + registers that missing piece.

────────────────────────────────────────────────────────────────────────────
WHAT THE RE-EXECUTOR DOES
────────────────────────────────────────────────────────────────────────────
Given the context the sampler already captured for a query on an Iceberg table
(bucket, table_prefix, the pruning ``partition_filters``, the KEPT file keys,
the snapshot id, connection_id), it:

  1. re-enumerates the table's FULL data-file set with pruning DISABLED, by
     calling the SAME reader (``get_iceberg_data_files``) with
     ``partition_filters=None`` — the reader's own full_scan kill-switch;
  2. runs ``SELECT COUNT(*) … WHERE <partition_filters>`` over the KEPT set and
     again over the FULL set, reusing the SAME DuckDB + presign + ``_build_where``
     machinery the ``/api/query/preview`` path uses (no query engine is
     reimplemented here);
  3. returns ``(pruned_rows, full_rows)`` for the sampler to compare.

Because the full run has pruning OFF it reads STRICTLY MORE data, so the
comparison can only ever reveal the pruned path MISSING rows (``full > pruned``
⇒ the brain wrongly pruned matching rows ⇒ data loss).  It can never itself
cause loss, and it never touches the user's primary result.

FAITHFUL-OR-SKIP.  A wrong comparison is worse than none.  If the captured
context is too thin to re-run faithfully — no connection, no kept keys, or a
filter op we cannot reproduce EXACTLY (a scalar op outside ``_build_where``'s
vocabulary, or a SET/RANGE op whose value shape we cannot type EXACTLY, e.g.
``not_like`` or a non-numeric ``between``) — the re-executor returns ``None``
and the sampler drops the sample cleanly (no incident, no quarantine).

The SET/RANGE ops ``in`` / ``not_in`` / ``between`` / ``not_between`` ARE
supported (2026-07-17 widening): ``in``/``not_in`` are emitted as the exact
multi-value generalisation of ``_build_where``'s VARCHAR-cast ``equals`` /
``not_equals`` comparison; numeric ``between``/``not_between`` reuse the same
``TRY_CAST(col AS DOUBLE)`` ordering ``_build_where`` uses for ``gt``/``lt``.
Any list that is empty, holds a NULL/non-scalar element, or (for a range)
whose bounds are not both numeric → still SKIPS (faithful-or-skip).  This also
means the Sentinel's loss-lane verify (which calls the re-executor with only
``{"table_prefix": …}``) gets ``None`` ⇒ "cannot prove safe" ⇒ it HOLDS the
quarantine (never downgrades on doubt) — exactly the safe behaviour.

────────────────────────────────────────────────────────────────────────────
OFF BY DEFAULT — ZERO COST, ZERO BEHAVIOUR CHANGE
────────────────────────────────────────────────────────────────────────────
``register()`` is a NO-OP unless an operator opted in via
``completeness.shadow_sample_rate > 0`` OR a non-empty
``completeness.shadow_tables``.  In a default install neither is set, so
``register()`` returns WITHOUT calling ``set_reexecutor`` — ``get_reexecutor()``
stays ``None`` and the reader's Tier-3 enqueue block is skipped ENTIRELY (it is
guarded by ``if _cc_reexec is not None``).  Nothing is enqueued, nothing is
re-run, and every query behaves byte-for-byte as before.

BOUNDED · BACKGROUND · FAIL-OPEN · NON-RECURSIVE.  The re-executor only ever
runs on the sampler's bounded worker pool (never inline on the user's request),
respects ``shadow_max_concurrent``, swallows every error into a skip, and wraps
its full-set re-enumeration in ``completeness_control.shadow_reexec_guard`` so a
re-run can never enqueue another re-run.
"""
from __future__ import annotations

import json
import logging
from typing import Any, Dict, List, Optional, Tuple

import core.completeness_control as cc

logger = logging.getLogger(__name__)

# db_manager captured at registration so the re-executor can resolve a
# connection's decrypted credentials OFF the query hot-path.  Set only when the
# feature is opted in (see ``register``); ``None`` in a default install.
_DB_MANAGER: Any = None

# Reader partition-filter SCALAR op  ->  ``_build_where`` op.
# ONLY scalar ops whose SQL we can reproduce EXACTLY (the same parameterized
# predicate the preview COUNT path emits, verbatim) are listed here.  The
# SET/RANGE ops (``in`` / ``not_in`` / ``between`` / ``not_between``) are handled
# separately in the shadow-only emitter ``_emit_set_range_sql`` (see below).
# Any op in NEITHER table — ``not_like`` / ``contains`` bounds-only operators —
# makes the whole sample SKIP (faithful-or-skip).
_OP_MAP: Dict[str, str] = {
    "equals": "equals", "eq": "equals", "=": "equals", "==": "equals",
    "not_equals": "not_equals", "ne": "not_equals", "!=": "not_equals",
    "gt": "gt", ">": "gt", "greater_than": "gt",
    "gte": "gte", ">=": "gte", "greater_equals": "gte",
    "lt": "lt", "<": "lt", "less_than": "lt",
    "lte": "lte", "<=": "lte", "less_equals": "lte",
    "is_null": "is_null", "isnull": "is_null",
    "is_not_null": "is_not_null", "isnotnull": "is_not_null",
    "starts_with": "starts_with", "like_prefix": "starts_with",
}

# Reader partition-filter SET/RANGE op  ->  canonical shadow op.  These are NOT
# expressible in ``_build_where``'s vocabulary, so the shadow lane emits their
# SQL itself (``_emit_set_range_sql``) — faithfully mirroring how ``_build_where``
# compares (VARCHAR cast for equality, ``TRY_CAST(... AS DOUBLE)`` for ordering).
_SET_RANGE_OP_MAP: Dict[str, str] = {
    "in": "in",
    "not_in": "not_in", "nin": "not_in", "notin": "not_in",
    "between": "between",
    "not_between": "not_between", "notbetween": "not_between",
}
# Canonical SET/RANGE ops — a condition whose op is one of these is routed to
# ``_emit_set_range_sql`` instead of ``_build_where`` in ``_count_over_keys``.
_SET_RANGE_OPS = frozenset(_SET_RANGE_OP_MAP.values())


def _is_bindable_scalar(v: Any) -> bool:
    """A single IN/NOT-IN list element we can bind as a parameter EXACTLY the
    way ``_build_where`` binds an ``equals`` value (``str(v)`` under a VARCHAR
    cast).  Lists/dicts/None are NOT bindable → the whole sample SKIPS."""
    return isinstance(v, (str, int, float, bool)) and not isinstance(v, type(None))


def _emit_set_range_sql(
    col: str, op: str, val: Any, q_fn: Any,
) -> Optional[Tuple[str, List[Any]]]:
    """Emit the ``(sql_fragment, params)`` for ONE canonical SET/RANGE condition,
    using parameterized ``?`` placeholders (no manual quoting → no injection, a
    bad value simply fails to bind → the caller's try/except SKIPS).  Returns
    ``None`` when the value shape cannot be reproduced EXACTLY (faithful-or-skip).

    The emitted SQL is a pure function of ``(col, op, val)`` — it never depends on
    the file set — so the SAME fragment+params is produced for the KEPT side and
    the FULL side (apples-to-apples).

      • ``in``          → ``CAST(col AS VARCHAR) IN (?, …)``           (multi-value
                          generalisation of ``_build_where`` ``equals``)
      • ``not_in``      → ``CAST(col AS VARCHAR) NOT IN (?, …)``       (standard
                          SQL NOT IN: a NULL col value yields UNKNOWN → excluded,
                          exactly as the user's real ``NOT IN`` query behaves)
      • ``between``     → ``TRY_CAST(col AS DOUBLE) BETWEEN ? AND ?``  (numeric
                          only; == ``gte`` AND ``lte``, both already supported)
      • ``not_between`` → ``(TRY_CAST(col AS DOUBLE) < ? OR … > ?)``   (numeric
                          only; NULLs excluded, matching SQL NOT BETWEEN)
    """
    qcol = q_fn(col)
    if op in ("in", "not_in"):
        # val is pre-validated by _map_filters: a non-empty list of bindable,
        # non-NULL scalars.  Bind each exactly as equals does (str under VARCHAR).
        if not isinstance(val, (list, tuple)) or len(val) == 0:
            return None
        params: List[Any] = []
        for v in val:
            if not _is_bindable_scalar(v):
                return None                 # NULL / nested shape → SKIP
            params.append(str(v))
        placeholders = ", ".join(["?"] * len(params))
        cast = f"CAST({qcol} AS VARCHAR)"
        if op == "in":
            return f"{cast} IN ({placeholders})", params
        return f"{cast} NOT IN ({placeholders})", params
    if op in ("between", "not_between"):
        # Numeric-only: both bounds must cast to float, else SKIP.  This mirrors
        # _build_where's TRY_CAST(... AS DOUBLE) ordering used for gt/gte/lt/lte,
        # so a numeric BETWEEN is provably == (gte lo) AND (lte hi).
        if not isinstance(val, (list, tuple)) or len(val) != 2:
            return None
        try:
            lo = float(val[0])
            hi = float(val[1])
        except (ValueError, TypeError):
            return None                     # non-numeric bounds (e.g. dates) → SKIP
        expr = f"TRY_CAST({qcol} AS DOUBLE)"
        if op == "between":
            return f"{expr} BETWEEN ? AND ?", [lo, hi]
        return f"({expr} < ? OR {expr} > ?)", [lo, hi]
    return None


def _compose_shadow_where(
    conditions: List[Dict[str, Any]],
    valid_cols: List[str],
    build_where_fn: Any,
    q_fn: Any,
) -> Optional[Tuple[str, List[Any]]]:
    """Build the FULL ``(WHERE-string, params)`` for the shadow COUNT from two
    faithful sources, ANDed together (the shadow always ANDs its prune
    predicates — see ``_map_filters``):

      • scalar ops   → ``build_where_fn`` verbatim (the preview COUNT path's SQL);
      • SET/RANGE ops → ``_emit_set_range_sql`` (shadow-only, parameterized).

    Returns ``None`` (→ skip the sample) if any part cannot be built EXACTLY — a
    scalar op that did not translate, or an unrepresentable SET/RANGE value.

    PURE FUNCTION of ``(conditions, valid_cols)`` — it never references the file
    set — so for a given table it yields a BYTE-IDENTICAL WHERE+params on both
    the KEPT and the FULL side.  That identity is the apples-to-apples guarantee:
    ``COUNT(*) WHERE X`` over kept vs full uses the very same ``X``."""
    where_parts: List[str] = []
    params: List[Any] = []
    scalar_conds = [c for c in conditions if c["op"] not in _SET_RANGE_OPS]
    set_range_conds = [c for c in conditions if c["op"] in _SET_RANGE_OPS]
    if scalar_conds:
        s_where, s_params = build_where_fn(
            json.dumps({"conjunction": "AND", "conditions": scalar_conds}),
            valid_cols)
        if not s_where:
            # A scalar op did not translate (e.g. a non-numeric gt val) → would
            # be an unfiltered count on that dimension.  Refuse.
            return None
        body = s_where[len(" WHERE "):] if s_where.startswith(" WHERE ") \
            else s_where.lstrip()
        where_parts.append(body)
        params.extend(s_params or [])
    for c in set_range_conds:
        frag = _emit_set_range_sql(c["col"], c["op"], c["val"], q_fn)
        if frag is None:
            # Unrepresentable value shape slipped past _map_filters → refuse
            # (never emit an approximate WHERE).
            return None
        sql_frag, f_params = frag
        where_parts.append(sql_frag)
        params.extend(f_params)
    if not where_parts:
        return None
    return " WHERE " + " AND ".join(where_parts), params


# ═══════════════════════════════════════════════════════════════════════════
# Registration — off by default.
# ═══════════════════════════════════════════════════════════════════════════
def _feature_enabled() -> bool:
    """True only when an operator has opted in: ``shadow_sample_rate > 0`` OR a
    non-empty ``shadow_tables``.  Fail-open → False (stay inert on any error)."""
    try:
        return cc.shadow_sample_rate() > 0.0 or bool(cc.shadow_tables())
    except Exception:
        return False


def register(db_manager: Any = None) -> bool:
    """Register the shadow re-executor with ``completeness_control`` — IFF shadow
    sampling is opted in.  Returns True when it actually registered.

    OFF BY DEFAULT: with the default config (``shadow_sample_rate`` 0.0,
    ``shadow_tables`` empty) this returns WITHOUT registering, leaving
    ``get_reexecutor()`` ``None`` so the reader's Tier-3 enqueue block is skipped
    entirely — zero added work, zero behaviour change.  Fail-open: any error is
    logged and swallowed so a registration hiccup can never break startup."""
    global _DB_MANAGER
    try:
        if not _feature_enabled():
            logger.info(
                "[completeness-reexec] shadow sampling OFF "
                "(shadow_sample_rate=0.0, shadow_tables empty) — re-executor "
                "NOT registered; get_reexecutor() stays None (zero cost, zero "
                "behaviour change on every query).")
            return False
        _DB_MANAGER = db_manager
        cc.set_reexecutor(shadow_reexec)
        logger.warning(
            "[completeness-reexec] shadow re-executor REGISTERED (opt-in): "
            "shadow_sample_rate=%s shadow_tables=%s — SAMPLED queries on "
            "eligible tables now get a BACKGROUND full-scan-off row-count audit "
            "(bounded pool, off the user's request path, fail-open).",
            cc.shadow_sample_rate(), cc.shadow_tables())
        return True
    except Exception as exc:
        logger.warning(
            "[completeness-reexec] registration failed (fail-open, non-fatal): "
            "%s", exc)
        return False


def unregister() -> None:
    """Test / admin helper — drop the re-executor and captured db_manager."""
    global _DB_MANAGER
    _DB_MANAGER = None
    try:
        cc.set_reexecutor(None)
    except Exception:
        pass


# ═══════════════════════════════════════════════════════════════════════════
# Internal helpers (module-level so tests can substitute S3 / DuckDB cleanly).
# ═══════════════════════════════════════════════════════════════════════════
def _resolve_conn(connection_id: int) -> Optional[Tuple[Any, Dict[str, Any]]]:
    """Return ``(s3_client, conn_config)`` for a connection_id, reusing the same
    credential path (``get_connection_raw`` → ``make_s3_client_for_conn``) as
    query execution.  ``None`` when unresolvable (→ skip)."""
    dbm = _DB_MANAGER
    if dbm is None or not connection_id:
        return None
    try:
        raw = dbm.get_connection_raw(int(connection_id))
    except Exception as exc:
        logger.debug("[completeness-reexec] get_connection_raw(%s) failed: %s",
                     connection_id, exc)
        return None
    if not raw:
        return None
    conn_config = raw.get("config") or {}
    try:
        from core.s3_utilities import make_s3_client_for_conn
        s3 = make_s3_client_for_conn(raw)
    except Exception as exc:
        logger.debug("[completeness-reexec] make_s3_client_for_conn failed: %s",
                     exc)
        return None
    if s3 is None:
        return None
    return s3, conn_config


def _enumerate_full_keys(s3_client: Any, ctx: Dict[str, Any]) -> Optional[List[str]]:
    """Re-enumerate ALL data files for the table+snapshot with pruning DISABLED
    (``partition_filters=None`` — the reader's own full-scan kill-switch).
    Reuses ``get_iceberg_data_files``; the caller holds the recursion guard so
    this re-enumeration cannot enqueue another shadow sample.  ``None`` on any
    failure (→ skip)."""
    bucket = ctx.get("bucket")
    table_prefix = ctx.get("table_prefix")
    if not bucket or not table_prefix:
        return None
    try:
        from core.iceberg_reader import get_iceberg_data_files
        rows = get_iceberg_data_files(
            s3_client, str(bucket), str(table_prefix),
            partition_filters=None,        # ← pruning OFF: the FULL file set
            keys_only=True,
            snapshot_id=ctx.get("snapshot_id"),
            connection_id=ctx.get("connection_id"),
            table_name=ctx.get("table_name"),
        )
    except Exception as exc:
        logger.debug("[completeness-reexec] full re-enumeration failed: %s", exc)
        return None
    keys: List[str] = []
    for r in (rows or []):
        k = r.get("key") if isinstance(r, dict) else None
        if k:
            keys.append(str(k))
    return keys or None


def _map_filters(
    partition_filters: Optional[List[Dict[str, Any]]],
) -> Optional[List[Dict[str, Any]]]:
    """Translate the reader's ``partition_filters`` into the shadow lane's
    condition vocabulary — scalar ops mapped to ``_build_where``'s op names, and
    the SET/RANGE ops (``in``/``not_in``/``between``/``not_between``) mapped to
    their canonical form for ``_emit_set_range_sql``.  Returns the mapped list,
    or ``None`` if there are no filters (nothing to compare) OR ANY filter uses
    an op we cannot reproduce exactly OR whose value shape is not faithfully
    reproducible — in which case the whole sample is skipped (faithful-or-skip)."""
    if not partition_filters:
        # No prune predicate → a full-vs-kept comparison would compare two
        # UNFILTERED counts (full always ≥ kept whenever anything was pruned),
        # which is meaningless.  Skip.
        return None
    out: List[Dict[str, Any]] = []
    for f in partition_filters:
        if not isinstance(f, dict):
            return None
        col = f.get("col") if f.get("col") is not None else f.get("column")
        op_raw = f.get("op") if f.get("op") is not None else f.get("operator")
        op = str(op_raw or "").strip().lower()
        if not col:
            return None
        val = f.get("val") if "val" in f else f.get("value", "")
        mapped = _OP_MAP.get(op)
        if mapped is not None:
            out.append({"col": str(col), "op": mapped, "val": val})
            continue
        canon = _SET_RANGE_OP_MAP.get(op)
        if canon is None:
            return None  # unsupported op → skip whole sample
        # Validate the value shape NOW (faithful-or-skip): the SET/RANGE emitter
        # must be able to reproduce it EXACTLY, else drop the whole sample rather
        # than emit an approximate WHERE.
        if canon in ("in", "not_in"):
            if not isinstance(val, (list, tuple)) or len(val) == 0:
                return None                 # empty IN → degenerate → SKIP
            if not all(_is_bindable_scalar(v) for v in val):
                return None                 # NULL / nested element → SKIP
            out.append({"col": str(col), "op": canon, "val": list(val)})
        else:  # between / not_between — numeric bounds only
            if not isinstance(val, (list, tuple)) or len(val) != 2:
                return None
            try:
                out.append({"col": str(col), "op": canon,
                            "val": [float(val[0]), float(val[1])]})
            except (ValueError, TypeError):
                return None                 # non-numeric bounds → SKIP
    return out or None


def _count_over_keys(
    s3_client: Any,
    conn_config: Dict[str, Any],
    bucket: str,
    keys: Optional[List[str]],
    conditions: List[Dict[str, Any]],
    connection_id: int,
) -> Optional[int]:
    """``SELECT COUNT(*)`` over the given S3 parquet keys applying ``conditions``
    as a WHERE, reusing the SAME DuckDB + presign + ``_build_where`` machinery as
    the preview path.  Returns the count, or ``None`` on any failure OR if the
    WHERE cannot be built faithfully (→ skip the sample).  An empty key set
    trivially counts 0 (no scan)."""
    if keys is None:
        return None
    if len(keys) == 0:
        return 0
    try:
        uris: List[str] = []
        for k in keys:
            ks = str(k)
            uris.append(ks if ks.startswith("s3://")
                        else f"s3://{bucket}/{ks.lstrip('/')}")
        from core.s3_utilities import get_s3_access_mode, s3_urls_to_presigned
        if get_s3_access_mode(conn_config) == "presigned":
            paths = s3_urls_to_presigned(s3_client, uris, conn_config)
        else:
            paths = uris
        from core.duckdb_views import _build_iceberg_read_expr
        from_clause = _build_iceberg_read_expr(paths)
        # Lazy import (background thread, well after startup) keeps this off the
        # import graph and avoids a core→api cycle at load time.
        from api.data_grid_api import _duckdb_con_with_s3, _build_where, _q
        con = _duckdb_con_with_s3(conn_config, connection_id)
        valid_cols = con.execute(
            f"SELECT * FROM {from_clause} LIMIT 0").fetchdf().columns.tolist()
        # Every filter col MUST exist, else _build_where silently drops it and we
        # would count UNFILTERED → a wrong comparison.  Refuse instead.
        for c in conditions:
            if c["col"] not in valid_cols:
                logger.debug("[completeness-reexec] filter col %r absent from "
                             "schema — skip", c["col"])
                return None
        # Compose the WHERE (scalar via _build_where + SET/RANGE via the
        # shadow-only emitter).  Pure function of (conditions, schema) → byte
        # -identical for the KEPT and FULL calls (apples-to-apples).  None → an
        # op/value that cannot be reproduced EXACTLY → skip.
        composed = _compose_shadow_where(conditions, valid_cols, _build_where, _q)
        if composed is None:
            return None
        where, params = composed
        row = con.execute(
            f"SELECT COUNT(*) FROM {from_clause}{where}", params or []).fetchone()
        return int(row[0]) if row and row[0] is not None else None
    except Exception as exc:
        logger.debug("[completeness-reexec] count over %d keys failed: %s",
                     len(keys), exc)
        return None


# ═══════════════════════════════════════════════════════════════════════════
# The registered re-executor.
# ═══════════════════════════════════════════════════════════════════════════
def shadow_reexec(ctx: Dict[str, Any]) -> Optional[Tuple[int, int]]:
    """Return ``(pruned_rows, full_rows)`` for the sampler to compare, or ``None``
    to DECLINE the sample.  Runs ONLY on the sampler's background worker (never
    inline), fail-open, and non-recursive (the full-set re-enumeration is wrapped
    in the recursion guard).  It never sees, touches, or returns the user's
    primary result — it only counts rows."""
    tp = None
    try:
        if not isinstance(ctx, dict):
            return None
        tp = ctx.get("table_prefix")
        cid = ctx.get("connection_id")
        kept = ctx.get("kept_file_keys")
        bucket = ctx.get("bucket")
        # The Sentinel's loss-lane verify calls us with only {"table_prefix": …}.
        # That is too thin to re-run → decline → the Sentinel HOLDS quarantine
        # (never downgrades on doubt).  Same for any query missing connection /
        # kept keys / bucket.
        if not cid or kept is None or not bucket or not tp:
            logger.debug("[completeness-reexec] context too thin to re-run "
                         "(table=%s) — decline", tp)
            return None
        conditions = _map_filters(ctx.get("partition_filters"))
        if conditions is None:
            logger.debug("[completeness-reexec] filters not faithfully "
                         "reproducible for %s — decline sample", tp)
            return None
        # RECURSION GUARD around every reader/DuckDB touch: the full re-enumeration
        # calls back into the reader, which would otherwise reach the Tier-3
        # enqueue gate again.
        with cc.shadow_reexec_guard():
            resolved = _resolve_conn(int(cid))
            if resolved is None:
                return None
            s3, conn_config = resolved
            full_keys = _enumerate_full_keys(s3, ctx)
            if not full_keys:
                return None
            pruned = _count_over_keys(
                s3, conn_config, str(bucket), list(kept), conditions, int(cid))
            full = _count_over_keys(
                s3, conn_config, str(bucket), full_keys, conditions, int(cid))
        if pruned is None or full is None:
            return None
        if full < pruned:
            # kept ⊆ full under the SAME predicate, so full ≥ pruned always.
            # An inversion means the two runs disagree on something structural
            # (snapshot skew) — refuse rather than report a bogus result.
            logger.debug("[completeness-reexec] full(%d) < pruned(%d) for %s — "
                         "inconsistent, decline", full, pruned, tp)
            return None
        logger.info("[completeness-reexec] shadow re-run for %s: pruned=%d "
                    "full=%d (full-scan-off audit).", tp, pruned, full)
        return (int(pruned), int(full))
    except Exception as exc:
        # FAIL-OPEN: never surface, never affect anything — just decline.
        logger.warning("[completeness-reexec] shadow re-run errored for %s "
                       "(declined, fail-open): %s", tp, exc)
        return None
