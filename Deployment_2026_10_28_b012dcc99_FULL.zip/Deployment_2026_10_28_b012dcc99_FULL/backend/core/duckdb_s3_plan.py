"""Single decision point: how should the DuckDB subprocess (or in-process
httpfs caller) configure itself to read the S3 URLs that appear in a
piece of SQL?

Why this exists -- strategic version of the 2026-06-23 smart-brain VPC
incident.  Background:

    * The DuckDB subprocess used to derive its setup from ONE input --
      ``conn_config`` -- via ``get_s3_access_mode`` (``"native"`` vs
      ``"presigned"``).  That single boolean drove FOUR decisions: load
      httpfs, set ``s3_endpoint``, set credentials, run pre-download.

    * As the smart brain learned new tricks (VPC presigned fast path,
      proxy fallback, on-prem pre-download), the PARENT process started
      emitting SQL whose contents no longer matched the connection's
      access_mode -- e.g. ``access_mode="native"`` but the SQL already
      contains ``read_parquet(['https://vpce-…?X-Amz-Signature=…'])``.

    * The subprocess kept setting ``s3_endpoint`` and S3 credentials
      because access_mode said ``"native"``.  httpfs then applied its
      OWN SigV4 on top of the already-signed URL -> libcurl dropped the
      malformed request -> ``HTTP 0 Internal Server Error``.

The strategic fix is NOT to scatter ``if "X-Amz-Signature=" in setup_sql``
guards through the subprocess.  It's to recognise that there are three
distinct strategies and compute ONE plan describing which strategy fires
and what each subsystem (httpfs / endpoint / creds / SSL bundle /
pre-download) should do under it.  Every consumer reads the plan; no
caller second-guesses individual fields.

The three strategies:

    LOCAL_FILES
        Used by on-prem ``access_mode="presigned"``.  Subprocess
        pre-downloads the presigned HTTPS URLs to local temp files via
        Python urllib, rewrites the SQL to local paths, then DuckDB
        reads native local parquet -- httpfs is never loaded.

    NATIVE_S3_SIGNED_BY_DUCKDB
        Used by AWS S3 native and on-prem S3 native-mode connections.
        ``s3://`` URLs travel through DuckDB httpfs which signs each
        request itself.  Subprocess sets ``s3_endpoint``, credentials,
        SSL bundle.

    PRESIGNED_URLS_IN_SQL
        Used by the smart-VPC fast path (and any future caller that
        emits already-signed HTTPS URLs in setup_sql).  httpfs IS
        loaded for the HTTPS GET, BUT ``s3_endpoint`` and credentials
        are NOT set or libcurl would re-sign the URL.  SSL bundle still
        matters because libcurl is making real HTTPS calls.

Detection precedence is intentional:

    1. ``access_mode="presigned"`` -> LOCAL_FILES (existing on-prem
       behaviour, no surprises).
    2. SQL contains presigned-URL markers AND access_mode="native" ->
       PRESIGNED_URLS_IN_SQL.
    3. Default -> NATIVE_S3_SIGNED_BY_DUCKDB.

The detection of "SQL has presigned URLs" looks for the canonical
SigV4 marker ``X-Amz-Signature=``.  This catches every presigned URL
boto3 generates regardless of whether they were emitted by the smart-
VPC fast path, the on-prem ``s3_urls_to_presigned`` helper, or any
future code path.  No new wiring required as the brain learns more
strategies.

Used by:
    * ``core.duckdb_subprocess`` -- the subprocess COPY-TO path.
    * In-process httpfs callers that build their own DuckDB connection
      (federation_engine, BQB streaming, MV refresh) can adopt the same
      plan to stay consistent.
"""

from __future__ import annotations

import re
import threading
import weakref
from dataclasses import dataclass
from typing import Optional

from core.s3_utilities import get_s3_access_mode


# ── Reset-stamp registry ───────────────────────────────────────────────
#
# 2026-06-23 round-7 -- a behavioural test against real DuckDB caught
# that ``setattr(con, "_qs_…", True)`` silently fails on
# ``duckdb.DuckDBPyConnection`` (no ``__dict__``).  The PooledS3Con
# wrapper's setattr falls through to the inner con and the attribute
# never sticks.  Result: pool release never saw the stamp, kept
# pooling RESET connections, next query on the same pool found no
# s3_endpoint -> HTTP 403 on s3:// reads.  The whole purpose of the
# stamp was defeated silently.
#
# Strategic fix: side-channel registry keyed off the connection's
# identity.  ``WeakSet`` tracks every connection whose S3 signing was
# RESET by ``reset_s3_signing_on_connection``.  ``is_connection_reset``
# is the public check used by the data_grid_api pool release path.
# WeakSet ensures GC cleans entries automatically when connections
# close -- no leak, no manual cleanup, no per-connection state.
#
# Threadlocking: WeakSet is not thread-safe per Python docs.  Wrap
# every mutation + read in a single module-level lock so the pool
# release path can't see a half-mutated set under concurrent
# checkouts.

_RESET_CONNECTIONS: "weakref.WeakSet" = weakref.WeakSet()
_RESET_CONNECTIONS_LOCK = threading.Lock()


def mark_connection_reset(con) -> bool:
    """Add ``con`` to the reset-stamp registry.  Used by
    ``reset_s3_signing_on_connection`` after a successful RESET pass.
    Returns True on success, False when ``con`` doesn't support
    weakref (no production DuckDB connection type fails this -- a
    fallback exists for completeness).
    """
    try:
        with _RESET_CONNECTIONS_LOCK:
            _RESET_CONNECTIONS.add(con)
        return True
    except TypeError:
        # Object doesn't support weakref.  Fall back to setattr for
        # objects that do support __dict__ (Python proxy wrappers,
        # test doubles).  Pool release checks BOTH the registry and
        # the legacy attribute, so this still works.
        try:
            setattr(con, "_qs_s3_signing_reset_for_presigned_views", True)
            return True
        except Exception:
            return False


def is_connection_reset(con) -> bool:
    """True if ``reset_s3_signing_on_connection`` has stamped this
    connection.  Used by data_grid_api._return_to_s3_pool to decide
    whether to recycle (close) or pool the connection.
    """
    try:
        with _RESET_CONNECTIONS_LOCK:
            if con in _RESET_CONNECTIONS:
                return True
    except TypeError:
        pass
    # Back-compat: respect the legacy setattr-based stamp too -- some
    # callers / test doubles use it.
    try:
        return bool(getattr(
            con, "_qs_s3_signing_reset_for_presigned_views", False))
    except Exception:
        return False


def _unmark_connection_reset(con) -> None:
    """Test-only helper to clear the stamp without closing the
    connection.  Production code never needs this -- WeakSet GC
    handles cleanup automatically when the connection closes."""
    try:
        with _RESET_CONNECTIONS_LOCK:
            _RESET_CONNECTIONS.discard(con)
    except TypeError:
        pass
    try:
        if hasattr(con, "_qs_s3_signing_reset_for_presigned_views"):
            delattr(con, "_qs_s3_signing_reset_for_presigned_views")
    except Exception:
        pass

# SigV4 query-parameter that EVERY ``boto3 generate_presigned_url`` URL
# carries.  Single source of truth -- if AWS ever changes the parameter
# name we update it here and every detection site follows.
SIGV4_PRESIGN_MARKER = "X-Amz-Signature="

# Tighter detector: the marker must appear inside a URL's query string
# (preceded by ``?`` or ``&``) so the planner doesn't false-positive
# when a user submits SQL like ``SELECT 'X-Amz-Signature=foo' AS x``.
# Either ``?X-Amz-Signature=`` (first query param) or ``&X-Amz-Signature=
# `` (subsequent param) is enough -- both forms are produced by every
# boto3 ``generate_presigned_url`` call.
_PRESIGN_MARKER_IN_QUERYSTRING_RE = re.compile(
    r"[?&]X-Amz-Signature=", re.IGNORECASE,
)


# ── Strategy kinds ─────────────────────────────────────────────────────

LOCAL_FILES = "local_files"
NATIVE_S3_SIGNED_BY_DUCKDB = "native_s3_signed_by_duckdb"
PRESIGNED_URLS_IN_SQL = "presigned_urls_in_sql"


@dataclass(frozen=True)
class S3SetupPlan:
    """Plan that drives every S3-setup decision in the DuckDB subprocess
    (and any in-process httpfs caller that opts in).

    Boolean fields are intentionally ORTHOGONAL -- callers should consult
    each field directly without re-deriving "what kind am I in".  The
    ``kind`` and ``reason`` fields are for logging / brain trace only.
    """
    kind: str
    reason: str

    # httpfs extension -- LOAD 'httpfs' or not.
    load_httpfs: bool

    # SET s3_region / s3_access_key_id / s3_secret_access_key /
    # s3_session_token / s3_endpoint -- DuckDB httpfs signs URLs itself.
    set_endpoint_and_credentials: bool

    # SET ca_cert_file (or disable verification) for libcurl HTTPS.
    # True whenever httpfs is loaded -- libcurl needs to validate TLS
    # on the VPCE / S3 endpoint regardless of who signed the URL.
    apply_ssl_bundle: bool

    # Run the on-prem ``_pre_download_presigned`` step that turns
    # ``https://…?X-Amz-Signature=…`` URLs into local temp files via
    # Python urllib.  Only True for LOCAL_FILES.
    predownload_presigned_to_local: bool

    # Allow the proxy / VPC boto3 pre-download fallbacks to fire when
    # the corresponding gates trip.  Only meaningful for
    # NATIVE_S3_SIGNED_BY_DUCKDB -- LOCAL_FILES already pre-downloaded,
    # PRESIGNED_URLS_IN_SQL must NOT pre-download (the URLs would lose
    # their signed-for-VPCE host).
    allow_boto3_predownload_fallback: bool


# ── The READ STRATEGY: (plan, proxy, vpc) -> what DuckDB is handed ──────────
#
# 2026-09-26 (F3 round 5).  The plan says which of three setups applies;
# the DuckDB child then still chose, inline and in three places, whether
# to hand DuckDB the URLs or to pre-download them first -- urllib for a
# LOCAL_FILES plan (on-prem presigned: libcurl HTTP-0 / SSL), boto3 when
# the corporate proxy governs DuckDB's traffic, a presign-rewrite for the
# VPC workaround.  The scheduled S3 road had to make the same choice and
# was making it separately.  ONE function now; the child and the road both
# call it and dispatch on its answer, so "what does DuckDB read" has one
# author.  The strategy names say what is READ and by whom:
READ_LOCAL_PRESIGNED = "local_files_presigned_urllib"   # LOCAL_FILES: urllib-download the presigned URLs
READ_LOCAL_BOTO3 = "local_files_boto3"                  # native + proxy: boto3-download the s3:// objects
READ_HTTPFS_PRESIGNED_IN_SQL = "httpfs_presigned_in_sql"  # SQL already presigned: httpfs, no creds, nothing to do
READ_HTTPFS_PRESIGN_FOR_VPC = "httpfs_presign_for_vpc"    # native + VPC workaround: presign s3:// first, httpfs, no creds
READ_HTTPFS_NATIVE = "httpfs_native"                    # native: httpfs signs s3:// itself
READ_STRATEGIES = (READ_LOCAL_PRESIGNED, READ_LOCAL_BOTO3, READ_HTTPFS_PRESIGNED_IN_SQL,
                   READ_HTTPFS_PRESIGN_FOR_VPC, READ_HTTPFS_NATIVE)


def read_strategy(plan: "S3SetupPlan", *, proxy_applies: bool, vpc_needed: bool) -> str:
    """The one verdict: given the plan and the two gates the child evaluates
    (``core.proxy_utils.duckdb_proxy_applies`` and
    ``core.ssl_config.vpc_httpfs_workaround_needed``), what DuckDB reads.

    Mirrors the child's precedence exactly: a LOCAL_FILES plan always
    pre-downloads its presigned URLs; a PRESIGNED_URLS_IN_SQL plan never
    pre-downloads (the URLs are signed for their host); a native plan
    pre-downloads through boto3 when the proxy applies, presigns for the
    VPC workaround when only that applies, and otherwise lets httpfs sign.
    """
    if plan.predownload_presigned_to_local:
        return READ_LOCAL_PRESIGNED
    if not plan.allow_boto3_predownload_fallback:
        return READ_HTTPFS_PRESIGNED_IN_SQL
    if proxy_applies:
        return READ_LOCAL_BOTO3
    if vpc_needed:
        return READ_HTTPFS_PRESIGN_FOR_VPC
    return READ_HTTPFS_NATIVE


def _sql_has_presigned_marker(*sql_pieces: Optional[str]) -> bool:
    """True if any of the provided SQL strings carries the SigV4 marker
    in a URL query-string position (``?X-Amz-Signature=`` or
    ``&X-Amz-Signature=``).

    Requiring the marker to follow ``?`` or ``&`` rules out false
    positives like ``SELECT 'X-Amz-Signature=foo' AS x`` -- a string
    literal a user could submit in raw SQL.  Real presigned URLs ALWAYS
    have the marker in a query-string position because that's where
    boto3 puts it.
    """
    for piece in sql_pieces:
        if piece and _PRESIGN_MARKER_IN_QUERYSTRING_RE.search(piece):
            return True
    return False


def sql_has_presigned_marker(*sql_pieces: Optional[str]) -> bool:
    """Public alias for ``_sql_has_presigned_marker`` so callers outside
    this module can use the same regex-precise detector instead of the
    fragile substring scan.  Used by ``register_s3_views`` and
    ``federation_engine`` to decide whether to RESET S3 signing on a
    DuckDB connection before query execution.
    """
    return _sql_has_presigned_marker(*sql_pieces)


def _extract_presigned_hosts(sql: Optional[str]) -> set:
    """Extract the set of HTTPS hostnames that appear in presigned URLs
    within ``sql``.  Used by ``reset_s3_signing_on_connection`` to
    SCOPE the DROP SECRET pass -- only secrets whose endpoint matches a
    presigned URL host are dropped, so federation cross-source queries
    that mix native ``s3://`` URLs (per-secret) with VPC-presigned URLs
    (per-secret) only lose the VPC-presigned-side secret.

    Returns an empty set when ``sql`` has no presigned URLs (caller
    interprets as "drop nothing on the secret side").
    """
    if not sql:
        return set()
    # Match the full presigned URL, capture the host.  We deliberately
    # accept any HTTPS URL whose query string carries the SigV4 marker
    # -- works for s3-region.amazonaws.com, vpce-*.amazonaws.com, and
    # on-prem hosts.
    _url_re = re.compile(
        r"https?://([A-Za-z0-9.\-]+)(?:[:/][^'\"\s]*)?\?[^'\"\s]*"
        + SIGV4_PRESIGN_MARKER,
        re.IGNORECASE,
    )
    return {m.group(1).lower() for m in _url_re.finditer(sql)}


def reset_s3_signing_on_connection(
    con, *, sql_context: Optional[str] = None,
) -> bool:
    """RESET ``s3_endpoint`` + S3 credentials AND drop every S3-typed
    DuckDB SECRET on the connection so httpfs doesn't double-sign
    presigned URLs that the caller (or ``register_s3_views``) has
    already embedded into views or inline SQL.  Stamps the connection
    with ``_qs_s3_signing_reset_for_presigned_views`` so connection-
    pool release paths can drop the connection instead of caching it
    in an indeterminate S3-settings state.

    Why drop SECRETs too: ``federation_engine`` creates DuckDB SECRETs
    (``CREATE SECRET s3_conn_<id> (TYPE S3, …)``) instead of, or in
    addition to, the pragma path.  A SECRET scoped to ``s3://bucket``
    can still be matched against ``https://bucket.s3.<region>.amazonaws
    .com/…`` URLs that DuckDB recognises as the same logical S3
    location -- triggering the same double-sign as raw pragmas.
    Dropping every S3 SECRET is the only way to be sure.  The federated
    connection is not pooled (single-use), so the drop has no
    downstream cost.

    Used by:
      * ``duckdb_views._suspend_signing_if_views_contain_presigned_urls``
        (in-process view registration path).
      * ``federation_engine`` (inline ``read_parquet([...])`` SQL after
        ``_s3_urls_to_presigned`` has replaced ``s3://`` URLs).
      * Any future caller that emits presigned URLs into the SQL of
        a connection that previously had ``s3_endpoint`` set OR an
        S3 SECRET defined.

    Best-effort: returns True when at least one RESET or DROP
    succeeded; False on total errors (caller logs if it cares).
    """
    _any_succeeded = False
    for _stmt in (
        "RESET s3_endpoint",
        "RESET s3_access_key_id",
        "RESET s3_secret_access_key",
        "RESET s3_session_token",
    ):
        try:
            con.execute(_stmt)
            _any_succeeded = True
        except Exception:
            # Best-effort -- some DuckDB versions return KeyError for
            # RESET on a setting that was never SET.  Harmless: the
            # setting is already in the desired cleared state.
            pass

    # Drop S3-typed SECRETs so httpfs can't match a presigned URL
    # against a still-defined SECRET scope.  ``duckdb_secrets()`` may
    # not exist on older DuckDB versions -- fail-open.
    #
    # Scoped drop (2026-06-23 audit round 6): when ``sql_context`` is
    # provided, only drop secrets whose endpoint matches a presigned-
    # URL host in the SQL.  Protects federation cross-source queries
    # that mix native ``s3://`` (per-secret) with VPC-presigned URLs
    # (per-secret) -- dropping ALL secrets would break the native side
    # (no creds left to sign s3:// reads).  When ``sql_context`` is
    # None (default), drop all S3 secrets -- safe back-compat for
    # callers that own the entire connection lifecycle (in-process
    # register_s3_views path closes / pool-drops the connection
    # immediately after, so over-broad drops have no downstream cost).
    _presigned_hosts = _extract_presigned_hosts(sql_context)
    _scoped = sql_context is not None and bool(_presigned_hosts)
    try:
        rows = con.execute(
            "SELECT name, secret_string FROM duckdb_secrets() "
            "WHERE LOWER(type) = 's3'"
        ).fetchall()
    except Exception:
        rows = []
    for row in rows:
        try:
            _name = row[0] if row else None
            if not _name:
                continue
            if _scoped:
                # Parse the secret's endpoint from secret_string
                # (format: ``…;endpoint=<host>;…``) and skip the drop
                # if that endpoint doesn't appear among the presigned-
                # URL hosts in the SQL.
                _secret_str = (row[1] if len(row) > 1 else "") or ""
                _ep_match = re.search(
                    r"endpoint=([^;]+)", str(_secret_str),
                    re.IGNORECASE,
                )
                _ep = (_ep_match.group(1).strip().lower()
                       if _ep_match else "")
                if _ep and _ep not in _presigned_hosts:
                    # This secret protects a different host -- leave it
                    # alone so native s3:// reads on its connection
                    # still work.
                    continue
            _safe = str(_name).replace('"', '""')
            con.execute(f'DROP SECRET IF EXISTS "{_safe}"')
            _any_succeeded = True
        except Exception:
            pass

    if _any_succeeded:
        # Stamp via the side-channel registry -- works for raw
        # DuckDBPyConnection (no __dict__) AND wrappers.  See
        # ``mark_connection_reset`` docstring for the round-7 rationale.
        mark_connection_reset(con)
    return _any_succeeded


def plan_s3_setup(
    conn_config: dict,
    setup_sql: Optional[str] = None,
    copy_sql: Optional[str] = None,
) -> S3SetupPlan:
    """Decide how the DuckDB subprocess should configure itself for the
    given connection + SQL payload.  Returns one of the three strategies
    described in the module docstring.

    Detection is content-aware: the SQL strings are scanned for the SigV4
    marker so the planner notices when the parent process has already
    presigned URLs (smart-VPC fast path, on-prem presigned helpers, etc.)
    even though ``conn_config`` says ``access_mode="native"``.  This is
    the strategic generalisation of "the parent presigned the URLs but
    the subprocess didn't know".
    """
    plan = _plan_s3_setup_inner(conn_config, setup_sql, copy_sql)
    # ── 2026-08-03 SHADOW OBSERVER (default OFF, changes nothing) ─────────
    # This is the ONE site both processes already share: the parent calls
    # ``plan_s3_setup`` (duckdb_views.s3_full_copy, multi_worker_dispatcher)
    # and the DuckDB child calls it again from identical inputs.  Wiring the
    # observation here means one edit, not one per downloader.
    #
    # Fail-open without exception: a diagnostic must never be the reason a
    # query fails, so ANY error is logged at debug and the plan is returned
    # unchanged.
    try:
        from core.s3_read_strategy import observe as _rs_observe
        _rs_observe(conn_config, plan, setup_sql, copy_sql)
    except Exception as _rs_exc:
        import logging as _rs_log
        _rs_log.getLogger(__name__).debug(
            "read-strategy shadow observation skipped (non-fatal): %s",
            _rs_exc)
    return plan


def _plan_s3_setup_inner(
    conn_config: dict,
    setup_sql: Optional[str] = None,
    copy_sql: Optional[str] = None,
) -> S3SetupPlan:
    """The unmodified planner body.  Split out so the shadow observer wraps
    it at exactly one place without touching any strategy branch."""
    access_mode = get_s3_access_mode(conn_config)

    if access_mode == "presigned":
        # On-prem presigned mode: parent emits ``https://…?X-Amz-Signature=…``
        # URLs that the SUBPROCESS pre-downloads to local files via Python
        # urllib (libcurl can't reach the on-prem host).  DuckDB then reads
        # native local parquet -- no httpfs, no S3 config.
        return S3SetupPlan(
            kind=LOCAL_FILES,
            reason=(
                "access_mode=presigned -- subprocess will pre-download "
                "presigned URLs via Python urllib and read local files; "
                "httpfs is NOT loaded."
            ),
            load_httpfs=False,
            set_endpoint_and_credentials=False,
            apply_ssl_bundle=False,
            predownload_presigned_to_local=True,
            allow_boto3_predownload_fallback=False,
        )

    if _sql_has_presigned_marker(setup_sql, copy_sql):
        # The parent process (smart-VPC fast path in register_s3_views,
        # or any future caller) already SigV4-signed every URL in the
        # SQL.  httpfs MUST load (we still need HTTPS GETs), but
        # s3_endpoint and credentials MUST NOT be set or libcurl re-signs
        # the URL -> the original signature is invalidated and the
        # request is dropped (HTTP 0 in libcurl land) or rejected (403
        # SignatureDoesNotMatch in S3 land).
        return S3SetupPlan(
            kind=PRESIGNED_URLS_IN_SQL,
            reason=(
                "access_mode=native but SQL already contains presigned "
                "URLs (X-Amz-Signature=) -- httpfs loaded for HTTPS "
                "GETs, s3_endpoint and credentials suppressed to avoid "
                "SigV4 double-signing (HTTP 0 / 403 SignatureDoesNotMatch)."
            ),
            load_httpfs=True,
            set_endpoint_and_credentials=False,
            apply_ssl_bundle=True,
            predownload_presigned_to_local=False,
            allow_boto3_predownload_fallback=False,
        )

    # Default: raw s3:// URLs in SQL, DuckDB httpfs signs requests
    # itself using the credentials and endpoint we hand it.  Proxy /
    # VPC pre-download fallbacks may still kick in further down based
    # on their own gates -- this strategy permits them.
    return S3SetupPlan(
        kind=NATIVE_S3_SIGNED_BY_DUCKDB,
        reason=(
            "access_mode=native + no presigned URLs in SQL -- DuckDB "
            "httpfs signs s3:// URLs itself using configured endpoint "
            "and credentials."
        ),
        load_httpfs=True,
        set_endpoint_and_credentials=True,
        apply_ssl_bundle=True,
        predownload_presigned_to_local=False,
        allow_boto3_predownload_fallback=True,
    )
