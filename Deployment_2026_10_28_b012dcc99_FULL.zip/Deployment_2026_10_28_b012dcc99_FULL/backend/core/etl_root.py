"""Single chokepoint for locating the ETL framework tree.

WHY THIS EXISTS
---------------
The ETL framework (``ETL/steps/…``) lives OUTSIDE ``backend/``, so three
product modules bootstrapped ``sys.path`` themselves before doing
``from steps.X import Y``:

  * ``core/dataflow/stages/etl_bridge.py``
  * ``core/dataflow/stages/sap_decomposed_stages.py``
  * ``core/sap_passthrough.py``

They had THREE DIFFERENT candidate lists, and every one of them led with one
developer's absolute path, ``Path("c:/DEV/outputs/ETL")``:

  * etl_bridge also tried ``parents[5] / "ETL"`` — off by one.  From
    ``backend/core/dataflow/stages/etl_bridge.py`` parents[5] is the repo
    root's GRANDparent (``C:/DEV``), so that fallback resolved to
    ``C:/DEV/ETL`` and has never once matched.  It also had no ``/app/ETL``
    candidate, which is the container path the other two rely on.
  * the two SAP sites had no ``__file__``-relative candidate at all, so off
    ``c:/DEV/outputs`` and outside a container their discovery came down to
    ``Path("./ETL")`` — i.e. whatever the current working directory happened
    to be.

Net effect: on the original dev box everything worked via the hardcoded
literal, and every other checkout fell through to guesses.  Worse than
missing is FOREIGN-BUT-PRESENT — a second checkout at that same absolute
path would be imported silently and the pipeline would run another
environment's step vocabulary while reporting success.

Resolution order here is deliberate:

  1. ``QS_ETL_ROOT`` — the deploy knob.  An operator who says where the tree
     is must win over any guess.
  2. the tree that ships WITH THIS CHECKOUT, derived by walking up from this
     module — correct on any layout and any drive, and it cannot pick up a
     different clone.
  3. ``/app/ETL`` — the container layout.
  4. CWD and its parent — last-resort dev convenience, unchanged from before.

A candidate only wins if it actually contains ``steps/``, so a stale knob or
an empty directory falls through instead of poisoning ``sys.path``.
"""
from __future__ import annotations

import logging
import os
import sys
from pathlib import Path
from typing import Iterable, Optional

logger = logging.getLogger(__name__)

#: Deploy knob.  Set it to the directory that CONTAINS ``steps/``.
ETL_ROOT_ENV = "QS_ETL_ROOT"

#: Marker that proves a candidate really is the ETL tree.
_MARKER = "steps"


def _candidates() -> Iterable[Path]:
    env = os.environ.get(ETL_ROOT_ENV, "").strip()
    if env:
        yield Path(env)

    # This module is <repo>/backend/core/etl_root.py, so the ETL tree that
    # ships with this checkout is a sibling of backend/.  Walk up rather than
    # index a fixed parent — indexing is exactly what was off by one before,
    # and it silently returns a WRONG path instead of failing.
    here = Path(__file__).resolve()
    for parent in here.parents:
        yield parent / "ETL"

    yield Path("/app/ETL")
    yield Path.cwd() / "ETL"
    yield Path.cwd().parent / "ETL"


def find_etl_root(required_file: Optional[str] = None) -> Optional[Path]:
    """Return the ETL tree root, or ``None`` if no candidate qualifies.

    ``required_file`` is an optional path under ``steps/`` (e.g.
    ``"sap_odata_base.py"``) that a caller needs; a candidate missing it is
    skipped, so a partial or unrelated tree cannot satisfy the lookup.
    """
    seen = set()
    for candidate in _candidates():
        try:
            resolved = candidate.resolve()
        except (OSError, ValueError):  # pragma: no cover - exotic paths
            continue
        if resolved in seen:
            continue
        seen.add(resolved)

        steps_dir = resolved / _MARKER
        if not steps_dir.is_dir():
            continue
        if required_file and not (steps_dir / required_file).exists():
            continue
        return resolved
    return None


def ensure_etl_on_path(required_file: Optional[str] = None) -> bool:
    """Put the ETL tree on ``sys.path`` so ``from steps.X import Y`` works.

    Returns True if ``steps`` is importable afterwards (including the case
    where it already was), False if no candidate qualified — callers then
    fail at execute time with a clear "ETL framework not installed" message
    rather than an opaque ImportError.

    2026-08-19 — NO "ALREADY IMPORTABLE" SHORTCUT.  An earlier version
    returned True as soon as ``import steps`` succeeded.  That is not
    sufficient: the ETL step modules import SIBLINGS of ``steps/`` —
    ``sap_odata_download`` does ``from managers... import``, and there are
    ``datasources`` and ``core_libs`` too.  Those resolve only if the ETL
    ROOT itself is on ``sys.path``.  When ``steps`` happened to be importable
    by some other route, the shortcut returned True without ever adding the
    root, and the caller then died on
    ``ModuleNotFoundError: No module named 'managers'`` — an error naming a
    package nobody asked for, from a helper that had just reported success.

    So always resolve the root and put it on the path; the insert is
    idempotent and cheap.  The import check afterwards is the actual verdict.
    """
    root = find_etl_root(required_file)
    if root is None:
        logger.warning(
            "ETL framework not found. Set %s to the directory containing "
            "steps/ (looked at the checkout sibling, /app/ETL and the CWD).",
            ETL_ROOT_ENV,
        )
        return False

    root_str = str(root)
    if root_str not in sys.path:
        sys.path.insert(0, root_str)
        logger.info("ETL framework root added to sys.path: %s", root_str)
    try:
        import steps  # type: ignore  # noqa: F401
        return True
    except ImportError as exc:
        logger.warning(
            "ETL root %s is on sys.path but 'steps' still will not import: %s",
            root_str, exc,
        )
        return False
