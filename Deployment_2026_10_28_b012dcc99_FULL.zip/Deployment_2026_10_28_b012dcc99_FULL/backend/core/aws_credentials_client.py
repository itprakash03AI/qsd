"""Thin Python client for ``POST /api/aws-portal/credentials``.

Designed for ETL batch jobs, Spark applications, and Airflow tasks that need
fresh AWS STS credentials at runtime without re-implementing the JWT portal
handshake. The client caches credentials in memory and only re-fetches when
they are within ``refresh_buffer_seconds`` of expiry, so a long-running job
doesn't hammer the API on every S3 call.

This module is self-contained (depends only on ``requests``) so the file can
be copied verbatim into a Spark job's ``--py-files`` bundle without dragging
in the rest of the QueryStudio backend.

Generic usage (most common — supply AD service credentials directly)
---------------------------------------------------------------------

::

    from core.aws_credentials_client import AwsCredentialsClient

    client = AwsCredentialsClient(
        base_url="http://querystudio-api:8000",
        # Caller authenticates to QueryStudio:
        api_key="sk_live_...",              # or basic_auth=(u, p)
        # AD service credentials the portal will validate:
        ad_username="svc_etl_dev",
        ad_password="...",
        # Portal targeting — optional if config defaults apply:
        portal_base_url="https://awsportal.corp.example",
        role_name="DataReader",
        account_id="123456789012",
    )

    creds = client.get()                    # cached + auto-refreshed
    spark.conf.set("spark.hadoop.fs.s3a.access.key", creds["aws_access_key_id"])
    spark.conf.set("spark.hadoop.fs.s3a.secret.key", creds["aws_secret_access_key"])
    spark.conf.set("spark.hadoop.fs.s3a.session.token", creds["aws_session_token"])

Convenience modes for QueryStudio-internal callers
---------------------------------------------------

When ``ad_username``/``ad_password`` are omitted, ``mode`` selects the
credential source:

  * ``mode="current_user"`` — uses the calling user's vaulted password
  * ``mode="system_account"`` + ``system_account_id=N`` — admin-only
  * ``mode="service"`` — admin-only, config-level service account

::

    # Airflow DAG using a stored system account
    client = AwsCredentialsClient(
        base_url=Variable.get("querystudio_api_url"),
        api_key=Variable.get("querystudio_api_key"),
        mode="system_account",
        system_account_id=int(Variable.get("aws_portal_system_account_id")),
    )
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Any, Dict, Optional, Tuple

import requests

logger = logging.getLogger(__name__)

DEFAULT_REFRESH_BUFFER_SECONDS = 300  # refresh when <5 min left
DEFAULT_TIMEOUT_SECONDS = 15


class AwsCredentialsClient:
    """In-memory-cached client for the AWS credential retrieval endpoint.

    A single instance is thread-safe and intended to be created once per
    process (e.g. at Spark driver startup) and reused across all S3
    interactions.
    """

    def __init__(
        self,
        base_url: str,
        *,
        # QueryStudio authentication (pick ONE)
        api_key: Optional[str] = None,
        basic_auth: Optional[Tuple[str, str]] = None,
        bearer_token: Optional[str] = None,
        # AD credentials for the generic (direct) path
        ad_username: Optional[str] = None,
        ad_password: Optional[str] = None,
        # Explicit mode (only needed for non-direct convenience modes)
        mode: Optional[str] = None,
        system_account_id: Optional[int] = None,
        # AWS portal targeting overrides (config defaults apply when omitted)
        portal_base_url: Optional[str] = None,
        role_name: Optional[str] = None,
        account_id: Optional[str] = None,
        sf_ref_no: Optional[str] = None,
        proxy_url: Optional[str] = None,
        verify_ssl: bool = True,
        timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
        refresh_buffer_seconds: int = DEFAULT_REFRESH_BUFFER_SECONDS,
        request_proxies: Optional[Dict[str, str]] = None,
    ) -> None:
        if not base_url:
            raise ValueError("base_url is required")
        if not (api_key or basic_auth or bearer_token):
            raise ValueError(
                "One of api_key, basic_auth, or bearer_token must be provided"
            )

        self._endpoint = base_url.rstrip("/") + "/api/aws-portal/credentials"
        self._api_key = api_key
        self._basic_auth = basic_auth
        self._bearer_token = bearer_token
        self._mode = mode
        self._ad_username = ad_username
        self._ad_password = ad_password
        self._system_account_id = system_account_id
        self._portal_overrides = {
            k: v for k, v in {
                "portal_base_url": portal_base_url,
                "role_name": role_name,
                "account_id": account_id,
                "sf_ref_no": sf_ref_no,
                "proxy_url": proxy_url,
            }.items() if v
        }
        self._verify_ssl = verify_ssl
        self._timeout = timeout_seconds
        self._refresh_buffer = refresh_buffer_seconds
        self._request_proxies = request_proxies

        self._lock = threading.Lock()
        self._cached: Optional[Dict[str, Any]] = None
        self._cached_at: float = 0.0

    # ── Public API ────────────────────────────────────────────────────────

    def get(self, force_refresh: bool = False) -> Dict[str, Any]:
        """Return STS credentials, fetching fresh ones only when needed.

        Returns the full response dict from the endpoint, including
        ``aws_access_key_id``, ``aws_secret_access_key``,
        ``aws_session_token``, ``expires_at``, ``expiration_iso``,
        ``expires_in_seconds``, ``source``.
        """
        with self._lock:
            if not force_refresh and self._is_fresh():
                return self._cached  # type: ignore[return-value]
            return self._fetch_locked(force_refresh=force_refresh)

    def invalidate(self) -> None:
        """Drop the cached credentials. Next ``get()`` will re-fetch."""
        with self._lock:
            self._cached = None
            self._cached_at = 0.0

    def expires_in_seconds(self) -> int:
        """Seconds remaining on the current cached credentials, or 0."""
        with self._lock:
            if not self._cached:
                return 0
            return max(0, int(self._cached.get("expires_at", 0) - time.time()))

    # ── Internals ─────────────────────────────────────────────────────────

    def _is_fresh(self) -> bool:
        if not self._cached:
            return False
        expires_at = float(self._cached.get("expires_at") or 0)
        if not expires_at:
            return False
        return (expires_at - time.time()) > self._refresh_buffer

    def _fetch_locked(self, force_refresh: bool) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "force_refresh": force_refresh,
            **self._portal_overrides,
        }
        # Server auto-derives mode from request shape when omitted, but
        # forward an explicit mode if the caller pinned one.
        if self._mode:
            payload["mode"] = self._mode
        if self._ad_username and self._ad_password:
            payload["username"] = self._ad_username
            payload["password"] = self._ad_password
        if self._system_account_id is not None:
            payload["system_account_id"] = int(self._system_account_id)

        headers = {"Content-Type": "application/json"}
        auth = None
        if self._api_key:
            headers["X-API-Key"] = self._api_key
        elif self._bearer_token:
            headers["Authorization"] = f"Bearer {self._bearer_token}"
        elif self._basic_auth:
            auth = self._basic_auth

        try:
            resp = requests.post(
                self._endpoint,
                json=payload,
                headers=headers,
                auth=auth,
                verify=self._verify_ssl,
                timeout=self._timeout,
                proxies=self._request_proxies,
            )
        except requests.RequestException as exc:
            raise AwsCredentialsClientError(
                f"AWS credential fetch network error: {exc}"
            ) from exc

        if resp.status_code >= 400:
            body = (resp.text or "")[:500].strip()
            raise AwsCredentialsClientError(
                f"AWS credential fetch failed: HTTP {resp.status_code} {body!r}"
            )

        try:
            data = resp.json()
        except ValueError as exc:
            raise AwsCredentialsClientError(
                f"AWS credential fetch returned non-JSON: {resp.text[:200]!r}"
            ) from exc

        if not data.get("aws_access_key_id"):
            raise AwsCredentialsClientError(
                f"AWS credential response missing aws_access_key_id: {data}"
            )

        self._cached = data
        self._cached_at = time.time()
        expires_in = data.get("expires_in_seconds", 0)
        logger.info(
            "[aws-creds-client] Fetched fresh credentials (mode=%s, source=%s, expires_in=%ds)",
            self._mode, data.get("source", "unknown"), expires_in,
        )
        return data


class AwsCredentialsClientError(RuntimeError):
    """Raised when the credential client cannot fetch fresh credentials."""
    pass
