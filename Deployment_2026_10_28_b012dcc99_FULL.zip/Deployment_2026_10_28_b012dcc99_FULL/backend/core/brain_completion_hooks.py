"""BrainCompletionHooks -- shared chokepoint for Phase 155/156 hooks.

Single helper called from EVERY query-completion site so the brain
learns from BQB / CQB / PV / Feed Gen / Reports / Reconciliation /
SQL connector / cross-source -- not just the original BQB path.

Pre-refactor (2026-06-26) this helper lived in ``api/execute_api.py``
which created a forbidden ``core -> api`` import dependency for
callers like feed_engine.  Moved here so:
  * Layering stays clean (core only depends on core)
  * One implementation, one set of guard rails (engine_meta dict
    coercion, NaN/Inf clamp, fail-OPEN per hook)
  * New surfaces (reconciliation, DataFlow, etc.) can opt in with
    a single import

Fires three hooks, each fail-OPEN independently:
  * Hook 3 -- brain SQL-hash cache (agg_cache.put_cached_result)
  * Hook 4 -- co-access prewarm (brain_prewarm.trigger_after_query)
  * Hook 7 -- route outcome (brain_route_history.record_outcome)
"""
from __future__ import annotations

import logging
import os
import time
from typing import Any, Optional

logger = logging.getLogger(__name__)


def phase156_completion_hooks(
    *,
    raw_sql: Optional[str],
    query_config_dict: Optional[dict],
    output_file_path: Optional[str],
    stats: dict,
    query_t0_monotonic: Optional[float],
    db_manager: Any,
    username: str = "",
) -> None:
    """Fire the three Phase 155/156 brain hooks at query completion.

    Args:
      raw_sql:            the executed SQL.  Required for hooks 3 + 7;
                          empty string disables them.
      query_config_dict:  source of ``_iceberg_snapshot_id`` (memo
                          identity) + ``registered_tables`` (prewarm
                          + route-history bucket/prefix identity).
      output_file_path:   path to the parquet result; hook 3 caches
                          (sql_hash, snapshot) -> file when present.
      stats:              completion stats dict; hook 7 reads engine_meta
                          + total_rows.
      query_t0_monotonic: time.monotonic() at query start; hook 7
                          computes wall-clock EMA.  None -> seconds=0.
      db_manager:         DB session source.  Required for hooks 4 + 7.
      username:           the principal the result belongs to.  Hook 3
                          threads it into put_cached_result so the brain
                          result cache is scoped per principal when
                          row-security is enabled (2026-08-20).  Empty
                          falls back to the request contextvar; with
                          row-security ON and no resolvable principal
                          the cache write is skipped (unknown = unsafe).

    Fail-OPEN at every hook -- any error logs at debug + the other
    hooks still run.  Never raises.
    """
    # 2026-10-08 -- a run the dispatcher SERVED from the brain cache is
    # not a new observation: re-storing it would restart the entry's TTL
    # on every repeat, and its wall-clock says nothing about any engine.
    _served_from_brain_cache = bool((stats or {}).get("from_brain_cache"))

    # Hook 3 -- brain SQL-hash cache.
    try:
        if (raw_sql and output_file_path and os.path.isfile(output_file_path)
                and not _served_from_brain_cache):
            from core.agg_cache import (
                make_sql_hash as _mk_sql_hash,
                put_cached_result as _brain_put,
                brain_snapshot_from_query_config as _brain_snap,
            )
            _sql_hash = _mk_sql_hash(raw_sql)
            # The ONE reader the dispatcher's lookup also uses (2026-10-08):
            # what is stored under is what is looked up with.  Empty = no
            # snapshot known = nothing stored (put_cached_result refuses).
            _snap = _brain_snap(query_config_dict)
            if _sql_hash:
                _brain_put(
                    _sql_hash, _snap, output_file_path,
                    int((stats or {}).get("total_rows", 0) or 0),
                    username=username or None,
                )
    except Exception as exc:
        logger.debug("[brain-cache] write hook skipped: %s", exc)

    # Hook 4 -- co-access prewarm.
    try:
        from core.brain_prewarm import trigger_after_query as _pw_trigger
        _qc_d = query_config_dict if isinstance(query_config_dict, dict) else {}
        for _rt in _qc_d.get("registered_tables") or []:
            if not isinstance(_rt, dict):
                continue
            if _rt.get("format") != "iceberg":
                continue
            _b = _rt.get("bucket") or ""
            _p = (_rt.get("s3_prefix") or "").rstrip("/")
            if _b and _p:
                _pw_trigger(_b, _p, db_manager=db_manager)
    except Exception as exc:
        logger.debug("[brain-prewarm] hook skipped: %s", exc)

    # Hook 7 -- route outcome (wall-clock EMA).
    try:
        if query_t0_monotonic is not None:
            _wall_seconds = max(0.0, time.monotonic() - query_t0_monotonic)
        else:
            _wall_seconds = 0.0
        # engine_meta type safety (Phase 156 R19) -- explicit dict coerce.
        _em_raw = (stats or {}).get("engine_meta")
        _engine_meta = _em_raw if isinstance(_em_raw, dict) else {}
        _engine_picked = str(_engine_meta.get("engine") or "")
        if not _engine_picked:
            if (stats or {}).get("from_multi_worker"):
                _engine_picked = "multi_worker"
            elif (stats or {}).get("from_cache"):
                _engine_picked = "result_cache"
            else:
                _engine_picked = "single"
        if raw_sql and _engine_picked and not _served_from_brain_cache:
            from core.agg_cache import make_sql_hash as _mk_sql_hash_h
            from core.brain_route_history import record_outcome as _ro_rec
            _hist_sql_hash = _mk_sql_hash_h(raw_sql)
            _hist_qc = query_config_dict if isinstance(query_config_dict, dict) else {}
            _hist_bucket = ""
            _hist_prefix = ""
            for _rt in _hist_qc.get("registered_tables") or []:
                if isinstance(_rt, dict) and _rt.get("format") == "iceberg":
                    _hist_bucket = _rt.get("bucket") or ""
                    _hist_prefix = (_rt.get("s3_prefix") or "").rstrip("/")
                    break
            if _hist_sql_hash and _hist_bucket and _hist_prefix:
                _ro_rec(
                    sql_hash=_hist_sql_hash,
                    bucket=_hist_bucket,
                    table_prefix=_hist_prefix,
                    engine=_engine_picked,
                    seconds=_wall_seconds,
                    status="completed",
                    db_manager=db_manager,
                )
    except Exception as exc:
        logger.debug("[brain-route-history] hook skipped: %s", exc)


__all__ = ["phase156_completion_hooks"]
