"""BF-308 — Background-jobs registry.

User asked: "all background jobs should be controlled by admin...admin
can decide...what to run n what to not".

A central registry every long-running asyncio task can register with.
Admin sees the full list + status, can start/stop individual jobs from
the UI, and config flags can disable autostart per job.

Each job has:
  - name (stable identifier, e.g. "iceberg_metadata_sync")
  - description (admin-friendly)
  - factory (() -> coroutine the loop runs)
  - autostart (bool, derived from config)
  - controllable (bool — false for jobs that MUST run, e.g. WS heartbeat)

The registry handles task lifecycle uniformly so each job module doesn't
re-implement start/stop/cancel/restart.

2026-10-08 -- ``running`` IS THE COROUTINE, NOT THE TASK OBJECT.  Found live
in the production topology: the iceberg manifest watcher's loop had never
started on the scheduler pod (its starter put the task on a loop nobody
ran), and this registry listed it ``running: True`` because its shim task
existed.  Every job task is now created through ``core.service_loop.
start_service`` and the job keeps the :class:`~core.service_loop.
ServiceHandle`; ``is_running()`` reads the handle (the coroutine's own
first line sets it), ``to_dict()`` carries its ``liveness`` (started,
last beat, loop running), and a task whose loop is not running reads as
``stopped``.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class BackgroundJob:
    """A single managed background task."""
    name: str
    description: str
    factory: Callable[[], Awaitable[None]]
    autostart: bool = True
    controllable: bool = True
    # Live state (mutated by the runtime; do not persist)
    task: Optional[asyncio.Task] = field(default=None, repr=False)
    started_at: Optional[datetime] = None
    stopped_at: Optional[datetime] = None
    paused_at: Optional[datetime] = None
    paused: bool = False         # admin clicked pause (deliberate, vs crashed)
    last_error: Optional[str] = None
    # R6 (2026-08-03) — supervision: how many times _wrap restarted the
    # factory after a crash, and when the last crash happened.  Surfaced in
    # to_dict so the admin UI / health tooling can spot flapping daemons.
    restart_count: int = 0
    last_crash_at: Optional[datetime] = None
    # True while the job is sleeping in R6 restart backoff.  The task is
    # still alive during that sleep, so this is what distinguishes
    # "crash-looping" from "running" — see status().
    restarting: bool = False
    # 2026-09-01 — a PLACEHOLDER for a daemon owned by a DIFFERENT pod.
    # Registered on every pod that does not run it, so an admin can see and
    # control the whole fleet from whichever pod is serving the admin UI.
    # It never holds a task: `factory` is never called on a remote entry.
    remote: bool = False
    owner: str = ""
    # 2026-10-08 -- the handle ``core.service_loop.start_service`` returned
    # for ``task``: the truth about whether the coroutine STARTED.  None for
    # a task somebody assigned directly (tests stub one); then the legacy
    # "task exists and is not done" answer is all there is.
    handle: Optional[Any] = field(default=None, repr=False)

    def _live_handle(self) -> Optional[Any]:
        h = self.handle
        if h is not None and self.task is not None and h.task is self.task:
            return h
        return None

    def is_running(self) -> bool:
        h = self._live_handle()
        if h is not None:
            return bool(h.is_running())
        return self.task is not None and not self.task.done()

    def liveness(self) -> Optional[Dict[str, Any]]:
        h = self._live_handle()
        return h.snapshot() if h is not None else None

    def status(self) -> str:
        # Check paused FIRST — admin's intent ("I paused this") trumps
        # the transient state where the task is still running between
        # cancel() and the cancellation actually propagating.  If admin
        # said pause, status is paused regardless of task state.
        if self.paused:
            return "paused"
        # Crash-backoff is checked BEFORE is_running(): under R6 supervision
        # the backoff sleep happens inside the task, so the task is alive and
        # is_running() is True while the job is actually crash-looping.
        if getattr(self, "restarting", False):
            return "errored"
        # A placeholder has no local task, so every check below would call it
        # "stopped" — the one answer that is both false and alarming.
        if self.remote:
            return "remote"
        if self.is_running():
            return "running"
        if self.task is None:
            return "stopped"
        if self.task.cancelled():
            return "stopped"
        # A task that never started because its loop is not running (the
        # 2026-10-08 class): pending forever, not completed, not errored.
        h = self._live_handle()
        if h is not None and not h.done():
            return "stopped"
        if self.last_error:
            return "errored"
        try:
            if self.task.exception() is not None:
                return "errored"
        except (asyncio.CancelledError, asyncio.InvalidStateError):
            pass
        return "completed"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name":          self.name,
            "description":   self.description,
            "autostart":     self.autostart,
            "controllable":  self.controllable,
            "running":       self.is_running(),
            "paused":        self.paused,
            "status":        self.status(),
            "started_at":    self.started_at.isoformat() if self.started_at else None,
            "stopped_at":    self.stopped_at.isoformat() if self.stopped_at else None,
            "paused_at":     self.paused_at.isoformat() if self.paused_at else None,
            "last_error":    self.last_error,
            "remote":        self.remote,
            "owner":         self.owner,
            "restart_count": self.restart_count,
            "last_crash_at": self.last_crash_at.isoformat() if self.last_crash_at else None,
            # 2026-10-08 -- the coroutine's own evidence: started, last beat,
            # its loop running.  None for a job with no task of its own.
            "liveness":      self.liveness(),
        }


_jobs: Dict[str, BackgroundJob] = {}
# Lock guards _jobs against concurrent register / autostart / stop_all.
# In production registration only happens at startup, but admin tooling
# + dev autoreload can still race.
import threading as _threading  # noqa: E402
_jobs_lock = _threading.Lock()

# BF-320: persisted pause state
_db_manager = None


#: How often each pod reconciles its LOCAL daemons against the DB pause
#: table.  Matches the _DB_PAUSE_TTL_SECONDS granularity the pause design
#: already promises ("admin Pause clicks now land on every pod within ~5s").
_PAUSE_RECONCILE_INTERVAL_S = 5.0


def _db_paused_all() -> Optional[Dict[str, bool]]:
    """Every job's persisted pause flag in ONE query — ``None`` when the DB
    cannot be read at all.

    Deliberately NOT ``is_paused()``: that returns True as soon as the LOCAL
    flag is set, so it can never report a resume, and it collapses "the DB
    says running" into "I could not ask".  A reconciler that cancels daemons
    must be able to tell those two apart.

    Read in bulk because this runs every few seconds on every pod: per-name
    lookups made it one round trip per daemon per tick, which is ~28 queries
    every 5s buying exactly the same answer.  A missing row means "never
    paused", so absence maps to False rather than to unknown.
    """
    if _db_manager is None:
        return None
    try:
        rows = _db_manager.list_background_job_states() or []
    except Exception as exc:
        logger.debug("background_jobs: pause state unreadable: %s", exc)
        return None
    return {r.get("name"): bool(r.get("paused")) for r in rows}


_READ_DB = object()


def reconcile_pause_state(persisted: Any = _READ_DB) -> Dict[str, str]:
    """Apply admin pause/resume intent, raised on ANY pod, to this pod's own
    daemons.  Returns {name: action} for logs and tests.

    2026-09-01.  Pause was persisted to the DB from the moment it was built,
    but only two daemons of twenty-eight ever read it back
    (``dq_monitor`` and ``within_island_supplement``) — every other daemon
    kept running through an admin Pause and only stopped at the next pod
    restart, because ``autostart_all`` skips paused jobs at boot.  So the
    button reported success and, for 26 daemons, did nothing until a
    restart nobody was going to perform.

    Putting the check inside each daemon's loop would mean editing 26 loops
    and would still miss the 27th.  The cancellation already lives here —
    ``pause()`` cancels the task — so this reconciles the same way, just
    triggered by DB state instead of a local call.  No daemon changes.

    FAIL-OPEN, in one direction only: an unreadable DB row yields ``None``
    and nothing is cancelled.  A monitoring outage must never be able to
    stop the fleet — that failure would look exactly like the daemons
    crashing, at the moment observability is already gone.
    """
    actions: Dict[str, str] = {}
    if _db_manager is None:
        return actions
    # 2026-10-07: ``persisted`` may be handed in already read -- the loop
    # below reads it on a worker thread; the cancel/restart half needs the
    # event loop (it touches the daemons' asyncio tasks) and stays here.
    if persisted is _READ_DB:
        persisted = _db_paused_all()
    if persisted is None:
        return actions          # unreadable: change nothing (see docstring)

    with _jobs_lock:
        candidates = [(j.name, j.paused, j.remote, j.controllable)
                      for j in _jobs.values()]

    to_resume = []
    for name, local_paused, remote, controllable in candidates:
        # Placeholders have nothing to cancel; a non-controllable daemon is
        # declared as "must always run" and admin intent does not override
        # that (the endpoints refuse it too — same rule, one meaning).
        if remote or not controllable:
            continue
        want = persisted.get(name, False)
        if want and not local_paused:
            with _jobs_lock:
                job = _jobs.get(name)
                if job is None or job.paused:
                    continue
                if job.task is not None and not job.task.done():
                    job.task.cancel()
                job.paused = True
                job.paused_at = datetime.now(timezone.utc)
            actions[name] = "paused"
            logger.info("background_jobs: '%s' paused by admin on another "
                        "pod — cancelled here", name)
        elif not want and local_paused:
            to_resume.append(name)

    # start() takes the lock itself, so it is called outside the loop above.
    for name in to_resume:
        try:
            start(name)
            actions[name] = "resumed"
            logger.info("background_jobs: '%s' resumed by admin on another "
                        "pod — restarted here", name)
        except Exception as exc:
            logger.warning("background_jobs: could not resume '%s' after a "
                           "remote resume: %s", name, exc)
    return actions


def _this_pod_id() -> str:
    """A stable identity for this process.  Prefers the pod name the
    orchestrator already assigns, so a row can be traced back to a pod that
    an operator can actually go and look at."""
    import os
    import socket
    for var in ("QS_POD_ID", "POD_NAME", "HOSTNAME"):
        v = os.environ.get(var)
        if v:
            return v[:150]
    try:
        return socket.gethostname()[:150]
    except Exception:
        return f"pid-{os.getpid()}"


#: 2026-09-27 -- daemons THIS process registered at boot that are NOT
#: background_jobs tasks (APScheduler jobs, plain threads).  The scheduler
#: pod's ``daemon_registry.register_scheduler_owned`` records the ones that
#: registered, so its heartbeat carries them.  Before this, 23 scheduler-
#: owned daemons (the retention sweeps, the close-out digest, the SLA
#: scanner, ...) appeared in NO pod's heartbeat and the admin Effective
#: Posture card could only say COULD_NOT_DETERMINE for every one of them.
#:
#: 2026-09-28 -- each value is ``{"how", "running", "status"}``: the singleton
#: gate (daemon_registry.start_when_singleton) records a DEFERRED singleton
#: as not running, so a non-leader's heartbeat says "deferred" where the
#: leader's says "registered" and the card shows one runner, not two.
_boot_registered: Dict[str, Dict[str, Any]] = {}

#: the feed-gate APScheduler job ids (core/scheduler.py), reported by the
#: lock holder when present -- same ids as effective_posture.FEED_JOB_IDS.
FEED_GATE_JOB_IDS = ("__feed_sod_generator__", "__feed_queue_worker__",
                     "__feed_sla_tracker__", "__feed_etl_dep_poller__")


def record_boot_registrations(names, how: str, *, running: bool = True,
                              status: Optional[str] = None) -> None:
    """Remember daemons registered in this process outside ``register``.

    ``running=False`` records a first-hand "NOT running here" -- a deferred
    or declined singleton -- which is a different fact from silence: the
    Effective Posture card renders silence as COULD_NOT_DETERMINE and this
    as off/deferred, naming the pod.  ``status`` is the word shown; it
    defaults to ``registered`` (live) or ``not running``.
    """
    with _jobs_lock:
        for n in names:
            if n:
                _boot_registered[str(n)] = {
                    "how": how, "running": bool(running),
                    "status": status or ("registered" if running
                                         else "not running")}


def _boot_registered_reports(exclude) -> List[Dict[str, Any]]:
    """Heartbeat entries for the boot registrations.  A job whose APScheduler
    id equals the daemon name is checked live (paused = no next run); the
    whole scheduler paused (maintenance window) pauses every entry.  Anything
    else reports what is known first-hand: registered at boot, by a process
    whose heartbeat is itself the evidence it is still alive."""
    with _jobs_lock:
        boot = dict(_boot_registered)
    # The feed gates are APScheduler jobs visible only in the lock holder's
    # in-memory jobstore: the holder reports the ones it has, by job id.
    try:
        from core.scheduler import _this_process_runs_apscheduler
        if _this_process_runs_apscheduler():
            for jid in FEED_GATE_JOB_IDS:
                boot.setdefault(jid, {
                    "how": "APScheduler job on the scheduler lock holder",
                    "running": True, "status": None})
    except Exception:
        pass
    if not boot:
        return []
    sch = None
    try:
        from core.scheduler import get_scheduler
        sch = get_scheduler()
    except Exception:
        sch = None
    try:
        from apscheduler.schedulers.base import STATE_PAUSED
        sched_paused = sch is not None and getattr(sch, "state", None) == STATE_PAUSED
    except Exception:
        sched_paused = False
    out: List[Dict[str, Any]] = []
    for name, rec in sorted(boot.items()):
        if name in exclude:
            continue
        row = _boot_report_row(name, rec, sch, sched_paused)
        if row is not None:
            out.append(row)
    return out


def _boot_report_row(name: str, rec: Dict[str, Any], sch,
                     sched_paused: bool) -> Optional[Dict[str, Any]]:
    """One heartbeat row for a boot registration, or None for a feed gate
    this process's APScheduler does not hold."""
    job = None
    if sch is not None:
        try:
            job = sch.get_job(name)
        except Exception:
            job = None
    if name in FEED_GATE_JOB_IDS and job is None:
        return None       # a gate that is not registered here reports nothing
    paused = bool(sched_paused or (job is not None
                                   and getattr(job, "next_run_time", 1) is None))
    live = bool(rec.get("running", True))
    if paused:
        status = "paused"
    elif not live:
        status = rec.get("status") or "not running"
    elif job is not None:
        status = "scheduled"
    else:
        status = rec.get("status") or "registered"
    return {"name": name, "description": rec.get("how"),
            "running": live and not paused, "paused": paused,
            "status": status, "restart_count": 0, "last_error": None}


def publish_heartbeat() -> int:
    """Report this pod's OWN daemons so other pods can see them.

    Placeholders are excluded deliberately.  A placeholder knows nothing
    about the daemon it stands for, and a row from it would compete with
    the first-hand report from the pod that actually runs it — the reader
    would have no way to tell which was the observation.

    Best-effort by design: a heartbeat that could break a daemon would be
    worse than no heartbeat.  Failures are logged at debug because this
    runs every few seconds and a DB blip must not fill the log.
    """
    if _db_manager is None:
        return 0
    with _jobs_lock:
        mine = [j.to_dict() for j in _jobs.values() if not j.remote]
    mine += _boot_registered_reports({j["name"] for j in mine})
    if not mine:
        return 0
    try:
        from core.pod_role import current as _pod_current
        role = str(_pod_current().role)
    except Exception:
        role = "unknown"
    try:
        return int(_db_manager.record_daemon_heartbeat(
            _this_pod_id(), role, mine) or 0)
    except Exception as exc:
        logger.debug("background_jobs: heartbeat write failed: %s", exc)
        return 0


async def _pause_reconciler() -> None:
    """The loop behind reconcile_pause_state.  Registered on every pod that
    wires persistence, and non-controllable — a job that could pause the
    reconciler could never be resumed, because the reconciler is what
    delivers the resume."""
    # 2026-10-07: both DB round trips (the pause read, the heartbeat write)
    # run on a worker thread.  Every 5 s on EVERY pod they ran inline on the
    # event loop -- measured in-process among the loop-stall samples under
    # query load, where a pool checkout can wait seconds.
    while True:
        await asyncio.sleep(_PAUSE_RECONCILE_INTERVAL_S)
        try:
            _persisted = (await asyncio.to_thread(_db_paused_all)
                          if _db_manager is not None else None)
            reconcile_pause_state(_persisted)
        except Exception as exc:      # pragma: no cover - defensive
            logger.warning("background_jobs: pause reconcile failed "
                           "(will retry): %s", exc)
        # Published AFTER reconciling, so the row reflects the state an
        # admin's click just produced rather than the one it replaced.
        try:
            await asyncio.to_thread(publish_heartbeat)
        except Exception as exc:      # pragma: no cover - defensive
            logger.debug("background_jobs: heartbeat failed: %s", exc)


def init_persistence(db_manager) -> None:
    """Wire the DB manager so paused state survives pod restarts.
    Called once from main.py at startup, before autostart_all()."""
    global _db_manager
    _db_manager = db_manager
    # Every pod that persists pause state also has to OBEY it — see
    # reconcile_pause_state.  Registered here rather than in
    # daemon_registry because that table is the scheduler pod's boot list,
    # and this has to run wherever daemons run.
    #
    # Registering while one is already running would leave BOTH polling:
    # ``register`` replaces the entry but deliberately does not cancel the
    # task (its docstring says so), so the old one becomes unreachable and
    # immortal.  Production calls this once per process, but a re-entry —
    # dev autoreload, or a test that builds several apps — would otherwise
    # accumulate pollers that nothing can stop.
    existing = get_job("pause_reconciler")
    if existing is not None and existing.is_running():
        return
    register("pause_reconciler",
             "Applies admin pause/resume raised on any pod, and publishes "
             "this pod's daemon heartbeats",
             _pause_reconciler, autostart=True, controllable=False)


def register(name: str, description: str, factory: Callable[[], Awaitable[None]],
              autostart: bool = True, controllable: bool = True) -> BackgroundJob:
    """Register a background job.  Idempotent — re-registering with the
    same name overwrites the prior entry (the running task, if any, is
    NOT cancelled — call stop() first)."""
    with _jobs_lock:
        if name in _jobs and _jobs[name].is_running():
            logger.warning("background_jobs: re-registering '%s' while it's still running", name)
        job = BackgroundJob(name=name, description=description, factory=factory,
                             autostart=autostart, controllable=controllable)
        _jobs[name] = job
        return job


async def _never_runs_here() -> None:  # pragma: no cover - defensive
    raise RuntimeError("remote placeholder factory must never be started")


def register_remote(name: str, description: str, owner: str) -> BackgroundJob:
    """Declare a daemon that runs on ANOTHER pod, so this pod can show and
    control it.

    2026-09-01, from testing: "why i dont see all other background jobs...
    iceberg manifest watcher" and "they should run under background pods but
    can be managed from admin ui".

    Both halves were broken, and the second is the worse one.  ``_jobs`` is a
    module-level dict, so it holds only the daemons registered in THIS
    process.  The daemons run on the scheduler/worker pod; the admin UI is
    served by the API pod.  So the list came back empty AND every control
    endpoint raised ``KeyError`` -> 404 "unknown job" for exactly the core
    daemons an operator needs to manage.

    The cross-pod design was already half-built: ``is_paused`` reads a
    DB-backed table precisely so a pause can reach another pod, and its
    docstring says "the API pod has placeholder entries".  Nothing ever
    created one — the mechanism was described and never written.  This is
    that missing half, not a new design.

    A placeholder is deliberately inert: no task, no autostart, and a factory
    that raises if anything ever tries to run it.  It exists to be listed and
    to carry admin intent into the DB, where the owning pod picks it up.
    """
    with _jobs_lock:
        existing = _jobs.get(name)
        # Never let a placeholder displace the real thing: on the owning pod
        # the daemon registers for real, and that entry always wins.
        if existing is not None and not existing.remote:
            return existing
        job = BackgroundJob(name=name, description=description,
                            factory=_never_runs_here, autostart=False,
                            controllable=True, remote=True, owner=owner)
        _jobs[name] = job
        return job


def list_jobs() -> List[Dict[str, Any]]:
    """Return all registered jobs with current status."""
    with _jobs_lock:
        return [j.to_dict() for j in _jobs.values()]


_DB_PAUSE_CACHE: Dict[str, "tuple[float, bool]"] = {}
_DB_PAUSE_TTL_SECONDS = 5.0  # short enough that admin Pause/Resume
# clicks land within ~5s on every pod's next tick; long enough that
# daemons calling is_paused() in hot loops don't hammer the DB.


def is_paused(name: str) -> bool:
    """2026-06-24 -- True when admin has paused the job via the
    admin UI / pause() endpoint.  Used by APScheduler-backed
    daemons whose ``_tick`` should short-circuit on pause without
    relying on task cancellation (those daemons register with
    ``factory=lambda: None`` because the underlying scheduler is
    APScheduler, not asyncio; ``pause()`` can't cancel an
    APScheduler tick from the registry-task side).

    Returns False for unknown / unregistered names so callers
    never block on a typo.

    Phase 154 (2026-06-25) -- cross-pod pause propagation.  In
    split-pod (scheduler.mode=external) deployments, the API pod
    has placeholder entries + writes pause state to the DB via
    set_background_job_paused.  The SCHEDULER pod's _jobs[name].
    paused starts False and stayed False because nothing on the
    scheduler pod re-read the DB after startup -- daemons kept
    running through admin Pause clicks.

    Fix: is_paused() also consults the DB-backed BackgroundJobState
    table.  Short (5s) per-name cache so daemons calling is_paused()
    in hot loops don't hammer the DB.  True is returned when EITHER
    the local in-memory flag OR the DB row says paused.  Admin
    Pause clicks now land on every pod within ~5s.
    """
    with _jobs_lock:
        job = _jobs.get(name)
        local_paused = bool(getattr(job, "paused", False)) if job is not None else False

    if local_paused:
        return True

    # DB-backed cross-pod check (cached).
    if _db_manager is None:
        return local_paused
    now = time.time()
    entry = _DB_PAUSE_CACHE.get(name)
    if entry is not None and (now - entry[0]) < _DB_PAUSE_TTL_SECONDS:
        return entry[1]
    db_paused = False
    try:
        state = _db_manager.get_background_job_state(name)
        if state and state.get("paused"):
            db_paused = True
    except Exception:
        # Fail-OPEN to local state: a DB lookup failure must NOT
        # silently pause every daemon.  Local in-memory flag stands.
        db_paused = local_paused
    _DB_PAUSE_CACHE[name] = (now, db_paused)
    return db_paused


def invalidate_db_pause_cache(name: Optional[str] = None) -> None:
    """Drop cached DB pause state -- called after pause()/resume() so
    the LOCAL pod sees its own action immediately (without waiting
    for the 5s TTL)."""
    if name is None:
        _DB_PAUSE_CACHE.clear()
    else:
        _DB_PAUSE_CACHE.pop(name, None)


def get_job(name: str) -> Optional[BackgroundJob]:
    with _jobs_lock:
        return _jobs.get(name)


def _reset_for_start(job: BackgroundJob) -> None:
    """Caller is starting this job — reset transient state."""
    job.started_at = datetime.now(timezone.utc)
    job.stopped_at = None
    job.paused_at = None
    job.paused = False
    job.last_error = None


def _launch(job: BackgroundJob, loop: asyncio.AbstractEventLoop) -> None:
    """Create the job's supervised task through THE one starter
    (``core.service_loop.start_service``) and keep its handle, so
    ``running`` is the coroutine's own first line and not the task
    object's existence."""
    from core.service_loop import start_service
    handle = start_service(job.name, lambda: _wrap(job), loop=loop,
                           task_name=f"background_job:{job.name}")
    job.handle = handle
    job.task = handle.task


def start(name: str) -> Dict[str, Any]:
    """Start a job by name.  Returns its updated status dict.

    Resume semantics: if the job is in paused state (admin paused but
    cancellation may not yet have propagated, so task may still appear
    running), this clears the paused flag.  The previous task is
    cancelled if needed; a fresh task is created.
    """
    with _jobs_lock:
        job = _jobs.get(name)
        if job is None:
            raise KeyError(f"background job '{name}' is not registered")
        if not job.controllable:
            raise PermissionError(f"background job '{name}' is non-controllable (must always run)")
        # Starting a placeholder locally would run the daemon on the WRONG
        # pod — two copies of a singleton.  Clearing the pause flag is the
        # whole of the local work; the DB write in resume() is what actually
        # reaches the owner.
        if job.remote:
            _reset_for_start(job)
            logger.info("background_jobs: cleared pause for remote '%s' "
                        "(owner: %s) — the owning pod resumes it", name,
                        job.owner)
            return job.to_dict()
        # Already-running, NOT paused → noop (idempotent start)
        if job.is_running() and not job.paused:
            return job.to_dict()
        # If paused, ensure the previous task is cancelled before
        # creating a fresh one (avoids two tasks running simultaneously)
        if job.task is not None and not job.task.done():
            job.task.cancel()
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            raise RuntimeError("no running asyncio loop — start() must be called from async context")
        _launch(job, loop)
        _reset_for_start(job)   # clears paused, last_error, stopped_at
        logger.info("background_jobs: started '%s'", name)
        return job.to_dict()


def stop(name: str) -> Dict[str, Any]:
    """Cancel a running job.  Returns its updated status dict.

    Use this for "stopped because we don't want it now" (status=stopped).
    For "I want to resume later from the same place" use pause() instead.
    """
    with _jobs_lock:
        job = _jobs.get(name)
        if job is None:
            raise KeyError(f"background job '{name}' is not registered")
        if not job.controllable:
            raise PermissionError(f"background job '{name}' is non-controllable")
        # Stop means "cancel the task NOW", and a cancellation cannot be sent
        # to another process.  Pause CAN cross pods (it is persisted, and the
        # owner reconciles against it), so point there rather than accepting
        # the click and doing nothing — a control that silently no-ops is
        # worse than one that refuses.
        if job.remote:
            raise PermissionError(
                f"background job '{name}' runs on the {job.owner}; stop "
                f"cannot be delivered across pods. Use pause, which is "
                f"persisted and takes effect on the owning pod within ~5s.")
        if job.task is not None and not job.task.done():
            job.task.cancel()
            job.stopped_at = datetime.now(timezone.utc)
            logger.info("background_jobs: cancelled '%s'", name)
        # Clear paused flag so a subsequent stop after pause leaves the
        # job in a clean "stopped" state, not lingering "paused".
        job.paused = False
        job.paused_at = None
        return job.to_dict()


def pause(name: str, paused_by: Optional[str] = None) -> Dict[str, Any]:
    """Admin-deliberate pause — cancels the running task AND marks the
    job as paused.  Distinct from stop() so admins can tell at a glance
    whether a job was paused on purpose or stopped by failure.

    BF-320: also persists to DB so the paused state survives pod restart.
    autostart_all() reads the persisted state and skips paused jobs.

    Resume with ``start()`` (or the explicit ``resume()`` alias) which
    re-creates the task and clears the paused flag.
    """
    with _jobs_lock:
        job = _jobs.get(name)
        if job is None:
            raise KeyError(f"background job '{name}' is not registered")
        if not job.controllable:
            raise PermissionError(f"background job '{name}' is non-controllable")
        if not job.remote and job.task is not None and not job.task.done():
            job.task.cancel()
        job.paused = True
        job.paused_at = datetime.now(timezone.utc)
        logger.info("background_jobs: paused '%s'", name)
    # Persist OUTSIDE the lock so DB I/O doesn't block other ops
    if _db_manager is not None:
        try:
            _db_manager.set_background_job_paused(name, True, paused_by)
        except Exception as exc:
            logger.warning("background_jobs: pause persist failed for '%s': %s",
                            name, exc)
    # Phase 154 -- drop DB pause cache so the LOCAL pod sees the
    # new state on its next is_paused() call (without waiting for
    # the 5s TTL).  OTHER pods still get the eventual-consistent
    # 5s-TTL view, which is the design.
    invalidate_db_pause_cache(name)
    return job.to_dict()


def resume(name: str) -> Dict[str, Any]:
    """Resume a paused job — alias for start().  Cleaner verb in admin UI.
    BF-320: also clears the persisted pause state."""
    out = start(name)
    if _db_manager is not None:
        try:
            _db_manager.set_background_job_paused(name, False)
        except Exception as exc:
            logger.warning("background_jobs: resume persist failed for '%s': %s",
                            name, exc)
    # Phase 154 cross-pod cache invalidation (see pause() comment).
    invalidate_db_pause_cache(name)
    return out


# R6 (2026-08-03) — supervision constants.  Module-level so tests (and,
# in a pinch, operators via monkeypatch) can shrink them.
_RESTART_BACKOFF_INITIAL_S = 5.0
_RESTART_BACKOFF_MAX_S = 300.0
# A factory that ran at least this long before crashing is considered to
# have been healthy — the next crash restarts from the initial backoff
# instead of continuing to double.
_RESTART_BACKOFF_RESET_AFTER_S = 600.0


async def _wrap(job: BackgroundJob) -> None:
    """Run the job's factory with error capture so the job's status
    reflects whether it crashed or was cancelled.

    BF-310-fix: on a regular (non-cancel) exception we record last_error
    and DO NOT re-raise.  Re-raising leaves the task in an "exception
    was never retrieved" state — asyncio prints a noisy warning at GC.
    Cancellation is re-raised so cancellation propagates correctly.

    2026-06-24 -- factory may return None for daemons whose heartbeat
    is owned by APScheduler / a separate asyncio loop (the registry
    entry exists only for admin visibility + pause-state).  Skip the
    await in that case so we don't raise ``TypeError: object NoneType
    can't be used in await`` and trash the registration -- which used
    to take out both the watcher AND every other shim-registered
    daemon (bloom scanner, mirror daemons, prewarmer, etc.) and made
    them invisible in the admin UI.

    R6 (2026-08-03) — SUPERVISION.  Previously a daemon that raised was
    marked "errored" and NEVER ran again: no watchdog, no restart, no
    health integration — visible only if an admin happened to open the
    jobs UI.  Every registry daemon now restarts with exponential
    backoff (5 s doubling to 300 s cap, reset after a 10-minute healthy
    run).  A factory that RETURNS normally is a completed one-shot and
    is NOT restarted; cancellation (stop/pause/shutdown) still exits
    immediately.  ``restart_count`` / ``last_crash_at`` are surfaced in
    to_dict for the admin UI.
    """
    backoff = _RESTART_BACKOFF_INITIAL_S
    while True:
        run_started = time.monotonic()
        # Cleared here, set in the except arm below: a job sitting in restart
        # backoff still has a LIVE asyncio task (the backoff sleep is inside
        # it), so is_running() is True and status() would report "running"
        # for a job that is actually crash-looping.  R6's supervision is a
        # good change, but it must not make a broken daemon look healthy in
        # the admin UI -- that is the false-healthy pattern this codebase
        # keeps having to undo.  Cleared on each new attempt so a job that
        # crashed once and recovered reports "running" again, not "errored"
        # forever.
        job.restarting = False
        try:
            result = job.factory()
            if result is None:
                # Shim registration (APScheduler / asyncio loop owns the
                # actual heartbeat).  Sit idle so the admin UI shows the
                # task as "running" (paused-state still respected because
                # the underlying tick checks ``is_paused``).  CancelledError
                # propagates correctly so stop()/pause() still cancel.
                while True:
                    await asyncio.sleep(3600)
            else:
                await result
            return   # normal completion — one-shot job, do not restart
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            job.last_error = f"{type(exc).__name__}: {exc}"[:500]
            job.last_crash_at = datetime.now(timezone.utc)
            if (time.monotonic() - run_started) >= _RESTART_BACKOFF_RESET_AFTER_S:
                backoff = _RESTART_BACKOFF_INITIAL_S
            job.restart_count += 1
            job.restarting = True
            logger.warning(
                "background_jobs '%s' crashed (restart #%d in %.0fs): %s",
                job.name, job.restart_count, backoff, exc, exc_info=True,
            )
        # Backoff INSIDE the task: stop()/pause() cancel() lands here as
        # CancelledError and exits cleanly; admin pause during backoff is
        # honoured without polling.
        await asyncio.sleep(backoff)
        backoff = min(backoff * 2, _RESTART_BACKOFF_MAX_S)


def autostart_all() -> int:
    """Called from FastAPI startup — kicks off every job whose autostart
    flag is True AND that wasn't paused by an admin.  Returns count started.

    BF-320: paused state is loaded from DB before deciding what to start,
    so admin pauses survive pod restarts.
    """
    started = 0
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        logger.warning("background_jobs.autostart_all: no running loop")
        return 0

    # Load persisted pause states first (BF-320)
    persisted_paused: set = set()
    if _db_manager is not None:
        try:
            for state in _db_manager.list_background_job_states():
                if state.get("paused"):
                    persisted_paused.add(state["name"])
        except Exception as exc:
            logger.warning("background_jobs: pause-state load failed: %s", exc)

    with _jobs_lock:
        for job in _jobs.values():
            # Apply persisted pause state on first sight after restart
            if job.name in persisted_paused and not job.paused:
                job.paused = True
                logger.info("background_jobs: '%s' restored as paused (DB)", job.name)
            if not job.autostart or job.is_running() or job.paused:
                continue
            _launch(job, loop)
            _reset_for_start(job)
            started += 1
    if started:
        logger.info("background_jobs: autostarted %d job(s) (skipped %d paused)",
                     started, len(persisted_paused))
    return started


def stop_all(reason: str = "shutdown") -> int:
    """Cancel every running job — called from FastAPI shutdown."""
    n = 0
    with _jobs_lock:
        for job in _jobs.values():
            if job.task is not None and not job.task.done():
                job.task.cancel()
                n += 1
    if n:
        logger.info("background_jobs: cancelled %d job(s) on %s", n, reason)
    return n
