"""Phase N (2026-06-08) — ScanPlan / PruneContext.

Single object that owns the full pruning decision chain for ONE query
across ALL its iceberg tables.  Replaces the scattered logic that
previously lived across duckdb_views, iceberg_reader,
iceberg_db_first_reader, join_pruner.

Why one object
==============

Pre-Phase-N every gate (partition prune, manifest stats, supplement,
join probe, self-heal) made its own decision and emitted its own log
line.  Tracing "why did my query scan 1313 files instead of 200?"
required grepping 6 modules.  Operators had no single source of truth.

Phase N: one ``PruneContext`` per execution.  One ``TableScanPlan``
per iceberg table.  Every gate appends a ``Decision`` so the plan
itself records what happened.  The plan persists to DB at end of
query via ``persist()`` so the admin UI can render the full trail
without log scraping.

Architecture
============

::

  PruneContext (per query, per execution_id)
    ├── tables: List[TableScanPlan]
    │     ├── connection_id, bucket, table_prefix
    │     ├── partition_spec  (column -> iceberg type, transform-aware)
    │     ├── iceberg_field_types
    │     ├── filters_received:    List[BrainFilter]
    │     ├── filters_classified:  classification per filter
    │     ├── files_before:        int
    │     ├── files_after_partition:   int
    │     ├── files_after_stats:       int
    │     ├── files_after_supplement:  int
    │     ├── files_after_join_probe:  int
    │     ├── files_final:             int
    │     ├── decisions: List[Decision]   (every gate)
    │     ├── needs_self_heal: List[str]  (columns lacking bounds)
    │     └── pruning_source: L1_cache | L2_db_first | L3_manifest
    ├── joins: List[JoinPlan]
    │     ├── anchor / target / column
    │     ├── bounds_required / available
    │     └── synthesized_filter: Optional[BrainFilter]
    └── execution_id

Decisions are append-only with structured shape (gate, action, reason,
counts) so we can compute per-gate prune attribution AND surface to
the UI as a flow diagram.

Integration
===========

Existing code paths (setup_registered_views, iceberg_reader) can
gradually migrate.  Phase N provides:

  * ``PruneContext.from_legacy_inputs(...)``  -- builds a plan from
    the inputs setup_registered_views already has (partition_filters,
    registered_tables, raw_sql, ...).  Adapter for current callers.

  * ``PruneContext.materialize_table(table_name, ...)``  -- builds
    the per-table file list, applying all pruning stages on the way
    and recording each Decision.

  * ``PruneContext.persist(db_manager)``  -- writes the full plan to
    the diagnostic store.

Phase R will eventually delete the parallel logic in iceberg_reader /
duckdb_views once PruneContext is proven to handle every case.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from .filter import (
    BrainFilter, FilterSource, from_legacy_dict_list,
)


logger = logging.getLogger(__name__)


# ── Decision types ──────────────────────────────────────────────────


class DecisionGate(str, Enum):
    """Pruning stage that produced the decision."""
    PARTITION_RESOLVE   = "partition_resolve"
    FILTER_EXTRACT      = "filter_extract"
    FILTER_PROPAGATE    = "filter_propagate"
    PARTITION_PRUNE     = "partition_prune"
    COLUMN_STATS_PRUNE  = "column_stats_prune"
    SUPPLEMENT_PRUNE    = "supplement_prune"
    JOIN_PROBE          = "join_probe"
    SELF_HEAL           = "self_heal"
    BLOOM_PRUNE         = "bloom_prune"


class DecisionAction(str, Enum):
    """What the gate did."""
    ENGAGED     = "engaged"      # gate ran and pruned files
    NO_OP       = "no_op"        # gate ran but didn't prune anything
    SKIPPED     = "skipped"      # gate didn't run (gate condition false)
    FAILED      = "failed"       # gate raised an exception (fail-OPEN)
    HEALED      = "healed"       # self-heal triggered and succeeded
    HEAL_FAIL   = "heal_failed"  # self-heal triggered and failed


class PruningSource(str, Enum):
    """Which cache layer satisfied the read."""
    L1_CACHE       = "l1_cache"
    L2_DB_FIRST    = "l2_db_first"
    L3_MANIFEST    = "l3_manifest"
    UNKNOWN        = "unknown"


@dataclass
class Decision:
    """One gate's outcome.  Append-only on TableScanPlan.decisions."""
    gate:        DecisionGate
    action:      DecisionAction
    reason:      str
    files_before: int = 0
    files_after:  int = 0
    columns:     List[str] = field(default_factory=list)
    elapsed_ms:  float = 0.0
    extra:       Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "gate":         self.gate.value,
            "action":       self.action.value,
            "reason":       self.reason,
            "files_before": self.files_before,
            "files_after":  self.files_after,
            "files_dropped": self.files_before - self.files_after,
            "columns":      self.columns,
            "elapsed_ms":   round(self.elapsed_ms, 2),
            "extra":        self.extra,
        }


# ── JoinPlan ─────────────────────────────────────────────────────────


@dataclass
class JoinPlan:
    """One JOIN edge planned by the brain.  Used to drive bounds
    aggregation on anchor and synth-filter injection into target."""
    anchor_table:    str       # lowercase real table name
    anchor_col:      str
    target_table:    str
    target_col:      str
    bounds_required: bool = True
    bounds_available: bool = False
    synthesized_filter: Optional[BrainFilter] = None
    notes:           List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "anchor": f"{self.anchor_table}.{self.anchor_col}",
            "target": f"{self.target_table}.{self.target_col}",
            "bounds_required":   self.bounds_required,
            "bounds_available":  self.bounds_available,
            "synthesized_filter": (
                self.synthesized_filter.to_legacy_dict_with_table()
                if self.synthesized_filter else None
            ),
            "notes":             self.notes,
        }


# ── TableScanPlan ────────────────────────────────────────────────────


@dataclass
class TableScanPlan:
    """One iceberg table's complete pruning plan + outcome."""
    table_name:           str
    connection_id:        Optional[int]
    bucket:               str
    table_prefix:         str
    snapshot_id:          Optional[str] = None

    # Resolution
    partition_columns:    List[str] = field(default_factory=list)
    iceberg_field_types:  Dict[str, str] = field(default_factory=dict)

    # Filters (Phase M shape)
    filters_received:     List[BrainFilter] = field(default_factory=list)

    # File counts at each stage
    files_before:             int = 0
    files_after_partition:    int = 0
    files_after_stats:        int = 0
    files_after_supplement:   int = 0
    files_after_join_probe:   int = 0
    files_final:              int = 0

    # Decisions
    decisions:            List[Decision] = field(default_factory=list)
    needs_self_heal:      List[str] = field(default_factory=list)
    pruning_source:       PruningSource = PruningSource.UNKNOWN

    # Phase 150 — mirror routing decision after pruning.  None when no
    # mirror exists for this snapshot OR routing is disabled OR the
    # query falls below the big_query_min_files threshold.  Surfaces as
    # the "served from mirror" chip in the diagnose UI.
    mirror_decision:      Optional[Dict[str, Any]] = None

    elapsed_ms:           float = 0.0

    def record(self, decision: Decision) -> None:
        self.decisions.append(decision)
        logger.info(
            "[scan_plan] %s gate=%s action=%s files=%d->%d reason=%s",
            self.table_name, decision.gate.value, decision.action.value,
            decision.files_before, decision.files_after, decision.reason,
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "table_name":        self.table_name,
            "connection_id":     self.connection_id,
            "bucket":            self.bucket,
            "table_prefix":      self.table_prefix,
            "snapshot_id":       self.snapshot_id,
            "partition_columns": self.partition_columns,
            "iceberg_field_types": self.iceberg_field_types,
            "filters_received":  [f.to_legacy_dict_with_table()
                                  for f in self.filters_received],
            "files_before":            self.files_before,
            "files_after_partition":   self.files_after_partition,
            "files_after_stats":       self.files_after_stats,
            "files_after_supplement":  self.files_after_supplement,
            "files_after_join_probe":  self.files_after_join_probe,
            "files_final":             self.files_final,
            "decisions":         [d.to_dict() for d in self.decisions],
            "needs_self_heal":   self.needs_self_heal,
            "pruning_source":    self.pruning_source.value,
            "mirror_decision":   self.mirror_decision,
            "elapsed_ms":        round(self.elapsed_ms, 2),
        }


# ── PruneContext ─────────────────────────────────────────────────────


@dataclass
class PruneContext:
    """Top-level plan owning all per-table plans + cross-table joins
    for ONE query (one execution_id)."""
    execution_id:   str
    raw_sql:        Optional[str] = None
    tables:         List[TableScanPlan] = field(default_factory=list)
    joins:          List[JoinPlan] = field(default_factory=list)
    created_at:     datetime = field(
        default_factory=lambda: datetime.now(timezone.utc))
    completed_at:   Optional[datetime] = None

    # Aggregate roll-up (populated at finalize())
    total_files_before:  int = 0
    total_files_after:   int = 0

    def add_table(self, plan: TableScanPlan) -> None:
        self.tables.append(plan)

    def add_join(self, plan: JoinPlan) -> None:
        self.joins.append(plan)

    def find_table(self, name: str) -> Optional[TableScanPlan]:
        nl = (name or "").lower()
        for t in self.tables:
            if t.table_name.lower() == nl:
                return t
        return None

    def finalize(self) -> None:
        """Compute roll-up totals + stamp completed_at.  Call at end of
        query processing right before persist()."""
        self.total_files_before = sum(t.files_before for t in self.tables)
        self.total_files_after = sum(t.files_final for t in self.tables)
        self.completed_at = datetime.now(timezone.utc)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "execution_id":  self.execution_id,
            "raw_sql":       self.raw_sql,
            "created_at":    self.created_at.isoformat(),
            "completed_at":  self.completed_at.isoformat() if self.completed_at else None,
            "total_files_before": self.total_files_before,
            "total_files_after":  self.total_files_after,
            "tables":        [t.to_dict() for t in self.tables],
            "joins":         [j.to_dict() for j in self.joins],
        }

    # ── Persistence (Phase P) ─────────────────────────────────────────

    def persist(self, db_manager: Any) -> bool:
        """Write the full plan to the ``query_scan_plans`` table.

        Phase R deep-dive fixes:
          * Bug B FIX: removed the per-table record_pruning_history call.
            iceberg_reader.get_iceberg_data_files ALREADY calls it
            directly for legacy compatibility -- double-writing wasted
            rows.  This method now writes ONLY the unified plan.
          * Bug D FIX: UPSERT pattern (UPDATE existing row, INSERT only
            on first write) so re-persists within one query don't
            create N duplicate rows.  Last write wins -- caller can
            re-persist after each iceberg read without bloating the
            table.  /api/admin/queries/scan-plan/{id} sees the
            most-complete plan.

        Best-effort: never raises.  Returns True on successful persist.
        """
        if db_manager is None:
            return False
        try:
            from core.db.models import QueryScanPlan
            with db_manager.get_session() as sess:
                existing = (sess.query(QueryScanPlan)
                            .filter(QueryScanPlan.execution_id == self.execution_id)
                            .first())
                if existing is None:
                    sess.add(QueryScanPlan(
                        execution_id=self.execution_id,
                        raw_sql=(self.raw_sql or "")[:8000],
                        plan=self.to_dict(),
                        total_files_before=self.total_files_before,
                        total_files_after=self.total_files_after,
                        completed_at=self.completed_at,
                    ))
                else:
                    existing.plan = self.to_dict()
                    existing.total_files_before = self.total_files_before
                    existing.total_files_after = self.total_files_after
                    if self.completed_at:
                        existing.completed_at = self.completed_at
                    if self.raw_sql and not existing.raw_sql:
                        existing.raw_sql = self.raw_sql[:8000]
            return True
        except Exception as exc:
            logger.debug(
                "[scan_plan] persist failed (legacy pruning_history "
                "still written by iceberg_reader): %s", exc,
            )
            return False

    # ── Adapter from legacy inputs ────────────────────────────────────

    @classmethod
    def from_legacy_inputs(
        cls,
        execution_id: str,
        raw_sql: Optional[str] = None,
        partition_filters: Optional[List[Dict[str, Any]]] = None,
    ) -> "PruneContext":
        """Build an empty PruneContext seeded with the BrainFilter
        list from the legacy partition_filters dict shape.  Tables are
        added later as setup_registered_views processes each one."""
        ctx = cls(execution_id=execution_id, raw_sql=raw_sql)
        # Filters are not associated with tables here -- they're
        # routed per-table when each TableScanPlan is built.  Tracked
        # on the ctx for diagnostic completeness.
        ctx._initial_filters = from_legacy_dict_list(
            partition_filters or [], source=FilterSource.WHERE_CLAUSE)
        return ctx


# ── Module-level execution registry (in-memory cache of latest plans) ─
#
# Keeps the most recent N PruneContexts in memory for fast UI lookup.
# Persisted version lives in DB via persist().  This in-mem store
# matches the existing ``_PRUNING`` ring in query_diagnostic_store.

_RECENT_CONTEXTS: Dict[str, PruneContext] = {}
_RECENT_MAX = 100


def remember(ctx: PruneContext) -> None:
    """Stash this PruneContext in memory for the admin UI to read."""
    _RECENT_CONTEXTS[ctx.execution_id] = ctx
    if len(_RECENT_CONTEXTS) > _RECENT_MAX:
        # FIFO eviction
        for k in list(_RECENT_CONTEXTS.keys())[:-_RECENT_MAX]:
            _RECENT_CONTEXTS.pop(k, None)


# ── Phase Z (2026-06-09) — JOIN-PRUNER bound-source attribution ──────
#
# When the BoundProviderRegistry aggregates bounds for join keys, each
# col's report carries WHICH source had data (partition / manifest_stats
# / supplement) plus files_covered / files_missing.  This registry
# stashes per-execution per-table reports so the diagnose UI can show
# the operator real reasoning instead of opaque "no bounds returned".
#
# Thread-safe: Phase S anchor pre-fetches multiple tables in parallel
# (ThreadPoolExecutor), and each iceberg read calls record_bound_report
# concurrently.  Without the lock, a Python dict assignment race could
# drop one table's report.

import threading as _threading  # noqa: E402

_BOUND_REPORTS: Dict[str, Dict[str, Dict[str, Any]]] = {}
_BOUND_REPORTS_LOCK = _threading.Lock()


def record_bound_report(
    execution_id: str,
    table_name: str,
    report: Dict[str, Dict[str, Any]],
) -> None:
    """Stash one table's bound-source-attribution report.  Multiple
    tables per execution: each call adds (table, report) under the
    execution_id key."""
    if not execution_id or not table_name or not report:
        return
    with _BOUND_REPORTS_LOCK:
        bucket = _BOUND_REPORTS.setdefault(execution_id, {})
        bucket[table_name] = dict(report)
        if len(_BOUND_REPORTS) > _RECENT_MAX:
            for k in list(_BOUND_REPORTS.keys())[:-_RECENT_MAX]:
                _BOUND_REPORTS.pop(k, None)


def get_bound_report(execution_id: str) -> Optional[Dict[str, Dict[str, Any]]]:
    """Return ``{table_name: {col: {sources, files_covered, ...}}}`` for
    the given execution, or None if no report was recorded."""
    with _BOUND_REPORTS_LOCK:
        rep = _BOUND_REPORTS.get(execution_id)
        if rep is None:
            return None
        # Return a shallow copy so readers can't mutate the registry's
        # state.  Deep enough for the JSON-serialise path the diagnose
        # endpoint runs the result through.
        return {k: dict(v) for k, v in rep.items()}


# ── Phase T (2026-06-08) — execution path tracking ───────────────────
#
# Captures the routing decisions made for each query BEFORE the brain
# even has a chance to run.  Surfaces to /diagnose UI so operators
# can see WHICH code path their query took (BQB raw SQL / subprocess
# / structured / other) without grepping logs.

_EXECUTION_PATH: Dict[str, Dict[str, Any]] = {}


def record_execution_path(
    execution_id: str,
    branch: str,
    has_reg: bool,
    raw_sql: bool,
    has_s3_reg: bool,
    files: Optional[List[str]] = None,
    notes: Optional[str] = None,
) -> None:
    """Stash the routing decision for one execution.  Called by
    execute_api.py at branch entry so the admin UI can show WHY a
    particular brain code path ran (or didn't)."""
    _EXECUTION_PATH[execution_id] = {
        "branch":      branch,
        "has_reg":     has_reg,
        "raw_sql":     raw_sql,
        "has_s3_reg":  has_s3_reg,
        "files":       list(files)[:10] if files else [],
        "notes":       notes or "",
        "recorded_at": datetime.now(timezone.utc).isoformat(),
    }
    # FIFO eviction matches _RECENT_CONTEXTS
    if len(_EXECUTION_PATH) > _RECENT_MAX:
        for k in list(_EXECUTION_PATH.keys())[:-_RECENT_MAX]:
            _EXECUTION_PATH.pop(k, None)


def record_execution_path_if_absent(execution_id: str, branch: str, **kw) -> bool:
    """AQD-01 (2026-09-23) -- record only if this id has no path yet.

    For a SHARED chokepoint (the semantic-layer query wrapper) that runs
    beneath entry points which record their own, more specific branch -- a
    feed run, a DataFlow stage.  First writer wins, so the outer answer is
    not overwritten by the generic one.  Returns whether it recorded.
    """
    if not execution_id or execution_id in _EXECUTION_PATH:
        return False
    kw.setdefault("has_reg", False)
    kw.setdefault("raw_sql", False)
    kw.setdefault("has_s3_reg", False)
    record_execution_path(execution_id, branch, **kw)
    return True


def get_execution_path(execution_id: str) -> Optional[Dict[str, Any]]:
    return _EXECUTION_PATH.get(execution_id)


def get_recent(execution_id: str) -> Optional[PruneContext]:
    return _RECENT_CONTEXTS.get(execution_id)


def list_recent(limit: int = 20) -> List[Dict[str, Any]]:
    items = list(_RECENT_CONTEXTS.items())[-limit:]
    return [
        {
            "execution_id":      ex,
            "created_at":        ctx.created_at.isoformat(),
            "completed_at":      ctx.completed_at.isoformat() if ctx.completed_at else None,
            "total_files_before": ctx.total_files_before,
            "total_files_after":  ctx.total_files_after,
            "tables":            len(ctx.tables),
        }
        for ex, ctx in items
    ]


__all__ = [
    "DecisionGate",
    "DecisionAction",
    "PruningSource",
    "Decision",
    "JoinPlan",
    "TableScanPlan",
    "PruneContext",
    "remember",
    "get_recent",
    "list_recent",
]
