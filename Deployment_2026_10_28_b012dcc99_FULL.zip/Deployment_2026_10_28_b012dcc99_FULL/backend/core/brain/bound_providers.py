"""Phase Z (2026-06-09) — unified column-bound provider registry.

THE PROBLEM the previous patches kept stumbling on:

Iceberg has THREE sources of per-file column min/max bounds:
  1. data_file.partition[col]   — partition value (identity transform)
  2. data_file.lower_bounds/upper_bounds[field_id] — manifest col-stats
  3. column_stats_supplement_v2 — parquet-footer-derived backfill

Pre-refactor, ``iceberg_reader.get_iceberg_data_files`` consulted these
three sources via three INDEPENDENT inline blocks: separate load
logic, separate per-file iteration, separate emit gates.  Every fix
had to thread through all three.  The supplement-only-join-key bug
(the 1313-file regression) was: the supplement loader queried for
WHERE-filter cols only — never asked for the actual join key — so
the per-file lookup silently returned nothing.

THIS MODULE introduces a unifying abstraction:

  - ``Provider`` — abstract base.  Each concrete provider knows ONE
    source.  Has two hooks: ``preload(cols, ctx)`` (one-time bulk
    fetch, e.g. supplement table query) and ``bounds_for(col, file)``
    (per-file lookup).  Returns ``(lo, hi, source_label)`` or
    ``None`` if the source has no data for that (col, file).

  - ``BoundProviderRegistry`` — holds providers in priority order.
    ``preload(cols)`` calls every provider once.  ``resolve(col,
    file)`` walks providers and returns the FIRST hit.  Source
    attribution preserved end-to-end.

  - ``BoundAggregator`` — runs the registry over a stream of files
    and accumulates min/max + singleton set per col.  Single per-
    file walk replaces the three inline blocks.

Why this is enterprise-grade:
  - Adding a 4th source (bloom filter, manifest-list partition
    summaries, Iceberg V3 stats-v2) is ONE new ``Provider`` class —
    not three new if-blocks in three files.
  - Tested in isolation: providers are pure functions on (col, file)
    so unit tests don't need to mock 5 layers of S3.
  - Self-diagnosing: ``aggregator.report()`` returns per-col source
    attribution so the diagnose UI can show "code: partition (5
    distinct) · entity_id: supplement (1 file) · amount: null".
  - Fail-safe: any provider exception is caught and that provider
    skipped for the rest of the call.  Aggregator continues.

Out of scope here (separate follow-ups):
  - iceberg_db_first_reader's _compute_join_key_bounds still has its
    own logic — will be ported once this lands and is stable in prod
  - pyiceberg path likewise
"""
from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


# ── Result shapes ──────────────────────────────────────────────────────────


@dataclass(frozen=True)
class BoundHit:
    """One provider's bound for one (col, file).

    ``singleton_value`` is set when lo == hi (the file has exactly one
    distinct value for this col, which is the natural case for
    identity-transform partition columns + sort-ordered clustered cols).
    Used by the aggregator to populate ``join_key_distinct_values``
    for IN-list pushdown.
    """
    lo: Any
    hi: Any
    source: str             # "partition" | "manifest_stats" | "supplement" | ...
    singleton_value: Optional[Any] = None


@dataclass
class AggregatedBounds:
    """Per-col aggregation result across all surviving files."""
    lo: Any = None
    hi: Any = None
    sources_used: Set[str] = field(default_factory=set)
    singletons: Optional[Set[Any]] = field(default_factory=set)
    files_covered: int = 0
    files_missing: int = 0
    # A file that contributed only ONE side (lo XOR hi) -> its opposite bound
    # is unknown, so the aggregated (lo,hi) is NOT a valid range over all files.
    # emit_bounds refuses the BETWEEN when this is set (would over-prune).
    half_bound: bool = False


# ── Provider base class ────────────────────────────────────────────────────


class Provider(ABC):
    """One bound source.  Override ``preload`` if the source needs a
    bulk-load step (e.g. one DB query for the supplement table); leave
    as a no-op when the source is purely per-entry (partition values,
    manifest stats are already in the avro dict).

    ``bounds_for`` MUST be fast — called per file.  Return ``None``
    when the source has nothing for that (col, file) pair so the
    registry can try the next provider.
    """

    name: str = "unknown"

    def preload(self, cols: List[str], context: Dict[str, Any]) -> None:
        """One-time bulk fetch.  Default: no-op.

        ``context`` carries the per-table context the provider needs:
        e.g. ``{"bucket": ..., "table_prefix": ..., "db_manager": ...,
        "snapshot_id": ..., "schema_index": ..., "partition_spec": ...}``.
        """

    @abstractmethod
    def supports_col(self, col_lower: str) -> bool:
        """Cheap pre-check used during registry preload to decide
        whether THIS provider has any chance for this col.  Lets us
        avoid bulk-loading sources that can't possibly help (e.g.
        supplement query for a known partition col)."""

    @abstractmethod
    def bounds_for(
        self,
        col_lower: str,
        file_path: str,
        data_file: Dict[str, Any],
    ) -> Optional[BoundHit]:
        """Per-file lookup.  ``data_file`` is the manifest entry's
        data_file dict.  Return ``None`` when this source has no data
        for that (col, file) — caller falls through to next provider.
        """


# ── Concrete providers ─────────────────────────────────────────────────────


class PartitionValueProvider(Provider):
    """Source #1 — identity-transform partition values.

    For partition columns with identity transform, the per-file value
    in ``data_file.partition[col]`` IS the col's value across all rows
    of that file.  So lo == hi == that value, and singleton_value is
    populated naturally (every file → one distinct partition value →
    IN-list pushdown candidate).

    Non-identity transforms (bucket/truncate/year/month/day/hour) are
    intentionally skipped — their bounds can't be safely projected
    onto an arbitrary join target (bucket numbers don't equal col
    values; date-truncated periods need range widening).  Caller
    falls through to manifest-stats or supplement.
    """

    name = "partition"

    def __init__(self, partition_spec: Dict[str, str],
                  decode_partition_value: Callable[[Any, str], Any]):
        # partition_spec: ``{spec_key: type_str}`` where type_str
        # encodes transforms as ``_transform_<kind>...``.  Identity
        # transforms have plain type strings like "date" / "string".
        self._spec_lower: Dict[str, str] = {
            str(k).lower(): v for k, v in (partition_spec or {}).items()
        }
        self._real_name_by_lower: Dict[str, str] = {
            str(k).lower(): k for k in (partition_spec or {})
        }
        self._decode = decode_partition_value
        # Cols this provider claims (only identity-transformed
        # partition cols).  Computed once at construction.
        self._identity_cols: Set[str] = set()
        for k_lower, t in self._spec_lower.items():
            if not str(t).startswith("_transform_"):
                self._identity_cols.add(k_lower)

    def supports_col(self, col_lower: str) -> bool:
        return col_lower in self._identity_cols

    def bounds_for(self, col_lower, file_path, data_file):
        if col_lower not in self._identity_cols:
            return None
        partition = data_file.get("partition")
        if not isinstance(partition, dict):
            return None
        real_name = self._real_name_by_lower.get(col_lower, col_lower)
        raw = partition.get(real_name)
        if raw is None:
            return None
        try:
            dec = self._decode(raw, self._spec_lower[col_lower])
        except Exception:
            return None
        if dec is None:
            return None
        return BoundHit(lo=dec, hi=dec, source=self.name, singleton_value=dec)


class ManifestStatsProvider(Provider):
    """Source #2 — Iceberg manifest column-stats (lower_bounds /
    upper_bounds maps keyed on field-id, values are raw bytes).

    Covers any non-partition col the writer chose to track.  Bounds
    here are the file's true min/max — the file may contain many
    distinct values between them, so singleton_value is set ONLY
    when lo == hi.
    """

    name = "manifest_stats"

    def __init__(
        self,
        col_to_fid: Dict[str, int],
        fid_to_type: Dict[int, str],
        decode_bound: Callable[[Optional[bytes], str], Any],
    ):
        self._col_to_fid: Dict[str, int] = {
            (k or "").lower(): v for k, v in (col_to_fid or {}).items()
        }
        self._fid_to_type = fid_to_type or {}
        self._decode = decode_bound

    def supports_col(self, col_lower: str) -> bool:
        return col_lower in self._col_to_fid

    def bounds_for(self, col_lower, file_path, data_file):
        fid = self._col_to_fid.get(col_lower)
        if fid is None:
            return None
        lb_map = data_file.get("lower_bounds") or {}
        ub_map = data_file.get("upper_bounds") or {}
        # Defensive coerce — some avro shapes return map<int,bytes>
        # as list-of-{key,value} records (Phase W).
        if isinstance(lb_map, (list, tuple)):
            lb_map = _coerce_map_list(lb_map)
        if isinstance(ub_map, (list, tuple)):
            ub_map = _coerce_map_list(ub_map)
        lb_b = lb_map.get(fid) or lb_map.get(str(fid))
        ub_b = ub_map.get(fid) or ub_map.get(str(fid))
        if lb_b is None and ub_b is None:
            return None
        ftype = self._fid_to_type.get(fid, "string")
        try:
            lo = self._decode(lb_b, ftype) if lb_b else None
            hi = self._decode(ub_b, ftype) if ub_b else None
        except Exception:
            return None
        if lo is None and hi is None:
            return None
        sv = lo if (lo is not None and hi is not None and lo == hi) else None
        return BoundHit(lo=lo, hi=hi, source=self.name, singleton_value=sv)


def _coerce_map_list(raw):
    """Helper: avro map-as-list-of-{key,value} → dict.

    2026-08-21 — delegates to core.iceberg_reader._avro_kv_map.  This module
    already knew Avro emits map<int,X> in two shapes ("Phase W"), while
    iceberg_reader — the MAIN consumer — did not, and raised AttributeError
    into a fail-open handler on every file of an array-encoded table.  Two
    copies is how one of them stays wrong; keep exactly one.
    """
    try:
        from core.iceberg_reader import _avro_kv_map
        return _avro_kv_map(raw)
    except Exception:
        return {}


class SupplementProvider(Provider):
    """Source #3 — column_stats_supplement_v2 table (parquet-footer
    scan results stored in QueryStudio's own DB).

    Covers any column the admin has run a scan for, INCLUDING cols
    that aren't partition keys and aren't in manifest column-stats.
    Per-file bounds are stored as strings (decode at compare time);
    we surface them as-is to the aggregator.

    PRELOAD: one DB query for all requested cols (vs N queries per
    file).  Pre-Phase-Z the loader was scoped to WHERE-filter cols
    only; this provider asks for EVERY col it's registered against
    — closing the supplement-only-join-key bug.
    """

    name = "supplement"

    def __init__(self):
        # file_path → {col_lower: (lo_str, hi_str, null_count)}
        self._bounds: Dict[str, Dict[str, tuple]] = {}
        self._loaded_cols: Set[str] = set()

    def supports_col(self, col_lower: str) -> bool:
        # Until preload runs we can't know.  Reporting True is safe
        # because bounds_for returns None when the per-file lookup
        # misses — registry just falls through to no-provider for
        # that col.  Avoids needing a separate "schema introspection"
        # pre-check against the supplement table.
        return True

    def preload(self, cols, context):
        db_manager = context.get("db_manager")
        bucket = context.get("bucket")
        table_prefix = context.get("table_prefix")
        snapshot_id = context.get("snapshot_id") or ""
        if not (db_manager and bucket and table_prefix and cols):
            return
        # 2026-07-03 -- route through the Phase 160 store chokepoint so
        # this hot-path caller (fires on query bind) also benefits from
        # the columnar brain-store hit rate + its trace / metrics.  The
        # helper is store-first with DB fallback preserved, so behaviour
        # on store miss / error / disabled is identical to the prior
        # direct DB call.  Rule from Phase 160: every column-stats hot-
        # path reader routes through this chokepoint, never directly.
        # Route through the SINGLE grain-routing chokepoint (2026-07-13):
        # it reads the per-file v3 table under grain=v3, else the v2 store
        # (store-first, DB-fallback).  Same {file_path:{col:(lo,hi,nulls,rc)}}
        # shape either way.  Direct-DB fallback only if the import fails.
        try:
            from core.brain_duckdb_store import get_col_stats_for_snapshot_via_store
        except Exception:
            get_col_stats_for_snapshot_via_store = None
        try:
            if get_col_stats_for_snapshot_via_store is not None:
                raw = get_col_stats_for_snapshot_via_store(
                    db_manager,
                    bucket=bucket,
                    table_prefix=str(table_prefix).rstrip("/"),
                    snapshot_id=str(snapshot_id),
                    column_names=list({c.lower() for c in cols}),
                )
            else:
                raw = db_manager.iceberg_col_stats_get_for_snapshot(
                    bucket=bucket,
                    table_prefix=str(table_prefix).rstrip("/"),
                    snapshot_id=str(snapshot_id),
                    column_names=list({c.lower() for c in cols}),
                )
        except Exception as exc:
            logger.debug("SupplementProvider.preload failed: %s", exc)
            return
        for file_path, col_map in (raw or {}).items():
            self._bounds[file_path] = {
                (k or "").lower(): v for k, v in (col_map or {}).items()
            }
        self._loaded_cols.update(c.lower() for c in cols)

    def bounds_for(self, col_lower, file_path, data_file):
        if col_lower not in self._loaded_cols:
            return None
        file_bounds = self._bounds.get(file_path)
        if not file_bounds:
            return None
        entry = file_bounds.get(col_lower)
        if not entry:
            return None
        try:
            lo, hi = entry[0], entry[1]
        except (IndexError, TypeError):
            return None
        if lo is None and hi is None:
            return None
        sv = lo if (lo is not None and hi is not None and lo == hi) else None
        return BoundHit(lo=lo, hi=hi, source=self.name, singleton_value=sv)


# ── Registry + aggregator ──────────────────────────────────────────────────


class BoundProviderRegistry:
    """Holds providers in PRIORITY ORDER and dispatches per-(col,file)
    lookups.  Priority is the construction order — first hit wins.

    Default priority: partition > manifest_stats > supplement.
    Rationale:
      - partition value is the most authoritative for partition cols
        (every row in the file IS that value; no min/max widening)
      - manifest stats are next — the writer chose to track this col
        and its bounds are accurate (per-row min/max within the file)
      - supplement is the backfill — parquet-footer-derived, same
        accuracy as manifest stats but may lag behind newest files
    """

    def __init__(self, providers: List[Provider]):
        self._providers = list(providers)

    def preload(self, cols: List[str], context: Dict[str, Any]) -> None:
        for p in self._providers:
            try:
                # Filter cols to those this provider might support so
                # bulk loads don't fetch data we'll never use.
                supported = [c for c in cols if p.supports_col(c.lower())]
                if supported:
                    p.preload(supported, context)
            except Exception as exc:
                logger.warning(
                    "BoundProviderRegistry.preload: %s raised %s — "
                    "provider skipped for this query",
                    p.name, exc,
                )

    def resolve(
        self,
        col_lower: str,
        file_path: str,
        data_file: Dict[str, Any],
    ) -> Optional[BoundHit]:
        """First-hit-wins walk across providers.  Returns the FIRST
        BoundHit any provider produces for (col, file), or None when
        no provider has data."""
        for p in self._providers:
            try:
                hit = p.bounds_for(col_lower, file_path, data_file)
                if hit is not None:
                    return hit
            except Exception as exc:
                logger.debug(
                    "%s.bounds_for(%s, %s) raised: %s",
                    p.name, col_lower, file_path, exc,
                )
        return None


def _to_num(x):
    """int/float of a numeric-looking value, else raise ValueError."""
    if isinstance(x, bool):
        raise ValueError("bool is not a numeric bound")
    if isinstance(x, (int, float)):
        return x
    try:
        return int(x)
    except (ValueError, TypeError):
        return float(x)   # raises ValueError/TypeError if not numeric


def _is_ambiguous_numeric_string(v) -> bool:
    """True if ``v`` is a STRING that parses as a number.  Its ordering is
    AMBIGUOUS: the emitted ``BETWEEN`` may be applied lexicographically (VARCHAR
    target) or numerically (numeric target) downstream, and we can't tell which
    here -- so ``emit_bounds`` refuses to prune on it."""
    if not isinstance(v, str):
        return False
    try:
        _to_num(v)
        return True
    except (ValueError, TypeError):
        return False


def _bound_lt(a, b) -> bool:
    """``a < b`` in the values' NATIVE ordering -- native numbers compare
    numerically, strings lexicographically (SQL VARCHAR default collation; ISO
    dates sort chronologically).

    2026-07-06 DATA-LOSS FIX: do NOT numerically re-order numeric-LOOKING
    strings here.  The aggregation ordering must match how the emitted
    ``target BETWEEN lo AND hi`` is APPLIED on the target column, and a
    numeric-looking string bound can be applied lexicographically (VARCHAR
    target) OR numerically (numeric target) -- unknown here.  Aggregating one
    way and applying the other drops matching rows (e.g. numeric-aggregated
    [2,1000] applied lexicographically drops "50": '50' > '1000' lex).  So
    ``emit_bounds`` refuses to emit an ambiguous numeric-string bound; keeping
    native ordering here just makes lo/hi correct for the cases we DO emit
    (native-numeric and clearly-non-numeric strings).  Mixed native/string
    types raise TypeError -> caller's guard nulls the column (safe)."""
    return a < b


class BoundAggregator:
    """Walks a stream of (file_path, data_file) tuples and aggregates
    per-col min/max + singleton set via the registry.

    Single source of truth for ``join_key_bounds`` and
    ``join_key_distinct_values`` emit.  Replaces the three inline
    blocks scattered in iceberg_reader.
    """

    def __init__(self, registry: BoundProviderRegistry, cols: List[str]):
        self._reg = registry
        self._cols: List[str] = [str(c).split(".")[-1].lower()
                                  for c in (cols or []) if c]
        self._agg: Dict[str, AggregatedBounds] = {
            c: AggregatedBounds() for c in self._cols
        }

    @property
    def cols(self) -> List[str]:
        return list(self._cols)

    def observe(self, file_path: str, data_file: Dict[str, Any]) -> None:
        """Process one surviving file.  Updates per-col accumulator."""
        for col_lower in self._cols:
            slot = self._agg[col_lower]
            hit = self._reg.resolve(col_lower, file_path, data_file)
            if hit is None:
                slot.files_missing += 1
                # File has no bound for this col → singleton invariant
                # broken (file may contain anything).
                slot.singletons = None
                continue
            slot.files_covered += 1
            slot.sources_used.add(hit.source)
            # A one-sided hit (lo XOR hi) leaves this file's opposite bound
            # UNKNOWN -- the aggregate range can no longer be trusted to cover
            # every file's values -> mark half_bound so emit_bounds won't emit
            # a (possibly under-covering) BETWEEN that would over-prune.
            if (hit.lo is not None) != (hit.hi is not None):
                slot.half_bound = True
            # Min/max accumulation with type-mismatch guard.  _bound_lt does
            # numeric-aware comparison so numeric-as-string supplement bounds
            # aren't ordered lexicographically (data-loss fix).
            try:
                if slot.lo is None or (hit.lo is not None and _bound_lt(hit.lo, slot.lo)):
                    if hit.lo is not None:
                        slot.lo = hit.lo
                if slot.hi is None or (hit.hi is not None and _bound_lt(slot.hi, hit.hi)):
                    if hit.hi is not None:
                        slot.hi = hit.hi
            except TypeError:
                # Heterogeneous types (rare; would mean cross-source
                # decode produced mixed shapes).  Drop col safely.
                slot.lo = None
                slot.hi = None
                slot.singletons = None
                continue
            # Singleton tracking
            if slot.singletons is not None:
                if hit.singleton_value is not None:
                    slot.singletons.add(hit.singleton_value)
                else:
                    slot.singletons = None

    def emit_bounds(self) -> Dict[str, tuple]:
        """``{col_lower: (lo, hi)}`` for cols where BOTH bounds are
        populated AND every surviving file contributed a bound.  Cols with
        PARTIAL coverage are excluded — caller treats missing as "no probe
        possible".

        2026-07-04 DATA-LOSS FIX: previously this returned a (lo,hi) computed
        over only the COVERED subset of anchor files whenever ``files_missing
        > 0`` -- an incomplete build-side domain.  The synthesized
        ``target BETWEEN lo AND hi`` then pruned probe files holding keys that
        match the UNcovered anchor files, dropping join rows.  The
        singleton/IN path was already guarded (any miss nulls ``singletons``);
        the BETWEEN/range path was not.  Now both require full coverage."""
        out: Dict[str, tuple] = {}
        for col, slot in self._agg.items():
            if not (
                slot.lo is not None and slot.hi is not None
                and slot.files_missing == 0
                and slot.files_covered > 0
                and not slot.half_bound   # some file contributed only one side
            ):
                continue
            # DATA-LOSS GUARD (2026-07-06): refuse to emit a BETWEEN range whose
            # bounds are numeric-LOOKING STRINGS.  Such a bound may be applied
            # lexicographically (VARCHAR target) or numerically (numeric target)
            # downstream, and lo/hi aggregated in one ordering but applied in
            # the other drops matching rows (numeric [2,1000] applied lex drops
            # "50"; lex ["1000","50"] applied numerically is an empty range).
            # We can't know the target's compare semantics here, so don't prune
            # this column -- correctness over optimization.  Native-numeric and
            # clearly-non-numeric-string bounds are unambiguous and safe.
            # Only a genuine RANGE (lo != hi) is ordering-ambiguous.  A
            # singleton (lo == hi) emits ``BETWEEN v AND v`` == ``= v``, which
            # is EQUALITY -- unambiguous under either ordering -- so it stays
            # (this is the 1313-file supplement-only join-key case).
            if slot.lo != slot.hi and (
                _is_ambiguous_numeric_string(slot.lo)
                or _is_ambiguous_numeric_string(slot.hi)
            ):
                continue
            out[col] = (slot.lo, slot.hi)
        return out

    def emit_distinct(self, max_distinct: int = 200) -> Dict[str, list]:
        """``{col_lower: [v1, v2, ...]}`` for cols where every observed
        file had a singleton bound (closed-set IN-list).  Capped by
        ``max_distinct`` so an absurdly large set doesn't blow up
        downstream SQL parsers."""
        out: Dict[str, list] = {}
        for col, slot in self._agg.items():
            if slot.singletons is None or not slot.singletons:
                continue
            if len(slot.singletons) > max_distinct:
                continue
            try:
                out[col] = sorted(slot.singletons)
            except TypeError:
                out[col] = list(slot.singletons)
        return out

    def report(self) -> Dict[str, Dict[str, Any]]:
        """Per-col diagnostic report.  Surfaced into ``_out_meta`` so
        the diagnose UI can show ``code: partition (5 distinct
        values) · entity_id: supplement (1 file matched) · amount:
        missing on 1239 files``."""
        out: Dict[str, Dict[str, Any]] = {}
        for col, slot in self._agg.items():
            out[col] = {
                "sources":        sorted(slot.sources_used),
                "files_covered":  slot.files_covered,
                "files_missing":  slot.files_missing,
                "has_bounds":     slot.lo is not None and slot.hi is not None,
                "distinct_count": (len(slot.singletons)
                                    if slot.singletons else 0),
            }
        return out
