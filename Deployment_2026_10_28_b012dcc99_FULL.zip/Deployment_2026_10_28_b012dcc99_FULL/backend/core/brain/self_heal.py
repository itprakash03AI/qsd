"""Phase O (2026-06-08) — Unified self-heal capability on PruneContext.

Pre-Phase-O, three separate self-heal mechanisms existed:

  * BF-547 async supplement scan (fire-and-forget after read)
  * Phase L sync supplement scan for join-key cols
  * partition_resolver Tier 3 metadata fallback

Phase O consolidates these into ONE callable: ``heal_missing_bounds``
that takes a ``TableScanPlan`` (which already knows what columns are
missing bounds + what scan is needed) and EITHER sync-blocks OR fires
async based on a single strategy enum.

This is the "high IQ" the user asked for: the plan KNOWS what's
needed, and one healer DOES it.  No more scattered ad-hoc scans.
"""
from __future__ import annotations

import logging
import threading
import time
from enum import Enum
from typing import Any, Dict, List, Optional

from .scan_plan import (
    Decision, DecisionAction, DecisionGate, TableScanPlan,
)


logger = logging.getLogger(__name__)


class HealStrategy(str, Enum):
    """How aggressively to heal missing bounds."""
    SYNC_WITH_TIMEOUT = "sync_timeout"   # block briefly to scan, then proceed
    ASYNC_ONLY        = "async"          # fire & forget; current query unaffected
    OFF               = "off"            # don't heal, let pruning degrade


def heal_missing_bounds(
    plan: TableScanPlan,
    missing_columns: List[str],
    *,
    db_manager: Any,
    s3_client: Any,
    file_keys: Optional[List[str]] = None,
    strategy: HealStrategy = HealStrategy.SYNC_WITH_TIMEOUT,
    max_files: int = 200,
    timeout_s: float = 10.0,
) -> bool:
    """Trigger a column-stats scan for ``missing_columns`` on the
    table described by ``plan``.

    Returns True when bounds are now available (or when ASYNC_ONLY +
    scan kicked off successfully).  False on any error.  Records a
    ``Decision`` on the plan regardless.
    """
    if strategy == HealStrategy.OFF or not missing_columns:
        plan.record(Decision(
            gate=DecisionGate.SELF_HEAL, action=DecisionAction.SKIPPED,
            reason="strategy=off or no missing columns",
            columns=missing_columns,
        ))
        return False

    if not (db_manager and s3_client and plan.bucket and plan.table_prefix):
        plan.record(Decision(
            gate=DecisionGate.SELF_HEAL, action=DecisionAction.SKIPPED,
            reason="missing db_manager / s3_client / bucket / prefix",
            columns=missing_columns,
        ))
        return False

    # Resolve file list if caller didn't supply one.
    if file_keys is None:
        try:
            from core.iceberg_reader import get_iceberg_data_files
            files_meta = get_iceberg_data_files(
                s3_client, plan.bucket, plan.table_prefix,
                keys_only=True, max_files=max_files,
                db_manager=db_manager,
            )
            file_keys = [
                m.get("key") or m.get("path") for m in files_meta
                if (m.get("key") or m.get("path"))
            ]
        except Exception as exc:
            plan.record(Decision(
                gate=DecisionGate.SELF_HEAL, action=DecisionAction.FAILED,
                reason=f"file-list resolution failed: {exc}",
                columns=missing_columns,
            ))
            return False
    if not file_keys:
        plan.record(Decision(
            gate=DecisionGate.SELF_HEAL, action=DecisionAction.SKIPPED,
            reason="no data files to scan",
            columns=missing_columns,
        ))
        return False

    snap_id = plan.snapshot_id or ""

    def _do_scan(success_flag: Dict[str, Any]) -> None:
        try:
            from core.iceberg_column_stats import scan_files_to_supplement
            scan_files_to_supplement(
                db_manager, s3_client, plan.bucket, plan.table_prefix,
                snap_id, file_keys,
                target_columns=missing_columns,
                max_workers=8,
                skip_already_scanned=True,
                connection_id=plan.connection_id,
                table_name=plan.table_name,
            )
            success_flag["ok"] = True
        except Exception as exc:
            success_flag["err"] = str(exc)

    t0 = time.monotonic()
    result_state: Dict[str, Any] = {"ok": False}

    if strategy == HealStrategy.ASYNC_ONLY:
        _t = threading.Thread(
            target=_do_scan, args=(result_state,), daemon=True,
            name=f"qs-self-heal-{plan.table_name[:20]}",
        )
        _t.start()
        plan.record(Decision(
            gate=DecisionGate.SELF_HEAL, action=DecisionAction.HEALED,
            reason=f"async scan QUEUED for cols={missing_columns} "
                   f"(next query benefits)",
            columns=missing_columns,
            elapsed_ms=(time.monotonic() - t0) * 1000.0,
            extra={"strategy": "async", "file_keys_count": len(file_keys)},
        ))
        return True

    # SYNC_WITH_TIMEOUT
    done_event = threading.Event()

    def _wrapped_scan():
        try:
            _do_scan(result_state)
        finally:
            done_event.set()

    _t = threading.Thread(
        target=_wrapped_scan, daemon=True,
        name=f"qs-self-heal-{plan.table_name[:20]}",
    )
    _t.start()
    completed = done_event.wait(timeout=timeout_s)
    elapsed_ms = (time.monotonic() - t0) * 1000.0
    if not completed:
        plan.record(Decision(
            gate=DecisionGate.SELF_HEAL, action=DecisionAction.HEAL_FAIL,
            reason=f"sync scan TIMED OUT after {timeout_s}s "
                   f"(continuing in background)",
            columns=missing_columns, elapsed_ms=elapsed_ms,
            extra={"strategy": "sync_timeout", "file_keys_count": len(file_keys)},
        ))
        return False
    if result_state.get("err"):
        plan.record(Decision(
            gate=DecisionGate.SELF_HEAL, action=DecisionAction.HEAL_FAIL,
            reason=f"sync scan errored: {result_state['err']}",
            columns=missing_columns, elapsed_ms=elapsed_ms,
        ))
        return False
    plan.record(Decision(
        gate=DecisionGate.SELF_HEAL, action=DecisionAction.HEALED,
        reason=f"sync scan COMPLETE for cols={missing_columns} "
               f"({len(file_keys)} files)",
        columns=missing_columns, elapsed_ms=elapsed_ms,
        extra={"strategy": "sync_timeout", "file_keys_count": len(file_keys)},
    ))
    return True


__all__ = ["HealStrategy", "heal_missing_bounds"]
