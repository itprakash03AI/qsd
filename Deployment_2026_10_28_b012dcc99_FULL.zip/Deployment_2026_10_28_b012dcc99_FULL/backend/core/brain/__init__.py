"""QueryStudio Pruning Brain (Phases M-R, 2026-06-08).

A single decision-owning architecture for iceberg query pruning.
Replaces the scattered logic that previously lived across
duckdb_views, iceberg_reader, iceberg_db_first_reader, join_pruner,
sql_partition_extractor.

Modules
=======

  filter.py       — Phase M: single BrainFilter dataclass.  Lossless
                    representation that carries table prefix, operator,
                    value, and transform-applied state.  All extractors
                    emit this shape; all readers consume it.

  scan_plan.py    — Phase N: PruneContext + TableScanPlan + Decision.
                    One object owns the full pruning decision chain
                    per query.  Every gate records a Decision so
                    operators can audit without grepping logs.

  self_heal.py    — Phase O: unified self-heal capability on the plan.
                    Replaces BF-547 async + Phase L sync ad-hoc paths
                    with one strategy-configurable healer.

  diagnostic.py   — Phase P: scan-plan API helpers (persist to DB,
                    serve via /api/admin/queries/scan-plan/{id}).

Public re-exports below let existing callers gradually migrate.
"""
from __future__ import annotations

from .filter import BrainFilter, FilterOp, FilterSupport, FilterSource

__all__ = [
    "BrainFilter",
    "FilterOp",
    "FilterSupport",
    "FilterSource",
]
