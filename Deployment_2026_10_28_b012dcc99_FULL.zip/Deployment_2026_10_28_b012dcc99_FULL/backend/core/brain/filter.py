"""Phase M (2026-06-08) — Single filter representation for the brain.

Pre-Phase-M, the same logical filter existed in 4 different forms:

  * ``PartitionFilter`` dataclass     (sql_partition_extractor.py)
  * ``{col, op, val}`` dict           (iceberg_reader, duckdb_views)
  * ``{col, op, value}`` dict         (iceberg_db_first_reader brain)
  * Qualified vs unqualified ``col``  (sometimes "main.date", sometimes "date")

Conversions between them silently dropped information.  The famous
``partition_filters_to_pruning_format`` dropped the table prefix,
which caused ``JoinPruner.plan_probes_from_raw_joins`` to silently
emit 0 probes for unqualified filters -- the user's "ext_table 1239
files" over-scan bug class.

Phase M defines ONE lossless shape (``BrainFilter``) and provides
bidirectional adapters to/from each legacy shape.  New code uses
BrainFilter exclusively; existing callers can migrate gradually via
the adapters without breakage.

Design rules
============

  * NEVER drop info on a conversion.  Adapters preserve table,
    qualified-status, original operator string, transform metadata.
  * Operator names normalised to ``FilterOp`` enum values internally,
    but ``original_op_str`` retained so we can round-trip.
  * Value coercion is opt-in via ``coerced_for_type`` -- raw user
    value always preserved alongside.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Any, Dict, List, Optional


class FilterOp(str, Enum):
    """Normalised operator names.  String values match what the
    iceberg_reader's pruning code already expects so the BrainFilter
    -> dict adapter doesn't have to remap."""
    EQ          = "equals"
    NEQ         = "not_equals"
    LT          = "less_than"
    LTE         = "less_equals"
    GT          = "greater_than"
    GTE         = "greater_equals"
    IN          = "in"
    NOT_IN      = "not_in"
    BETWEEN     = "between"
    NOT_BETWEEN = "not_between"
    LIKE        = "like"
    LIKE_PREFIX = "like_prefix"
    NOT_LIKE    = "not_like"
    IS_NULL     = "is_null"
    IS_NOT_NULL = "is_not_null"
    UNKNOWN     = "unknown"


_LEGACY_OP_MAP: Dict[str, FilterOp] = {
    # equality
    "=":  FilterOp.EQ, "==": FilterOp.EQ, "eq": FilterOp.EQ,
    "equals": FilterOp.EQ,
    "!=": FilterOp.NEQ, "<>": FilterOp.NEQ, "neq": FilterOp.NEQ,
    "ne": FilterOp.NEQ, "not_equals": FilterOp.NEQ,
    # ordered
    "<":  FilterOp.LT, "lt": FilterOp.LT, "less_than": FilterOp.LT,
    "<=": FilterOp.LTE, "le": FilterOp.LTE, "lte": FilterOp.LTE,
    "less_equals": FilterOp.LTE,
    ">":  FilterOp.GT, "gt": FilterOp.GT, "greater_than": FilterOp.GT,
    ">=": FilterOp.GTE, "ge": FilterOp.GTE, "gte": FilterOp.GTE,
    "greater_equals": FilterOp.GTE,
    # sets
    "in": FilterOp.IN, "in_": FilterOp.IN,
    "not_in": FilterOp.NOT_IN, "nin": FilterOp.NOT_IN,
    # ranges
    "between": FilterOp.BETWEEN,
    "not_between": FilterOp.NOT_BETWEEN, "notbetween": FilterOp.NOT_BETWEEN,
    # text
    "like": FilterOp.LIKE, "like_prefix": FilterOp.LIKE_PREFIX,
    "starts_with": FilterOp.LIKE_PREFIX,
    "not_like": FilterOp.NOT_LIKE,
    # null
    "is_null": FilterOp.IS_NULL, "isnull": FilterOp.IS_NULL,
    "is_not_null": FilterOp.IS_NOT_NULL, "isnotnull": FilterOp.IS_NOT_NULL,
}


def _normalise_op(op_str: str) -> FilterOp:
    if not op_str:
        return FilterOp.UNKNOWN
    return _LEGACY_OP_MAP.get(op_str.lower().strip(), FilterOp.UNKNOWN)


class FilterSupport(str, Enum):
    """Operator + bound-source combination determines whether the
    filter can prune via manifest stats, supplement bounds, both,
    or neither.  Recorded so the diagnostic UI can show 'this filter
    couldn't prune because supplement was empty for col X'."""
    FULL        = "full"            # manifest or supplement bounds usable
    SUPPLEMENT  = "supplement_only" # supplement covers, manifest doesn't
    MANIFEST    = "manifest_only"   # manifest covers, supplement doesn't
    NONE        = "none"            # no bounds available
    UNSUPPORTED = "unsupported"     # operator can't prune (LIKE, function)


class FilterSource(str, Enum):
    """Where this filter came from.  Helps diagnose extraction issues."""
    WHERE_CLAUSE       = "where"          # user-typed in WHERE
    JOIN_ON_LITERAL    = "join_on"        # literal in JOIN ON (rare)
    JOIN_PROPAGATED    = "join_propagated"  # propagated via JOIN equiv
    JOIN_PRUNER_SYNTH  = "join_pruner_synth"  # synthesized BETWEEN
    SEMI_JOIN_INNER    = "semi_join_inner"  # IN (SELECT ...) inner-WHERE
    ADMIN_OVERRIDE     = "admin"          # admin-injected
    UNKNOWN            = "unknown"


@dataclass(frozen=False)
class BrainFilter:
    """Single lossless representation of a query filter.

    Fields:

      table          — original table reference (alias resolved to real
                       name when known).  ``None`` = unqualified.  This is
                       the field whose loss caused the JoinPruner unqualified
                       bug.
      column         — bare column name (no table prefix)
      op             — normalised operator enum
      values         — list (use list even for scalar ops; ``values[0]`` for
                       scalar).  BETWEEN uses ``[lo, hi]``; IN uses the
                       full list.  IS NULL uses ``[]``.
      original_op_str — what the source SQL literally said ("=", "BETWEEN",
                        ...) — preserved for telemetry.
      source         — where this filter originated (FilterSource)
      coerced_for    — iceberg_type the value was coerced TO (None when
                       raw)
      transform      — partition transform name if this filter applies to
                       a transformed partition col ("day"/"month"/...
                       /None for identity).  Used so the manifest-bound
                       comparison knows whether to convert the user's
                       value via apply_transform_to_value.

    Adapters:

      from_legacy_dict({col, op, val})              -> BrainFilter
      from_partition_filter(PartitionFilter)        -> BrainFilter
      to_legacy_dict()  -> {col, op, val}  (lossy on table)
      to_legacy_dict_with_table()  -> {col: "table.col", op, val}
    """
    column:           str
    op:               FilterOp
    values:           List[Any] = field(default_factory=list)
    table:            Optional[str] = None
    original_op_str:  str = ""
    source:           FilterSource = FilterSource.UNKNOWN
    coerced_for:      Optional[str] = None
    transform:        Optional[str] = None

    # ── Constructors from legacy shapes ─────────────────────────────

    @classmethod
    def from_legacy_dict(cls, d: Dict[str, Any],
                          source: FilterSource = FilterSource.UNKNOWN,
                          ) -> "BrainFilter":
        """Adapter from the ``{col, op, val}`` / ``{col, op, value}``
        dict shape that iceberg_reader + duckdb_views use.  Handles
        qualified columns ('table.col') by splitting."""
        raw_col = (d.get("col") if d.get("col") is not None
                   else d.get("column", ""))
        raw_col = str(raw_col or "")
        table = None
        column = raw_col
        if "." in raw_col:
            parts = raw_col.rsplit(".", 1)
            table = parts[0].rsplit(".", 1)[-1].lower() if parts[0] else None
            column = parts[1]
        op_str = str(
            d.get("op") if d.get("op") is not None
            else d.get("operator", "")
        )
        op = _normalise_op(op_str)
        val = (d.get("val") if "val" in d
               else (d.get("value") if "value" in d
                     else d.get("values", [])))
        if val is None:
            values = []
        elif isinstance(val, (list, tuple)):
            values = list(val)
        else:
            values = [val]
        return cls(
            column=column or "", op=op, values=values,
            table=table, original_op_str=op_str, source=source,
        )

    @classmethod
    def from_partition_filter(cls, pf: Any,
                               source: FilterSource = FilterSource.WHERE_CLAUSE,
                               ) -> "BrainFilter":
        """Adapter from sql_partition_extractor.PartitionFilter
        dataclass.  Preserves the ``table`` field that
        ``partition_filters_to_pruning_format`` previously dropped."""
        table = (getattr(pf, "table", None) or "").lower() or None
        column = (getattr(pf, "column", "") or "")
        op_str = str(getattr(pf, "operator", "") or "")
        op = _normalise_op(op_str)
        raw_vals = getattr(pf, "values", []) or []
        values = list(raw_vals) if isinstance(raw_vals, (list, tuple)) \
                 else [raw_vals]
        return cls(
            column=column, op=op, values=values,
            table=table, original_op_str=op_str, source=source,
        )

    # ── Adapters to legacy shapes ────────────────────────────────────

    def to_legacy_dict(self) -> Dict[str, Any]:
        """Lossy adapter: matches the ``{col, op, val}`` shape the
        existing iceberg_reader / pruner expects.  Loses the table
        prefix (caller should use to_legacy_dict_with_table when the
        target consumer is JoinPruner / _compute_table_filters)."""
        if self.op == FilterOp.BETWEEN and len(self.values) == 2:
            val = list(self.values)
        elif self.op in (FilterOp.IN, FilterOp.NOT_IN):
            val = list(self.values)
        elif self.op in (FilterOp.IS_NULL, FilterOp.IS_NOT_NULL):
            val = ""
        elif self.values:
            val = self.values[0]
        else:
            val = ""
        return {
            "col": self.column,
            "op": self.op.value,
            "val": val,
        }

    def to_legacy_dict_with_table(self) -> Dict[str, Any]:
        """Same as to_legacy_dict but with col qualified ``table.col``
        when ``table`` is known.  Used when emitting to the JoinPruner
        ``_collect_filtered_tables`` path which needs qualified cols
        to identify the anchor."""
        d = self.to_legacy_dict()
        if self.table:
            d["col"] = f"{self.table}.{self.column}"
        return d

    # ── Convenience predicates ───────────────────────────────────────

    @property
    def is_qualified(self) -> bool:
        return self.table is not None

    @property
    def is_prunable(self) -> bool:
        """Can the operator prune at all?  LIKE-prefix yes; LIKE arbitrary no.
        IS NULL yes (via null_count); IS NOT NULL yes (via null_count vs
        row_count)."""
        return self.op not in (FilterOp.LIKE, FilterOp.NOT_LIKE,
                                FilterOp.UNKNOWN)

    def applies_to_table(self, table_name: str) -> bool:
        """True when this filter should apply to the named table.
        Unqualified filters apply to ALL tables.  Qualified filters
        apply only to their own table."""
        if not self.table:
            return True
        return self.table.lower() == (table_name or "").lower()

    def with_table(self, table: str) -> "BrainFilter":
        """Return a copy with ``table`` set.  Used by JOIN propagation
        to derive a filter on the OTHER side of a join."""
        return replace(self, table=table.lower(),
                        source=FilterSource.JOIN_PROPAGATED)

    def with_coerced_values(self, new_values: List[Any],
                              iceberg_type: str) -> "BrainFilter":
        """Return a copy whose ``values`` have been coerced for the
        target column's iceberg type.  Preserves original via the
        caller's bookkeeping (re-coercing from raw is also fine since
        we keep the raw values nowhere -- caller has them)."""
        return replace(self, values=list(new_values),
                        coerced_for=iceberg_type)

    def with_transform(self, transform_name: str) -> "BrainFilter":
        """Mark this filter as targeting a transformed partition col
        (so the manifest-bound check knows to apply the transform when
        comparing)."""
        return replace(self, transform=transform_name)


# ── Bulk adapters ─────────────────────────────────────────────────────


def from_legacy_dict_list(dicts: List[Dict[str, Any]],
                            source: FilterSource = FilterSource.UNKNOWN,
                            ) -> List[BrainFilter]:
    return [BrainFilter.from_legacy_dict(d, source=source) for d in (dicts or [])]


def to_legacy_dict_list(filters: List[BrainFilter],
                          *, qualified: bool = False,
                          ) -> List[Dict[str, Any]]:
    if qualified:
        return [f.to_legacy_dict_with_table() for f in filters]
    return [f.to_legacy_dict() for f in filters]


__all__ = [
    "BrainFilter",
    "FilterOp",
    "FilterSupport",
    "FilterSource",
    "from_legacy_dict_list",
    "to_legacy_dict_list",
]
