"""Phase Z.7 (2026-06-09) — per-execution brain log capture.

The user kept asking "where did the brain's decisions go?" because the
diagnose UI only showed structured fields (execution_path, scan_plan,
bound_report) — the rich diagnostic text the brain emits (JOIN-PRUNER
attribution, Phase S anchor bounds, BF-547 self-heal triggers,
column-stats supplement load diagnostics, partition-spec mismatches)
all went to server logs the operator never read.

This module hooks into Python's logging machinery via a custom
``Handler`` that:
  * Filters by logger name (only brain-relevant: ``core.iceberg_reader``,
    ``core.brain.*``, ``core.join_pruner``, ``api.execute_api``).
  * Further filters by message markers (PHASE_MARKERS) so the captured
    set stays the brain narrative, not the noise.
  * Resolves the current ``execution_id`` from the ContextVar (set by
    execute_api / feed_engine / reports_api / dataflow_dispatcher).
  * Appends to a per-execution circular buffer.

Read API surfaces the captured lines to ``/api/admin/queries/diagnose/
{id}`` via a new ``brain_logs`` field.  Diagnose UI renders them as a
scrollable panel — operator sees exactly what the brain saw, in order,
with timestamps and levels.

Why a logging Handler instead of instrumenting each emit site:
  * Zero risk: hooks into the same stream that already produces the
    server logs.  If a log line appears in the file, it appears in the
    buffer.  No new code paths for the brain to diverge from.
  * Future-proof: a future ``logger.info("PHASE Q: ...")`` is captured
    automatically without touching this module.
  * Idiomatic: standard library pattern, no exotic plumbing.
"""
from __future__ import annotations

import logging
import re
import threading
from datetime import datetime, timezone
from typing import Any, Dict, List


# ── What we capture ────────────────────────────────────────────────────────

# Logger names worth listening to.  Anything outside this set is ignored
# at the handler — keeps the buffer tight on the brain narrative.
#
# 2026-09-06 — ``core.federation_engine``, ``core.island_prefix_planner``
# and ``core.s3_footer_stats`` added.  Measured, by driving
# ``POST /api/business-reports/{id}/execute`` against an S3 server that
# counts requests at the wire: an ICEBERG report captured 8 lines and a
# PLAIN-PARQUET hive report captured ZERO.  Every listed prefix above is
# on the iceberg road; the plain-parquet report route is
# federation_engine, and its narrative — the unconditional
# ``[island-list]`` and ``[s3-prune]`` lines, which are precisely "what
# the brain decided and what it DECLINED to do" — went only to the server
# log.  The diagnose panel therefore answered "the brain said nothing"
# for the majority of S3 reports, which is the same failure this module
# was written to end.  The marker filter below still applies, so only
# those decision lines are captured, not federation's routine chatter.
_BRAIN_LOGGER_PREFIXES = (
    "core.iceberg_reader",
    "core.brain",
    "core.join_pruner",
    "core.iceberg_db_first_reader",
    "core.iceberg_snapshot_cache",
    "core.federation_engine",
    "core.island_prefix_planner",
    "core.s3_footer_stats",
    "api.execute_api",
)

# Message markers: only lines containing one of these substrings make it
# into the capture buffer.  Anything not matching is logged normally to
# the server log but skipped here — avoids drowning the UI in routine
# trace noise (HTTP requests, heartbeats, etc.).
PHASE_MARKERS = (
    "JOIN-PRUNER",
    "Phase S",
    "Phase Z",
    "Phase X",
    "Phase Y",
    "Phase V",
    "Phase T",
    "Phase N",
    "BF-547",
    "BF-COL-STATS",
    "BF-296",
    "BF-298",
    "self-heal",
    "auto-supplement",
    "Iceberg pruning",
    "Iceberg table",
    "Iceberg partition",
    "Iceberg cache HIT",
    "Iceberg cache MISS",
    "Raw SQL Iceberg",
    "Raw SQL partition pruning",
    "Raw SQL non-partition pruning",
    "anchor bounds",
    "synth filter",
    "injected synth",
    "manifest-list cache",
    "schema evolution",
    "data files after pruning",
    "ICEBERG-CACHE",
    "JoinPruner",
    # 2026-09-06 — the PLAIN-PARQUET report route's decision lines.  These
    # three are the whole narrative that route produces: which prefix was
    # enumerated and why the island did or did not engage; how many files
    # the listing returned and how many survived each prune stage; and
    # whether the footer pass paid for itself.  "island NOT engaged
    # (reason=...)" is the one that matters most — the system logs what it
    # DID, and this is the line that says what it DECLINED to do.
    "[island-list]",
    "[s3-prune]",
    "footer min/max pruning",
    "Footer stats pruning",
    "footer probe DECLINED",
)
_MARKER_REGEX = re.compile("|".join(re.escape(m) for m in PHASE_MARKERS))


# ── Per-execution buffer ───────────────────────────────────────────────────

_BUFFERS: Dict[str, List[Dict[str, Any]]] = {}
_BUFFERS_LOCK = threading.Lock()
_PER_EXEC_CAP = 500     # last-N per execution_id (cheap; lines are small)
_MAX_EXECUTIONS = 200   # FIFO eviction at the execution level


def _push(execution_id: str, level: str, logger_name: str, message: str) -> None:
    with _BUFFERS_LOCK:
        bucket = _BUFFERS.setdefault(execution_id, [])
        bucket.append({
            "ts":      datetime.now(timezone.utc).isoformat(),
            "level":   level,
            "logger":  logger_name,
            "message": message,
        })
        if len(bucket) > _PER_EXEC_CAP:
            del bucket[:-_PER_EXEC_CAP]
        if len(_BUFFERS) > _MAX_EXECUTIONS:
            # Drop oldest execution_ids to keep memory bounded.  Dict
            # iteration order in CPython 3.7+ is insertion order, so
            # the first keys are the oldest writes.
            _trim = len(_BUFFERS) - _MAX_EXECUTIONS
            for k in list(_BUFFERS.keys())[:_trim]:
                _BUFFERS.pop(k, None)


def get_brain_logs(execution_id: str) -> List[Dict[str, Any]]:
    """Return all captured log lines for one execution_id in order.

    Returns a shallow copy so the caller can't mutate the registry."""
    if not execution_id:
        return []
    with _BUFFERS_LOCK:
        return list(_BUFFERS.get(execution_id, []))


# ── The Handler ────────────────────────────────────────────────────────────


class BrainLogCaptureHandler(logging.Handler):
    """logging.Handler that mirrors brain-narrative log lines into the
    per-execution buffer.  Attached to the root logger at startup so it
    sees every log record emitted across the app — but filters
    aggressively so only relevant lines land in the capture.
    """

    def __init__(self):
        super().__init__()
        # We don't need stdout/stderr — this handler only captures.
        # setLevel(NOTSET) so the dispatch sees everything; we filter
        # inside emit().
        self.setLevel(logging.NOTSET)

    def emit(self, record: logging.LogRecord) -> None:
        try:
            # 1) Logger-name gate: only brain modules.
            name = record.name or ""
            if not any(name.startswith(p) for p in _BRAIN_LOGGER_PREFIXES):
                return

            # 2) Resolve the current execution_id from the ContextVar.
            #    Set by execute_query_background / feed_engine / etc.
            try:
                from core.query_diagnostic_store import get_current_execution_id
            except Exception:
                return
            execution_id = get_current_execution_id()
            if not execution_id:
                return

            # 3) Format the message (handles % args).  Skip if formatting
            #    raises — better to lose one line than break the query
            #    path the handler sits on.
            try:
                message = record.getMessage()
            except Exception:
                return

            # 4) Marker filter: only lines containing one of the PHASE
            #    markers go in.  Routine HTTP / heartbeat noise stays out.
            if not _MARKER_REGEX.search(message):
                return

            _push(execution_id, record.levelname, name, message)
        except Exception:
            # Handler MUST NOT raise — would break logging which would
            # cascade across the whole app.
            pass


_INSTALL_LOCK = threading.Lock()


def is_installed() -> bool:
    """True iff a capture handler is attached to the root logger NOW.

    Answered from the root logger's handler list, never from a flag.
    2026-09-11: ``install()`` used to remember its own first call in a
    module-global ``_INSTALLED`` and return early on it.  The handler it
    installed lives in ``logging.root.handlers``, which other code
    rewrites -- ``duckdb_forkserver._detach_nonstdio_log_handlers``
    strips every non-stdio handler from every logger, and
    ``main._configure_logging`` assigns the list wholesale -- so the flag
    said "attached" while the root logger held nothing, and every later
    ``install()`` was a no-op.  A value computed for a gate and then kept
    apart from what the system does will disagree with it; the gate now
    reads the thing itself.
    """
    return any(isinstance(h, BrainLogCaptureHandler)
               for h in logging.getLogger().handlers)


def install() -> None:
    """Attach the capture handler to the root logger.  Idempotent --
    safe to call multiple times; re-attaches if the handler has been
    stripped since the last call (see ``is_installed``).  Call from app
    startup and from any path that must be sure the capture is live."""
    with _INSTALL_LOCK:
        if is_installed():
            return
        logging.getLogger().addHandler(BrainLogCaptureHandler())
