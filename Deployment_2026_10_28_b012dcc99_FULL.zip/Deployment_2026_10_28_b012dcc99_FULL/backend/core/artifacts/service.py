"""ResultArtifactService — THE metadata + lifecycle chokepoint (Phase 6).

Every read/write of the ``result_artifacts`` table lives here (single-
chokepoint rule).  The service glues three things together:

* the **byte store** (:mod:`core.artifacts.store` — local FS or S3),
* the **metadata row** (portable SQLite+PG, plain-TEXT manifest JSON —
  no JSONB-only operators),
* the **lifecycle** (TTL + reader refcount/grace + GC sweep + orphan
  reaping + stale-temp janitor).

Serving invariants (the doc's edge cases, made structural):

* **Visibility is manifest-gated twice** — the byte store requires the
  manifest object/file (written last), and the DB row is inserted only
  AFTER the store publish returned.  A crash anywhere mid-publish leaves
  nothing a reader can observe.
* **Lookup is by ``execution_id`` ONLY.**  There is deliberately no
  "find an artifact by content address" API on the serving path: reuse
  across users flows exclusively through the Phase-5 single-flight
  chain (attach → share_verified → result grant), so this module can
  never become a new sharing path that bypasses HARD gate 1.
* **Reader refcount with a RENEWABLE lease** (L2-S1) — ``acquire_reader``
  bumps the refcount AND stamps a DB-time lease; a long-running stream
  RENEWS the lease per batch through the :class:`_ReaderLease` handle
  (monotone — never shortens a concurrent reader's later lease), so a
  slow consumer is busy for its whole read, while a crashed reader
  (leaked refcount) can only delay collection by the grace, never block
  it forever.  The reap is FENCED: byte deletion first CLAIMS the row
  with a conditional UPDATE (zero the refcount while not busy) — a
  renewal that lands first makes the reap a no-op, a claim that lands
  first makes every later renewal return False and the reader ABORTS
  (fail-open to inline delivery; a possibly-reaped artifact is never
  served).  Deletion unpublishes FIRST (row → ``deleting`` = invisible
  to new readers, then manifest, then data).
* **Integrity on serve** — the byte length recorded in the manifest is
  verified on every open; a mismatch (truncation, bit rot, eventual-
  consistency half-read) makes the artifact ABSENT (fail-closed reuse,
  hard gate 2) and the caller falls back to inline delivery (fail-open
  availability).
* **DB-time only** for every expiry comparison (the Phase-2 clock-skew
  rule): pod wall-clocks never participate in GC math.

Fail-open contract: public helpers used on the API path
(:func:`maybe_hydrate_execution_result`, :func:`artifact_gc_tick`)
NEVER raise — any error means "no artifact" and today's behavior.
"""
from __future__ import annotations

import logging
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

from sqlalchemy import text as sa_text

from core.artifacts.store import (
    ArtifactAddress, ArtifactIntegrityError, ArtifactManifest, ArtifactStore,
    ArtifactStoreError, build_arrow_ipc_from_parquet, build_store,
)

logger = logging.getLogger(__name__)

_CFG_SECTION = "industrialization_artifacts"


class ArtifactNotFound(ArtifactStoreError):
    """No published artifact exists for this execution (inline result)."""


class ArtifactRangeError(ArtifactStoreError):
    """Requested page/range starts past EOF (416-style, never a silent
    empty page)."""


class ArtifactLeaseLost(ArtifactStoreError):
    """The reader's lease could not be renewed mid-stream (the reap fence
    claimed the row, the artifact is gone, or the lease store is
    unreachable).  Callers ABORT the artifact read and fall back to
    inline delivery — a possibly-reaped artifact is never served."""


def _cfg_int(key: str, fallback: int) -> int:
    try:
        from core.config import get as _cfg_get
        return int(_cfg_get(_CFG_SECTION, key, fallback) or fallback)
    except Exception:
        return fallback


class _ReaderLease:
    """One acquired read lease (L2-S1).

    * ``renew_if_due()`` — called from inside the streaming loops; hits
      the DB only when the renew interval elapsed (pod-monotonic clock
      used ONLY for cadence — every expiry COMPARISON stays in DB time,
      the clock-skew rule).  Returns False the moment a renewal loses to
      the reap fence (or the lease store is unreachable): the reader
      must abort and fail open to inline delivery.
    * ``release()`` — exactly-once (a double release must never
      decrement a concurrent reader's refcount out from under it).
    """

    __slots__ = ("_svc", "artifact_id", "_interval", "_last",
                 "_released", "_lost", "_lock")

    def __init__(self, svc: "ResultArtifactService", artifact_id: str,
                 renew_interval_seconds: float):
        self._svc = svc
        self.artifact_id = str(artifact_id)
        self._interval = max(0.0, float(renew_interval_seconds))
        self._last = time.monotonic()
        self._released = False
        self._lost = False
        self._lock = threading.Lock()

    def renew_if_due(self) -> bool:
        with self._lock:
            if self._lost or self._released:
                return False
            if (time.monotonic() - self._last) < self._interval:
                return True
            try:
                ok = self._svc.renew_reader(self.artifact_id)
            except Exception as exc:
                # Lease store unreachable — we can no longer PROVE the
                # artifact is protected, so the read must abort (the
                # caller's inline path preserves correctness).
                logger.warning(
                    "[artifacts] lease renewal failed for %s (fail-open: "
                    "aborting artifact read, inline delivery serves): %s",
                    self.artifact_id, exc)
                ok = False
            if ok:
                self._last = time.monotonic()
            else:
                self._lost = True
            return ok

    def release(self) -> None:
        with self._lock:
            if self._released:
                return
            self._released = True
        self._svc.release_reader(self.artifact_id)


class ResultArtifactService:
    """Construct with a live DatabaseManager (same contract as JobQueue)."""

    def __init__(self, db_manager, store: Optional[ArtifactStore] = None):
        if db_manager is None:
            raise ArtifactStoreError("ResultArtifactService requires a DatabaseManager")
        self._db = db_manager
        self._store = store
        self._hydrate_locks: Dict[str, threading.Lock] = {}
        self._hydrate_guard = threading.Lock()

    # ── dialect helpers (DB-time ONLY — the clock-skew rule) ────────────

    @property
    def _is_pg(self) -> bool:
        return bool(getattr(self._db, "is_postgresql", False))

    @property
    def _now_sql(self) -> str:
        return "(now() at time zone 'utc')" if self._is_pg else "datetime('now')"

    def _future_sql(self, param: str) -> str:
        """SQL expression: DB-UTC now + :<param> seconds."""
        if self._is_pg:
            return f"((now() at time zone 'utc') + make_interval(secs => :{param}))"
        return f"datetime('now', :{param}_mod)"

    def _past_sql(self, param: str) -> str:
        """SQL expression: DB-UTC now - :<param> seconds."""
        if self._is_pg:
            return f"((now() at time zone 'utc') - make_interval(secs => :{param}))"
        return f"datetime('now', :{param}_mod)"

    def _secs_params(self, param: str, seconds: int, *, past: bool = False) -> Dict[str, Any]:
        if self._is_pg:
            return {param: int(seconds)}
        sign = "-" if past else "+"
        return {f"{param}_mod": f"{sign}{int(seconds)} seconds"}

    #: an artifact is BUSY (never deletable) only while readers hold an
    #: unexpired lease — NULL-safe on both dialects.
    def _not_busy_pred(self) -> str:
        return ("(active_readers <= 0 OR reader_lease_expires_at IS NULL "
                f"OR reader_lease_expires_at <= {self._now_sql})")

    def store(self, backend: Optional[str] = None) -> ArtifactStore:
        if self._store is not None and (backend is None
                                        or backend == self._store.name):
            return self._store
        if backend is None:
            if self._store is None:
                self._store = build_store()
            return self._store
        return build_store(backend)

    # ── publish (executor side) ─────────────────────────────────────────

    def publish_from_parquet(
        self, *,
        execution_id: str,
        job_id: str,
        plan_hash: str,
        snapshot_id: str,
        rls_key: str,
        source_parquet: Path,
        created_by: Optional[str] = None,
        ttl_seconds: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Stream a result parquet into the byte store as Arrow IPC and
        record the metadata row.  Raises on ANY failure — the executor
        caller fails OPEN (inline delivery is untouched; the artifact is
        purely additive).

        HARD gate 1: the address is the full ``(plan_hash, snapshot_id,
        rls_key)`` triple + a random salt.  An empty rls_key (legacy /
        pre-Phase-5 posture) is replaced by a per-job unique fail-closed
        key so the address can NEVER be less than the triple."""
        if not execution_id or not job_id:
            raise ArtifactStoreError("publish requires execution_id + job_id")
        source_parquet = Path(source_parquet)
        if not source_parquet.exists():
            raise ArtifactStoreError(f"result file missing: {source_parquet}")
        effective_rls_key = rls_key or f"failclosed:{job_id}"
        address = ArtifactAddress(plan_hash=str(plan_hash or ""),
                                  snapshot_id=str(snapshot_id or ""),
                                  rls_key=str(effective_rls_key))
        salt = uuid.uuid4().hex
        batch_rows = _cfg_int("ipc_batch_rows", 32768)
        ttl = int(ttl_seconds if ttl_seconds is not None
                  else _cfg_int("ttl_seconds", 86400))

        import tempfile
        tmp_dir = Path(tempfile.mkdtemp(prefix="qs_artifact_build_"))
        tmp_data = tmp_dir / f"{salt}.arrow"
        try:
            manifest = build_arrow_ipc_from_parquet(
                source_parquet, tmp_data, batch_rows=batch_rows)
            manifest = ArtifactManifest(
                rows=manifest.rows, data_bytes=manifest.data_bytes,
                checksum_sha256=manifest.checksum_sha256,
                batch_rows=manifest.batch_rows, schema=manifest.schema,
                address={"plan_hash": address.plan_hash,
                         "snapshot_id": address.snapshot_id,
                         "rls_key": address.rls_key},
                created_at=manifest.created_at,
            )
            store = self.store()
            published = store.publish(address=address, salt=salt,
                                      data_path=tmp_data, manifest=manifest)
        finally:
            try:
                if tmp_data.exists():
                    tmp_data.unlink()
                tmp_dir.rmdir()
            except OSError:
                pass

        artifact_id = str(uuid.uuid4())
        from core.db.models import ResultArtifact
        row = ResultArtifact(
            id=artifact_id,
            execution_id=str(execution_id),
            job_id=str(job_id),
            plan_hash=address.plan_hash,
            snapshot_id=address.snapshot_id,
            rls_key=address.rls_key,
            salt=salt,
            backend=published.backend,
            locator=published.locator,
            manifest_json=manifest.to_json(),
            row_count=int(manifest.rows),
            byte_size=int(manifest.data_bytes),
            checksum=manifest.checksum_sha256,
            status="published",
            active_readers=0,
            created_by=created_by,
            # Provisional pod-clock stamps — immediately overwritten below
            # with DB-time in the SAME transaction (L2-C5).
            created_at=datetime.now(timezone.utc),
            expires_at=datetime.now(timezone.utc) + timedelta(seconds=max(60, ttl)),
        )
        with self._db.get_session() as session:
            session.add(row)
            session.flush()
            # L2-C5 (2026-07-25 red-team): created_at/expires_at must be
            # DB-time — GC compares expires_at to DB now(), so a pod with a
            # skewed wall clock would give its artifacts a too-long (never
            # expiring within skew) or too-short TTL.  Same clock-skew rule
            # queue.py already follows: stamps and comparisons come from
            # the ONE database clock.
            session.execute(sa_text(f"""
                UPDATE result_artifacts
                SET created_at = {self._now_sql},
                    expires_at = {self._future_sql('ttl')}
                WHERE id = :id
            """), {"id": artifact_id,
                   **self._secs_params("ttl", max(60, ttl))})
        logger.info(
            "[artifacts] published result artifact %s for execution=%s "
            "job=%s (%d rows, %d bytes, backend=%s)",
            artifact_id, execution_id, job_id, manifest.rows,
            manifest.data_bytes, published.backend)
        return {"id": artifact_id, "execution_id": str(execution_id),
                "backend": published.backend, "locator": published.locator,
                "row_count": manifest.rows, "byte_size": manifest.data_bytes}

    # ── lookup (execution-linked ONLY — see module docstring) ───────────

    def get_for_execution(self, execution_id: str) -> Optional[Dict[str, Any]]:
        """Newest PUBLISHED artifact for this execution, or None."""
        if not execution_id:
            return None
        with self._db.get_session(read_only=True) as session:
            row = session.execute(sa_text("""
                SELECT id, execution_id, job_id, plan_hash, snapshot_id,
                       rls_key, backend, locator, manifest_json, row_count,
                       byte_size, checksum, status
                FROM result_artifacts
                WHERE execution_id = :e AND status = 'published'
                ORDER BY created_at DESC, id DESC
                LIMIT 1
            """), {"e": str(execution_id)}).mappings().first()
        return dict(row) if row else None

    # ── reader refcount / lease (acquire → renew → release) ────────────

    def _lease_extend_sql(self, param: str) -> str:
        """SET fragment: extend the lease MONOTONELY to DB-now+:param —
        never shorten another reader's later lease (max(lease_until)
        via portable CASE, no dialect-specific GREATEST-on-null games)."""
        future = self._future_sql(param)
        return (f"reader_lease_expires_at = CASE "
                f"WHEN reader_lease_expires_at IS NULL "
                f"  OR reader_lease_expires_at < {future} "
                f"THEN {future} ELSE reader_lease_expires_at END")

    def acquire_reader(self, artifact_id: str) -> bool:
        """Register an active reader (refcount + DB-time lease).  Returns
        False when the artifact is no longer published (GC unpublished it
        between lookup and acquire) — the caller treats that as absent.
        The conditional UPDATE races the GC's conditional unpublish on
        the same row: the DB serializes them, so either the acquire wins
        (artifact busy → reap is a no-op) or the reap wins (rowcount 0 →
        clean absent)."""
        grace = _cfg_int("reader_grace_seconds", 600)
        with self._db.get_session() as session:
            n = session.execute(sa_text(f"""
                UPDATE result_artifacts SET
                    active_readers = active_readers + 1,
                    {self._lease_extend_sql('grace')},
                    last_read_at = {self._now_sql}
                WHERE id = :id AND status = 'published'
            """), {"id": artifact_id,
                   **self._secs_params("grace", grace)}).rowcount
        return n == 1

    def renew_reader(self, artifact_id: str) -> bool:
        """L2-S1: extend the lease MID-STREAM so a slow consumer stays
        busy for its whole read.  FENCED: requires a live refcount, so a
        renewal can only succeed while the reap fence (which zeroes
        ``active_readers`` before deleting bytes) has not claimed the
        row — one conditional UPDATE per side, DB-serialized, multi-pod
        safe.  Deliberately does NOT require status='published': an
        in-flight reader keeps its protection across an unpublish (TTL /
        orphan reap) and the byte-delete pass waits for it.  Returns
        False when the row is gone/claimed → the reader must abort.
        Raises on DB errors (the lease handle turns that into a lost
        lease — fail-open)."""
        grace = _cfg_int("reader_grace_seconds", 600)
        with self._db.get_session() as session:
            n = session.execute(sa_text(f"""
                UPDATE result_artifacts SET
                    {self._lease_extend_sql('grace')},
                    last_read_at = {self._now_sql}
                WHERE id = :id AND active_readers > 0
            """), {"id": artifact_id,
                   **self._secs_params("grace", grace)}).rowcount
        return n == 1

    def acquire_lease(self, artifact_id: str) -> Optional[_ReaderLease]:
        """Acquire and wrap in a renewable, release-once lease handle —
        what the read paths use.  None → artifact no longer published."""
        if not self.acquire_reader(artifact_id):
            return None
        grace = _cfg_int("reader_grace_seconds", 600)
        interval = _cfg_int("lease_renew_interval_seconds",
                            max(1, grace // 3))
        return _ReaderLease(self, artifact_id, float(interval))

    def release_reader(self, artifact_id: str) -> None:
        """Idempotent decrement (floor 0).  Never raises."""
        try:
            with self._db.get_session() as session:
                session.execute(sa_text("""
                    UPDATE result_artifacts SET
                        active_readers = CASE WHEN active_readers > 0
                                              THEN active_readers - 1
                                              ELSE 0 END
                    WHERE id = :id
                """), {"id": artifact_id})
        except Exception as exc:
            logger.warning("[artifacts] release_reader failed for %s "
                           "(lease grace will unblock GC): %s",
                           artifact_id, exc)

    # ── reads ───────────────────────────────────────────────────────────

    def _open_verified(self, art: Dict[str, Any]) -> Tuple[Path, ArtifactManifest]:
        manifest = ArtifactManifest.from_json(art["manifest_json"])
        store = self.store(art.get("backend"))
        path = store.open_local(art["locator"], manifest,
                                cache_key=str(art["id"]))
        return path, manifest

    def read_range_for_execution(self, execution_id: str, offset: int,
                                 limit: int) -> Tuple[bytes, Dict[str, Any]]:
        """Serve ``limit`` rows starting at ``offset`` as a serialized
        Arrow IPC **stream**, reading ONLY the record batches that
        intersect the range (offset+limit over Arrow record batches —
        never the whole artifact).

        Returns ``(ipc_stream_bytes, meta)``.  Raises
        :class:`ArtifactNotFound` (no artifact / unpublished / integrity
        failure) or :class:`ArtifactRangeError` (offset past EOF)."""
        art = self.get_for_execution(execution_id)
        if art is None:
            raise ArtifactNotFound(
                f"no published artifact for execution {execution_id}")
        lease = self.acquire_lease(art["id"])
        if lease is None:
            raise ArtifactNotFound(
                f"artifact {art['id']} was unpublished before read")
        try:
            try:
                path, manifest = self._open_verified(art)
            except ArtifactIntegrityError as exc:
                logger.warning("[artifacts] integrity failure on serve — "
                               "treating as absent: %s", exc)
                raise ArtifactNotFound(str(exc))
            try:
                return _read_range_ipc(path, manifest, offset, limit,
                                       renew=lease.renew_if_due)
            except ArtifactLeaseLost as exc:
                # L2-S1: the reap fence won mid-stream — never serve a
                # possibly-reaped artifact; the caller falls back inline.
                logger.warning("[artifacts] range read aborted — %s", exc)
                raise ArtifactNotFound(str(exc))
            except FileNotFoundError as exc:
                # Bytes vanished under us (reaped despite everything /
                # external delete) — same fail-open: absent, inline serves.
                logger.warning("[artifacts] artifact bytes vanished "
                               "mid-read — treating as absent: %s", exc)
                raise ArtifactNotFound(
                    f"artifact bytes vanished mid-read: {exc}")
        finally:
            lease.release()

    def hydrate_parquet_for_execution(self, execution_id: str,
                                      dest_dir: Path) -> Optional[Path]:
        """Materialize the artifact as ``<dest_dir>/<execution_id>.parquet``
        (batch-streamed — bounded memory; atomic temp+rename), so EVERY
        existing result surface (DuckDB pagination, charts, pivot,
        exports, Arrow endpoint) serves from it unchanged on any pod.

        Returns the local path, or None when no artifact exists.  Raises
        only on real store/DB errors (callers fail open)."""
        art = self.get_for_execution(execution_id)
        if art is None:
            return None
        dest_dir = Path(dest_dir)
        dest = dest_dir / f"{execution_id}.parquet"
        if dest.exists():
            return dest
        with self._hydrate_guard:
            lock = self._hydrate_locks.setdefault(str(execution_id),
                                                  threading.Lock())
            # L2-C6 (2026-07-25): bound the per-key dict (passport_registry
            # FIFO idiom) — never let a long-lived process grow it
            # unbounded.  Held locks are skipped (evicting one would only
            # cost duplicate hydrate work, but skipping is free); an
            # evicted key simply mints a fresh lock next time.
            while len(self._hydrate_locks) > 4096:
                evicted = False
                for k in list(self._hydrate_locks):
                    lk = self._hydrate_locks[k]
                    if lk is lock or lk.locked():
                        continue
                    self._hydrate_locks.pop(k, None)
                    evicted = True
                    break
                if not evicted:
                    break
        with lock:
            if dest.exists():
                return dest
            lease = self.acquire_lease(art["id"])
            if lease is None:
                return None
            try:
                try:
                    path, manifest = self._open_verified(art)
                except ArtifactIntegrityError as exc:
                    logger.warning("[artifacts] integrity failure on hydrate "
                                   "— treating as absent: %s", exc)
                    return None
                dest_dir.mkdir(parents=True, exist_ok=True)
                tmp = dest_dir / f"_tmp-hydrate-{uuid.uuid4().hex}.parquet"
                try:
                    try:
                        _stream_ipc_to_parquet(path, tmp,
                                               renew=lease.renew_if_due)
                    except (ArtifactLeaseLost, FileNotFoundError) as exc:
                        # L2-S1 fail-open: lease lost / bytes reaped
                        # mid-stream → absent; caller serves inline.
                        logger.warning("[artifacts] hydrate aborted — "
                                       "treating as absent: %s", exc)
                        return None
                    import os as _os
                    _os.replace(str(tmp), str(dest))
                finally:
                    try:
                        if tmp.exists():
                            tmp.unlink()
                    except OSError:
                        pass
                logger.info("[artifacts] hydrated execution %s from artifact "
                            "%s (%d rows) → %s", execution_id, art["id"],
                            manifest.rows, dest)
                return dest
            finally:
                lease.release()

    # ── GC sweep (executor/reaper cadence; N sweepers safe) ─────────────

    def gc_sweep(self) -> Dict[str, int]:
        """One idempotent lifecycle pass:

          1. UNPUBLISH expired artifacts that hold no live reader lease
             (row → ``deleting``: instantly invisible to lookups);
          2. UNPUBLISH orphans (published rows past a minimum age whose
             job AND execution rows are both gone);
          3. DELETE bytes for ``deleting`` rows with no live lease —
             manifest first, then data, then the metadata row (a failed
             byte delete leaves the row for the next sweep);
          4. sweep stale temp/spool leftovers.

        Every step is a conditional UPDATE/bounded scan — concurrent
        sweeps on N executors are safe.  Never raises."""
        out = {"expired": 0, "orphaned": 0, "deleted": 0, "temp_swept": 0}
        now = self._now_sql
        not_busy = self._not_busy_pred()
        try:
            with self._db.get_session() as session:
                out["expired"] = session.execute(sa_text(f"""
                    UPDATE result_artifacts SET status = 'deleting'
                    WHERE status = 'published'
                      AND expires_at IS NOT NULL AND expires_at < {now}
                      AND {not_busy}
                """)).rowcount
        except Exception as exc:
            logger.warning("[artifacts] gc expiry pass failed: %s", exc)

        try:
            out["orphaned"] = self._reap_orphans()
        except Exception as exc:
            logger.warning("[artifacts] gc orphan pass failed: %s", exc)

        try:
            out["deleted"] = self._delete_unpublished()
        except Exception as exc:
            logger.warning("[artifacts] gc delete pass failed: %s", exc)

        try:
            grace = _cfg_int("reader_grace_seconds", 600)
            out["temp_swept"] = self.store().sweep_temp(grace)
        except Exception as exc:
            logger.debug("[artifacts] gc temp sweep failed: %s", exc)

        if any(out.values()):
            logger.info("[artifacts] gc sweep: %s", out)
        return out

    def _reap_orphans(self) -> int:
        """Published artifacts past a minimum age whose job row AND
        execution row are both gone → unpublish.  Conservative: any
        lookup uncertainty keeps the artifact (fail-open)."""
        min_age = _cfg_int("orphan_min_age_seconds", 3600)
        with self._db.get_session(read_only=True) as session:
            rows = session.execute(sa_text(f"""
                SELECT id, execution_id, job_id FROM result_artifacts
                WHERE status = 'published'
                  AND created_at < {self._past_sql('age')}
                ORDER BY created_at ASC
                LIMIT 200
            """), self._secs_params("age", min_age, past=True)).fetchall()
        if not rows:
            return 0
        orphaned = 0
        for art_id, execution_id, job_id in rows:
            try:
                with self._db.get_session(read_only=True) as session:
                    job = session.execute(sa_text(
                        "SELECT 1 FROM query_jobs WHERE id = :id LIMIT 1"),
                        {"id": job_id}).first()
                    if job is not None:
                        continue
                    ex = session.execute(sa_text(
                        "SELECT 1 FROM query_executions WHERE id = :id LIMIT 1"),
                        {"id": execution_id}).first()
                    if ex is not None:
                        continue
            except Exception:
                continue  # uncertainty → keep (fail-open)
            with self._db.get_session() as session:
                orphaned += session.execute(sa_text("""
                    UPDATE result_artifacts SET status = 'deleting'
                    WHERE id = :id AND status = 'published'
                """), {"id": art_id}).rowcount
        return orphaned

    def _delete_unpublished(self) -> int:
        with self._db.get_session(read_only=True) as session:
            rows = session.execute(sa_text(f"""
                SELECT id, backend, locator FROM result_artifacts
                WHERE status = 'deleting' AND {self._not_busy_pred()}
                ORDER BY created_at ASC
                LIMIT 200
            """)).fetchall()
        deleted = 0
        for art_id, backend, locator in rows:
            # L2-S1 REAP FENCE: between the scan above and the byte delete
            # below, a live reader's renewal may have re-armed the lease.
            # CLAIM the row first with one conditional UPDATE (zero the
            # refcount while still not busy) — the DB serializes it
            # against renew_reader's UPDATE on the same row, so exactly
            # one side wins: a renewal that landed first keeps the row
            # busy (claim rowcount 0 → skip, reap is a NO-OP); a claim
            # that lands first makes every later renewal fail
            # (``active_readers > 0`` is false) → the reader aborts and
            # never serves reaped bytes.  Multi-pod safe: the fence is
            # DB state, not an in-process lock.
            try:
                with self._db.get_session() as session:
                    claimed = session.execute(sa_text(f"""
                        UPDATE result_artifacts
                        SET active_readers = 0,
                            reader_lease_expires_at = NULL
                        WHERE id = :id AND status = 'deleting'
                          AND {self._not_busy_pred()}
                    """), {"id": art_id}).rowcount
            except Exception as exc:
                logger.warning("[artifacts] reap-fence claim failed for %s "
                               "(retried next sweep): %s", art_id, exc)
                continue
            if claimed != 1:
                continue   # a live lease re-armed since the scan — no-op
            try:
                store = self.store(backend)
                store.delete(locator)
                drop_spool = getattr(store, "drop_spool", None)
                if callable(drop_spool):
                    drop_spool(str(art_id))
            except Exception as exc:
                logger.warning("[artifacts] byte delete failed for %s "
                               "(retried next sweep): %s", art_id, exc)
                continue
            with self._db.get_session() as session:
                deleted += session.execute(sa_text(
                    "DELETE FROM result_artifacts WHERE id = :id "
                    "AND status = 'deleting'"), {"id": art_id}).rowcount
        return deleted


# ── pure IPC range/stream helpers ───────────────────────────────────────

def _lease_check(renew) -> None:
    """L2-S1: invoke the streaming loop's renew hook (cadence-throttled
    inside the lease handle).  A failed renewal means the reap fence may
    have won — abort instead of serving possibly-reaped bytes."""
    if renew is not None and not renew():
        raise ArtifactLeaseLost(
            "reader lease lost mid-stream — the artifact may have been "
            "reaped; aborting (caller falls back to inline delivery)")


def _read_range_ipc(path: Path, manifest: ArtifactManifest,
                    offset: int, limit: int,
                    renew=None) -> Tuple[bytes, Dict[str, Any]]:
    """Read [offset, offset+limit) from an Arrow IPC file, touching ONLY
    the record batches that intersect the range, and serialize the slice
    as an IPC stream (done inside the memory-map scope so no buffer
    outlives the map).  ``renew`` (optional zero-arg → bool) is the
    reader-lease renewal hook, called before the open and per record
    batch — a slow consumer keeps its lease alive for the whole read."""
    import pyarrow as pa

    offset = max(0, int(offset))
    limit = max(1, int(limit))
    total = int(manifest.rows)
    if offset >= total and not (offset == 0 and total == 0):
        raise ArtifactRangeError(
            f"offset {offset} is past the end of the result ({total} rows)")

    _lease_check(renew)
    with pa.memory_map(str(path), "r") as mm:
        reader = pa.ipc.open_file(mm)
        schema = reader.schema
        n_batches = reader.num_record_batches
        counts = list(manifest.batch_rows)

        selected = []
        first_start: Optional[int] = None
        start = 0
        for i in range(n_batches):
            if i < len(counts):
                n = counts[i]
                batch = None
            else:  # manifest without batch index (older writer) — read to size
                _lease_check(renew)
                batch = reader.get_batch(i)
                n = batch.num_rows
            end = start + n
            if end > offset and start < offset + limit:
                if batch is None:
                    _lease_check(renew)
                    batch = reader.get_batch(i)
                selected.append(batch)
                if first_start is None:
                    first_start = start
            start = end
            if start >= offset + limit:
                break

        if not selected:
            table = pa.table({f.name: pa.array([], type=f.type)
                              for f in schema})
        else:
            table = pa.Table.from_batches(selected)
            table = table.slice(offset - int(first_start or 0), limit)

        sink = pa.BufferOutputStream()
        with pa.ipc.new_stream(sink, schema) as writer:
            writer.write_table(table)
        payload = bytes(sink.getvalue())
        meta = {
            "total_rows": total,
            "offset": offset,
            "rows_in_page": table.num_rows,
            "columns": [f.name for f in schema],
        }
    return payload, meta


def _stream_ipc_to_parquet(src_ipc: Path, dest_parquet: Path,
                           renew=None) -> int:
    """Convert an Arrow IPC file to parquet batch-by-batch (bounded
    memory).  Returns rows written.  ``renew`` is the reader-lease
    renewal hook (see :func:`_lease_check`) — hydrating a huge result is
    THE long-running consumer the L2-S1 lease protects."""
    import pyarrow as pa
    import pyarrow.parquet as pq

    rows = 0
    _lease_check(renew)
    with pa.memory_map(str(src_ipc), "r") as mm:
        reader = pa.ipc.open_file(mm)
        writer = pq.ParquetWriter(str(dest_parquet), reader.schema)
        try:
            for i in range(reader.num_record_batches):
                _lease_check(renew)
                batch = reader.get_batch(i)
                writer.write_batch(batch)
                rows += batch.num_rows
        finally:
            writer.close()
    return rows


# ── module singleton + fail-open convenience wrappers ───────────────────

_service: Optional[ResultArtifactService] = None
_service_lock = threading.Lock()


def get_artifact_service(db_manager=None) -> ResultArtifactService:
    """Process-wide service.  First call must provide (or be able to
    resolve) a DatabaseManager; later calls reuse the singleton.

    L2-C3 (2026-07-25): an explicitly-passed DIFFERENT DatabaseManager
    REBINDS the singleton instead of being silently ignored (see
    get_job_queue for the rationale)."""
    global _service
    if _service is None:
        with _service_lock:
            if _service is None:
                if db_manager is None:
                    db_manager = _default_db_manager()
                _service = ResultArtifactService(db_manager)
                return _service
    if db_manager is not None and db_manager is not _service._db:
        with _service_lock:
            if db_manager is not _service._db:
                logger.warning(
                    "get_artifact_service: rebinding singleton to a "
                    "DIFFERENT DatabaseManager (old=%r new=%r)",
                    _service._db, db_manager)
                _service = ResultArtifactService(db_manager)
    return _service


def reset_artifact_service_for_tests() -> None:
    global _service
    with _service_lock:
        _service = None


def _default_db_manager():
    try:
        import main as _main
        dbm = getattr(_main, "db_manager", None)
        if dbm is not None:
            return dbm
    except Exception:
        pass
    raise ArtifactStoreError(
        "no DatabaseManager available for ResultArtifactService — pass one "
        "explicitly or initialize the app first")


def _flag_on() -> bool:
    try:
        from core.industrialization import is_enabled
        return is_enabled("result_artifacts")
    except Exception:
        return False


def maybe_hydrate_execution_result(execution_id: str,
                                   dest_dir: Path) -> Optional[Path]:
    """API-side fail-open fallback (called from ``find_csv_file`` AFTER
    every existing local/S3 fallback missed): if the flag is armed and a
    published artifact exists for this execution, materialize it locally
    and return the parquet path.  Flag OFF → one flag read, None.  Any
    error → None (today's 404/pending behavior).

    AUTHZ NOTE: like the existing S3-results fallback in the same
    function, this performs NO authorization — every calling endpoint
    enforces ``_enforce_execution_ownership`` (owner / service / admin /
    verified single-flight grant) BEFORE resolving the file."""
    if not _flag_on():
        return None
    try:
        svc = get_artifact_service()
        return svc.hydrate_parquet_for_execution(str(execution_id),
                                                 Path(dest_dir))
    except Exception as exc:
        logger.warning("[artifacts] hydration fallback failed for %s "
                       "(fail-open): %s", execution_id, exc)
        return None


def artifact_gc_tick(db_manager=None) -> Optional[Dict[str, int]]:
    """Flag-gated GC entry point for the executor/reaper cadence.  Flag
    OFF → no-op after one read.  Never raises."""
    if not _flag_on():
        return None
    try:
        return get_artifact_service(db_manager).gc_sweep()
    except Exception as exc:
        logger.warning("[artifacts] gc tick failed (non-fatal, retried "
                       "next cadence): %s", exc)
        return None
