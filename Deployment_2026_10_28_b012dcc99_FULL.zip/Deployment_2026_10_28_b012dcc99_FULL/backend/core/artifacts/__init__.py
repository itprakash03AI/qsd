"""Industrialization Phase 6 — content-addressed result artifacts.

One artifact abstraction for pagination + single-flight fan-out + export
(+ Phase 8 materialized islands later): the executor streams a result as
an Arrow IPC file to a pluggable byte store (local FS or S3) under the
full content address ``(plan_hash, snapshot_id, rls_key)`` + salt; the
API serves full/page/range reads from the artifact; a TTL + refcount GC
owns the lifecycle.  Flag-gated by ``industrialization.result_artifacts``
(default OFF — byte-for-byte today's behavior), fail-open everywhere.

Public surface:
    * :class:`ArtifactStore` + backends + :func:`register_backend` /
      :func:`build_store` (bytes),
    * :class:`ResultArtifactService` + :func:`get_artifact_service`
      (metadata + lifecycle + reads),
    * fail-open wrappers :func:`maybe_hydrate_execution_result` and
      :func:`artifact_gc_tick` for the API / executor call sites.
"""
from core.artifacts.store import (               # noqa: F401
    ArtifactAddress,
    ArtifactIntegrityError,
    ArtifactManifest,
    ArtifactStore,
    ArtifactStoreError,
    LocalArtifactStore,
    PublishedArtifact,
    S3ArtifactStore,
    build_store,
    register_backend,
)
from core.artifacts.service import (             # noqa: F401
    ArtifactNotFound,
    ArtifactRangeError,
    ResultArtifactService,
    artifact_gc_tick,
    get_artifact_service,
    maybe_hydrate_execution_result,
    reset_artifact_service_for_tests,
)

__all__ = [
    "ArtifactAddress", "ArtifactIntegrityError", "ArtifactManifest",
    "ArtifactStore", "ArtifactStoreError", "LocalArtifactStore",
    "PublishedArtifact", "S3ArtifactStore", "build_store",
    "register_backend",
    "ArtifactNotFound", "ArtifactRangeError", "ResultArtifactService",
    "artifact_gc_tick", "get_artifact_service",
    "maybe_hydrate_execution_result", "reset_artifact_service_for_tests",
]
