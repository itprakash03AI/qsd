"""Result-artifact BYTE stores (Industrialization Phase 6).

The store moves query results OUT of pod RAM: the executor streams the
result as an **Arrow IPC file** (random-access format — record batches
are individually addressable, which is what makes page/range reads
possible without loading the whole result) to a backend, and every later
consumer (pagination, export, single-flight fan-out) reads ranges from
that one artifact.

Two backends behind one abstract interface (plugin registry — adding a
backend is one class + one ``register_backend`` call):

* :class:`LocalArtifactStore` — a directory on local disk / NFS.  The
  on-prem posture: QS on-prem has NO DuckDB httpfs and uses presigned /
  pre-download flows, so results must be able to live on a mounted
  filesystem.  Atomic publish = write to a temp name in the SAME
  directory + ``os.replace`` (data first, manifest last).
* :class:`S3ArtifactStore` — a QS-owned bucket/prefix.  Publish = upload
  the data object, then put the manifest object LAST.  Reads spool the
  object to a local cache file once (Trino spooling-protocol analogue:
  segments live in object storage, the serving pod fetches by handle),
  then serve ranges from the local copy via memory-mapped Arrow.

Torn-write safety (the doc's edge cases): an artifact **without its
manifest does not exist** — readers require the manifest object/file and
verify the recorded byte length before serving; a crash mid-upload
leaves no manifest, so nothing can ever observe a half-artifact.
Deletion runs in the opposite order: manifest FIRST (unpublish), then
data.

Addresses contain ONLY hashes/uuids (plan_hash / snapshot / rls_key /
salt) — never usernames or SQL (the sensitive-data-in-paths edge case).

Fail-open contract: every method raises loudly on error; CALLERS treat
a store failure as "no artifact" and fall back to today's inline result
delivery — a store hiccup can never lose a query.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import threading
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

_CFG_SECTION = "industrialization_artifacts"

#: Manifest schema version (additive-only; readers ignore unknown fields).
MANIFEST_VERSION = 1

_MANIFEST_SUFFIX = ".manifest.json"
_TEMP_PREFIX = "_tmp-"


class ArtifactStoreError(RuntimeError):
    """Base error for artifact byte-store operations."""


class ArtifactIntegrityError(ArtifactStoreError):
    """The stored bytes do not match the manifest (truncation / bit rot /
    eventual-consistency read of a half-object).  Treated as ABSENT by
    callers — fail-closed reuse (hard gate 2), fail-open delivery."""


def _cfg(key: str, fallback):
    try:
        from core.config import get as _cfg_get
        v = _cfg_get(_CFG_SECTION, key, fallback)
        return type(fallback)(v) if v is not None else fallback
    except Exception:
        return fallback


# ── sha256 verification (2026-07-23 red-team M2) ────────────────────────
#
# checksum_sha256 was recorded in every manifest but no reader verified it
# — same-length corruption (bit rot, torn overwrite) served wrong bytes.
# Verification runs ONCE per artifact per process (at S3 spool time / on
# local first-open) and is cached against (checksum, size, mtime); a
# mismatch raises ArtifactIntegrityError → callers treat the artifact as
# ABSENT (fail-closed reuse, fail-open delivery).  Manifests without a
# checksum (older writers) keep the length-only check — compat, additive.

_verified_lock = threading.Lock()
_verified: Dict[str, Tuple[str, int, float]] = {}
_VERIFIED_MAX = 4096


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with open(str(path), "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def verify_artifact_checksum(path: Path, manifest: "ArtifactManifest",
                             *, cache_key: str) -> None:
    """Verify ``path``'s sha256 against the manifest, once per process
    (cached on (checksum, size, mtime)).  Raises
    :class:`ArtifactIntegrityError` on mismatch."""
    checksum = (getattr(manifest, "checksum_sha256", "") or "").strip()
    if not checksum:
        return   # legacy manifest without a checksum — length check only
    try:
        st = Path(path).stat()
    except OSError as exc:
        raise ArtifactIntegrityError(
            f"artifact data unreadable for checksum verify: {path}: {exc}")
    sig = (checksum, int(st.st_size), float(st.st_mtime))
    with _verified_lock:
        if _verified.get(cache_key) == sig:
            return
    actual = _sha256_file(Path(path))
    if actual != checksum:
        raise ArtifactIntegrityError(
            f"artifact sha256 mismatch for {path}: manifest={checksum} "
            f"actual={actual} (same-length corruption)")
    with _verified_lock:
        _verified[cache_key] = sig
        if len(_verified) > _VERIFIED_MAX:
            for k in list(_verified.keys())[:_VERIFIED_MAX // 4]:
                _verified.pop(k, None)


def _drop_verified(cache_key: str) -> None:
    with _verified_lock:
        _verified.pop(cache_key, None)


def _safe_segment(value: str, fallback: str = "none") -> str:
    """A path/key segment built ONLY from [A-Za-z0-9_-] — rls_keys such as
    ``failclosed:<uuid>`` carry ':' which is illegal on Windows paths."""
    cleaned = re.sub(r"[^A-Za-z0-9_-]", "_", str(value or ""))[:80]
    return cleaned or fallback


@dataclass(frozen=True)
class ArtifactAddress:
    """The content address (HARD gate 1: never less than the full
    ``(plan_hash, snapshot_id, rls_key)`` triple)."""
    plan_hash: str
    snapshot_id: str
    rls_key: str

    def key_path(self, salt: str) -> str:
        """Relative storage path — hashes/uuids only, never user data."""
        return "/".join((
            _safe_segment(self.plan_hash, "noplan"),
            _safe_segment(self.snapshot_id, "nosnap"),
            _safe_segment(self.rls_key, "nokey"),
            f"{_safe_segment(salt, 'salt')}.arrow",
        ))


@dataclass(frozen=True)
class ArtifactManifest:
    """The visibility gate: written LAST, verified on serve."""
    rows: int
    data_bytes: int
    checksum_sha256: str
    batch_rows: Tuple[int, ...]           # rows per IPC record batch, in order
    schema: List[Dict[str, str]]          # [{"name":..., "type":...}] (display; IPC file is authoritative)
    address: Dict[str, str]
    created_at: float
    version: int = MANIFEST_VERSION
    extras: Dict[str, Any] = field(default_factory=dict)

    def to_json(self) -> str:
        d = {
            "version": self.version, "rows": self.rows,
            "data_bytes": self.data_bytes,
            "checksum_sha256": self.checksum_sha256,
            "batch_rows": list(self.batch_rows),
            "schema": self.schema, "address": dict(self.address),
            "created_at": self.created_at,
        }
        d.update(self.extras or {})
        return json.dumps(d, sort_keys=True, separators=(",", ":"))

    @classmethod
    def from_json(cls, raw: str) -> "ArtifactManifest":
        d = json.loads(raw)
        return cls(
            rows=int(d["rows"]), data_bytes=int(d["data_bytes"]),
            checksum_sha256=str(d.get("checksum_sha256") or ""),
            batch_rows=tuple(int(x) for x in (d.get("batch_rows") or [])),
            schema=list(d.get("schema") or []),
            address=dict(d.get("address") or {}),
            created_at=float(d.get("created_at") or 0.0),
            version=int(d.get("version") or 1),
        )


@dataclass(frozen=True)
class PublishedArtifact:
    """What a successful write returns — everything the metadata row needs."""
    backend: str
    locator: str
    manifest: ArtifactManifest


def build_arrow_ipc_from_parquet(source_parquet: Path, dest_path: Path,
                                 *, batch_rows: int) -> ArtifactManifest:
    """Stream a result parquet into an Arrow IPC **file** at ``dest_path``
    (temp path chosen by the caller) batch-by-batch — memory stays bounded
    by one batch, never the whole result.  Returns the manifest describing
    what was written (rows, bytes, checksum, per-batch row counts)."""
    import pyarrow as pa
    import pyarrow.parquet as pq

    pf = pq.ParquetFile(str(source_parquet))
    schema = pf.schema_arrow
    counts: List[int] = []
    total = 0
    with pa.OSFile(str(dest_path), "wb") as sink:
        with pa.ipc.new_file(sink, schema) as writer:
            for batch in pf.iter_batches(batch_size=max(1024, int(batch_rows))):
                writer.write_batch(batch)
                counts.append(batch.num_rows)
                total += batch.num_rows

    data_bytes = os.path.getsize(dest_path)
    digest = hashlib.sha256()
    with open(dest_path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return ArtifactManifest(
        rows=total, data_bytes=data_bytes,
        checksum_sha256=digest.hexdigest(),
        batch_rows=tuple(counts),
        schema=[{"name": f.name, "type": str(f.type)} for f in schema],
        address={}, created_at=time.time(),
    )


class ArtifactStore(ABC):
    """Abstract byte store.  Implementations MUST be safe for concurrent
    writers of DIFFERENT artifacts (the salt makes every locator unique)
    and MUST make publish atomic + manifest-last."""

    name: str = "abstract"

    @abstractmethod
    def publish(self, *, address: ArtifactAddress, salt: str,
                data_path: Path, manifest: ArtifactManifest) -> PublishedArtifact:
        """Move/upload the finished IPC file + write the manifest LAST.
        ``data_path`` is a local temp file the caller prepared."""

    @abstractmethod
    def open_local(self, locator: str, manifest: ArtifactManifest,
                   *, cache_key: str) -> Path:
        """Return a LOCAL path to the artifact's IPC bytes, verifying the
        manifest's recorded length (cheap integrity check on serve).  S3
        spools to a local cache file keyed by ``cache_key``; local returns
        the file itself.  Raises :class:`ArtifactIntegrityError` on any
        length mismatch (callers treat as absent → recompute/fallback)."""

    @abstractmethod
    def delete(self, locator: str) -> None:
        """Delete manifest FIRST (unpublish), then data.  Idempotent —
        missing objects are not an error."""

    @abstractmethod
    def sweep_temp(self, older_than_seconds: float) -> int:
        """Remove stale temp leftovers (crashed writers).  Returns count."""


# ── Local filesystem backend (on-prem / dev / NFS) ──────────────────────

def _long_path_safe(path: Path) -> Path:
    """Windows: opt an absolute path out of the legacy 260-char MAX_PATH.

    2026-08-19 — an artifact's key path is three long segments by design:
    ``<plan_hash:64>/<snapshot_id>/<rls_key:64>/<salt>.arrow``.  That is
    ~140 characters before the root, which is fine on the Linux deployment
    and fine on a Windows box with LongPathsEnabled — and on a Windows box
    WITHOUT it, every publish under a deep root dies with::

        FileNotFoundError: [WinError 206] The filename or extension is too
        long: '...\\artifact_store\\snap-1\\kkkk...pppp'

    WinError 206 names neither the limit nor the registry switch, so it
    reads as a corrupted path rather than a platform ceiling.  The ``\\\\?\\``
    prefix tells the Win32 API to skip MAX_PATH parsing; it requires a
    fully-resolved absolute path with no ``.``/``..`` segments, which is why
    we resolve first and bail out if anything looks unusual.

    No-op on POSIX and on paths already short enough or already prefixed, so
    the stored locator is byte-identical everywhere it was working before.
    """
    if os.name != "nt":
        return path
    text = str(path)
    if text.startswith("\\\\?\\") or len(text) < 240:
        return path
    try:
        resolved = path.resolve()
    except (OSError, ValueError):
        return path
    text = str(resolved)
    if text.startswith("\\\\?\\"):
        return resolved
    if text.startswith("\\\\"):                      # UNC \\server\share
        return Path("\\\\?\\UNC" + text[1:])
    if len(text) > 1 and text[1] == ":":             # drive-letter absolute
        return Path("\\\\?\\" + text)
    return path                                      # relative — leave alone


class LocalArtifactStore(ArtifactStore):
    name = "local"

    def __init__(self, root: Optional[Path] = None):
        if root is None:
            configured = str(_cfg("local_root", "") or "").strip()
            if configured:
                root = Path(configured)
            else:
                from core.config import paths as _paths
                root = _paths.data_dir / "result_artifacts"
        self._root = Path(root)

    @property
    def root(self) -> Path:
        return self._root

    def _final_path(self, address: ArtifactAddress, salt: str) -> Path:
        # Every write and read in this class funnels through here, so the
        # MAX_PATH opt-out belongs at this one point rather than at each
        # mkdir/replace/open site.
        return _long_path_safe(self._root / Path(address.key_path(salt)))

    def publish(self, *, address: ArtifactAddress, salt: str,
                data_path: Path, manifest: ArtifactManifest) -> PublishedArtifact:
        final = self._final_path(address, salt)
        final.parent.mkdir(parents=True, exist_ok=True)
        # Atomic within one filesystem: temp already lives elsewhere, so
        # stage into the destination directory first, then os.replace.
        staged = final.parent / f"{_TEMP_PREFIX}{uuid.uuid4().hex}.arrow"
        try:
            os.replace(str(data_path), str(staged))
        except OSError:
            # Cross-device (temp dir on another mount) → copy then remove.
            import shutil
            shutil.copyfile(str(data_path), str(staged))
            try:
                os.unlink(str(data_path))
            except OSError:
                pass
        os.replace(str(staged), str(final))
        # Manifest LAST — the visibility gate.
        mpath = Path(str(final) + _MANIFEST_SUFFIX)
        mtmp = final.parent / f"{_TEMP_PREFIX}{uuid.uuid4().hex}.json"
        mtmp.write_text(manifest.to_json(), encoding="utf-8")
        os.replace(str(mtmp), str(mpath))
        return PublishedArtifact(backend=self.name, locator=str(final),
                                 manifest=manifest)

    def open_local(self, locator: str, manifest: ArtifactManifest,
                   *, cache_key: str) -> Path:
        path = Path(locator)
        mpath = Path(locator + _MANIFEST_SUFFIX)
        if not mpath.exists():
            raise ArtifactIntegrityError(
                f"artifact manifest missing (unpublished/torn): {mpath}")
        if not path.exists():
            raise ArtifactIntegrityError(f"artifact data missing: {path}")
        actual = path.stat().st_size
        if int(actual) != int(manifest.data_bytes):
            raise ArtifactIntegrityError(
                f"artifact length mismatch for {path}: "
                f"expected {manifest.data_bytes}, found {actual}")
        # M2: sha256 verified on first open (cached per process) — a
        # same-length corruption must never serve wrong bytes.
        verify_artifact_checksum(path, manifest, cache_key=cache_key)
        return path

    def delete(self, locator: str) -> None:
        # Manifest first (unpublish), then data.  Idempotent.
        for target in (Path(locator + _MANIFEST_SUFFIX), Path(locator)):
            try:
                target.unlink()
            except FileNotFoundError:
                pass
        # Best-effort prune of now-empty address directories.
        try:
            d = Path(locator).parent
            for _ in range(3):
                if d == self._root or any(d.iterdir()):
                    break
                d.rmdir()
                d = d.parent
        except Exception:
            pass

    def sweep_temp(self, older_than_seconds: float) -> int:
        removed = 0
        try:
            cutoff = time.time() - max(0.0, older_than_seconds)
            if not self._root.exists():
                return 0
            for p in self._root.rglob(f"{_TEMP_PREFIX}*"):
                try:
                    if p.is_file() and p.stat().st_mtime < cutoff:
                        p.unlink()
                        removed += 1
                except OSError:
                    continue
        except Exception as exc:
            logger.debug("[artifacts] local temp sweep failed: %s", exc)
        return removed


# ── S3 backend (QS-owned prefix) ────────────────────────────────────────

class S3ArtifactStore(ArtifactStore):
    """Results under a QS-owned ``s3://bucket/prefix``.

    ``client``/``bucket`` are injectable (tests use a fake client);
    production resolves them lazily from the app-wide S3 config exactly
    like the existing Phase-19F ``s3_results`` helpers — same credential
    chain, optional ``s3_bucket_override``.

    Reads spool the object ONCE to a local cache file (single-flight per
    artifact) and serve every page from the spooled copy — pod RAM never
    holds more than one transfer chunk."""

    name = "s3"

    def __init__(self, client=None, bucket: Optional[str] = None,
                 prefix: Optional[str] = None,
                 spool_dir: Optional[Path] = None):
        self._client = client
        self._bucket = bucket
        self._prefix = (prefix if prefix is not None
                        else str(_cfg("s3_prefix", "querystudio/artifacts/")))
        if spool_dir is None:
            configured = str(_cfg("spool_dir", "") or "").strip()
            if configured:
                spool_dir = Path(configured)
            else:
                from core.config import paths as _paths
                spool_dir = _paths.data_dir / "artifact_spool"
        self._spool = Path(spool_dir)
        self._spool_locks: Dict[str, threading.Lock] = {}
        self._spool_locks_guard = threading.Lock()

    # -- client resolution (lazy; injectable) ---------------------------

    def _resolve(self):
        if self._client is not None and self._bucket:
            return self._client, self._bucket
        from core.s3_storage import S3Config, S3StorageHandler
        import main as _main
        base = getattr(_main, "s3_config", None)
        if base is None:
            raise ArtifactStoreError(
                "S3 artifact backend configured but no app-wide s3_config "
                "is available")
        bucket = (str(_cfg("s3_bucket_override", "")).strip()
                  or base.bucket_name)
        handler = S3StorageHandler(S3Config(
            bucket_name=bucket,
            region_name=base.region_name,
            auth_mode=base.auth_mode,
            aws_access_key_id=base.aws_access_key_id,
            aws_secret_access_key=base.aws_secret_access_key,
            aws_session_token=base.aws_session_token,
            aws_profile=base.aws_profile,
            role_arn=base.role_arn,
            role_session_name=base.role_session_name,
            external_id=base.external_id,
            endpoint_url=base.endpoint_url,
            ssl_verify=base.ssl_verify,
            path_style=base.path_style,
        ))
        self._client, self._bucket = handler.s3_client, bucket
        return self._client, self._bucket

    def _key(self, address: ArtifactAddress, salt: str) -> str:
        return f"{self._prefix.rstrip('/')}/{address.key_path(salt)}"

    @staticmethod
    def _parse_locator(locator: str) -> Tuple[str, str]:
        if not locator.startswith("s3://"):
            raise ArtifactStoreError(f"not an s3 locator: {locator!r}")
        rest = locator[len("s3://"):]
        bucket, _, key = rest.partition("/")
        if not bucket or not key:
            raise ArtifactStoreError(f"malformed s3 locator: {locator!r}")
        return bucket, key

    # -- interface -------------------------------------------------------

    def publish(self, *, address: ArtifactAddress, salt: str,
                data_path: Path, manifest: ArtifactManifest) -> PublishedArtifact:
        client, bucket = self._resolve()
        key = self._key(address, salt)
        # Data first (multipart under the hood for big files; an
        # incomplete multipart never becomes a visible object)…
        with open(str(data_path), "rb") as f:
            client.upload_fileobj(f, bucket, key)
        # …manifest LAST (the visibility gate).
        client.put_object(Bucket=bucket, Key=key + _MANIFEST_SUFFIX,
                          Body=manifest.to_json().encode("utf-8"))
        try:
            os.unlink(str(data_path))
        except OSError:
            pass
        return PublishedArtifact(backend=self.name,
                                 locator=f"s3://{bucket}/{key}",
                                 manifest=manifest)

    def _verified_spool_or_none(self, cached: Path,
                                manifest: ArtifactManifest,
                                cache_key: str) -> Optional[Path]:
        """Serve the spool copy only if length AND sha256 (cached verify)
        agree; a corrupt spool file is dropped so the next attempt
        re-downloads (M2)."""
        if not (cached.exists()
                and cached.stat().st_size == int(manifest.data_bytes)):
            return None
        try:
            verify_artifact_checksum(cached, manifest, cache_key=cache_key)
        except ArtifactIntegrityError as exc:
            _drop_verified(cache_key)
            logger.warning("[artifacts] corrupt spool copy dropped "
                           "(re-download next read): %s", exc)
            try:
                cached.unlink()
            except OSError as unlink_exc:
                logger.debug("[artifacts] corrupt spool unlink failed: %s",
                             unlink_exc)
            return None
        return cached

    def open_local(self, locator: str, manifest: ArtifactManifest,
                   *, cache_key: str) -> Path:
        cached = self._spool / f"{_safe_segment(cache_key, 'artifact')}.arrow"
        got = self._verified_spool_or_none(cached, manifest, cache_key)
        if got is not None:
            return got
        with self._spool_locks_guard:
            lock = self._spool_locks.setdefault(cache_key, threading.Lock())
            # L2-C6 (2026-07-25): bound the per-key dict (passport_registry
            # FIFO idiom).  Held locks are skipped; an evicted key mints a
            # fresh lock next time (worst case: one redundant download,
            # never corruption — the spool publish is atomic-replace).
            while len(self._spool_locks) > 4096:
                evicted = False
                for k in list(self._spool_locks):
                    lk = self._spool_locks[k]
                    if lk is lock or lk.locked():
                        continue
                    self._spool_locks.pop(k, None)
                    evicted = True
                    break
                if not evicted:
                    break
        with lock:
            got = self._verified_spool_or_none(cached, manifest, cache_key)
            if got is not None:
                return got
            client, _default_bucket = None, None
            bucket, key = self._parse_locator(locator)
            client, _default_bucket = self._resolve()
            # Manifest-presence check IS the read barrier (eventual-
            # consistency edge case): a data object without its manifest
            # does not exist to the serving path.
            try:
                client.head_object(Bucket=bucket, Key=key + _MANIFEST_SUFFIX)
            except Exception as exc:
                raise ArtifactIntegrityError(
                    f"artifact manifest missing on s3 (unpublished/torn): "
                    f"{locator}: {exc}")
            self._spool.mkdir(parents=True, exist_ok=True)
            tmp = self._spool / f"{_TEMP_PREFIX}{uuid.uuid4().hex}.arrow"
            try:
                resp = client.get_object(Bucket=bucket, Key=key)
                body = resp["Body"]
                try:
                    with open(str(tmp), "wb") as f:
                        for chunk in iter(lambda: body.read(1024 * 1024), b""):
                            f.write(chunk)
                finally:
                    try:
                        body.close()
                    except Exception:
                        pass
                actual = tmp.stat().st_size
                if int(actual) != int(manifest.data_bytes):
                    raise ArtifactIntegrityError(
                        f"artifact length mismatch for {locator}: "
                        f"expected {manifest.data_bytes}, found {actual}")
                os.replace(str(tmp), str(cached))
                # M2: verify the sha256 ONCE at spool time (cached per
                # process) — the spooled copy then serves every later
                # read pre-verified; a bad download is dropped + raised.
                try:
                    verify_artifact_checksum(cached, manifest,
                                             cache_key=cache_key)
                except ArtifactIntegrityError:
                    _drop_verified(cache_key)
                    try:
                        cached.unlink()
                    except OSError as unlink_exc:
                        logger.debug("[artifacts] bad-download unlink "
                                     "failed: %s", unlink_exc)
                    raise
            finally:
                try:
                    if tmp.exists():
                        tmp.unlink()
                except OSError:
                    pass
            return cached

    def drop_spool(self, cache_key: str) -> None:
        """Best-effort removal of the local spool copy (called by GC)."""
        _drop_verified(cache_key)
        try:
            (self._spool / f"{_safe_segment(cache_key, 'artifact')}.arrow").unlink()
        except OSError:
            pass

    def delete(self, locator: str) -> None:
        client, _b = self._resolve()
        bucket, key = self._parse_locator(locator)
        # Manifest first (unpublish), then data.  Idempotent (S3 delete of
        # a missing key succeeds).
        client.delete_object(Bucket=bucket, Key=key + _MANIFEST_SUFFIX)
        client.delete_object(Bucket=bucket, Key=key)

    def sweep_temp(self, older_than_seconds: float) -> int:
        removed = 0
        try:
            cutoff = time.time() - max(0.0, older_than_seconds)
            if self._spool.exists():
                for p in self._spool.glob(f"{_TEMP_PREFIX}*"):
                    try:
                        if p.is_file() and p.stat().st_mtime < cutoff:
                            p.unlink()
                            removed += 1
                    except OSError:
                        continue
        except Exception as exc:
            logger.debug("[artifacts] spool temp sweep failed: %s", exc)
        return removed


# ── Backend registry (plugin pattern) ───────────────────────────────────

_BACKENDS: Dict[str, Callable[[], ArtifactStore]] = {}
_backends_lock = threading.Lock()


def register_backend(name: str, factory: Callable[[], ArtifactStore],
                     *, replace: bool = False) -> None:
    with _backends_lock:
        if name in _BACKENDS and not replace:
            raise ValueError(f"artifact backend {name!r} already registered")
        _BACKENDS[name] = factory


register_backend("local", LocalArtifactStore)
register_backend("s3", S3ArtifactStore)


def build_store(backend: Optional[str] = None) -> ArtifactStore:
    """Construct the configured byte store.  Unknown backend name → falls
    back to local WITH a loud log (never crashes the executor over a
    config typo; local is always safe)."""
    name = (backend or str(_cfg("backend", "local"))).strip().lower() or "local"
    with _backends_lock:
        factory = _BACKENDS.get(name)
    if factory is None:
        logger.error("[artifacts] unknown backend %r — falling back to "
                     "'local' (check industrialization_artifacts.backend)",
                     name)
        with _backends_lock:
            factory = _BACKENDS["local"]
    return factory()
