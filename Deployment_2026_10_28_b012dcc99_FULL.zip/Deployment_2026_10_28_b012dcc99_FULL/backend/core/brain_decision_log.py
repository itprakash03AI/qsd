"""Brain decision log -- circular buffer of recent brain decisions for ops.

Strategic context (2026-06-30 deep-dive #2):
  The brain records per-layer pruning counts (manifest_pruned,
  supplement_pruned, bloom_pruned) inside its private SensorOutputs
  but nothing surfaces them.  Operators can't tell whether the bloom
  filter is actually pruning OR whether their queries are silently
  scan-all because predicates aren't reaching the brain.

This module is the single chokepoint for brain decision telemetry:
  * BrainRouter calls ``record(sql_hash, decision, sensor_outputs)``
    on every dispatch
  * Last N decisions held in-memory (bounded; default 200)
  * Cumulative Prometheus counters per pruning layer
  * /api/admin/brain/last-decisions endpoint returns the buffer

Per memory feedback_single_chokepoint_pattern + feedback_strategic_not_patch.
"""
from __future__ import annotations

import collections
import logging
import threading
from datetime import datetime, timezone
from typing import Any, Deque, Dict, List, Optional


_LOG = logging.getLogger(__name__)


# Cumulative counters (process-lifetime).  Surfaced via /metrics.
_PRUNE_COUNTERS_LOCK = threading.Lock()
_prune_counters: Dict[str, int] = {
    "manifest_pruned":   0,    # files dropped by manifest min/max bounds
    "supplement_pruned": 0,    # files dropped by supplement bounds DB
    "bloom_pruned":      0,    # files dropped by bloom sidecar
    "files_scanned":     0,    # total files brain looked at
    "decisions_total":   0,    # total brain decisions recorded
}


class BrainDecisionLog:
    """Circular buffer of recent brain decisions.

    Each entry captures everything ops need to debug a specific query
    without touching the DB.  Strictly read-mostly: writes happen on
    every dispatch (lockless via deque + replace), reads happen rarely
    from the admin endpoint (lock-acquired snapshot).
    """

    DEFAULT_CAPACITY = 200

    def __init__(self, capacity: int = DEFAULT_CAPACITY) -> None:
        self.capacity = max(10, int(capacity))
        self._buffer: Deque[Dict[str, Any]] = collections.deque(maxlen=self.capacity)
        self._lock = threading.Lock()

    def record(
        self,
        *,
        sql_hash:           str = "",
        bucket:             str = "",
        table_prefix:       str = "",
        snapshot_id:        str = "",
        file_count:         int = 0,
        decision_engine:    str = "",
        decision_reason:    str = "",
        manifest_surviving: int = -1,
        prune_breakdown:    Optional[Dict[str, int]] = None,
        sensors_consulted:  Optional[List[str]] = None,
        cost_local_s:       float = -1.0,
        cost_spark_s:       float = -1.0,
        has_prunable_preds: bool = False,
        latency_breakdown:  Optional[Dict[str, Any]] = None,
    ) -> None:
        """Append one decision to the buffer.  Also bumps the
        cumulative Prometheus counters.

        Phase 160 (2026-07-01): if ``latency_breakdown`` is None the
        recorder auto-samples the ContextVar-scoped active breakdown
        via ``brain_latency_breakdown.current_breakdown``.  That way
        existing callers (brain_router) don't have to plumb the
        breakdown through — they get free instrumentation.
        """
        # Auto-sample the active per-query breakdown if the caller
        # didn't supply one.  Safe in test / background contexts —
        # returns None when no breakdown active.
        if latency_breakdown is None:
            try:
                from core.brain_latency_breakdown import current_breakdown
                _cb = current_breakdown()
                if _cb is not None:
                    latency_breakdown = _cb.as_dict()
            except Exception as _cb_exc:                              # pragma: no cover
                # 2026-07-02 -- best-effort attach.  Missing breakdown
                # (test context, background job) is expected; debug-
                # log so a systemic breakdown-import failure is
                # greppable.
                _LOG.debug(
                    "brain_decision_log: latency_breakdown attach "
                    "suppressed %s: %s",
                    type(_cb_exc).__name__, _cb_exc,
                )
        entry = {
            "ts":                 datetime.now(timezone.utc).isoformat(timespec="seconds"),
            "sql_hash":           sql_hash,
            "bucket":             bucket,
            "table_prefix":       table_prefix,
            "snapshot_id":        snapshot_id,
            "file_count":         file_count,
            "manifest_surviving": manifest_surviving,
            "prune_breakdown":    dict(prune_breakdown or {}),
            "sensors_consulted":  list(sensors_consulted or []),
            "decision_engine":    decision_engine,
            # Deep-dive #5 (2026-06-30): bump from 200 -> 1000.  Earlier
            # truncation silently dropped multi-layer diagnostic detail
            # ("skipped(brain_disabled, db_degraded, p95=2500ms,
            # no_partition_col_in_where...)") past character 200.  1000
            # holds the longest legitimate reason while still bounding
            # per-entry memory.  Admin endpoint may further cap render
            # length if needed.
            # Deep-dive #9 (2026-06-30): defensive str() coercion.
            # A caller that mistakenly passes bytes (e.g. from an
            # exception whose args contain bytes) would otherwise
            # store bytes in the buffer + crash the FastAPI JSON
            # response at /admin/brain/last-decisions with
            # TypeError("Object of type bytes is not JSON serializable").
            "decision_reason":    str(decision_reason or "")[:1000],
            "cost_local_s":       round(cost_local_s, 2) if cost_local_s >= 0 else None,
            "cost_spark_s":       round(cost_spark_s, 2) if cost_spark_s >= 0 else None,
            "has_prunable_preds": has_prunable_preds,
            # Phase 160 (2026-07-01) — per-query s3 / metadata /
            # pruning / compute / other breakdown from
            # brain_latency_breakdown.  None when the caller ran
            # outside a query context (background prune, admin
            # sync).  Surfaces in /api/admin/brain/last-decisions
            # for the "why was this slow" view.
            "latency_breakdown":  dict(latency_breakdown or {}),
        }
        with self._lock:
            self._buffer.append(entry)
        # Counters: deep-dive #4 (2026-06-30) -- fold into ONE critical
        # section so Prometheus scrapes never observe a half-updated
        # state (manifest_pruned bumped but decisions_total not yet).
        with _PRUNE_COUNTERS_LOCK:
            if prune_breakdown:
                for k in ("manifest_pruned", "supplement_pruned", "bloom_pruned"):
                    _prune_counters[k] += int(prune_breakdown.get(k, 0) or 0)
            _prune_counters["files_scanned"] += int(file_count or 0)
            _prune_counters["decisions_total"] += 1

    def snapshot(self, limit: int = 50) -> Dict[str, Any]:
        """Return the last N entries + cumulative counters."""
        with self._lock:
            recent = list(self._buffer)[-max(1, int(limit)):]
        with _PRUNE_COUNTERS_LOCK:
            counters = dict(_prune_counters)
        return {
            "recent":   recent,
            "counters": counters,
            "capacity": self.capacity,
        }


# ── module-level singleton ──────────────────────────────────────────────


_singleton: Optional[BrainDecisionLog] = None
_singleton_lock = threading.Lock()


def get_log() -> BrainDecisionLog:
    global _singleton
    if _singleton is None:
        with _singleton_lock:
            if _singleton is None:
                import os
                cap = int(os.environ.get("QS_BRAIN_LOG_CAPACITY", "200") or 200)
                _singleton = BrainDecisionLog(capacity=cap)
    return _singleton


def reset_log() -> None:
    """Test hook."""
    global _singleton
    with _singleton_lock:
        _singleton = None
        with _PRUNE_COUNTERS_LOCK:
            for k in _prune_counters:
                _prune_counters[k] = 0


def get_prune_counters() -> Dict[str, int]:
    """Read-only snapshot of cumulative counters for Prometheus."""
    with _PRUNE_COUNTERS_LOCK:
        return dict(_prune_counters)


__all__ = [
    "BrainDecisionLog", "get_log", "reset_log", "get_prune_counters",
]
