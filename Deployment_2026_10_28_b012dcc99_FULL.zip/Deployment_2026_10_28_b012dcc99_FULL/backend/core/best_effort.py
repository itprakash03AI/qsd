"""The declared idiom for best-effort cleanup.

Closing a cursor, cancelling a statement, releasing a handle, nudging a
progress row: these must not raise, because raising during cleanup replaces
the real error with the cleanup's error and the operator loses the cause.
Swallowing is correct here.

Being SILENT is not. ``except Exception: pass`` leaves no trace at all, so a
cursor that never closes, a cancel the engine refused, or a handle that leaks
is invisible until it becomes a resource exhaustion nobody can explain. This
codebase caps bare silent handlers for exactly that reason
(``tests/test_silent_exceptions.py``), and that cap has been ratcheted
400 → 760 by the reflex of raising it whenever it is hit.

So the swallow is kept and the silence is removed::

    with best_effort("close trino cursor"):
        cur.close()

One chokepoint, one spelling, one place to change the level or add metrics —
instead of N copies of an anonymous ``pass``. The message names the ACTION,
so a log line says what was attempted rather than only where it failed.

Deliberately NOT ``contextlib.suppress``: that is silent too, merely spelled
differently, and using it here would satisfy the guard while defeating its
purpose. A guard you route around is worse than one you fail.

WHAT THIS IS NOT FOR
--------------------
Never wrap work whose failure changes the ANSWER. A swallowed exception on a
read path is how a `TypeError` in our own call once got reported as an "S3
read failure" and returned 0 of 3 files with a SUCCESS status. If the caller's
result depends on the block succeeding, it must raise.
"""
from __future__ import annotations

import logging
from contextlib import contextmanager
from typing import Iterator, Optional

_log = logging.getLogger(__name__)


@contextmanager
def best_effort(action: str,
                *,
                logger: Optional[logging.Logger] = None,
                level: int = logging.DEBUG) -> Iterator[None]:
    """Run a cleanup step that must never raise, and say so when it fails.

    ``action`` is a short human phrase naming what was attempted — "close
    duckdb cursor", "drop unload scratch table". It lands in the log line, so
    prefer the verb over the variable name.

    ``level`` defaults to DEBUG because cleanup failures are usually noise;
    pass ``logging.WARNING`` where a failure has an operator consequence (a
    leaked scratch table costs money; a leaked cursor costs a connection).
    """
    try:
        yield
    except Exception as exc:                       # noqa: BLE001 — the point
        (logger or _log).log(
            level, "best-effort step failed (continuing): %s — %s: %s",
            action, type(exc).__name__, exc)


def note_best_effort(action: str,
                     exc: BaseException,
                     *,
                     logger: Optional[logging.Logger] = None,
                     level: int = logging.DEBUG) -> None:
    """The same contract for an existing ``except`` body.

    ``best_effort`` is the shape for new code. This is the one-line conversion
    for the many existing handlers whose body is a bare ``pass``::

        try:
            cur.close()
        except Exception as exc:
            note_best_effort("close duckdb cursor", exc)

    Same swallow, same log line, no restructuring of code that already works —
    which matters when converting handlers in files that are load-bearing.
    """
    (logger or _log).log(
        level, "best-effort step failed (continuing): %s — %s: %s",
        action, type(exc).__name__, exc)
