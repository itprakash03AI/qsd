"""
AWS Athena connector — serverless SQL on data in S3 / Glue Catalog.

Why this exists: lets users point QueryStudio at an Athena Workgroup
and run heavy SQL without operating a query engine.  Cost model is
pay-per-TB-scanned (~$5/TB by default), so the connector encourages
two guardrails:

  1. **Workgroup**: Athena enforces ``BytesScannedCutoffPerQuery``
     and per-query / per-workgroup cost limits.  Set those via the
     AWS console; this connector REQUIRES a workgroup name and warns
     if "primary" (the unbounded default) is used in production.
  2. **bytes_scanned_cutoff_mb** (optional): a per-connection
     belt-and-suspenders.  When set, every query is preceded by an
     EXPLAIN that sets ``bytes_scanned_cutoff_per_query`` for the
     session — Athena rejects with a clear error before scanning.

Required config keys:
  region            – AWS region (e.g. "us-east-1")
  s3_staging_dir    – s3://bucket/prefix where Athena writes results
  workgroup         – Athena workgroup name (REQUIRED for cost guard)
  catalog           – AwsDataCatalog (default) or Lake Formation catalog name
  schema            – default Glue database (optional)
  auth_type         – "iam_role" | "access_key" | "profile" | "instance"
  aws_access_key_id – when auth_type=access_key
  aws_secret_access_key – when auth_type=access_key
  aws_session_token – when auth_type=access_key (optional, for STS creds)
  aws_profile       – when auth_type=profile
  bytes_scanned_cutoff_mb – optional per-query cutoff in MB (cost guard)
"""

import logging
import re
from typing import Any, Dict, List, Optional

from .base import SqlConnector, unique_column_names, DriverNotInstalled

logger = logging.getLogger(__name__)


_QUOTE = '"'    # Athena/Trino DML identifier quote (backticks are DDL-only)
_LITQ = "'"


def _qi(name):
    """Quote ONE identifier -- but only when it actually needs quoting.

    2026-08-20 -- ATHENA WAS THE LAST SQL CONNECTOR WITH NO QUOTER.

    Trino got one on 2026-08-19 and Snowflake/Databricks on 2026-08-20, each
    time because catalog/schema/table were interpolated BARE into SHOW and
    DESCRIBE.  Athena had neither ``_qi`` nor ``_ql``, and its values arrive
    from an authenticated user's connection config and browse requests, so
    the bare f-strings were both a browse failure for any name needing
    quoting and an injection surface running under that connection's own
    credentials.  Every branch sits inside a bare ``except Exception:`` that
    falls through to another interpolated statement, so a break-out failed
    SILENTLY to the caller while still executing.

    CONDITIONAL, for the same reason as the siblings: quoting everything
    would change case-folding semantics and break browses that work today.
    A bare-safe name passes through byte-identical.

    Note this emits DOUBLE QUOTES, not backticks: this connector's own
    comment records that Athena DML takes double quotes and backticks are
    DDL-only -- yet the SHOW/DESCRIBE statements used backticks anyway.

    2026-08-20 (third pass) -- delegates to the ONE shared implementation in
    base.py.  The local copy passed reserved words bare (Trino grammar
    reserves ORDER/TABLE, so ``SHOW TABLES IN "cat".order`` failed) and
    treated ``$`` as bare-safe when Trino grammar does not.  Reserved words
    lower-fold before quoting, matching Trino's bare-identifier fold.
    """
    from .base import quote_identifier
    return quote_identifier(name, quote=_QUOTE, fold=str.lower,
                            allow_dollar=False)


def _ql(value):
    """Quote a string LITERAL.

    information_schema lookups compare table_schema / table_name against
    STRING LITERALS, so those need literal escaping rather than identifier
    quoting -- an unescaped single quote in a schema name closed the literal
    and appended attacker-controlled SQL.
    """
    s = str(value)
    return _LITQ + s.replace(_LITQ, _LITQ + _LITQ) + _LITQ


def _parse_athena_partitions(ddl: str) -> List[Dict[str, str]]:
    """Extract partition column names + types from Athena CREATE TABLE DDL.

    Athena DDL for a partitioned table looks like:
        CREATE EXTERNAL TABLE foo (
            col1 string,
            col2 int
        )
        PARTITIONED BY (
            year int,
            month int,
            dt date
        )
        ...
    """
    m = re.search(
        r"PARTITIONED\s+BY\s*\(\s*(.+?)\s*\)\s*(?:STORED|LOCATION|TBLPROPERTIES|ROW\s+FORMAT|WITH|;|$)",
        ddl, re.IGNORECASE | re.DOTALL,
    )
    if not m:
        return []
    body = m.group(1)
    cols: List[Dict[str, str]] = []
    for raw_line in body.split(","):
        line = raw_line.strip().rstrip(",")
        if not line or line.startswith("--"):
            continue
        parts = line.split(None, 1)
        if len(parts) >= 2:
            name = parts[0].strip("`\"' ")
            typ = parts[1].strip()
            # Drop any trailing COMMENT '...'
            typ = re.sub(r"\s+COMMENT\s+'.+?'$", "", typ, flags=re.IGNORECASE).strip()
            cols.append({"name": name, "type": typ, "transform": "identity"})
        elif parts:
            cols.append({"name": parts[0].strip("`\"' "),
                         "type": "string", "transform": "identity"})
    return cols


# ── Shared pyathena connection helper ───────────────────────────────────────
# BF-428H — Single pyathena-cursor factory used by BOTH the connection-type
# (AthenaConnector below) AND the s3_readers strategy (AthenaReader in
# core/s3_readers/athena.py).  Without this, both paths reimplement the
# same wiring (proxy, BotoCfg, AWS auth modes, region/staging defaults)
# and any future fix has to land in two places.

def _close_quietly(cur) -> None:
    """Close a cursor, swallowing the close failure.

    The query has already run (or already failed); a cursor that will not
    close must not mask that outcome with a second exception.
    """
    try:
        cur.close()
    except Exception:
        pass


def build_pyathena_connection(
    *,
    region: str,
    s3_staging_dir: str,
    workgroup: str,
    schema: Optional[str] = None,
    catalog: Optional[str] = None,
    aws_kwargs: Optional[Dict[str, Any]] = None,
    proxies: Optional[Dict[str, str]] = None,
    connect_timeout: int = 10,
    read_timeout: int = 60,
    retries: Optional[Dict[str, Any]] = None,
):
    """Build a pyathena DBAPI connection.  Single source of truth for
    Athena wiring (BF-428H dedup).

    Required:
      region            : AWS region (e.g. ``us-east-1``)
      s3_staging_dir    : where Athena writes results (``s3://...``)
      workgroup         : Athena workgroup; falls back to ``primary``
                          with a WARN log (unbounded cost)

    Optional:
      schema            : default database; falls back to ``default``
      catalog           : Glue catalog name; falls back to ``AwsDataCatalog``
      aws_kwargs        : credential dict (access_key / secret /
                          session_token OR profile_name).  Empty dict
                          means rely on the IAM role attached to the
                          pod / instance profile.
      proxies           : ``{"http": "...", "https": "..."}`` for corporate
                          proxy; None = no proxy
      connect_timeout / read_timeout / retries : botocore Config tuning

    Raises RuntimeError if pyathena is not installed or if s3_staging_dir
    is missing.
    """
    try:
        from pyathena import connect as _ath_connect
        from botocore.config import Config as _BotoCfg
    except ImportError as exc:
        raise DriverNotInstalled(
            "pyathena",
            "pyathena package is not installed.  Add 'pyathena>=3.0' "
            "to requirements.txt and restart the backend."
        ) from exc

    if not s3_staging_dir:
        raise RuntimeError(
            "Athena requires 's3_staging_dir' (s3://bucket/prefix where "
            "Athena writes results)."
        )
    if not workgroup:
        logger.warning(
            "Athena connection has no workgroup configured — using "
            "'primary' (no per-query bytes-scanned cap).  Set a "
            "workgroup with cost limits for production."
        )
        workgroup = "primary"

    if retries is None:
        retries = {"max_attempts": 3, "mode": "adaptive"}

    boto_cfg = _BotoCfg(
        connect_timeout=connect_timeout,
        read_timeout=read_timeout,
        retries=retries,
        proxies=proxies,
    )

    kwargs: Dict[str, Any] = dict(
        region_name=region,
        s3_staging_dir=s3_staging_dir,
        work_group=workgroup,
        schema_name=schema or "default",
        catalog_name=catalog or "AwsDataCatalog",
        config=boto_cfg,
    )
    if aws_kwargs:
        kwargs.update(aws_kwargs)

    return _ath_connect(**kwargs)


class AthenaConnector(SqlConnector):
    """Connector for Amazon Athena (serverless SQL over S3 + Glue catalog)."""

    #: 2026-09-16 — audited and DELIBERATELY NOT reusable, which is the
    #: finding rather than an omission.  ``_execute`` issues
    #: ``SET SESSION bytes_scanned_cutoff_per_query = {cap}`` — a
    #: SESSION-LEVEL COST CAP derived from the CALLER.  Hand that session to
    #: the next caller and they inherit the previous caller's scan cutoff:
    #: too high and a cost guard silently does not apply, too low and their
    #: query is refused for a limit that was never theirs.  Either way it is
    #: money or a wrong answer, decided by whoever happened to run first.
    #:
    #: Resetting it would mean restoring "no cutoff", and Athena has no
    #: statement that reliably means that — ``SET SESSION`` to a sentinel is
    #: guessing.  ``_cost_cap_warned`` and ``_last_query_execution_id`` are
    #: per-caller too (a reused instance would suppress the cost warning the
    #: second caller should see, and expose the first caller's query id to
    #: cancel).  So this stays at the inherited POOL_SAFE = False until
    #: someone can state what a correct reset is.
    POOL_SAFE = False

    DEFAULT_CATALOG = "AwsDataCatalog"

    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self._conn = None
        # Track query execution IDs so cancel can call athena.stop_query_execution.
        self._last_query_execution_id: Optional[str] = None

    # ── Internal helpers ─────────────────────────────────────────────────────

    def _resolved_region(self) -> str:
        """The AWS region this connection declares -- REFUSING rather than
        guessing when it declares none.

        2026-09-20.  This read was ``config.get("region", "us-east-1")``, so
        a connection created through the API without a ``region`` ran in
        us-east-1 silently.  The trap is specific and it is easy to fall
        into: an S3 connection in this product spells the same idea
        ``region_name``, so a caller who copies an S3 config gets a
        connection that looks configured, reports a plausible AWS error
        from the WRONG region, and names nothing useful.  (The Athena form
        in the UI writes ``region`` and requires it -- this is the
        API-created path.)

        A default region is not a cap that can be throttled; it decides
        which account's data is read.  So it refuses.
        """
        region = str(self.config.get("region") or "").strip()
        if region:
            return region
        if str(self.config.get("region_name") or "").strip():
            raise ValueError(
                "Athena connection has no 'region'. It has 'region_name', "
                "which is the S3 connection's spelling and is NOT read here "
                "-- rename it to 'region'. Refusing to default to us-east-1: "
                "the region decides which account's data is queried.")
        raise ValueError(
            "Athena connection has no 'region'. Refusing to default to "
            "us-east-1: the region decides which account's data is queried, "
            "so a guess would return the wrong answer rather than an error.")

    def _get_aws_kwargs(self) -> Dict[str, Any]:
        """Resolve AWS credential kwargs based on auth_type."""
        auth_type = (self.config.get("auth_type") or "iam_role").lower()
        kwargs: Dict[str, Any] = {}
        if auth_type != "access_key" and (
                str(self.config.get("aws_access_key_id") or "").strip()
                or str(self.config.get("aws_secret_access_key") or "").strip()):
            # 2026-09-20 -- the same shape as the 'profile' refusal below.
            # Access keys with auth_type 'iam_role' (the DEFAULT, so this is
            # what an API caller who supplies keys and nothing else gets)
            # meant the keys were never passed to pyathena and botocore fell
            # through to the pod's ambient chain: the query ran as a
            # DIFFERENT principal, or died with "Unable to locate
            # credentials" naming nothing about the keys sitting in the
            # config. A declaration that contradicts itself is refused.
            raise ValueError(
                f"Athena connection supplies aws_access_key_id/"
                f"aws_secret_access_key but auth_type is '{auth_type}', so "
                f"they would be IGNORED and the ambient credential chain "
                f"used instead. Set auth_type='access_key' to use them, or "
                f"remove them to use the role.")
        if auth_type == "access_key":
            kwargs["aws_access_key_id"] = self.config.get("aws_access_key_id", "")
            kwargs["aws_secret_access_key"] = self.config.get("aws_secret_access_key", "")
            tok = self.config.get("aws_session_token")
            if tok:
                kwargs["aws_session_token"] = tok
        elif auth_type == "profile":
            prof = self.config.get("aws_profile")
            if not prof:
                # 2026-08-19 -- there was no else here, so a connection
                # DECLARING profile auth with no profile name fell through to
                # the pod/instance default credential chain and executed as a
                # DIFFERENT principal, with no error and no log.  Every other
                # auth mode fails loudly on bad input; only this one degraded
                # silently into someone else's identity.
                raise ValueError(
                    "Athena auth_type is 'profile' but no aws_profile was "
                    "given. Refusing to fall back to the ambient credential "
                    "chain, which would run this query as a different "
                    "principal than the connection declares."
                )
            kwargs["profile_name"] = prof
        # iam_role / instance: rely on the IAM role attached to the pod / EC2
        # instance profile — boto3 picks it up automatically; no kwargs.
        return kwargs

    def _get_proxies(self) -> Optional[Dict[str, str]]:
        """If proxy is configured for AWS endpoints, build the proxies dict.

        BF-NONBLOCK-AUDIT-3 / Phase 119: corporate proxies that intercept
        AWS calls — share the same logic the rest of the codebase uses.
        """
        try:
            from core.proxy_utils import get_boto_proxies
            return get_boto_proxies(endpoint_url=f"athena.{self.config.get('region', 'us-east-1')}.amazonaws.com") or None
        except Exception:
            return None

    def _get_connection(self):
        """Lazy-build pyathena DBAPI connection.

        IMPORTANT: pyathena is a stateless wrapper around boto3 — there's
        no persistent TCP connection to keep alive.  We deliberately
        SKIP the SELECT-1 liveness ping that other connectors use because:
          1. Every Athena query is billed per byte scanned (SELECT 1 ≈
             10 MB scanned minimum = $0.00005 — small but multiplied
             across page-loads / CRUD operations).
          2. SELECT 1 takes 1-5 s on Athena (cold-start latency) — the
             ping itself would slow every operation.
        Caching by re-using the boto3 client + region is enough; if AWS
        credentials expire we'll get an ExpiredToken error on the real
        query and reconnect via the same code path other connectors use.
        """
        if self._conn is not None:
            return self._conn

        # BF-428H — delegate to the shared module-level factory so this
        # connection-type and the s3_readers AthenaReader strategy share
        # ONE pyathena code path.
        self._conn = build_pyathena_connection(
            region=self._resolved_region(),
            s3_staging_dir=self.config.get("s3_staging_dir", ""),
            workgroup=self.config.get("workgroup", ""),
            schema=self.config.get("schema"),
            catalog=self.config.get("catalog", self.DEFAULT_CATALOG),
            aws_kwargs=self._get_aws_kwargs(),
            proxies=self._get_proxies(),
        )
        return self._conn

    def _cursor(self):
        return self._get_connection().cursor()

    # ── Connection lifecycle ─────────────────────────────────────────────────

    def test_connection(self) -> Dict[str, Any]:
        cur = None
        try:
            cur = self._cursor()
            cur.execute("SELECT 1 AS ok")
            cur.fetchone()
            return {
                "success": True,
                "message": (
                    f"Connected to Athena (region={self.config.get('region')}, "
                    f"workgroup={self.config.get('workgroup', 'primary')}, "
                    f"catalog={self.config.get('catalog', self.DEFAULT_CATALOG)})"
                ),
                "details": {
                    "region":    self.config.get("region"),
                    "workgroup": self.config.get("workgroup", "primary"),
                    "catalog":   self.config.get("catalog", self.DEFAULT_CATALOG),
                },
            }
        except Exception as e:
            logger.exception("Athena test_connection failed")
            return self._test_failure(e)
        finally:
            if cur:
                try:
                    cur.close()
                except Exception:
                    pass

    def close(self):
        if self._conn:
            try:
                self._conn.close()
            except Exception as exc:
                logger.warning("athena_connector close failed: %s", exc, exc_info=True)
            self._conn = None

    # ── Schema browsing ──────────────────────────────────────────────────────

    def list_catalogs(self) -> List[str]:
        """Athena: each Glue catalog (AwsDataCatalog default + Lake Formation
        federated catalogs) is exposed via SHOW DATABASES IN <catalog>.
        We list the configured catalogs by querying the data catalog itself.
        """
        cur = self._cursor()
        try:
            # SHOW CATALOGS is supported in newer Athena engine v3
            try:
                cur.execute("SHOW CATALOGS")
                rows = cur.fetchall()
                return [r[0] for r in rows]
            except Exception:
                # Fallback — return the configured single catalog
                return [self.config.get("catalog", self.DEFAULT_CATALOG)]
        finally:
            cur.close()

    def list_schemas(self, catalog: str) -> List[str]:
        cur = self._cursor()
        try:
            cur.execute(f"SHOW DATABASES IN {_qi(catalog)}")
            return [r[0] for r in cur.fetchall()]
        finally:
            cur.close()

    # 2026-08-19 -- ATHENA DML IS TRINO GRAMMAR: identifiers take DOUBLE
    # QUOTES; backticks are DDL-only (CREATE TABLE).  The information_schema
    # queries below were written with backticks, so they could never parse and
    # every call silently rode its fallback: list_tables lost the VIEW/TABLE
    # distinction, list_columns fell back to DESCRIBE, and detect_partitions
    # returned [].  That last one also disabled the typed-literal fix on
    # Athena, because column-type resolution reads list_columns.

    def list_tables(self, catalog: str, schema: str) -> List[Dict[str, Any]]:
        """Use information_schema for catalog-qualified listing — works
        across both AwsDataCatalog and Lake Formation federated catalogs.
        """
        cur = self._cursor()
        try:
            # Try information_schema first (qualified)
            try:
                cur.execute(
                    "SELECT table_name, table_type "
                    f"FROM {_qi(catalog)}.information_schema.tables "
                    f"WHERE table_schema = {_ql(schema)}"
                )
                rows = cur.fetchall()
                return [
                    {
                        "name": r[0],
                        "type": "VIEW" if (r[1] or "").upper() == "VIEW" else "TABLE",
                        "catalog": catalog,
                        "schema": schema,
                    } for r in rows
                ]
            except Exception:
                # Fall back to SHOW TABLES (no view/table distinction)
                cur.execute(f"SHOW TABLES IN {_qi(catalog)}.{_qi(schema)}")
                return [
                    {"name": r[0], "type": "TABLE", "catalog": catalog, "schema": schema}
                    for r in cur.fetchall()
                ]
        finally:
            cur.close()

    def list_columns(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        cur = self._cursor()
        try:
            try:
                cur.execute(
                    "SELECT column_name, data_type, is_nullable, ordinal_position "
                    f"FROM {_qi(catalog)}.information_schema.columns "
                    f"WHERE table_schema = {_ql(schema)} AND table_name = {_ql(table)} "
                    "ORDER BY ordinal_position"
                )
                rows = cur.fetchall()
                return [
                    {
                        "name": r[0], "type": r[1],
                        "nullable": (r[2] or "").upper() != "NO",
                        "ordinal":  int(r[3]) if r[3] is not None else i,
                    } for i, r in enumerate(rows)
                ]
            except Exception:
                # DESCRIBE fallback
                cur.execute(f"DESCRIBE {_qi(catalog)}.{_qi(schema)}.{_qi(table)}")
                rows = cur.fetchall()
                return [
                    {"name": r[0], "type": r[1], "nullable": True, "ordinal": i}
                    for i, r in enumerate(rows)
                ]
        finally:
            cur.close()

    # ── Partition detection ────────────────────────────────────────────────────

    def _partitions_from_ddl(self, cur, catalog: str, schema: str,
                             table: str) -> List[Dict[str, Any]]:
        """Partition columns from SHOW CREATE TABLE's ``PARTITIONED BY`` clause.

        Returns [] both when the DDL carries no clause (Iceberg tables on
        Athena partition via table properties, so their DDL has none) and
        when the probe itself fails -- either way the caller falls through
        to information_schema, which is what the inline code did.
        """
        try:
            cur.execute(f"SHOW CREATE TABLE {_qi(catalog)}.{_qi(schema)}.{_qi(table)}")
            ddl_row = cur.fetchone()
            ddl = ddl_row[0] if ddl_row else ""
            return _parse_athena_partitions(ddl)
        except Exception:
            return []

    def _partitions_from_information_schema(self, cur, catalog: str,
                                            schema: str,
                                            table: str) -> List[Dict[str, Any]]:
        """Partition columns from Glue's ``information_schema.columns``.

        The fallback for Iceberg-on-Athena.  Raises on failure so the
        caller can log the "could not find out" warning once.
        """
        cur.execute(
            "SELECT column_name, data_type "
            f"FROM {_qi(catalog)}.information_schema.columns "
            f"WHERE table_schema = {_ql(schema)} AND table_name = {_ql(table)} "
            "AND extra_info LIKE '%partition%'"
        )
        return [
            {"name": r[0], "type": r[1], "transform": "identity"}
            for r in cur.fetchall()
        ]

    def detect_partitions(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        """Detect partition columns via SHOW CREATE TABLE DDL parsing.

        Athena DDL exposes ``PARTITIONED BY (col type, ...)`` for partitioned
        Hive/Glue tables.  Iceberg tables on Athena use a different syntax
        (partitioned via table properties); for those, fall back to
        information_schema.partitions if available.
        """
        cur = self._cursor()
        try:
            parts = self._partitions_from_ddl(cur, catalog, schema, table)
            if parts:
                return parts
            # Fallback: check Glue catalog directly via information_schema
            return self._partitions_from_information_schema(
                cur, catalog, schema, table)
        except Exception:
            # 2026-08-20 -- WARNING, not silent (the information_schema
            # branch swallowed its failure before this log ever fired) and
            # WARNING, not DEBUG: [] means both "not partitioned" and
            # "could not find out", and the second silently disables
            # partition prompting so queries full-scan.  Trino/Snowflake
            # were raised to WARNING for exactly this reason; Athena was
            # left behind.
            logger.warning(
                "detect_partitions failed for %s.%s.%s -- treating as "
                "unpartitioned, so no partition filter will be offered",
                catalog, schema, table, exc_info=True)
            return []
        finally:
            _close_quietly(cur)

    # ── Query execution ──────────────────────────────────────────────────────

    def _maybe_set_cost_cutoff(self, cur):
        """Best-effort per-query bytes-scanned cap.

        2026-08-19 -- THIS CANNOT ENFORCE, and used to look like it did.  The
        old body ran ``SET SESSION bytes_scanned_cutoff_per_query`` inside a
        bare ``except: pass``, so all three reasons it fails were invisible:

          * Athena has no session to set it in -- every statement is a separate
            StartQueryExecution, so a SET does not carry into the next call;
          * ``BytesScannedCutoffPerQuery`` is a WORKGROUP configuration
            (UpdateWorkGroup), not a query-settable property;
          * the failure was swallowed.

        The operator therefore believed a cap existed while a 100 TB scan ran
        and billed in full.  The attempt is kept (harmless, and a future engine
        version may honour it), but a failure is now stated once per connector,
        and the post-execution check below reports an actual breach.  The UI
        helper text was corrected to say the cap requires workgroup
        configuration -- see core/connectors/__init__.py.
        """
        cap_mb = self.config.get("bytes_scanned_cutoff_mb")
        if not cap_mb:
            return
        try:
            cap_bytes = int(cap_mb) * 1024 * 1024
            cur.execute(f"SET SESSION bytes_scanned_cutoff_per_query = {cap_bytes}")
        except Exception as exc:
            if not getattr(self, "_cost_cap_warned", False):
                self._cost_cap_warned = True
                logger.warning(
                    "Athena per-query cost cap (%s MB) could NOT be applied "
                    "(%s). Athena enforces this only as a WORKGROUP setting "
                    "(BytesScannedCutoffPerQuery) -- set it on the workgroup, "
                    "or queries will scan without a cap.", cap_mb, exc)

    def _check_cost_cutoff(self, scanned_bytes: Optional[int]) -> None:
        """Report a breach of the configured cap after the fact.

        Cannot prevent the spend -- see above -- but an operator who believes
        a cap is in force must at least learn that it was exceeded.
        """
        cap_mb = self.config.get("bytes_scanned_cutoff_mb")
        if not cap_mb or not scanned_bytes:
            return
        try:
            cap_bytes = int(cap_mb) * 1024 * 1024
            if int(scanned_bytes) > cap_bytes:
                logger.warning(
                    "Athena query scanned %.2f GB, EXCEEDING the configured "
                    "%s MB cost cap (~$%.2f at $5/TB). The cap is advisory "
                    "unless set on the Athena WORKGROUP.",
                    int(scanned_bytes) / 1024 ** 3, cap_mb,
                    int(scanned_bytes) / 1024 ** 4 * 5)
        except Exception:
            pass

    def _build_query_result(self, cur) -> Dict[str, Any]:
        """Assemble the result envelope, including bytes-scanned cost telemetry.

        Cost is best-effort: a driver that does not expose
        ``data_scanned_in_bytes`` simply omits both cost keys rather than
        reporting a zero that would read as "this scan was free".
        """
        desc = cur.description or []
        col_info = [{"name": n, "type": str(d[1])} for n, d in zip(unique_column_names(d[0] for d in desc), desc)]
        rows_raw = cur.fetchall()
        col_names = unique_column_names(d[0] for d in desc)
        rows = [dict(zip(col_names, row)) for row in rows_raw]
        # Pull bytes scanned for cost telemetry (best-effort)
        bytes_scanned = None
        try:
            bytes_scanned = getattr(cur, "data_scanned_in_bytes", None)
        except Exception:
            pass
        result: Dict[str, Any] = {
            "columns": col_info,
            "rows": rows,
            "total_rows": len(rows),
        }
        if bytes_scanned is not None:
            result["bytes_scanned"] = int(bytes_scanned)
            # Cost estimate at $5/TB (default Athena pricing)
            result["estimated_cost_usd"] = round(
                (int(bytes_scanned) / (1024 ** 4)) * 5.0, 4)
        return result

    def execute_query(self, sql: str, limit: Optional[int] = None) -> Dict[str, Any]:
        sql = self._apply_limit(sql, limit)
        for attempt in range(2):
            cur = self._cursor()
            try:
                self._maybe_set_cost_cutoff(cur)
                cur.execute(sql)
                # Capture the Athena query_execution_id for cancel + cost reporting
                self._last_query_execution_id = getattr(cur, "query_id", None)
                return self._build_query_result(cur)
            except Exception as exc:
                _close_quietly(cur)
                if attempt == 0 and self._is_connection_error(exc):
                    logger.warning("Athena execute_query connection error, retrying: %s", exc)
                    self._conn = None
                    continue
                raise
            finally:
                _close_quietly(cur)
        raise RuntimeError("Athena execute_query failed after retry")

    def _stop_via_boto3(self, query_id: str) -> None:
        """Stop a running Athena query by id via ``stop_query_execution``.

        The fallback for drivers whose cursor has no ``.cancel()``.  A
        failure here is stated LOUDLY, not swallowed: the scan is still
        running and Athena is still billing for the bytes it scans.
        """
        try:
            import boto3
            from botocore.config import Config as _BotoCfg
            kwargs = self._get_aws_kwargs()
            # 2026-08-19 -- same trust store as every other boto3
            # client in this product (core.ssl_config), instead of the
            # ambient default.
            try:
                from core.ssl_config import as_boto3_verify, resolve_ssl
                _ath_verify = as_boto3_verify(resolve_ssl(
                    self.config.get("verify_ssl", True)))
            except Exception:
                _ath_verify = None
            ath = boto3.client("athena",
                                region_name=self.config.get("region"),
                                config=_BotoCfg(proxies=self._get_proxies() or None),
                                **({"verify": _ath_verify}
                                   if _ath_verify is not None else {}),
                                **kwargs)
            ath.stop_query_execution(QueryExecutionId=query_id)
        except Exception as exc:
            logger.warning(
                "Athena cancel FAILED for query %s (%s) -- the scan is "
                "still running and still being billed", query_id, exc)

    def _start_cancel_watchdog(self, cancel_event, stop_event, do_cancel) -> None:
        """Poll *cancel_event* on a timer and cancel the query when it fires.

        A daemon thread, because pyathena's ``execute()`` blocks for the
        whole billable scan -- nothing on this thread can observe the
        cancel while it matters.  *stop_event* retires the watchdog.
        """
        import threading as _th

        def _wd():
            while not stop_event.is_set():
                if cancel_event.is_set():
                    do_cancel(self._last_query_execution_id)
                    return
                stop_event.wait(0.5)

        _th.Thread(target=_wd, name="qs-athena-cancel", daemon=True).start()

    def _cancel_on_abandon(self, cur) -> None:
        """Cancel a query whose result set the consumer stopped reading.

        2026-08-21 -- close() is NOT a cancel: Athena keeps executing and
        keeps SCANNING BYTES, which is what Athena bills for.
        """
        try:
            cur.cancel()
            logger.info("Athena: result set abandoned before completion "
                        "— cancelled the query (stops further scan)")
        except Exception as _cxl:
            logger.debug("Athena cancel on abandon failed: %s", _cxl)

    def _stream_batches(self, cur, col_info, col_names, chunk_size,
                        cancel_event):
        """Yield ``(col_info, rows)`` until the cursor drains or the caller stops.

        Always yields at least once: a zero-row result must still carry the
        column shape, or the caller cannot tell "no rows" from "no answer".
        """
        yielded_any = False
        while True:
            if cancel_event is not None and cancel_event.is_set():
                break
            batch = cur.fetchmany(chunk_size)
            if not batch:
                break
            yielded_any = True
            yield col_info, [dict(zip(col_names, row)) for row in batch]
        if not yielded_any:
            yield col_info, []

    def execute_query_streaming(
        self,
        sql: str,
        chunk_size: int = 1000,
        limit: Optional[int] = None,
        cancel_event=None,
    ):
        """Cursor-based streaming via fetchmany.

        Cancel: pyathena cursor doesn't have ``.cancel()`` in older
        versions; we use ``boto3 athena.stop_query_execution`` keyed
        by the query_execution_id captured after ``cur.execute``.
        """
        import threading as _th
        sql = self._apply_limit(sql, limit)
        cur = self._cursor()
        _stop = _th.Event()

        def _do_cancel(query_id: Optional[str]):
            # 2026-08-19 -- the `if not query_id: return` guard used to sit
            # ABOVE cur.cancel(), which does not need an id.  The id it
            # guarded on (_last_query_execution_id) is assigned only AFTER
            # cur.execute() returns, and pyathena's execute() blocks for the
            # whole billable scan -- so during the only window where cancel
            # matters the id was None and this was a no-op.  On a REUSED
            # connector it was worse: the attribute still held the PREVIOUS
            # query's id, so boto3 stopped an already-finished query while
            # the live scan continued.
            #
            # cur.cancel() first, unconditionally; and prefer the cursor's
            # OWN id, which pyathena sets as soon as the query is submitted.
            try:
                cancel_fn = getattr(cur, "cancel", None)
                if callable(cancel_fn):
                    cancel_fn()
                    return
            except Exception as exc:
                logger.debug("Athena cur.cancel() failed: %s", exc)
            query_id = getattr(cur, "query_id", None) or query_id
            if not query_id:
                logger.warning(
                    "Athena cancel requested but no query id is known yet -- "
                    "the scan will run to completion and still be billed")
                return
            # Fallback: boto3 stop_query_execution
            self._stop_via_boto3(query_id)

        if cancel_event is not None:
            self._start_cancel_watchdog(cancel_event, _stop, _do_cancel)

        _drained = False
        try:
            self._maybe_set_cost_cutoff(cur)
            cur.execute(sql)
            self._last_query_execution_id = getattr(cur, "query_id", None)
            desc = cur.description or []
            col_info = [{"name": n, "type": str(d[1])} for n, d in zip(unique_column_names(d[0] for d in desc), desc)]
            col_names = unique_column_names(d[0] for d in desc)
            yield from self._stream_batches(
                cur, col_info, col_names, chunk_size, cancel_event)
            _drained = True
        finally:
            # 2026-08-21 — CANCEL AT THE SOURCE ON ANY EARLY EXIT.  _stop.set()
            # kills the cancel watchdog (the only caller of cancel, polling on a
            # timer) and close() is not a cancel — Athena keeps executing and
            # keeps SCANNING BYTES, which is what Athena bills for.  A consumer
            # that stopped reading left the query running to completion.
            if not _drained:
                self._cancel_on_abandon(cur)
            _stop.set()
            _close_quietly(cur)

    @staticmethod
    def _is_connection_error(exc: Exception) -> bool:
        # 2026-08-26 -- "expiredtoken" was MISSING, and it is the spelling AWS
        # actually uses.  botocore raises
        #   An error occurred (ExpiredToken) when calling the
        #   StartQueryExecution operation: The security token included in the
        #   request is expired
        # which lowercases to "expiredtoken" -- matching neither "expired
        # token" (space) nor "token expired".  So the real expiry never
        # registered as a connection error, execute_query did not retry, and
        # the promise written into _get_connection's docstring ("if AWS
        # credentials expire we'll get an ExpiredToken error on the real query
        # and reconnect via the same code path") was never kept.  With
        # role-based auth the session token expires roughly hourly, so this
        # surfaced as a hard query failure on an idle connection.
        #
        # This is the ONLY place in the codebase that omitted it:
        # core/error_detection.py, core/iceberg_reader.py, core/feed_engine.py,
        # core/iceberg_bloom_sidecar.py and core/iceberg_column_stats.py all
        # carry "expiredtoken".  Aligned with that vocabulary rather than
        # inventing a sixth spelling.
        msg = str(exc).lower()
        return any(k in msg for k in (
            "connection refused", "connection reset", "connection abort",
            "broken pipe", "eof", "timed out", "timeout",
            "endpoint connection error", "could not connect",
            "expiredtoken", "expired token", "token expired",
            "token has expired",
        ))
