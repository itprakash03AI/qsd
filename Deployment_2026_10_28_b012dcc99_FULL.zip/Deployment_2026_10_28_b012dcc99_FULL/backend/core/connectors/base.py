"""
Abstract base class for SQL data source connectors.
All SQL connectors (Trino/Starburst, Snowflake, Databricks) implement this interface.
"""

import re
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

# A LIMIT clause only governs the statement when it TRAILS it.  Anchoring the
# match here is what makes `...\nLIMIT 10` visible (a bare ' LIMIT ' substring
# test missed it and appended a second clause) while keeping a ' LIMIT '
# occurring inside a string literal or comment from suppressing a real limit.
_TRAILING_LIMIT_RE = re.compile(
    # 2026-08-20 -- NULL ADDED.  query_compiler emits Snowflake's unbounded
# spelling as "LIMIT NULL" (query_compiler.py, _unbounded), which this
# pattern did not recognise -- so _apply_limit believed the SQL carried no
# window and appended a SECOND clause, producing
#     ... LIMIT NULL OFFSET 100\nLIMIT 5000
# which Snowflake rejects at parse time.  That is precisely the defect this
# regex was written to fix, reintroduced by a dialect spelling added later.
# Measured before: LIMIT NULL OFFSET 100 -> matched=False.
r"\bLIMIT\s+(?:\d+|ALL|NULL)\s*(?:OFFSET\s+\d+\s*)?\Z",
    re.IGNORECASE | re.DOTALL,
)



class DriverNotInstalled(RuntimeError):
    """The connector's driver package is not importable on THIS server.

    2026-09-15.  Every connector raised a plain ``RuntimeError("<pkg> is
    not installed. Add ... to requirements.txt")`` from its lazy import.
    ``POST /api/connections/{id}/test`` rendered that honestly (the
    connector's own ``{success: false, message}`` verdict), while
    ``GET .../tables`` answered 502 and ``GET .../files`` 500 -- both
    rewritten by main.py's CWE-209 chokepoint into "Internal server error.
    Please contact support."  Same missing driver, two answers, one of
    them useless.

    A missing driver is a CAPABILITY statement about the server, not a
    fault in the request and not an internal error, so it is its own
    type: the browse routes map it to 501 (the precedent PDF export set:
    ``PdfRendererUnavailable`` -> 501), which the chokepoint lets through.
    It subclasses RuntimeError so every existing ``except RuntimeError``
    keeps working.  ``package`` is the pip name the operator installs.
    """

    def __init__(self, package: str, message: str):
        super().__init__(message)
        self.package = package


def unique_column_names(names) -> List[str]:
    """Result column names, de-duplicated, order and first occurrence preserved.

    2026-08-25.  A SQL result may carry two columns of the SAME name — any
    ``SELECT a.id, b.id``, or a JOIN where both sides have ``id``/``name``/
    ``date``.  Every consumer downstream keys rows by name:

      * the connectors build rows with ``dict(zip(col_names, row))`` — a dict,
        so the LAST duplicate silently overwrites the first;
      * ``ParquetStreamWriter`` does ``cols_data[name].append(row.get(name))``,
        so both slots receive the same value;
      * the UI renders ``<TableCell key={col}>``, so duplicate names produce
        duplicate React keys and misplaced cells.

    Measured:

        dict(zip(['id','name','id'], (1,'alice',99)))
        -> {'id': 99, 'name': 'alice'}      # the first id is GONE

    HTTP 200, wrong data, no warning anywhere. That is why this exists.

    Renaming the LATER occurrence (``id``, ``id_1``, ``id_2``) is what every
    other SQL tool does, and it keeps the FIRST column's name stable so an
    existing saved report or column config still resolves.

    THIS FUNCTION IS THE IDENTITY WHEN NAMES ARE ALREADY UNIQUE — which is what
    makes it safe at every call site: results that work today are unchanged
    byte for byte, and only a result that was already being corrupted differs.

    Suffix is ``_1`` rather than pandas' ``.1``: a dot is unsafe in an
    identifier that may be re-quoted into SQL or used as a parquet field name.
    Collisions with an existing ``id_1`` are handled by incrementing until the
    name is genuinely free, so the output is unique even for adversarial input.
    """
    out: List[str] = []
    seen: set = set()
    for raw_name in names:
        name = "" if raw_name is None else str(raw_name)
        if name not in seen:
            seen.add(name)
            out.append(name)
            continue
        n = 1
        cand = f"{name}_{n}"
        while cand in seen:
            n += 1
            cand = f"{name}_{n}"
        seen.add(cand)
        out.append(cand)
    return out

# 2026-08-20 -- SHARED, LITERAL-AWARE "does this SQL already declare a row
# window?" test.
#
# Two drifted copies of this question existed.  connectors/base.py used the
# anchored regex above (correct, but blind to the ANSI FETCH form), while
# oracle_connector.py used bare substring tests -- `"ROWNUM" in upper` etc --
# which match INSIDE STRING LITERALS.  Measured:
#
#     SELECT * FROM t WHERE note = 'we use ROWNUM here'
#         -> oracle believed a window was present and SKIPPED the cap
#            entirely, returning an unbounded result and reporting it as the
#            capped answer.  Silent wrong row counts.
#
#     SELECT * FROM t OFFSET 20 ROWS FETCH NEXT 10 ROWS ONLY
#         -> base did NOT recognise the ANSI form and appended a second
#            clause, a parse error on Trino for user SQL written that way.
#
# One implementation, literal-stripped first, understanding BOTH grammars.
def _strip_sql_literals(sql: str) -> str:
    """Blank out quoted spans AND comments so keyword tests cannot match
    inside data or prose.  Length is preserved so offsets stay meaningful.

    2026-08-20 (second pass) -- COMMENTS, IN THE SAME SCAN.

    The first version handled only quotes, which left three holes, all found
    by re-deriving the commit's own claim:

      "SELECT * FROM t LIMIT 10 -- capped"
          window not seen  -> a SECOND clause appended -> parse error
      "SELECT * FROM t -- final LIMIT 10"
          window WRONGLY seen -> Oracle skips its ROWNUM cap -> UNBOUNDED
      "SELECT * FROM t\n-- don't forget\nLIMIT 10"
          the apostrophe in the comment opened an unterminated literal span
          that swallowed the real trailing clause

    The last one is why comments are consumed in the SAME left-to-right pass
    rather than stripped in a prior sweep: a `--` inside a string literal is
    data, and a `'` inside a comment is prose.  Only one scan can tell them
    apart, by whichever token opens first.
    """
    out = []
    i, n = 0, len(sql)
    while i < n:
        ch = sql[i]
        # line comment -- blank to end of line
        if ch == "-" and i + 1 < n and sql[i + 1] == "-":
            while i < n and sql[i] != chr(10):
                out.append(" ")
                i += 1
            continue
        # block comment
        if ch == "/" and i + 1 < n and sql[i + 1] == "*":
            end = sql.find("*/", i + 2)
            stop = n if end == -1 else end + 2
            out.append(" " * (stop - i))
            i = stop
            continue
        if ch in ("'", '"'):
            quote = ch
            out.append(" ")
            i += 1
            while i < n:
                if sql[i] == quote:
                    if i + 1 < n and sql[i + 1] == quote:
                        out.append("  ")
                        i += 2
                        continue
                    out.append(" ")
                    i += 1
                    break
                out.append(" ")
                i += 1
            continue
        out.append(ch)
        i += 1
    return "".join(out)


# 2026-08-20 (second pass): ROWS WITH TIES added -- valid Oracle 12c /
# ANSI spelling that the ONLY-anchored pattern missed, so a query using
# it was double-capped.
_FETCH_WINDOW_RE = re.compile(
    r"\bFETCH\s+(?:FIRST|NEXT)\b[\s\S]*?\bROWS?\s+(?:ONLY|WITH\s+TIES)\s*\Z",
    re.IGNORECASE,
)
_ROWNUM_RE = re.compile(r"\bROWNUM\b", re.IGNORECASE)


#: Leading keywords for statements that CANNOT carry a trailing row limit.
#
# 2026-09-17.  ``_apply_limit`` appended ``LIMIT n`` to whatever it was
# handed, and the caller supplies the limit, not the statement -- so any
# non-SELECT run through a connector got one.  Two different failures came
# out of that, found while driving Iceberg DDL through the product:
#
#   SYNTAX   ``CREATE TABLE ...``, ``DROP TABLE ...``, ``SHOW TABLES`` come
#            back as "mismatched input 'LIMIT'" -- an error naming a clause
#            the caller never wrote, at a line number that does not exist in
#            their SQL.
#
#   SILENT   ``INSERT INTO t SELECT ...`` + ``LIMIT 5000`` is VALID SQL that
#            writes 5,000 rows instead of all of them.  Same for
#            ``UPDATE``/``DELETE``/``MERGE`` on dialects that accept a limit.
#            A truncated WRITE reports success; nothing anywhere says the
#            other rows were dropped.  That is the one that matters.
#
# ``EXPLAIN`` is here for a third reason: appending to it is syntactically
# fine and silently explains a DIFFERENT query than the operator asked about.
#
# WHY A DENYLIST AND NOT AN ALLOWLIST.  An allowlist ("append only to SELECT
# / WITH / VALUES / TABLE") is the tidier shape, but it fails in the
# dangerous direction: anything it does not recognise -- a dialect spelling,
# a leading construct not thought of here -- loses its cap and runs
# UNBOUNDED.  A cap must throttle (CLAUDE.md section 4), so the safe default
# is to keep appending and subtract only what is KNOWN to be unable to carry
# a limit.  Every entry below is a statement no dialect in this repo takes a
# trailing row window on, or one where taking it is the bug.
_NO_ROW_LIMIT_LEADERS = (
    # DDL
    "create", "drop", "alter", "truncate", "comment", "rename",
    # DML that would be silently TRUNCATED rather than rejected
    "insert", "update", "delete", "merge", "upsert",
    # metadata / session / control — row-returning but not limitable here
    "show", "describe", "desc", "explain", "analyze", "analyse",
    "set", "reset", "use", "call", "execute", "prepare", "deallocate",
    "grant", "revoke", "deny",
    "begin", "commit", "rollback", "start", "savepoint",
    "refresh", "vacuum", "optimize", "msck",
)

_LEADING_WORD_RE = re.compile(r"[A-Za-z_]+")


def sql_takes_row_limit(sql: str) -> bool:
    """False when appending ``LIMIT n`` to ``sql`` would break or corrupt it.

    Literals and comments are blanked first, so a leading ``--`` banner or a
    statement beginning inside a quoted span cannot decide the answer.

    Unknown leading keywords return True on purpose -- see the note on
    ``_NO_ROW_LIMIT_LEADERS`` for why the default has to be "still cap it".
    """
    cleaned = _strip_sql_literals(str(sql or "").strip())
    # A blanked leading comment leaves whitespace, and a parenthesised
    # ``(SELECT ...)`` is still a query; neither changes the verdict.
    cleaned = cleaned.lstrip().lstrip("(").lstrip()
    m = _LEADING_WORD_RE.match(cleaned)
    if not m:
        return True
    return m.group(0).lower() not in _NO_ROW_LIMIT_LEADERS


def sql_declares_row_window(sql: str, *, include_rownum: bool = False) -> bool:
    """True when ``sql`` already carries its own row window.

    ``include_rownum`` is for Oracle, whose legacy wrap is a ROWNUM predicate
    rather than a trailing clause.
    """
    stripped = _strip_sql_literals(str(sql or "").strip().rstrip(";"))
    if _TRAILING_LIMIT_RE.search(stripped):
        return True
    if _FETCH_WINDOW_RE.search(stripped):
        return True
    if include_rownum and _ROWNUM_RE.search(stripped):
        return True
    return False


# 2026-08-20 (third pass) -- ONE bare-safe test and ONE conditional quoter.
#
# The conditional identifier quoter grew four copies in two days (trino ->
# snowflake -> databricks -> athena), and the copies had already drifted in
# three ways, each a live defect:
#
#   1. Trino's copy -- the FIRST one -- quoted UNCONDITIONALLY.  Trino
#      lower-folds bare identifiers, so a connection config carrying
#      `catalog: "Hive"` that resolved fine bare became the case-sensitive
#      `"Hive"` -> "Catalog 'Hive' does not exist".  The bare-safe
#      pass-through was applied to the three NEW quoters and never
#      retrofitted to the one that started the series.
#   2. All three conditional copies passed RESERVED WORDS through bare:
#      `_qi("order") == "order"`, so `DESCRIBE TABLE db.sch.order` was a
#      parse error on Snowflake and `SHOW TABLES IN "cat".order` failed on
#      Athena (Trino grammar reserves ORDER/TABLE).  sql_filter_wrapper.py
#      has carried exactly the right posture (bare-safe AND not reserved)
#      since 2026-08-03; its 95-word list is REUSED here, not copied.
#   3. All three copies treated `$` as bare-safe.  `$` is bare-legal ONLY
#      on Snowflake; `acct$x` passed through bare is a parse error on Spark
#      and Trino grammar.  Hence ``allow_dollar``, defaulting to the
#      posture that is safe everywhere.
#
# Case folding on the reserved-word branch: a bare identifier case-FOLDS
# (Snowflake upper-folds; Trino/Databricks/Athena lower-fold) while a quoted
# one is case-SENSITIVE.  A reserved word that WOULD have been bare must
# therefore be folded to the dialect's storage case before quoting, so that
# quoting it does not change which object is addressed -- `_qi("Order")` on
# Snowflake must mean the object `ORDER`, i.e. emit `"ORDER"`, not `"Order"`.
# Names that were never bare-legal (a hyphen, a space, a quote) are quoted
# VERBATIM, exactly as before: the user typed an exact name that could not
# have folded.
from core.sql_filter_wrapper import _SQL_RESERVED_WORDS


def ident_is_bare_safe(s: str, *, allow_dollar: bool = False) -> bool:
    """True when the identifier could legally appear bare in the dialect
    (character-wise -- reserved words are the CALLER's concern and are
    handled by :func:`quote_identifier`)."""
    if not s:
        return False
    first = s[0]
    if not (("a" <= first <= "z") or ("A" <= first <= "Z") or first == "_"):
        return False
    extra = "_$" if allow_dollar else "_"
    return all((("a" <= c <= "z") or ("A" <= c <= "Z")
                or ("0" <= c <= "9") or c in extra) for c in s)


def quote_identifier(name: Any, *, quote: str = '"', fold=str.lower,
                     allow_dollar: bool = False) -> str:
    """Render one identifier: bare when it is bare-safe AND not reserved,
    quoted (with embedded quote characters doubled) otherwise.

    ``quote`` is the dialect's identifier quote character (Databricks uses
    a backtick); ``fold`` is the dialect's bare-identifier case fold
    (Snowflake ``str.upper``, the rest ``str.lower``), applied ONLY on the
    reserved-word branch -- see the module comment above.
    """
    s = str(name)
    if ident_is_bare_safe(s, allow_dollar=allow_dollar):
        if s.lower() not in _SQL_RESERVED_WORDS:
            return s
        s = fold(s)
    return quote + s.replace(quote, quote + quote) + quote


class SourceUnavailableError(Exception):
    """The source could not be REACHED -- nothing about the statement was
    judged.  FB-39 (2026-09-19).

    ``SourceStatementError`` below is right for a REFUSAL (ORA-00942, a
    Trino FUNCTION_NOT_FOUND): the statement is unprocessable at the
    source, so a 4xx carrying the engine's text beats a 500 the chokepoint
    would flatten.  It was applied one case too widely.  With qs-trino
    stopped, POST /api/business-reports/{id}/execute answered ``400 "... is
    temporarily unavailable ... This clears ITSELF: just run the query
    again in 59s"`` -- the open breaker's own sentence, under a status that
    tells the client ITS REQUEST was bad, with no Retry-After to back off
    on.  An open breaker, a refused TCP connect, a DNS miss or a connect
    timeout is not a refusal; it clears by itself; it is a 503 with a
    Retry-After (``api.connector_errors.source_unavailable_503``).

    ``retry_after`` is the breaker's own countdown when there is one, else
    a short default -- the breaker opens after repeated failures and then
    supplies the exact figure.  Deliberately NOT a ValueError: the routes
    map ValueError to 4xx, which is the defect.
    """

    #: Retry-After for a transient failure the breaker has not yet timed.
    DEFAULT_RETRY_AFTER_S = 5

    def __init__(self, cause: BaseException, connection_type: str, *,
                 subject: str = "The {conn_type} source"):
        from core.error_sanitizer import explain_failure
        ct = str(connection_type or "").strip().lower() or "sql"
        retry = getattr(cause, "retry_after", None)
        try:
            self.retry_after = (float(retry) if retry is not None
                                else float(self.DEFAULT_RETRY_AFTER_S))
        except (TypeError, ValueError):
            self.retry_after = float(self.DEFAULT_RETRY_AFTER_S)
        if retry is not None:
            # The breaker wrote its sentence for the reader ("This clears
            # ITSELF ..."); keep it verbatim rather than re-rendering.
            text = str(cause)
        else:
            text = (explain_failure(cause, subject=f"Reaching {subject.format(conn_type=ct)}")
                    + f".  The source could not be reached -- nothing about "
                    f"the statement was refused -- and this is a transient "
                    f"condition: retry in {int(self.retry_after)}s.")
        super().__init__(text)
        self.connection_type = ct
        self.cause = cause


class CredentialsUnavailableError(SourceUnavailableError):
    """The source was never contacted: its credentials could not be OBTAINED.

    2026-10-04, live: with the published-API pod's Vault token missing, a
    Snowflake view (System Account, key pair from Vault) answered ``500
    "Query execution failed -- contact administrator"``.  Nothing about the
    request was wrong and nothing in our code was broken -- the secret
    store did not hand over the key -- yet the caller got the answer
    reserved for an internal fault, and no Retry-After to back off on.

    A subclass of ``SourceUnavailableError`` on purpose: every route that
    already answers "could not reach the source" with 503 + Retry-After
    (``api.connector_errors``) answers this the same way, through the same
    classifier, with no new branch at any route.

    The sentence is CALLER-SAFE: it names the connection type and what to
    do, never the System Account, the Vault path or role, or the resolver's
    own text -- the published API serves external consumers (CWE-209).
    The full root cause is on ``self.cause`` and in the ERROR line the
    connector factory writes.
    """

    #: Longer than a connect blip: a secret store or token comes back in
    #: tens of seconds, not five.
    DEFAULT_RETRY_AFTER_S = 30

    def __init__(self, cause: BaseException, connection_type: str):
        ct = str(connection_type or "").strip().lower() or "sql"
        Exception.__init__(
            self,
            f"The credentials for this {ct} source could not be obtained, so "
            f"the source was not contacted -- nothing about the request was "
            f"refused.  Retry in {self.DEFAULT_RETRY_AFTER_S}s; if it "
            f"persists, an administrator must check the connection's "
            f"system account and the secret store.")
        self.retry_after = float(self.DEFAULT_RETRY_AFTER_S)
        self.connection_type = ct
        self.cause = cause


def admin_cause(exc: BaseException) -> BaseException:
    """What an ADMIN surface (a connection test) should explain.

    ``CredentialsUnavailableError``'s sentence is deliberately caller-safe and
    so says nothing about WHICH field the System Account lacks.  The admin
    who is testing the connection needs exactly that ("has no Snowflake
    private key: it has the fields ['key', 'username']" -- field NAMES,
    never values), so admin routes explain the root cause instead.  Every
    other exception is returned unchanged.
    """
    if isinstance(exc, CredentialsUnavailableError) and exc.cause is not None:
        return exc.cause
    return exc


#: A CONNECTION the source refused for a reason a retry never clears
#: (2026-10-08, the Starburst-shaped rig).  Each entry: the tokens that
#: identify it in the exception's class names or text, and the sentence
#: the person sees -- the remedy, in the connection's own field names.
#:
#: Before this, requests' ``SSLError`` was classified TRANSIENT (its MRO
#: holds ``ConnectionError`` and urllib3 wraps it in ``MaxRetryError``):
#: a certificate the pod does not trust answered 503 + Retry-After and
#: counted as a breaker failure, for a condition no retry clears; and the
#: trino client's HTTP 401 (a wrong password) was no PEP-249 class, so the
#: browse routes answered 500 "contact support" for the one thing the
#: person could fix.
_CONNECTION_REFUSALS = (
    # (class-name tokens, message tokens, sentence)
    ((), ("wrong_version_number", "wrong version number"),
     "The {ct} source answered a TLS handshake with plain HTTP: the port is "
     "not an HTTPS port. Set http_scheme to http for a cluster without TLS, "
     "or point the connection at the cluster's HTTPS port."),
    (("SSLCertVerificationError",),
     ("certificate verify failed", "certificate_verify_failed",
      "unable to get local issuer certificate", "self-signed certificate",
      "self signed certificate", "hostname mismatch", "doesn't match",
      "certificate is not valid for",
      # the JVM's spellings (the Spark lane's JDBC driver, 2026-10-10 --
      # core/spark_k8s/failure_text.py renders the Java cause as text)
      "pkix path building failed", "unable to find valid certification path",
      "sslhandshakeexception"),
     "The {ct} source's TLS certificate is not trusted by this server. Paste "
     "the issuing CA on the connection (ca_cert_pem), or deploy it in the "
     "server's trust bundle (QS_CA_BUNDLE_PATH); turn verification off only "
     "for a known internal endpoint."),
    (("TrinoAuthError",), ("error 401", "401 unauthorized", "http 401"),
     "The {ct} source rejected the user name or password (HTTP 401). Check "
     "the connection's user, password and auth_type -- and that the login "
     "goes over HTTPS, since Trino/Starburst accept no credentials over HTTP."),
    ((), ("error 403", "http 403", "403 forbidden"),
     "The {ct} source refused this user (HTTP 403): the login was accepted "
     "but the user may not use the cluster. Check the user's role or "
     "cluster entitlement at the source."),
)


def connection_refusal_reason(exc: BaseException, connection_type: str = "sql"
                              ) -> Optional[str]:
    """The sentence for a CONNECTION the source refused for a reason no retry
    clears -- an untrusted certificate, HTTPS spoken to an HTTP port, a
    rejected login -- or None.  Walks the cause chain (bounded): urllib3
    nests the SSL verdict three exceptions deep."""
    ct = str(connection_type or "sql").strip().lower() or "sql"
    seen = 0
    cur: Optional[BaseException] = exc
    while cur is not None and seen < 8:
        seen += 1
        names = {k.__name__ for k in type(cur).__mro__}
        msg = str(cur).lower()
        for class_tokens, msg_tokens, sentence in _CONNECTION_REFUSALS:
            if (names & set(class_tokens)) or any(tok in msg for tok in msg_tokens):
                return sentence.format(ct=ct)
        nxt = cur.__cause__ if cur.__cause__ is not None else cur.__context__
        cur = nxt if nxt is not cur else None
    return None


#: Message tokens that say the source JUDGED the caller's RIGHT to do what
#: the statement asked (2026-10-10, the first live run against the
#: Starburst-shaped rig).  Trino answers a refused ``X-Trino-Role`` with HTTP
#: 500 and a Java exception body (``io.trino.spi.security.AccessDeniedException:
#: Access Denied: Cannot set role sb_auditor\n\tat io.trino...``) -- the
#: trino client raises a plain ``HttpError`` for it, no PEP-249 class, so
#: the browse routes answered 500 "contact support"; a SELECT on a hidden
#: column is a ``TrinoUserError`` named PERMISSION_DENIED whose ``str()`` is
#: the driver's repr (``TrinoUserError(type=USER_ERROR, name=...``), which
#: three roads stored verbatim as the run's error.  Oracle spells it
#: ORA-01031 / ORA-00942 (the latter is a verdict already); Snowflake
#: "Insufficient privileges to operate on ...".  NOT "permission denied"
#: alone: that is also the OS's wording for a file we may not open, which is
#: OUR fault, not the source's verdict.
_ACCESS_DENIED_MSG_TOKENS = ("access denied", "accessdeniedexception",
                             "insufficient privileges")
#: The driver's own name for it (Trino ``error_name``).
_ACCESS_DENIED_ERROR_NAMES = frozenset({"PERMISSION_DENIED"})
#: Where a sentence ends inside a response body that was rendered as
#: ``repr(bytes)``: the Java stack's ``\n\tat`` arrives as the four
#: characters backslash-n-backslash-t.
_SENTENCE_BREAKS = ("\\r\\n", "\\n", "\\t", "\r\n", "\n", "\t")


def driver_message(exc: BaseException) -> Optional[str]:
    """The plain sentence a DRIVER exception carries, when its ``str()`` is a
    repr instead (the trino client's ``TrinoQueryError.__str__`` returns
    ``repr(self)``: ``TrinoUserError(type=USER_ERROR, name=..., message="...",
    query_id=...)``).  None for any exception whose ``str()`` already IS the
    message.  Judged by shape -- a ``message`` text plus an ``error_name``
    and a ``str()`` that opens with the class name -- never by import."""
    msg = getattr(exc, "message", None)
    if not isinstance(msg, str) or not msg.strip():
        return None
    if not hasattr(exc, "error_name"):
        return None
    if not str(exc).startswith(type(exc).__name__ + "("):
        return None
    return msg.strip()


def _first_sentence(text: str, start: int) -> str:
    """``text`` from ``start`` to the first line / stack break, trailing
    quote and bytes-repr artefacts removed."""
    out = text[start:]
    cut = len(out)
    for brk in _SENTENCE_BREAKS:
        i = out.find(brk)
        if 0 <= i < cut:
            cut = i
    return out[:cut].strip().rstrip("'\"").strip()


def _denial_in_text(text: str) -> Optional[str]:
    """The access-denial sentence inside ``text``, or None."""
    low = text.lower()
    for tok in _ACCESS_DENIED_MSG_TOKENS:
        i = low.find(tok)
        if i < 0:
            continue
        if tok == "accessdeniedexception":
            # "...AccessDeniedException: Access Denied: Cannot set role X"
            # -- the sentence starts after the class name.
            j = low.find("access denied", i + len(tok))
            i = j if j >= 0 else i
        return _first_sentence(text, i)
    return None


def source_access_denial(exc: BaseException) -> Optional[str]:
    """The source's sentence when it refused the caller's RIGHT -- a role it
    may not assume, a column or table it may not read -- or None.  The
    cluster's verdict, in the cluster's words, with no Java frames and no
    driver repr around it.  Walks the cause chain (bounded).

    A CONNECTION refusal wins: Trino answers a wrong password with HTTP
    401 and the body "Access Denied: Invalid credentials" -- that is the
    connection's login being wrong (400, fix the connection), not a right
    the caller lacks (403).  Found live 2026-10-10 (starburst_like T3)."""
    if connection_refusal_reason(exc) is not None:
        return None
    seen = 0
    cur: Optional[BaseException] = exc
    while cur is not None and seen < 8:
        seen += 1
        name = str(getattr(cur, "error_name", "") or "").upper()
        if name in _ACCESS_DENIED_ERROR_NAMES:
            return driver_message(cur) or str(cur).strip()
        found = _denial_in_text(driver_message(cur) or str(cur))
        if found:
            return found
        nxt = cur.__cause__ if cur.__cause__ is not None else cur.__context__
        cur = nxt if nxt is not cur else None
    return None


#: The HTTP status a source's ACCESS verdict answers with: the caller may
#: not do this at the source, and no change to the statement's text fixes
#: it -- 403, like a row-security refusal (``RowSecurityRefused``).
ACCESS_DENIED_STATUS = 403


def source_verdict_status(exc: BaseException) -> Optional[int]:
    """THE status a source's verdict carries beyond the route's own 4xx:
    403 for an access denial; None when the route's default (400 on a
    browse, 422 on an execute) stands.  One decision for the sync routes
    (``api.connector_errors``) and the stored ``SourceStatementError``."""
    if source_access_denial(exc) is not None:
        return ACCESS_DENIED_STATUS
    return None


#: Exception CLASS names (walked up each class's MRO, so a driver subclass
#: qualifies) that mean "could not reach the source".  Names, not imports:
#: this module must not drag in every driver.
_TRANSIENT_EXC_CLASS_NAMES = frozenset({
    "CircuitOpenError",
    # stdlib
    "ConnectionError", "ConnectionRefusedError", "ConnectionResetError",
    "ConnectionAbortedError", "BrokenPipeError", "TimeoutError", "gaierror",
    "herror",
    # requests / urllib3 / httpx (Trino, Databricks, REST)
    "ConnectTimeout", "ReadTimeout", "Timeout", "MaxRetryError",
    "NewConnectionError", "ConnectTimeoutError", "ProtocolError",
    "ConnectError", "RemoteProtocolError",
    # DB-API drivers name the connect failure this way
    "TrinoConnectionError", "InterfaceError",
})
#: Driver-reported error NAMES that mean "not ready yet".  FB-40
#: (2026-09-19): for ~6 s after ``docker restart qs-trino`` every browse
#: answered 500 "contact support"; the log held TrinoQueryError(
#: type=INTERNAL_ERROR, name=SERVER_STARTING_UP, "Trino server is still
#: initializing").  The TYPE is INTERNAL_ERROR, so classifying on the type
#: would call a self-clearing start-up an internal fault -- the NAME (the
#: driver exposes it as ``error_name``) is what says it clears itself.
_TRANSIENT_ERROR_NAMES = frozenset({
    "SERVER_STARTING_UP", "SERVER_SHUTTING_DOWN", "NO_NODES_AVAILABLE",
    "REMOTE_TASK_ERROR", "REMOTE_HOST_GONE", "CLUSTER_OUT_OF_MEMORY",
})
#: Message tokens that identify a connect-level failure when the class name
#: does not (Oracle's DatabaseError carries the code in the text).
_TRANSIENT_MSG_TOKENS = (
    "server is still initializing", "server_starting_up", "server is starting",
    "dpy-6005", "dpy-6001", "dpy-4011",          # oracledb: cannot connect / lost
    "ora-12541", "ora-12170", "ora-12543", "ora-12514", "ora-03113", "ora-03114",
    "250001",                                    # snowflake: could not connect
    "connection refused", "name or service not known", "getaddrinfo failed",
    "nodename nor servname", "temporary failure in name resolution",
    "unknownhostexception",                      # the JVM's (Spark lane)
    "connection reset by peer", "timed out", "no route to host",
    "failed to establish a new connection", "max retries exceeded",
)


def is_transient_source_failure(exc: BaseException) -> bool:
    """True when ``exc`` (or anything in its cause chain, bounded) says the
    source could not be reached, as opposed to the source judging the
    statement.  Unknown classes with no transient token are NOT transient --
    a refusal mislabelled as an outage would hide a real error behind a
    retry loop."""
    # A refused CONNECTION (untrusted certificate, rejected login) is
    # decided FIRST: requests spells an SSL failure as a ConnectionError
    # inside a MaxRetryError, both of which the lists below call transient.
    # So is a refused RIGHT (2026-10-10): the source answered; it is up.
    if connection_refusal_reason(exc) is not None:
        return False
    if source_access_denial(exc) is not None:
        return False
    seen = 0
    cur: Optional[BaseException] = exc
    while cur is not None and seen < 8:
        seen += 1
        if isinstance(cur, (SourceUnavailableError,)):
            return True
        if isinstance(cur, SourceStatementError):
            return False
        names = {k.__name__ for k in type(cur).__mro__}
        if names & _TRANSIENT_EXC_CLASS_NAMES:
            return True
        # FB-40: a driver that names its errors (Trino: error_name) -- the
        # name outranks the type, which is INTERNAL_ERROR for a start-up.
        if str(getattr(cur, "error_name", "") or "").upper() in _TRANSIENT_ERROR_NAMES:
            return True
        msg = str(cur).lower()
        if any(tok in msg for tok in _TRANSIENT_MSG_TOKENS):
            return True
        # 2026-10-02 -- the DuckDB S3 scan's declared transient signatures
        # (core.s3_scan_retry.TRANSIENT_SIGNATURES: type AND message).  The
        # scan retry called "Could not connect to server ... HTTP HEAD" a
        # transient and retried it; when the retries ran out, THIS
        # classifier said "not transient" and the route answered a 500
        # "contact support" for a condition a re-run cleared.  Two answers
        # to one question; the declared list now answers both.
        try:
            from core.s3_scan_retry import classify_transient
            if classify_transient(cur) is not None:
                return True
        except ImportError:                                 # pragma: no cover
            pass
        nxt = cur.__cause__ if cur.__cause__ is not None else cur.__context__
        cur = nxt if nxt is not cur else None
    return False


#: PEP-249 exception class names.  A driver raising one of these has
#: JUDGED the statement (or its own state); our code never raises them.
#: ``Error``/``Warning`` are excluded as too generic, and the transient
#: members (OperationalError, InterfaceError) are consulted only AFTER
#: is_transient_source_failure has said no.
_DBAPI_VERDICT_CLASS_NAMES = frozenset({
    "DatabaseError", "ProgrammingError", "DataError", "IntegrityError",
    "NotSupportedError", "InternalError", "OperationalError", "InterfaceError",
})


def is_source_verdict(exc: BaseException) -> bool:
    """True when ``exc`` is the DRIVER's verdict on a statement -- a PEP-249
    exception (Trino's TrinoUserError is a ProgrammingError; Oracle's
    ORA-00942 a DatabaseError) that is not transient.  A TypeError in our
    own code is neither.  FB-40b (2026-09-19): on the CQB browse routes a
    SCHEMA_NOT_FOUND refusal was a 500 "contact support" -- the source's
    sentence erased -- the FB-29b shape on the other browser."""
    if isinstance(exc, SourceStatementError):
        return True
    if connection_refusal_reason(exc) is not None:
        # 2026-10-08: the source judged the CONNECTION (certificate, login)
        # -- the caller's to fix, so a 4xx with the sentence, like a
        # refused statement.
        return True
    if source_access_denial(exc) is not None:
        # 2026-10-10: the source judged the caller's RIGHT (a role it may
        # not set, a column it may not read) -- Trino's HTTP 500 +
        # AccessDeniedException body carries no PEP-249 class, so it was
        # a 500 "contact support" at every browse route.
        return True
    if is_transient_source_failure(exc):
        return False
    seen = 0
    cur: Optional[BaseException] = exc
    while cur is not None and seen < 8:
        seen += 1
        # FB-41: the driver classified it for us (Trino: error_type
        # USER_ERROR) -- honour that before the class-name test.
        if str(getattr(cur, "error_type", "") or "").upper() == "USER_ERROR":
            return True
        if {k.__name__ for k in type(cur).__mro__} & _DBAPI_VERDICT_CLASS_NAMES:
            return True
        nxt = cur.__cause__ if cur.__cause__ is not None else cur.__context__
        cur = nxt if nxt is not cur else None
    return False


def wrap_source_failure(exc: BaseException, connection_type: str, *,
                        subject: Optional[str] = None) -> Exception:
    """THE one place a connector failure is classified (FB-39).

    Returns the exception to raise: a ``SourceUnavailableError`` when the
    source could not be reached (503 + Retry-After at the route), else a
    ``SourceStatementError`` (the source's verdict, 4xx with its text).
    An already-classified exception is returned unchanged so nested wrap
    sites never re-wrap.  Every site that used to construct
    ``SourceStatementError`` directly goes through here; a guard test
    keeps it that way.
    """
    if isinstance(exc, (SourceUnavailableError, SourceStatementError)):
        return exc
    if is_transient_source_failure(exc):
        if subject is None:
            return SourceUnavailableError(exc, connection_type)
        return SourceUnavailableError(exc, connection_type, subject=subject)
    if subject is None:
        return SourceStatementError(exc, connection_type)
    return SourceStatementError(exc, connection_type, subject=subject)


class SourceStatementError(ValueError):
    """The SOURCE engine refused or failed the statement it was sent.

    2026-09-15.  A dataset execute that Oracle refused (ORA-03048, ORA-00911)
    surfaced as ``HTTPException(500, "Execution failed")``, which the app's
    5xx chokepoint (``main.py``) replaces with "Internal server error.
    Please contact support with this reference."  The ORA line -- the one
    thing that tells the author what to change -- lived only in
    ``federation_executions.error_message``, which no screen shows for a
    failed run.  Live verification took the request id to the server log
    to learn what a user could never learn.

    The engine's verdict on a statement is not an internal error; it is the
    request being unprocessable AT THE SOURCE, and the routes already map
    ``ValueError`` (the engine's own refusals) to a 422 that carries its
    text.  So this is a ValueError whose message is the engine's, rendered
    ONCE through ``core.error_sanitizer.explain_failure`` (credentials,
    paths and proxy URLs scrubbed; stack traces never included) -- the same
    text reaches the stored ``error_message`` and the response.  A failure
    inside OUR code (a TypeError in the builder) is not wrapped and stays a
    500.
    """

    def __init__(self, cause: BaseException, connection_type: str, *,
                 subject: str = "The statement sent to the {conn_type} source"):
        from core.error_sanitizer import explain_failure
        ct = str(connection_type or "").strip().lower() or "sql"
        # ``explain_failure`` renders "<subject> failed: <cause>", so the
        # subject is a noun phrase: "The statement sent to the oracle
        # source failed: ORA-00942: table or view ... does not exist".
        super().__init__(explain_failure(
            cause, subject=subject.format(conn_type=ct)))
        self.connection_type = ct
        self.cause = cause
        #: 2026-10-10 -- the status this verdict carries beyond the route's
        #: own 4xx (403 for an access denial), or None.  Decided ONCE by
        #: ``source_verdict_status``; ``api.connector_errors.refusal_status``
        #: reads it at the routes that answer a ValueError themselves.
        self.http_status = source_verdict_status(cause)


def describe_source_failure(exc: BaseException, connection_type: str) -> str:
    """THE text a lane that records a failed run stores as its
    ``error_message`` (2026-10-10, found by the first live run against the
    Starburst-shaped rig).

    Three roads stored ``str(exc)`` raw: the SQL editor wrote
    ``HTTPSConnectionPool(host=..., port=8443): Max retries exceeded ...
    CERTIFICATE_VERIFY_FAILED`` for an untrusted certificate while the
    connection TEST and the browse routes said "not trusted ... paste the
    issuing CA (ca_cert_pem)", and ``TrinoUserError(type=USER_ERROR,
    name=PERMISSION_DENIED, message="Access Denied: ...")`` -- the driver's
    repr -- for a hidden column.  Two answers to one question.

    A source failure (could not be reached / refused the connection /
    judged the statement or the right) is rendered through the SAME
    classifier and renderer the routes use (``wrap_source_failure`` ->
    ``explain_failure``), so the stored text and a sync route's detail are
    one sentence.  Anything else -- a fault in our own code -- keeps its own
    text, scrubbed, with a bare exception named (``TypeError: ...``) rather
    than being attributed to the source.
    """
    from core.error_sanitizer import describe_exception
    if isinstance(exc, (SourceUnavailableError, SourceStatementError)):
        return str(exc)
    if is_transient_source_failure(exc) or is_source_verdict(exc):
        return str(wrap_source_failure(exc, connection_type))
    return describe_exception(exc)


class SqlConnector(ABC):
    """
    Base class for all SQL source connectors.
    Config dict is passed at construction time — all connection parameters come
    from the stored connection record (no hardcoded values).
    """

    def __init__(self, config: Dict[str, Any]):
        self.config = config

    def _test_failure(self, exc: BaseException) -> Dict[str, Any]:
        """The failed ``test_connection`` result, rendered ONCE for every
        connector (2026-09-14).

        Each subclass used to return ``{"message": str(e)}`` -- which for a
        credential stored under the wrong key is the string ``'user'``.  The
        message now names the connector, the missing field, and whether the
        configuration actually lacks it; see
        ``core.error_sanitizer.explain_failure``.  ``details`` stays ``{}``:
        callers assert that shape.
        """
        from core.error_sanitizer import explain_failure
        label = type(self).__name__
        if label.endswith("Connector"):
            label = label[:-len("Connector")] or label
        return {
            "success": False,
            "message": explain_failure(
                exc, subject=f"{label} connection test",
                config=self.config if isinstance(self.config, dict) else None),
            "details": {},
        }

    # ── Connection lifecycle ──────────────────────────────────────────────────

    @abstractmethod
    def test_connection(self) -> Dict[str, Any]:
        """
        Verify connectivity.
        Returns: { "success": bool, "message": str, "details": {...} }
        """

    @abstractmethod
    def close(self):
        """Release any held resources / connection pools."""

    # ── Execution ID for status reporting ───────────────────────────────────
    # BF-TRINO-STATUS: connectors that poll source-DB query state (Trino
    # cur.stats, Snowflake query_id lookup, etc.) need to know which
    # QueryStudio execution_id to attribute status to.  Caller invokes
    # this before execute_query / execute_query_streaming.  Default is
    # None — connectors that don't poll status ignore it cleanly.

    def set_execution_id(self, execution_id):
        """Bind a QueryStudio execution_id to this connector instance so
        the streaming methods can push live source-DB query state to
        ``core.execution_stage`` for the heartbeat / per-query log."""
        self._qs_execution_id = execution_id

    # ── Reuse contract (2026-09-16) ─────────────────────────────────────
    # Connection pooling hands ONE connector instance to a SECOND caller.
    # That is only safe if the instance carries no state from the first --
    # and these instances DO: ``set_execution_id`` binds a QueryStudio
    # execution id used to attribute live source-DB query status, so a
    # reused connector would report execution B's progress against
    # execution A.  That was demonstrated, not theorised: wiring the pool
    # made a test receive the PREVIOUS test's connector with its fields
    # still set.
    #
    # ``POOL_SAFE`` is a DECLARATION and defaults to False, because this
    # repo has already paid for the other default: OG's ``RETRY_SAFE`` once
    # defaulted true, a non-idempotent step was retried, and it produced
    # 50M duplicate rows.  Unknown is unsafe.  A connector class opts in
    # only when someone has read it and can say what ``reset_for_reuse``
    # has to clear.

    #: May an instance of this connector be handed to a second caller after
    #: ``reset_for_reuse()``?  Declared per class; never inferred.
    POOL_SAFE: bool = False

    def reset_for_reuse(self) -> None:
        """Clear per-CALLER state before this instance is reused.

        The base clears what the base binds.  A subclass that holds a
        cursor, a session setting, a temp view or a transaction must extend
        this AND declare ``POOL_SAFE = True`` -- in that order.  Raising
        from here is a valid answer: the pool discards a connector whose
        reset fails rather than pass it on.
        """
        self._qs_execution_id = None

    # ── Schema browsing ───────────────────────────────────────────────────────

    @abstractmethod
    def list_catalogs(self) -> List[str]:
        """Return list of catalog names (databases in Snowflake, catalogs in Trino)."""

    @abstractmethod
    def list_schemas(self, catalog: str) -> List[str]:
        """Return list of schema names within the given catalog."""

    @abstractmethod
    def list_tables(self, catalog: str, schema: str) -> List[Dict[str, Any]]:
        """
        Return list of table info dicts:
        [{ "name": str, "type": "TABLE"|"VIEW", "catalog": str, "schema": str }]
        """

    @abstractmethod
    def list_columns(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        """
        Return column metadata:
        [{ "name": str, "type": str, "nullable": bool, "ordinal": int }]
        """

    # ── Partition detection ─────────────────────────────────────────────────────

    def detect_partitions(self, catalog: str, schema: str, table: str) -> List[Dict[str, Any]]:
        """
        Detect partition / clustering columns for a table.
        Returns: [{ "name": str, "type": str, "transform": str }]
        Override in subclasses that support partition introspection.
        Default: empty list (no partition detection).
        """
        return []

    # ── Write capabilities (2026-08-22, write ladder rung 1) ──────────────────

    def write_capabilities(self) -> Dict[str, Any]:
        """What this connector DECLARES about writing results somewhere
        other than back through this process.

        Registry-shaped (core.feed.write_ladder): the ladder routes on
        this declaration and NEVER if/elifs per connector type.  The
        base class declares NOTHING -- UNKNOWN = UNSAFE -- so a connector
        gains rung-1 (engine-side write) eligibility only by overriding
        this and returning e.g.::

            {"engine_write": {"scratch_catalog": ..., "scratch_schema": ...,
                              "s3_location": ...}}

        and only when the CONNECTION's own config carries the required
        declaration (the per-resource declaration IS the opt-in -- same
        rule as the vault resolver).
        """
        return {}

    # ── Query execution ───────────────────────────────────────────────────────

    @abstractmethod
    def execute_query(self, sql: str, limit: Optional[int] = None) -> Dict[str, Any]:
        """
        Execute a SQL statement and return results as a dict:
        {
            "columns": [{ "name": str, "type": str }],
            "rows":    list[dict],
            "total_rows": int,
        }
        Implementations should apply `limit` if provided (adds LIMIT clause or
        uses cursor row-limit to avoid fetching millions of rows without intent).
        """

    # ── Streaming execution (Phase 139 Tier 2.1) ──────────────────────────────

    def execute_query_streaming(
        self,
        sql: str,
        chunk_size: int = 1000,
        limit: Optional[int] = None,
        cancel_event=None,
    ):
        """Yield (columns, rows_chunk) tuples as the cursor produces rows.

        Real cursor.fetchmany(N) pull — first chunk arrives as soon as the
        source DB has the first N rows, NOT after the full result lands.
        Mirrors Trino's HTTP chunked-transfer model.

        BF-262 follow-up: ``cancel_event`` is an optional ``threading.Event``;
        when set, connectors abort the cursor and stop yielding.  Mirrors the
        DuckDB ``con.interrupt()`` pattern from execute_api but uses each
        connector's native cancel API (Snowflake/Trino: ``cursor.cancel()``;
        Databricks/Oracle: ``cursor.close()``).  Default implementation
        checks the event between batches; subclasses that fall back to
        ``execute_query`` cannot cancel mid-execute.
        Yields:
            (columns_list, rows_chunk) where columns_list is a list of dicts
            with name/type and rows_chunk is a list of dicts.
        """
        result = self.execute_query(sql, limit=limit)
        cols = result.get("columns", [])
        rows = result.get("rows", [])
        if not rows:
            yield cols, []
            return
        for i in range(0, len(rows), chunk_size):
            if cancel_event is not None and cancel_event.is_set():
                return
            yield cols, rows[i : i + chunk_size]

    # ── Helper ───────────────────────────────────────────────────────────────

    def _apply_limit(self, sql: str, limit: Optional[int]) -> str:
        """Append a LIMIT clause unless one is already present.

        Non-positive means UNLIMITED, matching the rest of the product.

        2026-08-17 -- two defects fixed here, in the one helper every SQL
        connector (trino/starburst, snowflake, databricks, athena) shares:

        1. ``limit=0`` used to emit ``LIMIT 0`` and return ZERO rows.  On
           2026-08-13 the product adopted "0 means unlimited" and fixed the
           SQL *builders*, but the raw 0 still reached this helper.  That
           turned "0 was silently clipped to a default" into "0 returns
           nothing" -- so on a Starburst business report, the only spelling
           that removes the cap was the one that returned an empty result.
           feed_engine.py:2490 works around it locally with a comment saying
           a connector reading limit=0 "would return ZERO rows"; fixing it
           at the source removes the need for that workaround everywhere.

        2. Detection was the substring ``' LIMIT '``, so the ordinary
           formatted spelling ``...\\nLIMIT 10`` was not seen and a SECOND
           clause was appended -- ``LIMIT 10\\nLIMIT 5000`` -- which Trino
           rejects at parse time, failing the whole report.  Conversely a
           ``' LIMIT '`` appearing inside a string literal suppressed a
           genuine limit.  Detection is now an anchored match on a TRAILING
           clause, which is the only position that actually governs the
           statement.
        """
        if limit is None or int(limit) <= 0:
            # 2026-10-03 -- the trailing ';' is dropped on the NO-limit road too.
            # Only the limit branch stripped it, so the query builder's
            # ``... LIMIT 5000;`` reached Trino unlimited-and-unstripped:
            # "mismatched input ';'" on every visual run over a browsed table.
            # These connectors run ONE statement; a terminator is never theirs.
            return sql.strip().rstrip(';').rstrip()
        stripped = sql.strip().rstrip(';')
        # 2026-08-20 (second pass) -- USE THE SHARED DETECTOR.
        #
        # sql_declares_row_window() was added EARLIER THE SAME DAY to answer
        # exactly this question, and was wired into ORACLE ONLY -- while this
        # function, the one that motivated it, kept testing the LIMIT-only
        # regex.  So ANSI-FETCH SQL still got a second window appended:
        #
        #   'OFFSET 20 ROWS FETCH NEXT 10 ROWS ONLY'  ->  '...' + LIMIT 5000
        #
        # a parse error on Trino/Snowflake/Databricks/Athena, reachable from
        # report row limits, DQ rules (limit=10000) and feed query_params.
        # Building the right tool and wiring it into one caller is the same
        # defect this sweep keeps finding.
        if sql_declares_row_window(stripped):
            return stripped
        # 2026-09-17 -- a limit is only meaningful on a statement that can
        # CARRY one.  DDL and SHOW come back as "mismatched input 'LIMIT'",
        # naming a clause the caller never wrote; worse, INSERT ... SELECT
        # accepts it and silently writes fewer rows than asked.  See
        # _NO_ROW_LIMIT_LEADERS for why this subtracts rather than allows.
        if not sql_takes_row_limit(stripped):
            return stripped
        # int() so a float/bool limit cannot reach the SQL text verbatim.
        return f"{stripped}\nLIMIT {int(limit)}"
