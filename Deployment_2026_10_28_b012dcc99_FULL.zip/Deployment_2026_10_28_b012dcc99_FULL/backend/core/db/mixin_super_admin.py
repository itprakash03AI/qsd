"""
Mixin — SuperAdmin (Phase 107-D).

Break-glass admin accounts stored in SQLite. Works even when AD bind fails,
so an operator can always recover access if directory services are down.
"""
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any

from core.db.models import SuperAdmin


class SuperAdminMixin:
    """Database CRUD for break-glass super admin accounts."""

    def create_super_admin(
        self,
        username: str,
        password_hash: str,
        created_by: Optional[str] = None,
        notes: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a new super admin row. Raises if username already exists."""
        with self.get_session() as session:
            existing = session.query(SuperAdmin).filter(SuperAdmin.username == username).one_or_none()
            if existing is not None:
                raise ValueError(f"super admin already exists: {username}")
            row = SuperAdmin(
                username=username,
                password_hash=password_hash,
                is_active=True,
                created_at=datetime.now(timezone.utc),
                created_by=created_by,
                notes=notes,
            )
            session.add(row)
            session.flush()
            return row.to_dict(include_hash=False)

    def get_super_admin_by_username(self, username: str) -> Optional[Dict[str, Any]]:
        """Returns the row INCLUDING password_hash (for auth verification only)."""
        with self.get_session() as session:
            row = session.query(SuperAdmin).filter(SuperAdmin.username == username).one_or_none()
            return row.to_dict(include_hash=True) if row else None

    def list_super_admins(self) -> List[Dict[str, Any]]:
        """All super admins. Never returns password hashes."""
        with self.get_session() as session:
            rows = session.query(SuperAdmin).order_by(SuperAdmin.username).all()
            return [r.to_dict(include_hash=False) for r in rows]

    def update_super_admin_password(self, username: str, new_password_hash: str) -> bool:
        """Rotate password hash. Returns True if updated, False if not found."""
        with self.get_session() as session:
            row = session.query(SuperAdmin).filter(SuperAdmin.username == username).one_or_none()
            if row is None:
                return False
            row.password_hash = new_password_hash
            return True

    def set_super_admin_active(self, username: str, active: bool) -> bool:
        """Enable/disable a super admin without deleting it."""
        with self.get_session() as session:
            row = session.query(SuperAdmin).filter(SuperAdmin.username == username).one_or_none()
            if row is None:
                return False
            row.is_active = bool(active)
            return True

    def delete_super_admin(self, username: str) -> bool:
        """Hard delete a super admin row."""
        with self.get_session() as session:
            row = session.query(SuperAdmin).filter(SuperAdmin.username == username).one_or_none()
            if row is None:
                return False
            session.delete(row)
            return True

    def record_super_admin_login(self, username: str) -> None:
        """Stamp last_login_at on successful break-glass login. Best-effort."""
        try:
            with self.get_session() as session:
                row = session.query(SuperAdmin).filter(SuperAdmin.username == username).one_or_none()
                if row is not None:
                    row.last_login_at = datetime.now(timezone.utc)
        except Exception:
            pass

    def count_active_super_admins(self) -> int:
        """Number of currently-active super admins. Used to prevent lockout."""
        with self.get_session() as session:
            return int(
                session.query(SuperAdmin)
                .filter(SuperAdmin.is_active == True)  # noqa: E712
                .count()
            )
