"""
Phase 114-B — Published View Webhooks CRUD mixin.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import List, Optional

logger = logging.getLogger(__name__)


class WebhooksMixin:
    """CRUD methods for PublishedViewWebhook."""

    def create_pv_webhook(self, *, view_id: int | None, url: str, events: list,
                          secret: str | None = None, retry_max: int = 3,
                          timeout_seconds: int = 10, created_by: str = "") -> dict:
        from core.db.models import PublishedViewWebhook
        with self.get_session() as session:
            wh = PublishedViewWebhook(
                view_id=view_id, url=url, events=events, secret=secret,
                retry_max=retry_max, timeout_seconds=timeout_seconds,
                created_by=created_by,
            )
            session.add(wh)
            session.flush()
            result = wh.to_dict()
            session.commit()
            return result

    def list_pv_webhooks(self, view_id: int | None = None, active_only: bool = False) -> List[dict]:
        from core.db.models import PublishedViewWebhook
        with self.get_session() as session:
            q = session.query(PublishedViewWebhook)
            if view_id is not None:
                q = q.filter(
                    (PublishedViewWebhook.view_id == view_id) |
                    (PublishedViewWebhook.view_id.is_(None))
                )
            if active_only:
                q = q.filter(PublishedViewWebhook.is_active)
            return [w.to_dict() for w in q.order_by(PublishedViewWebhook.id.desc()).all()]

    def get_pv_webhook(self, webhook_id: int) -> Optional[dict]:
        from core.db.models import PublishedViewWebhook
        with self.get_session() as session:
            wh = session.query(PublishedViewWebhook).filter(PublishedViewWebhook.id == webhook_id).first()
            return wh.to_dict() if wh else None

    def update_pv_webhook(self, webhook_id: int, **kwargs) -> Optional[dict]:
        from core.db.models import PublishedViewWebhook
        with self.get_session() as session:
            wh = session.query(PublishedViewWebhook).filter(PublishedViewWebhook.id == webhook_id).first()
            if not wh:
                return None
            for k, v in kwargs.items():
                if hasattr(wh, k):
                    setattr(wh, k, v)
            session.commit()
            return wh.to_dict()

    def delete_pv_webhook(self, webhook_id: int) -> bool:
        from core.db.models import PublishedViewWebhook
        with self.get_session() as session:
            wh = session.query(PublishedViewWebhook).filter(PublishedViewWebhook.id == webhook_id).first()
            if not wh:
                return False
            session.delete(wh)
            session.commit()
            return True

    def get_webhooks_for_event(self, event: str, view_id: int | None = None) -> List[dict]:
        """Get active webhooks that subscribe to a given event."""
        from core.db.models import PublishedViewWebhook
        with self.get_session() as session:
            q = session.query(PublishedViewWebhook).filter(PublishedViewWebhook.is_active)
            all_wh = q.all()
            results = []
            for wh in all_wh:
                events = wh.events or []
                if event not in events:
                    continue
                # Match: global (view_id=None) or specific view
                if wh.view_id is None or wh.view_id == view_id:
                    results.append(wh.to_dict())
            return results

    def record_webhook_trigger(self, webhook_id: int, status_code: int | None) -> None:
        from core.db.models import PublishedViewWebhook
        try:
            with self.get_session() as session:
                wh = session.query(PublishedViewWebhook).filter(PublishedViewWebhook.id == webhook_id).first()
                if wh:
                    wh.last_triggered_at = datetime.now(timezone.utc)
                    wh.last_status_code = status_code
                    session.commit()
        except Exception as exc:
            logger.warning("Failed to record webhook trigger: %s", exc)
