"""Mixin -- feed CONSUMER subscriptions and the notice ledger (2026-09-28).

The DAO half of docs/FEATURE_STRATEGY_2026_09_28.html #3 ("delivery
receipts + self-subscription for feed consumers").  Same pattern as
mixin_user_groups.py: plain CRUD over two fresh tables, no policy -- the
policy (who may subscribe, what "delivered" means) lives in
core/feed/consumer_receipts.py and core/feed/consumer_notices.py.

The one rule this layer enforces is the ledger's INSERT-FIRST contract:
``record_feed_consumer_notice`` returns None when a row for the same
(feed, date, event, subscriber, run key) already exists, and it is the
DATABASE's unique constraint that says so -- two pods ticking at once
cannot both get a row back.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from sqlalchemy.exc import IntegrityError

from core.db.models import (
    DownloadFile, FeedConsumerNotice, FeedConsumerSubscription,
)

logger = logging.getLogger(__name__)


def _coerce_date(value):
    from core.db.mixin_feeds import _coerce_business_date
    return _coerce_business_date(value)


class FeedConsumersMixin:
    """DB methods for feed_consumer_subscriptions + feed_consumer_notices,
    plus the one Download Centre lookup a receipt needs."""

    # ── subscriptions ────────────────────────────────────────────────────

    def get_feed_consumer_subscription(self, feed_config_id: int,
                                       username: str) -> Optional[dict]:
        with self.get_session(read_only=True) as session:
            row = session.query(FeedConsumerSubscription).filter(
                FeedConsumerSubscription.feed_config_id == int(feed_config_id),
                FeedConsumerSubscription.username == str(username),
            ).first()
            return row.to_dict() if row else None

    def upsert_feed_consumer_subscription(self, feed_config_id: int,
                                          username: str, events: List[str],
                                          email: Optional[str] = None) -> dict:
        """Replace (or create) ONE subscription per (feed, user)."""
        with self.get_session() as session:
            row = session.query(FeedConsumerSubscription).filter(
                FeedConsumerSubscription.feed_config_id == int(feed_config_id),
                FeedConsumerSubscription.username == str(username),
            ).first()
            if row is None:
                row = FeedConsumerSubscription(
                    feed_config_id=int(feed_config_id), username=str(username))
                session.add(row)
            row.events = [str(e) for e in (events or [])]
            row.email = (str(email).strip() or None) if email else None
            row.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def delete_feed_consumer_subscription(self, feed_config_id: int,
                                          username: str) -> bool:
        with self.get_session() as session:
            count = session.query(FeedConsumerSubscription).filter(
                FeedConsumerSubscription.feed_config_id == int(feed_config_id),
                FeedConsumerSubscription.username == str(username),
            ).delete()
            return bool(count)

    def list_feed_consumer_subscriptions(self, feed_config_id: Optional[int] = None,
                                         username: Optional[str] = None,
                                         event: Optional[str] = None
                                         ) -> List[dict]:
        """Subscriptions, optionally for one feed / one user / one event.
        The event filter is applied in Python (a JSON list column has no
        portable containment operator across SQLite and PostgreSQL)."""
        with self.get_session(read_only=True) as session:
            q = session.query(FeedConsumerSubscription)
            if feed_config_id is not None:
                q = q.filter(FeedConsumerSubscription.feed_config_id
                             == int(feed_config_id))
            if username is not None:
                q = q.filter(FeedConsumerSubscription.username == str(username))
            rows = [r.to_dict() for r in q.order_by(
                FeedConsumerSubscription.feed_config_id.asc(),
                FeedConsumerSubscription.username.asc()).all()]
        if event is not None:
            rows = [r for r in rows if str(event) in (r.get("events") or [])]
        return rows

    # ── the notice ledger ────────────────────────────────────────────────

    def record_feed_consumer_notice(self, *, feed_config_id: int, business_date: Any,
                                    event: str, username: str, run_key: str,
                                    feed_run_id: Optional[int] = None,
                                    channels: Optional[dict] = None
                                    ) -> Optional[dict]:
        """INSERT FIRST.  Returns the new row, or None when the ledger
        already holds one for this (feed, date, event, user, run key) --
        decided by the unique constraint, so it is race-safe across pods.
        Any other database failure raises: a notice whose ledger row
        could not be written must not be sent (it would be sent again on
        the next pass)."""
        bd = _coerce_date(business_date)
        with self.get_session() as session:
            row = FeedConsumerNotice(
                feed_config_id=int(feed_config_id), business_date=bd,
                event=str(event), username=str(username),
                run_key=str(run_key)[:40],
                feed_run_id=(int(feed_run_id) if feed_run_id is not None else None),
                channels=dict(channels or {}))
            session.add(row)
            try:
                session.flush()
            except IntegrityError:
                session.rollback()
                return None
            session.refresh(row)
            return row.to_dict()

    def update_feed_consumer_notice_channels(self, notice_id: int,
                                             channels: dict) -> None:
        with self.get_session() as session:
            row = session.query(FeedConsumerNotice).filter(
                FeedConsumerNotice.id == int(notice_id)).first()
            if row is not None:
                row.channels = dict(channels or {})

    def list_feed_consumer_notices(self, feed_config_id: Optional[int] = None,
                                   business_date: Any = None,
                                   username: Optional[str] = None,
                                   limit: int = 500) -> List[dict]:
        with self.get_session(read_only=True) as session:
            q = session.query(FeedConsumerNotice)
            if feed_config_id is not None:
                q = q.filter(FeedConsumerNotice.feed_config_id == int(feed_config_id))
            if business_date is not None:
                q = q.filter(FeedConsumerNotice.business_date
                             == _coerce_date(business_date))
            if username is not None:
                q = q.filter(FeedConsumerNotice.username == str(username))
            return [r.to_dict() for r in
                    q.order_by(FeedConsumerNotice.id.desc()).limit(int(limit)).all()]

    # ── the deliverable ──────────────────────────────────────────────────

    def find_feed_download_for_execution(self, feed_config_id: int,
                                         execution_id: str) -> Optional[dict]:
        """The Download Centre row the engine registered for ONE feed
        execution (core/feed/archive.py stamps source_kind='feed',
        source_id=<feed id>, execution_id=<the engine's exec id>).  None
        when nothing was registered -- a suppressed or failed delivery,
        or a run that predates FR-DEL-10."""
        if not execution_id:
            return None
        with self.get_session(read_only=True) as session:
            row = (session.query(DownloadFile)
                   .filter(DownloadFile.source_kind == "feed",
                           DownloadFile.source_id == str(feed_config_id),
                           DownloadFile.execution_id == str(execution_id))
                   .order_by(DownloadFile.id.desc())
                   .first())
            return row.to_dict() if row else None
