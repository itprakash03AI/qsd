"""Ping a pooled metadata-database connection only when it has been IDLE
(2026-10-03).

WHY
---
Every engine was built with ``pool_pre_ping=True``: SQLAlchemy sends a
``SELECT 1`` on EVERY checkout.  Measured live on the published-api pod
(2 workers, 50 paced consumers): 207 pings in one statement-log window, one
before every pooled checkout -- on a cached published-API call that is a
round trip per real statement, doubling the traffic to a Postgres that was
already the bottleneck (~100% CPU, ~55 req/s whatever the API worker count).

WHAT REPLACES IT
----------------
The same ping, on the same connections, with the same consequence -- but
only for a connection that sat in the pool longer than
``database.pool_ping_idle_seconds`` (default 5).  At load a connection is
checked back in and out again within milliseconds and is never pinged; after
a quiet spell, the first checkout of each connection is.  A failed ping
raises :class:`sqlalchemy.exc.InvalidatePoolError` -- exactly what
``pool_pre_ping`` raises -- so the pool discards EVERY connection older than
now and the checkout retries on a fresh one; the caller never sees it.

WHY THIS IS SAFE FOR A POSTGRES FAILOVER (the reasoning, not a hope)
--------------------------------------------------------------------
The two regimes differ for exactly one kind of connection: one that died
while it had been idle for LESS than the threshold, with nothing in this
process having noticed yet.

* Requests IN FLIGHT when the primary goes away fail under both regimes --
  a ping before the checkout does not help a statement already running.
* A failover (Patroni / RDS / an operator switchover) takes longer than five
  seconds end to end.  Either nothing touched the pool during it -- then
  every connection has been idle longer than the threshold and is pinged
  and replaced at its next checkout, exactly as pre-ping did -- or something
  did, and that statement failed with a disconnect.  SQLAlchemy answers a
  disconnect on a statement by invalidating the WHOLE pool
  (``Connection._handle_dbapi_exception`` -> ``pool._invalidate``: every
  connection checked out before that moment is replaced at its next
  checkout), so the stale connections are gone from then on.
* What remains is a sub-threshold blip with live traffic: at most the
  statements that race the first detected disconnect -- bounded by the
  connections checked out at that instant, once per event per process --
  fail and are answered as the database errors they are (the rate limiter
  falls back fail-closed, a read is a 5xx, the access-log batch is logged as
  lost).  Then the pool is clean.

That is the trade: ~one round trip per statement at load, against a handful
of extra failed requests per process in the narrowest failover window, all
of them loud.  ``database.pool_ping_idle_seconds = 0`` restores
``pool_pre_ping`` (a ping on every checkout) exactly.

Applied to the PostgreSQL primary and its read replicas.  SQLite keeps
``pool_pre_ping`` -- an in-process file has no round trip to save.
"""
from __future__ import annotations

import logging
import time
from typing import Any, Optional

from sqlalchemy import event
from sqlalchemy import exc as sa_exc

logger = logging.getLogger(__name__)

#: ``connection_record.info`` key: the monotonic time this DBAPI connection
#: last went back to the pool (or was opened).
LAST_RETURNED_KEY = "qs_last_returned_mono"

DEFAULT_IDLE_SECONDS = 5


def configured_idle_seconds() -> float:
    """``database.pool_ping_idle_seconds`` -- unreadable or malformed means
    the conservative answer, 0 (ping on every checkout)."""
    try:
        from core.config import get as _get
        v = _get("database", "pool_ping_idle_seconds", 5)
        return max(0.0, float(DEFAULT_IDLE_SECONDS if v is None else v))
    except Exception:
        return 0.0


def engine_kwargs(idle_seconds: float) -> dict:
    """The ``create_engine`` ping argument for this setting: SQLAlchemy's
    per-checkout pre-ping only when the idle gate is off."""
    return {"pool_pre_ping": idle_seconds <= 0}


def create_engine(url, idle_seconds: Optional[float] = None, *,
                  factory=None, **kwargs):
    """``create_engine`` with the idle-gated ping -- THE way a PostgreSQL
    metadata engine is built (``core/database.py``: the primary, its
    auto-create rebuild and every read replica).  Whatever ``pool_pre_ping``
    the caller passed is replaced by this setting's, and the listener is
    installed before anyone can check out.  ``factory`` is the engine
    constructor (``core.database`` passes its own module-level
    ``create_engine``); default SQLAlchemy's.

    FAIL-SAFE DIRECTION: if the listener cannot be installed, the engine is
    rebuilt with ``pool_pre_ping`` -- never left with no ping at all."""
    if factory is None:
        from sqlalchemy import create_engine as factory
    idle = configured_idle_seconds() if idle_seconds is None else max(0.0, float(idle_seconds))
    kwargs.pop("pool_pre_ping", None)
    engine = factory(url, **engine_kwargs(idle), **kwargs)
    if idle > 0:
        try:
            install(engine, idle)
        except Exception as exc:
            logger.warning("[db-pool] the idle-gated ping could not be installed "
                           "(%s: %s) -- this engine pings on EVERY checkout "
                           "(pool_pre_ping) instead", type(exc).__name__, exc)
            try:
                engine.dispose()
            except Exception as dispose_exc:
                logger.debug("[db-pool] dispose before rebuild: %s", dispose_exc)
            engine = factory(url, pool_pre_ping=True, **kwargs)
    return engine


def _ping(engine, dbapi_connection) -> bool:
    """The ping ``pool_pre_ping`` sends, through the same dialect hook:
    True = alive, False = disconnected; any other error propagates."""
    dialect = engine.dialect
    ping_w_event = getattr(dialect, "_do_ping_w_event", None)
    if ping_w_event is not None:
        return bool(ping_w_event(dbapi_connection))
    try:                                            # pragma: no cover - old SA
        return bool(dialect.do_ping(dbapi_connection))
    except dialect.loaded_dbapi.Error as err:       # pragma: no cover
        if dialect.is_disconnect(err, dbapi_connection, None):
            return False
        raise


def install(engine: Any, idle_seconds: float, *, clock=time.monotonic) -> bool:
    """Ping a connection on checkout only when it has been idle longer than
    ``idle_seconds``.  Returns False (and installs nothing) when the gate is
    off -- the engine must then have been built with ``pool_pre_ping``."""
    if idle_seconds <= 0:
        return False
    threshold = float(idle_seconds)

    @event.listens_for(engine, "connect")
    def _opened(dbapi_connection, record):
        record.info[LAST_RETURNED_KEY] = clock()

    @event.listens_for(engine, "checkin")
    def _returned(dbapi_connection, record):
        if record is not None:
            record.info[LAST_RETURNED_KEY] = clock()

    @event.listens_for(engine, "checkout")
    def _maybe_ping(dbapi_connection, record, proxy):
        last = record.info.get(LAST_RETURNED_KEY)
        if last is not None and clock() - last < threshold:
            return
        if not _ping(engine, dbapi_connection):
            logger.info("[db-pool] a connection idle for %s failed its ping -- "
                        "invalidating the pool (every older connection is "
                        "replaced) and retrying the checkout",
                        "an unknown time" if last is None
                        else f"{clock() - last:.1f}s")
            raise sa_exc.InvalidatePoolError()

    return True
