"""The Spark job's completion report as RECEIVED -- the callback's durable
CLAIM (2026-10-11, ``spark_job_reports``).

Found live (executions 2008/2009): the webhook did the WHOLE finalisation
-- Flow-B verification, the webhook-side delivery, the status -- inside the
request.  Under 29 overlapping runs that passed the job's 30 s read
timeout; the job logged ``CALLBACK failed ... Read timed out`` and did not
retry; the API never logged the execution at all; and the reconciler closed
the row UNVERIFIED.  A SUCCESS report, written and sent, was lost between
two processes.

Now the webhook does two cheap things inside the request and ACKs: it
verifies the signature and INSERTs the report here.  The row is the claim
-- ``execution_id`` is UNIQUE, so of two callbacks for one run (a retry
after a timeout) exactly one INSERT succeeds and only its request schedules
the finalisation; the other is answered "already received".  Finalisation
(``core.spark_k8s.completion.finalize_from_report`` -- the same
``finalize_success`` / ``finalize_failure`` every road uses) runs off the
request and stamps ``finalized_at``.  A claim that is never stamped (the API
pod died between ACK and finalisation) is finished by the reconciler from
THIS row -- one reader path, no second builder -- after
``webhook_grace_seconds``; a fresh unstamped claim tells the reconciler a
finalisation is in flight, so it defers.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from sqlalchemy.exc import IntegrityError

from core.db.models import SparkJobReport

logger = logging.getLogger(__name__)


def _row_to_dict(row: SparkJobReport) -> Dict[str, Any]:
    try:
        report = json.loads(row.report) if row.report else {}
    except ValueError:
        report = {}
    return {
        "id": row.id,
        "execution_id": row.execution_id,
        "state": row.state,
        "report": report,
        "received_via": row.received_via,
        "received_at": row.received_at,
        "finalized_at": row.finalized_at,
        "finalized_via": row.finalized_via,
        "finalize_error": row.finalize_error,
    }


class SparkJobReportsMixin:
    """``DatabaseManager`` methods for the job-report claim."""

    def claim_spark_job_report(self, execution_id: str, state: str,
                               report: Dict[str, Any], received_via: str = "webhook") -> bool:
        """INSERT the report; True when THIS caller holds the claim, False
        when a report for the execution was already received (the UNIQUE
        constraint decides, so two pods cannot both finalise)."""
        now = datetime.now(timezone.utc)
        with self.get_session() as session:
            session.add(SparkJobReport(
                execution_id=str(execution_id), state=str(state or ""),
                report=json.dumps(dict(report or {}), default=str),
                received_via=str(received_via or "webhook"), received_at=now))
            try:
                session.commit()
            except IntegrityError:
                session.rollback()
                return False
        return True

    def get_spark_job_report(self, execution_id: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            row = session.query(SparkJobReport).filter(
                SparkJobReport.execution_id == str(execution_id)).first()
            return _row_to_dict(row) if row else None

    def mark_spark_job_report_finalized(self, execution_id: str, via: str,
                                        error: Optional[str] = None) -> bool:
        with self.get_session() as session:
            row = session.query(SparkJobReport).filter(
                SparkJobReport.execution_id == str(execution_id)).first()
            if row is None:
                return False
            row.finalized_at = datetime.now(timezone.utc)
            row.finalized_via = str(via or "")
            row.finalize_error = (str(error)[:2000] if error else None)
            session.commit()
            return True

    def list_unfinalized_spark_job_reports(self, older_than_seconds: int = 0,
                                           limit: int = 200) -> List[Dict[str, Any]]:
        """Claims received but never stamped -- the API pod died between the
        ACK and the finalisation.  ``older_than_seconds`` keeps a claim whose
        finalisation is still in flight out of the list."""
        cutoff = datetime.now(timezone.utc)
        if older_than_seconds:
            from datetime import timedelta
            cutoff = cutoff - timedelta(seconds=int(older_than_seconds))
        with self.get_session(read_only=True) as session:
            q = session.query(SparkJobReport).filter(
                SparkJobReport.finalized_at.is_(None),
                SparkJobReport.received_at <= cutoff,
            ).order_by(SparkJobReport.received_at.asc()).limit(int(limit))
            return [_row_to_dict(r) for r in q.all()]
