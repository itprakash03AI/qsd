"""
Mixin — ETL Pipeline CRUD (Phase 127).
Extracted from DatabaseManager for modularity.
"""
from datetime import datetime, timezone, timedelta
from typing import Optional, List

from core.db.models import EtlPipelineConfig, EtlPipelineExecution


class EtlPipelinesMixin:
    """Database methods for ETL pipeline configs and executions."""

    # ── EtlPipelineConfig CRUD ─────────────────────────────────────────────

    def create_etl_pipeline(self, data: dict) -> dict:
        with self.get_session() as session:
            p = EtlPipelineConfig(**data)
            session.add(p)
            session.flush()
            session.refresh(p)
            return p.to_dict()

    def get_etl_pipeline(self, pipeline_id: int) -> Optional[dict]:
        with self.get_session(read_only=True) as session:
            p = session.get(EtlPipelineConfig, pipeline_id)
            return p.to_dict() if p else None

    def get_etl_pipeline_by_name(self, name: str) -> Optional[dict]:
        with self.get_session(read_only=True) as session:
            p = session.query(EtlPipelineConfig).filter(
                EtlPipelineConfig.name == name
            ).first()
            return p.to_dict() if p else None

    def list_etl_pipelines(self, is_active: bool = None,
                           execution_backend: str = None) -> List[dict]:
        with self.get_session(read_only=True) as session:
            q = session.query(EtlPipelineConfig)
            if is_active is not None:
                q = q.filter(EtlPipelineConfig.is_active == is_active)
            if execution_backend is not None:
                q = q.filter(EtlPipelineConfig.execution_backend == execution_backend)
            return [p.to_dict() for p in q.order_by(EtlPipelineConfig.name).all()]

    def update_etl_pipeline(self, pipeline_id: int, data: dict) -> Optional[dict]:
        with self.get_session() as session:
            p = session.get(EtlPipelineConfig, pipeline_id)
            if not p:
                return None
            for k, v in data.items():
                if hasattr(p, k):
                    setattr(p, k, v)
            p.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(p)
            return p.to_dict()

    def deactivate_etl_pipeline(self, pipeline_id: int) -> bool:
        with self.get_session() as session:
            p = session.get(EtlPipelineConfig, pipeline_id)
            if not p:
                return False
            p.is_active = False
            p.updated_at = datetime.now(timezone.utc)
            session.flush()
            return True

    def increment_etl_run_count(self, pipeline_id: int) -> None:
        # 2026-09-15: atomic in SQL (was a Python read-modify-write that
        # lost concurrent increments) -- see
        # mixin_datasets.increment_business_report_execution.
        try:
            from sqlalchemy import func as _sa_func, update as _sa_update
            with self.get_session() as session:
                session.execute(
                    _sa_update(EtlPipelineConfig)
                    .where(EtlPipelineConfig.id == pipeline_id)
                    .values(run_count=_sa_func.coalesce(EtlPipelineConfig.run_count, 0) + 1,
                            last_run_at=datetime.now(timezone.utc)))
        except Exception:
            pass  # non-critical

    # ── EtlPipelineExecution CRUD ──────────────────────────────────────────

    def create_etl_execution(self, data: dict) -> dict:
        with self.get_session() as session:
            e = EtlPipelineExecution(**data)
            session.add(e)
            session.flush()
            session.refresh(e)
            return e.to_dict()

    def get_etl_execution(self, exec_id: int) -> Optional[dict]:
        with self.get_session(read_only=True) as session:
            e = session.get(EtlPipelineExecution, exec_id)
            return e.to_dict() if e else None

    def get_etl_execution_by_exec_id(self, execution_id: str) -> Optional[dict]:
        with self.get_session(read_only=True) as session:
            e = session.query(EtlPipelineExecution).filter(
                EtlPipelineExecution.execution_id == execution_id
            ).first()
            return e.to_dict() if e else None

    # ── the scheduler tick's two questions (2026-10-08) ─────────────────
    # ``etl_engine._scheduler_tick`` has asked ``get_last_etl_execution``
    # and ``has_inflight_etl_execution`` since BF-589 (2026-05-29), and
    # neither existed: the tick's first call (``list_etl_pipelines(
    # active_only=True)`` -- the parameter is ``is_active``) raised, the
    # ``except`` logged at DEBUG and returned 0, and no scheduled pipeline
    # ever fired.  The fakes in the tick's tests carried all three.

    def get_last_etl_execution(self, pipeline_id: int) -> Optional[dict]:
        """The pipeline's newest execution row (by ``started_at``), or None
        when it never ran -- the cron base the scheduler counts from."""
        with self.get_session(read_only=True) as session:
            e = (session.query(EtlPipelineExecution)
                 .filter(EtlPipelineExecution.pipeline_id == pipeline_id)
                 .order_by(EtlPipelineExecution.started_at.desc(),
                           EtlPipelineExecution.id.desc())
                 .first())
            return e.to_dict() if e else None

    #: Execution states that mean "this pipeline is busy right now".
    INFLIGHT_ETL_STATES = ("pending", "running", "submitted", "claimed")

    def has_inflight_etl_execution(self, pipeline_id: int) -> bool:
        """Is one of the pipeline's executions still in flight?  The
        scheduler's idempotency gate: a due pipeline already running is not
        started again."""
        with self.get_session(read_only=True) as session:
            return session.query(EtlPipelineExecution.id).filter(
                EtlPipelineExecution.pipeline_id == pipeline_id,
                EtlPipelineExecution.status.in_(self.INFLIGHT_ETL_STATES),
            ).first() is not None

    def list_etl_executions(self, pipeline_id: int, limit: int = 50,
                            offset: int = 0, status: str = None) -> List[dict]:
        with self.get_session(read_only=True) as session:
            q = session.query(EtlPipelineExecution).filter(
                EtlPipelineExecution.pipeline_id == pipeline_id
            )
            if status is not None:
                q = q.filter(EtlPipelineExecution.status == status)
            rows = q.order_by(
                EtlPipelineExecution.started_at.desc()
            ).offset(offset).limit(limit).all()
            return [e.to_dict() for e in rows]

    def update_etl_execution(self, exec_id: int, data: dict) -> Optional[dict]:
        with self.get_session() as session:
            e = session.get(EtlPipelineExecution, exec_id)
            if not e:
                return None
            for k, v in data.items():
                if hasattr(e, k):
                    setattr(e, k, v)
            session.flush()
            session.refresh(e)
            return e.to_dict()

    def get_pending_etl_executions(self, limit: int = 10) -> List[dict]:
        """Get pending executions for the ETL worker to pick up."""
        with self.get_session(read_only=True) as session:
            rows = session.query(EtlPipelineExecution).filter(
                EtlPipelineExecution.status == "pending"
            ).order_by(EtlPipelineExecution.started_at.asc()).limit(limit).all()
            return [e.to_dict() for e in rows]

    def claim_etl_execution(self, execution_id: int, worker_id: str) -> Optional[dict]:
        """Atomically claim a pending execution by setting status='claimed'.

        Uses optimistic locking: UPDATE ... WHERE status='pending'.
        Returns the execution dict if claimed, None if already claimed by another worker.
        """
        with self.get_session() as session:
            updated = session.query(EtlPipelineExecution).filter(
                EtlPipelineExecution.id == execution_id,
                EtlPipelineExecution.status == "pending",
            ).update(
                {"status": "claimed", "claimed_by": worker_id,
                 "claimed_at": datetime.now(timezone.utc)},
                synchronize_session="fetch",
            )
            if updated == 0:
                return None  # Already claimed by another worker
            row = session.get(EtlPipelineExecution, execution_id)
            return row.to_dict() if row else None

    def reset_stale_claimed_executions(self, stale_minutes: int = 10) -> int:
        """Reset claimed executions older than stale_minutes back to pending.

        Prevents orphaned jobs when a worker crashes after claiming.
        """
        cutoff = datetime.now(timezone.utc) - timedelta(minutes=stale_minutes)
        with self.get_session() as session:
            count = session.query(EtlPipelineExecution).filter(
                EtlPipelineExecution.status == "claimed",
                EtlPipelineExecution.claimed_at < cutoff,
            ).update(
                {"status": "pending", "claimed_by": None, "claimed_at": None},
                synchronize_session="fetch",
            )
            return count

    def reset_stale_running_executions(self, stale_minutes: Optional[int] = None) -> int:
        """Mark executions stuck in running/submitted for >stale_minutes as failed.

        ONE unit, minutes (2026-10-08).  This took ``stale_hours`` while every
        caller of the DECLARED knob (``etl_pipelines.stale_execution_minutes``:
        the retention sweep, main.py's bootstrap + cleanup thread) passed
        ``stale_minutes=`` -- each call raised TypeError, caught as
        "non-fatal", so since 2026-08-19 no stale ETL execution was failed.
        ``None`` = the declared knob.
        """
        if stale_minutes is None:
            from core.config import etl_pipelines as _etl_cfg
            stale_minutes = int(_etl_cfg.stale_execution_minutes)
        cutoff = datetime.now(timezone.utc) - timedelta(minutes=int(stale_minutes))
        with self.get_session() as session:
            count = session.query(EtlPipelineExecution).filter(
                EtlPipelineExecution.status.in_(["running", "submitted"]),
                EtlPipelineExecution.started_at < cutoff,
            ).update(
                {"status": "failed",
                 "error_message": f"Execution timed out (stuck >{stale_minutes}m)",
                 "error_stage": "timeout",
                 "completed_at": datetime.now(timezone.utc)},
                synchronize_session="fetch",
            )
            return count

    def all_parents_completed(self, pipeline: dict) -> bool:
        """Check if ALL parent pipelines have their latest execution completed.

        Used for ``trigger_mode='all'`` multi-parent semantics (Phase 132-H).
        Returns True if every parent's most recent execution status is 'completed'.
        """
        parent_ids = pipeline.get("depends_on_pipeline_ids") or []
        # Backward compat: single parent
        single = pipeline.get("depends_on_pipeline_id")
        if single and single not in parent_ids:
            parent_ids = parent_ids + [single]
        if not parent_ids:
            return True  # No parents — always ready

        with self.get_session(read_only=True) as session:
            for pid in parent_ids:
                latest = session.query(EtlPipelineExecution).filter(
                    EtlPipelineExecution.pipeline_id == pid,
                ).order_by(EtlPipelineExecution.started_at.desc()).first()
                if not latest or latest.status != "completed":
                    return False
            return True

    def cleanup_old_etl_executions(self, retention_days: int = 90) -> int:
        """Delete ETL execution records older than retention period. Returns count deleted."""
        cutoff = datetime.now(timezone.utc) - timedelta(days=retention_days)
        with self.get_session() as session:
            count = session.query(EtlPipelineExecution).filter(
                EtlPipelineExecution.started_at < cutoff,
            ).delete()
            return count
