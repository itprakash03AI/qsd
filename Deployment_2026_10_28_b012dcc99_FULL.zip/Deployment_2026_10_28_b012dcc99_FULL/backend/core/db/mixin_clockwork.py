"""Mixin — Clockwork authoring plane CRUD (2026-09-10).

Same pattern as mixin_feeds.py.  Every method returns dicts.  The fire log
and step rows are NOT here — ``core/clockwork/fire_log.py`` reflects
Clockwork's own tables; this mixin owns only what QueryStudio writes.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from core.clockwork.core_bridge import CoreUnavailable
from core.clockwork.projection import Projection, project, template_ids_of
from core.db.models import (
    ClockworkAlert, ClockworkAlertNotification, ClockworkDeployment, ClockworkFireResolution, ClockworkJob,
    ClockworkJobHealth, ClockworkJobVersion, ClockworkManualRequest,
    ClockworkQueryTemplate, ClockworkSchemaMigration, ClockworkSetting, ClockworkTaskType,
    MANUAL_OUTSTANDING_STATUSES, MANUAL_RESOLVED,
)

logger = logging.getLogger(__name__)


class ClockworkVersionConflict(RuntimeError):
    """The save carried a stale ``expected_version``."""

    def __init__(self, expected: int, actual: int):
        super().__init__(f"expected version {expected}, row is at {actual}")
        self.expected = expected
        self.actual = actual


def outstanding_request_reason(outstanding: Optional[Dict[str, Any]]) -> str:
    """THE ONE SPELLING of "a request is already outstanding" -- served as
    the run-now verdict's reason, and as the 409 when the constraint
    refused the INSERT.  Two spellings of one rule is the drift this
    file's guards keep finding."""
    if outstanding:
        return (f"manual request #{outstanding.get('id')} ({outstanding.get('kind')}) is already "
                f"{outstanding.get('status')} for this job (since {outstanding.get('requested_at')}); "
                f"one request per job at a time -- wait for it to be claimed and finish, or for "
                f"the deployment to mark it REFUSED / EXPIRED")
    return ("a manual request is already outstanding for this job; one request per job at a "
            "time -- wait for it to be claimed and finish, or for the deployment to mark it "
            "REFUSED / EXPIRED")


class ClockworkRequestOutstanding(RuntimeError):
    """A manual request for this job is already PENDING or CLAIMED, so the
    arbiter index refused a second one.  ``outstanding`` is the row that
    holds the slot (read after the refusal; None only if it vanished in
    between, which still leaves the refusal correct: the INSERT lost)."""

    def __init__(self, job_id: int, outstanding: Optional[Dict[str, Any]]):
        self.job_id = int(job_id)
        self.outstanding = outstanding
        super().__init__(outstanding_request_reason(outstanding))


class ClockworkTemplateInUse(RuntimeError):
    """A query template that one or more jobs snapshot cannot be deleted:
    their projection would go NULL on the next re-projection and they would
    leave the dispatch view.  ``jobs`` names them (``{id, name, enabled}``).
    Retire the template (``is_active: false``) or unbind the jobs first."""

    def __init__(self, template_id: int, jobs: List[Dict[str, Any]]) -> None:
        names = ", ".join(f"{j['name']} (id {j['id']})" for j in jobs)
        super().__init__(f"query template {template_id} is used by {len(jobs)} job(s): {names}; "
                         f"retire it (is_active: false) or unbind the jobs before deleting")
        self.template_id = int(template_id)
        self.jobs = list(jobs)


class ClockworkNotDispatchable(RuntimeError):
    """An ENABLED job whose definition the dispatcher core would refuse.

    Raised by the row's ONE writer, inside its transaction, so the row is
    never stored enabled-but-undispatchable: an enabled row in
    ``clockwork_jobs`` is, by construction, a row the dispatch view can
    project.  ``problems`` are the core validator's words (or the
    translation's, for what the core cannot express); ``core_unavailable``
    says the refusal is "could not check", not "checked and wrong".
    """

    def __init__(self, problems: List[Dict[str, str]], *, core_unavailable: bool = False):
        super().__init__(f"{len(problems)} problem(s) stop this job from dispatching")
        self.problems = list(problems)
        self.core_unavailable = core_unavailable


def _now() -> datetime:
    return datetime.now(timezone.utc)


_DEFINITION_FIELDS = (
    "name", "description", "enabled", "tenant", "owner", "cron", "timezone",
    "calendar_id", "weekend_days", "misfire_grace_seconds", "idempotent",
    "authority", "connection_id", "steps", "access",
)


class ClockworkMixin:
    """DB methods for the clockwork_* tables QueryStudio owns."""

    # ── The projection, at the ONE writer ──────────────────────────────

    def clockwork_projection_calendar(self, cal_id: int) -> Optional[Dict[str, Any]]:
        """The bound calendar as DATA for the projection (plan v2 section 4:
        share the data, not the module): its weekend days, every holiday
        (explicit dates and recurring month-days), its horizon and its
        version.  The dispatcher walks this beside the job, so the preview
        and the fire resolve the same day.  An unreadable holiday list is
        ``None`` -- the projection refuses rather than projecting a calendar
        with a hole in it."""
        cal = self.get_feed_calendar(int(cal_id))
        if not cal:
            return None
        if cal.get("is_active") is False:
            return {"name": cal.get("name"), "inactive": True}
        try:
            holidays = self.list_feed_holidays(int(cal["id"]))
        except Exception as exc:                                    # noqa: BLE001
            logger.warning("[clockwork] holidays of calendar %s unreadable (%s); the "
                           "projection refuses rather than project a calendar with a "
                           "hole in it", cal_id, exc)
            return None
        explicit: List[str] = []
        recurring: List[str] = []
        for h in holidays:
            hd = h.get("holiday_date")
            if hd is None:
                continue
            text = hd if isinstance(hd, str) else hd.isoformat()
            text = text[:10]
            if h.get("recurring"):
                recurring.append(text[5:])
            else:
                explicit.append(text)
        horizon = cal.get("horizon_end")
        if horizon is not None and not isinstance(horizon, str):
            horizon = horizon.isoformat()
        return {"id": cal.get("id"), "name": cal.get("name"),
                "weekend_days": list(cal.get("weekend_days") or []),
                "holidays": sorted(set(explicit)),
                "recurring_holidays": sorted(set(recurring)),
                "horizon_end": horizon[:10] if horizon else None,
                "version": int(cal.get("version") or 1),
                "holiday_count": len(explicit) + len(recurring)}

    def project_clockwork_job(self, definition: Dict[str, Any]) -> Projection:
        """The dispatcher's view of a definition.  Raises ``CoreUnavailable``.
        The calendar and every query template a step names travel as DATA
        (both looked up here, at the ONE writer)."""
        return project(definition, calendar_lookup=self.clockwork_projection_calendar,
                       template_lookup=self.get_clockwork_template)

    def _apply_clockwork_projection(self, row: ClockworkJob) -> Projection:
        """Derive ``dispatch_definition`` from the row, in the row's own
        transaction.  An ENABLED row that cannot dispatch is REFUSED here,
        before it is stored -- so the dispatch view never lacks a row the
        authoring table says is enabled.  A DISABLED row stores NULL and
        the reasons travel back to the caller."""
        try:
            projection = self.project_clockwork_job(row.definition())
        except CoreUnavailable as exc:
            if row.enabled:
                raise ClockworkNotDispatchable(
                    [{"path": "dispatch", "message": exc.reason}], core_unavailable=True)
            logger.warning("[clockwork] job %r stored without a projection: %s",
                           row.name, exc.reason)
            projection = Projection(None, [{"path": "dispatch", "message": exc.reason}])
        if row.enabled and projection.definition is None:
            raise ClockworkNotDispatchable(projection.problems)
        row.dispatch_definition = projection.definition
        return projection

    #: The alert kind a job carries while its bound calendar cannot be
    #: projected any more (edited to inactive, weekend days removed, deleted).
    CALENDAR_UNPROJECTABLE = "calendar_unprojectable"

    def reproject_clockwork_jobs_for_calendar(self, cal_id: int, *,
                                              reason: str = "calendar changed") -> Dict[str, Any]:
        """Re-derive ``dispatch_definition`` for EVERY job bound to this
        calendar.  Called by the feed calendar's mutators after their
        commit (``mixin_feeds._calendar_changed``).

        2026-09-10 audit: the calendar was inlined into the projection at
        job SAVE only, so a holiday added afterwards reached ``/preview``
        (live) and never the dispatcher (snapshot) -- the preview and the
        fire disagreed on the day.  A decision made twice.

        NEVER RAISES for a job, and never touches ``enabled``.  An ENABLED
        job whose calendar can no longer be projected stores NULL -- the
        dispatch view drops it, which is the fail-closed direction -- and
        carries a ``calendar_unprojectable`` alert naming the problems, so
        why-not-run answers REFUSED with that row as evidence.  When a later
        edit makes it projectable again the alert is acknowledged by the
        system.  Returns what happened, per job.
        """
        with self.get_session(read_only=True) as session:
            ids = [r.id for r in (session.query(ClockworkJob)
                                  .filter(ClockworkJob.calendar_id == int(cal_id))
                                  .order_by(ClockworkJob.id).all())]
        out = self._reproject_clockwork_jobs(ids, kind=self.CALENDAR_UNPROJECTABLE, noun="calendar",
                                             subject=f"calendar {cal_id}", reason=reason)
        out["calendar_id"] = int(cal_id)
        return out

    #: The alert kind a job carries while a query template it snapshots
    #: cannot be projected any more (retired, or edited into a statement
    #: the rules refuse).  The template twin of ``CALENDAR_UNPROJECTABLE``.
    TEMPLATE_UNPROJECTABLE = "template_unprojectable"

    def clockwork_jobs_using_template(self, template_id: int) -> List[Dict[str, Any]]:
        """Every job with a ``sql_scalar`` step naming this template --
        ``{id, name, enabled}`` each.  The reference lives inside the
        steps JSON, so it is read in Python rather than by a column."""
        with self.get_session(read_only=True) as session:
            rows = session.query(ClockworkJob).order_by(ClockworkJob.id).all()
            return [{"id": r.id, "name": r.name, "enabled": bool(r.enabled)}
                    for r in rows if int(template_id) in template_ids_of(r.definition())]

    def reproject_clockwork_jobs_for_template(self, template_id: int, *,
                                              reason: str = "template changed") -> Dict[str, Any]:
        """Re-derive ``dispatch_definition`` for EVERY job snapshotting this
        template -- the calendar rule, applied to the other thing a
        projection inlines.  Called by ``update_clockwork_template`` after
        its commit; never raises for a job, never touches ``enabled``."""
        ids = [j["id"] for j in self.clockwork_jobs_using_template(int(template_id))]
        out = self._reproject_clockwork_jobs(ids, kind=self.TEMPLATE_UNPROJECTABLE, noun="template",
                                             subject=f"query template {template_id}", reason=reason)
        out["template_id"] = int(template_id)
        return out

    def _reproject_clockwork_jobs(self, job_ids: List[int], *, kind: str, noun: str, subject: str,
                                  reason: str) -> Dict[str, Any]:
        """ONE re-projection for whatever a projection snapshots (a
        calendar, a template).  An ENABLED job that no longer projects
        stores NULL (out of the view, fail-closed) and carries an alert of
        ``kind``; a job that projects again has that alert acknowledged by
        the system."""
        out: Dict[str, Any] = {"reason": reason, "reprojected": [], "undispatchable": []}
        if not job_ids:
            return out
        with self.get_session() as session:
            rows = (session.query(ClockworkJob)
                    .filter(ClockworkJob.id.in_(sorted(set(int(i) for i in job_ids))))
                    .order_by(ClockworkJob.id).all())
            for row in rows:
                try:
                    projection = self.project_clockwork_job(row.definition())
                except CoreUnavailable as exc:
                    projection = Projection(None, [{"path": "dispatch", "message": exc.reason}])
                row.dispatch_definition = projection.definition
                if projection.definition is None and row.enabled:
                    out["undispatchable"].append({"job_id": row.id, "name": row.name,
                                                  "problems": list(projection.problems)})
                else:
                    out["reprojected"].append(row.id)
            session.flush()
        recovered = set(out["reprojected"])
        for u in out["undispatchable"]:
            words = "; ".join(p["message"] for p in u["problems"]) or "no reason given"
            logger.error("[clockwork] job %r (id %s) is ENABLED but its %s can no longer "
                         "be projected after %s: %s -- it is out of the dispatch view until fixed",
                         u["name"], u["job_id"], subject, reason, words)
            self.raise_clockwork_alert(
                kind=kind, job_id=int(u["job_id"]),
                message=(f"{subject} ({reason}) can no longer be projected for this "
                         f"enabled job, so it is out of the dispatch view: {words}"))
        if recovered:
            with self.get_session() as session:
                stale = (session.query(ClockworkAlert)
                         .filter(ClockworkAlert.kind == kind,
                                 ClockworkAlert.job_id.in_(sorted(recovered)),
                                 ClockworkAlert.acknowledged_at == None)  # noqa: E711
                         .all())
                for a in stale:
                    a.acknowledged_by = f"system: {noun} projectable again"
                    a.acknowledged_at = _now()
                    self._record_ack_on_ledger(session, a)
                session.flush()
        return out

    # ── Jobs ───────────────────────────────────────────────────────────

    def create_clockwork_job(self, definition: Dict[str, Any], *, created_by: str,
                             owner_group_id: Optional[int] = None,
                             note: Optional[str] = None) -> Dict[str, Any]:
        with self.get_session() as session:
            row = ClockworkJob(created_by=created_by, updated_by=created_by,
                               owner_group_id=owner_group_id, version=1)
            for k in _DEFINITION_FIELDS:
                if k in definition:
                    setattr(row, k, definition[k])
            if not row.tenant:
                row.tenant = "querystudio"
            projection = self._apply_clockwork_projection(row)
            session.add(row)
            session.flush()
            session.add(ClockworkJobVersion(job_id=row.id, version=1, definition=row.definition(),
                                            note=note or "created", created_by=created_by))
            session.flush()
            session.refresh(row)
            out = row.to_dict()
            out["dispatch_problems"] = projection.problems
            out["dispatch_warnings"] = projection.warnings
            return out

    def get_clockwork_job(self, job_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            row = session.query(ClockworkJob).filter(ClockworkJob.id == int(job_id)).first()
            return row.to_dict() if row else None

    def get_clockwork_job_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            row = session.query(ClockworkJob).filter(ClockworkJob.name == name).first()
            return row.to_dict() if row else None

    def list_clockwork_jobs(self, *, enabled: Optional[bool] = None,
                            tenant: Optional[str] = None) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(ClockworkJob)
            if enabled is not None:
                q = q.filter(ClockworkJob.enabled == enabled)
            if tenant:
                q = q.filter(ClockworkJob.tenant == tenant)
            return [r.to_dict() for r in q.order_by(ClockworkJob.name).all()]

    def update_clockwork_job(self, job_id: int, definition: Dict[str, Any], *,
                             expected_version: int, updated_by: str,
                             note: Optional[str] = None,
                             owner_group_id: Optional[int] = ...) -> Optional[Dict[str, Any]]:
        """Save = one version snapshot.  Optimistic concurrency on
        ``expected_version``; a mismatch raises :class:`ClockworkVersionConflict`.
        The version bump is a conditional UPDATE, so two saves racing on the
        same expected version cannot both win."""
        with self.get_session() as session:
            row = session.query(ClockworkJob).filter(ClockworkJob.id == int(job_id)).first()
            if not row:
                return None
            if int(row.version) != int(expected_version):
                raise ClockworkVersionConflict(int(expected_version), int(row.version))
            new_version = int(row.version) + 1
            bumped = (session.query(ClockworkJob)
                      .filter(ClockworkJob.id == int(job_id),
                              ClockworkJob.version == int(expected_version))
                      .update({ClockworkJob.version: new_version},
                              synchronize_session=False))
            if bumped != 1:
                session.rollback()
                raise ClockworkVersionConflict(int(expected_version), int(row.version) + 1)
            session.refresh(row)
            was_enabled = bool(row.enabled)
            for k in _DEFINITION_FIELDS:
                if k in definition:
                    setattr(row, k, definition[k])
            if owner_group_id is not ...:
                row.owner_group_id = owner_group_id
            row.updated_by = updated_by
            row.updated_at = _now()
            # The projection is re-derived on EVERY save, from the row as it
            # will be stored -- a version bump that left a stale projection
            # behind would dispatch an older definition than the UI shows.
            projection = self._apply_clockwork_projection(row)
            if was_enabled and not row.enabled:
                # Disabling retires the job's PENDING requests IN THIS
                # transaction: the dispatch view no longer carries them (it
                # joins an enabled job), and a request nobody will ever
                # claim must say so rather than sit PENDING.
                self._retire_pending_requests(
                    session, row.id,
                    f"job disabled by {updated_by} at version {new_version}; a request for a "
                    f"disabled job is not dispatched (enable the job and request again)")
            session.flush()
            session.add(ClockworkJobVersion(job_id=row.id, version=new_version,
                                            definition=row.definition(),
                                            note=note or "saved", created_by=updated_by))
            session.flush()
            session.refresh(row)
            out = row.to_dict()
            out["dispatch_problems"] = projection.problems
            out["dispatch_warnings"] = projection.warnings
            return out

    @staticmethod
    def _retire_pending_requests(session, job_id: int, detail: str) -> int:
        """PENDING -> REFUSED for every request of this job, with the reason
        in ``detail`` -- the same terminal shape the dispatcher writes for a
        request it will not run (contract section 3).  Returns the count."""
        return int(session.query(ClockworkManualRequest)
                   .filter(ClockworkManualRequest.job_id == int(job_id),
                           ClockworkManualRequest.status == "PENDING")
                   .update({ClockworkManualRequest.status: "REFUSED",
                            ClockworkManualRequest.resolved_at: _now(),
                            ClockworkManualRequest.detail: detail[:1000]},
                           synchronize_session=False))

    def delete_clockwork_job(self, job_id: int) -> int:
        with self.get_session() as session:
            n = session.query(ClockworkJob).filter(ClockworkJob.id == int(job_id)).delete()
            if n:
                self._retire_pending_requests(
                    session, int(job_id),
                    "job deleted; a request for a deleted job is not dispatched")
                session.query(ClockworkJobVersion).filter(
                    ClockworkJobVersion.job_id == int(job_id)).delete()
                session.query(ClockworkJobHealth).filter(
                    ClockworkJobHealth.job_id == int(job_id)).delete()
                # AND THE ALERTS, AND THEIR LEDGER.  Until 2026-09-11 they
                # were left behind, which is two defects in one: an alert
                # row pointing at a job that no longer exists is delivered
                # to the deployment FALLBACK for ever ("job N does not
                # exist"), and -- because the notifier delivers once per
                # alert IDENTITY and the identity is (job, deployment,
                # kind) -- deleting and recreating a job minted a fresh
                # identity, so delete-and-recreate was an unbounded way to
                # make the organisation send another email.
                ids = [int(r[0]) for r in session.query(ClockworkAlert.id).filter(
                    ClockworkAlert.job_id == int(job_id)).all()]
                if ids:
                    session.query(ClockworkAlertNotification).filter(
                        ClockworkAlertNotification.alert_id.in_(ids)).delete(
                            synchronize_session=False)
                session.query(ClockworkAlert).filter(
                    ClockworkAlert.job_id == int(job_id)).delete(
                        synchronize_session=False)
            return int(n)

    def list_clockwork_job_versions(self, job_id: int) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = (session.query(ClockworkJobVersion)
                    .filter(ClockworkJobVersion.job_id == int(job_id))
                    .order_by(ClockworkJobVersion.version.desc()).all())
            return [r.to_dict() for r in rows]

    # ── Query templates ────────────────────────────────────────────────

    def create_clockwork_template(self, data: Dict[str, Any], *, created_by: str) -> Dict[str, Any]:
        with self.get_session() as session:
            row = ClockworkQueryTemplate(created_by=created_by, updated_by=created_by, **data)
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def get_clockwork_template(self, template_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            row = session.query(ClockworkQueryTemplate).filter(
                ClockworkQueryTemplate.id == int(template_id)).first()
            return row.to_dict() if row else None

    def list_clockwork_templates(self, *, active_only: bool = False) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(ClockworkQueryTemplate)
            if active_only:
                q = q.filter(ClockworkQueryTemplate.is_active == True)  # noqa: E712
            return [r.to_dict() for r in q.order_by(ClockworkQueryTemplate.name).all()]

    def update_clockwork_template(self, template_id: int, data: Dict[str, Any], *,
                                  updated_by: str) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(ClockworkQueryTemplate).filter(
                ClockworkQueryTemplate.id == int(template_id)).first()
            if not row:
                return None
            if "sql_text" in data and data["sql_text"] != row.sql_text:
                row.version = int(row.version or 1) + 1
            for k, v in data.items():
                if hasattr(row, k) and k not in ("id", "version", "created_by", "created_at"):
                    setattr(row, k, v)
            row.updated_by = updated_by
            row.updated_at = _now()
            session.flush()
            session.refresh(row)
            out = row.to_dict()
        # AFTER the commit: every job snapshotting this template is
        # re-projected -- the calendar's rule (``mixin_feeds._calendar_changed``),
        # because a projection inlines the template's SQL.  Never raises:
        # the edit has happened and must not look like it has not; a job
        # that no longer projects is alerted by the re-projector.
        what = "template retired" if data.get("is_active") is False else "template updated"
        try:
            out["reprojection"] = self.reproject_clockwork_jobs_for_template(int(template_id), reason=what)
        except Exception as exc:                                        # noqa: BLE001
            logger.error("[clockwork] %s %s, but the re-projection of the jobs using it failed "
                         "(%s): they may still carry the OLD statement", what, template_id, exc)
            out["reprojection"] = {"template_id": int(template_id), "reason": what,
                                   "error": str(exc), "reprojected": [], "undispatchable": []}
        return out

    def delete_clockwork_template(self, template_id: int) -> int:
        """Refuses (``ClockworkTemplateInUse``) while any job snapshots it;
        the API renders that as 409 naming the jobs."""
        users = self.clockwork_jobs_using_template(int(template_id))
        if users:
            raise ClockworkTemplateInUse(int(template_id), users)
        with self.get_session() as session:
            return int(session.query(ClockworkQueryTemplate).filter(
                ClockworkQueryTemplate.id == int(template_id)).delete())

    # ── Catalogue + deployments (written by Clockwork; read here) ──────

    def list_clockwork_task_types(self) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [r.to_dict() for r in session.query(ClockworkTaskType)
                    .order_by(ClockworkTaskType.task_type, ClockworkTaskType.deployment_id).all()]

    def upsert_clockwork_task_type(self, deployment_id: str, task_type: str, *,
                                   routable: bool, reason: Optional[str] = None,
                                   config_schema: Optional[dict] = None,
                                   outputs: Optional[list] = None) -> Dict[str, Any]:
        """The deployment-side write, exposed so a test (or an in-process
        deployment) can report through the same seam Clockwork will."""
        with self.get_session() as session:
            row = session.query(ClockworkTaskType).filter(
                ClockworkTaskType.deployment_id == deployment_id,
                ClockworkTaskType.task_type == task_type).first()
            if row is None:
                row = ClockworkTaskType(deployment_id=deployment_id, task_type=task_type)
                session.add(row)
            row.routable = bool(routable)
            row.reason = reason
            row.config_schema = config_schema
            row.outputs = outputs
            row.reported_at = _now()
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def list_clockwork_deployments(self) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [r.to_dict() for r in session.query(ClockworkDeployment)
                    .order_by(ClockworkDeployment.deployment_id).all()]

    def get_clockwork_deployment(self, deployment_id: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            row = session.query(ClockworkDeployment).filter(
                ClockworkDeployment.deployment_id == deployment_id).first()
            return row.to_dict() if row else None

    def upsert_clockwork_deployment(self, deployment_id: str, *, environment: Optional[str] = None,
                                    version: Optional[str] = None,
                                    last_tick_at: Optional[datetime] = None,
                                    detail: Optional[dict] = None) -> Dict[str, Any]:
        with self.get_session() as session:
            row = session.query(ClockworkDeployment).filter(
                ClockworkDeployment.deployment_id == deployment_id).first()
            if row is None:
                row = ClockworkDeployment(deployment_id=deployment_id, started_at=_now())
                session.add(row)
            if environment is not None:
                row.environment = environment
            if version is not None:
                row.version = version
            if last_tick_at is not None:
                row.last_tick_at = last_tick_at
            if detail is not None:
                row.detail = detail
            session.flush()
            session.refresh(row)
            return row.to_dict()

    # ── Settings ───────────────────────────────────────────────────────

    def list_clockwork_settings(self) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            return [r.to_dict() for r in session.query(ClockworkSetting)
                    .order_by(ClockworkSetting.key).all()]

    def set_clockwork_setting(self, key: str, value: Any, *, updated_by: str,
                              description: Optional[str] = None) -> Dict[str, Any]:
        with self.get_session() as session:
            row = session.query(ClockworkSetting).filter(ClockworkSetting.key == key).first()
            if row is None:
                row = ClockworkSetting(key=key)
                session.add(row)
            row.value = value
            if description is not None:
                row.description = description
            row.updated_by = updated_by
            row.updated_at = _now()
            session.flush()
            session.refresh(row)
            return row.to_dict()

    # ── Manual requests ────────────────────────────────────────────────

    def create_clockwork_manual_request(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Writes the PENDING row -- or raises ``ClockworkRequestOutstanding``
        when the arbiter index (``models.MANUAL_ARBITER_INDEX``) refuses it
        because this job already has a PENDING or CLAIMED request.  The
        INDEX decides, so two concurrent requests cannot both pass a check
        that ran before either wrote; this method only names the winner."""
        from sqlalchemy.exc import IntegrityError
        try:
            with self.get_session() as session:
                row = ClockworkManualRequest(**data)
                session.add(row)
                session.flush()
                session.refresh(row)
                return row.to_dict()
        except IntegrityError as exc:
            job_id = int(data.get("job_id") or 0)
            outstanding = self.outstanding_clockwork_manual_request(job_id)
            if outstanding is None:
                raise                          # not the arbiter: fire_key UNIQUE, NOT NULL, ...
            raise ClockworkRequestOutstanding(job_id, outstanding) from exc

    def outstanding_clockwork_manual_request(self, job_id: int) -> Optional[Dict[str, Any]]:
        """The request holding this job's slot (PENDING or CLAIMED,
        ``models.MANUAL_OUTSTANDING_STATUSES``), oldest first, or None."""
        return self.outstanding_clockwork_manual_requests([int(job_id)]).get(int(job_id))

    def outstanding_clockwork_manual_requests(self, job_ids: List[int]) -> Dict[int, Dict[str, Any]]:
        """``{job_id: request}`` for every listed job that has an outstanding
        request -- ONE query for the list, the oldest row per job (the
        index allows exactly one, so "oldest" is only defensive)."""
        ids = sorted({int(j) for j in job_ids})
        if not ids:
            return {}
        out: Dict[int, Dict[str, Any]] = {}
        with self.get_session(read_only=True) as session:
            rows = (session.query(ClockworkManualRequest)
                    .filter(ClockworkManualRequest.job_id.in_(ids),
                            ClockworkManualRequest.status.in_(MANUAL_OUTSTANDING_STATUSES))
                    .order_by(ClockworkManualRequest.id.asc()).all())
            for r in rows:
                out.setdefault(int(r.job_id), r.to_dict())
        return out

    def list_clockwork_manual_requests(self, *, job_id: Optional[int] = None,
                                       status: Optional[str] = None,
                                       limit: int = 100) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(ClockworkManualRequest)
            if job_id is not None:
                q = q.filter(ClockworkManualRequest.job_id == int(job_id))
            if status:
                q = q.filter(ClockworkManualRequest.status == status)
            return [r.to_dict() for r in
                    q.order_by(ClockworkManualRequest.requested_at.desc()).limit(int(limit)).all()]

    def get_clockwork_manual_request(self, request_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            row = session.query(ClockworkManualRequest).filter(
                ClockworkManualRequest.id == int(request_id)).first()
            return row.to_dict() if row else None

    # ── Alerts ─────────────────────────────────────────────────────────

    def list_clockwork_alerts(self, *, job_id: Optional[int] = None,
                              unacknowledged_only: bool = False,
                              include_global: bool = True) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(ClockworkAlert)
            if job_id is not None:
                if include_global:
                    q = q.filter((ClockworkAlert.job_id == int(job_id)) | (ClockworkAlert.job_id == None))  # noqa: E711
                else:
                    q = q.filter(ClockworkAlert.job_id == int(job_id))
            if unacknowledged_only:
                q = q.filter(ClockworkAlert.acknowledged_at == None)  # noqa: E711
            return [r.to_dict() for r in q.order_by(ClockworkAlert.last_seen_at.desc()).all()]

    def raise_clockwork_alert(self, *, kind: str, message: str, job_id: Optional[int] = None,
                              deployment_id: Optional[str] = None) -> Dict[str, Any]:
        """Once per (job, deployment, kind); repeats bump ``count``."""
        with self.get_session() as session:
            row = session.query(ClockworkAlert).filter(
                ClockworkAlert.job_id == job_id,
                ClockworkAlert.deployment_id == deployment_id,
                ClockworkAlert.kind == kind).first()
            if row is None:
                row = ClockworkAlert(job_id=job_id, deployment_id=deployment_id, kind=kind,
                                     message=message, count=1)
                session.add(row)
            else:
                row.count = int(row.count or 0) + 1
                row.message = message
                row.last_seen_at = _now()
                row.acknowledged_at = None
                row.acknowledged_by = None
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def acknowledge_clockwork_alert(self, alert_id: int, *, by: str) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            row = session.query(ClockworkAlert).filter(ClockworkAlert.id == int(alert_id)).first()
            if not row:
                return None
            row.acknowledged_by = by
            row.acknowledged_at = _now()
            self._record_ack_on_ledger(session, row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    @staticmethod
    def _record_ack_on_ledger(session, alert: ClockworkAlert) -> None:
        """2026-09-11 audit (item 5).  The notifier used to learn of an
        acknowledgement only if a PASS observed ``acknowledged_at`` set --
        and the publisher clears it on every recurrence, so for a refusal
        recurring every tick the ack was usually gone before the next poll
        and the documented "re-page after a human acks and it recurs" held
        only when the poll landed in between.  The ack is now written onto
        the delivery ledger HERE, in the ack's own transaction, with the
        count it covered: the notifier's transition rule
        (``alert_acknowledged and count > alert_count``) then fires on the
        recurrence whatever the poll timing.  Every ack path calls this:
        the human's route and the system's (a projection recovered)."""
        from core.clockwork.notifier import severity_of
        led = (session.query(ClockworkAlertNotification)
               .filter(ClockworkAlertNotification.alert_id == int(alert.id)).first())
        if led is None:
            led = ClockworkAlertNotification(
                alert_id=int(alert.id), job_id=alert.job_id, kind=str(alert.kind or ""),
                severity=severity_of(alert.kind), status="acknowledged")
            session.add(led)
        led.alert_acknowledged = True
        led.alert_count = int(alert.count or 0)
        led.updated_at = _now()

    # ── Alert notifications (the delivery ledger) ───────────────────────

    def list_clockwork_alert_notifications(self, *, alert_ids: Optional[List[int]] = None
                                           ) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(ClockworkAlertNotification)
            if alert_ids is not None:
                if not alert_ids:
                    return []
                q = q.filter(ClockworkAlertNotification.alert_id.in_([int(x) for x in alert_ids]))
            return [r.to_dict() for r in q.order_by(ClockworkAlertNotification.alert_id).all()]

    def claim_clockwork_alert_notification(self, alert_id: int, *,
                                           expect_status: Optional[str] = None,
                                           expect_attempts: Optional[int] = None,
                                           **fields: Any) -> bool:
        """CLAIM the delivery of one alert: True = this caller delivers, False
        = another pass already holds (or finished) it.

        2026-10-10.  The notifier read the ledger, saw no row, delivered,
        THEN wrote the row (select-then-insert): two passes in the same
        window -- the scheduler pod's APScheduler job beside a hybrid pod's,
        or a run-now beside the tick -- both saw "no row" and both paged.
        Same shape, same fix as the close-out digest (commit 52583802):

        * first sighting (``expect_status`` None): INSERT the row (status
          ``sending``, the given fields); ``alert_id`` is UNIQUE, so the
          second insert is a uniqueness violation = already claimed.
        * a retry / re-raise (``expect_status`` given): ONE conditional
          UPDATE gated on the row still reading what this pass read
          (``status`` and ``attempts``); rowcount 1 = this pass owns the
          attempt, 0 = another pass moved it first.

        Never touches ``clockwork_alerts``.  A NOT NULL / FK violation is
        not a duplicate and is raised, never read as "claimed".
        """
        from sqlalchemy.exc import IntegrityError
        from core.db_errors import is_unique_violation
        now = _now()
        if expect_status is None:
            try:
                with self.get_session() as session:
                    row = ClockworkAlertNotification(alert_id=int(alert_id), **fields)
                    row.updated_at = now
                    session.add(row)
                    session.flush()
                return True
            except IntegrityError as exc:
                if is_unique_violation(exc):
                    return False
                raise
        with self.get_session() as session:
            q = session.query(ClockworkAlertNotification).filter(
                ClockworkAlertNotification.alert_id == int(alert_id),
                ClockworkAlertNotification.status == str(expect_status))
            if expect_attempts is not None:
                q = q.filter(ClockworkAlertNotification.attempts == int(expect_attempts))
            count = q.update({**fields, "updated_at": now}, synchronize_session=False)
            return int(count or 0) == 1

    def upsert_clockwork_alert_notification(self, alert_id: int, **fields: Any) -> Dict[str, Any]:
        """One ledger row per alert id; ``fields`` are the columns to set.
        Never touches ``clockwork_alerts``."""
        with self.get_session() as session:
            row = session.query(ClockworkAlertNotification).filter(
                ClockworkAlertNotification.alert_id == int(alert_id)).first()
            if row is None:
                row = ClockworkAlertNotification(alert_id=int(alert_id))
                session.add(row)
            for k, v in fields.items():
                setattr(row, k, v)
            row.updated_at = _now()
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def clockwork_alert_notifier_summary(self) -> Dict[str, Any]:
        """Counts by ledger status and the latest delivery, for ``/health``."""
        with self.get_session(read_only=True) as session:
            rows = session.query(ClockworkAlertNotification).all()
            by_status: Dict[str, int] = {}
            latest: Optional[datetime] = None
            for r in rows:
                by_status[r.status] = by_status.get(r.status, 0) + 1
                if r.notified_at and (latest is None or r.notified_at > latest):
                    latest = r.notified_at
            return {"ledger_rows": len(rows), "by_status": by_status,
                    "last_notified_at": latest.isoformat() if latest else None}

    # ── Health ─────────────────────────────────────────────────────────

    def list_clockwork_job_health(self, job_id: Optional[int] = None) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(ClockworkJobHealth)
            if job_id is not None:
                q = q.filter(ClockworkJobHealth.job_id == int(job_id))
            return [r.to_dict() for r in q.order_by(ClockworkJobHealth.job_id).all()]

    def upsert_clockwork_job_health(self, job_id: int, deployment_id: str, *, state: str,
                                    reason: Optional[str] = None,
                                    checked_at: Optional[datetime] = None) -> Dict[str, Any]:
        with self.get_session() as session:
            row = session.query(ClockworkJobHealth).filter(
                ClockworkJobHealth.job_id == int(job_id),
                ClockworkJobHealth.deployment_id == deployment_id).first()
            if row is None:
                row = ClockworkJobHealth(job_id=int(job_id), deployment_id=deployment_id)
                session.add(row)
            row.state = state
            row.reason = reason
            row.checked_at = checked_at or _now()
            session.flush()
            session.refresh(row)
            return row.to_dict()

    # ── Fire resolutions ───────────────────────────────────────────────

    def record_clockwork_fire_resolution(self, fire_key: str, *, job_id: Optional[int],
                                         verdict: str, note: str, resolved_by: str,
                                         retire_claimed_request: bool = False) -> Dict[str, Any]:
        """Writes (or rewrites) the resolution beside the fire.  With
        ``retire_claimed_request`` -- the route passes it for a fire that is
        still CLAIMED -- the manual request that owns this fire key, if it
        is CLAIMED, moves to ``MANUAL_RESOLVED`` IN THE SAME TRANSACTION
        (2026-09-11, audit remainder item 1): a pod that died mid-fire left
        it holding the job's run-now slot for ever, and only a human's
        assertion that the occurrence is finished may free it.  The
        returned dict carries ``retired_request`` (the request as it now
        is, or None: a scheduled fire owns no request)."""
        with self.get_session() as session:
            row = session.query(ClockworkFireResolution).filter(
                ClockworkFireResolution.fire_key == fire_key).first()
            if row is None:
                row = ClockworkFireResolution(fire_key=fire_key)
                session.add(row)
            row.job_id = job_id
            row.verdict = verdict
            row.note = note
            row.resolved_by = resolved_by
            row.resolved_at = _now()
            retired = None
            if retire_claimed_request:
                req = (session.query(ClockworkManualRequest)
                       .filter(ClockworkManualRequest.fire_key == fire_key,
                               ClockworkManualRequest.status == "CLAIMED").first())
                if req is not None:
                    req.status = MANUAL_RESOLVED
                    req.resolved_at = row.resolved_at
                    req.detail = (f"retired by a resolution ({verdict}) recorded by "
                                  f"{resolved_by} on its fire: {note}")[:1000]
                    session.flush()
                    session.refresh(req)
                    retired = req.to_dict()
            session.flush()
            session.refresh(row)
            out = row.to_dict()
            out["retired_request"] = retired
            return out

    def get_clockwork_fire_resolution(self, fire_key: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            row = session.query(ClockworkFireResolution).filter(
                ClockworkFireResolution.fire_key == fire_key).first()
            return row.to_dict() if row else None

    def list_clockwork_fire_resolutions(self, fire_keys: List[str]) -> Dict[str, Dict[str, Any]]:
        if not fire_keys:
            return {}
        with self.get_session(read_only=True) as session:
            rows = session.query(ClockworkFireResolution).filter(
                ClockworkFireResolution.fire_key.in_(list(fire_keys))).all()
            return {r.fire_key: r.to_dict() for r in rows}
    # ── The DDL ledger (2026-09-11) ────────────────────────────────────
    #
    # A RECORD of what was applied, never the authority on what is there:
    # ``core/clockwork/schema_admin.py`` decides by reading the catalogue
    # against each script's declared postcondition.  These two methods are
    # the whole surface -- write a row, read the history.

    def record_clockwork_schema_migration(self, row: Dict[str, Any]) -> Dict[str, Any]:
        with self.get_session() as session:
            entry = ClockworkSchemaMigration(
                script_id=str(row.get("script_id") or "")[:200],
                dialect=str(row.get("dialect") or "")[:20],
                filename=str(row.get("filename") or "")[:200],
                kind=str(row.get("kind") or "")[:20],
                checksum=(str(row["checksum"])[:64] if row.get("checksum") else None),
                statements=int(row.get("statements") or 0),
                status=str(row.get("status") or "")[:20],
                applied_at=datetime.now(timezone.utc).replace(tzinfo=None),
                applied_by=(str(row["applied_by"])[:100] if row.get("applied_by") else None),
                detail=(str(row["detail"]) if row.get("detail") else None),
            )
            session.add(entry)
            session.flush()
            session.refresh(entry)
            return entry.to_dict()

    def list_clockwork_schema_migrations(self, limit: int = 200) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            rows = (session.query(ClockworkSchemaMigration)
                    .order_by(ClockworkSchemaMigration.applied_at.desc(),
                              ClockworkSchemaMigration.id.desc())
                    .limit(max(1, int(limit))).all())
            return [r.to_dict() for r in rows]
