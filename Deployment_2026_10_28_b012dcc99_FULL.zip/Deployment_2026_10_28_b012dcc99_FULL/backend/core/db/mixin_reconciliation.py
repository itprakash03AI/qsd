"""Mixin — Source↔Destination reconciliation CRUD (Phase 133).

Provides ``create / get / list / update / deactivate`` for
``ReconciliationEntity`` and read helpers for ``ReconciliationRun``.
The runner / scheduler / API layer all import only these methods so
they never need to touch SQLAlchemy directly.
"""
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any

from core.db.models import (
    ReconciliationEntity, ReconciliationRun,
)


class ReconciliationMixin:
    """DB methods for reconciliation entities + run history."""

    # ── ReconciliationEntity CRUD ─────────────────────────────────────

    def create_reconciliation_entity(self, data: dict) -> dict:
        with self.get_session() as session:
            ent = ReconciliationEntity(**data)
            session.add(ent)
            session.flush()
            session.refresh(ent)
            return ent.to_dict()

    def get_reconciliation_entity(self, entity_id: int) -> Optional[dict]:
        with self.get_session(read_only=True) as session:
            ent = session.query(ReconciliationEntity).filter(
                ReconciliationEntity.id == entity_id,
            ).first()
            return ent.to_dict() if ent else None

    def get_reconciliation_entity_by_name(self, name: str) -> Optional[dict]:
        with self.get_session(read_only=True) as session:
            ent = session.query(ReconciliationEntity).filter(
                ReconciliationEntity.name == name,
            ).first()
            return ent.to_dict() if ent else None

    def list_reconciliation_entities(
        self,
        is_active: Optional[bool] = None,
        status: Optional[str] = None,
    ) -> List[dict]:
        with self.get_session(read_only=True) as session:
            q = session.query(ReconciliationEntity)
            if is_active is not None:
                q = q.filter(ReconciliationEntity.is_active == is_active)
            if status:
                q = q.filter(ReconciliationEntity.last_status == status)
            return [e.to_dict() for e in
                    q.order_by(ReconciliationEntity.name).all()]

    def list_reconciliation_entities_due(self,
                                          now: Optional[datetime] = None
                                          ) -> List[dict]:
        """Active, schedule-enabled entities whose
        ``last_checked_at + check_interval_hours`` is in the past
        (or never checked).  Used by the 2-hour background scheduler.
        """
        from datetime import timedelta
        now = now or datetime.now(timezone.utc)
        out: List[dict] = []
        with self.get_session(read_only=True) as session:
            rows = session.query(ReconciliationEntity).filter(
                ReconciliationEntity.is_active == True,            # noqa: E712
                ReconciliationEntity.schedule_enabled == True,     # noqa: E712
            ).all()
            for ent in rows:
                interval = ent.check_interval_hours or 2
                # Phase 4 (2026-08-23): SQLite (and TIMESTAMP-without-tz
                # Postgres) hands back NAIVE datetimes; subtracting one
                # from aware `now` raised TypeError.  The scheduler tick
                # swallowed it and returned -- so after ANY entity's first
                # check, scheduled reconciliation was permanently dead
                # while Check Now kept working: the feature looked alive
                # with its automation silently gone.
                last = ent.last_checked_at
                if last is not None and last.tzinfo is None:
                    last = last.replace(tzinfo=timezone.utc)
                if not last or (now - last) >= timedelta(hours=interval):
                    out.append(ent.to_dict())
        return out

    def update_reconciliation_entity(self, entity_id: int,
                                       data: dict) -> Optional[dict]:
        with self.get_session() as session:
            ent = session.query(ReconciliationEntity).filter(
                ReconciliationEntity.id == entity_id,
            ).first()
            if not ent:
                return None
            for k, v in data.items():
                if hasattr(ent, k):
                    setattr(ent, k, v)
            ent.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(ent)
            return ent.to_dict()

    def deactivate_reconciliation_entity(self, entity_id: int) -> bool:
        with self.get_session() as session:
            ent = session.query(ReconciliationEntity).filter(
                ReconciliationEntity.id == entity_id,
            ).first()
            if not ent:
                return False
            ent.is_active = False
            ent.updated_at = datetime.now(timezone.utc)
            session.flush()
            return True

    # ── ReconciliationRun read helpers ────────────────────────────────

    def list_reconciliation_runs(self, entity_id: int,
                                   limit: int = 50) -> List[dict]:
        with self.get_session(read_only=True) as session:
            rows = (session.query(ReconciliationRun)
                    .filter(ReconciliationRun.entity_id == entity_id)
                    .order_by(ReconciliationRun.started_at.desc())
                    .limit(max(1, min(int(limit), 500)))
                    .all())
            return [r.to_dict() for r in rows]

    def get_reconciliation_dashboard(self) -> Dict[str, Any]:
        """Summary tile for the dashboard — counts by status."""
        with self.get_session(read_only=True) as session:
            entities = session.query(ReconciliationEntity).filter(
                ReconciliationEntity.is_active == True,            # noqa: E712
            ).all()
            counts = {"total": 0, "ok": 0, "break": 0, "error": 0,
                      "never_checked": 0}
            broken_entities: List[Dict[str, Any]] = []
            for e in entities:
                counts["total"] += 1
                if e.last_status == "ok":
                    counts["ok"] += 1
                elif e.last_status == "break":
                    counts["break"] += 1
                    broken_entities.append(e.to_dict())
                elif e.last_status == "error":
                    counts["error"] += 1
                else:
                    counts["never_checked"] += 1
            return {"counts": counts, "broken_entities": broken_entities}
