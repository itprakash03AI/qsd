"""Per-ENGINE memos that cannot outlive their engine (2026-10-04).

Several shared stores create their own table on first use -- a new TABLE
self-creates on this platform only via ``create_all`` at startup, and a
manager built before the model existed would otherwise miss it
(``rate_limit_windows``, ``pv_bulk_prepare_jobs`` / ``_claims``,
``pv_materialise_flights``, ``br_serve_log``) -- and each kept its own memo
of "already created here" keyed by ``id(engine)``.  The rate limiter also
keyed its "this window already refused" memo by ``id(engine)``.

``id()`` is an ADDRESS, and CPython hands a freed address to the next
object.  A fresh metadata database per test (a new engine each time) got a
NEW engine at an OLD engine's address: the memo said "created",
``CREATE TABLE`` was skipped, and the store failed with ``no such table:
rate_limit_windows`` -- found on a full CI-replica run
(``test_redis_stays_the_store_when_configured``), order- and allocator-
dependent, so green in every isolated run.  The same address reuse would
let a refusal remembered for a dead engine refuse on a live one.

ONE answer now: memos keyed by the engine OBJECT in a
``WeakKeyDictionary`` -- a dead engine's entry goes with it, so no later
engine can inherit it -- and ``engine_token`` for a memo that needs a
hashable key part (a counter value never reused in the process).
"""
from __future__ import annotations

import itertools
import threading
import weakref
from typing import Any

_ready: "weakref.WeakKeyDictionary[Any, set]" = weakref.WeakKeyDictionary()
_tokens: "weakref.WeakKeyDictionary[Any, int]" = weakref.WeakKeyDictionary()
_next_token = itertools.count(1)
_lock = threading.Lock()


def ensure_table(engine: Any, table: Any) -> None:
    """``table.create(engine, checkfirst=True)`` the first time this engine
    asks for this table; a no-op afterwards.  Raises what ``create``
    raises (the caller decides whether a store failure is fatal)."""
    name = table.name
    done = _ready.get(engine)
    if done is not None and name in done:
        return
    with _lock:
        done = _ready.get(engine)
        if done is not None and name in done:
            return
        table.create(engine, checkfirst=True)
        _ready.setdefault(engine, set()).add(name)


def engine_token(engine: Any) -> int:
    """A process-unique number for this engine OBJECT -- never reused by a
    later engine (unlike ``id()``)."""
    tok = _tokens.get(engine)
    if tok is not None:
        return tok
    with _lock:
        tok = _tokens.get(engine)
        if tok is None:
            tok = next(_next_token)
            _tokens[engine] = tok
        return tok


def forget_tables_for_tests(engine: Any = None) -> None:
    """TEST SEAM: drop the created-table memo (for one engine, or all)."""
    with _lock:
        if engine is None:
            _ready.clear()
        else:
            _ready.pop(engine, None)
