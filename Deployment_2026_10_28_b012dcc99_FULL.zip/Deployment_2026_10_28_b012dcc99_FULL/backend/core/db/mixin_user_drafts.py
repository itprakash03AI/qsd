"""User-draft CRUD mixin — Phase 142.

Powers server-side draft persistence for every page in the frontend.
Replaces the per-component localStorage scatter with a single coherent
DB-backed store.

All methods are auth-scoped: callers MUST pass ``username`` from the
authenticated request.  No method allows cross-user access.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional

from core.db.models import UserDraft

_log = logging.getLogger(__name__)


class UserDraftsMixin:

    def get_user_draft(self, username: str, draft_key: str) -> Optional[Dict[str, Any]]:
        """Return the draft for (username, draft_key) or None."""
        if not username or not draft_key:
            return None
        with self.get_session(read_only=True) as session:
            d = session.query(UserDraft).filter(
                UserDraft.username == username,
                UserDraft.draft_key == draft_key,
            ).first()
            return d.to_dict() if d else None

    def upsert_user_draft(
        self,
        username: str,
        draft_key: str,
        content: Any,
        size_cap_bytes: int,
        per_user_cap_bytes: int,
    ) -> Dict[str, Any]:
        """Insert or update the draft.  Enforces per-draft + per-user size caps.

        Raises ``ValueError`` with a friendly message when a cap is exceeded —
        the API layer translates to HTTP 413.
        """
        if not username or not draft_key:
            raise ValueError("username and draft_key are required")

        try:
            payload = json.dumps(content, separators=(",", ":"))
        except (TypeError, ValueError) as exc:
            raise ValueError(f"content is not JSON-serialisable: {exc}") from exc

        size = len(payload.encode("utf-8"))
        if size_cap_bytes > 0 and size > size_cap_bytes:
            raise ValueError(
                f"draft exceeds per-draft size cap "
                f"({size:,} > {size_cap_bytes:,} bytes)"
            )

        # Bug-fix: handle the SELECT-then-INSERT race for concurrent
        # PUTs to the same (user, key).  Without this, two near-simultaneous
        # requests both observe no-row, both INSERT, the second fails with
        # IntegrityError on the UNIQUE constraint.  We catch + retry as
        # UPDATE so callers see consistent success.
        from sqlalchemy import func
        from sqlalchemy.exc import IntegrityError

        def _do_upsert():
            with self.get_session() as session:
                other_sum = (
                    session.query(func.coalesce(func.sum(UserDraft.size_bytes), 0))
                    .filter(UserDraft.username == username,
                              UserDraft.draft_key != draft_key)
                    .scalar()
                ) or 0
                if per_user_cap_bytes > 0 and (other_sum + size) > per_user_cap_bytes:
                    raise ValueError(
                        f"per-user total draft size cap exceeded "
                        f"({other_sum + size:,} > {per_user_cap_bytes:,} bytes)"
                    )

                d = session.query(UserDraft).filter(
                    UserDraft.username == username,
                    UserDraft.draft_key == draft_key,
                ).first()
                if d:
                    d.content_json = content
                    d.size_bytes = size
                    d.updated_at = datetime.now(timezone.utc)
                    session.flush()
                    session.refresh(d)
                else:
                    d = UserDraft(
                        username=username,
                        draft_key=draft_key,
                        content_json=content,
                        size_bytes=size,
                    )
                    session.add(d)
                    session.flush()
                    session.refresh(d)
                return d.to_dict()

        try:
            return _do_upsert()
        except IntegrityError as _race_exc:
            # Concurrent insert won — retry, which will go through the UPDATE branch
            _log.debug("upsert_user_draft race (concurrent INSERT) — retrying as UPDATE: %s", _race_exc)
            return _do_upsert()

    def delete_user_draft(self, username: str, draft_key: str) -> bool:
        """Delete one draft.  Idempotent — returns True even if it didn't exist."""
        if not username or not draft_key:
            return False
        with self.get_session() as session:
            n = session.query(UserDraft).filter(
                UserDraft.username == username,
                UserDraft.draft_key == draft_key,
            ).delete()
            return True if n is not None else False

    def list_user_drafts(self, username: str) -> List[Dict[str, Any]]:
        """Return summaries of every draft for ``username`` (no content
        payload — keeps the response small).  Used by admin debug + by the
        frontend to show "you have N saved drafts"."""
        if not username:
            return []
        with self.get_session(read_only=True) as session:
            rows = session.query(UserDraft).filter(
                UserDraft.username == username,
            ).order_by(UserDraft.updated_at.desc()).all()
            return [r.to_summary() for r in rows]

    def list_user_drafts_by_prefix(
        self, username: str, key_prefix: str,
    ) -> List[Dict[str, Any]]:
        """Return summaries of drafts whose key starts with ``key_prefix``.

        Useful for "show me all CQB drafts" (prefix=``cqb.``) or "all
        Dashboard drafts" (prefix=``dashboard.``)."""
        if not username:
            return []
        with self.get_session(read_only=True) as session:
            q = session.query(UserDraft).filter(
                UserDraft.username == username,
            )
            if key_prefix:
                q = q.filter(UserDraft.draft_key.like(f"{key_prefix}%"))
            rows = q.order_by(UserDraft.updated_at.desc()).all()
            return [r.to_summary() for r in rows]

    def cleanup_user_drafts(self, retain_days: int) -> int:
        """Daily cleanup — delete drafts older than ``retain_days``.
        Returns rows deleted."""
        if retain_days <= 0:
            return 0
        cutoff = datetime.now(timezone.utc) - timedelta(days=retain_days)
        with self.get_session() as session:
            n = session.query(UserDraft).filter(
                UserDraft.updated_at < cutoff,
            ).delete()
            return int(n or 0)

    def user_draft_stats(self) -> Dict[str, Any]:
        """Admin-facing stats — count + total bytes across all users."""
        with self.get_session(read_only=True) as session:
            from sqlalchemy import func
            row = session.query(
                func.count(UserDraft.id).label("count"),
                func.coalesce(func.sum(UserDraft.size_bytes), 0).label("total_bytes"),
                func.count(func.distinct(UserDraft.username)).label("users"),
            ).first()
            return {
                "draft_count": int(row.count or 0),
                "total_bytes": int(row.total_bytes or 0),
                "unique_users": int(row.users or 0),
            }
