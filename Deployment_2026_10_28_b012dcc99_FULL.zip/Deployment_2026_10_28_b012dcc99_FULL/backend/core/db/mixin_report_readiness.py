"""
Mixin -- business-date READINESS on reports and report SLOs (2026-09-28).

Five tables, all report-keyed: the readiness subject (which parameter is
the business date), the report's dependency mappings (the feed mapping's
columns, in a table of their own -- see the model docstrings for why they
do not share ``etl_dependency_mappings``), the readiness verdict each RUN
was served under, the SLO declaration, and the breach ledger.

The join that feeds the gate (``list_report_dependency_mappings_with_
tracking``) returns EXACTLY the row shape ``FeedsMixin.list_etl_dependency_
mappings_with_tracking`` returns, so ``core.feed.etl_dependency.
evaluate_gate_over_rows`` -- the ONE readiness decision -- reads a report's
rows without knowing whose they are.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Optional

from core.db.models import (
    EtlDependencyTracking,
    EtlDependencyType,
    ReportDependencyMapping,
    ReportReadinessRun,
    ReportReadinessSubject,
    ReportSlo,
    ReportSloBreach,
)

logger = logging.getLogger(__name__)


def _as_date(raw: Any) -> Optional[date]:
    if isinstance(raw, datetime):
        return raw.date()
    if isinstance(raw, date):
        return raw
    if isinstance(raw, str):
        try:
            return date.fromisoformat(raw[:10])
        except ValueError:
            return None
    return None


def _aware(dt: Optional[datetime]) -> Optional[datetime]:
    """SQLite hands naive values back; every writer here stores aware UTC."""
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


class ReportReadinessMixin:

    # ── readiness subject ────────────────────────────────────────────────

    def get_report_readiness_subject(self, report_id: int) -> Optional[dict]:
        with self.get_session(read_only=True) as session:
            row = (session.query(ReportReadinessSubject)
                   .filter(ReportReadinessSubject.report_id == int(report_id))
                   .first())
            return row.to_dict() if row else None

    def upsert_report_readiness_subject(self, report_id: int, *,
                                        business_date_param: Optional[str],
                                        updated_by: Optional[str]) -> dict:
        with self.get_session() as session:
            row = (session.query(ReportReadinessSubject)
                   .filter(ReportReadinessSubject.report_id == int(report_id))
                   .first())
            if row is None:
                row = ReportReadinessSubject(report_id=int(report_id))
                session.add(row)
            row.business_date_param = (str(business_date_param).strip()
                                       if business_date_param else None)
            row.updated_by = updated_by
            row.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    # ── dependency mappings ──────────────────────────────────────────────

    def list_report_dependency_mappings(self, report_id: int,
                                        active_only: bool = True) -> List[dict]:
        with self.get_session(read_only=True) as session:
            q = session.query(ReportDependencyMapping).filter(
                ReportDependencyMapping.report_id == int(report_id))
            if active_only:
                q = q.filter(ReportDependencyMapping.is_active == True)  # noqa: E712
            return [r.to_dict() for r in q.order_by(ReportDependencyMapping.id).all()]

    def replace_report_dependency_mappings(self, report_id: int,
                                           rows: List[dict]) -> List[dict]:
        """Atomic bulk replace (the feed route's semantics): every mapping
        for the report is removed and the given list inserted, in ONE
        session, so a failure leaves the old set intact."""
        with self.get_session() as session:
            (session.query(ReportDependencyMapping)
             .filter(ReportDependencyMapping.report_id == int(report_id))
             .delete(synchronize_session=False))
            out = []
            for data in rows:
                row = ReportDependencyMapping(report_id=int(report_id), **data)
                session.add(row)
                session.flush()
                out.append(row.to_dict())
            return out

    def count_report_dependency_mappings(self, report_id: int) -> int:
        with self.get_session(read_only=True) as session:
            return int(session.query(ReportDependencyMapping).filter(
                ReportDependencyMapping.report_id == int(report_id),
                ReportDependencyMapping.is_active == True,  # noqa: E712
            ).count())

    def list_report_dependency_mappings_with_tracking(self, report_id: int,
                                                      business_date) -> List[dict]:
        """The gate's rows for a REPORT -- the SAME shape as
        ``FeedsMixin.list_etl_dependency_mappings_with_tracking`` so the one
        gate reads them unchanged.  The tracking table is shared evidence
        keyed by (type, key, date), never by subject."""
        bd = _as_date(business_date)
        with self.get_session(read_only=True) as session:
            rows = (session.query(ReportDependencyMapping, EtlDependencyType,
                                  EtlDependencyTracking)
                    .join(EtlDependencyType,
                          EtlDependencyType.id == ReportDependencyMapping.dependency_type_id)
                    .outerjoin(EtlDependencyTracking,
                               (EtlDependencyTracking.dependency_type_id ==
                                ReportDependencyMapping.dependency_type_id) &
                               (EtlDependencyTracking.dependency_key ==
                                ReportDependencyMapping.dependency_key) &
                               (EtlDependencyTracking.business_date == bd))
                    .filter(ReportDependencyMapping.report_id == int(report_id),
                            ReportDependencyMapping.is_active == True)  # noqa: E712
                    .order_by(ReportDependencyMapping.id)
                    .all())
            out: List[dict] = []
            for mapping, type_row, tracking in rows:
                out.append({
                    "mapping_id":     int(mapping.id),
                    "type_id":        int(type_row.id),
                    "type_name":      type_row.dependency_type,
                    "dependency_key": mapping.dependency_key,
                    "action":         (tracking.action if tracking else None),
                    "updated_at":     (tracking.updated_at if tracking else None),
                    "calendar_name":  mapping.calendar_name,
                    "expected_rows":  mapping.expected_rows,
                    "business_date":  (tracking.business_date if tracking else None),
                    "arrival_sources": mapping.arrival_sources,
                    "require_mode":   mapping.require_mode,
                    "tracking_comments": (tracking.comments if tracking else None),
                })
            return out

    # ── readiness runs (the SLO's evidence) ──────────────────────────────

    def record_report_readiness_run(self, data: dict) -> dict:
        with self.get_session() as session:
            row = ReportReadinessRun(**data)
            if row.evaluated_at is None:
                row.evaluated_at = datetime.now(timezone.utc)
            session.add(row)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def list_report_readiness_runs(self, report_id: int, business_date,
                                   limit: int = 200) -> List[dict]:
        """Runs for (report, date), OLDEST first, ``evaluated_at`` aware
        UTC on the dict (``evaluated_at_dt``) beside the ISO string."""
        bd = _as_date(business_date)
        with self.get_session(read_only=True) as session:
            rows = (session.query(ReportReadinessRun)
                    .filter(ReportReadinessRun.report_id == int(report_id),
                            ReportReadinessRun.business_date == bd)
                    .order_by(ReportReadinessRun.evaluated_at.asc(),
                              ReportReadinessRun.id.asc())
                    .limit(int(limit)).all())
            out = []
            for r in rows:
                d = r.to_dict()
                d["evaluated_at_dt"] = _aware(r.evaluated_at)
                out.append(d)
            return out

    # ── SLO declaration ──────────────────────────────────────────────────

    def get_report_slo(self, report_id: int) -> Optional[dict]:
        with self.get_session(read_only=True) as session:
            row = (session.query(ReportSlo)
                   .filter(ReportSlo.report_id == int(report_id)).first())
            return row.to_dict() if row else None

    def list_report_slos(self, active_only: bool = True) -> List[dict]:
        with self.get_session(read_only=True) as session:
            q = session.query(ReportSlo)
            if active_only:
                q = q.filter(ReportSlo.is_active == True)  # noqa: E712
            return [r.to_dict() for r in q.order_by(ReportSlo.report_id).all()]

    def upsert_report_slo(self, report_id: int, data: dict) -> dict:
        with self.get_session() as session:
            row = (session.query(ReportSlo)
                   .filter(ReportSlo.report_id == int(report_id)).first())
            if row is None:
                row = ReportSlo(report_id=int(report_id))
                session.add(row)
            for key, value in data.items():
                setattr(row, key, value)
            row.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def delete_report_slo(self, report_id: int) -> bool:
        with self.get_session() as session:
            n = (session.query(ReportSlo)
                 .filter(ReportSlo.report_id == int(report_id))
                 .delete(synchronize_session=False))
            return bool(n)

    # ── breach ledger ────────────────────────────────────────────────────

    def get_report_slo_breach(self, report_id: int, business_date) -> Optional[dict]:
        bd = _as_date(business_date)
        with self.get_session(read_only=True) as session:
            row = (session.query(ReportSloBreach)
                   .filter(ReportSloBreach.report_id == int(report_id),
                           ReportSloBreach.business_date == bd).first())
            return row.to_dict() if row else None

    def record_report_slo_breach(self, data: dict) -> dict:
        """Insert-or-keep: the FIRST detection of a (report, date) breach
        wins; a later pass updates nothing but reads the row back."""
        bd = _as_date(data.get("business_date"))
        with self.get_session() as session:
            row = (session.query(ReportSloBreach)
                   .filter(ReportSloBreach.report_id == int(data["report_id"]),
                           ReportSloBreach.business_date == bd).first())
            if row is None:
                payload = dict(data)
                payload["business_date"] = bd
                row = ReportSloBreach(**payload)
                session.add(row)
                session.flush()
            session.refresh(row)
            return row.to_dict()

    def mark_report_slo_breach_served(self, report_id: int, business_date,
                                      served_at: datetime) -> Optional[dict]:
        bd = _as_date(business_date)
        with self.get_session() as session:
            row = (session.query(ReportSloBreach)
                   .filter(ReportSloBreach.report_id == int(report_id),
                           ReportSloBreach.business_date == bd).first())
            if row is None:
                return None
            row.state = "served_late"
            row.served_at = served_at
            session.flush()
            session.refresh(row)
            return row.to_dict()

    def list_report_slo_breaches(self, report_id: Optional[int] = None, *,
                                 business_date=None, limit: int = 50) -> List[dict]:
        with self.get_session(read_only=True) as session:
            q = session.query(ReportSloBreach)
            if report_id is not None:
                q = q.filter(ReportSloBreach.report_id == int(report_id))
            if business_date is not None:
                q = q.filter(ReportSloBreach.business_date == _as_date(business_date))
            rows = (q.order_by(ReportSloBreach.business_date.desc(),
                               ReportSloBreach.id.desc())
                    .limit(int(limit)).all())
            return [r.to_dict() for r in rows]


__all__ = ["ReportReadinessMixin"]
