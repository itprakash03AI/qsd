"""Is this database error one that can pass?  (2026-10-13)

Found live: the scheduler's database pool timed out for two minutes while the
laptop rig was saturated, and the wait loop of a HEALTHY Spark job -- one that
was reading 1M rows, minutes from delivering -- turned the pool timeout into
a failed run and its job was deleted.  A month-end run must not be lost to a
database that is briefly unreachable from the pod watching it.

Transient: the connection pool timed out, the connection dropped or was
refused, the server is restarting.  NOT transient: an error in the statement
or the data (it fails again, the same way).
"""
from __future__ import annotations


def is_transient_db_error(exc: BaseException) -> bool:
    try:
        from sqlalchemy import exc as sa_exc
    except Exception:          # pragma: no cover -- sqlalchemy is a hard dependency
        return False
    if isinstance(exc, sa_exc.TimeoutError):              # the pool: no connection in time
        return True
    if isinstance(exc, sa_exc.DBAPIError) and getattr(exc, "connection_invalidated", False):
        return True
    if isinstance(exc, (sa_exc.OperationalError, sa_exc.InterfaceError)):
        # OperationalError also carries PERMANENT errors on some databases
        # (SQLite: "no such table") -- transient only when it is about the
        # connection itself
        msg = str(exc).lower()
        return any(w in msg for w in _CONNECTION_WORDS)
    return isinstance(exc, (ConnectionError, TimeoutError))


_CONNECTION_WORDS = (
    "connection", "could not connect", "server closed", "timeout", "timed out",
    "terminating", "the database system is starting up", "the database system is shutting down",
    "database is locked", "broken pipe", "connection reset", "ssl syscall",
)
