"""
Mixin — Federation Views CRUD (Phase 93).
Extracted from DatabaseManager for modularity.
"""
from datetime import datetime, timezone
from typing import Optional, List, Dict, Any

from core.db.models import FederationView


class FederationViewsMixin:
    """Database methods for federation views (cross-connection saved queries)."""

    def create_federation_view(self, **kwargs) -> Dict[str, Any]:
        with self.get_session() as session:
            fv = FederationView(**kwargs)
            session.add(fv)
            session.flush()
            session.refresh(fv)
            return fv.to_dict()

    def get_federation_view(self, view_id: int) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            fv = session.query(FederationView).filter(FederationView.id == view_id).first()
            return fv.to_dict() if fv else None

    def get_federation_view_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            fv = session.query(FederationView).filter(FederationView.name == name).first()
            return fv.to_dict() if fv else None

    def list_federation_views(self, active_only: bool = False) -> List[Dict[str, Any]]:
        with self.get_session(read_only=True) as session:
            q = session.query(FederationView)
            if active_only:
                q = q.filter(FederationView.is_active == True)  # noqa: E712
            return [fv.to_dict() for fv in q.order_by(FederationView.name).all()]

    def update_federation_view(self, view_id: int, **kwargs) -> Optional[Dict[str, Any]]:
        with self.get_session() as session:
            fv = session.query(FederationView).filter(FederationView.id == view_id).first()
            if not fv:
                return None
            for k, v in kwargs.items():
                if hasattr(fv, k):
                    setattr(fv, k, v)
            fv.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(fv)
            return fv.to_dict()

    def delete_federation_view(self, view_id: int) -> bool:
        with self.get_session() as session:
            fv = session.query(FederationView).filter(FederationView.id == view_id).first()
            if not fv:
                return False
            session.delete(fv)
            session.flush()
            return True

    # ── Phase 97: Materialization helpers ─────────────────────────────────────

    def list_materialized_federation_views(self) -> List[Dict[str, Any]]:
        """Return federation views with status='ready' (materialized, usable in query builder)."""
        with self.get_session(read_only=True) as session:
            q = session.query(FederationView).filter(
                FederationView.is_active == True,   # noqa: E712
                FederationView.status == "ready",
            )
            return [fv.to_dict() for fv in q.order_by(FederationView.name).all()]

    def get_federation_views_by_ids(self, ids: List[int]) -> List[Dict[str, Any]]:
        """Get multiple federation views by ID — used for composability depth check."""
        if not ids:
            return []
        with self.get_session(read_only=True) as session:
            fvs = session.query(FederationView).filter(FederationView.id.in_(ids)).all()
            return [fv.to_dict() for fv in fvs]
