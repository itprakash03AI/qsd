"""
Mixin — Report Comments & Change Log (Phase 114-J/K).
"""
from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import List, Optional

from core.db.models import ReportComment, ReportChangeLog


class CommentsMixin:
    """Database methods for report comments and change history."""

    # ── Comments CRUD ─────────────────────────────────────────────────────

    def create_report_comment(self, *, report_id: int, username: str, text: str,
                              parent_id: int = None) -> dict:
        mentions = re.findall(r'@(\w+)', text)
        with self.get_session() as session:
            comment = ReportComment(
                report_id=report_id, parent_id=parent_id,
                username=username, text=text,
                mentions=mentions if mentions else None,
            )
            session.add(comment)
            session.flush()
            session.refresh(comment)
            return comment.to_dict()

    def list_report_comments(self, report_id: int, limit: int = 200) -> List[dict]:
        with self.get_session(read_only=True) as session:
            q = (session.query(ReportComment)
                 .filter(ReportComment.report_id == report_id)
                 .order_by(ReportComment.created_at.asc())
                 .limit(limit))
            return [c.to_dict() for c in q.all()]

    def update_report_comment(self, comment_id: int, report_id: int,
                              username: str, is_admin: bool = False,
                              **updates) -> Optional[dict]:
        """Update a comment — restricted to its OWNER (or an admin moderator).

        AUTHZ-1 (2026-08-22): the owner check now LIVES HERE, where the row is
        mutated — the previous comment claimed "here we check owner" while the
        query filtered on ``(id, report_id)`` only and the passed ``username``
        was discarded, so any analyst could edit anyone's comment.  A mismatch
        raises :class:`PermissionError` (route → 403); a genuinely missing row
        returns ``None`` (route → 404), so ownership enforcement cannot be
        bypassed by a caller that forgets to gate.
        """
        with self.get_session() as session:
            c = (session.query(ReportComment)
                 .filter(ReportComment.id == comment_id,
                         ReportComment.report_id == report_id)
                 .first())
            if not c:
                return None
            if not is_admin and (c.username or "") != (username or ""):
                raise PermissionError(
                    "only the comment's author (or an admin) may edit it")
            for k, v in updates.items():
                if hasattr(c, k):
                    setattr(c, k, v)
            if 'text' in updates:
                c.mentions = re.findall(r'@(\w+)', updates['text']) or None
            c.updated_at = datetime.now(timezone.utc)
            session.flush()
            session.refresh(c)
            return c.to_dict()

    def delete_report_comment(self, comment_id: int, report_id: int,
                              username: str = None,
                              is_admin: bool = False) -> bool:
        """Delete a comment (and its replies) — restricted to its OWNER (or an
        admin moderator).

        AUTHZ-1 (2026-08-22): the route previously passed NO identity and the
        query deleted on ``(id, report_id)`` only, so any analyst could erase
        anyone's thread.  Ownership is enforced HERE: a mismatch raises
        :class:`PermissionError` (route → 403), a missing row returns ``False``
        (route → 404).  ``username=None`` with ``is_admin=False`` is treated as
        an unauthenticated caller and refused unless the row is missing.
        """
        with self.get_session() as session:
            c = (session.query(ReportComment)
                 .filter(ReportComment.id == comment_id,
                         ReportComment.report_id == report_id)
                 .first())
            if not c:
                return False
            if not is_admin and (c.username or "") != (username or ""):
                raise PermissionError(
                    "only the comment's author (or an admin) may delete it")
            # Also delete child replies
            session.query(ReportComment).filter(
                ReportComment.parent_id == comment_id
            ).delete()
            session.delete(c)
            return True

    def count_report_comments(self, report_id: int) -> int:
        with self.get_session(read_only=True) as session:
            return session.query(ReportComment).filter(
                ReportComment.report_id == report_id
            ).count()

    # ── Change Log ────────────────────────────────────────────────────────

    def create_report_change_log(self, *, report_id: int, username: str,
                                 action: str, changes: list = None) -> dict:
        with self.get_session() as session:
            entry = ReportChangeLog(
                report_id=report_id, username=username,
                action=action, changes=changes,
            )
            session.add(entry)
            session.flush()
            session.refresh(entry)
            return entry.to_dict()

    def list_report_change_log(self, report_id: int, limit: int = 50) -> List[dict]:
        with self.get_session(read_only=True) as session:
            q = (session.query(ReportChangeLog)
                 .filter(ReportChangeLog.report_id == report_id)
                 .order_by(ReportChangeLog.created_at.desc())
                 .limit(limit))
            return [e.to_dict() for e in q.all()]
