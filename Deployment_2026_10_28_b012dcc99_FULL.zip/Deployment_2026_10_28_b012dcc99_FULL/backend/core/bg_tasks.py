"""BF-594 (2026-05-30) — shared fire-and-forget task helper.

CPython's event loop holds asyncio.Task objects in a **WeakSet**.  A
fire-and-forget ``asyncio.create_task(coro)`` whose result is discarded
can be garbage-collected mid-await — Python issue #88831.  Logs show
"Task was destroyed but it is pending!" and the in-flight work is
silently lost (a WS message never sends, a webhook never fires, a
credential refresh never completes).

BF-588/590/591 fixed this pattern inside ``api/execute_api.py`` via a
module-level ``_bg_broadcast_tasks: set`` + ``_track_bg_task`` helper.
BF-592 moved the implementation into ``core.query_queue.QueueManager``.
BF-594 hoists the helper into THIS module so every other file with
fire-and-forget tasks (sql_query_api, business_reports_api, auth_api,
connections_api, admin_api, published_views/management) can adopt the
same pattern without coupling to the queue subsystem.

Apply rule for new code:
    from core.bg_tasks import track_bg_task
    track_bg_task(some_coroutine())   # NOT asyncio.create_task(...)
"""
from __future__ import annotations

import asyncio
import logging
from typing import Awaitable, Set

logger = logging.getLogger(__name__)

# Module-level strong-ref set.  Tasks self-discard via done-callback.
_bg_tasks: Set[asyncio.Task] = set()


def track_bg_task(coro: Awaitable) -> asyncio.Task:
    """Schedule a coroutine on the running loop with strong-ref tracking.

    Returns the Task so callers that want to cancel / await can keep
    their own reference.  Whether or not they do, the task is held in
    the module-level set until its done-callback removes it — closing
    the Python issue #88831 GC hazard.

    Raises ``RuntimeError`` when no event loop is running — same
    semantics as ``asyncio.create_task``.  Callers in sync contexts
    should use ``asyncio.run_coroutine_threadsafe(...)`` instead.
    """
    t = asyncio.create_task(coro)
    _bg_tasks.add(t)
    t.add_done_callback(_bg_tasks.discard)
    return t


def inflight_count() -> int:
    """Live count of fire-and-forget tasks currently held strongly.

    CPython ``len(set)`` is a single GIL-atomic bytecode — safe to
    call from worker threads.
    """
    return len(_bg_tasks)


def cancel_all() -> int:
    """Cancel every tracked task.  Returns the count cancelled.

    Useful for clean shutdown.  Does NOT wait for tasks to finish —
    caller decides whether to await.
    """
    count = 0
    for t in list(_bg_tasks):
        if not t.done():
            t.cancel()
            count += 1
    return count
