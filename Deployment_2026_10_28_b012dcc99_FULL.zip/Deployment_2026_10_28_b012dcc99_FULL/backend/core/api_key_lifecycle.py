"""Phase 131 deep-dive #13 — in-flight API-key revocation.

Auth-time validation already catches a revoked key on the *next* request,
but a query that started while the key was still valid keeps running.
For long-running API-consumer queries (large Published Views with no
chunking, federation joins, cross-source pre-downloads), the gap between
admin Revoke and the query naturally completing can be minutes.

This module bridges that gap with two mechanisms:

1. **Immediate cancel on revoke** — the admin DELETE endpoint calls
   ``cancel_executions_for_api_key(api_key_id)`` which iterates the live
   registry and fires the matching cancel_event for each in-flight
   execution.

2. **Periodic sweep** — the scheduler runs ``sweep_revoked_api_keys()``
   every N seconds (config: ``auth.api_key_revocation_sweep_seconds``,
   default 30 s).  For each registered (execution_id, api_key_id), it
   re-queries the key; if the key is revoked, expired, or deleted, the
   cancel_event is fired.  This catches cases where the admin DELETE
   bypassed the immediate-cancel hook (e.g. DB direct edits, multi-pod
   races where revoke happens on a different pod).

Both mechanisms set the same ``threading.Event`` that
``core.duckdb_cancel.spawn_interrupt_watchdog`` polls, so the in-flight
DuckDB statement aborts within ~500 ms of the revoke.

Registration is voluntary — endpoints that handle API-key-authenticated
long-running queries call ``register_execution`` at start and
``unregister_execution`` at teardown.  Unregistered executions are
unaffected (no false-positive cancels).
"""
from __future__ import annotations

import logging
import threading
from typing import Dict, Set, Tuple, Optional

logger = logging.getLogger(__name__)

# execution_id → api_key_id
_registry: Dict[str, int] = {}
_registry_lock = threading.RLock()

# Reverse index for cheap cancel-by-key lookup
_by_key: Dict[int, Set[str]] = {}


def register_execution(execution_id: str, api_key_id: Optional[int]) -> None:
    """Note that ``execution_id`` was started by ``api_key_id``.

    Safe to call with ``api_key_id=None`` — non-api-key auth is just a
    no-op.  Idempotent: re-registering the same exec_id replaces the
    previous mapping (useful if a retry path picks up an older record).
    """
    if not execution_id or not api_key_id:
        return
    with _registry_lock:
        prev = _registry.get(execution_id)
        if prev is not None and prev != api_key_id:
            # Stale entry from a previous owner — clean reverse index.
            _by_key.get(prev, set()).discard(execution_id)
        _registry[execution_id] = int(api_key_id)
        _by_key.setdefault(int(api_key_id), set()).add(execution_id)


def unregister_execution(execution_id: str) -> None:
    """Drop the registry entry for ``execution_id``.  Always safe to call,
    even if it was never registered."""
    if not execution_id:
        return
    with _registry_lock:
        kid = _registry.pop(execution_id, None)
        if kid is not None:
            _by_key.get(kid, set()).discard(execution_id)


def list_active_pairs() -> Tuple[Tuple[str, int], ...]:
    """Snapshot the registry for sweep iteration without holding the lock."""
    with _registry_lock:
        return tuple(_registry.items())


def _fire_cancel(execution_id: str, reason: str) -> bool:
    """Look up the worker_pool record and set its cancel_event."""
    try:
        from core.worker_pool import get_pool
        wp = get_pool()
        # 2026-08-10 -- was ``hasattr(wp, "get_active")`` then
        # ``wp.get_active(execution_id)``.  WorkerPool has no ``get_active``
        # and never has: the hasattr guard was ALWAYS False, so this returned
        # False every time and REVOKING AN API KEY NEVER CANCELLED ANYTHING
        # in-flight on this pod.  It failed silently because the guard turned
        # a missing method into a clean "nothing to cancel".
        #
        # ``get_cancel_event(execution_id)`` is the method that does this
        # lookup (``get_active_tasks`` is a different thing -- WorkType
        # filter, list of dicts).
        if wp is None or not hasattr(wp, "get_cancel_event"):
            return False
        ev = wp.get_cancel_event(execution_id)
        if ev is None:
            return False
        ev.set()
        logger.info("[api_key_lifecycle] cancelled execution %s — %s",
                    execution_id, reason)
        return True
    except Exception as exc:
        logger.debug("[api_key_lifecycle] cancel lookup failed for %s: %s",
                     execution_id, exc)
        return False


def cancel_executions_for_api_key(api_key_id: int) -> int:
    """Fire cancel_event for every in-flight execution tied to ``api_key_id``.

    Returns the number of executions actually signalled.  Called from
    the admin Revoke endpoint so revocation is honoured immediately on
    this pod (the periodic sweep handles cross-pod cases via the DB).
    """
    if not api_key_id:
        return 0
    with _registry_lock:
        targets = list(_by_key.get(int(api_key_id), ()))
    fired = 0
    for exec_id in targets:
        if _fire_cancel(exec_id, f"api_key {api_key_id} revoked"):
            fired += 1
    return fired


def _orphan_check(execution_id: str) -> bool:
    """Return True when no worker_pool record exists for this execution.

    Used to GC registry entries leaked by code paths that don't reach
    their unregister call (typically: exception in the middle of a
    handler).  Best-effort — never raises.
    """
    try:
        from core.worker_pool import get_pool
        wp = get_pool()
        # 2026-08-10 -- same non-existent ``get_active`` as _fire_cancel.
        # Here the always-False guard meant this ALWAYS returned "a record
        # exists", so nothing was ever GC'd and the in-process registry this
        # function exists to bound grew unbounded on exactly the exceptional
        # exit paths it was written for.
        #
        # ``get_cancel_event`` is the record probe: it returns None when the
        # execution has no entry in the pool's index (or its record is gone),
        # which is exactly "orphan".
        if wp is None or not hasattr(wp, "get_cancel_event"):
            return False  # worker_pool not available — don't GC
        return wp.get_cancel_event(execution_id) is None
    except Exception:
        return False


def sweep_revoked_api_keys(db_manager) -> Dict[str, int]:
    """Periodic sweep — fire cancel_event for executions whose API key has
    been revoked, expired, or deleted since the execution started.

    Also GCs orphan registry entries (executions that completed without
    an explicit unregister) so the in-process registry doesn't grow
    unbounded under exceptional exit paths.

    Returns counters for telemetry.  Called from the scheduler tick.
    """
    import datetime as _dt
    counters = {"scanned": 0, "cancelled": 0, "missing": 0, "orphan_gc": 0}
    pairs = list_active_pairs()
    if not pairs:
        return counters

    now = _dt.datetime.now(_dt.timezone.utc)
    for exec_id, key_id in pairs:
        counters["scanned"] += 1
        try:
            ak = db_manager.get_api_key(key_id) if hasattr(db_manager, "get_api_key") else None
        except Exception as exc:
            logger.debug("[api_key_lifecycle] sweep lookup failed key=%d: %s",
                         key_id, exc)
            continue
        if ak is None:
            counters["missing"] += 1
            if _fire_cancel(exec_id, f"api_key {key_id} deleted"):
                counters["cancelled"] += 1
            unregister_execution(exec_id)
            continue
        if not ak.get("is_active"):
            if _fire_cancel(exec_id, f"api_key {key_id} revoked"):
                counters["cancelled"] += 1
            continue
        exp = ak.get("expires_at")
        if exp:
            if isinstance(exp, str):
                try:
                    exp = _dt.datetime.fromisoformat(exp.replace("Z", "+00:00"))
                except ValueError:
                    exp = None
            if exp is not None:
                if exp.tzinfo is None:
                    exp = exp.replace(tzinfo=_dt.timezone.utc)
                if now > exp and _fire_cancel(exec_id, f"api_key {key_id} expired"):
                    counters["cancelled"] += 1
                    continue
        # Key is valid — check for orphan registry entry (execution
        # completed but never unregistered, e.g. exception path).
        if _orphan_check(exec_id):
            unregister_execution(exec_id)
            counters["orphan_gc"] += 1
    return counters
