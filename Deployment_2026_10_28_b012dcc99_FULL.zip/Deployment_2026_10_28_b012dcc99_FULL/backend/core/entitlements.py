"""Generic entitlement resolver — Phase 130 hotfix-13.

Shared by feeds, reports, and any future resource that carries an
``owner_group_id``.  One module, one policy: per-resource read/write
authority resolved against the user's identity, the resource's owner,
the resource's group, and global roles.

The resolver is deliberately generic:

  can_view(resource, user, *, db=None)  -> bool
  can_edit(resource, user, *, db=None)  -> bool

``resource`` is any dict (or dict-like) with these optional keys:
  - created_by:     the username that created it
  - owner_group_id: id of the entitlement group that owns it
  - is_public:      True → readable by anyone authenticated

``user`` is the auth dependency dict: {username, role, is_admin, ...}.

Decision policy:

  VIEW grants when ANY:
    - user is system admin / super admin / support (read-everything role)
    - user.is_admin is True
    - resource is_public AND user is authenticated
    - resource.created_by == user.username
    - user is a member of resource.owner_group_id (any access_level)

  EDIT grants when ANY:
    - user is system admin / super admin (write-everything)
    - user.is_admin is True
    - resource.created_by == user.username
    - user is a member of resource.owner_group_id with
      resource_access_level == 'read_write'

  Support role gets VIEW but NOT EDIT — they observe and report,
  they do not mutate.

All role names are read from config (``roles.support_role_name`` etc.)
so admins can rename them without code changes — same DB-driven
principle as the failover override.
"""
from __future__ import annotations

import logging
from typing import Any, Mapping, Optional

logger = logging.getLogger(__name__)


# ── Public constants ─────────────────────────────────────────────────


READ_ONLY  = "read_only"
READ_WRITE = "read_write"
VALID_ACCESS_LEVELS = (READ_ONLY, READ_WRITE)


# ── Role helpers ─────────────────────────────────────────────────────


def _support_role_name() -> str:
    """Configurable name for the 'support' role.  Defaults to 'support'
    but admins can rename via the ``roles.support_role_name`` config /
    system_setting."""
    try:
        from core.config import roles as _roles_cfg
        return str(getattr(_roles_cfg, "support_role_name", "support") or "support").lower()
    except Exception:
        return "support"


def _user_role(user: Mapping[str, Any]) -> str:
    return str(user.get("role", "") or "").lower()


def is_support(user: Mapping[str, Any]) -> bool:
    """True when the user holds the configurable 'support' role.  The
    support role is read-only-everywhere: they see every resource but
    cannot mutate.  Useful for L1/L2 support staff."""
    return _user_role(user) == _support_role_name()


def is_admin_like(user: Mapping[str, Any]) -> bool:
    """Mirror of core.roles.is_admin_like — admin / super_admin role
    OR is_admin=True boolean flag.  Inlined here to avoid an import
    cycle with core.roles which depends on us in future."""
    try:
        from core.roles import is_admin_like as _imp
        return bool(_imp(user))
    except Exception:
        # Fallback: same logic the canonical helper uses.
        role = _user_role(user)
        return role in ("admin", "super_admin") or bool(user.get("is_admin"))


# ── Group membership lookup ──────────────────────────────────────────


def _resolve_db(db):
    if db is not None:
        return db
    # Fall back to the singleton accessor — main.py wires this up at
    # startup.  Tests inject explicitly.
    try:
        from core.database import get_db_manager
        return get_db_manager()
    except Exception:
        return None


def _membership(db, group_id: Optional[int], username: str) -> Optional[dict]:
    """Return the user_group_members row for (group_id, username) or
    None.  Tolerates partial DB stubs: when ``list_user_group_members``
    isn't a real list (test mocks, legacy callers), falls back to
    ``is_user_in_group`` and returns a synthetic row with the default
    ``resource_access_level='read_write'`` — same backwards-compat
    semantic as the schema default."""
    if not group_id or not username or db is None:
        return None
    try:
        members = db.list_user_group_members(group_id)
    except Exception as exc:
        logger.debug("entitlements: membership lookup failed: %s", exc)
        members = None
    # Normal path: iterate the real list.
    if isinstance(members, list):
        for m in members:
            if isinstance(m, dict) and str(m.get("username", "")).lower() == username.lower():
                return m
        return None
    # Stub path: fall back to the cheaper presence check.  Returning a
    # synthetic row with read_write keeps pre-hotfix-13 callers (whose
    # tests only mock is_user_in_group) working — every member used to
    # be full-access, and that's what read_write encodes.
    try:
        if hasattr(db, "is_user_in_group") and db.is_user_in_group(username, int(group_id)):
            return {"username": username, "resource_access_level": "read_write"}
    except Exception as exc:
        logger.debug("entitlements: is_user_in_group fallback failed: %s", exc)
    return None


# ── Public API ───────────────────────────────────────────────────────


def can_view(resource: Mapping[str, Any], user: Mapping[str, Any],
             *, db=None) -> bool:
    """Read authority for any resource with optional ``created_by`` +
    ``owner_group_id`` + ``is_public``."""
    if not resource or not user:
        return False
    if is_admin_like(user) or is_support(user):
        return True
    username = str(user.get("username", "") or "")
    if not username:
        return False
    # Public resource → any authenticated user reads.
    if resource.get("is_public"):
        return True
    # Owner.
    if str(resource.get("created_by", "") or "").lower() == username.lower():
        return True
    # Group member (any access level).
    db = _resolve_db(db)
    m = _membership(db, resource.get("owner_group_id"), username)
    return m is not None


def can_edit(resource: Mapping[str, Any], user: Mapping[str, Any],
             *, db=None) -> bool:
    """Write authority for any resource with optional ``created_by`` +
    ``owner_group_id``.  Support role gets NO edit access — that's
    deliberate and the whole point of the role.  is_public does NOT
    grant edit (that's a viewership flag)."""
    if not resource or not user:
        return False
    if is_admin_like(user):
        return True
    if is_support(user):
        return False  # support is observe-only
    username = str(user.get("username", "") or "")
    if not username:
        return False
    if str(resource.get("created_by", "") or "").lower() == username.lower():
        return True
    db = _resolve_db(db)
    m = _membership(db, resource.get("owner_group_id"), username)
    if m is None:
        return False
    return str(m.get("resource_access_level", "read_write")).lower() == READ_WRITE


# ── Dataset adapters (2026-08-09 dataset self-service) ───────────────
#
# BusinessDataset stores its creator in ``owner`` (not ``created_by``)
# and its share flag in ``is_published`` (not ``is_public``).  These two
# thin normalizers map that shape onto the ONE resolver above so the
# semantic layer reuses the exact policy business reports / feeds
# already trust — never a second drifting implementation.
#
#   view: admin/support, published, owner, owner-group member
#   edit: admin, owner, owner-group member with read_write
#         (support = observe-only; is_published grants NO edit)


def _dataset_as_resource(dataset: Mapping[str, Any]) -> dict:
    return {
        "created_by":     dataset.get("owner"),
        "owner_group_id": dataset.get("owner_group_id"),
        "is_public":      bool(dataset.get("is_published")),
    }


def dataset_can_view(dataset: Mapping[str, Any], user: Mapping[str, Any],
                     *, db=None) -> bool:
    """Read authority for a BusinessDataset dict.  Fail-closed."""
    if not dataset:
        return False
    try:
        return can_view(_dataset_as_resource(dataset), user, db=db)
    except Exception as exc:
        logger.warning("entitlements: dataset_can_view fail-CLOSED for "
                       "dataset=%s: %s", dataset.get("id"), exc)
        return False


def dataset_can_edit(dataset: Mapping[str, Any], user: Mapping[str, Any],
                     *, db=None) -> bool:
    """Write authority for a BusinessDataset dict.  Fail-closed."""
    if not dataset:
        return False
    try:
        return can_edit(_dataset_as_resource(dataset), user, db=db)
    except Exception as exc:
        logger.warning("entitlements: dataset_can_edit fail-CLOSED for "
                       "dataset=%s: %s", dataset.get("id"), exc)
        return False


# ── Convenience: explain WHY a decision was made (audit + UI) ────────


def explain(resource: Mapping[str, Any], user: Mapping[str, Any],
            action: str = "view", *, db=None) -> dict:
    """Return a dict explaining the decision and the reason.  Useful
    for tooltips ("you can see this because you're in group X") and
    for audit logs ("user Y denied because read_only in group Z")."""
    if action not in ("view", "edit"):
        raise ValueError("action must be 'view' or 'edit'")
    if is_admin_like(user):
        return {"granted": True, "reason": "admin"}
    if is_support(user):
        return {"granted": action == "view", "reason": "support_role_observe_only"}
    username = str(user.get("username", "") or "")
    if not username:
        return {"granted": False, "reason": "anonymous"}
    if action == "view" and resource.get("is_public"):
        return {"granted": True, "reason": "is_public"}
    if str(resource.get("created_by", "") or "").lower() == username.lower():
        return {"granted": True, "reason": "creator"}
    db = _resolve_db(db)
    gid = resource.get("owner_group_id")
    m = _membership(db, gid, username)
    if m is None:
        return {"granted": False, "reason": "not_creator_not_group_member"}
    level = str(m.get("resource_access_level", "read_write")).lower()
    if action == "view":
        return {"granted": True, "reason": f"group_member({level})", "group_id": gid}
    # action == 'edit'
    if level == READ_WRITE:
        return {"granted": True, "reason": "group_member(read_write)", "group_id": gid}
    return {"granted": False, "reason": "group_member(read_only)", "group_id": gid}


# ── Connection entitlement (THE leak gate decision) ──────────────────
#
# 2026-08-23: extracted from api.datasets_api._assert_connection_entitlement
# so a second surface (Data Quality rules, which execute SQL against a
# connection_id from rule config) resolves the SAME fact through the SAME
# decision instead of growing a twin.  The API layers keep their own
# HTTP mapping (403); this function is pure decision.


def denied_connection_ids(user: Mapping[str, Any],
                          connection_ids,
                          *, db=None) -> list:
    """Return the subset of ``connection_ids`` the user may NOT use.

    Empty list == fully entitled.  Mirrors the visibility rule of
    ``GET /api/connections``: a non-admin may use a connection when it is
    (a) their own (created_by == username), (b) shared (is_shared),
    (c) legacy-unowned (no created_by), or (d) explicitly ACL-granted
    (Phase 102-E, when admin_governance is enabled).  Any lookup failure,
    missing connection, or unmatched rule → DENIED for that id
    (fail-closed).
    """
    ids = [c for c in (connection_ids or []) if c is not None]
    if not ids:
        return []
    if is_admin_like(user):
        return []
    db = _resolve_db(db)
    username = str((user or {}).get("username", "") or "")
    if not username or db is None:
        return list(ids)
    acl_ids: set = set()
    try:
        from core.config import admin_governance as _gov
        if _gov.enabled:
            acl_ids = set(db.list_connection_ids_for_user(
                username, roles=[(user or {}).get("role", "viewer")]) or [])
    except Exception as exc:
        # Fail-closed for THIS source only: a broken ACL lookup shrinks
        # entitlement (own/shared/legacy still grant), never widens it.
        logger.warning("connection ACL lookup failed for %s (fail-closed): %s",
                       username, exc)
        acl_ids = set()
    denied = []
    for cid in ids:
        try:
            conn = db.get_connection(int(cid))
        except Exception as exc:
            logger.warning("connection %s entitlement lookup failed "
                           "(fail-closed): %s", cid, exc)
            conn = None
        allowed = bool(conn) and (
            (conn.get("created_by") or "") == username
            or bool(conn.get("is_shared"))
            or not conn.get("created_by")   # legacy connections (no owner)
            or int(cid) in acl_ids          # explicit ACL grant
        )
        if not allowed:
            denied.append(cid)
    return denied
