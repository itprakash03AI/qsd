"""How long a download stays in the Download Centre.

2026-08-22.  ``storage.downloads_expiry_days`` was a GHOST KNOB: declared with
a default of 7, surfaced in the admin UI, and read by exactly one place —
admin_api, echoing it straight back to that UI.  All twelve writers of a
download record hardcoded their own ``timedelta(days=7)`` or
``timedelta(days=1)``.  So the retention the operator set, and the retention
the settings screen promised, was never the retention enforced.  Lowering it
to satisfy a data-retention policy changed nothing at all.

Same shape as ``max_downloads_size_mb`` (which IS enforced, by the scheduler)
sitting next to it in the same config section — the pair is what makes the
gap invisible: one of the two storage knobs works.

TRANSIENT downloads keep their shorter life.  A handful of records —
stale-result fallbacks, partial-failure salvage — are deliberately kept for a
day rather than a week, and folding them onto the same number would silently
extend them.  They take ``min(configured, 1 day)`` instead, so the operator's
knob can still SHORTEN them (which is what a retention policy needs) but
raising the general TTL does not resurrect what was meant to be temporary.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

logger = logging.getLogger(__name__)

_DEFAULT_DAYS = 7
_TRANSIENT_DAYS = 1


def download_retention_days(transient: bool = False) -> int:
    """Configured retention in days.  Never returns < 1."""
    days = _DEFAULT_DAYS
    try:
        from core.config import get as _get
        raw = _get("storage", "downloads_expiry_days", _DEFAULT_DAYS)
        days = int(raw)
    except Exception as exc:
        logger.debug("[downloads] retention unreadable, using %d days: %s",
                     _DEFAULT_DAYS, exc)
        days = _DEFAULT_DAYS
    if days <= 0:
        # Unlike a row cap, 0 here cannot mean "unlimited": these are files on
        # a disk with a byte quota above them, and a never-expiring download
        # is how the quota eviction ends up destroying data instead.  Treat it
        # as "the shortest retention we support" and say so.
        logger.info("[downloads] storage.downloads_expiry_days=%r — a "
                    "download that never expires is not a retention policy; "
                    "using 1 day.", days)
        days = 1
    if transient:
        return min(days, _TRANSIENT_DAYS)
    return days


def download_expires_at(transient: bool = False) -> datetime:
    """UTC timestamp at which a download record should expire."""
    return datetime.now(timezone.utc) + timedelta(
        days=download_retention_days(transient=transient))


_SERVE_OK_STATUS = "available"


def download_refusal(record) -> "str | None":
    """Why this download must not be served, or ``None`` to serve it.

    2026-08-30 — READ-TIME enforcement of retention, and one rule for two
    routes that disagreed.  Measured before the change:

        SERVED       data_grid /download   <- retention LAPSED, status 'available'
        SERVED       queries   by-id       <- retention LAPSED, status 'available'
        SERVED       data_grid /download   <- status='expired'
        refused 410  queries   by-id       <- status='expired'
        SERVED       data_grid /download   <- status='deleted', file on disk
        refused 410  queries   by-id       <- status='deleted', file on disk

    Two defects in one shape.  ``expires_at`` was acted on ONLY by the
    scheduler's cleanup sweep, which flips ``status`` to 'expired': on a pod
    layout where no scheduler runs (``QS_POD_ROLE=api``,
    ``scheduler.mode=external``) — or simply between sweeps — a download
    stayed available forever past the retention its requester chose.  A
    retention that a daemon can silently switch off is not a retention
    policy, and this module exists because the last knob in this area had
    exactly that defect.

    And the two routes that hand over the bytes enforced different rules, so
    the by-id route's 410 was reachable around: ``/api/downloads/{id}``
    refused every non-available row while ``/api/downloads/{id}/download``
    checked nothing at all.

    Reasons are returned rather than raised so the module stays free of HTTP
    types; both callers map a reason to 410 GONE.
    """
    if not record:
        return None  # not-found is the caller's existing 404 path
    status = (record.get("status") or _SERVE_OK_STATUS)
    if status != _SERVE_OK_STATUS:
        return f"File is no longer available (status={status})"
    if download_has_lapsed(record.get("expires_at")):
        return ("File has passed its retention period and is no longer "
                "available")
    return None


def download_has_lapsed(expires_at) -> bool:
    """True only when the expiry moment is READABLE and has passed.

    An absent or unparseable timestamp returns False: retention is a
    reclamation policy, and an unreadable value must not make a live download
    vanish.  That is a cap, not a gate — the sweep still reclaims the file.
    Naive timestamps are read as UTC, which is what every writer stores.
    """
    if not expires_at:
        return False
    dt = expires_at
    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt.replace("Z", "+00:00"))
        except ValueError:
            logger.debug("[downloads] unparseable expires_at %r — not "
                         "treating it as expired", expires_at)
            return False
    if not isinstance(dt, datetime):
        return False
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return datetime.now(timezone.utc) > dt


# ── Requester-chosen retention ──────────────────────────────────────────
#
# A requester may ask to keep a download longer (or shorter) than the
# operator default: the export routes accept ``?retain_days=`` and the
# Download Centre lets an owner change it after the fact.  The RULE lives
# here, with both callers delegating, because it is one rule -- and this
# session's dominant defect was a rule spelled in two places that drifted.

#: Fallback operator ceiling when ``storage.downloads_retain_max_days`` is
#: not configured.
RETAIN_MAX_FALLBACK_DAYS = 30


class RetentionRefused(ValueError):
    """A requested retention that must be refused LOUDLY, carrying the reason.

    A ValueError rather than an HTTPException so this module stays free of
    web types; every caller maps it to 400 with ``str(exc)`` as the detail.
    """


def retention_max_days() -> int:
    """Operator ceiling (days) for a requester-chosen retention.

    Read from ``storage.downloads_retain_max_days``; an unset / broken /
    non-positive value falls back to :data:`RETAIN_MAX_FALLBACK_DAYS`.  A
    non-positive maximum is refused the same way a non-positive TTL is: an
    unbounded retention ceiling is not a retention policy.
    """
    try:
        from core.config import get as _get
        raw = int(_get("storage", "downloads_retain_max_days",
                       RETAIN_MAX_FALLBACK_DAYS))
    except Exception as exc:
        logger.debug("[downloads] retain-max unreadable, using %d days: %s",
                     RETAIN_MAX_FALLBACK_DAYS, exc)
        return RETAIN_MAX_FALLBACK_DAYS
    return raw if raw >= 1 else RETAIN_MAX_FALLBACK_DAYS


def validated_retention_days(retain_days) -> "int | None":
    """``None`` when not supplied; otherwise ``1..retention_max_days()``.

    Raises :class:`RetentionRefused` for anything else.  In particular an
    explicit ``0`` must never silently mean "keep forever": the ``x or
    default`` fold is this product's signature defect class, and a
    never-expiring download under a disk quota destroys data by eviction
    instead of by policy.
    """
    if retain_days is None or not isinstance(retain_days, int):
        # Not supplied.  The isinstance guard also covers DIRECT invocation
        # of a route function (tests/tools) where FastAPI's Query default
        # object itself arrives here -- that is "not supplied" too, never a
        # value to coerce.
        return None
    days = int(retain_days)
    if days <= 0:
        raise RetentionRefused(
            "retain_days must be >= 1. An explicit 0 does not mean "
            "'keep forever' — omit the parameter to use the "
            "operator-configured default retention.")
    max_days = retention_max_days()
    if days > max_days:
        raise RetentionRefused(
            f"retain_days={days} exceeds the operator maximum of "
            f"{max_days} days (storage.downloads_retain_max_days).")
    return days


def expires_at_for(retain_days) -> datetime:
    """Expiry for a requester-chosen retention; unsupplied → the default."""
    days = validated_retention_days(retain_days)
    if days is None:
        return download_expires_at()
    return datetime.now(timezone.utc) + timedelta(days=days)


# ── Reclamation: ONE owner, declared ────────────────────────────────────

_CLEANUP_OWNER_SCHEDULER = "scheduler"
_CLEANUP_OWNER_DOWNLOADS = "downloads"
_CLEANUP_OWNERS = (_CLEANUP_OWNER_SCHEDULER, _CLEANUP_OWNER_DOWNLOADS)


def downloads_cleanup_owner() -> str:
    """Which pod reclaims expired downloads.

    2026-08-30.  Reclamation used to live inside the scheduler's
    ``_cleanup_temp_files``, mixed in with orphaned-execution-artifact
    cleanup.  Splitting the Download Centre onto its own pod made that a
    question with a wrong answer available: run it on BOTH (two pods doing
    half a job each) or on NEITHER (files accumulate until the disk quota
    evicts them, which destroys data by accident instead of by policy).

    So the owner is DECLARED, and exactly one pod acts on it:

      "scheduler"  — the historical owner; the default, so nothing changes
                     for a deployment that has not split the pod out.
      "downloads"  — the Download Centre pod retires the files it serves,
                     and the scheduler logs that it is skipping them.

    An unrecognised value falls back to ``"scheduler"`` rather than to
    nobody: a typo must cost the split, never the reclamation.  Both charts
    read this key from their own ConfigMap, so they have to agree — the
    values files say so on both sides.
    """
    try:
        from core.config import get as _get
        raw = str(_get("storage", "downloads_cleanup_owner",
                       _CLEANUP_OWNER_SCHEDULER) or "").strip().lower()
    except Exception as exc:
        logger.debug("[downloads] cleanup owner unreadable, using %s: %s",
                     _CLEANUP_OWNER_SCHEDULER, exc)
        return _CLEANUP_OWNER_SCHEDULER
    if raw not in _CLEANUP_OWNERS:
        if raw:
            logger.warning(
                "[downloads] storage.downloads_cleanup_owner=%r is not one of "
                "%s — falling back to %s so reclamation still happens",
                raw, list(_CLEANUP_OWNERS), _CLEANUP_OWNER_SCHEDULER)
        return _CLEANUP_OWNER_SCHEDULER
    return raw


#: Rows retired per sweep.  A module constant rather than a literal so the
#: backlog branch below is reachable in a test without fabricating 10,000
#: rows -- a guard that can only fire in production is a guard nobody has
#: ever seen work.
_RECLAIM_PAGE = 10000


def reclaim_downloads(db) -> dict:
    """Retire downloads whose retention has lapsed.  Returns counts.

    The Download-Centre half of what used to be one mixed cleanup job:
    mark lapsed rows expired, unlink the files behind expired rows, and mark
    rows whose file has vanished as deleted.  Orphaned EXECUTION artifacts —
    files never registered here at all — are a different pod's business and
    stay with the scheduler.

    Every step is independently guarded: a single unreadable row or an
    already-deleted file must not abort the sweep and leave the rest of the
    disk uncollected.
    """
    from pathlib import Path

    unlinked = ghosts = expired = retired = 0
    if db is None:
        return {"expired": 0, "unlinked": 0, "ghosts": 0, "retired": 0}

    try:
        expired = int(db.mark_expired_downloads() or 0)
    except Exception as exc:
        logger.warning("[downloads] mark_expired_downloads failed: %s", exc,
                       exc_info=True)

    try:
        batch = db.list_download_files(status="expired",
                                       limit=_RECLAIM_PAGE,
                                       offset=0) or []
        for rec in batch:
            fp = Path(rec.get("file_path", "") or "")
            gone = True
            if fp.exists():
                try:
                    fp.unlink()
                    unlinked += 1
                except OSError as exc:
                    gone = False
                    logger.debug("[downloads] unlink %s failed: %s", fp, exc)
            if gone:
                # Retire the ROW once its file is gone.  Without this the
                # row stays status="expired" forever and keeps occupying
                # the page above, which is ordered created_at DESC and
                # capped: past _PAGE expired rows the sweep re-walks the
                # NEWEST ones (already reclaimed, nothing to do) and the
                # OLDEST files are never deleted at all.  Marking them
                # drains the backlog a page per pass and makes the status
                # true — "deleted" is what the ghost scan below already
                # means by "the file is not there".
                try:
                    db.update_download_file(rec["file_id"], status="deleted")
                    retired += 1
                except Exception as exc:
                    logger.debug("[downloads] retire %s failed: %s",
                                 rec.get("file_id"), exc)
        if len(batch) >= _RECLAIM_PAGE:
            # A full page means there is more behind it.  Say so: a sweep
            # that is permanently behind looks exactly like a quiet one.
            logger.warning(
                "[downloads] expired backlog exceeds one pass (%d rows "
                "reclaimed, more remain) — the next sweep continues",
                len(batch))
    except Exception as exc:
        logger.warning("[downloads] expired-file sweep failed: %s", exc,
                       exc_info=True)

    try:
        for rec in (db.list_download_files(status="available", limit=10000,
                                           offset=0) or []):
            fp = Path(rec.get("file_path", "") or "")
            if rec.get("file_path") and not fp.exists():
                try:
                    db.update_download_file(rec["file_id"], status="deleted")
                    ghosts += 1
                except Exception as exc:
                    logger.debug("[downloads] ghost cleanup failed: %s", exc)
    except Exception as exc:
        logger.warning("[downloads] ghost scan failed: %s", exc, exc_info=True)

    if expired or unlinked or ghosts:
        logger.info("[downloads] reclaimed: %d expired, %d file(s) unlinked, "
                    "%d ghost row(s)", expired, unlinked, ghosts)
    return {"expired": expired, "unlinked": unlinked, "ghosts": ghosts,
            "retired": retired}
