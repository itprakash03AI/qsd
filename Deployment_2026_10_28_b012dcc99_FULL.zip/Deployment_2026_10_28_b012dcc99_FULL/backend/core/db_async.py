"""
Async DB call wrapper — offload sync DB methods to a thread so they
don't block the asyncio event loop.

WHY: With PostgreSQL (network-attached) every DB call costs 5-50 ms.
Inside an async route handler, that means 5-50 ms of blocked event loop
per call — which starves WebSocket heartbeats, long-poll handlers, and
every other coroutine on the same loop.  With SQLite (in-process) the
hit was small enough to ignore; with PG it isn't.

USAGE in async route handlers:
    from core.db_async import adb

    # Instead of:
    rec = _db_manager.get_connection_raw(cid)

    # Write:
    rec = await adb(_db_manager.get_connection_raw, cid)

For DB calls inside SYNC functions that are themselves run in a thread
executor (e.g. `def _do(): ...` then `await asyncio.to_thread(_do)`),
no wrapping is needed — the whole `_do` already runs off-loop.
"""
from __future__ import annotations

import asyncio
from typing import Any, Callable, TypeVar

T = TypeVar("T")


async def adb(fn: Callable[..., T], *args: Any, **kwargs: Any) -> T:
    """Run a synchronous DB call on the default thread executor.

    Identical to ``await asyncio.to_thread(fn, *args, **kwargs)`` but
    aliased here so call sites are uniform across the codebase and a
    future change (e.g. dedicated DB executor pool) only needs to land
    in one place.
    """
    return await asyncio.to_thread(fn, *args, **kwargs)
