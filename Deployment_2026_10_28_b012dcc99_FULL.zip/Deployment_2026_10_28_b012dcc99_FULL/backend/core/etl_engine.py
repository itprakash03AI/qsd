"""
ETL Pipeline Engine — Phase 127.

Orchestrates ETL pipeline execution: smart routing to DuckDB/Spark/Airflow,
circuit breaker fallback chain, post-completion hooks (cache invalidation,
DQ checks, SLA alerting, dependency triggering, lineage updates).

Module-level injection pattern (same as feed_engine.py).
"""
import asyncio
import base64
import json
import logging
import re
import threading
import time
import uuid
from datetime import datetime, timezone
from typing import Callable, Optional

from core.db_async import adb
from core.http_utils import http_request

logger = logging.getLogger(__name__)

# Pre-compiled SLA time regex — HH:MM or HH:MM:SS (Phase 132 deep-dive)
_SLA_TIME_RE = re.compile(r'^([01]\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?$')

# ── Module-level references (injected at startup) ─────────────────────────
_db_manager = None
_broadcast_fn: Optional[Callable] = None
_cfg = None          # _EtlPipelinesCfg accessor
_airflow_cfg = None  # feed_generation.airflow for base_url/auth reuse

#: DECLARED (2026-10-08): this module's db handle is PROCESS-LOCAL by design
#: and is NOT routed through ``core.database.resolve_db_manager``.  An
#: api-only pod must not run ETL pipelines (main.py calls init_etl_engine
#: only where pod_role allows "etl_pipelines"), so "unbound" here MEANS
#: "this pod does not run them" and every route-reachable entry refuses
#: through ``_require_engine`` WITH that reason (EtlEngineNotInitialised ->
#: a 503 in etl_pipeline_api) rather than silently running on the
#: process-wide manager.  The sweep guard
#: (tests/test_db_handle_one_accessor_2026_10_08.py) accepts a bare read
#: only behind this declaration, and checks the named gate exists, compares
#: the handle to None and raises.
PROCESS_LOCAL_DB_HANDLE = {
    "handle": "_db_manager",
    "gate": "_require_engine",
    "why": ("ETL pipelines run only where init_etl_engine ran; a pod that "
            "did not run it refuses with the reason instead of running "
            "pipelines on the process-wide manager"),
}

# Circuit breakers — one per execution backend
_airflow_breaker = None
_spark_connect_breaker = None   # Spark Connect (zero-download distributed)
_spark_submit_breaker = None
_native_breaker = None

# Concurrency control for native DuckDB execution
_native_sem: Optional[threading.Semaphore] = None
# BF-582 (2026-05-29): tracked in-flight counter — replaces the
# ``_native_sem._value`` CPython introspection used by
# ``get_etl_engine_stats``.  Reading a private slot was brittle
# (could break on future Python versions); maintain our own counter
# alongside the semaphore acquire/release pairs.
_native_inflight: int = 0
_native_inflight_lock = threading.Lock()


# ── Shared _SimpleBreaker (same as feed_engine.py) ────────────────────────

def _sem_permits(configured, *, name: str) -> int:
    """Permit count for a concurrency semaphore, honouring 0 = UNLIMITED.

    2026-08-22 — delegates to core.concurrency_permits, the single definition.
    This was one of THREE private copies; the audit found the two semaphore
    constructors that never got the fix (published_views/warmup, graphql_api),
    which is what a copied fix always ends up costing.
    """
    from core.concurrency_permits import sem_permits as _sp
    return _sp(configured, name=name)


class _SimpleBreaker:
    """Minimal circuit breaker for external ETL backends."""

    def __init__(self, name: str, threshold: int = 3, cooldown: int = 60):
        self.name = name
        self.threshold = threshold
        self.cooldown = cooldown
        self._failures = 0
        self._last_failure = 0.0
        self._state = "closed"  # closed | open | half_open
        self._lock = threading.Lock()

    @property
    def is_open(self) -> bool:
        with self._lock:
            if self._state == "open":
                if time.time() - self._last_failure > self.cooldown:
                    self._state = "half_open"
                    return False
                return True
            return False

    def record_success(self):
        with self._lock:
            self._failures = 0
            self._state = "closed"

    def record_failure(self):
        with self._lock:
            self._failures += 1
            self._last_failure = time.time()
            if self._failures >= self.threshold:
                self._state = "open"
                logger.warning(
                    "[etl_engine] Circuit breaker OPEN for %s after %d failures",
                    self.name, self._failures,
                )

    def reset(self):
        with self._lock:
            self._failures = 0
            self._state = "closed"
            self._last_failure = 0.0

    def to_dict(self) -> dict:
        with self._lock:
            return {
                "name": self.name,
                "state": self._state,
                "failures": self._failures,
                "threshold": self.threshold,
                "cooldown": self.cooldown,
            }


# ── Initialization ────────────────────────────────────────────────────────

class EtlEngineNotInitialised(RuntimeError):
    """The ETL engine has no database on THIS pod.

    FB-34 (2026-09-19): ``POST /api/etl-pipelines/{id}/trigger`` returned
    ``500 "'NoneType' object has no attribute 'get_etl_pipeline'"`` for every
    id.  ``init_etl_engine`` is only called by main.py when
    ``etl_pipelines.enabled`` is true AND the pod role runs ETL, but the
    router is mounted on every pod -- so the route could not work, for any
    input, wherever the engine was not wired.  Same family as the 2026-09-01
    worker pod that never called ``init_persistence``: a wiring step nothing
    executes and no test notices.  The API maps this to a 503 that says
    which of the two conditions is unmet.
    """


def _require_engine() -> None:
    """Refuse -- with the reason -- before dereferencing ``_db_manager``."""
    if _db_manager is not None:
        return
    try:
        from core.config import etl_pipelines as _ep
        _enabled = bool(_ep.enabled)
    except Exception:                                    # noqa: BLE001
        _enabled = None
    if _enabled is False:
        why = ("etl_pipelines.enabled=false on this deployment -- enable it in "
               "config and restart the API")
    elif _enabled is True:
        why = ("this pod's role does not run ETL pipelines (init_etl_engine is "
               "only called where pod_role allows 'etl_pipelines'); send the "
               "request to a scheduler/worker pod")
    else:
        why = "the etl_pipelines config section could not be read"
    raise EtlEngineNotInitialised(
        f"ETL pipelines are not initialised on this pod: {why}.")


def init_etl_engine(db_manager, broadcast_fn=None):
    """Called from main.py _startup() when etl_pipelines.enabled is True."""
    global _db_manager, _broadcast_fn, _cfg, _airflow_cfg
    global _airflow_breaker, _spark_connect_breaker, _spark_submit_breaker, _native_breaker, _native_sem

    _db_manager = db_manager
    _broadcast_fn = broadcast_fn

    from core.config import etl_pipelines as ep_cfg
    _cfg = ep_cfg

    from core.config import feed_generation as fg_cfg
    _airflow_cfg = fg_cfg.airflow

    # Circuit breaker thresholds from spark_connect config when available
    try:
        from core.config import spark_connect as _sc
        _sc_threshold = _sc.circuit_breaker_failure_threshold
        _sc_cooldown  = _sc.circuit_breaker_cooldown_seconds
    except Exception:
        _sc_threshold, _sc_cooldown = 3, 120

    _airflow_breaker        = _SimpleBreaker("airflow",         threshold=3,            cooldown=120)
    _spark_connect_breaker  = _SimpleBreaker("spark_connect",   threshold=_sc_threshold, cooldown=_sc_cooldown)
    _spark_submit_breaker   = _SimpleBreaker("spark_submit",    threshold=3,            cooldown=60)
    _native_breaker         = _SimpleBreaker("native",          threshold=5,            cooldown=30)
# 2026-08-20 -- A ZERO-PERMIT SEMAPHORE IS AN OUTAGE, NOT A LIMIT.
    # These accessors are raw int(get(...)) with no clamp, so a configured
    # 0 -- which everywhere else in this product spells UNLIMITED, including
    # published_views.max_concurrent_per_key in this very module --
    # constructed a semaphore that can never be acquired:
    #   ETL  : threading acquire() with NO timeout -> hangs FOREVER, silently
    #   feed : acquire(timeout=300)                -> total outage after 300s
    #   PV   : asyncio.Semaphore(0) is TRUTHY, so it passes the readiness
    #          guard, then every request burns 30s and 429s
    # _sem_permits treats <=0 as 'no limit' so the operator's spelling means
    # what it means everywhere else.
    _native_sem = threading.Semaphore(
        _sem_permits(_cfg.max_concurrent_pipelines, name='etl_engine'))

    logger.info(
        "[etl_engine] Initialised — max_concurrent=%d, native_max=%d, spark_max=%d",
        _cfg.max_concurrent_pipelines,
        _cfg.size_thresholds.native_max_rows,
        _cfg.size_thresholds.spark_submit_max_rows,
    )


def get_etl_engine_stats() -> dict:
    """Return ETL engine capacity stats for health endpoint (Phase 132-I).

    BF-582: replaced ``_native_sem._value`` introspection (CPython
    private slot) with the maintained ``_native_inflight`` counter."""
    cap = _cfg.max_concurrent_pipelines if _cfg else 0
    with _native_inflight_lock:
        used = _native_inflight
    available = max(0, cap - used)
    return {
        "native_slots": {
            "max":       cap,
            "inflight":  used,
            "available": available,
        },
        "cluster_cap": {
            "max": _cfg.max_concurrent_pipelines_cluster if _cfg else 0,
            "current_running": _cluster_inflight_count(),
        },
        "circuit_breakers": get_circuit_breaker_status(),
    }


def _cluster_inflight_count() -> int:
    """BF-582: count running+pending etl executions cluster-wide via DB.

    Used by the cluster concurrency gate (``_check_cluster_capacity``).
    Returns ``-1`` when the count is INDETERMINATE — caller treats
    that as "skip the cap" rather than enforcing it on bad data.
    Real DB count returns 0 or higher; -1 is the sentinel.

    Indeterminate cases:
      * ``_db_manager`` not wired (fresh start, test harness)
      * Both lookup methods missing
      * Both lookup methods raised non-AttributeError
    """
    if not _db_manager:
        return -1
    # Prefer the dedicated db_manager method when it exists.
    _count_fn = getattr(_db_manager, "count_running_pipeline_executions", None)
    if callable(_count_fn):
        try:
            result = _count_fn()
            # Reject MagicMock / non-int returns — sentinel out.
            if isinstance(result, bool) or not isinstance(result, int):
                return -1
            return max(0, result)
        except Exception as exc:
            logger.debug("[etl_engine] cluster inflight count failed: %s", exc)
            return -1
    # Fall back to raw SQL via execute_scalar if available.
    _exec_fn = getattr(_db_manager, "execute_scalar", None)
    if callable(_exec_fn):
        try:
            result = _exec_fn(
                "SELECT COUNT(*) FROM etl_pipeline_executions "
                "WHERE status IN ('pending', 'submitted', 'running')"
            )
            if isinstance(result, bool) or not isinstance(result, int):
                return -1
            return max(0, result)
        except Exception:
            return -1
    return -1  # neither method available


def _check_cluster_capacity() -> Optional[str]:
    """BF-582: cluster-wide cap.  Returns None when under cap or
    when the check is indeterminate (test mocks, missing DB
    methods, etc.).  Returns reason string only when we are
    CONFIDENT capacity is exhausted.

    Fail-open: we'd rather over-schedule than deadlock the cluster
    on a stat-lookup failure."""
    if not _cfg:
        return None
    # Pull cap from config — accept only a real int (excludes bool
    # which is a subclass of int).  MagicMock returns MagicMock for
    # attribute access; we reject anything that isn't a plain int.
    cap_raw = getattr(_cfg, "max_concurrent_pipelines_cluster", None)
    if isinstance(cap_raw, bool) or not isinstance(cap_raw, int):
        return None
    cap = cap_raw
    if cap <= 0:
        return None  # disabled
    current = _cluster_inflight_count()
    if current < 0:
        return None  # indeterminate — skip cap
    if current >= cap:
        return (
            f"cluster at capacity ({current}/{cap} running+pending). "
            "Retry once a pipeline frees a slot, or raise "
            "etl_pipelines.max_concurrent_pipelines_cluster."
        )
    return None


# ── BF-582: periodic scheduler for trigger_type=schedule pipelines ────────
#
# Before BF-582 the ETL engine had NO loop that fired scheduled pipelines.
# trigger_pipeline() was only called from (a) the manual API endpoint,
# (b) webhook completion handlers, (c) dependency cascade.  Pipelines
# configured with ``trigger_type=schedule`` + cron in trigger_config
# never fired unless Airflow drove them externally — a silent gap.
#
# This loop ticks every ``scheduler_tick_seconds`` (default 60s):
#   1. List active scheduled pipelines
#   2. For each, parse cron from trigger_config.cron_expression
#   3. Compute next-fire time from the most-recent execution
#      (or pipeline.created_at if none)
#   4. If next-fire <= now AND the cluster has capacity, trigger
#
# Idempotent: an already-running pipeline is skipped this tick.
# Fail-open: any single pipeline's error is logged and doesn't block
# the rest of the tick.


class EtlSchedulerUnreadable(RuntimeError):
    """The tick could not READ the pipeline list.  Raised, never returned
    as 0: "nothing is due" and "the list could not be read" are opposite
    findings, and the second one used to look exactly like the first.

    2026-10-08 (found while planting the Docker proof's input): the tick
    called ``list_etl_pipelines(active_only=True)`` -- the parameter is
    ``is_active`` -- so the call raised TypeError on EVERY tick since
    BF-589 (2026-05-29), the ``except`` logged it at DEBUG and returned 0,
    and no scheduled ETL pipeline had fired since.  The two DAO methods
    the rest of the tick asks for (``get_last_etl_execution``,
    ``has_inflight_etl_execution``) did not exist either; the tick's tests
    passed against a fake that had all three.  Now the real DAO has them,
    the listing uses the real parameter, and an unreadable list raises
    this, so the loop logs at ERROR and the background-job ledger records
    ``error``, not ``no_input``.
    """


async def _scheduler_tick() -> int:
    """One scheduler tick.  Returns the number of pipelines triggered.
    (2026-10-08: see :class:`EtlSchedulerUnreadable` for why this tick had
    never fired, and ``tests/test_etl_scheduler_tick_fires_2026_10_08.py``.)
    """
    if not _db_manager or not _cfg:
        return 0
    # BF-589 (2026-05-29): wrap sync DB calls in asyncio.to_thread so
    # the scheduler tick doesn't freeze the event loop.  Each call was
    # 5-50ms; with 50 pipelines × N round-trips that adds up to
    # second-level freezes the user saw as "API stutter".
    try:
        pipelines = await asyncio.to_thread(_db_manager.list_etl_pipelines, is_active=True)
    except Exception as exc:
        raise EtlSchedulerUnreadable(
            f"the pipeline list could not be read, nothing fired this tick: "
            f"{type(exc).__name__}: {exc}") from exc

    now = datetime.now(timezone.utc)
    triggered = 0
    for pipeline in pipelines or []:
        if pipeline.get("trigger_type") != "schedule":
            continue
        cron_expr = (pipeline.get("trigger_config") or {}).get("cron_expression", "")
        if not cron_expr:
            continue
        try:
            from croniter import croniter
        except ImportError:
            logger.warning(
                "[etl_engine.scheduler] croniter not available — "
                "cannot evaluate cron schedules.  Install croniter."
            )
            return triggered

        # Last execution time, or pipeline created_at, or epoch.
        try:
            # BF-589: was sync — freezes event loop.
            last_exec = await asyncio.to_thread(_db_manager.get_last_etl_execution, pipeline["id"])
            # 2026-10-08: an execution row has ``started_at``, not ``created_at``
            # (that read fell through to the PIPELINE's creation time: every
            # already-run pipeline was due on every tick).
            base = ((last_exec or {}).get("started_at") or (last_exec or {}).get("created_at")
                    or pipeline.get("created_at") or now)
            if hasattr(base, "isoformat"):
                base_dt = base
            else:
                # ISO string — parse.
                base_dt = datetime.fromisoformat(str(base).replace("Z", "+00:00"))
            if base_dt.tzinfo is None:
                base_dt = base_dt.replace(tzinfo=timezone.utc)
        except Exception as exc:
            logger.debug(
                "[etl_engine.scheduler] %s: last-exec lookup failed (%s); "
                "treating as never-run", pipeline.get("name"), exc,
            )
            base_dt = pipeline.get("created_at") or now

        try:
            next_fire = croniter(cron_expr, base_dt).get_next(datetime)
            if next_fire.tzinfo is None:
                next_fire = next_fire.replace(tzinfo=timezone.utc)
        except Exception as exc:
            logger.warning(
                "[etl_engine.scheduler] %s: invalid cron %r — %s",
                pipeline.get("name"), cron_expr, exc,
            )
            continue

        if next_fire > now:
            continue  # not due yet

        # Idempotency: skip if this pipeline already has something
        # running/pending right now.
        try:
            # BF-589: was sync.
            inflight = await asyncio.to_thread(_db_manager.has_inflight_etl_execution, pipeline["id"])
        except AttributeError:
            inflight = False  # method not present — assume safe to fire
        except Exception:
            inflight = False
        if inflight:
            logger.debug(
                "[etl_engine.scheduler] %s due but already running — skipping",
                pipeline.get("name"),
            )
            continue

        # Fire!  trigger_pipeline already does cluster-cap check internally.
        try:
            await trigger_pipeline(
                pipeline["id"],
                trigger_type="schedule",
                triggered_by="etl_scheduler",
            )
            triggered += 1
            logger.info(
                "[etl_engine.scheduler] fired pipeline %s (cron=%r next=%s)",
                pipeline.get("name"), cron_expr, next_fire.isoformat(),
            )
        except Exception as exc:
            logger.warning(
                "[etl_engine.scheduler] %s trigger failed (continuing): %s",
                pipeline.get("name"), exc,
            )
    return triggered


async def run_etl_scheduler_loop():
    """BF-582: long-running task that ticks the ETL scheduler.

    Started from main.py when ``etl_pipelines.enabled=true`` AND
    ``etl_pipelines.scheduler_tick_seconds > 0``.  Sleep-first then
    tick — gives the engine init a chance to complete before the
    first DB query."""
    if not _cfg:
        return
    tick = _cfg.scheduler_tick_seconds
    if tick <= 0:
        logger.info(
            "[etl_engine.scheduler] disabled (scheduler_tick_seconds=0)"
        )
        return
    logger.info(
        "[etl_engine.scheduler] started — tick=%ds", tick,
    )
    while True:
        try:
            await asyncio.sleep(tick)
            n = await _scheduler_tick()
            if n:
                logger.debug(
                    "[etl_engine.scheduler] tick triggered %d pipeline(s)", n,
                )
        except asyncio.CancelledError:
            logger.info("[etl_engine.scheduler] cancelled — exiting loop")
            return
        except EtlSchedulerUnreadable as exc:
            # not "nothing due": the scheduler is blind.  ERROR, and keep
            # ticking -- the next read may succeed.
            logger.error("[etl_engine.scheduler] %s", exc)
        except Exception as exc:
            logger.warning("[etl_engine.scheduler] tick error (continuing): %s", exc)


# ── Backend Selection (Smart Routing) ─────────────────────────────────────

def _pick_backend(pipeline: dict) -> str:
    """Choose execution backend based on pipeline config + estimated row count.

    Routing tiers (ascending row count):
      ≤ native_max_rows      → native (DuckDB, in-process)
      ≤ spark_connect thresh → spark_connect (zero-download, interactive)
      ≤ spark_submit_max     → spark_submit (cluster, batch)
      above all              → airflow (Airflow DAG, fully async)

    Returns one of: 'native', 'spark_connect', 'spark_submit', 'airflow'.
    Applies circuit breaker fallback chain if preferred backend is unavailable.
    """
    configured = pipeline.get("execution_backend", "auto")

    if configured != "auto":
        # Explicit backend — still check circuit breaker
        return _apply_fallback(configured, pipeline)

    # Auto-routing based on estimated row count
    estimated_rows = pipeline.get("estimated_row_count") or pipeline.get("last_row_count") or 0
    native_max  = _cfg.size_thresholds.native_max_rows
    spark_max   = _cfg.size_thresholds.spark_submit_max_rows

    # Per-pipeline overrides
    overrides = pipeline.get("size_thresholds") or {}
    if overrides.get("native_max_rows"):
        native_max = overrides["native_max_rows"]
    if overrides.get("spark_submit_max_rows"):
        spark_max = overrides["spark_submit_max_rows"]

    # spark_connect threshold: use spark_connect.row_threshold from config,
    # but cap at spark_submit_max so the tiers are always ordered.
    try:
        from core.config import spark_connect as _sc
        _sc_enabled   = _sc.enabled
        _sc_threshold = min(_sc.row_threshold, spark_max)
    except Exception:
        _sc_enabled, _sc_threshold = False, spark_max

    if estimated_rows <= native_max:
        preferred = "native"
    elif _sc_enabled and estimated_rows <= _sc_threshold:
        preferred = "spark_connect"
    elif estimated_rows <= spark_max:
        preferred = "spark_submit"
    else:
        preferred = "airflow"

    return _apply_fallback(preferred, pipeline)


def _apply_fallback(preferred: str, pipeline: dict) -> str:
    """Apply circuit breaker fallback chain.

    Degradation order: airflow → spark_connect → spark_submit → native.
    """
    breakers = {
        "airflow":         _airflow_breaker,
        "spark_connect":   _spark_connect_breaker,
        "spark_submit":    _spark_submit_breaker,
        "native":          _native_breaker,
    }
    fallback_chain = {
        "airflow":       ["spark_connect", "spark_submit", "native"],
        "spark_connect": ["spark_submit", "native", "airflow"],
        "spark_submit":  ["spark_connect", "native", "airflow"],
        "native":        ["spark_connect", "spark_submit", "airflow"],
    }

    # Explicit fallback from pipeline config
    explicit_fallback = pipeline.get("fallback_backend")

    breaker = breakers.get(preferred)
    if breaker and not breaker.is_open:
        return preferred

    # Try explicit fallback first
    if explicit_fallback:
        fb_breaker = breakers.get(explicit_fallback)
        if fb_breaker and not fb_breaker.is_open:
            logger.warning(
                "[etl_engine] %s circuit open, falling back to %s (explicit)",
                preferred, explicit_fallback,
            )
            return explicit_fallback

    # Try fallback chain
    for fb in fallback_chain.get(preferred, []):
        fb_breaker = breakers.get(fb)
        if fb_breaker and not fb_breaker.is_open:
            logger.warning(
                "[etl_engine] %s circuit open, falling back to %s",
                preferred, fb,
            )
            return fb

    # All breakers open — force native with warning
    logger.error("[etl_engine] All circuit breakers open — forcing native execution")
    return "native"


# ── Pipeline Trigger ──────────────────────────────────────────────────────

# BF-591: strong-ref set for fire-and-forget tasks (Python issue #88831).
# Both _dispatch_execution + _run_dq_checks are scheduled via
# asyncio.create_task with no caller-held reference — without this set
# CPython may GC them mid-await.
_inflight_etl_tasks: set = set()


def _track_etl_task(coro):
    """BF-591: schedule + retain strong ref + auto-discard on done."""
    _t = asyncio.create_task(coro)
    _inflight_etl_tasks.add(_t)
    _t.add_done_callback(_inflight_etl_tasks.discard)
    return _t


async def trigger_pipeline(pipeline_id: int, trigger_type: str = "manual",
                           triggered_by: str = "system") -> dict:
    """Trigger an ETL pipeline execution.

    Returns the created execution record dict.

    BF-591: every DB round-trip + the cluster-capacity check is now
    routed through ``asyncio.to_thread`` so the event loop is not
    frozen for the duration of a Postgres / SQLite call (5-50 ms each,
    compounding across the 3-4 calls per trigger).
    """
    _require_engine()                                    # FB-34
    pipeline = await asyncio.to_thread(_db_manager.get_etl_pipeline, pipeline_id)
    if not pipeline:
        raise ValueError(f"Pipeline {pipeline_id} not found")
    if not pipeline.get("is_active"):
        raise ValueError(f"Pipeline {pipeline_id} is not active")

    # BF-582: cluster-wide concurrent-pipeline cap.  Without this gate
    # a multi-pod deployment can blow past the per-pod semaphore by a
    # factor of (pod_count).  Fails open if the DB lookup itself
    # fails so a stat-system glitch doesn't deadlock all triggers.
    # BF-591: _check_cluster_capacity reads from the DB; off-loop.
    cap_reason = await asyncio.to_thread(_check_cluster_capacity)
    if cap_reason:
        logger.warning(
            "[etl_engine] BF-582 cluster cap: refusing pipeline %s — %s",
            pipeline.get("name"), cap_reason,
        )
        raise RuntimeError(f"ETL cluster capacity reached: {cap_reason}")

    execution_id = f"etl_{uuid.uuid4().hex[:16]}"
    backend = _pick_backend(pipeline)

    # Compute SLA deadline if configured — Phase 132-F: validate format first
    sla_deadline = None
    sla_time = pipeline.get("sla_deadline_time")
    if sla_time and _cfg.sla.enabled:
        if not _SLA_TIME_RE.match(sla_time):
            logger.warning(
                "[etl_engine] Invalid sla_deadline_time '%s' for pipeline %s — ignoring",
                sla_time, pipeline.get("name"),
            )
        else:
            today = datetime.now(timezone.utc).date()
            parts = sla_time.split(":")
            h, m = int(parts[0]), int(parts[1])
            s = int(parts[2]) if len(parts) > 2 else 0
            sla_deadline = datetime(today.year, today.month, today.day, h, m, s,
                                    tzinfo=timezone.utc)

    execution = await asyncio.to_thread(_db_manager.create_etl_execution, {
        "pipeline_id": pipeline_id,
        "execution_id": execution_id,
        "status": "pending",
        "trigger_type": trigger_type,
        "triggered_by": triggered_by,
        "execution_backend_used": backend,
        "processing_mode_used": pipeline.get("processing_mode", "overwrite"),
        "started_at": datetime.now(timezone.utc),
        "sla_deadline": sla_deadline,
        "sla_breached": False,
        "retry_count": 0,
    })

    _broadcast("etl_triggered", {
        "pipeline_id": pipeline_id,
        "pipeline_name": pipeline.get("name"),
        "execution_id": execution_id,
        "backend": backend,
        "trigger_type": trigger_type,
        "triggered_by": triggered_by,
    })

    # External triggers: tracking only — external system drives execution
    if trigger_type == "external":
        await asyncio.to_thread(_db_manager.update_etl_execution, execution["id"], {
            "status": "submitted",
            "execution_backend_used": "external",
        })
        logger.info(
            f"External trigger: pipeline {pipeline_id} execution {execution_id} "
            f"registered for tracking (no dispatch)"
        )
        return execution

    # BF-591: strong-ref tracked dispatch — Python issue #88831 hazard
    # was silently dropping in-flight dispatches between status=submitted
    # and the first backend call.
    _track_etl_task(_dispatch_execution(pipeline, execution, backend))

    return execution


async def _dispatch_execution(pipeline: dict, execution: dict, backend: str):
    """Dispatch execution to the chosen backend."""
    exec_db_id = execution["id"]
    execution_id = execution["execution_id"]

    try:
        # BF-591: was sync — async path now off-loops DB writes.
        await asyncio.to_thread(_db_manager.update_etl_execution,
                                exec_db_id, {"status": "submitted"})

        if backend == "airflow":
            output_path = await _execute_via_airflow(pipeline, execution)
        elif backend == "spark_submit":
            output_path = await _execute_via_spark_submit(pipeline, execution)
        else:
            output_path, native_metrics = await _execute_via_native(pipeline, execution)

        # Backend succeeded — record success in breaker
        breaker = {"airflow": _airflow_breaker, "spark_submit": _spark_submit_breaker,
                    "native": _native_breaker}.get(backend)
        if breaker:
            breaker.record_success()

        await handle_etl_completion(
            execution_id=execution_id,
            state="completed",
            output_path=output_path,
            metrics=native_metrics if backend == "native" else None,
        )
    except Exception as exc:
        logger.error("[etl_engine] Pipeline %s execution %s failed: %s",
                     pipeline.get("name"), execution_id, exc)

        # Record failure in breaker
        breaker = {"airflow": _airflow_breaker, "spark_submit": _spark_submit_breaker,
                    "native": _native_breaker}.get(backend)
        if breaker:
            breaker.record_failure()

        # Check retry
        retry_count = execution.get("retry_count", 0)
        max_retries = _cfg.dead_letter.max_retries if _cfg.dead_letter.enabled else 0
        new_status = "failed" if retry_count >= max_retries else "pending"
        if retry_count >= max_retries and _cfg.dead_letter.enabled:
            new_status = "dead_letter"

        # BF-593: was sync; this is async path's failure branch and
        # must off-load DB writes just like the success path (BF-591).
        await asyncio.to_thread(_db_manager.update_etl_execution, exec_db_id, {
            "status": new_status,
            "error_message": str(exc)[:2000],
            "error_stage": _classify_error_stage(exc),
            "completed_at": datetime.now(timezone.utc),
            "retry_count": retry_count + 1,
        })

        _broadcast("etl_failed", {
            "pipeline_id": pipeline.get("id"),
            "pipeline_name": pipeline.get("name"),
            "execution_id": execution_id,
            "error": str(exc)[:500],
            "backend": backend,
            "status": new_status,
            "triggered_by": execution.get("triggered_by", "unknown"),
        })


# ── Execution Backends ────────────────────────────────────────────────────

async def _execute_via_airflow(pipeline: dict, execution: dict) -> str:
    """Trigger Airflow DAG via REST API and wait for webhook callback.

    Returns output S3 path on success.
    """
    base_url = _airflow_cfg.base_url.rstrip("/")
    dag_id = pipeline.get("airflow_dag_id") or _cfg.default_dag_id

    exec_id = execution.get("execution_id", "")
    dag_run_id = f"etl_{exec_id}"

    conf = {
        "pipeline_id": pipeline.get("id"),
        "pipeline_name": pipeline.get("name"),
        "execution_id": exec_id,
        "source_connection_id": pipeline.get("source_connection_id"),
        "source_s3_prefix": pipeline.get("source_s3_prefix"),
        "source_file_pattern": pipeline.get("source_file_pattern"),
        "dest_s3_bucket": pipeline.get("dest_s3_bucket"),
        "dest_s3_prefix": pipeline.get("dest_s3_prefix"),
        "dest_partition_columns": pipeline.get("dest_partition_columns"),
        "transform_rules": pipeline.get("transform_rules"),
        "processing_mode": pipeline.get("processing_mode", "overwrite"),
        "merge_key_columns": pipeline.get("merge_key_columns"),
        "watermark_column": pipeline.get("watermark_column"),
        "last_watermark_value": pipeline.get("last_watermark_value"),
        "spark_driver_memory": pipeline.get("spark_driver_memory") or _cfg.spark_defaults.driver_memory,
        "spark_executor_memory": pipeline.get("spark_executor_memory") or _cfg.spark_defaults.executor_memory,
        "spark_executor_cores": pipeline.get("spark_executor_cores") or _cfg.spark_defaults.executor_cores,
        "spark_num_executors": pipeline.get("spark_num_executors") or _cfg.spark_defaults.num_executors,
        "spark_extra_conf": pipeline.get("spark_extra_conf") or _cfg.spark_defaults.spark_conf,
    }

    # 2026-10-08 -- the ONE Airflow transport (core.feed.airflow_client):
    # this engine used to spell the dagRuns URL and the auth header itself,
    # a second transport beside the feed lane's.  The conf (this pipeline's
    # own vocabulary) is unchanged; only the carriage is shared.
    from core.feed.airflow_client import AirflowClient
    client = AirflowClient(
        base_url,
        (str(_airflow_cfg.auth_type or "none"),
         str(_airflow_cfg.username or "") or None,
         str(_airflow_cfg.password or "") or None),
        timeout_seconds=60, transport=http_request)
    await asyncio.to_thread(client.trigger_dag, dag_id, dag_run_id, conf)

    # BF-599h (2026-05-31): wrap sync DB write in adb — otherwise the
    # await above thaws the event loop and this next sync call freezes
    # it again on the pool's connection-pool grab.
    await adb(_db_manager.update_etl_execution, execution["id"], {
        "status": "running",
        "airflow_dag_run_id": dag_run_id,
        "airflow_dag_id": dag_id,
    })

    # Poll for completion (Spark job POSTs webhook, but we poll as safety net)
    poll_interval = 15
    poll_timeout = 7200  # 2 hours max
    deadline = time.time() + poll_timeout

    while time.time() < deadline:
        await asyncio.sleep(poll_interval)
        state = (await asyncio.to_thread(
            client.get_dag_run, dag_id, dag_run_id)).state

        if state == "success":
            dest_prefix = pipeline.get("dest_s3_prefix", "")
            dest_bucket = pipeline.get("dest_s3_bucket", "")
            return f"s3://{dest_bucket}/{dest_prefix}"
        elif state in ("failed", "upstream_failed"):
            raise RuntimeError(f"Airflow DAG {dag_id} failed with state: {state}")
        elif state in ("skipped", "upstream_skipped"):
            raise RuntimeError(f"Airflow DAG {dag_id} was skipped (state: {state})")

    raise RuntimeError(f"Airflow DAG {dag_id} poll timeout after {poll_timeout}s")


async def _execute_via_spark_submit(pipeline: dict, execution: dict) -> str:
    """Execute via spark-submit (K8s SparkApplication CR or CLI).

    For medium-sized jobs (500K-10M rows). Runs from ETL worker pod.
    Returns output S3 path.
    """
    # BF-599h: sync DB call → await adb to avoid blocking the loop.
    await adb(_db_manager.update_etl_execution, execution["id"], {"status": "running"})

    # Build spark-submit args
    spark_conf = {
        "spark.driver.memory": pipeline.get("spark_driver_memory") or _cfg.spark_defaults.driver_memory,
        "spark.executor.memory": pipeline.get("spark_executor_memory") or _cfg.spark_defaults.executor_memory,
        "spark.executor.cores": str(pipeline.get("spark_executor_cores") or _cfg.spark_defaults.executor_cores),
        "spark.executor.instances": str(pipeline.get("spark_num_executors") or 1),
    }
    extra_conf = pipeline.get("spark_extra_conf") or _cfg.spark_defaults.spark_conf
    spark_conf.update(extra_conf)

    pipeline_conf = json.dumps({
        "pipeline_id": pipeline.get("id"),
        "execution_id": execution.get("execution_id"),
        "source_s3_prefix": pipeline.get("source_s3_prefix"),
        "source_file_pattern": pipeline.get("source_file_pattern"),
        "dest_s3_bucket": pipeline.get("dest_s3_bucket"),
        "dest_s3_prefix": pipeline.get("dest_s3_prefix"),
        "dest_partition_columns": pipeline.get("dest_partition_columns"),
        "transform_rules": pipeline.get("transform_rules"),
        "processing_mode": pipeline.get("processing_mode", "overwrite"),
        "merge_key_columns": pipeline.get("merge_key_columns"),
        "watermark_column": pipeline.get("watermark_column"),
        "last_watermark_value": pipeline.get("last_watermark_value"),
    })

    # Build spark-submit command
    conf_args = []
    for k, v in spark_conf.items():
        conf_args.extend(["--conf", f"{k}={v}"])

    cmd = [
        "spark-submit",
        "--master", "k8s://https://kubernetes.default.svc",
        "--deploy-mode", "cluster",
        *conf_args,
        "--name", f"etl-{execution.get('execution_id', 'unknown')}",
        "/opt/spark/jobs/generic_etl.py",
        "--pipeline-config", pipeline_conf,
        "--execution-id", execution.get("execution_id", ""),
    ]

    # Execute spark-submit in thread (blocking subprocess)
    import subprocess
    result = await asyncio.to_thread(
        subprocess.run, cmd,
        capture_output=True, text=True, timeout=7200,
    )

    if result.returncode != 0:
        stderr = result.stderr[:2000] if result.stderr else "no stderr"
        raise RuntimeError(f"spark-submit failed (rc={result.returncode}): {stderr}")

    dest_prefix = pipeline.get("dest_s3_prefix", "")
    dest_bucket = pipeline.get("dest_s3_bucket", "")
    return f"s3://{dest_bucket}/{dest_prefix}"


async def _execute_via_native(pipeline: dict, execution: dict) -> tuple:
    """Execute via native DuckDB for small datasets (<500K rows).

    Runs in isolated subprocess (same pattern as duckdb_subprocess.py).
    Returns (output_path, metrics_dict).
    """
    # BF-599h: wrap sync DB call to keep the event loop responsive while
    # this async function holds it open.
    await adb(_db_manager.update_etl_execution, execution["id"], {"status": "running"})

    estimated = pipeline.get("estimated_row_count") or 0
    warning_threshold = _cfg.native_defaults.max_rows_warning
    if estimated > warning_threshold:
        logger.warning(
            "[etl_engine] Native execution for pipeline %s with %d estimated rows "
            "(exceeds warning threshold %d)",
            pipeline.get("name"), estimated, warning_threshold,
        )

    # Build DuckDB SQL from transform rules
    transform = pipeline.get("transform_rules") or {}
    source_prefix = pipeline.get("source_s3_prefix", "")
    file_pattern = pipeline.get("source_file_pattern", "*.parquet")

    import re
    _SAFE_IDENT = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*$')
    _SAFE_TYPE = re.compile(r'^[A-Za-z_][A-Za-z0-9_() ,]*$')

    def _quote_ident(name: str) -> str:
        """Quote DuckDB identifier. Validates against injection."""
        name = name.strip()
        if not _SAFE_IDENT.match(name):
            raise ValueError(f"Invalid identifier in transform rules: {name!r}")
        return f'"{name}"'

    def _validate_type(dtype: str) -> str:
        """Validate DuckDB type name against injection."""
        dtype = dtype.strip()
        if not _SAFE_TYPE.match(dtype):
            raise ValueError(f"Invalid type in transform rules: {dtype!r}")
        return dtype

    # SELECT clause — validate column identifiers
    select_cols = transform.get("select")
    if select_cols:
        select_clause = ", ".join(_quote_ident(c) for c in select_cols)
    else:
        select_clause = "*"

    # FROM clause — escape source path (single quotes)
    safe_prefix = source_prefix.replace("'", "''")
    safe_pattern = file_pattern.replace("'", "''")
    from_clause = f"read_parquet('{safe_prefix}{safe_pattern}')"

    # WHERE clause — admin-only field, validated at API layer
    where_clause = ""
    raw_where = transform.get("where", "")
    if raw_where:
        # Block dangerous patterns (DDL/DML keywords) — use regex word boundary
        # to prevent bypass via tab/newline/parenthesis after keyword
        import re as _re_kw
        where_lower = raw_where.lower()
        for forbidden in ("drop", "delete", "insert", "update", "alter",
                          "create", "truncate", "exec", "execute"):
            if _re_kw.search(r'\b' + forbidden + r'\b', where_lower):
                raise ValueError(f"Forbidden keyword in WHERE clause: {forbidden}")
        where_clause = f"WHERE {raw_where}"

    # Phase 129-A: WHERE-clause pruning — extract filter values and prune
    # the S3 file listing to skip irrelevant partitions (fail-open).
    #
    # BF-NON-PARTITION-PRUNE: was passing pc_map={} to the partition-only
    # extractor → returned empty → pruning silently no-op'd.  Switched to
    # extract_combined_filters_for_iceberg which extracts ALL WHERE-clause
    # filters (partition + non-partition) regardless of column membership.
    # filter_iceberg_files_by_partitions then matches what the file paths
    # actually carry.
    source_conn_id = pipeline.get("source_connection_id")
    if raw_where and source_conn_id and source_prefix.startswith("s3://"):
        try:
            from core.sql_partition_extractor import (
                extract_combined_filters_for_iceberg,
            )
            from core.s3_utilities import list_s3_parquet_files, filter_iceberg_files_by_partitions, make_s3_client_for_conn
            from core.credential_resolver import resolve_s3_credentials

            # BF-599h: wrap sync DB lookup (Postgres pool grab is I/O-bound)
            conn_record = await adb(_db_manager.get_connection_raw, source_conn_id) if _db_manager else None
            if conn_record:
                conn_cfg = conn_record.get("config", {})
                # BF-599h: cred resolution can call portal API → wrap to_thread.
                resolved = await asyncio.to_thread(resolve_s3_credentials, conn_cfg, "etl_prune")
                s3_client = make_s3_client_for_conn(resolved)
                # Parse s3://bucket/prefix → bucket, prefix_path
                _s3_parts = source_prefix.replace("s3://", "").split("/", 1)
                _prune_bucket = _s3_parts[0]
                _prune_prefix = _s3_parts[1] if len(_s3_parts) > 1 else ""

                all_files = list_s3_parquet_files(s3_client, _prune_bucket, _prune_prefix)
                if getattr(all_files, "truncated", False):
                    # 2026-08-20 — the listing hit its file cap, so it is a
                    # SUBSET of the table.  Rewriting from_clause to
                    # read_parquet(<pruned subset of a subset>) would DROP
                    # every unlisted file from the feed output with a
                    # success status.  Skip the pruning optimisation — the
                    # unpruned from_clause reads the full source, keeping
                    # the result complete (slower, never smaller).
                    logger.warning(
                        "[etl_engine] WHERE-pruning listing for s3://%s/%s "
                        "stopped at its %d-file cap — a TRUNCATED SUBSET. "
                        "Skipping file-level pruning so the feed reads the "
                        "FULL source (complete result over fast result).",
                        _prune_bucket, _prune_prefix, len(all_files),
                    )
                elif all_files:
                    filters = extract_combined_filters_for_iceberg(
                        f"SELECT * FROM _etl_src WHERE {raw_where}", {}
                    )
                    if filters:
                        pruned = filter_iceberg_files_by_partitions(all_files, filters)
                        if len(pruned) < len(all_files):
                            from_clause = f"read_parquet({pruned})"
                            logger.info(
                                "[etl_engine] WHERE pruning: %d → %d files (saved %d)",
                                len(all_files), len(pruned), len(all_files) - len(pruned),
                            )
        except Exception as exc:
            logger.debug("[etl_engine] WHERE pruning skipped: %s", exc)

    # Phase 129-B1: Watermark-based incremental — filter source rows by last watermark
    watermark_col = pipeline.get("watermark_column")
    watermark_val = pipeline.get("last_watermark_value")
    if watermark_col and watermark_val:
        _quote_ident(watermark_col)  # validate identifier
        safe_wm_val = watermark_val.replace("'", "''")
        wm_filter = f"{_quote_ident(watermark_col)} > '{safe_wm_val}'"
        if where_clause:
            where_clause = f"{where_clause} AND {wm_filter}"
        else:
            where_clause = f"WHERE {wm_filter}"
        logger.info("[etl_engine] Watermark filter: %s > '%s'", watermark_col, watermark_val)

    # Dedup — validate column identifiers
    dedup = transform.get("dedup")
    dedup_wrapper = None
    if dedup:
        dedup_cols = ", ".join(_quote_ident(c) for c in dedup.get("columns", []))
        order_by_raw = dedup.get("order_by", "rowid")
        order_by = _quote_ident(order_by_raw)
        dedup_wrapper = (dedup_cols, order_by)

    # Cast — validate column names and types
    cast_map = transform.get("cast") or {}
    if cast_map:
        for col, dtype in cast_map.items():
            _quote_ident(col)
            _validate_type(dtype)
        if select_cols:
            new_cols = []
            for c in select_cols:
                col_name = c.strip()
                if col_name in cast_map:
                    qc = _quote_ident(col_name)
                    new_cols.append(f"CAST({qc} AS {_validate_type(cast_map[col_name])}) AS {qc}")
                else:
                    new_cols.append(_quote_ident(col_name))
            select_clause = ", ".join(new_cols)

    # Build final SQL
    if dedup_wrapper:
        dedup_cols, order_by = dedup_wrapper
        sql = (
            f"SELECT * FROM ("
            f"SELECT {select_clause}, "
            f"ROW_NUMBER() OVER (PARTITION BY {dedup_cols} ORDER BY {order_by}) AS _rn "
            f"FROM {from_clause} {where_clause}"
            f") WHERE _rn = 1"
        )
    else:
        sql = f"SELECT {select_clause} FROM {from_clause} {where_clause}"

    # Custom SQL overrides everything — admin-only, validated at API layer
    if transform.get("custom_sql"):
        custom = transform["custom_sql"]
        custom_lower = custom.lower()
        import re as _re_kw2
        for forbidden in ("drop", "delete", "insert", "update", "alter",
                          "create", "truncate", "exec", "execute"):
            if _re_kw2.search(r'\b' + forbidden + r'\b', custom_lower):
                raise ValueError(f"Forbidden keyword in custom_sql: {forbidden}")
        sql = custom

    # Execute via DuckDB subprocess
    dest_bucket = pipeline.get("dest_s3_bucket", "")
    dest_prefix = pipeline.get("dest_s3_prefix", "")
    partition_cols = pipeline.get("dest_partition_columns") or []

    # Build COPY statement for output
    output_path = f"s3://{dest_bucket}/{dest_prefix}"
    partition_clause = ""
    if partition_cols:
        # BF-121: Validate partition column identifiers (was missing — SQL injection)
        safe_pcols = ", ".join(_quote_ident(c) for c in partition_cols)
        partition_clause = f", PARTITION_BY ({safe_pcols})"

    copy_sql = (
        f"COPY ({sql}) TO '{output_path}' "
        f"(FORMAT PARQUET, COMPRESSION SNAPPY{partition_clause})"
    )

    # Run in thread with semaphore
    async with _AsyncSemaphore(_native_sem):
        result = await asyncio.to_thread(_run_native_duckdb, copy_sql, sql, pipeline)

    return output_path, result


def _run_native_duckdb(copy_sql: str, data_sql: str, pipeline: dict) -> dict:
    """Run DuckDB COPY command in isolated connection. Returns metrics dict."""
    import duckdb

    memory_limit = pipeline.get("native_duckdb_memory_limit") or _cfg.native_defaults.duckdb_memory_limit
    threads = _cfg.native_defaults.duckdb_threads

    con = duckdb.connect(":memory:")
    try:
        con.execute(f"SET memory_limit = '{memory_limit}'")
        con.execute(f"SET threads = {threads}")

        # S3 credentials — resolve from source connection (portal, STS, keys, etc.)
        # Note: _run_native_duckdb is sync (runs inside asyncio.to_thread
        # from the async caller), so the DB lookup here is correctly sync.
        source_conn_id = pipeline.get("source_connection_id")
        if source_conn_id and _db_manager:
            conn_record = _db_manager.get_connection_raw(source_conn_id)
            if conn_record:
                conn_cfg = conn_record.get("config", {})
                conn_type = conn_record.get("connection_type", conn_cfg.get("type", ""))
                if conn_type in ("s3", "aws_s3"):
                    # Resolve credentials (portal, assume_role, etc.)
                    from core.credential_resolver import resolve_s3_credentials
                    resolved_cfg = resolve_s3_credentials(conn_cfg, "etl_engine")

                    # 2026-09-26 -- credentials / region / endpoint / ssl /
                    # url-style from the ONE resolver (core.s3_access).  This
                    # site used to force path-style on every custom endpoint;
                    # the resolver applies the single product-wide rule.
                    from core.s3_access import resolve_s3_access
                    resolve_s3_access(resolved_cfg, proxy=False).apply_to_duckdb(con)

        # Also configure dest S3 if different bucket/creds are needed
        dest_conn_id = pipeline.get("dest_connection_id")
        if dest_conn_id and dest_conn_id != source_conn_id and _db_manager:
            logger.warning(
                "[etl_engine] Dest connection %d differs from source %d — "
                "DuckDB COPY uses single S3 config; ensure same creds work for both",
                dest_conn_id, source_conn_id or 0,
            )

        con.execute(copy_sql)

        # Phase 129-B1: Collect max watermark value after COPY for incremental tracking
        metrics = {"status": "success"}
        watermark_col = pipeline.get("watermark_column")
        if watermark_col:
            try:
                safe_wc = watermark_col.replace('"', '""')
                max_row = con.execute(f'SELECT MAX("{safe_wc}") FROM ({data_sql})').fetchone()
                if max_row and max_row[0] is not None:
                    metrics["watermark_value_after"] = str(max_row[0])
            except Exception as wm_exc:
                logger.debug("[etl_engine] Watermark collection failed: %s", wm_exc)

        return metrics
    finally:
        con.close()


class _AsyncSemaphore:
    """Async context manager wrapping a threading.Semaphore.

    BF-582: also maintains ``_native_inflight`` so
    ``get_etl_engine_stats`` reports accurate slot usage without
    poking ``_sem._value`` (a CPython private slot)."""

    def __init__(self, sem: threading.Semaphore):
        self._sem = sem

    async def __aenter__(self):
        await asyncio.to_thread(self._sem.acquire)
        global _native_inflight
        with _native_inflight_lock:
            _native_inflight += 1
        return self

    async def __aexit__(self, *args):
        global _native_inflight
        with _native_inflight_lock:
            _native_inflight = max(0, _native_inflight - 1)
        self._sem.release()


# ── Completion Handler ────────────────────────────────────────────────────

async def handle_etl_completion(execution_id: str, state: str,
                                output_path: str = None, error: str = None,
                                metrics: dict = None) -> dict:
    """Handle ETL pipeline completion (called by webhook or inline).

    Updates execution record, runs post-completion hooks, broadcasts events.
    Returns updated execution dict.
    """
    _require_engine()                                    # FB-34
    # BF-599h: wrap sync DB calls — handle_etl_completion runs from
    # webhook handlers and inline completion paths; both are on the
    # async event loop and serialise across tenants if blocked.
    execution = await adb(_db_manager.get_etl_execution_by_exec_id, execution_id)
    if not execution:
        raise ValueError(f"Execution {execution_id} not found")

    pipeline = await adb(_db_manager.get_etl_pipeline, execution["pipeline_id"])
    metrics = metrics or {}
    now = datetime.now(timezone.utc)

    started = execution.get("started_at")
    duration = None
    if started:
        if isinstance(started, str):
            started = datetime.fromisoformat(started)
        if started.tzinfo is None:
            started = started.replace(tzinfo=timezone.utc)
        duration = (now - started).total_seconds()

    if state == "completed":
        update_data = {
            "status": "completed",
            "completed_at": now,
            "duration_seconds": duration,
            "output_path": output_path,
            "input_row_count": metrics.get("input_row_count"),
            "output_row_count": metrics.get("output_row_count"),
            "output_file_count": metrics.get("output_file_count"),
            "output_size_bytes": metrics.get("output_size_bytes"),
            "watermark_value_after": metrics.get("watermark_value_after"),
            "source_s3_paths": metrics.get("source_s3_paths"),
            "dest_s3_paths": metrics.get("dest_s3_paths"),
        }
        # Remove None values to avoid overwriting existing data
        update_data = {k: v for k, v in update_data.items() if v is not None}
        # BF-599h: wrap all three sync writes — completion handler runs
        # on the loop; without adb each blocks for the pool grab.
        updated = await adb(_db_manager.update_etl_execution, execution["id"], update_data)

        # Update pipeline tracking fields
        pipeline_update = {"last_execution_id": execution["id"]}
        if metrics.get("output_row_count"):
            pipeline_update["last_row_count"] = metrics["output_row_count"]
            pipeline_update["estimated_row_count"] = metrics["output_row_count"]
        if metrics.get("watermark_value_after"):
            pipeline_update["last_watermark_value"] = metrics["watermark_value_after"]
        await adb(_db_manager.update_etl_pipeline, execution["pipeline_id"], pipeline_update)
        await adb(_db_manager.increment_etl_run_count, execution["pipeline_id"])

        # Post-completion hooks
        await _post_completion_hooks(pipeline, updated or execution)

        _broadcast("etl_completed", {
            "pipeline_id": execution["pipeline_id"],
            "pipeline_name": pipeline.get("name") if pipeline else None,
            "execution_id": execution_id,
            "output_path": output_path,
            "duration_seconds": duration,
            "output_row_count": metrics.get("output_row_count"),
            "triggered_by": execution.get("triggered_by"),
        })

        logger.info("[etl_engine] Pipeline %d [%s] COMPLETED — %s rows, %.2fs",
                    execution["pipeline_id"], execution_id,
                    metrics.get("output_row_count", "?"), duration)

        return updated or execution

    else:
        # Failed
        update_data = {
            "status": "failed",
            "completed_at": now,
            "duration_seconds": duration,
            "error_message": (error or "Unknown error")[:2000],
            "error_stage": metrics.get("error_stage", "callback"),
        }
        # BF-599h: failed-path sync write also wrapped.
        updated = await adb(_db_manager.update_etl_execution, execution["id"], update_data)

        _broadcast("etl_failed", {
            "pipeline_id": execution["pipeline_id"],
            "pipeline_name": pipeline.get("name") if pipeline else None,
            "execution_id": execution_id,
            "error": (error or "")[:500],
            "triggered_by": execution.get("triggered_by"),
        })

        logger.error("[etl_engine] Pipeline %d [%s] FAILED: %s",
                     execution["pipeline_id"], execution_id,
                     (error or "Unknown")[:500])

        return updated or execution


# ── DQ Check (Phase 129-D) ────────────────────────────────────────────────

async def _run_dq_checks(pipeline: dict, execution: dict, dest_conn_id: int):
    """Profile destination output + compare to baseline, alert on anomalies.

    Runs async (fire-and-forget) — never blocks pipeline completion.
    """
    try:
        from core.agents.dq_monitor import DQMonitorAgent
        from core.cache_layer import get_cache, create_cache

        agent = DQMonitorAgent({})
        output_path = execution.get("output_path") or ""
        if not output_path:
            dest_bucket = pipeline.get("dest_s3_bucket", "")
            dest_prefix = pipeline.get("dest_s3_prefix", "")
            output_path = f"s3://{dest_bucket}/{dest_prefix}" if dest_bucket else ""
        if not output_path:
            return

        # Profile output in thread (DuckDB is sync)
        import duckdb

        def _profile():
            con = duckdb.connect(":memory:")
            try:
                # Set S3 credentials for destination
                source_conn_id = pipeline.get("source_connection_id") or dest_conn_id
                if source_conn_id and _db_manager:
                    conn_record = _db_manager.get_connection_raw(source_conn_id)
                    if conn_record:
                        conn_cfg = conn_record.get("config", {})
                        from core.credential_resolver import resolve_s3_credentials
                        resolved = resolve_s3_credentials(conn_cfg, "etl_dq")
                        # BF-133: Escape credentials to prevent SQL injection / syntax errors
                        # 2026-09-26 -- the ONE resolver (core.s3_access).
                        from core.s3_access import resolve_s3_access
                        resolve_s3_access(resolved, proxy=False).apply_to_duckdb(con)
                return agent.profile_table(output_path, dest_conn_id, con)
            finally:
                con.close()

        current = await asyncio.to_thread(_profile)
        if current.get("error"):
            logger.warning("[etl_engine] DQ profile failed: %s", current["error"])
            return

        # Compare to previous baseline
        pipeline_id = pipeline.get("id")
        baseline_key = f"etl_dq_baseline_{pipeline_id}"
        cache = get_cache("etl_dq_baselines")
        if not cache:
            cache = create_cache("etl_dq_baselines", ttl=0, max_entries=500)

        baseline = cache.get(baseline_key) if cache else None
        anomalies = agent.compare_to_baseline(current, baseline) if baseline else []

        if anomalies:
            logger.warning("[etl_engine] DQ anomalies for pipeline %d: %s",
                           pipeline_id, anomalies)
            _broadcast("etl_dq_anomalies", {
                "pipeline_id": pipeline_id,
                "pipeline_name": pipeline.get("name"),
                "anomalies": anomalies,
                "execution_id": execution.get("execution_id"),
                "triggered_by": execution.get("triggered_by"),
            })

        # Store as new baseline (no expiry)
        if cache:
            cache.set(baseline_key, current, ttl=0)

        logger.info("[etl_engine] DQ check completed for pipeline %d: %d rows, %d anomalies",
                    pipeline_id, current.get("row_count", 0), len(anomalies))
    except Exception as exc:
        logger.warning("[etl_engine] DQ check failed: %s", exc)


# ── Post-Completion Hooks ─────────────────────────────────────────────────

async def _post_completion_hooks(pipeline: dict, execution: dict):
    """Run post-completion hooks: cache invalidation, DQ, SLA, deps, lineage."""
    if not pipeline:
        return

    on_complete = _cfg.on_complete
    dest_conn_id = pipeline.get("dest_connection_id")

    # 1. Cache invalidation
    if on_complete.invalidate_cache and dest_conn_id:
        try:
            from core.query_cache import invalidate_by_source
            invalidate_by_source(connection_id=dest_conn_id)
            logger.info("[etl_engine] Cache invalidated for connection %d", dest_conn_id)
        except Exception as exc:
            logger.warning("[etl_engine] Cache invalidation failed: %s", exc)

    # 2. S3 listing cache clear
    if on_complete.refresh_partitions and dest_conn_id:
        try:
            from core.s3_utilities import clear_listing_cache
            clear_listing_cache(connection_id=dest_conn_id)
            logger.info("[etl_engine] S3 listing cache cleared for connection %d", dest_conn_id)
        except Exception as exc:
            logger.warning("[etl_engine] S3 listing cache clear failed: %s", exc)

    # 3. DQ checks (async, non-blocking — Phase 129-D)
    # BF-591: strong-ref via _track_etl_task — Python issue #88831
    # silent task-drop fix mirrors the dispatch path above.
    if on_complete.run_dq_checks and dest_conn_id:
        _track_etl_task(_run_dq_checks(pipeline, execution, dest_conn_id))

    # 4. SLA check
    if _cfg.sla.enabled:
        await _check_sla(pipeline, execution)

    # 5. Trigger dependent pipelines
    if on_complete.trigger_dependents:
        await _trigger_dependents(pipeline)

    # 6. Update lineage
    if on_complete.update_lineage:
        _update_lineage(pipeline, execution)


async def _check_sla(pipeline: dict, execution: dict):
    """Check if execution completed within SLA deadline."""
    sla_deadline = execution.get("sla_deadline")
    if not sla_deadline:
        return

    completed_at = execution.get("completed_at")
    if not completed_at:
        return

    if isinstance(sla_deadline, str):
        sla_deadline = datetime.fromisoformat(sla_deadline)
    if isinstance(completed_at, str):
        completed_at = datetime.fromisoformat(completed_at)

    if completed_at > sla_deadline:
        logger.warning(
            "[etl_engine] SLA BREACHED for pipeline %s: completed %s, deadline %s",
            pipeline.get("name"), completed_at, sla_deadline,
        )
        # BF-591: was sync.
        await asyncio.to_thread(_db_manager.update_etl_execution,
                                execution["id"], {"sla_breached": True})

        _broadcast("etl_sla_breached", {
            "pipeline_id": pipeline.get("id"),
            "pipeline_name": pipeline.get("name"),
            "execution_id": execution.get("execution_id"),
            "sla_deadline": str(sla_deadline),
            "completed_at": str(completed_at),
        })

        # Notify via configured channels
        notify_emails = pipeline.get("sla_notify_emails")
        notify_webhook = pipeline.get("sla_notify_webhook")
        if notify_webhook:
            try:
                from core.url_safety import validate_url_safety
                validate_url_safety(notify_webhook)
                payload = json.dumps({
                    "event": "etl_sla_breached",
                    "pipeline_name": pipeline.get("name"),
                    "sla_deadline": str(sla_deadline),
                    "completed_at": str(completed_at),
                }).encode("utf-8")
                await asyncio.to_thread(
                    http_request, notify_webhook, "POST", payload,
                    {"Content-Type": "application/json"}, timeout=10,
                )
            except ValueError as ssrf_exc:
                logger.warning("[etl_engine] SLA webhook SSRF blocked for %s: %s",
                               notify_webhook, ssrf_exc)
            except Exception as exc:
                logger.warning("[etl_engine] SLA webhook notification failed: %s", exc)

        # 2026-08-17 -- sla_notify_emails was READ and then never used.  The
        # column exists (core/db/models.py), it is settable through
        # api/etl_pipeline_api.py, and the admin who filled it in got NOTHING:
        # only the webhook branch above was ever implemented, so an SLA breach
        # notified nobody by email.  A configured channel that silently does
        # not fire is worse than an absent feature -- the operator believes
        # they are covered.
        if notify_emails:
            try:
                from core.email_service import send_email
                _to = [a.strip() for a in str(notify_emails).replace(";", ",").split(",")
                       if a.strip()]
                if _to:
                    _name = pipeline.get("name") or pipeline.get("id")
                    await asyncio.to_thread(
                        send_email,
                        _to,
                        f"[QueryStudio] ETL SLA breached: {_name}",
                        (f"<p>Pipeline <b>{_name}</b> breached its SLA.</p>"
                         f"<ul><li>Execution: {execution.get('execution_id')}</li>"
                         f"<li>SLA deadline: {sla_deadline}</li>"
                         f"<li>Completed at: {completed_at}</li></ul>"),
                    )
            except Exception as exc:
                # Fail-open + logged: a notification must never fail the run
                # it is reporting on, but silence is what caused this bug.
                logger.warning(
                    "[etl_engine] SLA email notification failed for %s: %s",
                    notify_emails, exc)


async def _trigger_dependents(pipeline: dict):
    """Trigger pipelines that depend on this one.

    Validates dependency graph for cycles before triggering to prevent
    infinite loops (A→B→A). Limits chain depth to 10.
    """
    pipeline_id = pipeline.get("id")
    if not pipeline_id:
        return

    try:
        all_pipelines = _db_manager.list_etl_pipelines(is_active=True)

        # Build dependency graph and check for cycles involving this pipeline
        if _has_dependency_cycle(pipeline_id, all_pipelines):
            logger.error(
                "[etl_engine] Dependency cycle detected involving pipeline %s — "
                "skipping dependent triggers to prevent infinite loop",
                pipeline.get("name"),
            )
            return

        # Find dependents: single parent OR multi-parent (depends_on_pipeline_ids)
        dependents = []
        for p in all_pipelines:
            if p.get("depends_on_pipeline_id") == pipeline_id:
                dependents.append(p)
            elif pipeline_id in (p.get("depends_on_pipeline_ids") or []):
                dependents.append(p)

        for dep in dependents:
            # Phase 132-H: trigger_mode="all" requires ALL parents completed
            if dep.get("trigger_mode") == "all":
                if not _db_manager.all_parents_completed(dep):
                    logger.info(
                        "[etl_engine] Pipeline %s has trigger_mode=all — "
                        "not all parents completed yet, skipping",
                        dep.get("name"),
                    )
                    continue

            logger.info(
                "[etl_engine] Triggering dependent pipeline %s (depends on %s)",
                dep.get("name"), pipeline.get("name"),
            )
            await trigger_pipeline(
                dep["id"],
                trigger_type="dependency",
                triggered_by=f"pipeline:{pipeline.get('name')}",
            )
    except Exception as exc:
        logger.warning("[etl_engine] Dependency trigger failed: %s", exc)


def _has_dependency_cycle(start_id: int, all_pipelines: list) -> bool:
    """Check if any dependency chain from start_id loops back to itself.

    Uses DFS with visited tracking. Also returns True if chain depth >10.
    """
    # Build adjacency: parent_id -> [child_ids]
    children = {}
    for p in all_pipelines:
        pid = p.get("id")
        dep = p.get("depends_on_pipeline_id")
        if dep is not None:
            children.setdefault(dep, []).append(pid)
        # Phase 132-H fix: also include multi-parent edges
        for dep_id in (p.get("depends_on_pipeline_ids") or []):
            if dep_id != dep:  # Avoid double-adding
                children.setdefault(dep_id, []).append(pid)

    visited = set()
    stack = [(start_id, 0)]
    while stack:
        node, depth = stack.pop()
        if depth > 10:
            return True  # Chain too deep — treat as cycle
        if node in visited:
            continue  # Already traversed from a different path
        visited.add(node)
        for child in children.get(node, []):
            if child == start_id:
                return True  # Cycle back to start
            stack.append((child, depth + 1))
    return False


def _update_lineage(pipeline: dict, execution: dict):
    """Update data catalog lineage with ETL pipeline information."""
    try:
        source_conn_id = pipeline.get("source_connection_id")
        dest_conn_id = pipeline.get("dest_connection_id")
        if source_conn_id and dest_conn_id:
            logger.info(
                "[etl_engine] Lineage updated: connection %d → pipeline %s → connection %d",
                source_conn_id, pipeline.get("name"), dest_conn_id,
            )
    except Exception as exc:
        logger.warning("[etl_engine] Lineage update failed: %s", exc)


# ── Helpers ───────────────────────────────────────────────────────────────

def _classify_error_stage(exc: Exception) -> str:
    """Classify error into pipeline stage for reporting."""
    msg = str(exc).lower()
    if "airflow" in msg or "dag" in msg:
        return "trigger"
    if "spark" in msg or "executor" in msg:
        return "spark"
    if "callback" in msg or "webhook" in msg:
        return "callback"
    if "sla" in msg:
        return "sla"
    if "s3" in msg or "bucket" in msg or "access denied" in msg:
        return "s3"
    if "duckdb" in msg or "memory" in msg:
        return "duckdb"
    if "timeout" in msg or "timed out" in msg:
        return "timeout"
    if "connection" in msg or "refused" in msg:
        return "connection"
    return "unknown"


def _broadcast(event_type: str, data: dict):
    """Broadcast ETL event via WebSocket."""
    if _broadcast_fn:
        try:
            _broadcast_fn({"type": event_type, **data})
        except Exception as exc:
            logger.debug("[etl_engine] Broadcast failed: %s", exc)


def get_circuit_breaker_status() -> dict:
    """Return status of all circuit breakers for admin API."""
    return {
        "airflow":       _airflow_breaker.to_dict()        if _airflow_breaker        else None,
        "spark_connect": _spark_connect_breaker.to_dict()  if _spark_connect_breaker  else None,
        "spark_submit":  _spark_submit_breaker.to_dict()   if _spark_submit_breaker   else None,
        "native":        _native_breaker.to_dict()         if _native_breaker         else None,
    }


def reset_circuit_breaker(backend: str) -> bool:
    """Reset a specific circuit breaker. Returns True if found and reset."""
    breakers = {
        "airflow":       _airflow_breaker,
        "spark_connect": _spark_connect_breaker,
        "spark_submit":  _spark_submit_breaker,
        "native":        _native_breaker,
    }
    breaker = breakers.get(backend)
    if breaker:
        breaker.reset()
        logger.info("[etl_engine] Circuit breaker %s reset", backend)
        return True
    return False
