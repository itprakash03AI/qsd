"""
Shared execution state — module-level dicts/locks used by both the
execute engine and admin/monitoring endpoints.

Extracting here breaks the circular import between main.py endpoints and
admin router that both need access to in-flight execution tracking.

Usage:
    from core.execution_state import (
        running_tasks, cancellation_flags, inflight_queries,
        user_query_counts, user_query_lock,
        get_global_sem, set_global_sem,
        get_queue_count, increment_queue_count, decrement_queue_count,
        global_queue_lock,
    )
"""
from __future__ import annotations

import asyncio
import threading
from typing import Dict, Optional

# ── Per-execution cancellation registry ───────────────────────────────────────
running_tasks:      Dict[str, "asyncio.Task"] = {}  # execution_id → asyncio.Task
cancellation_flags: Dict[str, threading.Event] = {}  # execution_id → threading.Event

# ── In-flight query deduplication ─────────────────────────────────────────────
# Maps cache_key → (primary_execution_id, asyncio.Event)
inflight_queries: Dict[str, tuple] = {}

# ── Per-user concurrency tracking ─────────────────────────────────────────────
# BF-593 (2026-05-30): aliased to the QueueManager singleton's state so
# admin_api.py + core.executors.concurrency.py read the LIVE per-user
# counter that execute_api actually updates.  Before this fix the dict
# below was a standalone empty dict that nothing incremented, so the
# admin dashboard's "active_now" overlay always showed 0 for every user
# and any caller of the "canonical" global_refusal() / per_user_active_count()
# helpers in core/executors/concurrency.py got numbers totally divorced
# from reality.
#
# The aliasing must work whether QueueManager is constructed before or
# after this module is imported — get_queue_manager() lazy-initialises.
from core.query_queue import get_queue_manager as _get_queue_manager  # noqa: E402
_queue_mgr = _get_queue_manager()
user_query_counts: Dict[str, int] = _queue_mgr._user_query_counts
user_query_lock = _queue_mgr._lock

# ── Global concurrency gate ────────────────────────────────────────────────────
# asyncio.Semaphore is event-loop-bound; initialised at startup via set_global_sem()
_global_query_sem: Optional[asyncio.Semaphore] = None
_global_queue_count = 0
global_queue_lock = threading.Lock()


def set_global_sem(sem: asyncio.Semaphore) -> None:
    """Called once from startup after the event loop is running."""
    global _global_query_sem
    _global_query_sem = sem


def get_global_sem() -> Optional[asyncio.Semaphore]:
    return _global_query_sem


def get_queue_count() -> int:
    return _global_queue_count


def increment_queue_count() -> int:
    global _global_queue_count
    with global_queue_lock:
        _global_queue_count += 1
        return _global_queue_count


def decrement_queue_count() -> int:
    global _global_queue_count
    with global_queue_lock:
        _global_queue_count = max(0, _global_queue_count - 1)
        return _global_queue_count


# ── Idempotency key registry ────────────────────────────────────────────────
# Maps (username, client-provided idempotency key) → (execution_id, timestamp)
# Entries expire after 10 minutes to avoid unbounded growth.
#
# SECURITY 2026-08-20 — the registry is namespaced by USERNAME.  The key is a
# raw CLIENT-SUPPLIED string; before this fix two principals submitting the
# same key value (guessable, reused, or a client that hardcodes one) collided
# in a single global namespace, so user B's request returned user A's
# execution_id — and the handler then returned A's status/handle to B.
_idempotency_keys: Dict[tuple, tuple] = {}
_idempotency_lock = threading.Lock()
_IDEMPOTENCY_TTL = 600  # 10 minutes


def _idem_registry_key(username: str, key: str) -> tuple:
    """Composite registry key.  A tuple (not string concat) so a crafted
    username/key containing the separator can't collide across principals."""
    return (str(username or ""), str(key))


def check_idempotency(key: str, username: str = "") -> Optional[str]:
    """Return execution_id if this key was recently used BY THIS PRINCIPAL,
    else None.  ``username`` scopes the lookup — see registry comment."""
    if not key:
        return None
    with _idempotency_lock:
        _prune_idempotency()
        entry = _idempotency_keys.get(_idem_registry_key(username, key))
        if entry:
            return entry[0]  # execution_id
    return None

def register_idempotency(key: str, execution_id: str, username: str = "") -> None:
    """Register a (principal, idempotency key) → execution_id mapping."""
    if not key:
        return
    import time
    with _idempotency_lock:
        _idempotency_keys[_idem_registry_key(username, key)] = (execution_id, time.time())

def _prune_idempotency() -> None:
    """Remove expired idempotency entries (called under lock)."""
    import time
    now = time.time()
    expired = [k for k, (_, ts) in _idempotency_keys.items() if now - ts > _IDEMPOTENCY_TTL]
    for k in expired:
        del _idempotency_keys[k]


# ── Phase 139 honest-fix #1 — heartbeat tracking for stale-query auto-cancel ──
# Frontend pings each in-flight execution_id every N seconds. If we don't see
# a heartbeat for STALE_TIMEOUT seconds we assume the user closed the browser
# / navigated away and cancel the execution to free up resources.
#
# Phase 141 honest-fix: ALSO track last engine-progress timestamp.  The
# stale-cancel decision should consider BOTH heartbeats:
#   * client heartbeat stale  AND
#   * engine progress also stale
# A 16-minute query that is actively scanning files should NOT be killed just
# because the user's corporate-proxy dropped the WebSocket for ~60 seconds.
# Symptoms of the old behaviour: queries cancelled at exactly ~17 min when
# the proxy idle-timeout (e.g. 1000s) fires mid-query.
_heartbeat_lock = threading.Lock()
_last_heartbeat: Dict[str, float] = {}   # execution_id → unix ts of last CLIENT ping
_last_engine_progress: Dict[str, float] = {}  # execution_id → unix ts of last engine activity


def record_heartbeat(execution_id: str) -> None:
    """Update the last-heartbeat timestamp for an execution. Idempotent."""
    if not execution_id:
        return
    import time
    with _heartbeat_lock:
        _last_heartbeat[execution_id] = time.time()


def record_engine_progress(execution_id: str) -> None:
    """Update the last engine-progress timestamp.  Called by the server-side
    heartbeat loop AND by any code that observes the engine making progress
    (chunks_processed bumped, parquet flush completed, etc.).

    Used by the smart stale-cancel decision: a query whose engine is still
    making progress is NEVER killed even if the client heartbeat is stale.
    """
    if not execution_id:
        return
    import time
    with _heartbeat_lock:
        _last_engine_progress[execution_id] = time.time()


def remove_heartbeat(execution_id: str) -> None:
    """Drop the heartbeat + progress records (called on completion/failure/cancel)."""
    with _heartbeat_lock:
        _last_heartbeat.pop(execution_id, None)
        _last_engine_progress.pop(execution_id, None)


def _gc_orphan_engine_progress(max_age_seconds: float = 3600.0) -> int:
    """Bug-fix: CLI / scheduled / API-driven executions stamp engine progress
    but never have a client heartbeat record.  ``remove_heartbeat()`` is
    only called from the stale-cancel loop (which iterates over
    ``_last_heartbeat``), so engine-progress entries for those executions
    leak indefinitely.

    This GC pass drops engine-progress entries OLDER than ``max_age_seconds``
    that have NO matching ``_last_heartbeat`` entry — these are guaranteed
    orphans (a real interactive execution would have heartbeat refresh).

    Called from the stale-cancel loop on each 30 s tick.  Returns rows
    cleaned for logging.
    """
    import time
    cutoff = time.time() - max_age_seconds
    with _heartbeat_lock:
        orphans = [
            eid for eid, ts in _last_engine_progress.items()
            if ts < cutoff and eid not in _last_heartbeat
        ]
        for eid in orphans:
            _last_engine_progress.pop(eid, None)
        return len(orphans)


def get_stale_executions(
    stale_timeout_seconds: float = 60.0,
    engine_progress_grace_seconds: float = 60.0,
) -> list:
    """Return execution_ids that should be auto-cancelled.

    Smart-cancel rule (Phase 141): an execution is eligible only when
    BOTH the client heartbeat AND the engine progress timestamp are older
    than the respective thresholds.  This prevents the previous failure
    mode where a 16-minute query was killed because a corporate-proxy
    dropped the WebSocket mid-query while the engine was still scanning.

    Only returns executions that HAVE a heartbeat record (i.e. the frontend
    sent at least one). Executions without any heartbeat are not auto-cancelled
    — they may be CLI / scheduled / API-driven where no browser is watching.
    """
    import time
    now = time.time()
    client_cutoff = now - stale_timeout_seconds
    engine_cutoff = now - engine_progress_grace_seconds
    with _heartbeat_lock:
        stale = []
        for eid, ts in _last_heartbeat.items():
            if ts >= client_cutoff:
                continue  # client heartbeat is fresh — keep alive
            engine_ts = _last_engine_progress.get(eid, 0.0)
            if engine_ts >= engine_cutoff:
                continue  # engine is still progressing — keep alive
            stale.append(eid)
        return stale


def get_heartbeat_count() -> int:
    """Number of executions currently being heartbeat-tracked."""
    with _heartbeat_lock:
        return len(_last_heartbeat)


def get_engine_progress_count() -> int:
    """Number of executions with a recorded engine-progress timestamp."""
    with _heartbeat_lock:
        return len(_last_engine_progress)
