"""Admin snapshots of daemons whose state lives in PROCESS MEMORY -- answered
by the process that runs the daemon, not by whichever pod took the request.

2026-10-07.  In production the API pod (``QS_POD_ROLE=api``,
``scheduler.mode=external``) answers every ``/api/admin/*`` route, while the
scheduler-owned daemons (``core.daemon_registry.SCHEDULER_OWNED``) run inside
``scheduler_worker.py`` on the scheduler pod.  A route that returns a
daemon's module-level ring / last-tick dict therefore read the API pod's
EMPTY copy: a healthy daemon looked dead (found on the Iceberg manifest
watcher: ``last_tick.ran_at: null, tables_polled: 0`` while the DB showed
every table certified).

The Iceberg watcher's status is now answered from durable tables
(``iceberg_manifest_watcher.get_watcher_status``).  Daemons that keep NO
durable record of their ticks are answered here: the snapshot is computed by
the process that owns the daemon -- this one when it runs the daemon, else
the scheduler worker via its control API (``GET
/control/daemon-snapshot/{name}``, the same channel ``/api/admin/scheduler``
uses in external mode).  Every answer says which process produced it
(``answered_by``); when the owner cannot be reached the local copy is
returned WITH a warning saying it is not the daemon's state -- never an empty
ring presented as the truth.
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, Optional, Tuple

logger = logging.getLogger(__name__)


def _prefetch_status(_limit: Optional[int]) -> Any:
    from core.query_history_prefetcher import get_prefetch_status
    return get_prefetch_status()


def _coordinator_status(limit: Optional[int]) -> Any:
    from core.brain_coordinator import get_current_pressure_state, recent_reports
    return {"current": get_current_pressure_state(),
            "recent_reports": recent_reports(limit=int(limit or 20))}


def _parquet_sync_ticks(limit: Optional[int]) -> Any:
    from core.plain_parquet_metadata_sync import recent_ticks
    return {"ticks": recent_ticks(limit=int(limit or 10))}


def _parquet_mirror_ticks(limit: Optional[int]) -> Any:
    from core.plain_parquet_mirror import recent_ticks
    return {"ticks": recent_ticks(limit=int(limit or 10))}


def _iceberg_mirror_ticks(limit: Optional[int]) -> Any:
    from core.iceberg_mirror import get_recent_ticks
    return {"ticks": get_recent_ticks(limit=int(limit or 10))}


def _output_gateway_ticks(limit: Optional[int]) -> Any:
    from core.output_gateway import get_recent_ticks
    return {"ticks": get_recent_ticks(limit=int(limit or 10))}


def _iceberg_sync_runs(_limit: Optional[int]) -> Any:
    from core.iceberg_metadata_sync import (get_last_summary, get_recent_runs,
                                            get_sync_progress)
    return {"summary": get_last_summary(), "progress": get_sync_progress(),
            "recent_runs": get_recent_runs()}


def _feed_failover_state(_limit: Optional[int]) -> Any:
    """The feed failover agent's streaks (filled by its APScheduler tick) and
    the feed engine's backend circuit breakers (tripped where feeds run)."""
    from core.feed_engine import get_backend_status
    out: Dict[str, Any] = {"circuit_breakers": get_backend_status()}
    try:
        from core.database import get_db_manager
        from core.feed.failover_agent import get_agent
        dbm = get_db_manager()
        out["agent"] = (get_agent(dbm).status() if dbm is not None
                        else {"error": "no db manager in this process"})
    except Exception as exc:
        out["agent"] = {"error": str(exc)[:200]}
    return out


#: name -> (owning daemon in core.daemon_registry, snapshot(limit)).
#: An ALLOW-LIST: the control endpoint serves nothing else.
SNAPSHOTS: Dict[str, Tuple[str, Callable[[Optional[int]], Any]]] = {
    "adaptive_prefetch.status":     ("adaptive_prefetch", _prefetch_status),
    "brain_coordinator.status":     ("brain_coordinator_daemon", _coordinator_status),
    "plain_parquet_sync.ticks":     ("plain_parquet_sync", _parquet_sync_ticks),
    "plain_parquet_mirror.ticks":   ("plain_parquet_mirror_daemon", _parquet_mirror_ticks),
    "iceberg_mirror.ticks":         ("iceberg_mirror_daemon", _iceberg_mirror_ticks),
    "output_gateway.ticks":         ("output_gateway_cleanup", _output_gateway_ticks),
    "iceberg_metadata_sync.runs":   ("iceberg_metadata_sync", _iceberg_sync_runs),
    # The agent tick and the feed queue worker are APScheduler jobs: they run
    # wherever APScheduler runs (the scheduler worker in external mode).
    "feed_failover.state":          ("apscheduler_embedded", _feed_failover_state),
}


def local_snapshot(name: str, limit: Optional[int] = None) -> Any:
    """This process's view.  ``KeyError`` for a name not on the allow-list."""
    _daemon, fn = SNAPSHOTS[name]
    return fn(limit)


def _scheduler_mode() -> Optional[str]:
    try:
        from core.config import scheduler as _sched_cfg
        return str(getattr(_sched_cfg, "mode", "") or "") or None
    except Exception:
        return None


def scheduler_daemons_run_here() -> bool:
    """Does THIS process run the scheduler-owned daemons?

    2026-10-10 -- answered by the GATE THAT STARTED THEM, not by
    configuration.  This used to be the pod-role / scheduler.mode answer
    (hybrid + embedded -> True), while the daemons' actual start gate is the
    scheduler LOCK (``daemon_registry._worker_holds_singleton_role``; every
    singleton starts through ``start_when_singleton`` and APScheduler runs
    only in the lock holder).  On the rig a hybrid api pod in embedded mode
    LOST the lock ("Scheduler lock contended") and ran none of them, yet
    answered ``runs_here: true`` and showed ``running: false`` for a Kafka
    consumer that was running on the scheduler pod -- two answers to "who
    runs this daemon".  Now: an api-role pod never does (its role gate never
    starts them); any other process does iff it holds the lock.  Prefer
    :func:`daemon_runs_here` for a NAMED daemon: it reads the gate's own
    record of what it did for that daemon in this process.
    """
    try:
        from core import pod_role
        if pod_role.current().is_api():
            return False
    except Exception:                                  # noqa: BLE001
        pass
    try:
        from core.daemon_registry import _worker_holds_singleton_role
        return bool(_worker_holds_singleton_role())
    except Exception:                                  # noqa: BLE001
        return (_scheduler_mode() or "embedded") != "external"


def daemon_runs_here(name: str) -> bool:
    """Does THIS process run the scheduler-owned daemon ``name``?

    First-hand when the singleton gate recorded its decision for ``name``
    here (``started`` / ``declined`` = this process is the one that decided
    and answers for it; ``deferred`` = it runs elsewhere), else the lock
    answer of :func:`scheduler_daemons_run_here`.
    """
    try:
        from core.daemon_registry import _SINGLETON_OUTCOMES
        outcome = _SINGLETON_OUTCOMES.get(name)
    except Exception:                                  # noqa: BLE001
        outcome = None
    if outcome is not None:
        return outcome in ("started", "declined")
    return scheduler_daemons_run_here()


def scheduler_worker_configured() -> bool:
    """Is there a scheduler worker whose control API this process can ask?

    ``scheduler.mode=external`` declares one.  2026-10-10: so does an
    embedded-mode pod with ``scheduler.worker_host`` pointed at another host
    (the rig's hybrid api pod: QUERYSTUDIO_SCHEDULER_WORKER_HOST=scheduler)
    -- when such a pod does not run a daemon, the worker answers for it
    instead of this pod's empty copy being shown as the truth.
    """
    if _scheduler_mode() == "external":
        return True
    host = (_worker_host() or "").strip().lower()
    return bool(host) and host not in ("127.0.0.1", "localhost", "::1")


def _worker_host() -> Optional[str]:
    try:
        from core.config import scheduler as _sched_cfg
        return str(getattr(_sched_cfg, "worker_host", "") or "") or None
    except Exception:                                  # noqa: BLE001
        return None


def no_owner_api_reason() -> str:
    return (f"its process exposes no control API in this topology "
            f"(scheduler.mode={_scheduler_mode() or 'unset'}, "
            f"scheduler.worker_host={_worker_host() or 'unset'})")


async def daemon_snapshot(name: str, *, limit: Optional[int] = None,
                          proxy: Optional[Callable[..., Any]] = None
                          ) -> Dict[str, Any]:
    """``{"data", "answered_by", "daemon"[, "warning"]}`` from the process
    that owns the daemon.

    ``proxy`` is ``admin_api._scheduler_worker_proxy`` (async ``(method,
    path)`` -> JSON).  Used only when this process does not run the daemon
    and ``scheduler.mode`` is ``external`` -- the topology in which the
    scheduler worker's control API exists.
    """
    import asyncio
    daemon, _fn = SNAPSHOTS[name]
    if daemon_runs_here(daemon):
        data = await asyncio.to_thread(local_snapshot, name, limit)
        return {"data": data, "answered_by": "this_process", "daemon": daemon}
    why = ("this pod does not run the %s daemon (scheduler-owned); "
           % daemon)
    if proxy is not None and scheduler_worker_configured():
        path = f"/control/daemon-snapshot/{name}"
        if limit is not None:
            path += f"?limit={int(limit)}"
        try:
            remote = await proxy("GET", path)
            if isinstance(remote, dict) and "data" in remote:
                return {"data": remote["data"],
                        "answered_by": "scheduler_worker", "daemon": daemon}
            why += "the scheduler worker answered without a snapshot; "
        except Exception as exc:
            detail = getattr(exc, "detail", None) or str(exc)
            why += f"the scheduler worker could not be reached ({detail}); "
    else:
        why += no_owner_api_reason() + "; "
    data = await asyncio.to_thread(local_snapshot, name, limit)
    logger.info("[daemon-snapshot] %s: %s", name, why.strip())
    return {"data": data, "answered_by": "this_process", "daemon": daemon,
            "warning": why + "the data below is THIS process's copy, which "
                             "is empty when the daemon runs elsewhere -- it "
                             "is not evidence the daemon is idle."}


__all__ = ["SNAPSHOTS", "daemon_snapshot", "local_snapshot",
           "scheduler_daemons_run_here", "daemon_runs_here",
           "scheduler_worker_configured", "no_owner_api_reason"]
