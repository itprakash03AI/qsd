"""Phase 139 honest-fix #3 — Executor protocol + engine registry.

Defines the abstract contract every query-execution engine satisfies. Today
the engines are spread across api/execute_api.py functions; this module
provides the structural target they should converge toward.

Engines:
  duckdb        — local + S3 parquet via DuckDB (default)
  spark_connect — large S3 queries via Spark Connect gRPC (opt-in)
  sql_connector — Snowflake / Trino / Databricks / Oracle (per-connection)
  cross_source  — multi-source UNION / JOIN via DuckDB combine

The registry lets future code dispatch at one place:

    from core.executors.protocol import EngineRegistry, EngineKind
    executor = EngineRegistry.get(EngineKind.DUCKDB)
    result = await executor.execute(...)

Existing in-flight functions (execute_query_background etc.) are NOT moved
in this pass — that's the next refactor. This pass establishes the names
and shape so future passes have a clear migration target.
"""
from __future__ import annotations

import enum
import logging
from dataclasses import dataclass
from typing import Any, Dict, Optional, Protocol, runtime_checkable

logger = logging.getLogger(__name__)


# ── Engine kinds ─────────────────────────────────────────────────────────

class EngineKind(str, enum.Enum):
    DUCKDB        = "duckdb"
    SPARK_CONNECT = "spark_connect"
    SQL_CONNECTOR = "sql_connector"
    CROSS_SOURCE  = "cross_source"
    METADATA_ONLY = "metadata_only"

    @classmethod
    def from_str(cls, s: str) -> "EngineKind":
        """Parse a string to EngineKind. Returns DUCKDB for unknown values."""
        try:
            return cls(s)
        except ValueError:
            logger.debug("unknown engine kind %r — defaulting to DUCKDB", s)
            return cls.DUCKDB


@dataclass
class ExecutionResult:
    """Return shape every executor produces."""
    total_rows:        int
    file_size_bytes:   int
    output_file:       Optional[str]   # local path to parquet result
    chunks_processed:  int = 0
    file_stats:        Optional[Dict[str, Any]] = None
    metadata_only:     bool = False
    engine:            EngineKind = EngineKind.DUCKDB
    extra:             Optional[Dict[str, Any]] = None


@dataclass
class ExecutionRequest:
    """Common request envelope all executors accept."""
    execution_id:        str
    query_config:        Any            # api.models.query_models.QueryConfigModel
    executed_by:         str
    raw_sql:             Optional[str] = None
    cache_strategy:      str = "auto"
    query_id:            Optional[int] = None
    query_config_dict:   Optional[Dict[str, Any]] = None
    cache_key:           Optional[str] = None
    fallback_output:     Optional[str] = None
    # 2026-08-22 (audit round 4, #11).  The envelope now CARRIES the cap, so
    # an executor cannot silently drop it on the way through.  Every
    # published-view cap regression in this codebase has been a sibling
    # dispatch that simply did not pass the limit along.  0 / None mean
    # UNLIMITED, as everywhere else.
    row_limit:           Optional[int] = None


# ── The Executor contract ────────────────────────────────────────────────

@runtime_checkable
class Executor(Protocol):
    """Every engine implements this contract."""

    kind: EngineKind

    async def execute(self, request: ExecutionRequest) -> ExecutionResult:
        """Run the query end-to-end. Writes parquet to disk, broadcasts
        completion via the WS manager, updates the DB, returns metrics."""
        ...

    def supports(self, request: ExecutionRequest) -> bool:
        """Return True if this executor can handle the request."""
        ...


# ── Registry ─────────────────────────────────────────────────────────────

class EngineRegistry:
    """Static registry of executor instances keyed by EngineKind.

    Use:
        EngineRegistry.register(EngineKind.DUCKDB, my_executor)
        ex = EngineRegistry.get(EngineKind.DUCKDB)
        for kind, ex in EngineRegistry.iter_supported(request):
            ...
    """
    _registry: Dict[EngineKind, Executor] = {}

    @classmethod
    def register(cls, kind: EngineKind, executor: Executor) -> None:
        cls._registry[kind] = executor
        logger.info("EngineRegistry: registered %s", kind.value)

    @classmethod
    def get(cls, kind: EngineKind) -> Optional[Executor]:
        return cls._registry.get(kind)

    @classmethod
    def all(cls) -> Dict[EngineKind, Executor]:
        return dict(cls._registry)

    @classmethod
    def iter_supported(cls, request: ExecutionRequest):
        """Yield (kind, executor) pairs whose .supports(request) is True."""
        for kind, ex in cls._registry.items():
            try:
                if ex.supports(request):
                    yield kind, ex
            except Exception as exc:
                logger.debug("EngineRegistry: %s.supports() failed: %s", kind, exc)

    @classmethod
    def clear(cls) -> None:
        """Test helper — clear the registry."""
        cls._registry.clear()
