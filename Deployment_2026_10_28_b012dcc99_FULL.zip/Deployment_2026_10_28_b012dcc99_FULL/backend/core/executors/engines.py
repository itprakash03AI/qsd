"""Phase 139 honest-fix #3 — Executor wrapper classes for the 5 engines.

Wraps the existing async background functions in api/execute_api.py with
classes that satisfy the Executor protocol. ZERO behavior change — the
classes delegate to the existing functions. The point of this pass is to:

  1. Establish the structural target (one class per engine)
  2. Centralise the routing decision (which engine? → supports())
  3. Give future refactor passes a clean place to MOVE function bodies INTO

The actual function bodies still live in api/execute_api.py. A future pass
can copy each body into its respective Executor class, replace the
wrapper's await-call with inline execution, then delete the original.

Engines:
  - DuckDBExecutor          (default — local + S3 parquet via DuckDB)
  - SqlConnectorExecutor    (Trino / Snowflake / Databricks / Oracle)
  - CrossSourceExecutor     (cross-connection UNION / JOIN via DuckDB)
  - SparkConnectExecutor    (zero-download S3 via Spark Connect)
  - MetadataOnlyExecutor    (COUNT(*) / MIN / MAX from manifest stats)
"""
from __future__ import annotations

import logging
from typing import Optional

from core.executors.protocol import (
    EngineKind, Executor, ExecutionRequest, ExecutionResult,
)

logger = logging.getLogger(__name__)


# ── DuckDB (default) ─────────────────────────────────────────────────────

class DuckDBExecutor:
    """Default engine — single-process DuckDB on local + S3 parquet.

    supports():
      - True for any request that:
          * has no cross_connection_id in the query_config
          * is not Spark-routed (engine_override != "spark")
          * is not a connector type (those go to SqlConnectorExecutor)
        DuckDB is the fall-through default.
    """
    kind = EngineKind.DUCKDB

    def supports(self, request: ExecutionRequest) -> bool:
        qc = request.query_config_dict or {}
        if qc.get("cross_connection_id"):
            return False
        # If a SQL connector type is involved, SqlConnectorExecutor handles it
        conn_type = qc.get("connection_type", "")
        if conn_type in {"snowflake", "trino", "starburst", "databricks", "oracle", "athena"}:
            return False
        return True

    async def execute(self, request: ExecutionRequest) -> ExecutionResult:
        """Delegate to api.execute_api.execute_query_background.

        Returns an ExecutionResult derived from the final DB state after
        the function completes (it broadcasts via WS internally).
        """
        from api.execute_api import execute_query_background
        await execute_query_background(
            execution_id=request.execution_id,
            query_config=request.query_config,
            query_id=request.query_id,
            executed_by=request.executed_by,
            raw_sql=request.raw_sql,
            cache_strategy=request.cache_strategy,
            cache_key=request.cache_key,
            query_config_dict=request.query_config_dict,
            fallback_output_file=request.fallback_output,
        )
        return _result_from_db(request.execution_id, EngineKind.DUCKDB)


# ── SQL Connector (Trino / Snowflake / Databricks / Oracle) ──────────────

class SqlConnectorExecutor:
    """Routes SQL connector queries through the connector's execute_query_streaming.

    supports():
      - True for connection_type ∈ {snowflake, trino, starburst, databricks, oracle}
    """
    kind = EngineKind.SQL_CONNECTOR

    SUPPORTED_TYPES = {"snowflake", "trino", "starburst", "databricks", "oracle", "athena"}

    def supports(self, request: ExecutionRequest) -> bool:
        qc = request.query_config_dict or {}
        conn_type = qc.get("connection_type", "")
        return conn_type in self.SUPPORTED_TYPES

    async def execute(self, request: ExecutionRequest) -> ExecutionResult:
        """Delegate to api.execute_api.execute_sql_connector_background.

        The connector instance must be pre-built and attached to the request
        via query_config_dict["_connector_instance"] OR resolved from the
        connection record. For now this wrapper is best-suited to be called
        from execute_api.py's existing dispatch which already has the
        connector — direct callers should construct via _build_connector_for.
        """
        from api.execute_api import execute_sql_connector_background
        qc = request.query_config_dict or {}
        connector = qc.get("_connector_instance")
        sql = qc.get("_resolved_sql") or request.raw_sql or ""
        if connector is None:
            raise RuntimeError(
                "SqlConnectorExecutor needs a pre-built connector instance "
                "in query_config_dict['_connector_instance']. "
                "Build via core.connector_factory.get_connector(...) first."
            )
        await execute_sql_connector_background(
            execution_id=request.execution_id,
            connector=connector,
            sql=sql,
            query_id=request.query_id,
            executed_by=request.executed_by,
            cache_key=request.cache_key,
            cache_strategy=request.cache_strategy,
            query_config_dict=request.query_config_dict,
            row_limit=request.row_limit,
        )
        return _result_from_db(request.execution_id, EngineKind.SQL_CONNECTOR)


# ── Cross-source (multi-connection UNION / JOIN) ─────────────────────────

class CrossSourceExecutor:
    """Multi-source UNION / JOIN combined via DuckDB.

    supports():
      - True when query_config carries a cross_connection_id (i.e. there
        IS a secondary side).
    """
    kind = EngineKind.CROSS_SOURCE

    def supports(self, request: ExecutionRequest) -> bool:
        qc = request.query_config_dict or {}
        return bool(qc.get("cross_connection_id"))

    async def execute(self, request: ExecutionRequest) -> ExecutionResult:
        """Delegate to api.execute_api.execute_cross_query_background.

        Cross-source requires both engines + secondary config to be pre-
        resolved; like SqlConnectorExecutor, this is best called via the
        existing dispatch which has the context already.
        """
        from api.execute_api import execute_cross_query_background
        qc = request.query_config_dict or {}
        primary_engine = qc.get("_primary_engine")
        secondary_engine = qc.get("_secondary_engine")
        secondary_config = qc.get("_secondary_config")
        combine_mode = qc.get("combine_mode", "union")
        join_config = qc.get("join_config")
        if primary_engine is None or secondary_engine is None or secondary_config is None:
            raise RuntimeError(
                "CrossSourceExecutor needs _primary_engine, _secondary_engine, "
                "and _secondary_config in query_config_dict. "
                "Build via the dispatch in execute_api.execute_query_endpoint."
            )
        await execute_cross_query_background(
            execution_id=request.execution_id,
            primary_engine=primary_engine,
            primary_config=request.query_config,
            secondary_engine=secondary_engine,
            secondary_config=secondary_config,
            combine_mode=combine_mode,
            join_config=join_config,
            query_id=request.query_id,
            executed_by=request.executed_by,
            cache_key=request.cache_key,
            cache_strategy=request.cache_strategy,
            query_config_dict=request.query_config_dict,
            primary_raw_sql=qc.get("_primary_raw_sql") or request.raw_sql,
            secondary_raw_sql=qc.get("_secondary_raw_sql"),
            primary_connection_id=qc.get("_primary_connection_id"),
            secondary_connection_id=qc.get("_secondary_connection_id"),
        )
        return _result_from_db(request.execution_id, EngineKind.CROSS_SOURCE)


# ── Spark Connect (opt-in) ───────────────────────────────────────────────

class SparkConnectExecutor:
    """Zero-download S3 queries via Spark Connect gRPC.

    supports():
      - Encapsulates the routing gates from spark_dispatch.should_use_spark_connect.
      - Note: even when this returns True, the actual execution still goes
        through DuckDBExecutor's path (execute_query_background) which
        internally routes to Spark via _execute_via_spark_connect when the
        gates pass. We expose supports() as a query-time hint.
    """
    kind = EngineKind.SPARK_CONNECT

    def supports(self, request: ExecutionRequest) -> bool:
        from core.executors.spark_dispatch import should_use_spark_connect
        qc = request.query_config_dict or {}
        conn_cfg = qc.get("_s3_conn_config", {}) or {}
        engine_override = qc.get("engine_override")
        estimated_rows = int(qc.get("estimated_rows", 0) or 0)
        use_spark, _ = should_use_spark_connect(
            engine_override, conn_cfg, estimated_rows, qc,
        )
        return use_spark

    async def execute(self, request: ExecutionRequest) -> ExecutionResult:
        """Spark routing is currently inlined in execute_query_background.
        Calling this wrapper just delegates back through the DuckDB path
        which will internally route to Spark when supports() is True."""
        return await DuckDBExecutor().execute(request)


# ── Metadata-only fast path ──────────────────────────────────────────────

class MetadataOnlyExecutor:
    """Answer COUNT(*) / MIN / MAX queries from manifest stats / parquet
    footers without scanning data files.

    supports():
      - True when raw_sql matches the metadata-only detector AND the query
        config has exactly 1 file with no joins/aggs/group_by/filters.
    """
    kind = EngineKind.METADATA_ONLY

    def supports(self, request: ExecutionRequest) -> bool:
        if not request.raw_sql:
            return False
        try:
            from core.metadata_only_optimizer import detect_metadata_only_query
            md = detect_metadata_only_query(request.raw_sql)
        except Exception:
            return False
        if not md:
            return False
        qc = request.query_config
        try:
            files = getattr(qc, "files", None) or []
            if len(files) != 1:
                return False
            if (getattr(qc, "joins", None)
                    or getattr(qc, "aggregations", None)
                    or getattr(qc, "group_by", None)
                    or getattr(qc, "filters", None)):
                return False
            return True
        except Exception:
            return False

    async def execute(self, request: ExecutionRequest) -> ExecutionResult:
        """Try the fast path. If it succeeds, return. If not, the caller
        should fall through to the standard DuckDBExecutor — same fail-OPEN
        contract as the inline path."""
        from api.execute_api import _try_metadata_only_fast_path
        from core.metadata_only_optimizer import detect_metadata_only_query
        md = detect_metadata_only_query(request.raw_sql or "")
        if not md:
            raise RuntimeError("MetadataOnlyExecutor: detector returned None")
        # The inline function needs run_engine + output_file; for the wrapper
        # we ask the caller to set them as private fields on the request.
        qc = request.query_config_dict or {}
        run_engine = qc.get("_run_engine")
        output_file = qc.get("_output_file")
        if run_engine is None or output_file is None:
            raise RuntimeError(
                "MetadataOnlyExecutor needs _run_engine and _output_file in "
                "query_config_dict (passed by execute_query_background)."
            )
        ok = await _try_metadata_only_fast_path(
            execution_id=request.execution_id,
            query_config=request.query_config,
            match=md,
            executed_by=request.executed_by,
            run_engine=run_engine,
            output_file=output_file,
            query_id=request.query_id,
        )
        if not ok:
            raise RuntimeError("MetadataOnlyExecutor: fast path declined the query")
        return _result_from_db(request.execution_id, EngineKind.METADATA_ONLY,
                               metadata_only=True)


# ── Helpers ──────────────────────────────────────────────────────────────

def _result_from_db(execution_id: str, kind: EngineKind,
                    metadata_only: bool = False) -> ExecutionResult:
    """Build an ExecutionResult from the DB state after a background function
    completes. Falls back to zero values if the DB lookup fails."""
    try:
        from api.execute_api import _db_manager
        if _db_manager is None:
            raise RuntimeError("_db_manager not initialized")
        rec = _db_manager.get_execution(execution_id) or {}
        return ExecutionResult(
            total_rows=int(rec.get("total_rows", 0) or 0),
            file_size_bytes=int(rec.get("file_size_bytes", 0) or 0),
            output_file=rec.get("output_file"),
            chunks_processed=int(rec.get("chunks_processed", 0) or 0),
            metadata_only=metadata_only,
            engine=kind,
        )
    except Exception as exc:
        logger.debug("_result_from_db lookup failed (%s) — returning empty result", exc)
        return ExecutionResult(
            total_rows=0, file_size_bytes=0, output_file=None,
            engine=kind, metadata_only=metadata_only,
        )


def register_all_engines() -> None:
    """Register all 5 wrapper executors with the EngineRegistry.

    Call this ONCE at startup, after set_execute_dependencies() so the
    underlying functions can resolve their module-level deps.
    """
    from core.executors.protocol import EngineRegistry
    EngineRegistry.register(EngineKind.DUCKDB,         DuckDBExecutor())
    EngineRegistry.register(EngineKind.SQL_CONNECTOR,  SqlConnectorExecutor())
    EngineRegistry.register(EngineKind.CROSS_SOURCE,   CrossSourceExecutor())
    EngineRegistry.register(EngineKind.SPARK_CONNECT,  SparkConnectExecutor())
    EngineRegistry.register(EngineKind.METADATA_ONLY,  MetadataOnlyExecutor())
    logger.info("Phase 139: registered 5 engine executors with EngineRegistry")


def pick_executor(request: ExecutionRequest) -> Optional[Executor]:
    """Pick the most-specific executor for a request.

    Priority:
      1. METADATA_ONLY    (cheapest path, only fires when detector matches)
      2. CROSS_SOURCE     (must short-circuit before connector or duckdb)
      3. SQL_CONNECTOR    (specific connection types)
      4. SPARK_CONNECT    (S3 queries above row threshold, opt-in)
      5. DUCKDB           (default fallback)
    """
    from core.executors.protocol import EngineRegistry
    for kind in (EngineKind.METADATA_ONLY, EngineKind.CROSS_SOURCE,
                 EngineKind.SQL_CONNECTOR, EngineKind.SPARK_CONNECT,
                 EngineKind.DUCKDB):
        ex = EngineRegistry.get(kind)
        if ex is None:
            continue
        try:
            if ex.supports(request):
                return ex
        except Exception as exc:
            logger.debug("pick_executor: %s.supports() failed: %s", kind, exc)
    return None
