"""Phase 139 honest-fix #3 — per-engine executor: Spark Connect routing.

Extracted from api/execute_api.py so the routing-decision logic + circuit
breaker can be tested in isolation. The actual Spark execution still lives
in execute_api._execute_via_spark_connect (it depends on internal state
like _ws_manager and the agent orchestrator).

Public API:
  should_use_spark_connect(...) → (use_spark: bool, reason: str)
  get_spark_breaker()           → circuit breaker singleton
  fallback_message(reason)      → human-readable text or None (silent)
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Optional

logger = logging.getLogger(__name__)


# ── Messages broadcast when Spark routing falls back to DuckDB ──────────
SPARK_FALLBACK_MESSAGES: dict = {
    "disabled":            "Spark Connect is not enabled.",
    "not_s3":              "Spark Connect supports S3 connections only — using DuckDB.",
    "cross_connection":    (
        "Cross-connection queries use DuckDB — "
        "Spark Connect supports single-connection S3 only."
    ),
    "circuit_breaker_open": (
        "Spark Connect server is temporarily unavailable — using DuckDB. "
        "Query may be slower for large datasets."
    ),
    "below_threshold":     None,   # silent — normal DuckDB range
    "user_override":       None,   # user asked for DuckDB explicitly
}


def fallback_message(reason: str) -> Optional[str]:
    """Return the human-readable message for a fallback reason, or None
    if this reason should not be surfaced (silent fallback)."""
    return SPARK_FALLBACK_MESSAGES.get(reason)


class SparkBreaker:
    """Minimal circuit breaker for the Spark Connect server.

    Opens after ``threshold`` consecutive failures; closes after the
    cooldown elapses. Public form of execute_api._SparkBreaker.
    """

    def __init__(self, threshold: int = 3, cooldown: int = 120):
        self._lock = threading.Lock()
        self._state = "closed"          # "closed" | "open" | "half_open"
        self._failures = 0
        self._opened_at = 0.0
        self._threshold = threshold
        self._cooldown = cooldown

    @property
    def is_open(self) -> bool:
        with self._lock:
            if self._state == "open":
                if time.time() - self._opened_at > self._cooldown:
                    self._state = "half_open"
                    return False
                return True
            return False

    def record_success(self) -> None:
        with self._lock:
            self._failures = 0
            self._state = "closed"

    def record_failure(self) -> None:
        with self._lock:
            self._failures += 1
            if self._failures >= self._threshold:
                self._state = "open"
                self._opened_at = time.time()
                logger.warning(
                    "[spark_connect] Circuit breaker OPEN after %d failures",
                    self._failures,
                )

    def reset(self) -> None:
        with self._lock:
            self._failures = 0
            self._state = "closed"
            self._opened_at = 0.0


_spark_breaker: Optional[SparkBreaker] = None
_spark_breaker_lock = threading.Lock()


def get_spark_breaker() -> SparkBreaker:
    """Return (creating lazily) the module-level Spark circuit breaker.

    Reads thresholds from core.config.spark_connect on first call.
    """
    global _spark_breaker
    with _spark_breaker_lock:
        if _spark_breaker is None:
            try:
                from core.config import spark_connect as _sc
                _spark_breaker = SparkBreaker(
                    threshold=_sc.circuit_breaker_failure_threshold,
                    cooldown=_sc.circuit_breaker_cooldown_seconds,
                )
            except Exception:
                _spark_breaker = SparkBreaker()
        return _spark_breaker


def should_use_spark_connect(
    engine_override: Optional[str],
    conn_config: dict,
    estimated_rows: int,
    query_config_dict: Optional[dict],
) -> tuple:
    """Return ``(use_spark: bool, reason: str)`` for the routing decision.

    Public form of execute_api._should_use_spark_connect. Same gates:
      1. engine_override == "duckdb"  → user_override
      2. engine_override == "spark"   → forced (still needs S3 conn)
      3. spark_connect.enabled=False  → disabled
      4. conn is not S3               → not_s3
      5. cross-connection query       → cross_connection
      6. circuit breaker open         → circuit_breaker_open
      7. estimated_rows ≤ threshold   → below_threshold
      else                            → use Spark
    """
    try:
        from core.config import spark_connect as _sc
    except Exception:
        return False, "disabled"

    # 2026-07-15 Iceberg safety floor: Spark reads S3 as plain parquet
    # (snapshot- AND delete-blind), so an Iceberg V2 table routed here silently
    # over-counts.  Divert iceberg-referencing queries to native/DuckDB — even
    # under an explicit spark override, which must not force a wrong result.
    # Uses the CANONICAL detector (single source of truth); fail-safe False on
    # any error so non-iceberg routing is unchanged.
    def _refs_iceberg() -> bool:
        try:
            from core.query_hints import references_iceberg_registered_table
            return references_iceberg_registered_table(
                query_config_dict, (conn_config or {}).get("registered_tables"),
            )
        except Exception:
            return False

    if engine_override == "duckdb":
        return False, "user_override"
    if engine_override == "spark":
        if not (conn_config or {}):
            return False, "not_s3"
        if _refs_iceberg():
            return False, "iceberg_format"
        return True, ""
    if not _sc.enabled:
        return False, "disabled"
    if _refs_iceberg():
        return False, "iceberg_format"
    _is_s3 = bool((conn_config or {}).get("bucket")) or bool((conn_config or {}).get("bucket_name"))
    if not _is_s3:
        return False, "not_s3"
    if (query_config_dict or {}).get("cross_connection_id"):
        return False, "cross_connection"
    if get_spark_breaker().is_open:
        return False, "circuit_breaker_open"
    if estimated_rows < 0 or estimated_rows <= _sc.row_threshold:
        return False, "below_threshold"
    return True, ""
