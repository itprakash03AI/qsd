"""Per-engine executor: the global-capacity ADMISSION rule (Phase 139; 2026-09-28).

ONE decision, made under ONE lock.  Every grant of a per-user query slot
(``QueueManager.acquire_slot`` -- /api/execute's three lanes and the SQL
editor's /api/sql/execute) decides "is the pod at its global cap?" with
:func:`global_refusal` INSIDE the critical section on ``user_query_lock``
that increments the counter.

THE DEFECT THIS CLOSES (found live 2026-09-28, 25 users / 50 workers on
the Docker rig): "Server is at capacity (11/8 concurrent queries)" -- 11
active against a cap of 8.  The global load-shed was CHECK-THEN-ACT:
``execute_api._check_load_shed`` (an inline copy of :func:`check_load_shed`)
read the sum of ``user_query_counts`` and raised at ``>= cap``, but
reserved nothing; the slot was taken later by a separate increment under
the same lock.  Three lanes granted past the cap:

  * the per-user QUEUE path -- a caller that passed the global check,
    waited for a per-user slot, and was then granted with NO second look
    at the global count;
  * the SQL editor's lane (``api/sql_query_api.py``), which incremented
    the counter and never consulted the global cap at all;
  * the agent-retry re-acquires in ``execute_api`` (unchanged: a retry is
    the same run re-taking the slot it released; see the report).

The cap protects pod memory; it leaked exactly under the burst it exists
for.  The verdict is now computed from the counts the lock protects and
the increment happens in the same critical section, so admission can
never carry the count past the cap.  The inline copy in execute_api is
deleted -- a decision made twice is a bug.

The refusal shape is unchanged and lives HERE only
(:class:`AdmissionRefusal`): 503 + ``Retry-After: 5`` with the "Server is
at capacity" text.  Global is decided BEFORE per-user so a single power
user cannot starve the cluster.  The per-user cap on every production
lane is the QUEUE (``acquire_slot``: wait, then 503 ``queue_full`` /
``wait_timeout``); the old ``increment_user_query_count`` -- a second,
callerless increment door answering 429 -- is gone.

THERE IS NO OBSERVE-ONLY PROBE ANY MORE (2026-09-29).  ``check_load_shed``
was the read-only look the business-report lane took at this counter
without ever holding a slot in it -- and the two published-view handlers
over a saved query / a federation view took no look at all.  A cap that
some query paths skip does not bound what it claims to (the cap protects
the pod's memory; a published-view query runs on the same engines).  Every
path that runs a query now takes a slot through
``QueueManager.acquire_slot(..., max_global=)`` -- the report lanes and
every published-view handler through ``core.reports.admission.QuerySlot``
(a global-only grant, ``max_per_user=None``, for the lane whose per-user
bound is its typed pool; a per-user grant charged to the consumer for the
published API).  ``refusal_at`` / ``global_refusal`` are the rule,
:class:`AdmissionRefusal` the wire shape; nothing else decides.

Pure helpers -- no FastAPI / async / DB dependencies (``HTTPException`` is
lazily imported for the refusal).  Tested in isolation.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import ClassVar, Dict, Mapping, Optional

logger = logging.getLogger(__name__)

# Re-export the canonical state from execution_state. We keep that as the
# single source so existing call sites that import from execute_api still
# share the same dict.
from core.execution_state import (  # noqa: E402
    user_query_counts as _user_query_counts,
    user_query_lock as _user_query_lock,
)

LOAD_SHED_RETRY_AFTER_S = 5


def _http_exception(status_code: int, detail: str, headers: Optional[Dict[str, str]] = None):
    """Lazy-import HTTPException so this module loads without fastapi
    (e.g. in unit-test environments)."""
    from fastapi import HTTPException
    return HTTPException(status_code=status_code, detail=detail, headers=headers)


@dataclass(frozen=True)
class AdmissionRefusal:
    """The pod is at its global cap.  ``active`` is the count the verdict
    was taken on, ``cap`` the limit it was compared with.  The wire text
    (503 + Retry-After) is built here and nowhere else."""

    active: int
    cap: int

    status_code: ClassVar[int] = 503

    @property
    def detail(self) -> str:
        return (
            f"Server is at capacity ({self.active}/{self.cap} concurrent queries). "
            f"Try again in a few seconds."
        )

    @property
    def headers(self) -> Dict[str, str]:
        return {"Retry-After": str(LOAD_SHED_RETRY_AFTER_S)}

    def as_http(self):
        """The refusal as the HTTPException the routes raise."""
        return _http_exception(self.status_code, self.detail, self.headers)


def refusal_at(active: int, max_global: int) -> Optional[AdmissionRefusal]:
    """THE rule on a number: ``None`` admits; a refusal when ``active`` is
    at or over ``max_global``.  ``max_global <= 0`` disables the cap."""
    if not max_global or max_global <= 0:
        return None
    if active >= max_global:
        return AdmissionRefusal(int(active), int(max_global))
    return None


def global_refusal(counts: Mapping[str, int], max_global: int) -> Optional[AdmissionRefusal]:
    """The rule over counts the CALLER holds ``user_query_lock`` on.  The
    caller increments in the same critical section on ``None`` -- that is
    what makes the admission atomic (``QueueManager.acquire_slot``)."""
    return refusal_at(sum(counts.values()), max_global)


def decrement_user_query_count(username: str) -> int:
    """Decrement the per-user count. Returns the new value (clamped >= 0)."""
    with _user_query_lock:
        v = max(0, _user_query_counts.get(username, 0) - 1)
        _user_query_counts[username] = v
        return v


def per_user_active_count(username: str) -> int:
    """Inspect-only: read the per-user active count without modifying it."""
    with _user_query_lock:
        return _user_query_counts.get(username, 0)
