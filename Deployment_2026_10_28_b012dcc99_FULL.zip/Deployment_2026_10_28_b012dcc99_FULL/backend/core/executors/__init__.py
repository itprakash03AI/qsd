"""Phase 139 honest-fix #3 — per-engine executor modules.

execute_api.py is ~5,300 lines and growing. This package extracts the
self-contained helpers into focused modules so future contributors can
find the right code and execute_api.py becomes a thinner orchestrator.

Modules:
  concurrency      — global + per-user concurrency gates, load shedding
  spark_dispatch   — Spark Connect routing decision + circuit breaker

The three big async background functions (execute_query_background,
execute_sql_connector_background, execute_cross_query_background) still
live in api/execute_api.py but import their helpers from here. Future
work: extract those into engine-specific Executor classes.
"""
