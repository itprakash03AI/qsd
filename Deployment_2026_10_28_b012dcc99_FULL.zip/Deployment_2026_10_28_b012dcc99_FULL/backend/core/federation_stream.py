"""Bounded-memory result write for the federation / Business Report engine.

WHY THIS MODULE EXISTS
----------------------
``FederationEngine.execute_dataset_query`` used to materialise the WHOLE
result as one pandas DataFrame in the API pod — ``fetchdf()`` on both DuckDB
routes, and one ``execute_sql_to_dataframe`` DataFrame on the connector route —
and only the WRITE was streamed (``df_to_parquet_streaming``).  Peak memory was
therefore ``O(total_rows x row_width)``, and ``federation.max_result_rows``
(500K) was the only thing standing between a wide result and an OOM that takes
the pod down along with every interactive user sharing it.  Raising that cap
without fixing the write walks straight into the OOM the cap exists to prevent.

This is the SAME shape the codebase already proved twice, not a third design:

  * the Published API bulk export (``api/published_views/bulk.py``) streams a
    stable parquet artifact with ``pf.iter_batches`` -> encode -> yield, and
    measured FLAT at 12.7 MB from 25k to 1M rows;
  * ``duckdb_subprocess._progressive_concat_parts`` concatenates COPY parts
    through ``iter_batches`` into ONE ``ParquetWriter`` at O(one batch);
  * ``connector_to_parquet.execute_sql_to_parquet`` — the Phase 154 chokepoint —
    already streams a SQL-connector cursor straight to parquet.  The federation
    engine simply never called it.

So the piece that was missing is only the DuckDB half: pull the result through
``to_arrow_reader()`` and write each ``RecordBatch`` into one ``ParquetWriter``.
Peak memory becomes O(one batch), and the artifact on disk is unchanged — which
matters, because everything downstream (the microcube, the agg cache
write-through, the paged viewer, retention) already reads that artifact rather
than the DataFrame.

WHAT THIS DELIBERATELY DOES NOT DO
----------------------------------
It does not touch ``federation.max_result_rows``.  That clamp is DISCLOSED
truncation (``row_limit`` / ``truncated`` / ``unstable_truncation``, 122a8c30)
that downstream consumers read; it stops being a memory bound once the write is
streamed, but it remains a policy bound, and changing a disclosed number is an
operator decision, not a side effect of a performance fix.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

# Rows per arrow batch pulled out of DuckDB.  The width-aware helper is the
# same one duckdb_subprocess uses to size row groups, so a wide result yields
# SMALLER batches and peak memory stays bounded in BYTES rather than in rows —
# a 400-column result at a fixed 64k rows would be the OOM this module removes.
_DEFAULT_BATCH_ROWS = 65_536
_MIN_BATCH_ROWS = 1_024


def _batch_rows_for_width(n_columns: int) -> int:
    """Rows per batch for a result of the given width (fail-open to a default)."""
    try:
        from core.parquet_write_opts import row_group_rows_for_width
        rows = int(row_group_rows_for_width(max(1, int(n_columns)),
                                            max_rows=_DEFAULT_BATCH_ROWS))
        return max(_MIN_BATCH_ROWS, rows)
    except Exception:  # noqa: BLE001 - sizing must never fail the query
        return _DEFAULT_BATCH_ROWS


class ParquetBatchSink:
    """Write ``pyarrow.RecordBatch`` objects into ONE parquet file.

    The writer is created from the FIRST batch's schema, which is also how
    ``ParquetStreamWriter`` and ``_progressive_concat_parts`` behave.  A result
    with no rows still produces a valid, typed, EMPTY parquet file — callers
    (the microcube, the viewer, ``pd.read_parquet``) require the artifact to
    exist, and a missing file would turn "zero rows" into a crash.
    """

    def __init__(self, output_path: str, compression: str = "zstd"):
        self.output_path = output_path
        self.compression = compression
        self._writer = None
        self._schema = None
        self.total_rows = 0

    @property
    def column_names(self) -> List[str]:
        return list(self._schema.names) if self._schema is not None else []

    def _ensure_writer(self, schema) -> None:
        if self._writer is not None:
            return
        import pyarrow.parquet as pq
        os.makedirs(os.path.dirname(self.output_path) or ".", exist_ok=True)
        self._schema = schema
        self._writer = pq.ParquetWriter(
            self.output_path, schema, compression=self.compression)

    def write_batch(self, batch) -> None:
        if batch is None:
            return
        if batch.num_rows == 0:
            # Pin the schema anyway: a stream of nothing but empty batches must
            # still produce a typed file, not a missing one.
            self._ensure_writer(batch.schema)
            return
        self._ensure_writer(batch.schema)
        self._writer.write_batch(batch)
        self.total_rows += batch.num_rows

    def finalise(self, schema=None) -> "ParquetBatchSink":
        """Close the writer, creating a typed-empty file if nothing arrived."""
        if self._writer is None:
            if schema is None:
                raise ValueError(
                    "ParquetBatchSink.finalise: no batches were written and no "
                    "schema was supplied — refusing to leave the artifact missing")
            self._ensure_writer(schema)
        try:
            self._writer.close()
        finally:
            self._writer = None
        return self

    def abandon(self) -> None:
        """Close and remove a partial file after a failure mid-stream."""
        try:
            if self._writer is not None:
                self._writer.close()
        except Exception:  # noqa: BLE001
            pass
        self._writer = None
        try:
            if os.path.exists(self.output_path):
                os.remove(self.output_path)
        except OSError as exc:
            logger.debug("could not remove partial artifact %s: %s",
                         self.output_path, exc)


def duckdb_result_to_parquet(
    result,
    output_path: str,
    *,
    execution_id: str = "",
    label: str = "duckdb",
    compression: str = "zstd",
) -> Dict[str, Any]:
    """Stream a DuckDB result straight to parquet at O(one batch) memory.

    ``result`` is what ``con.execute(sql)`` returns.  ``to_arrow_reader`` is the
    current spelling; ``fetch_record_batch`` is its deprecated predecessor and
    is accepted so this works across the DuckDB versions in the fleet.

    Returns ``{"total_rows", "columns", "file_size_bytes"}``.  Raises on any
    reader/writer failure AFTER removing the partial artifact — a half-written
    parquet that later reads as a short result is exactly the silent data loss
    this codebase keeps getting bitten by.
    """
    n_cols = 0
    try:
        desc = getattr(result, "description", None)
        n_cols = len(desc) if desc else 0
    except Exception:  # noqa: BLE001
        n_cols = 0
    batch_rows = _batch_rows_for_width(n_cols)

    if hasattr(result, "to_arrow_reader"):
        reader = result.to_arrow_reader(batch_rows)
    elif hasattr(result, "fetch_record_batch"):
        reader = result.fetch_record_batch(batch_rows)
    else:  # pragma: no cover - every supported DuckDB has one of the two
        raise RuntimeError(
            "DuckDB result exposes neither to_arrow_reader nor "
            "fetch_record_batch — cannot stream this result")

    sink = ParquetBatchSink(output_path, compression=compression)
    try:
        for batch in reader:
            sink.write_batch(batch)
        sink.finalise(schema=getattr(reader, "schema", None))
    except BaseException:
        sink.abandon()
        raise
    finally:
        try:
            reader.close()
        except Exception:  # noqa: BLE001 - close is best-effort
            pass

    size = os.path.getsize(output_path) if os.path.exists(output_path) else 0
    logger.info("[%s] %s streamed %d rows to parquet (%d cols, batch=%d rows, "
                "%.1f MB on disk) — peak memory is O(one batch), not O(result)",
                execution_id, label, sink.total_rows, len(sink.column_names),
                batch_rows, size / (1024 * 1024))
    return {
        "total_rows": sink.total_rows,
        "columns": sink.column_names,
        "file_size_bytes": size,
    }
