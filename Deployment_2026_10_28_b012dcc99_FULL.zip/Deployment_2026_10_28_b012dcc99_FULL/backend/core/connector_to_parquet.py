"""Single chokepoint: SQL connector -> parquet file with bounded memory.

2026-06-24 -- strategic consolidation per operator directive: "complete
end to end ... no more gaps ... brain is not smart".

Before this module, FIVE distinct write patterns lived across the
codebase:

  1. ``execute_sql_connector_background``        (interactive BQB/CQB/PA)
       streaming + ParquetStreamWriter (commit f7fe439)
  2. ``feed_engine`` SQL connector path           (Feed Gen)
       per-chunk pyarrow.ParquetWriter
  3. ``cross_source_engine`` single-source        (Reports + DataFlow)
       blocking execute_query + df.to_parquet     OOM RISK
  4. ``cross_source_engine`` join                 (Reports cross-source)
       blocking execute_query (x2) + df.merge + df.to_parquet  OOM RISK
  5. ``federation_engine`` dataset / merged       (Federation views)
       blocking execute_query + df.to_parquet     OOM RISK

Three of those five had memory risk -- 170M-row Trino reports could
OOM the pod even though the interactive path was already fixed.
Operator: "how can we have such gaps".

Strategic chokepoint:

  ``execute_sql_to_parquet``   ONE helper that takes a connector +
                                SQL + output_path and writes the
                                parquet file with bounded memory.
                                Uses connector.execute_query_streaming
                                + ParquetStreamWriter under the hood.
                                Fallback to blocking execute_query
                                when the connector lacks streaming.

  ``df_to_parquet_streaming``  ONE helper for writing an already-
                                in-memory DataFrame (e.g. join result)
                                to parquet via the same streaming
                                writer.  Slices the DataFrame into
                                batches so peak memory matches the
                                bounded-queue contract.

  ``df_chunks_to_parquet_streaming``
                                ONE helper for callers holding a chunk
                                *generator* rather than a DataFrame.
                                Never concatenates, so the caller does
                                not have to cap rows to stay in memory.

Every connector-writes-parquet site consumes one of these.  Future
features inherit the bounded-memory contract automatically -- no per-
site re-implementation.

Used by (single chokepoint):
  * api/execute_api.execute_sql_connector_background
  * core/cross_source_engine (3 sites)
  * core/federation_engine (2 sites)
  * core/feed_engine (consolidation -- post this commit)
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple
from core.best_effort import note_best_effort

logger = logging.getLogger(__name__)

#: Bounded queue depth between the fetch and write threads -- the default
#: of every streaming entry point below.  A run holds up to this many
#: fetched batches PLUS the one being fetched and the one being written
#: (``STREAM_BATCHES_IN_FLIGHT``); core.feed.batch_budget sizes the fetch
#: from it (2026-10-11).
DEFAULT_QUEUE_MAXSIZE = 4
STREAM_BATCHES_IN_FLIGHT = DEFAULT_QUEUE_MAXSIZE + 2


def execute_sql_to_parquet(
    connector,
    sql: str,
    output_path: str,
    *,
    row_limit: Optional[int] = None,
    cancel_event=None,
    chunk_size: int = 10_000,
    queue_maxsize: int = DEFAULT_QUEUE_MAXSIZE,
    compression: str = "zstd",
) -> Dict[str, Any]:
    """Single chokepoint -- stream a SQL connector result into a parquet
    file with bounded memory.

    Uses ``connector.execute_query_streaming`` + ``ParquetStreamWriter``
    so the peak resident memory cost is
    ``(chunk_size * row_bytes * queue_maxsize)``, NOT
    ``(total_rows * row_bytes)``.

    Args:
        connector:     A core.connectors.base.SqlConnector instance.
                        Caller is responsible for connector lifecycle
                        (connect/close).  This helper does NOT call
                        connector.close() so callers can reuse for
                        follow-on queries.
        sql:           Complete SQL to execute.
        output_path:   Filesystem path where the parquet file is
                        written.  Parent dir must exist.
        row_limit:     Optional cap on rows fetched.  When set, the
                        helper stops fetching as soon as the cap is
                        reached -- protects against runaway queries.
        cancel_event:  threading.Event; when set mid-stream, the
                        connector's cursor.cancel() fires + the
                        ParquetStreamWriter drops the partial file.
        chunk_size:    Rows per fetchmany batch (default 10k).
        queue_maxsize: Bounded queue depth between fetch + write
                        threads.  Memory bound = chunk_size *
                        row_bytes * queue_maxsize.

    Returns:
        ``{"total_rows": int, "file_size_bytes": int, "columns": [...]}``

    Raises:
        InterruptedError on cancel_event mid-stream.
        Any underlying connector / writer exception (caller decides
        whether to retry / fallback).
    """
    from core.parquet_stream_writer import ParquetStreamWriter
    import os
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    # 0 (and any non-positive) is the product's spelling of UNLIMITED -- see
    # _resolve_report_row_limit and federation_engine.  Normalise it to None
    # HERE so neither the connector's LIMIT clause nor the client-side stop
    # below can read it as "stop at zero rows".  Without this, `row_limit=0`
    # broke out after the very first chunk and reported SUCCESS.
    row_limit = None if (row_limit is None or int(row_limit) <= 0) else int(row_limit)

    col_defs: List[Dict[str, Any]] = []
    col_names: List[str] = []
    writer: Optional[ParquetStreamWriter] = None
    total_rows = 0
    try:
        # Try streaming first.  Most connectors override; fallback
        # path below covers the ones that don't.
        try:
            for chunk_cols, chunk_rows in connector.execute_query_streaming(
                sql, chunk_size=chunk_size,
                limit=row_limit, cancel_event=cancel_event,
            ):
                if cancel_event is not None and cancel_event.is_set():
                    if writer is not None:
                        writer.cancel()
                    raise InterruptedError("Cancelled by user")
                if not chunk_cols:
                    continue
                if not col_defs:
                    col_defs = chunk_cols
                    col_names = [c.get("name", "") for c in col_defs]
                if not chunk_rows:
                    continue
                if writer is None:
                    writer = ParquetStreamWriter(
                        output_path=output_path,
                        columns=col_defs,
                        queue_maxsize=queue_maxsize,
                        compression=compression,
                    )
                    writer.start()
                # Connector contract: rows_chunk can be list of dicts
                # OR list of tuples.  Normalise to tuples so
                # ParquetStreamWriter's column-position write works
                # for both shapes.
                if chunk_rows and isinstance(chunk_rows[0], dict):
                    chunk_rows = [
                        tuple(r.get(n) for n in col_names)
                        for r in chunk_rows
                    ]
                # 2026-08-19 -- TRUNCATE TO THE BUDGET BEFORE WRITING.
                # This used to write the whole chunk and only then check the
                # cap, so a row_limit of 10 against a chunk_size of 10,000
                # wrote 10,000 rows and reported them as total_rows.  A cap
                # may throttle, but it may not hand back MORE rows than were
                # asked for and call that the answer -- the caller sizes
                # downloads and previews off this number.
                if row_limit is not None:
                    remaining = row_limit - total_rows
                    if remaining <= 0:
                        break
                    if len(chunk_rows) > remaining:
                        chunk_rows = chunk_rows[:remaining]
                writer.put_batch(chunk_rows, timeout=300)
                total_rows += len(chunk_rows)
                if row_limit is not None and total_rows >= row_limit:
                    break
        except NotImplementedError:
            # Connector lacks streaming -- one blocking fetch, then
            # write the whole result in a single batch.  Memory
            # bound = result_size for these connectors (rare; only
            # legacy / mock implementations).
            result = connector.execute_query(sql, limit=row_limit)
            col_defs = result.get("columns") or []
            col_names = [c.get("name", "") for c in col_defs]
            all_rows = result.get("rows") or []
            # 2026-08-19 -- do not TRUST the connector to have honoured the
            # limit.  The streaming path truncates precisely; this fallback
            # took the connector's word for it, so an implementation that
            # ignores `limit` returned more rows than were asked for and
            # reported the oversized count as the answer.
            if row_limit is not None and int(row_limit) > 0:
                if len(all_rows) > int(row_limit):
                    all_rows = all_rows[:int(row_limit)]
            total_rows = len(all_rows)
            if total_rows > 0 and col_defs:
                if all_rows and isinstance(all_rows[0], dict):
                    all_rows = [
                        tuple(r.get(n) for n in col_names)
                        for r in all_rows
                    ]
                writer = ParquetStreamWriter(
                    output_path=output_path, columns=col_defs,
                    queue_maxsize=queue_maxsize, compression=compression,
                )
                writer.start()
                writer.put_batch(all_rows, timeout=300)

        # Drain + close.
        if writer is not None:
            writer.signal_end()
            _written = writer.finalise(timeout=1800)
            writer.close()
            if _written:
                total_rows = _written

        # Empty-result fallback -- write a typed-empty parquet so
        # downstream readers don't 404.
        #
        # 2026-10-07 (feed lane contract, B6) -- TYPED BY THE SOURCE'S
        # DECLARED TYPES, the same mapping the streaming writer applies to
        # a column whose first batch is all NULL (ints int64, decimals at
        # (38, their scale), timestamps microsecond, ...), falling back to
        # string only for a type it cannot map.  Every column used to be a
        # string here, so a counterparty's parquet schema changed on the
        # days a feed had no rows -- and the Spark lane's empty file kept
        # the real types, so it also depended on routing.
        if total_rows == 0:
            import pyarrow as pa
            import pyarrow.parquet as pq
            from core.parquet_stream_writer import _arrow_type_for_declared
            empty_cols = col_names or []
            declared = {c.get("name", ""): c.get("type") for c in col_defs
                        if isinstance(c, dict)}
            empty_schema = pa.schema(
                [pa.field(n, _arrow_type_for_declared(declared.get(n), pa)
                          or pa.string()) for n in empty_cols])
            pq.write_table(empty_schema.empty_table(), output_path,
                           compression=compression)

        file_size = os.path.getsize(output_path) if os.path.exists(output_path) else 0
        return {
            "total_rows":      total_rows,
            "file_size_bytes": file_size,
            "columns":         col_defs,
        }
    finally:
        if writer is not None:
            try:
                writer.close()
            except Exception as _be_exc:
                note_best_effort("writer.close()", _be_exc,
                                 logger=logger)


def df_to_parquet_streaming(
    df,
    output_path: str,
    *,
    batch_size: int = 50_000,
    queue_maxsize: int = DEFAULT_QUEUE_MAXSIZE,
    compression: str = "zstd",
) -> Dict[str, Any]:
    """Sibling chokepoint -- write an already-in-memory DataFrame
    (e.g. cross-source JOIN result) to parquet via the streaming
    writer.

    The DataFrame is sliced into ``batch_size`` chunks and pushed
    through ``ParquetStreamWriter``.  Peak resident parquet-write
    cost stays bounded; the source DataFrame itself is the caller's
    memory (intrinsic to in-memory joins).

    Args:
        df:           pandas DataFrame to write.
        output_path:  Filesystem path.  Parent dir must exist.
        batch_size:   Rows per parquet-write batch (default 50k).
        queue_maxsize: Bounded queue depth.

    Returns:
        ``{"total_rows": int, "file_size_bytes": int}``
    """
    from core.parquet_stream_writer import ParquetStreamWriter
    import os

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    col_names = list(df.columns)
    col_defs = [{"name": n} for n in col_names]

    if len(df) == 0:
        # Empty DataFrame -- write typed-empty parquet.  2026-10-11: typed
        # from the frame's OWN dtypes (an all-object / null column, which
        # pandas cannot type, becomes a string); every column used to be a
        # string whatever the frame declared.
        import pyarrow as pa
        import pyarrow.parquet as pq
        try:
            inferred = pa.Schema.from_pandas(df, preserve_index=False)
        except Exception:  # noqa: BLE001 -- an untypeable frame keeps the string fallback
            inferred = None
        fields = []
        for n in col_names:
            t = None
            if inferred is not None and n in inferred.names:
                t = inferred.field(n).type
                if pa.types.is_null(t):
                    t = None
            fields.append(pa.field(n, t or pa.string()))
        pq.write_table(pa.schema(fields).empty_table(),
                       output_path, compression=compression)
        return {"total_rows": 0,
                "file_size_bytes": os.path.getsize(output_path)}

    writer = ParquetStreamWriter(
        output_path=output_path, columns=col_defs,
        queue_maxsize=queue_maxsize, compression=compression,
    )
    writer.start()
    try:
        # Slice the DataFrame into batches of tuples.
        n = len(df)
        for start in range(0, n, batch_size):
            end = min(start + batch_size, n)
            chunk = df.iloc[start:end].itertuples(index=False, name=None)
            writer.put_batch(list(chunk), timeout=300)
        writer.signal_end()
        written = writer.finalise(timeout=1800)
        return {
            "total_rows": written,
            "file_size_bytes": os.path.getsize(output_path),
        }
    finally:
        writer.close()


def df_chunks_to_parquet_streaming(
    chunks,
    output_path: str,
    *,
    batch_size: int = 50_000,
    queue_maxsize: int = DEFAULT_QUEUE_MAXSIZE,
    compression: str = "zstd",
) -> Dict[str, Any]:
    """Sibling chokepoint -- write an ITERABLE of DataFrames to parquet
    without ever concatenating them.

    ``df_to_parquet_streaming`` bounds the parquet *write*, but its caller
    has already paid for the whole result in memory.  Callers that hold a
    chunk *generator* (the parquet engines' ``execute_query``) were doing::

        df = pd.concat(list(engine.execute_query(config)))
        df_to_parquet_streaming(df, path)

    which materialises every row before the bounded writer ever sees one.
    That is why those call sites carried a row cap: the cap was propping up
    the materialisation, not expressing a product limit.  Consuming the
    generator lazily removes the reason for the cap, so an unlimited query
    streams at bounded memory instead of truncating or OOMing.

    Args:
        chunks:       Iterable of pandas DataFrames (may be empty / lazy).
        output_path:  Filesystem path.  Parent dir must exist.
        batch_size:   Rows per parquet-write batch (default 50k).
        queue_maxsize: Bounded queue depth.

    Returns:
        ``{"total_rows": int, "file_size_bytes": int}``
    """
    from core.parquet_stream_writer import ParquetStreamWriter
    import os

    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    iterator = iter(chunks)
    first = None
    for candidate in iterator:
        # Skip leading empty frames -- they carry no rows but may carry the
        # column names we need to open the writer.
        if first is None:
            first = candidate
        if len(candidate) > 0:
            first = candidate
            break

    if first is None:
        # No chunks at all -- delegate the typed-empty write.
        import pandas as pd
        return df_to_parquet_streaming(
            pd.DataFrame(), output_path, compression=compression)

    col_names = list(first.columns)
    col_defs = [{"name": n} for n in col_names]

    writer = ParquetStreamWriter(
        output_path=output_path, columns=col_defs,
        queue_maxsize=queue_maxsize, compression=compression,
    )
    writer.start()
    try:
        def _feed(frame) -> None:
            n = len(frame)
            for start in range(0, n, batch_size):
                end = min(start + batch_size, n)
                rows = frame.iloc[start:end].itertuples(index=False, name=None)
                writer.put_batch(list(rows), timeout=300)

        _feed(first)
        for frame in iterator:
            if len(frame) == 0:
                continue
            _feed(frame)

        writer.signal_end()
        written = writer.finalise(timeout=1800)
        return {
            "total_rows": written,
            "file_size_bytes": os.path.getsize(output_path),
        }
    finally:
        writer.close()


def execute_sql_to_dataframe(
    connector,
    sql: str,
    *,
    row_limit: Optional[int] = None,
    cancel_event=None,
    chunk_size: int = 10_000,
) -> "Tuple[Any, List[Dict[str, Any]], int]":
    """Streaming fetch -> single pandas DataFrame.

    Use this for cross-source / federation JOIN intermediates that
    MUST hold a DataFrame in memory (intrinsic to in-memory merge).
    Beats ``connector.execute_query`` because:

      * No list-of-dicts intermediate (peak ~2-3x DataFrame size).
      * cancel_event honoured mid-stream.
      * NotImplementedError -> falls back to blocking execute_query.

    Returns ``(df, columns, total_rows)``.
    """
    import pandas as pd

    # See execute_sql_to_parquet -- non-positive means UNLIMITED, not "zero
    # rows".  Normalise before it reaches the connector or the stop below.
    row_limit = None if (row_limit is None or int(row_limit) <= 0) else int(row_limit)

    col_defs: List[Dict[str, Any]] = []
    col_names: List[str] = []
    frames: List[Any] = []
    total = 0
    try:
        for chunk_cols, chunk_rows in connector.execute_query_streaming(
            sql, chunk_size=chunk_size,
            limit=row_limit, cancel_event=cancel_event,
        ):
            if cancel_event is not None and cancel_event.is_set():
                raise InterruptedError("Cancelled by user")
            if chunk_cols and not col_defs:
                col_defs = chunk_cols
                col_names = [c.get("name", "") for c in col_defs]
            if not chunk_rows:
                continue
            # 2026-08-20 -- TRUNCATE THE CHUNK, not just stop after it.
            # The 2026-08-19 overshoot fix (see execute_sql_to_parquet
            # above) was applied to the parquet sibling ONLY, and the
            # commit generalised the claim to "a cap may not hand back
            # MORE rows than were asked for".  Here it still could: the
            # whole chunk was appended and the break tested AFTERWARDS, so
            # row_limit=10 against a 1,000-row chunk returned 1,000 rows
            # and reported 1,000 as total_rows.  Live via row_limit from
            # cross_source_engine's primary/secondary legs.
            if row_limit is not None:
                remaining = row_limit - total
                if remaining <= 0:
                    break
                if len(chunk_rows) > remaining:
                    chunk_rows = chunk_rows[:remaining]
            if isinstance(chunk_rows[0], dict):
                frames.append(pd.DataFrame(chunk_rows))
            else:
                frames.append(pd.DataFrame(chunk_rows, columns=col_names))
            total += len(chunk_rows)
            if row_limit is not None and total >= row_limit:
                break
        if not frames:
            return pd.DataFrame(columns=col_names), col_defs, 0
        df = pd.concat(frames, ignore_index=True)
        return df, col_defs, len(df)
    except NotImplementedError:
        # Connector lacks streaming -- blocking fetch fallback.
        result = connector.execute_query(sql, limit=row_limit)
        col_defs = result.get("columns") or []
        col_names = [c.get("name", "") for c in col_defs]
        rows = result.get("rows") or []
        # 2026-08-20 -- do not TRUST the connector to have honoured the
        # limit, same as the parquet sibling's fallback.  A connector that
        # ignores `limit` handed back its whole result and the row count
        # was reported as the answer.
        if row_limit is not None and len(rows) > row_limit:
            rows = rows[:row_limit]
        if not rows:
            return pd.DataFrame(columns=col_names), col_defs, 0
        if isinstance(rows[0], dict):
            df = pd.DataFrame(rows)
        else:
            df = pd.DataFrame(rows, columns=col_names)
        return df, col_defs, len(df)


def execute_sql_to_parts(
    connector,
    sql: str,
    parts_dir: str,
    *,
    rows_per_part: int = 5_000_000,
    row_limit: Optional[int] = None,
    cancel_event=None,
    chunk_size: int = 10_000,
    queue_maxsize: int = DEFAULT_QUEUE_MAXSIZE,
    compression: str = "zstd",
    resume: bool = False,
    resume_max_age_seconds: int = 86_400,
    dialect: Optional[str] = None,
    source_meta: Optional[Dict[str, Any]] = None,
    on_part_complete=None,
) -> Dict[str, Any]:
    """Write ladder RUNG 3 — native streaming, PART-ROTATED.

    Same bounded-memory streaming contract as ``execute_sql_to_parquet``
    (this module's whole reason to exist), but the output is a PARTS
    DIRECTORY: ``part-00000.parquet``, ``part-00001.parquet``, … plus a
    manifest (core.feed.parts_manifest).  The writer rotates every
    ``rows_per_part`` rows; after each rotation the PARTIAL manifest is
    re-written atomically, so a crashed run leaves a durable record of
    exactly which rows already exist — the resume unit.

    ``rows_per_part <= 0`` means NEVER ROTATE (one part).  That is a
    declared semantic, not a 0==unlimited fold: rotation is an output
    SHAPE, not a cap — no value of this knob drops rows.

    Resume (``resume=True``): a partial manifest in ``parts_dir`` is
    honoured only when ALL of the following hold, and each refusal is a
    logged, distinct reason (never a silent restart):
      * its ``sql_sha256`` matches THIS statement (resuming someone
        else's parts is row corruption);
      * every completed part's parquet footer matches the manifest
        (verify_local_parts);
      * the SQL has a stable outer ORDER BY **and** the engine-side
        OFFSET rewrite is provably safe for ``dialect``
        (``stream_cursor_session._sql_with_offset`` — the same helper
        the cursor grid uses; one implementation, not a fork).  A
        spliced UNORDERED resume is silent row corruption — the one
        outcome that is never acceptable — so without a provable order
        the parts are wiped and the run restarts from zero.

    ``on_part_complete(PartInfo)`` fires after each part is durable —
    the "serve parts as they land" hook for the Published API.

    Cancel/failure leave completed parts + the partial manifest IN
    PLACE (they are the resume artifact); only the in-flight part file
    is dropped.

    Returns ``{"total_rows", "parts", "manifest_path", "resumed_rows",
    "file_size_bytes", "columns"}``.
    """
    import base64 as _b64
    import uuid as _uuid
    from pathlib import Path

    import pyarrow as pa
    import pyarrow.parquet as pq

    from core.feed.parts_manifest import (
        PartInfo, PartsManifest, PartsManifestError,
        load_manifest, verify_local_parts, sql_sha256,
        PARTIAL_MANIFEST_NAME, MANIFEST_NAME,
    )
    from core.parquet_stream_writer import ParquetStreamWriter

    parts_path = Path(parts_dir)
    parts_path.mkdir(parents=True, exist_ok=True)

    row_limit = None if (row_limit is None or int(row_limit) <= 0) else int(row_limit)
    rotate_every = int(rows_per_part)
    _sql_hash = sql_sha256(sql)

    def _wipe_parts(reason: str) -> None:
        logger.info("[parts] restart from zero (%s) — clearing %s",
                    reason, parts_path)
        for child in parts_path.iterdir():
            if child.name.endswith(".parquet") or child.name in (
                    MANIFEST_NAME, PARTIAL_MANIFEST_NAME):
                try:
                    child.unlink()
                except OSError as _rm_exc:
                    raise RuntimeError(
                        f"cannot clear stale part {child} for a clean "
                        f"restart: {_rm_exc}") from _rm_exc

    # ── Resume decision ──────────────────────────────────────────────
    manifest: Optional[PartsManifest] = None
    resumed_rows = 0
    effective_sql = sql
    if resume:
        try:
            prev, _src = load_manifest(parts_path, allow_partial=True)
        except PartsManifestError:
            prev = None
        if prev is not None and prev.status == "complete":
            # A COMPLETE manifest for the same SQL is already the answer.
            if prev.sql_sha256 == _sql_hash:
                logger.info("[parts] complete manifest already present for "
                            "this SQL — nothing to do")
                return {
                    "total_rows": prev.total_rows,
                    "parts": len(prev.parts),
                    "manifest_path": str(parts_path / MANIFEST_NAME),
                    "resumed_rows": prev.total_rows,
                    "file_size_bytes": prev.total_bytes,
                    "columns": [{"name": c} for c in prev.columns()],
                }
            _wipe_parts("complete manifest belongs to a DIFFERENT statement")
            prev = None
        if prev is not None:
            import time as _time_rs
            _age = _time_rs.time() - float(prev.created_at or 0.0)
            if (resume_max_age_seconds > 0
                    and _age > resume_max_age_seconds):
                # Identical SQL days apart can still mean DIFFERENT data
                # (the source moved); the sql-hash and order guards
                # cannot see that.  Age is the contract: an old partial
                # restarts from zero, DECLARED.  0 disables the cap —
                # a declared semantic, not a 0==unlimited fold.
                _wipe_parts(
                    f"partial build is {_age / 3600.0:.1f}h old "
                    f"(> resume_max_age_seconds={resume_max_age_seconds})")
            elif prev.sql_sha256 != _sql_hash:
                _wipe_parts("partial manifest belongs to a DIFFERENT statement")
            else:
                try:
                    verify_local_parts(parts_path, prev)
                except PartsManifestError as _v_exc:
                    _wipe_parts(f"completed parts failed verification: {_v_exc}")
                else:
                    skip = int(prev.total_rows)
                    if skip == 0:
                        manifest = prev
                        logger.info("[parts] resume: no rows durable yet — "
                                    "restarting the stream, keeping build_id")
                    else:
                        from core.stream_cursor_session import (
                            sql_has_stable_order, _sql_with_offset,
                        )
                        seek = (_sql_with_offset(sql, skip, dialect or "")
                                if sql_has_stable_order(sql) else None)
                        if seek is None:
                            _wipe_parts(
                                f"{skip} row(s) are durable but the SQL has "
                                f"no provable stable order (or dialect "
                                f"{dialect!r} has no safe OFFSET rewrite) — "
                                f"a spliced unordered resume is silent row "
                                f"corruption")
                        else:
                            manifest = prev
                            resumed_rows = skip
                            effective_sql = seek
                            logger.info(
                                "[parts] RESUMING at row %d across %d "
                                "completed part(s) via engine-side OFFSET",
                                skip, len(prev.parts))
    else:
        # Not resuming: a stale dir is an error waiting to be served.
        if any(parts_path.glob("*.parquet")) or (
                parts_path / PARTIAL_MANIFEST_NAME).exists() or (
                parts_path / MANIFEST_NAME).exists():
            _wipe_parts("resume not requested")

    if manifest is None:
        manifest = PartsManifest(
            sql_sha256=_sql_hash,
            build_id=f"native:{_uuid.uuid4().hex[:12]}",
            source=dict(source_meta or {}, rung="native_stream"),
        )

    if row_limit is not None and resumed_rows >= row_limit:
        # Everything the budget allows is already durable.
        manifest.finalize(parts_path)
        return {
            "total_rows": resumed_rows,
            "parts": len(manifest.parts),
            "manifest_path": str(parts_path / MANIFEST_NAME),
            "resumed_rows": resumed_rows,
            "file_size_bytes": manifest.total_bytes,
            "columns": [{"name": c} for c in manifest.columns()],
        }

    # ── Streaming loop with rotation ─────────────────────────────────
    col_defs: List[Dict[str, Any]] = []
    col_names: List[str] = []
    writer: Optional[ParquetStreamWriter] = None
    part_index = len(manifest.parts)
    part_rows = 0
    part_path: Optional[Path] = None
    total_new_rows = 0
    unified_schema = (manifest.arrow_schema()
                      if manifest.schema_b64 else None)

    def _unify(schema_a, schema_b):
        if schema_a is None:
            return schema_b
        if schema_a.equals(schema_b):
            return schema_a
        try:
            return pa.unify_schemas([schema_a, schema_b],
                                    promote_options="permissive")
        except TypeError:
            # older pyarrow spelling
            return pa.unify_schemas([schema_a, schema_b])

    def _open_part() -> None:
        nonlocal writer, part_rows, part_path
        part_path = parts_path / f"part-{part_index:05d}.parquet"
        writer = ParquetStreamWriter(
            output_path=str(part_path), columns=col_defs,
            queue_maxsize=queue_maxsize, compression=compression,
        )
        writer.start()
        part_rows = 0

    def _close_part() -> None:
        """Finalise the in-flight part, append it to the manifest, and
        re-write the PARTIAL manifest atomically — the durability point."""
        nonlocal writer, part_index, part_rows, part_path, unified_schema
        if writer is None:
            return
        writer.signal_end()
        written = writer.finalise(timeout=1800)
        writer.close()
        writer = None
        pf = pq.ParquetFile(str(part_path))
        try:
            footer_rows = pf.metadata.num_rows
            part_schema = pf.schema_arrow
        finally:
            pf.close()
        if footer_rows != written or written != part_rows:
            raise RuntimeError(
                f"part {part_path.name}: fed {part_rows} rows, writer "
                f"reports {written}, footer says {footer_rows} — refusing "
                f"to record a part whose numbers do not reconcile")
        unified_schema = _unify(unified_schema, part_schema)
        manifest.schema_b64 = _b64.b64encode(
            unified_schema.serialize().to_pybytes()).decode("ascii")
        info = PartInfo(
            index=part_index, name=part_path.name,
            rows=footer_rows, bytes=part_path.stat().st_size,
            location="local",
        )
        manifest.parts.append(info)
        manifest.total_rows += footer_rows
        manifest.total_bytes += info.bytes
        manifest.write(parts_path, partial=True)
        logger.info("[parts] part %s durable: %d rows, %d bytes "
                    "(total %d rows / %d parts)",
                    info.name, info.rows, info.bytes,
                    manifest.total_rows, len(manifest.parts))
        part_index += 1
        part_rows = 0
        part_path = None
        if on_part_complete is not None:
            try:
                on_part_complete(info)
            except Exception as _cb_exc:
                logger.warning("[parts] on_part_complete failed: %s", _cb_exc)

    try:
        for chunk_cols, chunk_rows in connector.execute_query_streaming(
            effective_sql, chunk_size=chunk_size,
            limit=(None if row_limit is None
                   else max(0, row_limit - resumed_rows)),
            cancel_event=cancel_event,
        ):
            if cancel_event is not None and cancel_event.is_set():
                if writer is not None:
                    writer.cancel()
                    try:
                        writer.finalise(timeout=60)
                    except InterruptedError:
                        pass
                    writer.close()
                    writer = None
                raise InterruptedError("Cancelled by user")
            if not chunk_cols:
                continue
            if not col_defs:
                col_defs = chunk_cols
                col_names = [c.get("name", "") for c in col_defs]
            if not chunk_rows:
                continue
            if chunk_rows and isinstance(chunk_rows[0], dict):
                chunk_rows = [tuple(r.get(n) for n in col_names)
                              for r in chunk_rows]
            # Truncate to the remaining budget BEFORE writing (same
            # contract as execute_sql_to_parquet — a cap may throttle
            # but may never hand back MORE rows than asked for).
            if row_limit is not None:
                remaining = row_limit - resumed_rows - total_new_rows
                if remaining <= 0:
                    break
                if len(chunk_rows) > remaining:
                    chunk_rows = chunk_rows[:remaining]
            # Feed the chunk, splitting across rotation boundaries.
            while chunk_rows:
                if writer is None:
                    _open_part()
                if rotate_every > 0:
                    room = rotate_every - part_rows
                    head, chunk_rows = chunk_rows[:room], chunk_rows[room:]
                else:
                    head, chunk_rows = chunk_rows, []
                writer.put_batch(head, timeout=300)
                part_rows += len(head)
                total_new_rows += len(head)
                if rotate_every > 0 and part_rows >= rotate_every:
                    _close_part()
            if (row_limit is not None
                    and resumed_rows + total_new_rows >= row_limit):
                break
        _close_part()

        if manifest.total_rows == 0 and not manifest.parts:
            # Typed-empty single part — downstream readers never 404,
            # exactly like the single-file sibling's empty fallback.
            # 2026-10-11: typed by the source's DECLARED types (the
            # single-file sibling has been since 2026-10-07, B6); every
            # column used to be a string here.
            from core.parquet_stream_writer import _arrow_type_for_declared
            empty_cols = col_names or []
            declared = {c.get("name", ""): c.get("type") for c in col_defs
                        if isinstance(c, dict)}
            empty_schema = pa.schema(
                [pa.field(n, _arrow_type_for_declared(declared.get(n), pa)
                          or pa.string()) for n in empty_cols])
            empty_path = parts_path / "part-00000.parquet"
            pq.write_table(empty_schema.empty_table(), str(empty_path),
                           compression=compression)
            manifest.schema_b64 = _b64.b64encode(
                empty_schema.serialize().to_pybytes()).decode("ascii")
            manifest.parts.append(PartInfo(
                index=0, name=empty_path.name, rows=0,
                bytes=empty_path.stat().st_size, location="local"))
            manifest.total_bytes = manifest.parts[0].bytes

        manifest_path = manifest.finalize(parts_path)
        return {
            "total_rows": manifest.total_rows,
            "parts": len(manifest.parts),
            "manifest_path": str(manifest_path),
            "resumed_rows": resumed_rows,
            "file_size_bytes": manifest.total_bytes,
            "columns": col_defs or [{"name": c} for c in manifest.columns()],
        }
    finally:
        if writer is not None:
            try:
                writer.close()
            except Exception as _be_exc:
                note_best_effort("writer.close()", _be_exc,
                                 logger=logger)


__all__ = [
    "execute_sql_to_parquet",
    "execute_sql_to_parts",
    "df_to_parquet_streaming",
    "execute_sql_to_dataframe",
]
