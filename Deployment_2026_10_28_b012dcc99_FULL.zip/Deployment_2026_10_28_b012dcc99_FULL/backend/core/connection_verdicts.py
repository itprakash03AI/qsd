"""One recent answer to "is this source reachable?" -- served, not re-probed
(2026-10-07).

THE STORM.  ``POST /auth/login`` fires ``api.auth_api._validate_user_
connections_at_login`` in the background: a ``test_connection`` against the
SOURCE of every connection the user can see (up to 20), for every login.  On
the Docker login rig the API log carried ``[conn-validate] ... name=
'snowflake-real' ... result='network_or_config_error'`` dozens of times in 40
minutes from two users' sign-ins (browser specs and harness logins sign in
over and over).  At 100 users signing in around 9 am that is 100 x N probes
against production sources -- a failing one included, re-probed by every
sign-in with no backoff -- for a health check nobody is waiting on.

THE RULE.  A verdict is kept per connection (and per user for a portal
connection, whose credentials are the user's) together with a fingerprint of
the configuration it was taken under:

* ``ok``      is served for ``connection_validation.ok_ttl_seconds`` (900);
* a failure   is served for a BACKOFF that doubles with each consecutive
              failed probe: ``fail_backoff_seconds`` (60) x 2^(n-1), capped
              at ``fail_backoff_max_seconds`` (1800) -- a source that is down
              is asked again at 1, 2, 4, 8 ... 30 minutes, not on every login;
* a CHANGED configuration (an admin fixed the host, rotated the password) is
  a different fingerprint: the old verdict does not apply and the next login
  probes;
* an explicit **Test** (``POST /api/connections/{id}/test``) always probes;
  its result, persisted on the connection row by that route
  (``last_tested_at`` / ``last_test_status``), is also a verdict the login
  sweep honours -- the freshest of the two wins.

Concurrent sweeps share ONE probe per key (single-flight): 25 users signing
in at once against a cold cache probe each source once, not 25 times.

Nothing here blocks a page: the sweep is a fire-and-forget background task
after the login response; this module only decides whether it touches the
source at all.  State is process-local (a pod that restarts probes once), the
same posture as every other connection cache; the persisted Test verdict is
the cross-pod part.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

RESULT_OK = "ok"


def _cfg() -> Tuple[float, float, float]:
    try:
        from core.config import connection_validation as _cv
        return (float(_cv.ok_ttl_seconds), float(_cv.fail_backoff_seconds),
                float(_cv.fail_backoff_max_seconds))
    except Exception:
        return 900.0, 60.0, 1800.0


def config_fingerprint(config: Any) -> str:
    """A digest of the connection's configuration -- never the configuration
    itself (it carries credentials)."""
    try:
        raw = json.dumps(config or {}, sort_keys=True, default=str)
    except Exception:
        raw = repr(config)
    return hashlib.sha256(raw.encode("utf-8", "replace")).hexdigest()[:24]


@dataclass
class Verdict:
    result: str            # "ok" or the failure class ("timeout", "s3_error", ...)
    reason: str
    at: float              # wall-clock epoch of the probe
    fingerprint: str
    failures: int          # consecutive failed probes (0 after an ok)

    @property
    def ok(self) -> bool:
        return self.result == RESULT_OK

    def fresh_until(self) -> float:
        ok_ttl, base, cap = _cfg()
        if self.ok:
            return self.at + ok_ttl
        return self.at + min(cap, base * (2 ** max(0, self.failures - 1)))


_lock = threading.Lock()
_verdicts: Dict[Any, Verdict] = {}
_inflight: Dict[Any, "asyncio.Future"] = {}


def _persisted(conn: Dict[str, Any], fingerprint: str) -> Optional[Verdict]:
    """The explicit Test's verdict on the connection row, as a Verdict."""
    status = str(conn.get("last_test_status") or "").lower()
    at_raw = conn.get("last_tested_at")
    if status not in ("success", "failed") or not at_raw:
        return None
    try:
        if isinstance(at_raw, datetime):
            at_dt = at_raw
        else:
            at_dt = datetime.fromisoformat(str(at_raw))
        if at_dt.tzinfo is None:
            at_dt = at_dt.replace(tzinfo=timezone.utc)   # the route stores naive UTC
        at = at_dt.timestamp()
    except Exception:
        return None
    return Verdict(result=RESULT_OK if status == "success" else "failed",
                   reason=str(conn.get("last_test_message") or "")[:200],
                   at=at, fingerprint=fingerprint, failures=0 if status == "success" else 1)


def cached_verdict(key: Any, conn: Dict[str, Any], *,
                   now: Optional[float] = None) -> Optional[Verdict]:
    """The verdict to SERVE for ``key`` instead of probing, or None (probe).

    ``conn`` is the connection row (decrypted config is fine: only its
    fingerprint is kept)."""
    now = time.time() if now is None else now
    fp = config_fingerprint(conn.get("config"))
    with _lock:
        mine = _verdicts.get(key)
    if mine is not None and mine.fingerprint != fp:
        mine = None                           # the configuration changed since
    candidates = [v for v in (mine, _persisted(conn, fp)) if v is not None]
    if not candidates:
        return None
    best = max(candidates, key=lambda v: v.at)
    if best is not mine and mine is not None and not best.ok and not mine.ok:
        best.failures = max(best.failures, mine.failures)
    return best if now < best.fresh_until() else None


def record(key: Any, conn: Dict[str, Any], result: str, reason: str = "",
           *, now: Optional[float] = None) -> Verdict:
    """Remember a probe's outcome for ``key``."""
    now = time.time() if now is None else now
    fp = config_fingerprint(conn.get("config"))
    with _lock:
        prev = _verdicts.get(key)
        failures = 0
        if result != RESULT_OK:
            failures = (prev.failures if prev is not None and prev.fingerprint == fp
                        and not prev.ok else 0) + 1
        v = Verdict(result=result, reason=str(reason or "")[:200], at=now,
                    fingerprint=fp, failures=failures)
        _verdicts[key] = v
    return v


async def probe_once(key: Any, probe: Callable[[], Awaitable[Tuple[str, str]]]
                     ) -> Tuple[str, str, bool]:
    """Run ``probe`` (-> ``(result, reason)``) unless one for ``key`` is
    already running, in which case await THAT one.  Returns
    ``(result, reason, shared)`` -- ``shared`` True when this caller did not
    probe itself."""
    loop = asyncio.get_running_loop()
    with _lock:
        fut = _inflight.get(key)
        mine = fut is None or fut.done() or fut.get_loop() is not loop
        if mine:
            fut = loop.create_future()
            _inflight[key] = fut
    if not mine:
        result, reason = await asyncio.shield(fut)
        return result, reason, True
    try:
        result, reason = await probe()
        fut.set_result((result, reason))
        return result, reason, False
    except BaseException as exc:
        if not fut.done():
            fut.set_result(("internal_error", str(exc)[:200]))
            # nobody may be awaiting it -- never leave "exception never retrieved"
        raise
    finally:
        with _lock:
            if _inflight.get(key) is fut:
                _inflight.pop(key, None)


def key_for(conn: Dict[str, Any], username: str = "") -> Tuple[Any, ...]:
    """A portal-authenticated S3 connection probes with the USER's password,
    so its verdict is the user's; every other connection's is the source's."""
    cfg = conn.get("config") or {}
    if (str(conn.get("connection_type") or "").lower() == "s3"
            and str(cfg.get("auth_mode") or "").lower() == "portal"):
        return ("conn", conn.get("id"), "user", str(username or ""))
    return ("conn", conn.get("id"))


def reset() -> None:
    """Forget every verdict (tests; an operator hook)."""
    with _lock:
        _verdicts.clear()
        _inflight.clear()
