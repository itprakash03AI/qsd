"""BrainRouter -- the planner chokepoint that CLOSES the sense->act loop.

Phase 155 (2026-06-25) -- operator directive:
  "iceberg watcher and blooming scan ... 4000 files in VPC ... no pre-
  download ... writer team frozen ... spark connect we will do".

Strategic context
-----------------
The brain ALREADY has 12 sensor modules (brain_pruning_iq, brain_trace,
brain_cost_model, brain_forecaster, brain_coordinator,
iceberg_co_access, iceberg_bloom_sidecar, iceberg_column_stats,
iceberg_manifest_watcher, agg_cache, ...).  Each measures something
useful about the query / table / fleet.

But the EXECUTION decider (``core.engine_router``) reads NONE of them.
It runs static operator-written rules: ``if file_count > 50 -> multi_
worker``.  The brain looks smart in ``brain_trace`` and ``pruning_iq``
verdicts but is COSMETIC -- it diagnoses, never decides.

This module fixes that.  ``BrainRouter.recommend_route(features)``
reads every relevant sensor + produces a ``RouteRecommendation``.
``engine_router.decide_engine`` consults the brain BEFORE evaluating
its config rules; operator-explicit overrides still win, but absent
overrides the brain drives.

Strategic shape (single-chokepoint pattern, per the memory rule
"feedback_single_chokepoint_pattern"):
  * ONE class with ONE method (recommend_route) at the call site.
  * Every brain consultation happens here -- callers don't reach
    into brain_pruning_iq / agg_cache / cost_model individually.
  * Future sensors plug in via private ``_consult_X`` methods; the
    decision tree is the only thing that changes.

Constraints honoured
--------------------
  * No data file reads on the API pod (writer-frozen + no pre-download).
  * Reuses every existing sensor module; no duplication.
  * Fail-OPEN: any sensor error -> brain returns ``None`` -> caller
    falls back to existing operator config rules.  The brain CANNOT
    break query execution.
"""
from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ── Decision dataclass ────────────────────────────────────────────────


@dataclass
class RouteRecommendation:
    """One brain recommendation.  Consumed by engine_router.decide_engine.

    Fields:
      engine:        One of ENGINE_SINGLE / ENGINE_MULTI_WORKER /
                     ENGINE_MULTI_POD / ENGINE_SPARK_CONNECT / "cache" /
                     "empty".  "cache" + "empty" are brain-only verdicts
                     the wire-in maps to the existing engines as
                     appropriate (cache -> single with a cached-result
                     path; empty -> single with a 0-row short-circuit).
      reason:        Operator-readable explanation.  Stamped into
                     brain_trace + the EngineDecision.reason field so
                     the admin UI can render it without translation.
      confidence:    0.0..1.0 -- low confidence means engine_router
                     may override with its config rules.
      surviving_files:  Output of manifest deep-prune, if it ran.
                     -1 = not evaluated.
      est_local_seconds:  Cost model's prediction for the SINGLE path.
                     -1.0 = unknown.
      est_spark_seconds:  Cost model's prediction for SPARK_CONNECT.
                     -1.0 = unknown.
      sensors_consulted:  Debug list of which sensors actually fired
                     for this recommendation.  Useful when the verdict
                     surprises an operator.
    """
    engine:          str
    reason:          str
    confidence:      float = 1.0
    surviving_files: int = -1
    est_local_seconds:  float = -1.0
    est_spark_seconds:  float = -1.0
    sensors_consulted:  List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "engine":             self.engine,
            "reason":             self.reason,
            "confidence":         round(self.confidence, 3),
            "surviving_files":    self.surviving_files,
            "est_local_seconds":  round(self.est_local_seconds, 2)
                                  if self.est_local_seconds >= 0 else None,
            "est_spark_seconds":  round(self.est_spark_seconds, 2)
                                  if self.est_spark_seconds >= 0 else None,
            "sensors_consulted":  list(self.sensors_consulted),
        }


# Verdict labels exposed for callers.  Match ENGINE_* in engine_router
# where they overlap; "cache" + "empty" are brain-only signals.
ROUTE_SINGLE        = "single"
ROUTE_MULTI_WORKER  = "multi_worker"
ROUTE_MULTI_POD     = "multi_pod"
ROUTE_SPARK_CONNECT = "spark_connect"
ROUTE_CACHE         = "cache"     # serve from agg_cache
ROUTE_EMPTY         = "empty"     # manifest-pruned to zero -- short circuit


# ── Config knobs (lazy reads so runtime tuning works) ─────────────────


def _cfg(key: str, fallback: Any) -> Any:
    try:
        from core.config import get as _g
        return _g("brain_router", key, fallback)
    except Exception:
        return fallback


def enabled() -> bool:
    """Master switch.  Default True -- brain consultation is fail-OPEN
    so flipping it off should be unnecessary in normal operation."""
    return bool(_cfg("enabled", True))


def small_file_threshold() -> int:
    """surviving_files <= this -> route to SINGLE regardless of cost.

    2026-06-28 BUG-FIX: previously ``int(_cfg(...) or 50)`` silently
    coerced an operator-set ``0`` back to the default ``50`` because
    Python treats ``0`` as falsy.  That contradicted the documented
    intent of "set to 0 to disable the file-count short-circuit"
    (used both by tests + operators forcing multi-worker on small
    file sets).  Use ``is None`` discriminator so explicit 0 wins.
    """
    raw = _cfg("small_file_threshold", None)
    if raw is None:
        return 50
    try:
        return int(raw)
    except (TypeError, ValueError):
        return 50


def spark_route_threshold_seconds() -> float:
    """If the local cost prediction is below this, prefer SINGLE/MULTI
    even when SPARK looks faster -- the routing overhead isn't worth
    it for sub-N-second queries."""
    return float(_cfg("spark_route_threshold_seconds", 5.0) or 5.0)


def spark_cost_model_enabled() -> bool:
    """Phase 169 — master gate for observed-cost Spark routing.  DEFAULT
    OFF.  When ON, _consult_cost_model derives ``cost_spark`` from the
    per-engine EMA that brain_route_history already records, which WAKES
    the three Spark branches in _decide (they gate on ``cost_spark > 0``).
    Off by default because it changes engine-routing behaviour across all
    surfaces -- soak it (watch route_history + brain_decision_log) before
    flipping on.  See PHASE_169_SPARK_COST_MODEL_DESIGN.md."""
    return bool(_cfg("spark_cost_model_enabled", False))


def spark_cost_model_min_samples() -> int:
    """Minimum observed Spark runs for a SQL shape before we trust its
    EMA as ``cost_spark`` (avoids routing off a single noisy sample)."""
    raw = _cfg("spark_cost_model_min_samples", None)
    if raw is None:
        return 5
    try:
        return max(1, int(raw))
    except (TypeError, ValueError):
        return 5


def spark_route_savings_factor() -> float:
    """Require Spark prediction to be at least N* faster than local
    before routing -- guards against noisy cost-model predictions."""
    return float(_cfg("spark_route_savings_factor", 1.5) or 1.5)


# ── Query context dataclass ────────────────────────────────────────────


@dataclass
class QueryContext:
    """Inputs the brain needs to make a routing decision.

    Constructed by the caller (typically execute_api) from what it
    already knows about the query.  No fetches here -- brain stays
    light.
    """
    sql:                 str = ""
    sql_hash:            str = ""        # For agg_cache lookup; "" disables
    snapshot_id:         Optional[str] = None
    bucket:              str = ""
    table_prefix:        str = ""
    file_count_unpruned: int = 0         # From manifest list (free)
    median_file_size:    int = 0         # Bytes; 0 = unknown
    is_cross_source:     bool = False
    has_join:            bool = False
    filter_columns:      List[str] = field(default_factory=list)
    partition_columns:   List[str] = field(default_factory=list)
    # Optional: caller can supply manifest stats directly so the brain
    # doesn't have to re-fetch.  ``None`` means brain skips manifest
    # deep-prune (falls through to cost-model only).
    manifest_stats:      Optional[Any] = None
    # 2026-06-30 deep-dive fix: ``where_predicates`` is the THE
    # missing input that broke pruning.  When non-empty AND
    # ``has_prunable_predicates`` is True, the brain runs the full
    # 3-layer prune (manifest stats + supplement bounds + bloom).
    # Each predicate shape: ``{col: str, op: str, value: Any}`` --
    # populated by ``core.query_feature_builder.QueryFeatureBuilder``.
    where_predicates:    List[Dict[str, Any]] = field(default_factory=list)
    # ``True`` iff at least one predicate references a partition column.
    # Drives the brain's fast path: when False the brain skips the
    # supplement + bloom DB lookups (saves 2 Postgres roundtrips per
    # query, relevant when Postgres is slow).
    has_prunable_predicates: bool = False
    # Deep-dive #3 (2026-06-30): signal that ``manifest_stats`` already
    # carries supplement bounds in each entry's ``stats`` dict.  When
    # True, ``_consult_manifest_prune`` does NOT pass ``db_manager`` to
    # ``evaluate_where`` for the supplement layer -- the data is already
    # in Layer 1 of stats so the supplement DB call would be redundant.
    manifest_stats_includes_supplement: bool = False
    # Deep-dive #7 (2026-06-30): iceberg vs parquet discriminator for
    # the supplement / bloom DB lookups.  Defaults to 'iceberg' to
    # match the pre-fix behaviour; parquet callers must pass 'parquet'
    # so bloom + supplement DB queries match the right format rows.
    format: str = "iceberg"
    # 2026-07-15 DATA-LOSS FIX -- ``{lower_col: iceberg_type_str}`` from
    # the table's current schema.  Threaded into evaluate_where so the
    # Layer-3 bloom verdict is gated on probe-encoding parity (a string
    # SQL literal probed against a DATE/INT-built bloom hashes different
    # bytes -> false "absent" -> file wrongly pruned).  Empty map ->
    # bloom prune is skipped entirely (fail-open over-scan; estimates
    # over-count, never under-count).
    iceberg_col_types: Dict[str, str] = field(default_factory=dict)
    # 2026-10-08 -- the brain-cache hit the CALLER resolved and is
    # prepared to SERVE (``core.agg_cache.BrainCacheHit`` from
    # ``lookup_brain_cache``).  The router never looks the cache up by
    # itself any more: it used to assert "agg_cache hit" for a snapshot it
    # did not know and route to SINGLE, where nothing served it and every
    # file was read (live: 42 s cold -> 245 s "warm").  ``None`` = no
    # ROUTE_CACHE verdict, whatever the cache holds.
    cached_result: Optional[Any] = None


# ── Sensor wrappers (one method per existing brain module) ────────────


class _SensorOutputs:
    """Aggregated outputs from every sensor consulted for this query.
    Used internally so the recommend_route decision tree reads
    everything from one struct instead of calling 8 functions."""

    def __init__(self) -> None:
        self.manifest_surviving: int = -1
        self.cache_hit: bool = False
        self.cost_local: float = -1.0
        self.cost_spark: float = -1.0
        self.spark_saturated: bool = False
        self.hostile_pattern: bool = False
        self.coordinator_pressure: str = "low"
        self.consulted: List[str] = []
        # Phase 156 -- new sensors.
        self.memo_hit: bool = False
        self.memo_surviving: int = -1
        self.outcome_prefer_local: bool = False
        # Per-layer pruning breakdown from iceberg_manifest_prune so
        # operators can see which layer did the work.
        self.prune_breakdown: Dict[str, int] = {}


# ── The chokepoint class ─────────────────────────────────────────────


class BrainRouter:
    """Singleton planner.  Reads every brain sensor; returns a
    RouteRecommendation or None.

    Used by:
      * core.engine_router.decide_engine -- consults BEFORE the
        operator-config rule evaluation.

    Not used by anything else.  Adding callers without going through
    engine_router is FORBIDDEN (single chokepoint).
    """

    _instance: Optional["BrainRouter"] = None
    _instance_lock = threading.Lock()

    @classmethod
    def get_default(cls) -> "BrainRouter":
        # Phase 156 deep-dive R11 -- double-checked lock so concurrent
        # callers under cold-start (multi-worker boot, parallel admin
        # probes) don't both construct an instance.  Replacing the
        # second one is harmless today (instances are stateless), but
        # would silently break if BrainRouter ever holds per-instance
        # state (e.g. a per-pod warm cache).
        if cls._instance is None:
            with cls._instance_lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    def recommend_route(
        self, ctx: QueryContext,
    ) -> Optional[RouteRecommendation]:
        """Return the brain's route recommendation, or None to defer
        to the operator config rules.

        Fail-OPEN: any sensor exception -> None.  Brain never blocks
        execution.

        2026-06-30 deep-dive #2: every decision (and every "no opinion"
        outcome) is recorded into the BrainDecisionLog with full sensor
        outputs + pruning breakdown.  Operators can:
          * grep [brain-trace] log lines for "manifest_pruned=N
            supplement_pruned=M bloom_pruned=K" to see per-layer activity
          * curl /api/admin/brain/last-decisions to see the last 50
            decisions + cumulative counters
          * scrape qs_brain_files_pruned_total{layer=...} for alerting
        """
        # Deep-dive #3 (2026-06-30): even the fast-path bail-outs must
        # leave a trace -- otherwise operators see "brain consulted 0
        # times" in /admin/brain/last-decisions when the brain is
        # actually disabled / called with empty SQL, and can't tell which.
        if not enabled():
            self._log_early_return(ctx, "skipped(brain_disabled)")
            return None
        if not ctx.sql:
            self._log_early_return(ctx, "skipped(empty_sql)")
            return None
        sensors: Optional[_SensorOutputs] = None
        try:
            sensors = self._consult_all_sensors(ctx)
            rec = self._decide(ctx, sensors)
            self._log_decision(ctx, sensors, rec)
            return rec
        except Exception as exc:
            logger.debug(
                "[brain-router] sensor consult failed for %s/%s: %s "
                "-- deferring to config rules", ctx.bucket,
                ctx.table_prefix, exc,
            )
            # Record the failure so ops see the brain attempted +
            # bailed (vs silent skip).
            if sensors is not None:
                try:
                    self._log_decision(ctx, sensors, None,
                                        bail_reason=f"{type(exc).__name__}: {exc}")
                except Exception:
                    pass
            return None

    def _log_early_return(self, ctx: "QueryContext", reason: str) -> None:
        """Decision log entry for the fast-path early returns (brain
        disabled / empty sql).  No sensors ran -- prune_breakdown empty
        but the entry still bumps decisions_total + leaves a row in
        /admin/brain/last-decisions so operators can see brain attempted.
        """
        try:
            from core.brain_decision_log import get_log
            get_log().record(
                sql_hash=ctx.sql_hash,
                bucket=ctx.bucket,
                table_prefix=ctx.table_prefix,
                snapshot_id=str(ctx.snapshot_id or ""),
                file_count=ctx.file_count_unpruned,
                decision_engine="none",
                decision_reason=reason,
                manifest_surviving=-1,
                prune_breakdown=None,
                sensors_consulted=[],
                has_prunable_preds=ctx.has_prunable_predicates,
            )
        except Exception as exc:
            logger.debug("[brain-router] _log_early_return failed: %s", exc)

    def _log_decision(
        self,
        ctx: "QueryContext",
        sensors: "_SensorOutputs",
        rec: Optional["RouteRecommendation"],
        bail_reason: str = "",
    ) -> None:
        """Single chokepoint for brain decision telemetry.  Writes one
        ``[brain-trace]`` log line AND records into the decision log so
        the admin endpoint + Prometheus counters can surface it.

        Failures here are non-fatal -- telemetry must never break the
        query path."""
        try:
            from core.brain_decision_log import get_log
            decision_engine = rec.engine if rec is not None else (
                f"none({bail_reason[:60]})" if bail_reason else "none(no_strong_signal)"
            )
            decision_reason = rec.reason if rec is not None else bail_reason
            cost_local = (rec.est_local_seconds if rec is not None
                          else sensors.cost_local)
            cost_spark = (rec.est_spark_seconds if rec is not None
                          else sensors.cost_spark)
            get_log().record(
                sql_hash=ctx.sql_hash,
                bucket=ctx.bucket,
                table_prefix=ctx.table_prefix,
                snapshot_id=str(ctx.snapshot_id or ""),
                file_count=ctx.file_count_unpruned,
                decision_engine=decision_engine,
                decision_reason=decision_reason,
                manifest_surviving=sensors.manifest_surviving,
                prune_breakdown=sensors.prune_breakdown,
                sensors_consulted=sensors.consulted,
                cost_local_s=cost_local,
                cost_spark_s=cost_spark,
                has_prunable_preds=ctx.has_prunable_predicates,
            )
            # Single-line trace -- grep-friendly.
            breakdown = sensors.prune_breakdown or {}
            logger.info(
                "[brain-trace] sql_hash=%s engine=%s files=%d "
                "surviving=%d manifest_pruned=%d supplement_pruned=%d "
                "bloom_pruned=%d sensors=%s prunable=%s",
                (ctx.sql_hash or "")[:12],
                decision_engine,
                ctx.file_count_unpruned,
                sensors.manifest_surviving,
                breakdown.get("manifest_pruned", 0),
                breakdown.get("supplement_pruned", 0),
                breakdown.get("bloom_pruned", 0),
                ",".join(sensors.consulted),
                ctx.has_prunable_predicates,
            )
        except Exception as exc:
            logger.debug("[brain-router] _log_decision failed: %s", exc)

    # ── Sensor consultation ───────────────────────────────────────

    def _consult_all_sensors(self, ctx: QueryContext) -> _SensorOutputs:
        out = _SensorOutputs()
        # 2026-06-30 PER-SENSOR fast-path -- each sensor runs ONLY when
        # its inputs are present.  Saves Postgres roundtrips when the
        # query simply can't benefit (no partition col in WHERE = no
        # pruning possible = no point hitting supplement / bloom).
        # Pre-fix every sensor ran on every query.

        # Memo: needs sql_hash AND snapshot_id (memoised pruned-file list).
        if ctx.sql_hash and ctx.snapshot_id:
            self._consult_memo(ctx, out)

        # Manifest prune: needs prunable predicates + manifest_stats.
        # Hosts the supplement + bloom DB lookups inside evaluate_where;
        # consulting it without prunable predicates means N DB roundtrips
        # that mathematically cannot prune any file.
        if not out.memo_hit and ctx.has_prunable_predicates \
                and ctx.manifest_stats is not None:
            self._consult_manifest_prune(ctx, out)

        # Agg cache: ONLY the hit the caller resolved and will serve
        # (2026-10-08).  No lookup here -- see QueryContext.cached_result.
        if ctx.cached_result is not None:
            self._consult_agg_cache(ctx, out)

        # Always-cheap heuristics (microseconds; no DB).
        self._consult_cost_model(ctx, out)
        self._consult_coordinator(ctx, out)
        self._consult_hostile_pattern(ctx, out)

        # Route history: needs sql_hash + table identifiers.
        if ctx.sql_hash and ctx.bucket and ctx.table_prefix:
            self._consult_route_history(ctx, out)
        return out

    def _consult_memo(
        self, ctx: QueryContext, out: _SensorOutputs,
    ) -> None:
        """Phase 156.2 -- memoised pruned-file list.  Returns the
        cached surviving count without re-running 3 pruning layers."""
        if not ctx.sql_hash or not ctx.snapshot_id:
            return
        try:
            from core.brain_pruning_memo import get_memo
            # R6 (2026-07-22): get_memo folds the pruning-config fingerprint into
            # the key internally (single chokepoint), so passing the RAW
            # ctx.sql_hash here keys identically to the reader's put — this
            # routing-hint sensor hits the reader's entries again.
            row = get_memo(
                ctx.sql_hash, ctx.snapshot_id,
                bucket=ctx.bucket or None,
                table_prefix=ctx.table_prefix or None,
            )
            # Phase 156 deep-dive R19b -- only treat as a HIT when the
            # entry is structurally valid: dict with a list-typed
            # ``surviving_files`` key.  A corrupt entry (None /
            # bad-typed surviving_files) used to set memo_hit=True
            # with surviving_count=0 -- causing brain to short-circuit
            # to ROUTE_EMPTY instead of falling through.  Result:
            # ghost-empty results from cache corruption.
            if not isinstance(row, dict):
                return
            sf = row.get("surviving_files")
            if not isinstance(sf, list):
                logger.debug(
                    "[brain-router] memo entry has bad surviving_files "
                    "type (%s) -- treating as miss",
                    type(sf).__name__,
                )
                return
            try:
                survivors = int(row.get("surviving_count") or len(sf))
            except (TypeError, ValueError):
                return
            out.memo_hit = True
            out.memo_surviving = max(0, survivors)
            # Reuse the same field downstream so step 2/3 of the
            # decision tree sees it.
            if out.manifest_surviving < 0:
                out.manifest_surviving = out.memo_surviving
            out.consulted.append("memo")
        except Exception as exc:
            logger.debug("[brain-router] memo skipped: %s", exc)

    def _consult_route_history(
        self, ctx: QueryContext, out: _SensorOutputs,
    ) -> None:
        """Phase 156.3 -- outcome-based feedback.  Asks: for this SQL
        shape, did local actually beat Spark in recent runs?"""
        if not ctx.sql_hash or not ctx.bucket or not ctx.table_prefix:
            return
        try:
            from core.brain_route_history import prefer_local_over_spark
            out.outcome_prefer_local = bool(prefer_local_over_spark(
                sql_hash=ctx.sql_hash, bucket=ctx.bucket,
                table_prefix=ctx.table_prefix,
            ))
            out.consulted.append("route_history")
        except Exception as exc:
            logger.debug("[brain-router] route_history skipped: %s", exc)

    def _consult_manifest_prune(
        self, ctx: QueryContext, out: _SensorOutputs,
    ) -> None:
        """Run the WHERE clause against manifest stats; return the
        surviving file count.  ZERO data-file reads -- manifests +
        supplement + bloom are all metadata-only.

        Phase 156.1 -- now passes db_manager + identifiers so
        evaluate_where also consults supplement bounds + bloom
        sidecar.  When caller doesn't provide them, falls back to
        manifest-only Phase 155 behaviour.

        2026-06-30 deep-dive fix: ``where_predicates`` is NOW threaded
        from ctx (was hardcoded to None which made every pruning layer
        a no-op).  Combined with QueryFeatureBuilder populating
        manifest_stats + predicates upstream, the 3-layer prune
        finally produces non-zero pruning counts on partition-column
        queries.

        Skips when caller didn't provide manifest_stats (avoids a
        re-fetch on the brain path; ctx caller is the right one to
        decide if it's worth a manifest list read).
        """
        # Deep-dive #5 (2026-06-30): treat empty list the same as None
        # -- evaluate_where would return 0 surviving for an empty list
        # which the brain interprets as ROUTE_EMPTY, a correctness bug
        # when the empty list represents "no data" (caller hadn't loaded
        # bounds), not "0 files survive the WHERE".
        if not ctx.manifest_stats:
            return
        # 2026-06-30: skip the DB layers entirely when predicates can't
        # benefit from them.  evaluate_where would happily run
        # supplement + bloom lookups with bloom_cols=[] -> empty result
        # set -> nothing pruned -- wasted Postgres roundtrip.
        _use_db_layers = bool(ctx.has_prunable_predicates)
        try:
            from core.iceberg_manifest_prune import evaluate_where
            _dbm = None
            if _use_db_layers:
                try:
                    from core.database import get_db_manager
                    _dbm = get_db_manager()
                except Exception:
                    _dbm = None
            # Deep-dive #3 (2026-06-30): when the builder already baked
            # supplement bounds into manifest_stats Layer 1, signal
            # evaluate_where to skip the supplement DB load (would be a
            # second redundant Postgres roundtrip on the same data).
            _preloaded_supp: Optional[Dict[str, Dict[str, Any]]] = None
            if ctx.manifest_stats_includes_supplement:
                _preloaded_supp = {}
            prune_stats: Dict[str, int] = {}
            _raw_surviving = evaluate_where(
                manifest_stats=ctx.manifest_stats,
                filter_columns=ctx.filter_columns,
                where_clause=None,
                where_predicates=list(ctx.where_predicates) if ctx.where_predicates else None,
                db_manager=_dbm,
                bucket=ctx.bucket or None,
                table_prefix=ctx.table_prefix or None,
                snapshot_id=str(ctx.snapshot_id or "") or None,
                stats_out=prune_stats,
                supplement_bounds=_preloaded_supp,
                format=ctx.format,    # deep-dive #7
                # 2026-07-15 -- bloom probe-encoding parity gate input.
                # Empty/missing map means Layer-3 bloom is skipped
                # (fail-open) instead of running the type-blind probe.
                col_types=dict(getattr(ctx, "iceberg_col_types", None) or {}),
            )
            # Deep-dive #4 (2026-06-30): evaluate_where returns -1 when
            # inputs are malformed.  -1 leaks into decision-log
            # ("manifest_surviving=-1" looks like "1 survives") and into
            # Prometheus counters.  Map back to the unpruned count so
            # downstream consumers see a real "no opinion" signal.
            if _raw_surviving is None or _raw_surviving < 0:
                out.manifest_surviving = ctx.file_count_unpruned
                logger.debug(
                    "[brain-router] evaluate_where returned %s -- "
                    "falling back to file_count_unpruned=%d",
                    _raw_surviving, ctx.file_count_unpruned,
                )
            else:
                out.manifest_surviving = _raw_surviving
            out.prune_breakdown = dict(prune_stats)
            out.consulted.append("manifest_prune")
        except Exception as exc:
            logger.debug("[brain-router] manifest_prune skipped: %s", exc)

    def _consult_agg_cache(
        self, ctx: QueryContext, out: _SensorOutputs,
    ) -> None:
        """Hash-based result memoisation.  The caller resolved a
        ``BrainCacheHit`` for this (sql, snapshot) and will SERVE it; the
        brain only reads it (2026-10-08: it used to look the cache up on
        its own, with the snapshot it did not know, and route to SINGLE
        where the executor read every file).  A hit for an unknown
        snapshot cannot exist: ``lookup_brain_cache`` refuses it."""
        hit = ctx.cached_result
        if hit is None:
            return
        try:
            _snap = str(getattr(hit, "snapshot_id", "") or "")
            _path = str(getattr(hit, "file_path", "") or "")
            out.cache_hit = bool(_snap and _path)
            out.consulted.append("agg_cache")
        except Exception as exc:
            logger.debug("[brain-router] agg_cache skipped: %s", exc)

    def _consult_cost_model(
        self, ctx: QueryContext, out: _SensorOutputs,
    ) -> None:
        """Predict LOCAL execution time from the observed-cost model.

        ``cost_spark`` is intentionally left dormant (-1.0).  ``CostModel``
        learns source/mirror/gateway seconds from ``query_pruning_history``
        and has NO Spark-execution timing model, so a truthful
        local-vs-Spark comparison is not yet possible.  Populating
        ``cost_spark`` would mean fabricating a number that flips real
        routing -- the three Spark branches in ``_decide`` (Steps 4/5/6)
        gate on ``cost_spark > 0`` -- so that is deferred to a future,
        data-backed Spark cost model.  Populating ``cost_local`` alone is
        DECISION-NEUTRAL today (Step 5 also requires ``cost_spark > 0``),
        so this only makes the ``est_local_seconds`` telemetry + the
        /admin/brain diagnostics honest.

        2026-07-04: replaces a dead ``predict_query_cost`` import (the
        symbol never existed; every call raised ImportError and was
        swallowed, leaving the sensor a silent no-op).  Now wired to the
        real ``CostModel`` public API.
        """
        try:
            from core.brain_cost_model import (
                CostModel, enabled as _cost_model_enabled,
            )
            if not _cost_model_enabled():
                return
            from core.database import get_db_manager
            _dbm = get_db_manager()
            if _dbm is None:
                return
            files = max(out.manifest_surviving, ctx.file_count_unpruned, 1)
            decision = CostModel.get_default(_dbm).route_decision(
                ctx.bucket, ctx.table_prefix, files,
            )
            # CostModel source estimate feeds cost_local when available.
            # (Its absence must NOT skip the independent Phase 169 spark
            # path below -- route_history can have Spark data even when
            # CostModel has no source-estimate observations.)
            if decision is not None:
                source_est = next(
                    (e for e in decision.estimates if e.path == "source"),
                    None,
                )
                if source_est is not None:
                    out.cost_local = float(source_est.predicted_seconds)
                    out.consulted.append("cost_model")

            # Phase 169 (DEFAULT OFF) -- observed-cost Spark routing.
            # Derive cost_spark (and an apples-to-apples cost_local) from
            # the per-engine EMA that brain_route_history already records,
            # so the three Spark branches in _decide fire ONLY on real
            # evidence Spark was faster for this SQL shape.  Requires BOTH
            # engines to have >= min_samples so we never route off a single
            # noisy run.  Dormant (cost_spark stays -1.0 -> Spark branches
            # unreachable) until the gate is flipped + soaked -- no routing
            # change by default.  The existing outcome_prefer_local guard
            # in Steps 4/5/6 is an additional brake (route_history proving
            # local faster suppresses Spark regardless).
            if spark_cost_model_enabled() and ctx.sql_hash:
                try:
                    from core.brain_route_history import lookup as _rh_lookup
                    _stats = _rh_lookup(
                        ctx.sql_hash, ctx.bucket, ctx.table_prefix, _dbm,
                    ) or {}
                    _min = spark_cost_model_min_samples()
                    _spark = _stats.get("spark_connect") or {}
                    _spark_n = int(_spark.get("sample_count", 0) or 0)
                    _spark_s = float(_spark.get("ema_seconds", 0) or 0)
                    _local = (_stats.get("single")
                              or _stats.get("multi_worker") or {})
                    _local_n = int(_local.get("sample_count", 0) or 0)
                    _local_s = float(_local.get("ema_seconds", 0) or 0)
                    if (_spark_n >= _min and _spark_s > 0
                            and _local_n >= _min and _local_s > 0):
                        out.cost_spark = _spark_s
                        out.cost_local = _local_s
                        if "route_history_cost" not in out.consulted:
                            out.consulted.append("route_history_cost")
                except Exception as _rh_exc:
                    logger.debug(
                        "[brain-router] spark cost model skipped: %s", _rh_exc,
                    )
        except Exception as exc:
            logger.debug("[brain-router] cost_model skipped: %s", exc)

    def _consult_coordinator(
        self, ctx: QueryContext, out: _SensorOutputs,
    ) -> None:
        """Brain coordinator publishes a process-wide pressure flag
        based on S3 bandwidth.  When high, prefer Spark (compute in
        the data plane) over local."""
        try:
            from core.brain_coordinator import get_current_pressure
            out.coordinator_pressure = str(get_current_pressure() or "low")
            out.consulted.append("coordinator")
        except Exception as exc:
            logger.debug("[brain-router] coordinator skipped: %s", exc)

    def _consult_hostile_pattern(
        self, ctx: QueryContext, out: _SensorOutputs,
    ) -> None:
        """Pruning-hostile filter patterns (CAST on partition column,
        regex, function-on-bound-col) make local execution waste
        cycles -- Spark handles these better."""
        try:
            from core.duckdb_format_normaliser import normalise_strftime_formats  # noqa: F401  -- just probe importability
        except Exception:
            pass
        # The SQL classifier that detects hostile patterns lives in the
        # query rewriter; integration is a TODO.  For now, a cheap
        # heuristic: presence of CAST( or REGEXP( in the WHERE.
        try:
            import re
            sql_upper = ctx.sql.upper()
            if re.search(r"\bCAST\s*\(", sql_upper) or \
                    re.search(r"\bREGEXP", sql_upper) or \
                    re.search(r"\bSUBSTRING\s*\(", sql_upper) or \
                    re.search(r"\bLOWER\s*\(", sql_upper):
                out.hostile_pattern = True
            out.consulted.append("hostile_pattern_heuristic")
        except Exception:
            pass

    # ── Decision tree ─────────────────────────────────────────────

    def _decide(
        self, ctx: QueryContext, s: _SensorOutputs,
    ) -> Optional[RouteRecommendation]:
        """The 5-step ladder from the Phase 155 plan."""
        files = (s.manifest_surviving if s.manifest_surviving >= 0
                 else ctx.file_count_unpruned)

        # Step 1: cache hit -- the caller serves the hit it handed us.
        # ``cache_hit`` is set ONLY from ``ctx.cached_result`` (the one
        # gate, in _consult_all_sensors); no second check here.
        if s.cache_hit:
            _hit_snap = str(getattr(ctx.cached_result, "snapshot_id", "")
                            or ctx.snapshot_id or "")
            return RouteRecommendation(
                engine=ROUTE_CACHE,
                reason=(f"agg_cache hit for sql_hash={ctx.sql_hash} "
                        f"+ snapshot={_hit_snap} (served by the caller)"),
                confidence=1.0,
                surviving_files=files,
                sensors_consulted=s.consulted,
            )

        # Step 2: manifest pruned to zero -- short-circuit.
        if s.manifest_surviving == 0:
            return RouteRecommendation(
                engine=ROUTE_EMPTY,
                reason=("manifest min/max bounds prove no file can "
                        "match the WHERE clause"),
                confidence=1.0,
                surviving_files=0,
                sensors_consulted=s.consulted,
            )

        # Step 3: small enough -> local single-worker.
        if 0 < files <= small_file_threshold():
            return RouteRecommendation(
                engine=ROUTE_SINGLE,
                reason=(f"surviving files {files} <= threshold "
                        f"{small_file_threshold()} -- local is fastest"),
                confidence=0.9,
                surviving_files=files,
                est_local_seconds=s.cost_local,
                est_spark_seconds=s.cost_spark,
                sensors_consulted=s.consulted,
            )

        # Step 4: hostile pattern + Spark available -> Spark.
        # Phase 156.3 override: if route_history proved local was
        # actually faster for this SQL shape last time, ignore the
        # hostile-pattern heuristic.  Evidence beats heuristics.
        if s.hostile_pattern and s.cost_spark > 0 and not s.outcome_prefer_local:
            return RouteRecommendation(
                engine=ROUTE_SPARK_CONNECT,
                reason=("hostile filter pattern (CAST / REGEXP / "
                        "function on bound column) -- DuckDB-on-S3 "
                        "can't prune; Spark handles it natively"),
                confidence=0.85,
                surviving_files=files,
                est_local_seconds=s.cost_local,
                est_spark_seconds=s.cost_spark,
                sensors_consulted=s.consulted,
            )

        # Step 5: cost-driven routing -- Spark wins when significantly
        # faster AND the local cost is non-trivial.
        # Phase 156.3 override: route_history evidence wins over
        # cost-model prediction.
        if (s.cost_local > spark_route_threshold_seconds() and
                s.cost_spark > 0 and
                s.cost_local > s.cost_spark * spark_route_savings_factor() and
                not s.outcome_prefer_local):
            return RouteRecommendation(
                engine=ROUTE_SPARK_CONNECT,
                reason=(f"cost model: local p50 {s.cost_local:.1f}s vs "
                        f"spark p50 {s.cost_spark:.1f}s -- spark route "
                        f"saves {s.cost_local - s.cost_spark:.1f}s"),
                confidence=0.8,
                surviving_files=files,
                est_local_seconds=s.cost_local,
                est_spark_seconds=s.cost_spark,
                sensors_consulted=s.consulted,
            )

        # Phase 156.3 -- explicit "local won here last time" signal.
        # When route_history says local beat Spark by the configured
        # margin and we have a small/medium file count, surface a
        # ROUTE_SINGLE recommendation with the evidence in the reason.
        if s.outcome_prefer_local and 0 < files:
            return RouteRecommendation(
                engine=ROUTE_SINGLE,
                reason=("route_history: prior runs show local was "
                        "faster than Spark by the configured margin "
                        "for this SQL shape"),
                confidence=0.75,
                surviving_files=files,
                est_local_seconds=s.cost_local,
                est_spark_seconds=s.cost_spark,
                sensors_consulted=s.consulted,
            )

        # Step 6: coordinator high pressure -> Spark when available.
        if (s.coordinator_pressure == "high" and s.cost_spark > 0):
            return RouteRecommendation(
                engine=ROUTE_SPARK_CONNECT,
                reason=("coordinator reports high S3 bandwidth pressure "
                        "-- push compute to Spark to relieve the API pod"),
                confidence=0.7,
                surviving_files=files,
                est_local_seconds=s.cost_local,
                est_spark_seconds=s.cost_spark,
                sensors_consulted=s.consulted,
            )

        # Default: no strong signal -- defer to engine_router's config
        # rules.  Returning None means "no opinion".
        return None


__all__ = [
    "BrainRouter",
    "QueryContext",
    "RouteRecommendation",
    "ROUTE_SINGLE",
    "ROUTE_MULTI_WORKER",
    "ROUTE_MULTI_POD",
    "ROUTE_SPARK_CONNECT",
    "ROUTE_CACHE",
    "ROUTE_EMPTY",
    "enabled",
]
