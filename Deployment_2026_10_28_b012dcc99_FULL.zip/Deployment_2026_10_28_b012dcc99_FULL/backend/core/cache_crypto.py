"""
Phase 134-G5: Cache Encryption at Rest.

AES-256-GCM encryption for cached parquet files.
Ensures compliance with SOC 2, HIPAA, GDPR for data at rest.
"""

import hashlib
import logging
import os
import secrets
from typing import Optional

logger = logging.getLogger(__name__)

# Optional dependency — gracefully degrade if not installed
try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    _HAS_CRYPTO = True
except ImportError:
    _HAS_CRYPTO = False
    logger.info("cryptography library not installed — cache encryption unavailable")


class CacheEncryption:
    """AES-256-GCM encryption/decryption for cached files."""

    def __init__(self, enabled: bool = False, key: Optional[bytes] = None,
                 key_source: str = "config"):
        self.enabled = enabled and _HAS_CRYPTO
        self._key = key
        self._key_source = key_source
        if self.enabled and not self._key:
            self._key = self._load_key()
        if self.enabled and self._key:
            logger.info("Cache encryption enabled (AES-256-GCM)")
        elif enabled and not _HAS_CRYPTO:
            logger.warning("Cache encryption requested but cryptography library not installed")

    def _load_key(self) -> Optional[bytes]:
        """Load encryption key from configured source."""
        if self._key_source == "env":
            raw = os.environ.get("QS_CACHE_ENCRYPTION_KEY", "")
            if raw:
                return hashlib.sha256(raw.encode()).digest()
        elif self._key_source == "k8s_secret":
            # K8s secret mounted as env var
            raw = os.environ.get("QS_CACHE_ENCRYPTION_KEY", "")
            if raw:
                return hashlib.sha256(raw.encode()).digest()
        elif self._key_source == "config":
            raw = os.environ.get("QS_CACHE_ENCRYPTION_KEY", "")
            if raw:
                return hashlib.sha256(raw.encode()).digest()
        logger.warning("No encryption key found for source=%s — encryption disabled", self._key_source)
        self.enabled = False
        return None

    def encrypt_file(self, input_path: str, output_path: str) -> bool:
        """Encrypt a file using AES-256-GCM. Returns True on success."""
        if not self.enabled or not self._key:
            return False
        try:
            nonce = secrets.token_bytes(12)  # 96-bit nonce for GCM
            aesgcm = AESGCM(self._key)
            with open(input_path, "rb") as f:
                plaintext = f.read()
            ciphertext = aesgcm.encrypt(nonce, plaintext, None)
            tmp_path = output_path + ".enc.tmp"
            with open(tmp_path, "wb") as f:
                f.write(nonce)        # 12 bytes
                f.write(ciphertext)   # rest
            os.replace(tmp_path, output_path)
            return True
        except Exception as exc:
            logger.error("Encryption failed for %s: %s", input_path, exc)
            return False

    def decrypt_file(self, input_path: str, output_path: str) -> bool:
        """Decrypt an AES-256-GCM encrypted file. Returns True on success."""
        if not self.enabled or not self._key:
            return False
        try:
            with open(input_path, "rb") as f:
                data = f.read()
            if len(data) < 12:
                logger.error("Encrypted file too small: %s", input_path)
                return False
            nonce = data[:12]
            ciphertext = data[12:]
            aesgcm = AESGCM(self._key)
            plaintext = aesgcm.decrypt(nonce, ciphertext, None)
            tmp_path = output_path + ".dec.tmp"
            with open(tmp_path, "wb") as f:
                f.write(plaintext)
            os.replace(tmp_path, output_path)
            return True
        except Exception as exc:
            logger.error("Decryption failed for %s: %s", input_path, exc)
            return False

    def is_available(self) -> bool:
        """Check if encryption is enabled and key is loaded."""
        return self.enabled and self._key is not None
