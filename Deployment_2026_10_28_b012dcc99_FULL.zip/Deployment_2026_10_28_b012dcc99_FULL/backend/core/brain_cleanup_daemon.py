"""BrainCleanupDaemon -- bounded-table cleanup for Phase 156 tables.

Phase 156 (2026-06-25) -- the brain_pruning_memo and
brain_route_outcome tables grow on every query.  Without a cleanup
daemon they'd accumulate forever; with one, untouched rows beyond
the configured TTL are evicted.

Strategic shape -- single daemon, both tables:

  * One scheduler job (default every 6h).
  * Single tick consults config-driven TTLs:
      - brain_pruning_memo.cleanup_ttl_hours  (default 72h)
      - brain_route_history.cleanup_ttl_days  (default 30d)
  * Both DB calls fail-OPEN; one failure doesn't block the other.
  * Honours background_jobs admin pause control.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


def _cfg(section: str, key: str, fallback: Any) -> Any:
    try:
        from core.config import get as _g
        return _g(section, key, fallback)
    except Exception:
        return fallback


def cron_interval_hours() -> int:
    return int(_cfg("brain_cleanup", "interval_hours", 6) or 6)


def cleanup_tick(db_manager: Any) -> Dict[str, Any]:
    """Single sweep -- evict stale rows from both tables.  Always
    runs (no master switch); the per-target TTLs are the knobs."""
    out: Dict[str, Any] = {
        "memo_evicted":           0,
        "route_history_evicted":  0,
        "memo_error":             None,
        "route_history_error":    None,
    }
    if db_manager is None:
        return out

    # ── brain_pruning_memo ──────────────────────────────────────────
    try:
        memo_ttl_hours = int(
            _cfg("brain_pruning_memo", "cleanup_ttl_hours", 72) or 72
        )
        # Phase 156 deep-dive R14 -- TTL floor.  If operator sets the
        # cleanup TTL to 0 or negative, ``cutoff`` would equal now and
        # the daemon would DELETE EVERY ROW.  Floor at 1 hour so a
        # misconfig can't nuke the table.
        if memo_ttl_hours < 1:
            logger.warning(
                "[brain-cleanup] memo cleanup_ttl_hours=%d <1 -- "
                "flooring to 1h to prevent total wipe.",
                memo_ttl_hours,
            )
            memo_ttl_hours = 1
        cutoff = (datetime.now(timezone.utc)
                  - timedelta(hours=memo_ttl_hours)).isoformat()
        out["memo_evicted"] = int(
            db_manager.brain_memo_evict_older_than(cutoff) or 0
        )
    except Exception as exc:
        out["memo_error"] = str(exc)[:200]
        logger.warning("[brain-cleanup] memo evict failed: %s", exc)

    # ── brain_route_outcome ─────────────────────────────────────────
    try:
        hist_ttl_days = int(
            _cfg("brain_route_history", "cleanup_ttl_days", 30) or 30
        )
        # Phase 156 deep-dive R14 -- TTL floor mirror of memo path.
        if hist_ttl_days < 1:
            logger.warning(
                "[brain-cleanup] route_history cleanup_ttl_days=%d <1 -- "
                "flooring to 1d to prevent total wipe.",
                hist_ttl_days,
            )
            hist_ttl_days = 1
        cutoff = (datetime.now(timezone.utc)
                  - timedelta(days=hist_ttl_days)).isoformat()
        out["route_history_evicted"] = int(
            db_manager.brain_route_outcome_evict_older_than(cutoff) or 0
        )
    except Exception as exc:
        out["route_history_error"] = str(exc)[:200]
        logger.warning("[brain-cleanup] route history evict failed: %s",
                       exc)

    # Phase 157 (2026-06-26) -- Tier 3: time-bound report grant expiry.
    # Piggybacks on the same 6h tick.  Bounded: only rows with a non-
    # NULL grant_until in the past are touched.  Each expiration emits
    # an audit event so the report's history shows the auto-revoke.
    try:
        from core.business_report_permissions import expire_old_grants
        out["br_grants_expired"] = int(
            expire_old_grants(db_manager) or 0
        )
    except Exception as exc:
        out["br_grants_error"] = str(exc)[:200]
        logger.warning(
            "[brain-cleanup] BR grant expiry failed: %s", exc,
        )

    if (out["memo_evicted"]
            or out["route_history_evicted"]
            or out.get("br_grants_expired", 0)):
        logger.info(
            "[brain-cleanup] evicted %d memo + %d route-history + %d "
            "expired BR grants",
            out["memo_evicted"], out["route_history_evicted"],
            out.get("br_grants_expired", 0),
        )
    return out


def register_cleanup_daemon(
    scheduler: Any, db_manager: Any,
) -> Optional[str]:
    """Hook into the APScheduler the way pruning_alerts.register_alerts_daemon
    does.  Also registers with core.background_jobs so the daemon
    becomes pausable from the admin UI."""
    if scheduler is None:
        return None
    hours = max(1, cron_interval_hours())
    job_id = "brain_cleanup_daemon"
    try:
        def _tick():
            try:
                from core.background_jobs import is_paused as _bj_paused
                if _bj_paused("brain_cleanup_daemon"):
                    return {"status": "skipped", "reason": "paused by admin"}
            except Exception:
                pass
            try:
                return cleanup_tick(db_manager)      # the ledger reads the result (2026-10-07)
            except Exception as exc:
                logger.warning("[brain-cleanup] tick error: %s", exc,
                               exc_info=True)
                return {"error": str(exc)[:300]}

        scheduler.add_job(
            _tick, "interval", hours=hours,
            id=job_id, replace_existing=True,
            max_instances=1, coalesce=True,
        )
        logger.info(
            "[brain-cleanup] scheduled every %dh (job_id=%s)",
            hours, job_id,
        )

        try:
            from core import background_jobs as _bj
            def _factory():
                return None
            _bj.register(
                name="brain_cleanup_daemon",
                description=(
                    f"Phase 156 -- brain table cleanup.  Every {hours}h, "
                    "evicts stale rows from brain_pruning_memo "
                    "(TTL: brain_pruning_memo.cleanup_ttl_hours, "
                    "default 72h) and brain_route_outcome (TTL: "
                    "brain_route_history.cleanup_ttl_days, default "
                    "30d).  Keeps the brain's memory tables bounded."
                ),
                factory=_factory,
                autostart=True,
                controllable=True,
            )
            logger.info(
                "[brain-cleanup] registered in background_jobs registry",
            )
        except Exception as _bj_exc:
            logger.debug(
                "[brain-cleanup] background_jobs registration failed "
                "(non-fatal): %s", _bj_exc,
            )
        return job_id
    except Exception as exc:
        logger.warning("[brain-cleanup] register failed: %s", exc)
        return None


__all__ = ["cleanup_tick", "register_cleanup_daemon"]
