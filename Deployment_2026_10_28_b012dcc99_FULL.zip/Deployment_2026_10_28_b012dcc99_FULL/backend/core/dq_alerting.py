"""
Phase 114-E — Data Quality alert dispatch engine.

Dispatches alerts to configured channels (email, webhook, Slack) when DQ rules fail.
All send functions are fail-safe — errors are logged but never propagated.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import smtplib
from datetime import datetime, timedelta, timezone
from email.mime.text import MIMEText
from typing import List

logger = logging.getLogger(__name__)

# THE severity vocabulary + ordering (2026-08-23: public — the API used to
# carry an inline copy of this mapping in run_single_rule, and its Pydantic
# models a third spelling in regex form; all three now read from here).
SEVERITY_ORDER = {"info": 0, "warning": 1, "critical": 2}
SEVERITIES = tuple(SEVERITY_ORDER)


def severity_meets_threshold(severity: str, threshold: str) -> bool:
    """True when ``severity`` is at or above ``threshold``.  Unknown
    spellings rank as 'warning' — the historical default of both former
    copies, kept identical so convergence changes no decision."""
    return (SEVERITY_ORDER.get(severity, 1)
            >= SEVERITY_ORDER.get(threshold, 1))


_SEVERITY_ORDER = SEVERITY_ORDER  # legacy internal alias


def dispatch_dq_alerts(rule: dict, result: dict, cfg, db) -> List[dict]:
    """Check severity threshold and dispatch alerts to all configured channels.

    Args:
        rule: DQ rule dict (name, severity, etc.)
        result: DQ result dict (passed, metric_value, etc.)
        cfg: config module (has data_quality.alert_channels, etc.)
        db: DatabaseManager instance

    Returns:
        List of alert dicts created.
    """
    if result.get("passed", True):
        return []  # Only alert on failures

    # 2026-09-17 (FB-8b) -- an ERRORED check still alerts: a rule that
    # silently stopped running is worse than one that fails.  What changes is
    # that the alert SAYS SO, instead of arriving as a critical data-quality
    # failure on data nobody has actually measured.  _build_payload carries
    # it; see the ``kind`` field there.

    # Severity check
    rule_severity = rule.get("severity", "warning")
    threshold = cfg.data_quality.notify_severity_threshold
    if not severity_meets_threshold(rule_severity, threshold):
        return []

    channels = cfg.data_quality.alert_channels or []
    if not channels:
        return []

    # ── Cooldown CAP (2026-08-23) ────────────────────────────────────
    # Alert dispatch now fires from EVERY path that records a failure
    # (scheduled loops included), so a persistently-failing rule on a
    # 60-minute interval would email/page every tick.  This is a CAP —
    # it THROTTLES (skip + log), it never fails; and any error probing
    # the history fails OPEN, because alerting twice beats alerting
    # never.  0 disables the cooldown = alert on every failure.
    try:
        cooldown_min = int(getattr(cfg.data_quality, "alert_cooldown_minutes", 60))
    except Exception:
        cooldown_min = 60
    if cooldown_min > 0 and db is not None and rule.get("id") is not None:
        try:
            recent = db.list_dq_alerts(rule_id=rule.get("id"), status="sent",
                                       limit=1)
            last_iso = recent[0].get("sent_at") if recent else None
            if last_iso:
                last_dt = datetime.fromisoformat(
                    str(last_iso).replace("Z", "+00:00"))
                if last_dt.tzinfo is None:
                    last_dt = last_dt.replace(tzinfo=timezone.utc)
                age = datetime.now(timezone.utc) - last_dt
                if age < timedelta(minutes=cooldown_min):
                    logger.info(
                        "DQ alert for rule %s suppressed by cooldown "
                        "(last sent %.1f min ago < %d min)",
                        rule.get("id"), age.total_seconds() / 60, cooldown_min)
                    return []
        except Exception as exc:
            logger.warning("DQ alert cooldown probe failed (alerting "
                           "anyway): %s", exc)

    alerts = []
    payload = _build_payload(rule, result)

    for channel_cfg in channels:
        ch_type = channel_cfg.get("type", "").lower()
        try:
            if ch_type == "email":
                _send_email(payload, channel_cfg)
                status = "sent"
                error = None
            elif ch_type == "webhook":
                _send_webhook(payload, channel_cfg)
                status = "sent"
                error = None
            elif ch_type == "slack":
                _send_slack(payload, channel_cfg)
                status = "sent"
                error = None
            else:
                logger.warning("Unknown alert channel type: %s", ch_type)
                continue
        except Exception as exc:
            from core.proxy_utils import sanitize_proxy_error
            status = "failed"
            error = sanitize_proxy_error(str(exc))[:500]
            logger.warning("DQ alert dispatch failed (%s): %s", ch_type, sanitize_proxy_error(str(exc)))

        try:
            alert = db.create_dq_alert(
                rule_id=rule.get("id"),
                result_id=result.get("id"),
                channel=ch_type,
                recipient=channel_cfg.get("recipients", channel_cfg.get("url", channel_cfg.get("webhook_url", ""))),
                status=status,
                sent_at=datetime.now(timezone.utc) if status == "sent" else None,
                error=error,
                payload=payload,
            )
            alerts.append(alert)
        except Exception as exc:
            logger.warning("Failed to persist DQ alert record: %s", exc)

    return alerts


def _build_payload(rule: dict, result: dict) -> dict:
    """Build the alert payload dict.

    2026-09-17 (FB-8b) -- ``kind`` distinguishes a DATA failure from a CHECK
    that could not run, and the default message says which.  Before this both
    arrived as "DQ rule 'X' failed" with severity critical, so a rule pointing
    at a table that had been renamed read exactly like genuinely bad data.
    Whoever is paged needs to know which of the two they are looking at before
    they can do anything at all.
    """
    _errored = str(result.get("outcome") or "") == "errored"
    _err = (result.get("details") or {}).get("error") if isinstance(
        result.get("details"), dict) else None
    if _errored:
        _default_msg = (
            f"DQ rule '{rule.get('name')}' COULD NOT RUN"
            + (f": {_err}" if _err else "")
            + ". This is a problem with the CHECK, not a measurement of the "
              "data -- the data has not been assessed.")
    else:
        _default_msg = f"DQ rule '{rule.get('name')}' failed"
    return {
        "rule_id": rule.get("id"),
        "rule_name": rule.get("name", "Unknown"),
        "rule_type": rule.get("rule_type", ""),
        "severity": rule.get("severity", "warning"),
        "passed": result.get("passed", False),
        "outcome": result.get("outcome"),
        "kind": "check_error" if _errored else "data_failure",
        "metric_value": result.get("metric_value"),
        "threshold_value": result.get("threshold_value"),
        "message": result.get("error_message", _default_msg),
        "checked_at": result.get("checked_at", datetime.now(timezone.utc).isoformat()),
    }


def _send_email(payload: dict, cfg: dict) -> None:
    """Send alert email via SMTP (stdlib — no external dependency)."""
    smtp_host = cfg.get("smtp_host", "localhost")
    smtp_port = int(cfg.get("smtp_port", 587))
    smtp_user = cfg.get("smtp_user", "")
    smtp_pass = cfg.get("smtp_password", "")
    use_tls = cfg.get("use_tls", True)
    from_addr = cfg.get("from_address", "querystudio-alerts@noreply.local")
    recipients = cfg.get("recipients", "")
    if isinstance(recipients, str):
        recipients = [r.strip() for r in recipients.split(",") if r.strip()]
    if not recipients:
        # 2026-08-23: was log-and-return — the caller then recorded the
        # alert as status="sent".  A misconfigured channel must record
        # FAILED, not claim delivery that never happened.
        raise ValueError("email alert channel has no recipients configured")

    subject = f"[QueryStudio DQ] {payload.get('severity', 'warning').upper()}: {payload.get('rule_name', 'Rule')} failed"
    body = (
        f"Data Quality Alert\n"
        f"{'=' * 40}\n"
        f"Rule: {payload.get('rule_name')}\n"
        f"Type: {payload.get('rule_type')}\n"
        f"Severity: {payload.get('severity')}\n"
        f"Metric: {payload.get('metric_value')}\n"
        f"Threshold: {payload.get('threshold_value')}\n"
        f"Checked: {payload.get('checked_at')}\n"
        f"\n{payload.get('message', '')}\n"
    )

    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = from_addr
    msg["To"] = ", ".join(recipients)

    if use_tls:
        with smtplib.SMTP(smtp_host, smtp_port) as server:
            server.starttls()
            if smtp_user:
                server.login(smtp_user, smtp_pass)
            server.sendmail(from_addr, recipients, msg.as_string())
    else:
        with smtplib.SMTP(smtp_host, smtp_port) as server:
            if smtp_user:
                server.login(smtp_user, smtp_pass)
            server.sendmail(from_addr, recipients, msg.as_string())

    logger.info("DQ alert email sent to %s for rule '%s'", recipients, payload.get("rule_name"))


def _send_webhook(payload: dict, cfg: dict) -> None:
    """Send alert as HTTP POST to a webhook URL."""
    import httpx
    from core.url_safety import validate_url_safety

    url = cfg.get("url", "")
    if not url:
        # 2026-08-23: see email sender — misconfiguration is a FAILED
        # delivery, never a silent "sent".
        raise ValueError("webhook alert channel has no url configured")
    try:
        validate_url_safety(url)
    except ValueError as ssrf_err:
        logger.warning("[dq_alerting] SSRF blocked webhook %s: %s", url[:80], ssrf_err)
        raise ValueError(f"webhook url blocked by SSRF policy: {ssrf_err}")
    secret = cfg.get("secret")
    timeout = int(cfg.get("timeout_seconds", 10))

    body_bytes = json.dumps(payload, default=str).encode("utf-8")
    headers = {"Content-Type": "application/json", "X-QS-Event": "dq_alert"}
    if secret:
        sig = hmac.new(secret.encode("utf-8"), body_bytes, hashlib.sha256).hexdigest()
        headers["X-QS-Signature"] = sig

    from core.proxy_utils import get_httpx_proxy_url
    with httpx.Client(timeout=timeout, proxy=get_httpx_proxy_url(),
                      follow_redirects=False) as client:
        resp = client.post(url, content=body_bytes, headers=headers)
        resp.raise_for_status()

    logger.info("DQ alert webhook sent to %s (status %d)", url, resp.status_code)


def _send_slack(payload: dict, cfg: dict) -> None:
    """Send alert to Slack Incoming Webhook."""
    import httpx
    from core.url_safety import validate_url_safety

    webhook_url = cfg.get("webhook_url", "")
    if not webhook_url:
        # 2026-08-23: see email sender — misconfiguration is a FAILED
        # delivery, never a silent "sent".
        raise ValueError("slack alert channel has no webhook_url configured")
    try:
        validate_url_safety(webhook_url)
    except ValueError as ssrf_err:
        logger.warning("[dq_alerting] SSRF blocked Slack webhook %s: %s", webhook_url[:80], ssrf_err)
        raise ValueError(f"slack webhook url blocked by SSRF policy: {ssrf_err}")

    severity_emoji = {"info": ":information_source:", "warning": ":warning:", "critical": ":rotating_light:"}.get(
        payload.get("severity", "warning"), ":warning:"
    )
    text = (
        f"{severity_emoji} *DQ Alert: {payload.get('rule_name')}*\n"
        f"Type: {payload.get('rule_type')} | Severity: {payload.get('severity')}\n"
        f"Metric: {payload.get('metric_value')} (threshold: {payload.get('threshold_value')})\n"
        f"{payload.get('message', '')}"
    )
    slack_payload = {"text": text}

    from core.proxy_utils import get_httpx_proxy_url
    with httpx.Client(timeout=10, proxy=get_httpx_proxy_url(),
                      follow_redirects=False) as client:
        resp = client.post(webhook_url, json=slack_payload)
        resp.raise_for_status()

    logger.info("DQ alert Slack message sent for rule '%s'", payload.get("rule_name"))
