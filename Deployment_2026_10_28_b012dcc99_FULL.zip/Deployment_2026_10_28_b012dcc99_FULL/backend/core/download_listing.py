"""Paging a listing whose visibility rule lives in CODE, not in SQL.

2026-08-30.  Both Download Centre listings fetched a page of rows and *then*
filtered it to what the caller may see.  That is backwards, and it is visible
to the user rather than subtle.  Measured, with 25 rows belonging to other
users ahead of alice's 5:

    /api/exports   limit=5    -> alice sees 0 of her 5 files
    /api/downloads limit=5    -> alice sees 0 of her 5 files
    /api/downloads limit=10   -> alice sees 0 of her 5 files

An empty Download Centre for a user who has five downloads.  The rows are
ordered ``created_at DESC``, so on any busy deployment a user's own files fall
outside the window as soon as other people generate enough downloads --
exactly when they most need to find theirs.  ``/api/exports`` fetched
``limit * 3`` to paper over it, which merely moves the threshold: it fails
whenever more than two thirds of recent rows belong to someone else.

Filtering in SQL is not available here.  Visibility is not "created_by = me":
it is ``_enforce_download_ownership`` -- creator, or an entitlement share
(source read check plus proven row-security scope equality), or the
originating execution's owner, or admin/support.  That rule is code, and
duplicating a weaker version of it into a WHERE clause is how the Download
Centre ended up with four different visibility rules in the first place.

So: page the source until enough VISIBLE rows are collected, or the source is
exhausted, or a scan bound is reached -- and SAY SO when the bound is what
stopped it.  A truncated listing that reports success is the same silent-cap
shape as a reclamation sweep that never drains.

``offset`` counts VISIBLE rows, which is what a paginating client means by
"page 2 of my downloads".  For an admin, every row is visible and the result
is identical to the old behaviour.
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List

logger = logging.getLogger(__name__)

#: Rows pulled from the store per round trip.
_PAGE = 200

#: Hard bound on how many rows one request will scan.  Without it a caller
#: whose visible set is empty would walk the entire table.
_MAX_SCAN = 5000


def visible_page(fetch: Callable[[int, int], List[Dict[str, Any]]],
                 is_visible: Callable[[Dict[str, Any]], bool],
                 *, limit: int, offset: int = 0,
                 page: int = _PAGE, max_scan: int = _MAX_SCAN,
                 label: str = "downloads") -> List[Dict[str, Any]]:
    """Collect ``limit`` visible rows, skipping the first ``offset`` of them.

    ``fetch(limit, offset)`` reads raw rows from the store; ``is_visible(row)``
    applies the caller's own rule and must never raise (wrap it).
    """
    if limit <= 0:
        return []
    out: List[Dict[str, Any]] = []
    seen_visible = 0
    scanned = 0
    raw_offset = 0
    while scanned < max_scan:
        batch = fetch(page, raw_offset) or []
        if not batch:
            return out                      # source exhausted — complete answer
        raw_offset += len(batch)
        scanned += len(batch)
        for row in batch:
            if not is_visible(row):
                continue
            seen_visible += 1
            if seen_visible <= offset:
                continue
            out.append(row)
            if len(out) >= limit:
                return out
        if len(batch) < page:
            return out                      # short read — source exhausted
    logger.warning(
        "[%s] listing stopped after scanning %d rows with %d visible result(s) "
        "— there may be more. Raise the scan bound or narrow the query.",
        label, scanned, len(out))
    return out
