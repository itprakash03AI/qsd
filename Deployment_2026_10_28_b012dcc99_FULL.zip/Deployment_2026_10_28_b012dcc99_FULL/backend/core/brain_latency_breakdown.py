"""Brain latency breakdown — Phase 160 (2026-07-01).

Why this exists
---------------
Today the brain answers "did we prune?" via
``brain_decision_log`` and "which decisions ran?" via ``brain_trace``.
But "where did the query's wall-clock go?" is unstructured — the
breakdown lives in prose comments (``metadata_seconds``) or is spread
across ad-hoc log lines.  Without a structured p50/p95 breakdown per
stage the operator cannot decide whether the bottleneck is S3, brain
metadata, or DuckDB compute — which is the deciding evidence for
Phase 1 (warm subprocess pool) vs Phase 3 (NFS mirror) in the
DuckDB Query Cache Brainstorm (2026-07-01).

Design properties
-----------------
- **Single chokepoint**: every stage timer goes through
  :class:`LatencyBreakdown`.  No parallel timers scattered across
  execute_api / iceberg_reader / duckdb_subprocess.  Callers use the
  ``.stage()`` context manager or ``.add_seconds()`` — one API.
- **Fail-open**: any measurement error swallowed silently.  A broken
  stopwatch must never break a query.
- **Prometheus histograms** for p50/p95 aggregation across the fleet
  — populated by :func:`emit`.  Buckets tuned for the QS range
  (10 ms - 60 s).
- **brain_trace integration**: :meth:`LatencyBreakdown.emit` also
  traces a ``latency`` entry so the per-query trace shows the
  breakdown alongside routing decisions.
- **Multi-instance safe**: the class is stateless across queries; each
  query builds its own ``LatencyBreakdown`` object and emits.  No
  ContextVar; no risk of async-task cross-contamination.

Stages
------
- ``s3``:          S3 GET / listing time (bytes over the wire)
- ``metadata``:    iceberg manifest walk + parquet-footer parse time
- ``pruning``:     brain layers (manifest / supplement / bloom) time
- ``coldstart``:   per-query DuckDB subprocess fixed tax — interpreter
                   spawn + ``import duckdb`` + ``LOAD httpfs`` + S3
                   cred/SSL setup.  Broken out from ``compute`` so the
                   operator can see how much a warm subprocess pool
                   (Phase 1) would eliminate vs. genuine compute.
- ``compute``:     DuckDB execution time (the real scan/aggregate)
- ``other``:       residual not captured elsewhere

The six stages compose the ``total`` wall-clock the operator sees.
"""
from __future__ import annotations

import logging
import threading
import time
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Any, Dict, Generator, Optional


logger = logging.getLogger(__name__)


# Canonical stage names.  Locked here so the CI contract test can
# guarantee no site invents a new stage (which would silently drop
# from the Prometheus dashboard).
STAGES = ("s3", "metadata", "pruning", "coldstart", "compute", "other")


# ── Prometheus histograms (lazy-created) ─────────────────────────────────
#
# Buckets in seconds tuned for the QS query range: sub-second for cache
# hits, tens of seconds for cold S3-heavy queries.  Any query over 60s
# rolls into +Inf which is fine — the tail is what the operator watches.
_HISTOGRAM_BUCKETS = (
    0.010, 0.025, 0.050, 0.100, 0.250, 0.500,
    1.0, 2.5, 5.0, 10.0, 25.0, 60.0,
)


_PROM_LOCK = threading.Lock()
_prom_histograms: Dict[str, Any] = {}   # stage -> prometheus_client.Histogram
_prom_ready = False


def _ensure_prom_histograms() -> Dict[str, Any]:
    """Lazily build the Prometheus histograms.  Fail-open on any
    import / registration error — the module is optional and must
    never break the brain path.

    On ``ValueError('Duplicated timeseries...')`` — the collector
    already exists in the default REGISTRY (typical when a test
    resets our local dict but the registry state persists).  We
    look up the existing collector and reuse it so ``.observe()``
    calls still land on a valid metric.
    """
    global _prom_ready
    with _PROM_LOCK:
        if _prom_ready:
            return _prom_histograms
        _prom_ready = True   # mark before try so we don't retry-loop
        try:
            from prometheus_client import Histogram, REGISTRY  # type: ignore
        except Exception as exc:                       # pragma: no cover
            logger.debug("prometheus_client unavailable: %s", exc)
            return _prom_histograms
        specs = [(stage,
                  f"qs_brain_latency_{stage}_seconds",
                  f"Wall-clock time spent in the {stage} stage of a "
                  f"single query. Populated by "
                  f"brain_latency_breakdown.LatencyBreakdown.emit().")
                 for stage in STAGES]
        specs.append(("total", "qs_brain_latency_total_seconds",
                      "Total query wall-clock time observed by "
                      "brain_latency_breakdown.  Sum of stage times "
                      "plus any residual not attributed to a stage."))
        for key, metric_name, docstring in specs:
            existing = _lookup_existing_metric(REGISTRY, metric_name)
            if existing is not None:
                _prom_histograms[key] = existing
                continue
            try:
                _prom_histograms[key] = Histogram(
                    metric_name, docstring, buckets=_HISTOGRAM_BUCKETS,
                )
            except Exception as exc:
                # Race: another thread registered between our lookup
                # and Histogram().  Look up again and reuse; if that
                # ALSO fails, log + skip (fail-open).
                existing = _lookup_existing_metric(REGISTRY, metric_name)
                if existing is not None:
                    _prom_histograms[key] = existing
                else:                                       # pragma: no cover
                    logger.debug("prom histogram %s not created: %s",
                                 metric_name, exc)
        return _prom_histograms


def _lookup_existing_metric(registry: Any, name: str) -> Optional[Any]:
    """Look up an already-registered collector by its metric name.

    ``prometheus_client`` doesn't expose a public lookup so we walk
    the registry's private index.  If the private API changes across
    versions, return None and let the caller re-register.
    """
    try:
        index = getattr(registry, "_names_to_collectors", None)
        if not isinstance(index, dict):
            return None
        return index.get(name)
    except Exception:                                       # pragma: no cover
        return None


# ── LatencyBreakdown ─────────────────────────────────────────────────────


@dataclass
class LatencyBreakdown:
    """One structured latency breakdown per query.

    Callers build one per query, feed it via ``stage()`` or
    ``add_seconds()``, and call ``emit()`` at completion.
    """

    stages_seconds: Dict[str, float] = field(default_factory=dict)
    total_seconds: float = 0.0
    started_at: float = field(default_factory=time.monotonic)

    def __post_init__(self) -> None:
        # Guarantee every canonical stage has a slot from the start
        # so downstream renderers can iterate without KeyErrors.
        for stage in STAGES:
            self.stages_seconds.setdefault(stage, 0.0)

    def add_seconds(self, stage: str, seconds: float) -> None:
        """Attribute ``seconds`` of wall-clock to ``stage``.

        Non-canonical stages are folded into ``other`` so a typo at
        the call site cannot silently drop time from the breakdown.
        """
        try:
            s = float(seconds)
        except Exception:
            return
        if s <= 0 or s != s:   # NaN check
            return
        bucket = stage if stage in STAGES else "other"
        self.stages_seconds[bucket] = self.stages_seconds.get(bucket, 0.0) + s

    @contextmanager
    def stage(self, name: str) -> Generator[None, None, None]:
        """Context manager form — the elapsed time inside the ``with``
        block is attributed to ``name``.  Exceptions are re-raised but
        the elapsed time is still recorded (a slow S3 GET that then
        errors still counts as S3 time)."""
        t0 = time.monotonic()
        try:
            yield
        finally:
            self.add_seconds(name, time.monotonic() - t0)

    def finalize(self, total_seconds: Optional[float] = None) -> None:
        """Set the total wall-clock.

        Pass ``total_seconds`` explicitly when the orchestrator has a
        better clock (e.g. execute_api's start-to-response elapsed).
        Omit to derive from ``started_at`` — useful when this object
        is the only stopwatch around.
        """
        if total_seconds is not None:
            try:
                self.total_seconds = max(0.0, float(total_seconds))
            except Exception as _cast_exc:
                # 2026-07-02 -- non-numeric total_seconds from a
                # buggy orchestrator.  Debug-log so the bad callsite
                # can be traced; fall through to the monotonic-clock
                # derivation below.
                logger.debug(
                    "finalize: float(total_seconds=%r) suppressed %s: "
                    "%s -- falling back to monotonic derivation",
                    total_seconds, type(_cast_exc).__name__, _cast_exc,
                )
                total_seconds = None
        if total_seconds is None:
            self.total_seconds = max(
                0.0, time.monotonic() - self.started_at,
            )
        # Attribute residual (total minus sum of stages) to ``other``
        # so operators can see how much time is unaccounted for.  A
        # large residual means the caller forgot to instrument a stage.
        attributed = sum(self.stages_seconds.get(s, 0.0)
                         for s in STAGES if s != "other")
        residual = self.total_seconds - attributed - self.stages_seconds.get("other", 0.0)
        if residual > 0:
            self.stages_seconds["other"] = (
                self.stages_seconds.get("other", 0.0) + residual
            )

    def as_dict(self) -> Dict[str, Any]:
        """Serialize for brain_trace / brain_decision_log / JSON blobs."""
        out = {"total_seconds": round(self.total_seconds, 4)}
        for stage in STAGES:
            out[f"{stage}_seconds"] = round(
                self.stages_seconds.get(stage, 0.0), 4,
            )
        return out

    def emit(self, *, trace: bool = True) -> Dict[str, Any]:
        """Publish this breakdown to Prometheus + optionally
        brain_trace, and return the serialized dict for callers that
        want to persist it in ``query_executions.files_metadata``.

        Idempotent: calling ``emit`` twice on the same object doubles
        the Prometheus contribution.  Call once per query at the
        completion boundary.
        """
        # Auto-finalize if the caller forgot.  Uses the started_at
        # timestamp captured at construction so total_seconds is
        # sensible even without an explicit finalize().
        if self.total_seconds <= 0:
            self.finalize()

        histograms = _ensure_prom_histograms()
        for stage in STAGES:
            hist = histograms.get(stage)
            if hist is None:
                continue
            val = self.stages_seconds.get(stage, 0.0)
            if val > 0:
                try:
                    hist.observe(val)
                except Exception as exc:              # pragma: no cover
                    logger.debug("prom observe stage=%s failed: %s",
                                 stage, exc)
        total_hist = histograms.get("total")
        if total_hist is not None and self.total_seconds > 0:
            try:
                total_hist.observe(self.total_seconds)
            except Exception as exc:                  # pragma: no cover
                logger.debug("prom observe total failed: %s", exc)

        payload = self.as_dict()

        if trace:
            # Delayed import so this module has no hard dep on
            # brain_trace (helps unit-test isolation).
            try:
                from core.brain_trace import trace as _bt_trace
                _bt_trace("latency", "emit", **payload)
            except Exception as exc:                  # pragma: no cover
                logger.debug("brain_trace emit failed: %s", exc)

        return payload


# ── module-level helpers ─────────────────────────────────────────────────


def new_breakdown() -> LatencyBreakdown:
    """Factory — one call per query at the orchestrator boundary.

    Returns a fresh LatencyBreakdown pre-seeded with zero for every
    canonical stage.  Callers thread this object down through the
    setup / execute / cleanup phases and call ``emit()`` at the end.
    """
    return LatencyBreakdown()


# ── ContextVar-scoped helpers ───────────────────────────────────────────
#
# The wire-in pattern mirrors ``brain_trace``: the orchestrator
# (execute_api) calls :func:`begin_breakdown` at query entry; every
# lower layer calls :func:`record_stage` (or the :func:`stage_ctx`
# context manager) without threading the object down; the
# orchestrator calls :func:`emit_breakdown` at query completion.
#
# ContextVar so the breakdown propagates ACROSS ``asyncio.to_thread``
# boundaries — the sync DuckDB / iceberg_reader code can attribute
# time to the correct query.


_BREAKDOWN_VAR: ContextVar[Optional[LatencyBreakdown]] = ContextVar(
    "brain_latency_breakdown", default=None,
)


def begin_breakdown() -> LatencyBreakdown:
    """Start a new breakdown in the current async context.  Safe to
    call multiple times — the second call discards the prior state
    and starts fresh (matches brain_trace.begin semantics)."""
    b = LatencyBreakdown()
    _BREAKDOWN_VAR.set(b)
    return b


def current_breakdown() -> Optional[LatencyBreakdown]:
    """Return the active breakdown or None if :func:`begin_breakdown`
    wasn't called for this async context."""
    return _BREAKDOWN_VAR.get()


def record_stage(name: str, seconds: float) -> None:
    """Attribute ``seconds`` of wall-clock to ``name`` on the active
    breakdown.  No-op when inactive (e.g. background daemon, admin
    handler outside a query context) so callers don't need conditional
    guards at every site."""
    b = _BREAKDOWN_VAR.get()
    if b is None:
        return
    try:
        b.add_seconds(name, seconds)
    except Exception:                                       # pragma: no cover
        pass


@contextmanager
def stage_ctx(name: str) -> Generator[None, None, None]:
    """Context-manager form of :func:`record_stage`.  No-op when
    inactive — the ``with`` block runs, wall-clock isn't attributed."""
    b = _BREAKDOWN_VAR.get()
    if b is None:
        yield
        return
    with b.stage(name):
        yield


def emit_breakdown(total_seconds: Optional[float] = None) -> Dict[str, Any]:
    """Finalize + publish the active breakdown, then clear the
    ContextVar.  Returns the serialized dict (or an empty dict when
    inactive) so the orchestrator can persist it into
    ``query_executions.files_metadata``.

    Idempotent — a second call after clear returns {}.
    """
    b = _BREAKDOWN_VAR.get()
    if b is None:
        return {}
    if total_seconds is not None:
        b.finalize(total_seconds=total_seconds)
    payload = b.emit()
    _BREAKDOWN_VAR.set(None)
    return payload


def clear_breakdown() -> None:
    """Test hook — drop the ContextVar without emitting."""
    _BREAKDOWN_VAR.set(None)


def reset_for_tests() -> None:
    """Test-only: clear the lazy Prometheus histogram cache so the
    next call to :func:`_ensure_prom_histograms` re-registers.
    Rarely needed — the histograms are process-lifetime idempotent."""
    global _prom_ready
    with _PROM_LOCK:
        _prom_histograms.clear()
        _prom_ready = False


__all__ = [
    "STAGES", "LatencyBreakdown", "new_breakdown",
    "begin_breakdown", "current_breakdown", "record_stage",
    "stage_ctx", "emit_breakdown", "clear_breakdown",
    "reset_for_tests",
]
