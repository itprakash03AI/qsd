"""DuckDB strftime/strptime format-string normaliser (BF-571 + BF-572).

DuckDB's ``STRFTIME`` / ``STRPTIME`` follow Python's ``%`` directives.  When
SQL written for another dialect leaks through with format specifiers like
MySQL/Starburst's ``%i`` (minute) — or worse, with an upstream-mangled
mix of ``%-M`` and ``%i`` — DuckDB raises::

    Invalid Input Error: Failed to parse format specifier '...':
      Unrecognized format for strftime/strptime: %i

User scenario that drove this fix: a Starburst query like
``DATE_FORMAT(d, '%Y-%m-%d %H:%i:%s')`` was reaching DuckDB with its
format string only partially translated.  The agent should auto-fix
this in the query rather than leaving the user staring at a stack
trace.

This module scans every supported date/time formatting call in the SQL
and rewrites it so DuckDB can run it unchanged:

BF-571 — MySQL/Starburst ``DATE_FORMAT`` family (% directives)
    * ``STRFTIME(expr, fmt)`` / ``STRPTIME(text, fmt)`` — repair bad ``%``
      specifiers in the format string.
    * ``DATE_FORMAT(expr, fmt)`` → ``STRFTIME(CAST(expr AS TIMESTAMP), fmt)``
      because DuckDB has no DATE_FORMAT.

BF-572 — Trino/Starburst Joda-Time family (letter patterns)
    * ``format_datetime(expr, joda_fmt)`` → ``STRFTIME(CAST(expr AS
      TIMESTAMP), strftime_fmt)`` with Joda → strftime pattern conversion.
    * ``parse_datetime(text, joda_fmt)`` → ``STRPTIME(text, strftime_fmt)``.
    * ``to_iso8601(timestamp)`` → ``STRFTIME(CAST(... AS TIMESTAMP),
      '%Y-%m-%dT%H:%M:%S.%gZ')`` because DuckDB has no TO_ISO8601.

Returns ``(repaired_sql, [fix_descriptions])`` so the executor can
surface the agent action in the response — users see exactly what
was auto-corrected, not a silent rewrite.

Design notes
------------
* Idempotent — running twice produces the same output.
* Safe — only modifies the *quoted* format-string argument; SQL outside
  the literals is untouched.
* Conservative — never rewrites a directive that is already valid DuckDB
  (e.g. ``%M`` and ``%m`` stay as-is); only rewrites specifiers DuckDB
  rejects outright.
* DuckDB-target only — this module assumes the destination is DuckDB.
  Don't call it on SQL bound for Starburst/Trino/Snowflake.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Iterable

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Format-specifier repair table
# ---------------------------------------------------------------------------
# Each entry: (bad_specifier, duckdb_equivalent, human_description).
# Order matters: longer multi-char sequences MUST come first so we don't
# half-match (e.g. ``%T`` before ``%t``).
_FORMAT_REPAIRS: tuple[tuple[str, str, str], ...] = (
    # ── Compound MySQL specifiers (longer first) ──────────────────────
    ("%T", "%H:%M:%S",        "MySQL %T (24-hour time)"),
    ("%r", "%I:%M:%S %p",     "MySQL %r (12-hour time with AM/PM)"),
    ("%v", "%V",              "MySQL %v (ISO week-of-year, Mon start)"),
    ("%X", "%G",              "MySQL %X (ISO week-year)"),
    # ── Single-char MySQL DATE_FORMAT (NOT in DuckDB strftime) ────────
    ("%i", "%M",              "MySQL %i (minute padded)"),
    ("%c", "%-m",             "MySQL %c (month unpadded)"),
    ("%e", "%-d",             "MySQL %e (day-of-month unpadded)"),
    ("%k", "%-H",             "MySQL %k (hour 24 unpadded)"),
    ("%l", "%-I",             "MySQL %l (hour 12 unpadded)"),
    ("%h", "%I",              "MySQL %h (hour 12 padded, alias of %I)"),
    # MySQL/Starburst use ``%s`` interchangeably with ``%S`` (second
    # padded).  DuckDB only accepts the capital form.
    ("%s", "%S",              "MySQL %s (second padded, lowercase)"),
)


# Regex to find STRFTIME / STRPTIME / DATE_FORMAT calls with a quoted
# format-string argument.  Captures:
#   1: function name
#   2: first arg expression up to (and including) the comma
#   3: format-string body inside the quotes
#
# We tolerate single-quote SQL escapes (``''``) and backslash escapes
# inside the format-string literal.  The first-arg capture allows
# nested parens / quoted strings — TWO levels deep so common Trino
# shapes like ``DATE_FORMAT(COALESCE(d, NOW()), '…')`` or
# ``DATE_FORMAT(CAST(CAST(d AS DATE) AS TIMESTAMP), '…')`` match.
# Three-deep is vanishingly rare in DATE_FORMAT's first arg; leaving
# it un-rewritten only costs a clearer DuckDB error at execute time.
_STR_TIME_CALL = re.compile(
    r"""
    \b(STRFTIME|STRPTIME|DATE_FORMAT)    # 1: function name
    \s*\(                                 # opening paren
    (                                     # 2: first arg + comma
        (?:
            [^'(),]                       # plain chars
            | '(?:[^']|'')*'              # single-quoted string
            | \( (?: [^()] | \( [^()]* \) )* \)   # up to two nesting levels
        )+?
        ,
    )
    \s*
    '((?:[^'\\]|\\.|'')*)'                # 3: quoted format string
    \s*\)                                 # closing paren
    """,
    re.IGNORECASE | re.VERBOSE,
)


@dataclass
class FormatFix:
    """One auto-correction applied to a format string."""

    function: str          # e.g. "STRFTIME" / "DATE_FORMAT"
    original_format: str   # the format string as written
    repaired_format: str   # the rewritten format string
    specifiers_fixed: list[str] = field(default_factory=list)
    function_rewritten: bool = False  # True when DATE_FORMAT → STRFTIME

    def describe(self) -> str:
        """One-line, user-facing summary of this fix."""
        parts: list[str] = []
        if self.specifiers_fixed:
            parts.append(
                f"format specifiers {', '.join(self.specifiers_fixed)} "
                f"→ DuckDB equivalents"
            )
        if self.function_rewritten:
            parts.append("DATE_FORMAT → STRFTIME(CAST(... AS TIMESTAMP), ...)")
        return f"{self.function}: " + "; ".join(parts) if parts else self.function


def _match_repair(rest: str) -> tuple[str, str] | None:
    """Find the repair-table entry whose bad spelling starts *rest*.

    First match wins, so ``_FORMAT_REPAIRS`` order is load-bearing:
    a longer bad spelling must precede any prefix of itself.
    """
    for bad, good, _desc in _FORMAT_REPAIRS:
        if rest.startswith(bad):
            return bad, good
    return None


def _repair_format(fmt: str) -> tuple[str, list[str]]:
    """Apply the repair table to a single format-string literal.

    Returns ``(repaired_format, list_of_specifiers_that_were_fixed)``.
    Preserves ``%%`` literal-percent escapes."""
    out: list[str] = []
    fixed: list[str] = []
    seen: set[str] = set()
    i = 0
    n = len(fmt)
    while i < n:
        ch = fmt[i]
        if ch != "%":
            out.append(ch)
            i += 1
            continue
        rest = fmt[i:]
        if rest.startswith("%%"):
            out.append("%%")
            i += 2
            continue
        repair = _match_repair(rest)
        if repair is not None:
            bad, good = repair
            out.append(good)
            i += len(bad)
            if bad not in seen:
                fixed.append(bad)
                seen.add(bad)
            continue
        # No repair — emit the '%' and move on (the directive char
        # will be picked up next iteration).
        out.append("%")
        i += 1
    return "".join(out), fixed


def _normalise_strftime_formats_inner(sql: str) -> tuple[str, list[FormatFix]]:
    """Pass 1 of :func:`normalise_strftime_formats`.  Rewrite cross-dialect strftime specifiers in *sql* to DuckDB
    form.  Also rewrites ``DATE_FORMAT(expr, fmt)`` to
    ``STRFTIME(CAST(expr AS TIMESTAMP), fmt)`` because DuckDB doesn't
    recognise DATE_FORMAT.

    Returns ``(repaired_sql, [fixes])``.  When no fix is applied, the
    input SQL is returned unchanged and the list is empty (cheap
    fast-path).
    """
    if not sql or "%" not in sql:
        return sql, []
    # Fast-path: skip the regex walk if NO trigger token is textually
    # present.  DATE_FORMAT must always trigger because the function
    # itself is bogus on DuckDB.
    needs_walk = "DATE_FORMAT" in sql.upper() or any(
        bad in sql for bad, _, _ in _FORMAT_REPAIRS
    )
    if not needs_walk:
        return sql, []

    fixes: list[FormatFix] = []
    _ranges = _STRING_RANGES_HOLDER.get()

    def _sub(match: re.Match) -> str:
        # BF-571 audit fix: skip matches that start inside a SQL
        # string literal — they're user data, not function calls.
        if _ranges and _inside_string_literal(match.start(), _ranges):
            return match.group(0)
        fn_orig = match.group(1)
        fn_upper = fn_orig.upper()
        first_arg = match.group(2)  # includes trailing comma
        raw_fmt = match.group(3)
        repaired_fmt, specs = _repair_format(raw_fmt)

        rewrite_fn = (fn_upper == "DATE_FORMAT")

        if repaired_fmt == raw_fmt and not rewrite_fn:
            return match.group(0)

        fixes.append(FormatFix(
            function=fn_upper,
            original_format=raw_fmt,
            repaired_format=repaired_fmt,
            specifiers_fixed=specs,
            function_rewritten=rewrite_fn,
        ))

        if rewrite_fn:
            # DATE_FORMAT(expr, fmt) → STRFTIME(CAST(expr AS TIMESTAMP), fmt)
            # `first_arg` ends with a comma — peel it off, wrap in CAST,
            # then re-attach.
            expr = first_arg.rstrip(",").strip()
            new_first = f"CAST({expr} AS TIMESTAMP),"
            return f"STRFTIME({new_first} '{repaired_fmt}')"

        # Same function — just replace the format literal.
        return f"{fn_orig}({first_arg} '{repaired_fmt}')"

    repaired_sql = _STR_TIME_CALL.sub(_sub, sql)
    if fixes:
        logger.info(
            "duckdb_format_normaliser: %d auto-fix(es) applied (%s)",
            len(fixes), ", ".join(f.describe() for f in fixes),
        )
    return repaired_sql, fixes


# ---------------------------------------------------------------------------
# BF-572: Joda-Time pattern → strftime conversion
# ---------------------------------------------------------------------------
# Trino/Starburst ``format_datetime``/``parse_datetime`` use Joda-Time
# letter patterns (``yyyy-MM-dd HH:mm:ss.SSS``) — a totally different
# syntax from MySQL's ``%`` directives.  DuckDB doesn't have these
# functions at all, so we rewrite them to STRFTIME/STRPTIME with a
# converted format string.
#
# Joda pattern reference:
#   https://www.joda.org/joda-time/key_format.html
#
# Mapping table: (letter, {run_length: strftime_equivalent}).  Run length
# = how many of that letter the user wrote (``y`` vs ``yyyy``).  Lookup
# rule: exact match if present; otherwise the LARGEST table entry
# whose length ≤ requested length.  If no entry exists for the letter
# the run is emitted verbatim (best-effort fallback).
_JODA_LETTER_MAP: dict[str, dict[int, str]] = {
    # Year — yyyy/yy/y are the common cases.
    "y": {1: "%-y", 2: "%y", 4: "%Y"},
    "Y": {1: "%-y", 2: "%y", 4: "%G"},     # week-year ≈ ISO year
    "x": {4: "%G"},                         # weekyear
    # Month
    "M": {1: "%-m", 2: "%m", 3: "%b", 4: "%B"},
    # Day of month
    "d": {1: "%-d", 2: "%d"},
    # Day of year
    "D": {1: "%j", 2: "%j", 3: "%j"},
    # Day of week (text)
    "E": {1: "%a", 3: "%a", 4: "%A"},
    "e": {1: "%w"},                         # day of week (numeric, Mon=1)
    # Week of year
    "w": {1: "%-V", 2: "%V"},
    # Hour 0-23
    "H": {1: "%-H", 2: "%H"},
    # Hour 1-12 (clockhour)
    "h": {1: "%-I", 2: "%I"},
    # Hour 0-11 / 1-24 — approximations
    "K": {1: "%-I", 2: "%I"},
    "k": {1: "%-H", 2: "%H"},
    # Minute
    "m": {1: "%-M", 2: "%M"},
    # Second
    "s": {1: "%-S", 2: "%S"},
    # Sub-second fraction — Joda S is milliseconds (default 3 digits)
    # DuckDB ``%g`` = milliseconds (3 digits zero-padded);
    # ``%f`` = microseconds (6 digits).
    "S": {1: "%g", 2: "%g", 3: "%g", 6: "%f"},
    # AM/PM
    "a": {1: "%p"},
    # Time zone
    "z": {1: "%Z", 4: "%Z"},
    "Z": {1: "%z", 2: "%z", 4: "%z"},
    # Era — Joda G; strftime has no equivalent.  Leave un-mapped so the
    # caller can warn (we'll emit verbatim).
}


def _convert_joda_run(letter: str, length: int) -> str | None:
    table = _JODA_LETTER_MAP.get(letter)
    if not table:
        return None
    if length in table:
        return table[length]
    best_key: int | None = None
    for k in table:
        if k <= length and (best_key is None or k > best_key):
            best_key = k
    if best_key is not None:
        return table[best_key]
    # Fallback: smallest key
    return table[min(table.keys())]


def _consume_joda_literal(pattern: str, i: int, n: int) -> tuple[str, int]:
    """Consume the quoted literal at *i*; returns (emitted_text, next_index).

    ``''`` is an escaped single quote; otherwise everything up to the
    matching close quote is literal text.
    """
    if i + 1 < n and pattern[i + 1] == "'":
        # Escaped single quote — emit literal '
        return "'", i + 2
    # Find matching close quote.
    j = i + 1
    while j < n and pattern[j] != "'":
        j += 1
    literal = pattern[i + 1:j]
    # strftime literal text needs % escaped to %%.
    return literal.replace("%", "%%"), (j + 1 if j < n else n)


def _consume_joda_letter_run(
    pattern: str, i: int, n: int,
) -> tuple[str, int, str | None]:
    """Consume the run of one repeated pattern letter starting at *i*.

    Returns ``(emitted_text, next_index, converted_run)``.  The third
    element is the run text when it mapped to a real specifier and
    ``None`` when the letter is unknown — an unknown letter passes
    verbatim, which is the safest fail-open.
    """
    ch = pattern[i]
    j = i
    while j < n and pattern[j] == ch:
        j += 1
    run = pattern[i:j]
    converted = _convert_joda_run(ch, len(run))
    if converted is None:
        # Unknown letter — pass verbatim (will likely render
        # literally on DuckDB which is the safest fail-open).
        return run, j, None
    return converted, j, run


def _record_joda_run(run: str, runs: list[str], seen: set[str]) -> None:
    """Remember *run* as converted, once, in first-seen order."""
    if run not in seen:
        runs.append(run)
        seen.add(run)


def joda_to_strftime(joda_pattern: str) -> tuple[str, list[str]]:
    """Convert a Joda-Time format pattern to a DuckDB strftime format.

    Returns ``(strftime_pattern, [joda_runs_converted])``.  Single-quote
    sections are treated as literal text (Joda convention); ``''``
    represents a literal single quote.  Any ``%`` inside literal text
    is escaped to ``%%`` so strftime sees it as a literal percent.
    Unknown pattern letters pass through verbatim — best-effort.
    """
    out: list[str] = []
    runs: list[str] = []
    seen: set[str] = set()
    i = 0
    n = len(joda_pattern)
    while i < n:
        ch = joda_pattern[i]
        # Joda literal escape: '…' or '' (escaped single quote)
        if ch == "'":
            text, i = _consume_joda_literal(joda_pattern, i, n)
            out.append(text)
            continue
        # Letter run = a Joda pattern token.
        if ch.isalpha():
            text, i, run = _consume_joda_letter_run(joda_pattern, i, n)
            out.append(text)
            if run is not None:
                _record_joda_run(run, runs, seen)
            continue
        # Non-letter, non-quote — literal.  Escape stray %.
        if ch == "%":
            out.append("%%")
        else:
            out.append(ch)
        i += 1
    return "".join(out), runs


# ---------------------------------------------------------------------------
# BF-572: format_datetime / parse_datetime / to_iso8601 rewriter
# ---------------------------------------------------------------------------
_JODA_CALL = re.compile(
    r"""
    \b(FORMAT_DATETIME|PARSE_DATETIME)    # 1: function name
    \s*\(                                  # opening paren
    (                                      # 2: first arg + comma
        (?:
            [^'(),]
            | '(?:[^']|'')*'
            | \( (?: [^()] | \( [^()]* \) )* \)
        )+?
        ,
    )
    \s*
    '((?:[^'\\]|\\.|'')*)'                 # 3: quoted Joda format string
    \s*\)                                  # closing paren
    """,
    re.IGNORECASE | re.VERBOSE,
)


# to_iso8601(x) is a Trino built-in returning the ISO 8601 string.
# DuckDB has no equivalent function, so rewrite to STRFTIME with a
# canonical ISO format including milliseconds (Joda default).
_TO_ISO8601_CALL = re.compile(
    r"""
    \bTO_ISO8601\s*\(
    (                                      # 1: single arg
        (?:
            [^'(),]
            | '(?:[^']|'')*'
            | \( (?: [^()] | \( [^()]* \) )* \)
        )+?
    )
    \)
    """,
    re.IGNORECASE | re.VERBOSE,
)


def _normalise_joda_calls(sql: str) -> tuple[str, list[FormatFix]]:
    """Rewrite format_datetime / parse_datetime / to_iso8601 calls."""
    fixes: list[FormatFix] = []
    if not sql:
        return sql, fixes

    fast_check = sql.upper()
    if (
        "FORMAT_DATETIME" not in fast_check
        and "PARSE_DATETIME" not in fast_check
        and "TO_ISO8601" not in fast_check
    ):
        return sql, fixes

    _ranges = _STRING_RANGES_HOLDER.get()

    def _sub_joda(match: re.Match) -> str:
        # BF-571 audit fix: skip matches that start inside a SQL
        # string literal — they're user data, not function calls.
        if _ranges and _inside_string_literal(match.start(), _ranges):
            return match.group(0)
        fn_orig = match.group(1)
        fn_upper = fn_orig.upper()
        first_arg = match.group(2)  # includes trailing comma
        joda_fmt_raw = match.group(3)
        # SQL un-escape: ``''`` inside the captured literal text
        # represents a single ``'``.  Joda also uses ``''`` as the
        # escape for a literal quote, but the un-escaping happens at
        # the *SQL* layer when DuckDB reads the literal — so we have
        # to apply the same un-escape here to match the semantic
        # string the user intended.  Without this, a pattern like
        # ``'yyyy-MM-dd''T''HH:mm:ss'`` would have its literal-T
        # block double-escaped and render as ``2026-05-29'T'14:35:07``.
        joda_fmt = joda_fmt_raw.replace("''", "'")
        strftime_fmt, runs = joda_to_strftime(joda_fmt)

        fixes.append(FormatFix(
            function=fn_upper,
            original_format=joda_fmt_raw,
            repaired_format=strftime_fmt,
            specifiers_fixed=runs,
            function_rewritten=True,
        ))

        # SQL-escape single quotes in the converted format string —
        # Joda literal text (e.g. ``'T'``) becomes raw ``T`` in our
        # output, and we wrap the whole thing in single quotes for
        # SQL.  Any stray ``'`` in the converted string must be
        # doubled (``''``) so the SQL literal stays balanced.
        sql_safe_fmt = strftime_fmt.replace("'", "''")
        if fn_upper == "FORMAT_DATETIME":
            # format_datetime(expr, joda) → STRFTIME(CAST(expr AS TIMESTAMP), strftime)
            expr = first_arg.rstrip(",").strip()
            return f"STRFTIME(CAST({expr} AS TIMESTAMP), '{sql_safe_fmt}')"
        # parse_datetime(text, joda) → STRPTIME(text, strftime)
        text_arg = first_arg.rstrip(",").strip()
        return f"STRPTIME({text_arg}, '{sql_safe_fmt}')"

    out = _JODA_CALL.sub(_sub_joda, sql)

    def _sub_iso(match: re.Match) -> str:
        # BF-571 audit fix: skip matches that start inside a SQL
        # string literal.  TO_ISO8601 is the highest-risk false
        # positive because it has no format-string anchor to
        # distinguish a real call from data.
        if _ranges and _inside_string_literal(match.start(), _ranges):
            return match.group(0)
        expr = match.group(1).strip()
        # Canonical ISO 8601 with millisecond precision (matches Joda
        # default for to_iso8601).  ``%g`` is DuckDB's millisecond
        # specifier.
        fixes.append(FormatFix(
            function="TO_ISO8601",
            original_format="",
            repaired_format="%Y-%m-%dT%H:%M:%S.%gZ",
            specifiers_fixed=["to_iso8601"],
            function_rewritten=True,
        ))
        return f"STRFTIME(CAST({expr} AS TIMESTAMP), '%Y-%m-%dT%H:%M:%S.%gZ')"

    out = _TO_ISO8601_CALL.sub(_sub_iso, out)
    return out, fixes


# ---------------------------------------------------------------------------
# Combine the two rewriter passes so callers stay on one entry point.
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# String-literal range tracker — protects against false-positive matches
# inside user string literals (e.g. ``SELECT 'TO_ISO8601(d)' AS lit``).
# We compute the [start, end) ranges of every SQL string literal once,
# then in each rewriter callback skip matches whose start position falls
# inside any such range.  This preserves the rewriters' ability to see
# the actual format-string argument while ignoring lookalike text
# inside user data.
# ---------------------------------------------------------------------------
_SQL_STRING_LIT = re.compile(r"'(?:[^']|'')*'")


def _string_literal_ranges(sql: str) -> list[tuple[int, int]]:
    """Return a sorted list of (start, end) for every single-quoted SQL
    string literal in *sql*.  Used to reject regex matches that fall
    INSIDE a literal — those would corrupt user data."""
    return [(m.start(), m.end()) for m in _SQL_STRING_LIT.finditer(sql)]


def _inside_string_literal(pos: int, ranges: list[tuple[int, int]]) -> bool:
    """True iff *pos* falls inside any [start, end) range."""
    for s, e in ranges:
        if s <= pos < e:
            return True
        if s > pos:
            break  # ranges are sorted
    return False


def normalise_strftime_formats(sql: str) -> tuple[str, list[FormatFix]]:
    """Full normaliser — handles MySQL ``DATE_FORMAT``/strftime + Trino
    Joda ``format_datetime``/``parse_datetime``/``to_iso8601`` in one
    pass.  Returns ``(repaired_sql, [fixes])``.

    String-literal collision avoidance: every match whose START
    position falls inside a SQL string literal of the ORIGINAL SQL
    is skipped, so ``SELECT 'DATE_FORMAT(d, ''%i'')' FROM t`` is
    untouched.  This is computed against the input once before the
    rewriters run — pass-1's rewrite doesn't shift offsets that
    matter for pass-2 because the masked regions never contain
    rewriteable calls (we just verified).
    """
    if not sql:
        return sql, []
    # Snapshot string-literal ranges of the INPUT SQL.  Pass these
    # to both rewriters via a module-level holder (cheaper than
    # threading through call args).
    ranges = _string_literal_ranges(sql)
    _STRING_RANGES_HOLDER.set(ranges)
    try:
        sql_step1, fixes1 = _normalise_strftime_formats_inner(sql)
        # After pass 1 the SQL may have grown/shrunk.  Recompute
        # ranges for pass 2 so the joda rewriter has the right map.
        ranges2 = _string_literal_ranges(sql_step1)
        _STRING_RANGES_HOLDER.set(ranges2)
        sql_step2, fixes2 = _normalise_joda_calls(sql_step1)
    finally:
        _STRING_RANGES_HOLDER.set([])
    return sql_step2, fixes1 + fixes2


# Module-level holder for string-literal ranges.  Set by
# ``normalise_strftime_formats`` before each pass; consulted by the
# rewriters' _sub callbacks.  Single-threaded inside one normaliser
# call so no contention concern.
class _RangesHolder:
    __slots__ = ("ranges",)

    def __init__(self) -> None:
        self.ranges: list[tuple[int, int]] = []

    def set(self, ranges: list[tuple[int, int]]) -> None:
        self.ranges = ranges

    def get(self) -> list[tuple[int, int]]:
        return self.ranges


_STRING_RANGES_HOLDER = _RangesHolder()


def normalise_many(sqls: Iterable[str]) -> list[tuple[str, list[FormatFix]]]:
    """Convenience wrapper — apply normaliser to a sequence of statements."""
    return [normalise_strftime_formats(s) for s in sqls]
