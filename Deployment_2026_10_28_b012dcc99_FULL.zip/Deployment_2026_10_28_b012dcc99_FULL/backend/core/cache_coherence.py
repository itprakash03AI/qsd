"""Cross-pod cache-invalidation bus over the SHARED Postgres
``system_settings`` table (2026-08-02).

WHY
---
Process-local TTL caches made the same query return different answers
depending on which pod the load balancer picked (stale Iceberg snapshot
pointer; connection/credential edits invalidating only ONE pod's caches).
The fleet needs an invalidation channel, and the ONLY infrastructure every
deployment already shares is Postgres — Redis exists in ``cache_layer``'s
``RedisBroadcastCache`` but is optional and unwired.  This module is the
no-new-infrastructure channel; Redis remains an optional accelerator.

HOW
---
One ``system_settings`` row per namespace::

    key   = "cachesync.epoch.<namespace>"        (< 128 chars)
    value = {"token": "<uuid>", "ts": <wall>, "reason": "..."}

* ``bump(namespace)`` — a pod performed an invalidation: write a fresh
  token (last-write-wins; ``set_system_setting`` is already race-safe
  across pods).
* ``current_token(namespace)`` — throttled read (default: at most one
  single-row PK SELECT per ``cache.coherence_poll_seconds`` — default 5 s —
  per namespace per pod).  Consumers compare the token against the one
  they last observed; a change means "a peer invalidated: drop local
  state".

The ``cachesync.`` prefix deliberately does NOT collide with the
``iceberg_`` prefix polled by ``system_settings_version()`` in
``iceberg_manifest_watcher`` / ``iceberg_db_first_reader``, so epoch
writes never trigger those reload paths.

FAILURE POLICY (fail-open, never breaks queries)
------------------------------------------------
* ``bump`` failure → WARNING log, returns None.  Peers then converge via
  their pre-existing TTLs — exactly today's behaviour.
* read failure → keep serving the last-observed token (DEBUG log) and
  respect the poll throttle so a DB outage cannot become a retry storm.
* no DB wired (unit harness / early boot / N=1 without Postgres) → all
  calls are cheap no-ops returning None.

N=1: a single pod both bumps and observes its own token; consumers that
performed the invalidation self-acknowledge the returned token so they do
not re-clear what they just surgically invalidated.
"""
from __future__ import annotations

import logging
import threading
import time
import uuid
from typing import Any, Callable, Dict, Optional

logger = logging.getLogger(__name__)

_KEY_PREFIX = "cachesync.epoch."


def _default_db_getter() -> Any:
    """Find the app's DatabaseManager via the globals main.py already wires
    at startup — no new wiring required.  Returns None when unavailable
    (unit harness / early boot), which makes the whole bus a no-op."""
    try:
        from core import config as _cfg
        dbm = getattr(_cfg, "_db_manager_ref", None)
        if dbm is not None:
            return dbm
    except Exception as exc:                                  # pragma: no cover
        logger.debug("cache_coherence: config db ref lookup failed: %s", exc)
    try:
        from core import iceberg_snapshot_cache as _isc
        return getattr(_isc, "_db_manager", None)
    except Exception as exc:                                  # pragma: no cover
        logger.debug("cache_coherence: isc db ref lookup failed: %s", exc)
        return None


def _config_poll_seconds() -> float:
    """cache.coherence_poll_seconds — how often (max) a pod re-reads each
    epoch row.  Clamped to >= 1 s so a config typo cannot hammer the DB."""
    try:
        from core.config import get as _cfg_get
        return max(1.0, float(_cfg_get("cache", "coherence_poll_seconds", 5) or 5))
    except Exception:
        return 5.0


class CoherenceBus:
    """Namespaced epoch tokens over the shared system_settings table.

    Instantiable so tests can simulate multiple pods (one bus per "pod",
    all sharing one fake settings DB).  Production uses the module
    singleton from :func:`get_bus`.
    """

    def __init__(
        self,
        db_getter: Optional[Callable[[], Any]] = None,
        poll_seconds: Optional[float] = None,
        mono_fn: Callable[[], float] = time.monotonic,
        wall_fn: Callable[[], float] = time.time,
    ):
        self._db_getter = db_getter or _default_db_getter
        self._poll_seconds = poll_seconds        # None → config-driven
        self._mono = mono_fn
        self._wall = wall_fn
        self._lock = threading.Lock()
        # ns → {"token": str|None, "ts": float|None, "checked_at": float}
        self._state: Dict[str, Dict[str, Any]] = {}

    # ── internals ─────────────────────────────────────────────────────

    def _poll(self) -> float:
        if self._poll_seconds is not None:
            return float(self._poll_seconds)
        return _config_poll_seconds()

    @staticmethod
    def _row_key(namespace: str) -> str:
        return f"{_KEY_PREFIX}{namespace}"[:128]

    def _refresh(self, namespace: str) -> Dict[str, Any]:
        """Return the (possibly cached) state for ``namespace``, reading the
        DB at most once per poll interval.  Fail-open: on any error the
        last-observed state is kept and the throttle window still applies."""
        now = self._mono()
        with self._lock:
            st = self._state.get(namespace)
            if st is not None and (now - st["checked_at"]) < self._poll():
                return st
        db = None
        try:
            db = self._db_getter()
        except Exception as exc:
            logger.debug("cache_coherence: db getter failed for ns=%s: %s",
                         namespace, exc)
        token: Optional[str] = None
        ts: Optional[float] = None
        read_ok = False
        if db is not None:
            try:
                val = db.get_system_setting(self._row_key(namespace), None)
                read_ok = True
                if isinstance(val, dict):
                    raw_token = val.get("token")
                    if raw_token:
                        token = str(raw_token)
                    raw_ts = val.get("ts")
                    if raw_ts is not None:
                        try:
                            ts = float(raw_ts)
                        except (TypeError, ValueError):
                            ts = None
            except Exception as exc:
                logger.debug(
                    "cache_coherence: epoch read failed for ns=%s "
                    "(keeping last-observed token, fail-open): %s",
                    namespace, exc)
        with self._lock:
            st = self._state.get(namespace)
            if read_ok or st is None:
                st = {"token": token if read_ok else (st or {}).get("token"),
                      "ts": ts if read_ok else (st or {}).get("ts"),
                      "checked_at": now}
            else:
                # read failed → keep last-observed values, stamp the check
                st = dict(st)
                st["checked_at"] = now
            self._state[namespace] = st
            return st

    # ── public API ────────────────────────────────────────────────────

    def bump(self, namespace: str, reason: str = "") -> Optional[str]:
        """Announce an invalidation for ``namespace`` fleet-wide.  Returns
        the new token on success (callers may self-acknowledge it), None on
        failure (fail-open: WARNING logged, local invalidation unaffected)."""
        db = None
        try:
            db = self._db_getter()
        except Exception as exc:
            logger.debug("cache_coherence: db getter failed on bump ns=%s: %s",
                         namespace, exc)
        if db is None:
            return None
        token = uuid.uuid4().hex
        ts = self._wall()
        try:
            db.set_system_setting(
                self._row_key(namespace),
                {"token": token, "ts": ts, "reason": str(reason)[:120]},
                updated_by="cache_coherence",
            )
        except Exception as exc:
            logger.warning(
                "cache_coherence: epoch bump FAILED for ns=%s (%s) — peer "
                "pods will converge via their TTLs instead: %s",
                namespace, reason or "no reason", exc)
            return None
        with self._lock:
            self._state[namespace] = {"token": token, "ts": ts,
                                      "checked_at": self._mono()}
        logger.info("cache_coherence: bumped ns=%s (%s)",
                    namespace, reason or "no reason")
        return token

    def current_token(self, namespace: str) -> Optional[str]:
        """Latest epoch token for ``namespace`` (throttled read), or None
        when no bump has ever happened / no DB is wired."""
        return self._refresh(namespace).get("token")

    def last_bump_wall(self, namespace: str) -> Optional[float]:
        """Wall-clock timestamp of the latest bump (throttled read)."""
        return self._refresh(namespace).get("ts")

    def reset(self) -> None:
        """Drop all locally-observed state (tests / admin clear)."""
        with self._lock:
            self._state.clear()


# ── module singleton ──────────────────────────────────────────────────

_bus: Optional[CoherenceBus] = None
_bus_lock = threading.Lock()


def get_bus() -> CoherenceBus:
    """Process-wide bus singleton (lazily created; safe pre-boot because
    the default db_getter simply returns None until main.py wires a
    DatabaseManager into core.config / iceberg_snapshot_cache)."""
    global _bus
    if _bus is None:
        with _bus_lock:
            if _bus is None:
                _bus = CoherenceBus()
    return _bus
