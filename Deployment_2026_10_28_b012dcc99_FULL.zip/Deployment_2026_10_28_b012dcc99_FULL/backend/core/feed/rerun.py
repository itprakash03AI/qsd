"""THE re-run of a feed run (2026-10-12).

One function puts a run back on the queue, whoever asks: an operator's Re-run
(api/feed_api.py), the re-run of only the failed side, and a RESTATEMENT --
a new upstream message for a delivered business date
(core/feed/restatement.py).  The queue worker (scheduler / feed-worker pod)
executes it, heartbeated, like any run; nothing here executes a feed.

The run row is the (feed, business date) task; every re-run is a new
EXECUTION of it, so the run date of each delivery is the date of its own
execution (``run_date_of``) and a file named ``..._{run_date}`` is named once
per day it was delivered.
"""
from __future__ import annotations

from datetime import date, datetime, timezone
from typing import Any, Mapping, Optional

TRIGGER_RERUN = "rerun"
TRIGGER_RESTATEMENT = "restatement"


def run_date_of(ts: Any = None) -> date:
    """THE run date: the UTC calendar date of ``ts`` (now when None) -- the
    same date the engine names a file's ``{run_date}`` with."""
    if ts is None:
        return datetime.now(timezone.utc).date()
    if isinstance(ts, str):
        ts = datetime.fromisoformat(ts.replace("Z", "+00:00"))
    if isinstance(ts, datetime):
        if ts.tzinfo is not None:
            ts = ts.astimezone(timezone.utc)
        return ts.date()
    return ts


def refusal(row: Mapping[str, Any], db: Any = None) -> Optional[str]:
    """Why this run cannot be re-queued, or None.  A RUNNING run would get a
    second execution beside the live one (two deliveries); a manual Run Now
    run is never claimed by the queue (manual_run_excluded) -- it is re-run
    with Run Now.  With ``db``: an EXECUTION of this feed and date still
    active refuses too -- the run row says failed / cancelled the moment a
    cancel is asked, while the execution takes seconds to stop; a re-run
    accepted in that window was overwritten by the stopping execution's
    final write and silently vanished (found live 2026-10-13)."""
    if str(row.get("status") or "").lower() == "running":
        return (f"feed_run {row.get('id')} is running -- re-queuing it would start a "
                f"second execution beside the live one.  Cancel it first, then re-run.")
    if db is not None and row.get("feed_config_id") is not None:
        active = db.get_active_feed_execution(int(row["feed_config_id"]))
        if active and str(active.get("business_date") or "") == str(row.get("business_date") or ""):
            return (f"the last attempt of feed_run {row.get('id')} ({active.get('execution_id')}) "
                    f"is still stopping -- re-run it in a few seconds, once it has stopped.")
    if str(row.get("run_type") or "").lower() in ("manual", "dry_run"):
        return (f"feed_run {row.get('id')} is a Run Now ({row.get('run_type')}); run the feed "
                f"again with Run Now -- the run queue never claims a manual run.")
    return None


def requeue(db: Any, row: Mapping[str, Any], *, actor: str, reason: str,
            backend: Optional[str] = None, reuse: Optional[dict] = None,
            triggered_by: str = TRIGGER_RERUN) -> dict:
    """The run goes back on the QUEUE -- pending, RUN, ``released_at`` now
    (so the queue lookback admits an old business date) and the requested
    lane in ``rerun_backend``.  It used to be executed INSIDE the API process
    as a background task while the row also read pending/RUN, so the queue
    worker could claim it too: two executions, two deliveries (found live: a
    40M-row re-run executed in qs-local-api).  ``reuse`` is set only by the
    re-run of the failed side; any other re-run reads every side."""
    return db.update_feed_run(int(row["id"]), {
        "status": "pending",
        "started_at": None,
        "completed_at": None,
        "error": None,
        "action_decision": "RUN",
        "action_reason": reason,
        "triggered_by": triggered_by,
        "triggered_by_user": actor,
        "retry_count": int(row.get("retry_count") or 0) + 1,
        "released_at": datetime.now(timezone.utc),
        "rerun_backend": backend,
        "rerun_reuse": reuse,
    })
