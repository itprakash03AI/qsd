"""Enterprise feed-generation framework — Phase 130.

See ``FEED_ENTERPRISE_PLAN.md`` at the repo root for the full design.

Public surface (each class lives in its own file — one responsibility
per module, no module-level singletons, dependency-injected
constructors so unit tests can pass mocks freely):

  - ``BusinessCalendar``         — business-day / holiday arithmetic
  - ``BusinessCalendarRepo``     — TTL-cached calendar lookup
  - ``FilenameRenderer``         — token language for FILE_NAME / CTL_FILE_NAME
  - ``ControlFileWriter``        — sidecar .ctl manifest writer
  - ``ControlFileRecord``        — typed input record
  - ``ActionConditionEvaluator`` — runs SQL CASE to decide RUN vs SKIP
  - ``ActionDecision``           — typed result
  - ``AirflowClient``            — REST wrapper for Airflow 2.x stable API
  - ``DagRunInfo`` / ``TaskInstanceInfo`` — typed Airflow result objects
  - ``CompressionFormat``        — supported codecs
  - ``CompressionWriter``        — gzip / bzip2 / zstd / snappy

Activation flags (all default false — production behaviour
unchanged until admin opts in):
  - feed_generation.sod_enabled
  - feed_generation.sla_tracker_enabled
  - feed_generation.allow_external_triggers
"""
from __future__ import annotations

from .calendar import BusinessCalendar, BusinessCalendarRepo
from .filename_renderer import FilenameRenderer, RenderContext
from .compression import CompressionFormat, CompressionWriter, CompressionResult
from .control_file import ControlFileRecord, ControlFileWriter, ControlFormatSpec
from .control_format_repo import ControlFormatRepo
from .checksum import (
    compute_file_checksum,
    compute_all as compute_checksums_all,
    normalise_algorithm,
    SUPPORTED_ALGORITHMS,
    UnknownChecksumAlgorithm,
)
from .action_condition import ActionConditionEvaluator, ActionDecision
from .airflow_client import (
    AirflowClient,
    DagInfo,
    DagRunInfo,
    TaskInstanceInfo,
    build_default_client_from_config,
)
from .sod_generator import SodTaskGenerator, SodResult
from .sla_tracker import SlaTracker, SlaSweepResult

__all__ = [
    "BusinessCalendar",
    "BusinessCalendarRepo",
    "FilenameRenderer",
    "RenderContext",
    "CompressionFormat",
    "CompressionWriter",
    "CompressionResult",
    "ControlFileRecord",
    "ControlFileWriter",
    "ControlFormatSpec",
    "ControlFormatRepo",
    "compute_file_checksum",
    "compute_checksums_all",
    "normalise_algorithm",
    "SUPPORTED_ALGORITHMS",
    "UnknownChecksumAlgorithm",
    "ActionConditionEvaluator",
    "ActionDecision",
    "AirflowClient",
    "DagInfo",
    "DagRunInfo",
    "TaskInstanceInfo",
    "build_default_client_from_config",
    "SodTaskGenerator",
    "SodResult",
    "SlaTracker",
    "SlaSweepResult",
]
