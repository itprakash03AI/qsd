"""Checksum helpers — Phase 130 hotfix-4.

Single responsibility: compute file checksums in any of the algorithms
enterprise downstreams use.  Algorithm selection is DB-driven via
``feed_control_file_formats.checksum_algorithm`` — never hardcoded in
Python.

Supported algorithms:
  - ``md5``    — FIPS-safe (uses ``usedforsecurity=False`` so OpenShift
                 FIPS mode doesn't reject it; output is byte-for-byte
                 identical to standard MD5 for non-FIPS environments)
  - ``sha1``   — also FIPS-safe via the same flag
  - ``sha256`` — default; cryptographically strong, always available
  - ``sha512`` — same family, larger digest
  - ``crc32``  — fast 32-bit; for cheap sanity check, not security

Caller passes the algorithm name as a string (matches the DB column);
``UnknownChecksumAlgorithm`` raised on typos so a misconfigured format
row fails loud rather than silently shipping the wrong digest.

The module is stateless — no caching, no defaults.  Callers
(``ControlFileWriter``) choose what to compute based on the format
spec they were constructed with.
"""
from __future__ import annotations

import hashlib
import os
import zlib
from typing import Iterable

# Algorithms we recognise.  Keys are the lowercase strings stored in
# ``feed_control_file_formats.checksum_algorithm``.  Adding a new
# algorithm is one entry here + (for hashlib variants) one branch in
# ``_streaming_hexdigest``.
SUPPORTED_ALGORITHMS = ("md5", "sha1", "sha256", "sha512", "crc32")

_HASHLIB_ALGORITHMS = {"md5", "sha1", "sha256", "sha512"}


class UnknownChecksumAlgorithm(ValueError):
    """Raised when a format row specifies an algorithm we don't support."""


def normalise_algorithm(name: str) -> str:
    """Lowercase + strip + alias-resolve the algorithm name."""
    if not name:
        return ""
    n = name.strip().lower()
    # Common aliases — accept them so admins typing "MD-5" or "SHA-256"
    # in the UI don't silently break a feed.
    n = n.replace("-", "").replace("_", "")
    aliases = {
        "sha2": "sha256",
        "sha256bit": "sha256",
        "sha512bit": "sha512",
    }
    n = aliases.get(n, n)
    if n not in SUPPORTED_ALGORITHMS:
        raise UnknownChecksumAlgorithm(
            f"Unknown checksum algorithm: {name!r}.  "
            f"Supported: {SUPPORTED_ALGORITHMS}"
        )
    return n


def compute_bytes_checksum(raw: bytes, algorithm: str) -> str:
    """Compute hex digest of an in-memory ``bytes`` blob.

    BF-515 (2026-05-28): added for DataFlow ChecksumStage which had its
    own hardcoded ``hashlib.new(algo, raw).hexdigest()`` path that
    silently rejected CRC32 (zlib-based, not hashlib).  Single helper
    keeps the FIPS-safe MD5/SHA1 + CRC32 logic in one place.
    """
    algo = normalise_algorithm(algorithm)
    if not isinstance(raw, (bytes, bytearray)):
        raise TypeError(
            f"compute_bytes_checksum requires bytes, got {type(raw).__name__}"
        )
    if algo == "crc32":
        return f"{zlib.crc32(raw) & 0xFFFFFFFF:08x}"
    h = _new_hasher(algo)
    h.update(raw)
    return h.hexdigest()


def compute_file_checksum(
    path: os.PathLike,
    algorithm: str,
    *,
    chunk_size: int = 1024 * 1024,
) -> str:
    """Stream a file through the named algorithm.  Returns hex digest.

    Default chunk size (1 MiB) matches the DuckDB httpfs chunk so we
    don't fight the OS page cache on big files.
    """
    algo = normalise_algorithm(algorithm)
    if algo == "crc32":
        return _streaming_crc32(path, chunk_size)
    return _streaming_hexdigest(path, algo, chunk_size)


def compute_all(
    path: os.PathLike,
    algorithms: Iterable[str],
    *,
    chunk_size: int = 1024 * 1024,
) -> dict:
    """Compute multiple algorithms in a single read pass.

    Use case: an enterprise CTL format wants both MD5 and SHA-256 for
    defence-in-depth.  Reading the file once and updating both hashers
    in parallel is much cheaper than two separate passes for big files.

    Returns ``{algo: hex_digest}``.  CRC32 piggy-backs on the same loop.
    """
    norm = [normalise_algorithm(a) for a in algorithms if a]
    if not norm:
        return {}

    hashers = {}
    for a in norm:
        if a in _HASHLIB_ALGORITHMS:
            hashers[a] = _new_hasher(a)
    want_crc = "crc32" in norm

    crc_val = _feed_hashers_from_file(path, hashers, want_crc, chunk_size)

    result = {a: h.hexdigest() for a, h in hashers.items()}
    if want_crc:
        result["crc32"] = f"{crc_val & 0xFFFFFFFF:08x}"
    return result


def _feed_hashers_from_file(
    path: os.PathLike,
    hashers: dict,
    want_crc: bool,
    chunk_size: int,
) -> int:
    """Read *path* once, updating every hasher in *hashers* as we go.

    Returns the running CRC32 accumulator, which is meaningless (and
    left at 0) unless *want_crc* — the caller decides whether to use it.
    """
    crc_val = 0
    with open(path, "rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            for h in hashers.values():
                h.update(chunk)
            if want_crc:
                crc_val = zlib.crc32(chunk, crc_val)
    return crc_val


# ── Internals ──────────────────────────────────────────────────────────


def _new_hasher(algo: str):
    """Construct a hashlib hasher with FIPS-safe defaults.

    For MD5 / SHA-1: pass ``usedforsecurity=False`` so OpenSSL FIPS mode
    treats the call as a checksum (legitimate non-crypto use) rather
    than rejecting it.  Output is byte-for-byte identical to standard
    MD5 / SHA-1; only the FIPS-policy check is bypassed.

    For SHA-256 / SHA-512: no flag needed (always allowed in FIPS).
    """
    # 2026-09-13 security-hotspot triage: the two `except TypeError`
    # <3.9 fallbacks were removed.  ``usedforsecurity`` has existed since
    # Python 3.9 and this repo runs 3.13/3.14, so they were unreachable --
    # and their comment ("if the cluster also has FIPS strict-mode this
    # will fail loudly") described a branch that can no longer be entered.
    # MD5/SHA-1 survive here because a DOWNSTREAM CONSUMER's sidecar
    # format demands them (``algo`` is feed configuration, not our choice
    # of security primitive); they are interop checksums against
    # accidental corruption, never an authenticity check, and nothing in
    # QueryStudio trusts a file because its md5 matched.
    if algo == "md5":
        return hashlib.md5(usedforsecurity=False)
    if algo == "sha1":
        return hashlib.sha1(usedforsecurity=False)
    if algo == "sha256":
        return hashlib.sha256()
    if algo == "sha512":
        return hashlib.sha512()
    raise UnknownChecksumAlgorithm(algo)


def _streaming_hexdigest(path: os.PathLike, algo: str, chunk_size: int) -> str:
    h = _new_hasher(algo)
    with open(path, "rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _streaming_crc32(path: os.PathLike, chunk_size: int) -> str:
    """8-char lowercase hex (zero-padded) — matches the enterprise
    convention used by zip / gzip headers."""
    val = 0
    with open(path, "rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            val = zlib.crc32(chunk, val)
    return f"{val & 0xFFFFFFFF:08x}"
