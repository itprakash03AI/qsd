"""Deployment windows — "do not START runs during the change window"
(BRD FR-OPS-04) — 2026-09-03.

Semantics, decided and stated (not implied):

* A window blocks **STARTING** a run — manual execute, external trigger,
  rerun, bulk-rerun, retry, backfill.  It NEVER touches a run in
  flight: killing a run mid-SFTP is hazard H1, and the cancel endpoint
  stays available for a human who decides a specific run must die.
* Scope is **global, per feed-group, or per feed** — a change window is
  usually an environment-wide event (global), but a counterparty-side
  change affects one group or one feed; all three are real, so all
  three are expressible.  A feed is blocked by ANY matching active
  window.
* The refusal is **visible**: it 409s with the window named (id, scope,
  reason, when it ends, who declared it) and what to do instead; every
  refusal is recorded on the window itself (advisory tail, capped) and
  the run surface renders active/upcoming windows as a section — a
  silent non-start at 03:00 is indistinguishable from a broken
  scheduler, which is the defect class this whole feature avoids.
* Admins may override per-call (``?override_deployment_window=true``),
  audited — a window must not be able to hold the platform hostage
  during an incident.

Storage: ONE system_settings key (``feed_ops.deployment_windows``)
holding the list — windows are few, short-lived, and admin-managed;
a list under one key keeps create/delete atomic per operation.

Enforcement points live in api/feed_api.py and api/feed_ops_api.py.
The SCHEDULED path (core/feed_engine.run_scheduled_feed / queue worker)
is owned by another workstream — until it calls
``blocking_window_for_feed`` before starting, cron-fired runs are NOT
gated; that anchor is reported, not silently assumed.
"""
from __future__ import annotations

import logging
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

logger = logging.getLogger(__name__)

STORE_KEY = "feed_ops.deployment_windows"
SCOPES = ("global", "group", "feed")
#: Advisory refusal tail kept on each window (visibility, not audit —
#: the audit log carries the authoritative record).
_REFUSAL_TAIL = 20


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _parse_ts(raw: Any, field: str) -> datetime:
    try:
        ts = datetime.fromisoformat(str(raw))
    except (TypeError, ValueError):
        raise ValueError(
            f"{field} {raw!r} is not an ISO datetime "
            f"(e.g. 2026-09-06T22:00:00+00:00)")
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=timezone.utc)
    return ts


def list_windows(db: Any) -> list:
    store = db.get_system_setting(STORE_KEY, None)
    if isinstance(store, dict) and isinstance(store.get("windows"), list):
        return list(store["windows"])
    return []


def _save(db: Any, windows: list, updated_by: Optional[str]) -> None:
    db.set_system_setting(
        STORE_KEY, {"windows": windows}, updated_by=updated_by,
        description="deployment windows (FR-OPS-04): do not START feed "
                    "runs while a matching window is active")


def create_window(db: Any, *, scope: str, scope_id: Optional[int],
                  starts_at: Any, ends_at: Any, reason: str,
                  created_by: str) -> dict:
    """Validate + append one window.  Raises ValueError with the fix
    named on every refusal."""
    if scope not in SCOPES:
        raise ValueError(f"scope must be one of {SCOPES} (got {scope!r})")
    if scope == "global":
        scope_id = None
    else:
        if scope_id is None:
            raise ValueError(
                f"scope={scope!r} needs scope_id — the "
                f"{'feed_group' if scope == 'group' else 'feed'} id the "
                f"window applies to")
        scope_id = int(scope_id)
    start = _parse_ts(starts_at, "starts_at")
    end = _parse_ts(ends_at, "ends_at")
    if end <= start:
        raise ValueError(
            f"ends_at ({end.isoformat()}) must be after starts_at "
            f"({start.isoformat()}) — a zero/negative window blocks "
            f"nothing and would only mislead")
    if end <= _now():
        raise ValueError(
            f"ends_at ({end.isoformat()}) is already in the past — a "
            f"window that can never block anything is a config mistake, "
            f"refused rather than stored")
    if not str(reason or "").strip():
        raise ValueError(
            "reason is required: at 03:00 the refusal names this reason "
            "to the operator whose run did not start")
    win = {
        "id": uuid.uuid4().hex[:12],
        "scope": scope,
        "scope_id": scope_id,
        "starts_at": start.isoformat(),
        "ends_at": end.isoformat(),
        "reason": str(reason).strip(),
        "created_by": created_by,
        "created_at": _now().isoformat(),
        "refusals": [],
    }
    windows = list_windows(db)
    windows.append(win)
    _save(db, windows, created_by)
    return win


def delete_window(db: Any, window_id: str, deleted_by: str) -> bool:
    windows = list_windows(db)
    kept = [w for w in windows if str(w.get("id")) != str(window_id)]
    if len(kept) == len(windows):
        return False
    _save(db, kept, deleted_by)
    try:
        db.delete_system_setting(_refusal_key(window_id))
    except Exception:
        logger.debug("[deployment_window] refusal tail for %s not "
                     "removed", window_id, exc_info=True)
    return True


def _matches(win: dict, feed: dict) -> bool:
    scope = win.get("scope")
    if scope == "global":
        return True
    if scope == "group":
        gid = feed.get("feed_group_id")
        return gid is not None and int(gid) == int(win.get("scope_id") or -1)
    if scope == "feed":
        return int(feed.get("id") or -1) == int(win.get("scope_id") or -2)
    return False


def _active(win: dict, now: datetime) -> bool:
    try:
        return (_parse_ts(win.get("starts_at"), "starts_at") <= now
                < _parse_ts(win.get("ends_at"), "ends_at"))
    except ValueError:
        # A malformed stored window: treat as ACTIVE-for-matching?  No —
        # it cannot say when it ends, so it would block forever.  Log
        # loudly, do not block on garbage.
        logger.error("[deployment_window] window %s has unparseable "
                     "bounds — ignored: %r", win.get("id"), win)
        return False


def blocking_window_for_feed(db: Any, feed: dict,
                             now: Optional[datetime] = None
                             ) -> Optional[dict]:
    """The first active window matching this feed, or None.

    RAISES on a store read error — it never folds "could not read the
    windows" into "no window"; the two are opposite findings.  What a
    caller does with the raise is a POSTURE decision made at the call
    site: the run-START gates fail OPEN and audible (an unreadable
    settings row must not stop the estate at 03:00 — the run proceeds,
    the non-enforcement is ERROR-logged and audited), while the
    run-surface SECTION renders the failure as ``unavailable`` because
    a screen must never display a read failure as "no windows".
    """
    ts = now or _now()
    for win in list_windows(db):
        if _active(win, ts) and _matches(win, feed):
            return win
    return None


def _refusal_key(window_id: str) -> str:
    return f"{STORE_KEY}.refusals.{window_id}"


def record_refusal(db: Any, window_id: str, *, feed_id: int,
                   actor: str, action: str) -> None:
    """Advisory refusal tail, stored under the window's OWN key.

    Deliberately NOT written into the windows list: rewriting that list
    here would race an admin's concurrent create — a lost-update there
    silently DELETES a window, which is a change window not enforced.
    The list is written only by create/delete; this key's own
    last-write-wins can at worst drop one tail entry, which costs a
    dashboard line, never correctness — the audit log is authoritative.
    """
    try:
        key = _refusal_key(window_id)
        tail = db.get_system_setting(key, None)
        tail = list(tail) if isinstance(tail, list) else []
        tail.append({"at": _now().isoformat(), "feed_id": feed_id,
                     "actor": actor, "action": action})
        db.set_system_setting(
            key, tail[-_REFUSAL_TAIL:], updated_by=actor,
            description=f"refusals under deployment window {window_id}")
    except Exception:
        logger.warning("[deployment_window] could not record refusal on "
                       "window %s", window_id, exc_info=True)


def refusals_for(db: Any, window_id: str) -> list:
    try:
        tail = db.get_system_setting(_refusal_key(window_id), None)
        return list(tail) if isinstance(tail, list) else []
    except Exception:
        return []


def surface_rows(db: Any, now: Optional[datetime] = None,
                 lookahead_hours: int = 24) -> list:
    """Run-surface rows: ACTIVE windows plus those starting within the
    lookahead.  Raises on a store read failure so the section renders
    ``unavailable`` — an empty list must genuinely mean 'no windows'."""
    ts = now or _now()
    horizon = ts + timedelta(hours=lookahead_hours)
    rows: list = []
    for win in list_windows(db):
        try:
            start = _parse_ts(win.get("starts_at"), "starts_at")
            end = _parse_ts(win.get("ends_at"), "ends_at")
        except ValueError:
            rows.append({**win, "status": "malformed"})
            continue
        if end <= ts:
            continue
        status = "active" if start <= ts else (
            "upcoming" if start <= horizon else None)
        if status:
            rows.append({
                "id": win.get("id"), "scope": win.get("scope"),
                "scope_id": win.get("scope_id"),
                "starts_at": win.get("starts_at"),
                "ends_at": win.get("ends_at"),
                "reason": win.get("reason"),
                "created_by": win.get("created_by"),
                "status": status,
                "recent_refusals": refusals_for(db, win.get("id"))[-5:],
            })
    return rows


def refusal_detail(win: dict, *, feed: dict) -> str:
    """The 409 body — names the window and what to do instead."""
    scope = win.get("scope")
    scope_txt = ("platform-wide" if scope == "global" else
                 f"feed group {win.get('scope_id')}" if scope == "group"
                 else f"this feed ({win.get('scope_id')})")
    return (
        f"Deployment window {win.get('id')} is active ({scope_txt}) — "
        f"runs must not START until it ends at {win.get('ends_at')}: "
        f"{win.get('reason')} (declared by {win.get('created_by')}). "
        f"Runs already in flight are NOT touched.  What to do: wait for "
        f"the window to end; or an admin can pass "
        f"override_deployment_window=true on this call (audited), or "
        f"delete the window via "
        f"DELETE /api/admin/deployment-windows/{win.get('id')}.")
