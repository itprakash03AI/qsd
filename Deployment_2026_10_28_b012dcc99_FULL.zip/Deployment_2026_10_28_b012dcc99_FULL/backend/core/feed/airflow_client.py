"""AirflowClient — Phase 130/1b.

Stateless wrapper around the Airflow REST API.  One method per public
endpoint we use.  Both feed_engine and etl_engine will migrate to this
class (etl in a follow-up commit) so request/response handling lives
in one place.

Design principles (consistent with the rest of ``core/feed/``):
  - One class, one responsibility.
  - Dependency-injected — caller passes ``base_url`` + auth tuple,
    the class never reads config directly.  Tests can inject a fake
    transport for offline tests.
  - Frozen dataclasses for typed results.
  - Stateless — the only instance attribute is the precomputed
    ``Authorization`` header so we don't recompute base64 per call.

This class does NOT poll for completion — polling belongs to the
caller (because it owns the cancellation token, breaker integration,
WS broadcasts, etc.).  ``AirflowClient`` only knows how to trigger,
get-status, list, and inspect task instances.
"""
from __future__ import annotations

import base64
import json
import logging
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Mapping, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class DagRunInfo:
    """Typed view of an Airflow DAG-run record (subset we care about)."""
    dag_id: str
    dag_run_id: str
    state: str            # 'queued' | 'running' | 'success' | 'failed' | ...
    execution_date: Optional[str]
    start_date: Optional[str]
    end_date: Optional[str]
    conf: Mapping[str, Any]
    raw: Mapping[str, Any]  # the full response dict for callers needing more

    @property
    def is_terminal(self) -> bool:
        return self.state in ("success", "failed", "upstream_failed",
                              "skipped", "upstream_skipped")


@dataclass(frozen=True)
class DagInfo:
    """Typed view of an Airflow DAG record (subset we expose to the UI).

    Returned by ``AirflowClient.list_dags()`` / ``get_dag()``.  Lets the
    admin UI show what DAGs exist, whether they're active, and let the
    operator trigger one ad-hoc without needing to open the Airflow UI.
    """
    dag_id: str
    description: Optional[str]
    is_paused: bool
    is_active: bool
    schedule_interval: Optional[str]
    tags: list
    raw: Mapping[str, Any]


@dataclass(frozen=True)
class TaskInstanceInfo:
    """Typed view of an Airflow task instance."""
    dag_id: str
    dag_run_id: str
    task_id: str
    state: str
    try_number: int
    raw: Mapping[str, Any]


AuthSpec = Tuple[str, Optional[str], Optional[str]]
"""(auth_type, username, password) — auth_type is 'basic' | 'none' | 'token'."""


class AirflowClient:
    """Thin REST client for Airflow 2.x stable API (``/api/v1``)."""

    def __init__(
        self,
        base_url: str,
        auth: AuthSpec,
        *,
        timeout_seconds: int = 60,
        transport: Optional[Callable[..., dict]] = None,
    ) -> None:
        if not base_url:
            raise ValueError("AirflowClient: base_url is required")
        self._base = base_url.rstrip("/")
        self._timeout = int(timeout_seconds)
        self._auth_header = self._build_auth_header(auth)
        # Lazy import so unit tests can run without urllib/network.
        if transport is None:
            from core.http_utils import http_request as _default_transport
            self._transport = _default_transport
        else:
            self._transport = transport

    # ── Public API ────────────────────────────────────────────────────

    def trigger_dag(
        self,
        dag_id: str,
        dag_run_id: str,
        conf: Mapping[str, Any],
    ) -> DagRunInfo:
        """POST ``/dags/{dag_id}/dagRuns`` — kick off a DAG run.

        Raises ``RuntimeError`` if Airflow rejects the trigger.
        """
        url = f"{self._base}/api/v1/dags/{dag_id}/dagRuns"
        payload = json.dumps(
            {"dag_run_id": dag_run_id, "conf": dict(conf)},
        ).encode("utf-8")
        resp = self._transport(
            url, "POST", payload, self._headers(json_body=True),
            timeout=self._timeout,
        )
        if "dag_run_id" not in resp:
            raise RuntimeError(
                f"Airflow trigger_dag({dag_id}, {dag_run_id}) failed: "
                f"response missing dag_run_id — {resp!r}"
            )
        return self._dag_run_from_response(dag_id, resp)

    def get_dag_run(self, dag_id: str, dag_run_id: str) -> DagRunInfo:
        """GET ``/dags/{dag_id}/dagRuns/{dag_run_id}`` — current state."""
        url = f"{self._base}/api/v1/dags/{dag_id}/dagRuns/{dag_run_id}"
        resp = self._transport(
            url, "GET", None, self._headers(json_body=False),
            timeout=self._timeout,
        )
        return self._dag_run_from_response(dag_id, resp)

    def set_dag_run_state(self, dag_id: str, dag_run_id: str,
                          state: str) -> DagRunInfo:
        """PATCH ``/dags/{dag_id}/dagRuns/{dag_run_id}`` -- mark a run
        ``failed`` (the engine's best-effort stop of a DAG run whose feed
        execution was cancelled before the DAG submitted anything,
        2026-10-08) or ``success`` / ``queued``.  Airflow 2.x accepts
        exactly those three states here."""
        if state not in ("failed", "success", "queued"):
            raise ValueError(
                f"Airflow dagRuns PATCH accepts failed/success/queued, "
                f"not {state!r}")
        url = f"{self._base}/api/v1/dags/{dag_id}/dagRuns/{dag_run_id}"
        payload = json.dumps({"state": state}).encode("utf-8")
        resp = self._transport(
            url, "PATCH", payload, self._headers(json_body=True),
            timeout=self._timeout,
        )
        return self._dag_run_from_response(dag_id, resp)

    def list_recent_runs(self, dag_id: str, limit: int = 20) -> List[DagRunInfo]:
        """GET ``/dags/{dag_id}/dagRuns?order_by=-execution_date&limit=N``."""
        if limit <= 0:
            raise ValueError("limit must be positive")
        url = (
            f"{self._base}/api/v1/dags/{dag_id}/dagRuns"
            f"?order_by=-execution_date&limit={int(limit)}"
        )
        resp = self._transport(
            url, "GET", None, self._headers(json_body=False),
            timeout=self._timeout,
        )
        runs = resp.get("dag_runs", []) or []
        return [self._dag_run_from_response(dag_id, r) for r in runs]

    def list_dags(
        self,
        *,
        tag: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
        only_active: bool = True,
    ) -> List[DagInfo]:
        """GET ``/dags`` — enumerate DAGs registered with the Airflow
        instance.  Used by the admin UI to populate a picker so
        operators can see which DAGs exist + pick one for ad-hoc
        triggers / inspection.

        ``tag`` filters by Airflow tag (e.g. ``"querystudio"`` to see
        only our auto-generated feed DAGs).  ``only_active`` excludes
        ``is_active=false`` DAGs (paused-or-removed DAGs that linger
        in the metadata DB).
        """
        if limit <= 0:
            raise ValueError("limit must be positive")
        qs: List[str] = [f"limit={int(limit)}", f"offset={int(offset)}"]
        if tag:
            qs.append(f"tags={tag}")
        if only_active:
            qs.append("only_active=true")
        url = f"{self._base}/api/v1/dags?{'&'.join(qs)}"
        resp = self._transport(
            url, "GET", None, self._headers(json_body=False),
            timeout=self._timeout,
        )
        dags = resp.get("dags", []) or []
        return [self._dag_from_response(d) for d in dags]

    def get_dag(self, dag_id: str) -> DagInfo:
        """GET ``/dags/{dag_id}`` — single-DAG details."""
        url = f"{self._base}/api/v1/dags/{dag_id}"
        resp = self._transport(
            url, "GET", None, self._headers(json_body=False),
            timeout=self._timeout,
        )
        return self._dag_from_response(resp)

    def get_task_instances(
        self, dag_id: str, dag_run_id: str,
    ) -> List[TaskInstanceInfo]:
        """GET ``/dags/{dag_id}/dagRuns/{dag_run_id}/taskInstances``."""
        url = (
            f"{self._base}/api/v1/dags/{dag_id}/dagRuns/{dag_run_id}"
            f"/taskInstances"
        )
        resp = self._transport(
            url, "GET", None, self._headers(json_body=False),
            timeout=self._timeout,
        )
        out: List[TaskInstanceInfo] = []
        for ti in resp.get("task_instances", []) or []:
            out.append(TaskInstanceInfo(
                dag_id=ti.get("dag_id", dag_id),
                dag_run_id=ti.get("dag_run_id", dag_run_id),
                task_id=ti.get("task_id", ""),
                state=ti.get("state") or "",
                try_number=int(ti.get("try_number", 0) or 0),
                raw=ti,
            ))
        return out

    # ── Internals ─────────────────────────────────────────────────────

    @staticmethod
    def _build_auth_header(auth: AuthSpec) -> Optional[str]:
        auth_type, username, password = auth
        kind = (auth_type or "none").lower()
        if kind == "basic":
            if not username:
                return None
            creds = f"{username}:{password or ''}".encode()
            return f"Basic {base64.b64encode(creds).decode()}"
        if kind in ("bearer", "token"):
            # password field carries the token in our config schema
            if not password:
                return None
            return f"Bearer {password}"
        return None  # 'none' or unknown → no Authorization header

    def _headers(self, json_body: bool) -> Dict[str, str]:
        h: Dict[str, str] = {"Accept": "application/json"}
        if json_body:
            h["Content-Type"] = "application/json"
        if self._auth_header:
            h["Authorization"] = self._auth_header
        return h

    @staticmethod
    def _dag_from_response(resp: Mapping[str, Any]) -> DagInfo:
        return DagInfo(
            dag_id=resp.get("dag_id", ""),
            description=resp.get("description"),
            is_paused=bool(resp.get("is_paused", False)),
            is_active=bool(resp.get("is_active", True)),
            schedule_interval=(
                resp.get("schedule_interval", {}).get("value")
                if isinstance(resp.get("schedule_interval"), dict)
                else resp.get("schedule_interval")
            ),
            tags=[t.get("name", t) if isinstance(t, dict) else t
                   for t in (resp.get("tags") or [])],
            raw=dict(resp),
        )

    @staticmethod
    def _dag_run_from_response(dag_id: str, resp: Mapping[str, Any]) -> DagRunInfo:
        return DagRunInfo(
            dag_id=resp.get("dag_id", dag_id),
            dag_run_id=resp.get("dag_run_id", ""),
            state=resp.get("state") or "",
            execution_date=resp.get("execution_date"),
            start_date=resp.get("start_date"),
            end_date=resp.get("end_date"),
            conf=resp.get("conf") or {},
            raw=dict(resp),
        )


def build_default_client_from_config(cfg) -> AirflowClient:
    """Convenience factory — builds an ``AirflowClient`` from the typed
    ``_FeedGenerationAirflowCfg`` accessor (or anything quack-compatible).

    The accessor MUST expose: ``base_url``, ``auth_type``, ``username``,
    ``password``, ``poll_timeout_seconds``.
    """
    return AirflowClient(
        base_url=str(cfg.base_url),
        auth=(str(cfg.auth_type or "none"),
              str(cfg.username or "") or None,
              str(cfg.password or "") or None),
        timeout_seconds=int(getattr(cfg, "poll_timeout_seconds", 60) or 60),
    )
