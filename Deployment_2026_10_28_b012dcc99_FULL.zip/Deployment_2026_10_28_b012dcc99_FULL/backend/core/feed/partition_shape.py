"""A feed's SHAPE — how its partition list is declared (BRD §2, §9.3).

One of the six properties a feed author supplies.  The declaration is
CONFIG-BASED, never discovered at runtime, and three properties of that choice
are deliberate (§9.3):

* **auditable** — the split for business date D can be shown, and shown again
  next year, because it was recorded rather than inferred;
* **overridable per run** — support can re-run one entity by narrowing the
  list, without editing the feed;
* **bounded** — ``max_parts`` turns a partition explosion into a loud refusal
  instead of 40,000 child rows at 2am.

Stored inside ``query_params`` under a reserved key rather than as a new
column, for the reason §14 gives: a new TABLE self-creates, a new COLUMN does
not — it needs a migration AND a verified deploy step, and until both land
every feed read raises "no such column".  ``query_params`` is an existing JSON
column that already carries reserved keys (the WHERE-clause mapping), so the
shape reaches every pod the moment the code does.

What this module does NOT do is decide.  The pruning subsystem can already
discover partitions; under a declared rule it may only PROPOSE — surfacing
"the source has 1,240 partitions for D, your config declares 1,180" as a
pre-flight warning.  Declared stays authoritative; drift becomes visible
instead of silent.  That is the difference between config-based and
config-blind.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Mapping, Optional

logger = logging.getLogger(__name__)

#: Reserved key inside ``query_params``.  Underscore-prefixed like the
#: WHERE-clause mapping, so a consumer override can never set it: an external
#: trigger must not be able to rewrite the publisher's declared shape.
SHAPE_KEY = "_partition"


class ShapeError(ValueError):
    """A declared shape that cannot be honoured.  Raised at AUTHORING and at
    admission — never mid-run, where a refusal costs a wasted extract."""


@dataclass(frozen=True)
class PartitionShape:
    """How a feed declares its partition list."""
    columns: tuple = ()
    values: tuple = ()              # literal identities, when declared inline
    values_sql: Optional[str] = None   # or the query that yields them
    max_parts: Optional[int] = None
    on_empty: str = "fail"
    #: Did the author declare a values SOURCE at all?  Distinct from
    #: whether that source yielded anything: a feed declaring
    #: ``values: []`` has DECLARED an empty list, which FR-CMP-04 says
    #: must be refused unless on_empty=skip.  Reading it as "no shape"
    #: would turn the one decision this section exists for back into a
    #: silent no-op.
    has_values_source: bool = False

    @property
    def declared(self) -> bool:
        return bool(self.values or self.values_sql
                    or self.has_values_source)

    def to_dict(self) -> dict:
        return {"columns": list(self.columns), "values": list(self.values),
                "values_sql": self.values_sql, "max_parts": self.max_parts,
                "on_empty": self.on_empty,
                "has_values_source": self.has_values_source}


def read_shape(feed_config: Mapping[str, Any]) -> Optional[PartitionShape]:
    """Parse the declared shape, or None when the feed declares none.

    A feed with no shape is a single-file feed — the overwhelming majority —
    and must stay exactly as it is.  Absence is not an error.
    """
    raw = (feed_config.get("query_params") or {}).get(SHAPE_KEY)
    if not raw:
        return None
    if not isinstance(raw, Mapping):
        raise ShapeError(
            f"{SHAPE_KEY} must be an object, got {type(raw).__name__} — a "
            f"malformed shape is refused rather than ignored, because an "
            f"ignored one silently produces a single file where the author "
            f"declared many")

    values = raw.get("values")
    values_sql = raw.get("values_sql") or raw.get("sql")
    if values is not None and not isinstance(values, (list, tuple)):
        raise ShapeError(
            f"{SHAPE_KEY}.values must be a list of identities, got "
            f"{type(values).__name__}")
    if values and values_sql:
        raise ShapeError(
            f"{SHAPE_KEY} declares BOTH values and values_sql — which one is "
            f"authoritative cannot be guessed, and guessing wrong silently "
            f"changes how many files the counterparty receives")

    max_parts = raw.get("max_parts")
    if max_parts is not None:
        try:
            max_parts = int(max_parts)
        except (TypeError, ValueError):
            raise ShapeError(
                f"{SHAPE_KEY}.max_parts must be an integer, got "
                f"{max_parts!r}")
        if max_parts <= 0:
            # Not a fold: 0 is refused rather than read as unlimited.  This
            # codebase has shipped 1M of 70M rows because a cap of 0 folded
            # into "no cap".
            raise ShapeError(
                f"{SHAPE_KEY}.max_parts={max_parts} is refused — 0 does NOT "
                f"mean unlimited.  Omit max_parts to leave the declaration "
                f"unbounded")

    on_empty = str(raw.get("on_empty") or "fail").strip().lower()
    if on_empty not in ("fail", "skip"):
        raise ShapeError(
            f"{SHAPE_KEY}.on_empty must be 'fail' or 'skip', got "
            f"{on_empty!r} — a typo must not become a new state")

    columns = raw.get("columns") or ()
    if isinstance(columns, str):
        columns = (columns,)
    return PartitionShape(
        columns=tuple(str(c) for c in columns),
        values=tuple(values or ()),
        values_sql=str(values_sql) if values_sql else None,
        max_parts=max_parts,
        on_empty=on_empty,
        has_values_source=("values" in raw or "values_sql" in raw
                           or "sql" in raw),
    )


def resolve_identities(shape: PartitionShape, *, run_sql=None) -> list:
    """The identities this run will produce a part for.

    ``run_sql`` is injected — this module never opens a connection.  When the
    shape declares SQL and no runner is supplied, that is an ERROR rather than
    an empty list: an empty list would flow into ``declare_partitions`` and
    either refuse (noisy but wrong) or, with ``on_empty=skip``, silently
    produce nothing at all.
    """
    if shape.values:
        return list(shape.values)
    if not shape.values_sql:
        return []
    if run_sql is None:
        raise ShapeError(
            "the shape declares values_sql but no SQL runner was supplied — "
            "refusing rather than treating an unresolvable declaration as an "
            "empty one, which with on_empty=skip would produce NOTHING and "
            "report success")
    rows = run_sql(shape.values_sql)
    out = []
    for row in rows or ():
        if isinstance(row, (list, tuple)):
            out.append(row[0] if row else None)
        elif isinstance(row, Mapping):
            out.append(next(iter(row.values()), None))
        else:
            out.append(row)
    return [v for v in out if v is not None]
