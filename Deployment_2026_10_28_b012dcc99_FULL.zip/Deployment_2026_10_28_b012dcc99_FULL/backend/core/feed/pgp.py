"""PGP seam — FR-ART-06 / FR-SEC-08 / FR-SEC-09 (BRD 2026-09-02 §10.2, §16.3).

Counterparty SFTP contracts routinely REQUIRE PGP.  Until 2026-09-03 the
platform's only honest move was refusal: nothing encrypted a delivered
file, and the validator said so.  This module is the single encryption
chokepoint — the artifact chain (spark lane) and ``pipeline.apply_encryption``
(native lane) both call it, so "encrypted" has exactly one spelling.

Design rules, each load-bearing:

* **A stated refusal, never a silent plaintext fallback.**  Modeled on
  ``netcool_sender.sender_refusal``: :func:`backend_refusal` names exactly
  what is missing, and :func:`encrypt_file` raises :class:`PgpUnavailable`
  carrying that reason.  There is NO code path from "encrypt this" to
  "here is the plaintext back" — a plaintext file delivered under a
  contract that says encrypted is the worst outcome in the feed platform.

* **The output is verified, not assumed.**  ``encrypt_file`` checks the
  produced bytes actually carry OpenPGP framing (armored header or a
  packet tag octet with the high bit set) and are not the input bytes.
  A backend that hands back the plaintext — or nothing — is a failure,
  not a delivery.  The guard tests the OUTPUT, not the call (2026-08-20:
  17 of 24 source guards could not fail because they tested spellings).

* **Key expiry is readable WITHOUT a backend** (FR-SEC-09).  The
  authoring preflight must run on every deployment, including one whose
  encryption backend is not installed yet — an expired key must be
  refused AT SAVE, not discovered at 03:00.  So :func:`inspect_public_key`
  is a self-contained RFC 4880 v4 packet parser (parsing needs no
  crypto): key creation time from the public-key packet, expiry from
  signature subpacket 9.  Anything it cannot parse with certainty is a
  :class:`PgpKeyError` — a key we cannot read is a refusal, not a shrug.

Backends probed, in order: ``pgpy`` (pure python), ``gnupg``
(python-gnupg wrapping the gpg binary).  Neither is a declared
dependency yet — the deployment that needs PGP installs one, and until
then every pgp contract term is refused at authoring with the reason.
"""
from __future__ import annotations

import base64
import binascii
import logging
import struct
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

#: Suffix the encryption step appends — also the delivery-time tripwire's
#: vocabulary (``delivery_hops``): an artifact under a pgp contract whose
#: name carries none of these is refused before any transport is touched.
ENCRYPTED_SUFFIX = ".pgp"
ENCRYPTED_SUFFIXES = (".pgp", ".gpg", ".asc")

_ARMOR_HEADER = b"-----BEGIN PGP MESSAGE-----"


class PgpUnavailable(RuntimeError):
    """No encryption backend on this deployment — a STATED refusal.
    The message names what is missing and how to fix it."""


class PgpKeyError(ValueError):
    """The recipient public key cannot be read with certainty."""


def looks_encrypted_name(name: str) -> bool:
    """Does this artifact NAME claim to be encrypted?  A name check only
    — the content guarantee lives in :func:`encrypt_file`'s output
    verification; this exists for the delivery-time tripwire, which has
    the manifest (names) but deliberately no file access."""
    return str(name or "").lower().endswith(ENCRYPTED_SUFFIXES)


# ── backend discovery (the seam) ──────────────────────────────────────────


def _pgpy_backend():
    import pgpy  # noqa: F401 — probe

    def _encrypt(src: Path, dest: Path, armored_key: str) -> None:
        import pgpy as _pgpy
        key, _ = _pgpy.PGPKey.from_blob(armored_key)
        message = _pgpy.PGPMessage.new(src.read_bytes(),
                                       file=True, filename=src.name)
        # Encrypt to the key's encryption-capable subkey when present,
        # else the primary — pgpy resolves usage flags itself.
        dest.write_bytes(bytes(key.encrypt(message)))

    return ("pgpy", _encrypt)


def _gnupg_backend():
    import shutil
    import gnupg  # noqa: F401 — probe

    gpg_bin = shutil.which("gpg") or shutil.which("gpg2")
    if not gpg_bin:
        raise ImportError("python-gnupg importable but no gpg binary on PATH")

    def _encrypt(src: Path, dest: Path, armored_key: str) -> None:
        import tempfile

        import gnupg as _gnupg
        with tempfile.TemporaryDirectory(prefix="qs-pgp-") as home:
            gpg = _gnupg.GPG(gnupghome=home, gpgbinary=gpg_bin)
            imported = gpg.import_keys(armored_key)
            fps = [r.get("fingerprint") for r in imported.results
                   if r.get("fingerprint")]
            if not fps:
                raise PgpKeyError(
                    f"gpg imported no usable key from the recipient "
                    f"block: {imported.results!r}")
            with open(src, "rb") as fh:
                res = gpg.encrypt_file(
                    fh, fps, output=str(dest),
                    always_trust=True, armor=False)
            if not res.ok:
                raise RuntimeError(
                    f"gpg encryption failed: {res.status or res.stderr}")

    return ("gnupg", _encrypt)


def _resolve_backend():
    """``(name, encrypt_callable)`` or None.  Never raises."""
    for probe in (_pgpy_backend, _gnupg_backend):
        try:
            return probe()
        except Exception:  # noqa: BLE001 — a broken probe is "not available"
            continue
    return None


def backend_refusal() -> str | None:
    """None when an encryption backend exists; otherwise the STATED
    reason — what is missing, named, so the authoring-time finding and
    the run-time refusal both carry it (never a silent skip)."""
    if _resolve_backend() is not None:
        return None
    return ("no PGP backend on this deployment: neither 'pgpy' nor "
            "'python-gnupg' (with a gpg binary on PATH) is installed.  "
            "Install one to honour encryption=pgp contracts (FR-ART-06)")


# ── encryption (never a plaintext fallback) ───────────────────────────────


def encrypt_file(path, armored_public_key: str, *,
                 delete_input: bool = True) -> Path:
    """Encrypt ``path`` to the recipient key -> ``<path>.pgp``.

    Raises :class:`PgpUnavailable` (stated refusal) when no backend
    exists, :class:`PgpKeyError` on an unusable key, and verifies the
    OUTPUT before returning: produced bytes must exist, differ from the
    plaintext, and carry OpenPGP framing.  On any failure the plaintext
    input is left untouched and NEVER returned as the result.
    """
    src = Path(path)
    if not src.is_file():
        raise FileNotFoundError(f"nothing to encrypt at {src}")
    if not (armored_public_key or "").strip():
        raise PgpKeyError(
            "encryption requested with no recipient public key — there "
            "is nobody to encrypt to")
    backend = _resolve_backend()
    if backend is None:
        raise PgpUnavailable(backend_refusal())
    name, encrypt = backend
    dest = src.with_name(src.name + ENCRYPTED_SUFFIX)
    encrypt(src, dest, armored_public_key)
    _verify_encrypted_output(src, dest, backend_name=name)
    if delete_input:
        try:
            src.unlink()
        except OSError:
            logger.warning("[pgp] encrypted %s but could not remove the "
                           "plaintext original", src)
    logger.info("[pgp] encrypted %s -> %s via %s", src.name, dest.name, name)
    return dest


def _verify_encrypted_output(src: Path, dest: Path, *,
                             backend_name: str) -> None:
    """The output check that makes a silent no-op backend impossible.
    Deletes a bad output before raising so a failed encryption leaves
    no half-artifact behind."""

    def _fail(reason: str):
        try:
            dest.unlink()
        except OSError:
            pass
        raise RuntimeError(
            f"PGP backend {backend_name!r} produced an unusable output "
            f"for {src.name}: {reason} — refusing; the plaintext was NOT "
            f"delivered and remains at {src}")

    if not dest.is_file() or dest.stat().st_size == 0:
        _fail("no output file / empty output")
    head = dest.open("rb").read(64)
    plaintext_head = src.open("rb").read(64)
    if head == plaintext_head and dest.stat().st_size == src.stat().st_size:
        _fail("output bytes equal the plaintext input")
    # OpenPGP framing: armored header, or a binary packet whose first
    # octet has the packet-tag high bit set (RFC 4880 §4.2).
    if not (head.startswith(_ARMOR_HEADER) or (head and head[0] & 0x80)):
        _fail("output carries no OpenPGP framing (not armored, first "
              "octet has no packet-tag bit)")


# ── key inspection (pure RFC 4880 parsing — FR-SEC-09) ────────────────────


@dataclass(frozen=True)
class KeyInfo:
    created: datetime
    expires_at: datetime | None  # None = no expiry declared

    def expired(self, now: datetime) -> bool:
        return self.expires_at is not None and self.expires_at <= now


def _dearmor(armored: str) -> bytes:
    text = (armored or "").strip()
    if "BEGIN PGP" not in text:
        raise PgpKeyError(
            "recipient key is not an ASCII-armored PGP block "
            "(no '-----BEGIN PGP ... -----' header)")
    lines = text.replace("\r\n", "\n").split("\n")
    body: list[str] = []
    in_body = False
    seen_blank = False
    for line in lines:
        s = line.strip()
        if s.startswith("-----BEGIN PGP"):
            in_body = True
            seen_blank = False
            continue
        if s.startswith("-----END PGP"):
            break
        if not in_body:
            continue
        if not seen_blank:
            # Armor headers (Version:, Comment:) run until a blank line.
            # A body with no headers starts immediately — a base64 line
            # has no ':' so treat it as the body's first line.
            if not s:
                seen_blank = True
                continue
            if ":" in s:
                continue
            seen_blank = True
        if s.startswith("="):  # CRC24 line
            continue
        if s:
            body.append(s)
    if not body:
        raise PgpKeyError("armored key block has no base64 body")
    try:
        return base64.b64decode("".join(body), validate=True)
    except (binascii.Error, ValueError) as exc:
        raise PgpKeyError(f"armored key body is not valid base64: {exc}") \
            from exc


def _iter_packets(data: bytes):
    """Yield ``(tag, body)`` per RFC 4880 §4.2.  Refuses (PgpKeyError)
    on partial-length or indeterminate-length packets — a public key
    block never legitimately uses either, and guessing lengths is how a
    parser silently reads the wrong field as an expiry."""
    i, n = 0, len(data)
    while i < n:
        octet = data[i]
        if not octet & 0x80:
            raise PgpKeyError(
                f"byte {i}: not an OpenPGP packet header (0x{octet:02x})")
        if octet & 0x40:  # new format
            tag = octet & 0x3F
            i += 1
            if i >= n:
                raise PgpKeyError("truncated packet header")
            l1 = data[i]
            if l1 < 192:
                length, i = l1, i + 1
            elif l1 < 224:
                if i + 1 >= n:
                    raise PgpKeyError("truncated 2-octet length")
                length, i = ((l1 - 192) << 8) + data[i + 1] + 192, i + 2
            elif l1 == 255:
                if i + 4 >= n:
                    raise PgpKeyError("truncated 5-octet length")
                length = struct.unpack(">I", data[i + 1:i + 5])[0]
                i += 5
            else:
                raise PgpKeyError(
                    "partial-length packet in a public key block — "
                    "refusing to guess where it ends")
        else:  # old format
            tag = (octet >> 2) & 0x0F
            ltype = octet & 0x03
            i += 1
            if ltype == 0:
                if i >= n:
                    raise PgpKeyError("truncated 1-octet length")
                length, i = data[i], i + 1
            elif ltype == 1:
                if i + 1 >= n:
                    raise PgpKeyError("truncated 2-octet length")
                length, i = struct.unpack(">H", data[i:i + 2])[0], i + 2
            elif ltype == 2:
                if i + 3 >= n:
                    raise PgpKeyError("truncated 4-octet length")
                length, i = struct.unpack(">I", data[i:i + 4])[0], i + 4
            else:
                raise PgpKeyError(
                    "indeterminate-length packet — refusing to guess")
        if i + length > n:
            raise PgpKeyError(
                f"packet (tag {tag}) declares {length} bytes but only "
                f"{n - i} remain — truncated key block")
        yield tag, data[i:i + length]
        i += length


def _iter_subpackets(area: bytes):
    """Yield ``(type, body)`` from a signature subpacket area (§5.2.3.1)."""
    i, n = 0, len(area)
    while i < n:
        l1 = area[i]
        if l1 < 192:
            length, i = l1, i + 1
        elif l1 < 255:
            if i + 1 >= n:
                raise PgpKeyError("truncated subpacket length")
            length, i = ((l1 - 192) << 8) + area[i + 1] + 192, i + 2
        else:
            if i + 4 >= n:
                raise PgpKeyError("truncated 5-octet subpacket length")
            length = struct.unpack(">I", area[i + 1:i + 5])[0]
            i += 5
        if length < 1 or i + length > n:
            raise PgpKeyError("malformed subpacket area")
        sp_type = area[i] & 0x7F
        yield sp_type, area[i + 1:i + length]
        i += length


def inspect_public_key(armored: str) -> KeyInfo:
    """Creation and expiry of the primary key in an armored public key
    block.  Pure parsing (no backend, no crypto, no signature
    verification — this reads DECLARED facts for the authoring
    preflight; cryptographic trust in the key is the transfer channel's
    problem, stated in BRD §18).

    Expiry per RFC 4880: seconds-after-creation in signature subpacket
    9.  Where several self-signatures carry one, the signature with the
    LATEST creation time wins (that is how key expiry is extended).  A
    signature with no subpacket 9 at all, when it is the latest, means
    the expiry was REMOVED — also honoured.
    """
    data = _dearmor(armored)
    packets = list(_iter_packets(data))
    if not packets:
        raise PgpKeyError("key block contains no OpenPGP packets")
    tag, body = packets[0]
    if tag != 6:
        raise PgpKeyError(
            f"first packet is tag {tag}, not a public-key packet (6) — "
            f"is this a PRIVATE key or a message?")
    if len(body) < 6:
        raise PgpKeyError("public-key packet too short")
    version = body[0]
    if version != 4:
        raise PgpKeyError(
            f"public key is version {version}; only v4 keys are "
            f"supported by this parser — refusing to guess the expiry "
            f"of a key format it does not know")
    created_ts = struct.unpack(">I", body[1:5])[0]
    created = datetime.fromtimestamp(created_ts, tz=timezone.utc)

    # Self-signatures over the primary key: direct-key (0x1F) and the
    # user-id certifications (0x10..0x13).  Subkey-binding (0x18)
    # signatures describe SUBKEYS, not the primary — excluded.
    best: tuple[int, int | None] | None = None  # (sig_created, expiry_secs)
    for ptag, pbody in packets[1:]:
        if ptag != 2 or len(pbody) < 6 or pbody[0] != 4:
            continue
        sig_type = pbody[1]
        if sig_type not in (0x1F, 0x10, 0x11, 0x12, 0x13):
            continue
        hashed_len = struct.unpack(">H", pbody[4:6])[0]
        hashed = pbody[6:6 + hashed_len]
        if len(hashed) != hashed_len:
            raise PgpKeyError("signature packet truncates its hashed area")
        sig_created = 0
        expiry_secs: int | None = None
        for sp_type, sp in _iter_subpackets(hashed):
            if sp_type == 2 and len(sp) >= 4:      # signature creation
                sig_created = struct.unpack(">I", sp[:4])[0]
            elif sp_type == 9 and len(sp) >= 4:    # key expiration
                expiry_secs = struct.unpack(">I", sp[:4])[0]
        if best is None or sig_created >= best[0]:
            best = (sig_created, expiry_secs)

    expires_at = None
    if best is not None and best[1]:
        expires_at = created + timedelta(seconds=best[1])
    return KeyInfo(created=created, expires_at=expires_at)


def key_preflight(armored: str, *, now: datetime | None = None,
                  warn_days: int = 30) -> tuple[str, str] | None:
    """FR-SEC-09 — the authoring-time key gate.

    Returns ``None`` (key usable), ``("error", reason)`` (expired or
    unreadable — must refuse the save) or ``("warning", reason)``
    (expires within ``warn_days`` — surfaced at save, delivery would
    still work today).  An unreadable key is an ERROR, not a shrug: a
    preflight that cannot read the key has not preflighted anything.
    """
    now = now or datetime.now(timezone.utc)
    try:
        info = inspect_public_key(armored)
    except PgpKeyError as exc:
        return ("error", f"recipient key unreadable: {exc}")
    if info.expires_at is None:
        return None
    if info.expires_at <= now:
        return ("error",
                f"recipient PGP key EXPIRED {info.expires_at.isoformat()} "
                f"— a feed encrypting to it will fail on every run; "
                f"refuse at authoring, not at 03:00 (FR-SEC-09)")
    if info.expires_at <= now + timedelta(days=warn_days):
        return ("warning",
                f"recipient PGP key expires {info.expires_at.isoformat()} "
                f"(within {warn_days} days) — rotate it before it becomes "
                f"a delivery failure (FR-SEC-09)")
    return None
