"""Which connections does a run actually touch? (BRD §4.2, FR-RUN-07)

The seam Foundation C's claims machinery needs and deliberately does not
build: a feed's concurrency is the MINIMUM free budget across every source it
touches, so the budget can only be enforced once something can answer "every
source it touches" for a given run.

Getting this wrong is quiet in both directions and the two failures are not
symmetric:

* MISS a connection and its budget is not enforced — the whole point of the
  foundation is lost for that feed, and a worker scale-out flattens the
  warehouse at 2am with nothing in the system aware of it;
* INVENT a connection and the run waits for a slot on something it never
  reads, which looks exactly like a busy source.

So this resolves only what the feed definition actually DECLARES, and reports
what it could not resolve rather than guessing.  A feed whose set cannot be
resolved is admitted UNBUDGETED — pre-Foundation-C behaviour — because
refusing to run a feed we cannot budget would convert an accounting gap into
an outage.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Mapping

logger = logging.getLogger(__name__)

#: Destination kinds that reach a REGISTERED connection and therefore consume
#: a slot on it.  ``local`` is pod disk — no connection, no budget.  ``sftp``
#: is currently carried as a config blob rather than a connection record
#: (FR-DEL-07 is still partial), so it consumes no slot until endpoints are
#: registered objects; that is a KNOWN gap, stated here rather than silently
#: producing an unbudgeted hop.
CONNECTION_BACKED_DESTINATIONS = frozenset({"s3", "oracle"})


@dataclass(frozen=True)
class ConnectionSet:
    """Every connection one run touches, plus what could not be resolved."""
    connection_ids: tuple = ()
    unresolved: tuple = ()          # human-readable reasons, never silent

    @property
    def resolved(self) -> bool:
        return not self.unresolved

    def to_dict(self) -> dict:
        return {"connection_ids": list(self.connection_ids),
                "unresolved": list(self.unresolved),
                "resolved": self.resolved}


def resolve_connection_set(feed_config: Mapping[str, Any], *,
                           dao: Any = None) -> ConnectionSet:
    """The connections a run of *feed_config* will touch.

    ``dao`` is optional and only used to follow a published view to its
    execution connection; without it that hop is reported as unresolved
    rather than skipped silently.
    """
    ids: list = []
    unresolved: list = []

    def _add(value, why: str):
        if value is None:
            return
        try:
            ids.append(int(value))
        except (TypeError, ValueError):
            unresolved.append(f"{why}: {value!r} is not a connection id")

    # ── source side ──────────────────────────────────────────────────
    _add(feed_config.get("connection_id"), "primary source")
    _add(feed_config.get("secondary_connection_id"), "cross-source side")

    source_type = str(feed_config.get("source_type") or "").lower()
    if source_type == "published_view" and not feed_config.get("connection_id"):
        # A published view carries its OWN execution connection, which is not
        # copied onto the feed.  Following it needs a read; without one, say
        # so rather than budgeting nothing.
        view_id = feed_config.get("source_id")
        if dao is None:
            unresolved.append(
                f"published_view {view_id}: no dao supplied to resolve its "
                f"execution connection")
        else:
            try:
                view = dao.get_published_view(int(view_id)) or {}
                _add(view.get("execution_connection_id")
                     or view.get("connection_id"), "published view")
            except Exception as exc:
                unresolved.append(
                    f"published_view {view_id}: {exc}")

    # ── destination side ─────────────────────────────────────────────
    dest_type = str(feed_config.get("destination_type") or "").lower()
    if dest_type in CONNECTION_BACKED_DESTINATIONS:
        dest_cfg = feed_config.get("destination_config") or {}
        dest_conn = dest_cfg.get("connection_id")
        if dest_conn is None:
            unresolved.append(
                f"destination {dest_type!r}: no connection_id in "
                f"destination_config, so its budget is not enforced")
        else:
            _add(dest_conn, f"destination {dest_type}")

    # Deduplicate but keep a stable order — the same feed must always claim
    # the same set in the same order, or two workers can deadlock taking two
    # connections in opposite orders.
    seen: set = set()
    ordered = tuple(i for i in ids if not (i in seen or seen.add(i)))

    if unresolved:
        logger.warning(
            "[connection_set] feed %s: %d connection(s) resolved, %d "
            "UNRESOLVED (%s) — the run is admitted but those sources are "
            "NOT budgeted",
            feed_config.get("id"), len(ordered), len(unresolved),
            "; ".join(unresolved))
    return ConnectionSet(connection_ids=ordered,
                         unresolved=tuple(unresolved))
