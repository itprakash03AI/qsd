"""SlaTracker — Phase 130/4.

Periodic batch that scans pending + running feed_runs whose
``sla_to`` deadline has elapsed and marks them ``sla_breached=True``.
Notifications are dispatched through the same notification queue used
by the rest of the feed engine.

SLA fields on a feed_config (and copied to feed_runs at SOD-creation
time):
  - ``sla_from``: "HH:MM" or "+HH:MM" — earliest acceptable start
  - ``sla_to``:   "HH:MM" or "+HH:MM" — latest acceptable completion

Both are interpreted as UTC offsets from the start of business_date.
A "+" prefix is accepted but stripped (matches the enterprise
``+12:00`` convention from the sample row).

Behaviour:
  - Scans every ``sla_check_interval_seconds`` (config).
  - Skips rows already breached so we don't spam the notification
    channel.
  - Updates feed_runs.sla_breached = true + records breach reason in
    ``action_reason`` (appended; existing reason preserved).
  - Returns a typed ``SlaSweepResult`` summarising the sweep.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Any, Callable, List, Mapping, Optional

logger = logging.getLogger(__name__)

_SLA_TIME_RE = re.compile(r"^\+?([01]?\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?$")


@dataclass
class SlaSweepResult:
    """Per-sweep summary returned by ``SlaTracker.sweep_once``."""
    checked: int = 0
    breached_new: int = 0
    already_breached: int = 0
    invalid_sla: int = 0
    notifications_fired: int = 0
    breached_run_ids: List[int] = field(default_factory=list)
    error_details: List[str] = field(default_factory=list)
    # BF-524 (2026-05-28): True when the sweep was skipped because
    # ``sla_tracker.paused=True`` was set in config.  Caller can render
    # an explicit "alerts paused" status badge instead of treating an
    # empty result as "all healthy".
    paused: bool = False

    def to_dict(self) -> dict:
        return {
            "checked": self.checked,
            "breached_new": self.breached_new,
            "already_breached": self.already_breached,
            "invalid_sla": self.invalid_sla,
            "notifications_fired": self.notifications_fired,
            "breached_run_ids": list(self.breached_run_ids),
            "error_details": list(self.error_details),
            "paused": self.paused,
        }


class SlaTracker:
    """Marks pending/running feed_runs as breached when sla_to passes.

    Constructor parameters (DI):
      - ``db``: DatabaseManager-shaped object with ``list_feed_runs``
        and ``update_feed_run``.
      - ``notify_fn``: optional callable invoked with
        ``(run_row, breach_seconds)`` on each new breach.  Used for
        email + webhook hookup.  No-op when None.
      - ``now_fn``: returns the current UTC datetime — overrideable
        in tests for deterministic timing.
    """

    PENDING_OR_RUNNING = ("pending", "running")

    def __init__(
        self,
        db,
        *,
        notify_fn: Optional[Callable[[Mapping[str, Any], int], None]] = None,
        now_fn: Optional[Callable[[], datetime]] = None,
    ) -> None:
        if db is None:
            raise ValueError("SlaTracker requires a db manager")
        self._db = db
        self._notify_fn = notify_fn
        self._now_fn = now_fn or (lambda: datetime.now(timezone.utc))
        # 2026-09-03 — feed_config_id -> sla_timezone, rebuilt per sweep
        # (a config edit must take effect on the next sweep, not on the
        # next pod restart).
        self._tz_cache: dict = {}

    # ── Public API ────────────────────────────────────────────────────

    def sweep_once(self, business_date: Optional[date] = None) -> SlaSweepResult:
        """Run a single SLA-breach sweep.  Returns a typed summary.

        BF-524 (2026-05-28): honours ``sla_tracker.paused`` config flag.
        When set to True the sweep returns an empty result immediately
        with a structured ``paused=True`` marker so the caller can log
        clearly that no alerts will fire.  Use this during planned
        outage windows to silence breach notifications without
        stopping the scheduler job entirely (which would lose the
        in-process sweep cadence + restart-on-resume cost).
        """
        result = SlaSweepResult()
        self._tz_cache = {}
        # Admin-controlled pause gate.  Read each tick so flipping the
        # flag takes effect on the next sweep without restart.
        try:
            from core.config import get as _cfg_get
            if bool(_cfg_get("sla_tracker", "paused", False)):
                logger.warning(
                    "[sla_tracker] PAUSED via config (sla_tracker.paused=true) "
                    "— skipping breach sweep.  No notifications will fire "
                    "until the flag is cleared.  Use during planned outage "
                    "windows so already-late feeds don't trigger cascading "
                    "false-positive alerts."
                )
                result.paused = True
                return result
        except Exception as _cfg_exc:
            logger.debug("[sla_tracker] pause-flag read failed (non-fatal): %s", _cfg_exc)
        rows: List[dict] = []

        # If the caller didn't restrict by date, sweep EVERY open run
        # (pending / running), whatever its business date (2026-10-12).  The
        # sweep used to read today's and yesterday's only, so a month-end
        # business date worked days later (the owner's 2026-09-30 month end,
        # its messages arriving in October) was never swept: the board showed
        # its SLA breached from the same deadline while no alert was ever
        # raised -- two answers to one question.  The open set is small by
        # nature (closed runs leave it).
        if business_date is None:
            for status in self.PENDING_OR_RUNNING:
                rows.extend(self._db.list_feed_runs(
                    business_date=None, status=status, limit=10000,
                ))
        else:
            for status in self.PENDING_OR_RUNNING:
                rows.extend(self._db.list_feed_runs(
                    business_date=business_date, status=status, limit=10000,
                ))

        now = self._now_fn()
        for row in rows:
            try:
                self._check_one(row, now, result)
            except Exception as e:
                msg = f"feed_run {row.get('id')}: {e}"
                result.error_details.append(msg[:300])
                logger.warning("[sla_tracker] %s", msg)
        return result

    # ── Per-row handling ──────────────────────────────────────────────

    def _check_one(self, row: Mapping[str, Any], now: datetime,
                   result: SlaSweepResult) -> None:
        result.checked += 1

        if row.get("sla_breached"):
            result.already_breached += 1
            return

        sla_to_raw = row.get("sla_to")
        if not sla_to_raw:
            return  # No SLA defined → nothing to track

        biz_d = _coerce_date(row.get("business_date"))
        if biz_d is None:
            return

        # 2026-09-03 — the split-brain fix (FR-SCH-06).  This sweep used to
        # read ``sla_to`` as a bare UTC hour while the alert ladder
        # (core/feed/acting_time.resolve_sla_at) read the SAME column as
        # local-time-in-``sla_timezone`` — two consumers, two meanings,
        # wrong breach flags for every non-UTC feed.  Both now branch on
        # the same real column: sla_timezone declared -> ONE shared
        # resolver (acting_time's, so DST answers cannot drift between the
        # lanes); NULL -> the legacy bare-UTC parse, byte-for-byte.
        sla_to_dt = self.deadline_for(row)
        if sla_to_dt is None:
            result.invalid_sla += 1
            return

        if now < sla_to_dt:
            # 2026-10-12 -- AT RISK is an alert too (the board highlights it,
            # the owner: "sla breached or sla at risk ... should be
            # highlighted"): inside ``feed_generation.sla_at_risk_minutes``
            # of the deadline, ONE ``sla_at_risk`` alert per run.
            from core.feed.sla_board import at_risk_minutes
            if (sla_to_dt - now).total_seconds() <= at_risk_minutes() * 60:
                self._alert(row, "sla_at_risk", biz_d,
                            f"due by {sla_to_raw} ({self._sla_timezone_for(row.get('feed_config_id')) or 'UTC'}), "
                            f"{int((sla_to_dt - now).total_seconds() // 60)} min left and not delivered")
            return  # SLA not yet breached

        # Mark the breach.
        breach_seconds = int((now - sla_to_dt).total_seconds())
        reason = self._compose_reason(row, sla_to_raw, breach_seconds)
        self._db.update_feed_run(int(row["id"]), {
            "sla_breached": True,
            "action_reason": reason,
        })
        result.breached_new += 1
        result.breached_run_ids.append(int(row["id"]))
        self._alert(row, "sla_breached", biz_d, reason)

        if self._notify_fn is not None:
            try:
                self._notify_fn(row, breach_seconds)
                result.notifications_fired += 1
            except Exception as e:
                logger.warning(
                    "[sla_tracker] notify hook failed for run %s: %s",
                    row.get("id"), e,
                )

    # ── Helpers ───────────────────────────────────────────────────────

    def _alert(self, row: Mapping[str, Any], kind: str, biz_d: date, message: str) -> None:
        """Raise the run's SLA alert on THE alert road (core/feed/feed_alerts.py:
        one per (kind, run), the kind's channels are data).  Never raises."""
        try:
            from core.feed import feed_alerts
            feed = self._db.get_feed_config(int(row["feed_config_id"])) or {
                "id": row.get("feed_config_id"), "name": row.get("feed_name")}
            feed_alerts.raise_alert(self._db, kind, feed=feed, business_date=biz_d,
                                    feed_run_id=row.get("id"), message=message,
                                    dedupe_key=f"{kind}:{row.get('id')}:{biz_d.isoformat()}")
            if kind == "sla_breached":
                feed_alerts.clear(self._db, by="sla_breached",
                                  dedupe_keys=[f"sla_at_risk:{row.get('id')}:{biz_d.isoformat()}"])
        except Exception as exc:                        # noqa: BLE001 -- alerting never fails a sweep
            logger.warning("[sla_tracker] %s alert for run %s not raised: %s", kind, row.get("id"), exc)

    def deadline_for(self, row: Mapping[str, Any]) -> Optional[datetime]:
        """THE run's SLA deadline as an aware UTC instant, or None (no SLA /
        unparseable).  The breach sweep and the SLA board (core/feed/
        sla_board.py, 2026-10-12) both ask HERE -- one answer, so the board
        can never show "on time" for a run the sweep marks breached.

        2026-09-03 — the split-brain fix (FR-SCH-06): sla_timezone declared
        -> acting_time's resolver (DST answers cannot drift between lanes);
        NULL -> the legacy bare-UTC parse, byte-for-byte."""
        sla_to_raw = row.get("sla_to")
        biz_d = _coerce_date(row.get("business_date"))
        if not sla_to_raw or biz_d is None:
            return None
        tz_name = self._sla_timezone_for(row.get("feed_config_id"))
        if tz_name:
            from core.feed.acting_time import resolve_sla_at
            return resolve_sla_at(biz_d, str(sla_to_raw).strip().lstrip("+"), tz_name)
        return self._sla_to_datetime(sla_to_raw, biz_d)

    def seed_timezones(self, configs: Mapping[int, Mapping[str, Any]]) -> None:
        """Prime the per-feed zone cache from configs the caller already
        read (2026-10-12: the board asked ``get_feed_config`` once per feed).
        The same rule as ``_sla_timezone_for``: a non-empty string or None."""
        for fid, cfg in (configs or {}).items():
            raw = (cfg or {}).get("sla_timezone")
            self._tz_cache[int(fid)] = (raw.strip()
                                        if isinstance(raw, str) and raw.strip() else None)

    def _sla_timezone_for(self, feed_config_id) -> Optional[str]:
        """The feed's declared ``sla_timezone``, cached per sweep.

        None (feed unknown, config unreadable, or column NULL) selects
        the legacy bare-UTC interpretation — an unreadable config must
        not move a deadline, it must keep the meaning the row has always
        had.
        """
        try:
            fid = int(feed_config_id)
        except (TypeError, ValueError):
            return None
        if fid not in self._tz_cache:
            tz_name = None
            try:
                cfg = self._db.get_feed_config(fid) or {}
                raw = cfg.get("sla_timezone")
                # A plain non-empty STRING or nothing: anything else (a
                # mock, a number, a stray dict from a bad write) must
                # select the legacy path, not crash the sweep or invent
                # a zone.
                tz_name = (raw.strip()
                           if isinstance(raw, str) and raw.strip() else None)
            except Exception as exc:
                logger.warning(
                    "[sla_tracker] feed_config %s unreadable (%s) — its "
                    "sla_to stays interpreted as bare UTC this sweep",
                    fid, exc)
            self._tz_cache[fid] = tz_name
        return self._tz_cache[fid]

    @staticmethod
    def _sla_to_datetime(sla_raw: str, biz_d: date) -> Optional[datetime]:
        """Parse ``"+12:00"`` / ``"17:30"`` / ``"17:30:45"`` into a
        timezone-aware UTC datetime anchored to ``biz_d``."""
        if not isinstance(sla_raw, str):
            return None
        m = _SLA_TIME_RE.match(sla_raw.strip())
        if m is None:
            return None
        hh, mm, ss = m.group(1), m.group(2), m.group(3)
        try:
            return datetime(
                biz_d.year, biz_d.month, biz_d.day,
                int(hh), int(mm), int(ss or 0),
                tzinfo=timezone.utc,
            )
        except ValueError:
            return None

    @staticmethod
    def _compose_reason(row: Mapping[str, Any], sla_to: str,
                        breach_seconds: int) -> str:
        prior = row.get("action_reason") or ""
        msg = f"SLA breached: sla_to={sla_to} exceeded by {breach_seconds}s"
        if not prior:
            return msg
        if msg in prior:
            return prior  # idempotent — never duplicate
        return f"{prior}; {msg}"


def _coerce_date(v) -> Optional[date]:
    if v is None:
        return None
    if isinstance(v, date) and not isinstance(v, datetime):
        return v
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, str):
        try:
            return datetime.fromisoformat(v[:10]).date()
        except Exception:
            return None
    return None
