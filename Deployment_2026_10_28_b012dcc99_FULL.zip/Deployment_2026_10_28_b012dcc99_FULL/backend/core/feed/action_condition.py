"""ActionConditionEvaluator — Phase 130/1b.

Evaluates the enterprise ``ACTION_CONDITION`` SQL clause to decide
whether a feed should RUN or SKIP on a given business date.

Reference sample row (FEED_ENTERPRISE_PLAN.md):

    ACTION_CONDITION:
        CASE WHEN d.file_date NOT IN
             (… last 6 business days of month, excluding holidays …)
        THEN 'SKIP' END

Contract: the SQL is wrapped in ``SELECT <expr> AS decision`` and
must return either ``'SKIP'``, ``'RUN'``, or ``NULL``.  ``NULL`` is
treated as RUN (the "default behaviour" — matches the enterprise
convention where omitting the CASE ELSE means "no opinion → run").

The evaluator is **sandboxed**:
  - Runs the expression in an isolated in-memory DuckDB connection,
    NOT the production query engine.
  - Pre-binds ``$business_date`` so admins can write
    ``CASE WHEN $business_date IN ... THEN 'SKIP' END``.
  - Refuses statements that are not a single SELECT-style expression
    (no ``ATTACH``, ``COPY``, ``INSTALL``, ``DELETE``, etc.).

One responsibility per class — this class only decides RUN/SKIP.
Calendar lookups are delegated to ``BusinessCalendar`` injected at
construction time so the evaluator can answer questions like
"is this date in the last N business days of its month?" without
needing direct DB access.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import date
from typing import Optional

from .calendar import BusinessCalendar

logger = logging.getLogger(__name__)

# ── Hard guard — SQL must look like an expression, not a statement ──
_FORBIDDEN_KEYWORDS = (
    "ATTACH", "COPY", "INSTALL", "LOAD", "DELETE", "UPDATE", "INSERT",
    "CREATE", "DROP", "ALTER", "PRAGMA", "CALL", "EXPORT", "IMPORT",
    "GRANT", "REVOKE", "SET ", "BEGIN", "COMMIT", "ROLLBACK",
)

# Allowed decision strings — anything else is a config error
_ALLOWED_DECISIONS = {"RUN", "SKIP", None}


@dataclass(frozen=True)
class ActionDecision:
    """Typed result of evaluating an ``ACTION_CONDITION``."""
    decision: str          # 'RUN' or 'SKIP'
    reason: Optional[str]  # human-readable; SQL snippet for the audit log
    sql_returned: Optional[str]  # raw SQL output (for debugging)


class ActionConditionEvaluator:
    """Decides RUN vs SKIP for a feed on a given business_date.

    Constructed with a ``BusinessCalendar`` so calendar-aware shortcuts
    (``IS_LAST_N_BUSINESS_DAYS_OF_MONTH(d, N)``) can be answered without
    hitting the DB during evaluation.
    """

    # Sentinel exposed for tests / callers
    DEFAULT_DECISION = "RUN"

    def __init__(self, calendar: BusinessCalendar) -> None:
        self._calendar = calendar

    # ── Public API ────────────────────────────────────────────────────

    def evaluate(
        self,
        action_condition_sql: Optional[str],
        business_date: date,
    ) -> ActionDecision:
        """Evaluate ``action_condition_sql`` for ``business_date``.

        When the SQL is empty / ``None``, returns RUN immediately
        (no condition → no skip).
        """
        if not action_condition_sql or not action_condition_sql.strip():
            return ActionDecision(
                decision="RUN",
                reason=None,
                sql_returned=None,
            )

        sql = action_condition_sql.strip()
        self._validate(sql)
        rewritten = self._apply_macros(sql, business_date)

        try:
            raw = self._run_expression(rewritten, business_date)
        except Exception as e:
            # ANY failure → safe default: SKIP with reason.  We do NOT
            # silently RUN — that would risk delivering bad data when
            # the condition is broken.
            logger.warning(
                "ACTION_CONDITION evaluation failed (date=%s, sql=%r): %s",
                business_date, action_condition_sql[:200], e,
            )
            return ActionDecision(
                decision="SKIP",
                reason=f"ACTION_CONDITION error: {e}",
                sql_returned=None,
            )

        decision = self._normalise(raw)
        if decision not in _ALLOWED_DECISIONS:
            logger.warning(
                "ACTION_CONDITION returned unexpected value %r — treating as SKIP",
                raw,
            )
            return ActionDecision(
                decision="SKIP",
                reason=f"ACTION_CONDITION returned unexpected value: {raw!r}",
                sql_returned=str(raw),
            )

        if decision == "SKIP":
            return ActionDecision(
                decision="SKIP",
                reason=f"ACTION_CONDITION returned 'SKIP' for {business_date}",
                sql_returned=str(raw),
            )
        # decision is 'RUN' or None
        return ActionDecision(
            decision="RUN",
            reason=None,
            sql_returned=str(raw) if raw is not None else None,
        )

    # ── Helpers ───────────────────────────────────────────────────────

    def _validate(self, sql: str) -> None:
        """Reject anything that looks like a statement, not an expression."""
        upper = sql.upper()
        for kw in _FORBIDDEN_KEYWORDS:
            # Use word-boundary-ish check — avoid false positives on
            # things like 'INSERTED' in a column name (unlikely but safe).
            if re.search(rf"\b{re.escape(kw.strip())}\b", upper):
                raise ValueError(
                    f"ACTION_CONDITION SQL contains forbidden keyword "
                    f"{kw.strip()!r}: this field accepts only expressions"
                )
        # Cap length so a runaway config can't lock the evaluator up
        if len(sql) > 5000:
            raise ValueError("ACTION_CONDITION SQL too long (max 5000 chars)")

    def _apply_macros(self, sql: str, business_date: date) -> str:
        """Replace QueryStudio macros with literal values evaluated against
        the injected ``BusinessCalendar``.

        Supported macros:
          - ``$business_date``
            literal ISO date placed in single quotes
          - ``IS_LAST_N_BUSINESS_DAYS_OF_MONTH($business_date, N)``
            replaced by TRUE / FALSE
          - ``IS_BUSINESS_DAY($business_date)``
            replaced by TRUE / FALSE
        """
        # 1. Resolve IS_LAST_N_BUSINESS_DAYS_OF_MONTH first — its argument
        # list includes $business_date so we must do this BEFORE the
        # date substitution.
        def _eval_last_n(m: re.Match) -> str:
            n = int(m.group(1))
            ok = self._calendar.is_last_n_business_days_of_month(business_date, n)
            return "TRUE" if ok else "FALSE"

        sql = re.sub(
            r"IS_LAST_N_BUSINESS_DAYS_OF_MONTH\s*\(\s*\$business_date\s*,\s*(\d+)\s*\)",
            _eval_last_n,
            sql,
            flags=re.IGNORECASE,
        )

        # 1b. BF-472 — IS_NTH_BUSINESS_DAY_OF_MONTH for enterprise
        # "workday N" schedules.  Same shape as IS_LAST_N: pair with
        # ACTION_CONDITION ``CASE WHEN NOT IS_NTH_BUSINESS_DAY_OF_MONTH
        # ($business_date, 6) THEN 'SKIP' END`` for a workday-6 feed.
        def _eval_nth(m: re.Match) -> str:
            n = int(m.group(1))
            ok = self._calendar.is_nth_business_day_of_month(business_date, n)
            return "TRUE" if ok else "FALSE"

        sql = re.sub(
            r"IS_NTH_BUSINESS_DAY_OF_MONTH\s*\(\s*\$business_date\s*,\s*(\d+)\s*\)",
            _eval_nth,
            sql,
            flags=re.IGNORECASE,
        )

        # 2. IS_BUSINESS_DAY
        def _eval_is_business(_m: re.Match) -> str:
            # A CalendarHorizonError propagates deliberately (FR-SCH-02):
            # substituting TRUE would run the feed on a day the calendar
            # cannot vouch for, and FALSE would skip a day it may owe.
            # Refusing the DECISION is the only honest third option, and
            # the caller reports it as a failed condition rather than a
            # silent verdict.
            return "TRUE" if self._calendar.is_business_day(business_date) else "FALSE"

        sql = re.sub(
            r"IS_BUSINESS_DAY\s*\(\s*\$business_date\s*\)",
            _eval_is_business,
            sql,
            flags=re.IGNORECASE,
        )

        # 3. Bare $business_date → 'YYYY-MM-DD'
        sql = re.sub(
            r"\$business_date\b",
            f"DATE '{business_date.isoformat()}'",
            sql,
            flags=re.IGNORECASE,
        )
        return sql

    def _run_expression(self, expr: str, business_date: date):
        """Execute the rewritten expression in a fresh in-memory DuckDB.

        Returning the FIRST column of the FIRST row as the decision.
        """
        import duckdb  # local import — keep module import light

        # Wrap in SELECT … unless caller already wrote a SELECT
        upper = expr.upper().lstrip()
        if upper.startswith("SELECT") or upper.startswith("WITH"):
            wrapped = expr
        else:
            wrapped = f"SELECT ({expr}) AS decision"

        with duckdb.connect(":memory:") as con:
            row = con.execute(wrapped).fetchone()
        if row is None:
            return None
        return row[0]

    @staticmethod
    def _normalise(raw) -> Optional[str]:
        """Coerce DuckDB output to one of {'RUN','SKIP',None}."""
        if raw is None:
            return None
        s = str(raw).strip().upper()
        if s in ("", "NULL"):
            return None
        if s in ("RUN", "SKIP"):
            return s
        # Truthy → SKIP (the enterprise convention is "condition matched → skip")
        if s in ("TRUE", "T", "1", "Y", "YES"):
            return "SKIP"
        if s in ("FALSE", "F", "0", "N", "NO"):
            return None  # treat as RUN
        return s  # leaves bad value visible to caller for the warn-and-skip path
