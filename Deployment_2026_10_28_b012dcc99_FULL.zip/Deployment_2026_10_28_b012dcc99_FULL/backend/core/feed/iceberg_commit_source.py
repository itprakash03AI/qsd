"""The Iceberg-commit arrival source — "data for date D is ready" (2026-09-27).

A feed that reads an Iceberg table another team writes has, until now, had
no event to wait on but a clock or a control file.  This module turns a
COMMIT into a dependency arrival:

    manifest watcher / metadata sync detects a new snapshot
      -> database.update_watched_iceberg_sync fires the snapshot-change
         listeners (core/iceberg_snapshot_reactions.py arms THIS one)
      -> on_snapshot_change: which dependencies declared this table?
      -> prove_dates_in_snapshot: read the snapshot's OWN metadata
      -> record_dependency_arrival(source="iceberg_commit") — the SAME
         ledger the Kafka resolver writes
      -> the ONE gate (core/feed/etl_dependency.py::evaluate_gate_verdicts,
         via core/feed/arrival_sources.py) reads it back.

Three rules, enforced here rather than hoped for:

1.  **"Contains D" is PROVED from the table's metadata, never assumed from
    "a commit happened".**  Two proofs are accepted, both exact:
      * a partition value — the declared column is an ``identity`` or
        ``day`` partition source, and a live data file's partition tuple
        carries D;
      * a per-file column bound — a live data file's manifest ``lower_bounds``
        and ``upper_bounds`` for the column are BOTH D (every row of that
        file is on D).  This is what makes a table partitioned by
        ``month(dt)`` provable for a daily load.
    A file whose bounds merely OVERLAP D proves nothing and is not counted.

2.  **Unreadable is COULD NOT TELL.**  A metadata read that fails, a snapshot
    the metadata no longer lists, a column that is not in the schema or has
    a type that cannot carry a date — each records an ``unreadable``
    inspection with the reason, and the gate reports COULD NOT TELL for the
    source.  Never MET, and never NOT MET either: "the table is unreadable"
    and "the table has no data for D" lead to opposite investigations.

3.  **A replay produces no duplicate.**  The arrival identity is
    ``iceberg:<bucket>/<prefix>@<snapshot_id>``; an inspection row is unique
    per (dependency, snapshot); and an arrival is written only when the
    ledger holds no identical identity for (dependency, D).  Firing the
    listener twice for one snapshot — a second pod, a restart, a test — is
    a no-op at three layers.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Mapping, Optional, Set

from core.feed.dependency_gate import MET, NOT_MET, UNKNOWN
from core.table_prefix import canonical_prefix, same_prefix

logger = logging.getLogger(__name__)

LEDGER_SOURCE = "iceberg_commit"

STATUS_PROVED = "proved"
STATUS_NO_PROOF = "no_proof"
STATUS_UNREADABLE = "unreadable"

METHOD_PARTITION_IDENTITY = "partition:identity"
METHOD_PARTITION_DAY = "partition:day"
METHOD_BOUNDS = "bounds"

#: Column types whose decoded value carries a calendar date.
_DATE_CARRYING_TYPES = ("date", "timestamp", "timestamptz", "timestamp_tz",
                        "timestamp with local time zone", "string")


class CommitUnreadable(Exception):
    """The snapshot's metadata could not be read or cannot prove a date —
    the reason is the message.  The gate reports COULD NOT TELL."""


def table_source_key(bucket: str, table_prefix: str) -> str:
    """The ledger ``source_key`` of an Iceberg-commit arrival: WHICH table
    proved the date (2026-10-08).  A dependency may declare two tables
    (ALL: both must have data; ANY: either); each declaration's evaluator
    counts only arrivals carrying its own table's key.  Rows written
    before the key existed carry the same bucket / prefix in their
    payload, which the evaluator also reads."""
    return f"iceberg:{bucket}/{canonical_prefix(table_prefix)}"


def commit_identity(bucket: str, table_prefix: str, snapshot_id: Any) -> str:
    return f"iceberg:{bucket}/{canonical_prefix(table_prefix)}@{snapshot_id}"


def _today_utc() -> date:
    """The clock the look-back window is judged against (a seam for tests)."""
    return datetime.now(timezone.utc).date()


def load_config() -> Dict[str, Any]:
    """The declared ``feed_generation.dependency_iceberg_commit`` block."""
    try:
        from core.config import get as _cfg_get
        raw = _cfg_get("feed_generation", "dependency_iceberg_commit", {}) or {}
    except ImportError:
        raw = {}
    if not isinstance(raw, Mapping):
        raw = {}
    return {
        "enabled": bool(raw.get("enabled", True)),
        "lookback_days": int(raw.get("lookback_days", 14)),
        "max_files_inspected": int(raw.get("max_files_inspected", 200000)),
    }


# ── The proof ─────────────────────────────────────────────────────────────

@dataclass
class ProofResult:
    status: str                         # proved | no_proof
    method: Optional[str]
    dates: Set[date] = field(default_factory=set)
    files_seen: int = 0
    reason: str = ""
    #: 2026-10-11 -- the PARTITION the proof was restricted to (rendered
    #: ``{column: value}``), or None for a date-only proof; and the live
    #: files whose partition could not be read for a filtered column (never
    #: counted: unknown is not met).
    partition_values: Optional[Dict[str, str]] = None
    unverifiable_files: int = 0
    #: 2026-10-12 (the owner: "why iceberg doesn't say which table, COB,
    #: business event, system entity"): the data the proof SAW for the
    #: partition -- live files that proved a date, and their rows (the
    #: manifest's record_count; None when a file did not carry one)
    files_matched: int = 0
    rows_matched: Optional[int] = 0


class PartitionUnrenderable(Exception):
    """A declared ``partition_values`` entry carries a ``{TOKEN}`` the feed's
    parameters cannot fill (2026-10-11).  The dependency is COULD NOT TELL
    with this message -- never evaluated against a guessed partition."""


def partition_label(values: Optional[Mapping[str, str]]) -> str:
    """``{code=E1, businessevent=EOD}`` for sentences; '' when date-only."""
    if not values:
        return ""
    return "{" + ", ".join(f"{k}={v}" for k, v in sorted(values.items())) + "}"


def _as_date(value: Any) -> Optional[date]:
    """A decoded partition value / bound as a calendar date, or None."""
    if value is None:
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = str(value).strip()
    if len(text) < 10:
        return None
    try:
        return date.fromisoformat(text[:10])
    except ValueError:
        return None


# Seams over the reader — each is one S3-facing read, monkeypatchable by
# value in tests.  They ride the reader's own caches so an inspection after
# a reconcile pays no round trip the reconcile already paid.

def _load_metadata(s3_client, bucket: str, table_prefix: str) -> dict:
    from core.iceberg_reader import _latest_metadata_key, _read_s3_json_cached
    meta_prefix = table_prefix.rstrip("/") + "/metadata/"
    key = _latest_metadata_key(s3_client, bucket, meta_prefix, force_fresh=True)
    if not key:
        raise CommitUnreadable(f"no metadata.json under s3://{bucket}/{meta_prefix}")
    return _read_s3_json_cached(s3_client, bucket, key)


def _load_manifest_list(s3_client, bucket: str, snapshot: Mapping[str, Any]) -> List[dict]:
    from core.iceberg_reader import (_read_avro, _read_manifest_list_avro_cached,
                                     _s3_uri_to_key)
    uri = snapshot.get("manifest-list")
    if not uri:
        raise CommitUnreadable("snapshot carries no manifest-list")
    key = _s3_uri_to_key(uri)
    return _read_avro(_read_manifest_list_avro_cached(s3_client, bucket, key))


def _load_manifest_entries(s3_client, bucket: str, manifest_key: str) -> List[dict]:
    from core import iceberg_snapshot_cache as _isc
    from core.iceberg_reader import _read_avro

    def _fetch(bkt: str, key: str) -> List[dict]:
        body = s3_client.get_object(Bucket=bkt, Key=key)["Body"].read()
        return _read_avro(body)

    entries = _isc.get_or_fetch_manifest_entries(bucket, manifest_key, fetch_fn=_fetch)
    if getattr(entries, "qs_read_failed", False):
        raise CommitUnreadable(f"manifest {manifest_key} could not be read")
    return list(entries)


def _current_schema(metadata: Mapping[str, Any]) -> Mapping[str, Any]:
    schemas = metadata.get("schemas") or (
        [metadata["schema"]] if "schema" in metadata else [])
    csid = metadata.get("current-schema-id")
    return next((s for s in schemas if s.get("schema-id") == csid),
                schemas[0] if schemas else {})


def _active_spec(metadata: Mapping[str, Any]) -> Mapping[str, Any]:
    specs = metadata.get("partition-specs") or []
    if not specs and "partition-spec" in metadata:
        ps = metadata["partition-spec"]
        specs = [{"spec-id": 0, "fields": ps}] if isinstance(ps, list) else [ps]
    dsid = metadata.get("default-spec-id", 0)
    return next((s for s in specs if s.get("spec-id") == dsid),
                specs[0] if specs else {})


def _bound_for(bounds: Mapping[Any, Any], fid: int) -> Optional[bytes]:
    v = bounds.get(fid)
    if v is None:
        v = bounds.get(str(fid))
    if isinstance(v, (bytes, bytearray)):
        return bytes(v)
    return None


def _filter_readers(metadata: Mapping[str, Any], schema: Mapping[str, Any],
                    partition_values: Mapping[str, str]):
    """Per filtered column: how a live data file's value of it is read --
    the identity partition value when the column is an identity partition
    source, else the file's lower/upper bounds (equal = the file's one
    value).  A filter naming a column not in the schema is UNREADABLE (the
    declaration is wrong; the gate must say so, not wait for ever)."""
    from core.iceberg_reader import _extract_partition_spec
    spec_types = _extract_partition_spec(metadata)
    readers = []
    for col, wanted in partition_values.items():
        col_lower = str(col).strip().lower()
        fld = next((f for f in (schema.get("fields") or [])
                    if isinstance(f, dict) and str(f.get("name", "")).lower() == col_lower), None)
        if fld is None:
            raise CommitUnreadable(
                f"partition_values names column {col!r}, which is not in the "
                f"table's current schema")
        fid = fld.get("id") if fld.get("id") is not None else fld.get("field-id")
        part_name = None
        for pf in (_active_spec(metadata).get("fields") or []):
            src = pf.get("source-id") if pf.get("source-id") is not None else pf.get("source_id")
            if src == fid and str(pf.get("transform") or "").lower() == "identity":
                part_name = pf.get("name")
                break
        readers.append({"column": col, "wanted": str(wanted).strip(), "fid": int(fid),
                        "ctype": fld.get("type"), "part_name": part_name,
                        "ptype": spec_types.get(part_name) if part_name else None})
    return readers


def _value_text(v: Any) -> Optional[str]:
    if v is None:
        return None
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    return str(v).strip()


def _file_matches(data_file: Mapping[str, Any], readers: list) -> Optional[bool]:
    """True when EVERY filtered column of this file equals its wanted value,
    False when one differs, None when one cannot be read (no partition
    value, no bounds, bounds that span more than one value)."""
    from core.iceberg_reader import _avro_kv_map, _decode_bound, _decode_partition_value
    for rd in readers:
        got: Optional[str] = None
        if rd["part_name"]:
            raw = (data_file.get("partition") or {}).get(rd["part_name"])
            if raw is None:
                return None
            got = _value_text(_decode_partition_value(raw, rd["ptype"] or "string"))
        else:
            lo = _bound_for(_avro_kv_map(data_file.get("lower_bounds")), rd["fid"])
            hi = _bound_for(_avro_kv_map(data_file.get("upper_bounds")), rd["fid"])
            if lo is None or hi is None:
                return None
            lo_t = _value_text(_decode_bound(lo, rd["ctype"]))
            hi_t = _value_text(_decode_bound(hi, rd["ctype"]))
            if lo_t is None or lo_t != hi_t:
                return None
            got = lo_t
        if got is None:
            return None
        if got != rd["wanted"]:
            return False
    return True


def prove_dates_in_snapshot(s3_client, *, bucket: str, table_prefix: str,
                            snapshot_id: Any, date_column: str,
                            max_files: int = 200000,
                            partition_values: Optional[Mapping[str, str]] = None,
                            ) -> ProofResult:
    """Which calendar dates does snapshot ``snapshot_id`` PROVE to hold in
    ``date_column``?  Raises :class:`CommitUnreadable` for anything that
    cannot be read or cannot prove.

    Every live data file is consulted (status != deleted).  The proof is
    the partition value when the column is an identity/day partition
    source; otherwise a file whose column bounds are one date.

    ``partition_values`` (2026-10-11) restricts the proof to the files OF
    ONE PARTITION: a file counts only when every named column's value --
    its identity partition value, or its equal lower/upper bounds -- is the
    wanted one.  A file whose value for a filtered column cannot be read is
    NOT counted (unknown is not met).  Why: 4,000 per-(entity, event) feeds
    read ONE fact_tetb; "a commit contains the date" was true for all of
    them the moment the first entity loaded (live, 2026-10-11).
    """
    from core.iceberg_reader import (_avro_kv_map, _decode_bound,
                                     _decode_partition_value,
                                     _extract_partition_spec, _s3_uri_to_key)

    try:
        metadata = _load_metadata(s3_client, bucket, table_prefix)
    except CommitUnreadable:
        raise
    except Exception as exc:  # noqa: BLE001 — every read failure is one verdict: unreadable
        raise CommitUnreadable(f"metadata.json could not be read: {exc}") from exc

    snapshot = next((s for s in (metadata.get("snapshots") or [])
                     if str(s.get("snapshot-id")) == str(snapshot_id)), None)
    if snapshot is None:
        raise CommitUnreadable(
            f"snapshot {snapshot_id} is not listed in the table's current "
            f"metadata (expired, or the metadata pointer is behind)")

    schema = _current_schema(metadata)
    col_lower = str(date_column).strip().lower()
    col_field = next((f for f in (schema.get("fields") or [])
                      if isinstance(f, dict)
                      and str(f.get("name", "")).lower() == col_lower), None)
    if col_field is None:
        raise CommitUnreadable(
            f"column {date_column!r} is not in the table's current schema")
    fid = col_field.get("id") if col_field.get("id") is not None else col_field.get("field-id")
    ctype = col_field.get("type")
    if not isinstance(ctype, str) or ctype.lower() not in _DATE_CARRYING_TYPES:
        raise CommitUnreadable(
            f"column {date_column!r} has type {ctype!r}, which cannot carry a "
            f"calendar date -- declare a date, timestamp or ISO-string column")

    # Partition proof available?  identity/day on THIS column.
    part_name: Optional[str] = None
    method: str = METHOD_BOUNDS
    for pf in (_active_spec(metadata).get("fields") or []):
        src = pf.get("source-id") if pf.get("source-id") is not None else pf.get("source_id")
        if src != fid:
            continue
        transform = str(pf.get("transform") or "").lower()
        if transform == "identity":
            part_name, method = pf.get("name"), METHOD_PARTITION_IDENTITY
            break
        if transform == "day":
            part_name, method = pf.get("name"), METHOD_PARTITION_DAY
            break
    spec_types = _extract_partition_spec(metadata) if part_name else {}
    ptype = spec_types.get(part_name) if part_name else None
    filters = dict(partition_values or {})
    readers = _filter_readers(metadata, schema, filters) if filters else []

    try:
        manifests = _load_manifest_list(s3_client, bucket, snapshot)
    except CommitUnreadable:
        raise
    except Exception as exc:  # noqa: BLE001
        raise CommitUnreadable(f"manifest list could not be read: {exc}") from exc

    proved: Set[date] = set()
    files_seen = 0
    unverifiable = 0
    files_matched = 0
    rows_matched: Optional[int] = 0

    def _matched(df) -> None:
        nonlocal files_matched, rows_matched
        files_matched += 1
        rc = df.get("record_count")
        rows_matched = (rows_matched + int(rc)) if (rows_matched is not None and rc is not None) else None
    for m in manifests:
        if int(m.get("content") or 0) != 0:
            continue                          # delete manifests carry no data
        mpath = m.get("manifest_path")
        if not mpath:
            continue
        try:
            entries = _load_manifest_entries(s3_client, bucket, _s3_uri_to_key(mpath))
        except CommitUnreadable:
            raise
        except Exception as exc:  # noqa: BLE001
            raise CommitUnreadable(f"manifest {mpath} could not be read: {exc}") from exc
        for entry in entries:
            if int(entry.get("status") or 0) == 2:
                continue                      # deleted in this snapshot
            data_file = entry.get("data_file") or {}
            files_seen += 1
            if files_seen > max_files:
                raise CommitUnreadable(
                    f"snapshot holds more than {max_files} data files "
                    f"(feed_generation.dependency_iceberg_commit."
                    f"max_files_inspected) -- inspection refused rather "
                    f"than run unbounded")
            if readers:
                hit = _file_matches(data_file, readers)
                if hit is None:
                    unverifiable += 1       # unknown is not met: never counted
                    continue
                if not hit:
                    continue                # another partition's file
            if part_name:
                raw = (data_file.get("partition") or {}).get(part_name)
                d = _as_date(_decode_partition_value(raw, ptype or "date"))
                if d is not None:
                    proved.add(d)
                    _matched(data_file)
                continue
            lo = _bound_for(_avro_kv_map(data_file.get("lower_bounds")), int(fid))
            hi = _bound_for(_avro_kv_map(data_file.get("upper_bounds")), int(fid))
            if lo is None or hi is None:
                continue                      # no bounds: proves nothing
            d_lo = _as_date(_decode_bound(lo, ctype))
            d_hi = _as_date(_decode_bound(hi, ctype))
            if d_lo is not None and d_lo == d_hi:
                proved.add(d_lo)
                _matched(data_file)

    where = f" for partition {partition_label(filters)}" if filters else ""
    unv = f"; {unverifiable} file(s) whose partition could not be read were not counted" if unverifiable else ""
    if proved:
        return ProofResult(STATUS_PROVED, method, proved, files_seen,
                           f"{len(proved)} date(s) proved by {method} over "
                           f"{files_seen} live data file(s){where}{unv}",
                           partition_values=filters or None, unverifiable_files=unverifiable,
                           files_matched=files_matched, rows_matched=rows_matched)
    return ProofResult(STATUS_NO_PROOF, method, set(), files_seen,
                       f"no data file proves a date in {date_column!r}{where} "
                       f"({files_seen} live file(s); method {method}{unv})",
                       partition_values=filters or None, unverifiable_files=unverifiable)


# ── The declared partition, rendered from the feed's parameters ───────────

def _feed_params_for_etl(db: Any, etl_id: Any) -> Dict[str, Any]:
    """The scalar ``query_params`` of the feed(s) keyed by ``etl_id`` -- a
    template member carries SYSTEM_ENTITY / EventCode there.  Several feeds
    under one etl_id contribute only the keys they AGREE on; a key they
    disagree on is dropped (an ambiguous value is no value)."""
    feeds: List[Dict[str, Any]] = []
    lister = getattr(db, "list_feed_configs_by_etl_id", None)
    if lister is not None:
        try:
            feeds = list(lister(int(etl_id)) or [])
        except Exception:  # noqa: BLE001 -- fall back to the feed whose id IS the etl_id
            feeds = []
    if not feeds:
        getter = getattr(db, "get_feed_config", None)
        try:
            one = getter(int(etl_id)) if getter is not None else None
        except Exception:  # noqa: BLE001
            one = None
        feeds = [one] if one else []
    merged: Dict[str, Any] = {}
    conflicting: set = set()
    for f in feeds:
        for k, v in ((f or {}).get("query_params") or {}).items():
            if not isinstance(v, (str, int, float, bool)):
                continue
            if k in merged and merged[k] != v:
                conflicting.add(k)
            merged.setdefault(k, v)
    for k in conflicting:
        merged.pop(k, None)
    return merged


def render_partition_values(db: Any, etl_id: Any, spec: Mapping[str, Any]) -> Optional[Dict[str, str]]:
    """The declaration's ``partition_values`` with every ``{TOKEN}`` filled
    from the feed's parameters by THE ONE token renderer
    (``core.feed.sql_tokens.render_og_tokens`` -- the same vocabulary the
    SQL is rendered with), lower-cased column names.  None when the
    declaration names no partition.  Raises :class:`PartitionUnrenderable`
    when a token has no value: the dependency is then COULD NOT TELL, never
    evaluated against a guessed partition."""
    raw = spec.get("partition_values")
    if not isinstance(raw, Mapping) or not raw:
        return None
    from core.feed.sql_tokens import UnresolvedToken, UnsafeTokenValue, render_og_tokens
    params = _feed_params_for_etl(db, etl_id) if any("{" in str(v) for v in raw.values()) else {}
    out: Dict[str, str] = {}
    for col, value in raw.items():
        text = str(value)
        if "{" in text:
            try:
                text = render_og_tokens(text, params, feed_id=etl_id) or ""
            except (UnresolvedToken, UnsafeTokenValue) as exc:
                raise PartitionUnrenderable(
                    f"partition_values[{col!r}]={value!r} cannot be rendered from the "
                    f"feed's parameters: {exc}") from exc
            if "{" in text:
                raise PartitionUnrenderable(
                    f"partition_values[{col!r}]={value!r} carries a token the feed's "
                    f"query_params do not declare (known: {sorted(params)}) -- refusing "
                    f"to judge the commit against a literal '{{' value")
        text = text.strip()
        if not text:
            raise PartitionUnrenderable(f"partition_values[{col!r}] rendered empty")
        out[str(col).strip().lower()] = text
    return out


# ── The listener body ─────────────────────────────────────────────────────

def _in_window(d: date, today: date, lookback_days: int) -> bool:
    return (today - timedelta(days=lookback_days)) <= d <= (today + timedelta(days=1))


def _resolve_table(db: Any, connection_id: int, table_name: str):
    from core.iceberg_watch_registry import resolve_registered_iceberg_table
    return resolve_registered_iceberg_table(db, connection_id, table_name)


def declaring_dependencies(db: Any, *, connection_id: int, bucket: str,
                           table_prefix: str) -> List[Dict[str, Any]]:
    """``[{dependency_name, date_column, table, connection_id,
    partition_values | partition_problem}]`` — every active mapping that
    declared an ``iceberg_commit`` source on THIS (connection, bucket,
    prefix), de-duplicated by (name, column, rendered partition).  A
    declaration whose partition cannot be rendered is listed WITH its
    problem so the listener records an unreadable inspection (the gate
    then says COULD NOT TELL with the reason)."""
    from core.feed.arrival_sources import KIND_ICEBERG_COMMIT, declared_sources
    out: List[Dict[str, Any]] = []
    seen: set = set()
    for mapping in db.list_etl_dependency_mappings_with_sources():
        name = str(mapping.get("dependency_key") or "")
        for spec in declared_sources(mapping):
            if spec.get("kind") != KIND_ICEBERG_COMMIT:
                continue
            try:
                if int(spec.get("connection_id")) != int(connection_id):
                    continue
            except (TypeError, ValueError):
                continue
            entry, _reason = _resolve_table(db, int(connection_id),
                                            str(spec.get("table") or ""))
            if entry is None:
                continue
            if entry["bucket"] != bucket or not same_prefix(entry["table_prefix"], table_prefix):
                continue
            problem = None
            try:
                values = render_partition_values(db, mapping.get("etl_id"), spec)
            except PartitionUnrenderable as exc:
                values, problem = None, str(exc)
            key = (name, str(spec.get("date_column") or "").lower(),
                   tuple(sorted((values or {}).items())), problem)
            if key in seen:
                continue
            seen.add(key)
            target = {"dependency_name": name,
                      "date_column": str(spec.get("date_column")),
                      "table": entry["name"], "connection_id": int(connection_id),
                      "partition_values": values}
            if problem:
                target["partition_problem"] = problem
            out.append(target)
    return out


def on_snapshot_change(db: Any, *, connection_id: int, bucket: str,
                       table_prefix: str, new_snapshot_id: Any,
                       s3_client: Any = None,
                       s3_client_factory: Optional[Callable[[int], Any]] = None,
                       prover: Optional[Callable[..., ProofResult]] = None,
                       today: Optional[date] = None,
                       cfg: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
    """Inspect ONE new snapshot for every dependency that declared the table.

    Returns a summary (also logged) — ``dependencies`` looked at,
    ``inspected`` (new inspections written), ``replays`` (snapshot already
    inspected for that dependency), ``arrivals`` (ledger rows written),
    ``unreadable`` (inspections recorded as could-not-read), and per-
    dependency detail.  Never raises: this runs inside a listener.
    """
    cfg = dict(cfg) if cfg is not None else load_config()
    summary: Dict[str, Any] = {
        "bucket": bucket, "table_prefix": table_prefix,
        "snapshot_id": str(new_snapshot_id), "dependencies": 0,
        "inspected": 0, "replays": 0, "arrivals": 0, "unreadable": 0,
        "detail": [],
    }
    if not cfg.get("enabled", True):
        summary["skipped"] = "feed_generation.dependency_iceberg_commit.enabled is false"
        return summary
    if not new_snapshot_id:
        summary["skipped"] = "no snapshot id"
        return summary
    try:
        targets = declaring_dependencies(db, connection_id=int(connection_id),
                                         bucket=bucket, table_prefix=table_prefix)
    except Exception as exc:  # noqa: BLE001 — listener: log, never raise
        logger.error("[iceberg_commit] could not list declaring dependencies "
                     "for %s/%s: %s", bucket, table_prefix, exc)
        summary["error"] = str(exc)
        return summary
    summary["dependencies"] = len(targets)
    if not targets:
        return summary

    today = today or datetime.now(timezone.utc).date()
    lookback = int(cfg.get("lookback_days", 14))
    identity = commit_identity(bucket, table_prefix, new_snapshot_id)
    prove = prover or prove_dates_in_snapshot
    client = s3_client

    for target in targets:
        name = target["dependency_name"]
        column = target["date_column"]
        partition = target.get("partition_values")
        detail: Dict[str, Any] = {"dependency": name, "date_column": column,
                                  "partition_values": partition}
        summary["detail"].append(detail)
        if target.get("partition_problem"):
            # 2026-10-11 -- a partition the feed's parameters cannot spell:
            # recorded unreadable (COULD NOT TELL), never judged against a
            # guessed partition and never released on the table as a whole.
            _record(db, target, bucket, table_prefix, new_snapshot_id,
                    STATUS_UNREADABLE, None, [], 0, target["partition_problem"])
            summary["unreadable"] += 1
            detail["outcome"] = STATUS_UNREADABLE
            detail["reason"] = target["partition_problem"]
            logger.error("[iceberg_commit] %r: %s", name, target["partition_problem"])
            continue
        try:
            # 2026-10-08 -- THIS table's latest inspection: a dependency
            # declaring two tables has two histories, and the other
            # table's snapshot id never equals this one's.
            prior = db.latest_iceberg_commit_inspection(
                name, bucket=bucket, table_prefix=table_prefix)
        except Exception as exc:  # noqa: BLE001
            prior = None
            logger.warning("[iceberg_commit] prior inspection unreadable for "
                           "%r: %s", name, exc)
        if prior and str(prior.get("snapshot_id")) == str(new_snapshot_id):
            detail["outcome"] = "replay"
            summary["replays"] += 1
            continue

        if client is None:
            try:
                if s3_client_factory is not None:
                    client = s3_client_factory(int(connection_id))
                else:
                    from core.iceberg_manifest_watcher import _build_s3_client
                    client = _build_s3_client(db, int(connection_id))
            except Exception as exc:  # noqa: BLE001
                client = None
                detail["outcome"] = STATUS_UNREADABLE
                detail["reason"] = f"s3 client could not be built: {exc}"
        if client is None:
            _record(db, target, bucket, table_prefix, new_snapshot_id,
                    STATUS_UNREADABLE, None, [], 0,
                    detail.get("reason") or "s3 client unavailable")
            summary["unreadable"] += 1
            detail["outcome"] = STATUS_UNREADABLE
            continue

        try:
            proof = prove(client, bucket=bucket, table_prefix=table_prefix,
                          snapshot_id=new_snapshot_id, date_column=column,
                          max_files=int(cfg.get("max_files_inspected", 200000)),
                          partition_values=partition)
        except CommitUnreadable as exc:
            _record(db, target, bucket, table_prefix, new_snapshot_id,
                    STATUS_UNREADABLE, None, [], 0, str(exc))
            summary["unreadable"] += 1
            detail["outcome"] = STATUS_UNREADABLE
            detail["reason"] = str(exc)
            logger.error("[iceberg_commit] %r: snapshot %s of %s/%s could NOT "
                         "be read -- the gate reports COULD NOT TELL: %s",
                         name, new_snapshot_id, bucket, table_prefix, exc)
            continue
        except Exception as exc:  # noqa: BLE001 — same verdict, different cause
            _record(db, target, bucket, table_prefix, new_snapshot_id,
                    STATUS_UNREADABLE, None, [], 0, f"{type(exc).__name__}: {exc}")
            summary["unreadable"] += 1
            detail["outcome"] = STATUS_UNREADABLE
            detail["reason"] = f"{type(exc).__name__}: {exc}"
            logger.error("[iceberg_commit] %r: inspection of snapshot %s "
                         "raised: %s", name, new_snapshot_id, exc)
            continue

        in_window = sorted(d for d in proof.dates if _in_window(d, today, lookback))
        written = 0
        for d in in_window:
            if _record_arrival(db, name, d, identity, {
                    "snapshot_id": str(new_snapshot_id), "bucket": bucket,
                    "table_prefix": canonical_prefix(table_prefix),
                    "table": target["table"], "date_column": column,
                    "method": proof.method, "files_seen": proof.files_seen,
                    "partition_values": partition}):
                written += 1
        summary["arrivals"] += written
        recorded = _record(db, target, bucket, table_prefix, new_snapshot_id,
                           proof.status, proof.method,
                           [d.isoformat() for d in in_window], proof.files_seen,
                           proof.reason, proof=proof)
        if recorded:
            summary["inspected"] += 1
        detail.update(outcome=proof.status, method=proof.method,
                      dates_proved=[d.isoformat() for d in in_window],
                      dates_outside_window=len(proof.dates) - len(in_window),
                      arrivals=written, files_seen=proof.files_seen)
        logger.info("[iceberg_commit] %r: snapshot %s of %s/%s %s -- %s; "
                    "%d arrival(s) recorded for %s",
                    name, new_snapshot_id, bucket, table_prefix, proof.status,
                    proof.reason, written, [d.isoformat() for d in in_window])
    return summary


def _record(db: Any, target: Mapping[str, Any], bucket: str, table_prefix: str,
            snapshot_id: Any, status: str, method: Optional[str],
            dates: List[str], files_seen: int, reason: str,
            proof: Optional[ProofResult] = None) -> bool:
    try:
        row = db.record_iceberg_commit_inspection({
            # WHICH table and WHICH partition (COB + the declared partition
            # columns: business event, system entity ...) and how much data
            # the proof saw there -- the record says it, the screen reads it
            "table_name": str(target.get("table") or "") or None,
            "partition_values": (proof.partition_values if proof is not None
                                 else target.get("partition_values")) or None,
            "files_matched": proof.files_matched if proof is not None else None,
            "rows_matched": proof.rows_matched if proof is not None else None,
            "dependency_name": target["dependency_name"],
            "connection_id": int(target["connection_id"]),
            "bucket": bucket, "table_prefix": canonical_prefix(table_prefix),
            "snapshot_id": str(snapshot_id),
            "date_column": str(target["date_column"]),
            "status": status, "method": method, "dates_proved": dates,
            "files_seen": int(files_seen), "reason": (reason or "")[:2000],
            "inspected_at": datetime.now(timezone.utc),
        })
        return row is not None
    except Exception as exc:  # noqa: BLE001 — evidence bookkeeping must not take the listener down
        logger.error("[iceberg_commit] inspection row for %r @ %s could not "
                     "be written: %s", target.get("dependency_name"),
                     snapshot_id, exc)
        return False


def _table_rows(events: List[Mapping[str, Any]], key: str,
                bucket: str, table_prefix: str) -> List[Mapping[str, Any]]:
    """The ``iceberg_commit`` ledger rows that count for ONE declared
    table (2026-10-08): rows carrying its ``source_key``, rows written
    before the key existed whose payload names the same bucket / prefix,
    and untagged rows naming no table at all (an operator's)."""
    from core.feed.ledger import same_source_rows
    out = []
    for e in same_source_rows(
            [e for e in events if str(e.get("source") or "") == LEDGER_SOURCE],
            key):
        if e.get("source_key"):
            out.append(e)
            continue
        payload = e.get("payload") if isinstance(e.get("payload"), Mapping) else {}
        pb, pp = payload.get("bucket"), payload.get("table_prefix")
        if not pb and not pp:
            out.append(e)                     # untagged: for every table
        elif pb == bucket and same_prefix(str(pp or ""), table_prefix):
            out.append(e)
    return out


def _record_arrival(db: Any, name: str, business_date: date, identity: str,
                    payload: Dict[str, Any]) -> bool:
    """Append the arrival unless the ledger already holds an
    ``iceberg_commit`` arrival for (name, D) from THIS TABLE.  Returns
    whether a row was written.

    ONE arrival per (dependency, date, table) from this source, on
    purpose: every later snapshot of a daily table re-proves the last
    ``lookback_days`` dates, and recording each under its own snapshot
    identity would make the ledger classify fourteen REPLAYS per commit —
    each raising a regeneration decision.  A re-load of an already-proved
    date is therefore NOT a replay signal from this source; that signal
    still comes from a Kafka message or an operator.  Per TABLE since
    2026-10-08: a dependency declaring two tables needs an arrival from
    each (the first commit used to block the second table's arrival for
    ever, and the second table's evaluator read the first's arrival as its
    own -- "ALL of two tables" released on one).
    """
    from core.feed.ledger import record_dependency_arrival
    bucket = str(payload.get("bucket") or "")
    table_prefix = str(payload.get("table_prefix") or "")
    key = table_source_key(bucket, table_prefix)
    try:
        prior = db.list_dependency_events(name, business_date)
    except Exception as exc:  # noqa: BLE001 — cannot prove absence: do not write twice on a guess
        logger.error("[iceberg_commit] ledger unreadable for %r @ %s (%s) -- "
                     "arrival NOT written this pass; the next inspection of a "
                     "later snapshot re-proves it", name, business_date, exc)
        return False
    if (_table_rows(prior, key, bucket, table_prefix)
            or any(str(p.get("message_identity")) == identity for p in prior)):
        return False
    result = record_dependency_arrival(
        db, dependency_name=name, business_date=business_date,
        source=LEDGER_SOURCE, message_identity=identity, payload=payload,
        source_key=key)
    return bool(result.recorded)


# ── The gate side: one source's verdict ───────────────────────────────────

def evaluate_source(db: Any, *, dependency_name: str, spec: Mapping[str, Any],
                    business_date: date,
                    ledger_events: Optional[List[Dict[str, Any]]],
                    ledger_error: Optional[str],
                    etl_id: Any = None) -> tuple:
    """(verdict, reason, evidence) for one ``iceberg_commit`` declaration.

    Order of evidence:
      1. an ``iceberg_commit`` arrival on the ledger for D  -> MET;
      2. the ledger unreadable                               -> COULD NOT TELL;
      3. the declared table not registered / not Iceberg    -> COULD NOT TELL;
      4. a declared partition the feed cannot spell          -> COULD NOT TELL;
      5. the latest inspection ``unreadable``                -> COULD NOT TELL;
      6. the table not watched (nothing can observe it)      -> COULD NOT TELL;
      7. otherwise NOT MET, saying what WAS observed (and the partition
         waited for, when one is declared).
    """
    table = str(spec.get("table") or "")
    column = str(spec.get("date_column") or "")
    try:
        conn_id = int(spec.get("connection_id"))
    except (TypeError, ValueError):
        return (UNKNOWN, f"declaration has no usable connection_id "
                         f"({spec.get('connection_id')!r})", None)
    label = f"{table} (connection {conn_id})"

    if ledger_events is None:
        return (UNKNOWN, f"the arrival ledger could not be read ({ledger_error})",
                None)

    entry, reason = _resolve_table(db, conn_id, table)
    if entry is None:
        # 2026-10-08 -- the table must be known before its arrivals can be
        # told from another declared table's; an unresolvable declaration
        # is COULD NOT TELL whatever the ledger holds.
        return (UNKNOWN, reason, None)
    key = table_source_key(entry["bucket"], entry["table_prefix"])
    hits = _table_rows(ledger_events, key, entry["bucket"], entry["table_prefix"])
    if hits:
        last = hits[-1]
        payload = last.get("payload") or {}
        part = payload.get("partition_values") if isinstance(payload, Mapping) else None
        return (MET,
                f"snapshot {payload.get('snapshot_id', '?')} of {label} "
                f"proved data for {business_date.isoformat()} in "
                f"{column!r}{' for partition ' + partition_label(part) if part else ''} "
                f"({payload.get('method', '?')}) at {last.get('arrived_at')}",
                {"last_arrived_at": last.get("arrived_at"),
                 "snapshot_id": payload.get("snapshot_id"),
                 "method": payload.get("method"),
                 "arrival_count": len(hits),
                 "partition_values": part,
                 "source_key": key})

    # 2026-10-11 -- the declared partition, as the listener would render it:
    # a token the feed cannot fill is COULD NOT TELL (never "not met" for a
    # partition nobody can spell), and the hold names what is waited for.
    try:
        partition = render_partition_values(db, etl_id, spec) if etl_id is not None else (
            {str(k).lower(): str(v) for k, v in (spec.get("partition_values") or {}).items()} or None)
    except PartitionUnrenderable as exc:
        return (UNKNOWN, str(exc), {"partition_values": spec.get("partition_values")})
    where = f" for partition {partition_label(partition)}" if partition else ""

    try:
        inspection = db.latest_iceberg_commit_inspection(
            dependency_name, bucket=entry["bucket"],
            table_prefix=entry["table_prefix"])
    except Exception as exc:  # noqa: BLE001
        return (UNKNOWN, f"inspection history could not be read: {exc}", None)
    if inspection and inspection.get("status") == STATUS_UNREADABLE:
        return (UNKNOWN,
                f"the last commit (snapshot {inspection.get('snapshot_id')}) of "
                f"{label} could not be read: {inspection.get('reason')}",
                {"snapshot_id": inspection.get("snapshot_id"),
                 "inspected_at": inspection.get("inspected_at")})

    try:
        watched = db.get_watched_iceberg_table(
            connection_id=conn_id, bucket=entry["bucket"],
            table_prefix=entry["table_prefix"])
    except Exception as exc:  # noqa: BLE001
        return (UNKNOWN, f"watched state of {label} could not be read: {exc}", None)
    if not watched or not watched.get("enabled", True):
        return (UNKNOWN,
                f"{label} is not watched, so no commit can be observed -- "
                f"re-save the dependency or register the table (watching is "
                f"automatic on register when iceberg.watch_registered_tables "
                f"is on)", None)

    observed = ""
    if inspection:
        observed = (f"; last inspected snapshot {inspection.get('snapshot_id')} at "
                    f"{inspection.get('inspected_at')} proved "
                    f"{inspection.get('dates_proved') or 'no date'} "
                    f"({inspection.get('reason')})")
    elif watched.get("last_snapshot_id"):
        observed = (f"; the watcher last saw snapshot "
                    f"{watched.get('last_snapshot_id')} at "
                    f"{watched.get('last_synced_at')} and no inspection has "
                    f"run for this dependency yet")
    # 2026-09-27 -- a date outside the look-back window is never recorded,
    # however many commits contain it; say THAT, not "no commit observed"
    # (which sends the operator looking for a load that may have happened).
    _lookback = int(load_config().get("lookback_days", 14))
    _today = _today_utc()
    if not _in_window(business_date, _today, _lookback):
        return (NOT_MET,
                f"{column}={business_date.isoformat()} is outside the Iceberg-commit "
                f"look-back window ({_lookback} days), so commits for it are not "
                f"recorded -- widen feed_generation.dependency_iceberg_commit."
                f"lookback_days or skip this dependency for the run",
                {"last_snapshot_id": watched.get("last_snapshot_id"),
                 "last_synced_at": watched.get("last_synced_at")})
    return (NOT_MET,
            f"no commit of {label} containing {column}={business_date.isoformat()}"
            f"{where} has been observed{observed}",
            {"last_snapshot_id": watched.get("last_snapshot_id"),
             "last_synced_at": watched.get("last_synced_at"),
             "partition_values": partition})


__all__ = [
    "LEDGER_SOURCE", "STATUS_PROVED", "STATUS_NO_PROOF", "STATUS_UNREADABLE",
    "METHOD_PARTITION_IDENTITY", "METHOD_PARTITION_DAY", "METHOD_BOUNDS",
    "CommitUnreadable", "PartitionUnrenderable", "ProofResult", "commit_identity",
    "table_source_key", "partition_label", "load_config",
    "prove_dates_in_snapshot", "render_partition_values", "declaring_dependencies",
    "on_snapshot_change", "evaluate_source",
]
