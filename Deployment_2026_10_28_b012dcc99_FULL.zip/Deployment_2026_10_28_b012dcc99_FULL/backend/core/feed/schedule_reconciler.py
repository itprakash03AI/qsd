"""Feed schedule reconciler — feed_configs is the ONE truth for per-feed crons.

Phase 4 (2026-08-23).  The defect this closes, concretely:

``POST /api/feeds`` (and PUT / enable-schedule) registered the APScheduler
cron job via ``feed_api._register_schedule`` — which registers into the
LOCAL process's scheduler and swallows every failure.  On any pod that does
not hold the scheduler lock (scheduler.mode=external, or multi-pod embedded
where the load balancer picked a non-leader), ``get_scheduler()`` is None:
the endpoint returned 200/201, the UI showed the schedule enabled, and the
feed NEVER fired.  The mirror defect: disable/delete on such a pod left the
persistent job firing forever.  The same fact (is this feed scheduled, and
on what cron) lived in two places — feed_configs and the APScheduler
jobstore — with nobody converging them.

This module makes the DB row the single source of truth.  The pod that owns
the scheduler runs :func:`reconcile_feed_schedule_jobs` on an interval
(``feed_generation.schedule_reconcile_interval_seconds``, registered in
``core.scheduler.init_scheduler`` as ``__feed_schedule_reconcile__``):

  * a feed with ``is_active`` + ``schedule_enabled`` + ``cron_expression``
    gets a ``feed_{id}`` job (added if missing, replaced if the cron or
    timezone changed),
  * every ``feed_*`` job whose feed is disabled, unscheduled or deleted is
    removed,
  * a row whose cron/timezone cannot parse is counted + logged LOUDLY every
    pass (visible, never silently dropped) — and the API-side validators
    (``validate_cron_and_tz``) stop new rows like that from being created.

``feed_api._register_schedule`` remains as the same-pod fast path so the
single-pod embedded deployment keeps its instant registration; this sweep
is the guarantee.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

#: id prefix for per-feed cron jobs — shared with feed_api._register_schedule.
FEED_JOB_PREFIX = "feed_"

#: user-schedule ids look like ``qs_{id}_{hex}`` and system jobs ``__x__`` —
#: neither starts with this prefix, so the sweep can never touch them.


def validate_cron_and_tz(cron_expr: str, tz: Optional[str]) -> None:
    """Raise ``ValueError`` (with the parser's message) when the cron
    expression or timezone cannot build a CronTrigger.

    ONE validator used by the API models, the enable-schedule endpoint and
    the reconciler — so what the API accepts is exactly what the scheduler
    can run.
    """
    from core.cron_compat import crontab_trigger
    try:
        crontab_trigger(cron_expr, timezone=tz or "UTC")
    except Exception as exc:
        raise ValueError(
            f"Invalid cron expression {cron_expr!r} (timezone {tz or 'UTC'!r}): {exc}"
        ) from exc


def _build_trigger(cron_expr: str, tz: Optional[str]):
    from core.cron_compat import crontab_trigger
    return crontab_trigger(cron_expr, timezone=tz or "UTC")


def _trigger_signature(trigger) -> str:
    """A comparable identity for a trigger: fields + timezone.

    ``str(CronTrigger)`` renders the cron fields but not the timezone, so
    the timezone is appended explicitly — a feed whose cron stayed the same
    while its timezone changed MUST re-register.
    """
    return f"{trigger}@{getattr(trigger, 'timezone', None)}"


def desired_feed_jobs(db) -> Dict[str, dict]:
    """The jobs feed_configs says should exist: ``{job_id: spec}``."""
    out: Dict[str, dict] = {}
    rows = db.list_feed_configs(is_active=True) or []
    for fc in rows:
        if not fc.get("schedule_enabled") or not fc.get("cron_expression"):
            continue
        feed_id = int(fc["id"])
        out[f"{FEED_JOB_PREFIX}{feed_id}"] = {
            "feed_id": feed_id,
            "cron": str(fc["cron_expression"]),
            "tz": fc.get("timezone") or "UTC",
            "name": fc.get("name") or f"feed:{feed_id}",
        }
    return out


def reconcile_feed_schedule_jobs(db, scheduler) -> Dict[str, Any]:
    """One convergence pass.  Returns counters (numbers, not adjectives) so
    the daemon log line and the tests can assert what actually happened:
    ``{desired, added, updated, removed, unchanged, invalid, errors}``.
    """
    counters = {"desired": 0, "added": 0, "updated": 0, "removed": 0,
                "unchanged": 0, "invalid": 0, "errors": 0}
    if scheduler is None or db is None:
        return counters

    from core.feed_engine import run_scheduled_feed

    desired = desired_feed_jobs(db)
    counters["desired"] = len(desired)

    # Current feed_* jobs in the PERSISTENT store (user schedules and daemon
    # jobs live under other prefixes/stores and are never touched).
    current: Dict[str, Any] = {}
    for job in scheduler.get_jobs(jobstore="default"):
        if str(job.id).startswith(FEED_JOB_PREFIX):
            current[str(job.id)] = job

    # Converge: add / update
    for job_id, spec in desired.items():
        try:
            try:
                trigger = _build_trigger(spec["cron"], spec["tz"])
            except Exception as exc:
                counters["invalid"] += 1
                logger.warning(
                    "[feed_schedule_reconciler] feed %s has an UNSCHEDULABLE "
                    "cron (%r, tz=%r): %s — the feed will NOT fire until it "
                    "is fixed", spec["feed_id"], spec["cron"], spec["tz"], exc,
                )
                continue
            existing = current.get(job_id)
            if existing is not None and (
                _trigger_signature(existing.trigger) == _trigger_signature(trigger)
            ):
                counters["unchanged"] += 1
                continue
            scheduler.add_job(
                func=run_scheduled_feed,
                trigger=trigger,
                id=job_id,
                args=[spec["feed_id"]],
                name=f"feed:{spec['name']}",
                replace_existing=True,
                misfire_grace_time=300,
                jobstore="default",
            )
            if existing is None:
                counters["added"] += 1
                logger.info(
                    "[feed_schedule_reconciler] registered %s (cron=%s tz=%s)",
                    job_id, spec["cron"], spec["tz"],
                )
            else:
                counters["updated"] += 1
                logger.info(
                    "[feed_schedule_reconciler] re-registered %s — trigger "
                    "drifted from DB truth (now cron=%s tz=%s)",
                    job_id, spec["cron"], spec["tz"],
                )
            try:
                db.update_feed_config(spec["feed_id"],
                                      {"apscheduler_job_id": job_id})
            except Exception:
                logger.debug("[feed_schedule_reconciler] could not stamp "
                             "apscheduler_job_id on feed %s", spec["feed_id"])
        except Exception as exc:
            counters["errors"] += 1
            logger.warning(
                "[feed_schedule_reconciler] feed %s reconcile failed: %s",
                spec.get("feed_id"), exc,
            )

    # Converge: remove jobs whose feed is gone / disabled / unscheduled.
    for job_id in current:
        if job_id in desired:
            continue
        try:
            scheduler.remove_job(job_id, jobstore="default")
            counters["removed"] += 1
            logger.info(
                "[feed_schedule_reconciler] removed %s — its feed is "
                "deleted, inactive or unscheduled in the DB", job_id,
            )
        except Exception as exc:
            counters["errors"] += 1
            logger.warning(
                "[feed_schedule_reconciler] could not remove stale job %s: %s",
                job_id, exc,
            )

    return counters
