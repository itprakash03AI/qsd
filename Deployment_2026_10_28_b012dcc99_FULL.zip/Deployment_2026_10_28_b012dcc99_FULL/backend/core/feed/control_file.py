"""ControlFileWriter — Phase 130/1b + hotfix-4 (DB-driven format).

Writes the sidecar ``.ctl`` manifest that accompanies an output feed file.
Mainframes / enterprise downstreams treat the control file as the
authoritative "the data file is ready and undamaged" signal, so we
emit it AFTER the data file is fully on disk (compression applied,
fsync optional).

Phase 130 hotfix-4 — format is DB-driven via ``ControlFormatSpec``.
The legacy hardcoded field order remains as the fallback when no spec
is configured, so existing feeds keep their current behaviour.

One responsibility per class — this class only knows how to render
control-file text from a typed input record + spec and write it.
Filename rendering, compression, checksum computation are someone
else's job (FilenameRenderer / CompressionWriter / checksum.py).
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any, Iterable, List, Mapping, Optional

from .checksum import compute_file_checksum, normalise_algorithm

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ControlFileRecord:
    """Typed input for ``ControlFileWriter.write()``.

    All optional fields default to ``None`` so callers only populate
    what they actually have — the writer renders rows only for fields
    whose value is not ``None``.  Multiple checksum fields can be
    populated simultaneously when the format requests defence-in-depth.
    """
    filename: str
    row_count: int
    byte_size: int
    business_date: Optional[date] = None
    feed_name: Optional[str] = None
    feed_id: Optional[int] = None
    run_id: Optional[int] = None
    # All supported checksum algorithms (Phase 130 hotfix-4).  Whichever
    # are non-None get rendered, in the order the format spec dictates.
    checksum_md5:    Optional[str] = None
    checksum_sha1:   Optional[str] = None
    checksum_sha256: Optional[str] = None
    checksum_sha512: Optional[str] = None
    checksum_crc32:  Optional[str] = None
    generated_at: Optional[datetime] = None
    extras: Mapping[str, str] = field(default_factory=dict)


# Default field order used when no ``ControlFormatSpec`` is supplied —
# matches the pre-hotfix-4 behaviour byte-for-byte so existing feeds
# don't change shape.
_DEFAULT_FIELD_ORDER = (
    "filename",
    "row_count",
    "byte_size",
    "checksum_sha256",
    "business_date",
    "feed_name",
    "feed_id",
    "run_id",
    "generated_at",
)

# Labels each field renders with by default (UPPERCASE for the mainframe
# convention).  Spec rows can override per-field via ``field_specs``.
_DEFAULT_LABELS = {
    "filename":         "FILENAME",
    "row_count":        "ROW_COUNT",
    "byte_size":        "BYTE_SIZE",
    "business_date":    "BUSINESS_DATE",
    "feed_name":        "FEED_NAME",
    "feed_id":          "FEED_ID",
    "run_id":           "RUN_ID",
    "generated_at":     "GENERATED_AT",
    "checksum_md5":     "CHECKSUM_MD5",
    "checksum_sha1":    "CHECKSUM_SHA1",
    "checksum_sha256":  "CHECKSUM_SHA256",
    "checksum_sha512":  "CHECKSUM_SHA512",
    "checksum_crc32":   "CHECKSUM_CRC32",
}


@dataclass(frozen=True)
class ControlFormatSpec:
    """Resolved control-file format — DB-driven (Phase 130 hotfix-4).

    Built from a ``feed_control_file_formats`` row by
    ``ControlFormatRepo.get()``.  Frozen so the writer can hold it
    without worrying about mutation between render() calls.

    ``fields``:  ordered list of identifiers (``filename``,
                 ``row_count``, ``checksum_md5``, …).  ``None`` → fall
                 back to ``_DEFAULT_FIELD_ORDER``.
    ``field_specs``: optional per-field overrides — keys: label, width,
                 pad ('left'|'right'), align ('left'|'right'), format
                 (strftime when the field is a date).
    ``checksum_algorithms``: ordered list of algorithms to compute.
                 Determines which ``checksum_*`` fields are populated.
    """
    style: str = "key_value"            # key_value | delimited | fixed_width
    delimiter: str = "|"
    fields: Optional[List[str]] = None
    field_specs: Mapping[str, Any] = field(default_factory=dict)
    checksum_algorithms: List[str] = field(default_factory=list)
    date_format: str = "%Y%m%d"
    datetime_format: str = "%Y-%m-%dT%H:%M:%SZ"

    @classmethod
    def from_row(cls, row: Mapping[str, Any]) -> "ControlFormatSpec":
        """Build a spec from a ``feed_control_file_formats`` row dict.

        Resolves the algorithm list: ``checksum_algorithms`` (JSON list)
        wins; falls back to ``checksum_algorithm`` (single string);
        falls back to ``["sha256"]``.  ``"none"`` → empty list (no
        checksum computed).
        """
        algos_raw = row.get("checksum_algorithms")
        if isinstance(algos_raw, (list, tuple)) and algos_raw:
            algos = [normalise_algorithm(a) for a in algos_raw if a]
        else:
            single = row.get("checksum_algorithm") or "sha256"
            if single.strip().lower() == "none":
                algos = []
            else:
                algos = [normalise_algorithm(single)]

        return cls(
            style=str(row.get("style") or "key_value"),
            delimiter=str(row.get("delimiter") or "|"),
            fields=list(row["fields"]) if row.get("fields") else None,
            field_specs=dict(row.get("field_specs") or {}),
            checksum_algorithms=algos,
            date_format=str(row.get("date_format") or "%Y%m%d"),
            datetime_format=str(row.get("datetime_format") or "%Y-%m-%dT%H:%M:%SZ"),
        )


class ControlFileWriter:
    """Sidecar ``.ctl`` manifest writer.

    Stateless apart from the spec held for the lifetime of the
    instance.  Tests can construct ad-hoc specs without DB; production
    callers build via ``ControlFormatSpec.from_row()``.

    Three styles supported:
      - ``key_value``  — ``FIELD=value`` per line (default)
      - ``delimited``  — single line, fields joined by ``delimiter``
      - ``fixed_width``— each value padded to ``field_specs[name].width``
    """

    _VALID_STYLES = ("key_value", "delimited", "fixed_width")

    def __init__(
        self,
        style: str = "key_value",
        delimiter: str = "|",
        date_format: str = "%Y%m%d",
        datetime_format: str = "%Y-%m-%dT%H:%M:%SZ",
        field_order: Iterable[str] = _DEFAULT_FIELD_ORDER,
        *,
        spec: Optional[ControlFormatSpec] = None,
        field_specs: Optional[Mapping[str, Any]] = None,
    ) -> None:
        if spec is not None:
            # Spec-driven path (Phase 130 hotfix-4 — DB-driven)
            if spec.style not in self._VALID_STYLES:
                raise ValueError(
                    f"Unknown control-file style: {spec.style!r} "
                    f"(expected one of {self._VALID_STYLES})"
                )
            self._style = spec.style
            self._delimiter = spec.delimiter
            self._date_format = spec.date_format
            self._datetime_format = spec.datetime_format
            self._field_order = tuple(spec.fields or _DEFAULT_FIELD_ORDER)
            self._field_specs = dict(spec.field_specs or {})
            self._algorithms = list(spec.checksum_algorithms or [])
        else:
            # Legacy constructor path — backwards compatible.
            if style not in self._VALID_STYLES:
                raise ValueError(
                    f"Unknown control-file style: {style!r} "
                    f"(expected one of {self._VALID_STYLES})"
                )
            self._style = style
            self._delimiter = delimiter
            self._date_format = date_format
            self._datetime_format = datetime_format
            self._field_order = tuple(field_order)
            self._field_specs = dict(field_specs or {})
            # Legacy default — single SHA-256 (matches Phase 1b behaviour).
            self._algorithms = ["sha256"]

    # ── Properties for inspection / wiring ──────────────────────────

    @property
    def algorithms(self) -> List[str]:
        """Algorithms the writer expects to be populated on the record
        before render().  Pipeline reads this to know which checksum
        computations to run after compression."""
        return list(self._algorithms)

    @property
    def style(self) -> str:
        return self._style

    # ── Public API ────────────────────────────────────────────────────

    def write(self, record: ControlFileRecord, output_path: os.PathLike) -> Path:
        """Write the control file.  Returns the resolved ``Path``.

        2026-08-04 — routed through the single atomic-publication primitive
        (``core.feed.publication``) so the consumer-visible ``.ctl`` name is
        only ever a complete file (many consumers treat the .ctl's appearance
        as the "feed is ready" trigger — a torn .ctl defeats its whole
        purpose).  Previously this was a hand-rolled temp+rename; atomicity
        is now structural, not per-call-site convention.
        """
        from .publication import publish_text
        text = self.render(record)
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        publish_text(text, path)
        return path

    def render(self, record: ControlFileRecord) -> str:
        """Pure rendering — no I/O.  Useful for tests."""
        gen_at = record.generated_at or datetime.now(timezone.utc)

        # Map identifier → value (or None if not populated).
        payload = self._build_payload(record, gen_at)

        # Caller-supplied extras override / extend the field list.
        ordered_keys: List[str] = list(self._field_order)
        for extra_key in record.extras.keys():
            if extra_key not in ordered_keys:
                ordered_keys.append(extra_key)
            payload[extra_key] = record.extras[extra_key]

        # Filter out fields with no value (so optional checksums don't
        # render an empty line for algorithms the format didn't request).
        rows: List[tuple] = []
        for k in ordered_keys:
            v = payload.get(k)
            if v is None:
                # Phase 4 (2026-08-23): POSITIONAL styles must keep the
                # COLUMN.  Dropping a None field shifted every later
                # column -- the seeded pipe-delimited format promised 5
                # columns and delivered 4 whenever business_date was
                # missing, and fixed-width offsets moved: the recipient's
                # parser sees a different file shape.  key_value keeps
                # the legacy behaviour (optional checksum lines absent).
                if self._style in ("delimited", "fixed_width"):
                    rows.append((self._label_for(k),
                                 self._format_value(k, "")))
                continue
            label = self._label_for(k)
            formatted = self._format_value(k, v)
            rows.append((label, formatted))

        if self._style == "key_value":
            return "\n".join(f"{lbl}={val}" for lbl, val in rows) + "\n"
        if self._style == "delimited":
            return self._delimiter.join(val for _, val in rows) + "\n"
        # fixed_width
        return "".join(val for _, val in rows) + "\n"

    # ── Internals ─────────────────────────────────────────────────────

    def _build_payload(self, record: ControlFileRecord,
                       gen_at: datetime) -> dict:
        return {
            "filename":         record.filename,
            "row_count":        record.row_count,
            "byte_size":        record.byte_size,
            "business_date":    record.business_date,
            "feed_name":        record.feed_name,
            "feed_id":          record.feed_id,
            "run_id":           record.run_id,
            "checksum_md5":     record.checksum_md5,
            "checksum_sha1":    record.checksum_sha1,
            "checksum_sha256":  record.checksum_sha256,
            "checksum_sha512":  record.checksum_sha512,
            "checksum_crc32":   record.checksum_crc32,
            "generated_at":     gen_at,
        }

    def _label_for(self, field_id: str) -> str:
        """Resolve the on-disk label.  Order: spec override → default
        UPPERCASE table → the identifier verbatim (extras)."""
        spec = self._field_specs.get(field_id) or {}
        if isinstance(spec, dict) and spec.get("label"):
            return str(spec["label"])
        return _DEFAULT_LABELS.get(field_id, field_id.upper())

    def _format_value(self, field_id: str, value: Any) -> str:
        """Convert a payload value to its on-disk string."""
        spec = self._field_specs.get(field_id) or {}
        fmt = spec.get("format") if isinstance(spec, dict) else None

        # Date / datetime — use spec override or class-level default.
        if isinstance(value, datetime):
            return value.strftime(fmt or self._datetime_format)
        if isinstance(value, date):
            return value.strftime(fmt or self._date_format)

        s = str(value)

        # Fixed-width style + per-field width → pad.
        if self._style == "fixed_width" and isinstance(spec, dict):
            width = int(spec.get("width") or 0)
            if width > 0:
                align = (spec.get("align") or "left").lower()
                pad_ch = spec.get("pad") or " "
                if len(pad_ch) > 1:
                    pad_ch = pad_ch[0]
                if align == "right":
                    s = s.rjust(width, pad_ch)[:width]
                else:
                    s = s.ljust(width, pad_ch)[:width]
        return s

    # ── Helpers ───────────────────────────────────────────────────────

    @staticmethod
    def compute_sha256(path: os.PathLike, chunk_size: int = 1024 * 1024) -> str:
        """Streaming SHA-256 helper.  Kept for backwards compat with
        existing callers; new code should use ``checksum.compute_file_checksum``
        directly or ``checksum.compute_all`` for multi-algorithm runs."""
        return compute_file_checksum(path, "sha256", chunk_size=chunk_size)
