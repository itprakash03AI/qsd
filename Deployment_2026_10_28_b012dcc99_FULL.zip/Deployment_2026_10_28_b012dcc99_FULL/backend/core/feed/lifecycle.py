"""Feed lifecycle governance — retirement, acceptance, PII, legal hold
(BRD FR-OPS-15/16, FR-ACC-02, FR-SEC-10/11) — 2026-09-03.

Four per-feed DECLARATIONS with teeth, none of which existed before:

* **retirement** (FR-OPS-15/16) — "disabled pending deletion" is now a
  STATED state with a quarantine period, distinguishable from a plain
  disable.  The audit ledger (run_events / delivery_attempts) already
  outlives a retired feed BY DESIGN (their feed_config_id columns are
  deliberately not ForeignKeys — models.py says so); this module makes
  that retention an explicit, queryable fact instead of an accident of
  schema.
* **acceptance** (FR-ACC-02) — a feed goes live because a HUMAN signed
  off on an acceptance run, not because the platform produced a file
  without erroring.  Applies to feeds onboarded AFTER this shipped
  (stamped at create/clone); existing feeds carry no acceptance record
  and are exempt — deliberately, so shipping this cannot brick a
  running estate.
* **pii** (FR-SEC-10) — a per-feed declaration, required before a NEW
  feed can be scheduled.  The DECLARATION is what is required — declaring
  "no PII" is as valid as declaring categories; silence is not.
* **legal_hold** (FR-SEC-11) — blocks feed deletion at the API (the only
  deletion path) and publishes ``legal_hold_feed_ids`` for the retention
  reaper to exclude.  The reaper itself
  (core/db/mixin_feeds.cleanup_old_feed_executions and its caller) is
  owned elsewhere — until it consults this set, reaping is NOT yet
  prevented; that gap is reported, not papered over.

Storage — ``system_settings`` rows, one key per (feed, aspect):

    feed_lifecycle.<feed_id>.<aspect>     aspect in ASPECTS

No schema change: SystemSetting is a race-safe JSON KV store already
used for runtime-tunable state.  One key per ASPECT (not one blob per
feed) so two concurrent writers of different aspects cannot clobber
each other with a read-modify-write.  The proper long-term home is
columns on feed_configs — that schema request is reported to the schema
owner; this module is the working implementation in the meantime and
the accessor seam means a later column migration changes only this
file.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

logger = logging.getLogger(__name__)

ASPECTS = ("retirement", "acceptance", "pii", "legal_hold")

#: FR-OPS-15 — default quarantine before a retired feed may be purged.
DEFAULT_QUARANTINE_DAYS = 30

_PREFIX = "feed_lifecycle."


def _key(feed_id: int, aspect: str) -> str:
    if aspect not in ASPECTS:
        raise ValueError(f"unknown lifecycle aspect {aspect!r} — one of "
                         f"{ASPECTS}")
    return f"{_PREFIX}{int(feed_id)}.{aspect}"


def _now() -> datetime:
    return datetime.now(timezone.utc)


def get_aspect(db: Any, feed_id: int, aspect: str) -> Optional[dict]:
    """One aspect record, or None when never declared."""
    rec = db.get_system_setting(_key(feed_id, aspect), None)
    return rec if isinstance(rec, dict) else None


def set_aspect(db: Any, feed_id: int, aspect: str, record: dict,
               updated_by: Optional[str] = None) -> dict:
    db.set_system_setting(
        _key(feed_id, aspect), record, updated_by=updated_by,
        description=f"feed {feed_id} lifecycle: {aspect}")
    return record


def clear_aspect(db: Any, feed_id: int, aspect: str) -> bool:
    return bool(db.delete_system_setting(_key(feed_id, aspect)))


def get_lifecycle(db: Any, feed_id: int) -> dict:
    """All four aspects for one feed (None where never declared)."""
    return {aspect: get_aspect(db, feed_id, aspect) for aspect in ASPECTS}


# ── Onboarding stamp (create + clone) ───────────────────────────────────

def stamp_onboarding(db: Any, feed_id: int, created_by: str, *,
                     cloned_from: Optional[int] = None,
                     copy_pii_from: Optional[dict] = None) -> None:
    """Mark a NEWLY onboarded feed as requiring acceptance sign-off.

    This stamp is what scopes the FR-ACC-02 gate to feeds created after
    the gate shipped: a feed with no acceptance record predates it and
    is exempt.  A clone COPIES the source's PII declaration (same source
    data, provenance recorded) but never its acceptance — a clone must
    earn its own sign-off.

    Fail-open ON PURPOSE and loudly: a settings-store hiccup must not
    fail the create that already committed the feed row — but a feed
    silently missing its stamp would silently skip the gate, so the
    failure is logged at ERROR with the feed named.
    """
    try:
        set_aspect(db, feed_id, "acceptance", {
            "required": True,
            "status": "pending",
            "stamped_at": _now().isoformat(),
            "stamped_by": created_by,
            "cloned_from": cloned_from,
        }, updated_by=created_by)
        if copy_pii_from:
            pii = dict(copy_pii_from)
            pii["copied_from_feed_id"] = cloned_from
            pii["copied_at"] = _now().isoformat()
            set_aspect(db, feed_id, "pii", pii, updated_by=created_by)
    except Exception:
        logger.error(
            "[lifecycle] could not stamp onboarding state for feed %s — "
            "the acceptance gate will NOT apply to this feed until an "
            "admin re-stamps it (sign-off endpoint creates the record)",
            feed_id, exc_info=True)


# ── Retirement (FR-OPS-15/16) ───────────────────────────────────────────

def start_retirement(db: Any, feed_id: int, *, reason: str,
                     requested_by: str,
                     quarantine_days: Optional[int] = None) -> dict:
    days = int(quarantine_days or DEFAULT_QUARANTINE_DAYS)
    if not (1 <= days <= 365):
        raise ValueError(
            f"quarantine_days must be 1..365 (got {days}) — the quarantine "
            f"is what separates 'disabled pending deletion' from 'gone'")
    now = _now()
    rec = {
        "state": "retiring",
        "reason": str(reason),
        "requested_by": requested_by,
        "requested_at": now.isoformat(),
        "quarantine_days": days,
        "quarantine_until": (now + timedelta(days=days)).isoformat(),
        # FR-OPS-16 — stated, not accidental: the audit ledger
        # (run_events / delivery_attempts) is retained regardless of this
        # feed's state; their feed_config_id columns are deliberately not
        # FKs so no cascade can erase them.
        "audit_retained": True,
    }
    return set_aspect(db, feed_id, "retirement", rec,
                      updated_by=requested_by)


def cancel_retirement(db: Any, feed_id: int, *, cancelled_by: str) -> bool:
    rec = get_aspect(db, feed_id, "retirement")
    if not rec:
        return False
    clear_aspect(db, feed_id, "retirement")
    logger.info("[lifecycle] feed %s retirement cancelled by %s "
                "(was requested by %s at %s)", feed_id, cancelled_by,
                rec.get("requested_by"), rec.get("requested_at"))
    return True


def retirement_active(db: Any, feed_id: int) -> Optional[dict]:
    rec = get_aspect(db, feed_id, "retirement")
    if rec and rec.get("state") == "retiring":
        return rec
    return None


def quarantine_remaining(rec: Optional[dict],
                         now: Optional[datetime] = None) -> Optional[float]:
    """Days of quarantine left (negative = elapsed), None when unknown."""
    if not rec:
        return None
    raw = rec.get("quarantine_until")
    if not raw:
        return None
    try:
        until = datetime.fromisoformat(str(raw))
        if until.tzinfo is None:
            until = until.replace(tzinfo=timezone.utc)
    except ValueError:
        return None
    return (until - (now or _now())).total_seconds() / 86400.0


# ── Legal hold (FR-SEC-11) ──────────────────────────────────────────────

def legal_hold_active(db: Any, feed_id: int) -> Optional[dict]:
    rec = get_aspect(db, feed_id, "legal_hold")
    if rec and rec.get("active"):
        return rec
    return None


def legal_hold_feed_ids(db: Any) -> set:
    """Every feed id under an ACTIVE legal hold.

    THE seam for retention reapers: cleanup jobs must exclude these ids
    before deleting execution/run history.  Fails CLOSED — if the store
    cannot be read the caller gets a raised error, never a silently
    empty set, because "no holds" and "could not read the holds" are
    opposite findings and a reaper acting on the wrong one destroys
    exactly what the hold exists to keep.
    """
    ids: set = set()
    for row in db.list_system_settings(_PREFIX) or []:
        key = str(row.get("key") or "")
        if not key.endswith(".legal_hold"):
            continue
        val = row.get("value")
        if isinstance(val, dict) and val.get("active"):
            middle = key[len(_PREFIX):-len(".legal_hold")]
            try:
                ids.add(int(middle))
            except ValueError:
                logger.warning("[lifecycle] unparseable legal-hold key %r",
                               key)
    return ids


# ── Acceptance gate (FR-ACC-02) ─────────────────────────────────────────

def has_successful_run(db: Any, feed_id: int) -> bool:
    """True when at least one execution or run COMPLETED for this feed.

    ``feed_has_ever_run`` is the wrong predicate here — it counts any
    attempt, and an acceptance run that failed is not an acceptance run.
    """
    from core.db.models import FeedExecution, FeedRun
    with db.get_session(read_only=True) as session:
        if session.query(FeedExecution.id).filter(
                FeedExecution.feed_config_id == int(feed_id),
                FeedExecution.status == "completed").first() is not None:
            return True
        if session.query(FeedRun.id).filter(
                FeedRun.feed_config_id == int(feed_id),
                FeedRun.status == "completed").first() is not None:
            return True
    return False


def acceptance_gate_refusals(db: Any, feed: dict) -> list:
    """Why this feed may NOT have its schedule enabled — [] when clear.

    Scope: only feeds carrying an acceptance record with
    ``required=True`` (stamped at create/clone after 2026-09-03).  A
    feed with no record predates the gate and passes — deliberately, so
    the gate cannot brick the existing estate; that posture is stated
    in the module docstring and in the report, not hidden.
    """
    feed_id = int(feed["id"])
    refusals: list = []
    acc = get_aspect(db, feed_id, "acceptance")
    if not acc or not acc.get("required"):
        return refusals
    if get_aspect(db, feed_id, "pii") is None:
        refusals.append(
            "PII declaration missing (FR-SEC-10): declare whether this "
            "feed carries PII via PUT /api/feeds/{id}/pii-declaration "
            "(contains_pii true with categories, or false) — the "
            "declaration is required, not the absence of PII.")
    if acc.get("status") != "accepted":
        refusals.append(
            "acceptance sign-off missing (FR-ACC-02): run the feed "
            "manually (POST /api/feeds/{id}/execute — the acceptance "
            "run), have the consumer verify the output, then record the "
            "sign-off via POST /api/feeds/{id}/acceptance/sign-off with "
            "contract_confirmed=true.  A feed does not go live because "
            "the platform produced a file without erroring.")
    return refusals


def record_sign_off(db: Any, feed_id: int, *, accepted_by: str,
                    contract_confirmed: bool, notes: Optional[str] = None,
                    ticket: Optional[str] = None) -> dict:
    """Record the consumer sign-off.  Caller enforces authz and the
    successful-acceptance-run precondition; this only writes the fact."""
    acc = get_aspect(db, feed_id, "acceptance") or {
        # A legacy feed being signed off voluntarily: record it (useful
        # audit) without retro-imposing the gate.
        "required": False, "status": "pending",
    }
    acc.update({
        "status": "accepted",
        "accepted_by": accepted_by,
        "accepted_at": _now().isoformat(),
        "contract_confirmed": bool(contract_confirmed),
        "notes": (str(notes).strip() or None) if notes else None,
        "ticket": (str(ticket).strip() or None) if ticket else None,
    })
    return set_aspect(db, feed_id, "acceptance", acc,
                      updated_by=accepted_by)
