"""The DAILY CLOSE-OUT DIGEST — one e-mail per feed group per business day
(2026-09-27).

At close of business a group owner wants ONE message that answers, for
their feeds and that day: what was delivered, what was not, what is still
waiting and on WHAT, and what failed at which step.  Every one of those
answers already exists on the run surface (``core/feed/run_surface.py``,
BRD §13.1) -- this module COMPOSES them per group and mails the result.
It runs no new query it can get from the surface and adds no state of its
own beyond the "already sent" marker.

How it runs
-----------
It is a daemon with the three edits the platform requires
(``core/retention_daemons.py::JOB_IDS``, ``core/daemon_registry.py::
SCHEDULER_OWNED``, the literal ``_daemon_allowed("feed_close_out_digest")``
in ``main.py``).  The registered job is a TICK every
``feed_generation.close_out_digest_check_interval_seconds``; the tick
sends only once the configured ``close_out_digest_time_utc`` has passed
for today's business date, and only once per (group, date) -- the marker
is a system setting, so two pods ticking cannot send twice (the second
reads the first's mark).  Declared config, default ON at 18:00 UTC.

A deployment with no mail relay is a NO-OP that says so: the tick returns
``status="unconfigured"`` with ``email_service.NOT_CONFIGURED_REASON`` and
logs it once per process, never every five minutes.  The admin preview
route (``api/feed_close_out_api.py``) shows the digest WITHOUT sending it,
mailer or not.

Recipients are the feed group's ``notification_email`` (feed_groups, the
operational group -- not the ACL group).  A group with feeds and no
address is listed in the preview as "no recipients" and skipped by the
sender; it is never silently dropped.
"""
from __future__ import annotations

import html as _html
import logging
from datetime import date, datetime, timezone
from typing import Any, Callable, Optional

from core.feed import run_surface

logger = logging.getLogger(__name__)

#: THE job id -- retention_daemons.JOB_IDS, daemon_registry.SCHEDULER_OWNED
#: and main.py's literal gate all spell exactly this.
JOB_ID = "feed_close_out_digest"

#: The "already sent" marker: ``{"<business_date>": {"<group_id>": iso}}``.
SENT_SETTING_KEY = "feed_close_out_digest.sent"
#: How many business dates the marker keeps (older entries are pruned).
SENT_KEEP_DATES = 14
#: One ``system_settings`` row per (business date, group) CLAIMED before the
#: send: ``feed_close_out_digest.claim.<YYYY-MM-DD>.<group_id>``.  The
#: aggregate marker above is the human-readable record and the admin
#: status's source; this row is the lock.  See :func:`_claim`.
CLAIM_KEY_PREFIX = "feed_close_out_digest.claim."
#: A claim older than this with no marker behind it is a ticker that died
#: mid-send; the next ticker takes it over rather than leaving the group
#: unsent for the day.
CLAIM_TAKEOVER_SECONDS = 15 * 60

#: Section names, in the order the e-mail shows them.
SECTIONS = ("delivered", "not_delivered", "waiting", "failed", "no_run")

_LOGGED_UNCONFIGURED = {"done": False}


# ── config ────────────────────────────────────────────────────────────────

def load_config() -> dict:
    """The three declared keys, read through the config object."""
    from core.config import get as _get
    enabled = bool(_get("feed_generation", "close_out_digest_enabled", True))
    raw_time = str(_get("feed_generation", "close_out_digest_time_utc",
                        "18:00") or "18:00")
    interval = int(_get("feed_generation",
                        "close_out_digest_check_interval_seconds", 300)
                   or 300)
    return {"enabled": enabled, "time_utc": raw_time,
            "check_interval_seconds": max(interval, 60)}


def parse_time_utc(raw: str) -> tuple[int, int]:
    """``"HH:MM"`` -> (hour, minute).  A malformed value REFUSES (ValueError)
    rather than defaulting: a digest that quietly moved to midnight is a
    digest nobody reads."""
    parts = str(raw or "").strip().split(":")
    if len(parts) != 2:
        raise ValueError(
            f"close_out_digest_time_utc {raw!r} is not HH:MM")
    h, m = int(parts[0]), int(parts[1])
    if not (0 <= h <= 23 and 0 <= m <= 59):
        raise ValueError(
            f"close_out_digest_time_utc {raw!r} is not a time of day")
    return h, m


def is_due(now: datetime, time_utc: str) -> bool:
    h, m = parse_time_utc(time_utc)
    now = now.astimezone(timezone.utc)
    return (now.hour, now.minute) >= (h, m)


def business_date_for(now: datetime) -> date:
    return now.astimezone(timezone.utc).date()


# ── composition ───────────────────────────────────────────────────────────

def _recipients(group: dict) -> list[str]:
    raw = str(group.get("notification_email") or "")
    return [a.strip() for a in raw.replace(";", ",").split(",")
            if a.strip()]


def _feed_label(feed: dict) -> str:
    return str(feed.get("display_name") or feed.get("name")
               or f"feed {feed.get('id')}")


def classify_group(db: Any, business_date: date, group: dict,
                   feeds: list[dict], *, surface: Optional[dict] = None,
                   ) -> dict:
    """One group's digest body: the five sections, from the run surface.

    ``surface`` is ``run_surface.build_surface(...)`` for the date, built
    ONCE by the caller for every group.  A section the surface could not
    read is reported as unavailable here too -- an empty "failed" list on a
    night the failures table was unreadable is the lie this platform keeps
    refusing to tell.
    """
    surface = surface or run_surface.build_surface(
        db, business_date=business_date)
    sections = surface.get("sections") or {}
    feed_ids = {int(f["id"]) for f in feeds if f.get("id") is not None}
    by_id = {int(f["id"]): f for f in feeds if f.get("id") is not None}

    def _rows(name: str) -> list:
        sec = sections.get(name) or {}
        return [r for r in (sec.get("rows") or [])
                if r.get("feed_config_id") is not None
                and int(r["feed_config_id"]) in feed_ids]

    unavailable = [n for n in ("blocked", "failures")
                   if (sections.get(n) or {}).get("unavailable")]

    failed = [{
        "feed_config_id": r.get("feed_config_id"),
        "feed": _feed_label(by_id.get(int(r["feed_config_id"]), {})),
        "feed_run_id": r.get("feed_run_id"),
        "step": r.get("failed_stage") or "(step not recorded)",
        "error": (str(r.get("error") or "")[:300]),
        "execution_id": r.get("execution_id"),
    } for r in _rows("failures")]

    waiting = [{
        "feed_config_id": r.get("feed_config_id"),
        "feed": _feed_label(by_id.get(int(r["feed_config_id"]), {})),
        "feed_run_id": r.get("feed_run_id"),
        "waiting_on": [b.get("dependency") for b in (r.get("blocking") or [])
                       if b.get("dependency")],
        "reasons": [b.get("reason") for b in (r.get("blocking") or [])
                    if b.get("reason")],
    } for r in _rows("blocked")]

    # The delivered / not-delivered split comes from the day's SCHEDULED
    # runs (manual Run Now and dry runs are excluded by the DAO's default,
    # exactly as the run surface reads them).
    delivered: list[dict] = []
    not_delivered: list[dict] = []
    seen: set[int] = set()
    try:
        day_runs = db.list_feed_runs(business_date=business_date,
                                     limit=None) or []
    except Exception as exc:  # noqa: BLE001
        logger.error("[close_out_digest] the day's runs could not be read "
                     "(%s) -- delivered/not-delivered are unavailable", exc)
        day_runs = []
        unavailable.append("runs")
    failed_ids = {int(r["feed_run_id"]) for r in failed
                  if r.get("feed_run_id") is not None}
    waiting_ids = {int(r["feed_run_id"]) for r in waiting
                   if r.get("feed_run_id") is not None}
    for run in day_runs:
        fid = run.get("feed_config_id")
        if fid is None or int(fid) not in feed_ids:
            continue
        seen.add(int(fid))
        rid = run.get("id")
        if rid in failed_ids or rid in waiting_ids:
            continue
        status = str(run.get("status") or "").lower()
        entry = {"feed_config_id": fid,
                 "feed": _feed_label(by_id.get(int(fid), {})),
                 "feed_run_id": rid, "status": status,
                 "rows": run.get("total_rows"),
                 "output_path": run.get("output_path"),
                 "completed_at": run.get("completed_at")}
        if status == "completed" and run.get("output_path"):
            delivered.append(entry)
        else:
            entry["reason"] = (
                "completed without a destination (delivery suppressed)"
                if status == "completed" else
                "skipped by ACTION_CONDITION" if status == "skipped" else
                "cancelled" if status == "cancelled" else
                "still running at close-out" if status == "running" else
                "not yet started at close-out" if status == "pending" else
                status or "unknown")
            if status == "skipped" and run.get("action_reason"):
                entry["reason"] += f": {run.get('action_reason')}"
            not_delivered.append(entry)

    no_run = [{"feed_config_id": f["id"], "feed": _feed_label(f),
               "reason": "no run row exists for this date"}
              for f in feeds
              if f.get("id") is not None and int(f["id"]) not in seen
              and int(f["id"]) not in {int(r["feed_config_id"])
                                       for r in failed + waiting}]

    return {
        "group": {"id": group.get("id"), "name": group.get("name"),
                  "display_label": group.get("display_label")},
        "business_date": business_date.isoformat(),
        "feed_count": len(feeds),
        "recipients": _recipients(group),
        "sections": {"delivered": delivered, "not_delivered": not_delivered,
                     "waiting": waiting, "failed": failed, "no_run": no_run},
        "counts": {"delivered": len(delivered),
                   "not_delivered": len(not_delivered),
                   "waiting": len(waiting), "failed": len(failed),
                   "no_run": len(no_run)},
        "unavailable_sections": sorted(set(unavailable)),
    }


def subject_for(digest: dict) -> str:
    c = digest["counts"]
    g = digest["group"]
    return (f"[QueryStudio] Close-out {g.get('name')} {digest['business_date']}"
            f": {c['delivered']} delivered, {c['not_delivered']} not "
            f"delivered, {c['waiting']} waiting, {c['failed']} failed")


def render_html(digest: dict) -> str:
    """A plain, mail-client-safe rendering: five headed lists, the facts
    each section exists to carry, and the gaps NAMED at the top."""
    e = _html.escape
    g = digest["group"]
    c = digest["counts"]
    s = digest["sections"]
    parts = [
        f"<h2>Close-out digest — {e(str(g.get('display_label') or g.get('name')))}"
        f" — {e(digest['business_date'])}</h2>",
        f"<p>{digest['feed_count']} feed(s) in group: "
        f"<b>{c['delivered']}</b> delivered, <b>{c['not_delivered']}</b> not "
        f"delivered, <b>{c['waiting']}</b> waiting, <b>{c['failed']}</b> "
        f"failed, <b>{c['no_run']}</b> with no run.</p>",
    ]
    if digest.get("unavailable_sections"):
        parts.append(
            "<p style='color:#b00'><b>Some answers could not be read:</b> "
            + e(", ".join(digest["unavailable_sections"]))
            + ". An empty list below is NOT evidence for those.</p>")

    def _list(title: str, rows: list, fmt: Callable[[dict], str]) -> None:
        parts.append(f"<h3>{e(title)} ({len(rows)})</h3>")
        if not rows:
            parts.append("<p><i>none</i></p>")
            return
        parts.append("<ul>" + "".join(f"<li>{fmt(r)}</li>" for r in rows)
                     + "</ul>")

    _list("Delivered", s["delivered"],
          lambda r: f"{e(r['feed'])} — {r.get('rows') if r.get('rows') is not None else '?'} rows"
                    f" → {e(str(r.get('output_path') or ''))}")
    _list("Not delivered", s["not_delivered"],
          lambda r: f"{e(r['feed'])} — {e(str(r.get('reason') or ''))}")
    _list("Waiting", s["waiting"],
          lambda r: f"{e(r['feed'])} — waiting on "
                    f"{e(', '.join(r.get('waiting_on') or []) or '(unnamed dependency)')}"
                    + (f" <small>({e('; '.join(r.get('reasons') or []))})</small>"
                       if r.get("reasons") else ""))
    _list("Failed", s["failed"],
          lambda r: f"{e(r['feed'])} — at step <b>{e(str(r.get('step')))}</b>"
                    f": {e(str(r.get('error') or ''))}")
    _list("No run", s["no_run"],
          lambda r: f"{e(r['feed'])} — {e(str(r.get('reason') or ''))}")
    parts.append("<p style='color:#666'><small>Sent by the QueryStudio "
                 "feed close-out digest.</small></p>")
    return "\n".join(parts)


def build_digests(db: Any, business_date: date, *,
                  group_id: Optional[int] = None) -> dict:
    """Every active group's digest (or one group's), WITHOUT sending.

    The surface is built once; each group is composed from it.  A group
    with no feeds is still listed (so "why did I get nothing" is
    answerable), marked ``sendable=False`` with the reason.
    """
    surface = run_surface.build_surface(db, business_date=business_date)
    groups = db.list_feed_groups(is_active=True) or []
    if group_id is not None:
        groups = [g for g in groups if int(g.get("id")) == int(group_id)]
    out = []
    for group in groups:
        feeds = [f for f in (db.list_feed_configs_in_group(int(group["id"]))
                             or []) if f.get("is_active", True)]
        digest = classify_group(db, business_date, group, feeds,
                                surface=surface)
        digest["subject"] = subject_for(digest)
        digest["html"] = render_html(digest)
        if not feeds:
            digest["sendable"] = False
            digest["skip_reason"] = "the group has no active feeds"
        elif not digest["recipients"]:
            digest["sendable"] = False
            digest["skip_reason"] = ("the group has no notification_email "
                                     "-- set one on the feed group")
        else:
            digest["sendable"] = True
            digest["skip_reason"] = None
        out.append(digest)
    return {"business_date": business_date.isoformat(),
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "surface_unavailable_sections":
                surface.get("unavailable_sections") or [],
            "groups": out}


# ── sending ───────────────────────────────────────────────────────────────

def _read_marker(db: Any) -> dict:
    try:
        raw = db.get_system_setting(SENT_SETTING_KEY, {}) or {}
        return dict(raw) if isinstance(raw, dict) else {}
    except Exception as exc:  # noqa: BLE001
        logger.error("[close_out_digest] the sent-marker could not be read "
                     "(%s) -- refusing to send rather than risk a duplicate",
                     exc)
        raise


def _write_marker(db: Any, marker: dict) -> None:
    dates = sorted(marker.keys())
    for old in dates[:-SENT_KEEP_DATES]:
        marker.pop(old, None)
    db.set_system_setting(SENT_SETTING_KEY, marker,
                          updated_by=JOB_ID,
                          description="feed close-out digest: sent per "
                                      "(business_date, feed_group_id)")
    _prune_claims(db, keep_from=(dates[-SENT_KEEP_DATES] if len(dates) > SENT_KEEP_DATES
                                 else (dates[0] if dates else None)))


def _claim(db: Any, bd_key: str, gid: str, now: datetime) -> bool:
    """INSERT-FIRST: this ticker owns the send of (date, group), or another
    one does.

    2026-10-08 (found while designing the Docker proof that counts the
    digest mails -- the rig runs this job on TWO pods: the scheduler's
    APScheduler job and the hybrid api pod's thread).  ``send_digests``
    read the aggregate marker once, mailed, then rewrote the whole dict:
    two tickers in the same window both saw the group unsent and both
    mailed, and the second write could drop the first's marks for other
    groups.  A row with the (date, group) in its KEY is the lock the
    marker never was: the primary key refuses the second insert.  A
    double without sessions (a test's fake DAO) keeps the marker-only
    path -- the claim is the product's rule, not the double's.
    """
    if not hasattr(db, "get_session"):
        return True
    from sqlalchemy.exc import IntegrityError
    from core.db.models import SystemSetting
    key = f"{CLAIM_KEY_PREFIX}{bd_key}.{gid}"
    try:
        with db.get_session() as session:
            session.add(SystemSetting(
                key=key, value={"claimed_at": now.isoformat()},
                description="feed close-out digest: send claimed by one ticker",
                updated_by=JOB_ID, updated_at=now))
            session.flush()
        return True
    except IntegrityError:
        pass
    # held by another ticker -- unless that ticker died mid-send long ago
    try:
        with db.get_session() as session:
            row = session.query(SystemSetting).filter(SystemSetting.key == key).first()
            claimed_at = None
            if row is not None and isinstance(row.value, dict):
                try:
                    claimed_at = datetime.fromisoformat(str(row.value.get("claimed_at")))
                except (TypeError, ValueError):
                    claimed_at = None
            if claimed_at is not None and claimed_at.tzinfo is None:
                claimed_at = claimed_at.replace(tzinfo=timezone.utc)
            if row is not None and claimed_at is not None and \
                    (now - claimed_at).total_seconds() > CLAIM_TAKEOVER_SECONDS:
                logger.warning("[close_out_digest] taking over a %ds-old claim for "
                               "%s / group %s (the ticker that made it never "
                               "marked the send)", int((now - claimed_at).total_seconds()),
                               bd_key, gid)
                row.value = {"claimed_at": now.isoformat(), "taken_over": True}
                row.updated_at = now
                session.flush()
                return True
    except Exception as exc:  # noqa: BLE001
        logger.error("[close_out_digest] claim for %s / group %s could not be "
                     "read (%s) -- not sending", bd_key, gid, exc)
    return False


def _release_claim(db: Any, bd_key: str, gid: str) -> None:
    """A send that FAILED gives the claim back so the next tick retries."""
    if not hasattr(db, "get_session"):
        return
    try:
        from core.db.models import SystemSetting
        with db.get_session() as session:
            session.query(SystemSetting).filter(
                SystemSetting.key == f"{CLAIM_KEY_PREFIX}{bd_key}.{gid}").delete(
                    synchronize_session=False)
    except Exception as exc:  # noqa: BLE001
        logger.error("[close_out_digest] claim for %s / group %s could not be "
                     "released (%s) -- a later tick may take it over", bd_key, gid, exc)


def _prune_claims(db: Any, *, keep_from: Optional[str]) -> None:
    """Drop claim rows for dates older than the marker keeps."""
    if keep_from is None or not hasattr(db, "get_session"):
        return
    try:
        from core.db.models import SystemSetting
        with db.get_session() as session:
            rows = session.query(SystemSetting).filter(
                SystemSetting.key.like(f"{CLAIM_KEY_PREFIX}%")).all()
            for row in rows:
                tail = row.key[len(CLAIM_KEY_PREFIX):]
                if tail[:10] < keep_from:
                    session.delete(row)
    except Exception as exc:  # noqa: BLE001
        logger.debug("[close_out_digest] claim prune failed: %s", exc)


def send_digests(db: Any, business_date: date, *,
                 mailer: Optional[Callable[..., bool]] = None,
                 now: Optional[datetime] = None) -> dict:
    """Send every sendable, not-yet-sent group digest for ``business_date``.

    Returns ``{"sent": [...], "skipped": [{group, reason}], "failed":
    [...]}``.  The marker is written per group right after ITS send, so a
    crash mid-loop re-sends only the groups that never got theirs.
    """
    from core import email_service
    mailer = mailer or email_service.send_email
    now = now or datetime.now(timezone.utc)
    bd_key = business_date.isoformat()
    marker = _read_marker(db)
    already = dict(marker.get(bd_key) or {})
    result: dict = {"business_date": bd_key, "sent": [], "skipped": [],
                    "failed": []}
    built = build_digests(db, business_date)
    for digest in built["groups"]:
        gid = str(digest["group"]["id"])
        gname = digest["group"]["name"]
        if gid in already:
            result["skipped"].append(
                {"group": gname, "reason": f"already sent at {already[gid]}"})
            continue
        if not digest.get("sendable"):
            result["skipped"].append(
                {"group": gname, "reason": digest.get("skip_reason")})
            continue
        if not _claim(db, bd_key, gid, now):
            result["skipped"].append(
                {"group": gname,
                 "reason": "being sent by another ticker (claim held)"})
            continue
        try:
            email_service.clear_send_failure_reason()
        except Exception:  # noqa: BLE001 - a test double may lack it
            pass
        ok = False
        try:
            ok = bool(mailer(digest["recipients"], digest["subject"],
                             digest["html"]))
        except Exception as exc:  # noqa: BLE001
            logger.error("[close_out_digest] group %s: the mailer raised "
                         "(%s)", gname, exc)
        if ok:
            already[gid] = now.isoformat()
            marker[bd_key] = already
            try:
                _write_marker(db, marker)
            except Exception as exc:  # noqa: BLE001
                logger.error("[close_out_digest] group %s digest SENT but "
                             "the marker could not be written (%s) -- a "
                             "later tick may send it again", gname, exc)
            result["sent"].append({"group": gname,
                                   "recipients": digest["recipients"],
                                   "subject": digest["subject"]})
            logger.info("[close_out_digest] sent %s to %s", gname,
                        digest["recipients"])
        else:
            _release_claim(db, bd_key, gid)
            reason = ""
            try:
                reason = email_service.last_send_failure_reason()
            except Exception:  # noqa: BLE001
                pass
            result["failed"].append({"group": gname,
                                     "reason": reason or "mailer returned False"})
            logger.error("[close_out_digest] group %s digest NOT sent: %s",
                         gname, reason or "mailer returned False")
    return result


def run_close_out_digest_tick(db: Any, *, now: Optional[datetime] = None,
                              mailer: Optional[Callable[..., bool]] = None,
                              ) -> dict:
    """The daemon's tick.  Cheap when nothing is due; idempotent per
    (group, business date); a NO-OP that says so when disabled or when no
    mailer is configured."""
    from core import email_service
    cfg = load_config()
    if not cfg["enabled"]:
        return {"status": "disabled"}
    if mailer is None and not email_service.is_email_enabled():
        if not _LOGGED_UNCONFIGURED["done"]:
            logger.warning("[close_out_digest] enabled but %s -- no digest "
                           "will be sent (said once per process)",
                           email_service.NOT_CONFIGURED_REASON)
            _LOGGED_UNCONFIGURED["done"] = True
        return {"status": "unconfigured",
                "reason": email_service.NOT_CONFIGURED_REASON}
    now = now or datetime.now(timezone.utc)
    try:
        due = is_due(now, cfg["time_utc"])
    except ValueError as exc:
        logger.error("[close_out_digest] %s -- not sending", exc)
        return {"status": "misconfigured", "reason": str(exc)}
    if not due:
        return {"status": "not_due", "due_at_utc": cfg["time_utc"]}
    bd = business_date_for(now)
    outcome = send_digests(db, bd, mailer=mailer, now=now)
    outcome["status"] = "ran"
    return outcome


def status(db: Any) -> dict:
    """What the admin status route shows: config + the sent marker."""
    cfg = load_config()
    try:
        marker = _read_marker(db)
    except Exception as exc:  # noqa: BLE001
        marker = {"unavailable": str(exc)}
    return {"job_id": JOB_ID, "config": cfg, "sent": marker}
