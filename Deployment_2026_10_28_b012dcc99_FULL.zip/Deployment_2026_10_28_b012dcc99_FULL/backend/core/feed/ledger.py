"""Foundation L — the append-only event ledger (BRD 2026-09-02).

The API over the ``run_events`` and ``dependency_events`` tables.  Three
design rules from the BRD, enforced here rather than hoped for:

1.  **Append-only** (§7.2).  Every arrival is a NEW ROW — never an upsert.
    The old dependency-tracking row was unique on (type, key,
    business_date), which made a second arrival an upsert and replay
    "undecidable in principle" (§4).  Nothing in this module updates or
    deletes a ledger row; state is always DERIVED from the log.

2.  **Fail-open writes, audible refusals** (hard requirement 2, FR-DEP-04).
    A ledger write must never fail a feed run, so every write path catches
    and returns instead of raising — but always logs at ERROR with the
    reason.  Silence is never an outcome.

3.  **Replay vs redelivery** (§7.5).  A second arrival for
    ``(dependency, business_date)`` whose ``message_identity`` differs from
    every prior one is a REPLAY (upstream re-sent corrected data); an
    identical identity is a Kafka redelivery (at-least-once transport
    noise).  The two demand opposite responses, and only the identity on
    the row can tell them apart.

Reads (:func:`arrivals_for`, :func:`derive_dependency_state`) deliberately
PROPAGATE db errors: a gate that cannot read the ledger must report
"could not tell", never "not met" (§7.4) — swallowing the error here
would convert one into the other.

The ``db`` seam is any object exposing the FeedsMixin ledger methods
(``insert_run_event``, ``insert_dependency_event``,
``list_dependency_events``, ``list_dependency_first_arrivals``), so tests
run against a fake and callers pass the DatabaseManager.
"""
from __future__ import annotations

import logging
import math
from collections.abc import Callable
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from typing import Any

# The single source of both vocabularies — the same tuples build the DB
# CHECK constraints, so the API refusal and the database can never drift.
from core.db.models import DEPENDENCY_EVENT_SOURCES, RUN_EVENT_TYPES

logger = logging.getLogger(__name__)

# ── Arrival classifications (BRD §7.5) ─────────────────────────────────────
ARRIVAL_FIRST = "first"              # no prior arrival for the key
ARRIVAL_REDELIVERY = "redelivery"    # identical identity already seen — transport noise
ARRIVAL_REPLAY = "replay"            # DIFFERENT identity for the same key — upstream re-sent
ARRIVAL_UNDECIDABLE = "undecidable"  # prior arrivals unreadable / identity missing — never guess (§7.4)

# FR-SLA-04: below this many observations a profile must SAY it is weak
# and the caller falls back to the decision deadline alone.
HIGH_CONFIDENCE_MIN_OBSERVATIONS = 30

# Day types the profile is segmented by when a classifier is available
# (§8.2).  'normal' is also the honest label for an UNSEGMENTED profile
# when no classifier has been wired yet.
_UNSEGMENTED_DAY_TYPES = (None, "", "any", "normal")


@dataclass(frozen=True)
class ArrivalResult:
    """What one call to :func:`record_dependency_arrival` did and found."""
    classification: str            # first | redelivery | replay | undecidable
    recorded: bool                 # False when the row could not be written (fail-open)
    prior_arrivals: int            # rows that existed BEFORE this arrival
    event: dict[str, Any] | None = None   # the appended row, when recorded

    @property
    def is_replay(self) -> bool:
        return self.classification == ARRIVAL_REPLAY

    @property
    def is_redelivery(self) -> bool:
        return self.classification == ARRIVAL_REDELIVERY


@dataclass(frozen=True)
class DependencyState:
    """Current state as a PROJECTION over the arrival log — the log is the
    source of truth; nothing here is stored anywhere (§7.2)."""
    dependency_name: str
    business_date: date
    met: bool
    arrival_count: int
    distinct_identities: int
    replay_seen: bool              # more than one distinct identity arrived
    first_arrived_at: Any | None
    last_arrived_at: Any | None
    #: FR-DEP-24 — rows the upstream reported, from the LATEST arrival
    #: that carried a count.  Latest, not the sum: a replay re-sends the
    #: whole load, so summing would report double what was ever loaded and
    #: turn a healthy replay into a silent all-clear.  ``None`` means no
    #: arrival said -- which is not zero.
    reported_rows: int | None = None


@dataclass(frozen=True)
class ArrivalProfile:
    """When a dependency normally arrives, per business-day type (§8.2).

    Percentiles are seconds since midnight UTC of the FIRST arrival per
    business date.  ``confidence`` is 'high' only at
    >= HIGH_CONFIDENCE_MIN_OBSERVATIONS observations; below that the
    caller must fall back to the decision deadline rather than page
    anyone on the strength of four data points (FR-SLA-04).
    ``segmented`` is False when no day-type classifier was available, so
    a consumer can tell a real 'normal-day' profile from an unsegmented
    everything-profile.
    """
    dependency_name: str
    day_type: str | None
    observations: int
    confidence: str                # 'high' | 'low'
    p50: float | None           # seconds since midnight UTC
    p90: float | None
    p95: float | None
    max: float | None
    segmented: bool = True

    def to_dict(self) -> dict[str, Any]:
        return {
            "dependency_name": self.dependency_name,
            "day_type": self.day_type,
            "observations": self.observations,
            "confidence": self.confidence,
            "p50": self.p50,
            "p90": self.p90,
            "p95": self.p95,
            "max": self.max,
            "p50_time": format_seconds_of_day(self.p50),
            "p90_time": format_seconds_of_day(self.p90),
            "p95_time": format_seconds_of_day(self.p95),
            "max_time": format_seconds_of_day(self.max),
            "segmented": self.segmented,
        }


# ── Writes (fail-open, audible) ────────────────────────────────────────────

def record_run_event(db, *, feed_config_id: int, business_date: date,
                     event_type: str, subject: str | None = None,
                     actor: str | None = None,
                     build_id: str | None = None,
                     payload: dict[str, Any] | None = None,
                     ) -> dict[str, Any] | None:
    """Append one run/step/decision event.  Never raises.

    Returns the appended row as a dict, or ``None`` when the event was
    refused (event_type outside the closed vocabulary) or the write
    failed — both logged at ERROR, never silent.
    """
    if event_type not in RUN_EVENT_TYPES:
        logger.error(
            "[ledger] REFUSED run event: event_type=%r is not in the closed "
            "vocabulary (feed_config_id=%s business_date=%s subject=%r). "
            "The event was NOT recorded. Valid types: %s",
            event_type, feed_config_id, business_date, subject,
            ", ".join(RUN_EVENT_TYPES))
        return None
    row = {
        "feed_config_id": feed_config_id,
        "business_date": business_date,
        "event_type": event_type,
        "subject": subject,
        "actor": actor,
        "build_id": build_id,
        "payload": payload,
    }
    try:
        return db.insert_run_event(row)
    except Exception as exc:  # noqa: BLE001 — deliberate fail-open (hard req 2): a ledger write must never fail a feed
        logger.error(
            "[ledger] run event write FAILED (fail-open — the caller's run "
            "continues, but this event is LOST): feed_config_id=%s "
            "business_date=%s event_type=%s subject=%r error=%s",
            feed_config_id, business_date, event_type, subject, exc)
        return None


def record_dependency_arrival(db, *, dependency_name: str,
                              business_date: date, source: str,
                              message_identity: str,
                              payload: dict[str, Any] | None = None,
                              reported_rows: int | None = None,
                              source_key: str | None = None,
                              ) -> ArrivalResult:
    """Append one arrival and classify it against the PRE-EXISTING log.

    Classification (§7.5) — the point of the whole foundation:
      * ``first``       — no prior arrival for (dependency, business_date)
      * ``redelivery``  — an IDENTICAL message_identity was already seen
                          (at-least-once transport noise; dedupe, no alarm)
      * ``replay``      — a DIFFERENT identity for the same key (upstream
                          re-sent; the run/delivery decision ladder applies)
      * ``undecidable`` — the prior log could not be read, or the identity
                          is missing; stated explicitly, never guessed.

    ``source_key`` (2026-10-08) names WHICH declared source of the
    dependency this arrival satisfies -- ``kafka:<topic>``,
    ``iceberg:<bucket>/<prefix>``, a file declaration's spec key.  The
    classification is keyed by it: a dependency that declares two Kafka
    topics gets its second topic's FIRST message classified ``first``, not
    ``replay`` of the first topic's (a replay raises a regeneration
    decision, and the second half of an "all" dependency arriving is not
    a re-send).  Prior rows with NO key (an operator's, a legacy producer's)
    count against every key, and an arrival with no key is compared with
    every prior row -- the pre-2026-10-08 rule, unchanged for them.

    Every arrival is a NEW ROW — a redelivery is still appended, because
    "did it arrive twice, and when?" must stay answerable a year later
    (§7.2).  Never raises; a failed write returns ``recorded=False`` after
    an ERROR log.
    """
    if source not in DEPENDENCY_EVENT_SOURCES:
        logger.error(
            "[ledger] REFUSED dependency arrival: source=%r is not in the "
            "closed vocabulary %s (dependency=%s business_date=%s "
            "message_identity=%r). The arrival was NOT recorded.",
            source, DEPENDENCY_EVENT_SOURCES, dependency_name,
            business_date, message_identity)
        return ArrivalResult(ARRIVAL_UNDECIDABLE, False, 0)
    if message_identity is None or not str(message_identity).strip():
        logger.error(
            "[ledger] REFUSED dependency arrival with EMPTY message_identity "
            "(dependency=%s business_date=%s source=%s): without an identity, "
            "replay vs redelivery is undecidable in principle (BRD §7.5). "
            "The arrival was NOT recorded.",
            dependency_name, business_date, source)
        return ArrivalResult(ARRIVAL_UNDECIDABLE, False, 0)

    # Classify against the rows that existed BEFORE this arrival.
    prior: list[dict[str, Any]] | None
    try:
        prior = db.list_dependency_events(dependency_name, business_date)
    except Exception as exc:  # noqa: BLE001 — deliberate fail-open (hard req 2): a ledger write must never fail a feed
        logger.error(
            "[ledger] could not read prior arrivals for %s @ %s — this "
            "arrival is UNDECIDABLE (not assumed first, not assumed replay): %s",
            dependency_name, business_date, exc)
        prior = None

    if prior is not None:
        prior = same_source_rows(prior, source_key)
    if prior is None:
        classification, prior_count = ARRIVAL_UNDECIDABLE, 0
    elif not prior:
        classification, prior_count = ARRIVAL_FIRST, 0
    elif any(p.get("message_identity") == message_identity for p in prior):
        classification, prior_count = ARRIVAL_REDELIVERY, len(prior)
    else:
        classification, prior_count = ARRIVAL_REPLAY, len(prior)

    row = {
        "dependency_name": dependency_name,
        "business_date": business_date,
        "arrived_at": datetime.now(timezone.utc),
        "source": source,
        "message_identity": message_identity,
        "payload": payload,
        # FR-DEP-24 — what the upstream SAID it loaded.  None when the
        # message did not say; never coerced to 0.
        "reported_rows": reported_rows,
        "source_key": (str(source_key)[:500] if source_key else None),
    }
    try:
        event = db.insert_dependency_event(row)   # NEW ROW, always
        if classification == ARRIVAL_REPLAY:
            # FR-DEP-10/18/20 (2026-09-03) — the replay classification's
            # first real consumer.  THIS is the chokepoint every arrival
            # transport goes through, so raising here means no future
            # producer can forget to: a replay landing after a feed has
            # already run raises a first-class regeneration decision
            # (evidence + cascade + ledger events) instead of ending as a
            # log-line suffix.  Fail-open on its own — the arrival itself
            # is already recorded and must never be lost to decision
            # bookkeeping (on_replay_detected never raises, but the
            # import itself must not take the arrival down either).
            try:
                from core.feed.regeneration import on_replay_detected
                on_replay_detected(db, dependency_name=dependency_name,
                                   business_date=business_date,
                                   arrival_event=event)
            except Exception as _exc:  # noqa: BLE001 — deliberate fail-open (hard req 2)
                logger.error(
                    "[ledger] replay of %r @ %s recorded, but the "
                    "regeneration decision could not be raised: %s",
                    dependency_name, business_date, _exc)
        return ArrivalResult(classification, True, prior_count, event)
    except Exception as exc:  # noqa: BLE001 — deliberate fail-open (hard req 2): a ledger write must never fail a feed
        logger.error(
            "[ledger] dependency arrival write FAILED (fail-open — the "
            "arrival is LOST from the ledger): dependency=%s "
            "business_date=%s source=%s message_identity=%r error=%s",
            dependency_name, business_date, source, message_identity, exc)
        return ArrivalResult(classification, False, prior_count)


def same_source_rows(events: list[dict[str, Any]],
                     source_key: str | None) -> list[dict[str, Any]]:
    """The ledger rows that count for ONE declared source (2026-10-08).

    ``source_key`` None -> every row.  Otherwise the rows carrying that key
    plus the rows carrying none (an operator's arrival, a row written
    before the column existed) -- an untagged arrival is for the
    dependency as a whole and satisfies every declared source of it.  THE
    one filter; every evaluator and the classifier above read through it.
    """
    if not source_key:
        return list(events or [])
    key = str(source_key)
    return [e for e in (events or [])
            if e.get("source_key") in (None, "", key)]


# ── Reads (state is a projection; db errors PROPAGATE — §7.4) ─────────────

def arrivals_for(db, dependency_name: str,
                 business_date: date) -> list[dict[str, Any]]:
    """Every arrival for (dependency, business_date), in arrival order.

    Propagates db errors: the caller must distinguish "no arrivals" from
    "could not read the ledger" (§7.4).
    """
    return list(db.list_dependency_events(dependency_name, business_date))


def derive_dependency_state(db, dependency_name: str,
                            business_date: date) -> DependencyState:
    """Current met / not-met state DERIVED from the arrival log.

    Nothing is stored: delete a log row and the state changes, because the
    ledger is the source of truth and this is a projection (§7.2).
    Propagates db errors — see :func:`arrivals_for`.
    """
    events = arrivals_for(db, dependency_name, business_date)
    identities = {e.get("message_identity") for e in events}
    return DependencyState(
        dependency_name=dependency_name,
        business_date=business_date,
        met=bool(events),
        arrival_count=len(events),
        distinct_identities=len(identities),
        replay_seen=len(identities) > 1,
        first_arrived_at=events[0].get("arrived_at") if events else None,
        last_arrived_at=events[-1].get("arrived_at") if events else None,
        reported_rows=_latest_reported_rows(events),
    )


def _latest_reported_rows(events: list[dict[str, Any]]) -> int | None:
    """The count from the LAST arrival that carried one.

    Latest rather than summed: a replay re-sends the whole load, so a sum
    would report double what was ever loaded and an under-loaded upstream
    that replayed would clear its own alarm.  Arrivals that carried no
    count are stepped over rather than treated as 0 -- one countless
    redelivery after a good message must not erase the good count.
    """
    for event in reversed(events):
        raw = event.get("reported_rows")
        if raw is None:
            continue
        try:
            return int(raw)
        except (TypeError, ValueError):
            continue
    return None


# ── Arrival profiles (§8.2) ────────────────────────────────────────────────

def percentile(sorted_values: list[float], pct: float) -> float:
    """Nearest-rank percentile over an ascending-sorted list.

    Percentile, NOT mean (FR-SLA-03): one catastrophic 09:00 arrival must
    not move the expectation for the next 90 days — a mean is dragged by
    exactly the events being detected.
    """
    if not sorted_values:
        raise ValueError("percentile of an empty list is undefined")
    n = len(sorted_values)
    rank = math.ceil((pct / 100.0) * n)
    rank = min(max(rank, 1), n)
    return sorted_values[rank - 1]


def seconds_of_day(value: Any) -> float:
    """Seconds since midnight for a datetime (or ISO-format string)."""
    if isinstance(value, str):
        value = datetime.fromisoformat(value)
    return (value.hour * 3600.0 + value.minute * 60.0
            + value.second + value.microsecond / 1e6)


def format_seconds_of_day(secs: float | None) -> str | None:
    """``13080.0`` → ``'03:38:00'`` for operator screens; None passes through."""
    if secs is None:
        return None
    total = int(secs)
    return f"{total // 3600:02d}:{(total % 3600) // 60:02d}:{total % 60:02d}"


def compute_arrival_profile(dependency_name: str, day_type: str | None,
                            observations: list[float], *,
                            segmented: bool = True) -> ArrivalProfile:
    """Pure profile maths over first-arrival times (seconds since midnight).

    Zero observations yields a profile that SAYS so (confidence='low',
    every percentile None) — a threshold is never invented (FR-SLA-04).
    """
    obs = sorted(observations)
    n = len(obs)
    confidence = "high" if n >= HIGH_CONFIDENCE_MIN_OBSERVATIONS else "low"
    if n == 0:
        return ArrivalProfile(dependency_name, day_type, 0, "low",
                              None, None, None, None, segmented)
    return ArrivalProfile(
        dependency_name, day_type, n, confidence,
        p50=percentile(obs, 50), p90=percentile(obs, 90),
        p95=percentile(obs, 95), max=obs[-1], segmented=segmented)


def arrival_profile(db, dependency_name: str, day_type: str | None, *,
                    now: datetime | None = None,
                    classify_day: Callable[[date], str] | None = None,
                    window_days: int = 90) -> ArrivalProfile:
    """p50/p90/p95/max of the first arrival per business date (§8.2).

    ``classify_day`` maps a business_date to its day type ('normal',
    'month_end', 'first_bd', 'after_holiday', ...) — the calendar that
    drives SOD owns that classification (FR-SLA-02).  Without one:

      * ``day_type`` in {None, '', 'any', 'normal'} → the profile is built
        over ALL observed days and marked ``segmented=False`` (stated, not
        hidden — a consumer can tell it apart from a real segmented one);
      * any other ``day_type`` → REFUSED loudly (WARNING) with zero
        observations, because segmenting by month_end without a calendar
        would silently mislabel every day.  Zero observations means
        confidence='low', which is the FR-SLA-04 fall-back, not a page.
    """
    now = now or datetime.now(timezone.utc)
    since = now.date() - timedelta(days=window_days)
    rows = db.list_dependency_first_arrivals(dependency_name, since)
    segmented = True
    if classify_day is not None:
        rows = [r for r in rows if classify_day(r["business_date"]) == day_type]
    elif day_type in _UNSEGMENTED_DAY_TYPES:
        segmented = False
        logger.info(
            "[ledger] arrival profile for %s: no day-type classifier "
            "supplied — profile is UNSEGMENTED (all %d observed days "
            "counted; month-end days included)", dependency_name, len(rows))
    else:
        logger.warning(
            "[ledger] arrival profile for %s day_type=%r REFUSED: no "
            "day-type classifier supplied and %r cannot be derived from "
            "the ledger alone. Returning 0 observations (confidence=low) "
            "so the caller falls back to the decision deadline (FR-SLA-04) "
            "instead of trusting a mislabelled profile.",
            dependency_name, day_type, day_type)
        rows = []
        segmented = False
    obs = [seconds_of_day(r["first_arrived_at"]) for r in rows]
    return compute_arrival_profile(dependency_name, day_type, obs,
                                   segmented=segmented)
