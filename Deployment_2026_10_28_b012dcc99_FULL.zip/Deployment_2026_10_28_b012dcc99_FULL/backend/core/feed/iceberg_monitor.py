"""The Iceberg monitor -- which Iceberg tables QueryStudio watches, what each
new commit PROVED, and which feeds it released (2026-10-12, owner request R4:
"iceberg UI?").

Composes what is recorded and decides nothing:

* ``watched_iceberg_tables`` -- every watched table: its latest snapshot, when
  it was last synced, ok / error with the error;
* ``iceberg_commit_inspections`` -- every inspection of a new snapshot for a
  feed dependency (``iceberg_commit`` arrival source): ``proved`` (the dates /
  partition the snapshot's own metadata proves), ``no_proof`` or
  ``unreadable`` with the reason;
* the feeds DECLARING each inspected dependency, with their run for each
  proved date (``feeds_declaring_dependencies``): ``released`` = RUN.

Grouped by table (connection, bucket, prefix).  A watched table with no
inspection is listed (nothing has declared a dependency on it, or no commit
since); an inspected table that is no longer watched is listed too, marked
``watched: false`` (its commits can no longer be seen).
"""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from typing import Any, Dict, List, Tuple


def _key(row) -> Tuple[int, str, str]:
    return (int(row.get("connection_id") or 0), str(row.get("bucket") or ""),
            str(row.get("table_prefix") or ""))


def build(db, *, days: int = 7, page: int = 1, page_size: int = 50) -> Dict[str, Any]:
    """PAGED over inspections (newest first, core/feed/paging.py); every
    watched table is listed on every page (its sync state is the monitor's
    headline), the page's inspections under their tables; ``inspection_counts``
    are over the whole window."""
    from core.feed.paging import block, paging
    pg = paging(page, page_size)
    since = datetime.now(timezone.utc) - timedelta(days=max(0, int(days)))
    try:
        watched = db.list_watched_iceberg_tables(enabled_only=False, limit=5000) or []
        watched_error = None
    except Exception as exc:                            # noqa: BLE001 -- said, not hidden
        watched, watched_error = [], f"{type(exc).__name__}: {exc}"
    inspections = db.list_recent_iceberg_commit_inspections(since, limit=pg.page_size,
                                                            offset=pg.offset) or []

    # the feeds each (dependency, proved date) released -- one query per date
    by_date: Dict[str, set] = {}
    for i in inspections:
        for d in (i.get("dates_proved") or []):
            by_date.setdefault(str(d)[:10], set()).add(i["dependency_name"])
    feeds: Dict[Tuple[str, str], List[dict]] = {}
    for d, names in by_date.items():
        try:
            bd = date.fromisoformat(d)
        except ValueError:
            continue
        for name, rows in (db.feeds_declaring_dependencies(sorted(names), bd) or {}).items():
            feeds[(name, d)] = rows

    tables: Dict[Tuple[int, str, str], Dict[str, Any]] = {}
    for w in watched:
        tables[_key(w)] = {
            "connection_id": w.get("connection_id"), "bucket": w.get("bucket"),
            "table_prefix": w.get("table_prefix"), "watched": True,
            "enabled": w.get("enabled", True),
            "last_snapshot_id": w.get("last_snapshot_id"),
            "last_synced_at": w.get("last_synced_at"),
            "last_sync_status": w.get("last_sync_status"),
            "last_sync_error": w.get("last_sync_error"),
            "last_files_count": w.get("last_files_count"),
            "inspections": []}
    for i in inspections:
        t = tables.setdefault(_key(i), {
            "connection_id": i.get("connection_id"), "bucket": i.get("bucket"),
            "table_prefix": i.get("table_prefix"), "watched": False, "enabled": None,
            "last_snapshot_id": None, "last_synced_at": None, "last_sync_status": None,
            "last_sync_error": None, "last_files_count": None, "inspections": []})
        released, held = [], []
        for d in (i.get("dates_proved") or []):
            for f in feeds.get((i["dependency_name"], str(d)[:10]), []):
                entry = {**f, "business_date": str(d)[:10]}
                (released if str(f.get("action_decision") or "").upper() == "RUN"
                 else held).append(entry)
        t["inspections"].append({**i, "released": released, "held": held})
    out = sorted(tables.values(), key=lambda t: (not t["inspections"], str(t["table_prefix"])))
    counts = db.iceberg_commit_inspection_counts(since) or {}
    return {"days": days, "tables": out, "inspection_counts": counts,
            "watched_unreadable": watched_error,
            "paging": block(sum(counts.values()), pg, len(inspections))}
