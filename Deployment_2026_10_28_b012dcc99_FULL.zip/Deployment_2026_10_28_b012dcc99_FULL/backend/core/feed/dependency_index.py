"""The reverse index — dependency -> the feeds it is blocking (BRD §7, §12).

Today you can ask "what is this feed waiting on"; the question an operator
actually has at 04:30 is the other way round: "what is APAC_POSITIONS
blocking?".  Two consumers need that grouping — the SLA watcher raises ONE
alert naming 34 feeds (FR-DEP-19 / FR-SLA-07), and the operator API answers
the question on demand — so it is computed HERE, once, and both read it.
Two copies would drift, and the alert would name a different set of feeds
than the screen shows.

Found while factoring (2026-09-02): the watcher's old inline grouping could
never form.  It read ``run.get("etl_id")`` from ``list_feed_runs`` rows, but
``FeedRun.to_dict()`` carries no ``etl_id`` — every run was skipped and the
by-dependency map was ALWAYS empty, so the watcher never raised anything.
This module reads the join that HAS etl_id
(``list_pending_runs_needing_dep_check``) instead.

A run is in this index when BOTH hold: its ``action_decision`` says WAIT
(queued and held are different states — a merely-pending run is about to
execute, and alerting on it would page people about a queue) AND the gate
currently names at least one blocking dependency.  The WAIT flag alone is a
poller-cadence-old cache; the gate alone cannot tell held from queued.
"""
from __future__ import annotations

import logging
from datetime import date
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


def _feed_fields(db: Any, feed_config_id: Any,
                 cache: Dict[int, dict]) -> dict:
    """Name + timezone for one feed config, cached per pass, fail-soft.

    Enrichment must never break the index: a feed whose config row cannot
    be read still shows up as blocked — just without a name.
    """
    try:
        fid = int(feed_config_id)
    except (TypeError, ValueError):
        return {}
    if fid not in cache:
        try:
            cfg = db.get_feed_config(fid) or {}
        except Exception as exc:
            logger.debug("[dependency_index] feed_config %s unreadable: %s",
                         fid, exc)
            cfg = {}
        cache[fid] = {
            "feed_name": cfg.get("name"),
            "timezone": cfg.get("timezone"),
        }
    return cache[fid]


def wait_business_dates(candidates: Any, *, since: date, until: date) -> list:
    """The distinct business dates in ``[since, until]`` that still have a
    run held at WAIT, oldest first.

    2026-09-28 -- the SLA watcher evaluates EVERY such date, not today
    alone: a run for yesterday still held after midnight, past its SLA,
    used to raise nothing.  Pure function over the rows
    ``list_pending_runs_needing_dep_check`` returns (the same rows
    :func:`build_blocking_index` reads), so one listing serves every date.
    A row with an unparseable date is skipped -- it can hold no clock.
    """
    seen: set = set()
    for run in candidates or []:
        if (run.get("action_decision") or "RUN") != "WAIT":
            continue
        raw = str(run.get("business_date") or "")[:10]
        try:
            bd = date.fromisoformat(raw)
        except ValueError:
            continue
        if since <= bd <= until:
            seen.add(bd)
    return sorted(seen)


def build_blocking_index(db: Any, *, business_date: date,
                         candidates: Any = None) -> dict:
    """Group the runs the gate is blocking BY DEPENDENCY for one date.

    ``candidates`` is an already-fetched ``list_pending_runs_needing_dep_check``
    result (2026-09-28: the SLA watcher lists once and indexes several
    dates); ``None`` lists here, as before.

    Returns::

        {
          "business_date": <date>,
          "by_dependency": {
              dep_name: {"runs": [run_dict, ...],
                          "verdicts": [DependencyVerdict, ...]},
              ...
          },
          "waiting_runs": <runs with a non-empty blocking set>,
          "errors": <gate reads that failed>,
        }

    Each run dict is the DAO row enriched with ``etl_id`` (from the join),
    ``feed_name`` / ``name`` and the feed's ``timezone`` — the fields the
    SLA ladder and the operator screen both need.  A gate read failing for
    one run costs THAT run's answer, never the pass: it is counted in
    ``errors`` and logged, because "nothing is blocked" and "the gate could
    not be read" are opposite findings.
    """
    from core.feed.etl_dependency import evaluate_gate_verdicts

    out: dict = {"business_date": business_date, "by_dependency": {},
                 "waiting_runs": 0, "errors": 0}
    if candidates is None:
        try:
            candidates = db.list_pending_runs_needing_dep_check() or []
        except Exception as exc:
            logger.error("[dependency_index] could not list pending runs: %s", exc)
            out["errors"] += 1
            # 2026-09-28 -- NAMED, not just counted: an index that could
            # not list the runs at all is "the blocked list could not be
            # read", which the screen must show as unavailable; one failed
            # gate read among many (also an error) is a partial answer.
            out["index_error"] = f"{type(exc).__name__}: {exc}"
            return out

    bd_iso = business_date.isoformat()
    cache: Dict[int, dict] = {}
    for run in candidates:
        if str(run.get("business_date") or "")[:10] != bd_iso:
            continue
        if (run.get("action_decision") or "RUN") != "WAIT":
            continue                      # queued, not held (see docstring)
        etl_id = run.get("etl_id")
        if not etl_id:
            continue
        try:
            verdicts = evaluate_gate_verdicts(db, int(etl_id), business_date)
        except Exception as exc:
            logger.warning("[dependency_index] gate read failed for run %s: "
                           "%s", run.get("id"), exc)
            out["errors"] += 1
            continue
        if verdicts is None or not verdicts.blocking:
            continue
        out["waiting_runs"] += 1
        enriched = dict(run)
        fields = _feed_fields(db, run.get("feed_config_id"), cache)
        enriched["feed_name"] = fields.get("feed_name")
        # ``name`` too: sla_watcher._tightest_sla reads it for the
        # skip-feed hint, and it read nothing before this enrichment.
        enriched.setdefault("name", fields.get("feed_name"))
        enriched.setdefault("timezone", fields.get("timezone"))
        for v in verdicts.blocking:
            entry = out["by_dependency"].setdefault(
                v.dependency_name, {"runs": [], "verdicts": []})
            entry["runs"].append(enriched)
            entry["verdicts"].append(v)
    return out


def last_arrival_at(db: Any, dependency_name: str) -> Optional[str]:
    """When this dependency was last seen arriving, across ALL dates.

    "APAC_POSITIONS, last seen three days ago" tells support who to call
    (FR-DEP-06).  Read from the arrival ledger's per-date first arrivals;
    ``None`` honestly means "never recorded arriving", and a ledger read
    failure is also ``None`` — logged, never raised, because this is an
    enrichment on a screen, not a gate.
    """
    try:
        rows = db.list_dependency_first_arrivals(dependency_name) or []
    except Exception as exc:
        logger.debug("[dependency_index] arrival ledger unreadable for %r: "
                     "%s", dependency_name, exc)
        return None
    if not rows:
        return None
    ts = rows[-1].get("first_arrived_at")
    if ts is None:
        return None
    return ts.isoformat() if hasattr(ts, "isoformat") else str(ts)
