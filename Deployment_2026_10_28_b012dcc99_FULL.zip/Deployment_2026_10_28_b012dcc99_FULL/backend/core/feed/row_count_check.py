"""Phase 131-B — Per-feed row-count threshold check.

When a feed completes, compare the actual row_count against the rolling
baseline (``feed_row_count_baseline``).  If the deviation exceeds the
configured tolerance, the run is either failed or warned based on
``feed_configs.row_count_action``.

Opt-in per feed: ``row_count_action`` defaults to ``'off'``, so this
check is a no-op for legacy feeds and new feeds until the owner
explicitly enables it.

DB-tunable defaults via system_settings:
    feed_generation.row_count_threshold_pct_default  (default 10)
    feed_generation.row_count_min_samples            (default 3)
"""
from __future__ import annotations

import logging
import statistics
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Sequence

logger = logging.getLogger(__name__)


#: The actions a feed may declare.  'hold' (2026-10-12, owner R2) evaluates
#: exactly like 'warn' here -- the breach is recorded, nothing raises -- and
#: the ENGINE then keeps the file and delivers nothing
#: (core/feed/variance_hold.py).
ROW_COUNT_ACTIONS = ("off", "warn", "fail", "hold")
#: ``row_count_compare_to`` values: the rolling average, or the previous
#: business date's DELIVERED rows.
ROW_COUNT_COMPARE_TO = ("baseline", "previous")
PREVIOUS_BASELINE_KIND = "previous_business_date"


class FeedRowCountAnomaly(Exception):
    """Raised when row_count is outside the configured tolerance and the
    feed's ``row_count_action`` is ``'fail'``.  Caught by feed_engine and
    surfaced as ``failed_stage='row_count_check'``."""

    def __init__(self, message: str):
        super().__init__(message)
        self.stage = "row_count_check"


# ── Config helpers ──────────────────────────────────────────────────


def _load_defaults() -> Dict[str, Any]:
    try:
        from core.config import _db_setting_or
    except ImportError:
        _db_setting_or = None  # type: ignore

    def _resolve(key: str, default: Any) -> Any:
        if _db_setting_or is None:
            return default
        return _db_setting_or(key, default)

    # 2026-09-02 (D3) — ``default_action`` is what a feed inherits when its own
    # ``row_count_action`` is NULL.  ``models.FeedConfig`` has always
    # documented NULL as "inherit system default"; ``evaluate`` implemented it
    # as "off", so the documented inheritance did not exist and a volume check
    # could never fire on a feed nobody had explicitly configured.
    #
    # 'warn' -- never 'fail' -- because this default applies to feeds whose
    # author made no choice: it must surface an anomaly, not block a delivery
    # on a threshold nobody agreed to.
    return {
        "default_threshold_pct": float(_resolve("feed_generation.row_count_threshold_pct_default", 10)),
        "min_samples":           int(_resolve("feed_generation.row_count_min_samples", 3)),
        "default_window_days":   int(_resolve("feed_generation.row_count_window_days", 7)),
        "default_action":        str(_resolve("feed_generation.row_count_action_default", "warn")).lower(),
    }


# ── The check itself (pure function) ────────────────────────────────


def evaluate(
    actual_rows: int,
    *,
    feed_config: Dict[str, Any],
    baseline: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """Pure-function row-count evaluator.

    Returns a dict describing the outcome.  Raises
    ``FeedRowCountAnomaly`` only when ``row_count_action='fail'`` AND
    the deviation breaches the threshold.

    Outcome shape:
        {
          "skipped": bool,         # True when check is off or no baseline
          "skipped_reason": str,   # human-readable reason
          "delta_pct": float,      # |actual - avg| / avg * 100
          "threshold_pct": float,
          "baseline_avg": int,
          "action": "off" | "warn" | "fail",
          "breach": bool,
        }

    2026-09-03 (FR-DEP-15) additions, each active only when its knob is
    configured (all NULL = byte-identical legacy behaviour):
        ``direction`` ("up"|"down") on every percentage outcome;
        ``reason="below_absolute_floor"`` + ``min_rows`` when
        ``row_count_min_rows`` fires;
        ``reason="expected_zero_ok"`` + ``expect_zero=True`` when
        ``row_count_expect_zero`` declares a legitimate empty set.
    """
    defaults = _load_defaults()
    # 2026-09-02 (D3) — NULL and "off" are DIFFERENT answers and used to be
    # folded together by ``or "off"``.  NULL means "the author expressed no
    # preference" (models.FeedConfig documents it as "inherit system default");
    # "off" means "the author turned the check OFF".  Folding them made the
    # documented inheritance unreachable and left the check silently disabled
    # on every feed nobody had explicitly configured.
    _declared = feed_config.get("row_count_action")
    action = (str(_declared).lower() if _declared not in (None, "")
              else defaults["default_action"])
    if action == "off":
        return {"skipped": True, "skipped_reason": "row_count_action=off"}

    # 2026-09-03 (FR-DEP-15) — the shape the single percentage could not
    # express.  All three knobs are NULL on existing feeds, and every one
    # of these branches is unreachable when they are — a feed with only a
    # percentage configured takes exactly the pre-existing path below.

    # Explicit expect-zero: the AUTHOR declared that zero rows is a
    # legitimate full answer (an empty region on its holiday).  Checked
    # first — an explicit declaration beats both the floor and the
    # percentage at exactly zero, because "the whole set is legitimately
    # empty" is a different statement from "the set came up short".
    if bool(feed_config.get("row_count_expect_zero")) and int(actual_rows) == 0:
        return {
            "skipped": False,
            "breach": False,
            "action": action,
            "actual_rows": 0,
            "expect_zero": True,
            "reason": "expected_zero_ok",
        }

    # Absolute floor: fewer rows than this is a breach REGARDLESS of any
    # percentage — and regardless of whether a baseline exists yet,
    # because a collapse from 4M rows to 12 is mechanically perfect
    # output and must not hide behind "insufficient samples".
    _floor = feed_config.get("row_count_min_rows")
    if _floor is not None and int(actual_rows) < int(_floor):
        result = {
            "skipped": False,
            "breach": True,
            "direction": "down",
            "action": action,
            "actual_rows": int(actual_rows),
            "min_rows": int(_floor),
            "reason": "below_absolute_floor",
        }
        if action == "fail":
            raise FeedRowCountAnomaly(
                f"Row count {actual_rows} is below the absolute floor "
                f"{int(_floor)} (row_count_min_rows)"
            )
        return result

    # 2026-10-12 (owner R2) -- ``row_count_compare_to = 'previous'``: the
    # baseline is ONE number, the rows the previous business date's run
    # DELIVERED ("today vs yesterday"), handed in by the engine as
    # ``{"kind": "previous_business_date", "avg_rows", "business_date"}``.
    # One delivered day is the whole sample by declaration, so the rolling
    # baseline's min-samples rule does not apply; NO earlier delivery is
    # said, never compared with zero.
    _previous = str(feed_config.get("row_count_compare_to") or "").lower() == "previous"
    if _previous:
        if not baseline or baseline.get("kind") != PREVIOUS_BASELINE_KIND:
            return {"skipped": True, "skipped_reason": "no_previous_delivery",
                    "baseline_kind": PREVIOUS_BASELINE_KIND}
    elif not baseline or baseline.get("sample_count", 0) < defaults["min_samples"]:
        return {
            "skipped": True,
            "skipped_reason": "insufficient_baseline_samples",
            "min_samples_required": defaults["min_samples"],
            "samples_available": baseline.get("sample_count", 0) if baseline else 0,
        }

    avg = float(baseline["avg_rows"]) or 0.0
    _bl_facts = ({"baseline_kind": PREVIOUS_BASELINE_KIND,
                  "baseline_business_date": baseline.get("business_date")}
                 if _previous else {"baseline_kind": "rolling"})
    if avg <= 0:
        if _previous and int(actual_rows) > 0:
            # yesterday delivered NOTHING, today has rows: no percentage
            # exists, and "no change" would be a lie -- it is a breach UP.
            result = {"skipped": False, "breach": True, "direction": "up",
                      "baseline_avg": 0, "actual_rows": int(actual_rows),
                      "delta_pct": None, "threshold_pct": None,
                      "action": action, "reason": "previous_was_zero", **_bl_facts}
            if action == "fail":
                raise FeedRowCountAnomaly(
                    f"Row count {actual_rows} after a previous business date "
                    f"that delivered 0 rows")
            return result
        if _previous:
            return {"skipped": False, "breach": False, "baseline_avg": 0,
                    "actual_rows": 0, "action": action,
                    "reason": "zero_both_days", **_bl_facts}
        return {"skipped": True, "skipped_reason": "baseline_avg_zero"}

    threshold = feed_config.get("row_count_threshold_pct")
    if threshold is None:
        threshold = defaults["default_threshold_pct"]
    threshold_pct = float(threshold)

    # 2026-09-03 (FR-DEP-15) — independent up/down tolerances.  Growth and
    # loss are different events: 30% more rows may be a good quarter, 5%
    # fewer may be a missing region.  A direction whose override is NULL
    # keeps the symmetric threshold above — existing feeds move nowhere.
    direction = "up" if actual_rows >= avg else "down"
    _override = feed_config.get(
        "row_count_threshold_pct_up" if direction == "up"
        else "row_count_threshold_pct_down")
    if _override is not None:
        threshold_pct = float(_override)

    delta_pct = abs(actual_rows - avg) / avg * 100.0
    breach = delta_pct > threshold_pct

    result = {
        "skipped": False,
        "delta_pct": round(delta_pct, 3),
        "threshold_pct": threshold_pct,
        "direction": direction,
        "baseline_avg": int(avg),
        "actual_rows": int(actual_rows),
        "action": action,
        "breach": breach,
        **_bl_facts,
    }

    if breach and action == "fail":
        raise FeedRowCountAnomaly(
            f"Row count {actual_rows} deviates {delta_pct:.1f}% from baseline "
            f"{int(avg)} (threshold {threshold_pct}%)"
        )

    return result


# ── Baseline recompute (called by the daily scheduler job) ──────────


def recompute_baseline_from_history(
    completed_runs: Sequence[Dict[str, Any]],
    *,
    rolling_window_days: int = 7,
) -> Optional[Dict[str, Any]]:
    """Compute baseline stats from a list of recently-completed feed_runs.

    Each input row needs ``total_rows`` (int) and ``completed_at``
    (datetime).  Filters out non-completed rows + rows older than the
    rolling window.  Returns ``None`` when fewer than 2 samples remain
    (caller's caller decides whether to overwrite the existing baseline
    or leave it).
    """
    cutoff = datetime.now(timezone.utc) - timedelta(days=rolling_window_days)
    rows: List[int] = []
    for r in completed_runs:
        if r.get("status") and r["status"] != "completed":
            continue
        ts = r.get("completed_at") or r.get("created_at")
        if ts is None:
            continue
        if isinstance(ts, str):
            try:
                ts = datetime.fromisoformat(ts.replace("Z", "+00:00"))
            except ValueError:
                continue
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        if ts < cutoff:
            continue
        rc = r.get("total_rows")
        if rc is None:
            continue
        rows.append(int(rc))

    if len(rows) < 2:
        return None

    avg = int(round(statistics.mean(rows)))
    try:
        stdev = int(round(statistics.stdev(rows))) if len(rows) >= 2 else None
    except statistics.StatisticsError:
        stdev = None
    return {
        "rolling_window_days": rolling_window_days,
        "avg_rows":            avg,
        "stdev_rows":          stdev,
        "min_rows":            min(rows),
        "max_rows":            max(rows),
        "sample_count":        len(rows),
        "last_updated_at":     datetime.now(timezone.utc),
    }
