"""Archive lifecycle stage + Download Centre registration —
FR-DEL-08..12 / FR-SEC-04 (BRD §11.3).

Three pieces, deliberately in one module because they share one
invariant — the KEY LAYOUT:

* :func:`archive_prefix` / :func:`archive_uri` — the FIXED layout
  ``s3://<bucket>/<feed>/<business_date>/<build_id>/`` (FR-DEL-09).
  Fixed BEFORE build because it is what makes a two-year-old file
  findable; ``build_id`` is load-bearing — without it a redelivery
  overwrites the original and the audit trail reads as if only one file
  ever existed.

* :class:`ArchiveDeliveryTarget` — archive as a delivery STEP
  (``role="delivery"``, name ``archive``), not a cleanup script
  (FR-DEL-08): it flows through the hop runner, so it is scheduled,
  observable, retryable and auditable exactly like every other hop, and
  its traits (idempotent — same key, same bytes) are declared in
  ``delivery_hops.DEFAULT_TARGET_TRAITS``.  The upload itself delegates
  to the engine's S3 transport (in-band HEAD verification, credential
  resolution via connection registry) — never a second S3 client
  recipe.

* :func:`feed_download_registration` / :func:`register_feed_download` —
  FR-DEL-10/11: every archived deliverable gets a Download Centre row
  naming feed, business date, build id, size, checksum and where the
  file IS (the S3 key — so download can be a redirect, not a 4 GB
  stream through the API pod).  The row is stamped ``source_kind="feed"``
  so ``core.download_sharing`` applies the FEED's access rule
  (FR-DEL-12/FR-SEC-04).  Columns the schema does not carry yet
  (checksum, business_date, build_id) are passed only once
  ``create_download_file`` accepts them — the composer inspects the
  seam's signature, so the day the schema owner adds them, they flow
  with NO change here; until then they are returned to the caller and
  logged, never silently dropped.

Registration is NOT wired into the engine from here (feed_engine is the
engine's own file); the anchors are one call each and are named in the
module's delivery report.
"""
from __future__ import annotations

import inspect
import logging
import re
import uuid
from datetime import date as _date
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, Mapping, Optional

from core.feed.delivery_targets import DeliveryReceipt, DeliveryTarget

logger = logging.getLogger(__name__)

_SEGMENT_BAD = re.compile(r"[^A-Za-z0-9._-]+")


class ArchiveLayoutError(ValueError):
    """A key layout that cannot be composed with certainty is refused —
    a guessed segment is a file nobody finds in two years."""


def _segment(value: Any, what: str) -> str:
    """One path segment: non-empty, no separators, no traversal.
    ONE guard: blank, pure-punctuation and pure-traversal inputs all
    sanitise to nothing usable and are refused by the same check."""
    s = _SEGMENT_BAD.sub("_", str(value or "").strip())
    if s.strip("._") == "":
        raise ArchiveLayoutError(
            f"archive key needs a usable {what} (got {value!r}) — the "
            f"layout s3://<bucket>/<feed>/<business_date>/<build_id>/ is "
            f"fixed (FR-DEL-09); a blank segment makes the file "
            f"unfindable in two years")
    return s


def archive_prefix(feed: Any, business_date: Any, build_id: Any) -> str:
    """``<feed>/<business_date>/<build_id>`` — every segment required."""
    if isinstance(business_date, (_date, datetime)):
        business_date = business_date.strftime("%Y-%m-%d")
    return "/".join((
        _segment(feed, "feed name"),
        _segment(business_date, "business date"),
        _segment(build_id, "build id"),
    ))


def archive_uri(bucket: str, feed: Any, business_date: Any, build_id: Any,
                filename: str) -> str:
    """The full FR-DEL-09 URI for one deliverable."""
    b = str(bucket or "").strip()
    if not b:
        raise ArchiveLayoutError("archive needs a bucket")
    return (f"s3://{b}/{archive_prefix(feed, business_date, build_id)}/"
            f"{_segment(filename, 'filename')}")


def inject_run_identity(dest_config: Mapping[str, Any], *, feed_name: Any,
                        business_date: Any, build_id: Any) -> Dict[str, Any]:
    """The engine-side anchor, as one call: an archive hop's config is
    static feed data; the run identity (business date, build id) is
    per-run.  The engine calls this right where it already injects
    ``_triggered_by_user`` before dispatching the hop."""
    out = dict(dest_config or {})
    out["feed"] = feed_name
    out["business_date"] = business_date
    out["build_id"] = build_id
    return out


class ArchiveDeliveryTarget(DeliveryTarget):
    """FR-DEL-08 — the archive lifecycle stage as a delivery step.

    ``dest_config`` must carry ``bucket`` (+ the same credential fields
    the s3 adapter takes) and the run identity (``feed``/``feed_name``,
    ``business_date``, ``build_id`` — see :func:`inject_run_identity`).
    A missing identity is a REFUSAL: archiving under a guessed key is
    filing a document in a random drawer.

    Registered from the builtin step list (anchor:
    ``core.feed.steps._register_builtins`` — one class in the delivery
    tuple) so a mispointed steps_dir cannot take it away."""

    name = "archive"
    #: The archive layout IS the run's identity — see the class
    #: docstring: a missing one is a refusal, not a default.
    needs_run_identity = True

    def deliver(self, local_path: str, filename: str,
                dest_config: Dict[str, Any]) -> DeliveryReceipt:
        cfg = dict(dest_config or {})
        prefix = archive_prefix(
            cfg.get("feed") or cfg.get("feed_name"),
            cfg.get("business_date"),
            cfg.get("build_id"))
        # Delegate to the engine's S3 transport: in-band verification,
        # credential resolution, atomicity — one recipe, not two.
        from core import feed_engine as _fe
        raw: dict = {}
        s3_cfg = {k: v for k, v in cfg.items()
                  if k not in ("feed", "feed_name", "business_date",
                               "build_id", "prefix")}
        s3_cfg["prefix"] = prefix
        uri = _fe._deliver_s3(local_path, filename, s3_cfg, _receipt=raw)
        receipt = DeliveryReceipt.from_outparam(uri, self.name, raw)
        receipt.extras["archive_prefix"] = prefix
        # The canonical FR-DEL-09 location, built by the one function
        # that knows the layout.  ``archive_uri`` existed with no caller
        # while every consumer that wanted "where is it?" had to
        # re-assemble bucket + prefix + filename itself — which is how
        # two spellings of one path start disagreeing.  Advisory: a
        # bucket the transport resolved from credentials rather than
        # config leaves the receipt without it, and the delivered uri
        # above is still authoritative.
        try:
            receipt.extras["archive_uri"] = archive_uri(
                cfg.get("bucket"), cfg.get("feed") or cfg.get("feed_name"),
                cfg.get("business_date"), cfg.get("build_id"), filename)
        except ArchiveLayoutError as exc:
            logger.debug("[feed_archive] canonical uri unavailable: %s", exc)
        return receipt


# ── Download Centre registration (FR-DEL-10/11/12) ─────────────────────────


def feed_download_registration(
        *, feed_config: Mapping[str, Any], filename: str, file_uri: str,
        size_bytes: int, business_date: Any, build_id: Any,
        checksum: Optional[str] = None,
        checksum_algorithm: Optional[str] = None,
        retention_days: Optional[int] = None,
        created_by: Optional[str] = None,
        now: Optional[datetime] = None) -> Dict[str, Any]:
    """The FR-DEL-10 registration row for one feed deliverable.

    ``file_uri`` records WHERE THE FILE IS (an ``s3://`` key or a local
    path) — FR-DEL-11's redirect-not-stream requirement rides on this
    field.  ``source_kind="feed"`` + ``source_id=<feed id>`` is the
    FR-DEL-12 stamp ``core.download_sharing`` resolves the feed's own
    access rule through; ``rls_signature`` carries the canonical-feed
    marker (the artifact is the feed's one output, not a per-principal
    materialisation — see download_sharing's module docstring).
    """
    feed_id = feed_config.get("id")
    if feed_id is None:
        raise ArchiveLayoutError(
            "cannot register a download for a feed with no id")
    if not str(file_uri or "").strip():
        # 2026-09-25: a row with no location is listed as available and
        # can never be served (410).  Nothing delivered = nothing to list.
        raise ArchiveLayoutError(
            "cannot register a download with no file location (was the "
            "delivery suppressed?)")
    if isinstance(business_date, (_date, datetime)):
        business_date = business_date.strftime("%Y-%m-%d")
    now = now or datetime.now(timezone.utc)
    expires_at = (now + timedelta(days=int(retention_days))
                  if retention_days else None)
    from core.download_sharing import FEED_CANONICAL_SCOPE, SOURCE_FEED
    return {
        "file_id": f"feed-{feed_id}-{uuid.uuid4().hex[:12]}",
        "filename": Path(filename).name,
        "file_path": str(file_uri),
        "file_size_bytes": int(size_bytes),
        "execution_id": str(build_id or "") or None,
        "expires_at": expires_at,
        "created_by": created_by or "feed_engine",
        "source_kind": SOURCE_FEED,
        "source_id": str(feed_id),
        "source_dataset_id": "",  # a feed signs no dataset scope
        "rls_signature": FEED_CANONICAL_SCOPE,
        # Below: FR-DEL-10 facts whose columns are a pending schema
        # request (download_files: checksum, checksum_algorithm,
        # business_date, build_id).  register_feed_download passes them
        # through the moment the seam accepts them.
        "checksum": checksum,
        "checksum_algorithm": checksum_algorithm,
        "business_date": str(business_date or "") or None,
        "build_id": str(build_id or "") or None,
    }


def register_feed_download(db, registration: Mapping[str, Any]
                           ) -> Dict[str, Any]:
    """Write the registration through ``db.create_download_file``,
    passing exactly the kwargs the seam accepts TODAY and logging what
    it cannot persist yet — pending facts are surfaced, never silently
    dropped, and start flowing automatically once the schema owner
    widens the seam."""
    fn = db.create_download_file
    accepted = set(inspect.signature(fn).parameters)
    reg = dict(registration)
    sendable = {k: v for k, v in reg.items() if k in accepted}
    pending = {k: v for k, v in reg.items()
               if k not in accepted and v is not None}
    if pending:
        logger.warning(
            "[feed_archive] download registration for %s: the seam does "
            "not accept %s yet (pending download_files schema columns) — "
            "recorded in the log, not the row",
            reg.get("file_id"), sorted(pending))
    return fn(**sendable)
