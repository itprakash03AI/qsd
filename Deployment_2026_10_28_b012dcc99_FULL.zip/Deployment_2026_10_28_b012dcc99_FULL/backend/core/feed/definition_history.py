"""Feed definition VERSION HISTORY — the read half of Foundation P (2026-09-27).

``core/feed/pinning.py`` writes a ``feed_definition_versions`` row every
time a run is CLAIMED with a definition whose hash the feed has not pinned
before.  That gave the platform an audit trail nobody could read: no route
listed the versions, nothing compared two of them, and an operator who
wanted "what changed between last Tuesday's file and today's" had to query
the table by hand.  This module is the reader:

* ``record_version`` — the SAVE half.  ``PUT /api/feeds/{id}`` (the ONE
  update) pins the definition it just wrote, through the SAME writer the
  claim uses (``dao.pin_feed_definition``), so the history shows edits as
  well as runs.  Deduplicated by hash: saving an unchanged feed mints no
  version.  Fail-open — a history row is an audit, never a reason a save
  fails — but LOUD (ERROR) when it cannot be written.
* ``diff_definitions`` — a FIELD-LEVEL diff between two snapshots.  A
  top-level key that changed is one entry; a dict-valued key (query_params,
  destination_config, output_options...) is diffed ONE level deeper so the
  entry names the sub-key, because "destination_config changed" is not an
  answer at 04:50.  Secrets are masked BEFORE diffing, so a password change
  reads as ``*** -> ***`` (it changed; the values are not shown).
* ``restore_payload`` — what a RESTORE sends through the normal update
  route.  Only fields the update model accepts, and never identity or
  operational state (``id``, ``created_by``, ``is_active``,
  ``schedule_enabled``): restoring a definition must not silently
  reactivate a feed or re-enable its cron.

Deliberately no HTTP here and no imports from api/ -- the route module
(``api/feed_versions_api.py``) is the thin shell.
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Iterable, Mapping, Optional

from core.feed import pinning as _pinning

logger = logging.getLogger(__name__)

#: Keys a RESTORE never sends through the update route.  ``id`` and
#: ``created_by`` are identity; ``is_active`` / ``schedule_enabled`` are
#: operational state with their own explicit routes (retire / unretire,
#: enable-schedule / disable-schedule) and their own audit lines.
RESTORE_NEVER = frozenset({
    "id", "created_by", "is_active", "schedule_enabled",
    "apscheduler_job_id", "flow_id",
})

#: Dict-valued definition fields diffed one level deeper.
NESTED_FIELDS = frozenset({
    "query_params", "output_options", "destination_config",
    "backend_config", "schedule_declaration", "where_clauses",
    "join_config", "contract",
})


def record_version(dao: Any, feed_config_id: int, *,
                   created_by: Optional[str] = None,
                   feed_config: Optional[Mapping[str, Any]] = None,
                   ) -> Optional[dict]:
    """Pin the feed's CURRENT definition as a version row (the SAVE half).

    Reads the stored row when ``feed_config`` is not given, snapshots it
    with the claim-time snapshotter (so an edit and a run that pin the
    same definition share ONE version), and returns the version row --
    the existing one when the hash is unchanged.  ``None`` when the
    feed does not exist or the write failed (logged at ERROR: the audit
    row is missing, the save itself is fine).
    """
    try:
        cfg = dict(feed_config) if feed_config is not None else (
            dao.get_feed_config(int(feed_config_id)) or None)
        if not cfg:
            return None
        snap = _pinning.snapshot_definition(cfg)
        return dao.pin_feed_definition(int(feed_config_id), snap,
                                       created_by=created_by)
    except Exception as exc:  # noqa: BLE001 -- audit, never a gate
        logger.error(
            "[definition_history] feed %s: the saved definition could not "
            "be recorded as a version (%s) -- the save stands, the history "
            "has a hole for this edit", feed_config_id, exc)
        return None


def _masked_value(mask: Optional[Callable[[dict], dict]], field: str,
                  sub: Optional[str], value: Any) -> Any:
    """Run ONE value through the masker in its definition-shaped position,
    so the masker's own key rules (a ``password`` under
    ``destination_config``) decide.  A masker that fails must not leak:
    the value is withheld entirely."""
    if mask is None or value is None:
        return value
    shaped = {field: ({sub: value} if sub is not None else value)}
    try:
        masked = mask(dict(shaped)) or {}
        got = masked.get(field)
        if sub is not None:
            got = (got or {}).get(sub) if isinstance(got, Mapping) else got
        return got
    except Exception as exc:  # noqa: BLE001
        logger.error("[definition_history] secret masking failed (%s); "
                     "the value is withheld", exc)
        return "<unavailable>"


def diff_definitions(before: Mapping[str, Any], after: Mapping[str, Any], *,
                     mask: Optional[Callable[[dict], dict]] = None,
                     ) -> list[dict]:
    """Field-level differences, ``before`` -> ``after``.

    Each entry: ``{"field", "path", "kind", "from", "to"}`` where ``kind``
    is ``added`` / ``removed`` / ``changed``, ``field`` is the top-level
    key and ``path`` is ``field`` or ``field.subkey`` for a nested change.
    Sorted by path so the answer is stable for a test and a reviewer.

    The comparison is on the RAW values and the masking is applied to the
    entries AFTERWARDS -- masking first made every password read as
    ``*** == ***``, i.e. unchanged, so a credential rotation was invisible
    in the history (caught by the first test written against it).
    """
    a = dict(before or {})
    b = dict(after or {})
    out: list[dict] = []
    for key in sorted(set(a) | set(b)):
        if key not in a:
            out.append({"field": key, "path": key, "kind": "added",
                        "from": None, "to": b[key]})
            continue
        if key not in b:
            out.append({"field": key, "path": key, "kind": "removed",
                        "from": a[key], "to": None})
            continue
        va, vb = a[key], b[key]
        if va == vb:
            continue
        if (key in NESTED_FIELDS and isinstance(va, Mapping)
                and isinstance(vb, Mapping)):
            for sub in sorted(set(va) | set(vb)):
                if sub not in va:
                    out.append({"field": key, "path": f"{key}.{sub}",
                                "kind": "added", "from": None,
                                "to": vb[sub]})
                elif sub not in vb:
                    out.append({"field": key, "path": f"{key}.{sub}",
                                "kind": "removed", "from": va[sub],
                                "to": None})
                elif va[sub] != vb[sub]:
                    out.append({"field": key, "path": f"{key}.{sub}",
                                "kind": "changed", "from": va[sub],
                                "to": vb[sub]})
            continue
        out.append({"field": key, "path": key, "kind": "changed",
                    "from": va, "to": vb})
    if mask is not None:
        for entry in out:
            sub = (entry["path"].split(".", 1)[1]
                   if "." in entry["path"] else None)
            for side in ("from", "to"):
                entry[side] = _masked_value(mask, entry["field"], sub,
                                            entry[side])
    return out


def changed_fields(before: Optional[Mapping[str, Any]],
                   after: Mapping[str, Any]) -> list[str]:
    """The top-level field names that differ -- the list view's summary.
    No values (so no masking is needed); ``before=None`` means the first
    version, whose summary is every field it carries."""
    if before is None:
        return sorted(k for k in (after or {}) if not str(k).startswith("_"))
    return sorted({d["field"] for d in diff_definitions(before, after)})


def restore_payload(definition: Mapping[str, Any],
                    accepted_fields: Iterable[str]) -> dict:
    """The body a RESTORE sends through the normal update route.

    Keeps only the fields the update model accepts and drops
    ``RESTORE_NEVER``.  A ``None`` value is kept when the update route's
    clearable set would honour it -- the route decides; this function only
    refuses to send what must never be restored.
    """
    accepted = set(accepted_fields)
    out: dict = {}
    for key, value in (definition or {}).items():
        if key in RESTORE_NEVER or str(key).startswith("_"):
            continue
        if key not in accepted:
            continue
        out[key] = value
    return out
