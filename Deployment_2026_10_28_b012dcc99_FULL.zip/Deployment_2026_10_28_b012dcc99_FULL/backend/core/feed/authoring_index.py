"""What the authoring checks know about EVERY feed, loaded ONCE and kept
current as a batch of saves proceeds (2026-10-10).

Found live by ``scripts/docker_proof/monthly_kafka_merge_feeds_proof.py``:
``POST /api/feed-templates`` creating N members cost 0.56 s/feed at N=50
and 0.98 s/feed at N=400 -- per-member cost GROWING with N, i.e. quadratic
-- which extrapolates to ~3 hours for the owner's 4,000 (SYSTEM_ENTITY,
EventCode) feeds, in one HTTP request.  Two checks inside ``create_feed``
/ ``replace_feed_dependencies`` listed every feed per member:

* **FR-ART-10** (``feed_api._refuse_filename_collision``): listed every
  feed and rendered each one's filename template twice to compare with
  the candidate -- O(N) renders per save;
* **FR-DEP-22** (``feed_api._refuse_dependency_cycle``): listed every feed
  and ran ONE ``list_etl_dependency_mappings`` query PER FEED to build the
  dependency graph -- O(N) queries per save (20,301 queries for 200
  members in the profile).

Both are correct for a hand-authored feed (one save, one listing) and
quadratic for a matrix.  The fix is not a second create path: the SAME
two checks run for a template member, but they read THIS snapshot when
one is in force (``feed_api._authoring_index``, a ContextVar the template
apply sets for the duration of its matrix) instead of listing the
database again.  The snapshot is kept correct as members land -- the
create / update routes :meth:`upsert_feed` the committed row and the
dependency route :meth:`set_dependency_keys` -- so a collision INSIDE the
matrix (member 2 against member 1, saved a moment ago) is still refused
with the same FR-ART-10 sentence, naming member 1.

Without a snapshot in force (the single-feed routes) the checks load one
of their own: :meth:`AuthoringIndex.load` is two queries (every feed,
every active dependency key), and the collision index is built lazily
on first use -- which is also what the single routes cost before, minus
the N mapping queries the cycle check no longer runs.
"""
from __future__ import annotations

from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional

from core.feed.filename_collision import Collision, CollisionIndex


def dependency_graph(feeds: Iterable[Mapping[str, Any]],
                     keys_of: Callable[[int], Iterable[str]], *,
                     this_id: int, this_etl_id: int,
                     new_keys: Iterable[str],
                     effective_etl_id: Callable[[Mapping[str, Any]], int]
                     ) -> Dict[str, List[str]]:
    """The FR-DEP-22 graph: each feed a node (reachable by its NAME or its
    effective etl_id), its edges its dependency keys; the feed being saved
    contributes the keys being saved, not its stored ones.  Pure over its
    inputs -- the one builder both data sources feed."""
    alias_to_node: Dict[str, str] = {}
    node_keys: Dict[str, List[str]] = {}
    for f in feeds or []:
        fid = int(f["id"])
        eid = this_etl_id if fid == this_id else effective_etl_id(f)
        node = str(f.get("name") or f"feed:{fid}")
        alias_to_node.setdefault(node, node)
        alias_to_node.setdefault(str(int(eid)), node)
        if fid == this_id:
            node_keys[node] = [str(k) for k in new_keys]
        else:
            node_keys[node] = [str(k or "") for k in keys_of(int(eid))]
    return {node: [alias_to_node.get(k, k) for k in keys]
            for node, keys in node_keys.items()}


class AuthoringIndex:
    """Every feed as the authoring checks see it, plus every feed's active
    dependency keys, plus (lazily) the filename-collision index."""

    def __init__(self, feeds: Iterable[Mapping[str, Any]],
                 dependency_rows_by_etl_id: Mapping[int, Iterable[Mapping[str, Any]]]):
        self._feeds: Dict[int, dict] = {}
        for f in feeds or []:
            self._feeds[int(f["id"])] = dict(f)
        self._rows: Dict[int, List[dict]] = {
            int(k): [dict(r) for r in v]
            for k, v in (dependency_rows_by_etl_id or {}).items()}
        self._collisions: Optional[CollisionIndex] = None
        self.upserts = 0
        self.key_sets = 0

    # ── construction ────────────────────────────────────────────────────

    @classmethod
    def load(cls, db: Any) -> "AuthoringIndex":
        """Two queries: every feed (active or not -- a retired feed's
        filename still lands where it landed) and every ACTIVE mapping's
        (id, dependency_key) under its etl_id."""
        feeds = db.list_feed_configs() or []
        rows = db.list_active_etl_dependency_rows_by_etl_id() or {}
        return cls(feeds, rows)

    # ── reads ───────────────────────────────────────────────────────────

    def feeds(self) -> List[dict]:
        return list(self._feeds.values())

    def dependency_rows(self, etl_id: int) -> List[dict]:
        """The active mappings under ``etl_id`` as ``{"id", "dependency_key"}``
        rows -- what ``list_etl_dependency_mappings`` gave the per-feed loops."""
        return [dict(r) for r in self._rows.get(int(etl_id), ())]

    def dependency_keys(self, etl_id: int) -> List[str]:
        return [str(r.get("dependency_key") or "") for r in self._rows.get(int(etl_id), ())]

    def schedule_declarations(self, *, active_only: bool = False) -> List[dict]:
        """The ``list_feed_schedule_declarations`` projection, from the
        snapshot (the on-completion cycle walk reads it)."""
        out = []
        for f in self._feeds.values():
            if active_only and not f.get("is_active", True):
                continue
            out.append({"id": f.get("id"), "name": f.get("name"),
                        "is_active": f.get("is_active", True),
                        "schedule_declaration": f.get("schedule_declaration")})
        return out

    def collisions(self, candidate: Mapping[str, Any], *,
                   exclude_id: Any = None) -> List[Collision]:
        if self._collisions is None:
            self._collisions = CollisionIndex(self._feeds.values())
        return self._collisions.collisions(candidate, exclude_id=exclude_id)

    # ── writes: a save the checks must see from now on ──────────────────

    def upsert_feed(self, feed: Mapping[str, Any]) -> None:
        """A feed row as COMMITTED (create or update) -- the whole row, so
        the next check compares against what is in the database."""
        if feed is None or feed.get("id") is None:
            return
        row = dict(feed)
        self._feeds[int(row["id"])] = row
        if self._collisions is not None:
            self._collisions.add(row)
        self.upserts += 1

    def set_dependency_rows(self, etl_id: int,
                            rows: Iterable[Mapping[str, Any]]) -> None:
        """The ACTIVE mappings now stored under ``etl_id`` (the dependency
        route replaces them wholesale, so this replaces them wholesale)."""
        self._rows[int(etl_id)] = [
            {"id": r.get("id"), "dependency_key": str(r.get("dependency_key") or "")}
            for r in rows]
        self.key_sets += 1
