"""How a feed's rows reach an Oracle table -- ONE answer, every lane.

Two rules live here, each once, both applied by the native lane
(``core/feed_engine.py::_deliver_oracle``) and the Spark lanes
(``spark/jobs/generic_feed.py::_write_oracle``):

  A. a MISSING destination table is created, from the result, the same
     way on every lane (below);
  B. the target changes in ONE transaction or not at all (see "ALL OR
     NOTHING" further down).

WHY RULE A EXISTS (2026-10-07)
------------------------------
The same feed -- Trino source, ``destination_type: oracle``, ``mode:
append``, ``execution_backend: auto`` -- COMPLETED when the size router sent
it to ``spark_k8s`` and FAILED at ``deliver_oracle`` when it sent it to
``native``.  Spark's JDBC writer creates a table that does not exist; the
native lane refused ("writes into an existing table and does not create
one").  Routing is automatic by size, so whether a feed succeeded depended
on how much data it had TODAY: a decision made twice with two answers.
Found live on Docker, ``scripts/docker_proof/spark_pods_proof.py`` S1.

THE RULE, applied by both lanes
-------------------------------
1. Probe the table (``SELECT * FROM <t> WHERE 1=0``).  It EXISTS -> use it
   as it is.  This module never issues ALTER, and never creates over it.
2. It does NOT exist (ORA-00942) -> CREATE it from the result schema:
   identifiers from ``oracle_identifiers`` (upper case, the identifier
   Oracle itself creates), column types from :data:`_ORACLE_TYPES` below.
   Every column is nullable.
3. A result column whose type has no Oracle home (a nested type, a TIME,
   an untyped all-NULL column) REFUSES before anything is created, naming
   the column and the fix.  A mangled table is worse than no table.
4. Two first runs at once: both probe "missing", both CREATE, one gets
   ORA-00955 ("name is already used").  The loser does NOT fail -- it
   re-probes and appends into the winner's table, exactly as it would have
   had it arrived a second later.
5. Mode semantics are unchanged by creation: ``append``/``insert`` insert,
   ``truncate_insert`` truncates then inserts (a just-created table is
   empty, so the truncate is a no-op).  There is no ``replace``.  Mode is
   honoured whatever the row count: an EMPTY result into an existing
   table under ``truncate_insert`` empties it on every lane (Spark always
   did; native used to return before connecting and left yesterday's rows
   in place, reading as today's).
6. An EMPTY result never CREATES a table, on any lane.  The native lane's
   empty parquet carries no source types -- ``execute_sql_to_parquet``
   writes every column of a zero-row result as a string -- so a table
   created from it would be VARCHAR2 forever, while the Spark lane (which
   reads JDBC metadata) would have created real types: two answers again.
   Nothing is written, the receipt says why, and the first non-empty run
   creates the table.  The Spark job skips its JDBC writer in that case,
   because Spark's writer would otherwise create the table itself.

WHO CREATES THE TABLE ON THE SPARK LANE NOW
-------------------------------------------
The job (``spark/jobs/generic_feed.py::_write_oracle``) runs this SAME
rule through the driver JVM's Oracle JDBC driver BEFORE Spark's own
writer, so Spark always finds an existing table and only inserts.  Spark's
Oracle dialect therefore no longer picks the column types, and that was
necessary, not tidy: Spark 3.5.3's dialect (the image's version) creates

    FloatType / DoubleType -> NUMBER(19, 4)   -- ROUNDS every value to four
                                                 decimal places, and any
                                                 |x| >= 10**15 is ORA-01438
    StringType             -> VARCHAR2(255)   -- any longer value fails the
                                                 whole write

Copying that mapping into the native lane would have made the two lanes
agree by making both of them lose data.  The table every lane now creates:

    logical type                 Oracle          Spark 3.5.3 default
    ---------------------------  --------------  ---------------------
    boolean                      NUMBER(1)       NUMBER(1)
    any integer (8..64 bit)      NUMBER(19)      NUMBER(3/5/10/19)
    unsigned 64-bit (Arrow)      NUMBER(20)      (no such Spark type)
    float32 / float64            BINARY_DOUBLE   NUMBER(19, 4)
    decimal(p, s)                NUMBER(38, s)   DECIMAL(p, s)
    string / char / varchar      VARCHAR2(4000)  VARCHAR2(255)
    binary                       BLOB            BLOB
    date                         DATE            DATE
    timestamp (s/ms/us, any tz)  TIMESTAMP(6)    TIMESTAMP
    timestamp (ns, Arrow only)   TIMESTAMP(9)    (Spark has no ns)
    nullability                  always NULL     NOT NULL when the
                                                 DataFrame field is

WHY the widths collapse (integers to NUMBER(19), decimals to precision
38): the two lanes do not SEE the same source type.  The Spark lane reads
the source's JDBC metadata (Trino ``integer`` -> IntegerType); the native
lane sees the parquet it wrote from Python values, where every integer is
int64 and ``ParquetStreamWriter._widen_decimals`` widens every decimal to
precision 38.  Keying the DDL on the width would hand the SAME source
column NUMBER(10) on one lane and NUMBER(19) on the other.  The widest
type either lane can see is a superset of both, and nothing is lost.  The
scale of a decimal survives on both lanes, so it is kept.

A SQL TIME column -- rule C (2026-10-07, second pass)
---------------------------------------------------
Oracle has no TIME type, and Spark has none either: Spark's JDBC reader
maps ``java.sql.Types.TIME`` to TimestampType, so the Spark lanes used to
deliver ``09:30:00`` as ``1970-01-01 09:30:00`` -- a wrong value presented
as right -- while native refused it (Oracle) or carried it (files).
Decision K4 of docs/FEED_LANE_CONTRACT_2026_10_07.html: a TIME is carried
into FILES as text ``HH:MM:SS[.ffffff]`` on every lane
(``core/feed/lane_output.py``) and REFUSED only for an Oracle
destination, by :func:`refuse_time_columns` -- ONE message, whichever lane
-- before anything is written:

* native: from the parquet schema (:func:`time_columns_in_arrow`), before
  connecting -- whether or not the table exists;
* Spark lanes: from the SOURCE's JDBC metadata (:func:`time_columns_in_
  jdbc`, the same ``SELECT * FROM (...) WHERE 1=0`` Spark's own reader
  issues), before the read is materialised (afterwards a TIME and a
  TIMESTAMP are indistinguishable).

NaN and +/-Infinity -- K4 (2026-10-07)
-------------------------------------
A non-finite float becomes NULL in an Oracle destination on every lane:
native binds :func:`oracle_bind_value` (it always did, inline), and the
Spark publish selects :func:`publish_select_item` -- ``CASE WHEN c IS NAN
OR c IS INFINITE THEN NULL ELSE c END`` -- for a column staged as
BINARY_DOUBLE.  Spark used to write the NaN itself.

ALL OR NOTHING -- rule B (2026-10-07)
-------------------------------------
A delivery changes the counterparty's table in ONE transaction, or leaves
it exactly as it was.  Until today neither lane did:

* Spark's JDBC writer commits EACH PARTITION in its own transaction, so a
  driver killed mid-write left the partitions already written in the
  target, and the retry wrote them again (duplicates).  ``truncate_insert``
  ran Spark's ``truncate=true``: a TRUNCATE (DDL -- it commits on its own)
  before the first row, so a failure left the table half-filled, and
  yesterday's rows were gone either way.
* native inserted in one transaction, but its ``truncate_insert`` also
  issued TRUNCATE first, with the same consequence.

Now ``truncate_insert`` is ``DELETE FROM <target>`` INSIDE the transaction
that inserts (:func:`replace_rows_sql`), on both lanes, and:

* native: probe/create (DDL, before anything is pending) -> DELETE (if
  truncate_insert) -> the batched INSERTs -> ONE commit; any failure rolls
  back.  One oracledb connection is one transaction, so no stage is
  needed.
* Spark: the job cannot make Spark's per-partition commits one
  transaction, so Spark writes a per-run STAGING table instead
  (:func:`staging_table_name`, in the login's own schema) and the driver
  then publishes it in ONE JDBC transaction -- DELETE (if truncate_insert)
  + ``INSERT INTO target SELECT ... FROM stage LOG ERRORS ...`` -- and
  drops the stage (PURGE: it holds the feed's data, so it must not linger
  in the recycle bin).  A kill at any point before the commit leaves the
  target untouched; a stage left by a crashed run is dropped by the next
  Spark Oracle write with the same login once it is older than
  :data:`STAGE_SWEEP_AGE_HOURS` (:func:`_stale_stages_sql`).  The row
  counts reported are the database's own (the stage's COUNT, the publish's
  update count, the error log's COUNT) -- never a second ``df.count()``
  (which re-executed the source query).

``max_error_percent`` -- ONE tolerance, both lanes (second pass)
--------------------------------------------------------------
A row the database rejects (too long, overflow, NOT NULL, a constraint) is
excluded and COUNTED, the rest commit, and the run is certified INCOMPLETE
-- unless the rejected share exceeds ``max_error_percent`` (default
:data:`DEFAULT_MAX_ERROR_PERCENT`), when the whole delivery rolls back
(:func:`rejection_refusal`, the one comparison both lanes make).  Native
counts rejects with ``executemany(batcherrors=True)``.  Spark used to fail
the whole write on the first rejected row; now:

* the stage is created with the RULE's wide types (:func:`stage_column_
  types`), always nullable, so it accepts every row the result can hold
  (a LOB target column keeps its LOB type -- the rule's VARCHAR2 would be
  narrower than the target);
* the publish converts into the target's own types under ``LOG ERRORS
  INTO`` a per-run error table (``QS_ERR_<same hash>``) ``REJECT LIMIT
  UNLIMITED``, so each rejection is logged rather than fatal;
* inside the transaction: staged == inserted + rejected must reconcile
  (or it rolls back), then the tolerance decides commit or rollback;
* the job reports ``delivered_rows`` / ``dropped_rows`` and the completion
  webhook certifies against them, exactly as native's receipt does.

A string longer than the 4000 bytes a VARCHAR2 stage column holds (K4,
inventory A5): native binds it, the database rejects that ONE row and it
is counted.  The Spark stage used to be VARCHAR2(4000) for every string,
so the stage write itself failed and the whole delivery with it.  The
stage now takes CLOB for a string column whose LONGEST value the job
measured over 4000 bytes (:func:`stage_column_types`'
``max_string_bytes``), and the publish's conversion into the target's
VARCHAR2 rejects exactly that row under LOG ERRORS -- one rejected row,
counted by :func:`rejection_refusal`, as on native.  The refusal message
is :func:`rejection_message` on both lanes.

THE MIRROR
----------
The Spark job cannot import ``backend/core`` (a different image), so this
file exists TWICE, byte-identical, exactly like ``oracle_identifiers.py``:

    backend/core/feed/oracle_destination_table.py     <- authored here
    spark/jobs/qs_oracle_destination_table.py         <- mechanical copy

Guard: backend/tests/test_oracle_destination_one_rule_2026_10_07.py
byte-compares them and drives BOTH real call sites against one fake
Oracle, asserting the DDL they issue for the same result is EQUAL, and
that a write killed part-way leaves the target as it was.

Stdlib only: it imports under the API's Python and the Spark image's.
"""
from __future__ import annotations

import hashlib
import logging
import re
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

# NO import of the identifier rule here, on purpose.  It lives in
# oracle_identifiers.py, whose mirror in the job image has a different
# module name (qs_oracle_identifiers), and a byte-identical file cannot
# import a different name in each image without a try/except fallback --
# which is an import of ``core`` the job image cannot satisfy.  Each caller
# hands in ITS copy of ``canonical_oracle_columns`` (the
# ``canonical_names`` parameter); the two copies are byte-compared by
# tests/test_oracle_identifier_casing_2026_09_21.py.

#: The two paths this file occupies (see THE MIRROR above).
MIRROR_PATHS = (
    "backend/core/feed/oracle_destination_table.py",
    "spark/jobs/qs_oracle_destination_table.py",
)

#: ``SCHEMA.TABLE`` or ``TABLE``, unquoted -- the grammar the native lane
#: has always validated a destination table name against.  The name is
#: interpolated into DDL, so nothing else is accepted.
_TABLE_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)?$")

#: Oracle's error codes for the two answers this module acts on.
ORA_TABLE_MISSING = "ORA-00942"   # table or view does not exist
ORA_NAME_IN_USE = "ORA-00955"     # name is already used by an existing object

#: logical type -> the Oracle column type every lane creates.  ONE table;
#: the two parsers below only translate their engine's spelling into these
#: keys.  ``decimal`` is formatted with the source's scale.
_ORACLE_TYPES = {
    "boolean": "NUMBER(1)",
    "integer": "NUMBER(19)",
    "unsigned64": "NUMBER(20)",
    "float": "BINARY_DOUBLE",
    "decimal": "NUMBER(38, {scale})",
    "string": "VARCHAR2(4000)",
    "binary": "BLOB",
    "date": "DATE",
    "timestamp": "TIMESTAMP(6)",
    "timestamp_ns": "TIMESTAMP(9)",
}

#: Oracle's NUMBER precision ceiling and scale range.
_MAX_PRECISION = 38
_MIN_SCALE, _MAX_SCALE = -84, 127

_DECIMAL = re.compile(r"^decimal(?:32|64|128|256)?\(\s*(\d+)\s*,\s*(-?\d+)\s*\)$")


class OracleTableCreateError(ValueError):
    """The result cannot become an Oracle table: refused, nothing created.

    A ``ValueError`` on purpose: the native delivery's retry policy treats
    ValueError as deterministic configuration and does not retry it.  A
    nested column will still be nested in sixty seconds.
    """


class OracleTableUnavailable(RuntimeError):
    """The table could not be probed or created for a reason this rule does
    not own (privileges, a dead listener).  RuntimeError: possibly
    transient, so the delivery's normal retry applies."""


def _decimal_type(match, column: str, spelled: str) -> str:
    precision, scale = int(match.group(1)), int(match.group(2))
    if precision > _MAX_PRECISION:
        raise OracleTableCreateError(
            f"Column {column!r} is {spelled}: precision {precision} exceeds "
            f"Oracle's NUMBER limit of {_MAX_PRECISION} digits. Round or "
            f"cast it in the feed's source query. Nothing was created.")
    if not _MIN_SCALE <= scale <= _MAX_SCALE:
        raise OracleTableCreateError(
            f"Column {column!r} is {spelled}: scale {scale} is outside "
            f"Oracle's range ({_MIN_SCALE}..{_MAX_SCALE}). Nothing was "
            f"created.")
    return _ORACLE_TYPES["decimal"].format(scale=scale)


def _unmappable(column: str, spelled: str, engine: str) -> OracleTableCreateError:
    return OracleTableCreateError(
        f"Column {column!r} has {engine} type {spelled!r}, which has no "
        f"Oracle column type, so this result cannot be written to Oracle "
        f"(neither a missing table nor the delivery's staging table can "
        f"hold it). Cast it in the feed's source query (to a string, "
        f"number, date or timestamp). Nothing was created or written.")


def oracle_type_for_arrow(arrow_type: Any, column: str = "?") -> str:
    """The Oracle type for one column of the NATIVE lane's parquet.

    ``arrow_type`` is a pyarrow DataType or its ``str()``; parsed from the
    string so this module needs no pyarrow.
    """
    text = str(arrow_type).strip()
    low = text.lower()
    if low.startswith("dictionary<"):
        # dictionary<values=string, indices=int32, ordered=0>: the VALUES
        # are the column's type; the dictionary is an encoding.
        m = re.match(r"^dictionary<values=(.+?), indices=", text)
        if m:
            return oracle_type_for_arrow(m.group(1), column)
    if low == "bool":
        return _ORACLE_TYPES["boolean"]
    if low in ("int8", "int16", "int32", "int64", "uint8", "uint16", "uint32"):
        return _ORACLE_TYPES["integer"]
    if low == "uint64":
        return _ORACLE_TYPES["unsigned64"]
    if low in ("halffloat", "float", "double"):
        return _ORACLE_TYPES["float"]
    m = _DECIMAL.match(low)
    if m:
        return _decimal_type(m, column, text)
    if low in ("string", "large_string", "string_view", "utf8", "large_utf8"):
        return _ORACLE_TYPES["string"]
    if (low in ("binary", "large_binary", "binary_view")
            or low.startswith("fixed_size_binary")):
        return _ORACLE_TYPES["binary"]
    if low.startswith(("date32", "date64")):
        return _ORACLE_TYPES["date"]
    m = re.match(r"^timestamp\[(s|ms|us|ns)(?:,.*)?\]$", low)
    if m:
        return _ORACLE_TYPES["timestamp_ns" if m.group(1) == "ns"
                             else "timestamp"]
    raise _unmappable(column, text, "Arrow")


def oracle_type_for_spark(spark_type: Any, column: str = "?") -> str:
    """The Oracle type for one column of the SPARK lane's DataFrame.

    ``spark_type`` is the ``simpleString`` ``df.dtypes`` reports
    (``bigint``, ``decimal(18,2)``, ``timestamp``) -- a string, so this
    module needs no pyspark.
    """
    text = str(spark_type).strip()
    low = text.lower()
    if low == "boolean":
        return _ORACLE_TYPES["boolean"]
    if low in ("tinyint", "byte", "smallint", "short", "int", "integer",
               "bigint", "long"):
        return _ORACLE_TYPES["integer"]
    if low in ("float", "real", "double"):
        return _ORACLE_TYPES["float"]
    m = _DECIMAL.match(low)
    if m:
        return _decimal_type(m, column, text)
    if low == "string" or re.match(r"^(var)?char\(\d+\)$", low):
        return _ORACLE_TYPES["string"]
    if low == "binary":
        return _ORACLE_TYPES["binary"]
    if low == "date":
        return _ORACLE_TYPES["date"]
    if low in ("timestamp", "timestamp_ntz", "timestamp_ltz"):
        return _ORACLE_TYPES["timestamp"]
    raise _unmappable(column, text, "Spark")


_TYPE_PARSERS = {"arrow": oracle_type_for_arrow, "spark": oracle_type_for_spark}


def _create_table_sql(table: str, source_columns: Sequence[Any],
                      source_types: Sequence[Any], type_system: str,
                      canonical_names: Callable[[Sequence[Any]], List[str]],
                      ) -> str:
    """The ONE ``CREATE TABLE`` statement for this result.

    ``canonical_names`` is the caller's copy of
    ``oracle_identifiers.canonical_oracle_columns`` (see the import note).

    Every column is mapped (and every refusal raised) BEFORE the statement
    exists, so a refusal can never leave half a table behind.
    """
    if not _TABLE_NAME.match(str(table or "")):
        raise OracleTableCreateError(f"Invalid Oracle table name: {table!r}")
    columns = list(source_columns)
    types = list(source_types)
    if not columns:
        raise OracleTableCreateError(
            f"Oracle delivery: {table} does not exist and the feed's result "
            f"has no columns to create it from. Nothing was created.")
    if len(types) != len(columns):
        raise OracleTableCreateError(
            f"Oracle delivery: {len(columns)} result columns but "
            f"{len(types)} column types -- the result schema could not be "
            f"read, so {table} was not created.")
    parse = _TYPE_PARSERS[type_system]
    oracle_types = [parse(t, str(c)) for c, t in zip(columns, types)]
    names = canonical_names(columns)
    body = ", ".join(f'"{n}" {t}' for n, t in zip(names, oracle_types))
    return f"CREATE TABLE {table} ({body})"


def ensure_oracle_table(table: str,
                        source_columns: Sequence[Any],
                        source_types: Sequence[Any],
                        type_system: str,
                        probe: Callable[[str], List[str]],
                        execute: Callable[[str], Any],
                        result_is_empty: Callable[[], bool],
                        canonical_names: Callable[[Sequence[Any]], List[str]],
                        ) -> Tuple[Optional[List[str]], bool]:
    """Rules 1-4 and 6.  Returns ``(the table's own column names, created)``.

    ``(None, False)`` is rule 6: the table does not exist and the result is
    empty, so nothing was created and there is nothing to write.  The
    caller must then write NOTHING -- not truncate, not insert.

    ``probe(sql)`` runs a query and returns its column names, raising on
    failure; ``execute(sql)`` runs a statement.  Both lanes pass their own
    driver's version of the two -- oracledb on native, the JVM's JDBC on
    Spark -- and nothing else differs.  ``type_system`` says how to read
    ``source_types``: ``"arrow"`` (native) or ``"spark"``.
    ``result_is_empty`` is asked only when the table is missing (on Spark
    it costs an action).  ``canonical_names`` is the caller's copy of the
    identifier rule (``canonical_oracle_columns``).
    """
    probe_sql = f"SELECT * FROM {table} WHERE 1=0"
    try:
        return list(probe(probe_sql)), False
    except Exception as exc:
        if ORA_TABLE_MISSING not in str(exc):
            raise OracleTableUnavailable(
                f"Oracle delivery could not read the shape of {table}: "
                f"{exc}") from exc

    if result_is_empty():
        return None, False

    ddl = _create_table_sql(table, source_columns, source_types, type_system,
                            canonical_names)
    created = True
    try:
        execute(ddl)
    except Exception as exc:
        if ORA_NAME_IN_USE not in str(exc):
            raise OracleTableUnavailable(
                f"Oracle delivery: {table} does not exist and could not be "
                f"created: {exc}") from exc
        # Rule 4: another run created it between our probe and our CREATE.
        created = False
    try:
        return list(probe(probe_sql)), created
    except Exception as exc:
        raise OracleTableUnavailable(
            f"Oracle delivery could not read the shape of {table} after "
            f"creating it: {exc}") from exc


# ── Rule B: all or nothing, with ONE tolerance ─────────────────────────

#: Every table this module creates for a delivery is named ``QS_STG_`` (the
#: stage) or ``QS_ERR_`` (its DML error log) + 16 hex digits: 23
#: characters, inside even pre-12.2 Oracle's 30-byte identifier limit, and
#: a shape the sweep can recognise without trusting anything else in the
#: schema.
STAGE_PREFIX = "QS_STG_"
ERROR_LOG_PREFIX = "QS_ERR_"
_STAGE_NAME = re.compile(r"^QS_(STG|ERR)_[0-9A-F]{16}$")

#: A stage older than this is a crashed run's and is dropped by the next
#: Spark-lane Oracle write with the same login.  Longer than any run the
#: Spark lane's own timeouts allow, so a live run's stage is never taken.
STAGE_SWEEP_AGE_HOURS = 24

#: At most this many stale tables are dropped per write: the sweep is
#: housekeeping and must not turn one delivery into a long DDL loop.
_STAGE_SWEEP_LIMIT = 50

#: The rejected-row share above which a delivery rolls back, when the
#: destination does not declare ``max_error_percent``.  ONE default, both
#: lanes.
DEFAULT_MAX_ERROR_PERCENT = 5.0

#: A target column of one of these types keeps it on the STAGE: the rule's
#: own type for the value (VARCHAR2(4000), BLOB) would be narrower than
#: what the target accepts, or not convertible into it.
_LOB_STAGE_TYPES = {"CLOB": "CLOB", "NCLOB": "NCLOB", "BLOB": "BLOB",
                    "LONG": "CLOB", "LONG RAW": "BLOB"}

#: The control columns of an Oracle DML error logging table -- all it
#: needs.  Data columns are optional, and leaving them out means a LOB in
#: the target can never make the error table unusable.
_ERROR_LOG_COLUMNS = ('"ORA_ERR_NUMBER$" NUMBER, "ORA_ERR_MESG$" VARCHAR2(2000), '
                      '"ORA_ERR_ROWID$" UROWID, "ORA_ERR_OPTYP$" VARCHAR2(2), '
                      '"ORA_ERR_TAG$" VARCHAR2(2000)')

_log = logging.getLogger(__name__)


def replace_rows_sql(table: str) -> str:
    """``truncate_insert``'s first statement, on EVERY lane: a DELETE.

    Never TRUNCATE: TRUNCATE is DDL, it commits on its own, so it cannot
    share a transaction with the INSERT that refills the table -- a
    failure after it leaves the table empty or half-filled.
    """
    if not _TABLE_NAME.match(str(table or "")):
        raise OracleTableCreateError(f"Invalid Oracle table name: {table!r}")
    return f"DELETE FROM {table}"


def max_error_percent(dest_config: Optional[dict]) -> float:
    """The destination's declared tolerance, or the one default."""
    raw = (dest_config or {}).get("max_error_percent")
    return DEFAULT_MAX_ERROR_PERCENT if raw is None else float(raw)


def rejection_refusal(rejected: int, total: int,
                      max_percent: float) -> Optional[str]:
    """THE tolerance decision, both lanes: ``None`` when the delivery may
    commit, else the reason it must roll back."""
    if rejected <= 0 or total <= 0:
        return None
    pct = (rejected / total) * 100
    if pct <= max_percent:
        return None
    return (f"Oracle batch error rate {pct:.1f}% exceeds max {max_percent}% "
            f"({rejected}/{total} rows failed)")


def rejection_message(refusal: str, first_errors: Sequence[Any],
                      table: str) -> str:
    """THE words of a tolerance refusal, both lanes: the decision, the
    database's first reasons, and what happened to the target."""
    sample = [str(e) for e in list(first_errors)[:3]]
    return (f"{refusal}; first errors: {sample}. Rolled back; nothing was "
            f"written to {table}.")


def oracle_bind_value(value: Any) -> Any:
    """What one value is bound as (K4): a NaN or +/-Infinity float becomes
    NULL -- an Oracle NUMBER cannot hold one, and a BINARY_DOUBLE that
    stores it hands every reader a value it cannot compare or sum."""
    if isinstance(value, float) and (value != value or value in (
            float("inf"), float("-inf"))):
        return None
    return value


#: The stage types whose values the publish passes through
#: :func:`publish_select_item`'s non-finite rule.
_FLOAT_STAGE_TYPES = ("BINARY_DOUBLE", "BINARY_FLOAT", "FLOAT")


def publish_select_item(column: str, stage_type: Any) -> str:
    """One SELECT-list item of the Spark lane's publish: the column, or --
    for a floating stage column -- :func:`oracle_bind_value`'s rule in
    Oracle SQL (``IS NAN`` / ``IS INFINITE``)."""
    c = f'"{column}"'
    if str(stage_type or "").strip().upper() in _FLOAT_STAGE_TYPES:
        return f"CASE WHEN {c} IS NAN OR {c} IS INFINITE THEN NULL ELSE {c} END"
    return c


def staging_table_name(execution_id: Any) -> str:
    """The per-run stage: derived from the execution id, so a retry of the
    same execution finds (and drops) its own crashed predecessor's stage,
    and two executions never share one.

    Its caller is the
    Spark job image (``spark/jobs/generic_feed.py::_write_oracle_atomically``),
    a separate deployable that imports this file's byte-identical mirror
    and is counted by the callerless sweeps (mirror_job_callers).
    tests/test_oracle_destination_one_rule_2026_10_07.py drives that real
    call site against a fake Oracle.
    """
    digest = hashlib.sha256(str(execution_id).encode("utf-8")).hexdigest()
    return f"{STAGE_PREFIX}{digest[:16].upper()}"


def _error_log_name(stage: str) -> str:
    return ERROR_LOG_PREFIX + stage[len(STAGE_PREFIX):]


#: The most bytes a VARCHAR2 stage column holds (MAX_STRING_SIZE=STANDARD).
VARCHAR2_MAX_BYTES = 4000


def stage_column_types(spark_types: Sequence[Any],
                       target_types: Sequence[Any],
                       columns: Sequence[str],
                       max_string_bytes: Optional[Sequence[Any]] = None
                       ) -> List[str]:
    """The STAGE's column types: the rule's own (wide, so the stage accepts
    every row the result can hold and the TARGET decides, row by row, under
    the error log), except a LOB target column, which keeps its LOB type,
    and a string column whose longest value (``max_string_bytes``, measured
    by the job over the result) is over :data:`VARCHAR2_MAX_BYTES`, which
    is staged as CLOB -- so a too-long value reaches the publish and is ONE
    rejected row there, as on native, instead of failing the stage write.

    Its caller is the
    Spark job image (``spark/jobs/generic_feed.py::_write_oracle_atomically``);
    see :func:`staging_table_name`.
    """
    longest = list(max_string_bytes or [])
    out: List[str] = []
    for i, (col, spark_t, target_t) in enumerate(
            zip(columns, spark_types, target_types)):
        lob = _LOB_STAGE_TYPES.get(str(target_t or "").strip().upper())
        rule = oracle_type_for_spark(spark_t, str(col))
        size = longest[i] if i < len(longest) else None
        if lob is None and rule.startswith("VARCHAR2") \
                and isinstance(size, int) and size > VARCHAR2_MAX_BYTES:
            lob = "CLOB"
        out.append(lob or rule)
    return out


def _column_list(columns: Sequence[str]) -> str:
    return ", ".join(f'"{c}"' for c in columns)


def _drop_stage_sql(stage: str) -> str:
    if not _STAGE_NAME.match(str(stage or "")):
        raise OracleTableCreateError(f"Not a staging table name: {stage!r}")
    return f"DROP TABLE {stage} PURGE"


def _stale_stages_sql(age_hours: float = STAGE_SWEEP_AGE_HOURS) -> str:
    """The login's own stages and error logs older than ``age_hours``."""
    return ("SELECT object_name FROM user_objects "
            "WHERE object_type = 'TABLE' "
            "AND (object_name LIKE 'QS\\_STG\\_%' ESCAPE '\\' "
            "OR object_name LIKE 'QS\\_ERR\\_%' ESCAPE '\\') "
            f"AND created < SYSDATE - ({float(age_hours)} / 24)")


def _sweep_stale_stages(query: Callable[[str], List[Any]],
                        execute: Callable[[str], Any],
                        keep: Sequence[str]) -> int:
    """Drop crashed runs' stages.  Best effort: a sweep that cannot run
    must not fail a delivery that is otherwise fine -- it is logged, and
    the next write tries again."""
    dropped = 0
    try:
        rows = query(_stale_stages_sql())
    except Exception as exc:
        _log.warning("Oracle staging sweep could not list stale stages: %s", exc)
        return 0
    for row in list(rows)[:_STAGE_SWEEP_LIMIT]:
        name = str(row[0] if isinstance(row, (list, tuple)) else row)
        if name in keep or not _STAGE_NAME.match(name):
            continue
        try:
            execute(_drop_stage_sql(name))
            dropped += 1
        except Exception as exc:
            _log.warning("Oracle staging sweep could not drop %s: %s", name, exc)
    if dropped:
        _log.info("Oracle staging sweep dropped %d stale table(s) older than "
                  "%sh", dropped, STAGE_SWEEP_AGE_HOURS)
    return dropped


def _drop_if_present(execute: Callable[[str], Any], name: str) -> None:
    try:
        execute(_drop_stage_sql(name))
    except Exception as exc:
        if ORA_TABLE_MISSING not in str(exc):
            raise OracleTableUnavailable(
                f"Oracle delivery could not clear its staging table {name}: "
                f"{exc}") from exc


def _count(query: Callable[[str], List[Any]], table: str) -> int:
    rows = list(query(f"SELECT COUNT(*) FROM {table}"))
    return int(rows[0][0])


def write_through_stage(*, table: str, stage: str, columns: Sequence[str],
                        stage_types: Sequence[str], mode: str,
                        max_percent: float,
                        execute: Callable[[str], Any],
                        query: Callable[[str], List[Any]],
                        transaction: Callable[..., List[int]],
                        write_stage: Callable[[str], Any]) -> Dict[str, int]:
    """Rule B for a writer that cannot hold one transaction (Spark).

    ``execute(sql)`` runs one auto-committed statement; ``query(sql)``
    returns rows; ``transaction(statements, decide)`` runs the statements in
    ONE transaction, hands their update counts to ``decide`` -- which may
    raise -- and then commits, or rolls back if anything raised;
    ``write_stage(stage)`` is the bulk writer, which may commit partially,
    but only ever into the STAGE.

    ``columns`` are the TARGET's own spellings (rule 1 already applied) and
    ``stage_types`` their stage types (:func:`stage_column_types`).
    Returns ``{"staged_rows", "delivered_rows", "dropped_rows"}`` -- every
    one the database's own count.

    Its caller is the
    Spark job image (``spark/jobs/generic_feed.py::_write_oracle_atomically``),
    a separate deployable that imports this file's byte-identical mirror
    and is counted by the callerless sweeps (mirror_job_callers).
    tests/test_oracle_destination_one_rule_2026_10_07.py drives that real
    call site against a fake Oracle.
    """
    errlog = _error_log_name(stage)
    _sweep_stale_stages(query, execute, keep=(stage, errlog))
    # A crashed earlier attempt of THIS execution: its tables are ours.
    _drop_if_present(execute, stage)
    _drop_if_present(execute, errlog)
    body = ", ".join(f'"{c}" {t}' for c, t in zip(columns, stage_types))
    try:
        execute(f"CREATE TABLE {stage} ({body})")
        execute(f"CREATE TABLE {errlog} ({_ERROR_LOG_COLUMNS})")
    except Exception as exc:
        raise OracleTableUnavailable(
            f"Oracle delivery could not create its staging tables {stage} / "
            f"{errlog} in the login's own schema (the Spark lane writes there "
            f"first so that {table} changes in one transaction; the login "
            f"needs CREATE TABLE): {exc}. Nothing was written to "
            f"{table}.") from exc
    try:
        write_stage(stage)
        staged = _count(query, stage)
        statements: List[str] = []
        if mode == "truncate_insert":
            statements.append(replace_rows_sql(table))
        select_list = ", ".join(publish_select_item(c, t)
                                for c, t in zip(columns, stage_types))
        statements.append(
            f"INSERT INTO {table} ({_column_list(columns)}) "
            f"SELECT {select_list} FROM {stage} "
            f"LOG ERRORS INTO {errlog} ('QS') REJECT LIMIT UNLIMITED")
        outcome: Dict[str, int] = {}

        def _decide(counts: List[int]) -> None:
            inserted = int(counts[-1])
            rejected = _count(query, errlog)
            if inserted + rejected != staged:
                raise OracleTableUnavailable(
                    f"Oracle delivery does not reconcile: {staged} rows "
                    f"staged, {inserted} inserted into {table}, {rejected} "
                    f"rejected. Rolled back; nothing was written.")
            refusal = rejection_refusal(rejected, staged, max_percent)
            if refusal:
                sample = [r[0] for r in query(
                    f"SELECT ORA_ERR_MESG$ FROM {errlog} WHERE ROWNUM <= 3")]
                raise RuntimeError(rejection_message(refusal, sample, table))
            outcome.update(staged_rows=staged, delivered_rows=inserted,
                           dropped_rows=rejected)

        transaction(statements, _decide)
        if outcome["dropped_rows"]:
            _log.error(
                "Oracle delivery COMMITTED WITH %d REJECTED ROWS (%d/%d "
                "inserted into %s, tolerance max_error_percent=%s) -- this "
                "run cannot be certified COMPLETE", outcome["dropped_rows"],
                outcome["delivered_rows"], staged, table, max_percent)
        return outcome
    finally:
        for name in (stage, errlog):
            try:
                execute(_drop_stage_sql(name))
            except Exception as exc:
                _log.warning("Oracle staging table %s was not dropped (%s); "
                             "the sweep will drop it after %sh", name, exc,
                             STAGE_SWEEP_AGE_HOURS)


# ── Rule C: a SQL TIME column ──────────────────────────────────────────

#: ``java.sql.Types.TIME`` and ``TIME_WITH_TIMEZONE``.
JDBC_TIME_TYPE_CODES = (92, 2013)

_ARROW_TIME = re.compile(r"^time(32|64)\[")


class SqlTimeColumnError(ValueError):
    """A SQL TIME column reached a lane or a destination that cannot carry
    it.  ValueError: deterministic, never retried."""


def time_columns_in_arrow(names: Sequence[Any],
                          types: Sequence[Any]) -> List[str]:
    """The NATIVE lane's TIME columns, from its parquet schema."""
    return [str(n) for n, t in zip(names, types)
            if _ARROW_TIME.match(str(t).strip().lower())]


def time_columns_in_jdbc(names: Sequence[Any],
                         type_codes: Sequence[Any]) -> List[str]:
    """A JDBC source's TIME columns, from its ResultSetMetaData -- what
    Spark's reader would silently turn into timestamps.

    Its caller is the
    Spark job image (``spark/jobs/generic_feed.py::_refuse_jdbc_time_columns``);
    see :func:`staging_table_name`.
    """
    return [str(n) for n, c in zip(names, type_codes)
            if int(c) in JDBC_TIME_TYPE_CODES]


def refuse_time_columns(columns: Sequence[str]) -> None:
    """THE refusal for a SQL TIME column bound for an ORACLE destination --
    one message, whichever lane raises it (K4: a file destination carries
    the TIME as text; only Oracle, which has no TIME type, refuses)."""
    if not columns:
        return
    names = list(columns)
    example = names[0]
    raise SqlTimeColumnError(
        f"Column(s) {names} are SQL TIME values and Oracle has no TIME "
        f"column type. CAST them to a string in the feed's source SQL -- "
        f"e.g. CAST({example} AS VARCHAR) -- so every lane delivers the same "
        f"text. Nothing was written.")
