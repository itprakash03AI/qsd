"""
Foundation C — fan-out to child file runs + derived parent status
(BRD 2026-09-02, §4.2/§4.3, FR-RUN-02/04/05).

* :func:`expand_run` — the declared partition list expands into child
  rows in status ``pending`` BEFORE anything executes (FR-RUN-05).
  Cheap and restartable: re-expansion inserts only the missing rows and
  never touches an existing child's state.  The reason a child is a ROW
  and not a loop iteration is addressability — a loop iteration cannot
  be re-run alone, and "re-run file 738 without touching the other 999"
  is a hard requirement (FR-RUN-02, §4.3).

* :func:`derive_parent_status` — the parent's status is DERIVED from
  its children against the DECLARED set, and never written directly
  (FR-RUN-04).  A directly-written parent is how a re-run of one child
  leaves a permanently failed parent, or how a parent reports complete
  while a child is still writing.  Counters may be carried for display;
  the verdict is recomputed here, not accumulated.

* :func:`recompute_parent` — loads the run's declaration + children and
  writes the DERIVED verdict onto the parent row, terminal states only
  (a non-terminal parent row is owned by its queue-worker claim).

The comparison is a SET comparison, not a counter reaching a total
(FR-CMP-05): a declared partition with NO child row — the "child that
never existed" (§9.2) — blocks completion exactly like a failed child,
and is named in the verdict.

Deliberately no imports from feed_engine / queue_worker / pipeline —
those workstreams call INTO this module, never the reverse.  The ``dao``
seam is any object exposing the FeedsMixin Foundation-C methods.
"""
from __future__ import annotations

import logging
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

# Single source of the status vocabulary — the same tuple builds the DB
# CHECK constraint, so this module and the database can never drift.
from core.db.models import (
    FEED_FILE_RUN_STATUSES,
    FEED_FILE_RUN_TERMINAL_STATUSES,
)

logger = logging.getLogger(__name__)

_IN_FLIGHT_STATUSES = ("pending", "running")

# Parent statuses this module may derive.  Deliberately the same words
# the feed_runs row already uses, so operator screens need no mapping.
PARENT_PENDING = "pending"
PARENT_RUNNING = "running"
PARENT_COMPLETED = "completed"
PARENT_FAILED = "failed"
PARENT_CANCELLED = "cancelled"


class FanoutError(ValueError):
    """A fan-out request that must be refused loudly."""


@dataclass(frozen=True)
class ExpansionResult:
    """What :func:`expand_run` did — inserted rows only, nothing executed."""

    feed_run_id: int
    declared_count: int
    inserted: int
    existing: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "feed_run_id": self.feed_run_id,
            "declared_count": self.declared_count,
            "inserted": self.inserted,
            "existing": self.existing,
        }


@dataclass(frozen=True)
class ParentVerdict:
    """The DERIVED parent status (FR-RUN-04) — recomputed, never
    accumulated.  ``complete`` is True only when the declared set and
    the completed-children set are the SAME set (FR-CMP-05)."""

    status: str
    complete: bool
    declared_count: int
    counts: dict[str, int]
    missing_identities: tuple[str, ...] = ()      # declared, no child row
    undeclared_identities: tuple[str, ...] = ()   # child row, not declared
    total_rows: int | None = None                 # sum of child row_counts, complete runs only
    reason: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "complete": self.complete,
            "declared_count": self.declared_count,
            "counts": dict(self.counts),
            "missing_identities": list(self.missing_identities),
            "undeclared_identities": list(self.undeclared_identities),
            "total_rows": self.total_rows,
            "reason": self.reason,
        }


def _identities_of(declaration: Any) -> list[str]:
    """Accept a completeness.PartitionDeclaration, a stored declaration
    dict, or a plain iterable of identities."""
    if declaration is None:
        raise FanoutError(
            "declaration is None — fan-out without a declared list would "
            "make the §9.3 set comparison impossible")
    idents = getattr(declaration, "identities", None)
    if idents is None and isinstance(declaration, dict):
        idents = declaration.get("identities")
    if idents is None:
        idents = declaration
    if isinstance(idents, (str, bytes)):
        raise FanoutError(
            "identities must be an iterable of partition identities, not "
            "a single string — a string iterates as characters")
    if not isinstance(idents, Iterable):
        raise FanoutError(
            f"identities must be an iterable, got "
            f"{type(idents).__name__} — a count is not a list (FR-CMP-02)")
    out: list[str] = []
    for ident in idents:
        if ident is None:
            raise FanoutError("identities contains None — an identity "
                              "that names nothing names nothing")
        s = str(ident)
        if not s:
            raise FanoutError("identities contains an empty identity")
        out.append(s)
    return out


def expand_run(dao, *, feed_run_id: int, declaration: Any,
               feed_config_id: int | None = None,
               business_date=None,
               created_by: str | None = None) -> ExpansionResult:
    """FR-RUN-05 — expand the declared partition list into ``pending``
    child rows before anything executes.

    Nothing here executes, claims, or schedules — it only writes rows.
    Idempotent: a partition that already has a child keeps its state
    (that is what makes a crash mid-expansion repairable by calling this
    again, and what keeps a re-expansion after "re-run file 738" from
    trampling the other 999).
    """
    idents = _identities_of(declaration)
    seen: set[str] = set()
    for ident in idents:
        if ident in seen:
            raise FanoutError(
                f"declared partition list contains duplicate identity "
                f"{ident!r} — (feed_run_id, partition_key) is unique; a "
                f"duplicate means the declaration query is wrong")
        seen.add(ident)
    res = dao.expand_feed_file_runs(
        feed_run_id=int(feed_run_id),
        partition_keys=idents,
        feed_config_id=feed_config_id,
        business_date=business_date,
        created_by=created_by,
    )
    result = ExpansionResult(
        feed_run_id=int(feed_run_id),
        declared_count=len(idents),
        inserted=int(res.get("inserted", 0)),
        existing=int(res.get("existing", 0)),
    )
    logger.info(
        "[fanout] run %s: %d declared partition(s) -> %d child row(s) "
        "inserted, %d already existed (states preserved)",
        feed_run_id, result.declared_count, result.inserted,
        result.existing)
    return result


def derive_parent_status(declared_identities: Iterable[Any],
                         children: Iterable[dict[str, Any]],
                         ) -> ParentVerdict:
    """FR-RUN-04 — the parent verdict, recomputed from scratch.

    Rules, in order:
    * a child in flight (pending/running) → the parent is in flight —
      never terminal, whatever else is true;
    * a declared partition with NO child row (§9.2's "child that never
      existed") or an UNDECLARED child row → the parent can never be
      ``complete``; with nothing in flight the verdict is ``failed``
      and the reason NAMES the identities;
    * all terminal: every declared partition completed and nothing
      undeclared → ``completed`` (the set comparison, FR-CMP-05);
      any failure → ``failed``; otherwise → ``cancelled``;
    * zero declared and zero children → vacuously complete (the
      on_empty=skip case; the completeness layer marks it ASSERTED,
      not verified — this function only answers the set question).
    """
    declared = [str(i) for i in (declared_identities or [])]
    declared_set = set(declared)
    kids = list(children or [])

    counts: dict[str, int] = {s: 0 for s in FEED_FILE_RUN_STATUSES}
    completed_keys: set[str] = set()
    child_keys: set[str] = set()
    total_rows = 0
    rows_known = True
    for child in kids:
        status = str(child.get("status"))
        key = str(child.get("partition_key"))
        child_keys.add(key)
        counts[status] = counts.get(status, 0) + 1
        if status == "completed":
            completed_keys.add(key)
            rc = child.get("row_count")
            if rc is None:
                rows_known = False
            else:
                total_rows += int(rc)

    missing = tuple(i for i in declared if i not in child_keys)
    undeclared = tuple(sorted(child_keys - declared_set))
    in_flight = any(counts.get(s, 0) for s in _IN_FLIGHT_STATUSES)
    terminal_total = sum(counts.get(s, 0)
                         for s in FEED_FILE_RUN_TERMINAL_STATUSES)

    # The set comparison (FR-CMP-05): complete means declared set ==
    # completed set, exactly — no missing, no extras, nothing in flight.
    complete = (not in_flight and not missing and not undeclared
                and declared_set == completed_keys)

    if complete:
        return ParentVerdict(
            status=PARENT_COMPLETED, complete=True,
            declared_count=len(declared), counts=counts,
            total_rows=(total_rows if rows_known else None),
            reason=("every declared partition has a completed part "
                    "(set comparison)" if declared else
                    "empty declaration — vacuously complete; the "
                    "completeness verdict must be ASSERTED (on_empty="
                    "skip), never verified"))

    if in_flight:
        started = counts.get("running", 0) > 0 or terminal_total > 0
        return ParentVerdict(
            status=(PARENT_RUNNING if started else PARENT_PENDING),
            complete=False, declared_count=len(declared), counts=counts,
            missing_identities=missing, undeclared_identities=undeclared,
            reason=(f"{counts.get('pending', 0)} pending, "
                    f"{counts.get('running', 0)} running of "
                    f"{len(declared)} declared"))

    # Nothing in flight, not complete — name WHY, loudly.
    reasons: list[str] = []
    if missing:
        shown = list(missing[:20])
        reasons.append(
            f"{len(missing)} declared partition(s) have NO child row "
            f"(the child that never existed, §9.2): {shown}")
    if undeclared:
        shown = list(undeclared[:20])
        reasons.append(
            f"{len(undeclared)} child row(s) exist for UNDECLARED "
            f"partition(s): {shown} — the manifest would hold parts "
            f"nobody declared")
    if counts.get("failed", 0):
        reasons.append(f"{counts['failed']} child(ren) failed")
    if counts.get("cancelled", 0):
        reasons.append(f"{counts['cancelled']} child(ren) cancelled")

    if counts.get("failed", 0) or missing or undeclared:
        status = PARENT_FAILED
    else:
        status = PARENT_CANCELLED
    return ParentVerdict(
        status=status, complete=False, declared_count=len(declared),
        counts=counts, missing_identities=missing,
        undeclared_identities=undeclared,
        reason="; ".join(reasons) or "no children in a terminal state")


def recompute_parent(dao, feed_run_id: int, *,
                     write: bool = True) -> ParentVerdict:
    """Load the run's declaration + children, derive the verdict, and
    (terminal verdicts only) write the DERIVED status onto the parent
    ``feed_runs`` row.

    * No recorded declaration → the set is unknowable, so the verdict
      can NEVER be complete (an unrecorded declaration is not evidence);
      nothing is written, and the refusal is logged at ERROR.
    * Non-terminal verdicts write nothing — the parent row is owned by
      its queue-worker claim while in flight, and stamping ``running``
      over it from here would fight that ownership.
    """
    decl = dao.get_partition_declaration(int(feed_run_id))
    children = dao.list_feed_file_runs(int(feed_run_id))
    if decl is None:
        counts: dict[str, int] = {s: 0 for s in FEED_FILE_RUN_STATUSES}
        for child in children:
            status = str(child.get("status"))
            counts[status] = counts.get(status, 0) + 1
        verdict = ParentVerdict(
            status=(PARENT_RUNNING if children else PARENT_PENDING),
            complete=False, declared_count=0, counts=counts,
            reason=("no partition declaration recorded for this run — "
                    "the declared set is unknowable, so the parent can "
                    "never be certified complete (FR-CMP-02: an "
                    "unrecorded declaration is not evidence)"))
        logger.error("[fanout] run %s: %s", feed_run_id, verdict.reason)
        return verdict

    verdict = derive_parent_status(decl.get("identities") or [], children)
    if write and verdict.status in FEED_FILE_RUN_TERMINAL_STATUSES:
        update: dict[str, Any] = {
            "status": verdict.status,
            "completed_at": datetime.now(timezone.utc),
        }
        if verdict.status == PARENT_COMPLETED:
            if verdict.total_rows is not None:
                update["total_rows"] = verdict.total_rows
            update["error"] = None
        else:
            update["error"] = verdict.reason
        dao.update_feed_run(int(feed_run_id), update)
        logger.info("[fanout] run %s: derived parent status %r (%s)",
                    feed_run_id, verdict.status, verdict.reason)
    return verdict
