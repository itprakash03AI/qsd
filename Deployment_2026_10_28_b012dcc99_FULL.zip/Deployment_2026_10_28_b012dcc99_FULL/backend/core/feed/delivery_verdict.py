"""THE destination evidence a delivered feed is certified against (D1).

docs/FEED_LANE_CONTRACT_2026_10_07.html, decision K5, inventory row D1.

A delivered run's completeness certificate reconciles the rows the source
produced against the rows the DESTINATION holds.  Three paths reached that
second number three ways:

* native: the delivery receipt's destination count, else an independent
  recount of the rendered file, else the engine's own row count
  (``feed_engine._certified_dest_rows``);
* spark_k8s, job-delivered: the completion webhook's
  ``feed_perf.verify_webhook_completion`` -- a recount of a LOCAL output
  path, which a pod's output never is, so "usually UNVERIFIED" for the
  same file native certified COMPLETE;
* QueryStudio-delivered after the job (the webhook-side delivery that an
  Airflow-orchestrated or artifacts-only run takes): the same webhook
  verification, computed BEFORE the delivery, over the artifact store.

:func:`certified_dest_rows` is now the ONE rule; every path calls it with
what it holds.  The Spark job reports the same receipt native's
transports fill (``core/feed/delivery_protocol.receipt``) -- including its
own recount of the file it rendered -- so the webhook has the evidence the
native lane has.

Backend only: the job reports evidence, it never certifies itself.
"""
from __future__ import annotations

from typing import Any, Mapping, Optional, Tuple

#: Why a number was chosen -- recorded beside it.
BASIS_DESTINATION = "destination_count"
BASIS_RECOUNT = "physical_recount"
BASIS_RENDERED = "rendered_rows"
BASIS_NONE = "none"


def _int(v: Any) -> Optional[int]:
    return int(v) if isinstance(v, int) and not isinstance(v, bool) else None


def certified_dest_rows(*, receipt: Optional[Mapping[str, Any]],
                        physical_rows: Any = None,
                        rendered_rows: Any = None
                        ) -> Tuple[Optional[int], str]:
    """``(rows, basis)`` -- the destination-side row count the certificate
    reconciles against, most independent evidence first:

    1. the DESTINATION's own count (``receipt["delivered_rows"]``): an
       Oracle delivery that committed with rows rejected under
       ``max_error_percent`` holds fewer rows than the file -- recounting
       the file would certify a short table COMPLETE;
    2. an independent PHYSICAL recount of the delivered file
       (``physical_rows``, or ``receipt["physical_rows"]`` from a job that
       recounted the file it rendered);
    3. the rows the RENDERER wrote -- only when a delivery receipt exists:
       a transport that reported what it did (native always does; a Spark
       job image from before 2026-10-07 reports nothing, and its run stays
       UNVERIFIED rather than certified on its own say-so).

    ``(None, "none")`` when there is no evidence: the certificate then
    reads UNVERIFIED, never COMPLETE.
    """
    rec = receipt if isinstance(receipt, Mapping) else None
    if rec is not None:
        n = _int(rec.get("delivered_rows"))
        if n is not None:
            return n, BASIS_DESTINATION
    n = _int(physical_rows)
    if n is None and rec is not None:
        n = _int(rec.get("physical_rows"))
    if n is not None:
        return n, BASIS_RECOUNT
    if rec is not None:
        n = _int(rendered_rows)
        if n is None:
            n = _int(rec.get("written_rows"))
        if n is not None:
            return n, BASIS_RENDERED
    return None, BASIS_NONE
