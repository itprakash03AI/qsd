"""Who owns a feed_runs row, and when — ONE vocabulary for every trigger path.

Phase 4 (2026-08-23).  The audits found the same fact — "which path runs
this feed today, and against which business_date" — resolved differently by
four writers:

  * SOD created a pending row for EVERY active feed (no cron filter),
  * the queue worker claimed EVERY pending row (its docstring promised
    "only feeds with no cron"; the filter did not exist) — so a feed with an
    18:00 cron was executed at ~00:00:30 by the queue AND again at 18:00 by
    the cron: wrong-time run + double delivery,
  * the cron path (`run_scheduled_feed`) never looked at the row at all —
    the row stayed "pending" all day while the feed delivered, the SLA
    tracker then flagged a false breach,
  * the external trigger created a row and executed without binding it.

This module gives the three helpers those writers now share:

:func:`resolve_feed_business_date`
    The SOD generator's calendar arithmetic (previous business day or
    today), extracted so the cron path resolves the SAME business_date SOD
    keyed the row on.

:func:`cron_owned`
    Whether the per-feed APScheduler cron is the primary owner of this
    feed's daily run.

:func:`cron_fire_passed`
    Whether the cron's first scheduled fire for the row's day is already in
    the past (plus a grace).  Before that moment the queue worker must keep
    its hands off the row; after it, the row is fair game — the queue
    worker becomes the safety net for a missed fire (scheduler down at
    18:00 no longer means "the feed silently never runs today").  The
    atomic pending->running claim keeps every hand-off race-safe.
"""
from __future__ import annotations

import logging
from datetime import date as _date
from datetime import datetime, time as _time, timedelta, timezone
from typing import Any, Mapping, Optional

logger = logging.getLogger(__name__)


def resolve_feed_business_date(db, feed_config: Mapping[str, Any],
                               run_date: Optional[_date] = None) -> _date:
    """The business_date a run of ``feed_config`` on ``run_date`` belongs to.

    Identical semantics to the SOD generator's step 2: with a resolvable
    calendar, ``previous_business_day_or_today``; without one (none named,
    or the name doesn't resolve — logged there), the run date itself.
    Fail-open to ``run_date``: date arithmetic must never kill a run.
    """
    run_d = run_date or datetime.now(timezone.utc).date()
    cal_name = (feed_config or {}).get("calendar_name")
    if not cal_name:
        return run_d
    try:
        from core.feed.calendar import BusinessCalendar, BusinessCalendarRepo
        spec = BusinessCalendarRepo(db).get(str(cal_name))
        if spec is None:
            return run_d
        return BusinessCalendar(spec).previous_business_day_or_today(run_d)
    except Exception as exc:
        logger.warning(
            "[run_ownership] business-date resolution failed for feed %s "
            "(calendar %r): %s — using run date",
            (feed_config or {}).get("id"), cal_name, exc,
        )
        return run_d


def cron_owned(feed_config: Mapping[str, Any]) -> bool:
    """True when the per-feed APScheduler cron is this feed's primary
    daily-run owner (schedule enabled AND a cron expression present)."""
    fc = feed_config or {}
    return bool(fc.get("schedule_enabled")) and bool(fc.get("cron_expression"))


def _row_day(row: Mapping[str, Any]) -> Optional[_date]:
    """The calendar day the row's cron would fire on: run_date when SOD
    stamped it, business_date otherwise (rows created by run_feed carry
    only business_date)."""
    for key in ("run_date", "business_date"):
        v = (row or {}).get(key)
        if v is None or v == "":
            continue
        if isinstance(v, datetime):
            return v.date()
        if isinstance(v, _date):
            return v
        try:
            return _date.fromisoformat(str(v)[:10])
        except ValueError:
            continue
    return None


def cron_fire_passed(feed_config: Mapping[str, Any], row: Mapping[str, Any],
                     *, now: Optional[datetime] = None,
                     grace_seconds: int = 0) -> bool:
    """Has the cron's FIRST fire for the row's day already passed (+grace)?

    Semantics for the queue worker's ownership filter:

      * fire time still ahead        -> False (hands off — cron's turn)
      * fire time passed (+grace)    -> True  (safety net may claim)
      * cron never fires on that day -> False (the row is not the cron's to
        run; it stays visibly pending rather than being invented a run —
        SOD creating a row for a day the feed's own cron skips is operator
        config to surface, not to silently execute)
      * cron unparsable              -> True  (the cron path can NEVER run
        it; the queue worker is the only thing left — logged)
    """
    fc = feed_config or {}
    cron = fc.get("cron_expression")
    if not cron:
        return True
    now = now or datetime.now(timezone.utc)
    day = _row_day(row)
    if day is None:
        # No date on the row at all — nothing to anchor "the cron's turn"
        # to; let the safety net have it.
        return True
    try:
        from core.cron_compat import crontab_trigger
        trg = crontab_trigger(str(cron),
                              timezone=fc.get("timezone") or "UTC")
        tz = trg.timezone
        day_start = datetime.combine(day, _time.min)
        # pytz needs localize(); zoneinfo takes tzinfo=.
        if hasattr(tz, "localize"):
            day_start = tz.localize(day_start)
        else:
            day_start = day_start.replace(tzinfo=tz)
        fire = trg.get_next_fire_time(None, day_start)
        if fire is None or fire.astimezone(tz).date() != day:
            return False  # cron skips this day entirely
        return now >= (fire + timedelta(seconds=int(grace_seconds)))
    except Exception as exc:
        logger.warning(
            "[run_ownership] feed %s cron %r unparsable (%s) — treating its "
            "pending row as queue-claimable (the cron path cannot run it)",
            fc.get("id"), cron, exc,
        )
        return True
