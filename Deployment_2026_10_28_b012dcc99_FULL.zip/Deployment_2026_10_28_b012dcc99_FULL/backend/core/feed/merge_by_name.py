"""THE merge of two sides BY COLUMN NAME -- one decision for every lane
(2026-10-10, the owner's cloud + on-prem ``fact_tetb_ext`` case).

MIRRORED byte-for-byte at ``spark/jobs/qs_merge_by_name.py`` (the Spark job
cannot import backend/core); the lane-mirror guard fails the suite if the
copies differ.  Standard library only, so the mirror runs in the job image.

The decision (lead, 2026-10-10; owner chose UNION ALL on 2026-10-08):

* rows are stacked (UNION ALL -- never de-duplicated);
* columns are aligned BY NAME, never by position: the cloud query projects
  75 columns and the on-prem one 73 in a DIFFERENT order, so a positional
  union would put SOURCE_DATA_ROW under PARTITION_KEY and certify it;
* the name match is CASE-INSENSITIVE (Trino folds an unquoted alias to
  lower case, Oracle to upper -- ``tran_currency_name`` and
  ``TRAN_CURRENCY_NAME`` are the same column), and the output is spelled
  the way the PRIMARY (cloud) side spells it;
* the output order is the primary side's column order; a column only the
  secondary side has is appended after them (in its own order);
* a column missing from a side is a typed NULL for that side's rows;
* a same-named column whose types are INCOMPATIBLE refuses the whole merge
  naming every such column and both types (:class:`MergeRefused`).  A
  correctness gate must fail; a VARCHAR stacked under a DECIMAL and
  promoted to text is a silent coercion the file's consumer cannot see.
  Compatible = the same TYPE FAMILY (string / number / temporal / bool /
  binary); a promotion inside a family (INTEGER under BIGINT, DATE under
  TIMESTAMP, VARCHAR(10) under VARCHAR) is allowed and DISCLOSED.  A type
  this module cannot classify is ``unknown``: it is not refused (unknown is
  not incompatible) and it is disclosed as unverified.

Every lane reads this plan: the native DuckDB combine
(``core/executors/cross_source_combine.py``), the zero-copy parts manifest,
the Spark job's ``_combine_union`` (through the mirror) and the engine's
pre-combine gate in ``core/feed_engine.py``.  None of them re-decides what
"by name" means.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

#: The pair the mirror guard (tests/test_lane_mirrors_2026_10_07.py)
#: byte-compares.
MIRROR_PATHS = (
    "backend/core/feed/merge_by_name.py",
    "spark/jobs/qs_merge_by_name.py",
)

#: BF-121 -- an empty side ships one placeholder column; it is never an
#: output column while any real column exists.
EMPTY_PLACEHOLDER = "__empty__"

FAMILY_STRING = "string"
FAMILY_NUMBER = "number"
FAMILY_TEMPORAL = "temporal"
FAMILY_BOOL = "bool"
FAMILY_BINARY = "binary"
FAMILY_UNKNOWN = "unknown"
FAMILY_OTHER = "other"

_STRING_PREFIXES = ("VARCHAR", "NVARCHAR", "CHAR", "NCHAR", "BPCHAR", "STRING",
                    "TEXT", "CLOB", "NCLOB", "UTF8", "LARGE_STRING",
                    "LARGE_UTF8", "JSON", "UUID")
_NUMBER_PREFIXES = ("TINYINT", "SMALLINT", "INT", "BIGINT", "HUGEINT",
                    "UTINYINT", "USMALLINT", "UINT", "UBIGINT", "UHUGEINT",
                    "DECIMAL", "NUMERIC", "NUMBER", "DOUBLE", "FLOAT", "REAL",
                    "HALFFLOAT", "LONG", "SHORT", "BYTE", "BINARY_FLOAT",
                    "BINARY_DOUBLE")
_TEMPORAL_PREFIXES = ("DATE", "TIME", "TIMESTAMP", "INTERVAL", "DURATION")
_BOOL_PREFIXES = ("BOOL",)
_BINARY_PREFIXES = ("BLOB", "BINARY", "VARBINARY", "BYTEA", "RAW",
                    "LARGE_BINARY", "LONG RAW")


def type_family(t: Any) -> str:
    """The family a type spelling belongs to -- DuckDB, Trino, Oracle,
    Spark and Arrow spellings alike (``VARCHAR(20)``, ``decimal(38,0)``,
    ``timestamp[us]``, ``NUMBER``, ``int32``)."""
    s = str(t or "").strip().upper()
    if not s or s == "NULL":
        # Arrow's ``null`` type is an all-NULL column: no type to disagree with.
        return FAMILY_UNKNOWN
    if s.startswith(_STRING_PREFIXES):
        return FAMILY_STRING
    if s.startswith(_NUMBER_PREFIXES):
        return FAMILY_NUMBER
    if s.startswith(_TEMPORAL_PREFIXES):
        return FAMILY_TEMPORAL
    if s.startswith(_BOOL_PREFIXES):
        return FAMILY_BOOL
    if s.startswith(_BINARY_PREFIXES):
        return FAMILY_BINARY
    return FAMILY_OTHER


def _norm_type(t: Any) -> str:
    return re.sub(r"\s+", " ", str(t or "").strip().upper())


def types_compatible(primary_type: Any, secondary_type: Any) -> bool:
    """Same family, or an unknown on either side (unknown is not
    incompatible -- the engine refuses loudly itself if it cannot cast).
    ``other`` (struct / list / map ...) is compatible only when the two
    spellings are identical."""
    fa, fb = type_family(primary_type), type_family(secondary_type)
    if FAMILY_UNKNOWN in (fa, fb):
        return True
    if fa != fb:
        return False
    if fa == FAMILY_OTHER:
        return _norm_type(primary_type) == _norm_type(secondary_type)
    return True


class MergeRefused(ValueError):
    """A same-named column has incompatible types on the two sides.

    The message names every such column with both types -- the person
    fixing the query needs the whole list, not the first one.
    """

    def __init__(self, incompatible: Sequence[Tuple[str, Any, Any]]):
        self.incompatible = list(incompatible)
        parts = [f"{name} is {p!s} on the primary side and {s!s} on the "
                 f"secondary side" for name, p, s in self.incompatible]
        super().__init__(
            "merge by column name REFUSED: the two sides disagree on the "
            "type of " + "; ".join(parts) + ". The sides are not combined "
            "and nothing is delivered: a column stacked under an "
            "incompatible type would be coerced silently. Fix the query "
            "that projects it (CAST both sides to one type) and re-run.")


@dataclass(frozen=True)
class MergeColumn:
    """One output column of the merge."""
    name: str                          # output spelling (the primary's)
    primary_name: Optional[str]        # the primary side's spelling, or None
    secondary_name: Optional[str]      # the secondary side's spelling, or None
    primary_type: Optional[str]
    secondary_type: Optional[str]

    @property
    def fill_type(self) -> Optional[str]:
        """The type a MISSING side's NULL is cast to: the other side's."""
        if self.primary_name is None:
            return self.secondary_type
        if self.secondary_name is None:
            return self.primary_type
        return None

    @property
    def renamed(self) -> bool:
        """A case-only spelling difference between the two sides."""
        return (self.primary_name is not None and self.secondary_name is not None
                and self.primary_name != self.secondary_name)

    @property
    def promoted(self) -> bool:
        """Both sides have it, spelled with different (compatible) types."""
        return (self.primary_name is not None and self.secondary_name is not None
                and _norm_type(self.primary_type) != _norm_type(self.secondary_type))


@dataclass
class MergePlan:
    """What the merge of two sides IS -- and everything it discloses."""
    columns: List[MergeColumn]
    primary_count: int
    secondary_count: int
    dropped_placeholder: bool = False
    #: ``(name, primary_type, secondary_type)`` for every promotion
    promotions: List[Tuple[str, str, str]] = field(default_factory=list)
    #: ``(output_name, secondary_spelling)`` for every case-only rename
    renames: List[Tuple[str, str]] = field(default_factory=list)
    #: columns whose family could not be classified on a side
    unverified: List[str] = field(default_factory=list)

    @property
    def names(self) -> List[str]:
        return [c.name for c in self.columns]

    @property
    def primary_only(self) -> List[str]:
        return [c.name for c in self.columns if c.secondary_name is None]

    @property
    def secondary_only(self) -> List[str]:
        return [c.name for c in self.columns if c.primary_name is None]

    @property
    def identical(self) -> bool:
        """Both sides already have exactly these columns, spelled and typed
        the same -- a zero-copy stack needs no projection at all."""
        return (not self.primary_only and not self.secondary_only
                and not self.renames and not self.promotions
                and not self.dropped_placeholder)

    def side_specs(self, side: str) -> List[Tuple[Optional[str], str, Optional[str]]]:
        """Per output column, for ``side`` (``primary`` / ``secondary``):
        ``(source_column_or_None, output_name, null_cast_type_or_None)``.
        A lane turns this into its own SELECT list / DataFrame projection;
        the decision of what each output column IS stays here."""
        if side not in ("primary", "secondary"):
            raise ValueError(f"side must be primary or secondary, not {side!r}")
        out = []
        for c in self.columns:
            src = c.primary_name if side == "primary" else c.secondary_name
            if src is None:
                out.append((None, c.name, c.fill_type))
            else:
                out.append((src, c.name, None))
        return out

    def disclosure(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {
            "rule": "union_all_by_name",
            "columns": len(self.columns),
            "primary_columns": self.primary_count,
            "secondary_columns": self.secondary_count,
            "primary_only": list(self.primary_only),
            "secondary_only": list(self.secondary_only),
        }
        if self.promotions:
            d["type_promotions"] = [f"{n}: {p} / {s}" for n, p, s in self.promotions]
        if self.renames:
            d["case_renames"] = [f"{o} (secondary spells it {s})" for o, s in self.renames]
        if self.unverified:
            d["unverified_types"] = list(self.unverified)
        if self.dropped_placeholder:
            d["dropped_placeholder"] = EMPTY_PLACEHOLDER
        return d


def _as_pairs(cols: Iterable[Any]) -> List[Tuple[str, Optional[str]]]:
    out: List[Tuple[str, Optional[str]]] = []
    for c in cols or []:
        if isinstance(c, (tuple, list)):
            name = str(c[0])
            typ = None if len(c) < 2 or c[1] is None else str(c[1])
        else:
            name, typ = str(c), None
        out.append((name, typ))
    return out


def plan_merge(primary_cols: Iterable[Any], secondary_cols: Iterable[Any]) -> MergePlan:
    """The plan for stacking ``secondary`` under ``primary`` by name.

    ``*_cols`` are ``[(name, type), ...]`` (a bare name is accepted; its
    type is then unknown).  Raises :class:`MergeRefused` when any
    same-named column is incompatible; raises ``ValueError`` when a side
    has no columns at all (a combine with one unreadable side returns the
    other side and calls it the answer) or spells one name twice.
    """
    p = _as_pairs(primary_cols)
    s = _as_pairs(secondary_cols)
    if not p or not s:
        raise ValueError(
            "merge by column name refused: the "
            + ("primary" if not p else "secondary")
            + " side reports no columns -- a side that cannot be described "
              "cannot be aligned, and combining the other side alone would "
              "deliver half the data as the whole")
    for label, side in (("primary", p), ("secondary", s)):
        lows = [n.lower() for n, _t in side]
        dup = sorted({n for n, _t in side if lows.count(n.lower()) > 1})
        if dup:
            raise ValueError(
                f"merge by column name refused: the {label} side spells "
                f"column(s) {dup} more than once (case-insensitively); "
                f"alias them so each name means one column")

    # BF-121: the placeholder is dropped while any real column exists on
    # either side.  An empty PRIMARY then contributes no columns and the
    # output takes the secondary's shape.
    dropped = False
    real_p = [(n, t) for n, t in p if n != EMPTY_PLACEHOLDER]
    real_s = [(n, t) for n, t in s if n != EMPTY_PLACEHOLDER]
    if (len(real_p) != len(p) or len(real_s) != len(s)) and (real_p or real_s):
        dropped = True
        p, s = real_p, real_s

    s_by_low = {n.lower(): (n, t) for n, t in s}
    p_lows = {n.lower() for n, _ in p}

    columns: List[MergeColumn] = []
    incompatible: List[Tuple[str, Any, Any]] = []
    promotions: List[Tuple[str, str, str]] = []
    renames: List[Tuple[str, str]] = []
    unverified: List[str] = []

    for name, ptype in p:
        hit = s_by_low.get(name.lower())
        if hit is None:
            columns.append(MergeColumn(name, name, None, ptype, None))
            continue
        sname, stype = hit
        if not types_compatible(ptype, stype):
            incompatible.append((name, ptype, stype))
        col = MergeColumn(name, name, sname, ptype, stype)
        columns.append(col)
        if FAMILY_UNKNOWN in (type_family(ptype), type_family(stype)):
            unverified.append(name)
        elif col.promoted:
            promotions.append((name, str(ptype), str(stype)))
        if col.renamed:
            renames.append((name, sname))
    for name, stype in s:
        if name.lower() in p_lows:
            continue
        columns.append(MergeColumn(name, None, name, None, stype))

    if incompatible:
        raise MergeRefused(incompatible)
    return MergePlan(columns=columns, primary_count=len(p),
                     secondary_count=len(s), dropped_placeholder=dropped,
                     promotions=promotions, renames=renames,
                     unverified=unverified)


# ── SQL rendering helpers (DuckDB / Trino spellings; identifiers quoted) ──

def quote_ident(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


_SQL_TYPE_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_ ]*(\([0-9, ]*\))?(\[\])?$")


def null_cast_type(t: Optional[str]) -> str:
    """The type a missing side's NULL is cast to, as SQL.  A spelling that
    does not look like a SQL type is refused rather than pasted into
    ``CAST(NULL AS ...)``; an unknown type falls back to VARCHAR (a NULL
    is a NULL -- the cast only fixes the column's declared type)."""
    s = str(t or "").strip()
    if not s:
        return "VARCHAR"
    if not _SQL_TYPE_RE.match(s):
        raise ValueError(f"type spelling {s!r} does not look like a SQL type; "
                         f"refusing to paste it into CAST(NULL AS ...)")
    return s


def sql_select_list(plan: MergePlan, side: str) -> str:
    """The SELECT list that projects ``side`` onto the plan's output
    columns: ``"src" AS "Out"`` for a column the side has, ``CAST(NULL AS
    T) AS "Out"`` for one it lacks.  DuckDB and Trino read this spelling."""
    items = []
    for src, out, fill in plan.side_specs(side):
        if src is None:
            items.append(f"CAST(NULL AS {null_cast_type(fill)}) AS {quote_ident(out)}")
        else:
            items.append(f"{quote_ident(src)} AS {quote_ident(out)}")
    return ", ".join(items)


# ── the run's record of the merge: ONE shape for every lane ──────────────

#: Where the record lands on the execution row (``files_metadata``).
CROSS_SOURCE_KEY = "cross_source"


def cross_source_record(combine_mode: Any, primary_rows: Optional[int],
                        secondary_rows: Optional[int], *,
                        merge: Optional[Dict[str, Any]] = None,
                        combine: Optional[str] = None,
                        combined_rows: Optional[int] = None,
                        lane: Optional[str] = None) -> Dict[str, Any]:
    """THE ``files_metadata.cross_source`` shape -- how an auditor sees
    ``primary + secondary == delivered`` on a cross-source run, built by
    ONE function on every lane (2026-10-10).

    The native engine built it inline; the Spark lane reported nothing
    (its runs carried ``cross_source: {}``, found live on the owner's
    Kafka-gated merge feeds at ``--backend spark_k8s``), so the certificate
    could not be checked against the sides there.  Now the native engine
    (``feed_engine._run_cross_source_native_query``) and the Spark job
    (``generic_feed._combine_cross_source``, through the mirror) both call
    this, and the completion webhook stores what the job built under
    ``CROSS_SOURCE_KEY`` verbatim.

    ``expected_rows`` is ``primary + secondary`` for a UNION (the only
    combine whose output size is known before it runs); None for a join or
    when a side's count is unknown.  ``merge`` is ``MergePlan.disclosure()``
    (absent for a join), ``combine`` names the engine that stacked the rows
    (``zero_copy_manifest`` / ``duckdb`` / ``spark_union_by_name`` /
    ``spark_join``), ``combined_rows`` what came out, ``lane`` which
    backend's process counted.  A None value is still written: an auditor
    must see "unknown", never a missing key read as zero."""
    mode = str(combine_mode or "union").strip().lower() or "union"

    def _int(v: Any) -> Optional[int]:
        return int(v) if isinstance(v, int) and not isinstance(v, bool) else None

    p, s = _int(primary_rows), _int(secondary_rows)
    rec: Dict[str, Any] = {
        "combine_mode": mode,
        "primary_rows": p,
        "secondary_rows": s,
        "expected_rows": (p + s) if (mode != "join" and p is not None
                                     and s is not None) else None,
    }
    if merge is not None:
        rec["merge"] = dict(merge)
    if combine is not None:
        rec["combine"] = str(combine)
    if combined_rows is not None:
        rec["combined_rows"] = _int(combined_rows)
    if lane:
        rec["lane"] = str(lane)
    return rec
