"""Feed identity — name shape validation and naming advice.

BRD 2026-09-02 §14.3 / defect D5 / FR-ID-01..03.  The feed name is
load-bearing in at least five places that all assume it is unique and
stable: the Netcool AlertKey and dedup Identifier, rendered output
filenames, the archive key layout, git-backed definition filenames, and
every support conversation.  A name is therefore REFUSED at authoring
when it cannot survive that chain — never rewritten silently, because a
silently-rewritten name is how a feed becomes unfindable (FR-ID-01).

Pure functions only.  No database, no config, no I/O — the API boundary
calls these; the engine never needs to.
"""
from __future__ import annotations

import re

# ── Length limit (FR-ID-02) ──────────────────────────────────────────────
#
# Derived from the TIGHTEST downstream constraint in the identity chain,
# not assumed.
#
# Until 2026-10-12 that was taken to be the Spark pod name: ``feed-<id>``
# capped at 56 (63 minus "-driver"), minus the prefix and a "-r99" budget
# = 47.  Since 2026-09-14 the pod name is ``<feed-name>-<short execution
# id>[-r{n}]`` (core/spark_k8s/manifest.py::cr_name_for): the ID is never
# cut and a long NAME is shortened DETERMINISTICALLY in the pod name only,
# while the execution row and every screen keep the full name; the CR's
# labels carry the execution id, never the name.  The pod chain no longer
# bounds the name -- and the 47 refused the owner's own naming on the live
# rig (2026-10-12: ``<SYSTEM_ENTITY>_FINANCE_SL_BALANCE_EXT_INTRADAY`` is
# 49), so one INTRADAY feed per entity was missing from a template's matrix.
#
# What bounds it now is the Netcool Identifier (core/feed/netcool.py
# ``build_identifier``): ``QS:<env>:<alert_type>:<object>:<business date>``
# in OMNIbus's varchar(255), where the object is a feed name or a
# dependency key built from one.  128 leaves 127 characters for the
# environment, the alert type, the date and the separators; the column is
# String(255).  Raising the cap refuses no name that exists.
K8S_DNS_LABEL_MAX = 63
CR_NAME_MAX = 56               # what cr_name_for enforces (63 - len("-driver"))
NETCOOL_IDENTIFIER_MAX = 255   # OMNIbus alerts.status Identifier
MAX_FEED_NAME_LEN = 128

# FR-ID-01 — bounded character set.  Uppercase letters, digits,
# underscore.  cr_name_for lowercases and maps '_' -> '-' to reach
# DNS-1123, which is lossless for this alphabet EXCEPT at the ends: a
# trailing '_' becomes a trailing '-' that cr_name_for strips, so
# "FOO_" and "FOO" would collapse into the SAME SparkApplication name —
# a silent mutation and a collision at once.  Ends must therefore be
# alphanumeric.
_NAME_CHARSET_RE = re.compile(r"^[A-Z0-9_]+$")

def normalize_feed_name(raw: str) -> str:
    """The feed form's rule, on the server (2026-10-13): upper case; space /
    hyphen / dot -> ``_``; other characters dropped; ``_`` runs collapsed;
    no leading or trailing ``_``.  The twin of the UI's ``feedNameForSave``
    (frontend/src/components/common/feedAuthoringRules.ts) -- a test pins
    them to the same answers.  Used where a name is DERIVED, not typed: a
    template member named from an entity code like ``SAP-2920-EMEA``."""
    s = str(raw or "").upper()
    s = re.sub(r"[\s.-]", "_", s)
    s = re.sub(r"[^A-Z0-9_]", "", s)
    s = re.sub(r"_+", "_", s)
    return s.strip("_")


NAME_ADVICE = (
    "A feed name is permanent identity, not a description.  Every "
    "mutable fact encoded in it — a frequency, a version, a region, an "
    "environment — will eventually change while the name cannot: it is "
    "burned into archives, alert keys, filenames and audit history from "
    "the first run.  GL_EXTRACT_APAC_DAILY_V2 embeds a frequency and a "
    "version that will both drift.  Put mutable facts in the "
    "description or the (editable) display name; keep the name to what "
    "the feed IS."
)

# Advisory-only vocabulary of mutable facts commonly embedded in names
# (FR-ID-03).  ADVISORY because names carrying these are already in
# live use — blocking would refuse names that exist today.
_FREQUENCY_TOKENS = {
    "DAILY", "WEEKLY", "MONTHLY", "QUARTERLY", "YEARLY", "ANNUAL",
    "HOURLY", "INTRADAY", "ADHOC",
}
_ENVIRONMENT_TOKENS = {"PROD", "PRODUCTION", "UAT", "DEV", "QA", "SIT", "PREPROD"}
_VERSION_TOKEN_RE = re.compile(r"^V\d+$")


def validate_feed_name(name) -> None:
    """Refuse a feed name that cannot survive the identity chain.

    Raises ValueError with a message that says what is wrong AND what to
    do.  Never rewrites the name (FR-ID-01: refused at save time, not
    sanitised silently).  Returns None on success.
    """
    if not isinstance(name, str) or not name:
        raise ValueError(
            "Feed name is required and must be a non-empty string. "
            "Choose a name using uppercase letters, digits and "
            "underscores, e.g. GL_EXTRACT_APAC."
        )
    if len(name) > MAX_FEED_NAME_LEN:
        raise ValueError(
            f"Feed name {name!r} is {len(name)} characters; the limit is "
            f"{MAX_FEED_NAME_LEN}. The name is carried whole into the "
            f"Netcool alert Identifier ({NETCOOL_IDENTIFIER_MAX} characters "
            f"with the environment, alert type and business date), and "
            f"names are never rewritten silently. Shorten the name; put "
            f"detail in the description or display name."
        )
    if not _NAME_CHARSET_RE.match(name):
        bad = sorted({c for c in name if not re.match(r"[A-Z0-9_]", c)})
        raise ValueError(
            f"Feed name {name!r} contains disallowed character(s) "
            f"{bad!r}. Allowed characters are uppercase A-Z, digits 0-9 "
            f"and underscore, e.g. GL_EXTRACT_APAC. The name is NOT "
            f"rewritten for you — a silently-adjusted name would no "
            f"longer match its archives, alerts and filenames — so "
            f"please re-enter it in the allowed alphabet."
        )
    if name.startswith("_") or name.endswith("_"):
        raise ValueError(
            f"Feed name {name!r} must start and end with a letter or "
            f"digit. A trailing underscore is stripped when the name is "
            f"mapped to a DNS-safe Kubernetes pod name, so "
            f"{name.strip('_')!r} and {name!r} would collide there. "
            f"Remove the leading/trailing underscore(s)."
        )


def name_advice(name) -> list:
    """FR-ID-03 — advisory warnings for mutable facts encoded in a name.

    Returns a (possibly empty) list of human-readable warnings.  Never
    raises and never blocks: names carrying these patterns are already
    in live use, and refusing them would refuse working feeds.  Surface
    the result as a warning next to the save.
    """
    warnings: list = []
    try:
        tokens = [t for t in str(name or "").upper().split("_") if t]
        freq = [t for t in tokens if t in _FREQUENCY_TOKENS]
        vers = [t for t in tokens if _VERSION_TOKEN_RE.match(t)]
        envs = [t for t in tokens if t in _ENVIRONMENT_TOKENS]
        if freq:
            warnings.append(
                f"Name embeds a frequency ({', '.join(freq)}): the "
                f"schedule can change but the name cannot. " + NAME_ADVICE
            )
        if vers:
            warnings.append(
                f"Name embeds a version marker ({', '.join(vers)}): the "
                f"next revision will make it a lie. " + NAME_ADVICE
            )
        if envs:
            warnings.append(
                f"Name embeds an environment ({', '.join(envs)}): names "
                f"are already unique per environment, and a definition "
                f"promoted between environments cannot carry it. "
                + NAME_ADVICE
            )
    except Exception:  # noqa: BLE001 -- advisory MUST never block a save
        # Advisory code must never take down a save.
        return warnings
    return warnings
