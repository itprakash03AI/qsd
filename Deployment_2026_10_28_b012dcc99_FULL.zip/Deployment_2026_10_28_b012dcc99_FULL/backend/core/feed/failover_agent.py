"""Failover agent — Phase 130 hotfix-13.

Background job that periodically probes Airflow + native worker health
and flips ``feed_generation.backend_override`` when one side becomes
unhealthy.  Designed for enterprise scale (10K+ feeds/day across
multiple pods) where manual operator intervention is too slow.

Decision policy (all thresholds DB-tunable via ``system_settings``):

  * Two consecutive probe results are tracked: ``airflow_streak``
    and ``native_streak`` count consecutive unhealthy ticks.
  * When ``airflow_streak >= unhealthy_streak_required`` AND native
    is healthy → set ``backend_override='native_only'`` (audit-logged
    + WS broadcast).
  * When ``native_streak >= unhealthy_streak_required`` AND airflow
    is healthy → set ``backend_override='airflow_only'``.
  * When both are unhealthy → set ``backend_override='halt'`` so we
    stop spawning doomed executions until ops fixes one side.
  * When the previously-failing side has been healthy for
    ``healthy_streak_required`` consecutive ticks AND the OTHER side
    is also healthy → revert to ``'auto'``.

The agent only writes the override when it would CHANGE the current
value, so admin-set overrides (``halt`` for maintenance, etc.) are
respected indefinitely if the operator manually sets them and
disables the agent.

Activation: ``feed_generation.failover_agent_enabled=true``
(default false).  Operators flip this from the admin UI; the
background_jobs registry pause/resume can also gate it without a
restart.
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from typing import Callable, Optional

logger = logging.getLogger(__name__)


@dataclass
class _Streaks:
    airflow_unhealthy: int = 0
    airflow_healthy: int = 0
    native_unhealthy: int = 0
    native_healthy: int = 0

    def record_airflow(self, healthy: bool) -> None:
        if healthy:
            self.airflow_healthy += 1
            self.airflow_unhealthy = 0
        else:
            self.airflow_unhealthy += 1
            self.airflow_healthy = 0

    def record_native(self, healthy: bool) -> None:
        if healthy:
            self.native_healthy += 1
            self.native_unhealthy = 0
        else:
            self.native_unhealthy += 1
            self.native_healthy = 0


class FailoverAgent:
    """Periodic probe-and-flip loop.  DI-friendly so unit tests can
    inject fake probes + a fake setter without booting the engine."""

    SETTING_KEY = "feed_generation.backend_override"

    def __init__(
        self,
        db_manager,
        *,
        probe_fn: Optional[Callable[[], dict]] = None,
        set_override_fn: Optional[Callable[[str, str], None]] = None,
        broadcast_fn: Optional[Callable[[dict], None]] = None,
        cfg=None,
    ) -> None:
        if db_manager is None:
            raise ValueError("FailoverAgent requires a db manager")
        self._db = db_manager
        if cfg is None:
            from core.config import feed_generation as _fg
            cfg = _fg
        self._cfg = cfg
        if probe_fn is None:
            from core.feed.health import probe_all
            probe_fn = lambda: probe_all(self._cfg)  # noqa: E731
        self._probe = probe_fn
        self._set_override_fn = set_override_fn
        self._broadcast_fn = broadcast_fn
        self._streaks = _Streaks()
        self._last_snapshot: dict = {}
        self._stopping = False

    # ── Public API ────────────────────────────────────────────────────

    def status(self) -> dict:
        """Inspection dict for the admin health endpoint."""
        return {
            "agent_enabled": bool(self._cfg.failover_agent_enabled),
            "interval_seconds": int(self._cfg.failover_agent_interval_seconds),
            "unhealthy_streak_required": int(self._cfg.failover_agent_unhealthy_streak_required),
            "healthy_streak_required": int(self._cfg.failover_agent_healthy_streak_required),
            "current_override": str(self._cfg.backend_override),
            "streaks": {
                "airflow_unhealthy": self._streaks.airflow_unhealthy,
                "airflow_healthy": self._streaks.airflow_healthy,
                "native_unhealthy": self._streaks.native_unhealthy,
                "native_healthy": self._streaks.native_healthy,
            },
            "last_snapshot": dict(self._last_snapshot),
        }

    def tick(self) -> dict:
        """Run one decision tick.  Returns a dict describing whether
        anything changed.  Safe to call from sync or async context."""
        snapshot = self._probe()
        self._last_snapshot = snapshot
        airflow = snapshot.get("airflow", {})
        native = snapshot.get("native", {})
        airflow_healthy = bool(airflow.get("healthy"))
        native_healthy = bool(native.get("healthy"))
        self._streaks.record_airflow(airflow_healthy)
        self._streaks.record_native(native_healthy)
        # Reflect health in Prometheus gauges so /metrics shows
        # current backend state without polling /api/admin/...
        try:
            from core.metrics import record_feed_backend_health
            record_feed_backend_health("airflow", airflow_healthy)
            record_feed_backend_health("native", native_healthy)
        except Exception:
            pass

        cur = str(self._cfg.backend_override or "auto").lower()
        unhealthy_req = int(self._cfg.failover_agent_unhealthy_streak_required)
        healthy_req = int(self._cfg.failover_agent_healthy_streak_required)
        desired = self._decide(
            current=cur,
            airflow_healthy=airflow_healthy,
            native_healthy=native_healthy,
            streaks=self._streaks,
            unhealthy_req=unhealthy_req,
            healthy_req=healthy_req,
        )

        out = {
            "current": cur,
            "desired": desired,
            "airflow_healthy": airflow_healthy,
            "native_healthy": native_healthy,
            "changed": False,
            "streaks": self.status()["streaks"],
        }
        if desired != cur:
            self._apply(desired, snapshot)
            out["changed"] = True
        return out

    async def run(self) -> None:
        """Long-running coroutine for background_jobs registry.  Sleeps
        ``interval_seconds`` between ticks; respects pause/stop via
        the registry's cancellation."""
        self._stopping = False
        while not self._stopping:
            try:
                result = self.tick()
                if result["changed"]:
                    logger.info(
                        "[failover_agent] flipped backend_override %s -> %s "
                        "(airflow_healthy=%s, native_healthy=%s)",
                        result["current"], result["desired"],
                        result["airflow_healthy"], result["native_healthy"],
                    )
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                logger.warning("[failover_agent] tick failed: %s", exc)
            interval = max(5, int(self._cfg.failover_agent_interval_seconds))
            try:
                await asyncio.sleep(interval)
            except asyncio.CancelledError:
                raise

    def stop(self) -> None:
        self._stopping = True

    # ── Internals ─────────────────────────────────────────────────────

    @staticmethod
    def _decide(
        *,
        current: str,
        airflow_healthy: bool,
        native_healthy: bool,
        streaks: _Streaks,
        unhealthy_req: int,
        healthy_req: int,
    ) -> str:
        """Decide what override SHOULD be, given the streak counters.

        Pure function — easy to unit test by feeding hand-crafted
        streak objects.  When the current override is ``halt`` the
        agent treats it as operator-imposed maintenance and only
        leaves it when BOTH backends are confirmed healthy for the
        recovery streak.
        """
        # Special case: 'halt' = operator pause; do not touch unless
        # both backends are healthy for the recovery window.
        if current == "halt":
            if (airflow_healthy and native_healthy
                    and streaks.airflow_healthy >= healthy_req
                    and streaks.native_healthy >= healthy_req):
                return "auto"
            return "halt"

        # Both unhealthy → halt.
        if (streaks.airflow_unhealthy >= unhealthy_req
                and streaks.native_unhealthy >= unhealthy_req):
            return "halt"

        # Only airflow unhealthy → native_only.
        if (streaks.airflow_unhealthy >= unhealthy_req
                and native_healthy):
            return "native_only"

        # Only native unhealthy → airflow_only.
        if (streaks.native_unhealthy >= unhealthy_req
                and airflow_healthy):
            return "airflow_only"

        # Recovery: previously overridden, but the failing side has
        # been healthy long enough AND the other side stayed healthy.
        if current == "native_only":
            if (airflow_healthy and native_healthy
                    and streaks.airflow_healthy >= healthy_req):
                return "auto"
            return current
        if current == "airflow_only":
            if (airflow_healthy and native_healthy
                    and streaks.native_healthy >= healthy_req):
                return "auto"
            return current

        # auto — stay auto.
        return "auto"

    def _apply(self, desired: str, snapshot: dict) -> None:
        """Persist the new override + audit + broadcast."""
        if self._set_override_fn is not None:
            self._set_override_fn(desired, "failover_agent")
        else:
            try:
                self._db.set_system_setting(
                    self.SETTING_KEY, desired,
                    updated_by="failover_agent",
                    description="Auto-set by feed failover agent",
                )
                from core import config as _cfg_mod
                _cfg_mod.invalidate_db_setting_cache(self.SETTING_KEY)
            except Exception as exc:
                logger.warning(
                    "[failover_agent] failed to persist override %r: %s",
                    desired, exc,
                )
                return
            try:
                self._db.audit(
                    "failover_agent",
                    "feed_backend_override_flipped",
                    resource_type="config",
                    resource_id=self.SETTING_KEY,
                    extra={"to": desired, "snapshot": snapshot},
                )
            except Exception:
                pass

        if self._broadcast_fn is not None:
            # 2026-10-07 -- a PLATFORM event (the deployment's backend
            # override, not one feed): addressed to every user holding the
            # admin role through THE platform function
            # (core/feed/event_audience.py::platform_event_audience).  It
            # used to carry no address at all and reached EVERY browser
            # through the notification outbox.  Nobody resolvable = not
            # sent, never sent to everybody.
            from core.feed.event_audience import (
                address, platform_event_audience)
            try:
                audience = platform_event_audience(self._db, role="admin")
            except Exception as exc:  # noqa: BLE001 -- never raises, but
                logger.warning("[failover_agent] admin audience could not "
                               "be resolved (%s) -- override change to %r "
                               "not broadcast", exc, desired)
                audience = []
            if not audience:
                logger.warning("[failover_agent] no admin resolvable -- "
                               "override change to %r not broadcast", desired)
            else:
                try:
                    self._broadcast_fn(address({
                        "type": "feed_backend_override_changed",
                        "to": desired,
                        "set_by": "failover_agent",
                        "snapshot": snapshot,
                    }, audience))
                except Exception:
                    pass

        # Prometheus metric — increment flip counter + reflect new
        # override value as a gauge so dashboards show "current state".
        try:
            from core.metrics import record_failover_flip, record_feed_backend_override
            cur = str(self._cfg.backend_override or "auto").lower()
            record_failover_flip(from_state=cur, to_state=desired)
            record_feed_backend_override(desired)
        except Exception:
            pass


# ── Process-wide singleton ────────────────────────────────────────────

_agent: Optional[FailoverAgent] = None


def get_agent(db_manager, broadcast_fn=None) -> FailoverAgent:
    """Return the process-wide FailoverAgent.  Constructed on first
    call; subsequent calls return the same instance so streaks
    persist across ticks."""
    global _agent
    if _agent is None:
        _agent = FailoverAgent(db_manager, broadcast_fn=broadcast_fn)
    return _agent


def reset_agent() -> None:
    """TEST SEAM (declared 2026-09-03) -- production must NOT call this.
    Test helper — drop the singleton."""
    global _agent
    _agent = None
