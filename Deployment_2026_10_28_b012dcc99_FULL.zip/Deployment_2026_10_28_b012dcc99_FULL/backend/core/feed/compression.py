"""Output-file compression — Phase 130.

Wraps the stdlib + optional third-party compressors behind a single
class so the feed engine doesn't have to switch on the compression
name at every write site.

Supported formats (driven by the ``CompressionFormat`` enum below):

  - ``none``   — pass-through
  - ``gzip``   — stdlib gzip
  - ``bzip2``  — stdlib bz2
  - ``zstd``   — optional, requires ``zstandard`` package
  - ``snappy`` — optional, requires ``python-snappy``

The optional formats raise a clear ``CompressionUnavailable`` when
their backing library isn't installed; the writer never tries to
guess.  Config flag ``feed_generation.allow_optional_compression``
controls whether the optional formats are advertised in the admin UI
(defaults true; flip false in air-gapped deploys where the optional
packages aren't shipped).
"""
from __future__ import annotations

import gzip
import bz2
import shutil
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Optional


class CompressionFormat(str, Enum):
    NONE   = "none"
    GZIP   = "gzip"
    BZIP2  = "bzip2"
    ZSTD   = "zstd"
    SNAPPY = "snappy"

    @classmethod
    def from_str(cls, value: Optional[str]) -> "CompressionFormat":
        if not value:
            return cls.NONE
        v = value.strip().lower()
        if v in ("", "none", "no", "false"):
            return cls.NONE
        if v in ("gz", "gzip"):
            return cls.GZIP
        if v in ("bz2", "bzip2"):
            return cls.BZIP2
        if v == "zstd":
            return cls.ZSTD
        if v == "snappy":
            return cls.SNAPPY
        raise ValueError(
            f"Unknown compression: {value!r}.  "
            f"Known: {[c.value for c in cls]}"
        )


class CompressionUnavailable(RuntimeError):
    """Raised when the chosen compression's backing library is not
    importable.  Carries the package name so the operator can fix
    the deployment without guessing."""


# ── File-extension table ────────────────────────────────────────────────────
#
# Matches the enterprise convention (``.csv.gz``, ``.dat.bz2``).  Filename
# renderer asks the writer for this so the rendered filename includes the
# right suffix — keeps the contract symmetric.

_SUFFIX: dict = {
    CompressionFormat.NONE:   "",
    CompressionFormat.GZIP:   ".gz",
    CompressionFormat.BZIP2:  ".bz2",
    CompressionFormat.ZSTD:   ".zst",
    CompressionFormat.SNAPPY: ".snappy",
}


@dataclass(frozen=True)
class CompressionResult:
    """Pure value object returned by ``CompressionWriter.compress``."""
    output_path: Path
    bytes_in: int
    bytes_out: int

    @property
    def ratio(self) -> float:
        if self.bytes_in == 0:
            return 1.0
        return round(self.bytes_out / self.bytes_in, 4)


# ── The class ───────────────────────────────────────────────────────────────


class CompressionWriter:
    """Compress an existing file (in place + rename, or to a new path).

    Stateless — pass the format on each call so a single writer can
    handle a batch of feeds with different formats without
    reconstruction.

    Example::

        cw = CompressionWriter()
        result = cw.compress(Path("/tmp/feed.csv"), CompressionFormat.GZIP)
        # result.output_path == /tmp/feed.csv.gz
    """

    def compress(
        self,
        input_path: Path,
        fmt: CompressionFormat,
        output_path: Optional[Path] = None,
        *,
        delete_input: bool = True,
        chunk_size: int = 1024 * 1024,
    ) -> CompressionResult:
        input_path = Path(input_path)
        if not input_path.exists():
            raise FileNotFoundError(input_path)
        if fmt == CompressionFormat.NONE:
            return CompressionResult(
                output_path=input_path,
                bytes_in=input_path.stat().st_size,
                bytes_out=input_path.stat().st_size,
            )
        if output_path is None:
            output_path = input_path.with_name(input_path.name + _SUFFIX[fmt])
        else:
            output_path = Path(output_path)
        bytes_in = input_path.stat().st_size
        # 2026-08-04 — structural atomicity.  The compressed stream used to be
        # written directly under its FINAL name in the output directory: a
        # consumer polling that directory could ingest a half-written
        # ``.gz``, and a failure mid-compress left the fragment behind under
        # the expected name.  All consumer-visible writes now route through
        # the single publication primitive — the final name only ever
        # comes into existence complete.
        from .publication import atomic_publication
        with atomic_publication(output_path) as _tmp:
            opener = self._opener_for(fmt, _tmp)
            with open(input_path, "rb") as src, opener as dst:
                shutil.copyfileobj(src, dst, length=chunk_size)
        bytes_out = output_path.stat().st_size
        if delete_input and output_path != input_path:
            try:
                input_path.unlink()
            except OSError:
                # Non-fatal: leftover uncompressed file isn't a
                # correctness issue, only disk hygiene.
                pass
        return CompressionResult(
            output_path=output_path, bytes_in=bytes_in, bytes_out=bytes_out,
        )

    @staticmethod
    def suffix_for(fmt: CompressionFormat) -> str:
        """Returns the filename suffix (including the leading dot)
        for the given format.  Empty for ``NONE``."""
        return _SUFFIX[fmt]

    # ── Internals ──────────────────────────────────────────────────────────

    @staticmethod
    def _opener_for(fmt: CompressionFormat, output_path: Path):
        if fmt == CompressionFormat.GZIP:
            return gzip.open(output_path, "wb")
        if fmt == CompressionFormat.BZIP2:
            return bz2.open(output_path, "wb")
        if fmt == CompressionFormat.ZSTD:
            try:
                import zstandard as _zstd
            except ImportError as exc:
                raise CompressionUnavailable(
                    "zstd compression requested but the 'zstandard' "
                    "package is not installed.  pip install zstandard "
                    "OR set output_options.compression to a stdlib "
                    "format (gzip / bzip2)."
                ) from exc
            cctx = _zstd.ZstdCompressor()
            f = open(output_path, "wb")
            return cctx.stream_writer(f)
        if fmt == CompressionFormat.SNAPPY:
            try:
                import snappy as _snappy
            except ImportError as exc:
                raise CompressionUnavailable(
                    "snappy compression requested but the "
                    "'python-snappy' package is not installed.  "
                    "pip install python-snappy."
                ) from exc
            # python-snappy's StreamCompressor exposes ``add_chunk(bytes)``
            # but no ``.write()``.  Wrap it so ``shutil.copyfileobj``
            # (which calls ``dst.write(buf)``) works without special-
            # casing snappy at the call site.
            class _SnappyWriter:
                def __init__(self, path):
                    self.path = path
                    self.f = None
                    self.compressor = _snappy.StreamCompressor()
                def __enter__(self):
                    self.f = open(self.path, "wb")
                    return self
                def write(self, data: bytes) -> int:
                    if not data:
                        return 0
                    self.f.write(self.compressor.add_chunk(data))
                    return len(data)
                def __exit__(self, *exc):
                    try:
                        tail = self.compressor.flush() if hasattr(self.compressor, "flush") else b""
                        if tail:
                            self.f.write(tail)
                    finally:
                        if self.f:
                            self.f.close()
                    return False
            return _SnappyWriter(output_path)
        raise AssertionError(f"unreachable compression format: {fmt}")
