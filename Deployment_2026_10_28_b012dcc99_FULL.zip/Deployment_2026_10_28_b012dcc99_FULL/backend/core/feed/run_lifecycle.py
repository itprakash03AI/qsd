"""A feed run survives a deploy (2026-10-14).

Found live: every rebuild of the rig -- and every Kubernetes rollout, whose
new pods carry new names -- left the run in flight "running" for the hourly
reaper.  The scheduler process (which hosts the queue worker on the rig and
in hybrid deployments) did not drain at all; the dedicated feed worker
drained 60 s (longer than Kubernetes' 30 s grace) and then deliberately left
held runs claimed, to avoid a duplicate delivery.

That concern is right, but the hour does not remove it -- knowing the old
process can no longer PUBLISH does.  A process that is exiting knows that
about itself.  THE routine, for every process that hosts the queue worker
(``core.scheduler.shutdown_scheduler`` and ``feed_worker.py``):

1. stop claiming and wait for held runs, up to
   ``feed_generation.shutdown_drain_seconds`` (inside the pod's grace);
2. close the PUBLISH GATE (``core.feed.delivery_protocol.close_publishing``):
   a publish not yet started is refused, one already inside is waited for;
   if one is STILL inside after the wait, nothing is handed back (that run
   may be delivered by this process at any instant) -- the next process /
   the reaper own it, exactly as before;
3. hand back what is still held (``hand_back_runs``): the attempt is failed
   with the reason, the run returns to the queue (a manual Run Now is failed
   instead -- never re-run by itself), its connection slots are released.

A process killed WITHOUT warning (OOM, SIGKILL) is covered by the pod's
next process (``queue_worker._reap_previous_process_once``) and, failing
that, the hourly reaper.
"""
from __future__ import annotations

import logging
import os
import time
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

#: set when this process handed back (or had to leave) in-flight runs: their
#: threads still run, but their work is DISOWNED -- the process must not wait
#: for them at exit (Python joins worker threads at interpreter exit; proven
#: live: the scheduler logged "stopped" and then sat until Docker killed it)
_DISOWNED = {"runs": []}

HANDED_BACK = ("the worker running this was shut down during the run (a deploy or "
               "restart); nothing was delivered; the run is back on the queue")
HANDED_BACK_MANUAL = ("the worker running this was shut down during the run (a deploy "
                      "or restart); nothing was delivered; run it again")


def _budget(budget_seconds: Optional[float]) -> float:
    if budget_seconds is not None:
        return max(0.0, float(budget_seconds))
    try:
        from core.config import feed_generation as _fg
        return max(0.0, float(_fg.shutdown_drain_seconds))
    except Exception:                                       # noqa: BLE001
        return 20.0


def hand_back_on_exit(worker: Any, db: Any, *, budget_seconds: Optional[float] = None,
                      publish_wait_seconds: float = 5.0) -> Dict[str, Any]:
    """Run the module's routine for ``worker`` (a ``FeedRunQueueWorker``).
    Returns what happened, for the exit log."""
    if worker is None:
        return {"worker": None}
    budget = _budget(budget_seconds)
    worker.begin_drain()
    deadline = time.monotonic() + budget
    while worker.held_run_ids() and time.monotonic() < deadline:
        time.sleep(0.25)
    held = sorted(worker.held_run_ids())
    if not held:
        logger.info("[run-lifecycle] drained cleanly: nothing held at exit")
        return {"held": [], "handed_back": 0}
    _DISOWNED["runs"] = list(held)
    from core.feed.delivery_protocol import close_publishing
    still = close_publishing("this worker is shutting down (a deploy or restart)",
                             wait_seconds=publish_wait_seconds)
    if still:
        logger.error(
            "[run-lifecycle] %d publish(es) still in progress after %.0f s: runs %s are NOT "
            "handed back (one may be delivered by this process at any instant); the next "
            "process on this pod, or the stale-run reaper, frees them",
            still, publish_wait_seconds, held)
        return {"held": held, "handed_back": 0, "publishing": still}
    try:
        out = db.hand_back_runs(held, pod_id=worker.pod_id)
    except Exception as exc:                                # noqa: BLE001
        logger.error("[run-lifecycle] could not hand back runs %s (%s); the next process "
                     "or the reaper frees them", held, exc)
        return {"held": held, "handed_back": 0, "error": str(exc)}
    logger.warning("[run-lifecycle] handed back at exit: %s", out)
    return dict(out, held=held)


def work_was_disowned() -> bool:
    """True when this process handed back (or left) runs whose threads still run."""
    return bool(_DISOWNED["runs"])


def exit_if_work_was_disowned(log=None) -> None:
    """The LAST step of a process's shutdown: when its in-flight runs were
    disowned, exit now instead of waiting for their threads (and their DuckDB
    child processes) to finish work that is no longer theirs -- the runs are
    back on the queue and the publish gate is closed.  A clean drain returns
    and the process exits normally."""
    if not work_was_disowned():
        return
    (log or logger).warning("[run-lifecycle] exiting now: runs %s were handed back; "
                            "their threads are not waited for", _DISOWNED["runs"])
    import logging as _lg
    import sys as _sys
    try:
        _lg.shutdown()
        _sys.stdout.flush()
        _sys.stderr.flush()
    finally:
        os._exit(0)


def hand_back_then_exit_from_signal(db, exit_code: int = 0, fallback_wait: float = 3.0) -> None:
    """For a process whose SIGTERM handler force-exits (the API in hybrid mode,
    ``main._force_exit_handler``): when it hosts a queue worker holding runs,
    run THE routine first; else keep its short wait.  Then exit."""
    try:
        from core.feed.queue_worker import peek_shared_queue_worker
        qw = peek_shared_queue_worker()
        if qw is not None and qw.held_run_ids() and db is not None:
            hand_back_on_exit(qw, db)
        else:
            time.sleep(max(0.0, fallback_wait))
    except Exception as exc:                                # noqa: BLE001
        logger.error("[run-lifecycle] hand-back from the signal path failed: %s", exc)
    os._exit(exit_code)


__all__ = ["hand_back_on_exit", "HANDED_BACK", "HANDED_BACK_MANUAL",
           "work_was_disowned", "exit_if_work_was_disowned",
           "hand_back_then_exit_from_signal"]
