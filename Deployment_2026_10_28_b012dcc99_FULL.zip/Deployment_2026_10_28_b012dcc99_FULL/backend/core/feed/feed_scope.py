"""THE scope chain of a feed (2026-10-12).

A mapping that applies to feeds -- a hold approver, a restatement policy, an
alert route -- is DATA keyed by a scope: ``feed`` (one feed), ``template``
(every member of one template), ``feed_group`` (e.g. one system entity's
group) or ``global``.  :func:`chain` lists the scopes a feed is in, MOST
SPECIFIC FIRST; a "the most specific wins" reader takes the first hit, an
"every scope adds" reader takes them all.  One answer to "which scopes is
this feed in".
"""
from __future__ import annotations

from typing import Any, List, Mapping, Optional, Tuple

SCOPES = ("feed", "template", "feed_group", "global")


def chain(feed: Optional[Mapping[str, Any]]) -> List[Tuple[str, Optional[int]]]:
    """[(scope, scope_id)] the feed belongs to, most specific first."""
    f = feed or {}
    out: List[Tuple[str, Optional[int]]] = []
    for scope, key in (("feed", "id"), ("template", "template_id"), ("feed_group", "feed_group_id")):
        if f.get(key) is not None:
            out.append((scope, int(f[key])))
    out.append(("global", None))
    return out


def matches(row: Mapping[str, Any], feed: Optional[Mapping[str, Any]]) -> bool:
    """Does this scoped row apply to the feed?"""
    return (row.get("scope"), row.get("scope_id")) in chain(feed)


def most_specific(rows, feed: Optional[Mapping[str, Any]]):
    """The row of the most specific scope the feed is in, or None."""
    by = {(r.get("scope"), r.get("scope_id")): r for r in rows or []}
    for key in chain(feed):
        if key in by:
            return by[key]
    return None
