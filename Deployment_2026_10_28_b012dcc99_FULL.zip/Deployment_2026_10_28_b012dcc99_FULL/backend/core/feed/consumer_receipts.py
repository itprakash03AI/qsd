"""Delivery RECEIPTS for feed CONSUMERS (2026-09-28).

docs/FEATURE_STRATEGY_2026_09_28.html #3.  A downstream team (often the
``viewer`` role, which has no /feeds/* route at all) asks the support desk
"did our file go, what was in it?".  Every fact that answers that already
exists on the producer's side -- the run row, the execution's delivery
chain verdict (``core/feed/delivery_hops.chain_verdict``), the completeness
certificate, the Download Centre row with its checksum, the delivery
attempts, and the decision ledger (``core/feed/dependency_skip.
decision_rows``).  This module COMPOSES them into one receipt per run and
adds no state: like the run surface, it runs no query it cannot get from
the DAO, so the receipt can never disagree with the record.

Three rules, each learned elsewhere in this codebase:

* **Unknown is never "delivered".**  A run with no execution row, no chain
  verdict, or an unreadable ledger says so in ``unknown`` and lands on
  ``outcome = "unknown"``.  "Could not read" and "did not deliver" lead a
  consumer to opposite phone calls.
* **No SQL, no connection details, no credentials, no data rows.**  The
  receipt names the file, its size, rows, checksum, the hop's LABEL and
  transport type -- never a destination URI, an endpoint, a query or a
  config bag.  ``assert_no_secrets`` is a guard the API runs on every
  receipt it serves, not a promise.
* **The gate is the feed's own view gate plus ONE clause.**  A consumer is
  a member of one of ``feed_configs.consumer_group_ids``; admins and
  support see everything; everyone else is told the feed does not exist
  (404, never 403 -- a refusal that names the feed leaks that it exists).
  The clause is NOT added to ``_filter_visible_feeds``: being a consumer
  widens nothing on the Today board, the run surface or /api/feeds.
"""
from __future__ import annotations

import html as _html
import logging
from datetime import date, datetime, timedelta, timezone
from typing import Any, Iterable, Mapping, Optional

logger = logging.getLogger(__name__)

#: One word the consumer reads.  ``delivered`` is claimed ONLY by the chain
#: verdict; every other value is "no file, and here is why".
OUTCOME_DELIVERED = "delivered"
OUTCOME_NOT_DELIVERED = "not_delivered"     # suppressed / dry run: by design
OUTCOME_FAILED = "failed"                   # the run failed or was cancelled
OUTCOME_SKIPPED = "skipped"                 # ACTION_CONDITION / decision
OUTCOME_WAITING = "waiting"                 # held on a dependency
OUTCOME_PENDING = "pending"
OUTCOME_RUNNING = "running"
OUTCOME_UNKNOWN = "unknown"
OUTCOMES = (OUTCOME_DELIVERED, OUTCOME_NOT_DELIVERED, OUTCOME_FAILED,
            OUTCOME_SKIPPED, OUTCOME_WAITING, OUTCOME_PENDING,
            OUTCOME_RUNNING, OUTCOME_UNKNOWN)

#: The receipt id: stable per run row, opaque, short enough for a URL.
RECEIPT_ID_PREFIX = "qsr-"

#: Keys that must NEVER appear in a served receipt (the guard's word list).
FORBIDDEN_KEYS = frozenset({
    "destination_config", "delivery_chain", "query_params", "sql",
    "raw_sql", "password", "secret", "private_key", "token", "api_key",
    "destination_uri", "endpoint_ref", "uri", "host", "connection_id",
    "backend_config", "file_path", "output_path", "destination_path",
})


# ── the gate ─────────────────────────────────────────────────────────────

def consumer_group_ids(feed: Optional[Mapping]) -> list:
    """The declared consumer groups, as ints; [] for none."""
    if not feed:
        return []
    out = []
    for g in (feed.get("consumer_group_ids") or []):
        try:
            out.append(int(g))
        except (TypeError, ValueError):
            continue
    return out


def _sees_everything(user: Mapping) -> bool:
    from core.entitlements import is_admin_like, is_support
    return bool(is_admin_like(user) or is_support(user))


def _is_consumer(db, feed: Optional[Mapping], user: Optional[Mapping]) -> bool:
    """Member of ANY of the feed's consumer groups.  False on missing
    inputs; a membership read that fails is False (fail closed)."""
    if not feed or not user:
        return False
    username = str(user.get("username") or "")
    if not username:
        return False
    from core.feed.permissions import user_in_group
    return any(user_in_group(db, username, gid) for gid in consumer_group_ids(feed))


def can_read_receipts(db, feed: Optional[Mapping], user: Optional[Mapping]) -> bool:
    """THE receipt gate: admin / support, the feed's own view gate (owner,
    owner-group member), or a declared consumer.  Nothing else."""
    if not feed or not user:
        return False
    if _sees_everything(user):
        return True
    from core.feed.permissions import can_view_feed
    try:
        if can_view_feed(feed, user, db):
            return True
    except Exception as exc:  # noqa: BLE001 - the clause below still answers
        logger.debug("[consumer_receipts] view gate failed for feed %s: %s",
                     feed.get("id"), exc)
    return _is_consumer(db, feed, user)


def consumable_feeds(db, user: Mapping) -> list:
    """The feeds on the caller's My Feeds page: every feed that declares a
    consumer group the caller belongs to; for admin / support, every feed
    that declares any consumer group (the consumer SURFACE, not the whole
    estate -- a feed with no declared consumers has no receipt audience).
    Membership is read once per group."""
    feeds = [f for f in (db.list_feed_configs() or []) if consumer_group_ids(f)]
    if _sees_everything(user):
        return feeds
    username = str((user or {}).get("username") or "")
    if not username:
        return []
    try:
        mine = {int(g["id"]) for g in (db.list_groups_for_user(username) or [])
                if g.get("id") is not None}
    except Exception as exc:  # noqa: BLE001
        logger.error("[consumer_receipts] group membership for %s could not be "
                     "read (%s) -- My Feeds is EMPTY, not 'no feeds'", username, exc)
        raise
    return [f for f in feeds if mine.intersection(consumer_group_ids(f))]


# ── composition ──────────────────────────────────────────────────────────

def receipt_id_for(run_id: Any) -> str:
    return f"{RECEIPT_ID_PREFIX}{int(run_id)}"


def run_id_from_receipt_id(receipt_id: str) -> Optional[int]:
    s = str(receipt_id or "").strip()
    if s.startswith(RECEIPT_ID_PREFIX):
        s = s[len(RECEIPT_ID_PREFIX):]
    try:
        return int(s)
    except ValueError:
        return None


def _as_date(value: Any) -> Optional[date]:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if value:
        try:
            return date.fromisoformat(str(value)[:10])
        except ValueError:
            return None
    return None


def _as_dt(value: Any) -> Optional[datetime]:
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except ValueError:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def _iso(value: Any) -> Optional[str]:
    dt = _as_dt(value)
    return dt.isoformat() if dt else None


def execution_for_run(db, feed_id: int, run: Mapping,
                      executions: Optional[Iterable[Mapping]] = None
                      ) -> Optional[dict]:
    """The execution row a run PRODUCED, or None.  Exact links first --
    the step recorder's stamp, the shared build_id, the manual run's
    derived build_id -- then the newest execution for the run's business
    date; a run with several attempts shows its LATEST attempt."""
    rows = list(executions) if executions is not None else None
    if rows is None:
        try:
            rows = db.list_feed_executions(int(feed_id), limit=200) or []
        except Exception as exc:  # noqa: BLE001
            logger.warning("[consumer_receipts] executions of feed %s unreadable: %s",
                           feed_id, exc)
            return None
    try:
        from core.feed.step_model.store import execution_id_for_run
        linked = execution_id_for_run(db, int(run["id"]))
    except Exception:  # noqa: BLE001
        linked = None
    if linked:
        for ex in rows:
            if str(ex.get("execution_id")) == str(linked):
                return dict(ex)
    build = run.get("build_id")
    if build:
        for ex in rows:
            if ex.get("build_id") and str(ex["build_id"]) == str(build):
                return dict(ex)
            if str(build) == f"manual-{ex.get('execution_id')}"[:40]:
                return dict(ex)
    bd = _as_date(run.get("business_date"))
    same_day = [ex for ex in rows if _as_date(ex.get("business_date")) == bd]
    if not same_day:
        return None
    same_day.sort(key=lambda ex: (str(ex.get("started_at") or ""), int(ex.get("id") or 0)))
    return dict(same_day[-1])


def _chain_verdict(execution: Optional[Mapping]) -> tuple:
    """``(verdict, reason)`` from the execution's stage_timings, or
    ``(None, why)`` when the record carries none."""
    if not execution:
        return None, "no execution record for this run"
    st = execution.get("stage_timings")
    if not isinstance(st, dict):
        return None, "the execution recorded no stage timings"
    chain = st.get("delivery_chain")
    if not isinstance(chain, dict) or not chain.get("verdict"):
        return None, "the execution recorded no delivery chain verdict"
    return str(chain.get("verdict")), (chain.get("reason") or None)


def _hops(attempts: Iterable[Mapping]) -> list:
    """Delivery attempts projected to what a consumer may see: the hop's
    label, transport type, attempt number, status, verification, the
    checksum of the bytes sent and when.  Never the URI or endpoint."""
    out = []
    for a in attempts:
        out.append({
            "hop": a.get("target"),
            "target_type": a.get("target_type"),
            "attempt": a.get("attempt"),
            "status": a.get("status"),
            "verification": a.get("verification"),
            "bytes_sent": a.get("bytes_sent"),
            "checksum": a.get("checksum"),
            "checksum_algorithm": a.get("checksum_algorithm"),
            "acknowledgment": a.get("acknowledgment"),
            "completed_at": _iso(a.get("completed_at")),
            "error": (str(a.get("error_message"))[:300]
                      if a.get("error_message") else None),
        })
    return out


def _attempts_for(db, feed_id: int, run: Mapping, execution: Optional[Mapping],
                  attempts: Optional[Iterable[Mapping]]) -> tuple:
    """The attempts of THIS run (matched on the execution's id / build) or,
    when nothing matches, every attempt of the business date.  ``(rows,
    unavailable_reason)``."""
    rows = list(attempts) if attempts is not None else None
    if rows is None:
        try:
            rows = db.list_delivery_attempts_for_feed(
                int(feed_id), _as_date(run.get("business_date")), limit=200) or []
        except Exception as exc:  # noqa: BLE001
            return [], f"delivery attempts could not be read: {exc}"
    bd = _as_date(run.get("business_date"))
    rows = [a for a in rows if _as_date(a.get("business_date")) == bd]
    keys = {str(k) for k in (run.get("build_id"),
                             (execution or {}).get("execution_id"),
                             (execution or {}).get("build_id")) if k}
    mine = [a for a in rows if a.get("build_id") and str(a["build_id"]) in keys]
    return (mine or rows), None


def sla_for(feed: Mapping, run: Mapping) -> Optional[datetime]:
    """The run's SLA as a UTC instant, from the SAME resolver the acting-time
    clocks use (``acting_time.resolve_sla_at``: ``sla_to`` in the feed's
    ``sla_timezone`` or UTC).  A run row carries its own ``sla_to`` (SOD
    copies the feed's; a backfill deliberately has none -- no breach clock
    by design); a legacy row without one falls back to the feed's unless
    it is a backfill."""
    from core.feed.acting_time import resolve_sla_at
    bd = _as_date(run.get("business_date"))
    if bd is None:
        return None
    sla_to = run.get("sla_to")
    if not sla_to and str(run.get("run_type") or "scheduled") != "backfill":
        sla_to = feed.get("sla_to")
    if not sla_to:
        return None
    tz = feed.get("sla_timezone")
    tz = tz.strip() if isinstance(tz, str) and tz.strip() else "UTC"
    return resolve_sla_at(bd, str(sla_to).lstrip("+"), tz)


def _decisions(db, feed_id: int, run: Mapping,
               events: Optional[Iterable[Mapping]]) -> tuple:
    """``(rows, unavailable_reason)`` from the ledger, projected by THE
    projection (``dependency_skip.decision_rows``) and filtered to this
    run.  An unreadable ledger is named, never an empty list."""
    from core.feed.dependency_skip import decision_rows
    rows = list(events) if events is not None else None
    if rows is None:
        try:
            rows = db.list_run_events(int(feed_id),
                                      business_date=_as_date(run.get("business_date"))) or []
        except Exception as exc:  # noqa: BLE001
            return None, f"the decision ledger could not be read: {exc}"
    out = []
    for d in decision_rows(rows, feed_run_id=run.get("id")):
        out.append({
            "event_type": d.get("event_type"),
            "dependency": d.get("dependency_key"),
            "actor": d.get("actor"),
            "at": _iso(d.get("at")),
            "reason_category": d.get("reason_category"),
            "reason": d.get("reason"),
        })
    return out, None


def _flags(run: Mapping, execution: Optional[Mapping], chain: Optional[str]) -> dict:
    fm = (execution or {}).get("files_metadata") or {}
    run_type = str(run.get("run_type") or "scheduled")
    dry = (run_type == "dry_run" or chain == "dry_run"
           or bool(isinstance(fm, dict) and fm.get("dry_run")))
    reason = str(run.get("action_reason") or "")
    return {
        "dry_run": dry,
        "backfill": run_type == "backfill",
        "manual": run_type == "manual",
        "suppressed": chain == "suppressed",
        "dependencies_overridden": "dependencies_overridden" in reason,
        "escalated": reason.startswith("Escalated after"),
    }


def _outcome(run: Mapping, execution: Optional[Mapping], chain: Optional[str],
             flags: Mapping) -> tuple:
    """``(outcome, reason)``.  The chain verdict is the ONLY path to
    ``delivered``.  The execution's terminal status outranks the run row's
    (the run row's terminal write is queued behind the execution's)."""
    if chain == "delivered":
        return OUTCOME_DELIVERED, None
    if flags.get("dry_run"):
        return OUTCOME_NOT_DELIVERED, "dry run: the chain ran and nothing was delivered"
    if chain == "suppressed":
        return OUTCOME_NOT_DELIVERED, "delivery suppressed on every hop (a backfill without delivery, or policy)"
    ex_status = str((execution or {}).get("status") or "").lower()
    run_status = str(run.get("status") or "").lower()
    if chain == "failed":
        return OUTCOME_FAILED, "the delivery chain did not deliver"
    if ex_status in ("failed", "cancelled"):
        return OUTCOME_FAILED, (f"the run was {ex_status}"
                                + (f" at step {execution.get('failed_stage')}"
                                   if (execution or {}).get("failed_stage") else ""))
    if run_status in ("failed", "cancelled"):
        return OUTCOME_FAILED, f"the run was {run_status}"
    if run_status == "skipped":
        return OUTCOME_SKIPPED, (str(run.get("action_reason") or "").strip()
                                 or "skipped by the run condition")
    if run_status in ("pending", "queued") and str(run.get("action_decision") or "RUN") == "WAIT":
        return OUTCOME_WAITING, (str(run.get("action_reason") or "").strip()
                                 or "held on a dependency")
    if run_status in ("pending", "queued"):
        return OUTCOME_PENDING, "not started yet"
    if run_status in ("running", "in_progress") or ex_status == "running":
        return OUTCOME_RUNNING, "still running"
    return OUTCOME_UNKNOWN, None


def build_receipt(db, feed: Mapping, run: Mapping, *,
                  execution: Optional[Mapping] = None,
                  executions: Optional[Iterable[Mapping]] = None,
                  attempts: Optional[Iterable[Mapping]] = None,
                  events: Optional[Iterable[Mapping]] = None,
                  now: Optional[datetime] = None) -> dict:
    """ONE run's receipt.  Every optional collection is a pre-read the
    list page hands in (executions / attempts / events of the feed) so a
    week of receipts is not a week of round trips; a single receipt reads
    them itself."""
    now = now or datetime.now(timezone.utc)
    unknown: list = []
    feed_id = int(feed["id"])

    ex = dict(execution) if execution is not None else execution_for_run(
        db, feed_id, run, executions)
    chain, chain_reason = _chain_verdict(ex)
    if chain is None and str(run.get("status") or "").lower() in ("completed", "failed"):
        unknown.append(f"delivery verdict: {chain_reason}")
    flags = _flags(run, ex, chain)
    outcome, outcome_reason = _outcome(run, ex, chain, flags)
    if outcome == OUTCOME_UNKNOWN:
        unknown.append("outcome: the record carries no delivery verdict "
                       f"and no terminal status (run status {run.get('status')!r})")

    hops, hops_unavailable = _attempts_for(db, feed_id, run, ex, attempts)
    if hops_unavailable:
        unknown.append(hops_unavailable)
    hop_rows = _hops(hops)

    # the file -- the Download Centre row when one was registered, else
    # what the execution row itself says it produced.
    download = None
    if ex and ex.get("execution_id"):
        try:
            download = db.find_feed_download_for_execution(feed_id, ex["execution_id"])
        except Exception as exc:  # noqa: BLE001
            unknown.append(f"the Download Centre row could not be read: {exc}")
    sent_sum = next((h for h in hop_rows if h.get("status") == "succeeded"
                     and h.get("checksum")), None)
    rows = (ex or {}).get("total_rows")
    if rows in (None, 0) and run.get("total_rows"):
        rows = run.get("total_rows")
    size = (download or {}).get("file_size_bytes") or (ex or {}).get("file_size_bytes") \
        or run.get("file_size_bytes")
    file_info = {
        "name": (download or {}).get("filename") or (ex or {}).get("output_filename"),
        "rows": rows,
        "size_bytes": size,
        "checksum": (download or {}).get("checksum") or (sent_sum or {}).get("checksum"),
        "checksum_algorithm": ((download or {}).get("checksum_algorithm")
                               or (sent_sum or {}).get("checksum_algorithm")),
        "format": (ex or {}).get("output_format") or feed.get("output_format"),
        "download_file_id": (download or {}).get("file_id"),
    }
    if outcome == OUTCOME_DELIVERED and not file_info["name"]:
        unknown.append("file name: neither a Download Centre row nor the "
                       "execution recorded one")

    # completeness -- the certificate the engine wrote, or its absence.
    fm = (ex or {}).get("files_metadata") or {}
    cert = fm.get("completeness_verdict") if isinstance(fm, dict) else None
    if isinstance(cert, dict) and cert.get("state"):
        completeness = {"state": cert.get("state"),
                        "reasons": [str(r) for r in (cert.get("reasons") or [])][:10]}
    else:
        completeness = {"state": None,
                        "reasons": ["dry run: nothing is certified"] if flags["dry_run"]
                        else ["no completeness certificate was recorded"]}
        if outcome == OUTCOME_DELIVERED:
            unknown.append("completeness: no certificate was recorded for a delivered run")

    # delivered at vs SLA -- the same SLA resolver the acting-time clocks use.
    delivered_at = None
    if outcome == OUTCOME_DELIVERED:
        delivered_at = _as_dt((ex or {}).get("delivery_completed_at"))
        if delivered_at is None:
            done = [h for h in hop_rows if h.get("status") == "succeeded" and h.get("completed_at")]
            if done:
                delivered_at = _as_dt(max(h["completed_at"] for h in done))
        if delivered_at is None:
            unknown.append("delivered at: no delivery time was recorded")
    try:
        sla_at = sla_for(feed, run)
    except Exception as exc:  # noqa: BLE001
        sla_at = None
        unknown.append(f"SLA: could not be resolved ({exc})")
    late: Optional[bool] = None
    minutes_late: Optional[int] = None
    if sla_at is not None:
        if delivered_at is not None:
            late = delivered_at > sla_at
            minutes_late = max(0, int((delivered_at - sla_at).total_seconds() // 60)) if late else 0
        elif outcome in (OUTCOME_DELIVERED,):
            late = None
        else:
            late = now > sla_at
            minutes_late = int((now - sla_at).total_seconds() // 60) if late else 0
    sla = {"sla_at": sla_at.isoformat() if sla_at else None,
           "sla_to": run.get("sla_to") or (feed.get("sla_to")
                                           if not flags["backfill"] else None),
           "sla_timezone": (feed.get("sla_timezone") or "UTC") if sla_at else None,
           "delivered_at": delivered_at.isoformat() if delivered_at else None,
           "late": late, "minutes_late": minutes_late}

    decisions, decisions_unavailable = _decisions(db, feed_id, run, events)
    if decisions_unavailable:
        unknown.append(decisions_unavailable)

    return {
        "receipt_id": receipt_id_for(run["id"]),
        "generated_at": now.isoformat(),
        "feed": {"id": feed_id, "name": feed.get("name"),
                 "display_name": feed.get("display_name"),
                 "description": feed.get("description")},
        "business_date": str(_as_date(run.get("business_date")) or run.get("business_date")),
        "run": {"id": run.get("id"), "status": run.get("status"),
                "run_type": str(run.get("run_type") or "scheduled"),
                "started_at": _iso(run.get("started_at")),
                "completed_at": _iso(run.get("completed_at")),
                "execution_id": (ex or {}).get("execution_id"),
                "error": (str(run.get("error") or (ex or {}).get("error_message") or "")[:500]
                          or None) if outcome == OUTCOME_FAILED else None},
        "outcome": outcome,
        "outcome_reason": outcome_reason,
        "file": file_info,
        "completeness": completeness,
        "delivery": {"verdict": chain, "reason": chain_reason if chain else None,
                     "hops": hop_rows},
        "sla": sla,
        "decisions": decisions,
        "flags": flags,
        "unknown": unknown,
    }


def assert_no_secrets(receipt: Any, *, _path: str = "receipt") -> None:
    """Refuse a receipt that carries a key from FORBIDDEN_KEYS anywhere in
    it.  Run by the API on every receipt served: the composition above
    never puts one in, and this is what makes that a guarantee rather
    than a habit."""
    if isinstance(receipt, dict):
        for k, v in receipt.items():
            if str(k).lower() in FORBIDDEN_KEYS:
                raise ValueError(f"receipt carries forbidden key {k!r} at {_path}")
            assert_no_secrets(v, _path=f"{_path}.{k}")
    elif isinstance(receipt, (list, tuple)):
        for i, v in enumerate(receipt):
            assert_no_secrets(v, _path=f"{_path}[{i}]")


# ── the list page ────────────────────────────────────────────────────────

def receipts_for_feeds(db, feeds: Iterable[Mapping], *, date_from: date,
                       date_to: date, now: Optional[datetime] = None) -> dict:
    """Every run of the given feeds in the window, newest date first, as
    receipts; manual runs and dry runs INCLUDED (a consumer asks whether a
    file went, whoever pressed the button) and labelled by ``run.run_type``.
    ``unavailable`` names a feed whose runs could not be listed -- a
    consumer must not read an empty page as "nothing went"."""
    now = now or datetime.now(timezone.utc)
    out: list = []
    unavailable: list = []
    feeds = list(feeds)
    wanted = {int(f["id"]) for f in feeds}
    try:
        all_runs = db.list_feed_runs(business_date_from=date_from,
                                     business_date_to=date_to, limit=None,
                                     include_manual=True) or []
    except Exception as exc:  # noqa: BLE001
        # ONE failure, named once per feed: the page must not read as
        # "nothing went" for any of them.
        return {"receipts": [],
                "unavailable": [{"feed_id": fid,
                                 "reason": f"runs could not be listed: {exc}"}
                                for fid in sorted(wanted)]}
    by_feed: dict = {}
    for r in all_runs:
        fid = int(r.get("feed_config_id") or 0)
        if fid in wanted:
            by_feed.setdefault(fid, []).append(r)
    for feed in feeds:
        fid = int(feed["id"])
        runs = by_feed.get(fid) or []
        if not runs:
            continue
        try:
            executions = db.list_feed_executions(fid, limit=500) or []
        except Exception as exc:  # noqa: BLE001
            executions = None
            unavailable.append({"feed_id": fid, "reason": f"executions could not be listed: {exc}"})
        try:
            attempts = db.list_delivery_attempts_for_feed(fid, None, limit=1000) or []
        except Exception as exc:  # noqa: BLE001
            attempts = None
            unavailable.append({"feed_id": fid, "reason": f"delivery attempts could not be listed: {exc}"})
        events_by_date: dict = {}
        for run in runs:
            bd = _as_date(run.get("business_date"))
            if bd not in events_by_date:
                try:
                    events_by_date[bd] = db.list_run_events(fid, business_date=bd) or []
                except Exception:  # noqa: BLE001
                    events_by_date[bd] = None
            out.append(build_receipt(db, feed, run, executions=executions,
                                     attempts=attempts, events=events_by_date[bd],
                                     now=now))
    out.sort(key=lambda r: (str(r["business_date"]), int(r["run"]["id"] or 0)), reverse=True)
    return {"receipts": out, "unavailable": unavailable}


def window(days: int, *, today: Optional[date] = None) -> tuple:
    today = today or datetime.now(timezone.utc).date()
    days = max(1, min(int(days or 7), 62))
    return today - timedelta(days=days - 1), today


# ── the printable receipt ────────────────────────────────────────────────

def _fmt_bytes(n: Any) -> str:
    try:
        n = int(n)
    except (TypeError, ValueError):
        return "unknown"
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:,} {unit}" if unit == "B" else f"{n:,.1f} {unit}"
        n = n / 1024
    return str(n)


def outcome_label(receipt: Mapping) -> str:
    o = receipt.get("outcome")
    return {
        OUTCOME_DELIVERED: "Delivered",
        OUTCOME_NOT_DELIVERED: "Not delivered (by design)",
        OUTCOME_FAILED: "Failed -- not delivered",
        OUTCOME_SKIPPED: "Skipped -- not delivered",
        OUTCOME_WAITING: "Waiting on a dependency",
        OUTCOME_PENDING: "Not started",
        OUTCOME_RUNNING: "Running",
    }.get(o, "Unknown -- could not tell")


def render_receipt_html(receipt: Mapping) -> str:
    """A plain, printable page: the facts, the gaps NAMED, nothing else."""
    e = _html.escape
    f = receipt.get("file") or {}
    s = receipt.get("sla") or {}
    d = receipt.get("delivery") or {}
    c = receipt.get("completeness") or {}
    feed = receipt.get("feed") or {}
    title = f"Delivery receipt -- {feed.get('display_name') or feed.get('name')} -- {receipt.get('business_date')}"
    rows = [
        ("Receipt", receipt.get("receipt_id")),
        ("Feed", feed.get("display_name") or feed.get("name")),
        ("Business date", receipt.get("business_date")),
        ("Outcome", outcome_label(receipt)
         + (f" -- {receipt['outcome_reason']}" if receipt.get("outcome_reason") else "")),
        ("Run", f"#{(receipt.get('run') or {}).get('id')} ({(receipt.get('run') or {}).get('run_type')})"),
        ("File", f.get("name") or "unknown"),
        ("Rows", f"{int(f['rows']):,}" if f.get("rows") is not None else "unknown"),
        ("Size", _fmt_bytes(f.get("size_bytes")) if f.get("size_bytes") is not None else "unknown"),
        ("Checksum", (f"{f.get('checksum_algorithm') or ''} {f.get('checksum')}".strip()
                      if f.get("checksum") else "none recorded")),
        ("Completeness", (str(c.get("state") or "not certified").upper()
                          + (": " + "; ".join(c.get("reasons") or []) if c.get("reasons") else ""))),
        ("Delivery chain", (str(d.get("verdict") or "no verdict recorded")
                            + (f" -- {d.get('reason')}" if d.get("reason") else ""))),
        ("Delivered at", s.get("delivered_at") or "--"),
        ("SLA", (f"{s.get('sla_at')}" if s.get("sla_at") else "no SLA declared")),
        ("Against SLA", ("on time" if s.get("late") is False
                         else f"LATE by {s.get('minutes_late')} min" if s.get("late")
                         else "--")),
    ]
    parts = [
        "<!DOCTYPE html><html><head><meta charset='utf-8'>",
        f"<title>{e(title)}</title>",
        "<style>body{font-family:Segoe UI,Arial,sans-serif;margin:32px;color:#222}"
        "table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:6px 10px;"
        "text-align:left;vertical-align:top}th{background:#f3f3f3;width:180px}"
        ".gap{color:#b00}.ok{color:#186}@media print{body{margin:8px}}</style></head><body>",
        f"<h1>{e(title)}</h1>",
        f"<p class='{'ok' if receipt.get('outcome') == OUTCOME_DELIVERED else 'gap'}'>"
        f"<b>{e(outcome_label(receipt))}</b></p>",
        "<table>" + "".join(f"<tr><th>{e(str(k))}</th><td>{e(str(v))}</td></tr>"
                            for k, v in rows) + "</table>",
    ]
    hops = d.get("hops") or []
    if hops:
        parts.append("<h2>Delivery hops</h2><table><tr><th>Hop</th><th>Type</th>"
                     "<th>Attempt</th><th>Status</th><th>Verified</th><th>Completed</th></tr>")
        for h in hops:
            parts.append("<tr>" + "".join(
                f"<td>{e(str(h.get(k) if h.get(k) is not None else '--'))}</td>"
                for k in ("hop", "target_type", "attempt", "status", "verification",
                          "completed_at")) + "</tr>")
        parts.append("</table>")
    dec = receipt.get("decisions")
    parts.append("<h2>Decisions</h2>")
    if dec is None:
        parts.append("<p class='gap'>The decision ledger could not be read.</p>")
    elif not dec:
        parts.append("<p>No dependency was skipped or overridden for this run.</p>")
    else:
        parts.append("<ul>" + "".join(
            f"<li><b>{e(str(x.get('event_type')))}</b> {e(str(x.get('dependency') or ''))}"
            f" by {e(str(x.get('actor') or 'unknown'))} at {e(str(x.get('at') or '?'))}"
            + (f" -- {e(str(x.get('reason')))}" if x.get("reason") else "") + "</li>"
            for x in dec) + "</ul>")
    unknown = receipt.get("unknown") or []
    if unknown:
        parts.append("<h2 class='gap'>Could not be read</h2><ul class='gap'>"
                     + "".join(f"<li>{e(str(u))}</li>" for u in unknown) + "</ul>")
    parts.append(f"<p><small>Generated {e(str(receipt.get('generated_at')))} by QueryStudio. "
                 "This receipt is assembled from the platform's own records; it carries no "
                 "data rows and no connection details.</small></p></body></html>")
    return "\n".join(parts)
