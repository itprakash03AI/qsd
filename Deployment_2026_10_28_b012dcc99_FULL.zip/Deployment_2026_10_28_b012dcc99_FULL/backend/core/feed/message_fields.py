"""Which fields of an upstream MESSAGE are shown, and where -- DATABASE data
(2026-10-12, the owner: "what columns are you showing from the Kafka message
table").  The table ``feed_message_fields`` (seeded once with the owner's
QS_KAFKA_MESSAGE columns, edited at /api/admin/feed-message-fields): the
dependency tile on Feed Run Status shows the ``on_tile`` rows, the Upstream
messages table the ``on_monitor`` rows, both in ``sort_order`` and under their
``label``.  A field is read case-insensitively from the message.  Cached
``CACHE_SECONDS``; writes invalidate.
"""
from __future__ import annotations

import time
from typing import Any, Dict, List, Mapping

CACHE_SECONDS = 30
_cache: Dict[str, Any] = {"at": 0.0, "rows": None}


def invalidate() -> None:
    _cache["at"], _cache["rows"] = 0.0, None


def _rows() -> List[Dict[str, Any]]:
    now = time.monotonic()
    if _cache["rows"] is not None and now - _cache["at"] < CACHE_SECONDS:
        return _cache["rows"]
    from core.database import get_db_manager
    db = get_db_manager()
    try:
        rows = list(db.list_feed_message_fields() or []) if db is not None else []
    except Exception:                                   # noqa: BLE001 -- unreadable = nothing shown
        rows = []
    _cache["at"], _cache["rows"] = now, rows
    return rows


def shown(where: str) -> List[Dict[str, str]]:
    """``where`` = "tile" | "monitor": [{field, label}] in display order."""
    key = "on_tile" if where == "tile" else "on_monitor"
    return [{"field": r["field"], "label": r["label"]} for r in _rows() if r.get(key)]


def identifying(fields: Mapping[str, Any] | None) -> Dict[str, Any]:
    """Only the fields that say WHAT a message is about (``identifies``),
    as the message spells them -- the expected message of a waiting tile."""
    keep = {str(r["field"]).upper() for r in _rows() if r.get("identifies")}
    return {k: v for k, v in (fields or {}).items() if str(k).upper() in keep}


def values(fields: Mapping[str, Any] | None, where: str) -> Dict[str, Any]:
    """The shown fields' values from a message (case-insensitive)."""
    upper = {str(k).upper(): v for k, v in (fields or {}).items()}
    return {f["field"]: upper.get(f["field"].upper()) for f in shown(where)}
