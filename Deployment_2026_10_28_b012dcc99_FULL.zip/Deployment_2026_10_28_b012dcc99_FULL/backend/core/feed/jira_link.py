"""
Step 8 — JIRA linkage for change control (BRD §15.2).

Decisions implemented (not re-litigated):

* JIRA binds to the CHANGE, not the object — callers stamp the ticket
  on the approval request / deploy record; this module only VALIDATES.
* JIRA validates, never gates the RUN.  Nothing on the run path imports
  this module (proven by test: with the client raising, a run-path pin
  is unaffected).  It may gate the CHANGE — and even there an OUTAGE is
  distinguished from an INVALID ticket: a change-control system that can
  halt production when a third-party tracker is down has become an
  availability risk, so the outage policy defaults to ``allow`` (and is
  recorded, never silent).

Three-state honesty (the FR-SEC-03 lesson applied to tickets): an
UNREACHABLE tracker is neither "valid" nor "invalid" — it is its own
outcome (``unavailable``) and policy decides what that means for the
change.  Folding an outage into either verdict is how a fail-open
becomes an escalation or an availability hole.

The client is an injected seam (``set_jira_client`` / per-call
``client=``) with one method::

    client.get_ticket(ticket_id) -> {"key": str, "status": str} | None

No HTTP client lives here — a deployment wires one (base_url etc. are
declared under ``feed_generation.governance.jira`` in core/config.py);
tests inject fakes.  There is deliberately no network fallback: an
enabled-but-unwired client is an OUTAGE, not a pass.
"""

import logging
import re
from typing import Any

logger = logging.getLogger(__name__)

#: PROJ-123 shape.  Project key: leading letter then letters/digits/underscore
#: (JIRA's own rule); issue number: digits.
TICKET_RE = re.compile(r"^[A-Z][A-Z0-9_]{0,31}-\d{1,10}$")

_DEFAULT_ALLOWED_STATUSES = ("Approved", "Ready for Deployment", "In Progress")

_client = None


def set_jira_client(client) -> None:
    """TEST SEAM (declared 2026-09-03) -- production must NOT call this.
    Wire the deployment's JIRA client (or ``None`` to unwire)."""
    global _client
    _client = client


def _cfg() -> dict[str, Any]:
    from core import config as _config  # late import — config is heavyweight
    gov = _config.get("feed_generation", "governance", {}) or {}
    return gov.get("jira", {}) or {}


def validate_ticket(ticket_id: str | None, *, client=None,
                    allowed_statuses=None,
                    enabled: bool | None = None) -> dict[str, Any]:
    """Validate one ticket for a CHANGE.  Never raises — every outcome is
    a value, because the caller must record it on the deploy record.

    Outcomes:
    * ``disabled``       — JIRA linkage off; the change proceeds without
      a ticket check (recorded as such, never silently);
    * ``missing``        — linkage on, no ticket given (refuse the change);
    * ``invalid_format`` — not PROJ-123 shaped (refuse);
    * ``not_found``      — JIRA answered: no such ticket (refuse);
    * ``bad_status``     — exists, but not in an allowed state (refuse);
    * ``valid``          — exists and in an allowed state;
    * ``unavailable``    — the tracker could not answer (client raised or
      unwired while enabled) — POLICY decides, `gate_change` applies it.
    """
    cfg = _cfg()
    if enabled is None:
        enabled = bool(cfg.get("enabled", False))
    if not enabled:
        return {"ticket": ticket_id, "outcome": "disabled",
                "detail": "JIRA linkage disabled — ticket not checked"}
    if not ticket_id or not str(ticket_id).strip():
        return {"ticket": ticket_id, "outcome": "missing",
                "detail": "a change to a governed object requires a ticket"}
    tid = str(ticket_id).strip()
    if not TICKET_RE.match(tid):
        return {"ticket": tid, "outcome": "invalid_format",
                "detail": f"{tid!r} is not a PROJ-123 shaped ticket id"}
    if allowed_statuses is None:
        allowed_statuses = cfg.get("allowed_statuses") \
            or list(_DEFAULT_ALLOWED_STATUSES)
    cl = client if client is not None else _client
    if cl is None:
        return {"ticket": tid, "outcome": "unavailable",
                "detail": "JIRA linkage enabled but no client is wired"}
    try:
        found = cl.get_ticket(tid)
    except Exception as exc:  # noqa: BLE001 — outage is a VALUE, not a crash
        logger.warning("[jira] tracker unavailable validating %s: %s",
                       tid, exc)
        return {"ticket": tid, "outcome": "unavailable",
                "detail": f"JIRA did not answer: {exc}"}
    if not found:
        return {"ticket": tid, "outcome": "not_found",
                "detail": f"ticket {tid} does not exist"}
    status = (found or {}).get("status")
    allowed_lc = {str(s).lower() for s in allowed_statuses}
    if str(status).lower() not in allowed_lc:
        return {"ticket": tid, "outcome": "bad_status", "status": status,
                "detail": f"ticket {tid} is in {status!r}, not one of "
                          f"{sorted(allowed_statuses)}"}
    return {"ticket": tid, "outcome": "valid", "status": status,
            "detail": "ticket exists and is in an allowed state"}


def gate_change(validation: dict[str, Any], *,
                outage_policy: str | None = None) -> tuple[bool, str]:
    """Apply a validation outcome to a CHANGE (never a run).

    Returns ``(allowed, reason)``.  ``unavailable`` follows
    ``outage_policy`` — ``allow`` (default: the tracker must not become
    an availability risk; the deploy record carries the outage) or
    ``block`` (a deployment that prefers stopping changes during a
    tracker outage)."""
    if outage_policy is None:
        outage_policy = str(_cfg().get("outage_policy", "allow"))
    outcome = (validation or {}).get("outcome")
    detail = (validation or {}).get("detail", "")
    if outcome in ("valid", "disabled", "skipped"):
        return True, detail or f"ticket outcome {outcome}"
    if outcome == "unavailable":
        if outage_policy == "block":
            return False, (f"JIRA unavailable and outage_policy=block — "
                           f"{detail}")
        logger.warning(
            "[jira] change allowed during tracker outage "
            "(outage_policy=allow) — validation recorded as 'unavailable': "
            "%s", detail)
        return True, "JIRA unavailable — allowed by outage_policy=allow"
    return False, detail or f"ticket outcome {outcome}"
