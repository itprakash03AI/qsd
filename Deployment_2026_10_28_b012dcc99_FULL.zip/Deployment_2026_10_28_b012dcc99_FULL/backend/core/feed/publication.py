"""Atomic publication — the ONE way a consumer-visible file comes into being.

2026-08-04 strategic redesign.  A feed is a contract with a downstream
system that cannot see when it lies.  The most basic lie is a torn read:
a consumer polling the output directory picks up a half-written file
under its final name.  Three sibling paths (format conversion, local
delivery, SFTP upload, control file) were individually fixed with
temp+rename on 2026-08-03 — and the compression path was missed, which
is the proof that per-call-site convention does not scale.  Atomicity
must be structural, not remembered.

This module is that structure:

    with atomic_publication(final_path) as tmp:
        ...write into tmp...            # consumer can never see tmp
    # <- on clean exit tmp is renamed onto final_path (os.replace,
    #    atomic within one filesystem).  On ANY failure the partial is
    #    removed and final_path either does not exist or is the
    #    previous complete file — never a fragment.

Guarantees:
  * The temp file lives in a ``.qs-partial`` subdirectory of the final
    path's directory — invisible to consumers globbing the directory,
    and on the same filesystem so the final ``os.replace`` is atomic.
  * The temp filename KEEPS the final file's full name as its suffix,
    so extension-validating writers (openpyxl requires ``.xlsx``) work
    unchanged.
  * Failure cleanup never masks the original error.

Writers that publish consumer-visible files MUST route through this
primitive.  Do not hand-roll temp+rename at call sites — that is the
convention this module exists to retire.
"""
from __future__ import annotations

import logging
import os
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator, Union

logger = logging.getLogger(__name__)

#: Name of the scratch subdirectory.  A leading dot keeps it out of
#: ``*`` globs (POSIX + Python glob semantics); consumers polling the
#: output directory can never observe an in-flight file.
SCRATCH_DIR_NAME = ".qs-partial"


def scratch_path_for(final_path: Union[str, Path]) -> Path:
    """Return a fresh, collision-free scratch path for ``final_path``.

    The scratch file sits under ``<dir>/.qs-partial/<pid>-<token>-<name>``
    — same filesystem as the destination (atomic rename), hidden from
    directory globs, and ending with the final filename so extension-
    validating writers accept it.
    """
    final = Path(final_path)
    scratch_dir = final.parent / SCRATCH_DIR_NAME
    scratch_dir.mkdir(parents=True, exist_ok=True)
    token = uuid.uuid4().hex[:8]
    return scratch_dir / f"{os.getpid()}-{token}-{final.name}"


@contextmanager
def atomic_publication(final_path: Union[str, Path]) -> Iterator[Path]:
    """Context manager yielding a scratch path; publishes atomically on exit.

    On clean exit the scratch file is moved onto ``final_path`` with
    ``os.replace`` (atomic within one filesystem — the scratch dir is a
    subdirectory of the destination directory, so it always is).

    On ANY exception the scratch file is removed and the exception
    propagates unchanged; ``final_path`` is never a fragment.

    Raises ``FileNotFoundError`` on clean exit if the body never
    created the scratch file — publishing nothing is a bug, not a
    success.
    """
    final = Path(final_path)
    tmp = scratch_path_for(final)
    try:
        try:
            yield tmp
        except FileNotFoundError as exc:
            # 2026-10-11 -- a writer that lost its scratch DIRECTORY (not a
            # missing input of its own) is named as such: the directory is
            # shared by every publication into this output dir, and "No such
            # file: /app/.../.qs-partial/<pid>-<tok>-<name>" with the path
            # redacted on the record read as a vanished data file.  The
            # error_message sanitiser redacts the whole path, so the names
            # the operator needs travel separately from it.
            if not tmp.parent.is_dir():
                logger.error(
                    "[publication] the scratch directory %s was removed while "
                    "the writer for %s ran (scratch file %s); %s",
                    tmp.parent, final, tmp.name, exc)
                raise FileNotFoundError(
                    f"atomic_publication: the scratch file '{tmp.name}' for "
                    f"'{final.name}' vanished -- its shared scratch directory "
                    f"'{SCRATCH_DIR_NAME}' under '{final.parent.name}' was "
                    f"removed while the writer ran; another process cleaned "
                    f"it from under a publication in flight "
                    f"(original: {exc})") from exc
            raise
        if not tmp.exists():
            raise FileNotFoundError(
                f"atomic_publication: writer completed without creating "
                f"{tmp} — nothing to publish to {final}"
            )
        os.replace(tmp, final)
    finally:
        _cleanup_scratch(tmp)


def publish_file(source_path: Union[str, Path],
                 final_path: Union[str, Path]) -> Path:
    """Atomically publish an existing (already-complete) local file.

    Copies ``source_path`` into the scratch area and renames onto
    ``final_path``.  Use when the content already exists as a complete
    local file (e.g. local delivery of a rendered feed output).
    """
    import shutil
    final = Path(final_path)
    with atomic_publication(final) as tmp:
        shutil.copy2(source_path, tmp)
    return final


def publish_text(text: str, final_path: Union[str, Path],
                 encoding: str = "utf-8") -> Path:
    """Atomically publish small text content (e.g. a control file)."""
    final = Path(final_path)
    with atomic_publication(final) as tmp:
        tmp.write_text(text, encoding=encoding)
    return final


def _cleanup_scratch(tmp: Path) -> None:
    """Remove a leftover scratch file.  The scratch DIRECTORY stays.

    Never raises — cleanup must not mask the writer's own error — but
    never silently swallows either: failures are logged.

    2026-10-11 -- this used to ``rmdir`` the scratch directory "when
    empty".  The directory is SHARED by every publication into one output
    directory, and a sibling publication is inside ``scratch_path_for``
    (``mkdir(exist_ok=True)`` done, its file not yet opened) for a moment
    on every run: the rmdir found the directory empty, succeeded, and the
    sibling's ``open()`` failed with ``[Errno 2] No such file or directory:
    .../.qs-partial/<pid>-<tok>-<name>`` -- 1 of 29 overlapping cross-source
    feeds on the rig, at ``format_csv``, with the path redacted on the
    record.  One owner, one cleanup: a publication removes ITS scratch
    file and nothing else.  An empty hidden directory left in the output
    dir costs nothing and no consumer globbing the directory sees it;
    stale scratch FILES from a killed pod are aged out by
    ``feed_engine.sweep_orphan_feed_temp_files``.
    """
    try:
        if tmp.exists():
            tmp.unlink()
    except OSError as exc:
        logger.warning(
            "[publication] could not remove partial file %s: %s", tmp, exc)
