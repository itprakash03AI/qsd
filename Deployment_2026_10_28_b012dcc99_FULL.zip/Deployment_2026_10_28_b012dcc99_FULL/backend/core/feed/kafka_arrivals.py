"""BRD §7.1 — the Kafka consumer: land the message, THEN interpret it.

The pipeline this module implements (feed platform step 6):

    our Kafka service
      -> consumer     thin: validate, dedupe by (topic, partition, offset), INSERT
      -> kafka_messages table            replayable, auditable
      -> resolver: message -> dependency arrival, for a business date
      -> the dependency gate re-evaluates (poller in etl_dependency.py)

Design rules, enforced here rather than hoped for:

1.  **The consumer is thin** (FR-DEP-01).  :func:`land_message` validates,
    dedupes and INSERTs — nothing else.  It never parses a payload and it
    never touches the ledger: a message that arrives while QueryStudio is
    restarting is still a row, and a consumer that acts directly loses it.
    Landing and meaning are SEPARATE — the resolver reads back from the
    TABLE, never from the in-flight message.

2.  **Dedupe belongs to the schema** (FR-DEP-03).  The unique constraint on
    (topic, partition, offset) in ``core/db/models.py::KafkaMessage``
    decides; this module only TRANSLATES the IntegrityError (surfaced as
    ``insert_kafka_message() -> None``) into a 'duplicate' outcome.  A
    uniqueness rule enforced only in Python is enforced only until two
    pods run.

3.  **Every refusal is audible at INFO with its reason** (FR-DEP-04).  The
    consumer this replaces was dark by construction: ``kafka_enabled``
    defaulted false, confluent-kafka sat in an ``optional = true`` Poetry
    group, and the refusal was logged at DEBUG.  "No messages arriving"
    and "no consumer running" are indistinguishable from the outside and
    lead to OPPOSITE investigations — :func:`announce_refusal` is the
    difference.

4.  **Resolution is configuration, not code** (FR-DEP-02).
    ``feed_generation.dependency_kafka.resolver_rules`` is a list of rule
    dicts parsed by :func:`rules_from_config` into the existing
    :class:`core.feed.dependency_gate.ResolverRule`; a new upstream system
    is a config change, never a deployment.

5.  **Poison is landed, marked, alerted ONCE, and stepped over**
    (FR-DEP-20).  A payload that is not JSON, matches no rule, or carries
    an unparseable business date is marked 'unresolvable' WITH the error —
    it leaves the resolver's read set forever and the next good message
    still processes.  One bad row never blocks the queue behind it.

6.  **The landing table is the retry buffer.**  When the LEDGER write
    fails (db down mid-pass), the kafka_messages row simply stays
    'landed' and the next pass retries — nothing is lost, nothing loops
    hot, and no in-memory queue is involved.

The transport is a SEAM: anything with ``poll(timeout) -> message | None``
(and optionally ``commit()`` / ``close()``) works, so every test runs with
no Kafka and no confluent-kafka installed.  The real adapter
(:func:`create_transport`) runs with auto-commit OFF and commits offsets
only after a drain with no failed landings: a landing failure re-polls the
same messages on the next pass, and the unique constraint absorbs the
overlap (at-least-once transport + exactly-once table).
"""
from __future__ import annotations

import json
import logging
import threading
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from core.feed.dependency_gate import (
    FilteredMessage,
    ResolverRule,
    UnresolvedMessage,
    classify_unresolvable,
    resolve_message,
)
from core.feed.ledger import record_dependency_arrival

logger = logging.getLogger(__name__)

# Resolution states — mirrors core.db.models.KAFKA_MESSAGE_RESOLUTIONS
# (imported lazily where needed so this module stays importable without
# the DB layer in pure-unit contexts).
LANDED = "landed"
RESOLVED = "resolved"
UNRESOLVABLE = "unresolvable"
#: 2026-10-11 -- a rule for the topic saw the message and its ``match``
#: filter excluded it (a non-COMPLETE state): recorded, no alert, satisfies
#: nothing.  See ``dependency_gate.FilteredMessage``.
FILTERED = "filtered"

# Outcomes of landing ONE message.
LAND_LANDED = "landed"        # new row inserted
LAND_DUPLICATE = "duplicate"  # (topic, partition, offset) already landed
LAND_INVALID = "invalid"      # transport handed something unlandable
LAND_FAILED = "failed"        # db error — the message is NOT persisted

_MAX_TOPIC_LEN = 500
_MAX_KEY_LEN = 500


@dataclass(frozen=True)
class LandResult:
    """What landing one message did."""
    outcome: str                       # landed | duplicate | invalid | failed
    row: dict | None = None         # the landed row, when outcome='landed'
    reason: str = ""


# ── Alert-once memory (FR-DEP-20) ──────────────────────────────────────────
# The DURABLE guarantee is the 'unresolvable' mark on the row (a marked row
# leaves the resolver's read set forever).  This in-process set is the
# secondary guard for the window where the MARK itself keeps failing: the
# row is retried each pass, but the alert still fires only once.
_alerted: dict[str, None] = {}          # insertion-ordered; values unused
_ALERTED_CAP = 10000


def reset_alert_memory() -> None:
    """TEST SEAM (declared 2026-09-03) -- production must NOT call this.
    Test seam + operational reset."""
    _alerted.clear()


def alert_once(key: str, message: str,
               alert_fn: Callable[[str], None] | None = None) -> bool:
    """The alert-once memory, for a sibling arrival producer (the
    Oracle-table watcher) -- ONE memory per process, so a dependency
    unmatched on both roads is alerted once, not twice."""
    return _alert_once(key, message, alert_fn)


def _alert_once(key: str, message: str,
                alert_fn: Callable[[str], None] | None) -> bool:
    """Fire ``alert_fn`` (default: ERROR log) once per key.  Returns
    whether the alert fired."""
    if key in _alerted:
        logger.debug("[kafka_arrivals] alert for %s already raised — "
                     "suppressing duplicate", key)
        return False
    if len(_alerted) >= _ALERTED_CAP:
        # Trim the oldest half rather than clearing: clearing would
        # re-alert every live poison row at once.
        for old in list(_alerted)[:_ALERTED_CAP // 2]:
            del _alerted[old]
        logger.info("[kafka_arrivals] alert-once memory hit %d entries — "
                    "trimmed the oldest half", _ALERTED_CAP)
    _alerted[key] = None
    if alert_fn is not None:
        try:
            alert_fn(message)
        except Exception as exc:  # noqa: BLE001 — an alert sink must never kill the consumer
            logger.error("[kafka_arrivals] alert sink raised (%s) — falling "
                         "back to log: %s", exc, message)
    else:
        logger.error("[kafka_arrivals] ALERT (once): %s", message)
    return True


# ── The consumer: validate, dedupe, INSERT — nothing else (FR-DEP-01) ─────

def validate_message(message: Mapping[str, Any]) -> str | None:
    """Return the refusal reason for an unlandable message, or None.

    'Unlandable' means the dedupe key itself is unusable — without a
    (topic, partition, offset) there is nothing to be idempotent ON.  A
    bad PAYLOAD is deliberately NOT invalid here: it lands and the
    resolver marks it unresolvable with the parse error (FR-DEP-20).
    """
    topic = message.get("topic")
    if not isinstance(topic, str) or not topic.strip():
        return f"message has no usable topic ({topic!r})"
    if len(topic) > _MAX_TOPIC_LEN:
        return (f"topic is {len(topic)} chars (cap {_MAX_TOPIC_LEN}) — "
                f"refusing to truncate a dedupe key component")
    for field in ("partition", "offset"):
        raw = message.get(field)
        if isinstance(raw, bool) or not isinstance(raw, int):
            return f"message {field} is {raw!r}, not an integer"
        if raw < 0:
            return f"message {field} is {raw!r} — negative is impossible"
    return None


def decode_payload(raw: Any) -> str | None:
    """The RAW payload as text for the landing row.  bytes are decoded
    utf-8 with replacement characters — a poison payload must still LAND
    (the parse refusal happens in the resolver, on the stored text)."""
    if raw is None:
        return None
    if isinstance(raw, bytes):
        return raw.decode("utf-8", errors="replace")
    if isinstance(raw, str):
        return raw
    # A fake/adapter handed a parsed object — store its JSON text so the
    # resolver reads the same thing either way.
    try:
        return json.dumps(raw)
    except (TypeError, ValueError):
        return str(raw)


def land_message(db, message: Mapping[str, Any]) -> LandResult:
    """Validate, dedupe, INSERT.  Never parses, never resolves, never
    touches the ledger (FR-DEP-01: the consumer must not act on a
    message — landing and meaning are separate).
    """
    refusal = validate_message(message)
    if refusal is not None:
        logger.error("[kafka_arrivals] message REFUSED (not landed): %s",
                     refusal)
        return LandResult(LAND_INVALID, reason=refusal)

    key = message.get("message_key")
    if key is not None:
        key = str(key)[:_MAX_KEY_LEN]
    data = {
        "topic": str(message["topic"]),
        "partition": int(message["partition"]),
        "offset": int(message["offset"]),
        "message_key": key,
        "payload": decode_payload(message.get("payload")),
        "landed_at": datetime.now(timezone.utc),
        "resolution": LANDED,
        "created_by": "kafka_consumer",
    }
    try:
        row = db.insert_kafka_message(data)
    except Exception as exc:  # noqa: BLE001 — outcome is reported, never swallowed
        reason = (f"landing failed for ({data['topic']}, "
                  f"{data['partition']}, {data['offset']}): {exc}")
        logger.error("[kafka_arrivals] %s — the message is NOT persisted; "
                     "the consumer must not advance past it", reason)
        return LandResult(LAND_FAILED, reason=reason)
    if row is None:
        # The TABLE's unique constraint rejected it: an at-least-once
        # redelivery (rebalance replay).  Classified without alarm
        # (FR-DEP-09) — the dependency is not satisfied twice.
        logger.debug("[kafka_arrivals] redelivery absorbed by the unique "
                     "key: (%s, %s, %s) already landed",
                     data["topic"], data["partition"], data["offset"])
        return LandResult(LAND_DUPLICATE)
    return LandResult(LAND_LANDED, row=row)


# ── The resolver loop: meaning, from the TABLE (FR-DEP-02, FR-DEP-20) ─────

def _mark_filtered(db, row: Mapping[str, Any], reason: str) -> bool:
    """Mark one landed row 'filtered' (2026-10-11).  Returns whether the
    mark stuck.  A db without the marker (an older double) falls back to the
    poison mark so the row still leaves the read set -- said at WARNING."""
    marker = getattr(db, "mark_kafka_message_filtered", None)
    if marker is None:
        logger.warning("[kafka_arrivals] db has no mark_kafka_message_filtered; "
                       "marking message id=%s unresolvable instead", row.get("id"))
        return _mark_unresolvable(db, row, reason, None)
    try:
        return marker(row["id"], reason) is not None
    except Exception as exc:  # noqa: BLE001 — a mark failure is retried next pass
        logger.error("[kafka_arrivals] could not mark message id=%s filtered "
                     "(%s) — it stays landed and is re-read next pass",
                     row.get("id"), exc)
        return False


def _mark_unresolvable(db, row: Mapping[str, Any], reason: str,
                       alert_fn: Callable[[str], None] | None) -> bool:
    """Mark one landed row poison, alerting ONCE.  Returns whether the
    mark stuck (False leaves the row 'landed' for the next pass — the
    alert-once memory keeps that retry silent)."""
    fact = classify_unresolvable(
        {"topic": row.get("topic"), "partition": row.get("partition"),
         "offset": row.get("offset")}, Exception(reason))
    _alert_once(
        fact["alert_once_key"],
        (f"kafka message ({row.get('topic')}, {row.get('partition')}, "
         f"{row.get('offset')}) is UNRESOLVABLE and will not be retried: "
         f"{reason}"),
        alert_fn)
    try:
        marked = db.mark_kafka_message_unresolvable(row["id"], reason)
    except Exception as exc:  # noqa: BLE001 — one poison row must not stop the pass
        logger.error("[kafka_arrivals] could not mark message id=%s "
                     "unresolvable (%s) — it stays 'landed' and the next "
                     "pass retries the mark (alert already raised once)",
                     row.get("id"), exc)
        return False
    if marked is None:
        logger.warning("[kafka_arrivals] message id=%s was already decided "
                       "by another pass — not re-marked", row.get("id"))
    return marked is not None


def resolve_pending(db, rules: Sequence[ResolverRule], *,
                    limit: int = 200,
                    alert_fn: Callable[[str], None] | None = None,
                    ) -> dict:
    """One pass: read landed rows, decide meaning, record arrivals.

    Per row, exactly one of:
      * resolved      — arrival appended to the dependency ledger
                        (classified first/redelivery/replay by
                        core.feed.ledger), row marked 'resolved';
      * unresolvable  — poison (bad JSON / no rule / bad date): marked
                        WITH the reason, alerted once, never retried;
      * retry_later   — the LEDGER write did not stick: the row stays
                        'landed' and the next pass retries (the landing
                        table is the retry buffer — nothing is lost).

    Never raises; a failed listing returns counters with ``list_failed``
    so the daemon loop survives a db blip.
    """
    counters: dict[str, Any] = {
        "scanned": 0, "resolved": 0, "unresolvable": 0, "retry_later": 0,
        "mark_failures": 0, "list_failed": False,
        # 2026-10-10 -- a templated rule rendered a dependency no feed
        # declares: the arrival IS on the ledger (a feed onboarded later
        # for that combination finds it), the message row says 'unmatched'
        # with the rendered name, and this counts it.
        "unmatched": 0,
        # 2026-10-11 -- excluded by a rule's match filter (not COMPLETE).
        "filtered": 0,
        "arrivals": {"first": 0, "redelivery": 0, "replay": 0,
                     "undecidable": 0},
    }
    try:
        rows = db.list_unresolved_kafka_messages(limit)
    except Exception as exc:  # noqa: BLE001 — a read blip must not kill the daemon loop
        logger.error("[kafka_arrivals] could not list unresolved messages "
                     "— resolver pass skipped: %s", exc)
        counters["list_failed"] = True
        return counters

    for row in rows:
        counters["scanned"] += 1

        # Parse the STORED payload — the resolver's input is the table,
        # never the in-flight message (FR-DEP-01).
        raw = row.get("payload")
        payload: Any = None
        if raw:
            try:
                payload = json.loads(raw)
            except (TypeError, ValueError) as exc:
                if not _mark_unresolvable(
                        db, row, f"payload is not JSON: {exc}", alert_fn):
                    counters["retry_later"] += 1
                else:
                    counters["unresolvable"] += 1
                continue
        if payload is not None and not isinstance(payload, dict):
            reason = (f"payload is JSON but not an object "
                      f"({type(payload).__name__}) — no field can carry a "
                      f"business date")
            if not _mark_unresolvable(db, row, reason, alert_fn):
                counters["retry_later"] += 1
            else:
                counters["unresolvable"] += 1
            continue

        message = {"topic": row.get("topic"),
                   "partition": row.get("partition"),
                   "offset": row.get("offset"),
                   "payload": payload or {}}
        try:
            arrival = resolve_message(message, rules)
        except FilteredMessage as exc:
            # 2026-10-11 -- ordinary traffic in a state the rule does not
            # accept (VERSION_STATE IN_PROGRESS on a topic whose rule wants
            # COMPLETE): recorded as 'filtered' WITH the reason, no alert.
            if _mark_filtered(db, row, str(exc)):
                counters["filtered"] += 1
            else:
                counters["retry_later"] += 1
            continue
        except UnresolvedMessage as exc:
            if not _mark_unresolvable(db, row, str(exc), alert_fn):
                counters["retry_later"] += 1
            else:
                counters["unresolvable"] += 1
            continue

        result = record_dependency_arrival(
            db,
            dependency_name=arrival.dependency_name,
            business_date=arrival.business_date,
            source="kafka",
            message_identity=arrival.message_identity,
            payload=payload if isinstance(payload, dict) else None,
            # FR-DEP-24 — the count the RULE named, lifted here because
            # the resolver is the only layer that knows which payload key
            # this upstream uses.  None when it publishes none.
            reported_rows=arrival.reported_rows,
            # 2026-10-08 -- WHICH declared Kafka source this message is
            # for: a dependency may declare two topics (ALL / ANY), and
            # each evaluator must see only its own topic's arrivals.
            source_key=kafka_source_key(row.get("topic")),
        )
        if not result.recorded:
            # The ledger write failed (already logged at ERROR by the
            # ledger).  The row stays 'landed' so the next pass retries:
            # losing the arrival would defeat the whole landing table.
            counters["retry_later"] += 1
            continue
        counters["arrivals"][result.classification] = (
            counters["arrivals"].get(result.classification, 0) + 1)

        # 2026-10-10 -- a DERIVED name (TETB_{SYSTEM_ENTITY}_{EventCode})
        # that no active feed declares is UNMATCHED: the arrival stays on
        # the ledger (a feed onboarded later for that combination is met
        # by it), the row is marked with the rendered name so an operator
        # can see which combination arrived with no feed, and it is never
        # dropped silently.  A FIXED-name rule keeps the pre-existing rule
        # (recorded, 'resolved' -- a dependency may legitimately have no
        # feed yet).  A db without the probe (an older double) cannot ask.
        if arrival.derived and _unmatched(db, arrival.dependency_name):
            reason = (f"no active feed declares dependency "
                      f"{arrival.dependency_name!r} (rendered from the message "
                      f"by its rule); the arrival for "
                      f"{arrival.business_date.isoformat()} is on the ledger and "
                      f"will satisfy a feed declared later")
            try:
                marked = db.mark_kafka_message_unmatched(
                    row["id"], dependency_name=arrival.dependency_name,
                    business_date=arrival.business_date, reason=reason)
            except Exception as exc:  # noqa: BLE001 -- the arrival IS recorded; only the mark failed
                marked = None
                logger.error("[kafka_arrivals] arrival recorded but message "
                             "id=%s could not be marked unmatched (%s)",
                             row.get("id"), exc)
            if marked is None:
                counters["mark_failures"] += 1
            else:
                counters["unmatched"] += 1
                _alert_once(f"unmatched:{arrival.dependency_name}",
                            f"[kafka_arrivals] UNMATCHED arrival: {reason}",
                            alert_fn)
            # 2026-10-11 -- a template that declares auto_onboard turns this
            # new system entity into a feed (core/feed/auto_onboard.py).
            from core.feed.auto_onboard import request_onboarding
            request_onboarding(db, payload if isinstance(payload, dict) else {},
                               dependency_name=arrival.dependency_name,
                               business_date=arrival.business_date, source="kafka",
                               message_identity=str(arrival.message_identity))
            continue

        try:
            marked = db.mark_kafka_message_resolved(
                row["id"], dependency_name=arrival.dependency_name,
                business_date=arrival.business_date)
        except Exception as exc:  # noqa: BLE001 — the arrival IS recorded; only the mark failed
            marked = None
            logger.error(
                "[kafka_arrivals] arrival recorded but message id=%s could "
                "not be marked resolved (%s) — the next pass re-resolves it "
                "and the ledger classifies that as a redelivery (identical "
                "identity), which is honest: recorded twice beats lost once",
                row.get("id"), exc)
        if marked is None:
            counters["mark_failures"] += 1
        else:
            counters["resolved"] += 1
    return counters


def run_pass(db, source, rules: Sequence[ResolverRule], *,
             max_messages: int = 500,
             poll_timeout: float = 1.0,
             resolver_batch_size: int = 200,
             alert_fn: Callable[[str], None] | None = None) -> dict:
    """Drain the transport (bounded), land every message, then resolve.

    A FAILED landing stops the drain and suppresses the offset commit:
    the transport re-delivers from the last commit next pass and the
    unique key absorbs everything already landed.  Skipping past an
    unlanded message would silently drop it — the one thing the landing
    table exists to prevent.
    """
    counters = {"polled": 0, "landed": 0, "duplicates": 0, "invalid": 0,
                "land_failures": 0, "committed": False}
    for _ in range(int(max_messages)):
        try:
            message = source.poll(poll_timeout)
        except Exception as exc:  # noqa: BLE001 — a transport blip is a pass-level event, not a crash
            logger.error("[kafka_arrivals] transport poll raised: %s", exc)
            break
        if message is None:
            break
        counters["polled"] += 1
        landed = land_message(db, message)
        if landed.outcome == LAND_FAILED:
            counters["land_failures"] += 1
            break
        elif landed.outcome == LAND_LANDED:
            counters["landed"] += 1
        elif landed.outcome == LAND_DUPLICATE:
            counters["duplicates"] += 1
        else:
            counters["invalid"] += 1

    if (counters["polled"] > 0 and counters["land_failures"] == 0
            and hasattr(source, "commit")):
        try:
            source.commit()
            counters["committed"] = True
        except Exception as exc:  # noqa: BLE001 — an uncommitted batch redelivers; the table dedupes
            logger.error("[kafka_arrivals] offset commit failed (%s) — the "
                         "batch will redeliver and the unique key absorbs "
                         "it", exc)

    counters["resolve"] = resolve_pending(
        db, rules, limit=resolver_batch_size, alert_fn=alert_fn)
    return counters


def kafka_source_key(topic: Any) -> str | None:
    """The ledger ``source_key`` of a Kafka arrival: ``kafka:<topic>``
    (2026-10-08).  A ``{"kind": "kafka", "topic": T}`` declaration is
    satisfied by arrivals carrying ``kafka:T`` (or none at all -- an
    operator's); a declaration naming no topic is satisfied by any Kafka
    arrival of the dependency.  One spelling, written by the resolver and
    read by the evaluator."""
    text = str(topic or "").strip()
    return f"kafka:{text}" if text else None


def _unmatched(db: Any, dependency_name: str) -> bool:
    """Whether NO active feed declares ``dependency_name``.  A db that
    cannot answer (no probe, or a read failure) is read as "declared":
    an unreadable catalogue must not turn every arrival into a false
    'unmatched' -- the arrival is on the ledger either way."""
    probe = getattr(db, "dependency_key_is_declared", None)
    if probe is None:
        return False
    try:
        return not bool(probe(dependency_name))
    except Exception as exc:  # noqa: BLE001 -- unreadable != undeclared
        logger.warning("[kafka_arrivals] could not ask whether %r is declared "
                       "(%s) -- treating it as declared", dependency_name, exc)
        return False


def rules_routing(rules: Sequence[ResolverRule], dependency_name: str,
                  topic: str | None = None) -> list[ResolverRule]:
    """The resolver rules that can ever satisfy ``dependency_name`` -- on
    ``topic`` when one is named.  Empty means NOTHING consumed from Kafka
    will ever be recorded for it: the gate says "cannot be satisfied"
    rather than waiting 48 h for a message no rule maps.

    2026-10-10 -- a TEMPLATED rule (``TETB_{SYSTEM_ENTITY}_{EventCode}``)
    routes every name it could render (``template_matches``), so one rule
    on one topic serves 4,000 feeds' dependencies."""
    from core.feed.dependency_gate import rule_is_templated, template_matches
    want = str(dependency_name or "")
    out = []
    for r in (rules or []):
        if topic and r.topic != str(topic):
            continue
        if r.dependency_name == want or (
                rule_is_templated(r) and template_matches(r.dependency_name, want)):
            out.append(r)
    return out


# ── Configuration (FR-DEP-02: rules are data) ─────────────────────────────

def rules_from_config(raw: Any) -> list[ResolverRule]:
    """Parse ``resolver_rules`` config into ResolverRule values.

    A malformed entry is REFUSED loudly (ERROR, with which fields are
    missing) and skipped — one bad rule must not take down the good
    ones, and a silent skip would be a dark rule nobody can debug.
    """
    if raw in (None, ""):
        return []
    if not isinstance(raw, (list, tuple)):
        logger.error("[kafka_arrivals] resolver_rules must be a list of "
                     "rule objects, got %s — NO rules are active",
                     type(raw).__name__)
        return []
    rules: list[ResolverRule] = []
    for i, entry in enumerate(raw):
        if not isinstance(entry, Mapping):
            logger.error("[kafka_arrivals] resolver rule #%d REFUSED: not "
                         "an object (%r)", i, entry)
            continue
        missing = [f for f in ("topic", "dependency_name",
                               "business_date_field")
                   if not str(entry.get(f) or "").strip()]
        if missing:
            logger.error("[kafka_arrivals] resolver rule #%d REFUSED: "
                         "missing required field(s) %s (rule: %r)",
                         i, ", ".join(missing), dict(entry))
            continue
        identity = entry.get("identity_fields")
        match = entry.get("match")
        field_values = _field_values_from_config(entry.get("field_values"), i)
        if field_values is None:
            continue
        rules.append(ResolverRule(
            topic=str(entry["topic"]),
            dependency_name=str(entry["dependency_name"]),
            business_date_field=str(entry["business_date_field"]),
            business_date_format=str(entry.get("business_date_format")
                                     or "%Y-%m-%d"),
            identity_fields=(tuple(str(f) for f in identity) if identity
                             else ("topic", "partition", "offset")),
            match=dict(match) if isinstance(match, Mapping) else {},
            # FR-DEP-24 — optional.  Absent means this upstream publishes
            # no row count and the expected-rows check does not apply to
            # it; a rule is NOT refused for lacking one.
            row_count_field=(str(entry["row_count_field"])
                             if str(entry.get("row_count_field") or "").strip()
                             else None),
            field_values=field_values,
        ))
    return rules


def _field_values_from_config(raw: Any, i: int) -> dict | None:
    """``{field: {payload value: spelling}}`` from a rule's ``field_values``
    (2026-10-11), every key and value as text.  None (the rule is REFUSED)
    when the shape is wrong -- a value map with a typo must not quietly
    render dependency names nobody declared."""
    if raw in (None, "", {}):
        return {}
    if not isinstance(raw, Mapping):
        logger.error("[kafka_arrivals] resolver rule #%d REFUSED: field_values "
                     "must be an object of {field: {value: spelling}}, got %s",
                     i, type(raw).__name__)
        return None
    out: dict = {}
    for fld, vmap in raw.items():
        if not isinstance(vmap, Mapping) or not vmap:
            logger.error("[kafka_arrivals] resolver rule #%d REFUSED: "
                         "field_values[%r] must be a non-empty object of "
                         "{value: spelling}", i, fld)
            return None
        out[str(fld)] = {str(k): str(v) for k, v in vmap.items()}
    return out


def dependency_is_unmatched(db: Any, dependency_name: str) -> bool:
    """Whether NO active feed declares ``dependency_name`` -- the question
    every arrival producer with a templated rule asks before recording a
    derived name as 'unmatched' (the Kafka resolver below, the Oracle-table
    watcher in core/feed/oracle_table_source.py).  Unreadable = declared."""
    return _unmatched(db, dependency_name)


def load_config() -> dict:
    """The declared ``feed_generation.dependency_kafka`` block, typed.

    Every key read here is DECLARED in core/config.py — a guard on an
    undeclared key is vacuous.
    """
    try:
        from core.config import get as _cfg_get
        raw = _cfg_get("feed_generation", "dependency_kafka", {}) or {}
    except ImportError:
        raw = {}
    if not isinstance(raw, Mapping):
        logger.error("[kafka_arrivals] feed_generation.dependency_kafka is "
                     "%s, not an object — treating as unconfigured",
                     type(raw).__name__)
        raw = {}
    topics = raw.get("topics") or []
    if not isinstance(topics, (list, tuple)):
        topics = [str(topics)]
    return {
        "enabled": bool(raw.get("enabled", False)),
        "bootstrap_servers": str(raw.get("bootstrap_servers") or ""),
        "topics": [str(t) for t in topics if str(t).strip()],
        "consumer_group": str(raw.get("consumer_group")
                              or "querystudio_feed_dependency_arrivals"),
        "auto_offset_reset": str(raw.get("auto_offset_reset") or "earliest"),
        "poll_timeout_seconds": float(raw.get("poll_timeout_seconds", 1.0)),
        "idle_sleep_seconds": float(raw.get("idle_sleep_seconds", 5.0)),
        "resolver_batch_size": int(raw.get("resolver_batch_size", 200)),
        "resolver_rules": rules_from_config(raw.get("resolver_rules")),
    }


# ── The transport seam ────────────────────────────────────────────────────

def transport_available() -> bool:
    """Whether confluent-kafka is importable.  A core dependency since
    2026-10-08 (``backend/requirements.txt``); an image built from an older
    manifest, or one that skipped it, still answers False here."""
    try:
        import confluent_kafka  # noqa: F401
        return True
    except ImportError:
        return False


# ── Transport fault: a RUNNING consumer whose broker is unreachable ──────
#
# 2026-10-08.  ``consumer_refusal`` says why the consumer will not RUN; it
# cannot say that a consumer that IS running has no broker to talk to.
# With the broker down the thread stays alive, the heartbeat says
# "running", and ``arrival_sources.producer_health`` answered UP -- so a
# dependency on a Kafka message read "not met" (chase the upstream) when
# the truth was "cannot be satisfied" (nothing can consume it).  librdkafka
# reports the condition itself: ``error_cb`` with ``_ALL_BROKERS_DOWN``
# when every broker is unreachable, and the periodic ``stats_cb`` carries
# each broker's ``state`` (UP when connected again).  The state is kept
# here, persisted through the system-settings table so the gate on ANOTHER
# pod reads the same fact, and cleared the moment a broker is UP or a
# message is polled.

#: system_settings key the consumer loop writes (a reason, or "" when the
#: transport is healthy).  The api pod's gate reads it: the consumer runs
#: on the scheduler pod and in-process state does not cross pods.
TRANSPORT_FAULT_SETTING = "feed_kafka_arrivals.transport_fault"
_transport_fault: str | None = None
_transport_fault_lock = threading.Lock()


def note_transport_fault(reason: str | None) -> None:
    """Record (or clear, with None) the transport's fault.  Called from
    librdkafka's callbacks and from a successful poll."""
    global _transport_fault
    with _transport_fault_lock:
        before = _transport_fault
        _transport_fault = (str(reason)[:500] if reason else None)
    if before != _transport_fault:
        if _transport_fault:
            logger.error("[kafka_arrivals] TRANSPORT FAULT: %s -- a dependency "
                         "on a Kafka message cannot be satisfied until the "
                         "broker is reachable", _transport_fault)
        else:
            logger.info("[kafka_arrivals] transport fault cleared -- the broker "
                        "is reachable again")


def _all_brokers_down(err: Any) -> bool:
    """Is ``err`` (a KafkaError, or anything with ``code()``) the
    all-brokers-down condition?  Compared by the library's own constant
    when it is importable, by its documented value (-187) otherwise."""
    try:
        code = err.code()
    except Exception:  # noqa: BLE001 -- not a KafkaError: not the condition
        return False
    try:
        from confluent_kafka import KafkaError
        return code == KafkaError._ALL_BROKERS_DOWN
    except ImportError:
        return code == -187


def brokers_up_in_stats(stats_json: str) -> bool | None:
    """From a librdkafka statistics document: True when at least one
    broker reports state UP, False when brokers are listed and none is,
    None when the document carries no broker states (unparseable, empty).
    Pure, so the clearing rule is provable without the library."""
    try:
        doc = json.loads(stats_json or "")
    except (TypeError, ValueError):
        return None
    brokers = doc.get("brokers") if isinstance(doc, dict) else None
    if not isinstance(brokers, dict) or not brokers:
        return None
    states = [str((b or {}).get("state") or "").upper()
              for b in brokers.values() if isinstance(b, dict)]
    if not states:
        return None
    return any(s == "UP" for s in states)


def _on_stats(stats_json: str) -> None:
    up = brokers_up_in_stats(stats_json)
    if up is True:
        note_transport_fault(None)
    elif up is False and _transport_fault is None:
        note_transport_fault("no broker reports state UP (librdkafka statistics)")


def _on_transport_error(err: Any) -> None:
    if _all_brokers_down(err):
        note_transport_fault(f"all brokers down: {err}")
    else:
        logger.warning("[kafka_arrivals] transport error: %s", err)


def transport_fault(db: Any = None) -> str | None:
    """Why a RUNNING consumer cannot currently receive, or None.

    In the process that runs the consumer the in-memory state answers; on
    any other pod the persisted setting does (``db`` may be None or lack
    the settings table: then only the in-process state is read).
    """
    if _thread is not None and _thread.is_alive():
        return _transport_fault
    if _transport_fault:
        return _transport_fault
    if db is None or not hasattr(db, "get_system_setting"):
        return None
    try:
        persisted = db.get_system_setting(TRANSPORT_FAULT_SETTING, None)
    except Exception as exc:  # noqa: BLE001 -- unreadable is not "faulty"
        logger.debug("[kafka_arrivals] transport fault setting unreadable: %s", exc)
        return None
    text = str(persisted or "").strip()
    return text or None


def _persist_transport_fault(db: Any, reason: str | None) -> None:
    if db is None or not hasattr(db, "set_system_setting"):
        return
    try:
        db.set_system_setting(TRANSPORT_FAULT_SETTING, reason or "",
                              updated_by="feed_kafka_arrivals",
                              description="Why the dependency Kafka consumer "
                                          "cannot currently receive (empty = "
                                          "healthy); written by the consumer "
                                          "loop, read by the gate on every pod")
    except Exception as exc:  # noqa: BLE001 -- bookkeeping must not stop the consumer
        logger.warning("[kafka_arrivals] transport fault could not be "
                       "persisted: %s", exc)


class _ConfluentSource:
    """The real transport, normalised to the seam.

    auto-commit is OFF: :func:`run_pass` calls :meth:`commit` only after
    a drain with no failed landings, so a crash between poll and INSERT
    re-delivers and the unique key absorbs the overlap.
    """

    def __init__(self, cfg: Mapping[str, Any]):
        from confluent_kafka import Consumer
        self._consumer = Consumer({
            "bootstrap.servers": cfg["bootstrap_servers"],
            "group.id": cfg["consumer_group"],
            "auto.offset.reset": cfg["auto_offset_reset"],
            "enable.auto.commit": False,
            # 2026-10-08 -- the broker's reachability, from the library
            # itself (see the transport-fault section above).
            "error_cb": _on_transport_error,
            "stats_cb": _on_stats,
            "statistics.interval.ms": int(cfg.get("statistics_interval_ms", 5000)),
        })
        self._consumer.subscribe(list(cfg["topics"]))

    def poll(self, timeout: float = 1.0) -> dict | None:
        msg = self._consumer.poll(timeout)
        if msg is None:
            return None
        err = msg.error()
        if err is not None:
            # Partition-EOF style events are informational; real errors
            # must be audible.  Either way there is nothing to land.
            logger.error("[kafka_arrivals] transport error event: %s", err)
            if _all_brokers_down(err):
                note_transport_fault(f"all brokers down: {err}")
            return None
        note_transport_fault(None)          # a message came through
        key = msg.key()
        if isinstance(key, bytes):
            key = key.decode("utf-8", errors="replace")
        return {
            "topic": msg.topic(),
            "partition": msg.partition(),
            "offset": msg.offset(),
            "message_key": key,
            "payload": msg.value(),
        }

    def commit(self) -> None:
        self._consumer.commit(asynchronous=False)

    def close(self) -> None:
        try:
            self._consumer.close()
        except Exception as exc:  # noqa: BLE001 — shutdown must not raise
            logger.warning("[kafka_arrivals] transport close raised: %s", exc)


def create_transport(cfg: Mapping[str, Any]) -> _ConfluentSource:
    """Build the real transport.  Raises RuntimeError with the install
    hint when confluent-kafka is absent — callers go through
    :func:`consumer_refusal` first, so reaching this without the
    library is a programming error worth a loud stop."""
    if not transport_available():
        raise RuntimeError(
            "confluent-kafka is not installed (a core dependency in "
            "backend/requirements.txt since 2026-10-08; this image was built "
            "from an older manifest) — install it with: "
            "pip install confluent-kafka")
    return _ConfluentSource(cfg)


# ── Refusals: audible at INFO, with the reason (FR-DEP-04) ────────────────

def consumer_refusal(cfg: Mapping[str, Any] | None = None, *,
                     transport_ok: bool | None = None) -> str | None:
    """Why the consumer will NOT run, or None when it can.

    Pure over its inputs so every refusal branch is testable without
    Kafka, config files or an importable confluent-kafka.
    """
    cfg = cfg if cfg is not None else load_config()
    if not cfg.get("enabled"):
        return ("feed_generation.dependency_kafka.enabled is false — no "
                "dependency messages will be consumed on this pod")
    if transport_ok is None:
        transport_ok = transport_available()
    if not transport_ok:
        return ("confluent-kafka is not installed (a core dependency in "
                "backend/requirements.txt since 2026-10-08; this image was "
                "built from an older manifest) — install it with: "
                "pip install confluent-kafka")
    if not cfg.get("bootstrap_servers"):
        return ("feed_generation.dependency_kafka.bootstrap_servers is "
                "empty — there is no broker to connect to")
    if not cfg.get("topics"):
        return ("feed_generation.dependency_kafka.topics is empty — there "
                "is nothing to subscribe to")
    return None


def announce_refusal(cfg: Mapping[str, Any] | None = None, *,
                     transport_ok: bool | None = None) -> str | None:
    """State the refusal AT INFO with the reason, and return it.

    This line is the defect being fixed, not a nicety: the predecessor
    refused at DEBUG, so "no messages arriving" (upstream problem) and
    "no consumer running" (our problem) were indistinguishable and led
    to opposite investigations (FR-DEP-04).
    """
    reason = consumer_refusal(cfg, transport_ok=transport_ok)
    if reason is not None:
        logger.info(
            "[kafka_arrivals] dependency consumer NOT running: %s. "
            "('no messages arriving' vs 'no consumer running' are opposite "
            "investigations — this line is the difference, FR-DEP-04)",
            reason)
    return reason


# ── Daemon wrapper (thread; the scheduler/daemon wiring is the caller's) ──

_thread: threading.Thread | None = None
_stop_event = threading.Event()
_last_pass: dict = {}


def _consumer_loop(db, source, cfg: Mapping[str, Any]) -> None:
    global _last_pass
    idle = float(cfg.get("idle_sleep_seconds", 5.0))
    # The persisted fault mirrors the in-process one; a fresh consumer
    # starts healthy until the library says otherwise.
    note_transport_fault(None)
    _persist_transport_fault(db, None)
    persisted: str | None = None
    while not _stop_event.is_set():
        try:
            counters = run_pass(
                db, source, cfg["resolver_rules"],
                poll_timeout=cfg.get("poll_timeout_seconds", 1.0),
                resolver_batch_size=cfg.get("resolver_batch_size", 200))
            _last_pass = counters
            if _transport_fault != persisted:
                _persist_transport_fault(db, _transport_fault)
                persisted = _transport_fault
            if counters["polled"] == 0:
                _stop_event.wait(idle)
        except Exception as exc:  # noqa: BLE001 — a pass failure must not kill the daemon
            logger.error("[kafka_arrivals] consumer pass raised — backing "
                         "off 5s: %s", exc)
            _stop_event.wait(5.0)
    if hasattr(source, "close"):
        try:
            source.close()
        except Exception as exc:  # noqa: BLE001 — shutdown must not raise
            logger.warning("[kafka_arrivals] source close raised: %s", exc)


def start_consumer(db, *, source_factory: Callable | None = None) -> bool:
    """Start the background consumer, or SAY at INFO why not.

    ``source_factory(cfg) -> source`` injects the transport (tests, or a
    future second transport); default is the confluent adapter.  Returns
    whether the consumer is running.
    """
    global _thread
    cfg = load_config()
    reason = announce_refusal(
        cfg, transport_ok=(True if source_factory is not None else None))
    if reason is not None:
        return False
    if _thread is not None and _thread.is_alive():
        logger.info("[kafka_arrivals] consumer already running")
        return True
    try:
        source = (source_factory(cfg) if source_factory is not None
                  else create_transport(cfg))
    except Exception as exc:  # noqa: BLE001 — a broken transport is a stated refusal, not a crash
        logger.error("[kafka_arrivals] dependency consumer NOT running: "
                     "transport construction failed: %s", exc)
        return False
    _stop_event.clear()
    _thread = threading.Thread(
        target=_consumer_loop, args=(db, source, cfg),
        name="feed-dependency-kafka-consumer", daemon=True)
    _thread.start()
    logger.info("[kafka_arrivals] dependency consumer STARTED: topics=%s "
                "group=%s resolver_rules=%d",
                cfg["topics"], cfg["consumer_group"],
                len(cfg["resolver_rules"]))
    return True


def stop_consumer(timeout: float = 10.0) -> None:
    global _thread
    _stop_event.set()
    if _thread is not None and _thread.is_alive():
        _thread.join(timeout=timeout)
        logger.info("[kafka_arrivals] dependency consumer stopped")
    # Clear the handle, not just the flag (2026-09-02).  ``get_status``
    # answers "running" from this global, so a stopped consumer whose
    # handle survives keeps reporting itself as running to the daemon
    # surface — and, in tests, leaks that answer into whatever else the
    # xdist worker runs next.  The same reset gap existed in sla_watcher
    # and netcool_sender.
    _thread = None


def reset_state_for_tests() -> None:
    """TEST SEAM (declared 2026-09-03) -- production must NOT call this.
    Return the module to its pre-start state — thread included."""
    stop_consumer(timeout=5.0)
    _stop_event.clear()
    note_transport_fault(None)


def get_status() -> dict:
    """For the admin surface: running or not, and if not, exactly why."""
    cfg = load_config()
    running = bool(_thread is not None and _thread.is_alive())
    return {
        "running": running,
        "refusal": None if running else consumer_refusal(cfg),
        # 2026-10-08 -- running is not receiving: the broker's reachability
        # as librdkafka last reported it (None = healthy / not running).
        "transport_fault": _transport_fault if running else None,
        "enabled": cfg["enabled"],
        "transport_available": transport_available(),
        "topics": cfg["topics"],
        "consumer_group": cfg["consumer_group"],
        "resolver_rules": len(cfg["resolver_rules"]),
        "last_pass": dict(_last_pass),
    }
