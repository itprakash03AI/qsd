"""Phase 131-C — File completeness verification.

Three-layer check, all run AFTER the format-conversion / delivery stages
of a feed.  Each layer is independent so feeds with only one delivery
target still get the cheap local-write check.

Layer 1 (`verify_local_file`): file exists, size > 0, parquet footer
  row-count matches claim, CSV line count matches claim ± 1.
Layer 2 (`verify_post_delivery`): for S3 destinations, HEAD the object
  and compare Content-Length to local file size.  For SFTP, stat the
  remote file.
Layer 3 (CTL checksum re-verify): handled by the existing
  `core.feed.control_file` module — this module just exposes the
  helpers so feed_engine can call them in the right order.

Raises `FileIntegrityError` on any mismatch.  The caller decides
whether to fail the feed (`integrity_check_action='fail'`) or just log
a warning (`integrity_check_action='warn'`).

All thresholds + the action are DB-tunable via system_settings — no
hardcoded values.  See `core.feed.file_integrity.load_config()`.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


class FileIntegrityError(Exception):
    """Raised when a generated feed file fails its completeness check.

    Carries the failed stage name so feed_engine can surface it on
    feed_executions.failed_stage without parsing the message."""

    def __init__(self, message: str, *, stage: str = "file_integrity_check"):
        super().__init__(message)
        self.stage = stage


# ── Layer 1: local-write verification ───────────────────────────────


def verify_local_file(
    output_path: str,
    *,
    expected_rows: Optional[int] = None,
    output_format: str = "csv",
    output_options: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Verify the file at ``output_path`` matches what the engine claims.

    Returns a dict with the observed file metadata.  Raises
    ``FileIntegrityError`` when the check fails.
    """
    options = output_options or {}
    fmt = (output_format or "csv").lower()

    if not os.path.exists(output_path):
        raise FileIntegrityError(f"Output file missing: {output_path}")

    file_size = os.path.getsize(output_path)
    if file_size == 0:
        raise FileIntegrityError(f"Output file is empty (0 bytes): {output_path}")

    observed: Dict[str, Any] = {
        "path": output_path,
        "size_bytes": file_size,
        "format": fmt,
    }

    if fmt == "parquet" and expected_rows is not None:
        try:
            import pyarrow.parquet as pq  # type: ignore
        except ImportError:
            logger.warning(
                "[file_integrity] pyarrow not available; skipping parquet "
                "footer check on %s", output_path,
            )
            return observed
        try:
            pf = pq.ParquetFile(output_path)
            written = pf.metadata.num_rows
        except Exception as e:
            raise FileIntegrityError(
                f"Parquet footer unreadable for {output_path}: {e}"
            ) from e
        observed["written_rows"] = written
        if written != expected_rows:
            raise FileIntegrityError(
                f"Parquet row count mismatch: footer says {written}, "
                f"expected {expected_rows} ({output_path})"
            )

    elif fmt == "csv" and expected_rows is not None:
        try:
            with open(output_path, "rb") as f:
                # binary mode + universal newline counting is cheap and
                # avoids decoding overhead on large CSVs.
                line_count = sum(1 for _ in f)
        except OSError as e:
            raise FileIntegrityError(
                f"CSV unreadable for {output_path}: {e}"
            ) from e
        header_offset = 1 if options.get("header", True) else 0
        expected_lines = expected_rows + header_offset
        observed["written_lines"] = line_count
        # Allow ±1 for trailing newline drift.
        if abs(line_count - expected_lines) > 1:
            raise FileIntegrityError(
                f"CSV line-count mismatch: file has {line_count} lines, "
                f"expected {expected_lines} ({output_path})"
            )

    elif fmt == "json" and expected_rows is not None:
        # JSON lines mode = one row per line; JSON array mode = single
        # blob.  We only verify when the file LOOKS like JSON-lines
        # (cheap line count); otherwise we rely on size > 0 above.
        if options.get("lines", False):
            try:
                with open(output_path, "rb") as f:
                    line_count = sum(1 for _ in f)
            except OSError as e:
                raise FileIntegrityError(
                    f"JSON unreadable for {output_path}: {e}"
                ) from e
            observed["written_lines"] = line_count
            if abs(line_count - expected_rows) > 1:
                raise FileIntegrityError(
                    f"JSON-lines line-count mismatch: file has "
                    f"{line_count} lines, expected {expected_rows}"
                )

    return observed


def physical_row_count(
    output_path: str,
    output_format: str = "csv",
    output_options: Optional[Dict[str, Any]] = None,
) -> Optional[int]:
    """Independently recount the rows physically present in the file.

    2026-07-22 — the observational primitive that BACKS the feed Completeness
    Certificate's reconciliation.  Unlike :func:`verify_local_file` (which
    RAISES on mismatch and is gated by the enforcement toggle), this never
    raises and is called UNCONDITIONALLY on the feed success path — the
    certificate must always be backed by an independent recount, by design,
    regardless of whether a mismatch is configured to fail/warn/ignore.

    Returns the physical data-row count (parquet footer, or line count minus the
    CSV/JSON-lines header), or ``None`` when it can't be determined cheaply
    (unreadable file, parquet without pyarrow, JSON-array blob).

    2026-08-04 — the per-format recount logic moved into the format
    renderers (``core.feed.renderers``): the class that RENDERS a format
    also owns how to independently recount it, so a new output format
    gets certificate-backing evidence from the same one adapter it
    registers — the renderer and its audit cannot drift apart.  An
    unregistered format returns ``None`` (honest absence — the
    certificate withholds rather than fabricates).
    """
    try:
        options = output_options or {}
        fmt = (output_format or "csv").lower()
        if not os.path.exists(output_path) or os.path.getsize(output_path) == 0:
            return None
        from core.feed.renderers import get_renderer, UnsupportedOutputFormat
        try:
            renderer = get_renderer(fmt)
        except UnsupportedOutputFormat:
            return None
        return renderer.physical_row_count(output_path, options)
    except Exception as exc:
        logger.debug("[file_integrity] physical_row_count failed for %s: %s",
                     output_path, exc)
        return None


# ── Delivered-output recount (webhook / Flow B verification) ─────────
#
# 2026-08-05 — the Spark-batch fallback (spark/jobs/generic_feed.py)
# delivers a DIRECTORY of part files (part-*.csv with a per-part header,
# part-*.snappy.parquet, part-*.json as JSON-lines) plus _SUCCESS
# markers — not the single file the Flow-A pipeline writes.  The webhook
# handler recounts that delivered output server-side so the feed
# completeness certificate reconciles Spark's reported count against an
# INDEPENDENT count, by the same certificate code Flow A uses.

#: Suffixes that make a text part uncountable without decompression.
#: (Parquet's internal compression is invisible to the footer count and
#: is NOT in this list.)
_UNCOUNTABLE_SUFFIXES = (
    ".gz", ".bz2", ".zst", ".zstd", ".lz4", ".snappy", ".deflate",
    ".br", ".zip", ".xz", ".7z",
)


def _recount_one_delivered_file(path: str) -> Optional[int]:
    """Recount ONE delivered data file by its extension, or ``None``.

    Extension-driven (not feed-config-driven) because the bytes on disk
    are the ground truth being audited: the Spark writer hardcodes a
    per-part CSV header and always writes JSON as JSON-lines, regardless
    of the feed's output_options.
    """
    lower = path.lower()
    if lower.endswith(".parquet"):
        from core.feed.renderers import get_renderer
        return get_renderer("parquet").physical_row_count(path)
    if lower.endswith(_UNCOUNTABLE_SUFFIXES):
        return None  # honest absence — never guess a compressed count
    if lower.endswith(".csv"):
        from core.feed.renderers import get_renderer
        # generic_feed.py hardcodes .option("header", "true") per part.
        return get_renderer("csv").physical_row_count(path, {"header": True})
    if lower.endswith(".json"):
        from core.feed.renderers import get_renderer
        # Spark's json writer emits JSON-lines (one object per line).
        return get_renderer("json").physical_row_count(path, {"lines": True})
    return None


def physical_row_count_delivered(output_path: str) -> Optional[int]:
    """Independently recount a DELIVERED output: a single file or a
    Spark-style part-file directory.

    Returns the total data-row count, or ``None`` when the output cannot
    be recounted honestly.  ALL data parts must be countable — a partial
    sum would under-count and fabricate an INCOMPLETE verdict, so one
    uncountable part withholds the whole recount (the certificate then
    reads UNVERIFIED, never a fabricated verdict either way).

    Never raises; returns ``None`` on any error (logged).
    """
    try:
        if os.path.isfile(output_path):
            return _recount_one_delivered_file(output_path)
        if not os.path.isdir(output_path):
            return None
        total = 0
        data_files = 0
        for root, dirs, files in os.walk(output_path):
            # Skip Spark bookkeeping dirs/files (_temporary, _SUCCESS,
            # .part-*.crc, ...): underscore/dot prefixes are the Hadoop
            # convention for non-data artifacts.
            dirs[:] = [d for d in dirs if not d.startswith(("_", "."))]
            for name in files:
                if name.startswith(("_", ".")) or name.endswith(".crc"):
                    continue
                n = _recount_one_delivered_file(os.path.join(root, name))
                if n is None:
                    logger.info(
                        "[file_integrity] delivered recount withheld: part "
                        "%r in %s is not independently countable",
                        name, output_path,
                    )
                    return None
                total += n
                data_files += 1
        return total if data_files else None
    except Exception as exc:
        logger.warning(
            "[file_integrity] physical_row_count_delivered failed for %s: %s",
            output_path, exc,
        )
        return None


# ── Layer 2: post-delivery verification ──────────────────────────────


def verify_post_delivery(
    *,
    local_path: str,
    local_size: int,
    dest_type: str,
    dest_config: Dict[str, Any],
    delivered_uri: str,
    s3_client_factory: Optional[Any] = None,
    sftp_client_factory: Optional[Any] = None,
) -> Dict[str, Any]:
    """Verify the file landed at the destination with the same size we
    wrote locally.  Best-effort — when the destination doesn't support
    cheap stat (e.g. some HTTP webhook), returns without raising.

    s3_client_factory / sftp_client_factory are injectable for tests.
    """
    dest_type = (dest_type or "local").lower()
    observed: Dict[str, Any] = {
        "dest_type": dest_type,
        "delivered_uri": delivered_uri,
        "local_size": local_size,
    }

    if dest_type == "local":
        # Delivered URI is the local copy itself; nothing new to verify.
        return observed

    if dest_type == "s3":
        if s3_client_factory is None:
            # Lazy import to avoid hard boto3 dep at module load.
            try:
                import boto3  # type: ignore
            except ImportError:
                logger.warning(
                    "[file_integrity] boto3 unavailable; skipping S3 "
                    "post-delivery verify for %s", delivered_uri,
                )
                return observed
            s3 = boto3.client("s3")  # uses configured creds
        else:
            s3 = s3_client_factory()
        bucket = dest_config.get("bucket")
        key = dest_config.get("key") or os.path.basename(local_path)
        if not bucket:
            # Try to parse from delivered_uri (s3://bucket/key)
            if delivered_uri.startswith("s3://"):
                _, _, rest = delivered_uri.partition("s3://")
                b, _, k = rest.partition("/")
                bucket = bucket or b
                key = k or key
        if not bucket:
            logger.warning(
                "[file_integrity] no S3 bucket resolvable; "
                "skipping post-delivery verify",
            )
            return observed
        try:
            head = s3.head_object(Bucket=bucket, Key=key)
        except Exception as e:
            raise FileIntegrityError(
                f"S3 HEAD failed for s3://{bucket}/{key}: {e}",
                stage="post_delivery_integrity_check",
            ) from e
        remote_size = head.get("ContentLength")
        observed["remote_size"] = remote_size
        if remote_size is not None and remote_size != local_size:
            raise FileIntegrityError(
                f"S3 size mismatch: uploaded {remote_size} bytes vs "
                f"local {local_size} bytes (s3://{bucket}/{key})",
                stage="post_delivery_integrity_check",
            )
        # ETag may be quoted; trim and compare when caller provided
        # local_md5 in dest_config.
        local_md5 = dest_config.get("_local_md5")
        if local_md5:
            etag = (head.get("ETag") or "").strip('"')
            observed["etag"] = etag
            # Multipart uploads have ETag like "<hash>-<parts>" which
            # is NOT an MD5.  Only compare when single-part.
            if "-" not in etag and etag != local_md5:
                raise FileIntegrityError(
                    f"S3 ETag mismatch on s3://{bucket}/{key}: "
                    f"remote={etag}, local_md5={local_md5}",
                    stage="post_delivery_integrity_check",
                )

    elif dest_type == "sftp":
        if sftp_client_factory is None:
            # SFTP verify is opt-in — without a factory we don't open
            # a new connection just for stat.  Caller may pass one.
            return observed
        sftp = sftp_client_factory()
        remote_path = dest_config.get("remote_path") or os.path.basename(local_path)
        try:
            stat = sftp.stat(remote_path)
        except Exception as e:
            raise FileIntegrityError(
                f"SFTP stat failed for {remote_path}: {e}",
                stage="post_delivery_integrity_check",
            ) from e
        remote_size = getattr(stat, "st_size", None)
        observed["remote_size"] = remote_size
        if remote_size is not None and remote_size != local_size:
            raise FileIntegrityError(
                f"SFTP size mismatch: remote {remote_size} vs "
                f"local {local_size}",
                stage="post_delivery_integrity_check",
            )

    return observed


# ── Config helper ────────────────────────────────────────────────────


def load_config() -> Dict[str, Any]:
    """Resolve effective integrity-check settings from system_settings
    (DB-driven) with sensible defaults.  No hardcoded thresholds — every
    knob is admin-tunable from the Failover Tunables panel."""
    try:
        from core.config import _db_setting_or
    except ImportError:
        _db_setting_or = None  # type: ignore

    def _resolve(key: str, default: Any) -> Any:
        if _db_setting_or is None:
            return default
        return _db_setting_or(key, default)

    return {
        "enabled":            bool(_resolve("feed_generation.integrity_check_enabled", True)),
        "action":             str(_resolve("feed_generation.integrity_check_action", "warn")),
        "post_delivery":      bool(_resolve("feed_generation.integrity_check_post_delivery", True)),
        "csv_line_tolerance": int(_resolve("feed_generation.integrity_csv_line_tolerance", 1)),
    }


def is_enabled_for_feed(feed_config: Dict[str, Any]) -> bool:
    """Per-feed override wins over system default.  ``None`` = inherit."""
    per_feed = feed_config.get("integrity_check_enabled")
    if per_feed is not None:
        return bool(per_feed)
    return load_config()["enabled"]
