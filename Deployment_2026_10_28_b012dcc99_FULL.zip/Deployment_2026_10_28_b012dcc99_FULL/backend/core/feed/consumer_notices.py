"""Self-subscription NOTICES for feed consumers (2026-09-28).

docs/FEATURE_STRATEGY_2026_09_28.html #3, the "Notify me" half.  A consumer
subscribes to one or more of ``FEED_CONSUMER_EVENTS`` on a feed they may
read receipts for:

* ``delivered`` -- the run's delivery chain verdict is DELIVERED
  (``consumer_receipts.OUTCOME_DELIVERED``, and nothing else);
* ``failed``    -- the run failed or was cancelled, so no file is coming
  from it;
* ``late``      -- the feed's SLA for the business date has passed
  (``consumer_receipts.sla_for``, the SAME resolver the acting-time clocks
  use) and nothing has been delivered for that date.

Three channels, all existing: the bell (``NotificationLog`` rows the
notification bell polls, channel ``websocket``), e-mail through THE mailer
(``core/email_service.py::send_email``; the subscription carries the
address -- a local user has none the platform could use), and the live
WebSocket push addressed to the subscriber (``core/scheduler.
feed_dep_broadcast`` -> the relay in ``core/notification_poller.py``).

ONCE PER EVENT, NOT PER PASS.  Every notice is INSERTED FIRST into the
``feed_consumer_notices`` ledger under a UNIQUE (feed, business date,
event, subscriber, run key), and only a row that landed is followed by a
send (``FeedConsumersMixin.record_feed_consumer_notice``).  A second call
for the same run, a second watcher tick, a second pod: the insert loses,
nothing is sent.  Both channels' verdicts are written back onto the row,
so "who was told, and did the mail go" is a ledger read.

Where the events come from:

* ``on_execution_finalised(db, exec_db_id)`` is called by the engine's ONE
  terminal write (``feed_engine._finalize_execution_row``) after the write
  landed -- every lane (native, fan-out, spark, cancelled, failed) ends
  there, and a write the clobber guard refused means another actor
  already finalised and already notified.  It never raises into the
  engine: a notice that cannot be sent is an ERROR line, not a failed run.
* ``late_tick(db)`` is the daemon (``JOB_ID``; the three legs:
  ``retention_daemons.JOB_IDS``, ``daemon_registry.SCHEDULER_OWNED``, the
  literal ``_daemon_allowed("feed_consumer_late_watch")`` in main.py).
  Every ``consumer_late_check_interval_seconds`` it looks at the runs of
  the last ``consumer_late_lookback_days`` for every feed with a ``late``
  subscriber and raises ONE late notice per (feed, business date) whose
  SLA has passed with no delivered run.  A feed with no run row for a
  date is not late (SOD creates a row per active feed per business day;
  a day with no row is a non-business day, a window exclusion, or SOD not
  running -- none of which is this feed's file being late).  Since
  2026-10-11 the tick's output carries ``sod_gaps``: the SOD generator's
  open gap records (a DUE date with no run beyond its catch-up window) for
  the watched feeds, so "no row" is visible even though it raises no notice.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timedelta, timezone
from typing import Any, Callable, Optional

from core.db.models import FEED_CONSUMER_EVENTS
from core.feed import consumer_receipts as _cr

logger = logging.getLogger(__name__)

#: THE job id -- retention_daemons.JOB_IDS, daemon_registry.SCHEDULER_OWNED
#: and main.py's literal gate all spell exactly this.
JOB_ID = "feed_consumer_late_watch"

EVENTS = tuple(FEED_CONSUMER_EVENTS)
EVENT_DELIVERED, EVENT_LATE, EVENT_FAILED = EVENTS

#: The WebSocket / bell event type per consumer event.  ONE spelling: the
#: NotificationLog row's ``event_type``, the socket message's ``type`` and
#: the frontend's NotificationContext branch.
EVENT_TYPE_PREFIX = "feed_consumer_"

#: The link a notice carries (the bell row's ``href`` and the mail's).
RECEIPT_HREF = "/feeds/mine?receipt={run_id}"


def load_config() -> dict:
    """The declared keys, read through the config object."""
    from core.config import get as _get
    enabled = bool(_get("feed_generation", "consumer_notices_enabled", True))
    interval = int(_get("feed_generation",
                        "consumer_late_check_interval_seconds", 300) or 300)
    lookback = int(_get("feed_generation", "consumer_late_lookback_days", 3) or 3)
    return {"enabled": enabled,
            "check_interval_seconds": max(interval, 60),
            "lookback_days": max(1, lookback)}


def event_for_receipt(receipt: dict) -> Optional[str]:
    """Which subscription event a finalised run's receipt raises, or None
    (suppressed, dry run, skipped and waiting runs raise nothing here;
    the late watcher covers "no file by the SLA")."""
    outcome = receipt.get("outcome")
    if outcome == _cr.OUTCOME_DELIVERED:
        return EVENT_DELIVERED
    if outcome == _cr.OUTCOME_FAILED:
        return EVENT_FAILED
    return None


# ── composing the notice ─────────────────────────────────────────────────

def _feed_label(feed: dict) -> str:
    return str(feed.get("display_name") or feed.get("name") or f"feed {feed.get('id')}")


def notice_text(event: str, feed: dict, receipt: dict) -> tuple:
    """``(title, message)`` -- plain words, the facts a consumer acts on."""
    label = _feed_label(feed)
    bd = receipt.get("business_date")
    f = receipt.get("file") or {}
    s = receipt.get("sla") or {}
    if event == EVENT_DELIVERED:
        title = f"{label} delivered for {bd}"
        bits = [f"File {f.get('name') or '(name not recorded)'}"]
        if f.get("rows") is not None:
            bits.append(f"{int(f['rows']):,} rows")
        if f.get("size_bytes") is not None:
            bits.append(_cr._fmt_bytes(f.get("size_bytes")))
        if f.get("checksum"):
            bits.append(f"{f.get('checksum_algorithm') or 'checksum'} {f['checksum']}")
        cert = (receipt.get("completeness") or {}).get("state")
        bits.append(f"completeness {cert}" if cert else "not certified")
        if s.get("late") is True:
            bits.append(f"LATE by {s.get('minutes_late')} min against the SLA")
        elif s.get("late") is False:
            bits.append("on time")
        return title, "; ".join(bits) + "."
    if event == EVENT_FAILED:
        title = f"{label} NOT delivered for {bd} -- the run failed"
        why = receipt.get("outcome_reason") or "the run failed"
        err = (receipt.get("run") or {}).get("error")
        return title, f"{why}." + (f" {err}" if err else "") + \
            " The producer has been told; no file is coming from this run."
    if event == EVENT_LATE:
        title = f"{label} is LATE for {bd}"
        why = _cr.outcome_label(receipt)
        return title, (f"The SLA ({s.get('sla_at')}) has passed and nothing was "
                       f"delivered for {bd}. Current state: {why}"
                       + (f" -- {receipt.get('outcome_reason')}" if receipt.get("outcome_reason") else "")
                       + ".")
    return f"{label}: {event} for {bd}", ""


def _send_bell(db, *, username: str, event: str, title: str, message: str,
               feed: dict, receipt: dict) -> dict:
    run_id = (receipt.get("run") or {}).get("id")
    try:
        db.log_notification(
            event_type=f"{EVENT_TYPE_PREFIX}{event}", channel="websocket",
            recipient=username, status="sent", title=title, message=message,
            payload={"feed_config_id": feed.get("id"), "feed_name": feed.get("name"),
                     "business_date": receipt.get("business_date"),
                     "feed_run_id": run_id, "receipt_id": receipt.get("receipt_id"),
                     "outcome": receipt.get("outcome"),
                     "href": RECEIPT_HREF.format(run_id=run_id)})
        return {"state": "sent"}
    except Exception as exc:  # noqa: BLE001
        logger.error("[consumer_notices] bell row for %s (%s, feed %s) failed: %s",
                     username, event, feed.get("id"), exc)
        return {"state": "failed", "reason": str(exc)[:300]}


def _send_email(*, email: Optional[str], title: str, message: str, receipt: dict,
                mailer: Optional[Callable[..., bool]]) -> dict:
    if not email:
        return {"state": "none", "reason": "the subscription carries no e-mail address"}
    from core import email_service
    send = mailer or email_service.send_email
    if mailer is None and not email_service.is_email_enabled():
        return {"state": "unconfigured", "recipients": [email],
                "reason": email_service.NOT_CONFIGURED_REASON}
    html = (f"<p>{_esc(message)}</p>"
            + _cr.render_receipt_html(receipt).split("<body>", 1)[-1].rsplit("</body>", 1)[0])
    try:
        email_service.clear_send_failure_reason()
    except Exception:  # noqa: BLE001 - a test double may lack it
        pass
    try:
        ok = bool(send([email], f"[QueryStudio] {title}", html, message))
    except Exception as exc:  # noqa: BLE001
        return {"state": "failed", "recipients": [email], "reason": f"{type(exc).__name__}: {exc}"[:300]}
    if ok:
        return {"state": "sent", "recipients": [email]}
    reason = ""
    try:
        reason = email_service.last_send_failure_reason()
    except Exception:  # noqa: BLE001
        pass
    return {"state": "failed", "recipients": [email],
            "reason": (reason or "the mailer returned False")[:300]}


def _esc(s: str) -> str:
    import html as _h
    return _h.escape(str(s or ""))


def _send_socket(*, username: str, event: str, title: str, message: str,
                 feed: dict, receipt: dict,
                 broadcast: Optional[Callable[[str, dict], None]]) -> dict:
    run_id = (receipt.get("run") or {}).get("id")
    # A PERSONAL notice: addressed to the subscriber whose subscription
    # produced it -- deliberately not the feed's audience (consumer groups
    # are a declaration, not a view grant; core/feed/event_audience.py).
    # The explicit ``audience`` stops feed_dep_broadcast re-addressing it.
    payload = {"audience": [username], "username": username,
               "feed_config_id": feed.get("id"),
               "feed_name": feed.get("name"), "business_date": receipt.get("business_date"),
               "feed_run_id": run_id, "receipt_id": receipt.get("receipt_id"),
               "outcome": receipt.get("outcome"), "title": title, "message": message,
               "href": RECEIPT_HREF.format(run_id=run_id)}
    try:
        if broadcast is not None:
            broadcast(f"{EVENT_TYPE_PREFIX}{event}", payload)
        else:
            from core.scheduler import feed_dep_broadcast
            feed_dep_broadcast(f"{EVENT_TYPE_PREFIX}{event}", payload)
        return {"state": "sent"}
    except Exception as exc:  # noqa: BLE001
        logger.warning("[consumer_notices] socket push for %s failed: %s", username, exc)
        return {"state": "failed", "reason": str(exc)[:300]}


def notify(db, feed: dict, receipt: dict, event: str, *, run_key: Optional[str] = None,
           mailer: Optional[Callable[..., bool]] = None,
           broadcast: Optional[Callable[[str, dict], None]] = None) -> dict:
    """Tell every subscriber of ``event`` on ``feed`` about ``receipt``,
    each ONCE.  Returns ``{event, notified: [{username, channels}],
    already: [usernames], skipped: [...]}``."""
    if event not in EVENTS:
        raise ValueError(f"unknown consumer event {event!r}; one of {EVENTS}")
    out: dict = {"event": event, "feed_config_id": feed.get("id"),
                 "business_date": receipt.get("business_date"),
                 "notified": [], "already": [], "failed": []}
    subs = db.list_feed_consumer_subscriptions(feed_config_id=int(feed["id"]), event=event)
    if not subs:
        return out
    run_id = (receipt.get("run") or {}).get("id")
    key = str(run_key or (run_id if run_id is not None else "date"))
    title, message = notice_text(event, feed, receipt)
    for sub in subs:
        username = str(sub.get("username") or "")
        if not username:
            continue
        try:
            row = db.record_feed_consumer_notice(
                feed_config_id=int(feed["id"]), business_date=receipt.get("business_date"),
                event=event, username=username, run_key=key, feed_run_id=run_id,
                channels={"state": "sending"})
        except Exception as exc:  # noqa: BLE001
            logger.error("[consumer_notices] ledger row for %s (%s, feed %s, %s) could "
                         "not be written (%s) -- NOT sent, will be retried by the next "
                         "event", username, event, feed.get("id"),
                         receipt.get("business_date"), exc)
            out["failed"].append({"username": username, "reason": str(exc)[:300]})
            continue
        if row is None:
            out["already"].append(username)
            continue
        channels = {
            "bell": _send_bell(db, username=username, event=event, title=title,
                               message=message, feed=feed, receipt=receipt),
            "email": _send_email(email=sub.get("email"), title=title, message=message,
                                 receipt=receipt, mailer=mailer),
            "socket": _send_socket(username=username, event=event, title=title,
                                   message=message, feed=feed, receipt=receipt,
                                   broadcast=broadcast),
        }
        try:
            db.update_feed_consumer_notice_channels(int(row["id"]), channels)
        except Exception as exc:  # noqa: BLE001
            logger.warning("[consumer_notices] channel verdicts for notice %s could "
                           "not be recorded: %s", row.get("id"), exc)
        reached = any(c.get("state") == "sent" for c in channels.values())
        (logger.info if reached else logger.error)(
            "[consumer_notices] %s: %s on feed %s for %s -> bell=%s email=%s socket=%s%s",
            username, event, feed.get("id"), receipt.get("business_date"),
            channels["bell"]["state"], channels["email"]["state"], channels["socket"]["state"],
            "" if reached else " -- NOBODY WAS REACHED")
        out["notified"].append({"username": username, "channels": channels})
    return out


# ── the engine seam ──────────────────────────────────────────────────────

def on_execution_finalised(db, exec_db_id: Any, *, mailer=None, broadcast=None) -> Optional[dict]:
    """Called by ``feed_engine._finalize_execution_row`` after a terminal
    write LANDED.  Resolves execution -> run -> feed, builds the receipt,
    and raises the event it implies.  Never raises; returns what it did
    (None = nothing to do, with the reason logged at DEBUG)."""
    try:
        if not load_config()["enabled"]:
            return None
        execution = db.get_feed_execution(exec_db_id)
        if not execution:
            return None
        run = db.feed_run_for_execution(execution)
        if not run:
            logger.debug("[consumer_notices] execution %s owns no run -- no notice",
                         exec_db_id)
            return None
        feed = db.get_feed_config(int(run["feed_config_id"]))
        if not feed:
            return None
        if not _cr.consumer_group_ids(feed):
            return None
        receipt = _cr.build_receipt(db, feed, run, execution=execution)
        event = event_for_receipt(receipt)
        if event is None:
            logger.debug("[consumer_notices] run %s outcome %s raises no event",
                         run.get("id"), receipt.get("outcome"))
            return None
        return notify(db, feed, receipt, event, mailer=mailer, broadcast=broadcast)
    except Exception as exc:  # noqa: BLE001 - advisory, never fails a run
        logger.error("[consumer_notices] notice for execution %s could not be raised: %s",
                     exec_db_id, exc, exc_info=True)
        return None


# ── the late watcher ─────────────────────────────────────────────────────

def late_tick(db, *, now: Optional[datetime] = None, mailer=None, broadcast=None,
              lookback_days: Optional[int] = None) -> dict:
    """ONE late notice per (feed, business date) whose SLA has passed with
    no delivered run, for every feed that has a ``late`` subscriber.
    Idempotent through the ledger (run key ``date``)."""
    cfg = load_config()
    if not cfg["enabled"]:
        return {"status": "disabled"}
    now = now or datetime.now(timezone.utc)
    days = int(lookback_days if lookback_days is not None else cfg["lookback_days"])
    today = now.date()
    date_from = today - timedelta(days=max(0, days))
    out: dict = {"status": "ran", "checked_feeds": 0, "late": [], "already": [],
                 "not_due": 0, "delivered": 0, "no_sla": 0, "unavailable": [],
                 "sod_gaps": []}
    feed_ids = sorted({int(s["feed_config_id"])
                       for s in (db.list_feed_consumer_subscriptions(event=EVENT_LATE) or [])})
    if not feed_ids:
        return out
    # 2026-10-11 -- a date with NO run row is still not "late" here (a notice
    # needs a receipt, a receipt needs a run), but it must be VISIBLE: the
    # SOD generator's open GAP records (a due date it found with no run,
    # core/feed/sod_generator.py) for the watched feeds ride the tick's
    # output, so the daemon ledger and the status route show a month-end
    # that never got a run.
    try:
        out["sod_gaps"] = list(db.list_feed_sod_gaps(feed_ids=feed_ids, open_only=True,
                                                     limit=1000) or [])
    except Exception as exc:  # noqa: BLE001
        out["unavailable"].append(f"sod gaps: {exc}")
    try:
        runs = db.list_feed_runs(business_date_from=date_from, business_date_to=today,
                                 limit=None, include_manual=True) or []
    except Exception as exc:  # noqa: BLE001
        logger.error("[consumer_notices] late tick: runs could not be listed (%s) -- "
                     "nothing evaluated this pass", exc)
        out["unavailable"].append(f"runs: {exc}")
        return out
    by_feed_date: dict = {}
    for r in runs:
        fid = int(r.get("feed_config_id") or 0)
        if fid in feed_ids:
            by_feed_date.setdefault((fid, _cr._as_date(r.get("business_date"))), []).append(r)
    for fid in feed_ids:
        feed = db.get_feed_config(fid)
        if not feed:
            continue
        out["checked_feeds"] += 1
        try:
            executions = db.list_feed_executions(fid, limit=500) or []
        except Exception as exc:  # noqa: BLE001
            executions = None
            out["unavailable"].append(f"feed {fid} executions: {exc}")
        for (f, bd), day_runs in sorted(by_feed_date.items()):
            if f != fid or bd is None:
                continue
            receipts = [_cr.build_receipt(db, feed, r, executions=executions, now=now)
                        for r in day_runs]
            if any(rc["outcome"] == _cr.OUTCOME_DELIVERED for rc in receipts):
                out["delivered"] += 1
                continue
            # the SLA of the date: any run row of the date carries it
            # (SOD copies the feed's); a date whose only rows are backfills
            # has no clock by design.
            sla_at = None
            for r in day_runs:
                try:
                    sla_at = _cr.sla_for(feed, r)
                except Exception as exc:  # noqa: BLE001
                    out["unavailable"].append(f"feed {fid} {bd}: SLA {exc}")
                if sla_at is not None:
                    break
            if sla_at is None:
                out["no_sla"] += 1
                continue
            if now < sla_at:
                out["not_due"] += 1
                continue
            # the receipt shown is the day's most telling run: newest row.
            receipts.sort(key=lambda rc: int((rc.get("run") or {}).get("id") or 0))
            result = notify(db, feed, receipts[-1], EVENT_LATE, run_key="date",
                            mailer=mailer, broadcast=broadcast)
            (out["late"] if result["notified"] else out["already"]).append(
                {"feed_config_id": fid, "business_date": bd.isoformat(),
                 "notified": [n["username"] for n in result["notified"]],
                 "already": result["already"]})
    return out


def status(db) -> dict:
    """What an admin status read shows: config + the latest notices."""
    cfg = load_config()
    try:
        recent = db.list_feed_consumer_notices(limit=50)
    except Exception as exc:  # noqa: BLE001
        recent = {"unavailable": str(exc)}
    return {"job_id": JOB_ID, "config": cfg, "recent": recent}
