"""Delivery-target adapters — one class per destination, one registry.

2026-08-04 strategic redesign.  Delivery to local / S3 / SFTP / Oracle
was an inline if/elif branch pile in ``feed_engine._deliver_to_destination``,
each branch with its own atomicity, retry and verification semantics —
and its own ways of silently doing nothing (the SFTP post-delivery
verifier no-oped when no client factory was injected; the S3 twin built
a client with the WRONG credentials and could only warn; an Oracle
delivery could COMMIT with up to ``max_error_percent`` of rows missing
and report success that the certificate could not see).

This module is the seam that removes the branches:

  * ``DeliveryTarget`` — one adapter per destination type.  ``deliver``
    returns a ``DeliveryReceipt`` that MUST state its verification
    outcome: ``verified`` (checked in-band, with the same authenticated
    session that performed the delivery — the injection problem the old
    layer-2 verifier had cannot exist) or ``absent`` WITH a reason.
    There is no silent success: a receipt without verification evidence
    is visible in the run record and the completeness certificate, not
    swallowed.
  * ``DeliveryReceipt.delivered_rows`` — destination-side row count for
    targets that can know it (Oracle row accounting).  The certificate
    reconciles against THIS when present, so a destination that dropped
    rows can no longer be certified COMPLETE by recounting the local
    file.
  * ``_TARGETS`` registry — ``get_delivery_target`` raises
    ``UnsupportedDeliveryTarget`` (a ``ValueError`` → treated as a
    non-retryable configuration error) listing what IS registered.

Adding a delivery target is one subclass + one ``register_target`` call;
the engine's retry loop, receipt plumbing and certificate wiring pick it
up unchanged.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from core.feed.steps import FeedStep

#: Verification outcomes a receipt may carry.  There is deliberately no
#: "failed" value: a failed verification RAISES from ``deliver`` — a
#: delivery whose evidence contradicts it is a failed delivery, not a
#: delivered file with a footnote.
VERIFIED = "verified"
ABSENT = "absent"          # no cheap evidence available — reason required


@dataclass
class DeliveryReceipt:
    """What a delivery adapter must hand back.  The receipt is the ONLY
    channel through which delivery evidence reaches the run record and
    the completeness certificate — an adapter cannot report success
    without also stating what it verified (or why it could not)."""

    uri: str
    target: str
    verification: str = ABSENT
    verification_detail: str = "adapter reported no evidence"
    #: Destination-side row count when the target can know it (Oracle).
    #: ``None`` for opaque-byte targets (file drops) — the certificate
    #: then reconciles against the independent file recount instead.
    delivered_rows: Optional[int] = None
    #: Rows the destination REJECTED but the delivery still committed
    #: (Oracle ``max_error_percent`` tolerance).  Non-zero here must
    #: surface in the run record — it is exactly the silent 5% lie.
    dropped_rows: int = 0
    extras: Dict[str, Any] = field(default_factory=dict)

    def to_stage_record(self) -> Dict[str, Any]:
        rec: Dict[str, Any] = {
            "target": self.target,
            "verification": self.verification,
            "detail": self.verification_detail,
        }
        if self.delivered_rows is not None:
            rec["delivered_rows"] = self.delivered_rows
        if self.dropped_rows:
            rec["dropped_rows"] = self.dropped_rows
        # AQD-10 (2026-09-23): HOW the delivery authenticated (method,
        # username, credential source, key type -- never the secret).  The
        # SFTP transport records it in-band; before this it rode in
        # ``extras`` and every persisted record dropped it.
        if isinstance(self.extras.get("auth"), dict):
            rec["auth"] = dict(self.extras["auth"])
        return rec

    @classmethod
    def from_outparam(cls, uri: str, target: str,
                      raw: Optional[Dict[str, Any]]) -> "DeliveryReceipt":
        """Build a receipt from the ``_receipt`` out-param dict the
        legacy delivery functions fill in-band."""
        raw = raw or {}
        return cls(
            uri=uri,
            target=target,
            verification=raw.get("verification", ABSENT),
            verification_detail=raw.get(
                "verification_detail", "adapter reported no evidence"),
            delivered_rows=raw.get("delivered_rows"),
            dropped_rows=int(raw.get("dropped_rows") or 0),
            extras={k: v for k, v in raw.items()
                    if k not in ("verification", "verification_detail",
                                 "delivered_rows", "dropped_rows")},
        )


class UnsupportedDeliveryTarget(ValueError):
    """No adapter registered for the requested destination type.
    Subclasses ``ValueError`` so the engine's retry loop treats it as a
    deterministic configuration error (no pointless retries)."""


class DeliveryTarget(FeedStep, ABC):
    """One destination type: how to publish a local file there, with
    verification evidence in-band.

    2026-09-02 — re-parented onto :class:`core.feed.steps.FeedStep`
    (``role="delivery"``): registry, discovery and the boot report are
    the SHARED step mechanism now; ``deliver`` — a receipt that must
    state verification, a miss that raises listing what is registered —
    is untouched.  The four builtin adapters (local/s3/sftp/oracle) are
    registered from the static list in ``core.feed.steps`` — the
    import-time registration loop feed_engine carried is deleted."""

    role = "delivery"
    #: Registry key (lowercase) — also the ``destination_type`` config value.
    name: str = ""
    #: Does this target need the RUN's identity (feed name, business
    #: date, build id) on top of its static destination settings?
    #: Declared rather than hardcoded, so a future target that files by
    #: run — a second archive tier, a dated vault — gets the injection
    #: by saying so, not by being named inside build_hop_plan.  A target
    #: that says True and receives no identity must REFUSE: filing under
    #: a guessed key is filing in a random drawer.
    needs_run_identity: bool = False

    @abstractmethod
    def deliver(self, local_path: str, filename: str,
                dest_config: Dict[str, Any]) -> DeliveryReceipt:
        """Publish ``local_path`` under ``filename`` at the destination.

        MUST be atomic from the consumer's point of view (the final name
        appears only complete) and MUST return a ``DeliveryReceipt``.
        Raise on failure — including verification evidence contradicting
        the delivery."""


# ── Registry — delegates to the shared step registry ───────────────────────
#
# ``register_target`` / ``get_delivery_target`` keep their signatures and
# exception type (callers and tests depend on both); the storage behind
# them is core.feed.steps.  Three outcomes now: registered → adapter;
# tombstoned (a discovered step file that failed to load) →
# ``StepLoadFailed`` naming the file and reason, deliberately NOT
# translated to UnsupportedDeliveryTarget — "failed to load" and "no
# such target" lead to opposite investigations; unknown →
# ``UnsupportedDeliveryTarget`` listing what IS registered.


def register_target(target: DeliveryTarget) -> None:
    """EXTENSION POINT (declared 2026-09-03) -- no in-tree caller by design.

    Register an adapter under its ``name``.  Runtime re-registration
    replaces (supports tests and deployment-specific overrides).

    The builtin adapters are registered from the static list in
    ``core.feed.steps`` and a discovered step registers itself through
    the loader, so nothing in this repository calls this function.  It
    is still the documented way to add a target at runtime -- this
    module's own header says "one subclass + one register_target call"
    -- and it forwards to ``steps.register_step(origin="runtime")``, so
    following that instruction genuinely works.

    Declared rather than deleted, and declared rather than left silent:
    a public extension point with no caller and a half-built module with
    no caller are indistinguishable from outside, and the second is the
    defect this codebase kept shipping."""
    from core.feed import steps as _steps
    if not target.name:
        raise ValueError("DeliveryTarget.name must be a non-empty string")
    _steps.register_step(target, origin="runtime")


def get_delivery_target(dest_type: str) -> DeliveryTarget:
    """Resolve the adapter for a destination — loud on miss."""
    from core.feed import steps as _steps
    try:
        t = _steps.get_step("delivery", dest_type)
    except _steps.UnknownStep:
        raise UnsupportedDeliveryTarget(
            f"Unsupported destination type: {dest_type}. "
            f"Registered targets: {_steps.registered_names('delivery')}"
        )
    if not isinstance(t, DeliveryTarget):
        raise UnsupportedDeliveryTarget(
            f"step delivery/{dest_type} is not a DeliveryTarget "
            f"({type(t).__name__}) — refusing to dispatch a delivery "
            f"to it"
        )
    return t


def known_targets() -> list:
    from core.feed import steps as _steps
    return _steps.registered_names("delivery")


class _TargetsView:
    """Back-compat view of the delivery registry — the storage moved to
    ``core.feed.steps`` (2026-09-02), but callers/tests that used the
    old module-level ``_TARGETS`` dict surface (membership, iteration,
    ``pop`` for cleanup) keep working against the LIVE registry.  A
    frozen dict copy here would be the lying kind of compatibility."""

    def _names(self) -> list:
        from core.feed import steps as _steps
        return _steps.registered_names("delivery")

    def __iter__(self):
        return iter(self._names())

    def __len__(self) -> int:
        return len(self._names())

    def __contains__(self, key: object) -> bool:
        return str(key or "").lower() in self._names()

    def get(self, key: str, default=None):
        try:
            return get_delivery_target(key)
        except (UnsupportedDeliveryTarget, Exception):
            return default

    def pop(self, key: str, default=None):
        from core.feed import steps as _steps
        removed = _steps.remove_step("delivery", key)
        return removed if removed is not None else default


_TARGETS = _TargetsView()
