"""A NEW system entity onboards itself from its first COMPLETE message (2026-10-11).

The owner's case: ~4,000 (SYSTEM_ENTITY, business event) month-end feeds,
each made from ONE template, each held by its dependencies until BOTH its
CLOUD and its ONPREM COMPLETE messages (Kafka topic or a QS_KAFKA_MESSAGE
row) have arrived.  A system entity can appear for the first time in any
month-end's traffic.  Until today its message was recorded on the dependency
ledger and marked UNMATCHED ("no active feed declares ...") -- and nothing
else happened until a person applied the template by hand.

Now, decided with the owner:
  * a template DECLARES that it onboards (``feed_templates.auto_onboard``):
        {"match":  {"DATA_SOURCE": "finance_sl_balance"},
         "params": {"SYSTEM_ENTITY": "CODE", "EventCode": "BUSINESS_EVENT"},
         "events": ["EOD", "ME5"]}           # optional
    -- the message's DATA_SOURCE picks the template; ``params`` names, per
    template parameter, the message field that carries its value;
  * the resolver (both roads, at the UNMATCHED point) writes ONE request
    per (template, member) -- ``request_onboarding``; the entity's cloud
    and on-prem messages land on the same row;
  * ``process_requests`` creates the member through the template's ordinary
    apply (every authoring rule holds: names, filename collisions, the
    dependency declarations), adds the row to the template's matrix (a later
    re-apply keeps it), and asks SOD for that business date, scoped to the
    new feed -- a month-end feed gets its task only when the date IS due on
    its calendar.  The new run is born WAITING like every other; its
    dependencies decide when it runs, and the arrival that triggered all
    this is already on the ledger.

Nothing here decides what a feed waits for: that is its declared
dependencies, exactly as the template declares them.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import date
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Tuple

from core.feed.feed_template import member_key

logger = logging.getLogger(__name__)

#: a request that failed (an error, not a refusal) is retried this many times
MAX_ATTEMPTS = 5

PENDING, ONBOARDED, REFUSED, FAILED = "pending", "onboarded", "refused", "failed"


def _field(payload: Mapping[str, Any], name: str) -> Any:
    """A message field by name, case-insensitively (OG payload keys are
    upper case; a hand-typed declaration may not be)."""
    if name in payload:
        return payload[name]
    low = str(name).lower()
    for k, v in payload.items():
        if str(k).lower() == low:
            return v
    return None


def declaration_problem(template: Mapping[str, Any]) -> Optional[str]:
    """Why a template's auto_onboard declaration cannot be used, or None."""
    ao = template.get("auto_onboard")
    if not ao:
        return "no auto_onboard declaration"
    if not isinstance(ao, dict):
        return "auto_onboard must be an object"
    params = ao.get("params")
    if not isinstance(params, dict) or not params:
        return "auto_onboard.params must map each template parameter to a message field"
    missing = [p for p in (template.get("parameters") or []) if p not in params]
    if missing:
        return f"auto_onboard.params does not say where {missing} come from"
    if not isinstance(ao.get("match") or {}, dict):
        return "auto_onboard.match must be an object of message field -> value"
    if ao.get("events") is not None and not isinstance(ao.get("events"), list):
        return "auto_onboard.events must be a list"
    return None


def match(templates: Iterable[Mapping[str, Any]],
          payload: Mapping[str, Any]) -> List[Tuple[Mapping[str, Any], Dict[str, str]]]:
    """Every active template whose declaration matches the message, with the
    member's parameter values read from it."""
    out = []
    for t in templates:
        if not t.get("is_active", True) or declaration_problem(t):
            continue
        ao = t["auto_onboard"]
        if any(str(_field(payload, k) if _field(payload, k) is not None else "").strip().lower()
               != str(v).strip().lower() for k, v in (ao.get("match") or {}).items()):
            continue
        values = {p: str(_field(payload, ao["params"][p]) or "").strip()
                  for p in t.get("parameters") or []}
        if not all(values.values()):
            continue
        events = ao.get("events")
        if events:
            ev_param = next((p for p, f in ao["params"].items()
                             if str(f).upper() in ("BUSINESS_EVENT", "BUSINESSEVENT", "EVENT")), None)
            if ev_param and values.get(ev_param) not in {str(e) for e in events}:
                continue
        out.append((t, values))
    return out


def request_onboarding(db: Any, payload: Mapping[str, Any], *, dependency_name: str,
                       business_date: Optional[date], source: str,
                       message_identity: str) -> int:
    """Called by the resolvers at the UNMATCHED point.  Writes a request per
    matching template (idempotent).  Returns how many were NEW.  Never
    raises: the arrival is already recorded, and onboarding must not be
    able to lose it."""
    try:
        templates = db.list_feed_templates()
    except Exception as exc:  # noqa: BLE001
        logger.error("[auto_onboard] could not list templates for %s: %s", dependency_name, exc)
        return 0
    new = 0
    hits = match(templates, payload or {})
    # Two templates claiming the same message would create TWO feeds for one
    # entity: never.  Every claimant's request is recorded REFUSED naming the
    # others, so the monitor says which declarations to fix.
    ambiguous = None
    if len(hits) > 1:
        names = sorted(str(t.get("name")) for t, _ in hits)
        ambiguous = (f"ambiguous: {len(hits)} templates declare auto_onboard for this message "
                     f"({', '.join(names)}) -- narrow their 'match' so exactly one applies")
        logger.error("[auto_onboard] %s (%s)", ambiguous, dependency_name)
    for t, values in hits:
        try:
            _row, created = db.upsert_onboarding_request({
                "template_id": int(t["id"]),
                "member_key": member_key(t["parameters"], values),
                "values": values, "business_date": business_date,
                "dependency_name": dependency_name, "source": source,
                "message_identity": message_identity,
                "status": REFUSED if ambiguous else PENDING,
                "detail": ambiguous})
        except Exception as exc:  # noqa: BLE001
            logger.error("[auto_onboard] request for %s on template %s not written: %s",
                         values, t.get("name"), exc)
            continue
        if created:
            new += 1
            logger.warning("[auto_onboard] NEW system entity %s from %s (%s): onboarding "
                           "requested on template %s", values, source, dependency_name, t.get("name"))
    return new


# ── carrying a request out ──────────────────────────────────────────────

ApplyFn = Callable[[Mapping[str, Any], List[Dict[str, str]]], Dict[str, Any]]
SodFn = Callable[[Any, date, int], str]


def _default_apply(template: Mapping[str, Any], rows: List[Dict[str, str]]) -> Dict[str, Any]:
    """The template's ordinary apply for these rows only (never retires a
    member), acting as the template's creator."""
    from api import feed_template_api as fta
    spec = fta._spec_of(dict(template))
    user = {"username": template.get("created_by") or "auto_onboard", "role": "admin",
            "auth_source": "auto_onboard"}
    report = asyncio.run(fta._apply(dict(template), spec, rows, user,
                                    dry_run=False, retire_missing=False))
    return report.to_dict()


def _default_sod(db: Any, business_date: date, feed_id: int) -> str:
    """SOD for the message's business date, scoped to the new feed."""
    from core.feed.sod_generator import SodTaskGenerator
    res = SodTaskGenerator(db).run_for_date(business_date, feed_ids=[int(feed_id)])
    if res.created or res.catchup_created:
        return "created"
    if res.already_existed:
        return "exists"
    if res.errors:
        return "error: " + "; ".join(res.error_details)[:200]
    return "not_due"


def _member_feed_id(report: Mapping[str, Any], key: str) -> Tuple[Optional[int], Optional[str]]:
    """(feed id, refusal reason) for one member from an apply report."""
    for bucket in ("created", "updated", "unchanged"):
        for e in report.get(bucket) or []:
            if e.get("key") == key or e.get("member_key") == key:
                return (int(e["feed_id"]) if e.get("feed_id") else None), None
    for bucket in ("refused", "conflicts"):
        for e in report.get(bucket) or []:
            if e.get("key") == key or e.get("member_key") == key:
                return None, str(e.get("reason") or e.get("detail") or bucket)[:1000]
    return None, "the apply report does not mention this member"


def process_requests(db: Any, *, limit: int = 50, apply_fn: Optional[ApplyFn] = None,
                     sod_fn: Optional[SodFn] = None) -> Dict[str, int]:
    """Carry out pending (and retryable failed) requests.  Never raises."""
    apply_fn = apply_fn or _default_apply
    sod_fn = sod_fn or _default_sod
    counters = {"onboarded": 0, "refused": 0, "failed": 0, "runs_created": 0}
    try:
        rows = (db.list_onboarding_requests(PENDING, limit)
                + [r for r in db.list_onboarding_requests(FAILED, limit)
                   if int(r.get("attempts") or 0) < MAX_ATTEMPTS])
    except Exception as exc:  # noqa: BLE001
        logger.error("[auto_onboard] could not list requests: %s", exc)
        return counters
    for req in rows[:limit]:
        rid = int(req["id"])
        try:
            t = db.get_feed_template(int(req["template_id"]))
            problem = "template is gone" if not t else (
                "template is inactive" if not t.get("is_active", True) else declaration_problem(t))
            if problem:
                db.update_onboarding_request(rid, {"status": REFUSED, "detail": problem})
                counters["refused"] += 1
                continue
            values = dict(req["values"])
            key = req["member_key"]
            matrix = list(t.get("matrix") or [])
            if all(member_key(t["parameters"], m) != key for m in matrix):
                matrix.append(values)
                from api.feed_template_api import _hash
                t = db.update_feed_template(int(t["id"]), {
                    "matrix": matrix,
                    "definition_hash": _hash(t["parameters"], t.get("definition"), matrix)}) or t
            report = apply_fn(t, [values])
            fid, refusal = _member_feed_id(report, key)
            if fid is None:
                db.update_onboarding_request(rid, {"status": REFUSED,
                                                   "detail": refusal or "no feed was created",
                                                   "attempts": int(req.get("attempts") or 0) + 1})
                counters["refused"] += 1
                logger.error("[auto_onboard] %s on template %s REFUSED: %s",
                             values, t.get("name"), refusal)
                continue
            run = "no business date in the message"
            if req.get("business_date"):
                bd = req["business_date"]
                bd = date.fromisoformat(bd) if isinstance(bd, str) else bd
                run = sod_fn(db, bd, fid)
                if run == "created":
                    counters["runs_created"] += 1
            db.update_onboarding_request(rid, {
                "status": ONBOARDED, "feed_config_id": fid, "run": run[:30],
                "detail": f"feed {fid} from template {t.get('name')}; SOD for "
                          f"{req.get('business_date')}: {run}",
                "attempts": int(req.get("attempts") or 0) + 1})
            counters["onboarded"] += 1
            logger.warning("[auto_onboard] ONBOARDED %s -> feed %s (template %s); SOD %s: %s",
                           values, fid, t.get("name"), req.get("business_date"), run)
        except Exception as exc:  # noqa: BLE001 -- recorded on the row, retried
            counters["failed"] += 1
            logger.exception("[auto_onboard] request %s failed", rid)
            try:
                db.update_onboarding_request(rid, {
                    "status": FAILED, "detail": f"{type(exc).__name__}: {exc}"[:1000],
                    "attempts": int(req.get("attempts") or 0) + 1})
            except Exception:  # noqa: BLE001
                pass
    return counters
