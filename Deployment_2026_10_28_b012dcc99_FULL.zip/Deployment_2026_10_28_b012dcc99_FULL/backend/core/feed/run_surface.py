"""The run surface — making the night legible (BRD §13.1).

Six questions support must be able to answer IN ONE SCREEN, at 04:50, without
writing a query:

  1. What is running right now, on which pod, holding which connection slots?
  2. What is blocked, and on WHAT — the blocking set, not a count?
  3. What is late against its own history, and how long is left to act?
  4. What failed, at which step, with which error, and is it retryable?
  5. Which files did last night's run produce, and were they delivered?
  6. Who decided what, and when?

Two design rules, both learned the hard way in this codebase:

**Database-backed and cross-pod from day one** (FR-OPS-01).  A screen that
reflects only the pod serving the request is worse than no screen, because it
is CONFIDENTLY WRONG — an operator reads "nothing is running" from a pod that
happens to be idle while three others are busy.

**Composition only.**  This module runs no new query it can get from the DAO,
and adds no state.  Every number here is derived from rows something else
already writes, so the screen can never disagree with the thing it describes.
A screen with its own counters is a second source of truth, and the two drift.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)

#: Run states that mean "someone is working on this right now".
ACTIVE_STATES = frozenset({"pending", "running", "in_progress", "queued"})
#: Run states that mean it is over, one way or another.
TERMINAL_STATES = frozenset({"completed", "failed", "cancelled", "skipped"})


@dataclass
class SurfaceSection:
    """One answer, with the evidence and — when there is nothing to show —
    WHY there is nothing.

    ``unavailable`` is not the same as empty.  "No runs are blocked" and "the
    blocked list could not be read" are opposite findings, and a screen that
    renders both as an empty table teaches an operator to trust an absence.
    """
    name: str
    rows: list = field(default_factory=list)
    unavailable: Optional[str] = None

    @property
    def count(self) -> int:
        return len(self.rows)

    def to_dict(self) -> dict:
        return {"name": self.name, "count": self.count, "rows": self.rows,
                "unavailable": self.unavailable}


def _section(name: str, fn) -> SurfaceSection:
    """Run one section, containing its failure to itself.

    One broken section must not blank the whole screen: at 04:50 five working
    answers and one honest gap beat a 500.
    """
    try:
        return SurfaceSection(name=name, rows=list(fn() or ()))
    except Exception as exc:
        logger.error("[run_surface] section %r could not be read: %s",
                     name, exc)
        return SurfaceSection(name=name, rows=[],
                              unavailable=f"{type(exc).__name__}: {exc}")


def running_now(db) -> SurfaceSection:
    """Q1 — what is running, on which pod, holding which slots.

    The claims table is the authority on "right now": it is written when work
    is admitted and cleared when it ends, on every pod, so it answers across
    the fleet rather than for whoever served the request.
    """
    def _rows():
        claims = db.list_connection_claims() or []
        by_run: dict = {}
        for claim in claims:
            key = (claim.get("run_kind"), claim.get("run_id"))
            entry = by_run.setdefault(key, {
                "run_kind": claim.get("run_kind"),
                "run_id": claim.get("run_id"),
                "pod_id": claim.get("pod_id"),
                "feed_config_id": claim.get("feed_config_id"),
                "claimed_at": claim.get("claimed_at"),
                "heartbeat_at": claim.get("heartbeat_at"),
                "connection_ids": [],
            })
            entry["connection_ids"].append(claim.get("connection_id"))
        return sorted(by_run.values(),
                      key=lambda r: str(r.get("claimed_at") or ""))
    return _section("running_now", _rows)


def blocked_on_what(db, business_date: date) -> SurfaceSection:
    """Q2 — what is blocked, and on WHAT.

    "9/10" tells support nothing actionable; "APAC_POSITIONS, last seen three
    days ago" tells them who to call (FR-DEP-06).  So each row carries the
    BLOCKING SET, never a count.
    """
    def _rows():
        from core.feed.etl_dependency import (
            effective_etl_id, evaluate_gate_verdicts,
        )
        waiting = [r for r in (db.list_feed_runs(business_date=business_date,
                                                 status="pending") or [])
                   if (r.get("action_decision") or "RUN") == "WAIT"]
        out = []
        feeds: dict = {}
        for run in waiting:
            # 2026-09-27 — the key comes from the FEED, resolved once per
            # feed: ``list_feed_runs`` rows are ``FeedRun.to_dict()`` and
            # carry no etl_id, so ``run.get("etl_id")`` was None for every
            # real row and this section listed every held run with an
            # EMPTY blocking set -- "9/10" with no names, the exact answer
            # the docstring says is not one.  A feed row that cannot be
            # read costs that run its names, never the section.
            fid = run.get("feed_config_id")
            if fid not in feeds:
                try:
                    feeds[fid] = db.get_feed_config(int(fid)) or None
                except Exception as exc:
                    logger.warning("[run_surface] feed_config %s unreadable "
                                   "(%s) -- its blocking set is unknown",
                                   fid, exc)
                    feeds[fid] = None
            feed = feeds[fid]
            blocking = []
            if feed is not None:
                verdicts = evaluate_gate_verdicts(
                    db, effective_etl_id(feed), business_date)
                if verdicts is not None:
                    blocking = [{"dependency": v.dependency_name,
                                 "verdict": v.verdict, "reason": v.reason}
                                for v in verdicts.blocking]
            out.append({"feed_run_id": run.get("id"),
                        "feed_config_id": run.get("feed_config_id"),
                        "business_date": str(business_date),
                        "blocking": blocking})
        return out
    return _section("blocked", _rows)


def late_by_history(db, business_date: date,
                    now: Optional[datetime] = None) -> SurfaceSection:
    """Q3 — what is late against its OWN history, and how long is left to
    act (2026-09-28).

    One row per blocking dependency, from ``acting_time.clocks_for_blocked``
    -- the SAME computation the SLA watcher alerts on, so the sentence on
    this screen is the sentence on the Netcool console.  Each row says
    which of three things it knows: a minted clock (``usual_by``, p95 of a
    high-confidence profile) and how late against it; no usable history
    yet (``observations`` without a clock -- FR-SLA-04, never invented);
    or that the ledger / the clocks could not be read
    (``profile_unavailable`` / ``clocks_unavailable``).  Worst first.

    The blocking index failing is this section's ``unavailable`` -- an
    empty list here would read as "nothing is late".
    """
    def _rows():
        from core.feed import acting_time as _at
        at_now = now or datetime.now(timezone.utc)
        result = _at.clocks_for_blocked(db, business_date, at_now)
        if result.index_error is not None:
            raise RuntimeError(
                f"the blocking index could not be built: {result.index_error}")
        rows = [_at.blocked_row(item, business_date=business_date, now=at_now)
                for item in result.blocked]
        rows.extend(_at.failed_row(entry) for entry in result.failed)
        rows.sort(key=_at.worst_first_key)
        return rows
    return _section("late_by_history", _rows)


def failures(db, business_date: date) -> SurfaceSection:
    """Q4 — what failed, at which step, with which error, and is it retryable.

    The step and the retryability are the two facts that decide what support
    does next, so a row without them is not an answer.
    """
    def _rows():
        runs = db.list_feed_runs(business_date=business_date,
                                 status="failed") or []
        out = []
        for run in runs:
            latest = None
            try:
                execs = db.list_feed_executions(
                    int(run.get("feed_config_id") or 0), limit=1) or []
                latest = execs[0] if execs else None
            except Exception as exc:
                logger.debug("[run_surface] execution lookup failed: %s", exc)
            out.append({
                "feed_run_id": run.get("id"),
                "feed_config_id": run.get("feed_config_id"),
                "error": run.get("error"),
                "failed_stage": (latest or {}).get("failed_stage"),
                "execution_id": (latest or {}).get("execution_id"),
                "completeness": ((latest or {}).get("files_metadata") or {})
                                .get("completeness_verdict"),
            })
        return out
    return _section("failures", _rows)


def produced_and_delivered(db, feed_config_id: int,
                           limit: int = 20) -> SurfaceSection:
    """Q5 — which files did the run produce, and were they DELIVERED?

    Two different questions.  A feed can produce every file correctly and
    deliver none of them; showing only "completed" answers the first and lets
    an operator believe it answered the second.
    """
    def _rows():
        attempts = db.list_delivery_attempts_for_feed(
            int(feed_config_id), limit=limit) or []
        return [{"manifest_version": a.get("manifest_version"),
                 "hop": a.get("target") or a.get("hop_label"),
                 "target_type": a.get("target_type"),
                 "attempt": a.get("attempt"),
                 "status": a.get("status"),
                 "acknowledgment": a.get("acknowledgment"),
                 "uri": a.get("uri"),
                 "error": a.get("error")} for a in attempts]
    return _section("delivery", _rows)


def decisions(db, feed_config_id: int, business_date: date) -> SurfaceSection:
    """Q6 — who decided what, and when.

    Read from the append-only ledger, not from current state: a skip that was
    later superseded still HAPPENED, and "who decided" is unanswerable from a
    row that only holds the latest value.
    """
    def _rows():
        events = db.list_run_events(int(feed_config_id),
                                    business_date=business_date) or []
        return [e for e in events
                if str(e.get("event_type") or "").startswith("decision")
                or "skip" in str(e.get("event_type") or "")]
    return _section("decisions", _rows)


def children_of(db, feed_run_id: int) -> SurfaceSection:
    """The fan-out view: which partition produced which part, and which one is
    file 738 so support can re-run it alone."""
    def _rows():
        return db.list_feed_file_runs(int(feed_run_id)) or []
    return _section("children", _rows)


def deployment_windows(db) -> SurfaceSection:
    """FR-OPS-04 — active and imminent change windows, with their recent
    refusals.  On the surface DELIBERATELY: a run that silently did not
    start during a window is indistinguishable from a broken scheduler;
    here the operator sees the window, its reason, and who it refused.
    Empty rows mean "no windows"; a store read failure renders the
    section ``unavailable`` — the two must never look alike."""
    def _rows():
        from core.feed.deployment_window import surface_rows
        return surface_rows(db)
    return _section("deployment_windows", _rows)


def report_slos(db, business_date: date, now: Optional[datetime] = None,
                report_visible=None) -> SurfaceSection:
    """Reports at risk (2026-09-28) -- every active report PROMISE ("fresh
    and served by 07:00 London") for the date, worst first, from
    ``core.reports.slo.surface_rows``: breached (with its cause), at risk
    (the data is not complete and the promise is ahead), could not
    evaluate, served late, ready, met.  Scoped INSIDE the section by the
    reader's report view rule (``report_visible(report) -> bool``, the same
    ``can_view_business_report`` every report route applies; None = every
    report), because a report is not a feed and the feed-id scope cannot
    name it.  A ledger that cannot be read is the section's
    ``unavailable`` -- never an empty table that reads as "every promise
    kept"."""
    def _rows():
        from core.reports import slo as _slo
        return _slo.surface_rows(db, business_date, now=now,
                                 report_visible=report_visible)
    return _section("report_slos", _rows)


#: Sections whose rows carry a ``feed_config_id`` and are scoped to the
#: feeds the caller may VIEW (2026-09-27).  The per-feed sections are
#: gated on their ``feed_config_id`` argument by the route instead.
FEED_SCOPED_SECTIONS = frozenset({"running_now", "blocked", "failures",
                                  "late_by_history"})


def _scope_dependency_row(row: dict, visible_feed_ids: set) -> Optional[dict]:
    """A ``late_by_history`` row names a SET of feeds.  Keep the ones the
    caller may view; drop the row when none is left (a dependency blocking
    only other teams' feeds is not this reader's problem to see).  The
    tightest-SLA feed and the sentence naming it are REDACTED when that
    feed is not visible -- the deadline itself stays, it governs every
    feed the skip would release -- because the surface must never name a
    feed its reader is refused on the next click."""
    ids = [int(i) for i in (row.get("blocked_feed_ids") or [])
           if int(i) in visible_feed_ids]
    if not ids:
        return None
    out = dict(row)
    out["blocked_feed_ids"] = ids
    out["blocked_feeds"] = [
        f for f in (row.get("blocked_feeds") or [])
        if f.get("feed_config_id") is not None
        and int(f["feed_config_id"]) in visible_feed_ids]
    out["blocked_count"] = len(ids)
    sla_feed = row.get("sla_feed")
    visible_names = {str(f.get("feed_name")) for f in out["blocked_feeds"]}
    if sla_feed and str(sla_feed) not in visible_names:
        out["sla_feed"] = None
        out["sla_feed_redacted"] = True
        if out.get("summary"):
            out["summary"] = str(out["summary"]).replace(
                str(sla_feed), "a feed outside your view")
    return out


def _scope(section: SurfaceSection,
           visible_feed_ids: Optional[set]) -> SurfaceSection:
    """Keep only the rows of feeds the caller may view.  ``None`` = every
    feed (admin, support, a no-auth deployment).  A row with no feed id
    (a claim of another run kind) is kept: it names no feed.  A row that
    names a SET of feeds (``blocked_feed_ids``) is narrowed to the visible
    ones and dropped when none remain."""
    if visible_feed_ids is None or section.name not in FEED_SCOPED_SECTIONS:
        return section
    kept = []
    for r in section.rows:
        if r.get("blocked_feed_ids") is not None:
            scoped = _scope_dependency_row(r, visible_feed_ids)
            if scoped is not None:
                kept.append(scoped)
            continue
        if (r.get("feed_config_id") is None
                or int(r["feed_config_id"]) in visible_feed_ids):
            kept.append(r)
    section.rows = kept
    return section


def build_surface(db, *, business_date: Optional[date] = None,
                  feed_config_id: Optional[int] = None,
                  feed_run_id: Optional[int] = None,
                  visible_feed_ids: Optional[set] = None,
                  report_visible=None) -> dict:
    """Assemble the screen.  Every section is independent and self-contained,
    so one unreadable table costs one answer rather than all six.

    ``visible_feed_ids`` (2026-09-27) scopes the fleet sections to the
    feeds the caller may VIEW -- the same rule as ``/api/feeds`` and the
    Today board, so the support desk never names a feed its reader would
    be refused on the next click.  ``None`` means every feed.
    ``report_visible`` (2026-09-28) is the same idea for the report
    section: the reader's ``can_view_business_report`` rule, or None."""
    bd = business_date or datetime.now(timezone.utc).date()
    # late_by_history FIRST (2026-09-28): it is the section an operator
    # reads at 04:50, and the screen shows the sections in this order.
    sections = [_scope(s, visible_feed_ids) for s in (
        late_by_history(db, bd), running_now(db), blocked_on_what(db, bd),
        failures(db, bd))]
    sections.append(report_slos(db, bd, report_visible=report_visible))
    sections.append(deployment_windows(db))
    if feed_config_id is not None:
        sections.append(produced_and_delivered(db, feed_config_id))
        sections.append(decisions(db, feed_config_id, bd))
    if feed_run_id is not None:
        sections.append(children_of(db, feed_run_id))
    return {
        "business_date": bd.isoformat(),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "sections": {s.name: s.to_dict() for s in sections},
        # A screen that silently dropped a section would read as "nothing to
        # report".  Name the gaps at the top level so they cannot be missed.
        "unavailable_sections": [s.name for s in sections if s.unavailable],
    }
