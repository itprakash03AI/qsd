"""THE Oracle destination identifier rule -- ONE answer, every lane.

WHY THIS MODULE EXISTS (FB-59, 2026-09-21)
------------------------------------------
Two QueryStudio lanes write a feed into an Oracle table:

  * ``native``     -- core/feed_engine.py::_deliver_oracle (oracledb INSERT)
  * ``spark_k8s``  -- spark/jobs/generic_feed.py::_write_oracle (Spark JDBC),
                      shared with the ``airflow`` lane

and until this module they answered "what is this column CALLED in Oracle"
differently.  The native lane asks the table and adopts its spelling.  The
Spark lane handed Spark the DataFrame's own column names, which Spark's
Oracle dialect QUOTES -- so a table Spark CREATED came out
``"id","region","amt","qty","dt"``: lower-case QUOTED, which in Oracle is a
permanent identifier, not a display choice.  ``SELECT REGION FROM t`` then
raises ORA-00904 forever, for every consumer, and whether a given feed's
table is readable that way depended on whether the table happened to exist
before the feed first ran.

THE RULE
--------
1. If the destination table EXISTS, its own spelling wins on a case-only
   difference, and a source column with no home in it REFUSES the delivery.
   (Column ORDER stays the SOURCE's: values are bound positionally.)
2. If the table does NOT exist and the lane creates it, every column is
   created as the identifier ORACLE ITSELF would create from unquoted DDL:
   the source name folded to UPPER CASE.
3. A name that cannot be folded safely is REFUSED, never mangled.

WHY UPPER CASE, and not "whatever the source spelled"
-----------------------------------------------------
* It is REVERSIBLE.  ``REGION`` answers to ``SELECT REGION``, ``SELECT
  region`` and ``SELECT "REGION"`` because Oracle folds unquoted
  identifiers up.  ``"region"`` answers to ``"region"`` alone -- forever,
  for every report, feed, reconciliation rule and hand-written statement.
  One casing is readable by everything; the other is readable only by
  callers who already know how the table happened to be written.
* It is the rule this product ALREADY states.  ``_deliver_oracle`` says so
  in its own comment ("Oracle folds an unquoted identifier to upper case
  when the table is created, so the stored name is AMOUNT") -- the native
  lane was written expecting canonical tables, and the Spark lane was
  creating tables that violate that expectation.
* The fold LOSES NOTHING THIS PRODUCT CAN EXPRESS.  The Oracle connector
  lower-cases every result key it reads (``_fetchall_as_dicts``) and the
  native delivery matches columns case-insensitively, so QueryStudio cannot
  tell ``Region`` from ``region`` on an Oracle table in the first place.
  Where the fold WOULD lose something -- two source columns differing only
  by case -- rule 3 refuses instead of quietly dropping one into the other.
* The upper-case tables already on a rig are NOT the reason.  Those were
  created by hand-written DDL; "it has always looked like that" is not a
  specification, and this rule does not rest on it.

Emitting the canonical identifier QUOTED is a no-op in Oracle -- ``"REGION"``
and unquoted ``REGION`` are the same identifier -- so both lanes may keep
quoting, which is what keeps the name safe to interpolate.

THE MIRROR, and why there is one
--------------------------------
The Spark job is a separate deployable: a different image, a different
process, no database, and it CANNOT import ``backend/core`` (the API image
copies ``backend/`` only; the job image's build context is ``spark/``).  So
this file exists TWICE, byte-identical, and a guard fails the suite the
moment the two copies differ:

    backend/core/feed/oracle_identifiers.py      <- authored here
    spark/jobs/qs_oracle_identifiers.py          <- mechanical copy

Guard: backend/tests/test_oracle_identifier_casing_2026_09_21.py.  It
byte-compares the two files AND drives both real call sites over one table
of cases, asserting the identifiers they put on the wire are EQUAL -- the
disagreement, not merely the value, because the symptom (ORA-00904 in some
other subsystem) surfaces nowhere near the writer that caused it.

Stdlib only, on purpose: it has to import under the API's Python and under
the Spark image's Python with nothing installed.
"""
from __future__ import annotations

import re
from typing import Any, Iterable, List, Optional, Sequence

#: The two paths this file occupies.  Both copies name both paths, which is
#: what makes the byte comparison the guard performs possible at all.
MIRROR_PATHS = (
    "backend/core/feed/oracle_identifiers.py",
    "spark/jobs/qs_oracle_identifiers.py",
)

#: Oracle's UNQUOTED identifier grammar: a letter, then letters, digits or
#: underscores.  A leading underscore is refused -- Oracle raises ORA-00911
#: on it, the same rule that cost this product every raw_sql Oracle feed on
#: the Spark lanes when the JDBC sub-query alias was ``_subq`` (2026-09-13).
_UNQUOTED_IDENTIFIER = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")

#: Oracle 12.2+ allows 128 bytes; earlier releases 30.  The longer bound is
#: the one this product's supported targets enforce.
ORACLE_MAX_IDENTIFIER_BYTES = 128


class OracleIdentifierError(ValueError):
    """A destination column cannot be named in Oracle.

    Deliberately a ``ValueError``: the native delivery's retry policy
    treats ValueError as a DETERMINISTIC configuration error and does not
    retry it.  A column name will still be illegal in sixty seconds.
    """


def canonical_oracle_identifier(name: Any) -> str:
    """The identifier Oracle itself would create for ``name``.

    Upper-cased, and REFUSED rather than mangled when it is not a legal
    unquoted Oracle identifier.
    """
    text = "" if name is None else str(name)
    if not _UNQUOTED_IDENTIFIER.match(text):
        raise OracleIdentifierError(
            f"Column name {text!r} cannot be created in Oracle: an "
            f"identifier must start with a letter and contain only "
            f"letters, digits and underscores. Rename it in the feed's "
            f"source query, or create the destination table yourself with "
            f"the name you want. Nothing was written.")
    if len(text.encode("utf-8")) > ORACLE_MAX_IDENTIFIER_BYTES:
        raise OracleIdentifierError(
            f"Column name {text!r} is "
            f"{len(text.encode('utf-8'))} bytes; Oracle's limit is "
            f"{ORACLE_MAX_IDENTIFIER_BYTES}. Nothing was written.")
    return text.upper()


def canonical_oracle_columns(source_columns: Iterable[Any]) -> List[str]:
    """Rule 2 + rule 3: the identifiers a CREATED table gets.

    Source order is preserved -- both lanes bind values positionally, so
    reordering the names to suit the target would write every value into
    the wrong column.
    """
    resolved: List[str] = []
    seen: dict = {}
    for col in source_columns:
        ident = canonical_oracle_identifier(col)
        if ident in seen:
            raise OracleIdentifierError(
                f"Source columns {seen[ident]!r} and {str(col)!r} are the "
                f"same Oracle identifier ({ident}) -- Oracle folds unquoted "
                f"names to upper case, so one table cannot hold both. Alias "
                f"one of them in the feed's source query. Nothing was "
                f"written.")
        seen[ident] = str(col)
        resolved.append(ident)
    return resolved


def adopt_table_spelling(source_columns: Iterable[Any],
                         table_columns: Sequence[Any],
                         table: str = "the destination table") -> List[str]:
    """Rule 1: an EXISTING table's own spelling wins on a case-only match.

    Refuses on a source column with no home (dropping it would shift every
    later value into the wrong column or silently write NULLs -- a delivery
    that "succeeded" with wrong data) and on a table holding two columns
    that differ only by case, where "case-insensitively" has no single
    answer.
    """
    by_lower: dict = {}
    ambiguous = set()
    for col in table_columns:
        text = str(col)
        key = text.lower()
        if key in by_lower and by_lower[key] != text:
            ambiguous.add(key)
        by_lower.setdefault(key, text)

    resolved: List[str] = []
    missing: List[str] = []
    for col in source_columns:
        key = str(col).lower()
        if key in ambiguous:
            raise OracleIdentifierError(
                f"Oracle delivery: {table} has more than one column spelled "
                f"{key!r} (differing only by case), so source column "
                f"{str(col)!r} has no unambiguous target. Nothing was "
                f"written.")
        match = by_lower.get(key)
        if match is None:
            missing.append(str(col))
        else:
            resolved.append(match)
    if missing:
        raise OracleIdentifierError(
            f"Oracle delivery: {table} has no column(s) matching "
            f"{missing} (case-insensitively). The table's columns are "
            f"{list(table_columns)}. Nothing was written.")
    return resolved


def resolve_oracle_columns(source_columns: Iterable[Any],
                           table_columns: Optional[Sequence[Any]] = None,
                           table: str = "the destination table") -> List[str]:
    """THE entry point both lanes call.

    ``table_columns`` is the destination table's own column list when the
    lane has read it, and ``None`` when the lane has not -- because the
    table does not exist yet, or because the lane leaves the match to the
    driver.  ``None`` therefore means "the canonical, created shape is the
    answer".

    Note what ``None`` is NOT: it is not "the table has no columns".  An
    EMPTY sequence is a table that WAS read and came back shapeless, which
    is a different thing and refuses through :func:`adopt_table_spelling`
    naming every source column as missing.  Unknown is not empty.
    """
    if table_columns is None:
        return canonical_oracle_columns(source_columns)
    return adopt_table_spelling(source_columns, table_columns, table)
