"""What a feed DRAFT would run -- the one cheap read the authoring form
makes while the author is still typing (2026-10-11).

The owner's two reports, both found in the UI:

* "no query selection in cross source" -- the feed form could pick a second
  CONNECTION but not what runs on it, and showed nothing of what the merge
  would do.
* "where clause not getting generic once we have saved queries" -- a query
  built in the query builder saves LITERAL filter values (``CODE =
  'SAP-2504'``); a feed, above all a template of 4,000 members, needs
  ``{SYSTEM_ENTITY}``.

:func:`resolve_draft` answers both from ONE body shaped like a feed
(source, connection, second side, ``query_params``, ``token_bindings``):

* each SIDE's SQL, resolved through the SAME resolver the run and the
  preview use (``core.feed_sql_resolver.resolve_feed_sql`` ->
  ``core.feed.source_plan``), so what the form shows is what runs;
* each side's LITERAL predicates (``core.feed.sql_tokens.literal_predicates``)
  with the draft's binding, if any, attached -- the author binds each to a
  token and the form stores ``token_bindings`` on the feed;
* the MERGE plan's disclosure (``core.feed.merge_by_name.plan_merge`` over the
  projections ``core.sql_output_columns`` reads offline): the output columns,
  the ones only one side has, the case renames, or the refusal / the reason
  it cannot tell (a ``SELECT *`` side);
* whether the primary saved query ALREADY carries its own second side (a
  BQB cross-source query) -- the ONE decision the form states: the feed runs
  it as saved; a second side declared on the feed REPLACES the query's own
  (``source_plan.inherit_cross_source``: explicit feed fields win).

:func:`bindings_problem` is the SAVE gate the feed routes apply: every
binding must be well-formed (``sql_tokens.validate_token_bindings``) AND
match a literal predicate in its side's SQL as it resolves NOW.  A binding
that no longer matches at RUN time refuses the run (``BindingRefused``,
raised by the renderer on every lane) -- a correctness gate must fail.

Read-only: no execution, no connector, no write.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

#: The feed fields a draft may carry; everything else is ignored.
DRAFT_FIELDS = (
    "id", "name", "source_type", "source_id", "connection_id", "query_params",
    "secondary_connection_id", "secondary_source_type", "secondary_source_id",
    "combine_mode", "join_config", "token_bindings",
)


def _draft_probe(draft: Dict[str, Any]) -> Dict[str, Any]:
    probe = {k: draft.get(k) for k in DRAFT_FIELDS if draft.get(k) is not None}
    probe.setdefault("query_params", {})
    return probe


def declared_parameters(draft: Dict[str, Any]) -> List[str]:
    """The scalar keys of ``query_params`` -- the parameters a ``{NAME}``
    token may name (``sql_tokens.declared_token_names`` reads the same)."""
    qp = draft.get("query_params") or {}
    if not isinstance(qp, dict):
        return []
    return sorted(k for k, v in qp.items()
                  if isinstance(v, (str, int, float, bool)) and not str(k).startswith("_")
                  and k not in ("sql", "secondary_raw_sql", "secondary"))


def _side_report(sql: Optional[str], status: Optional[str], message: Optional[str],
                 source_name: Optional[str], connection_id: Any,
                 connection_name: Optional[str], side: str,
                 bindings: List[dict]) -> Dict[str, Any]:
    from core.feed.sql_tokens import literal_predicates, _binding_side
    preds = literal_predicates(sql) if (sql and status == "ok") else []
    mine = {(str(b.get("column") or "").lower(), str(b.get("literal")))
            : b for b in bindings if _binding_side(b.get("side")) == side}
    rows = []
    for p in preds:
        b = mine.get((p["column"].lower(), p["literal"]))
        rows.append({
            "column": p["column"], "qualified": p["qualified"],
            "operator": p["operator"], "literal": p["literal"],
            "kind": p["kind"], "wrapper": p["wrapper"],
            "occurrences": p["occurrences"], "text": p["text"],
            "bound_to": (b.get("token") if b else None),
            "format": (b.get("format") if b else None),
        })
    return {
        "side": side,
        "status": status or ("ok" if sql else "empty"),
        "message": message or "",
        "source_name": source_name,
        "connection_id": connection_id,
        "connection_name": connection_name,
        "sql": sql or "",
        # Unknown is not empty: a statement the tokenizer could not read has
        # no predicates to OFFER, which is not "this query filters nothing".
        "predicates_readable": bool(sql and status == "ok"),
        "predicates": rows,
    }


def _merge_disclosure(primary_sql: Optional[str], secondary_sql: Optional[str],
                      combine_mode: Optional[str]) -> Dict[str, Any]:
    mode = (combine_mode or "union").strip().lower()
    if mode != "union":
        return {"rule": "join", "known": False,
                "reason": "a JOIN's output is the join's own projection; "
                          "the merge-by-name disclosure applies to UNION ALL"}
    if not primary_sql or not secondary_sql:
        return {"rule": "union_all_by_name", "known": False,
                "reason": "a side has no SQL yet"}
    from core.sql_output_columns import derive_columns_from_sql_text
    p_cols = [c["physical_name"] for c in derive_columns_from_sql_text(primary_sql)]
    s_cols = [c["physical_name"] for c in derive_columns_from_sql_text(secondary_sql)]
    missing = [lbl for lbl, cols in (("primary", p_cols), ("secondary", s_cols)) if not cols]
    if missing:
        return {"rule": "union_all_by_name", "known": False,
                "reason": (f"the {' and '.join(missing)} side's columns cannot be "
                           f"read from its SQL alone (a SELECT * or an unparseable "
                           f"statement); the run decides the merge from the "
                           f"materialised sides and refuses an incompatible column")}
    from core.feed.merge_by_name import MergeRefused, plan_merge
    try:
        plan = plan_merge(p_cols, s_cols)
    except MergeRefused as exc:
        return {"rule": "union_all_by_name", "known": True, "refused": str(exc)}
    except ValueError as exc:
        return {"rule": "union_all_by_name", "known": True, "refused": str(exc)}
    d = plan.disclosure()
    d["known"] = True
    d["output_columns"] = list(plan.names)
    d["types_known"] = False  # offline: names only; types are compared at run time
    return d


def _inherited_second_side(db, probe: Dict[str, Any]) -> Dict[str, Any]:
    """Does the PRIMARY source carry its own second side (a BQB cross-source
    saved query / published view / split sql_file)?  Reported whatever the
    draft declares, so the form can state the rule."""
    from core.feed.source_plan import inherit_cross_source
    scratch = {k: v for k, v in probe.items()
               if k not in ("secondary_connection_id", "secondary_source_type",
                            "secondary_source_id", "combine_mode", "join_config")}
    try:
        inherit_cross_source(db, scratch.get("source_type") or "",
                             scratch.get("source_id"), scratch)
    except ValueError as exc:
        return {"carries_second_side": None, "refusal": str(exc)}
    except Exception as exc:  # noqa: BLE001 -- a lookup failure is "could not tell"
        return {"carries_second_side": None, "reason": f"could not read the source: {exc}"}
    if scratch.get("secondary_connection_id"):
        return {
            "carries_second_side": True,
            "secondary_connection_id": scratch.get("secondary_connection_id"),
            "combine_mode": scratch.get("combine_mode") or "union",
            # THE rule, stated once: explicit feed fields win (source_plan).
            "rule": ("the feed runs the query as saved, combining its own two "
                     "sides; a second side declared on the feed REPLACES the "
                     "query's own second side -- it is never combined twice"),
            "feed_overrides": bool(probe.get("secondary_connection_id")),
        }
    return {"carries_second_side": False}


def resolve_draft(db, draft: Dict[str, Any]) -> Dict[str, Any]:
    """See the module docstring.  Never raises for a draft that does not
    resolve -- each side carries its status and message."""
    from core.feed.filename_renderer import _BUILTIN_DATE_FORMATS
    from core.feed.sql_tokens import DATE_TOKENS, BindingRefused, validate_token_bindings
    from core.feed_sql_resolver import resolve_feed_sql

    probe = _draft_probe(draft)
    raw_bindings = draft.get("token_bindings") or []
    declared = declared_parameters(probe)
    bindings_problem_text: Optional[str] = None
    try:
        bindings = validate_token_bindings(raw_bindings, declared=declared)
    except BindingRefused as exc:
        bindings = [b for b in raw_bindings if isinstance(b, dict)]
        bindings_problem_text = str(exc)

    preview = resolve_feed_sql(db, probe)
    is_cross = bool(preview.get("secondary_connection_id")) or bool(preview.get("combine_mode"))
    primary = _side_report(
        preview.get("sql"), preview.get("source_status"), preview.get("source_message"),
        preview.get("source_name"), preview.get("connection_id"),
        preview.get("connection_name"), "primary", bindings)
    secondary = None
    if is_cross:
        secondary = _side_report(
            preview.get("secondary_sql"), preview.get("secondary_source_status"),
            preview.get("secondary_source_message"), preview.get("secondary_source_name"),
            preview.get("secondary_connection_id"), preview.get("secondary_connection_name"),
            "secondary", bindings)

    # Every binding's verdict against the SQL that resolves NOW.
    verdicts = []
    for b in bindings:
        side = secondary if (str(b.get("side") or "").lower() == "secondary") else primary
        if side is None:
            verdicts.append({**b, "matched": False,
                             "reason": "the feed has no second side"})
            continue
        hit = next((p for p in side["predicates"]
                    if p["column"].lower() == str(b.get("column") or "").lower()
                    and p["literal"] == str(b.get("literal"))), None)
        if hit is None:
            verdicts.append({**b, "matched": False,
                             "reason": (f"no predicate {b.get('column')} <op> "
                                        f"{b.get('literal')!r} in the {side['side']} "
                                        f"side's SQL" if side["predicates_readable"]
                                        else f"the {side['side']} side's SQL could not be read")})
        else:
            verdicts.append({**b, "matched": True, "occurrences": hit["occurrences"]})

    merge = (_merge_disclosure(primary["sql"] if primary["status"] == "ok" else None,
                               (secondary or {}).get("sql") if (secondary or {}).get("status") == "ok" else None,
                               preview.get("combine_mode"))
             if is_cross else None)

    return {
        "is_cross": is_cross,
        # 2026-10-12 -- every {TOKEN} the query uses, by KIND: a calendar
        # date, an upstream-message value (per environment), or a PARAMETER
        # the feed must give a value (query_params)
        "query_tokens": query_tokens(primary, secondary, probe),
        "combine_mode": (preview.get("combine_mode") or ("union" if is_cross else None)),
        "primary": primary,
        "secondary": secondary,
        "merge": merge,
        "inherited": _inherited_second_side(db, probe),
        "bindings": verdicts,
        "bindings_problem": bindings_problem_text,
        "tokens": {
            "date_tokens": sorted(DATE_TOKENS),
            "parameters": declared,
            "date_formats": sorted(_BUILTIN_DATE_FORMATS),
        },
    }


def query_tokens(primary: Optional[Dict[str, Any]], secondary: Optional[Dict[str, Any]],
                 draft: Dict[str, Any]) -> List[Dict[str, Any]]:
    """``[{name, format, kind, sides, value, has_value}]`` -- every token the
    sides' SQL uses.  ``kind``: ``date`` (the calendar fills it),
    ``message`` (the environment's upstream message fills it --
    feed_message_tokens), ``parameter`` (the feed's query_params must)."""
    from core.feed import upstream_contract as _uc
    from core.feed.sql_tokens import DATE_TOKENS, tokens_in
    msg = {t.lower() for t in (_uc.token_names() or [])}
    params = draft.get("query_params") or {}
    out: Dict[str, Dict[str, Any]] = {}
    for side in (primary, secondary):
        if not side or side.get("status") != "ok":
            continue
        for t in tokens_in(side.get("sql")):
            row = out.setdefault(t["name"], {"name": t["name"], "format": t["format"], "sides": []})
            row["sides"].append(side["side"])
    for name, row in out.items():
        if name in DATE_TOKENS:
            row["kind"] = "date"
        elif name.lower() in msg:
            row["kind"] = "message"
        else:
            row["kind"] = "parameter"
        val = params.get(name) if isinstance(params, dict) else None
        row["value"] = val if isinstance(val, (str, int, float, bool)) else None
        row["has_value"] = row["kind"] != "parameter" or row["value"] not in (None, "")
    return list(out.values())


def missing_parameters_problem(db, feed_shape: Dict[str, Any]) -> Optional[str]:
    """The SAVE gate for a query's PARAMETER tokens (2026-10-12): a feed whose
    SQL uses ``{NAME}`` with no value in ``query_params`` is refused naming
    them -- at run time the token would be left as written, match nothing and
    certify an empty file (or refuse every run).  None when every parameter
    has a value, or the SQL cannot be read now (said by the source checks)."""
    try:
        report = resolve_draft(db, feed_shape)
    except Exception:                                   # noqa: BLE001 -- unreadable: the source checks say it
        return None
    missing = [t["name"] for t in report.get("query_tokens") or []
               if t["kind"] == "parameter" and not t["has_value"]]
    if not missing:
        return None
    return (f"the query uses parameter token(s) {', '.join('{' + m + '}' for m in missing)} with no "
            f"value: give each a value in the feed's parameters (query_params) -- e.g. "
            f"{missing[0]}=<value>; a calendar date token ({{BUSINESSDATE}}) and an upstream "
            f"message token ({{version}}) are filled by the run itself.")


def bindings_problem(db, feed_shape: Dict[str, Any]) -> Optional[str]:
    """The SAVE gate: None when every binding is well-formed and matches a
    literal predicate of its side's SQL as it resolves now; else ONE sentence
    naming the first fault (the route turns it into a 422)."""
    from core.feed.sql_tokens import BindingRefused, validate_token_bindings
    raw = feed_shape.get("token_bindings")
    if not raw:
        return None
    try:
        bindings = validate_token_bindings(raw, declared=declared_parameters(feed_shape))
    except BindingRefused as exc:
        return str(exc)
    report = resolve_draft(db, {**feed_shape, "token_bindings": bindings})
    for v in report["bindings"]:
        if not v.get("matched"):
            return (f"token binding {v.get('column')} = {v.get('literal')!r} -> "
                    f"{{{v.get('token')}}} ({v.get('side')} side) cannot be applied: "
                    f"{v.get('reason')}.  A binding must name a literal predicate "
                    f"the side's SQL holds, or the run would deliver the literal "
                    f"with a green status.")
    return None
