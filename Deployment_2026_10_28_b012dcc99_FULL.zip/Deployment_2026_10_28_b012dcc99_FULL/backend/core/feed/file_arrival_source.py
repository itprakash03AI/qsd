"""The FILE arrival source -- "the upstream's files for date D have landed"
(2026-10-07).

THE DEFECT THIS CLOSES
----------------------
The ``file`` kind was in the arrival-source vocabulary
(``core/feed/arrival_sources.py``) and its evaluator looked for a
``dependency_events`` row with source ``file`` -- but NOTHING in production
wrote one.  A feed held at WAIT on a file dependency waited until
``etl_dep_wait_escalation_hours`` (48) and failed.  BUILT, not WIRED.  In the
incumbent OG system "a data file plus its .ctl / READY control file has
landed" is a standard upstream signal; this module is its producer.

THE PIPELINE (the Kafka and Iceberg-commit sources' shape)
----------------------------------------------------------
    feed_dependency_file_watch tick (scheduler-owned, every
      feed_generation.dependency_file.interval_seconds)
      -> watch_tick: every pending WAIT run inside the look-back window
         whose dependencies DECLARE a ``file`` source
      -> render the declared path / pattern / control file for the run's
         business date (the filename renderer's own tokens, nothing else)
      -> LIST the location through the product's ONE S3 client path
         (``core.s3_utilities.make_s3_client_for_conn`` -- the cached handler
         every S3 read uses: credentials, region, VPCE, SSL) or, for a
         ``local`` connection, its base_path
      -> files (and the control file, when declared) present:
         record_dependency_arrival(source="file") -- the SAME ledger
      -> the ONE gate (etl_dependency.evaluate_gate_verdicts via
         arrival_sources) reads it back; the existing poller flips
         WAIT -> RUN.  Nothing else in the release path changes.

Four rules, enforced here rather than hoped for:

1.  **Unknown is not absent.**  A LIST that fails, a connection that cannot
    be read, a local base_path that is not mounted, or a LIST that stops at
    its key budget BEFORE the requirement is met is UNREADABLE: the
    observation says so and the gate reports COULD NOT TELL -- never MET,
    and never NOT MET either.  (Presence found inside a budget-stopped
    listing IS proof; absence inside one is not.)
2.  **One arrival per (dependency, date, declared source).**  The tick
    skips a target the ledger already holds an arrival for; the arrival's
    identity is a digest of the matched keys, sizes and LastModified, so
    two pods racing the same files classify as a REDELIVERY, not a replay.
3.  **Bounded.**  One prefix LIST per target per tick (no recursion beyond
    what a prefix LIST returns), at most ``max_keys`` keys; only WAIT runs
    inside ``lookback_days``; one client per connection per tick.
4.  **What it is waiting for is said.**  The evaluator renders the declared
    location for the date and puts it in the reason (the Today page's WAIT
    chip, the dependency panel, the blocking route), with the latest
    observation -- "last looked at T: 3 data files, control READY absent".
"""
from __future__ import annotations

import fnmatch
import hashlib
import json
import logging
import os
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Callable, Dict, List, Mapping, Optional, Tuple

from core.feed.dependency_gate import MET, NOT_MET, UNKNOWN

logger = logging.getLogger(__name__)

LEDGER_SOURCE = "file"

STATUS_PRESENT = "present"
STATUS_ABSENT = "absent"
STATUS_PARTIAL = "partial"
STATUS_UNREADABLE = "unreadable"

#: Every key a ``file`` declaration may carry.  Anything else is REFUSED at
#: authoring: a misspelt ``control_fle`` silently ignored would be a feed
#: released on the data file alone, without the READY its author asked for.
SPEC_KEYS = ("kind", "connection_id", "path", "pattern", "control_file",
             "min_files")

#: The renderer's tokens that NAME THE BUSINESS DATE -- the only ones a
#: watched path may use.  A dependency is evaluated per (dependency,
#: business date); ``{run_date}`` / a bare ``${YYYYMMDD}`` name the day the
#: run executes, which differs per feed and per re-run, so the gate could
#: never re-derive the location it is waiting on.
_BUSINESS_DATE_BRACE = ("business_date", "cob", "me_business_date")
_BUSINESS_DATE_FUNCTIONS = ("BUSINESS_DATE", "COB_BUSINESS_DATE")

#: How many matched objects an evidence record lists by name.
_EVIDENCE_FILES = 50

_LOCAL_TYPES = ("local",)
_S3 = "s3://"


class FileSpecRefused(ValueError):
    """A ``file`` declaration that cannot be stored, with the reason."""


def _today_utc() -> date:
    """The clock the look-back window is judged against (a seam for tests)."""
    return datetime.now(timezone.utc).date()


def load_config() -> Dict[str, Any]:
    """The declared ``feed_generation.dependency_file`` block."""
    try:
        from core.config import get as _cfg_get
        raw = _cfg_get("feed_generation", "dependency_file", {}) or {}
    except ImportError:
        raw = {}
    if not isinstance(raw, Mapping):
        raw = {}

    def _int(name: str, default: int, lo: int, hi: int) -> int:
        try:
            v = int(raw.get(name, default))
        except (TypeError, ValueError):
            v = default
        return max(lo, min(hi, v))

    return {
        "enabled": bool(raw.get("enabled", True)),
        "interval_seconds": _int("interval_seconds", 60, 10, 86400),
        "lookback_days": _int("lookback_days", 7, 0, 3660),
        "max_keys": _int("max_keys", 1000, 1, 100000),
    }


# ── The declaration ───────────────────────────────────────────────────────

def _check_template(field_name: str, value: str, where: str) -> bool:
    """Refuse a template the filename renderer cannot render exactly, or
    that names anything but the business date.  Returns whether it names
    the business date at all."""
    from core.feed.filename_renderer import (
        template_tokens, template_vocabulary, unknown_template_tokens,
    )
    unknown = unknown_template_tokens(value)
    if unknown:
        raise FileSpecRefused(
            f"{where}.{field_name}={value!r} names {', '.join(unknown)}, which "
            f"the filename renderer does not know. {template_vocabulary()}")
    parsed = template_tokens(value)
    stray = str(parsed["stray"])
    if "{" in stray or "}" in stray or "${" in stray:
        raise FileSpecRefused(
            f"{where}.{field_name}={value!r} contains a brace that is not a "
            f"renderer token, so it would be listed LITERALLY. Date formats "
            f"are the renderer's codes -- {{business_date:YYYYMMDD}} or "
            f"${{COB_BUSINESS_DATE(YYYY-MM-DD)}} -- not strftime (%Y%m%d)")
    found = False
    for tok in parsed["tokens"]:
        name = str(tok["name"])
        is_bd = ((tok["syntax"] == "brace" and name in _BUSINESS_DATE_BRACE)
                 or (tok["syntax"] == "dollar" and name in _BUSINESS_DATE_FUNCTIONS))
        if not is_bd:
            raise FileSpecRefused(
                f"{where}.{field_name}={value!r}: {tok['token']} is not the "
                f"business date. A file dependency is evaluated per business "
                f"date, so its location may use only {{business_date[:FMT]}} "
                f"(or {{cob}} / {{me_business_date}}) and "
                f"${{BUSINESS_DATE(FMT)}} / ${{COB_BUSINESS_DATE(FMT)}} -- a "
                f"run date, a feed name or a sequence differs per feed and per "
                f"re-run, and the gate could not say what it is waiting for")
        if not tok["format_known"]:
            raise FileSpecRefused(
                f"{where}.{field_name}={value!r}: {tok['token']} names the "
                f"date format {tok['arg']!r}, which the renderer does not know "
                f"(it would render YYYYMMDD instead). {template_vocabulary()}")
        found = True
    return found


def _blank_to_none(raw: Any) -> Optional[str]:
    if raw is None:
        return None
    text = str(raw).strip()
    return text or None


def _clean_path(raw: Any, where: str) -> str:
    path = str(raw).strip()
    if not path.lower().startswith(_S3):
        path = path.lstrip("/")
    if not path:
        raise FileSpecRefused(f"{where} (file) path is empty")
    if ".." in path.replace("\\", "/").split("/"):
        raise FileSpecRefused(
            f"{where} (file) path {path!r} climbs out of its root with '..'")
    return path


def _clean_min_files(raw: Any, has_control: bool, where: str) -> Optional[int]:
    if _blank_to_none(raw) is None:
        return None
    try:
        min_files = int(raw)
    except (TypeError, ValueError):
        raise FileSpecRefused(
            f"{where} (file) min_files={raw!r} is not a whole number")
    floor = 0 if has_control else 1
    if min_files < floor or min_files > 100000:
        hint = ("" if has_control else
                " (0 -- 'the control file alone' -- needs a control_file)")
        raise FileSpecRefused(
            f"{where} (file) min_files={min_files} must be between "
            f"{floor} and 100000{hint}")
    return min_files


def normalise_declaration(entry: Mapping[str, Any], norm: Dict[str, Any],
                          where: str) -> Dict[str, Any]:
    """The ``file`` kind's authoring check (called by
    ``arrival_sources.parse_arrival_sources`` after the generic parameter
    pass).  Pure: no database.  ``norm`` already carries ``connection_id``
    (int) and ``path`` (str); the optional ``pattern`` / ``control_file`` /
    ``min_files`` are typed here.  Raises :class:`FileSpecRefused`."""
    unknown = sorted(str(k) for k in entry.keys() if str(k) not in SPEC_KEYS)
    if unknown:
        raise FileSpecRefused(
            f"{where} (file) has unknown key(s) {unknown}; a file source "
            f"takes {list(SPEC_KEYS[1:])}")
    out: Dict[str, Any] = {"kind": norm["kind"],
                           "connection_id": int(norm["connection_id"]),
                           "path": _clean_path(norm["path"], where)}
    for name in ("pattern", "control_file"):
        text = _blank_to_none(entry.get(name))
        if text is None:
            continue
        if "/" in text or "\\" in text:
            raise FileSpecRefused(
                f"{where} (file) {name}={text!r} is matched against a file "
                f"NAME; put the folder in path")
        out[name] = text
    min_files = _clean_min_files(entry.get("min_files"),
                                 bool(out.get("control_file")), where)
    if min_files is not None:
        out["min_files"] = min_files
    names_date = False
    for name in ("path", "pattern", "control_file"):
        if out.get(name):
            names_date = _check_template(name, out[name], where) or names_date
    if not names_date:
        raise FileSpecRefused(
            f"{where} (file) names no business-date token in path, pattern "
            f"or control_file, so yesterday's files would satisfy every later "
            f"day -- e.g. path 'landing/gl/{{business_date:YYYYMMDD}}/'")
    return out


def effective_spec(spec: Mapping[str, Any]) -> Dict[str, Any]:
    """The declaration with its defaults applied -- what is watched."""
    raw_min = spec.get("min_files")
    return {
        "connection_id": int(spec.get("connection_id")),
        "path": str(spec.get("path") or ""),
        "pattern": str(spec.get("pattern") or "*"),
        "control_file": (str(spec.get("control_file")) if spec.get("control_file")
                         else None),
        "min_files": int(raw_min) if raw_min not in (None, "") else 1,
    }


def is_watchable(spec: Mapping[str, Any]) -> bool:
    """A declaration the watcher can act on (a ``{"kind": "file"}`` stored
    before 2026-10-07 names no location)."""
    try:
        int(spec.get("connection_id"))
    except (TypeError, ValueError):
        return False
    return bool(str(spec.get("path") or "").strip())


def spec_key(spec: Mapping[str, Any]) -> str:
    """A stable digest of the declaration: two file sources on one
    dependency are two keys; re-saving the same declaration is the same."""
    blob = json.dumps(effective_spec(spec), sort_keys=True)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:24]


def _s3_bucket_refusal(conn: Mapping[str, Any], path: str) -> Optional[str]:
    bucket = _bucket_of(conn.get("config") or {})
    label = f"connection {conn.get('id')} ({conn.get('name')})"
    if not bucket:
        return f"{label} names no bucket, so there is nothing to list"
    if path.lower().startswith(_S3):
        named = path[len(_S3):].split("/", 1)[0]
        if named.lower() != bucket.lower():
            return (f"path {path!r} names bucket {named!r}, but {label} reads "
                    f"bucket {bucket!r} -- one bucket, one connection")
    return None


def validate_against_connection(db: Any, spec: Mapping[str, Any]) -> Optional[str]:
    """The authoring check that needs the database: the connection must
    exist and be S3 (or ``local`` with a base_path), and an ``s3://`` path
    must name that connection's bucket.  Returns the refusal, or None."""
    from core.connection_duplicates import is_s3_type
    conn_id = int(spec["connection_id"])
    conn = db.get_connection_raw(conn_id)
    if not conn or conn.get("is_active") is False:
        return f"connection {conn_id} does not exist"
    ctype = str(conn.get("connection_type") or "").strip().lower()
    cfg = conn.get("config") or {}
    if is_s3_type(ctype):
        return _s3_bucket_refusal(conn, str(spec.get("path") or ""))
    if ctype in _LOCAL_TYPES:
        if not str(cfg.get("base_path") or "").strip():
            return (f"connection {conn_id} ({conn.get('name')}) is local but "
                    f"has no base_path")
        return None
    return (f"connection {conn_id} ({conn.get('name')}) is {ctype or '?'}; a "
            f"file source lists an S3 bucket or a local/NFS base_path")


# ── Rendering ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class RenderedSpec:
    path: str
    pattern: str
    control_file: Optional[str]
    min_files: int


def render_spec(spec: Mapping[str, Any], business_date: date) -> RenderedSpec:
    """The declaration rendered for one business date by THE filename
    renderer.  ``run_date`` is set to the business date only because the
    context requires one; authoring refuses every token that would read it."""
    from core.feed.filename_renderer import FilenameRenderer, RenderContext
    eff = effective_spec(spec)
    renderer = FilenameRenderer()
    ctx = RenderContext(run_date=business_date, business_date=business_date)
    ctl = eff["control_file"]
    return RenderedSpec(
        path=renderer.render(eff["path"], ctx),
        pattern=renderer.render(eff["pattern"], ctx),
        control_file=renderer.render(ctl, ctx) if ctl else None,
        min_files=int(eff["min_files"]),
    )


def _bucket_of(cfg: Mapping[str, Any]) -> str:
    return str(cfg.get("bucket_name") or cfg.get("bucket") or "").strip()


@dataclass(frozen=True)
class Location:
    kind: str             # "s3" | "local"
    label: str            # what the operator reads: s3://bucket/prefix
    bucket: str = ""
    prefix: str = ""
    base_path: str = ""


def resolve_location(conn: Mapping[str, Any], rendered_path: str) -> Location:
    """Where a rendered path lives on its connection.  Raises ValueError
    when the connection cannot carry one (the caller's could-not-tell)."""
    from core.connection_duplicates import is_s3_type
    ctype = str(conn.get("connection_type") or "").strip().lower()
    cfg = conn.get("config") or {}
    if is_s3_type(ctype):
        bucket = _bucket_of(cfg)
        prefix = rendered_path
        if prefix.lower().startswith(_S3):
            bucket, _, prefix = prefix[len(_S3):].partition("/")
        if not bucket:
            raise ValueError(f"connection {conn.get('id')} names no bucket")
        return Location("s3", f"{_S3}{bucket}/{prefix}", bucket=bucket,
                        prefix=prefix)
    if ctype in _LOCAL_TYPES:
        base = str(cfg.get("base_path") or "").strip()
        if not base:
            raise ValueError(f"connection {conn.get('id')} has no base_path")
        return Location("local", f"{base.rstrip('/')}/{rendered_path}",
                        prefix=rendered_path, base_path=base)
    raise ValueError(f"connection {conn.get('id')} is {ctype or '?'}, not S3 "
                     f"or local")


# ── Listing (bounded; through the ONE client path) ────────────────────────

@dataclass
class Listing:
    objects: List[Dict[str, Any]] = field(default_factory=list)
    truncated: bool = False


def _iso(value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc).isoformat()
    return str(value)


def list_s3(client: Any, bucket: str, prefix: str, max_keys: int) -> Listing:
    """ONE prefix LIST (paged only up to ``max_keys`` keys).  Raises on a
    transport/permission failure -- the caller records UNREADABLE."""
    out = Listing()
    token: Optional[str] = None
    while True:
        kwargs: Dict[str, Any] = {"Bucket": bucket, "Prefix": prefix,
                                  "MaxKeys": max(1, min(1000, max_keys - len(out.objects)))}
        if token:
            kwargs["ContinuationToken"] = token
        page = client.list_objects_v2(**kwargs)
        for obj in page.get("Contents") or []:
            out.objects.append({"key": obj.get("Key"),
                                "size": int(obj.get("Size") or 0),
                                "last_modified": _iso(obj.get("LastModified"))})
        more = bool(page.get("IsTruncated"))
        token = page.get("NextContinuationToken")
        if not more or not token:
            return out
        if len(out.objects) >= max_keys:
            out.truncated = True
            return out


def _local_walk_root(base: Path, rel_prefix: str) -> Path:
    """The folder a local prefix LIST walks: the prefix itself when it names
    a folder, else its parent (and the prefix filters names)."""
    start = (base / rel_prefix).resolve() if rel_prefix else base
    try:
        start.relative_to(base)
    except ValueError:
        raise PermissionError(f"{rel_prefix!r} resolves outside base_path")
    return start if (rel_prefix.endswith("/") or start.is_dir()) else start.parent


def list_local(base_path: str, prefix: str, max_keys: int) -> Listing:
    """The local/NFS equivalent of a prefix LIST under the connection's
    base_path, with the same traversal guard the landed-file step applies.
    An absent or unmounted base_path RAISES (unreadable); an absent folder
    under it is simply empty."""
    from core.connection_manager import _normalize_path
    base = _normalize_path(base_path).resolve()
    if not base.is_dir():
        raise FileNotFoundError(
            f"base_path {base_path} is not a readable directory on this pod "
            f"(not mounted?)")
    rel_prefix = prefix.replace("\\", "/")
    walk_root = _local_walk_root(base, rel_prefix)
    out = Listing()
    if not walk_root.is_dir():
        return out
    for dirpath, dirnames, filenames in os.walk(walk_root):
        dirnames.sort()
        for name in sorted(filenames):
            p = Path(dirpath) / name
            rel = p.relative_to(base).as_posix()
            if not rel.startswith(rel_prefix):
                continue
            if len(out.objects) >= max_keys:
                out.truncated = True
                return out
            st = p.stat()
            out.objects.append({
                "key": rel, "size": int(st.st_size),
                "last_modified": datetime.fromtimestamp(
                    st.st_mtime, timezone.utc).isoformat()})
    return out


def _default_s3_client(conn: Mapping[str, Any]) -> Any:
    """THE product's S3 client for a connection -- the cached handler every
    S3 read uses (credentials, region, VPCE, SSL).  Never a second client."""
    from core.s3_utilities import make_s3_client_for_conn
    return make_s3_client_for_conn(dict(conn))


# ── Observing one declared source ─────────────────────────────────────────

@dataclass
class Observation:
    status: str
    location: str
    reason: str
    data: List[Dict[str, Any]] = field(default_factory=list)
    control: List[Dict[str, Any]] = field(default_factory=list)
    truncated: bool = False

    def evidence(self, rendered: Optional[RenderedSpec] = None) -> Dict[str, Any]:
        ev: Dict[str, Any] = {
            "location": self.location,
            "file_count": len(self.data),
            "total_bytes": sum(int(o.get("size") or 0) for o in self.data),
            "files": self.data[:_EVIDENCE_FILES],
            "files_listed_in_full": len(self.data) <= _EVIDENCE_FILES,
            "control": self.control[:10],
            "listing_truncated": self.truncated,
        }
        if rendered is not None:
            ev.update(pattern=rendered.pattern,
                      control_file=rendered.control_file,
                      min_files=rendered.min_files)
        return ev


def _basename(key: str) -> str:
    return str(key or "").rstrip("/").rsplit("/", 1)[-1]


def _split_matches(listing: Listing, rendered: RenderedSpec
                   ) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """(data files matching the pattern, control files) -- folder markers
    and hidden (in-flight temp) names are neither; a control file is never
    also counted as data."""
    data: List[Dict[str, Any]] = []
    control: List[Dict[str, Any]] = []
    for obj in listing.objects:
        key = str(obj.get("key") or "")
        name = _basename(key)
        if not key or key.endswith("/") or name.startswith("."):
            continue
        if rendered.control_file and fnmatch.fnmatchcase(name, rendered.control_file):
            control.append(obj)
        elif fnmatch.fnmatchcase(name, rendered.pattern):
            data.append(obj)
    return data, control


def classify(listing: Listing, rendered: RenderedSpec,
             location: str) -> Observation:
    """Decide present / absent / partial / unreadable from one listing."""
    data, control = _split_matches(listing, rendered)
    want_ctl = bool(rendered.control_file)
    enough = len(data) >= rendered.min_files
    ctl_ok = (not want_ctl) or bool(control)
    what = (f"{len(data)} data file(s) matching {rendered.pattern!r}"
            + (f", control file {rendered.control_file!r} "
               + ("found" if control else "absent") if want_ctl else ""))
    if enough and ctl_ok:
        return Observation(STATUS_PRESENT, location,
                           f"{what} under {location}", data, control,
                           listing.truncated)
    if listing.truncated:
        return Observation(
            STATUS_UNREADABLE, location,
            f"the listing of {location} stopped at its key budget "
            f"(feed_generation.dependency_file.max_keys) before the "
            f"requirement was met -- {what} among the keys listed, and what "
            f"was not listed is unknown; narrow the path or raise max_keys",
            data, control, True)
    if not data and not control:
        return Observation(STATUS_ABSENT, location,
                           f"nothing under {location} matches -- {what}",
                           data, control)
    missing = []
    if not enough:
        missing.append(f"{rendered.min_files - len(data)} more data file(s) "
                       f"matching {rendered.pattern!r} (need {rendered.min_files})")
    if not ctl_ok:
        missing.append(f"the control file {rendered.control_file!r}")
    return Observation(STATUS_PARTIAL, location,
                       f"{what} under {location}; still missing "
                       + " and ".join(missing), data, control)


def observe(db: Any, spec: Mapping[str, Any], business_date: date, *,
            max_keys: int,
            s3_client_factory: Optional[Callable[[Mapping[str, Any]], Any]] = None,
            client_cache: Optional[Dict[int, Any]] = None,
            ) -> Tuple[Observation, Optional[RenderedSpec]]:
    """List one declared source for one date.  Never raises: every failure
    is an UNREADABLE observation carrying its reason."""
    try:
        rendered = render_spec(spec, business_date)
    except Exception as exc:  # noqa: BLE001 -- one verdict: unreadable
        return (Observation(STATUS_UNREADABLE, str(spec.get("path")),
                            f"the declared path could not be rendered for "
                            f"{business_date.isoformat()}: {exc}"), None)
    conn, problem = _usable_connection(db, int(spec.get("connection_id")))
    if problem is not None:
        return Observation(STATUS_UNREADABLE, rendered.path, problem), rendered
    try:
        loc = resolve_location(conn, rendered.path)
    except ValueError as exc:
        return Observation(STATUS_UNREADABLE, rendered.path, str(exc)), rendered
    try:
        listing = _list_location(loc, conn, max_keys, s3_client_factory,
                                 client_cache if client_cache is not None else {})
    except Exception as exc:  # noqa: BLE001 -- unknown != absent
        return (Observation(STATUS_UNREADABLE, loc.label,
                            f"listing {loc.label} failed -- "
                            f"{type(exc).__name__}: {exc}"), rendered)
    return classify(listing, rendered, loc.label), rendered


def _usable_connection(db: Any, conn_id: int
                       ) -> Tuple[Optional[Mapping[str, Any]], Optional[str]]:
    """(connection, None) or (None, why it cannot be listed through)."""
    try:
        conn = db.get_connection_raw(conn_id)
    except Exception as exc:  # noqa: BLE001
        return None, f"connection {conn_id} could not be read: {exc}"
    if not conn:
        return None, f"connection {conn_id} no longer exists"
    if conn.get("is_active") is False:
        # A deleted connection is soft-deleted: the record (and its
        # credentials) still read back, and listing through it would keep
        # a removed source quietly releasing feeds.
        return None, (f"connection {conn_id} ({conn.get('name')}) has been "
                      f"deleted -- re-point the dependency")
    return conn, None


def _list_location(loc: Location, conn: Mapping[str, Any], max_keys: int,
                   s3_client_factory: Optional[Callable[[Mapping[str, Any]], Any]],
                   cache: Dict[int, Any]) -> Listing:
    """LIST one location; raises on any failure (the caller's unreadable)."""
    if loc.kind != "s3":
        return list_local(loc.base_path, loc.prefix, max_keys)
    conn_id = int(conn.get("id") or 0)
    client = cache.get(conn_id)
    if client is None:
        client = (s3_client_factory or _default_s3_client)(conn)
        if client is None:
            raise RuntimeError("no S3 client could be built")
        cache[conn_id] = client
    return list_s3(client, loc.bucket, loc.prefix, max_keys)


def arrival_identity(obs: Observation) -> str:
    """Deterministic over WHAT matched: the same files observed twice (two
    pods, a retry) are a redelivery to the ledger, a changed set a replay."""
    lines = sorted(f"{o.get('key')}|{o.get('size')}|{o.get('last_modified')}"
                   for o in obs.data + obs.control)
    digest = hashlib.sha256("\n".join(lines).encode("utf-8")).hexdigest()[:16]
    return f"file:{obs.location[:440]}@{digest}"


def _matching_arrivals(events: List[Mapping[str, Any]], key: Optional[str]
                       ) -> List[Mapping[str, Any]]:
    """Ledger rows from THIS declared source.  An arrival carrying no key
    (written by an operator or another producer) counts for every file
    source of the dependency.  The key is the row's ``source_key``
    (2026-10-08, the ledger's own column) or, for rows written before it
    existed, the ``spec_key`` in the payload."""
    from core.feed.ledger import same_source_rows
    out = []
    for e in same_source_rows(
            [e for e in events or []
             if str(e.get("source") or "") == LEDGER_SOURCE], key):
        if e.get("source_key"):
            out.append(e)
            continue
        payload = e.get("payload") if isinstance(e.get("payload"), Mapping) else {}
        sk = payload.get("spec_key")
        if sk is None or key is None or sk == key:
            out.append(e)
    return out


def _record_arrival(db: Any, name: str, business_date: date, key: str,
                    spec: Mapping[str, Any], obs: Observation,
                    rendered: RenderedSpec) -> bool:
    from core.feed.ledger import record_dependency_arrival
    payload = {"spec_key": key, "connection_id": int(spec["connection_id"]),
               **obs.evidence(rendered)}
    result = record_dependency_arrival(
        db, dependency_name=name, business_date=business_date,
        source=LEDGER_SOURCE, message_identity=arrival_identity(obs),
        payload=payload, source_key=key)
    return bool(result.recorded)


# ── The tick ──────────────────────────────────────────────────────────────

def _as_date(raw: Any) -> Optional[date]:
    if isinstance(raw, datetime):
        return raw.date()
    if isinstance(raw, date):
        return raw
    if isinstance(raw, str) and raw:
        try:
            return date.fromisoformat(raw[:10])
        except ValueError:
            return None
    return None


def _in_window(d: date, today: date, lookback_days: int) -> bool:
    return (today - timedelta(days=lookback_days)) <= d <= (today + timedelta(days=1))


def _waiting_pairs(runs: List[Mapping[str, Any]], today: date, lookback: int,
                   summary: Dict[str, Any]) -> List[Tuple[int, date]]:
    """(effective etl_id, business date) of every WAIT run in the window."""
    pairs = set()
    for run in runs:
        bd = _as_date(run.get("business_date"))
        etl = run.get("etl_id")
        if (str(run.get("action_decision") or "").upper() != "WAIT"
                or bd is None or etl is None
                or not _in_window(bd, today, lookback)):
            continue
        summary["runs_waiting"] += 1
        pairs.add((int(etl), bd))
    return sorted(pairs)


def _file_specs(rows: List[Mapping[str, Any]]):
    """(dependency name, spec) for every watchable ``file`` declaration on
    rows an operator has not already asserted (SKIP)."""
    from core.feed.arrival_sources import KIND_FILE, declared_sources
    from core.feed.dependency_gate import ACTION_SKIP
    for row in rows:
        if str(row.get("action") or "").upper() == ACTION_SKIP:
            continue
        name = str(row.get("dependency_key") or "")
        for spec in declared_sources(row):
            if spec.get("kind") == KIND_FILE and is_watchable(spec):
                yield name, spec


def _targets(db: Any, runs: List[Mapping[str, Any]], today: date,
             lookback: int, summary: Dict[str, Any]
             ) -> Dict[Tuple[str, date, str], Dict[str, Any]]:
    targets: Dict[Tuple[str, date, str], Dict[str, Any]] = {}
    for etl, bd in _waiting_pairs(runs, today, lookback, summary):
        try:
            rows = db.list_etl_dependency_mappings_with_tracking(etl, bd)
        except Exception as exc:  # noqa: BLE001 -- one feed's rows, not the pass
            summary["errors"] += 1
            logger.error("[file_arrival] mappings for etl_id %s @ %s unreadable: "
                         "%s", etl, bd, exc)
            continue
        for name, spec in _file_specs(rows):
            targets.setdefault((name, bd, spec_key(spec)), spec)
    return targets


def _new_summary() -> Dict[str, Any]:
    return {"status": "ran", "runs_waiting": 0, "targets": 0, "looked": 0,
            "arrivals": 0, "already_arrived": 0, "waiting": 0,
            "unreadable": 0, "errors": 0, "detail": []}


def watch_tick(db: Any, *, today: Optional[date] = None,
               cfg: Optional[Mapping[str, Any]] = None,
               s3_client_factory: Optional[Callable[[Mapping[str, Any]], Any]] = None,
               ) -> Dict[str, Any]:
    """One pass: look for the files every waiting run's ``file`` sources
    declare, record an arrival for each that has landed.  Never raises."""
    cfg = dict(cfg) if cfg is not None else load_config()
    summary = _new_summary()
    if not cfg.get("enabled", True):
        summary["status"] = "disabled"
        summary["reason"] = "feed_generation.dependency_file.enabled is false"
        return summary
    try:
        runs = list(db.list_pending_runs_needing_dep_check())
    except Exception as exc:  # noqa: BLE001
        logger.error("[file_arrival] could not list pending runs: %s", exc)
        summary.update(status="error", reason=str(exc))
        return summary
    targets = _targets(db, runs, today or _today_utc(),
                       int(cfg.get("lookback_days", 7)), summary)
    summary["targets"] = len(targets)
    clients: Dict[int, Any] = {}
    for (name, bd, key), spec in targets.items():
        detail: Dict[str, Any] = {"dependency": name,
                                  "business_date": bd.isoformat()}
        if len(summary["detail"]) < 50:
            summary["detail"].append(detail)
        detail["outcome"] = _watch_one(
            db, name, bd, key, spec, summary,
            max_keys=int(cfg.get("max_keys", 1000)),
            s3_client_factory=s3_client_factory, clients=clients,
            detail=detail)
    if summary["targets"]:
        logger.info("[file_arrival] tick: %d target(s), %d looked, %d arrival(s), "
                    "%d waiting, %d could not tell, %d already arrived",
                    summary["targets"], summary["looked"], summary["arrivals"],
                    summary["waiting"], summary["unreadable"],
                    summary["already_arrived"])
    return summary


def _watch_one(db: Any, name: str, bd: date, key: str, spec: Mapping[str, Any],
               summary: Dict[str, Any], *, max_keys: int,
               s3_client_factory: Optional[Callable[[Mapping[str, Any]], Any]],
               clients: Dict[int, Any], detail: Dict[str, Any]) -> str:
    """One target: skip it if it already arrived, else look, record the
    arrival when the files are there, and keep the observation.  Returns
    the outcome word."""
    try:
        events = list(db.list_dependency_events(name, bd))
    except Exception as exc:  # noqa: BLE001 -- cannot prove absence: do not write twice on a guess
        summary["errors"] += 1
        logger.error("[file_arrival] ledger unreadable for %r @ %s (%s) -- "
                     "not looked at this pass", name, bd, exc)
        return "ledger_unreadable"
    if _matching_arrivals(events, key):
        summary["already_arrived"] += 1
        return "already_arrived"
    obs, rendered = observe(db, spec, bd, max_keys=max_keys,
                            s3_client_factory=s3_client_factory,
                            client_cache=clients)
    summary["looked"] += 1
    detail["location"] = obs.location
    if obs.status == STATUS_PRESENT and rendered is not None:
        if _record_arrival(db, name, bd, key, spec, obs, rendered):
            summary["arrivals"] += 1
            logger.info("[file_arrival] %r @ %s ARRIVED: %s", name, bd, obs.reason)
        else:
            summary["errors"] += 1
            obs.reason += (" -- but the arrival could not be recorded; the "
                           "next pass retries")
    elif obs.status == STATUS_UNREADABLE:
        summary["unreadable"] += 1
        logger.warning("[file_arrival] %r @ %s COULD NOT TELL: %s", name, bd,
                       obs.reason)
    else:
        summary["waiting"] += 1
    if not _keep_observation(db, name, bd, key, spec, obs, rendered):
        summary["errors"] += 1
    return obs.status


def _keep_observation(db: Any, name: str, bd: date, key: str,
                      spec: Mapping[str, Any], obs: Observation,
                      rendered: Optional[RenderedSpec]) -> bool:
    wants_ctl = bool(rendered and rendered.control_file)
    try:
        db.upsert_file_arrival_observation({
            "dependency_name": name, "business_date": bd, "spec_key": key,
            "connection_id": int(spec["connection_id"]),
            "location": obs.location[:1024], "status": obs.status,
            "data_files": len(obs.data),
            "control_found": bool(obs.control) if wants_ctl else None,
            "reason": obs.reason[:2000],
            "evidence": obs.evidence(rendered),
            "observed_at": datetime.now(timezone.utc),
        })
        return True
    except Exception as exc:  # noqa: BLE001 -- evidence bookkeeping must not stop the pass
        logger.error("[file_arrival] observation for %r @ %s could not be "
                     "written: %s", name, bd, exc)
        return False


# ── The gate side: one source's verdict ───────────────────────────────────

def _waiting_for(db: Any, spec: Mapping[str, Any], business_date: date
                 ) -> Tuple[str, Dict[str, Any]]:
    """What this source is waiting for, rendered for the date, in words and
    as data.  Reads the connection record (a DB read, never the network)."""
    rendered = render_spec(spec, business_date)
    label = rendered.path
    try:
        conn = db.get_connection_raw(int(spec["connection_id"]))
        if conn:
            label = resolve_location(conn, rendered.path).label
    except Exception:  # noqa: BLE001 -- the words degrade to the bare path
        pass
    if rendered.min_files <= 0:
        words = f"control file {rendered.control_file!r} under {label}"
    else:
        words = (f"{rendered.min_files} file(s) matching {rendered.pattern!r} "
                 f"under {label}"
                 + (f" and control file {rendered.control_file!r}"
                    if rendered.control_file else ""))
    return words, {"location": label, "pattern": rendered.pattern,
                   "control_file": rendered.control_file,
                   "min_files": rendered.min_files}


def _met_from(hits: List[Mapping[str, Any]]) -> tuple:
    """MET, with the files the latest arrival recorded."""
    last = hits[-1]
    payload = last.get("payload") if isinstance(last.get("payload"), Mapping) else {}
    where = payload.get("location") or "the declared location"
    count = payload.get("file_count")
    ctl = list(payload.get("control") or [])
    ctl_words = ""
    if ctl:
        ctl_words = ", control " + ", ".join(_basename(c.get("key")) for c in ctl[:3])
    counted = "the" if count is None else count
    return (MET,
            f"{counted} file(s) landed under {where}{ctl_words} -- recorded "
            f"at {last.get('arrived_at')}",
            {"last_arrived_at": last.get("arrived_at"),
             "arrival_count": len(hits),
             "location": payload.get("location"),
             "file_count": count,
             "total_bytes": payload.get("total_bytes"),
             "files": list(payload.get("files") or [])[:10],
             "control": ctl[:3]})


def evaluate_source(db: Any, *, dependency_name: str, spec: Mapping[str, Any],
                    business_date: date,
                    ledger_events: Optional[List[Dict[str, Any]]],
                    ledger_error: Optional[str]) -> tuple:
    """(verdict, reason, evidence) for one ``file`` declaration.

    Order of evidence:
      1. the ledger unreadable                         -> COULD NOT TELL;
      2. a ``file`` arrival for D from this source     -> MET (with the files);
      3. a declaration naming no location (pre-2026-10-07) -> NOT MET, saying
         nothing watches for it;
      4. the latest observation UNREADABLE              -> COULD NOT TELL;
      5. otherwise NOT MET, saying WHAT it waits for and what was last seen.
    (A watcher that is switched off or not running is the producer's
    health: ``arrival_sources.producer_health`` turns any unmet verdict into
    "cannot be satisfied".)
    """
    if ledger_events is None:
        return (UNKNOWN, f"the arrival ledger could not be read ({ledger_error})",
                None)
    watchable = is_watchable(spec)
    key = spec_key(spec) if watchable else None
    hits = _matching_arrivals(ledger_events, key)
    if hits:
        return _met_from(hits)
    if not watchable:
        return (NOT_MET,
                f"no file arrival recorded for {business_date.isoformat()}; this "
                f"declaration names no connection and path, so the file watcher "
                f"does not look for one -- re-save the dependency with a "
                f"connection and path", None)
    try:
        words, waiting = _waiting_for(db, spec, business_date)
    except Exception as exc:  # noqa: BLE001
        return (UNKNOWN, f"the declared path could not be rendered for "
                         f"{business_date.isoformat()}: {exc}", None)
    evidence: Dict[str, Any] = {"waiting_for": waiting}
    # A watcher that is switched off is the PRODUCER's health, decided once
    # for every kind in arrival_sources.producer_health ("cannot be
    # satisfied") -- not a second time here.
    cfg = load_config()
    try:
        obs = db.get_file_arrival_observation(dependency_name, business_date, key)
    except Exception as exc:  # noqa: BLE001
        return (UNKNOWN, f"the file watcher's observations could not be read "
                         f"({exc}) -- waiting for {words}", evidence)
    if obs:
        evidence.update(observed_at=obs.get("observed_at"),
                        status=obs.get("status"), looks=obs.get("looks"),
                        data_files=obs.get("data_files"),
                        control_found=obs.get("control_found"))
        if obs.get("status") == STATUS_UNREADABLE:
            return (UNKNOWN,
                    f"the last look (at {obs.get('observed_at')}) could not "
                    f"tell: {obs.get('reason')} -- waiting for {words}",
                    evidence)
        return (NOT_MET,
                f"waiting for {words}; last looked at {obs.get('observed_at')}: "
                f"{obs.get('reason')}", evidence)
    if not _in_window(business_date, _today_utc(), int(cfg["lookback_days"])):
        return (NOT_MET,
                f"waiting for {words}, but {business_date.isoformat()} is outside "
                f"the file watcher's look-back window ({cfg['lookback_days']} "
                f"days), so nothing looks for it -- widen feed_generation."
                f"dependency_file.lookback_days or skip this dependency for the "
                f"run", evidence)
    return (NOT_MET,
            f"waiting for {words} -- not looked at yet (the watcher lists it "
            f"every {cfg['interval_seconds']} s while a run waits on it)",
            evidence)


__all__ = [
    "LEDGER_SOURCE", "FileSpecRefused", "load_config",
    "normalise_declaration", "validate_against_connection", "watch_tick",
    "evaluate_source",
]
