"""Feed schedule vocabulary — BRD §2.1 "Schedule" (2026-09-02).

The BRD says an author supplies

    "A calendar rule: daily, month-end, workday N, cron expression,
     or on completion of feed X"

and the platform derives "the business date, the SOD tasks for the day,
whether today is a business day for this feed".  Until this module the
backend could only represent ``cron + timezone + calendar_name`` — the
other three kinds had no representation at all.

This module is PURE: no DB access, no scheduler wiring, no module-level
state.  It gives the authorable kinds an explicit, validated shape:

  * :func:`parse_schedule` — authored dict -> frozen :class:`FeedSchedule`,
    or :class:`ScheduleError` naming exactly what is wrong.  ``None``
    (no declaration) returns ``None`` so the existing cron-only path is
    untouched.
  * :func:`due_on` — "is this feed due on this business date", answered
    with the three-state :class:`Due` enum against the EXISTING
    :class:`core.feed.calendar.BusinessCalendar` (holiday/weekend logic
    is NOT reimplemented here).
  * :func:`to_legacy_fields` — honest translation into what today's
    scheduler (APScheduler cron + SOD ACTION_CONDITION) already
    understands, with ``fully_expressed=False`` where it cannot.

Design decisions (each traces to a shipped incident in this codebase):

  * ``workdays`` (2026-09-03, operator: "SOD will be created based on
    feed schedule type ... but should run on workday 1 to workday 15,
    workday 10 only") is ONE kind with two mutually-exclusive authoring
    forms — ``{"from": a, "to": b}`` (an INCLUSIVE range) or
    ``{"days": [..]}`` (a discrete set) — NOT two kinds.  Both forms
    reduce at parse time to the same internal representation (a sorted
    tuple of members) and every consumer sees only that, so the two
    forms cannot diverge in behaviour: there is one evaluation path,
    not a range path and a set path that drift apart.
      - Bounds are INCLUSIVE: from=1, to=15 is due on workdays 1 AND 15.
      - SHORT MONTHS DO NOT CLAMP: a member with no matching business
        day that month (workday 15 in a 12-business-day month) simply
        has no due day — identical to the existing ``workday_n``
        semantics.  For a range starting at 1 this means "every
        business day of a short month", which is what "run workday 1
        to 15" intends; for ``{"days": [15]}`` alone it means NOT DUE
        that month, never a silent rewrite to "the last business day"
        (an author who means month-end writes -1 or month_end).
      - NEGATIVE members (counted from month end, like workday_n) are
        allowed in the SET — each member is an independent, well-defined
        check — and in a SAME-SIGN range (from=-3, to=-1 = the last
        three business days).  A MIXED-SIGN range is REFUSED: which
        dates from=-2, to=3 covers depends on the month's length (it
        can be empty, overlapping, or double-counting), so it is
        ill-defined, not merely unusual.
      - REVERSED bounds (from=15, to=1), a ZERO member, |member| > 15,
        DUPLICATE members and an EMPTY set are all REFUSED, never
        swapped / dropped / deduplicated — the same no-normalisation
        stance as ``workday_n = 0`` below.
  * ``workday_n = 0`` is REFUSED, never folded into "the 1st" or
    "every day".  (2026-08-13: an ``a or b`` fold made 0 mean "capped
    at 1M rows" on a 70M feed, reported SUCCESS.)
  * An UNRECOGNISED kind raises; it is never treated as "not due".
    (2026-08-21: an unrecognised operator spelling and a deliberate
    refusal were indistinguishable — both failed open, and the most
    selective partition predicate was silently dropped on every query.)
  * ``on_completion_of`` is EVENT-DRIVEN — a trigger, not a date rule.
    :func:`due_on` returns the distinct state :attr:`Due.EVENT_DRIVEN`
    rather than raising, BECAUSE callers here iterate feeds inside
    broad fail-open ``try/except`` handlers (2026-08-19: the parent
    discarded the child's error; 2026-09-01: pause was inert because a
    failure path changed nothing) — an exception would be swallowed and
    the feed silently skipped forever.  Instead the enum's ``__bool__``
    RAISES for ``EVENT_DRIVEN``, so a caller that treats the answer as
    a boolean fails loudly in its OWN frame, at the exact line that
    made the category error, and cannot read "event-driven" as
    "not due today".
"""
from __future__ import annotations

import enum
from dataclasses import dataclass
from datetime import date as _date, datetime as _datetime
from typing import Any, Mapping, Optional, Tuple

from .calendar import BusinessCalendar

__all__ = [
    "ScheduleError",
    "FeedSchedule",
    "Due",
    "SCHEDULE_KINDS",
    "WORKDAY_N_MIN",
    "WORKDAY_N_MAX",
    "parse_schedule",
    "due_on",
    "BUSINESS_DATES",
    "business_date_for",
    "next_task",
    "to_legacy_fields",
    "LegacyTranslation",
]


class ScheduleError(ValueError):
    """A schedule declaration is invalid, or a schedule was used in a
    way its kind does not support.  The message always names the field
    or kind at fault — never a bare 'invalid schedule'."""


# The authorable kinds: the five from BRD §2.1 plus ``workdays``
# (2026-09-03 — a workday RANGE/SET; see the module docstring).  A
# tuple, not a set, so the error message lists them in a stable order.
KIND_DAILY = "daily"
KIND_MONTH_END = "month_end"
KIND_WORKDAY_N = "workday_n"
KIND_WORKDAYS = "workdays"
KIND_CRON = "cron"
KIND_ON_COMPLETION = "on_completion_of"
#: 2026-10-12 -- a feed with NO date rule that SOD never schedules: it runs
#: only when asked (Run Now, a trigger, a harness).  Without it, a feed with
#: no declaration fell to the legacy every-day rule and its task sat on the
#: day's board whether or not anyone meant it to run.
KIND_ON_DEMAND = "on_demand"

SCHEDULE_KINDS: Tuple[str, ...] = (
    KIND_DAILY,
    KIND_MONTH_END,
    KIND_WORKDAY_N,
    KIND_WORKDAYS,
    KIND_CRON,
    KIND_ON_COMPLETION,
    KIND_ON_DEMAND,
)

# 2026-10-13 -- the SECOND axis of a schedule (the owner: "jobs can be daily,
# month end ... month-end date but run on workday 5 ... month end and run
# daily, the Kafka message comes daily for the current month end").  ``kind``
# says on which days a task is CREATED (the run day); ``business_date`` says
# which date the DATA is for on that run day:
#   run_day             the run day itself (the default; every feed before this)
#   month_end           the CURRENT month end: the last month-end business day
#                       on or before the run day (a month-end feed run daily)
#   previous_month_end  the month end of the month BEFORE the run day's
#                       (a month end delivered on workday 5)
BD_RUN_DAY = "run_day"
BD_MONTH_END = "month_end"
BD_PREVIOUS_MONTH_END = "previous_month_end"
BUSINESS_DATES: Tuple[str, ...] = (BD_RUN_DAY, BD_MONTH_END, BD_PREVIOUS_MONTH_END)

# BRD §6: "Workday N — Nth business day of the month; N = 1…15 and
# negative from the end".  Negative N is supported (it is genuinely
# useful: "3rd-last business day" survives short months and holiday
# clusters where a fixed calendar day does not), bounded symmetrically.
WORKDAY_N_MIN = 1
WORKDAY_N_MAX = 15


class Due(enum.Enum):
    """Three-state answer from :func:`due_on`.

    ``DUE`` and ``NOT_DUE`` behave as booleans.  ``EVENT_DRIVEN`` means
    "this feed has no date rule at all — it runs when its upstream feed
    completes" and REFUSES boolean coercion: ``if due_on(...)`` on an
    event-driven feed raises :class:`ScheduleError` at the caller's own
    line instead of silently reading as False ("not due today") or
    True ("runs every day").  See the module docstring for why this is
    a raising ``__bool__`` rather than a raising ``due_on``.
    """

    DUE = "due"
    NOT_DUE = "not_due"
    EVENT_DRIVEN = "event_driven"

    def __bool__(self) -> bool:
        if self is Due.DUE:
            return True
        if self is Due.NOT_DUE:
            return False
        raise ScheduleError(
            "Due.EVENT_DRIVEN cannot be used as a boolean: this feed is "
            "triggered by completion of another feed, not by a date rule. "
            "Handle Due.EVENT_DRIVEN explicitly (route it to the "
            "dependency gate) instead of asking 'is it due today'."
        )


@dataclass(frozen=True)
class FeedSchedule:
    """Validated schedule declaration.  Always built via
    :func:`parse_schedule`; the fields not used by ``kind`` are None.

    ``calendar_name``/``timezone`` are carried verbatim — resolving the
    name to a :class:`BusinessCalendar` stays the caller's job (it is
    DB-driven), keeping this module pure.
    """

    kind: str
    calendar_name: Optional[str] = None
    timezone: Optional[str] = None
    workday_n: Optional[int] = None          # kind == workday_n only
    # kind == workdays only: the resolved membership, sorted ascending.
    # BOTH authoring forms (from/to range, days set) land here — one
    # representation, one evaluation path.
    workday_members: Optional[Tuple[int, ...]] = None
    cron_expression: Optional[str] = None    # kind == cron only
    upstream_feed: Optional[str] = None      # kind == on_completion_of only
    #: which date the data is for on a run day (BUSINESS_DATES)
    business_date: str = "run_day"


# ── Parsing / validation ────────────────────────────────────────────────────


def _require_str(decl: Mapping[str, Any], key: str, *, required: bool) -> Optional[str]:
    """Fetch an optional/required string field, refusing wrong types
    and empty strings with a message naming the field."""
    if key not in decl or decl[key] is None:
        if required:
            raise ScheduleError(
                f"schedule kind {decl.get('kind')!r} requires field {key!r}"
            )
        return None
    val = decl[key]
    if not isinstance(val, str) or not val.strip():
        raise ScheduleError(
            f"schedule field {key!r} must be a non-empty string, "
            f"got {val!r} ({type(val).__name__})"
        )
    return val.strip()


_ALLOWED_KEYS = {
    KIND_DAILY: set(),
    KIND_MONTH_END: set(),
    KIND_WORKDAY_N: {"n"},
    KIND_WORKDAYS: {"from", "to", "days"},
    KIND_CRON: {"cron"},
    KIND_ON_COMPLETION: {"feed"},
    KIND_ON_DEMAND: set(),
}
_COMMON_KEYS = {"kind", "calendar_name", "timezone", "business_date"}


def parse_schedule(decl: Optional[Mapping[str, Any]]) -> Optional[FeedSchedule]:
    """Parse an authored schedule declaration.

    ``None`` returns ``None`` — the ABSENCE of a declaration means the
    feed stays on today's cron-only path, byte-for-byte unchanged; this
    function must never invent a schedule for a feed that declared
    none.

    Any other invalid input raises :class:`ScheduleError` naming the
    exact problem: wrong container type, missing/unknown ``kind``,
    missing per-kind field, wrong field type, ``n`` out of range or
    zero, unknown extra keys.  Unknown keys are REFUSED rather than
    ignored because this codebase has shipped a P0 where a twin pydantic
    model silently dropped ``raw_sql`` (2026-08-23) — silent key drops
    hide author intent.
    """
    if decl is None:
        return None
    if not isinstance(decl, Mapping):
        raise ScheduleError(
            f"schedule declaration must be a dict, got {type(decl).__name__}"
        )

    kind = decl.get("kind")
    if kind is None:
        raise ScheduleError(
            "schedule declaration is missing 'kind' "
            f"(one of {', '.join(SCHEDULE_KINDS)})"
        )
    if not isinstance(kind, str):
        raise ScheduleError(
            f"schedule 'kind' must be a string, got {type(kind).__name__}"
        )
    kind = kind.strip().lower()
    if kind not in SCHEDULE_KINDS:
        raise ScheduleError(
            f"unknown schedule kind {kind!r}; valid kinds are "
            f"{', '.join(SCHEDULE_KINDS)}.  Unknown kinds are refused, "
            "never treated as 'not due' or 'always due'."
        )

    allowed = _COMMON_KEYS | _ALLOWED_KEYS[kind]
    extra = set(decl.keys()) - allowed
    if extra:
        raise ScheduleError(
            f"schedule kind {kind!r} does not accept key(s) "
            f"{', '.join(sorted(repr(k) for k in extra))}; "
            f"allowed keys are {', '.join(sorted(allowed))}"
        )

    calendar_name = _require_str(decl, "calendar_name", required=False)
    timezone = _require_str(decl, "timezone", required=False)
    bd_rule = (_require_str(decl, "business_date", required=False) or BD_RUN_DAY).strip().lower()
    if bd_rule not in BUSINESS_DATES:
        raise ScheduleError(
            f"unknown business_date {bd_rule!r}; valid values are {', '.join(BUSINESS_DATES)} "
            "(which date the data is for on the day the task runs)")
    if bd_rule != BD_RUN_DAY and kind in (KIND_ON_COMPLETION, KIND_ON_DEMAND):
        raise ScheduleError(
            f"business_date {bd_rule!r} needs a date rule; a {kind} feed takes its business "
            "date from what starts it")

    workday_n: Optional[int] = None
    workday_members: Optional[Tuple[int, ...]] = None
    cron_expression: Optional[str] = None
    upstream_feed: Optional[str] = None

    if kind == KIND_WORKDAY_N:
        workday_n = _parse_workday_n(decl)
    elif kind == KIND_WORKDAYS:
        workday_members = _parse_workdays(decl)
    elif kind == KIND_CRON:
        cron_expression = _parse_cron(decl)
    elif kind == KIND_ON_COMPLETION:
        upstream_feed = _require_str(decl, "feed", required=True)

    return FeedSchedule(
        kind=kind,
        calendar_name=calendar_name,
        timezone=timezone,
        workday_n=workday_n,
        workday_members=workday_members,
        cron_expression=cron_expression,
        upstream_feed=upstream_feed,
        business_date=bd_rule,
    )


def business_date_for(schedule: FeedSchedule, run_day: _date,
                      calendar: Optional[BusinessCalendar]) -> _date:
    """The business date of the DATA on a run day (2026-10-13): THE mapping
    every reader uses -- SOD and its catch-up, the board by run date, the
    restatement window, the summary.  ``run_day`` itself unless the
    declaration says otherwise (see BUSINESS_DATES)."""
    cal = calendar if calendar is not None else BusinessCalendar(None)
    rule = getattr(schedule, "business_date", BD_RUN_DAY) or BD_RUN_DAY
    if rule == BD_RUN_DAY:
        return run_day
    if rule == BD_PREVIOUS_MONTH_END:
        return cal.previous_eom(run_day)
    if rule == BD_MONTH_END:
        d = run_day
        for _ in range(400):
            if cal.is_last_n_business_days_of_month(d, 1):
                return d
            d = _date.fromordinal(d.toordinal() - 1)
        raise ScheduleError(f"no month-end business day within 400 days before {run_day}")
    raise ScheduleError(f"business_date_for: unknown business_date {rule!r}")


def next_task(schedule: FeedSchedule, business_date: _date,
              calendar: Optional[BusinessCalendar], horizon_days: int = 400
              ) -> Optional[Tuple[_date, _date]]:
    """The NEXT task after the one for ``business_date``: ``(run day, its
    business date)`` -- the first due run day after ``business_date`` whose
    business date is LATER (a month end run daily is on the same business
    date for weeks; its next task is the next month end).  None for a
    feed with no date rule, or none within the horizon."""
    d = business_date
    for _ in range(horizon_days):
        d = _date.fromordinal(d.toordinal() + 1)
        v = due_on(schedule, d, calendar)
        if v is Due.EVENT_DRIVEN:
            return None
        if v is Due.DUE:
            bd = business_date_for(schedule, d, calendar)
            if bd > business_date:
                return d, bd
    return None


def _parse_workday_n(decl: Mapping[str, Any]) -> int:
    """Validate the ``n`` field of a workday_n declaration."""
    if "n" not in decl or decl["n"] is None:
        raise ScheduleError("schedule kind 'workday_n' requires field 'n'")
    n = decl["n"]
    # bool is an int subclass: True would silently mean "workday 1".
    if isinstance(n, bool) or not isinstance(n, int):
        raise ScheduleError(
            f"workday_n 'n' must be an integer, got {n!r} "
            f"({type(n).__name__})"
        )
    if n == 0:
        raise ScheduleError(
            "workday_n n=0 is refused: there is no 0th business day. "
            "0 does NOT mean 'every day', 'unlimited', or 'the 1st' "
            "(this platform once shipped a '0 means unlimited' fold "
            "that truncated a 70M-row feed to 1M and reported "
            "SUCCESS).  Use n=1 for the first business day or n=-1 "
            "for the last."
        )
    # NOTE: this range guard deliberately checks only the UPPER bound —
    # the only integer with abs(n) < WORKDAY_N_MIN is 0, which the
    # dedicated guard above already refused with its own message.
    # Keeping the coverage disjoint means each guard is independently
    # observable (mutation-testable).
    if abs(n) > WORKDAY_N_MAX:
        raise ScheduleError(
            f"workday_n n={n} is out of range: |n| must be between "
            f"{WORKDAY_N_MIN} and {WORKDAY_N_MAX} (BRD §6: "
            "'N = 1…15 and negative from the end')"
        )
    return n


def _validate_workday_member(value: Any, where: str) -> int:
    """One workday member (a range bound or a set element): an int,
    never bool, never 0, |value| <= WORKDAY_N_MAX.  Shared by both
    authoring forms so the range and the set cannot disagree on what a
    valid member is."""
    if isinstance(value, bool) or not isinstance(value, int):
        raise ScheduleError(
            f"workdays {where} must be an integer, got {value!r} "
            f"({type(value).__name__})"
        )
    if value == 0:
        raise ScheduleError(
            f"workdays {where} = 0 is refused: there is no 0th business "
            "day.  0 does NOT mean 'every day' or 'the 1st' (this "
            "platform once shipped a '0 means unlimited' fold that "
            "truncated a 70M-row feed to 1M and reported SUCCESS).  "
            "Use 1 for the first business day or -1 for the last."
        )
    if abs(value) > WORKDAY_N_MAX:
        raise ScheduleError(
            f"workdays {where} = {value} is out of range: |value| must "
            f"be between {WORKDAY_N_MIN} and {WORKDAY_N_MAX}"
        )
    return value


def _parse_workdays(decl: Mapping[str, Any]) -> Tuple[int, ...]:
    """Validate a ``workdays`` declaration into its sorted membership.

    Exactly ONE of the two authoring forms must be present:

      * ``from`` + ``to`` — an INCLUSIVE, same-sign range;
      * ``days`` — a non-empty list of distinct members.

    See the module docstring for the design decisions (inclusive
    bounds, no short-month clamp, negative members, mixed-sign-range
    refusal, no normalisation of reversed/zero/duplicate input).
    """
    has_from = decl.get("from") is not None
    has_to = decl.get("to") is not None
    has_days = decl.get("days") is not None

    if (has_from or has_to) and has_days:
        raise ScheduleError(
            "workdays accepts EITHER a range (from/to) OR a set (days), "
            "not both in one declaration — two forms for one schedule "
            "would be two spellings that can disagree"
        )
    if not has_from and not has_to and not has_days:
        raise ScheduleError(
            "workdays requires either a range (both 'from' and 'to') "
            "or a set ('days': a non-empty list of workday numbers)"
        )

    if has_from or has_to:
        return _parse_workdays_range(decl, has_from, has_to)
    return _parse_workdays_set(decl["days"])


def _parse_workdays_range(decl: Mapping[str, Any],
                          has_from: bool, has_to: bool) -> Tuple[int, ...]:
    """The from/to form: inclusive, same-sign, never reversed."""
    if not (has_from and has_to):
        missing = "to" if has_from else "from"
        raise ScheduleError(
            f"workdays range requires BOTH 'from' and 'to'; "
            f"{missing!r} is missing"
        )
    lo = _validate_workday_member(decl["from"], "'from'")
    hi = _validate_workday_member(decl["to"], "'to'")
    if (lo > 0) != (hi > 0):
        raise ScheduleError(
            f"workdays range from={lo} to={hi} mixes a "
            "count-from-start bound with a count-from-end bound; "
            "which dates that covers depends on the month's length "
            "(it can be empty, overlapping or double-counting), so "
            "it is refused.  Use two feeds, or a 'days' set whose "
            "members are each independently well-defined."
        )
    if lo > hi:
        raise ScheduleError(
            f"workdays range from={lo} to={hi} is reversed "
            "(from must be <= to); refused, never silently swapped"
        )
    return tuple(range(lo, hi + 1))


def _parse_workdays_set(days: Any) -> Tuple[int, ...]:
    """The days form: a non-empty list of distinct valid members,
    canonicalised to ascending order (order carries no meaning)."""
    if isinstance(days, (str, bytes)) or not isinstance(days, (list, tuple)):
        raise ScheduleError(
            f"workdays 'days' must be a list of integers, got "
            f"{days!r} ({type(days).__name__})"
        )
    if len(days) == 0:
        raise ScheduleError(
            "workdays 'days' is empty: a schedule with no due days is "
            "a feed that never runs, silently — declare the days or "
            "remove the schedule"
        )
    members = [_validate_workday_member(v, "'days' member") for v in days]
    dupes = sorted({m for m in members if members.count(m) > 1})
    if dupes:
        raise ScheduleError(
            f"workdays 'days' contains duplicate member(s) "
            f"{dupes}: refused, never silently deduplicated — a "
            "duplicate usually means a typo'd member"
        )
    return tuple(sorted(members))


def _parse_cron(decl: Mapping[str, Any]) -> str:
    """Validate the ``cron`` field of a cron declaration."""
    cron_expression = _require_str(decl, "cron", required=True)
    fields = cron_expression.split()
    if len(fields) != 5:
        raise ScheduleError(
            f"cron expression {cron_expression!r} has "
            f"{len(fields)} field(s); expected 5 "
            "(minute hour day month day_of_week — the crontab form "
            "APScheduler's CronTrigger.from_crontab accepts)"
        )
    return cron_expression


# ── Due-ness ────────────────────────────────────────────────────────────────


def due_on(
    schedule: FeedSchedule,
    business_date: _date,
    calendar: Optional[BusinessCalendar],
) -> Due:
    """Is this feed due on ``business_date``?  Returns :class:`Due`.

    ``calendar`` is a resolved :class:`BusinessCalendar` (or ``None``,
    which — matching :class:`BusinessCalendar(None)` everywhere else in
    this platform — treats every day as a business day).  All holiday
    and weekend arithmetic is delegated to the existing calendar
    methods; nothing is reimplemented here.

    Per kind:

    * ``daily`` — DUE on every business day of the calendar.
    * ``month_end`` — DUE only on the LAST business day of the month
      (a month-end landing on a weekend/holiday therefore rolls to the
      previous business day, via
      ``BusinessCalendar.is_last_n_business_days_of_month(d, 1)``).
    * ``workday_n`` with n>0 — DUE only on the exact Nth business day
      of the month.  A month with fewer than N business days simply has
      no due day (never DUE that month) — the rule does NOT clamp to
      month-end.
    * ``workday_n`` with n<0 — DUE only on the exact |n|-th business
      day counted back from month end (n=-1 == month_end).
    * ``workdays`` — DUE iff the date is the exact Nth business day
      for AT LEAST ONE member (each member judged exactly like a
      ``workday_n`` of that value, negative members included).  A
      member with no matching business day in a short month simply
      contributes no due day — never a clamp to month-end.
    * ``cron`` — this function answers ONLY the calendar-filter half
      (BRD §6: "Cron: explicit expression, still calendar-filtered"):
      DUE iff ``business_date`` is a business day.  The cron's own
      minute/hour/day fields are owned by APScheduler and are NOT
      evaluated here — a caller needing "would this cron fire today"
      must ask the trigger, not this function.
    * ``on_completion_of`` — returns :attr:`Due.EVENT_DRIVEN`, always.
      This kind has no date rule; asking "is it due today" is a
      category error.  The distinct state (whose ``__bool__`` raises)
      was chosen over raising here so that a fail-open ``try/except``
      around a feed loop cannot swallow the signal and silently skip
      the feed — see the module docstring.

    An unknown ``kind`` (a hand-built dataclass that bypassed
    :func:`parse_schedule`) raises :class:`ScheduleError` — never
    fail-open to DUE or NOT_DUE.
    """
    if schedule is None:
        raise ScheduleError(
            "due_on(None): this feed has no schedule declaration; the "
            "legacy cron-only path owns it and due_on must not be asked"
        )
    if isinstance(business_date, _datetime) or not isinstance(business_date, _date):
        raise ScheduleError(
            f"business_date must be a datetime.date (not datetime), "
            f"got {type(business_date).__name__}"
        )
    cal = calendar if calendar is not None else BusinessCalendar(None)

    kind = schedule.kind
    if kind in (KIND_ON_COMPLETION, KIND_ON_DEMAND):
        # no date rule: something else starts it (its upstream / a person)
        return Due.EVENT_DRIVEN
    if kind == KIND_DAILY or kind == KIND_CRON:
        return Due.DUE if cal.is_business_day(business_date) else Due.NOT_DUE
    if kind == KIND_MONTH_END:
        return (
            Due.DUE
            if cal.is_last_n_business_days_of_month(business_date, 1)
            else Due.NOT_DUE
        )
    if kind == KIND_WORKDAY_N:
        return _workday_due(cal, business_date, schedule.workday_n)
    if kind == KIND_WORKDAYS:
        return _workdays_due(cal, business_date, schedule.workday_members)

    raise ScheduleError(
        f"due_on: unrecognised schedule kind {kind!r} — refusing to "
        "answer.  An unknown kind must never be read as 'not due' "
        "(feed never runs) or 'due' (feed runs every day)."
    )


def _workday_due(cal: BusinessCalendar, business_date: _date,
                 n: Optional[int]) -> Due:
    """Exact-Nth-business-day check for :func:`due_on` (kind workday_n)."""
    if not isinstance(n, int) or isinstance(n, bool) or n == 0:
        raise ScheduleError(
            f"workday_n schedule carries invalid n={n!r}; "
            "was this FeedSchedule built without parse_schedule()?"
        )
    return Due.DUE if _workday_hit(cal, business_date, n) else Due.NOT_DUE


def _workday_hit(cal: BusinessCalendar, business_date: _date, n: int) -> bool:
    """Is ``business_date`` exactly the Nth business day of its month
    (n>0 from the start, n<0 from the end)?  The single predicate both
    ``workday_n`` and every ``workdays`` member evaluate through — one
    path, so the two kinds cannot disagree on what 'workday N' means."""
    if n > 0:
        return cal.is_nth_business_day_of_month(business_date, n)
    # Exactly the k-th business day from month end: the date is
    # within the last k business days but NOT within the last
    # k-1 (is_last_n(d, 0) is False by contract, so k=1 works).
    k = -n
    return cal.is_last_n_business_days_of_month(
        business_date, k
    ) and not cal.is_last_n_business_days_of_month(business_date, k - 1)


def _workdays_due(cal: BusinessCalendar, business_date: _date,
                  members: Optional[Tuple[int, ...]]) -> Due:
    """Any-member-hits check for :func:`due_on` (kind workdays)."""
    if not members or not isinstance(members, tuple):
        raise ScheduleError(
            f"workdays schedule carries invalid members={members!r}; "
            "was this FeedSchedule built without parse_schedule()?"
        )
    for m in members:
        if not isinstance(m, int) or isinstance(m, bool) or m == 0:
            raise ScheduleError(
                f"workdays schedule carries invalid member {m!r}; "
                "was this FeedSchedule built without parse_schedule()?"
            )
    hit = any(_workday_hit(cal, business_date, m) for m in members)
    return Due.DUE if hit else Due.NOT_DUE


# ── Translation to today's scheduler vocabulary ─────────────────────────────


@dataclass(frozen=True)
class LegacyTranslation:
    """What today's scheduler columns/ACTION_CONDITION can express of a
    parsed schedule.  ``fully_expressed=False`` means the legacy fields
    alone do NOT implement the rule and the caller must also consult
    :func:`due_on` (or, for on_completion_of, the dependency gate);
    ``note`` says exactly what is missing."""

    cron_expression: Optional[str]
    timezone: Optional[str]
    calendar_name: Optional[str]
    action_condition: Optional[str]
    fully_expressed: bool
    note: str


def to_legacy_fields(schedule: FeedSchedule) -> LegacyTranslation:
    """Translate a parsed schedule into today's vocabulary:
    ``feed_configs.cron_expression / timezone / calendar_name`` plus a
    SOD ``ACTION_CONDITION`` string where one exists.

    Honest limits (each verified against the current source):

    * ``daily``, ``month_end``, positive ``workday_n`` — fully
      expressible: SOD creates the day's row, the emitted
      ACTION_CONDITION (``IS_BUSINESS_DAY`` /
      ``IS_LAST_N_BUSINESS_DAYS_OF_MONTH($business_date, 1)`` /
      ``IS_NTH_BUSINESS_DAY_OF_MONTH($business_date, N)``) decides
      RUN vs SKIP, and the queue worker executes cron-less feeds.
    * ``workdays`` with ALL-POSITIVE members — fully expressible: the
      macro layer replaces each ``IS_NTH_BUSINESS_DAY_OF_MONTH`` with a
      TRUE/FALSE literal and the sandboxed evaluator then evaluates the
      OR of those literals as ordinary SQL, so a membership of k days
      becomes k OR-ed macros (k <= 15, ~50 chars each — far under the
      evaluator's 5000-char cap).  ANY negative member makes the whole
      translation ``fully_expressed=False`` for the same reason as
      negative ``workday_n`` below.
    * NEGATIVE ``workday_n`` is NOT expressible today: the
      ACTION_CONDITION macro regex accepts only ``(\\d+)`` — a minus
      sign simply does not match, and the raw text would reach the
      expression evaluator unresolved.  ``fully_expressed=False``;
      the caller must gate on :func:`due_on`.
    * ``cron`` — fully expressible (it IS today's vocabulary).
    * ``on_completion_of`` — NOT expressible: it is a dependency edge
      (BRD §6: "the trigger is a dependency, not a schedule"), and no
      cron/condition can encode "when feed X completes".
      ``fully_expressed=False``; the caller must register it with the
      dependency gate.

    Unknown kinds raise :class:`ScheduleError` (never a silent empty
    translation).
    """
    kind = schedule.kind
    base = {
        "cron_expression": None,
        "timezone": schedule.timezone,
        "calendar_name": schedule.calendar_name,
    }
    if (getattr(schedule, "business_date", BD_RUN_DAY) or BD_RUN_DAY) != BD_RUN_DAY:
        # the legacy ACTION_CONDITION judges $business_date: for data of
        # another date (the month end) it would test the WRONG day and skip
        # every run -- due_on judges the run day, alone (2026-10-13)
        return LegacyTranslation(
            **base,
            action_condition=None,
            fully_expressed=False,
            note=(f"{kind} runs for business date {schedule.business_date}: the legacy "
                  "condition reads $business_date, not the run day -- due_on decides"),
        )
    if kind == KIND_DAILY:
        return LegacyTranslation(
            **base,
            action_condition=(
                "CASE WHEN NOT IS_BUSINESS_DAY($business_date) "
                "THEN 'SKIP' END"
            ),
            fully_expressed=True,
            note="daily = every business day; queue worker runs it, "
                 "condition skips non-business days",
        )
    if kind == KIND_MONTH_END:
        return LegacyTranslation(
            **base,
            action_condition=(
                "CASE WHEN NOT IS_LAST_N_BUSINESS_DAYS_OF_MONTH"
                "($business_date, 1) THEN 'SKIP' END"
            ),
            fully_expressed=True,
            note="month_end = last business day of month via existing "
                 "ACTION_CONDITION macro",
        )
    if kind == KIND_WORKDAY_N:
        n = schedule.workday_n
        if isinstance(n, int) and not isinstance(n, bool) and n > 0:
            return LegacyTranslation(
                **base,
                action_condition=(
                    "CASE WHEN NOT IS_NTH_BUSINESS_DAY_OF_MONTH"
                    f"($business_date, {n}) THEN 'SKIP' END"
                ),
                fully_expressed=True,
                note=f"workday_n n={n} via existing ACTION_CONDITION macro",
            )
        return LegacyTranslation(
            **base,
            action_condition=None,
            fully_expressed=False,
            note=(
                f"workday_n n={n!r} (negative-from-end) is NOT "
                "expressible in today's ACTION_CONDITION macros (the "
                "IS_NTH_BUSINESS_DAY_OF_MONTH regex accepts only an "
                "unsigned integer); the caller must gate on due_on()"
            ),
        )
    if kind == KIND_WORKDAYS:
        members = schedule.workday_members or ()
        if members and all(
            isinstance(m, int) and not isinstance(m, bool) and m > 0
            for m in members
        ):
            ors = " OR ".join(
                f"IS_NTH_BUSINESS_DAY_OF_MONTH($business_date, {m})"
                for m in members
            )
            return LegacyTranslation(
                **base,
                action_condition=f"CASE WHEN NOT ({ors}) THEN 'SKIP' END",
                fully_expressed=True,
                note=(
                    f"workdays {list(members)} via OR-ed "
                    "IS_NTH_BUSINESS_DAY_OF_MONTH macros"
                ),
            )
        return LegacyTranslation(
            **base,
            action_condition=None,
            fully_expressed=False,
            note=(
                f"workdays {list(members)!r} contains a "
                "negative-from-end member, which today's "
                "IS_NTH_BUSINESS_DAY_OF_MONTH macro regex (unsigned "
                "integers only) cannot express; the caller must gate "
                "on due_on()"
            ),
        )
    if kind == KIND_CRON:
        return LegacyTranslation(
            cron_expression=schedule.cron_expression,
            timezone=schedule.timezone,
            calendar_name=schedule.calendar_name,
            action_condition=None,
            fully_expressed=True,
            note="cron is today's native vocabulary",
        )
    if kind == KIND_ON_DEMAND:
        return LegacyTranslation(
            **base,
            action_condition=None,
            fully_expressed=False,
            note="on_demand has no date rule: it runs only when asked (Run Now / a trigger)",
        )
    if kind == KIND_ON_COMPLETION:
        return LegacyTranslation(
            **base,
            action_condition=None,
            fully_expressed=False,
            note=(
                f"on_completion_of {schedule.upstream_feed!r} is a "
                "dependency edge, not a schedule (BRD §6); no "
                "cron/condition can express it — register it with the "
                "dependency gate"
            ),
        )
    raise ScheduleError(
        f"to_legacy_fields: unrecognised schedule kind {kind!r} — "
        "refusing to emit an empty translation for an unknown kind"
    )
