"""Measured runtime profiles — the producer the decision ladder was missing
(FR-SLA-01 / FR-SLA-05, 2026-09-03).

``acting_time.compute_clocks`` has always preferred a MEASURED runtime over a
declared one, and ``sla_watcher`` passed ``measured_runtime_seconds=None``
hardcoded — so the decision deadline ("skip APAC by 05:15 to still make the
06:00 SLA", the stated point of BRD §8) could never be computed on any
production feed.  This module is the producer:

* the MEASUREMENT — p95 of the durations of recently completed ``feed_runs``
  for one feed.  p95, not the mean: one catastrophic 4-hour run must not
  drag the expectation for the next 90 days (the FR-SLA-03 rule, applied to
  runtimes).
* a STORED profile (``feed_runtime_profiles``) — append-only, one row per
  recompute.  FR-SLA-05 forbids recomputing from scratch on every 60-second
  watcher tick, and requires "what did we expect on the day we alerted?" to
  stay answerable — which the latest row with ``computed_at <= that day``
  answers exactly.  Rows are never touched in place: moving an unchanged
  row's ``computed_at`` forward would change the as-of answer for every
  date in between.
* a SCHEDULE — :func:`ensure_fresh` recomputes only when the stored profile
  is older than :data:`REFRESH_INTERVAL_SECONDS`; every other call is one
  indexed read.  The watcher calls it each pass; the recompute happens a
  handful of times a day, not 1,440.

Below :data:`MIN_SAMPLES` completed runs the stored profile SAYS it is weak
(``p95_seconds`` NULL) and the ladder falls back to the feed's DECLARED
``expected_runtime_seconds`` — the FR-SLA-04 pattern: never invent an
expectation from four data points.

Fail-open throughout: profiling must never delay or fail a feed, and a
failed recompute leaves the previous stored profile in force (stated at
ERROR, never silently).
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import Any, Optional

logger = logging.getLogger(__name__)

#: How far back completed runs count toward the profile.
WINDOW_DAYS = 90

#: Cap on the rows one recompute reads.
MAX_RUNS_PER_RECOMPUTE = 500

#: Below this many completed runs the profile stores NULL percentiles —
#: a weak profile that says so, rather than a number nobody should trust.
MIN_SAMPLES = 5

#: A stored profile younger than this is simply READ (FR-SLA-05 — the 60s
#: watcher tick must not recompute); older triggers one recompute.
REFRESH_INTERVAL_SECONDS = 6 * 3600


def _duration_seconds(run: dict) -> Optional[float]:
    """completed_at - started_at for one run row, in seconds.

    Returns None when either timestamp is missing/unparseable or the
    difference is not positive — a zero or negative duration is clock
    skew, not a measurement.
    """
    started = _parse_ts(run.get("started_at"))
    completed = _parse_ts(run.get("completed_at"))
    if started is None or completed is None:
        return None
    secs = (completed - started).total_seconds()
    return secs if secs > 0 else None


def _parse_ts(value: Any) -> Optional[datetime]:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None


def compute_runtime_stats(completed_runs: list, *,
                          window_days: int = WINDOW_DAYS) -> dict:
    """Pure maths: the profile row (minus identity) for a set of run rows.

    Rows without both timestamps are stepped over, never counted as zero.
    Fewer than :data:`MIN_SAMPLES` usable durations yields NULL
    percentiles with the honest ``sample_count`` — the weak profile IS
    the answer (FR-SLA-04 pattern).
    """
    from core.feed.ledger import percentile

    durations = sorted(
        d for d in (_duration_seconds(r) for r in completed_runs)
        if d is not None)
    n = len(durations)
    if n < MIN_SAMPLES:
        return {"window_days": int(window_days), "sample_count": n,
                "p50_seconds": None, "p95_seconds": None,
                "max_seconds": None}
    return {
        "window_days": int(window_days),
        "sample_count": n,
        "p50_seconds": int(round(percentile(durations, 50))),
        "p95_seconds": int(round(percentile(durations, 95))),
        "max_seconds": int(round(durations[-1])),
    }


def recompute_and_store(db: Any, feed_config_id: int, *,
                        now: Optional[datetime] = None,
                        window_days: int = WINDOW_DAYS) -> Optional[dict]:
    """One recompute: read completed runs, compute, APPEND the profile row.

    Returns the stored row, or None when the recompute failed (logged at
    ERROR; the previously stored profile stays in force — fail-open).
    """
    at_now = now or datetime.now(timezone.utc)
    try:
        runs = db.list_recent_completed_feed_runs(
            int(feed_config_id),
            at_now - timedelta(days=int(window_days)),
            limit=MAX_RUNS_PER_RECOMPUTE) or []
        stats = compute_runtime_stats(runs, window_days=window_days)
        row = db.insert_feed_runtime_profile({
            "feed_config_id": int(feed_config_id),
            "computed_at": at_now,
            **stats,
        })
        logger.info(
            "[runtime_profile] feed %s: profile recomputed — %d sample(s), "
            "p95=%ss", feed_config_id, stats["sample_count"],
            stats["p95_seconds"])
        return row
    except Exception as exc:  # noqa: BLE001 — fail-open: profiling must never fail a feed
        logger.error(
            "[runtime_profile] feed %s: recompute FAILED (%s) — the "
            "previously stored profile (if any) stays in force",
            feed_config_id, exc)
        return None


def ensure_fresh(db: Any, feed_config_id: int, *,
                 now: Optional[datetime] = None) -> Optional[dict]:
    """The profile in force, recomputed first ONLY when stale.

    This is the FR-SLA-05 schedule: a fresh stored profile is one indexed
    read; a stale (or absent) one triggers a single recompute.  Never
    raises — a read failure returns None after an ERROR log, and the
    caller treats "no profile" as "no measured runtime" (the declared
    fallback applies).
    """
    at_now = now or datetime.now(timezone.utc)
    try:
        latest = db.get_latest_feed_runtime_profile(int(feed_config_id))
    except Exception as exc:  # noqa: BLE001 — fail-open
        logger.error(
            "[runtime_profile] feed %s: stored profile unreadable (%s) — "
            "no measured runtime this pass", feed_config_id, exc)
        return None
    if latest is not None:
        computed_at = _parse_ts(latest.get("computed_at"))
        if computed_at is not None:
            if computed_at.tzinfo is None:
                computed_at = computed_at.replace(tzinfo=timezone.utc)
            age = (at_now - computed_at).total_seconds()
            if 0 <= age < REFRESH_INTERVAL_SECONDS:
                return latest
    stored = recompute_and_store(db, feed_config_id, now=at_now)
    return stored if stored is not None else latest


def measured_runtime_seconds(db: Any, feed_config_id: int, *,
                             as_of: Optional[datetime] = None
                             ) -> Optional[int]:
    """The measured p95 from the STORED profile — never recomputes.

    ``as_of`` is the audit read: what did we expect on that day?  None
    when no profile exists or the stored one is too weak to trust
    (p95 NULL) — the caller falls back to the declared runtime.
    """
    try:
        profile = db.get_latest_feed_runtime_profile(int(feed_config_id),
                                                     as_of=as_of)
    except Exception as exc:  # noqa: BLE001 — fail-open
        logger.error(
            "[runtime_profile] feed %s: stored profile unreadable (%s)",
            feed_config_id, exc)
        return None
    if not profile:
        return None
    p95 = profile.get("p95_seconds")
    try:
        value = int(p95) if p95 is not None else None
    except (TypeError, ValueError):
        return None
    return value if value and value > 0 else None
