"""The dependency gate — not met, not expected, could not tell (BRD §7).

This is the operational heart of the platform, and the scenario it exists for
is the one a generic design gets wrong: nine of ten messages have arrived, an
SLA is closing in, and the tenth may never come because an upstream has a
holiday we do not.  That needs a state machine, not a boolean.

Three distinctions carry the whole section, and folding any two of them
together is how the estate ends up paging people at 04:19 to chase a message
that was never going to be sent:

    MET            evidence arrived and was accepted
    NOT MET        expected, and absent — this is the actionable one
    NOT EXPECTED   the upstream's OWN calendar says today is a holiday, so no
                   alert, no skip, no incident (FR-DEP-08)
    COULD NOT TELL the evidence could not be read.  Its own state, never
                   folded into either of the two above

Everything here is a PURE function over values.  The DB and the calendar are
injected, so the gate is provable without either.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from datetime import date
from typing import Any, Mapping, Optional, Sequence

logger = logging.getLogger(__name__)

# ── Verdicts ──────────────────────────────────────────────────────────────

MET = "met"
NOT_MET = "not_met"
NOT_EXPECTED = "not_expected"
UNKNOWN = "could_not_tell"

#: Verdicts that let a run proceed.  ``NOT_EXPECTED`` is here because a
#: dependency the upstream was never going to send cannot block anything; it
#: is NOT here as a convenience, and it is only ever reached via an explicit
#: upstream calendar (never by absence of one).
SATISFYING = frozenset({MET, NOT_EXPECTED})

#: Actions carried on the tracking row.  ``SKIP`` satisfies the gate but is
#: rendered distinctly for the whole life of the run: a skipped dependency
#: means the feed was produced on an ASSERTION, not on evidence (FR-DEP-12).
ACTION_COMPLETE = "COMPLETE"
ACTION_SKIP = "SKIP"
ACTION_PENDING = "PENDING"
ACTION_RESET = "RESET"

# ── Declared arrival sources: how several sources combine (2026-09-27) ──
#
# A dependency may DECLARE where its evidence comes from (the vocabulary in
# core/feed/arrival_sources.py: a Kafka message, an ETL/OG status row, a
# landed file, an Iceberg commit that proves the date).  Each declared source
# gets its own verdict and THIS is the one place they are combined -- the
# boolean poller path and the four-verdict path both call it, so the two
# can never answer differently.
REQUIRE_ALL = "all"
REQUIRE_ANY = "any"
REQUIRE_MODES = (REQUIRE_ALL, REQUIRE_ANY)


def normalise_require_mode(raw: Any) -> str:
    """``all`` unless the author said ``any``.  ALL is the default on purpose:
    a dependency that declares two sources and is satisfied by either has
    to SAY so, because the safe reading of "wait for A and B" is both."""
    text = str(raw or "").strip().lower()
    return REQUIRE_ANY if text == REQUIRE_ANY else REQUIRE_ALL


def combine_source_verdicts(sources: Sequence[Mapping[str, Any]],
                            require_mode: Any = REQUIRE_ALL) -> tuple:
    """Fold per-source verdicts into ONE (verdict, reason) pair.

    Each entry is ``{"kind": str, "verdict": MET|NOT_MET|UNKNOWN, "reason": str}``.

    ALL:  any NOT MET  -> NOT MET, naming the blocking source(s);
          else any UNKNOWN -> COULD NOT TELL, naming the unreadable one(s)
          ("unknown in ALL is could-not-tell", never met);
          else every source MET -> MET, naming every source.
    ANY:  any MET -> MET, naming the source that met;
          else any UNKNOWN -> COULD NOT TELL (a source that could not be
          read might have met it -- reporting NOT MET would page someone
          about a possibly-healthy upstream);
          else NOT MET, naming every source.
    An EMPTY declaration is a refusal, not vacuous truth: the caller must not
    reach here without at least one source.  NOT_EXPECTED is not a source
    verdict (it comes from the upstream calendar, applied before this).
    """
    mode = normalise_require_mode(require_mode)
    entries = [dict(s) for s in (sources or [])]
    if not entries:
        return (UNKNOWN, "no arrival source could be evaluated -- the "
                         "declaration is empty")

    def _named(items: list) -> str:
        return "; ".join(
            f"{e.get('kind', '?')}: {e.get('reason') or e.get('verdict')}"
            for e in items)

    met = [e for e in entries if e.get("verdict") == MET]
    unknown = [e for e in entries if e.get("verdict") == UNKNOWN]
    not_met = [e for e in entries
               if e.get("verdict") not in (MET, UNKNOWN)]
    if mode == REQUIRE_ANY:
        if met:
            return (MET, f"met by {_named(met)}")
        if unknown:
            return (UNKNOWN,
                    f"none of the declared sources has met it and at least "
                    f"one could not be read -- {_named(unknown)}")
        return (NOT_MET, f"none of the declared sources has met it -- "
                         f"{_named(not_met)}")
    # ALL
    if not_met:
        return (NOT_MET, f"waiting on {_named(not_met)}"
                         + (f" (met: {', '.join(e.get('kind', '?') for e in met)})"
                            if met else ""))
    if unknown:
        return (UNKNOWN, f"could not read {_named(unknown)}"
                         + (f" (met: {', '.join(e.get('kind', '?') for e in met)})"
                            if met else ""))
    return (MET, f"every declared source met it -- {_named(met)}")


@dataclass(frozen=True)
class DependencyVerdict:
    """One dependency's answer, with the evidence that produced it."""
    dependency_name: str
    business_date: date
    verdict: str
    action: Optional[str] = None
    reason: str = ""
    asserted: bool = False        # satisfied by a human, not by evidence
    last_seen: Optional[Any] = None
    expected_rows: Optional[int] = None
    reported_rows: Optional[int] = None
    #: 2026-09-27 — the per-source answers for a dependency that DECLARED
    #: its arrival sources (``[{kind, verdict, reason}, ...]``); None for
    #: the legacy any-evidence rule.  Carried so a screen can say WHICH
    #: source met or blocked, in the words the gate used.
    sources: Optional[tuple] = None

    @property
    def satisfies(self) -> bool:
        return self.verdict in SATISFYING

    def to_dict(self) -> dict:
        return {
            "dependency_name": self.dependency_name,
            "business_date": self.business_date.isoformat(),
            "verdict": self.verdict,
            "action": self.action,
            "reason": self.reason,
            "asserted": self.asserted,
            "satisfies": self.satisfies,
            "expected_rows": self.expected_rows,
            "reported_rows": self.reported_rows,
            "sources": ([{"kind": s.get("kind"), "verdict": s.get("verdict"),
                          "reason": s.get("reason")} for s in self.sources]
                        if self.sources is not None else None),
        }


@dataclass
class GateResult:
    """The gate's answer for one feed on one business date.

    ``blocking`` is the whole operational picture.  A feed with 5-10
    dependencies is not "waiting" — it is 9/10 satisfied, and "9/10" tells
    support nothing actionable.  "APAC_POSITIONS, last seen three days ago"
    tells them who to call (FR-DEP-06).
    """
    business_date: date
    verdicts: list = field(default_factory=list)

    @property
    def blocking(self) -> list:
        return [v for v in self.verdicts if not v.satisfies]

    @property
    def admitted(self) -> bool:
        return not self.blocking

    @property
    def asserted(self) -> bool:
        """True when the run proceeds on at least one human assertion.

        This mark travels with the run and reaches the completeness verdict
        and the control record: a consumer reconciling a regulatory feed is
        entitled to know the feed was produced without one of its inputs
        confirmed (FR-CMP-09).
        """
        return any(v.asserted for v in self.verdicts)

    @property
    def unknown(self) -> list:
        return [v for v in self.verdicts if v.verdict == UNKNOWN]

    def to_dict(self) -> dict:
        return {
            "business_date": self.business_date.isoformat(),
            "admitted": self.admitted,
            "asserted": self.asserted,
            "total": len(self.verdicts),
            "met": sum(1 for v in self.verdicts if v.satisfies),
            "blocking": [v.to_dict() for v in self.blocking],
            "verdicts": [v.to_dict() for v in self.verdicts],
        }

    def render(self, feed_name: str = "", sla: str = "") -> str:
        """The screen, not a query someone writes under pressure at 04:50.

        FR-DEP-07 — the gate is a SCREEN.  This is its text form, used in logs
        and in the run surface.
        """
        head = (f"feed={feed_name or '?'} business_date="
                f"{self.business_date.isoformat()}"
                + (f" SLA {sla}" if sla else ""))
        met = sum(1 for v in self.verdicts if v.satisfies)
        lines = [head, f"deps {met}/{len(self.verdicts)} met"]
        for v in self.verdicts:
            mark = {MET: "  met     ", NOT_EXPECTED: "  n/a     ",
                    UNKNOWN: "  UNKNOWN ", NOT_MET: "  NOT MET "}[v.verdict]
            lines.append(f"{mark}{v.dependency_name:<20} {v.reason}")
        return "\n".join(lines)


# ── The verdict for one dependency ────────────────────────────────────────

def evaluate_dependency(
    *,
    dependency_name: str,
    business_date: date,
    action: Optional[str],
    row_business_date: Optional[date] = None,
    upstream_calendar: Any = None,
    expected_rows: Optional[int] = None,
    reported_rows: Optional[int] = None,
    last_seen: Any = None,
    evidence_readable: bool = True,
    source_verdicts: Optional[Sequence[Mapping[str, Any]]] = None,
    require_mode: Any = None,
) -> DependencyVerdict:
    """One dependency's verdict, with its reason.

    ``upstream_calendar`` is the calendar that governs THIS DEPENDENCY — not
    ours.  That distinction is FR-DEP-08 and the reason the holiday scenario
    stops being an incident.  Absent a declared upstream calendar the
    dependency is simply expected: inferring "not expected" from a missing
    calendar would silence a genuinely broken upstream.

    ``source_verdicts`` (2026-09-27) are the per-source answers for a
    dependency that DECLARED its arrival sources, already resolved by
    ``core/feed/arrival_sources.py``; ``require_mode`` says how they
    combine.  When present they ARE the evidence: the tracking-row
    ``action`` is consulted only for an operator's SKIP (an assertion
    always wins) and the upstream calendar still applies before them.
    """
    def v(verdict, reason, **kw):
        return DependencyVerdict(
            dependency_name=dependency_name, business_date=business_date,
            verdict=verdict, action=action, reason=reason, last_seen=last_seen,
            expected_rows=expected_rows, reported_rows=reported_rows,
            sources=(tuple(dict(s) for s in source_verdicts)
                     if source_verdicts is not None else None),
            **kw)

    if not evidence_readable:
        # FR-DEP: "could not tell" is its own state.  Reporting NOT MET would
        # page someone about an upstream that may be perfectly healthy;
        # reporting MET would admit a run on evidence nobody read.
        return v(UNKNOWN, "dependency evidence could not be read")

    # ── Stale satisfaction (FR-DEP-17) ───────────────────────────────────
    # A COMPLETE row from yesterday satisfying today's gate is silent and
    # produces a feed built on nothing.  The state is keyed by business date
    # and the join is never relaxed.
    if (action and row_business_date is not None
            and row_business_date != business_date):
        return v(NOT_MET,
                 f"the only evidence is for {row_business_date.isoformat()}, "
                 f"not {business_date.isoformat()} — a stale row must never "
                 f"satisfy today's gate")

    normalised = str(action or "").strip().upper()

    if normalised == ACTION_SKIP:
        return v(MET, "skipped by an operator — this run proceeds on an "
                      "ASSERTION, not on evidence", asserted=True)

    if source_verdicts is not None:
        # ── Declared sources (2026-09-27) ────────────────────────────────
        # The upstream calendar is consulted FIRST, as for every other
        # dependency: a not-expected day is not an incident whatever the
        # sources say.  Then the sources combine -- ONE rule, shared with
        # the boolean poller path through ``combine_source_verdicts``.
        excused = _calendar_verdict(upstream_calendar, business_date,
                                    dependency_name)
        if excused is not None:
            return v(*excused)
        verdict, reason = combine_source_verdicts(source_verdicts, require_mode)
        return v(verdict, reason)

    if normalised == ACTION_COMPLETE:
        # ── Partial upstream (FR-DEP-21) ─────────────────────────────────
        # "The message says COMPLETE but upstream loaded 60% of its rows."
        # Where the message CARRIES a count, verify it: a dependency that can
        # be verified and is not is a choice worth making explicitly.
        if expected_rows is not None and reported_rows is not None:
            if int(reported_rows) < int(expected_rows):
                return v(NOT_MET,
                         f"reported COMPLETE with {reported_rows} rows but "
                         f"{expected_rows} were expected — a partial upstream "
                         f"load is not a met dependency")
        return v(MET, "arrived")

    # ── Not expected (FR-DEP-08) ─────────────────────────────────────────
    # Reached ONLY through a declared upstream calendar.  If the upstream's
    # calendar says today is a holiday, the gate reports not-expected: no
    # alert, no skip, no incident, and nobody is paged to chase a message that
    # was never going to be sent.
    excused = _calendar_verdict(upstream_calendar, business_date,
                                dependency_name)
    if excused is not None:
        return v(*excused)

    if normalised in (ACTION_PENDING, ACTION_RESET, ""):
        return v(NOT_MET, "not yet arrived")
    return v(NOT_MET, f"unrecognised action {action!r}")


def _calendar_verdict(upstream_calendar: Any, business_date: date,
                      dependency_name: str) -> Optional[tuple]:
    """(verdict, reason) when the upstream calendar EXCUSES or cannot be
    read; None when the dependency is expected today (or has no calendar).

    Absent a declared upstream calendar the dependency is simply expected:
    inferring "not expected" from a missing calendar would silence a
    genuinely broken upstream.
    """
    if upstream_calendar is None:
        return None
    try:
        expected_today = bool(upstream_calendar.is_business_day(business_date))
    except Exception as exc:
        logger.error(
            "[dependency_gate] upstream calendar for %s raised (%s) — "
            "reporting COULD NOT TELL rather than assuming the dependency "
            "is either due or excused", dependency_name, exc)
        return (UNKNOWN, f"upstream calendar unreadable: {exc}")
    if not expected_today:
        return (NOT_EXPECTED,
                "the upstream's own calendar says today is not a "
                "business day for it — nothing was ever going to be sent")
    return None


def evaluate_gate(rows: Sequence[Mapping[str, Any]], *, business_date: date,
                  calendars: Optional[Mapping[str, Any]] = None) -> GateResult:
    """The gate for one feed: a verdict per dependency, and the blocking set.

    ``rows`` are the feed's dependency mappings joined to their tracking
    state.  ``calendars`` maps a dependency name to the calendar that governs
    IT (never ours).
    """
    cals = calendars or {}
    verdicts = []
    for row in rows:
        name = str(row.get("dependency_key") or row.get("dependency_name") or "")
        verdicts.append(evaluate_dependency(
            dependency_name=name,
            business_date=business_date,
            action=row.get("action"),
            row_business_date=row.get("business_date"),
            upstream_calendar=cals.get(name),
            expected_rows=row.get("expected_rows"),
            reported_rows=row.get("reported_rows"),
            last_seen=row.get("updated_at"),
            evidence_readable=bool(row.get("evidence_readable", True)),
            # 2026-09-27 — set by arrival_sources.resolve_arrival_sources
            # for rows that DECLARED their sources; absent otherwise.
            source_verdicts=row.get("source_verdicts"),
            require_mode=row.get("require_mode"),
        ))
    return GateResult(business_date=business_date, verdicts=verdicts)


# ── Cycles: fail at authoring, not at 3am (FR-DEP-22) ─────────────────────

def find_dependency_cycle(graph: Mapping[str, Sequence[str]]) -> Optional[list]:
    """Return one cycle as a list of names, or None.

    A depends on B depends on A means both wait forever, and the stale-run
    escalation then reports two unrelated failures hours later.  Detect it at
    SAVE time and refuse it.
    """
    WHITE, GREY, BLACK = 0, 1, 2
    colour = {n: WHITE for n in graph}
    stack: list = []

    def walk(node) -> Optional[list]:
        colour[node] = GREY
        stack.append(node)
        for nxt in graph.get(node, ()):  # a name outside the graph is a leaf
            if nxt not in colour:
                continue
            if colour[nxt] == GREY:
                return stack[stack.index(nxt):] + [nxt]
            if colour[nxt] == WHITE:
                found = walk(nxt)
                if found:
                    return found
        colour[node] = BLACK
        stack.pop()
        return None

    for node in graph:
        if colour[node] == WHITE:
            found = walk(node)
            if found:
                return found
    return None


# ── Message resolution: configuration, not code (FR-DEP-02) ───────────────

class UnresolvedMessage(Exception):
    """A landed message that maps to no dependency.

    Raised rather than returned so a caller cannot ignore it by accident: an
    unresolved message must be RECORDED and alerted once, never dropped (see
    ``classify_unresolvable``).
    """


class FilteredMessage(UnresolvedMessage):
    """A landed message a rule for its topic SAW and EXCLUDED by its
    ``match`` filter (2026-10-11): the owner's upstream publishes every
    state of a load on one topic (``VERSION_STATE`` IN_PROGRESS / FAILED /
    COMPLETE) and only COMPLETE may satisfy a dependency.

    A subclass, so a caller that only knows ``UnresolvedMessage`` still
    refuses to treat it as an arrival; a caller that knows this class
    records it as ``filtered`` -- the expected shape of ordinary traffic,
    never poison and never an alert.  Thousands of non-COMPLETE messages a
    day must not raise thousands of ERROR alerts.
    """


@dataclass(frozen=True)
class ResolvedArrival:
    dependency_name: str
    business_date: date
    message_identity: str
    #: Rows the upstream SAYS it loaded, when its message carries a count
    #: and a rule names the field.  ``None`` means the message did not say
    #: -- which is NOT zero: zero would read as a total upstream failure
    #: and fire the partial-load alarm on every message from an upstream
    #: that simply never reports counts.
    reported_rows: Optional[int] = None
    #: 2026-10-10 -- the dependency name was DERIVED from payload fields
    #: through a templated rule (``TETB_{SYSTEM_ENTITY}_{EventCode}``).  The
    #: resolver then asks whether any feed DECLARES that name: one that does
    #: not is recorded as ``unmatched`` (never dropped, never "resolved").
    derived: bool = False


#: ``{field}`` inside a rule's ``dependency_name`` -- the payload field whose
#: value is pasted there (2026-10-10).  One rule, one topic, 4,000 feeds:
#: the message says which (entity, event) partition is ready, and the
#: dependency it satisfies is spelled from those fields.
_NAME_FIELD_RE = re.compile(r"\{([A-Za-z_][A-Za-z0-9_]*)\}")

#: What a RENDERED dependency name may look like: the characters a feed
#: author can type into ``dependency_key`` without surprising the ledger
#: (no whitespace, no quotes, bounded).
_RENDERED_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.\-:/]{0,199}$")


def rule_is_templated(rule: "ResolverRule") -> bool:
    """Whether the rule's ``dependency_name`` carries ``{field}`` placeholders."""
    return bool(_NAME_FIELD_RE.search(str(rule.dependency_name or "")))


def render_dependency_name(template: str, payload: Mapping[str, Any],
                           field_values: Optional[Mapping[str, Mapping[str, str]]] = None,
                           ) -> str:
    """Spell the dependency a message is for, from its payload.

    Every field must be present with a non-blank scalar value; the rendered
    name must be a well-formed key.  Anything else raises
    :class:`UnresolvedMessage` -- the message is landed, marked
    unresolvable WITH the reason, alerted once and stepped over (FR-DEP-20);
    guessing an entity code is how a feed is released by another feed's
    partition.

    ``field_values`` (2026-10-11) is the rule's VALUE MAP, per field: the
    owner's messages say ``CLOUD_COMPLIANT: "true" / "false"`` and the
    dependency a feed author declares is ``..._CLOUD`` / ``..._ONPREM``.
    A mapped field's value must be one of the declared keys (compared as
    text, case-insensitively); a value the map does not name is REFUSED,
    not pasted -- a new upstream value must be a config change, never a
    dependency nobody declared.
    """
    missing, bad, unmapped = [], [], []
    maps = field_values or {}

    def _sub(m: "re.Match[str]") -> str:
        key = m.group(1)
        value = (payload or {}).get(key)
        if value is None or (isinstance(value, str) and not value.strip()):
            missing.append(key)
            return ""
        if isinstance(value, bool):
            value = "true" if value else "false"
        if not isinstance(value, (str, int, float)):
            bad.append(f"{key}={value!r}")
            return ""
        text = str(value).strip()
        vmap = maps.get(key)
        if not vmap:
            return text
        hit = _mapped_value(vmap, text)
        if hit is None:
            unmapped.append(f"{key}={text!r} (declared: {sorted(vmap)})")
            return ""
        return hit

    out = _NAME_FIELD_RE.sub(_sub, str(template))
    if missing or bad or unmapped:
        raise UnresolvedMessage(
            f"dependency name template {template!r} needs payload field(s) "
            + (f"{missing} which the message does not carry" if missing else "")
            + (" and " if missing and bad else "")
            + (f"{bad} which are not scalar values" if bad else "")
            + (" and " if (missing or bad) and unmapped else "")
            + (f"{unmapped} whose value is not in the rule's field_values map"
               if unmapped else "")
            + " -- refusing to guess which feed's partition this is")
    if not _RENDERED_NAME_RE.match(out):
        raise UnresolvedMessage(
            f"dependency name template {template!r} rendered {out!r}, which "
            f"is not a well-formed dependency key (letters, digits, _ . - : / "
            f"only, no whitespace or quotes, at most 200 characters)")
    return out


def _mapped_value(vmap: Mapping[str, str], text: str) -> Optional[str]:
    """The value map's spelling of ``text``: an exact key first, then a
    case-insensitive one; None when the map does not name it."""
    hit = vmap.get(text)
    if hit is None:
        low = text.lower()
        hit = next((v for k, v in vmap.items()
                    if str(k).strip().lower() == low), None)
    return str(hit).strip() if hit is not None else None


def template_matches(template: str, name: str) -> bool:
    """Could ``template`` have rendered ``name``?  Every literal part must
    appear in order and every field must take at least one character.  The
    evaluator asks this to know whether a templated rule ROUTES a feed's
    dependency key (a key no rule can ever produce "cannot be satisfied")."""
    if not rule_template_pattern(template).fullmatch(str(name or "")):
        return False
    return True


def rule_template_pattern(template: str) -> "re.Pattern[str]":
    parts, last = [], 0
    for m in _NAME_FIELD_RE.finditer(str(template or "")):
        parts.append(re.escape(template[last:m.start()]))
        parts.append(r"[A-Za-z0-9_.\-:/]+?")
        last = m.end()
    parts.append(re.escape(template[last:]))
    return re.compile("".join(parts))


#: A resolver rule is DATA.  Every new upstream system must be a config
#: change, not a deployment — otherwise onboarding a feed needs a release.
#: ``business_date_field`` names the payload key carrying the date;
#: ``business_date_format`` is an explicit strptime format, because guessing a
#: date format is how 01/02 becomes the wrong day for six months.
@dataclass(frozen=True)
class ResolverRule:
    topic: str
    dependency_name: str
    business_date_field: str
    business_date_format: str = "%Y-%m-%d"
    identity_fields: tuple = ("topic", "partition", "offset")
    match: Mapping[str, Any] = field(default_factory=dict)
    #: FR-DEP-24 — the payload key carrying the upstream's row count, when
    #: it publishes one.  Per-rule because every upstream names it
    #: differently; unset means this upstream reports no count, and the
    #: partial-load check simply does not apply to it.
    row_count_field: Optional[str] = None
    #: 2026-10-11 -- per templated field, how a payload VALUE is spelled in
    #: the dependency name: ``{"CLOUD_COMPLIANT": {"true": "CLOUD",
    #: "false": "ONPREM"}}``.  Empty = values pasted as they arrive.
    field_values: Mapping[str, Mapping[str, str]] = field(default_factory=dict)


_DATE_ONLY = re.compile(r"^\d{4}-\d{2}-\d{2}")


def rule_matches_payload(rule: "ResolverRule", payload: Mapping[str, Any]) -> bool:
    """Whether the rule's ``match`` filter admits ``payload`` -- every named
    field equal to its value (as given, or as text, so an Oracle NUMBER 1
    matches a rule written ``"1"``).  THE one reading of the filter: the
    resolver and the Oracle-table watcher both ask here."""
    for k, v in (rule.match or {}).items():
        got = (payload or {}).get(k)
        if got == v:
            continue
        if got is not None and v is not None and str(got).strip() == str(v).strip():
            continue
        return False
    return True


def resolve_message(message: Mapping[str, Any],
                    rules: Sequence[ResolverRule]) -> ResolvedArrival:
    """Map a landed message onto (dependency, business date, identity).

    The consumer's only job is to land the row; THIS decides what a message
    means.  Keeping it as data is what stops every new upstream system
    becoming a deployment.
    """
    topic = str(message.get("topic") or "")
    payload = message.get("payload") or {}
    filtered_by: list = []
    for rule in rules:
        if rule.topic != topic:
            continue
        if not rule_matches_payload(rule, payload):
            # 2026-10-11 -- a rule for this topic SAW the message and its
            # filter excluded it.  Remembered: if no other rule takes it,
            # that is a FILTERED message (ordinary traffic in another
            # state), not poison.
            filtered_by.append(rule)
            continue
        raw = payload.get(rule.business_date_field)
        bdate = _parse_business_date(raw, rule.business_date_format)
        if bdate is None:
            raise UnresolvedMessage(
                f"topic {topic!r} matched rule for {rule.dependency_name!r} "
                f"but its {rule.business_date_field!r} is {raw!r}, which is "
                f"not a {rule.business_date_format} date — refusing to guess "
                f"a business date")
        # 2026-10-10 -- a templated name is spelled from the payload: ONE
        # rule on ONE topic routes a message to exactly the feed whose
        # dependency key it renders (TETB_{SYSTEM_ENTITY}_{EventCode}).
        derived = rule_is_templated(rule)
        name = (render_dependency_name(rule.dependency_name, payload,
                                       rule.field_values)
                if derived else rule.dependency_name)
        return ResolvedArrival(
            dependency_name=name,
            business_date=bdate,
            message_identity=build_identity(message, rule.identity_fields),
            reported_rows=_read_reported_rows(payload, rule),
            derived=derived,
        )
    if filtered_by:
        shown = sorted({
            f"{k}={payload.get(k)!r} (rule wants {v!r})"
            for r in filtered_by for k, v in (r.match or {}).items()
            if not rule_matches_payload(
                ResolverRule(r.topic, r.dependency_name,
                             r.business_date_field, match={k: v}), payload)})
        raise FilteredMessage(
            f"topic {topic!r} is routed by {len(filtered_by)} rule(s) whose "
            f"match filter excludes this message: {'; '.join(shown)} -- "
            f"recorded as filtered; it satisfies nothing")
    raise UnresolvedMessage(
        f"no resolver rule matches topic {topic!r} — the message is landed and "
        f"kept, but it satisfies nothing until a rule is configured")


def _read_reported_rows(payload: Mapping[str, Any],
                        rule: "ResolverRule") -> Optional[int]:
    """The upstream's own row count, when its rule names the field.

    Three outcomes, and they must stay three:

    * the rule names no field -> ``None``.  This upstream does not report
      counts; the partial-load check does not apply to it and must not
      start failing because we invented a zero.
    * the field is present and parses -> that integer, INCLUDING 0.  An
      upstream that genuinely loaded no rows and says so is exactly the
      case FR-DEP-24 exists to catch.
    * the field is named but missing or unparseable -> ``None`` AND a
      WARNING.  "The upstream did not say" and "the upstream said
      something we could not read" lead to different investigations, and
      folding the second into 0 would page someone every night for a
      typo in a config key.
    """
    field_name = getattr(rule, "row_count_field", None)
    if not field_name:
        return None
    raw = payload.get(field_name)
    if raw is None:
        logger.warning(
            "[dependency_gate] %r names row_count_field %r but the payload "
            "has no such key -- reporting NO COUNT rather than 0; the "
            "expected-rows check will not run for this arrival",
            rule.dependency_name, field_name)
        return None
    try:
        return int(str(raw).strip())
    except (TypeError, ValueError):
        logger.warning(
            "[dependency_gate] %r reported a row count of %r, which is not "
            "an integer -- reporting NO COUNT rather than 0",
            rule.dependency_name, raw)
        return None


def build_identity(message: Mapping[str, Any], fields: Sequence[str]) -> str:
    """The identity that tells a REPLAY from a redelivery.

    Defaults to (topic, partition, offset): Kafka gives at-least-once
    delivery, so a rebalance re-delivers the SAME message and that must not
    read as an upstream re-send.
    """
    parts = []
    for key in fields:
        value = message.get(key)
        if value is None:
            value = (message.get("payload") or {}).get(key)
        parts.append("" if value is None else str(value))
    return "|".join(parts)


def _parse_business_date(raw: Any, fmt: str) -> Optional[date]:
    if isinstance(raw, date):
        return raw
    if raw is None:
        return None
    text = str(raw).strip()
    from datetime import datetime as _dt
    try:
        return _dt.strptime(text, fmt).date()
    except ValueError:
        pass
    # One tolerated shape: an ISO timestamp where a date was declared.  Any
    # OTHER mismatch is refused above rather than guessed at.
    if _DATE_ONLY.match(text):
        try:
            return _dt.strptime(text[:10], "%Y-%m-%d").date()
        except ValueError:
            return None
    return None


def classify_unresolvable(message: Mapping[str, Any], error: Exception) -> dict:
    """Turn an unresolvable message into a recorded, alert-once fact.

    FR-DEP-20 — a malformed message that can never resolve must not be retried
    forever, filling the logs.  Land it, mark it unresolvable WITH the parse
    error, alert once, and move on.  Never block the consumer on one bad row:
    one poison message must not stop every good one behind it.
    """
    return {
        "topic": message.get("topic"),
        "partition": message.get("partition"),
        "offset": message.get("offset"),
        "unresolvable": True,
        "reason": str(error)[:1000],
        "alert_once_key": (
            f"unresolvable:{message.get('topic')}:{message.get('partition')}"
            f":{message.get('offset')}"),
    }
