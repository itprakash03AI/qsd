"""Re-run ONLY the side that failed (2026-10-12, the owner: "if on-cloud
completed with 40 million and on-prem fails ... how will you rerun only
on-prem, or will you rerun from start again?" -- "user should have the
capability to rerun only the failed one").

A cross-source feed reads its CLOUD side (primary: the feed's own source)
and then its ON-PREM side (secondary: the second connection) into side
files, then merges them.  Before this module a failure of one side threw the
other side's file away, so a re-run read 40M cloud rows again.

THE RULE, decided here and nowhere else:

* KEEP -- when one side's read fails and the other side's read SUCCEEDED,
  the good side's file is moved under ``<output_dir>/kept_sides/`` and the
  failed execution records ``stage_timings.kept_side``: the side, the file,
  its rows, and the FINGERPRINT it was read under.
* FINGERPRINT -- what makes the kept rows the rows a fresh read would give:
  the feed, the business date, the side, that side's source / connection /
  query parameters (the SQL and its tokens), and that side's UPSTREAM
  CONTRACT identity (core/feed/upstream_contract.py: the governing message,
  its version, its expected rows).  A new or replayed message for
  that side changes it: the upstream says the data changed, so the kept rows
  are no longer the truth.
* OFFER -- ``offer(db, feed, execution)``: reusable only on the native lane,
  while the file exists and BOTH the fingerprint and the upstream token
  still match.  Otherwise the answer says why and a full re-run is the way.
* REUSE -- the re-run carries the kept record; the engine VERIFIES it again
  at execution (a value checked at the route and then trusted later would
  disagree with what runs) and reads only the failed side.  A record that no
  longer verifies is NOT an error: both sides are read, and the execution
  says why the reuse was refused.  The reused side is still certified
  against its message like any read; ``stage_timings.reused_side`` records
  what was reused and from which execution.  The kept file is deleted once
  a run that used it completes.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import shutil
from datetime import date
from pathlib import Path
from typing import Any, Dict, Mapping, Optional

logger = logging.getLogger(__name__)

KEPT_KEY = "kept_side"
REUSED_KEY = "reused_side"
REUSE_REFUSED_KEY = "reuse_refused"
SIDES = ("primary", "secondary")
class _SideWords(dict):
    """side -> its configured label (core/feed/environments.py), read live."""
    def __missing__(self, side):
        from core.feed.environments import label
        return label(side) or side

    def get(self, side, default=None):
        return self[side] if side is not None else default


SIDE_WORDS = _SideWords()
#: the lanes whose cross-source read this module understands (the Spark job
#: reads both sides inside the job; it keeps nothing)
REUSABLE_LANES = ("native",)


def other(side: str) -> str:
    return "secondary" if side == "primary" else "primary"


def _side_config(feed_config: Mapping[str, Any], side: str) -> Dict[str, Any]:
    if side == "primary":
        fc = dict(feed_config)
    else:
        from core.feed.source_plan import secondary_side_config
        fc = secondary_side_config(dict(feed_config))
    qp = {k: v for k, v in (fc.get("query_params") or {}).items() if not str(k).startswith("_")}
    return {"source_type": fc.get("source_type"), "source_id": fc.get("source_id"),
            "connection_id": fc.get("connection_id"), "query_params": qp,
            "secondary_raw_sql": (feed_config.get("query_params") or {}).get("secondary_raw_sql")
            if side == "secondary" else None}


def fingerprint(feed_config: Mapping[str, Any], side: str, business_date: Optional[date]) -> str:
    """What the side's rows were read under (module docstring)."""
    body = {"feed": feed_config.get("id"), "business_date": str(business_date or ""),
            "side": side, "read": _side_config(feed_config, side)}
    raw = json.dumps(body, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def upstream_token(db, feed_config: Mapping[str, Any], side: str,
                   business_date: Optional[date]) -> Optional[str]:
    """The side's UPSTREAM CONTRACT identity (core/feed/upstream_contract.py):
    the governing message, its version tokens and expected rows -- a new or
    replayed message (a new version) changes it.  The execution's own
    resolved contract when there is one, else resolved now.  None when the
    side is governed by no message.  Raises when unreadable (unknown is not
    "unchanged")."""
    from core.feed import upstream_contract
    contracts = feed_config.get("_upstream_contract")
    if not isinstance(contracts, Mapping):
        contracts = upstream_contract.resolve(db, feed_config, business_date)
    if "_unreadable" in contracts:
        raise RuntimeError(contracts["_unreadable"])
    return upstream_contract.identity(contracts.get(side))


def keep(db, feed_config: Mapping[str, Any], side: str, path: str, *,
         execution_id: str, business_date: Optional[date], output_dir: str) -> Optional[Dict[str, Any]]:
    """Move the good side's file out of the temp area and describe it.
    None when it cannot be kept (said in the log; the re-run is then full)."""
    if not path or not os.path.exists(path):
        return None
    try:
        rows = _parquet_rows(path)
        dest_dir = Path(output_dir) / "kept_sides"
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest = dest_dir / f"{execution_id}_{side}.parquet"
        shutil.move(str(path), str(dest))
        try:
            token = upstream_token(db, feed_config, side, business_date)
        except Exception as exc:                        # noqa: BLE001 -- kept, but never offered
            logger.warning("[side_resume] %s side kept but its upstream is unreadable (%s): "
                           "it will not be offered for reuse", side, exc)
            token = "unreadable"
        rec = {"side": side, "path": str(dest), "rows": rows, "execution_id": execution_id,
               "business_date": str(business_date or ""),
               "fingerprint": fingerprint(feed_config, side, business_date), "upstream": token}
        logger.info("[side_resume] feed %s: the %s side (%s rows) is KEPT for a re-run of the "
                    "other side only -> %s", feed_config.get("id"), SIDE_WORDS[side], rows, dest)
        return rec
    except Exception as exc:                            # noqa: BLE001 -- a full re-run still works
        logger.warning("[side_resume] feed %s: could not keep the %s side (%s) -- a re-run "
                       "reads both sides", feed_config.get("id"), side, exc)
        return None


def _parquet_rows(path: str) -> Optional[int]:
    try:
        import pyarrow.parquet as pq
        return int(pq.ParquetFile(path).metadata.num_rows)
    except Exception:                                   # noqa: BLE001
        return None


def verify(db, feed_config: Mapping[str, Any], kept: Mapping[str, Any],
           business_date: Optional[date]) -> Optional[str]:
    """None when ``kept`` may stand in for a fresh read of its side NOW,
    else the reason it may not.  THE check: the offer and the engine both
    call it."""
    side = str(kept.get("side") or "")
    if side not in SIDES:
        return f"the kept record names no side ({side!r})"
    path = str(kept.get("path") or "")
    if not path or not os.path.exists(path):
        return f"the kept {SIDE_WORDS[side]} rows are no longer on disk ({path or 'no file'})"
    if str(kept.get("business_date") or "") != str(business_date or ""):
        return (f"the kept {SIDE_WORDS[side]} rows are for {kept.get('business_date')}, "
                f"this run is for {business_date}")
    if kept.get("fingerprint") != fingerprint(feed_config, side, business_date):
        return (f"the {SIDE_WORDS[side]} side's query, source or parameters changed since its "
                f"rows were kept")
    if kept.get("upstream") == "unreadable":
        return f"the {SIDE_WORDS[side]} side's upstream messages could not be read when it was kept"
    try:
        now = upstream_token(db, feed_config, side, business_date)
    except Exception as exc:                            # noqa: BLE001 -- unknown refuses
        return f"the {SIDE_WORDS[side]} side's upstream messages cannot be read now ({exc})"
    if now != kept.get("upstream"):
        return (f"a new {SIDE_WORDS[side]} message arrived since its rows were kept -- the "
                f"upstream says the data changed, so both sides are read again")
    rows = _parquet_rows(path)
    if kept.get("rows") is not None and rows != kept.get("rows"):
        return f"the kept {SIDE_WORDS[side]} file holds {rows} rows, {kept.get('rows')} were kept"
    return None


def offer(db, feed_config: Mapping[str, Any], execution: Mapping[str, Any],
          business_date: Optional[date]) -> Optional[Dict[str, Any]]:
    """For a FAILED execution: may the failed side alone be re-run?
    ``{"rerun_side", "kept_side", "kept_rows", "ok", "reason"}`` or None
    when the execution kept nothing (then only a full re-run exists)."""
    st = execution.get("stage_timings") or {}
    kept = st.get(KEPT_KEY)
    if str(execution.get("status") or "") != "failed" or not isinstance(kept, dict):
        return None
    side = str(kept.get("side") or "")
    out = {"rerun_side": other(side) if side in SIDES else None, "kept_side": side,
           "kept_rows": kept.get("rows"), "from_execution": kept.get("execution_id"),
           "ok": False, "reason": None}
    if str(execution.get("execution_backend") or "native") not in REUSABLE_LANES:
        out["reason"] = f"the {execution.get('execution_backend')} lane reads both sides in one job"
        return out
    why = verify(db, feed_config, kept, business_date)
    out["ok"], out["reason"] = why is None, why
    return out


def working_copy(kept: Mapping[str, Any], work_dir: str) -> str:
    """A path the merge may CONSUME (the zero-copy union MOVES its side files
    into the result) while the kept file survives for another try: a hard
    link -- no bytes copied, 40M rows cost nothing -- or a copy where the
    filesystem refuses links."""
    src = str(kept["path"])
    Path(work_dir).mkdir(parents=True, exist_ok=True)
    dest = str(Path(work_dir) / f"reused_{Path(src).stem}_{os.getpid()}_{id(kept)}.parquet")
    try:
        os.link(src, dest)
    except OSError:
        shutil.copy2(src, dest)
    return dest


def discard(kept: Optional[Mapping[str, Any]]) -> None:
    """Delete a kept file once a run that used it completed."""
    path = str((kept or {}).get("path") or "")
    if path and "kept_sides" in path:
        try:
            os.remove(path)
        except OSError:
            pass
