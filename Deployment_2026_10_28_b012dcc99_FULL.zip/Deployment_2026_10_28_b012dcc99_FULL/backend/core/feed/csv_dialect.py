"""THE counterparty CSV dialect — resolved once, applied by both lanes.

QueryStudio has two feed implementations: ``core/feed/`` (native) and
``spark/jobs/generic_feed.py`` (the heavy lane, standalone, importing
nothing from this codebase).  The split is deliberate at DELIVERY — a
job that ships a file over SFTP and then dies before its webhook lands
presents as FAILED, and the resubmit delivers it twice — but reading,
writing and FORMATTING were duplicated, and duplicated code drifts.

It drifted within a day.  On 2026-09-02 the Spark job's own comment
recorded the previous instance ("a feed declaring delimiter='|' shipped
PIPES on the native lane and COMMAS on this one — same feed, same
definition, two different files, no error on either") and mapped the
three options the native renderer then supported.  On 2026-09-03 the
native renderer gained seven more and the authoring refusals were
lifted, which silently re-created the same defect the comment was
written about: a feed declaring ``line_terminator: lf`` got LF natively
and CRLF on Spark.  Routing is by SIZE, so the biggest feed — where the
format matters most — was the one that got it wrong.

So the dialect is resolved HERE, once, and both lanes APPLY the result:

* :func:`resolve` turns ``output_options`` into the canonical dialect.
  ``CsvRenderer`` consumes it directly.
* :func:`to_spark_writer_options` maps that same dialect onto Spark's
  CSV writer, and returns the terms Spark CANNOT express alongside it.
* the submit path ships the resolved dialect in ``--feed-config`` and
  REFUSES when anything is unexpressible, rather than shipping a
  different file under a green status.

There is deliberately no ``assert_expressible_on_spark`` helper here.
One existed briefly and became a SECOND entry point for "can this
engine express the contract?" -- which is the same duplication this
module exists to remove, one level up.  That question is answered in
exactly one place: ``core.feed.execution_contract``.

Spark's CSV writer is not a superset of Python's.  It has ``quoteAll``
(a boolean) where Python has four quoting modes, and it has no trailing
delimiter at all.  Those gaps are NAMED and refused — never silently
approximated, because an approximation here is a file the counterparty
parses wrongly without anyone finding out.
"""
from __future__ import annotations

import csv
from typing import Any, Mapping

#: line_terminator vocabulary -> the actual characters.
#: Built with chr() deliberately: a backslash-r escape written through a
#: shell heredoc arrives as a REAL carriage return and splits the line it
#: sits on.  That happened while this was being written.
TERMINATORS = {
    "crlf": chr(13) + chr(10),
    "lf": chr(10),
    "cr": chr(13),
}
DEFAULT_TERMINATOR = "crlf"

#: quoting vocabulary -> the Python csv constant.
QUOTING = {
    "minimal": csv.QUOTE_MINIMAL,
    "all": csv.QUOTE_ALL,
    "nonnumeric": csv.QUOTE_NONNUMERIC,
    "none": csv.QUOTE_NONE,
}
DEFAULT_QUOTING = "minimal"


class DialectError(ValueError):
    """A dialect that cannot be honoured, with the reason."""


def resolve(options: Mapping[str, Any] | None) -> dict:
    """The canonical dialect for one feed's ``output_options``.

    Every default reproduces the pre-2026-09-03 output byte for byte:
    utf-8, CRLF, minimal quoting, the double-quote character, no escape
    character, no trailing delimiter.  Serving a term must add a choice,
    never change what existing feeds emit.

    Raises :class:`DialectError` on a combination that cannot be
    written.  Refusing before the first byte beats failing mid-file,
    after the header has already shipped.
    """
    opts = dict(options or {})

    terminator_name = str(opts.get("line_terminator") or "").strip().lower()
    if terminator_name and terminator_name not in TERMINATORS:
        raise DialectError(
            f"unknown line_terminator {opts.get('line_terminator')!r} — one "
            f"of {tuple(TERMINATORS)}")
    terminator_name = terminator_name or DEFAULT_TERMINATOR

    quoting_name = str(opts.get("quoting") or "").strip().lower()
    if quoting_name and quoting_name not in QUOTING:
        raise DialectError(
            f"unknown quoting {opts.get('quoting')!r} — one of "
            f"{tuple(QUOTING)}")
    quoting_name = quoting_name or DEFAULT_QUOTING

    quotechar = str(opts.get("quotechar") or '"')[:1] or '"'
    escapechar = (str(opts.get("escapechar"))[:1]
                  if opts.get("escapechar") else None)
    if quoting_name == "none" and not escapechar:
        raise DialectError(
            "quoting='none' requires an escapechar: without one the writer "
            "fails on the first value containing the delimiter — mid-file, "
            "after the header has already shipped")

    delimiter = str(opts.get("delimiter") or ",")
    if len(delimiter) != 1:
        raise DialectError(
            f"delimiter must be exactly one character, got {delimiter!r}")

    return {
        "delimiter": delimiter,
        "header": bool(opts.get("header", True)),
        "encoding": str(opts.get("encoding") or "utf-8"),
        "line_terminator": terminator_name,
        "terminator_chars": TERMINATORS[terminator_name],
        "quoting": quoting_name,
        "quoting_const": QUOTING[quoting_name],
        "quotechar": quotechar,
        "escapechar": escapechar,
        "na_rep": ("" if opts.get("na_rep") is None
                   else str(opts.get("na_rep"))),
        "empty_string_marker": opts.get("empty_string_marker"),
        "trailing_delimiter": bool(opts.get("trailing_delimiter")),
    }


#: Spark's CSV writer keys for the terms it CAN express.
_SPARK_KEYS = {
    "delimiter": "sep",
    "encoding": "encoding",
    "quotechar": "quote",
    "escapechar": "escape",
    "na_rep": "nullValue",
}


def to_spark_writer_options(dialect: Mapping[str, Any]) -> tuple:
    """``(writer_options, unexpressible)`` for the Spark CSV writer.

    Spark's writer is NOT a superset of Python's.  It offers ``quoteAll``
    — a boolean — where Python has four quoting modes, and it has no
    trailing-delimiter concept.  Those terms come back in
    ``unexpressible`` so the caller can REFUSE, because approximating
    them produces a file the counterparty parses wrongly with nothing
    anywhere reporting a problem.

    Every value is a string: Spark requires it.
    """
    out: dict = {}
    unexpressible: list = []

    for key, spark_key in _SPARK_KEYS.items():
        value = dialect.get(key)
        if value is None or value == "":
            # nullValue="" IS meaningful — send it explicitly.
            if key == "na_rep" and value == "":
                out[spark_key] = ""
            continue
        out[spark_key] = str(value)

    out["header"] = "true" if dialect.get("header", True) else "false"
    out["lineSep"] = dialect.get(
        "terminator_chars", TERMINATORS[DEFAULT_TERMINATOR])

    quoting = str(dialect.get("quoting") or DEFAULT_QUOTING)
    if quoting == "all":
        out["quoteAll"] = "true"
    elif quoting == "minimal":
        out["quoteAll"] = "false"
    else:
        # nonnumeric / none: Spark has no equivalent.  Named, not
        # approximated.
        unexpressible.append(
            f"quoting={quoting!r} (Spark's CSV writer offers only "
            f"quoteAll=true|false; it cannot express QUOTE_NONNUMERIC or "
            f"QUOTE_NONE)")

    marker = dialect.get("empty_string_marker")
    if marker is not None:
        out["emptyValue"] = str(marker)

    if dialect.get("trailing_delimiter"):
        unexpressible.append(
            "trailing_delimiter=true (Spark's CSV writer emits no trailing "
            "field separator)")

    return out, unexpressible

