"""FR-ART-10 — filename collision refusal AT AUTHORING (BRD §10.3).

Two feeds resolving to the same filename at the same destination are
refused when the second one is SAVED — not discovered the night one
silently overwrites the other at a shared SFTP drop.  The refusal NAMES
the other feed, because "your filename collides" without a culprit is a
support ticket, not a refusal.

How collision is decided (both halves must hold):

1.  **Same rendered filename, proven on two probe dates.**  Templates
    are rendered through the REAL renderer chokepoint
    (``pipeline.render_filename_for_feed``) with each feed's own
    identity (name, id) and two fixed, distinct probe dates.  Equal
    output on ONE date can be a coincidence of formats; equal on BOTH
    (which differ in every date component) means the templates are the
    same function of the calendar — every night they will collide.
    Feed-identity tokens (``{feed_name}``, ``{feed_id}``) naturally
    differ per feed and correctly defuse the collision.

2.  **Same destination.**  A filename is only a collision where the
    files LAND together.  Destination identity is canonicalised per
    type (sftp host/port/path, s3 bucket/prefix, local path); two
    destinations that cannot be proven distinct compare by their full
    config — conservative in the refusing direction for same-type
    targets, and never a false refusal across different target types.

A template that cannot be rendered (unknown token, missing calendar
context) is NOT judged here — it cannot be PROVEN to collide, and the
renderer's own validation owns that refusal.  Skipping it is stated in
the result rather than silent.

Pure over its inputs: the caller (feed_api at save) supplies the
candidate and the other feeds' configs; nothing here touches the DB.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from typing import Any, Iterable, List, Mapping, Optional, Tuple

#: Two probe dates with no shared component (year, month, day, month
#: name all differ) — templates equal under BOTH are the same function
#: of the calendar.
_PROBE_DATES = (date(2001, 2, 3), date(2014, 7, 19))


@dataclass(frozen=True)
class Collision:
    other_feed_id: Any
    other_feed_name: str
    filename: str
    destination: str

    @property
    def message(self) -> str:
        return (
            f"filename collision (FR-ART-10): this feed and feed "
            f"{self.other_feed_name!r} (id {self.other_feed_id}) both "
            f"resolve to {self.filename!r} at the same destination "
            f"({self.destination}) — at delivery one would silently "
            f"overwrite the other.  Change the filename template (a "
            f"{{feed_name}} token distinguishes them) or the destination")


def _probe_render(feed: Mapping[str, Any], probe: date) -> Optional[str]:
    """Render this feed's template on a probe date; None = unprovable."""
    template = str(feed.get("output_filename_template") or "").strip()
    if not template:
        return None
    from .pipeline import render_filename_for_feed
    fmt = str(feed.get("output_format") or "csv").lower()
    ext = {"csv": "csv", "parquet": "parquet", "json": "jsonl",
           "excel": "xlsx"}.get(fmt, fmt)
    try:
        return render_filename_for_feed(
            template, ext, dict(feed), business_date=probe, run_id=0,
            run_date=probe)
    except Exception:  # noqa: BLE001 — unprovable, stated by caller
        return None


def destination_identity(feed: Mapping[str, Any]
                         ) -> Tuple[str, Tuple[Any, ...]]:
    """Canonical (type, identity) for where this feed's files LAND."""
    dtype = str(feed.get("destination_type") or "local").strip().lower()
    cfg = dict(feed.get("destination_config") or {})
    if dtype == "sftp":
        ident: Tuple[Any, ...] = (
            str(cfg.get("host") or "").strip().lower(),
            int(cfg.get("port") or 22),
            _norm_path(cfg.get("remote_path") or cfg.get("path") or ""))
    elif dtype in ("s3", "archive"):
        ident = (str(cfg.get("bucket") or "").strip().lower(),
                 _norm_path(cfg.get("prefix") or ""))
    elif dtype == "local":
        ident = (_norm_path(cfg.get("path") or cfg.get("directory")
                            or ""),)
    else:
        # Unknown target type: identity is the sorted non-credential
        # config — equal configs land together, distinct configs don't.
        ident = tuple(sorted(
            (k, str(v)) for k, v in cfg.items()
            if not _looks_secret(k)))
    return (dtype, ident)


def _norm_path(p: Any) -> str:
    s = str(p or "").strip().replace("\\", "/")
    while "//" in s:
        s = s.replace("//", "/")
    return s.rstrip("/").lower()


def _looks_secret(key: str) -> bool:
    k = str(key).lower()
    return any(w in k for w in ("password", "secret", "token", "key",
                                "credential", "passphrase"))


CollisionKey = Tuple[Tuple[str, Tuple[Any, ...]], Tuple[str, ...]]


def collision_key(feed: Mapping[str, Any]) -> Optional[CollisionKey]:
    """What two feeds must share to collide: (destination identity, the
    renders on both probe dates).  ``None`` = unprovable (no template, or
    one the renderer refuses) -- such a feed is never judged."""
    renders = tuple(_probe_render(feed, p) for p in _PROBE_DATES)
    if any(r is None for r in renders):
        return None
    return (destination_identity(feed), renders)  # type: ignore[return-value]


class CollisionIndex:
    """Every indexed feed under its :func:`collision_key`, so asking
    "which feeds collide with this candidate" is one dictionary lookup
    instead of a render of every other feed's template (2026-10-10).

    Built once over a list of feeds, each costing two renders; a feed
    saved afterwards is :meth:`add`-ed (or :meth:`remove`-d and re-added)
    so the index stays current as a batch of creates proceeds -- the
    feed template apply holds one for its whole matrix, where the
    per-member "render every other feed" made 4,000 members quadratic.
    :func:`find_filename_collisions` IS this index over the caller's list:
    one reading of "collides", whichever way the feeds arrive.
    """

    def __init__(self, feeds: Iterable[Mapping[str, Any]] = ()):
        self._buckets: dict = {}        # key -> [(feed id, name)], in add order
        self._key_of: dict = {}         # feed id -> key (feeds WITH an id)
        self.indexed = 0                # feeds that have a key (provable)
        self.unprovable = 0             # feeds skipped: no template / unrenderable
        for f in feeds:
            self.add(f)

    def add(self, feed: Mapping[str, Any]) -> None:
        fid = feed.get("id")
        if fid is not None:
            self.remove(fid)
        # 2026-10-12 -- an INACTIVE feed delivers nothing, so it collides with
        # nothing: it leaves the index (a retired feed blocked its own
        # successor -- found by the owner's month-end journey).  Reactivating
        # it is an update, which runs this check against the active feeds.
        if feed.get("is_active") is False:
            return
        key = collision_key(feed)
        if key is None:
            self.unprovable += 1
            return
        self.indexed += 1
        self._buckets.setdefault(key, []).append(
            (fid, str(feed.get("name") or "<unnamed>")))
        if fid is not None:
            self._key_of[fid] = key

    def remove(self, feed_id: Any) -> bool:
        key = self._key_of.pop(feed_id, None)
        if key is None:
            return False
        bucket = self._buckets.get(key) or []
        bucket[:] = [e for e in bucket if e[0] != feed_id]
        if not bucket:
            self._buckets.pop(key, None)
        self.indexed -= 1
        return True

    def collisions(self, candidate: Mapping[str, Any], *,
                   exclude_id: Any = None) -> List[Collision]:
        """Every indexed feed the candidate collides with, in index
        order.  The candidate's own stored row (its ``id``, or
        ``exclude_id`` on an update) is never its own collision."""
        if candidate.get("is_active") is False:
            return []                   # it delivers nothing: nothing to overwrite
        key = collision_key(candidate)
        if key is None:
            return []
        skip = {i for i in (candidate.get("id"), exclude_id) if i is not None}
        dest, renders = key
        return [Collision(other_feed_id=fid, other_feed_name=name,
                          filename=renders[0] or "",
                          destination=f"{dest[0]}:{dest[1]}")
                for fid, name in self._buckets.get(key, ())
                if fid is None or fid not in skip]


def find_filename_collisions(
        candidate: Mapping[str, Any],
        other_feeds: Iterable[Mapping[str, Any]]) -> List[Collision]:
    """Every OTHER feed the candidate collides with.  A feed with no
    template, or one whose template cannot be rendered, yields no
    collisions — unprovable is not proven."""
    return CollisionIndex(other_feeds).collisions(candidate)
