"""Rung 1 orchestration — the ENGINE writes, QueryStudio certifies.

2026-08-22, design_starburst_140m §4.2 rung 1.  The connector's
``unload_to_s3`` makes the cluster write parquet parts straight to S3;
this module owns everything around that statement:

  * scratch-table naming (collision-proof, DDL-safe by construction),
  * listing the parts the engine wrote (paginated, NO file-count cap —
    a cap here would silently drop parts from the manifest, which is
    row loss wearing a success banner),
  * per-part FOOTER reads (ranged GETs, ~16–64KB per part — never the
    data pages) to get each part's row count and schema,
  * the COMPLETENESS GATE: sum(part footer rows) must equal the
    engine-reported CTAS count, or the run FAILS.  A row count we did
    not verify is never reported as verified — and an unverifiable one
    fails loudly rather than shipping "probably complete",
  * lifecycle: the scratch table is ALWAYS dropped (finally), and on
    failure the orphaned S3 objects are deleted — a CTAS target left
    behind after a failure is garbage in the customer's catalog/bucket,
  * optional local materialisation (byte downloads — rows are never
    decoded in this process; that is the whole point of rung 1).

RLS: the SQL handed to this module must arrive ALREADY secured
(``secure_feed_sql`` runs before rung selection in the feed engine);
``unload_to_s3`` embeds it verbatim into the CTAS, so the pushed-down
write executes exactly the row-secured text — asserted by tests on the
generated statement.
"""
from __future__ import annotations

import logging
import re
import struct
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from core.feed.parts_manifest import (
    PartInfo, PartsManifest, sql_sha256,
)

logger = logging.getLogger(__name__)


class EngineUnloadError(RuntimeError):
    """Rung 1 failed.  ``stage`` names where; the message names the fix.

    Deliberately NOT silently degraded to rung 3: an operator who
    declared the engine_write capability wants to know it is broken,
    and a silent fallback masks a broken declaration forever (per-feed
    ``backend_config.write_rung='native_stream'`` is the explicit
    escape hatch while fixing it)."""

    def __init__(self, stage: str, message: str):
        super().__init__(f"[engine-unload:{stage}] {message}")
        self.stage = stage


@dataclass
class UnloadResult:
    manifest: PartsManifest
    rows_reported: int
    query_id: str
    table_fqn: str
    external_location: str
    ctas_sql: str
    s3_bucket: str
    s3_prefix: str
    verified: bool = True
    empty_columns: List[str] = field(default_factory=list)
    #: 2026-10-11 -- the LIMIT-0 probe's ``{name, type}`` per column, so a
    #: 0-row unload's typed-empty parquet carries the ENGINE'S types.  The
    #: names alone made every column a string, and a cross-source merge
    #: whose cloud side had no rows yet refused "BUSINESS_CLOSE_DATE is
    #: string on the primary side and date32[day] on the secondary" (live,
    #: 2026-10-11) -- the refusal was right; the empty file was wrong.
    empty_column_types: List[Dict[str, Any]] = field(default_factory=list)


def parse_s3_uri(uri: str) -> Tuple[str, str]:
    m = re.match(r"^s3a?://([^/]+)/?(.*)$", str(uri or "").strip())
    if not m:
        raise EngineUnloadError("config",
                                f"not an s3:// / s3a:// URI: {uri!r}")
    return m.group(1), m.group(2).rstrip("/")


def _list_all_objects(s3_client, bucket: str, prefix: str) -> List[Dict[str, Any]]:
    """Every object under prefix — paginated, deliberately UNCAPPED.

    ``list_s3_parquet_files`` (s3_utilities) caps at ``max_files`` and
    truncates; a truncated part listing here would build a manifest
    missing rows while the count gate below compares against a SUM of
    the listed parts — both sides short TOGETHER is exactly the failure
    a completeness gate exists to prevent.  So: our own paginator, no cap.
    """
    out: List[Dict[str, Any]] = []
    token = None
    while True:
        kwargs = {"Bucket": bucket, "Prefix": prefix + "/"}
        if token:
            kwargs["ContinuationToken"] = token
        resp = s3_client.list_objects_v2(**kwargs)
        for obj in resp.get("Contents") or []:
            out.append(obj)
        if not resp.get("IsTruncated"):
            break
        token = resp.get("NextContinuationToken")
        if not token:
            raise EngineUnloadError(
                "list", f"S3 listing of s3://{bucket}/{prefix}/ reported "
                        f"IsTruncated with no continuation token")
    return out


_FOOTER_PROBE_BYTES = 64 * 1024


def _read_parquet_footer(s3_client, bucket: str, key: str, size: int):
    """(num_rows, arrow_schema) from ranged GETs of the parquet FOOTER.

    Two GETs worst case (~16–256KB), never the data pages — the same
    footer-capture economics the pruning brain uses (08-21: ~16–256KB
    per file vs 32.2GB of data)."""
    import pyarrow as pa
    import pyarrow.parquet as pq

    if size < 12:
        raise EngineUnloadError(
            "footer", f"s3://{bucket}/{key} is {size} bytes — not parquet")
    probe = min(size, _FOOTER_PROBE_BYTES)
    tail = s3_client.get_object(
        Bucket=bucket, Key=key,
        Range=f"bytes={size - probe}-{size - 1}",
    )["Body"].read()
    if tail[-4:] != b"PAR1":
        raise EngineUnloadError(
            "footer", f"s3://{bucket}/{key} does not end with the parquet "
                      f"magic — the engine wrote something else here")
    footer_len = struct.unpack("<I", tail[-8:-4])[0]
    need = footer_len + 8
    if need > size:
        raise EngineUnloadError(
            "footer", f"s3://{bucket}/{key}: footer length {footer_len} "
                      f"exceeds the file size {size}")
    if need > len(tail):
        tail = s3_client.get_object(
            Bucket=bucket, Key=key,
            Range=f"bytes={size - need}-{size - 1}",
        )["Body"].read()
    footer_bytes = tail[-need:]
    md = pq.read_metadata(pa.BufferReader(footer_bytes))
    return int(md.num_rows), md.schema.to_arrow_schema()


def build_unload_s3_client(conn_config: Dict[str, Any], s3_location: str):
    """boto3 client for the unload location.

    ``unload_s3_access`` (dict on the TRINO connection's config, standard
    S3 keys: aws_access_key_id/…, endpoint_url, region_name, auth_mode)
    goes through the product's ONE S3 client chokepoint
    (``S3StorageHandler``/``build_s3_config`` — SSL bundles, VPCE
    normalisation, region resolution).  Absent, the ambient boto3 chain
    (IRSA / instance profile / env) is used — standard for in-cluster
    pods, and it fails loudly at the first call if nothing is there.
    """
    access = conn_config.get("unload_s3_access")
    bucket, _ = parse_s3_uri(s3_location)
    if isinstance(access, dict) and access:
        from core.s3_storage import S3StorageHandler, build_s3_config
        cfg = dict(access)
        cfg.setdefault("bucket_name", bucket)
        return S3StorageHandler(build_s3_config(cfg)).s3_client
    import boto3
    return boto3.client("s3")


def _scratch_table_name(exec_id: str) -> str:
    frag = re.sub(r"[^a-z0-9_]", "", str(exec_id or "").lower())[:24]
    # A random tail so a re-run of the same execution id can never
    # collide with a half-dropped predecessor.
    return f"qs_unload_{frag}_{uuid.uuid4().hex[:8]}"


def _delete_prefix(s3_client, bucket: str, prefix: str) -> None:
    """Best-effort orphan cleanup after a FAILED unload.  Failure to
    clean is logged at ERROR with the exact prefix — an orphan the
    operator does not know about is worse than one they do."""
    try:
        objs = _list_all_objects(s3_client, bucket, prefix)
        for i in range(0, len(objs), 1000):
            batch = objs[i:i + 1000]
            s3_client.delete_objects(
                Bucket=bucket,
                Delete={"Objects": [{"Key": o["Key"]} for o in batch],
                        "Quiet": True},
            )
        if objs:
            logger.info("[engine-unload] cleaned %d orphaned object(s) "
                        "under s3://%s/%s/", len(objs), bucket, prefix)
    except Exception as exc:
        logger.error(
            "[engine-unload] FAILED to clean orphaned unload objects under "
            "s3://%s/%s/ — delete them manually: %s", bucket, prefix, exc,
        )


def cleanup_unload_prefix(s3_client, bucket: str, prefix: str) -> None:
    """Delete an unload scratch prefix.

    2026-09-01 -- ``published_views_api`` has always imported this name and
    it did not exist; the module's deleter is the private ``_delete_prefix``.
    Because that import pulls FOUR names at once, the ImportError took the
    other three with it, so the ENTIRE engine-write rung for published views
    was unreachable and fell through to the slower path.

    A public wrapper rather than a rename: ``_delete_prefix`` has in-module
    callers, and exporting the capability is what was missing.
    """
    _delete_prefix(s3_client, bucket, prefix)


#: 2026-10-12 -- a parquet writer keeps a page + dictionary buffer PER COLUMN
#: until a row group closes.  At the engine defaults (128 MB row groups,
#: 1 MB pages) the owner's 460-column fact_tetb CTAS exceeded 1.76 GB and then
#: 2.73 GB per node at ANY task concurrency; with 32 MB / 256 kB the same
#: 36M-row CTAS wrote in 9m47s.  Wide = this many output columns or more
#: (or a width only the source knows, SELECT *).
WIDE_UNLOAD_COLUMNS = 100
WIDE_WRITER_SESSION = {"parquet_writer_block_size": "32MB", "parquet_writer_page_size": "256kB"}
_WRITER_SIZE_RE = __import__("re").compile(r"^\d+(B|kB|MB|GB)$")


def writer_session_for(sql: str, conn_config: Optional[dict] = None) -> Dict[str, str]:
    """THE parquet-writer sizing of a rung-1 CTAS, from the statement's WIDTH.
    The connection's ``unload_parquet_writer`` ({block_size, page_size})
    wins; else a wide statement gets ``WIDE_WRITER_SESSION``; else {} (the
    engine's defaults stand).  Values are validated (they are interpolated
    into SET SESSION); a malformed override is ignored, said in the log."""
    override = (conn_config or {}).get("unload_parquet_writer")
    if isinstance(override, dict) and override:
        out: Dict[str, str] = {}
        for k, prop in (("block_size", "parquet_writer_block_size"),
                        ("page_size", "parquet_writer_page_size")):
            v = str(override.get(k) or "").strip()
            if v and _WRITER_SIZE_RE.match(v):
                out[prop] = v
            elif v:
                logger.warning("[engine_unload] unload_parquet_writer.%s=%r is not a "
                               "size like 32MB -- ignored", k, v)
        return out
    from core.feed.batch_budget import sql_width
    width = sql_width(sql)
    if width is None or width >= WIDE_UNLOAD_COLUMNS:
        return dict(WIDE_WRITER_SESSION)
    return {}


def run_engine_unload(
    connector,
    sql: str,
    *,
    feed_config: Optional[dict] = None,
    exec_id: str = "",
    cancel_event=None,
    s3_client=None,
) -> UnloadResult:
    """Execute rung 1 end to end.  See module docstring for the contract."""
    feed_config = feed_config if isinstance(feed_config, dict) else {}
    caps = (connector.write_capabilities() or {}).get("engine_write") or {}
    scratch_catalog = str(caps.get("scratch_catalog") or "")
    scratch_schema = str(caps.get("scratch_schema") or "")
    s3_location = str(caps.get("s3_location") or "")
    if not (scratch_catalog and scratch_schema and s3_location):
        raise EngineUnloadError(
            "capability",
            "run_engine_unload called without a complete engine_write "
            "declaration — the ladder must not route here (this is a "
            "routing bug, not a configuration problem)")

    if s3_client is None:
        s3_client = build_unload_s3_client(connector.config, s3_location)

    table_name = _scratch_table_name(exec_id)
    bucket, base_prefix = parse_s3_uri(s3_location)
    prefix = f"{base_prefix}/{table_name}" if base_prefix else table_name

    table_fqn = ""
    unload: Optional[Dict[str, Any]] = None
    try:
        try:
            unload = connector.unload_to_s3(
                sql,
                s3_location=s3_location,
                scratch_catalog=scratch_catalog,
                scratch_schema=scratch_schema,
                table_name=table_name,
                cancel_event=cancel_event,
                writer_session=writer_session_for(sql, getattr(connector, "config", None)),
            )
        except InterruptedError:
            raise
        except Exception as exc:
            raise EngineUnloadError(
                "ctas",
                f"engine-side CTAS failed on the cluster: "
                f"{type(exc).__name__}: {exc}.  The connection declares the "
                f"engine_write capability; if the scratch schema or S3 "
                f"location is broken, fix the connection config or pin "
                f"backend_config.write_rung='native_stream' on the feed "
                f"while you do.") from exc
        table_fqn = unload["table_fqn"]
        rows_reported = int(unload["rows_reported"])

        objs = [o for o in _list_all_objects(s3_client, bucket, prefix)
                if not o["Key"].rsplit("/", 1)[-1].startswith((".", "_"))]

        # ── The completeness gate ────────────────────────────────────
        parts: List[PartInfo] = []
        schema = None
        footer_rows_total = 0
        for i, o in enumerate(sorted(objs, key=lambda x: x["Key"])):
            key, osize = o["Key"], int(o["Size"])
            n_rows, part_schema = _read_parquet_footer(s3_client, bucket,
                                                       key, osize)
            if schema is None:
                schema = part_schema
            elif not schema.equals(part_schema):
                raise EngineUnloadError(
                    "verify",
                    f"part {key} carries a different schema than its "
                    f"siblings — refusing to build a manifest over "
                    f"inconsistent parts")
            footer_rows_total += n_rows
            parts.append(PartInfo(
                index=i, name=key.rsplit("/", 1)[-1],
                rows=n_rows, bytes=osize, location="s3",
                uri=f"s3://{bucket}/{key}",
                checksum=(f"etag:{o['ETag'].strip(chr(34))}"
                          if o.get("ETag") else None),
            ))

        if footer_rows_total != rows_reported:
            raise EngineUnloadError(
                "verify",
                f"engine reported {rows_reported} rows written but the "
                f"parquet footers under s3://{bucket}/{prefix}/ sum to "
                f"{footer_rows_total} across {len(parts)} part(s).  "
                f"Refusing to certify — a count that does not reconcile "
                f"is not a count.")

        empty_columns: List[str] = []
        empty_column_types: List[Dict[str, Any]] = []
        if rows_reported == 0 and not parts:
            # A 0-row CTAS may legitimately write no files at all.  The
            # caller still needs the COLUMNS -- names AND the engine's
            # types -- to emit the typed-empty output every downstream
            # reader expects, so probe them the cheap way (LIMIT 0 never
            # touches data pages).
            try:
                probe = connector.execute_query(
                    f"SELECT * FROM (\n{sql}\n) qs_unload_probe LIMIT 0")
                empty_column_types = [
                    {"name": c.get("name", ""), "type": c.get("type")}
                    for c in (probe.get("columns") or []) if isinstance(c, dict)]
                empty_columns = [c["name"] for c in empty_column_types]
            except Exception as _p_exc:
                raise EngineUnloadError(
                    "verify",
                    f"CTAS wrote 0 rows and the LIMIT-0 column probe "
                    f"failed ({_p_exc}) — cannot produce a typed-empty "
                    f"output without the column names") from _p_exc

        import base64 as _b64
        manifest = PartsManifest(
            parts=parts,
            schema_b64=("" if schema is None else
                        _b64.b64encode(schema.serialize().to_pybytes())
                        .decode("ascii")),
            total_rows=footer_rows_total,
            total_bytes=sum(p.bytes for p in parts),
            status="complete",
            sql_sha256=sql_sha256(sql),
            build_id=f"unload:{exec_id or table_name}",
            source={
                "rung": "engine_write",
                "connector_type": type(connector).__name__,
                "ctas_query_id": unload.get("query_id") or "",
                "table_fqn": table_fqn,
                "external_location": unload.get("external_location") or "",
                "rows_reported": rows_reported,
                "verification": "footer_recount==engine_count",
            },
        )
        manifest.completed_at = manifest.created_at
        logger.info(
            "[engine-unload] VERIFIED feed=%s rows=%d parts=%d bytes=%d "
            "query_id=%s location=s3://%s/%s/",
            feed_config.get("id"), footer_rows_total, len(parts),
            manifest.total_bytes, unload.get("query_id") or "?",
            bucket, prefix,
        )
        return UnloadResult(
            manifest=manifest,
            rows_reported=rows_reported,
            query_id=str(unload.get("query_id") or ""),
            table_fqn=table_fqn,
            external_location=str(unload.get("external_location") or ""),
            ctas_sql=str(unload.get("ctas_sql") or ""),
            s3_bucket=bucket,
            s3_prefix=prefix,
            verified=True,
            empty_columns=empty_columns,
            empty_column_types=empty_column_types,
        )
    except BaseException:
        # ANY failure or cancel after the CTAS may have left data behind.
        if unload is not None:
            _delete_prefix(s3_client, bucket, prefix)
        raise
    finally:
        # The scratch TABLE is dropped no matter what.  For an external
        # table the data survives the drop — on success that is the
        # manifest's contents; on failure the except arm above already
        # deleted them.
        _fqn = table_fqn or (
            f"\"{scratch_catalog}\".\"{scratch_schema}\".\"{table_name}\"")
        try:
            connector.drop_scratch_table(_fqn)
        except Exception as drop_exc:
            logger.error(
                "[engine-unload] could not drop scratch table %s — drop it "
                "manually (garbage in the customer catalog): %s",
                _fqn, drop_exc,
            )


def materialize_parts_locally(
    result_manifest: PartsManifest,
    s3_client,
    parts_dir: str | Path,
    *,
    cancel_event=None,
    on_part=None,
) -> PartsManifest:
    """Download s3-resident parts as BYTES into ``parts_dir`` and return
    a local manifest.  Rows are never decoded here — this is a byte copy
    at network speed, not the per-row Python loop rung 1 exists to kill.
    Sizes are verified against the manifest after each download."""
    parts_dir = Path(parts_dir)
    parts_dir.mkdir(parents=True, exist_ok=True)
    local_parts: List[PartInfo] = []
    for p in result_manifest.parts:
        if cancel_event is not None and cancel_event.is_set():
            raise InterruptedError("part download cancelled")
        if p.location != "s3" or not p.uri:
            raise EngineUnloadError(
                "download", f"part {p.name} is not s3-resident")
        bucket, key = parse_s3_uri(p.uri)
        local_name = f"part-{p.index:05d}.parquet"
        target = parts_dir / local_name
        s3_client.download_file(bucket, key, str(target))
        got = target.stat().st_size
        if got != p.bytes:
            raise EngineUnloadError(
                "download",
                f"part {p.name}: downloaded {got} bytes, manifest says "
                f"{p.bytes} — refusing a torn copy")
        lp = PartInfo(index=p.index, name=local_name, rows=p.rows,
                      bytes=p.bytes, location="local", uri=None,
                      columns=p.columns, checksum=p.checksum,
                      renames=p.renames)
        local_parts.append(lp)
        if on_part is not None:
            try:
                on_part(lp)
            except Exception as _cb_exc:
                logger.warning("[engine-unload] on_part callback failed: %s",
                               _cb_exc)
    local = PartsManifest(
        parts=local_parts,
        schema_b64=result_manifest.schema_b64,
        total_rows=result_manifest.total_rows,
        total_bytes=result_manifest.total_bytes,
        status="complete",
        sql_sha256=result_manifest.sql_sha256,
        build_id=result_manifest.build_id,
        source=dict(result_manifest.source),
    )
    local.completed_at = local.created_at
    local.write(parts_dir, partial=False)
    return local


__all__ = [
    "EngineUnloadError", "UnloadResult", "run_engine_unload",
    "materialize_parts_locally", "build_unload_s3_client", "parse_s3_uri",
]
