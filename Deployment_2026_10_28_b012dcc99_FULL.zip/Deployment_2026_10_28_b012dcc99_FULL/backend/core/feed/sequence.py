"""Gapless per-feed file sequence numbers — FR-ART-07 (BRD §10.3).

Counterparties that demand ``FLX_TRADES_000123.csv`` are demanding
STATE, not formatting: the number must increase across runs, survive
restarts, and never repeat.  Three rules fall out of what "gapless"
means to the party CHECKING it, and each is enforced here:

* **A number, once taken, is never reused by a different run.**  A run
  that took 000124 and died did consume 000124.  Reusing it for the
  next business date would make two different files claim one identity;
  skipping silently would present the counterparty with an unexplained
  hole.  So a taken-but-never-committed allocation stays in the ledger
  as a VISIBLE gap (:meth:`SequenceAllocator.gaps`) — the operator can
  answer "why did 000124 never arrive?" from the record instead of a
  grep.
* **A re-run does not consume a new number unless the counterparty
  expects one** (FR-ART-07's own sentence).  Re-running the same
  ``(feed, scope, business_date)`` under ``redelivery="reuse"`` returns
  the ORIGINAL allocation — same number, same filename, the reuse
  convention.  ``redelivery="revision"`` mints a fresh number — the
  revision convention.  Which one is right is a contract term
  (``redelivery_naming``), never a guess.
* **Allocation is atomic under concurrency.**  The store must enforce
  ``UNIQUE (feed_config_id, scope_key, seq_value)``; two racing runs
  both computing MAX+1 collide on the insert and the loser retries with
  the next value.  No read-modify-write window.

The durable half is a STORE SEAM — this module owns the policy, the
schema owner adds the table (``feed_sequence_allocations``, see the
class docstring) and the db-mixin methods.  :class:`InMemorySequenceStore`
implements the same contract for tests and for the interim period; it
is process-local and says so, loudly, in its docstring — it must never
be wired as the production store.
"""
from __future__ import annotations

import threading
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

STATUS_TAKEN = "taken"          # a run holds this number right now
STATUS_COMMITTED = "committed"  # the file carrying it was delivered
STATUS_ABANDONED = "abandoned"  # a human recorded WHY it never shipped

_STATUSES = (STATUS_TAKEN, STATUS_COMMITTED, STATUS_ABANDONED)


class SequenceError(RuntimeError):
    """A sequence operation refused — the message says why."""


class SequenceConflict(SequenceError):
    """The store refused an insert on the UNIQUE(feed, scope, value)
    constraint — another run took the value first.  Stores MUST raise
    this (or an ``IntegrityError`` they translate to it) so the
    allocator can retry with the next value."""


@dataclass(frozen=True)
class Allocation:
    """One row of the ledger."""

    id: Any
    feed_config_id: int
    scope_key: str
    seq_value: int
    status: str
    business_date: str
    run_id: str
    taken_at: datetime
    committed_at: Optional[datetime] = None
    note: str = ""

    def formatted(self, width: int = 6) -> str:
        return format_sequence(self.seq_value, width)


def format_sequence(value: int, width: int = 6) -> str:
    """Zero-padded, and REFUSES a value that no longer fits the width —
    a counterparty parsing fixed positions reads a 7-digit number in a
    6-digit field as garbage, silently."""
    v = int(value)
    if v < 0:
        raise SequenceError(f"sequence value cannot be negative: {v}")
    out = f"{v:0{int(width)}d}"
    if len(out) > int(width):
        raise SequenceError(
            f"sequence value {v} does not fit width {width} — widen the "
            f"filename template's field before this run, not after the "
            f"counterparty's parser chokes")
    return out


class SequenceAllocator:
    """Policy over any store implementing the seam.

    Store contract (three methods; the SQL twin lives on the db mixin
    once the ``feed_sequence_allocations`` table lands)::

        list_feed_sequence_allocations(feed_config_id, scope_key)
            -> list[dict]      # every row for the (feed, scope) stream
        insert_feed_sequence_allocation(data: dict) -> dict
            # MUST enforce UNIQUE (feed_config_id, scope_key, seq_value)
            # and raise SequenceConflict when it fires
        update_feed_sequence_allocation(alloc_id, updates: dict) -> dict
    """

    def __init__(self, store, *, clock=None):
        self._store = store
        self._now = clock or (lambda: datetime.now(timezone.utc))

    # ── read ─────────────────────────────────────────────────────────

    def _rows(self, feed_config_id: int, scope_key: str) -> List[dict]:
        rows = self._store.list_feed_sequence_allocations(
            int(feed_config_id), str(scope_key))
        return sorted(rows or [], key=lambda r: int(r["seq_value"]))

    # ── allocate ─────────────────────────────────────────────────────

    def allocate(self, feed_config_id: int, *, business_date,
                 run_id, scope_key: str = "",
                 redelivery: str = "reuse",
                 _max_races: int = 5) -> Allocation:
        """Take the next number for this (feed, scope) stream.

        ``redelivery="reuse"``: a prior allocation for the SAME
        business date is returned as-is (original number — FR-ART-07's
        "a re-run must not consume a new sequence number").
        ``redelivery="revision"``: always a fresh number.
        """
        if redelivery not in ("reuse", "revision"):
            raise SequenceError(
                f"unknown redelivery convention {redelivery!r} — "
                f"'reuse' or 'revision' (FR-ART-09)")
        biz = str(business_date)
        if redelivery == "reuse":
            for r in self._rows(feed_config_id, scope_key):
                if str(r.get("business_date")) == biz \
                        and r.get("status") != STATUS_ABANDONED:
                    return self._to_alloc(r)
        last_conflict: Exception | None = None
        for _ in range(max(1, _max_races)):
            rows = self._rows(feed_config_id, scope_key)
            next_val = (int(rows[-1]["seq_value"]) + 1) if rows else 1
            data = {
                "feed_config_id": int(feed_config_id),
                "scope_key": str(scope_key),
                "seq_value": next_val,
                "status": STATUS_TAKEN,
                "business_date": biz,
                "run_id": str(run_id),
                "taken_at": self._now(),
            }
            try:
                return self._to_alloc(
                    self._store.insert_feed_sequence_allocation(data))
            except SequenceConflict as exc:
                last_conflict = exc  # another run won this value — next
        raise SequenceError(
            f"could not allocate a sequence value for feed "
            f"{feed_config_id} scope {scope_key!r} after {_max_races} "
            f"races ({last_conflict}) — something is allocating in a "
            f"tight loop; investigate before retrying")

    # ── lifecycle ────────────────────────────────────────────────────

    def commit(self, allocation_id) -> Allocation:
        """taken -> committed, when the file carrying the number was
        DELIVERED.  Committing twice is idempotent; committing an
        abandoned number is refused — its gap was already explained."""
        row = self._get(allocation_id)
        if row["status"] == STATUS_COMMITTED:
            return self._to_alloc(row)
        if row["status"] != STATUS_TAKEN:
            raise SequenceError(
                f"allocation {allocation_id} is {row['status']!r} — only "
                f"a 'taken' number can be committed")
        return self._to_alloc(self._store.update_feed_sequence_allocation(
            allocation_id,
            {"status": STATUS_COMMITTED, "committed_at": self._now()}))

    def abandon(self, allocation_id, *, reason: str) -> Allocation:
        """Record WHY a taken number will never ship.  The number stays
        consumed — the gap becomes explained, not erased."""
        if not (reason or "").strip():
            raise SequenceError(
                "a reason is required — an unexplained abandonment is "
                "just a gap with extra steps")
        row = self._get(allocation_id)
        if row["status"] == STATUS_COMMITTED:
            raise SequenceError(
                f"allocation {allocation_id} was COMMITTED — a delivered "
                f"number cannot be abandoned; a correction is a "
                f"redelivery, not a rewrite of the ledger")
        return self._to_alloc(self._store.update_feed_sequence_allocation(
            allocation_id, {"status": STATUS_ABANDONED, "note": reason}))

    # ── visibility (the whole point) ─────────────────────────────────

    def gaps(self, feed_config_id: int, scope_key: str = "") -> List[dict]:
        """Every number the counterparty will NOT receive, with its
        story: taken-but-never-committed rows (a run died holding the
        number), abandoned rows (explained), and any numeric hole with
        no ledger row at all (``missing`` — should be impossible while
        allocation goes through this class; its presence means someone
        wrote the store directly)."""
        rows = self._rows(feed_config_id, scope_key)
        out: List[dict] = []
        seen = set()
        for r in rows:
            seen.add(int(r["seq_value"]))
            if r.get("status") != STATUS_COMMITTED:
                out.append({"seq_value": int(r["seq_value"]),
                            "kind": r.get("status"),
                            "business_date": r.get("business_date"),
                            "run_id": r.get("run_id"),
                            "note": r.get("note") or ""})
        if rows:
            for v in range(1, int(rows[-1]["seq_value"])):
                if v not in seen:
                    out.append({"seq_value": v, "kind": "missing",
                                "business_date": None, "run_id": None,
                                "note": "no ledger row — store was "
                                        "written outside the allocator"})
        return sorted(out, key=lambda g: g["seq_value"])

    # ── internals ────────────────────────────────────────────────────

    def _get(self, allocation_id) -> dict:
        row = None
        getter = getattr(self._store, "get_feed_sequence_allocation", None)
        if getter is not None:
            row = getter(allocation_id)
        if row is None:
            raise SequenceError(f"no sequence allocation {allocation_id}")
        return dict(row)

    @staticmethod
    def _to_alloc(row: dict) -> Allocation:
        return Allocation(
            id=row.get("id"),
            feed_config_id=int(row["feed_config_id"]),
            scope_key=str(row.get("scope_key") or ""),
            seq_value=int(row["seq_value"]),
            status=str(row["status"]),
            business_date=str(row.get("business_date") or ""),
            run_id=str(row.get("run_id") or ""),
            taken_at=row.get("taken_at"),
            committed_at=row.get("committed_at"),
            note=str(row.get("note") or ""),
        )


class InMemorySequenceStore:
    """TEST SEAM (declared 2026-09-03) -- production must NOT call this.
    The seam's reference implementation — tests and NOTHING ELSE.

    Process-local: numbers here do not survive a restart, which is the
    exact property FR-ART-07 forbids.  The contract validator therefore
    still marks ``sequencing=gapless`` unsupported until the
    ``feed_sequence_allocations`` table exists and the db mixin carries
    the three methods.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._rows: List[Dict[str, Any]] = []
        self._next_id = 1

    def list_feed_sequence_allocations(self, feed_config_id, scope_key):
        with self._lock:
            return [dict(r) for r in self._rows
                    if r["feed_config_id"] == int(feed_config_id)
                    and r["scope_key"] == str(scope_key)]

    def insert_feed_sequence_allocation(self, data):
        with self._lock:
            for r in self._rows:
                if (r["feed_config_id"] == int(data["feed_config_id"])
                        and r["scope_key"] == str(data["scope_key"])
                        and int(r["seq_value"]) == int(data["seq_value"])):
                    raise SequenceConflict(
                        f"UNIQUE(feed, scope, seq) violated for "
                        f"{data['seq_value']}")
            row = dict(data)
            row["id"] = self._next_id
            self._next_id += 1
            row.setdefault("note", "")
            row.setdefault("committed_at", None)
            self._rows.append(row)
            return dict(row)

    def update_feed_sequence_allocation(self, alloc_id, updates):
        with self._lock:
            for r in self._rows:
                if r["id"] == alloc_id:
                    r.update(updates)
                    return dict(r)
        raise SequenceError(f"no sequence allocation {alloc_id}")

    def get_feed_sequence_allocation(self, alloc_id):
        with self._lock:
            for r in self._rows:
                if r["id"] == alloc_id:
                    return dict(r)
        return None
