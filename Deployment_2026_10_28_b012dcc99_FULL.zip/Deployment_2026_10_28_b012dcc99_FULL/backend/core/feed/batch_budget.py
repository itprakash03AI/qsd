"""How many ROWS a feed holds as Python objects at once -- decided in CELLS.

2026-10-11.  Found live with the owner's 75-column fact_tetb_ext query on the
Docker rig: the native lane's two row-holding stages sized their batches in
ROWS, so their memory grew with the feed's WIDTH.

* the stream (rung 3, ``core.connector_to_parquet``) fetched
  ``query_engine.chunk_size`` = 100,000 rows per ``fetchmany`` and queued up
  to ``queue_maxsize`` (4) of them -- three concurrent 1M-row runs took the
  scheduler from 945 to 2,031 MiB in 25 s and the kernel OOM-killed it;
* the renderers (``core.feed.renderers``) turned 100,000-row batches into
  pandas frames of Python objects -- one 75-column render peaked at 1,436
  MiB (13,333 rows: 647 MiB, same 25 s).

A 460-column feed would need several GB per run on either stage.  The ONE
rule: a stage of one run holds at most ``feed_generation.max_cells_in_memory``
cells (rows x columns) across every batch it can have in flight.  A
throttle, never a gate -- it changes how rows are batched, never which rows
are written.
"""
from __future__ import annotations

from typing import Optional

#: When the width cannot be known before the rows arrive (``SELECT *``, an
#: unparseable statement), assume a WIDE feed.  Unknown is not narrow: a
#: guess that is too small costs a little throughput, one that is too large
#: costs the pod.
ASSUMED_COLUMNS_WHEN_UNKNOWN = 100

DEFAULT_MAX_CELLS_IN_MEMORY = 1_000_000


def max_cells_in_memory() -> int:
    """``feed_generation.max_cells_in_memory`` (0 or less = no cap)."""
    try:
        from core.config import feed_generation as _fg
        return int(getattr(_fg, "max_cells_in_memory", DEFAULT_MAX_CELLS_IN_MEMORY))
    except Exception:
        return DEFAULT_MAX_CELLS_IN_MEMORY


def rows_within_budget(chunk_size: int, ncols: Optional[int], *,
                       batches_in_flight: int = 1,
                       budget: Optional[int] = None) -> int:
    """Rows per batch: ``chunk_size``, capped so ``batches_in_flight``
    batches of ``ncols`` columns hold at most the cell budget.

    ``ncols`` None / 0 = unknown -> :data:`ASSUMED_COLUMNS_WHEN_UNKNOWN`.
    Never below 1 row; a non-positive budget means no cap."""
    rows = max(1, int(chunk_size or 1))
    cap = max_cells_in_memory() if budget is None else int(budget)
    if cap <= 0:
        return rows
    width = int(ncols) if ncols and int(ncols) > 0 else ASSUMED_COLUMNS_WHEN_UNKNOWN
    per_batch = cap // (width * max(1, int(batches_in_flight)))
    return max(1, min(rows, per_batch))


def sql_width(sql: str) -> Optional[int]:
    """The statement's output column count from its text, or None when only
    the source knows (``SELECT *``) -- never 0 for "unknown"."""
    try:
        from core.sql_output_columns import derive_columns_from_sql_text
        cols = derive_columns_from_sql_text(sql)
    except Exception:
        return None
    return len(cols) or None
