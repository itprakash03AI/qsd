"""Completeness spine — BRD 2026-09-02 §9 (FR-CMP-01..09).

The failure mode this module is designed against: **a truncation that
was computed, then discarded**.  A file cap applied and the flag naming
it had no consumer; a row cap that folded 0 into "unlimited" and shipped
1M of 70M rows with status SUCCESS; a partition predicate lost so the
answer was a subset.  None of them failed — they all succeeded, smaller.

Hence FR-CMP-01, enforced here rather than hoped for: *a count that is
measured must be COMPARED, and a comparison that fails must CHANGE THE
RUN'S STATUS*.  Anything else is telemetry, not a control.

Design rules:

1.  **Three states, never two** (FR-CMP-07).  A completeness claim is
    ``verified`` (measured and compared), ``asserted`` (a human, a skip
    or a force-complete said so — recorded and visible downstream), or
    ``unverifiable`` (the evidence was unavailable).  "Unverifiable" is
    ITS OWN STATE and never folds into success — the whole defect class
    above comes from treating "could not tell" as "fine".  A claim whose
    comparison was made and DISAGREED is ``failed`` — and a failed claim
    makes the run INCOMPLETE, which is a run-status change, not a log
    line.

2.  **A verdict names its evidence.**  A bare boolean is the defect,
    not the feature: every :class:`Claim` carries a non-empty evidence
    mapping and refuses construction without one.

3.  **The declared partition list is DATA, not a loop bound**
    (FR-CMP-02).  The dangerous case is not a failed child — a failure
    is loud.  It is a child that NEVER EXISTED: the partition query
    returned 1,180 entities instead of 1,240 because a reference table
    was mid-load; every child succeeds, every part certifies, the feed
    is 60 entities short and every signal is green.  So the feed-level
    claim is a SET comparison of identities (FR-CMP-05), never a counter
    reaching a total, and the declared list is compared against the
    previous business date (FR-CMP-03) — the single highest-value
    completeness alarm available.

4.  **Pure functions, injected seams.**  No network, no live DB, no
    filesystem.  The two persistence helpers take a ``db`` object
    exposing two documented methods and PROPAGATE its errors — a
    declaration that cannot be recorded is not evidence, and swallowing
    the failure here would convert "could not record" into "recorded".
"""
from __future__ import annotations

import logging
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from typing import Any, Optional

logger = logging.getLogger(__name__)

# ── Claim levels (§9.1 — four independent claims) ──────────────────────────
LEVEL_SOURCE = "source"      # the source held N rows and the read was not truncated
LEVEL_PART = "part"          # this part holds exactly the rows it says
LEVEL_FEED = "feed"          # every declared partition produced a part
LEVEL_BUSINESS = "business"  # the number is plausible for this business date

CLAIM_LEVELS = (LEVEL_SOURCE, LEVEL_PART, LEVEL_FEED, LEVEL_BUSINESS)

# ── Claim / verdict states ─────────────────────────────────────────────────
# FR-CMP-07 — three outcomes for HOW completeness was established:
VERIFIED = "verified"          # measured and compared, and the comparison agreed
ASSERTED = "asserted"          # a human, a skip or a force-complete said so
UNVERIFIABLE = "unverifiable"  # the evidence was unavailable — NEVER success
# ...and the fourth outcome, which is not a way of being complete at all:
FAILED = "failed"              # measured, compared, and the comparison DISAGREED
INCOMPLETE = "incomplete"      # verdict state when any claim failed (FR-CMP-01)

CLAIM_STATES = (VERIFIED, ASSERTED, UNVERIFIABLE, FAILED)
VERDICT_STATES = (VERIFIED, ASSERTED, UNVERIFIABLE, INCOMPLETE)

# FR-CMP-03 — "a 5% drop in partition count is the single highest-value
# completeness alarm available".
DEFAULT_DROP_ALARM_PCT = 5.0

ON_EMPTY_FAIL = "fail"
ON_EMPTY_SKIP = "skip"
_ON_EMPTY_VALUES = (ON_EMPTY_FAIL, ON_EMPTY_SKIP)


class CompletenessError(ValueError):
    """Base for loud completeness refusals."""


class EmptyPartitionListError(CompletenessError):
    """FR-CMP-04 — zero partitions must never silently mean "nothing to
    do".  Raised unless the feed explicitly declares ``on_empty=skip``."""


class PartitionExplosionError(CompletenessError):
    """§9.3 — ``max_parts`` turns a partition explosion into a loud
    refusal instead of 40,000 child rows at 2am."""


# ── Claim — one level, one status, named evidence ──────────────────────────


@dataclass(frozen=True)
class Claim:
    """One completeness claim at one level, with the evidence that backs it.

    ``evidence`` is REQUIRED non-empty: a verdict must name its
    evidence, and a claim with nothing behind it is exactly the bare
    boolean this module exists to kill.
    """

    level: str
    status: str
    reason: str
    evidence: Mapping[str, Any]

    def __post_init__(self) -> None:
        if self.level not in CLAIM_LEVELS:
            raise CompletenessError(
                f"unknown claim level {self.level!r} — levels: {CLAIM_LEVELS}")
        if self.status not in CLAIM_STATES:
            raise CompletenessError(
                f"unknown claim status {self.status!r} — states: {CLAIM_STATES}")
        if not self.evidence:
            raise CompletenessError(
                f"a {self.level} claim must name its evidence — an empty "
                f"evidence mapping is a bare boolean, which is the defect, "
                f"not the feature")
        if not self.reason:
            raise CompletenessError(
                f"a {self.level} claim must state its reason")

    def to_dict(self) -> dict[str, Any]:
        return {
            "level": self.level,
            "status": self.status,
            "reason": self.reason,
            "evidence": dict(self.evidence),
        }


# ── Source claim (§9.1 row 1) ──────────────────────────────────────────────


def source_claim(*, engine_reported_rows: int | None,
                 rows_read: int | None,
                 cap_applied: bool | None,
                 cap_name: str | None = None) -> Claim:
    """The source held N rows for this partition and the read was not
    truncated.

    ``cap_applied`` is the EXPLICIT "no cap was applied" assertion — the
    half that was historically missing.  ``None`` means nobody asserted
    either way, and that is UNVERIFIABLE, never verified: a cap that was
    applied and not reported looks exactly like this.
    """
    ev: dict[str, Any] = {
        "engine_reported_rows": engine_reported_rows,
        "rows_read": rows_read,
        "cap_applied": cap_applied,
    }
    if cap_name is not None:
        ev["cap_name"] = cap_name
    if cap_applied is True:
        return Claim(LEVEL_SOURCE, FAILED,
                     f"a cap was applied to the read"
                     f"{f' ({cap_name})' if cap_name else ''} — the rows "
                     f"read are a subset of the source", ev)
    if engine_reported_rows is None:
        return Claim(LEVEL_SOURCE, UNVERIFIABLE,
                     "the source reports no row count — the read cannot be "
                     "compared against anything", ev)
    if rows_read is None:
        return Claim(LEVEL_SOURCE, UNVERIFIABLE,
                     "rows_read was not measured — the engine count has "
                     "nothing to be compared against", ev)
    if cap_applied is None:
        return Claim(LEVEL_SOURCE, UNVERIFIABLE,
                     "no assertion that no cap was applied — the missing "
                     "half of the source claim; an unreported cap looks "
                     "exactly like this", ev)
    if int(engine_reported_rows) != int(rows_read):
        return Claim(LEVEL_SOURCE, FAILED,
                     f"engine reported {engine_reported_rows} rows but "
                     f"{rows_read} were read — the read was truncated or "
                     f"the source moved", ev)
    return Claim(LEVEL_SOURCE, VERIFIED,
                 f"engine count and rows read agree at {rows_read} and no "
                 f"cap was applied", ev)


# ── Part claim (§9.1 row 2) ────────────────────────────────────────────────


def propose_partition_drift(declared, discovered) -> Optional[dict]:
    """FR-CMP-06 — PROPOSE the drift; never decide on it.

    "The pruning subsystem can already discover partitions.  Under a
    declared rule it must not decide -- but it may propose: surface 'the
    source has 1,240 partitions for D; your config declares 1,180' as a
    pre-flight warning at authoring time.  Declared stays authoritative;
    drift becomes visible instead of silent."

    The asymmetry is the whole requirement, and it cuts both ways:

    * a partition the SOURCE has and the declaration does not is data
      the counterparty will not receive, and the run will still certify
      COMPLETE, because completeness is measured against the DECLARED
      set.  That is correct -- a declaration is a promise, not a
      discovery -- and it is exactly why the gap has to be visible
      somewhere;
    * a partition DECLARED and absent from the source is the louder
      one at run time (the §9.2 feed claim FAILS on it), so here it is
      only advisory.

    Returns None when there is nothing to say, so a caller can attach
    the result unconditionally.  Never raises: an advisory that can take
    down a save is worse than no advisory.
    """
    try:
        dset = {str(v) for v in (declared or [])}
        sset = {str(v) for v in (discovered or [])}
    except TypeError:
        return None
    if not dset and not sset:
        return None
    missing_from_declaration = sorted(sset - dset)
    missing_from_source = sorted(dset - sset)
    if not missing_from_declaration and not missing_from_source:
        return None
    parts = [f"the source has {len(sset)} partitions; "
             f"this feed declares {len(dset)}"]
    if missing_from_declaration:
        parts.append(
            f"{len(missing_from_declaration)} present at the source and NOT "
            f"declared (they will not be produced, and the run will still "
            f"certify complete): "
            f"{', '.join(missing_from_declaration[:8])}"
            + (" ..." if len(missing_from_declaration) > 8 else ""))
    if missing_from_source:
        parts.append(
            f"{len(missing_from_source)} declared and NOT present at the "
            f"source (each will fail the §9.2 set claim at run time): "
            f"{', '.join(missing_from_source[:8])}"
            + (" ..." if len(missing_from_source) > 8 else ""))
    return {
        "declared_count": len(dset),
        "source_count": len(sset),
        "missing_from_declaration": missing_from_declaration,
        "missing_from_source": missing_from_source,
        # Stated in the payload, not just in prose: a consumer of this
        # dict must not be able to read it as a verdict.
        "authoritative": "declared",
        "message": " — ".join(parts),
    }


def part_claim(partition_key: str, *, footer_rows: int | None,
               manifest_rows: int | None) -> Claim:
    """This part holds exactly the rows its manifest entry says."""
    ev: dict[str, Any] = {
        "partition_key": partition_key,
        "footer_rows": footer_rows,
        "manifest_rows": manifest_rows,
    }
    if footer_rows is None or manifest_rows is None:
        missing = "footer" if footer_rows is None else "manifest"
        return Claim(LEVEL_PART, UNVERIFIABLE,
                     f"part {partition_key}: the {missing} row count was "
                     f"unavailable — one count written twice proves "
                     f"nothing, and no count at all proves less", ev)
    if int(footer_rows) != int(manifest_rows):
        return Claim(LEVEL_PART, FAILED,
                     f"part {partition_key}: parquet footer holds "
                     f"{footer_rows} rows but the manifest entry says "
                     f"{manifest_rows}", ev)
    return Claim(LEVEL_PART, VERIFIED,
                 f"part {partition_key}: footer and manifest agree at "
                 f"{footer_rows} rows", ev)


# ── Partition declaration (FR-CMP-02/04, §9.3) ─────────────────────────────


@dataclass(frozen=True)
class PartitionDeclaration:
    """The declared partition list, recorded as DATA — identities, not
    just a count (FR-CMP-02).  Auditable, overridable per run, bounded."""

    identities: tuple[str, ...]
    on_empty: str = ON_EMPTY_FAIL
    source: str | None = None            # e.g. partition.values.sql text
    declared_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc))

    @property
    def skipped(self) -> bool:
        """True only for the explicitly-declared empty case: zero
        partitions under ``on_empty=skip`` is a DECISION, not a no-op."""
        return not self.identities and self.on_empty == ON_EMPTY_SKIP

    @property
    def count(self) -> int:
        return len(self.identities)

    def to_dict(self) -> dict[str, Any]:
        return {
            "identities": list(self.identities),
            "identity_count": self.count,
            "on_empty": self.on_empty,
            "source": self.source,
            "declared_at": self.declared_at.isoformat(),
            "skipped": self.skipped,
        }


def _normalise_identities(identities: Any, *, what: str) -> tuple[str, ...]:
    """Identities, not a count, and not a string that iterates as chars."""
    if isinstance(identities, (str, bytes)):
        raise CompletenessError(
            f"{what} must be an iterable of partition identities, not a "
            f"single string — a string iterates as characters, which is a "
            f"silent bug, not a list")
    if isinstance(identities, (int, float, bool)):
        raise CompletenessError(
            f"{what} must be the partition IDENTITIES, not a count "
            f"({identities!r}) — certify the set, not a counter "
            f"(FR-CMP-05)")
    if not isinstance(identities, Iterable):
        raise CompletenessError(
            f"{what} must be an iterable of partition identities, got "
            f"{type(identities).__name__}")
    out: list[str] = []
    for ident in identities:
        if ident is None:
            raise CompletenessError(f"{what} contains None — an identity "
                                    f"that names nothing names nothing")
        s = str(ident)
        if not s:
            raise CompletenessError(f"{what} contains an empty identity")
        out.append(s)
    return tuple(out)


def declare_partitions(identities: Iterable[Any], *,
                       on_empty: str = ON_EMPTY_FAIL,
                       max_parts: int | None = None,
                       source: str | None = None) -> PartitionDeclaration:
    """Build the declared partition list for a run — the loop bound AND
    the completeness evidence, recorded before any child exists.

    Refusals, all loud:
      * empty list unless ``on_empty="skip"`` was explicitly declared
        (FR-CMP-04);
      * more than ``max_parts`` identities (§9.3 — a partition explosion
        is a refusal, not 40,000 child rows at 2am);
      * ``max_parts=0`` — zero does NOT mean unlimited here; omit
        ``max_parts`` (None) to leave the list unbounded.  This codebase
        has shipped ``a or b`` folding 0 into a cap before;
      * duplicate identities — ``(feed_run_id, partition_key)`` is
        unique in the DB, and a duplicate here means the declaration
        query is wrong.
    """
    if on_empty not in _ON_EMPTY_VALUES:
        raise CompletenessError(
            f"on_empty must be one of {_ON_EMPTY_VALUES}, got {on_empty!r} "
            f"— a typo must not become a new state")
    idents = _normalise_identities(identities, what="declared partition list")
    if not idents and on_empty != ON_EMPTY_SKIP:
        raise EmptyPartitionListError(
            "the declared partition list is EMPTY and the feed does not "
            "declare on_empty=skip — zero partitions must never silently "
            "mean 'nothing to do' (FR-CMP-04); an empty list is a "
            "DECISION, not a no-op")
    if max_parts is not None:
        if max_parts <= 0:
            raise CompletenessError(
                f"max_parts={max_parts} is refused: 0 (or negative) does "
                f"NOT mean unlimited — omit max_parts to leave the "
                f"declaration unbounded.  '0 means unlimited' has shipped "
                f"1M of 70M rows in this codebase before")
        if len(idents) > max_parts:
            raise PartitionExplosionError(
                f"declared partition list holds {len(idents)} identities, "
                f"above max_parts={max_parts} — refusing loudly instead "
                f"of fanning out (§9.3)")
    seen: set[str] = set()
    dupes: list[str] = []
    for ident in idents:
        if ident in seen:
            dupes.append(ident)
        seen.add(ident)
    if dupes:
        raise CompletenessError(
            f"declared partition list contains duplicate identities "
            f"{sorted(set(dupes))[:20]} — (feed_run_id, partition_key) is "
            f"unique; a duplicate means the declaration query is wrong")
    return PartitionDeclaration(identities=idents, on_empty=on_empty,
                                source=source)


# ── Previous-business-date comparison (FR-CMP-03) ──────────────────────────


@dataclass(frozen=True)
class PartitionComparison:
    """The declared list vs the previous business date's declared list.

    ``compared`` False means the previous declaration was unavailable
    (first run, or the record could not be read) — that is stated, not
    silently treated as agreement.  When ``alarm`` is True the
    comparison was made and FAILED, and per FR-CMP-01 that must change
    the run's status — :func:`combine_verdict` enforces it.
    """

    compared: bool
    previous_count: int | None
    declared_count: int
    drop_pct: float | None
    missing_identities: tuple[str, ...]  # in previous, absent now (when known)
    alarm: bool
    alarm_threshold_pct: float
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "compared": self.compared,
            "previous_count": self.previous_count,
            "declared_count": self.declared_count,
            "drop_pct": self.drop_pct,
            "missing_identities": list(self.missing_identities),
            "alarm": self.alarm,
            "alarm_threshold_pct": self.alarm_threshold_pct,
            "reason": self.reason,
        }


def _parse_previous(
        previous: PartitionDeclaration | Iterable[Any] | int,
) -> tuple[tuple[str, ...] | None, int]:
    """The previous declaration as (identities-or-None, count)."""
    if isinstance(previous, PartitionDeclaration):
        return previous.identities, previous.count
    if isinstance(previous, bool):
        raise CompletenessError("previous must be a declaration, identities "
                                "or a count — not a boolean")
    if isinstance(previous, int):
        if previous < 0:
            raise CompletenessError(
                f"previous count cannot be negative: {previous}")
        return None, previous
    idents = _normalise_identities(previous, what="previous partition list")
    return idents, len(idents)


def compare_to_previous(declaration: PartitionDeclaration,
                        previous: PartitionDeclaration | Iterable[Any] | int | None,
                        *,
                        drop_alarm_pct: float = DEFAULT_DROP_ALARM_PCT,
                        ) -> PartitionComparison:
    """FR-CMP-03 — compare the declared list against the previous
    business date.  Costs one query; catches the child that never
    existed.

    ``previous`` may be the previous :class:`PartitionDeclaration`, an
    iterable of its identities (preferred — missing identities get
    NAMED), a bare count (pct comparison only), or ``None`` when no
    previous declaration exists (stated in the result, never treated as
    agreement).
    """
    if drop_alarm_pct < 0:
        raise CompletenessError(
            f"drop_alarm_pct must be >= 0, got {drop_alarm_pct}")
    declared_count = declaration.count
    if previous is None:
        return PartitionComparison(
            compared=False, previous_count=None,
            declared_count=declared_count, drop_pct=None,
            missing_identities=(), alarm=False,
            alarm_threshold_pct=drop_alarm_pct,
            reason="no previous declaration available to compare against "
                   "— the comparison was NOT made (first run, or the "
                   "record was unreadable)")
    prev_idents, prev_count = _parse_previous(previous)
    missing: tuple[str, ...] = ()
    if prev_idents is not None:
        missing = tuple(sorted(set(prev_idents) - set(declaration.identities)))
    if prev_count == 0:
        drop_pct = 0.0 if declared_count >= 0 else None
        alarm = False
        reason = "previous declaration was empty — no drop is computable"
    else:
        drop_pct = round((prev_count - declared_count) * 100.0 / prev_count, 4)
        alarm = drop_pct > drop_alarm_pct
        if alarm:
            named = (f"; missing vs previous: {list(missing[:20])}"
                     if missing else "")
            reason = (f"declared partition count dropped {drop_pct}% vs the "
                      f"previous business date ({prev_count} -> "
                      f"{declared_count}), above the {drop_alarm_pct}% "
                      f"alarm threshold{named} — the highest-value "
                      f"completeness alarm there is (FR-CMP-03)")
        else:
            reason = (f"declared partition count within tolerance of the "
                      f"previous business date ({prev_count} -> "
                      f"{declared_count}, drop {drop_pct}% <= "
                      f"{drop_alarm_pct}%)")
    return PartitionComparison(
        compared=True, previous_count=prev_count,
        declared_count=declared_count, drop_pct=drop_pct,
        missing_identities=missing, alarm=alarm,
        alarm_threshold_pct=drop_alarm_pct, reason=reason)


# ── Feed claim (§9.2, FR-CMP-05 — certify the SET, not the parts) ─────────


def feed_claim(declaration: PartitionDeclaration,
               certified_partitions: Iterable[Any]) -> Claim:
    """Every declared partition produced a certified part — a SET
    comparison of identities, never a counter reaching a total.

    Two lists of the same LENGTH with different MEMBERS are the exact
    case a counter cannot see: partition 738 produced nothing while an
    undeclared 739 produced something, and the counts agree.
    """
    certified = _normalise_identities(
        certified_partitions, what="certified partition list")
    ev: dict[str, Any] = {
        "declared_count": declaration.count,
        "certified_count": len(certified),
        "declared_identities": list(declaration.identities),
        "certified_identities": list(certified),
        "on_empty": declaration.on_empty,
    }
    if declaration.skipped:
        if certified:
            ev["undeclared_certified"] = list(certified)
            return Claim(LEVEL_FEED, FAILED,
                         f"the declaration was an explicit empty skip, yet "
                         f"{len(certified)} parts were certified — parts "
                         f"exist that no declaration names", ev)
        return Claim(LEVEL_FEED, ASSERTED,
                     "zero partitions under an explicit on_empty=skip "
                     "declaration — complete by DECLARED skip, not by "
                     "measurement (visible downstream per FR-CMP-09)", ev)
    declared_set = set(declaration.identities)
    certified_set = set(certified)
    missing = tuple(sorted(declared_set - certified_set))
    undeclared = tuple(sorted(certified_set - declared_set))
    if missing or undeclared:
        ev["missing_partitions"] = list(missing)
        ev["undeclared_certified"] = list(undeclared)
        bits = []
        if missing:
            bits.append(f"{len(missing)} declared partition(s) have NO "
                        f"certified part: {list(missing[:20])}")
        if undeclared:
            bits.append(f"{len(undeclared)} certified part(s) that no "
                        f"declaration names: {list(undeclared[:20])} — the "
                        f"declared list was not the loop bound")
        return Claim(LEVEL_FEED, FAILED, "; ".join(bits), ev)
    return Claim(LEVEL_FEED, VERIFIED,
                 f"every one of the {declaration.count} declared "
                 f"partitions has a certified part — set comparison, "
                 f"identities matched exactly", ev)


# ── Business claim (§9.1 row 4, §7.7) ──────────────────────────────────────


def business_claim(*, row_count: int | None,
                   baseline_rows: float | None,
                   tolerance_pct: float) -> Claim:
    """The number is plausible for this business date.

    No baseline (a new feed) is UNVERIFIABLE — which is exactly when
    mistakes are most likely, so it must be stated, not skipped.
    """
    if tolerance_pct < 0:
        raise CompletenessError(
            f"tolerance_pct must be >= 0, got {tolerance_pct}")
    ev: dict[str, Any] = {
        "row_count": row_count,
        "baseline_rows": baseline_rows,
        "tolerance_pct": tolerance_pct,
    }
    if row_count is None:
        return Claim(LEVEL_BUSINESS, UNVERIFIABLE,
                     "no row count was measured — nothing to compare "
                     "against the baseline", ev)
    if baseline_rows is None:
        return Claim(LEVEL_BUSINESS, UNVERIFIABLE,
                     "no historical baseline exists (new feed, or too few "
                     "samples) — plausibility cannot be checked, which is "
                     "stated rather than treated as fine", ev)
    if baseline_rows == 0 and row_count != 0:
        # 2026-10-12 -- a change FROM ZERO is not a percentage: it was
        # recorded as ``float("inf")``, which no JSON column stores, and the
        # run's terminal write failed AFTER its file was delivered (found
        # live: a month end after an empty one).  Said in words, verdict kept.
        ev["deviation_pct"] = None
        ev["baseline_was_zero"] = True
        return Claim(LEVEL_BUSINESS, FAILED,
                     f"row count {row_count} against a baseline of 0 rows -- any "
                     f"rows after an empty baseline are beyond the {tolerance_pct}% "
                     f"tolerance; mechanically perfect and implausible is still wrong", ev)
    deviation = 0.0 if baseline_rows == 0 else abs(row_count - baseline_rows) * 100.0 / baseline_rows
    ev["deviation_pct"] = deviation
    if deviation > tolerance_pct:
        return Claim(LEVEL_BUSINESS, FAILED,
                     f"row count {row_count} deviates {deviation:.2f}% "
                     f"from the baseline {baseline_rows} — above the "
                     f"{tolerance_pct}% tolerance; mechanically perfect "
                     f"and implausible is still wrong", ev)
    return Claim(LEVEL_BUSINESS, VERIFIED,
                 f"row count {row_count} within {tolerance_pct}% of the "
                 f"baseline {baseline_rows} (deviation "
                 f"{deviation:.2f}%)", ev)


# ── Assertions (FR-CMP-09) ─────────────────────────────────────────────────

ASSERTION_KINDS = ("skip", "force_complete", "manual")


@dataclass(frozen=True)
class Assertion:
    """A human, a skip or a force-complete saying "complete" — recorded,
    and visible downstream.  A consumer reconciling a regulatory feed is
    entitled to know which kind of complete they received."""

    kind: str
    actor: str
    reason: str

    def __post_init__(self) -> None:
        if self.kind not in ASSERTION_KINDS:
            raise CompletenessError(
                f"unknown assertion kind {self.kind!r} — kinds: "
                f"{ASSERTION_KINDS}")
        if not self.actor or not self.reason:
            raise CompletenessError(
                "an assertion must record WHO asserted and WHY — an "
                "anonymous unexplained force-complete is not evidence")

    def to_dict(self) -> dict[str, Any]:
        return {"kind": self.kind, "actor": self.actor, "reason": self.reason}


@dataclass(frozen=True)
class UnattributableOverride:
    """A run WAS admitted past its dependency gate on an override, but the
    durable audit record cannot attribute it — the ledger row is
    unreadable, or it records no actor / no reason.

    Deliberately NOT an :class:`Assertion`:

    * honouring it would stamp ``asserted`` under an invented actor — the
      anonymous force-complete :class:`Assertion` itself refuses to exist;
    * dropping it would let the verdict come out ``verified`` — laundering
      an unattributed override into evidence (FR-CMP-09).

    So it rides as an UNVERIFIABLE source claim (:meth:`to_claim`): its
    own state, never success (FR-CMP-07).
    """

    detail: str

    def to_claim(self) -> Claim:
        return Claim(
            LEVEL_SOURCE, UNVERIFIABLE,
            f"this run was admitted on a dependency override that cannot "
            f"be attributed to an actor — refused as an assertion, and it "
            f"must not read as verified either: {self.detail}",
            {"gate_override": True, "detail": self.detail})


def assertion_from_skip_events(events: Iterable[Mapping[str, Any]],
                               ) -> Assertion | None:
    """FR-CMP-09 / FR-DEP-12 producer — build the run's skip
    :class:`Assertion` from the durable ``run_events`` ledger rows
    (``event_type='dependency_skipped'``, written by
    ``core.feed.dependency_skip.assert_skip`` BEFORE the tracking row
    that releases the gate).

    Actor and reason come from the audit rows — never invented here.

    * no skip rows → ``None`` (the verdict computes from evidence alone);
    * every row attributed → ONE ``kind="skip"`` assertion naming each
      skipped dependency, why, and by whom;
    * any row with NO recorded actor or NO recorded reason →
      :class:`CompletenessError` — an anonymous or unexplained override
      is REFUSED, never defaulted.  The caller surfaces the refusal as
      :class:`UnattributableOverride`, not as silence.
    """
    rows = [e for e in (events or [])
            if str((e or {}).get("event_type") or "") == "dependency_skipped"]
    if not rows:
        return None
    actors: list[str] = []
    entries: list[str] = []
    for e in rows:
        actor = str(e.get("actor") or "").strip()
        if not actor:
            raise CompletenessError(
                f"dependency_skipped audit row id={e.get('id')} for "
                f"{e.get('subject')!r} records NO actor — an anonymous "
                f"override is refused, never defaulted (FR-CMP-09)")
        payload = e.get("payload") or {}
        why = str(payload.get("reason") or "").strip()
        if not why:
            raise CompletenessError(
                f"dependency_skipped audit row id={e.get('id')} for "
                f"{e.get('subject')!r} records NO reason — an unexplained "
                f"override is refused, never defaulted (FR-CMP-09)")
        if actor not in actors:
            actors.append(actor)
        entry = f"{e.get('subject') or '(unnamed dependency)'}: {why}"
        if entry not in entries:
            entries.append(entry)
    return Assertion(
        kind="skip", actor=", ".join(actors),
        reason=("dependency skip admitted this run — " + "; ".join(entries)))


# ── The verdict (FR-CMP-07) ────────────────────────────────────────────────


@dataclass(frozen=True)
class CompletenessVerdict:
    """The one verdict a run must carry before it may reach ``complete``.

    ``state`` is ``verified`` / ``asserted`` / ``unverifiable`` — the
    three FR-CMP-07 outcomes — or ``incomplete`` when a measured
    comparison FAILED, which per FR-CMP-01 changes the run's status.
    """

    state: str
    claims: tuple[Claim, ...]
    reasons: tuple[str, ...]
    comparison: PartitionComparison | None = None
    assertion: Assertion | None = None

    def __post_init__(self) -> None:
        if self.state not in VERDICT_STATES:
            raise CompletenessError(
                f"unknown verdict state {self.state!r} — states: "
                f"{VERDICT_STATES}")
        if not self.reasons:
            raise CompletenessError("a verdict must state its reasons")

    @property
    def allows_complete(self) -> bool:
        """May the run be marked complete?  ONLY verified or asserted.
        ``unverifiable`` is its own state and never folds into success;
        ``incomplete`` failed a measured comparison."""
        return self.state in (VERIFIED, ASSERTED)

    @property
    def run_status_effect(self) -> str:
        """What the verdict does to the run's status (FR-CMP-01)."""
        if self.state == VERIFIED:
            return "complete"
        if self.state == ASSERTED:
            return "complete_by_assertion"
        if self.state == INCOMPLETE:
            return "incomplete"
        return "unverifiable"

    @property
    def control_file_annotation(self) -> str:
        """FR-CMP-09 — the verified/asserted distinction must reach the
        control record or the lineage."""
        return {
            VERIFIED: "COMPLETE-VERIFIED",
            ASSERTED: "COMPLETE-BY-ASSERTION",
            UNVERIFIABLE: "UNVERIFIABLE",
            INCOMPLETE: "INCOMPLETE",
        }[self.state]

    def to_dict(self) -> dict[str, Any]:
        return {
            "state": self.state,
            "run_status_effect": self.run_status_effect,
            "control_file_annotation": self.control_file_annotation,
            "reasons": list(self.reasons),
            "claims": [c.to_dict() for c in self.claims],
            "partition_comparison": (self.comparison.to_dict()
                                     if self.comparison else None),
            "assertion": (self.assertion.to_dict()
                          if self.assertion else None),
        }


def _asserted_verdict(claim_tuple: tuple[Claim, ...],
                      failed: list[Claim], unverifiable: list[Claim],
                      alarm: bool,
                      comparison: PartitionComparison | None,
                      assertion: Assertion) -> CompletenessVerdict:
    """The ASSERTED verdict — with everything it OVERRODE named, so
    complete-by-assertion is visible downstream, never laundered into
    verified (FR-CMP-09)."""
    overridden = [f"{c.level}: {c.status} — {c.reason}"
                  for c in (*failed, *unverifiable)]
    if alarm and comparison is not None:
        overridden.append(f"partition_comparison: {comparison.reason}")
    reasons = [(f"complete by {assertion.kind} assertion from "
                f"{assertion.actor}: {assertion.reason}")]
    if overridden:
        reasons.append("OVERRIDES: " + " | ".join(overridden))
    return CompletenessVerdict(
        state=ASSERTED, claims=claim_tuple, reasons=tuple(reasons),
        comparison=comparison, assertion=assertion)


def combine_verdict(claims: Iterable[Claim], *,
                    comparison: PartitionComparison | None = None,
                    assertion: Assertion | None = None,
                    ) -> CompletenessVerdict:
    """Combine the independent claims into ONE verdict that names its
    evidence.

    Precedence, and why:

    1.  An explicit :class:`Assertion` (skip / force-complete / manual)
        yields ``asserted`` — but everything it OVERRODE is named in the
        reasons, because "complete-by-assertion" must be visible
        downstream (FR-CMP-09), never laundered into "verified".
    2.  Any FAILED claim, or an alarming partition comparison, yields
        ``incomplete`` — a comparison that fails changes the run's
        status (FR-CMP-01).
    3.  Any UNVERIFIABLE claim yields ``unverifiable`` — its own state,
        never folded into success.
    4.  Any claim itself ASSERTED (e.g. an on_empty=skip feed claim)
        yields ``asserted``.
    5.  All claims VERIFIED — and at least one claim EXISTS — yields
        ``verified``.  Zero claims is zero evidence: ``unverifiable``.
    """
    claim_tuple = tuple(claims)
    for c in claim_tuple:
        if not isinstance(c, Claim):
            raise CompletenessError(
                f"combine_verdict takes Claim objects, got "
                f"{type(c).__name__} — a raw boolean or dict is not a "
                f"claim")

    failed = [c for c in claim_tuple if c.status == FAILED]
    unverifiable = [c for c in claim_tuple if c.status == UNVERIFIABLE]
    asserted_claims = [c for c in claim_tuple if c.status == ASSERTED]
    alarm = comparison is not None and comparison.alarm

    if assertion is not None:
        return _asserted_verdict(claim_tuple, failed, unverifiable,
                                 alarm, comparison, assertion)

    if failed or alarm:
        reasons = [f"{c.level}: {c.reason}" for c in failed]
        if alarm and comparison is not None:
            reasons.append(f"partition_comparison: {comparison.reason}")
        return CompletenessVerdict(
            state=INCOMPLETE, claims=claim_tuple, reasons=tuple(reasons),
            comparison=comparison, assertion=None)

    if unverifiable:
        reasons = tuple(f"{c.level}: {c.reason}" for c in unverifiable)
        return CompletenessVerdict(
            state=UNVERIFIABLE, claims=claim_tuple, reasons=reasons,
            comparison=comparison, assertion=None)

    if asserted_claims:
        reasons = tuple(f"{c.level}: {c.reason}" for c in asserted_claims)
        return CompletenessVerdict(
            state=ASSERTED, claims=claim_tuple, reasons=reasons,
            comparison=comparison, assertion=None)

    if not claim_tuple:
        return CompletenessVerdict(
            state=UNVERIFIABLE, claims=(),
            reasons=(("no completeness claims were made at all — zero "
                      "evidence is not evidence of completeness"),),
            comparison=comparison, assertion=None)

    reasons = tuple(f"{c.level}: {c.reason}" for c in claim_tuple)
    return CompletenessVerdict(
        state=VERIFIED, claims=claim_tuple, reasons=reasons,
        comparison=comparison, assertion=None)


# ── Persistence seams (FR-CMP-02) — the db object is injected ─────────────
#
# The ``db`` seam is any object exposing:
#
#   record_partition_declaration(feed_run_id=int, feed_config_id=int,
#       business_date=date, identities=list[str], identity_count=int,
#       on_empty=str, source=str|None, declared_at=datetime) -> None
#
#   get_partition_declaration_before(feed_config_id=int,
#       business_date=date) -> list[str] | None
#       (the identities of the most recent declaration STRICTLY BEFORE
#        the given business date, or None when none exists)
#
# Both helpers PROPAGATE db errors: a declaration that cannot be
# recorded is not evidence, and "could not read the previous list" must
# surface as an uncompared comparison — never be swallowed into
# agreement.


def persist_declaration(db, *, feed_run_id: int, feed_config_id: int,
                        business_date: date,
                        declaration: PartitionDeclaration) -> None:
    """FR-CMP-02 — record the declared list WITH the run: the
    identities, not just the count.  Errors propagate — loud."""
    db.record_partition_declaration(
        feed_run_id=feed_run_id,
        feed_config_id=feed_config_id,
        business_date=business_date,
        identities=list(declaration.identities),
        identity_count=declaration.count,
        on_empty=declaration.on_empty,
        source=declaration.source,
        declared_at=declaration.declared_at,
    )


def previous_declared_identities(db, *, feed_config_id: int,
                                 business_date: date) -> list[str] | None:
    """The previous business date's declared identities, or None when no
    prior declaration exists.  A db ERROR propagates: the caller must
    then build an UNCOMPARED comparison (``compare_to_previous(...,
    None)``) explicitly — this function never converts "could not read"
    into "nothing there"."""
    return db.get_partition_declaration_before(
        feed_config_id=feed_config_id, business_date=business_date)
