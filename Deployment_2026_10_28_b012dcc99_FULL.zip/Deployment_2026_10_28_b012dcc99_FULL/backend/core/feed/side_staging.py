"""A side's result STAGED on S3, validated, then brought local (2026-10-14).

The owner: "exploring if we execute the query, read S3 and write S3 -- is it
faster -- in case of cloud data; on-prem data we read from Hive; once the
cloud file is validated we download it locally, merge with on-prem and do the
further validation.  Writing on S3 is not hard-coded -- config based."

Declared on the feed, OFF unless present (``backend_config.stage_to_s3``)::

    {"side": "primary",                 # the side whose result is staged
     "connection_id": 323,              # the S3 connection (credentials)
     "bucket": "my-bucket", "prefix": "qs-stage/",
     "keep": false}                     # delete the staged objects afterwards

What happens to that side's result (a parquet file, or a parts directory):

1. every file is UPLOADED to ``s3://bucket/prefix/<execution id>/<side>/``;
2. VALIDATED there: the object's size (HEAD) is the local size;
3. DOWNLOADED again, fresh, and VALIDATED: the same bytes (sha256) and the
   same row count in its parquet footer;
4. the merge reads the DOWNLOADED copy -- the cloud file it was given, not
   the one it made.

Every step's seconds and bytes are on the execution record
(``files_metadata.cross_source.staged``), so "is it faster" is answered by the
run itself.  Any mismatch FAILS the run before the merge (a correctness
gate): a staged file that is not the file is never merged.
"""
from __future__ import annotations

import hashlib
import logging
import os
import time
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


class StagingRefused(ValueError):
    """The staging declaration is malformed, or a staged file did not
    validate.  The run fails before anything is merged."""


def staging_config(feed_config: dict, side: str) -> Optional[Dict[str, Any]]:
    """The declaration when it stages THIS side, else None."""
    bc = (feed_config or {}).get("backend_config")
    cfg = bc.get("stage_to_s3") if isinstance(bc, dict) else None
    if not cfg:
        return None
    if not isinstance(cfg, dict):
        raise StagingRefused("backend_config.stage_to_s3 must be an object")
    if str(cfg.get("side") or "primary").strip().lower() != side:
        return None
    missing = [k for k in ("bucket", "connection_id") if not cfg.get(k)]
    if missing:
        raise StagingRefused(f"backend_config.stage_to_s3 needs {missing}")
    return cfg


def _files(path: str) -> List[Tuple[str, str]]:
    """``[(local path, name)]`` of a side's result: one parquet, or a parts
    directory's parts in manifest order (the manifest travels as well)."""
    if os.path.isdir(path):
        from core.feed.parts_manifest import MANIFEST_NAME, load_manifest
        manifest, _ = load_manifest(path)
        out = [(os.path.join(path, p.name), p.name) for p in manifest.parts]
        out.append((os.path.join(path, MANIFEST_NAME), MANIFEST_NAME))
        return out
    return [(path, os.path.basename(path))]


def _sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _rows(path: str) -> Optional[int]:
    if not path.endswith(".parquet"):
        return None
    import pyarrow.parquet as pq
    return int(pq.read_metadata(path).num_rows)


def stage_side(result_path: str, cfg: Dict[str, Any], *, execution_id: str, side: str,
               client=None) -> Tuple[str, Dict[str, Any]]:
    """Stage ``result_path`` (module docstring).  Returns ``(the downloaded
    copy's path, the record)``; raises :class:`StagingRefused` on a mismatch."""
    if client is None:
        from core.feed_engine import _build_s3_client
        client = _build_s3_client({k: v for k, v in cfg.items() if k not in ("side", "keep")})
    bucket = str(cfg["bucket"])
    prefix = str(cfg.get("prefix") or "").strip("/")
    base = "/".join(p for p in (prefix, str(execution_id or "x"), side) if p)
    files = _files(result_path)
    rec: Dict[str, Any] = {"side": side, "location": f"s3://{bucket}/{base}/",
                           "files": len(files), "bytes": 0, "rows": 0}

    t0 = time.perf_counter()
    expect = []
    for local, name in files:
        key = f"{base}/{name}"
        client.upload_file(local, bucket, key)
        size = os.path.getsize(local)
        head = int(client.head_object(Bucket=bucket, Key=key).get("ContentLength", -1))
        if head != size:
            raise StagingRefused(f"staged s3://{bucket}/{key} is {head} bytes, the result "
                                 f"is {size} -- not merged")
        expect.append((key, name, size, _sha256(local), _rows(local)))
        rec["bytes"] += size
    rec["upload_seconds"] = round(time.perf_counter() - t0, 2)

    t1 = time.perf_counter()
    dest_dir = result_path.rstrip("/\\") + ".staged"
    os.makedirs(dest_dir, exist_ok=True)
    for key, name, size, sha, rows in expect:
        local = os.path.join(dest_dir, name)
        client.download_file(bucket, key, local)
        got_sha = _sha256(local)
        if got_sha != sha:
            raise StagingRefused(f"the file brought back from s3://{bucket}/{key} is not the "
                                 f"one staged (sha256 differs) -- not merged")
        got_rows = _rows(local)
        if got_rows != rows:
            raise StagingRefused(f"s3://{bucket}/{key} came back with {got_rows} rows, "
                                 f"{rows} were staged -- not merged")
        rec["rows"] += int(rows or 0)
    rec["download_validate_seconds"] = round(time.perf_counter() - t1, 2)

    if not cfg.get("keep"):
        for key, *_ in expect:
            try:
                client.delete_object(Bucket=bucket, Key=key)
            except Exception as exc:                        # noqa: BLE001 -- the file is merged; say so
                logger.warning("[stage-s3] could not remove s3://%s/%s (%s)", bucket, key, exc)
        rec["kept"] = False
    else:
        rec["kept"] = True
    rec["validated"] = "size (HEAD), sha256 and footer rows of every file"
    new_path = (dest_dir if os.path.isdir(result_path)
                else os.path.join(dest_dir, os.path.basename(result_path)))
    logger.info("[stage-s3] %s side: %d file(s), %d bytes, %d rows staged at %s, validated "
                "and brought back (upload %.1f s, download+validate %.1f s)", side,
                rec["files"], rec["bytes"], rec["rows"], rec["location"],
                rec["upload_seconds"], rec["download_validate_seconds"])
    return new_path, rec


__all__ = ["StagingRefused", "staging_config", "stage_side"]
