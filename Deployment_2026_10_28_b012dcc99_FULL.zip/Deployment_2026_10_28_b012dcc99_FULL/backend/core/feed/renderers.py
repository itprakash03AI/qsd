"""Feed output-format renderers — one adapter per format, one registry.

2026-08-04 strategic redesign.  ``feed_engine._convert_to_format_inner``
was a per-format if/elif pile (parquet / csv / json / excel), and
``feed.file_integrity`` carried a SECOND per-format branch pile for the
independent physical recount that backs the completeness certificate.
Adding a format meant touching both — and forgetting the second one
meant the certificate silently lost its independent evidence for that
format (UNVERIFIED at best, a false COMPLETE at worst).

This module is the single seam:

  * ``FormatRenderer`` — one class per output format.  It renders rows
    AND knows how to independently recount its own output, so the
    renderer and the evidence that audits it cannot drift apart.
  * ``_RENDERERS`` — one registry entry per format.  ``get_renderer``
    raises ``UnsupportedOutputFormat`` (a ``ValueError``) listing the
    known formats — misconfiguration is loud, never a silent fallthrough.

Adding a new output format is now: one subclass + one ``register_renderer``
call.  Nothing in feed_engine or file_integrity changes.

Renderers NEVER see the consumer-visible final path.  The engine hands
them a scratch path from ``core.feed.publication`` and publishes
atomically afterwards — a renderer physically cannot create a torn file
under a consumer-visible name.
"""
from __future__ import annotations

import csv
import json
import logging
import shutil
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

#: Excel's hard physical row limit (per sheet).
EXCEL_MAX_ROWS = 1_048_576


class UnsupportedOutputFormat(ValueError):
    """Raised when no renderer is registered for the requested format."""


class FeedOutputTruncatedError(RuntimeError):
    """The requested output format physically cannot hold every source row
    (Excel caps at 1,048,576 rows; ``max_output_rows`` may cap lower).
    Raised INSTEAD of silently truncating: a feed missing rows was
    previously delivered, its ``.ctl`` ROW_COUNT matched the truncated
    file, and the completeness certificate reconciled the truncated file
    against itself and stamped COMPLETE.  A loud failure is the only path
    a consumer cannot miss; opt in to truncated delivery per-feed via
    ``output_options.allow_excel_truncation`` (the run is then reported
    and certified INCOMPLETE, never COMPLETE)."""


class FormatRenderer(ABC):
    """One output format: how to render it, and how to audit the result.

    ``render`` writes parquet → ``out_path`` (a scratch path supplied by
    the engine — never the consumer-visible name) and returns the number
    of data rows written.

    ``physical_row_count`` independently recounts the rows physically
    present in a finished file of this format, or returns ``None`` when
    no cheap independent recount exists (the certificate then reconciles
    without destination evidence — honest absence, never a fabricated
    count).
    """

    #: Registry key (lowercase) — also the ``output_format`` config value.
    name: str = ""

    @abstractmethod
    def render(self, parquet_path: str, out_path: str,
               options: Dict[str, Any], *, chunk_size: int = 100000,
               max_output_rows: int = EXCEL_MAX_ROWS,
               meta: Optional[Dict[str, Any]] = None) -> int:
        """Write ``parquet_path`` as this format into ``out_path``.

        ``meta`` (optional dict) is populated in place with
        ``{"truncated": True, "source_rows": N, "written_rows": M}`` when
        a row-capped format wrote fewer rows than the source holds under
        an explicit opt-in — the engine uses it to report the run loudly
        and certify it INCOMPLETE.
        """

    def physical_row_count(self, path: str,
                           options: Optional[Dict[str, Any]] = None
                           ) -> Optional[int]:
        """Independent recount of data rows in a finished file, or None."""
        return None



# ── Parts-aware source opening (2026-08-22, write ladder) ───────────────────
#
# A native feed result can now be a PARTS DIRECTORY (manifest + N part
# files) instead of one parquet.  Renderers read through this ONE seam,
# which presents the same two things every renderer body uses — 
# ``iter_batches(batch_size=…)`` and ``metadata.num_rows`` — for both
# shapes.  A parts source only ever admits a COMPLETE manifest: a
# renderer must never render an in-flight build.


class _PartsSource:
    """ParquetFile-shaped adapter over a parts directory."""

    def __init__(self, parts_dir: str):
        from core.feed.parts_manifest import load_manifest
        self._dir = parts_dir
        self._manifest, _src = load_manifest(parts_dir)

        class _Md:
            pass
        self.metadata = _Md()
        self.metadata.num_rows = int(self._manifest.total_rows)

    @property
    def schema_arrow(self):
        return self._manifest.arrow_schema()

    def iter_batches(self, batch_size: int = 65536, columns=None):
        from core.feed.parts_manifest import iter_manifest_batches
        return iter_manifest_batches(
            self._dir, self._manifest,
            columns=columns, batch_rows=batch_size,
        )

    def close(self):
        pass


def open_parquet_source(parquet_path: str):
    """A ``pq.ParquetFile`` for a single file, a ``_PartsSource`` for a
    parts directory.  Loud on anything else."""
    import os
    if os.path.isdir(parquet_path):
        from core.feed.parts_manifest import is_parts_dir
        if not is_parts_dir(parquet_path):
            raise ValueError(
                f"{parquet_path} is a directory but carries no parts "
                f"manifest — refusing to guess what to render")
        return _PartsSource(parquet_path)
    import pyarrow.parquet as pq
    return pq.ParquetFile(parquet_path)


# ── Built-in renderers (bodies moved verbatim from feed_engine 2026-08-04) ──


class ParquetRenderer(FormatRenderer):
    name = "parquet"

    def render(self, parquet_path, out_path, options, *, chunk_size=100000,
               max_output_rows=EXCEL_MAX_ROWS, meta=None) -> int:
        import os
        import pyarrow.parquet as pq
        src_schema = open_parquet_source(parquet_path).schema_arrow
        if _time_fields(src_schema):
            # K4 (2026-10-07): a SQL TIME is TEXT in every file, on every
            # lane -- the Spark lanes cannot carry a time type at all
            # (their reader makes it a 1970-01-01 timestamp), so a native
            # time64 column made the counterparty's schema depend on
            # routing.  The extract keeps time64 (the Oracle refusal reads
            # it); the FILE carries core.feed.lane_output.time_text.
            return _render_parquet_time_as_text(
                parquet_path, out_path, src_schema, chunk_size)
        if os.path.isdir(parquet_path):
            # Parts directory → ONE output parquet, written batch-by-batch
            # through a pinned writer (unified schema from the manifest —
            # never re-inferred per chunk).  Verified against the manifest
            # before returning: a rendered count that does not reconcile
            # is refused, not reported.
            src = open_parquet_source(parquet_path)
            schema = src.schema_arrow
            total = 0
            writer = pq.ParquetWriter(out_path, schema, compression="zstd")
            try:
                for batch in src.iter_batches(batch_size=chunk_size):
                    writer.write_batch(batch)
                    total += batch.num_rows
            finally:
                writer.close()
            expected = src.metadata.num_rows
            if total != expected:
                raise RuntimeError(
                    f"parquet render from parts wrote {total} rows but the "
                    f"manifest holds {expected} — refusing to deliver a "
                    f"count that does not reconcile")
            return total
        shutil.copy2(parquet_path, out_path)
        pf = pq.ParquetFile(parquet_path)
        return pf.metadata.num_rows

    def physical_row_count(self, path, options=None):
        try:
            import pyarrow.parquet as pq  # type: ignore
        except ImportError:
            return None
        return int(pq.ParquetFile(path).metadata.num_rows)


def _time_fields(schema) -> list:
    import pyarrow as pa
    return [f.name for f in schema if pa.types.is_time(f.type)]


def _render_parquet_time_as_text(parquet_path, out_path, schema,
                                 chunk_size) -> int:
    import pyarrow as pa
    import pyarrow.parquet as pq
    from core.feed.lane_output import time_text
    times = set(_time_fields(schema))
    out_schema = pa.schema([
        f.with_type(pa.string()) if f.name in times else f for f in schema])
    src = open_parquet_source(parquet_path)
    total = 0
    writer = pq.ParquetWriter(out_path, out_schema, compression="zstd")
    try:
        for batch in src.iter_batches(batch_size=chunk_size):
            cols = []
            for f, col in zip(schema, batch.columns):
                if f.name in times:
                    col = pa.array([time_text(v) for v in col.to_pylist()],
                                   type=pa.string())
                cols.append(col)
            writer.write_batch(pa.RecordBatch.from_arrays(cols,
                                                          schema=out_schema))
            total += batch.num_rows
    finally:
        writer.close()
    return total


def iter_frames(pf, chunk_size: int):
    """Every row of ``pf`` as pandas frames within the cell budget
    (``core.feed.batch_budget``, 2026-10-11) -- the ONE loop the CSV / JSON
    / Excel renderers read through.  A frame of N rows x C columns is N*C
    Python objects; one frame is in flight at a time."""
    from core.feed.batch_budget import rows_within_budget
    rows = rows_within_budget(chunk_size, len(_source_columns(pf)) or None)
    for batch in pf.iter_batches(batch_size=rows):
        yield _batch_to_pandas(batch)


def _batch_to_pandas(batch):
    """A record batch as a DataFrame whose INTEGER columns stay integers.

    pandas 2.x (every Python 3.11 image) turns an integer column holding a
    NULL into float64: a feed shipped ``1`` as ``1.0`` (found 2026-09-25 on
    the rebuilt rig), and an id above 2**53 silently lost its low digits.
    ``integer_object_nulls`` keeps exact Python ints with ``None`` for the
    NULLs, which ``_is_missing`` renders as the contract's NULL marker."""
    return batch.to_pandas(integer_object_nulls=True)


def _inf_to_nan(df):
    """+/-inf -> NaN in the FLOAT columns only.  ``DataFrame.replace`` over
    every column re-infers object columns on pandas 2.x, which turned the
    exact integers ``_batch_to_pandas`` preserves back into float64."""
    import numpy as np
    floats = df.select_dtypes(include=[np.floating]).columns
    if len(floats):
        df[floats] = df[floats].replace([np.inf, -np.inf], np.nan)
    return df


def _is_missing(v: Any) -> bool:
    """One answer to "is this cell NULL?" -- ``core.feed.lane_output``'s,
    the same one the Spark job applies (None, NaN, +/-Infinity, NaT, NA)."""
    from core.feed.lane_output import is_missing
    return is_missing(v)


class CsvRenderer(FormatRenderer):
    name = "csv"

    def render(self, parquet_path, out_path, options, *, chunk_size=100000,
               max_output_rows=EXCEL_MAX_ROWS, meta=None) -> int:
        # ── ONE writer, every lane (2026-10-07, K1) ───────────────────
        # The dialect is resolved by core.feed.csv_dialect and APPLIED by
        # core.feed.lane_output.CsvRowWriter -- the writer the Spark job
        # renders with too (spark/jobs/qs_lane_output.py, a byte-identical
        # copy).  Until today the job wrote CSV with Spark's own writer:
        # booleans ``true``, timestamps ``...T09:30:00.000Z``, a quote
        # escaped ``\"``, a NULL ``""`` -- the size router decided which
        # file the counterparty got.  What a cell looks like (NULL / NaN /
        # Inf as the NULL marker, an empty string's own marker, a TIME as
        # HH:MM:SS[.ffffff]) is decided in that module, not here.
        from core.feed.csv_dialect import resolve as _resolve_dialect
        from core.feed.lane_output import CsvRowWriter, open_csv
        dialect = _resolve_dialect(options or {})
        pf = open_parquet_source(parquet_path)
        # 2026-10-13 -- a large file is written by several processes, the
        # same bytes (core/feed/csv_parallel.py); None = one process, below.
        from core.feed.csv_parallel import render_parallel
        _n = render_parallel(parquet_path, out_path, dialect, chunk_size,
                             [f.name for f in pf.schema_arrow])
        if _n is not None:
            return _n
        with open_csv(out_path, dialect) as f:
            writer = CsvRowWriter(f, dialect)
            header_written = False
            for df in iter_frames(pf, chunk_size):
                if not header_written:
                    writer.header(df.columns.tolist())
                    header_written = True
                for row in df.itertuples(index=False, name=None):
                    writer.row(row)
            if not header_written:
                # An empty result is still a file with its header.
                writer.header(_source_columns(pf))
        return writer.rows_written

    def physical_row_count(self, path, options=None):
        from core.feed.lane_output import csv_physical_rows
        return csv_physical_rows(path, bool((options or {}).get("header", True)))


def _source_columns(pf) -> list:
    """The column names of a source with no rows."""
    schema = getattr(pf, "schema_arrow", None)
    if schema is not None:
        return list(schema.names)
    return []


class JsonRenderer(FormatRenderer):
    name = "json"

    def render(self, parquet_path, out_path, options, *, chunk_size=100000,
               max_output_rows=EXCEL_MAX_ROWS, meta=None) -> int:
        # JSON lines through core.feed.lane_output.json_line -- the line
        # the Spark job writes too (K1).  Rows are read as TUPLES: the
        # DataFrame.iterrows() this used made each row ONE Series, which
        # upcasts a row of ints and floats to floats (an id of 1 shipped
        # as 1.0), and the lines end with \n on every OS (the text-mode
        # write ended them with os.linesep).
        from core.feed.lane_output import json_line
        pf = open_parquet_source(parquet_path)
        total_rows = 0
        with open(out_path, "w", encoding="utf-8", newline="") as f:
            for df in iter_frames(pf, chunk_size):
                cols = df.columns.tolist()
                for row in df.itertuples(index=False, name=None):
                    f.write(json_line(cols, row))
                total_rows += len(df)
        return total_rows

    def physical_row_count(self, path, options=None):
        options = options or {}
        if not options.get("lines", False):
            return None  # JSON-array blob — not a line-per-row shape
        from core.feed.lane_output import lines_physical_rows
        return lines_physical_rows(path)


class ExcelRenderer(FormatRenderer):
    name = "excel"

    def render(self, parquet_path, out_path, options, *, chunk_size=100000,
               max_output_rows=EXCEL_MAX_ROWS, meta=None) -> int:
        import pyarrow.parquet as pq
        import pandas as pd
        options = options or {}
        pf = open_parquet_source(parquet_path)
        total_rows = pf.metadata.num_rows
        # 2026-08-17 — non-positive max_output_rows means UNLIMITED (the
        # config default is 0 since 2026-08-13).  ``min(0, 1_048_576)``
        # was 0: every non-empty Excel feed failed with "row cap is 0"
        # (or delivered an EMPTY workbook under the truncation opt-in).
        # Excel's own physical limit is then the only cap.
        if not max_output_rows or max_output_rows <= 0:
            max_output_rows = EXCEL_MAX_ROWS
        excel_row_limit = min(max_output_rows, EXCEL_MAX_ROWS)

        # 2026-08-03 (C1) — NEVER truncate silently.  The old loop simply
        # ``break``ed at the cap: no warning, no error, no flag — and the
        # truncated count then flowed into the .ctl ROW_COUNT and the
        # completeness certificate's reconciliation.  Default: fail LOUD.
        # Explicit per-feed opt-in ``output_options.allow_excel_truncation``
        # delivers the truncated file but reports + certifies the run
        # INCOMPLETE via ``meta``.
        if total_rows > excel_row_limit:
            if not options.get("allow_excel_truncation", False):
                raise FeedOutputTruncatedError(
                    f"Excel output cannot hold every row: source has "
                    f"{total_rows:,} rows but the Excel row cap is "
                    f"{excel_row_limit:,} (min of Excel's 1,048,576 hard "
                    f"limit and feed_generation.max_output_rows="
                    f"{max_output_rows:,}).  Refusing to deliver a "
                    f"silently truncated feed.  Use output_format=csv/"
                    f"parquet for full data, or set "
                    f"output_options.allow_excel_truncation=true to deliver "
                    f"the first {excel_row_limit:,} rows explicitly marked "
                    f"INCOMPLETE."
                )
            logger.warning(
                "[feed_renderers] Excel output TRUNCATED by explicit opt-in "
                "(allow_excel_truncation): writing %d of %d source rows — "
                "this run will be reported and certified INCOMPLETE",
                excel_row_limit, total_rows,
            )
            if meta is not None:
                meta["truncated"] = True
                meta["source_rows"] = int(total_rows)
                meta["written_rows"] = int(excel_row_limit)

        # Chunked read — never load entire file into memory
        chunks = []
        rows_collected = 0
        for df_chunk in iter_frames(pf, chunk_size):
            # Round 15: openpyxl raises on NaN/Inf — coerce both to None
            # so Excel renders them as empty cells (consistent with CSV
            # na_marker default).
            df_chunk = _inf_to_nan(df_chunk)
            df_chunk = df_chunk.where(pd.notna(df_chunk), None)
            remaining = excel_row_limit - rows_collected
            if remaining <= 0:
                break
            if len(df_chunk) > remaining:
                df_chunk = df_chunk.head(remaining)
            chunks.append(df_chunk)
            rows_collected += len(df_chunk)
            if rows_collected >= excel_row_limit:
                break

        if chunks:
            df = pd.concat(chunks, ignore_index=True)
        else:
            df = pd.DataFrame()
        df.to_excel(out_path, index=False, engine="openpyxl")
        return len(df)

    # xlsx has no cheap independent recount — inherit the honest None.


# ── Registry ────────────────────────────────────────────────────────────────

_RENDERERS: Dict[str, FormatRenderer] = {}


def register_renderer(renderer: FormatRenderer) -> None:
    """Register a renderer under its ``name``.  Re-registration replaces
    (supports tests and deployment-specific overrides)."""
    if not renderer.name:
        raise ValueError("FormatRenderer.name must be a non-empty string")
    _RENDERERS[renderer.name.lower()] = renderer


def get_renderer(output_format: str) -> FormatRenderer:
    """Resolve the renderer for a format — loud on miss, never a fallthrough."""
    key = (output_format or "").lower()
    r = _RENDERERS.get(key)
    if r is None:
        raise UnsupportedOutputFormat(
            f"Unsupported output format: {output_format}. "
            f"Registered formats: {sorted(_RENDERERS)}"
        )
    return r


def known_formats() -> list:
    return sorted(_RENDERERS)


for _r in (ParquetRenderer(), CsvRenderer(), JsonRenderer(), ExcelRenderer()):
    register_renderer(_r)
