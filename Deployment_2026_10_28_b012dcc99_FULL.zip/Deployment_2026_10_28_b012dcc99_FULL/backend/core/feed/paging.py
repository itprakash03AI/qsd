"""THE paging contract of the feed screens' lists (2026-10-12, the owner:
"in upstream messages and all other places pagination is missing").

Every list a Feed Run Status tab shows -- upstream messages, auto-onboarded
entities, Iceberg inspections, variance holds, feed alerts -- pages the SAME
way: the request carries ``page`` (1-based) and ``page_size`` (clamped to
:data:`MAX_PAGE_SIZE`), the database returns ONE page (offset / limit), and
the answer carries a ``paging`` block -- page, page size, the TOTAL over the
whole filter (a grouped count, never the length of the page), pages, and the
first / last row shown ("Showing 51-100 of 4,012").  Counts per status that a
screen shows beside the list are grouped counts too: a count taken from one
page is wrong the moment there are two.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Sequence, Tuple

DEFAULT_PAGE_SIZE = 50
MAX_PAGE_SIZE = 500


@dataclass(frozen=True)
class Paging:
    page: int
    page_size: int

    @property
    def offset(self) -> int:
        return (self.page - 1) * self.page_size


def paging(page: Any = 1, page_size: Any = DEFAULT_PAGE_SIZE) -> Paging:
    """The request's page, clamped: page >= 1, 1 <= page_size <= MAX."""
    try:
        p = max(1, int(page or 1))
    except (TypeError, ValueError):
        p = 1
    try:
        s = max(1, min(int(page_size or DEFAULT_PAGE_SIZE), MAX_PAGE_SIZE))
    except (TypeError, ValueError):
        s = DEFAULT_PAGE_SIZE
    return Paging(p, s)


def block(total: int, p: Paging, shown: int) -> Dict[str, int]:
    """The answer's ``paging`` block."""
    total = max(0, int(total or 0))
    pages = max(1, -(-total // p.page_size))
    first = p.offset + 1 if shown else 0
    return {"page": p.page, "page_size": p.page_size, "total": total, "pages": pages,
            "first": first, "last": p.offset + shown if shown else 0}


def slice_rows(rows: Sequence[Any], p: Paging) -> Tuple[List[Any], int]:
    """One page of an already-filtered list (where the filter is not SQL --
    e.g. a per-user visibility rule) and the total it was cut from."""
    rows = list(rows or [])
    return rows[p.offset:p.offset + p.page_size], len(rows)
