"""Executing one child per declared partition (BRD §4.2, FR-RUN-02/04/05).

Foundation C made the child a ROW rather than a loop iteration, and the reason
is addressability: a loop iteration cannot be re-run alone, and "re-run file
738 without touching the other 999" is a hard requirement.  This is the half
that actually runs them.

Three rules the loop exists to enforce, none of which a plain ``for`` gives you:

* **A failed child stays failed and its siblings are untouched.**  One
  partition failing must not fail the other 999, and must not stop them
  running either.
* **The parent status is DERIVED, never written here.**  A directly-written
  parent is how a re-run of one child leaves a permanently failed parent, or
  how a parent reports complete while a child is still writing.
* **Every child is claimed before it runs.**  Two pods expanding the same run
  must not both execute partition 738; the claim is the only thing that makes
  that impossible rather than unlikely.

Everything is injected — the executor, the clock, the db.  Nothing here opens
a connection or imports the engine, so the whole loop is provable without one.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Optional, Sequence

logger = logging.getLogger(__name__)

#: The query token a partitioned feed binds.  A feed's SQL says
#: ``WHERE entity = '{{partition_key}}'``; the loop supplies the value per
#: child.  One reserved name, so a feed cannot be partitioned by accident.
PARTITION_TOKEN = "partition_key"


@dataclass
class ChildOutcome:
    partition_key: str
    status: str                    # completed | failed | skipped
    part_path: Optional[str] = None
    row_count: Optional[int] = None
    error: Optional[str] = None

    def to_dict(self) -> dict:
        return {"partition_key": self.partition_key, "status": self.status,
                "part_path": self.part_path, "row_count": self.row_count,
                "error": self.error}


@dataclass
class ChildRunSummary:
    feed_run_id: int
    outcomes: list = field(default_factory=list)

    @property
    def completed(self) -> list:
        return [o for o in self.outcomes if o.status == "completed"]

    @property
    def failed(self) -> list:
        return [o for o in self.outcomes if o.status == "failed"]

    @property
    def total_rows(self) -> int:
        return sum(int(o.row_count or 0) for o in self.completed)

    @property
    def part_paths(self) -> list:
        return [o.part_path for o in self.completed if o.part_path]

    def to_dict(self) -> dict:
        return {"feed_run_id": self.feed_run_id,
                "declared": len(self.outcomes),
                "completed": len(self.completed),
                "failed": len(self.failed),
                "total_rows": self.total_rows,
                "outcomes": [o.to_dict() for o in self.outcomes]}


def bind_partition(feed_config: dict, partition_key: str) -> dict:
    """A per-child copy of the feed config with the partition value bound.

    A COPY, deliberately: mutating the shared config would leak partition 738's
    value into partition 739's query, which produces a plausible file
    containing the wrong rows — the worst kind of wrong, because nothing
    fails.
    """
    cfg = dict(feed_config)
    params = dict(cfg.get("query_params") or {})
    params[PARTITION_TOKEN] = partition_key
    cfg["query_params"] = params
    return cfg


def execute_children(
    db: Any,
    feed_config: dict,
    *,
    feed_run_id: int,
    execute_one: Callable[[dict, str], Any],
    pod_id: str = "worker",
    heartbeat_every: int = 1,
    children: Optional[Sequence[dict]] = None,
) -> ChildRunSummary:
    """Run every pending child of ``feed_run_id``, one at a time.

    ``execute_one(child_config, partition_key)`` produces the part and returns
    either a path or ``(path, row_count)``.  It is injected so this module
    never imports the engine — and so the loop's rules can be proved without
    executing a query.

    Sequential on purpose for now: per-child CONCURRENCY belongs to the claims
    machinery (a child takes a slot on every connection its feed touches), and
    running children in parallel here would bypass that budget entirely —
    reintroducing exactly the per-process concurrency this platform just moved
    into the database.
    """
    rows = list(children if children is not None
                else db.list_feed_file_runs(feed_run_id, status="pending"))
    summary = ChildRunSummary(feed_run_id=int(feed_run_id))

    for index, child in enumerate(rows, start=1):
        key = str(child.get("partition_key") or "")
        child_id = child.get("id")

        claimed = db.claim_pending_feed_file_run(child_id, claimed_by=pod_id)
        if not claimed:
            # Another worker owns it.  NOT an error and NOT an outcome of
            # ours: recording one would let two pods each report a verdict on
            # the same partition.
            logger.info(
                "[child_execution] run %s partition %r already claimed by "
                "another worker — skipping", feed_run_id, key)
            continue

        try:
            produced = execute_one(bind_partition(feed_config, key), key)
        except Exception as exc:
            # The failure is recorded against THIS child and the loop
            # continues.  A partition that fails must not stop its siblings,
            # and must not fail them either (§4.2).
            logger.error(
                "[child_execution] run %s partition %r FAILED: %s",
                feed_run_id, key, exc)
            try:
                db.fail_feed_file_run(child_id, error=str(exc)[:2000],
                                      owned_by=pod_id)
            except Exception as _mark_exc:
                logger.error(
                    "[child_execution] run %s partition %r failed AND could "
                    "not be marked failed (%s) — it will look pending until "
                    "the reaper clears it", feed_run_id, key, _mark_exc)
            summary.outcomes.append(
                ChildOutcome(partition_key=key, status="failed",
                             error=str(exc)[:2000]))
            continue

        if heartbeat_every and index % heartbeat_every == 0:
            # A long fan-out must keep proving it is alive, or the reaper
            # reclaims a run that is working perfectly well.
            #
            # FR-RUN-08 fix (2026-09-02): this beat used to fire AFTER
            # complete_feed_file_run — on a child already 'completed', so
            # the status=='running' filter in heartbeat_feed_file_run
            # never matched: the beat NEVER landed and every child logged
            # a false "lost its claim" warning.  It now fires while the
            # child is still running (claimed above, completed below).
            try:
                if not db.heartbeat_feed_file_run(child_id, owned_by=pod_id):
                    logger.warning(
                        "[child_execution] run %s lost its claim on partition "
                        "%r — another actor now owns it", feed_run_id, key)
            except Exception as _hb_exc:
                logger.debug("[child_execution] heartbeat failed: %s", _hb_exc)

        part_path, row_count = _unpack(produced)
        db.complete_feed_file_run(child_id, part_path=part_path,
                                  row_count=row_count, owned_by=pod_id)
        summary.outcomes.append(
            ChildOutcome(partition_key=key, status="completed",
                         part_path=part_path, row_count=row_count))

    logger.info("[child_execution] run %s: %d completed, %d failed of %d",
                feed_run_id, len(summary.completed), len(summary.failed),
                len(summary.outcomes))
    return summary


def _unpack(produced: Any) -> tuple:
    """``execute_one`` may return a path, or ``(path, row_count)``.

    A bare path yields ``row_count=None`` — which is UNKNOWN, not zero.
    Recording zero would make a completeness claim the executor never made.
    """
    if isinstance(produced, (tuple, list)):
        path = produced[0] if produced else None
        rows = produced[1] if len(produced) > 1 else None
        return path, rows
    return produced, None
