"""Filename / control-file template renderer — Phase 130.

Implements the enterprise filename-mask language seen in the user's
sample row:

    FILE_NAME:        FLX_Claude_MONTHEND_{me_business_date}_{run_date}.dat
    CTL_FILE_NAME:    FLX_Claude_MONTHEND_{me_business_date}_{run_date}.ctl
    FILE_NAME_MASK:   Claude_MONTHEND_${COB_PREV_EOM(YYYYMMDD)}_${YYYYMMDD}.dat

Two token syntaxes, both supported in the same string:

  ``{name}``                — plain context variable (run_date, business_date,
                              feed_name, business_date_YYYYMMDD, etc).
                              Optional format suffix: ``{run_date:YYYYMMDD}``.

  ``${FUNCTION(FMT)}``      — enterprise function syntax:
                                ${YYYYMMDD}                  → run_date
                                ${YYYY-MM-DD}                → run_date
                                ${COB_PREV_EOM(YYYYMMDD)}    → previous-EOM business day
                                ${COB_BUSINESS_DATE(FMT)}    → resolved business_date
                                ${COB_PREV_BUSINESS_DAY(FMT)}→ business_date - 1 BD
                                ${RUN_DATE(FMT)}             → run_date

Zero hardcoded format strings beyond the standard date-format
vocabulary that the enterprise schema already defines.  Adding a new
function = one entry in the ``_FUNCTIONS`` dict.

Single responsibility: render a template string into a filename
given a context.  Does NOT touch the filesystem, does NOT write
anything, does NOT know about feed runs.  Caller composes it with
``ControlFileWriter`` etc.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date as _date
from typing import Callable, Dict, Optional


# ── Format code table (DB-extensible) ───────────────────────────────────────
#
# Maps enterprise format codes → Python strftime format strings.  The
# mapping is module-local because the codes are part of the public
# template language (admins write them in feed_configs.file_name_mask).
# Operators who need a custom format add to ``feed_generation.date_formats``
# in config.json — that override merges into this table at render time.

_BUILTIN_DATE_FORMATS: Dict[str, str] = {
    "YYYYMMDD":   "%Y%m%d",
    "YYYY-MM-DD": "%Y-%m-%d",
    "YYYYMM":     "%Y%m",
    "YYYY-MM":    "%Y-%m",
    "DD-MON-YYYY":"%d-%b-%Y",
    "DD-MMM-YYYY":"%d-%b-%Y",
    "DDMMYYYY":   "%d%m%Y",
    "MMDDYYYY":   "%m%d%Y",
    "YYYY":       "%Y",
    "MM":         "%m",
    "DD":         "%d",
}


def _resolve_date_format(code: str) -> Optional[str]:
    """Look up an enterprise format code → strftime format string.

    Config-driven extension: anything under
    ``feed_generation.date_formats`` in config.json is merged in
    (overrides builtins; adds new codes).  No code change required
    to support a new format.
    """
    if not code:
        return None
    upper = code.upper()
    try:
        from core.config import get as _cfg_get
        custom = _cfg_get("feed_generation", "date_formats", {}) or {}
        if isinstance(custom, dict) and upper in custom:
            v = custom[upper]
            if isinstance(v, str) and v:
                return v
    except Exception:
        pass
    return _BUILTIN_DATE_FORMATS.get(upper)


# ── Render context ──────────────────────────────────────────────────────────


@dataclass(frozen=True)
class RenderContext:
    """All inputs the renderer can substitute.  Frozen so the SOD job
    can construct one per feed-run and pass it to multiple consumers
    (filename, control file, SQL parameter binding) without worrying
    about mutation."""
    run_date: _date
    business_date: _date
    feed_name: str = ""
    feed_id: int = 0
    run_id: int = 0
    # COB helpers — caller pre-computes these from BusinessCalendar so
    # the renderer stays free of DB lookups + import cycles.  When the
    # caller doesn't supply them, ``${COB_PREV_EOM(…)}`` etc raise
    # ``KeyError`` with a clear message rather than silently producing
    # the wrong date.
    cob_prev_eom: Optional[_date] = None
    cob_prev_business_day: Optional[_date] = None
    # FR-ART-07 (2026-09-03) — the gapless file sequence number for THIS
    # run.  Pre-computed by the caller for the same reason the COB dates
    # are: allocating one is a durable, transactional, retry-on-conflict
    # database operation, and this module renders strings.  Absent when
    # the template does not ask for it; ``${SEQ(width)}`` on a context
    # without one RAISES rather than rendering a zero, because a
    # counterparty checking a sequence would read FLX_000000.csv as a
    # real file number and the hole would be permanent.
    sequence_value: Optional[int] = None
    # Free-form extras — e.g. an external trigger's payload-supplied
    # tags can land here without changing the dataclass shape.
    extras: Optional[Dict[str, str]] = None


# ── Function table ──────────────────────────────────────────────────────────
#
# Maps enterprise function name → callable that takes (RenderContext,
# fmt_code) and returns a string.  Extending = one row.  No string
# parsing of "if function_name == 'X' elif …" branches anywhere else
# in the file.

def _fmt_or_default(d: _date, fmt_code: Optional[str]) -> str:
    """Format a date with the requested code, falling back to
    YYYYMMDD when none supplied."""
    pyfmt = _resolve_date_format(fmt_code or "YYYYMMDD") or "%Y%m%d"
    return d.strftime(pyfmt)


_FUNCTIONS: Dict[str, Callable[[RenderContext, Optional[str]], str]] = {
    "RUN_DATE":              lambda ctx, fmt: _fmt_or_default(ctx.run_date, fmt),
    "COB_BUSINESS_DATE":     lambda ctx, fmt: _fmt_or_default(ctx.business_date, fmt),
    "BUSINESS_DATE":         lambda ctx, fmt: _fmt_or_default(ctx.business_date, fmt),
    "COB_PREV_EOM":          lambda ctx, fmt: _fmt_or_default(_require(ctx.cob_prev_eom, "COB_PREV_EOM"), fmt),
    "COB_PREV_BUSINESS_DAY": lambda ctx, fmt: _fmt_or_default(_require(ctx.cob_prev_business_day, "COB_PREV_BUSINESS_DAY"), fmt),
    # ``${SEQ}`` → 6 digits (the common counterparty width);
    # ``${SEQ(4)}`` → 4.  The width is a FIELD WIDTH in the
    # counterparty's parser, so overflowing it is refused loudly rather
    # than silently widened — see core.feed.sequence.format_sequence.
    "SEQ":                   lambda ctx, fmt: _render_sequence(ctx, fmt),
    "SEQUENCE":              lambda ctx, fmt: _render_sequence(ctx, fmt),
}


def _render_sequence(ctx: "RenderContext", fmt: Optional[str]) -> str:
    from .sequence import format_sequence
    if ctx.sequence_value is None:
        raise KeyError(
            "Template uses ${SEQ(...)} but RenderContext carries no "
            "sequence_value.  Allocate one through SequenceAllocator "
            "before rendering — a sequence number is durable state, not "
            "a format, and rendering a placeholder would hand the "
            "counterparty a file number that was never taken.")
    try:
        width = int(fmt) if (fmt or "").strip() else 6
    except ValueError:
        raise KeyError(
            f"${{SEQ({fmt})}} — the argument is a field WIDTH in digits "
            f"(e.g. ${{SEQ(6)}}), not a date format")
    return format_sequence(int(ctx.sequence_value), width)


def _require(value, name: str) -> _date:
    if value is None:
        raise KeyError(
            f"Template uses ${{{name}(…)}} but RenderContext didn't "
            f"supply it.  Compute via BusinessCalendar and set the "
            f"matching dataclass field before calling FilenameRenderer."
        )
    return value


# ── Renderer ────────────────────────────────────────────────────────────────


# ``${FUNC(FMT)}`` or ``${FMT}`` (bare date format treated as RUN_DATE)
_DOLLAR_TOKEN_RE = re.compile(r"\$\{([A-Z_][A-Z0-9_-]*)(?:\(([^)]*)\))?\}")

# ``{name}`` or ``{name:fmt}``
_BRACE_TOKEN_RE = re.compile(r"\{([A-Za-z_][A-Za-z0-9_]*)(?::([A-Za-z0-9_-]+))?\}")


#: The LEGACY vocabulary -- the five names the engine's original
#: ``template.format(...)`` expander knows (``core.feed_engine
#: ._legacy_build_filename``).  Declared HERE, beside the typed
#: vocabulary, because until 2026-09-13 the two renderers were chosen by
#: SYNTAX: a plain ``{business_date}`` (a name this renderer lists in its
#: own error message) was routed to the legacy formatter, which raised a
#: bare ``KeyError('business_date')`` -- and the run failed with the
#: reason ``'business_date'`` and nothing else.  One vocabulary, one
#: check (``unknown_template_tokens``), consulted at authoring and by the
#: router.
LEGACY_TOKENS = ("name", "date", "ext", "timestamp", "uuid")


def legacy_token_values(feed_name, ext, *, business_date=None,
                        now=None) -> Dict[str, str]:
    """THE values of the legacy five, for every lane (2026-10-07).

    ``{date}`` is the run's BUSINESS date when the run has one, and the
    wall-clock day only when it has none.  It used to be the wall clock
    always: a backfill for business date 2026-10-06 that ran on the 7th
    shipped ``..._20261007.csv`` -- yesterday's data under today's name,
    and a re-run of last month's feed collided with today's file.  The
    engine resolved the run's business date and handed it to the
    filename builder, which never read it for these five.  A template
    that wants the creation time says so explicitly: ``{timestamp}``,
    ``{run_date}`` or ``${RUN_DATE(FMT)}`` / a bare ``${YYYYMMDD}``.

    Computed in ONE place because it was computed in three (the engine's
    legacy expander, the pipeline's mixed-template extras and its
    no-renderer fallback -- the Spark lane's counterparty filename takes
    that fallback), and the three agreeing by copy is how one of them
    drifts.  ``{name}`` is sanitised exactly as before.
    """
    import uuid as _uuid
    from datetime import datetime as _datetime, timezone as _timezone

    moment = now or _datetime.now(_timezone.utc)
    day = _coerce_day(business_date) or moment.date()
    safe_name = "".join(c if c.isalnum() or c in ("_", "-") else "_"
                        for c in str(feed_name if feed_name is not None
                                     else "feed"))
    return {
        "name": safe_name,
        "date": day.strftime("%Y%m%d"),
        "ext": str(ext),
        "timestamp": moment.strftime("%Y%m%d_%H%M%S"),
        "uuid": _uuid.uuid4().hex[:8],
    }


def _coerce_day(value) -> Optional[_date]:
    """A date from a date, a datetime or an ISO string; None when there is
    none or it does not parse (the caller then uses the wall clock -- the
    pre-2026-10-07 behaviour, never a crash over a filename)."""
    from datetime import datetime as _datetime
    if value is None or value == "":
        return None
    if isinstance(value, _datetime):
        return value.date()
    if isinstance(value, _date):
        return value
    try:
        return _date.fromisoformat(str(value)[:10])
    except ValueError:
        return None

#: The plain ``{name}`` tokens ``FilenameRenderer._resolve_brace`` answers
#: itself (case-insensitive), before ``RenderContext.extras``.
BRACE_TOKENS = ("run_date", "business_date", "cob", "me_business_date",
                "feed_name", "feed_id", "run_id", "cob_prev_eom",
                "cob_prev_business_day")


def unknown_template_tokens(template: str, extras=()) -> "list[str]":
    """Every token the template names that NO renderer can resolve, in
    the template's own spelling -- ``[]`` when all of them are known.

    A ``${HEAD(...)}`` is known when HEAD is a date format code or a
    function in the table; a ``{name}`` / ``{name:fmt}`` is known when it
    is one of :data:`BRACE_TOKENS`, one of :data:`LEGACY_TOKENS`, or a
    caller-declared extra.  Consulted by the authoring routes (a 422 with
    the vocabulary, instead of a 3am ``KeyError``) and by the pipeline's
    router.
    """
    out: "list[str]" = []
    for m in _DOLLAR_TOKEN_RE.finditer(template or ""):
        head = m.group(1).upper()
        if head in _BUILTIN_DATE_FORMATS or _resolve_date_format(head)                 or head in _FUNCTIONS:
            continue
        out.append("${" + m.group(1) + "}")
    known_extras = {str(k).lower() for k in (extras or ())}
    # The renderer substitutes ``${...}`` FIRST, so its brace pass never
    # sees ``{YYYYMMDD}`` inside ``${YYYYMMDD}``; scan the same remainder.
    remainder = _DOLLAR_TOKEN_RE.sub("", template or "")
    for m in _BRACE_TOKEN_RE.finditer(remainder):
        name = m.group(1)
        low = name.lower()
        if low in BRACE_TOKENS or low in LEGACY_TOKENS or low in known_extras:
            continue
        out.append("{" + name + "}")
    return out


def template_tokens(template: str) -> Dict[str, object]:
    """The tokens the renderer would substitute, parsed by ITS OWN two
    patterns -- for a caller that must restrict WHICH known tokens it
    accepts (the file-arrival watcher accepts only the business date,
    2026-10-07) without keeping a second copy of the grammar.

    Returns ``{"tokens": [...], "stray": str}``.  Each token is
    ``{"token", "syntax" ("dollar" | "brace"), "name" (upper-cased for
    dollar, lower-cased for brace), "arg", "format_known"}``;
    ``format_known`` is False when a date format code the renderer would
    NOT resolve is named (``{business_date:%Y%m%d}`` never matches the
    brace pattern at all and is left in ``stray``; ``{business_date:FOO}``
    matches and would silently render as YYYYMMDD).  ``stray`` is the
    template with every recognised token removed, so a caller can refuse a
    left-over ``{`` / ``}`` / ``${`` the renderer would pass through as
    literal text.
    """
    out: list = []
    for m in _DOLLAR_TOKEN_RE.finditer(template or ""):
        head, arg = m.group(1).upper(), m.group(2)
        if head in _BUILTIN_DATE_FORMATS or _resolve_date_format(head):
            known = True                    # bare ${FMT}: run_date in FMT
        elif head in ("SEQ", "SEQUENCE"):
            known = True                    # the argument is a width
        else:
            known = (not (arg or "").strip()) or bool(_resolve_date_format(arg.strip()))
        out.append({"token": m.group(0), "syntax": "dollar", "name": head,
                    "arg": arg, "format_known": known})
    remainder = _DOLLAR_TOKEN_RE.sub("", template or "")
    for m in _BRACE_TOKEN_RE.finditer(remainder):
        name, fmt = m.group(1).lower(), m.group(2)
        out.append({"token": m.group(0), "syntax": "brace", "name": name,
                    "arg": fmt,
                    "format_known": (not fmt) or bool(_resolve_date_format(fmt))})
    return {"tokens": out, "stray": _BRACE_TOKEN_RE.sub("", remainder)}


def template_vocabulary() -> str:
    """The whole vocabulary, for a refusal message."""
    return (f"Known {{name}} tokens: {', '.join(BRACE_TOKENS + LEGACY_TOKENS)}; "
            f"${{FUNC(FMT)}} functions: {', '.join(sorted(_FUNCTIONS))}; "
            f"bare ${{FMT}} date formats: {', '.join(_BUILTIN_DATE_FORMATS)}")


class FilenameRenderer:
    """Render an enterprise filename template against a ``RenderContext``.

    Pure function wrapped in a class so future extensions (per-tenant
    function tables, audit logging of substitutions) have a stable
    seam without breaking callers.
    """

    def __init__(self):
        # Future: per-instance function override map for tenant-specific
        # custom tokens, populated from a DB-backed registry.
        self._functions = dict(_FUNCTIONS)

    def render(self, template: str, ctx: RenderContext) -> str:
        if not template:
            return ""

        # 1. ``${...}`` tokens (enterprise function syntax)
        def _dollar_sub(m: re.Match) -> str:
            head, arg = m.group(1).upper(), m.group(2)
            # Bare format code: ``${YYYYMMDD}`` → run_date in that format
            if head in _BUILTIN_DATE_FORMATS or _resolve_date_format(head):
                return _fmt_or_default(ctx.run_date, head)
            fn = self._functions.get(head)
            if fn is None:
                raise KeyError(
                    f"Unknown filename-template function: {head}.  "
                    f"Known: {sorted(self._functions.keys())}"
                )
            return fn(ctx, arg)

        out = _DOLLAR_TOKEN_RE.sub(_dollar_sub, template)

        # 2. ``{name}`` tokens (Python-style)
        def _brace_sub(m: re.Match) -> str:
            name, fmt = m.group(1), m.group(2)
            val = self._resolve_brace(name, ctx)
            if isinstance(val, _date):
                return _fmt_or_default(val, fmt)
            if fmt:
                # Format spec on a non-date value — let Python's
                # format() handle it so {run_id:05d} works as
                # expected.
                try:
                    return format(val, fmt)
                except (ValueError, TypeError):
                    return str(val)
            return str(val)

        out = _BRACE_TOKEN_RE.sub(_brace_sub, out)
        return out

    # ── Brace-token resolver — config-extensible ──────────────────────────

    def _resolve_brace(self, name: str, ctx: RenderContext):
        name_lower = name.lower()
        if name_lower in ("run_date",):
            return ctx.run_date
        if name_lower in ("business_date", "cob", "me_business_date"):
            return ctx.business_date
        if name_lower == "feed_name":
            return ctx.feed_name
        if name_lower == "feed_id":
            return ctx.feed_id
        if name_lower == "run_id":
            return ctx.run_id
        if name_lower == "cob_prev_eom":
            return _require(ctx.cob_prev_eom, "cob_prev_eom")
        if name_lower == "cob_prev_business_day":
            return _require(ctx.cob_prev_business_day, "cob_prev_business_day")
        if ctx.extras and name in ctx.extras:
            return ctx.extras[name]
        if ctx.extras and name_lower in {k.lower() for k in ctx.extras}:
            # Case-insensitive lookup
            for k, v in ctx.extras.items():
                if k.lower() == name_lower:
                    return v
        raise KeyError(
            f"Unknown filename-template variable: {{{name}}}.  "
            f"Known: run_date, business_date, me_business_date, "
            f"feed_name, feed_id, run_id, cob_prev_eom, cob_prev_business_day "
            f"+ anything in RenderContext.extras"
        )
