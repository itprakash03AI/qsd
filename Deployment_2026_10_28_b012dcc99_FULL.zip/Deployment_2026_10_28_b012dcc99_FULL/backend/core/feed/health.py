"""Feed-backend health probes — Phase 130 hotfix-13.

Two functions are exported:

  * ``probe_airflow()`` — checks the Airflow REST API and returns a
    typed ``BackendHealth`` snapshot.
  * ``probe_native_worker()`` — checks the in-process queue worker.

Both are designed for repeated cheap calls from the failover agent
(default every 30 s) AND for ad-hoc invocations from the admin
``GET /api/admin/feed-generation/health`` endpoint.

Native-worker health is driven by a heartbeat the worker updates on
every successful ``poll_once()``.  We record this in the
``FeedRunQueueWorker`` instance + mirror it to a module-level
``last_tick_at`` so the probe can read it without holding a worker
reference (avoids import cycles).

The probes never raise; on transport failure they return
``healthy=False`` with the exception text in ``detail``.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)

# One vocabulary for every three-state verdict in this product; see
# core/verdict_vocabulary.py for why it is not defined here.
from core.verdict_vocabulary import COULD_NOT_DETERMINE  # noqa: E402


# ── Native worker heartbeat ──────────────────────────────────────────
#
# Updated by the queue worker after every poll tick (success OR
# failure — failures still mean the worker is alive enough to tick).
# Module-level so probes can read without holding a worker reference.

_native_last_tick_at: Optional[float] = None
_native_last_tick_lock = threading.Lock()
_native_last_result: dict = {}


def record_native_tick(result: Optional[dict] = None) -> None:
    """Called by the queue worker after each ``poll_once()``.  Wall-
    clock time is recorded as ``time.time()`` for cross-process
    comparability if we ever persist this.  The optional ``result``
    dict (from ``QueuePollResult.to_dict()``) lets the probe surface
    the last tick's outcome."""
    global _native_last_tick_at
    with _native_last_tick_lock:
        _native_last_tick_at = time.time()
        if result is not None:
            _native_last_result.clear()
            _native_last_result.update(result)


def get_native_last_tick_at() -> Optional[float]:
    with _native_last_tick_lock:
        return _native_last_tick_at


def reset_native_heartbeat() -> None:
    """TEST SEAM (declared 2026-09-03) -- production must NOT call this.
    Test/admin helper — pretend the worker has never ticked."""
    global _native_last_tick_at
    with _native_last_tick_lock:
        _native_last_tick_at = None
        _native_last_result.clear()


# ── Probe results ────────────────────────────────────────────────────


@dataclass(frozen=True)
class BackendHealth:
    """Typed snapshot of one backend's health at a point in time."""

    backend: str           # 'airflow' | 'native'
    healthy: bool
    detail: str            # human-readable, safe to show in UI
    checked_at: str        # ISO-8601 UTC
    extras: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "backend": self.backend,
            "healthy": self.healthy,
            "detail": self.detail,
            "checked_at": self.checked_at,
            "extras": dict(self.extras),
        }


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ── Airflow probe ────────────────────────────────────────────────────


def probe_airflow(cfg=None, *, timeout_seconds: float = 5.0) -> BackendHealth:
    """Check the Airflow REST API ``/api/v1/health`` endpoint.

    Returns ``healthy=True`` when:
      * Airflow integration is enabled, AND
      * The health endpoint returns 200 with ``metadatabase.status='healthy'``
        AND ``scheduler.status='healthy'``.

    A disabled-integration case returns ``healthy=False`` with detail
    ``'integration_disabled'`` — the failover agent treats that as
    "not a viable backend" so it never tries to flip TO airflow when
    the operator hasn't configured it.
    """
    if cfg is None:
        from core.config import feed_generation as _fg
        cfg = _fg

    if not getattr(cfg, "airflow_enabled", False):
        return BackendHealth(
            backend="airflow",
            healthy=False,
            detail="integration_disabled",
            checked_at=_now_iso(),
        )

    base_url = str(getattr(cfg.airflow, "base_url", "") or "").rstrip("/")
    if not base_url:
        return BackendHealth(
            backend="airflow",
            healthy=False,
            detail="base_url_not_configured",
            checked_at=_now_iso(),
        )

    url = f"{base_url}/api/v1/health"
    try:
        from core.http_utils import http_request
        from core.feed.airflow_client import AirflowClient
        # Build auth header via the same helper the client uses, so
        # health probes honour the same credentials as live calls.
        auth_header = AirflowClient._build_auth_header(
            (str(getattr(cfg.airflow, "auth_type", "none") or "none"),
             str(getattr(cfg.airflow, "username", "") or "") or None,
             str(getattr(cfg.airflow, "password", "") or "") or None),
        )
        headers = {"Accept": "application/json"}
        if auth_header:
            headers["Authorization"] = auth_header
        resp = http_request(url, "GET", None, headers, timeout=int(timeout_seconds))
    except Exception as exc:
        return BackendHealth(
            backend="airflow",
            healthy=False,
            detail=f"transport_error: {type(exc).__name__}: {str(exc)[:200]}",
            checked_at=_now_iso(),
        )

    # Airflow returns shape: {"metadatabase": {"status": "healthy"}, "scheduler": {"status": "healthy"}}
    meta_ok = str((resp.get("metadatabase") or {}).get("status", "")).lower() == "healthy"
    sched_ok = str((resp.get("scheduler") or {}).get("status", "")).lower() == "healthy"
    healthy = bool(meta_ok and sched_ok)
    detail = "ok" if healthy else (
        f"metadatabase={(resp.get('metadatabase') or {}).get('status','?')},"
        f"scheduler={(resp.get('scheduler') or {}).get('status','?')}"
    )
    return BackendHealth(
        backend="airflow",
        healthy=healthy,
        detail=detail,
        checked_at=_now_iso(),
        extras={"raw": resp},
    )


# ── Is there a CONSUMER for pending rows? ────────────────────────────
#
# 2026-09-15.  The producer/consumer seam had no owner.  Three routes
# CREATE pending ``feed_runs`` rows -- the backfill launcher, the SOD
# generator, the external trigger -- and exactly one thing executes
# one: a queue worker.  ``feed_generation.queue_worker_enabled`` ships
# ``false``, so the default deployment produces work nothing consumes,
# and every surface reported success: 200 {"created": 20} from the
# backfill, an audit entry, and a health page calling the native
# backend ``healthy: true, detail: "queue_worker_disabled"``.
#
# THE FLAG IS NOT THE TRUTH.  ``feed_worker.py`` is a dedicated pod that
# polls unconditionally -- it never reads ``queue_worker_enabled`` --
# so a deployment can have a live consumer with the flag off.  The only
# honest answer comes from asking whether a worker has actually TICKED.
# Hence one probe, consulted by the health endpoint, the backfill route
# and the scheduler bootstrap, rather than three copies of a config
# read that would each be wrong in a different deployment.


@dataclass(frozen=True)
class ConsumerPresence:
    """Will anything execute a pending ``feed_runs`` row?

    Three states, matching the shape this product already uses for the
    same question elsewhere (``/api/feeds/backend-options``' available +
    detail, Clockwork's routable + reason, DataFlow's runnability):
    present, absent, and COULD NOT DETERMINE.  ``determined`` is False
    when the probe itself failed -- unknown is not "absent", and the two
    lead to different investigations.
    """

    present: bool
    reason: str = ""
    determined: bool = True
    source: str = ""          # config | heartbeat | none | probe_error

    def to_dict(self) -> dict:
        return {"present": bool(self.present), "reason": self.reason,
                "determined": bool(self.determined), "source": self.source}


def probe_queue_consumer(cfg=None, *, db=None) -> ConsumerPresence:
    """Answer the producer's question: if I insert a pending row, will
    anything pick it up?

    Order matters.  The CONFIGURED consumer is checked first because it
    is free and is the answer in every normal deployment; the heartbeat
    is consulted only when the flag is off, to catch the dedicated
    ``feed_worker.py`` pod that polls without the flag.  A stale
    heartbeat is NOT treated as present -- a worker that stopped ticking
    is exactly the case this is meant to catch.
    """
    if cfg is None:
        from core.config import feed_generation as _fg
        cfg = _fg

    if bool(getattr(cfg, "queue_worker_enabled", False)):
        return ConsumerPresence(True, "", True, "config")

    # Flag is off.  A deployed feed_worker.py pod still polls -- ask the
    # fleet whether one has ticked recently rather than assuming.
    stale_after = int(getattr(cfg, "native_worker_stale_after_seconds", 180))
    if db is None:
        try:
            from core.database import get_db_manager
            db = get_db_manager()
        except Exception as exc:
            return ConsumerPresence(
                False, f"{COULD_NOT_DETERMINE}: no database manager to ask "
                       f"whether a worker pod is ticking ({exc})",
                False, "probe_error")
    try:
        rows = db.list_worker_health() or []
    except Exception as exc:
        return ConsumerPresence(
            False, f"{COULD_NOT_DETERMINE}: worker_health_state could not be "
                   f"read ({type(exc).__name__}: {exc})", False, "probe_error")

    youngest = _youngest_tick_age(rows)
    if youngest is not None and youngest[0] <= stale_after:
        return ConsumerPresence(True, "", True, "heartbeat")

    detail = "no worker pod has ever ticked"
    if youngest is not None:
        detail = (f"the youngest worker tick is {youngest[0]:.0f}s old "
                  f"(> {stale_after}s) from {youngest[1]}")
    return ConsumerPresence(
        False,
        "nothing will execute a pending feed run: "
        "feed_generation.queue_worker_enabled=false and " + detail + ". "
        "Enable the queue worker, or deploy a feed_worker.py pod.",
        True, "none")


def _youngest_tick_age(rows) -> Optional[tuple]:
    """(age_seconds, pod_id) of the most recent worker tick, or None when
    no row carries a readable timestamp.  Naive timestamps are read as
    UTC -- some DAOs emit them, and letting the subtraction raise would
    silently drop every row and report 'never ticked'."""
    now_utc = datetime.now(timezone.utc)
    best = None
    for r in rows or []:
        ts_str = (r or {}).get("last_tick_at")
        if not ts_str:
            continue
        try:
            ts = datetime.fromisoformat(str(ts_str).replace("Z", "+00:00"))
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=timezone.utc)
            age = (now_utc - ts).total_seconds()
        except Exception:
            continue
        if best is None or age < best[0]:
            best = (age, r.get("pod_id"))
    return best


def pending_work_with_no_consumer(cfg=None, *, db=None) -> dict:
    """The full producer/consumer verdict, for a caller that is about to
    create work (the backfill route) or report health.

    Returns the consumer verdict plus how many rows are already waiting.
    ``stalled`` is True only when BOTH are known and bad -- an
    undetermined consumer probe never raises a false alarm, it says so.
    """
    presence = probe_queue_consumer(cfg, db=db)
    pending, exact = None, None
    if db is None:
        try:
            from core.database import get_db_manager
            db = get_db_manager()
        except Exception:
            db = None
    if db is not None:
        try:
            counted = db.count_pending_feed_runs()
            pending = int(counted.get("pending", 0))
            exact = bool(counted.get("exact", True))
        except Exception as exc:
            logger.debug("[feed_health] pending count unavailable: %s", exc)
    return {
        "consumer": presence.to_dict(),
        "pending_runs": pending,
        "pending_runs_exact": exact,
        "stalled": bool(presence.determined and not presence.present
                        and (pending or 0) > 0),
    }


# ── Native worker probe ──────────────────────────────────────────────


def _fleet_ages(fleet_rows: list) -> list:
    """``[(row, tick_age_seconds)]`` for every row with a parseable
    ``last_tick_at`` (naive timestamps read as UTC)."""
    now_utc = datetime.now(timezone.utc)
    out = []
    for r in fleet_rows:
        ts_str = r.get("last_tick_at")
        if not ts_str:
            continue
        try:
            ts = datetime.fromisoformat(str(ts_str).replace("Z", "+00:00"))
        except (TypeError, ValueError):
            continue
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        out.append((r, (now_utc - ts).total_seconds()))
    return out


def probe_native_worker(cfg=None, *, db=None) -> BackendHealth:
    """Native is healthy when AT LEAST ONE worker pod has ticked recently.

    Multi-pod mode (Phase 130 hotfix-13): the probe queries
    ``worker_health_state`` so the scheduler pod's failover agent sees
    every worker pod's heartbeat.  Single-pod mode falls back to the
    module-local heartbeat (``_native_last_tick_at``).

    Returns ``healthy=False`` when:
      * Queue worker is enabled but no pod has ticked, OR
      * Every pod's last tick is older than
        ``feed_generation.native_worker_stale_after_seconds``.

    When the queue worker is DISABLED at config level the answer depends
    on whether anything is WAITING (2026-09-15).  It used to be an
    unconditional ``healthy=True, detail='queue_worker_disabled'``, which
    is the lie this probe existed to prevent: an operator backfilled
    twenty days, got 200 {"created": 20} and an audit entry, read a
    health page that said the native backend was fine, and twenty files
    never appeared.  Now:

      * disabled, nothing pending  -> ``healthy=True``.  Unchanged, and
        still true: an estate that runs feeds through Airflow has no
        native work and is not broken.  Every deployment that is merely
        CONFIGURED this way keeps the verdict it had.
      * disabled, N rows pending   -> ``healthy=False``.  Work exists
        that nothing will execute.  This is deliberately fed to the
        failover agent: with Airflow viable it flips there and the rows
        get run, which is the right answer and was previously impossible
        because the native side always claimed to be well.

    A deployed ``feed_worker.py`` pod polls WITHOUT the flag, so the
    disabled branch asks the heartbeat before concluding anything --
    see ``probe_queue_consumer``.
    """
    if cfg is None:
        from core.config import feed_generation as _fg
        cfg = _fg

    queue_worker_enabled = bool(getattr(cfg, "queue_worker_enabled", False))
    if not queue_worker_enabled:
        consumer = probe_queue_consumer(cfg, db=db)
        if consumer.present:
            # A dedicated worker pod is ticking even though the flag is
            # off.  Fall through to the normal staleness path rather than
            # answering from config -- the fleet view is the better
            # evidence and it is already implemented below.
            queue_worker_enabled = True
        else:
            verdict = pending_work_with_no_consumer(cfg, db=db)
            pending = verdict.get("pending_runs")
            extras = {"consumer": verdict["consumer"],
                      "pending_runs": pending,
                      "pending_runs_exact": verdict.get("pending_runs_exact")}
            if verdict.get("stalled"):
                approx = "" if verdict.get("pending_runs_exact") else "+"
                return BackendHealth(
                    backend="native",
                    healthy=False,
                    detail=(f"queue_worker_disabled with {pending}{approx} "
                            f"pending run(s) that nothing will execute — "
                            f"{consumer.reason}"),
                    checked_at=_now_iso(),
                    extras=extras,
                )
            # Not stalled.  Say WHICH of the three reasons that is --
            # "nothing is pending" and "we could not find out" are not
            # the same statement, and writing the confident one when the
            # probe failed is the defect this function exists to stop,
            # one level down.
            if not consumer.determined:
                # Unknown is not "fine" and not "broken": we could not
                # read the fleet, so we cannot claim there is a consumer.
                # Reported WITHOUT flipping health, because a probe
                # failure must never trigger a backend failover.
                extras["undetermined"] = consumer.reason
                suffix = "consumer unconfirmed"
            elif pending is None:
                suffix = "pending run count unavailable"
            else:
                suffix = "nothing pending"
            return BackendHealth(
                backend="native",
                healthy=True,
                detail=f"queue_worker_disabled ({suffix})",
                checked_at=_now_iso(),
                extras=extras,
            )

    stale_after = int(getattr(cfg, "native_worker_stale_after_seconds", 180))
    now = time.time()

    # 1. Multi-pod fleet view via DB.  Health = ANY pod ticked recently.
    fleet_rows: list = []
    if db is None:
        try:
            from core.database import get_db_manager
            db = get_db_manager()
        except Exception:
            db = None
    if db is not None:
        try:
            fleet_rows = db.list_worker_health() or []
        except Exception:
            fleet_rows = []

    if fleet_rows:
        # Youngest tick across the fleet decides health (unchanged).  Some
        # DAOs (SQLite default datetime adapter) emit naive ISO strings;
        # treat naive as UTC so (now - ts) arithmetic doesn't raise
        # TypeError and silently filter out every row.
        #
        # 2026-10-07 -- ``pod_count`` counts LIVE pods (ticked within
        # ``stale_after``) and ``fleet`` lists only them.  It used to be
        # ``len(fleet_rows)``: one row per hostname:pid ever seen, so a prod
        # admin screen read ``pod_count: 231`` -- every restart since the
        # table existed.  Dead rows are now aged out by the worker itself
        # (core.feed.queue_worker.maybe_gc_worker_health) and reported here
        # as a count, not as pods.
        aged = _fleet_ages(fleet_rows)
        live = [r for r, a in aged if a <= stale_after]
        youngest_age, youngest_pod = None, None
        if aged:
            youngest_row, youngest_age = min(aged, key=lambda x: x[1])
            youngest_pod = youngest_row.get("pod_id")
        fleet_counts = {
            "pod_count": len(live),
            "stale_pod_rows": len(fleet_rows) - len(live),
            "pod_rows_recorded": len(fleet_rows),
        }
        if youngest_age is not None and youngest_age <= stale_after:
            return BackendHealth(
                backend="native",
                healthy=True,
                detail=f"fleet has recent tick ({youngest_age:.0f}s ago from {youngest_pod})",
                checked_at=_now_iso(),
                extras={
                    "youngest_tick_age_seconds": round(youngest_age, 1),
                    "youngest_pod": youngest_pod,
                    "stale_after_seconds": stale_after,
                    **fleet_counts,
                    "fleet": live,
                },
            )
        if youngest_age is not None:
            # Fleet rows exist but all are stale
            return BackendHealth(
                backend="native",
                healthy=False,
                detail=(f"fleet stale (youngest tick {youngest_age:.0f}s ago > "
                        f"threshold {stale_after}s, {len(fleet_rows)} pod "
                        f"row(s), none live)"),
                checked_at=_now_iso(),
                extras={
                    "youngest_tick_age_seconds": round(youngest_age, 1),
                    "youngest_pod": youngest_pod,
                    "stale_after_seconds": stale_after,
                    **fleet_counts,
                    "fleet": [],
                },
            )

    # 2. Fallback to in-process heartbeat (single-pod or DB unavailable).
    last_tick = get_native_last_tick_at()
    if last_tick is None:
        return BackendHealth(
            backend="native",
            healthy=False,
            detail="never_ticked",
            checked_at=_now_iso(),
            extras={"last_tick_at": None, "stale_after_seconds": stale_after,
                    "pod_count": 0},
        )

    age = now - last_tick
    if age > stale_after:
        return BackendHealth(
            backend="native",
            healthy=False,
            detail=f"stale (last tick {age:.0f}s ago > threshold {stale_after}s)",
            checked_at=_now_iso(),
            extras={
                "last_tick_age_seconds": round(age, 1),
                "stale_after_seconds": stale_after,
                "last_tick_at": datetime.fromtimestamp(last_tick, tz=timezone.utc).isoformat(),
            },
        )

    return BackendHealth(
        backend="native",
        healthy=True,
        detail=f"recent tick ({age:.0f}s ago)",
        checked_at=_now_iso(),
        extras={
            "last_tick_age_seconds": round(age, 1),
            "last_tick_at": datetime.fromtimestamp(last_tick, tz=timezone.utc).isoformat(),
            "last_tick_result": dict(_native_last_result),
        },
    )


def probe_all(cfg=None) -> dict:
    """Run both probes and return a combined snapshot for the admin
    health endpoint / failover agent."""
    return {
        "checked_at": _now_iso(),
        "airflow": probe_airflow(cfg).to_dict(),
        "native": probe_native_worker(cfg).to_dict(),
    }
