"""
Foundation C — per-connection concurrency claims + fair share
(BRD 2026-09-02, §4.2 FR-RUN-06..08, §13.5 FR-OPS-10..12).

The concurrency budget lives in the DATABASE, not in a worker process:
today's cap is ``max_concurrent`` on the queue worker — a per-process
number, so three replicas allow three times the intended concurrency and
nothing in the system knows.  ``connection_claims`` holds who has a slot
right now; ``connection_concurrency_budgets`` holds the allowance.

The rule that matters most (FR-RUN-07): a worker may claim a run only if
EVERY connection in that run's connection set has a free slot — a feed's
effective concurrency is the MINIMUM free budget across every source it
touches.  A feed reading Starburst and writing S3 cannot go faster than
Starburst allows, and expressing that as one global number would flatten
the warehouse.  Acquisition is ALL-OR-NOTHING: acquiring 2 of 3
connections and proceeding is worse than waiting (the transactional
mechanics live in ``mixin_feeds.try_acquire_connection_claims``; this
module owns the POLICY).

Fair share (§13.5):
* PRIORITY DIRECTION — see the block above ``importance_key``: this
  module is the ONE place the direction (1 = highest, the OG-ETL
  convention) is declared; everything else derives from it.
* FR-OPS-10 — priority is honoured AT CLAIM TIME, not only at insert:
  :func:`order_candidates` sorts pending work by aged effective
  priority every scheduling pass.
* FR-OPS-11 — ``reserved_critical_slots`` on a budget are invisible to
  non-critical claims, so the highest-priority work always has a slot.
* FR-OPS-12 — anti-starvation: :func:`effective_priority` lifts a
  waiting run one priority level per aging period, capped one level
  BELOW the critical ceiling — so a low-priority feed eventually
  competes with everything except the reservation.  It can wait; it
  cannot wait forever; and it can never consume the slot FR-OPS-11
  exists to guarantee.

  Corrected 2026-09-02.  This capped AT the ceiling, so an aged run
  became `is_critical` and took a reserved slot — which voids the
  reservation entirely: enough aged low-priority work can starve the
  critical work the reservation was set aside for, the exact outcome
  both requirements exist to prevent.  The BRD said "capped below ...
  can never let it take a reserved critical slot"; the code and its
  test pinned the opposite.  The spec was right.

Error posture: db errors PROPAGATE.  A claim ledger that cannot be read
must not silently mean "go" (unbounded concurrency — flattens the
warehouse) nor silently mean "stop" (an invisible outage); the caller
decides, seeing the truth.  Denials are logged at INFO — the system must
log what it DECLINED to do, not only what it did.

Deliberately no imports from feed_engine / queue_worker / pipeline —
those workstreams call INTO this module, never the reverse.  The ``dao``
seam is any object exposing the FeedsMixin connection-claim methods.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════════════════
#  PRIORITY DIRECTION — the ONE declaration (FR-OPS-10/12, 2026-09-02).
#
#  QueryStudio uses the OG-ETL convention the column has documented since
#  Phase 130 (core/db/models.py FeedConfig.priority): **1 = HIGHEST
#  priority, 9 = lowest**.  That is what the operator's authors type.
#  Until 2026-09-02 the runtime did the exact opposite (ORDER BY priority
#  DESC, critical >= 8) — priority=1 was served LAST.  The column comment
#  was right; the runtime was wrong; the runtime moved.
#
#  Every comparison, sort, lift and SQL ORDER BY in the codebase derives
#  from the primitives in this block — flipping the direction again is a
#  one-line change HERE, never a hunt for comparison operators.
#
#  MIGRATION DECISION (explicit, 2026-09-02): stored values are
#  REINTERPRETED, never rewritten.  A feed explicitly saved at 8 or 9
#  was authored against the documented "lower = higher" convention, so
#  8/9 always MEANT "least important" — under the fix it is finally
#  SERVED that way, and it is no longer critical.  A feed at 1 or 2 is
#  now served first and IS critical (may use reserved slots).  The
#  default 5 is the same mid-range value in both readings.
#  core/database.py logs the affected-row counts at migration time.
# ═══════════════════════════════════════════════════════════════════════

#: The single direction switch.  True = the OG-ETL convention (1 wins).
PRIORITY_LOWER_IS_MORE_IMPORTANT = True

#: The authorable range (the API accepts 1-9; see validate_priority).
PRIORITY_HIGHEST = 1
PRIORITY_LOWEST = 9

#: The row default — mid-range in either direction.
DEFAULT_PRIORITY = 5

#: Claims at or MORE IMPORTANT than this are CRITICAL (FR-OPS-11) and
#: may use a budget's reserved slots.  Under 1-is-highest that means
#: priority <= 2 (the mirror of the old ">= 8").
DEFAULT_CRITICAL_PRIORITY_CEILING = 2

#: FR-OPS-12 — every full period spent waiting lifts the effective
#: priority one level toward PRIORITY_HIGHEST (capped one level short
#: of critical — see effective_priority).
DEFAULT_AGING_SECONDS = 900

#: FR-OPS-06..09 — a backfill is a SEPARATE CONCURRENCY CLASS expressed
#: in this module's own vocabulary: it enters at the LEAST important
#: priority, so tonight's scheduled work (default 5) always outranks it,
#: and clamp_never_critical() guarantees no backfill — whatever an
#: operator types — can ever take a reserved critical slot.
DEFAULT_BACKFILL_PRIORITY = PRIORITY_LOWEST


def importance_key(priority: int) -> int:
    """Sort key under which MORE IMPORTANT sorts FIRST (ascending).
    The only place the direction switch is consulted for comparisons."""
    p = int(priority)
    return p if PRIORITY_LOWER_IS_MORE_IMPORTANT else -p


def is_more_important(a: int, b: int) -> bool:
    """True when priority ``a`` outranks priority ``b``."""
    return importance_key(a) < importance_key(b)


def one_level_less_important(priority: int) -> int:
    return (int(priority) + 1 if PRIORITY_LOWER_IS_MORE_IMPORTANT
            else int(priority) - 1)


def _lift(priority: int, levels: int) -> int:
    """Move ``priority`` toward PRIORITY_HIGHEST by ``levels``."""
    return (int(priority) - int(levels) if PRIORITY_LOWER_IS_MORE_IMPORTANT
            else int(priority) + int(levels))


def priority_order_clause(column):
    """The SQL ORDER BY term for "most important first".  Every query
    that orders feed work by priority uses THIS, so the direction lives
    here and nowhere else.  NULL rows compete at the row default (5) on
    every engine (SQLite puts NULLs first on ASC, Postgres last — a
    coalesce removes the disagreement)."""
    from sqlalchemy import func
    col = func.coalesce(column, DEFAULT_PRIORITY)
    return col.asc() if PRIORITY_LOWER_IS_MORE_IMPORTANT else col.desc()


def validate_priority(value, *, where: str = "priority") -> int:
    """Authoring-time validation (FR-OPS-10): 1..9, and the DIRECTION is
    stated in the refusal so an author who assumed higher-wins learns
    the convention at the moment they typed the value.  Raises
    ValueError — HTTP surfaces map it to 422."""
    try:
        p = int(value)
    except (TypeError, ValueError):
        raise ValueError(
            f"{where} must be an integer 1-9 (1 = HIGHEST priority, "
            f"9 = lowest; the OG-ETL convention), got {value!r}")
    if not (PRIORITY_HIGHEST <= p <= PRIORITY_LOWEST):
        raise ValueError(
            f"{where} must be between 1 and 9 — 1 is the HIGHEST priority "
            f"and {DEFAULT_CRITICAL_PRIORITY_CEILING} or better is "
            f"critical; 9 is the lowest.  Got {p}.  (If you meant 'most "
            f"important', that is 1, not a big number.)")
    return p


def priority_direction_warning(priority: int) -> str | None:
    """A non-refusing authoring nudge for reversed-looking values: 8/9
    read as 'most important' to someone assuming higher-wins, but they
    are the LOWEST tier here.  Returns None when nothing needs saying."""
    try:
        p = int(priority)
    except (TypeError, ValueError):
        return None
    if p >= 8:
        return (f"priority {p} is one of the LOWEST priorities: this "
                f"system uses the OG-ETL convention where 1 = highest.  "
                f"If this feed is critical, set priority 1 or 2.")
    return None


def clamp_never_critical(priority) -> int:
    """The strongest priority a NON-CRITICAL class of work (a backfill)
    may hold: one level short of the critical threshold, so it can never
    consume a reserved slot no matter what was typed.  Garbage falls to
    the backfill default (least important) — a nonsense value must never
    GRANT importance."""
    try:
        p = int(priority)
    except (TypeError, ValueError):
        return DEFAULT_BACKFILL_PRIORITY
    floor = one_level_less_important(DEFAULT_CRITICAL_PRIORITY_CEILING)
    return floor if is_more_important(p, floor) else p


@dataclass(frozen=True)
class ClaimDecision:
    """The outcome of one acquisition attempt — values, not a boolean:
    the deny path names WHICH connection blocked and what was free."""

    granted: bool
    run_id: int
    run_kind: str
    pod_id: str
    connection_ids: tuple[int, ...]
    critical: bool
    effective_priority: int
    #: connection_id -> free slots BEFORE this acquisition; None = no
    #: declared budget (unbounded).  Empty on the already_held refusal.
    free_slots: dict[int, int | None]
    blocking_connection_ids: tuple[int, ...]
    reason: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "granted": self.granted,
            "run_id": self.run_id,
            "run_kind": self.run_kind,
            "pod_id": self.pod_id,
            "connection_ids": list(self.connection_ids),
            "critical": self.critical,
            "effective_priority": self.effective_priority,
            "free_slots": {str(k): v for k, v in self.free_slots.items()},
            "blocking_connection_ids": list(self.blocking_connection_ids),
            "reason": self.reason,
        }


def effective_priority(priority: int | None, *,
                       waiting_since: datetime | None = None,
                       now: datetime | None = None,
                       aging_seconds: int = DEFAULT_AGING_SECONDS,
                       ceiling: int = DEFAULT_CRITICAL_PRIORITY_CEILING,
                       ) -> int:
    """FR-OPS-12 — the priority a run competes at RIGHT NOW.

    Every full ``aging_seconds`` waited lifts the run ONE level toward
    PRIORITY_HIGHEST, capped ONE LEVEL SHORT of the critical threshold
    (``ceiling``): ageing un-starves a run but must never make it
    CRITICAL, because a critical claim may take a reserved slot and the
    reservation is what guarantees critical work can always run.

    Aging never makes a run LESS important, and a run already critical
    keeps its own priority untouched (a genuinely critical feed stays
    critical — only the LIFT is bounded).  A missing/garbage ``priority``
    falls back to the row default (5); so does a value MORE important
    than PRIORITY_HIGHEST (a nonsense 0 or -3 must never smuggle in
    criticality).  A non-positive ``aging_seconds`` disables aging (it
    must never divide by zero or mean "age infinitely fast").
    """
    try:
        base = int(priority) if priority is not None else DEFAULT_PRIORITY
    except (TypeError, ValueError):
        base = DEFAULT_PRIORITY
    if is_more_important(base, PRIORITY_HIGHEST):
        # Out of range on the IMPORTANT side — refuse the smuggle.
        base = DEFAULT_PRIORITY
    if is_critical(base, ceiling=ceiling) or waiting_since is None:
        return base
    if not aging_seconds or aging_seconds <= 0:
        return base
    ref = now or datetime.now(timezone.utc)
    ws = waiting_since
    # Naive timestamps (DB rows store naive UTC) compare against naive.
    if ws.tzinfo is None and ref.tzinfo is not None:
        ref = ref.replace(tzinfo=None)
    elif ws.tzinfo is not None and ref.tzinfo is None:
        ws = ws.replace(tzinfo=None)
    waited = (ref - ws).total_seconds()
    if waited <= 0:
        return base
    lifted = _lift(base, int(waited // int(aging_seconds)))
    # One level short of critical: see the module docstring.  An aged
    # run competes with critical work for GENERAL slots and never for
    # the reservation.
    floor = one_level_less_important(ceiling)
    return floor if is_more_important(lifted, floor) else lifted


def is_critical(priority: int, *,
                ceiling: int = DEFAULT_CRITICAL_PRIORITY_CEILING) -> bool:
    """FR-OPS-11 — critical work may use the reserved slots.  Critical
    is "at or more important than the threshold": priority <= 2 under
    the 1-is-highest direction."""
    return importance_key(priority) <= importance_key(ceiling)


def _parse_when(value: Any) -> datetime | None:
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    try:
        return datetime.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None


def order_candidates(candidates: list[dict[str, Any]], *,
                     now: datetime | None = None,
                     aging_seconds: int = DEFAULT_AGING_SECONDS,
                     ceiling: int = DEFAULT_CRITICAL_PRIORITY_CEILING,
                     ) -> list[dict[str, Any]]:
    """FR-OPS-10 — the claim-time ordering of pending work.

    Sorted by AGED effective priority (most important first — the
    direction comes from importance_key, nowhere else), then FIFO on
    created_at (asc), then id — so priority is honoured when slots are
    HANDED OUT,
    not only when rows were inserted, and a long-waiting low-priority
    run climbs past fresher, nominally-higher work (FR-OPS-12).
    Input rows are untouched; the returned list is a new ordering.
    """
    ref = now or datetime.now(timezone.utc)

    def _key(row: dict[str, Any]):
        created = _parse_when(row.get("created_at"))
        eff = effective_priority(
            row.get("priority"), waiting_since=created, now=ref,
            aging_seconds=aging_seconds, ceiling=ceiling)
        created_sort = created or ref
        if created_sort.tzinfo is not None:
            created_sort = created_sort.replace(tzinfo=None)
        return (importance_key(eff), created_sort, row.get("id") or 0)

    return sorted(candidates, key=_key)


def acquire(dao, *, run_id: int, connection_ids: list[int], pod_id: str,
            priority: int | None = None,
            waiting_since: datetime | str | None = None,
            run_kind: str = "feed_run",
            feed_config_id: int | None = None,
            now: datetime | None = None,
            aging_seconds: int = DEFAULT_AGING_SECONDS,
            critical_ceiling: int = DEFAULT_CRITICAL_PRIORITY_CEILING,
            ) -> ClaimDecision:
    """Acquire one slot on EVERY connection in the set, or none at all
    (FR-RUN-07).

    ``waiting_since`` (typically the run row's created_at) drives the
    anti-starvation lift; the resulting effective priority decides
    whether the claim is CRITICAL and may use reserved slots.  The
    all-or-nothing transaction lives in the dao
    (``try_acquire_connection_claims``); db errors propagate.
    """
    # 2026-09-14 -- ``waiting_since`` arrives as whatever the DAO hands
    # out: the queue worker passes ``row.get("created_at")``, which on the
    # live PostgreSQL deployment is an ISO STRING (``to_dict``), and
    # ``effective_priority`` died on ``ws.tzinfo``.  The worker's
    # fail-open handler then admitted EVERY run unbudgeted, so the
    # per-source concurrency cap this module exists to enforce was
    # enforced for nobody.  ``order_candidates`` already parsed the same
    # field through ``_parse_when``; the same parser, here, so the two
    # entry points cannot read one row differently.
    eff = effective_priority(priority, waiting_since=_parse_when(waiting_since),
                             now=now, aging_seconds=aging_seconds,
                             ceiling=critical_ceiling)
    crit = is_critical(eff, ceiling=critical_ceiling)
    res = dao.try_acquire_connection_claims(
        run_id=int(run_id),
        connection_ids=list(connection_ids or []),
        pod_id=pod_id,
        run_kind=run_kind,
        critical=crit,
        priority=eff,
        feed_config_id=feed_config_id,
    )
    decision = ClaimDecision(
        granted=bool(res.get("granted")),
        run_id=int(run_id),
        run_kind=run_kind,
        pod_id=pod_id,
        connection_ids=tuple(sorted({int(c) for c in (connection_ids or [])})),
        critical=crit,
        effective_priority=eff,
        free_slots=dict(res.get("free_slots") or {}),
        blocking_connection_ids=tuple(res.get("blocking_connection_ids")
                                      or ()),
        reason=str(res.get("reason") or ""),
    )
    if decision.granted:
        logger.info(
            "[claims] granted %s %s to pod %s on connection(s) %s "
            "(effective priority %d%s)",
            run_kind, run_id, pod_id, list(decision.connection_ids), eff,
            ", critical" if crit else "")
    else:
        # Log the DECLINE — a system that logs only what it did leaves
        # "why is my feed waiting?" unanswerable.
        logger.info(
            "[claims] denied %s %s to pod %s: %s (blocking connection(s) "
            "%s, free_slots %s, effective priority %d%s)",
            run_kind, run_id, pod_id, decision.reason,
            list(decision.blocking_connection_ids),
            decision.free_slots, eff, ", critical" if crit else "")
    return decision


def release(dao, *, run_id: int, run_kind: str = "feed_run",
            pod_id: str | None = None) -> int:
    """Free every slot the run holds.  Returns slots released."""
    count = dao.release_connection_claims(run_id=int(run_id),
                                          run_kind=run_kind, pod_id=pod_id)
    if count:
        logger.info("[claims] released %d slot(s) for %s %s",
                    count, run_kind, run_id)
    return int(count or 0)


def heartbeat(dao, *, run_id: int, pod_id: str,
              run_kind: str = "feed_run") -> bool:
    """Beat on the run's claims.  False = the claims are GONE (reaped or
    released) — the caller no longer holds the slots and must stop, not
    keep executing against a budget someone else now counts on."""
    count = dao.heartbeat_connection_claims(run_id=int(run_id),
                                            pod_id=pod_id,
                                            run_kind=run_kind)
    if not count:
        logger.warning(
            "[claims] heartbeat for %s %s found NO claims held by pod %s "
            "— the slots were reclaimed; the caller must stop",
            run_kind, run_id, pod_id)
    return int(count or 0) > 0


def reap_stale_claims(dao, heartbeat_timeout_seconds: int) -> int:
    """FR-RUN-08 — reclaim slots held by pods that stopped beating, on
    the same heartbeat-keyed pattern as the run reaper (a dead pod
    holding four slots must not starve the source until someone
    notices).  Returns slots freed; a non-positive timeout reaps
    NOTHING (zero must never mean 'reap all')."""
    count = dao.reap_stale_connection_claims(int(heartbeat_timeout_seconds)
                                             if heartbeat_timeout_seconds
                                             else 0)
    if count:
        logger.warning(
            "[claims] reaped %d stale connection claim(s) (no heartbeat "
            "for >%ss — holding pod presumed dead); those slots are free "
            "again", count, heartbeat_timeout_seconds)
    return int(count or 0)
