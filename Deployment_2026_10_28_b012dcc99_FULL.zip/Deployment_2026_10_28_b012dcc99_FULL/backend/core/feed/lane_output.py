"""THE output rules of a feed FILE -- one copy of each decision, every lane.

docs/FEED_LANE_CONTRACT_2026_10_07.html, decisions K1 and K4.

A feed runs on the native engine (DuckDB / pandas in the API or worker
pod) or in a detached Spark job (``spark/jobs/generic_feed.py``, on
``spark_k8s`` or behind Airflow), chosen by SIZE.  Until 2026-10-07 the
job wrote its files with Spark's own writers, so the bytes a counterparty
received depended on how many rows the feed had that day: booleans
``true`` vs ``True``, timestamps ``2026-10-06T09:30:00.000Z`` vs
``2026-10-06 09:30:00``, a quote escaped ``\\"`` vs doubled ``""``, a NULL
string ``""`` vs empty, a part DIRECTORY instead of one named file, an
int32 / decimal(18,2) parquet column instead of int64 / decimal(38,2).
Every one of those is a DECISION, and every one was made twice.

So the decisions live HERE, and BOTH lanes call this module:

* the native renderers (``core/feed/renderers.py``) write CSV and JSON
  lines through :class:`CsvRowWriter` and :func:`json_line`, and recount
  through :func:`csv_physical_rows` / :func:`lines_physical_rows`;
* the Spark job imports ``spark/jobs/qs_lane_output.py`` -- a
  BYTE-IDENTICAL copy of this file (the job runs in its own image and
  cannot import ``backend/core``; ``tests/test_lane_mirrors_2026_10_07.py``
  fails the build the moment the two differ) -- and renders the same
  file on the Spark DRIVER from ``toLocalIterator()`` rows, and casts
  its JDBC result to the same file schema with :func:`spark_output_casts`.

What is decided here:

* CELL TEXT (K1): what a value looks like in a CSV field -- :func:`csv_cell`.
  The native lane's existing answer is the contract (it is what every
  counterparty already parses): ``True``/``False``; ``str()`` of a date /
  datetime / Decimal / int; ``repr`` of a float; a TIME as
  ``HH:MM:SS[.ffffff]``; NULL, NaN and +/-Infinity as the dialect's NULL
  marker.
* THE CSV DIALECT APPLIED: :class:`CsvRowWriter` takes the dialect as
  NAMES (``csv_dialect.resolve`` on the backend; the execution contract's
  ``csv`` block in the job) and applies all of it, including the terms
  Spark's own writer could never express (QUOTE_NONNUMERIC / QUOTE_NONE,
  a trailing delimiter).
* JSON LINES: :func:`json_line` -- the scalar rules of
  ``core.json_utils.sanitize_for_json`` (NaN/Inf -> null, dates ISO,
  Decimal as a number up to 15 significant digits, bytes as hex) and
  ``\\n`` after every object on every OS.
* THE FILE SCHEMA OF A SQL RESULT (K1, B2/B6): the native lane writes a
  SQL connector's result from Python values -- integers int64, decimals
  decimal(38, s), floats float64, timestamps microsecond and naive.  Spark
  reads the same result through JDBC metadata (int32, decimal(18, 2),
  float32, zoned timestamps).  :func:`spark_output_casts` is the cast list
  that puts the Spark result in the native shape.
* TIME (K4, B1/A3): a SQL TIME is carried into a FILE as text
  ``HH:MM:SS[.ffffff]`` on every lane (:func:`time_text`; Spark's JDBC
  reader would otherwise turn it into a 1970-01-01 timestamp, so the job
  converts it with :func:`time_text_sql` before anything is written), and
  REFUSED only for an Oracle destination (Oracle has no TIME type) --
  :func:`time_refused_for`.
* WHAT THE JOB RENDERS ITSELF (K1/K5): :func:`job_renders` -- CSV and JSON
  lines on the driver for SFTP / S3 destinations, PARQUET through Spark's
  writer for an S3 destination.  Anything else is rendered and delivered
  by QueryStudio from the job's artifacts (the webhook-side path), and
  Excel never reaches a Spark lane at all (K2: a routing floor).

This module imports nothing but the standard library -- the job image has
no pandas, no pyarrow and no backend.
"""
from __future__ import annotations

import csv
import datetime as _dt
import decimal as _decimal
import json
import math
import re
from typing import Any, Iterable, List, Mapping, Optional, Sequence, Tuple

#: The pair the mirror guard byte-compares.
MIRROR_PATHS = (
    "backend/core/feed/lane_output.py",
    "spark/jobs/qs_lane_output.py",
)

#: Bumped when the rules here change in a way an older job image would
#: render differently.  The job stamps it into its completion report.
LANE_OUTPUT_VERSION = 1


# ── K4: missing values, TIME ──────────────────────────────────────────

def is_missing(v: Any) -> bool:
    """One answer to "is this cell NULL?", for every spelling either lane
    produces: None, NaN and +/-Infinity (floats -- a counterparty's parser
    rejects the literal ``nan`` / ``inf``), pandas' NaT and NA (detected
    by class name: this module cannot import pandas)."""
    if v is None:
        return True
    if isinstance(v, float):
        return math.isnan(v) or math.isinf(v)
    return type(v).__name__ in ("NaTType", "NAType")


def time_text(v: Any) -> Optional[str]:
    """A SQL TIME as file text: ``HH:MM:SS``, plus ``.ffffff`` only when
    there are microseconds -- ``datetime.time.isoformat()``.  A
    ``datetime`` is what Spark's JDBC reader made of a TIME (a timestamp on
    1970-01-01); its time of day is the value."""
    if v is None:
        return None
    if isinstance(v, _dt.datetime):
        v = v.time()
    return v.isoformat()


def time_text_sql(column: str) -> str:
    """The same text in Spark SQL, for a TIME column Spark's reader turned
    into a 1970-01-01 timestamp: the time of day, ``.SSSSSS`` only when
    the microseconds are not zero.  NULL stays NULL."""
    c = f"`{column}`"
    return (f"CASE WHEN date_format({c}, 'SSSSSS') = '000000' "
            f"THEN date_format({c}, 'HH:mm:ss') "
            f"ELSE date_format({c}, 'HH:mm:ss.SSSSSS') END AS {c}")


#: The destinations that cannot carry a TIME at all.
TIME_REFUSED_DESTINATIONS = ("oracle",)


def time_refused_for(destination_type: Optional[str]) -> bool:
    """Is a SQL TIME column refused for this destination?  Only Oracle,
    which has no TIME type; every file destination carries it as text."""
    return str(destination_type or "").strip().lower() in \
        TIME_REFUSED_DESTINATIONS


# ── the file schema of a SQL result ────────────────────────────────────

_SPARK_INTEGERS = ("tinyint", "smallint", "int", "integer", "bigint")
_DECIMAL = re.compile(r"^decimal\((\d+),\s*(\d+)\)$")
#: Decimal precision is a declared CEILING; widening it changes no value.
DECIMAL_FILE_PRECISION = 38


def spark_output_casts(dtypes: Sequence[Tuple[str, str]],
                       time_columns: Sequence[str] = ()) -> Optional[List[str]]:
    """``selectExpr`` expressions that put a Spark JDBC result in the file
    schema the native lane writes for the same SQL result, or None when
    nothing differs.

    integers -> bigint (native: int64); float -> double; decimal(p, s) ->
    decimal(38, s) (native widens every decimal to 38 and keeps the
    scale); timestamp -> timestamp_ntz (native: naive microseconds -- a
    zoned Spark timestamp writes a UTC-adjusted parquet column and renders
    with an offset); a TIME column -> its text (:func:`time_text_sql`).

    Its caller is the
    Spark job image (``spark/jobs/generic_feed.py::_read_jdbc``), a
    separate deployable that imports this file's byte-identical mirror and
    is counted by the callerless sweeps (mirror_job_callers); the native lane has no
    DataFrame to cast (its file schema IS the SQL result's, through
    ``core/connector_to_parquet.py``).  The B1 / B2 / B6 cases of
    tests/test_lane_conformance_output_2026_10_07.py drive that real call
    site against a model of Spark and compare the parquet schema with the
    native lane's.
    """
    times = {str(c) for c in time_columns}
    exprs: List[str] = []
    changed = False
    for name, dtype in dtypes:
        t = str(dtype).strip().lower()
        col = f"`{name}`"
        if name in times:
            exprs.append(time_text_sql(name))
            changed = True
        elif t in _SPARK_INTEGERS and t != "bigint":
            exprs.append(f"CAST({col} AS BIGINT) AS {col}")
            changed = True
        elif t == "float":
            exprs.append(f"CAST({col} AS DOUBLE) AS {col}")
            changed = True
        elif _DECIMAL.match(t) and int(_DECIMAL.match(t).group(1)) \
                < DECIMAL_FILE_PRECISION:
            scale = int(_DECIMAL.match(t).group(2))
            exprs.append(f"CAST({col} AS DECIMAL({DECIMAL_FILE_PRECISION},"
                         f"{scale})) AS {col}")
            changed = True
        elif t == "timestamp":
            exprs.append(f"CAST({col} AS TIMESTAMP_NTZ) AS {col}")
            changed = True
        else:
            exprs.append(col)
    return exprs if changed else None


# ── who renders what ───────────────────────────────────────────────────

#: (output_format, destination_type) pairs the Spark job renders and
#: delivers ITSELF.  CSV / JSON lines are rendered on the driver with the
#: writer below; PARQUET is written by Spark's own parquet writer (the job
#: image has no pyarrow), which needs a store Spark can write to -- S3.
#: Every other pair is rendered by QueryStudio from the job's artifacts
#: (the webhook-side delivery), through the native renderers.
_JOB_RENDERS = {
    ("csv", "sftp"), ("csv", "s3"),
    ("json", "sftp"), ("json", "s3"),
    ("parquet", "s3"),
}


def job_renders(output_format: Optional[str],
                destination_type: Optional[str]) -> bool:
    """Can the Spark job render this format for this destination and
    deliver it itself, with every rule in this module applied?"""
    return (str(output_format or "csv").strip().lower(),
            str(destination_type or "").strip().lower()) in _JOB_RENDERS


# ── CSV ────────────────────────────────────────────────────────────────

_TERMINATORS = {"crlf": "\r\n", "lf": "\n", "cr": "\r"}
_QUOTING = {"minimal": csv.QUOTE_MINIMAL, "all": csv.QUOTE_ALL,
            "nonnumeric": csv.QUOTE_NONNUMERIC, "none": csv.QUOTE_NONE}


def csv_cell(v: Any, na_rep: str = "",
             empty_string_marker: Optional[str] = None) -> Any:
    """What one value becomes in a CSV field.

    Returns a value of a PLAIN Python type the csv module renders the
    agreed way -- ``bool`` (written ``True`` / ``False``), ``int``,
    ``float`` (``repr``), ``Decimal`` (``str``) or ``str`` -- because the
    csv module decides QUOTE_NONNUMERIC by the value's TYPE (a number is
    left unquoted), so a number turned into text here would change the
    quoting of every numeric field under that dialect.  numpy scalars
    (the native lane reads through pandas) become the plain type; the
    Spark driver's values already are."""
    if is_missing(v):
        return na_rep
    if isinstance(v, str):
        if v == "" and empty_string_marker is not None:
            return empty_string_marker
        return v
    kind = type(v).__name__
    if isinstance(v, bool) or kind in ("bool_", "bool8"):
        return bool(v)
    if isinstance(v, _dt.time):
        return time_text(v)
    if isinstance(v, (_dt.datetime, _dt.date)):
        return str(v)
    if isinstance(v, _decimal.Decimal):
        return v
    if isinstance(v, float) or kind.startswith("float"):
        return float(v)
    if isinstance(v, int) or kind.startswith(("int", "uint")):
        return int(v)
    if isinstance(v, (bytes, bytearray, memoryview)):
        return str(bytes(v))
    return str(v)


class CsvRowWriter:
    """THE CSV writer, both lanes.  ``dialect`` is the dialect by NAME --
    the keys ``core.feed.csv_dialect.resolve`` returns and the execution
    contract's ``csv`` block carries: delimiter, header, na_rep,
    line_terminator, quoting, quotechar, escapechar, empty_string_marker,
    trailing_delimiter.  ``fh`` is a text file opened with
    :func:`open_csv` (``newline=""`` and the dialect's encoding)."""

    def __init__(self, fh, dialect: Mapping[str, Any]):
        d = dict(dialect or {})
        self._na = "" if d.get("na_rep") is None else str(d.get("na_rep"))
        self._empty = d.get("empty_string_marker")
        self._trailing = bool(d.get("trailing_delimiter"))
        self._header = bool(d.get("header", True))
        quoting = str(d.get("quoting") or "minimal").strip().lower()
        terminator = str(d.get("line_terminator") or "crlf").strip().lower()
        escapechar = d.get("escapechar")
        self._writer = csv.writer(
            fh, delimiter=str(d.get("delimiter") or ","),
            lineterminator=_TERMINATORS[terminator],
            quoting=_QUOTING[quoting],
            quotechar=(str(d.get("quotechar") or '"')[:1] or '"'),
            escapechar=(str(escapechar)[:1] if escapechar else None))
        self.rows_written = 0

    def header(self, columns: Sequence[Any]) -> None:
        if self._header:
            self._writer.writerow(self._pad([str(c) for c in columns]))

    def row(self, values: Iterable[Any]) -> None:
        self._writer.writerow(self._pad(
            [csv_cell(v, self._na, self._empty) for v in values]))
        self.rows_written += 1

    def _pad(self, cells: List[Any]) -> List[Any]:
        # A trailing delimiter is one EMPTY FIELD at the end of the row --
        # written through the writer so a last value containing the
        # delimiter is still quoted.
        return [*cells, ""] if self._trailing else cells


# ── rendering in PARTS, in parallel (2026-10-13) ──────────────────────
#
# The owner: "40 million in 2 h 51 min ... 2 hours won't be accepted".  The
# time was the CSV text of 18.4 billion cells written by ONE process.  A
# large feed renders in PARTS -- each Spark executor its own partition --
# with THIS writer, so the bytes are the ones a single process writes: the
# parts, in order, ARE the file.

#: the encodings a part can be written in and joined byte-for-byte (a
#: UTF-8 BOM is written once, by the first part)
STREAMABLE_ENCODINGS = ("utf-8", "utf8", "utf-8-sig")


def streamable_reason(dialect: Mapping[str, Any]) -> Optional[str]:
    """None when this dialect's file can be rendered as ordered parts and
    joined byte-for-byte through a line-oriented part writer (each block
    handed over without its final ``\\n``, which the writer adds back);
    else why not -- that file is rendered in ONE process instead."""
    d = dict(dialect or {})
    term = str(d.get("line_terminator") or "crlf").strip().lower()
    if not _TERMINATORS.get(term, "").endswith("\n"):
        return f"line terminator {term!r} does not end in a newline"
    enc = str(d.get("encoding") or "utf-8").strip().lower()
    if enc not in STREAMABLE_ENCODINGS:
        return f"encoding {enc!r} is not UTF-8"
    return None


def render_block(rows: Iterable[Sequence[Any]], dialect: Mapping[str, Any],
                 header: Optional[Sequence[Any]] = None, bom: bool = False) -> Tuple[str, int]:
    """``(text, rows)``: ``rows`` (and ``header`` first, when given) as CSV
    text through :class:`CsvRowWriter` -- the SAME bytes a single process
    writes for them.  ``bom``: a UTF-8 BOM first (the file's first part of a
    ``utf-8-sig`` dialect)."""
    import io
    buf = io.StringIO(newline="")
    w = CsvRowWriter(buf, dialect)
    if header is not None:
        w.header(header)
    for r in rows:
        w.row(r)
    text = buf.getvalue()
    return (("\ufeff" + text) if bom else text), w.rows_written


def open_csv(path: str, dialect: Mapping[str, Any]):
    return open(path, "w", newline="",
                encoding=str((dialect or {}).get("encoding") or "utf-8"))


def csv_physical_rows(path: str, header: bool = True) -> int:
    """The independent recount the completeness certificate uses: physical
    lines minus the header line."""
    with open(path, "rb") as fh:
        lines = sum(1 for _ in fh)
    return max(0, lines - (1 if header else 0))


# ── JSON lines ─────────────────────────────────────────────────────────

def json_value(v: Any) -> Any:
    """One JSON-lines value: the scalar rules of
    ``core.json_utils.sanitize_for_json``."""
    if v is None or isinstance(v, (bool, str)):
        return v
    if isinstance(v, float):
        return None if (math.isnan(v) or math.isinf(v)) else v
    if isinstance(v, int):
        return v
    kind = type(v).__name__
    if kind in ("NaTType", "NAType"):
        return None
    if isinstance(v, (_dt.datetime, _dt.date, _dt.time)):
        return v.isoformat()
    if isinstance(v, _dt.timedelta):
        return v.total_seconds()
    if isinstance(v, _decimal.Decimal):
        # A float loses digits beyond ~15 significant ones; past that the
        # value travels as its exact text.
        try:
            return str(v) if len(v.as_tuple().digits) > 15 else float(v)
        except (ValueError, OverflowError, TypeError):
            return str(v)
    if isinstance(v, (bytes, bytearray, memoryview)):
        return bytes(v).hex()
    item = getattr(v, "item", None)
    if callable(item):                      # numpy scalars
        try:
            return json_value(item())
        except (ValueError, TypeError):
            pass
    iso = getattr(v, "isoformat", None)
    if callable(iso):
        try:
            return iso()
        except Exception:                   # noqa: BLE001
            pass
    return v


def json_line(columns: Sequence[Any], values: Sequence[Any]) -> str:
    """One object, one line, ``\\n``-terminated on every OS."""
    obj = {str(c): json_value(v) for c, v in zip(columns, values)}
    return json.dumps(obj, default=str) + "\n"


def lines_physical_rows(path: str) -> int:
    with open(path, "rb") as fh:
        return sum(1 for _ in fh)


# ── one renderer entry point for a row source ──────────────────────────

def render_rows(path: str, output_format: str, columns: Sequence[Any],
                rows: Iterable[Sequence[Any]],
                dialect: Optional[Mapping[str, Any]] = None) -> int:
    """Write ``rows`` as ``output_format`` (csv / json) to ``path``;
    returns the rows written.  The Spark job's driver render; the native
    renderers (``core/feed/renderers.py``) call the same writers batch by
    batch, so the DECISIONS are shared and only the loop differs.

    Its caller is the
    Spark job image (``spark/jobs/generic_feed.py::_render_on_driver``), a
    separate deployable that imports this file's byte-identical mirror and
    is counted by the callerless sweeps (mirror_job_callers).  The B3 / B4 / J cases
    of tests/test_lane_conformance_output_2026_10_07.py drive that real
    call site and compare its bytes with the native renderer's.
    """
    fmt = str(output_format or "csv").strip().lower()
    if fmt == "csv":
        with open_csv(path, dialect or {}) as fh:
            w = CsvRowWriter(fh, dialect or {})
            w.header(columns)
            for r in rows:
                w.row(r)
            return w.rows_written
    if fmt == "json":
        n = 0
        with open(path, "w", encoding="utf-8", newline="") as fh:
            for r in rows:
                fh.write(json_line(columns, r))
                n += 1
        return n
    raise ValueError(f"render_rows renders csv and json only, not {fmt!r}")
