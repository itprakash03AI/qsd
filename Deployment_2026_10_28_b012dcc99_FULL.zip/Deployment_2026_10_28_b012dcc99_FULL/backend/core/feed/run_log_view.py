"""What the UI's run-log view is looking at (2026-10-07).

A feed run executed on a pod whose engine broadcast is the scheduler relay
(or nothing) streams NO ``feed_run_log`` lines, and the log dialog sat on
"Waiting for log lines..." forever.  The executing engine records which
case it is on the execution (``feed_executions.log_stream``, declared by
whoever installed the broadcast -- ``core.feed.event_audience.
run_log_stream_of``) and THIS projection, carried as ``run_log`` on
``GET /api/feed-executions/{id}``, tells the UI what to do.  The UI does
not guess: an unrecorded pod is ``unknown``, never ``live``.

Modes:

* ``live``        -- running on a pod that streams: tail the WebSocket.
* ``unavailable`` -- running on a pod that does not: the log is stored on
                     the execution when the run finishes; re-read
                     ``stored_log_route`` every ``recheck_seconds``.  A
                     spark_k8s run also names its driver pod log
                     (``driver_log_route``, the only lane with one).
* ``unknown``     -- running, and the execution does not say (a row from
                     before the column, or not yet claimed by an engine).
* ``stored``      -- finished: ``files_metadata.log_lines`` is the log
                     (``stored_line_count`` of them; 0 says so).
"""
from __future__ import annotations

from typing import Any, Dict, Mapping, Optional

from core.feed.event_audience import RUN_LOG_LIVE, RUN_LOG_NONE

#: Statuses after which the stored log is complete.
FINISHED_STATUSES = frozenset({"completed", "failed", "cancelled"})

#: How often the UI re-reads the stored log while a run it cannot tail live
#: is still running.
RECHECK_SECONDS = 5

#: The only lane whose driver pod log has a route
#: (``api/feed_ops_api.py::feed_execution_driver_log`` refuses the others).
_DRIVER_LOG_LANES = frozenset({"spark_k8s"})


def _stored_lines(ex: Mapping[str, Any]) -> list:
    fm = ex.get("files_metadata")
    lines = fm.get("log_lines") if isinstance(fm, Mapping) else None
    return list(lines) if isinstance(lines, (list, tuple)) else []


def run_log_view(ex: Mapping[str, Any]) -> Dict[str, Any]:
    """The ``run_log`` projection of one execution row (dict shape, as the
    route serves it).  Never raises on a sparse row."""
    ex_id = ex.get("id")
    status = str(ex.get("status") or "").strip().lower()
    stream = ex.get("log_stream")
    stream = str(stream).strip().lower() if stream is not None else None
    backend = str(ex.get("execution_backend") or "").strip().lower()
    stored = _stored_lines(ex)
    stored_route = f"/api/feed-executions/{ex_id}"
    driver_route: Optional[str] = (
        f"/api/feed-executions/{ex_id}/driver-log"
        if backend in _DRIVER_LOG_LANES else None)

    if status in FINISHED_STATUSES:
        mode = "stored"
        if stored:
            message = (f"This run {status}; showing the {len(stored)} log "
                       f"lines it stored.")
        else:
            message = f"This run {status} and stored no log lines."
        recheck: Optional[int] = None
    elif stream == RUN_LOG_LIVE:
        mode = "live"
        message = "Tailing the run's log live."
        recheck = None
    elif stream == RUN_LOG_NONE:
        mode = "unavailable"
        message = ("A live log tail is not available for this run: the pod "
                   "executing it does not stream log lines.  Its log is "
                   "stored on the execution when the run finishes and is "
                   f"re-read every {RECHECK_SECONDS} seconds until then.")
        if driver_route:
            message += "  The Spark driver pod's log can be read meanwhile."
        recheck = RECHECK_SECONDS
    else:
        mode = "unknown"
        message = ("This execution does not say whether its pod streams "
                   "log lines (recorded by the engine once it claims the "
                   "run).  Its stored log is re-read every "
                   f"{RECHECK_SECONDS} seconds.")
        recheck = RECHECK_SECONDS

    return {
        "mode": mode,
        "message": message,
        "log_stream": stream,
        "stored_log_route": stored_route,
        "recheck_seconds": recheck,
        "driver_log_route": driver_route,
        "stored_line_count": len(stored),
    }
