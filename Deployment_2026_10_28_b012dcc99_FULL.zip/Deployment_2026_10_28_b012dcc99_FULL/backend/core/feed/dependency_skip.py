"""Writing the SKIP assertion the gate has always known how to read.

``dependency_gate`` honours ``action == "SKIP"`` on a tracking row — the run
proceeds MET with ``asserted=True``, the mark travels to the completeness
verdict and the control record (FR-CMP-09) — and until 2026-09-02 NOTHING in
QueryStudio ever wrote that action.  Only an external OTG ETL could.  An
operator staring at a blocked feed at 04:30 had no way to say "go anyway".

This module is that producer.  It does NOT invent a parallel mechanism: the
assertion is the same ``action='SKIP'`` upsert on the same tracking row the
external consumer would write, so the existing gate path picks it up with no
new code on the read side.

Two writes, in a deliberate order:

1. the AUDIT first — one append-only ``run_events`` row per affected run
   (``dependency_skipped``, actor, reason).  An override that cannot be
   audited must not happen: this is the one control that lets a regulatory
   feed ship without an input confirmed, and a skip nobody can explain a
   year on is the audit failure the platform exists to prevent.  So a
   failed audit write REFUSES the skip rather than proceeding unrecorded.
2. the tracking row second.  If it fails after the audit landed, the ledger
   shows an assertion that took no effect — and the caller's gate recompute
   shows the truth, so nothing silently claims success.  The upsert is
   idempotent; a retry converges.

The actor and reason are ALSO stamped into the tracking row's ``comments``
so the "why" survives even on a deployment where the ledger is unreadable.

Deliberately NOT written here: a ``dependency_events`` (arrival ledger) row.
The ledger bridge in ``etl_dependency._apply_ledger_arrivals`` treats any
ledger arrival as evidence and marks the dependency COMPLETE — which would
launder a human assertion into ``asserted=False`` "evidence" and erase
exactly the distinction FR-CMP-09 exists to keep.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from datetime import date, datetime, timezone
from typing import Any, Iterable, List, Mapping, Optional

logger = logging.getLogger(__name__)

#: Matches EtlDependencyTracking.comments (String(2000)).
_COMMENTS_MAX = 2000

# ── The skip REASON (2026-09-27) ─────────────────────────────────────────
#
# Owner: "sometimes the Kafka message won't come because of a holiday etc.,
# so it can be skipped by entering a valid reason."  A valid reason is a
# CATEGORY from this vocabulary plus free text long enough to say something
# a year on.  ONE validator serves every skip route (run, dependency, group,
# bulk) and the Run Now override, so "what is a valid reason" is decided
# once; the UI reads the vocabulary from ``GET /api/feed-dependencies/
# skip-reasons`` rather than carrying a copy.

#: (value, label) -- ordered as the UI offers them.
SKIP_REASON_CATEGORIES: tuple = (
    ("upstream_holiday", "Upstream holiday"),
    ("upstream_outage", "Upstream outage"),
    ("data_not_needed", "Data not needed"),
    ("other", "Other"),
)
SKIP_REASON_CATEGORY_HELP: dict = {
    "upstream_holiday": "The source observes a holiday today and was never "
                        "going to send. (Declare the upstream's calendar on "
                        "the dependency and no skip is needed next time.)",
    "upstream_outage": "The source failed or is late and the feed must go "
                       "without it.",
    "data_not_needed": "This run is correct without the input (empty day, "
                       "superseded load).",
    "other": "Anything else -- say what, in the text.",
}
#: The free text must carry at least this many characters ...
SKIP_REASON_MIN_CHARS = 10
#: ... and at least this many distinct words (letters), so "xxxxxxxxxx" and
#: "ok ok ok ok ok" are refused as trivial.
SKIP_REASON_MIN_WORDS = 2
SKIP_REASON_MAX_CHARS = 1000

_WORD_RE = re.compile(r"[A-Za-z][A-Za-z'\-]*")


class SkipReasonRefused(ValueError):
    """The reason is missing or trivial.  The message names what is missing
    and what would satisfy it; an API layer turns it into a 422."""


@dataclass(frozen=True)
class SkipReason:
    """A validated reason: the category, its label and the free text."""
    category: str
    label: str
    text: str

    def as_text(self) -> str:
        """The ONE string every audit row, tracking comment and
        action_reason carries: ``[Upstream holiday] the text``."""
        return f"[{self.label}] {self.text}"


def skip_reason_vocabulary() -> dict:
    """What the UI offers and the API enforces -- the same object."""
    return {
        "categories": [{"value": v, "label": lbl,
                        "help": SKIP_REASON_CATEGORY_HELP.get(v, "")}
                       for v, lbl in SKIP_REASON_CATEGORIES],
        "min_chars": SKIP_REASON_MIN_CHARS,
        "min_words": SKIP_REASON_MIN_WORDS,
        "max_chars": SKIP_REASON_MAX_CHARS,
    }


def validate_skip_reason(category: Any, text: Any) -> SkipReason:
    """A category from the vocabulary plus non-trivial free text, or a
    refusal that says exactly what is missing."""
    labels = dict(SKIP_REASON_CATEGORIES)
    allowed = ", ".join(v for v, _ in SKIP_REASON_CATEGORIES)
    cat = str(category or "").strip().lower()
    if not cat:
        raise SkipReasonRefused(
            f"reason_category is missing: pick one of {allowed}.  This skip "
            f"ships a feed without an input confirmed, and an override with "
            f"no stated kind is unauditable a year on.")
    if cat not in labels:
        raise SkipReasonRefused(
            f"reason_category {cat!r} is not in the vocabulary: pick one of "
            f"{allowed}.")
    cleaned = " ".join(str(text or "").split())
    if not cleaned:
        raise SkipReasonRefused(
            f"reason is missing: an unexplained override is unauditable a "
            f"year on.  Say what is late and why it is safe to proceed, in "
            f"at least {SKIP_REASON_MIN_CHARS} characters (e.g. "
            f"'APAC_POSITIONS upstream declared a late start; risk sign-off "
            f"by J. Doe').")
    if len(cleaned) < SKIP_REASON_MIN_CHARS:
        raise SkipReasonRefused(
            f"reason is too short ({len(cleaned)} characters; at least "
            f"{SKIP_REASON_MIN_CHARS} are needed): say what is late and why "
            f"it is safe to proceed.")
    if len(cleaned) > SKIP_REASON_MAX_CHARS:
        raise SkipReasonRefused(
            f"reason is too long ({len(cleaned)} characters; at most "
            f"{SKIP_REASON_MAX_CHARS}).")
    words = {w.lower() for w in _WORD_RE.findall(cleaned)}
    if len(words) < SKIP_REASON_MIN_WORDS:
        raise SkipReasonRefused(
            f"reason {cleaned!r} is trivial: it needs at least "
            f"{SKIP_REASON_MIN_WORDS} different words, so that someone "
            f"reading the audit a year on learns what was late and why the "
            f"feed went without it.")
    return SkipReason(category=cat, label=labels[cat], text=cleaned)


#: run_events.event_type values that are operator DECISIONS about a run's
#: dependencies -- what the timeline and the blocking panel list.
DECISION_EVENT_TYPES = ("dependency_skipped", "dependencies_overridden",
                        "dependency_wait_escalated")


def decision_rows(events: Iterable[Mapping[str, Any]],
                  feed_run_id: Optional[int] = None) -> List[dict]:
    """Project ledger rows into the decision shape the UI renders:
    ``{event_type, dependency_key, actor, at, reason, reason_category,
    feed_run_id, source}``.  With ``feed_run_id`` given, only decisions
    stamped for that run (a decision with no run stamp is kept -- an
    older audit row still HAPPENED)."""
    out: List[dict] = []
    for e in events:
        et = str(e.get("event_type") or "")
        if et not in DECISION_EVENT_TYPES:
            continue
        payload = e.get("payload") or {}
        if not isinstance(payload, dict):
            payload = {}
        stamped = payload.get("feed_run_id")
        if (feed_run_id is not None and stamped is not None
                and int(stamped) != int(feed_run_id)):
            continue
        out.append({
            "event_type": et,
            "dependency_key": e.get("subject"),
            "actor": e.get("actor"),
            "at": e.get("created_at") or e.get("occurred_at")
            or payload.get("asserted_at"),
            "reason": payload.get("reason"),
            "reason_category": payload.get("reason_category"),
            "feed_run_id": stamped,
            "feed_config_id": e.get("feed_config_id"),
            "business_date": e.get("business_date"),
            "source": payload.get("source"),
            "not_met": payload.get("not_met"),
        })
    return out


class SkipAuditUnrecordable(Exception):
    """The audit row could not be written, so the skip was refused.

    Carried as its own type so an API layer can turn it into a 5xx that
    says WHY nothing was skipped, rather than a success that recorded
    nothing.
    """


class SecondApproverRequired(Exception):
    """FR-DEP-14 (2026-09-03) — the skip needs a second, DIFFERENT approver.

    Raised when any affected feed declares
    ``skip_requires_second_approver`` and fewer than two distinct actors
    have approved this (dependency, business_date).  The CURRENT actor's
    approval was recorded before this was raised, so the second approver
    completes the skip by simply calling :func:`assert_skip` themselves.
    Nothing has been skipped when this raises — the tracking row is
    untouched.
    """

    def __init__(self, message: str, approvers: list):
        super().__init__(message)
        #: Who has approved so far, so an API layer can show "waiting on a
        #: second approver; alice has approved".
        self.approvers = list(approvers)


def _decision_deadline_at(db: Any, dependency_key: str, business_date: date,
                          when: datetime) -> tuple:
    """``(deadline, unavailable_reason)`` -- one of them None."""
    from core.feed.acting_time import decision_deadline_for
    try:
        deadline = decision_deadline_for(db, business_date, dependency_key,
                                         when)
    except Exception as exc:                          # noqa: BLE001
        logger.warning("[dependency_skip] decision deadline for %r on %s "
                       "could not be computed: %s", dependency_key,
                       business_date, exc)
        return None, f"{type(exc).__name__}: {exc}"
    if deadline is not None and deadline.tzinfo is None:
        deadline = deadline.replace(tzinfo=timezone.utc)
    return deadline, None


def skip_comment(actor: str, reason: str,
                 asserted_at: Optional[datetime] = None) -> str:
    """The durable who/why/when carried on the tracking row itself."""
    ts = (asserted_at or datetime.now(timezone.utc)).isoformat()
    return f"SKIP asserted by {actor} at {ts}: {reason}"[:_COMMENTS_MAX]


def assert_skip(
    db: Any,
    *,
    dependency_type_id: int,
    dependency_key: str,
    business_date: date,
    reason: str,
    actor: str,
    affected_runs: Iterable[Mapping[str, Any]],
    asserted_at: Optional[datetime] = None,
    source: str = "skip_api",
    reason_category: Optional[str] = None,
) -> dict:
    """Write one SKIP assertion: audit rows, then the tracking row.

    ``affected_runs`` are mappings each carrying at least
    ``feed_config_id`` and ``id`` (the feed_run id) — one audit row is
    appended per run this assertion releases, so "who skipped what, for
    which feed, and why" is answerable per feed a year on.

    Returns the upserted tracking row dict.
    Raises :class:`SkipAuditUnrecordable` if any audit row cannot be
    written — in that case the tracking row is NOT touched.
    Raises :class:`SecondApproverRequired` when any affected feed declares
    ``skip_requires_second_approver`` and this is only the FIRST distinct
    approver (FR-DEP-14) — the approval is recorded, nothing is skipped,
    and a DIFFERENT actor's identical call completes it.
    """
    when = asserted_at or datetime.now(timezone.utc)
    runs = list(affected_runs)

    # ── FR-DEP-14 maker/checker (2026-09-03) — checked BEFORE anything is
    # written to the audit-then-act pipeline below, because it is a
    # PRECONDITION on the act, not part of it: a refused skip must leave
    # the tracking row untouched and the per-run 'dependency_skipped'
    # audit unwritten (nothing was skipped, so nothing may say it was).
    # The current actor's APPROVAL is recorded first in every case — that
    # record is how the second approver's later call completes the skip.
    approvers: list = []
    if _second_approver_required(db, runs):
        approvers = _record_approval_and_list(
            db, dependency_type_id=int(dependency_type_id),
            dependency_key=dependency_key, business_date=business_date,
            actor=actor, reason=reason)
        if len(approvers) < 2:
            raise SecondApproverRequired(
                f"skipping {dependency_key!r} for "
                f"{business_date.isoformat()} releases a feed that requires "
                f"a SECOND approver (skip_requires_second_approver). "
                f"Approved so far: {', '.join(approvers)}. A DIFFERENT "
                f"user must assert the same skip to complete it; nothing "
                f"was skipped.", approvers)

    # 2026-09-28 -- the DECISION DEADLINE this dependency was under when the
    # skip was asserted, from the same clocks the alert and the Support
    # Desk show (``acting_time.decision_deadline_for``), stored WITH the
    # decision so "what share of skips were made in time" is a fact in the
    # ledger rather than a reconstruction.  Fail-soft and stated: a deadline
    # that could not be computed is recorded as unavailable with the
    # reason, never as "no deadline".
    deadline, deadline_unavailable = _decision_deadline_at(
        db, dependency_key, business_date, when)
    for run in runs:
        payload = {
            "reason": reason,
            "decision_deadline": deadline.isoformat() if deadline else None,
            "decision_deadline_unavailable": deadline_unavailable,
            "decided_before_deadline": (
                (when <= deadline) if deadline is not None else None),
            # 2026-09-27 -- the category the operator chose (the reason
            # text already carries its label), so the audit can be
            # counted by kind: how many upstream holidays went unskipped
            # because nobody declared the upstream's calendar?
            "reason_category": reason_category,
            "dependency_key": dependency_key,
            "feed_run_id": run.get("id"),
            "source": source,
            "asserted_at": when.isoformat(),
        }
        if approvers:
            # Maker/checker was in force: the audit row names EVERY
            # approver, so "who let this ship" is answerable per feed a
            # year on — not just the actor whose call happened to be
            # second.
            payload["approvers"] = approvers
        try:
            db.insert_run_event({
                "feed_config_id": int(run["feed_config_id"]),
                "business_date": business_date,
                "build_id": run.get("build_id"),
                "event_type": "dependency_skipped",
                "subject": dependency_key,
                "actor": actor,
                "payload": payload,
            })
        except Exception as exc:
            raise SkipAuditUnrecordable(
                f"the audit record for skipping {dependency_key!r} could not "
                f"be written ({exc}) — refusing to skip unrecorded; nothing "
                f"was changed") from exc

    row = db.record_etl_dependency_tracking(
        dependency_type_id=int(dependency_type_id),
        dependency_key=dependency_key,
        business_date=business_date,
        action="SKIP",
        comments=skip_comment(actor, reason, when),
    )
    logger.info(
        "[dependency_skip] %s asserted SKIP on %r for %s — releases %d "
        "run(s); reason: %s", actor, dependency_key,
        business_date.isoformat(), len(runs), reason)
    return row


def _second_approver_required(db: Any,
                              runs: Iterable[Mapping[str, Any]]) -> bool:
    """Does ANY affected feed declare ``skip_requires_second_approver``?

    One regulated feed in the release set makes the whole skip regulated —
    the control would be worthless if bundling an unregulated feed relaxed
    it.  FAIL CLOSED on an unreadable config: when two answers disagree
    about whether a control applies, the stricter one governs; a db hiccup
    must not become the way around maker/checker at 05:20.  (Default OFF is
    preserved for every readable config that does not opt in — the common
    path is unchanged.)
    """
    required = False
    for run in runs:
        try:
            fid = int(run["feed_config_id"])
        except (KeyError, TypeError, ValueError):
            continue
        try:
            cfg = db.get_feed_config(fid) or {}
        except Exception as exc:
            logger.error(
                "[dependency_skip] feed_config %s unreadable (%s) — "
                "treating the skip as REQUIRING a second approver "
                "(fail closed: a read failure must not waive maker/checker)",
                fid, exc)
            return True
        if bool(cfg.get("skip_requires_second_approver")):
            required = True
    return required


def _record_approval_and_list(db: Any, *, dependency_type_id: int,
                              dependency_key: str, business_date: date,
                              actor: str, reason: str) -> list:
    """Record THIS actor's approval and return every distinct approver.

    The insert is idempotent per (dependency, date, actor) — the same
    person asserting twice is still ONE approver.  A failed approval
    write refuses the whole call (:class:`SkipAuditUnrecordable`): an
    approval that cannot be recorded cannot be counted, and counting it
    anyway would let the control pass with no evidence it was exercised.
    """
    try:
        db.insert_feed_skip_approval({
            "dependency_type_id": int(dependency_type_id),
            "dependency_key": dependency_key,
            "business_date": business_date,
            "actor": actor,
            "reason": reason,
        })
        rows = db.list_feed_skip_approvals(
            dependency_type_id=int(dependency_type_id),
            dependency_key=dependency_key,
            business_date=business_date)
    except Exception as exc:
        raise SkipAuditUnrecordable(
            f"the maker/checker approval for skipping {dependency_key!r} "
            f"could not be recorded ({exc}) — refusing to count an "
            f"approval that left no evidence; nothing was changed") from exc
    seen: list = []
    for row in rows:
        name = str(row.get("actor") or "").strip()
        if name and name not in seen:
            seen.append(name)
    return seen


def type_ids_for_key(db: Any, etl_id: int, business_date: date,
                     dependency_key: str) -> list:
    """The dependency_type_id(s) mapped for this key on this feed.

    The tracking row is keyed (type_id, key, date), so the writer needs the
    type the MAPPING declared — never a guess.  Usually one; returned as a
    list because nothing in the schema forbids the same key under two types.
    """
    rows = db.list_etl_dependency_mappings_with_tracking(
        int(etl_id), business_date) or []
    return sorted({int(r["type_id"]) for r in rows
                   if str(r.get("dependency_key") or "") == dependency_key})

def release_admitted_run(db: Any, run_id: int, reason: str, *,
                         etl_id: Optional[int] = None,
                         source: str = "skip") -> str:
    """Flip ONE admitted run WAIT -> RUN and ANNOUNCE it (2026-09-27).

    Every skip route released the run in place (so "go anyway" means now)
    and said nothing: the poller raises ``feed_dep_ready`` only for a flip it
    makes itself, so a Today page open on anyone but the skipper kept showing
    WAIT until its next refresh.  One release, one announcement, for every
    route.  Raises when the row update fails (callers keep their fail-soft
    handling: the assertion is durable and the poller converges); the
    announcement is advisory and returns how it went.
    """
    db.update_feed_run(int(run_id), {
        "action_decision": "RUN",
        "action_reason": str(reason)[:2000],
    })
    try:
        run = db.get_feed_run(int(run_id)) or {}
        fid = run.get("feed_config_id")
        # 2026-10-07: THE audience (actor-if-a-person, owner, owner group)
        # -- this used to be the owner alone while the run's own events went
        # to the actor; two answers to one question.  The release is the
        # SYSTEM acting (a skip, an override, the poller's convergence).
        from core.feed.event_audience import address, feed_event_audience
        # ``run=`` the row just read: a held BACKFILL released from WAIT
        # reaches the person who asked for it (``triggered_by_user``).
        audience = feed_event_audience(db, fid, None, run=run)
        if not audience:
            return "no_audience"
        from core import scheduler as _sch
        from core.notification_queue import emit_ws_event
        return emit_ws_event(
            address({"type": "feed_dep_ready", "feed_run_id": int(run_id),
                     "etl_id": int(etl_id) if etl_id is not None else None,
                     "feed_config_id": int(fid), "released_by": source},
                    audience),
            session_factory=getattr(db, "SessionLocal", None),
            local_broadcast_fn=getattr(_sch, "_broadcast_fn", None))
    except Exception as exc:
        logger.warning("[dependency_skip] run %s released but not announced: %s",
                       run_id, exc)
        return "failed"
