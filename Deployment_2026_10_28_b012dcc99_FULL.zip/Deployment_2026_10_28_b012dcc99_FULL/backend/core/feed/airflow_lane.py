"""THE Airflow road for a feed run (2026-10-08).

There is ONE way a feed runs through Airflow: the factory DAG
(``airflow/dags/querystudio_feed_factory.py``) submits an EXECUTION through
``POST /api/feed-executions/{execution_id}/spark-submit``, where the ONE
conf builder (``core/spark_k8s/feed_conf.build_feed_conf``) resolves the
source plan, the per-run credential Secret, the artifact store and the
delivery owner, and the ONE submitter (``core/spark_k8s/runner``) creates
the workload.  The job reports through the signed webhook; the reconciler
supervises.  That road is what the C2 matrices certify.

Until this date the engine's airflow lane (``feed_engine._execute_airflow``)
took a SECOND road: it assembled the job's conf itself (secured SQL,
calendar params, a legacy projection), POSTed it as the DAG run's ``conf``
for a conf-driven DAG to hand to the job, and -- because that conf carried
no JDBC credentials and the job's output was remote -- handed the native
renderer a path it could never read.  Two roads to one lane is a decision
made twice, and the second one was broken (docs/FEED_LANE_CONTRACT_
2026_10_07.html s6, "known, not closed").

This module is the whole of what the engine ships to Airflow: a DISPATCH.
Which execution, which feed, the run's business date, the route the DAG
must call, and the name of this contract.  Nothing the job needs travels
here -- the DAG asks QueryStudio for it at submit, where it is secured.

A DAG that cannot honour the contract (an operator's conf-driven DAG that
runs the job itself) is not routed through another road: the engine sees
a DAG run that ended ``success`` with the execution never submitted and
REFUSES the run naming this contract (``feed_engine._execute_airflow``).

Guard: ``tests/test_airflow_one_road_2026_10_08.py`` -- the dispatch's
keys are exactly :data:`DISPATCH_CONF_KEYS`, ``trigger_dag`` is called
from the declared sites only, and only the transport spells the URL.
"""
from __future__ import annotations

import logging
from datetime import date
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger(__name__)

#: The contract name the DAG reads to know it was handed an execution to
#: ADOPT and submit (never a feed conf to run).  Bump the number when the
#: dispatch's meaning changes; a DAG built for an older contract adopts
#: the execution all the same (it reads only ``execution_id`` /
#: ``run_date``).
DISPATCH_CONTRACT = "spark_submit/1"

#: EVERY key the dispatch carries -- and none other (guarded).
DISPATCH_CONF_KEYS: Tuple[str, ...] = (
    "contract", "execution_id", "feed_config_id", "feed_name",
    "run_date", "submit_route",
)

#: Words that must never appear in a dispatch: a feed-conf field or a
#: credential reaching Airflow is the conf-driven road coming back.
NEVER_IN_DISPATCH: Tuple[str, ...] = (
    "query_params", "source_plan", "jdbc_config", "password",
    "secondary_query_params", "feed_params", "output_s3_bucket",
)

#: The literal the config SHIPS as feed_generation.airflow.default_dag_id.
#: No DAG file in this repo registers it: the factory registers
#: ``querystudio_feed_{id}`` per feed.  Kept as a named constant so
#: :func:`resolve_dag_id` can recognise "the operator never chose a DAG"
#: and derive the id the factory ACTUALLY registers, instead of 404ing at
#: trigger (P2 2026-08-22).
SHIPPED_DEFAULT_DAG_ID = "querystudio_feed"

SUBMIT_ROUTE_TEMPLATE = "/api/feed-executions/{execution_id}/spark-submit"


def resolve_dag_id(feed_config: dict, af_cfg) -> Tuple[str, str]:
    """Which Airflow DAG a QS-initiated dispatch triggers, and where the
    id came from (so a trigger failure can say which knob to fix).

    Order:
      1. ``backend_config.dag_id`` -- an explicit per-feed pin, wins.
      2. a NON-shipped-default ``feed_generation.airflow.default_dag_id``
         -- the operator deployed their own DAG; it must honour the
         dispatch contract (adopt + /spark-submit), and the engine refuses
         the run if it does not.
      3. the per-feed factory id ``querystudio_feed_{feed_id}`` -- the DAG
         ``querystudio_feed_factory.py`` actually registers for this feed.
    """
    _bc_dag_id = (feed_config.get("backend_config") or {}).get("dag_id")
    if _bc_dag_id:
        return str(_bc_dag_id), "backend_config.dag_id"
    _default = str(getattr(af_cfg, "default_dag_id", "") or "")
    if _default and _default != SHIPPED_DEFAULT_DAG_ID:
        return _default, "feed_generation.airflow.default_dag_id"
    return (f"querystudio_feed_{feed_config.get('id')}",
            "derived from feed id (factory DAG)")


def dag_run_id_for(execution_id: str) -> str:
    """The DAG run id for one execution: deterministic, so an Airflow-side
    duplicate trigger of the same execution collides instead of running
    twice."""
    return f"querystudio_{execution_id}"


def dag_run_conf(feed_config: dict, execution_record: dict, *,
                 run_date: Optional[date] = None) -> Dict[str, Any]:
    """The DISPATCH: what the engine ships to Airflow for one execution.

    Nothing here is the job's conf.  The DAG's ``run_spark_job`` task
    POSTs ``submit_route``, and QueryStudio builds the job's conf there --
    credentials in the per-run Secret, SQL secured against each side's own
    connection, the run's stored delivery decision, the artifact store.
    ``run_date`` is the run's BUSINESS date (E-M6): the engine knows it
    from the bound feed_run; the DAG passes it through so calendar tokens
    resolve against the run, not the DAG's logical date.
    """
    execution_id = str(execution_record.get("execution_id") or "")
    if not execution_id:
        raise ValueError("airflow dispatch: the execution has no execution_id")
    return {
        "contract": DISPATCH_CONTRACT,
        "execution_id": execution_id,
        "feed_config_id": feed_config.get("id"),
        "feed_name": feed_config.get("name"),
        "run_date": run_date.isoformat() if run_date else None,
        "submit_route": SUBMIT_ROUTE_TEMPLATE.format(execution_id=execution_id),
    }


def airflow_client_from(af_cfg, *, transport=None):
    """The REST client for ``feed_generation.airflow`` (one builder for the
    engine, so the transport can be injected by a test through the
    engine's own ``_http_request`` seam)."""
    from core.feed.airflow_client import AirflowClient
    return AirflowClient(
        base_url=str(af_cfg.base_url),
        auth=(str(getattr(af_cfg, "auth_type", "none") or "none"),
              str(getattr(af_cfg, "username", "") or "") or None,
              str(getattr(af_cfg, "password", "") or "") or None),
        timeout_seconds=60,
        transport=transport,
    )


def trigger_feed_dag_run(client, dag_id: str, dag_run_id: str,
                         conf: Dict[str, Any], *, dag_id_source: str):
    """POST the dispatch as a DAG run, and make the two failure shapes
    NAME the problem.

    A 404 here means "Airflow has no such DAG" -- before 2026-08-22 it
    surfaced as ``RuntimeError: HTTP 404 from http://airflow...`` which
    every on-call read as an Airflow outage.  The message names the DAG
    id, where the id came from, and what registers it.
    """
    try:
        return client.trigger_dag(dag_id, dag_run_id, conf)
    except RuntimeError as _trig_exc:
        if "HTTP 404" in str(_trig_exc):
            raise RuntimeError(
                f"Airflow has no DAG with id '{dag_id}' (trigger POST "
                f"returned 404). The id came from {dag_id_source}. "
                f"The feed factory registers 'querystudio_feed_<feed_id>' "
                f"via querystudio_feed_factory.py (requires "
                f"backend_config.execution_mode='spark_fallback' and the "
                f"factory DAG file deployed to Airflow). Set "
                f"backend_config.dag_id explicitly to pin a different DAG "
                f"-- one that honours the {DISPATCH_CONTRACT} dispatch "
                f"(adopt the execution, POST its spark-submit route)."
            ) from _trig_exc
        raise


def row_is_submitted(row: dict, dag_run_id: str) -> bool:
    """Has the DAG submitted this execution through /spark-submit?  The
    ONE submitter stamps ``external_job_id`` with the workload name and
    ``execution_backend`` with the compute lane; until then the row still
    carries the DAG run id the engine recorded."""
    row = row or {}
    ext = str(row.get("external_job_id") or "")
    return (str(row.get("execution_backend") or "").lower() == "spark_k8s"
            and bool(ext) and ext != dag_run_id)


def refusal_as_error(refusal: dict):
    """The declared spark_k8s error ``/spark-submit`` recorded on the row
    (``stage_timings.spark_submit_refusal``) when it answered the DAG with
    a 503, rebuilt so the engine applies the SAME submit-time rule the
    spark_k8s lane does (``backend_router.lane_failed_at_submit``)."""
    from core.spark_k8s.errors import SparkK8sUnavailable, SparkK8sUnreachable
    refusal = refusal or {}
    if refusal.get("kind") == "unreachable":
        return SparkK8sUnreachable(
            str(refusal.get("host") or ""), str(refusal.get("cause") or ""),
            detail=str(refusal.get("detail") or ""),
            request_sent=bool(refusal.get("request_sent", True)),
            nothing_created=bool(refusal.get("nothing_created", False)))
    return SparkK8sUnavailable(
        str(refusal.get("reason_code") or "unavailable"),
        str(refusal.get("detail") or ""))
