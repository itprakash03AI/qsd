"""Business-calendar arithmetic — Phase 130.

Single responsibility: given a (calendar_name, date), answer:
  - is this a business day?
  - what is the previous business day?
  - what is the previous end-of-month business day?
  - is this date one of the last N business days of its month?

All inputs are DB-driven.  Weekend definition lives in
``feed_calendars.weekend_days`` (JSON list of ISO weekday numbers).
Holiday list lives in ``feed_holidays`` (one row per date, optionally
``recurring`` if the holiday repeats every year on the same MM-DD).

Zero hardcoded country/region assumptions.  When the DB has no
``weekend_days`` for a calendar the consumer falls back to the system
config ``feed_generation.default_weekend_days``; that config is the
only "default" surface, and operators can change it without code
changes.
"""
from __future__ import annotations

import calendar as _stdlib_calendar
import logging
from dataclasses import dataclass
from datetime import date as _date, timedelta
from typing import List, Optional, Protocol, Set

# Added 2026-09-03 WITH the first logging call in this module.  The
# horizon warning was written before this import existed, so _load
# raised NameError, a caller swallowed it, the spec became None, and
# every date came back a business day — the precise failure FR-SCH-02
# exists to prevent, introduced by the change implementing it.  A name
# typo'd inside a fail-open path is invisible except through its
# consequences; here 16 tests showed the consequence immediately.
logger = logging.getLogger(__name__)


# ── Repository protocol (DB-driven, no module singletons) ──────────────────


class CalendarRepo(Protocol):
    """Subset of DatabaseManager that BusinessCalendar needs.  Defined
    as a Protocol so tests can pass a MagicMock without monkey-patching
    the real ``core.database`` module."""

    def get_feed_calendar_by_name(self, name: str) -> Optional[dict]: ...
    def list_feed_holidays(self, calendar_id: int) -> List[dict]: ...


# ── Default-weekend-day resolver (config-driven, NOT hardcoded) ─────────────


def _system_default_weekend_days() -> List[int]:
    """Read the system-wide weekend definition from config.  Used ONLY
    when the calendar row itself didn't supply a weekend_days list —
    i.e. as a fallback for legacy calendars.  Admins change this via
    ``feed_generation.default_weekend_days`` in config.json; no
    Python edit required.
    """
    try:
        from core.config import get as _cfg_get
        raw = _cfg_get("feed_generation", "default_weekend_days", None)
        if raw and isinstance(raw, (list, tuple)):
            out = [int(x) for x in raw if 1 <= int(x) <= 7]
            if out:
                return out
    except Exception:
        pass
    # If neither calendar nor config configured it, return empty —
    # caller interprets "no weekend" as "every day is a business day".
    # Better to be explicit + surface the misconfig than to silently
    # assume Sat/Sun like Western finance.
    return []


# ── Pure value objects ──────────────────────────────────────────────────────


class CalendarHorizonError(RuntimeError):
    """FR-SCH-02 — the calendar has not been populated through this date.

    Raised instead of answering, because the alternative is the sentence
    the requirement forbids: "the platform must never assume a day is a
    business day because the calendar does not say otherwise".  Beyond
    its horizon a calendar knows nothing, and "no holiday recorded" is
    indistinguishable from "not loaded yet" — so a month-end feed would
    compute the wrong business day, deliver on a public holiday to a
    closed counterparty, and report success.

    An UNDECLARED horizon (NULL) does not raise: an estate whose
    calendars predate this column must keep running.  It is stated once
    per calendar at load instead, so the gap is visible and fillable
    rather than silently unbounded.
    """


@dataclass(frozen=True)
class CalendarSpec:
    """Resolved calendar shape — fed by ``BusinessCalendarRepo``,
    consumed by ``BusinessCalendar``.  Frozen so tests can pass a
    literal instance without worrying about mutation."""
    id: int
    name: str
    weekend_days: List[int]        # ISO weekday numbers (Mon=1..Sun=7)
    holidays_explicit: Set[_date]  # specific-date holidays (one shot)
    holidays_recurring_md: Set[tuple]  # (month, day) tuples that repeat every year
    #: FR-SCH-01 — the last date this calendar is POPULATED THROUGH.
    #: None means UNDECLARED, which is a configuration gap, not "for
    #: ever".  Recurring holidays do not extend it: a recurring entry
    #: says "this date every year", never "no other holiday exists in
    #: 2029".
    horizon_end: Optional[_date] = None
    #: FR-SCH-01 — who ANSWERS for this calendar, not who typed the row.
    owner: str = ""
    #: FR-SCH-01 — bumped when holidays change, so a run can record
    #: which calendar version it was scheduled against.
    version: int = 1


# ── DB-backed repository ────────────────────────────────────────────────────


class BusinessCalendarRepo:
    """Loads a ``CalendarSpec`` for the given calendar name from the
    DB.  Caches resolved specs in-process for 5 minutes by default
    so the SOD task generator doesn't hit the DB per feed.

    The cache is keyed on (calendar_name, mtime-of-latest-holiday).
    A simpler implementation could use a flat TTL — picked the
    mtime-aware form so admin edits in the holiday admin UI take
    effect immediately, not 5 minutes later.
    """

    def __init__(self, repo: CalendarRepo, ttl_seconds: int = 300):
        self._repo = repo
        self._ttl_seconds = max(1, ttl_seconds)
        self._cache: dict = {}        # name → (CalendarSpec, fetched_at_ts)

    def get(self, calendar_name: str) -> Optional[CalendarSpec]:
        if not calendar_name:
            return None
        import time as _t
        now = _t.monotonic()
        cached = self._cache.get(calendar_name)
        if cached and (now - cached[1]) < self._ttl_seconds:
            return cached[0]
        spec = self._load(calendar_name)
        if spec is not None:
            self._cache[calendar_name] = (spec, now)
        return spec

    def invalidate(self, calendar_name: Optional[str] = None) -> None:
        """Called by the admin endpoints when a calendar / holiday is
        edited so the next ``get()`` reloads from DB."""
        if calendar_name:
            self._cache.pop(calendar_name, None)
        else:
            self._cache.clear()

    def _load(self, name: str) -> Optional[CalendarSpec]:
        row = self._repo.get_feed_calendar_by_name(name)
        if not row:
            return None
        weekend = row.get("weekend_days")
        if not weekend or not isinstance(weekend, (list, tuple)):
            weekend = _system_default_weekend_days()
        explicit: Set[_date] = set()
        recurring: Set[tuple] = set()
        for h in self._repo.list_feed_holidays(row["id"]) or []:
            hd = h.get("holiday_date")
            if hd is None:
                continue
            if isinstance(hd, str):
                try:
                    hd = _date.fromisoformat(hd)
                except ValueError:
                    continue
            if h.get("recurring"):
                recurring.add((hd.month, hd.day))
            else:
                explicit.add(hd)
        horizon = row.get("horizon_end")
        if isinstance(horizon, str):
            try:
                horizon = _date.fromisoformat(horizon[:10])
            except ValueError:
                horizon = None
        elif hasattr(horizon, "date") and not isinstance(horizon, _date):
            horizon = horizon.date()
        if horizon is None:
            # Stated ONCE per load, not per query: an undeclared horizon
            # is a real gap (nothing can tell "no holiday" from "not
            # loaded yet") but it must not spam a per-row hot path, and
            # it must not stop an estate whose calendars predate the
            # column.
            logger.warning(
                "[calendar] %r declares NO horizon_end — dates beyond its "
                "populated range cannot be distinguished from ordinary "
                "business days (FR-SCH-02).  Set horizon_end to the last "
                "date this calendar is loaded through.", name)
        return CalendarSpec(
            id=int(row["id"]),
            name=row["name"],
            weekend_days=[int(x) for x in weekend if 1 <= int(x) <= 7],
            holidays_explicit=explicit,
            holidays_recurring_md=recurring,
            horizon_end=horizon,
            owner=str(row.get("owner") or ""),
            version=int(row.get("version") or 1),
        )


# ── BusinessCalendar — the public API ──────────────────────────────────────


class BusinessCalendar:
    """Date arithmetic against a named calendar.

    Construct with a resolved ``CalendarSpec`` — typically from
    ``BusinessCalendarRepo.get(name)``.  All methods are pure functions
    over the spec, no DB access, safe to call in tight loops.

    Example::

        repo = BusinessCalendarRepo(db_manager)
        cal  = BusinessCalendar(repo.get("US_BANKING"))
        if not cal.is_business_day(date.today()):
            cal.previous_business_day(date.today())
    """

    def __init__(self, spec: Optional[CalendarSpec]):
        self._spec = spec

    # ── Predicates ─────────────────────────────────────────────────────────

    def is_weekend(self, d: _date) -> bool:
        if not self._spec:
            return False
        return d.isoweekday() in self._spec.weekend_days

    def is_holiday(self, d: _date) -> bool:
        if not self._spec:
            return False
        if d in self._spec.holidays_explicit:
            return True
        return (d.month, d.day) in self._spec.holidays_recurring_md

    def horizon_end(self) -> Optional[_date]:
        """The last date this calendar is populated through, or None
        when undeclared."""
        return getattr(self._spec, "horizon_end", None) if self._spec else None

    def assert_within_horizon(self, d: _date) -> None:
        """FR-SCH-02 — refuse a date the calendar cannot speak for.

        No-op when there is no spec (the caller already has no calendar
        and knows it) or when the horizon is undeclared (stated at load
        instead, so an older estate keeps running).
        """
        horizon = self.horizon_end()
        if horizon is not None and d > horizon:
            raise CalendarHorizonError(
                f"calendar {self._spec.name!r} is populated only through "
                f"{horizon.isoformat()}; it cannot say whether "
                f"{d.isoformat()} is a business day.  Refusing rather "
                f"than assuming one — an unloaded holiday and an ordinary "
                f"working day look identical from here (FR-SCH-02).  "
                f"Extend the calendar's holidays and its horizon_end"
                + (f"; owner: {self._spec.owner}" if self._spec.owner else ""))

    def is_business_day(self, d: _date) -> bool:
        self.assert_within_horizon(d)
        return not (self.is_weekend(d) or self.is_holiday(d))

    # ── Date walkers ───────────────────────────────────────────────────────

    def previous_business_day(self, d: _date) -> _date:
        """Walk back one calendar day at a time until we land on a
        business day.  ``d`` itself is NOT returned even when it's
        already a business day — semantic matches "the business day
        before this date" in enterprise file-delivery systems."""
        prev = d - timedelta(days=1)
        # Safety cap — 366 iterations covers a full year of consecutive
        # holidays which is well beyond any realistic configuration.
        for _ in range(366):
            if self.is_business_day(prev):
                return prev
            prev -= timedelta(days=1)
        raise RuntimeError(
            f"BusinessCalendar({self._spec.name if self._spec else '?'}): "
            f"could not find a business day within 366 days before {d.isoformat()}; "
            "calendar is over-restricted"
        )

    def previous_business_day_or_today(self, d: _date) -> _date:
        """Returns ``d`` if it's a business day, else walks back."""
        return d if self.is_business_day(d) else self.previous_business_day(d)

    def previous_eom(self, d: _date) -> _date:
        """End of the PREVIOUS month, rolled back to the most recent
        business day on or before that date.

        Equivalent to the enterprise ``COB_PREV_EOM`` function.  Used
        by month-end feeds whose business_date is "the last business
        day of the prior month".
        """
        first_of_this_month = d.replace(day=1)
        last_of_prev_month = first_of_this_month - timedelta(days=1)
        return self.previous_business_day_or_today(last_of_prev_month)

    def is_last_n_business_days_of_month(self, d: _date, n: int) -> bool:
        """Returns True when ``d`` is one of the last ``n`` business
        days of its calendar month.

        Implements the common month-end rule from the user's example
        (``ACTION_CONDITION ... last 6 business days of the month``):
        a feed runs ONLY in this window so the same monthly
        deliverable doesn't fire 22 times — once per business day
        in the month.
        """
        if n < 1:
            return False
        if not self.is_business_day(d):
            return False
        last_day_of_month = self._last_day_of_month(d)
        seen = 0
        cursor = last_day_of_month
        while cursor >= d:
            if self.is_business_day(cursor):
                seen += 1
                if cursor == d:
                    return seen <= n
            cursor -= timedelta(days=1)
        return False

    def is_nth_business_day_of_month(self, d: _date, n: int) -> bool:
        """BF-472 (2026-05-19) — returns True when ``d`` is the Nth
        business day of its calendar month, counting from the first.

        Used for enterprise schedules like "workday 6" or "workday 10"
        where the feed must run on the specific Nth business day of
        every month.  Pair with ACTION_CONDITION:

            CASE WHEN NOT IS_NTH_BUSINESS_DAY_OF_MONTH($business_date, 6)
                 THEN 'SKIP' END

        ``n`` is 1-indexed: n=1 is the first business day of the month.
        Returns False when ``n < 1`` or when ``d`` itself isn't a
        business day.
        """
        if n < 1:
            return False
        if not self.is_business_day(d):
            return False
        first_day_of_month = d.replace(day=1)
        seen = 0
        cursor = first_day_of_month
        while cursor <= d:
            if self.is_business_day(cursor):
                seen += 1
                if cursor == d:
                    return seen == n
            cursor += timedelta(days=1)
        return False

    def nth_business_day_of_month(self, year: int, month: int, n: int) -> Optional[_date]:
        """BF-472 — return the actual date of the Nth business day of
        the given ``(year, month)``.  Used by param_resolver to
        populate ``{{wd6_this_month}}`` etc. tokens.

        Returns ``None`` when the month has fewer than N business days
        (rare — would need a month with > 24 holidays).
        """
        if n < 1:
            return None
        cursor = _date(year, month, 1)
        # Stop at the last day of the month
        last_dom = _stdlib_calendar.monthrange(year, month)[1]
        end = _date(year, month, last_dom)
        seen = 0
        while cursor <= end:
            if self.is_business_day(cursor):
                seen += 1
                if seen == n:
                    return cursor
            cursor += timedelta(days=1)
        return None

    # ── Helpers ────────────────────────────────────────────────────────────

    @staticmethod
    def _last_day_of_month(d: _date) -> _date:
        return d.replace(day=_stdlib_calendar.monthrange(d.year, d.month)[1])

    # ── Diagnostics ────────────────────────────────────────────────────────

    @property
    def spec(self) -> Optional[CalendarSpec]:
        return self._spec
