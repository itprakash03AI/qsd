"""The ENVIRONMENTS a combined feed reads -- DATABASE data, never code
(2026-10-12, the owner: "all should be generic ... all db driven ... no
hardcoded in code ... if tomorrow a new source comes, easy to plug in").

A combined feed has sides (``primary`` = its own source, ``secondary`` =
the second connection).  Which ENVIRONMENT each side is -- its label on every
screen, how a dependency's NAME says it, how a MESSAGE's payload says it --
is the table ``feed_environments`` (model ``FeedEnvironment``; seeded once
with CLOUD / ON-PREM on a fresh database, edited at
``/api/admin/feed-environments``).

Every reader asks HERE: the upstream contract's governing dependency
(``etl_dependency.infer_certified_side``), the board's side of a dependency
and of a message (``core/feed/dashboard.py``), the one-side re-run's words
(``side_resume``) and the board's labels (served with the board).  An
unrecognised name or payload is "no side" -- never guessed.  Rows are cached
for ``CACHE_SECONDS``; every write through the routes invalidates.
"""
from __future__ import annotations

import threading
import time
from typing import Any, Dict, List, Mapping, Optional

SIDES = ("primary", "secondary")
CACHE_SECONDS = 30

_lock = threading.Lock()
_cache: Dict[str, Any] = {"at": 0.0, "rows": None}


def invalidate() -> None:
    with _lock:
        _cache["at"], _cache["rows"] = 0.0, None


def _rows(db=None) -> List[Dict[str, Any]]:
    now = time.monotonic()
    with _lock:
        if db is None and _cache["rows"] is not None and now - _cache["at"] < CACHE_SECONDS:
            return _cache["rows"]
    if db is None:
        from core.database import get_db_manager
        db = get_db_manager()
    try:
        raw = list(db.list_feed_environments() or []) if db is not None else []
    except Exception:                                   # noqa: BLE001 -- unreadable = no sides known
        raw = []
    with _lock:
        _cache["at"], _cache["rows"] = now, raw
    return raw


def environments(db=None) -> List[Dict[str, Any]]:
    """The active environments, normalised, in their configured order."""
    out = []
    for e in _rows(db):
        if isinstance(e, Mapping) and e.get("side") in SIDES:
            out.append({"side": e["side"], "label": str(e.get("label") or e["side"]).strip(),
                        "dependency_suffixes": [str(s).upper() for s in (e.get("dependency_suffixes") or [])],
                        "message_field": e.get("message_field"),
                        "message_values": [str(v).strip().lower() for v in (e.get("message_values") or [])]})
    return out


def label(side: Optional[str]) -> Optional[str]:
    """The screen word for a side ("CLOUD"), or None."""
    for e in environments():
        if e["side"] == side:
            return e["label"]
    return None


def side_of_dependency(name: Optional[str]) -> Optional[str]:
    """The side a dependency's NAME declares (its configured ending), or None.
    The longest matching ending wins (``_ON_PREM`` before ``_PREM``)."""
    up = str(name or "").upper()
    best = None
    for e in environments():
        for suf in e["dependency_suffixes"]:
            if suf and up.endswith(suf) and (best is None or len(suf) > best[0]):
                best = (len(suf), e["side"])
    return best[1] if best else None


def side_of_message(fields: Optional[Mapping[str, Any]]) -> Optional[str]:
    """The side a MESSAGE's payload declares (its configured field/value)."""
    if not isinstance(fields, Mapping):
        return None
    upper = {str(k).upper(): v for k, v in fields.items()}
    for e in environments():
        f = str(e.get("message_field") or "").upper()
        if f and upper.get(f) is not None and str(upper[f]).strip().lower() in e["message_values"]:
            return e["side"]
    return None


def public() -> List[Dict[str, str]]:
    """What the UI needs: side -> label, in the configured order."""
    return [{"side": e["side"], "label": e["label"]} for e in environments()]
