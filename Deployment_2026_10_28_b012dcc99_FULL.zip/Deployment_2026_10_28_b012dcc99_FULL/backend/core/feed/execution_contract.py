"""THE resolved execution contract — every decision, made once, here.

QueryStudio runs feeds on two execution ENGINES: DuckDB/pandas in the
API pod (native) and Spark in a driver pod (heavy).  Two engines is not
a design flaw — you cannot share "read with DuckDB" and "read with
Spark" code, any more than one SQL string is two query planners.

What must never be duplicated is a DECISION.  The engines may differ in
how they read a table or write a file; they may not differ in WHAT FILE
the counterparty gets.  Every time a decision was made twice, the two
answers drifted, and the drift was invisible because both lanes reported
success:

* 2026-09-02 — the Spark job ignored ``delimiter``: a pipe-delimited
  feed shipped PIPES natively and COMMAS on the heavy lane.
* 2026-09-03 — seven dialect terms became servable natively and the
  heavy lane silently kept the old shape: ``line_terminator: lf`` gave
  LF on one lane and CRLF on the other.
* the same day — the job's filename expander supported only the legacy
  ``{name}/{date}/{ext}`` tokens and "fell back to a safe default on any
  unknown token", so a feed templated ``${COB_PREV_EOM(YYYYMMDD)}`` or
  ``${SEQ(6)}`` was delivered under a DIFFERENT NAME.

Routing is by SIZE, so in every case the biggest, most expensive feed
was the one that got the wrong answer.

Patching each term as it is found does not converge — that is three
fixes for one defect, and a fourth term is one release away.  So this
module is the boundary instead:

    the backend RESOLVES the whole contract; an engine APPLIES it.

An engine that derives a decision is a bug, and
``tests/test_execution_contract_boundary_*`` fails the build on one
rather than waiting for a counterparty to notice.

Refusals happen HERE, at submit, before a pod exists.  The BRD's rule
for this class, verbatim: *a capability the author can DECLARE must be
honoured or REFUSED by every execution lane, never quietly downgraded.*
Until 2026-10-07 the Spark engine REFUSED the CSV terms its own writer
cannot express (QUOTE_NONNUMERIC / QUOTE_NONE, a trailing delimiter).
Since the feed lane contract (K1, docs/FEED_LANE_CONTRACT_2026_10_07.html)
the job renders through the native writer itself (``core/feed/
lane_output.py``, mirrored into the image), so those terms are HONOURED
on both engines and nothing in the CSV dialect refuses any more.
``ContractNotExpressible`` remains the shape of a refusal for the next
term an engine genuinely cannot honour.
"""
from __future__ import annotations

import logging
from typing import Any, Mapping, Optional

logger = logging.getLogger(__name__)

#: Bumped when the shape changes in a way an older engine cannot read.
#: The engine checks it and falls back to its legacy derivation rather
#: than half-applying a contract it does not understand.
CONTRACT_VERSION = 1

#: The engines this contract can be resolved for.  An engine is named,
#: never inferred: what is expressible differs between them, and a
#: refusal must say which engine could not express it.
ENGINE_NATIVE = "native"
ENGINE_SPARK = "spark"
ENGINES = (ENGINE_NATIVE, ENGINE_SPARK)


class ContractNotExpressible(ValueError):
    """A declared capability this engine cannot honour.

    Raised at SUBMIT.  The alternative is a file that differs from its
    contract delivered under a green status, which is the hardest
    failure of all to detect because nothing errors.
    """


def resolve_execution_contract(
    feed_config: Mapping[str, Any],
    *,
    engine: str,
    business_date=None,
    run_id=None,
) -> dict:
    """Every decision the engine needs, already made.

    The returned dict is JSON-safe and travels in the job payload.  It
    is deliberately a plain dict rather than a dataclass: it crosses a
    process boundary into an image that does not import this codebase,
    and a shape that only deserialises correctly here would defeat the
    purpose.

    ``engine`` decides what is EXPRESSIBLE, not what is wanted: the
    contract is the author's, and an engine that cannot honour part of
    it refuses rather than quietly narrowing it.
    """
    if engine not in ENGINES:
        raise ValueError(f"unknown engine {engine!r} — one of {ENGINES}")

    fmt = str(feed_config.get("output_format") or "csv").strip().lower()
    options = feed_config.get("output_options") or {}
    contract: dict = {
        "version": CONTRACT_VERSION,
        "engine": engine,
        "output_format": fmt,
    }

    # ── format dialect ───────────────────────────────────────────────
    if fmt == "csv":
        from core.feed.csv_dialect import resolve as _resolve_dialect
        from core.feed.csv_dialect import to_spark_writer_options
        dialect = _resolve_dialect(options)
        contract["csv"] = {
            "delimiter": dialect["delimiter"],
            "header": dialect["header"],
            "na_rep": dialect["na_rep"],
            "encoding": dialect["encoding"],
            "line_terminator": dialect["line_terminator"],
            "quoting": dialect["quoting"],
            "quotechar": dialect["quotechar"],
            "escapechar": dialect["escapechar"],
            "empty_string_marker": dialect["empty_string_marker"],
            "trailing_delimiter": dialect["trailing_delimiter"],
        }
        if engine == ENGINE_SPARK:
            # 2026-10-07 (feed lane contract, K1): the Spark job no longer
            # writes a CSV with Spark's writer.  It renders on the driver
            # through core.feed.lane_output.CsvRowWriter -- the native
            # renderer's own writer, mirrored byte-identical into the job
            # image -- from the dialect NAMES above, so every term is
            # HONOURED on this engine, the ones Spark's writer could never
            # express (QUOTE_NONNUMERIC / QUOTE_NONE, a trailing delimiter)
            # included; they used to be refused here.  ``writer_options``
            # still travels, for a job image built before the contract
            # (which applies Spark's writer and ignores the rest): the
            # completion webhook names such an image when it reports back.
            writer_options, _spark_writer_cannot = to_spark_writer_options(
                dialect)
            contract["csv"]["writer_options"] = writer_options
    from core.feed.lane_output import LANE_OUTPUT_VERSION
    contract["lane_output_version"] = LANE_OUTPUT_VERSION

    # ── the counterparty filename ────────────────────────────────────
    # Resolved with the real renderer, the real calendar and the real
    # sequence allocation — none of which is reachable from a Spark
    # driver, which is exactly why the ANSWER travels and not the logic.
    contract["filename"] = _resolve_filename(
        feed_config, business_date=business_date, run_id=run_id)

    return contract


def _resolve_filename(feed_config: Mapping[str, Any], *,
                      business_date=None, run_id=None) -> Optional[str]:
    """The counterparty filename, or None when it cannot be rendered.

    None means "unresolved — the engine keeps its own fallback", which
    is what an older submitter effectively sends.  Returning None rather
    than raising is deliberate: a template that cannot render is already
    a native-lane failure with its own error, and turning it into a
    submit refusal here would convert a rendering bug into an outage on
    a path that has a working fallback.
    """
    try:
        from core.spark_k8s.artifact_chain import counterparty_filename
        return counterparty_filename(
            dict(feed_config), business_date=business_date, run_id=run_id)
    except Exception as exc:      # noqa: BLE001 — stated, never silent
        logger.warning(
            "[execution_contract] could not resolve the counterparty "
            "filename for feed %s (%s) — the engine will fall back to its "
            "own token expansion, which may differ from the native lane",
            (feed_config or {}).get("id"), exc)
        return None
