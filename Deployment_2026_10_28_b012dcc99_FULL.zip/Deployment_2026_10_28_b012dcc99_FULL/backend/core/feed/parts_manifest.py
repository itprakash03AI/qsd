"""Parts manifest — the ONE artifact shape every write-ladder rung emits.

2026-08-22, design_starburst_140m §4.2.  A large feed result is no longer
"one giant parquet": it is a SET OF PARTS plus a manifest that records,
per part, exactly how many rows and bytes it holds.  The manifest — not
the parts — is the unit of certification, delivery, resume and
Published-API serving:

  * rung 1 (engine-side unload): the engine writes parts to S3; QS lists
    them, reads their FOOTERS, and the manifest's per-part row counts are
    reconciled against the engine-reported CTAS count before anything is
    certified.
  * rung 3 (native streaming): the part-rotating writer appends a part
    entry after each rotation, so a crashed run leaves a valid PARTIAL
    manifest naming exactly the rows that are already durable.
  * Published API bulk: offset→part mapping comes from the manifest's
    cumulative row counts, so resuming a 140M-row export at row 139M is
    O(part), not O(scan) — and an append-only manifest can be served
    WHILE it is still being built (prefix-version rule below).

Version semantics (why two functions):

  ``version()`` names the EXACT part list (count + rows + a digest over
  the per-part identities).  ``version_at(n)`` names the n-part PREFIX
  of the same list.  Because parts are immutable and the manifest is
  append-only while ``status == "building"``, a cursor minted against an
  older, shorter manifest is still byte-valid against the longer one —
  the serving layer verifies the cursor's version equals
  ``version_at(cursor_n_parts)`` instead of demanding exact equality.
  A REBUILD (new build id) changes every prefix version, so a torn
  splice across two builds is still impossible.

The manifest is truth about files.  ``verify_local_parts`` re-reads the
actual parquet footers and refuses on ANY mismatch — a manifest that
does not describe the bytes on disk is not a manifest, it is a rumour.
"""
from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Tuple
from core.best_effort import note_best_effort

logger = logging.getLogger(__name__)

MANIFEST_NAME = "manifest.json"
PARTIAL_MANIFEST_NAME = "manifest.partial.json"

_MANIFEST_SCHEMA_VERSION = 1


class PartsManifestError(ValueError):
    """A manifest that cannot be trusted: unreadable, unverifiable, or
    provably not describing the files it sits next to."""


@dataclass
class PartInfo:
    """One immutable part.  ``name`` is RELATIVE to the parts dir for
    local parts; ``uri`` carries the absolute location for s3 parts."""
    index: int
    name: str
    rows: int
    bytes: int
    location: str = "local"           # "local" | "s3"
    uri: Optional[str] = None         # s3://bucket/key for location=s3
    # Union-merge support: when a part was produced by a DIFFERENT side
    # of a cross-source union, it may hold a SUBSET of the manifest's
    # unified schema.  ``columns`` names what the part physically has;
    # None means "exactly the manifest schema".  The reader pads the
    # missing columns with typed NULLs and casts where types differ.
    columns: Optional[List[str]] = None
    checksum: Optional[str] = None    # "sha256:..." | "etag:..." | None
    # 2026-10-13 -- a union side that spells a column in another CASE
    # (Starburst ``SNAP_VERSION`` under the S3 engine's ``snap_version``):
    # {name in this part's file: name in the manifest schema}.  The reader
    # renames each batch before it pads, so the side is stacked without a
    # copy; ``columns`` above is in the MANIFEST's names.
    renames: Optional[Dict[str, str]] = None

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "PartInfo":
        return cls(
            index=int(d["index"]), name=str(d["name"]),
            rows=int(d["rows"]), bytes=int(d["bytes"]),
            location=str(d.get("location") or "local"),
            uri=d.get("uri"),
            columns=list(d["columns"]) if d.get("columns") else None,
            checksum=d.get("checksum"),
            renames=dict(d["renames"]) if d.get("renames") else None,
        )


def _schema_to_b64(schema) -> str:
    """Serialize a pyarrow schema losslessly (IPC bytes, base64)."""
    return base64.b64encode(schema.serialize().to_pybytes()).decode("ascii")


def _schema_from_b64(b64: str):
    import pyarrow as pa
    return pa.ipc.read_schema(pa.BufferReader(base64.b64decode(b64)))


@dataclass
class PartsManifest:
    """The manifest.  ``schema_b64`` is the UNIFIED arrow schema every
    reader presents, regardless of which part a batch came from."""
    parts: List[PartInfo] = field(default_factory=list)
    schema_b64: str = ""
    total_rows: int = 0
    total_bytes: int = 0
    status: str = "building"          # "building" | "complete"
    sql_sha256: str = ""
    build_id: str = ""                # distinguishes REBUILDS of the same dataset
    created_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None
    source: Dict[str, Any] = field(default_factory=dict)  # rung, connector_type, query ids…
    #: TRANSIENT delivery declaration (2026-09-03, FR-ART-06): the names
    #: of the files the artifact chain will actually hand a transport,
    #: set by ``prepare_artifact_chain`` AFTER packaging / compression /
    #: encryption rename the staged parts.  Deliberately NOT serialized
    #: (``to_dict``/``from_dict`` skip it) and NOT part of ``version()``
    #: — it is not identity; it exists so the hop runner's plaintext
    #: tripwire judges the REAL deliverables, not the Spark job's
    #: internal part names.
    delivered_names: Optional[List[str]] = None

    # ── identity ─────────────────────────────────────────────────────

    def _prefix_digest(self, n: int) -> str:
        h = hashlib.sha256()
        h.update(self.build_id.encode("utf-8"))
        h.update(b"|")
        h.update(self.sql_sha256.encode("utf-8"))
        for p in self.parts[:n]:
            h.update(f"|{p.name}:{p.rows}:{p.bytes}".encode("utf-8"))
        return h.hexdigest()[:16]

    def version_at(self, n_parts: int) -> str:
        n = max(0, min(int(n_parts), len(self.parts)))
        rows = sum(p.rows for p in self.parts[:n])
        return f"parts:{n}:{rows}:{self._prefix_digest(n)}"

    def version(self) -> str:
        return self.version_at(len(self.parts))

    # ── row arithmetic ───────────────────────────────────────────────

    def cumulative_rows(self) -> List[int]:
        """cumulative_rows()[i] == rows BEFORE part i."""
        out, acc = [], 0
        for p in self.parts:
            out.append(acc)
            acc += p.rows
        return out

    def locate(self, offset: int) -> Tuple[int, int]:
        """(part_index, rows_to_skip_within_part) for global row ``offset``.

        ``offset`` past the end returns (len(parts), 0) — the exhausted
        position, so callers can uniformly test ``part_index >= len``.
        """
        off = max(0, int(offset))
        acc = 0
        for i, p in enumerate(self.parts):
            if acc + p.rows > off:
                return i, off - acc
            acc += p.rows
        return len(self.parts), 0

    def arrow_schema(self):
        if not self.schema_b64:
            raise PartsManifestError("manifest carries no schema")
        return _schema_from_b64(self.schema_b64)

    def columns(self) -> List[str]:
        return [f.name for f in self.arrow_schema()]

    # ── (de)serialization ────────────────────────────────────────────

    def to_dict(self) -> dict:
        return {
            "_schema_version": _MANIFEST_SCHEMA_VERSION,
            "parts": [p.to_dict() for p in self.parts],
            "schema_b64": self.schema_b64,
            "total_rows": int(self.total_rows),
            "total_bytes": int(self.total_bytes),
            "status": self.status,
            "sql_sha256": self.sql_sha256,
            "build_id": self.build_id,
            "created_at": self.created_at,
            "completed_at": self.completed_at,
            "source": self.source,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "PartsManifest":
        m = cls(
            parts=[PartInfo.from_dict(p) for p in (d.get("parts") or [])],
            schema_b64=str(d.get("schema_b64") or ""),
            total_rows=int(d.get("total_rows") or 0),
            total_bytes=int(d.get("total_bytes") or 0),
            status=str(d.get("status") or "building"),
            sql_sha256=str(d.get("sql_sha256") or ""),
            build_id=str(d.get("build_id") or ""),
            created_at=float(d.get("created_at") or 0.0),
            completed_at=d.get("completed_at"),
            source=dict(d.get("source") or {}),
        )
        # Refuse a manifest whose own totals disagree with its own parts —
        # a self-inconsistent manifest is corruption, not data.
        _sum = sum(p.rows for p in m.parts)
        if int(m.total_rows) != _sum:
            raise PartsManifestError(
                f"manifest total_rows={m.total_rows} but its parts sum to "
                f"{_sum} — refusing a self-inconsistent manifest")
        return m

    # ── persistence (atomic; tmp + replace) ──────────────────────────

    def write(self, parts_dir: str | Path, *, partial: bool = False) -> Path:
        parts_dir = Path(parts_dir)
        parts_dir.mkdir(parents=True, exist_ok=True)
        name = PARTIAL_MANIFEST_NAME if partial else MANIFEST_NAME
        target = parts_dir / name
        tmp = parts_dir / (name + ".tmp")
        tmp.write_text(json.dumps(self.to_dict(), indent=1), encoding="utf-8")
        os.replace(str(tmp), str(target))
        return target

    def finalize(self, parts_dir: str | Path) -> Path:
        """building → complete: write manifest.json, remove the partial."""
        self.status = "complete"
        self.completed_at = time.time()
        out = self.write(parts_dir, partial=False)
        try:
            (Path(parts_dir) / PARTIAL_MANIFEST_NAME).unlink(missing_ok=True)
        except OSError as exc:
            logger.warning("[parts] could not remove partial manifest in %s: %s",
                           parts_dir, exc)
        return out


def is_parts_dir(path: str | Path) -> bool:
    p = Path(path)
    return p.is_dir() and ((p / MANIFEST_NAME).is_file()
                           or (p / PARTIAL_MANIFEST_NAME).is_file())


def load_manifest(parts_dir: str | Path,
                  *, allow_partial: bool = False) -> Tuple[PartsManifest, Path]:
    """Read the manifest.  A COMPLETE manifest always wins; the partial
    one is only admissible when the caller explicitly opted into serving
    an in-flight build (``allow_partial=True``)."""
    parts_dir = Path(parts_dir)
    complete = parts_dir / MANIFEST_NAME
    partial = parts_dir / PARTIAL_MANIFEST_NAME
    src = complete if complete.is_file() else (
        partial if (allow_partial and partial.is_file()) else None)
    if src is None:
        raise PartsManifestError(
            f"no {'manifest' if not allow_partial else 'manifest or partial manifest'} "
            f"in {parts_dir}")
    try:
        data = json.loads(src.read_text(encoding="utf-8"))
    except Exception as exc:
        raise PartsManifestError(f"unreadable manifest {src}: {exc}") from exc
    return PartsManifest.from_dict(data), src


def _part_disagreement(name: str, *, footer_rows, manifest_rows):
    """Does this part hold the rows its manifest entry claims?

    Returns ``(available, reason)``.  ``available`` is False when the
    completeness ladder could not be consulted at all, so the caller
    falls back to its own comparison and the refusal can never be LOST.
    ``reason`` is None when the part agrees, and the claim's own words
    when it does not.

    The comparison lives in ``completeness.part_claim`` and is consumed
    here: it is COMPLETENESS vocabulary, not parquet vocabulary, and the
    two used to be separate implementations of one sentence — this one
    refusing, that one producing an advisory Claim nobody built.
    Refusal is the right posture on this lane, so the claim decides
    WHETHER and the caller raises.

    VERIFIED is the only outcome that passes.  "unverifiable" is its own
    state and never folds into success; here, where a number that cannot
    be reproduced must not be certified OR served, it refuses like a
    mismatch.  The constant is imported beside the function rather than
    copied as a literal — a second spelling of "verified" is a second
    thing free to drift.
    """
    try:
        from core.feed.completeness import VERIFIED, part_claim
    except Exception:
        return False, None
    try:
        claim = part_claim(name, footer_rows=footer_rows,
                           manifest_rows=manifest_rows)
    except Exception:
        return False, None
    return True, (None if claim.status == VERIFIED else claim.reason)


def verify_local_parts(parts_dir: str | Path, manifest: PartsManifest) -> None:
    """Re-read every LOCAL part's parquet footer and refuse on mismatch.

    This is the completeness backstop: the manifest's numbers must be
    reproducible from the bytes on disk, independently, every time we
    are about to certify or serve them.  Raises PartsManifestError on
    the first discrepancy; s3-resident parts are skipped here (their
    verification happened at listing time against the engine count).
    """
    import pyarrow.parquet as pq
    parts_dir = Path(parts_dir)
    for p in manifest.parts:
        if p.location != "local":
            continue
        fp = parts_dir / p.name
        if not fp.is_file():
            raise PartsManifestError(f"part {p.name} missing from {parts_dir}")
        size = fp.stat().st_size
        if size != p.bytes:
            raise PartsManifestError(
                f"part {p.name}: manifest says {p.bytes} bytes, file has {size}")
        rows = pq.ParquetFile(str(fp)).metadata.num_rows
        # The footer-vs-manifest comparison is COMPLETENESS vocabulary,
        # not parquet vocabulary, so it is expressed once — in
        # completeness.part_claim — and consumed here.  The two used to
        # be separate implementations of the same sentence: this one
        # refusing, that one producing an advisory Claim nobody built.
        # Refusal is the right posture on this lane (a manifest whose
        # numbers do not reproduce must not be certified OR served), so
        # the claim decides WHETHER, and this raises.
        available, disagreement = _part_disagreement(
            p.name, footer_rows=rows, manifest_rows=p.rows)
        if available:
            if disagreement:
                raise PartsManifestError(disagreement)
        elif rows != p.rows:
            raise PartsManifestError(
                f"part {p.name}: manifest says {p.rows} rows, "
                f"footer says {rows}")


# ── The chained reader ───────────────────────────────────────────────
#
# One implementation of "iterate a parts dataset with O(one batch)
# memory", shared by the feed renderers and the Published-API bulk
# server.  Semantics mirror api/published_views/bulk.iter_dataset_batches
# (offset skips whole parts by manifest arithmetic, then whole row
# groups by footer arithmetic; max_rows<=0 means unbounded).


def _pad_batch_to_schema(batch, target_schema):
    """Project ``batch`` onto ``target_schema`` by name: missing columns
    become typed NULLs, matching columns are cast when the type differs.

    A cast that cannot be performed raises LOUDLY — silently substituting
    nulls for uncastable values would be row corruption with a 200.
    """
    import pyarrow as pa
    import pyarrow.compute as pc
    if batch.schema.equals(target_schema):
        return batch
    n = batch.num_rows
    by_name = {batch.schema.field(i).name: batch.column(i)
               for i in range(batch.num_columns)}
    arrays = []
    for f in target_schema:
        col = by_name.get(f.name)
        if col is None:
            arrays.append(pa.nulls(n, type=f.type))
        elif col.type.equals(f.type):
            arrays.append(col)
        else:
            arrays.append(pc.cast(col, f.type))   # raises on lossy/incompatible
    return pa.RecordBatch.from_arrays(arrays, schema=target_schema)


def iter_manifest_batches(
    parts_dir: str | Path,
    manifest: PartsManifest,
    *,
    columns: Optional[List[str]] = None,
    offset: int = 0,
    max_rows: int = 0,
    batch_rows: int = 65536,
) -> Iterator[Any]:
    """Yield ``pyarrow.RecordBatch`` across the manifest's LOCAL parts.

    Every batch is presented in the manifest's UNIFIED schema (or the
    ``columns`` projection of it), regardless of which part it came
    from — union-merged parts are padded/cast per batch.
    """
    import pyarrow.parquet as pq

    parts_dir = Path(parts_dir)
    target_schema = manifest.arrow_schema()
    if columns:
        known = {f.name for f in target_schema}
        missing = [c for c in columns if c not in known]
        if missing:
            raise PartsManifestError(
                f"unknown column(s) {missing}; dataset has {sorted(known)}")
        import pyarrow as pa
        target_schema = pa.schema([target_schema.field(c) for c in columns])

    remaining = None if int(max_rows) <= 0 else max(0, int(max_rows))
    if remaining == 0:
        return
    start_part, within = manifest.locate(offset)

    for pi in range(start_part, len(manifest.parts)):
        part = manifest.parts[pi]
        if part.location != "local":
            raise PartsManifestError(
                f"part {part.name} is {part.location}-resident; materialize "
                f"parts locally before serving rows from them")
        try:
            pf = pq.ParquetFile(str(parts_dir / part.name))
        except FileNotFoundError as exc:
            # 2026-10-11 -- a part the manifest still references is GONE.
            # The reader names it as such (the part, the parts dir, the rung
            # that built it -- a cross-source zero-copy union's parts are
            # the two SIDES moved in), because the bare "[Errno 2] No such
            # file or directory: /app/..." with the path redacted on the
            # record cannot be told from a vanished data file anywhere else.
            # The names travel apart from the path the sanitiser redacts.
            _src = manifest.source if isinstance(manifest.source, dict) else {}
            raise FileNotFoundError(
                f"part '{part.name}' of the parts manifest in "
                f"'{parts_dir.name}' is missing: the manifest (rung "
                f"{_src.get('rung') or 'unknown'}, build {manifest.build_id}, "
                f"{len(manifest.parts)} part(s), {manifest.total_rows} rows) "
                f"still references it, so the file was removed from under "
                f"the run after the manifest was written ({exc})") from exc
        try:
            md = pf.metadata
            # Row-group skip inside the FIRST part only.
            skip = within if pi == start_part else 0
            start_group, consumed = 0, 0
            while start_group < md.num_row_groups:
                rg_rows = md.row_group(start_group).num_rows
                if consumed + rg_rows <= skip:
                    consumed += rg_rows
                    start_group += 1
                else:
                    break
            if start_group >= md.num_row_groups:
                continue
            trim = skip - consumed
            ren = part.renames or {}
            part_cols = None
            if columns is not None:
                have = set(part.columns) if part.columns is not None else \
                    {ren.get(f.name, f.name) for f in pf.schema_arrow}
                physical = {v: k for k, v in ren.items()}
                part_cols = [physical.get(c, c) for c in columns if c in have]
            for batch in pf.iter_batches(batch_size=int(batch_rows),
                                         columns=part_cols,
                                         row_groups=list(range(start_group,
                                                               md.num_row_groups))):
                if trim:
                    if batch.num_rows <= trim:
                        trim -= batch.num_rows
                        continue
                    batch = batch.slice(trim)
                    trim = 0
                if remaining is not None and batch.num_rows > remaining:
                    batch = batch.slice(0, remaining)
                if batch.num_rows:
                    if ren:
                        batch = batch.rename_columns(
                            [ren.get(n, n) for n in batch.schema.names])
                    yield _pad_batch_to_schema(batch, target_schema)
                    if remaining is not None:
                        remaining -= batch.num_rows
                        if remaining <= 0:
                            return
        finally:
            try:
                pf.close()
            except Exception as _be_exc:
                note_best_effort("pf.close()", _be_exc,
                                 logger=logger)


def read_result_table(path: str | Path):
    """TEST SEAM (declared 2026-09-03) -- production must NOT call this.
    A ``pyarrow.Table`` from a single result parquet OR a parts dir.

    Convenience for SMALL results (tests, previews, sanity checks): it
    materialises the whole table, which is exactly what the streaming
    readers above exist to avoid — never use it on the large-feed path.
    """
    import pyarrow as pa
    import pyarrow.parquet as pq
    p = Path(path)
    if p.is_file():
        return pq.read_table(str(p))
    manifest, _src = load_manifest(p)
    batches = list(iter_manifest_batches(p, manifest))
    if not batches:
        return manifest.arrow_schema().empty_table()
    return pa.Table.from_batches(batches)


def sql_sha256(sql: str) -> str:
    return hashlib.sha256((sql or "").encode("utf-8")).hexdigest()


__all__ = [
    "MANIFEST_NAME", "PARTIAL_MANIFEST_NAME",
    "PartInfo", "PartsManifest", "PartsManifestError",
    "is_parts_dir", "load_manifest", "verify_local_parts",
    "iter_manifest_batches", "read_result_table", "sql_sha256",
]
