"""
Foundation P — definition pinning + build identity (BRD 2026-09-02).

Implements FR-RUN-01/03, FR-OPS-05 and FR-GOV-01:

* ``new_build_id()`` — a short, sortable, opaque attempt id.  Run identity
  becomes ``(feed_config_id, business_date, build_id)``; a re-run gets a
  NEW build id so "which attempt produced this file?" is answerable.
* ``snapshot_definition()`` — taken at CLAIM time: the feed definition
  (volatile/runtime fields stripped), the git commit it was deployed from
  and the container image tag.  Commit and image tag MAY be absent today
  (there is no deploy stamp yet) — the fields are modelled, the values are
  never invented: absent means ``None``, never a guess.
* ``pin_run_at_claim()`` — persists the snapshot (deduplicated per feed in
  ``feed_definition_versions``) and stamps the run row.  Persistence is
  fail-open for the RUN (a 02:00 pin-write failure must not kill the
  feed), but execution correctness is preserved regardless: the in-memory
  snapshot is returned and is what the caller must execute, so a
  definition deployed mid-run can never reach a running run.
* ``resolve_pinned()`` — a run always executes what it was admitted with.
  A run with no pin (pre-Foundation-P row, unwired trigger path) still
  executes on the LIVE config and SAYS SO at INFO — never silently.
* ``resolve_definition_for_rerun()`` — a re-run of an old business date
  uses the definition that was live FOR THAT DATE (the pin of the most
  recent run of that feed+date), not today's (FR-GOV-01).

Deliberately no imports from feed_engine / queue_worker / pipeline —
those workstreams call INTO this module, never the reverse.
"""

import copy
import hashlib
import json
import logging
import os
import secrets
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger(__name__)

# Env names a deploy MAY stamp onto the pod.  Absent → None (the pin
# honestly records "unknown"), never a fabricated value.
GIT_COMMIT_ENV = "QS_GIT_COMMIT"
IMAGE_TAG_ENV = "QS_IMAGE_TAG"

#: Fields of a feed_configs row that are OPERATIONAL STATE, not definition.
#: They change as a side effect of running (or of the scheduler), so two
#: pins of an untouched feed must not mint two versions because a counter
#: ticked.  Keys starting with ``_`` (runtime stash: ``_feed_run``,
#: ``_triggered_by_user``, ``_consumer_overrides``…) are always stripped.
VOLATILE_KEYS = frozenset({
    "run_count",
    "last_row_count",
    "last_execution_id",
    "next_run_at",
    "created_at",
    "updated_at",
    "apscheduler_job_id",
    # joined/derived view data, not part of the definition proper
    "feed_calendars",
})

# build_id: ``YYYYMMDDTHHMMSSffffff-xxxxxx`` — 28 chars.
#   * sortable: fixed-width UTC timestamp prefix orders attempts in time;
#   * short:    fits VARCHAR(40) with headroom;
#   * opaque:   consumers must not parse it — the 6 random hex chars make
#     equality the only supported operation besides ordering.
_BUILD_ID_MAX_LEN = 40


def new_build_id(now: datetime | None = None) -> str:
    """Mint a build id (FR-RUN-01).  ``now`` is injectable for tests only."""
    ts = (now or datetime.now(timezone.utc)).strftime("%Y%m%dT%H%M%S%f")
    bid = f"{ts}-{secrets.token_hex(3)}"
    # Defensive: the format above is 28 chars; the column is VARCHAR(40).
    return bid[:_BUILD_ID_MAX_LEN]


def canonical_definition(feed_config: dict[str, Any]) -> dict[str, Any]:
    """The pinnable subset of a feed config: definition, not run state."""
    out: dict[str, Any] = {}
    for key, value in (feed_config or {}).items():
        if key.startswith("_") or key in VOLATILE_KEYS:
            continue
        out[key] = copy.deepcopy(value)
    return out


def definition_hash(definition: dict[str, Any]) -> str:
    """Stable content hash — key order and datetime repr must not matter."""
    payload = json.dumps(definition, sort_keys=True, default=str,
                         separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def snapshot_definition(feed_config: dict[str, Any], *,
                        image_tag: str | None = None,
                        commit: str | None = None) -> dict[str, Any]:
    """Snapshot a feed definition at claim time (FR-RUN-03).

    Returns ``{"definition", "definition_hash", "git_commit",
    "image_tag"}``.  Explicit arguments win; otherwise the deploy-stamp
    env vars are consulted; otherwise the value is honestly ``None``.
    """
    definition = canonical_definition(feed_config)
    if commit is None:
        commit = os.environ.get(GIT_COMMIT_ENV) or None
    if image_tag is None:
        image_tag = os.environ.get(IMAGE_TAG_ENV) or None
    return {
        "definition": definition,
        "definition_hash": definition_hash(definition),
        "git_commit": commit,
        "image_tag": image_tag,
    }


def pin_run_at_claim(dao, run_row: dict[str, Any],
                     feed_config: dict[str, Any], *,
                     image_tag: str | None = None,
                     commit: str | None = None,
                     build_id: str | None = None,
                     pinned_by: str | None = None) -> dict[str, Any]:
    """Pin a claimed run: snapshot + version row + stamp the run row.

    Returns ``{"build_id", "version_id", "definition", "definition_hash",
    "git_commit", "image_tag", "persisted"}``.  The returned
    ``definition`` is what the caller MUST execute — even when
    persistence fails (``persisted=False``, logged at ERROR: the audit
    row is lost, the execution correctness is not).
    """
    snap = snapshot_definition(feed_config, image_tag=image_tag,
                               commit=commit)
    bid = build_id or (run_row or {}).get("build_id") or new_build_id()
    run_id = (run_row or {}).get("id")
    feed_id = (feed_config or {}).get("id") or (run_row or {}).get("feed_config_id")

    version_id = None
    persisted = False
    try:
        ver = dao.pin_feed_definition(int(feed_id), snap, created_by=pinned_by)
        version_id = ver.get("id") if ver else None
    except Exception as exc:  # noqa: BLE001 — deliberate fail-open (feed must still run)
        logger.error(
            "[pinning] could not persist definition version for feed %s "
            "run %s: %s — the run EXECUTES the in-memory snapshot it was "
            "admitted with, but the audit row is missing (FR-GOV-01 audit "
            "hole for this run)", feed_id, run_id, exc)
    if version_id is not None and run_id is not None:
        try:
            updated = dao.pin_feed_run(
                int(run_id), build_id=bid, version_id=version_id,
                git_commit=snap["git_commit"], image_tag=snap["image_tag"])
            persisted = updated is not None
        except Exception as exc:  # noqa: BLE001 — deliberate fail-open (feed must still run)
            logger.error(
                "[pinning] could not stamp run %s with pin (version %s): %s",
                run_id, version_id, exc)
    return {
        "build_id": bid,
        "version_id": version_id,
        "definition": snap["definition"],
        "definition_hash": snap["definition_hash"],
        "git_commit": snap["git_commit"],
        "image_tag": snap["image_tag"],
        "persisted": persisted,
    }


def resolve_pinned(run_row: dict[str, Any] | None, *,
                   dao=None,
                   live_config: dict[str, Any] | None = None,
                   ) -> tuple[dict[str, Any] | None, str]:
    """What should this run execute?  ``(config, source)``.

    ``source`` is ``"pinned"`` when the run's claim-time snapshot was
    loaded, ``"live"`` otherwise.  The live fallback is NEVER silent:
    * no pin at all → INFO (legitimate: pre-Foundation-P row or a
      trigger path not yet wired);
    * a pin that CANNOT be resolved → ERROR (the run promised a
      definition it can no longer produce — FR-GOV-01 is violated for
      this run and the log says so).
    """
    row = run_row or {}
    version_id = row.get("pinned_version_id")
    if version_id and dao is not None:
        ver = None
        try:
            ver = dao.get_feed_definition_version(int(version_id))
        except Exception as exc:  # noqa: BLE001 — fail-open, but LOUD (ERROR below)
            logger.error(
                "[pinning] failed loading definition version %s for run %s: %s",
                version_id, row.get("id"), exc)
        if ver and isinstance(ver.get("definition"), dict):
            return dict(ver["definition"]), "pinned"
        logger.error(
            "[pinning] run %s (build %s) is pinned to definition version %s "
            "which could not be resolved — falling back to LIVE config; this "
            "run may execute a DIFFERENT definition than it was admitted "
            "with (FR-GOV-01 violated for this run)",
            row.get("id"), row.get("build_id"), version_id)
    else:
        logger.info(
            "[pinning] run %s has no pinned definition — executing LIVE "
            "config (pre-Foundation-P row or unwired trigger path); a "
            "definition change since admission WILL affect this run",
            row.get("id"))
    return (dict(live_config) if live_config is not None else None), "live"


def _deliveries(dao, feed_config_id: int, business_date):
    """The date's COMPLETED executions, newest first; None = cannot tell
    (no reader, a read failure -- said)."""
    reader = getattr(dao, "list_feed_executions_for_date", None)
    if reader is None:
        return None
    try:
        done = reader([int(feed_config_id)], business_date) or {}
    except Exception as exc:  # noqa: BLE001 -- unknown keeps the pin, said
        logger.warning("[pinning] deliveries of feed %s date %s unreadable (%s) -- "
                       "keeping the pinned definition", feed_config_id, business_date, exc)
        return None
    return list(done.get(int(feed_config_id)) or [])


def _never_delivered(dao, feed_config_id: int, business_date) -> bool:
    """True only when the date is KNOWN to have no completed execution.
    Unknown (no reader, a read failure) keeps the pin -- reproducing is the
    safe side when we cannot tell."""
    dels = _deliveries(dao, feed_config_id, business_date)
    return dels is not None and not dels


def resolve_definition_for_rerun(dao, feed_config_id: int, business_date, *,
                                 live_config: dict[str, Any] | None = None,
                                 ) -> tuple[dict[str, Any] | None, str,
                                            str | None]:
    """Definition for a RE-RUN of an old business date (FR-GOV-01).

    Returns ``(config, source, prior_build_id)``.  Uses the pin of the
    most recent run of ``(feed, business_date)`` — the definition that
    was actually live FOR THAT DATE — never today's, unless no pinned
    prior run exists (then live, said at INFO) or the date was never
    DELIVERED (``live_never_delivered``: nothing to reproduce).
    """
    prior = None
    try:
        prior = dao.find_pinned_run_for_date(int(feed_config_id),
                                             business_date)
    except Exception as exc:  # noqa: BLE001 — fail-open, but LOUD (ERROR below)
        logger.error(
            "[pinning] lookup of prior pinned run failed for feed %s date "
            "%s: %s", feed_config_id, business_date, exc)
    if prior and _never_delivered(dao, feed_config_id, business_date):
        # 2026-10-13 -- the pin exists to REPRODUCE the file the receiver
        # got.  A date that never delivered has no such file: replaying the
        # definition its FAILED attempt pinned only repeats the failure the
        # author has since fixed (found live: a feed saved with a broken
        # source, corrected, re-run -> the same refusal, forever).
        logger.info(
            "[pinning] feed %s date %s was never delivered -- nothing to "
            "reproduce, the re-run executes the LIVE definition (the failed "
            "attempt's build %s is not replayed)", feed_config_id,
            business_date, prior.get("build_id"))
        return (dict(live_config) if live_config is not None else None,
                "live_never_delivered", prior.get("build_id"))
    if prior:
        # 2026-10-13 -- reproduce what was DELIVERED: the newest completed
        # execution's own pin, not the run row's FIRST pin.  A run whose
        # first attempts failed under a broken definition and then delivered
        # under the corrected one kept the broken pin on its row, and a
        # re-send replayed the broken definition (found live, Starburst road).
        dels = _deliveries(dao, feed_config_id, business_date) or []
        last = next((e for e in dels if e.get("pinned_version_id")), None)
        if last and last.get("pinned_version_id") != prior.get("pinned_version_id"):
            prior = dict(prior, pinned_version_id=last["pinned_version_id"],
                         build_id=last.get("build_id") or prior.get("build_id"))
        cfg, source = resolve_pinned(prior, dao=dao, live_config=live_config)
        if source == "pinned":
            return cfg, "pinned", prior.get("build_id")
        return cfg, source, prior.get("build_id")
    logger.info(
        "[pinning] no pinned prior run for feed %s date %s — re-run will "
        "execute the LIVE definition", feed_config_id, business_date)
    return (dict(live_config) if live_config is not None else None,
            "live", None)
