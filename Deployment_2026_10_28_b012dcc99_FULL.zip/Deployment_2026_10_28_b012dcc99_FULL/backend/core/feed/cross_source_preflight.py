"""Cross-source feed preflight — THE compatibility chokepoint for
cross-connection feeds (2026-08-04 audit: "does feed gen work for cross
source... aws s3 and hive s3?").

One decision point, called from BOTH:
  * config time — api/feed_api.create_feed / update_feed, so a feed that
    cannot work is refused with a red message when the user SAVES it,
    not with a stack trace when the scheduled run fires at 3 AM;
  * run time  — core/feed_engine._run_cross_source_native_query, for
    feeds saved before the save-time gate existed and for referenced
    sources edited into a broken shape after the feed was saved.

Why this is safe to share: the feed engine materializes each side with
its OWN connection, its OWN pooled DuckDB session and its OWN access
mode (api/data_grid_api.py:1074 resolves get_s3_access_mode per
conn_config; the pool at data_grid_api.py:967 is keyed by
connection_id).  There is therefore no "incompatible pair" of S3 access
modes — AWS-native × on-prem-presigned works by construction (verified
by execution 2026-08-04).  What DOES break feeds is configuration shape:
missing connections, unresolvable secondary SQL, half-inherited
cross-source config, invalid join keys, one SQL string reused across
different dialects.  Those are exactly what the checks below catch.

Plugin shape (repo convention — core/file_formats/, FILTER_OPERATORS):
each check is a function registered via @_check; adding a new rule is
one decorated function, not an if/elif chain at every call site.

Verdict semantics:
  * ERROR   → the feed CANNOT produce the configured result.  Save is
              refused (HTTP 400); a run raises before touching data.
              Never silently degrade to single-source: emitting half the
              data and certifying it COMPLETE is the worst outcome this
              product has (UNKNOWN = UNSAFE).
  * WARNING → likely to fail or surprise, but can work — surfaced to the
              user at save time, logged at run time, never blocks.
  * INFO    → operator context (e.g. resolved access modes).

Observability: every preflight emits ONE greppable line tagged
``[feed-crosssource]`` carrying both connection ids, both resolved
access modes, source_type and combine_mode — so "why did this feed
misbehave" is answerable from logs without a repro.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Optional

logger = logging.getLogger(__name__)

SEVERITY_ERROR = "error"
SEVERITY_WARNING = "warning"
SEVERITY_INFO = "info"

# Connection families.  ``sql_connector`` mirrors the vocabulary in
# feed_engine._execute_duckdb_query's _SQL_CONNECTOR_TYPES (keep in sync).
_S3_FAMILY = frozenset({"s3", "aws_s3"})
_SQL_CONNECTOR_FAMILY = frozenset({
    "trino", "starburst", "snowflake", "databricks", "oracle", "athena",
})
_LOCAL_FAMILY = frozenset({"", "local", "parquet"})


@dataclass
class SideProfile:
    """Everything the checks (and the log line) need to know about one
    side of a cross-source feed."""
    role: str                                  # "primary" | "secondary"
    connection_id: Optional[int] = None
    connection_name: str = ""
    connection_type: str = ""
    connection_found: bool = False
    family: str = "unknown"                    # s3 | sql_connector | local | unknown
    access_mode: Optional[str] = None          # native | presigned | None (non-S3)
    dialect: str = ""
    source_type: str = ""
    source_id: Optional[int] = None
    sql: str = ""
    sql_status: str = ""                       # ok | not_found | inactive | ...
    sql_message: str = ""

    def describe(self) -> str:
        mode = f", access_mode={self.access_mode}" if self.access_mode else ""
        name = f" '{self.connection_name}'" if self.connection_name else ""
        return (f"connection {self.connection_id}{name} "
                f"({self.connection_type or 'unknown'}{mode})")


@dataclass
class PreflightIssue:
    severity: str
    code: str
    message: str

    def to_dict(self) -> Dict[str, str]:
        return {"severity": self.severity, "code": self.code,
                "message": self.message}


@dataclass
class PreflightResult:
    feed_id: Any
    feed_name: str
    combine_mode: str
    primary: SideProfile
    secondary: SideProfile
    issues: List[PreflightIssue] = field(default_factory=list)

    @property
    def errors(self) -> List[PreflightIssue]:
        return [i for i in self.issues if i.severity == SEVERITY_ERROR]

    @property
    def warnings(self) -> List[PreflightIssue]:
        return [i for i in self.issues if i.severity == SEVERITY_WARNING]

    @property
    def ok(self) -> bool:
        return not self.errors

    def format_report(self) -> str:
        """Operator-facing refusal message: what is wrong, on which side,
        and what to change — modeled on core/spill_admission.format_refusal
        (state both sides of the problem, name the actions)."""
        head = (
            f"Cross-source preflight for feed "
            f"'{self.feed_name or self.feed_id}': "
            f"primary {self.primary.describe()} × "
            f"secondary {self.secondary.describe()}, "
            f"combine_mode={self.combine_mode or 'union'}."
        )
        lines = [head]
        for issue in self.issues:
            if issue.severity in (SEVERITY_ERROR, SEVERITY_WARNING):
                lines.append(f"  [{issue.severity.upper()}/{issue.code}] "
                             f"{issue.message}")
        return "\n".join(lines)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ok": self.ok,
            "combine_mode": self.combine_mode,
            "primary": {
                "connection_id": self.primary.connection_id,
                "connection_name": self.primary.connection_name,
                "connection_type": self.primary.connection_type,
                "access_mode": self.primary.access_mode,
                "source_type": self.primary.source_type,
                "source_id": self.primary.source_id,
            },
            "secondary": {
                "connection_id": self.secondary.connection_id,
                "connection_name": self.secondary.connection_name,
                "connection_type": self.secondary.connection_type,
                "access_mode": self.secondary.access_mode,
                "source_type": self.secondary.source_type,
                "source_id": self.secondary.source_id,
            },
            "issues": [i.to_dict() for i in self.issues],
        }


@dataclass
class _Ctx:
    """Check input — assembled once, handed to every registered check."""
    db_manager: Any
    feed_config: Dict[str, Any]
    primary: SideProfile
    secondary: SideProfile
    combine_mode: str
    # Referenced saved_query row (primary source), when source_type is
    # saved_query — lets checks inspect the saved secondary shape without
    # each re-fetching it.
    saved_query_row: Optional[Dict[str, Any]] = None
    # True when the secondary side reuses the primary's source (no
    # explicit secondary_source_type/_id and no distinct secondary shape
    # on the referenced source) — i.e. the SAME SQL runs on both sides.
    secondary_reuses_primary_sql: bool = True


_CHECKS: List[Callable[[_Ctx], Iterable[PreflightIssue]]] = []


def _check(fn: Callable[[_Ctx], Iterable[PreflightIssue]]):
    """Register a preflight check.  Plugin point: new rules are one
    decorated function."""
    _CHECKS.append(fn)
    return fn


# ── Profile assembly ─────────────────────────────────────────────────────


def _family_of(connection_type: str) -> str:
    t = (connection_type or "").lower()
    if t in _S3_FAMILY:
        return "s3"
    if t in _SQL_CONNECTOR_FAMILY:
        return "sql_connector"
    if t in _LOCAL_FAMILY:
        return "local"
    return "unknown"


def _profile_side(db_manager: Any, role: str, source_type: str,
                  source_id: Any, connection_id: Optional[int],
                  query_params: Optional[dict]) -> SideProfile:
    """Build one side's profile.  Read-only; uses the masked
    get_connection (access-mode fields — path_style / endpoint_url /
    s3_access_mode — are never masked, and decrypted credentials are not
    needed to classify a connection)."""
    from core.feed_sql_resolver import _resolve_one_side, _dialect_for

    resolved = _resolve_one_side(
        db_manager,
        source_type=source_type or "",
        source_id=source_id,
        connection_id_override=connection_id,
        query_params=query_params,
    )
    prof = SideProfile(
        role=role,
        connection_id=resolved.get("connection_id"),
        source_type=source_type or "",
        source_id=source_id,
        sql=resolved.get("sql") or "",
        sql_status=resolved.get("status") or "",
        sql_message=resolved.get("message") or "",
    )
    conn = None
    if prof.connection_id:
        try:
            conn = db_manager.get_connection(prof.connection_id)
        except Exception as exc:
            logger.debug("[feed-crosssource] connection %s lookup failed: %s",
                         prof.connection_id, exc)
            conn = None
    if conn:
        prof.connection_found = True
        prof.connection_name = conn.get("name") or ""
        prof.connection_type = (conn.get("connection_type")
                                or (conn.get("config") or {}).get("type", ""))
        prof.family = _family_of(prof.connection_type)
        if prof.family == "s3":
            try:
                from core.s3_utilities import get_s3_access_mode
                prof.access_mode = get_s3_access_mode(conn.get("config") or {})
            except Exception as exc:
                logger.debug("[feed-crosssource] access-mode resolve failed "
                             "for conn %s: %s", prof.connection_id, exc)
    prof.dialect = _dialect_for(prof.connection_type)
    return prof


# ── Checks (registry) ────────────────────────────────────────────────────


@_check
def _check_connections_exist(ctx: _Ctx) -> Iterable[PreflightIssue]:
    for prof in (ctx.primary, ctx.secondary):
        if not prof.connection_id:
            yield PreflightIssue(
                SEVERITY_ERROR, "CONN_UNSET",
                f"The {prof.role} side has no connection: neither the feed "
                f"nor the referenced {prof.source_type or 'source'} names a "
                f"connection_id. Fix: set "
                f"{'connection_id' if prof.role == 'primary' else 'secondary_connection_id'}"
                f" on the feed.",
            )
        elif not prof.connection_found:
            yield PreflightIssue(
                SEVERITY_ERROR, "CONN_MISSING",
                f"The {prof.role} side references connection "
                f"{prof.connection_id}, which does not exist (deleted or "
                f"never created). Fix: point the "
                f"{'feed' if prof.role == 'primary' else 'secondary side'} "
                f"at an existing connection.",
            )


@_check
def _check_combine_and_join(ctx: _Ctx) -> Iterable[PreflightIssue]:
    mode = (ctx.combine_mode or "union").strip().lower()
    if mode not in ("union", "join"):
        yield PreflightIssue(
            SEVERITY_ERROR, "COMBINE_INVALID",
            f"combine_mode '{ctx.combine_mode}' is not supported — use "
            f"'union' (stack rows from both sides) or 'join' (match rows "
            f"on keys).",
        )
        return
    if mode == "join":
        from core.executors.cross_source_combine import normalise_join_config
        try:
            normalise_join_config(ctx.feed_config.get("join_config") or {})
        except ValueError as exc:
            yield PreflightIssue(
                SEVERITY_ERROR, "JOIN_INVALID",
                f"join_config is invalid: {exc}. Fix: provide "
                f"join_config.how (INNER/LEFT/RIGHT/FULL/CROSS) and "
                f"matching-length left_on / right_on key lists.",
            )


@_check
def _check_secondary_source_resolvable(ctx: _Ctx) -> Iterable[PreflightIssue]:
    prof = ctx.secondary
    if prof.sql_status and prof.sql_status != "ok":
        yield PreflightIssue(
            SEVERITY_ERROR, "SECONDARY_SOURCE_UNRESOLVED",
            f"The secondary side's source ({prof.source_type} "
            f"{prof.source_id}) does not resolve to SQL: "
            f"{prof.sql_message or prof.sql_status}. The feed would fail "
            f"(or silently run single-source). Fix the referenced source "
            f"or the feed's secondary_source_type / secondary_source_id.",
        )


@_check
def _check_partial_saved_query_shape(ctx: _Ctx) -> Iterable[PreflightIssue]:
    """A saved query that carries a secondary SHAPE but no secondary
    connection is a half-built cross query.  Refuse loudly — running it
    single-source emits half the data and certifies COMPLETE."""
    sq = ctx.saved_query_row
    if not sq:
        return
    qcfg = sq.get("query_config") or {}
    has_shape = (
        (isinstance(qcfg.get("secondary_query_config"), dict)
         and qcfg.get("secondary_query_config"))
        or (isinstance(qcfg.get("secondary_raw_sql"), str)
            and qcfg.get("secondary_raw_sql", "").strip())
    )
    sec_cid = (ctx.feed_config.get("secondary_connection_id")
               or qcfg.get("secondary_connection_id"))
    if has_shape and not sec_cid:
        yield PreflightIssue(
            SEVERITY_ERROR, "CROSS_CONFIG_PARTIAL",
            f"Saved query {sq.get('id')} ('{sq.get('name') or ''}') has a "
            f"secondary SQL side but no secondary connection. Running it "
            f"would silently emit only the primary side's rows. Fix: "
            f"re-save the query with its secondary connection selected, "
            f"or remove the secondary SQL from it.",
        )


@_check
def _check_sql_file_secondary_section(ctx: _Ctx) -> Iterable[PreflightIssue]:
    """A cross-connection .sql file stores both sides in one file joined
    by '-- ===SECONDARY==='.  A file WITH that section but WITHOUT a
    secondary connection is the same half-built shape as above."""
    if (ctx.feed_config.get("source_type") != "sql_file"
            and ctx.feed_config.get("secondary_source_type") != "sql_file"):
        return
    # The primary profile's sql already holds the file content (the
    # read-only resolver returns it verbatim, unsplit).
    for prof in (ctx.primary, ctx.secondary):
        if prof.source_type != "sql_file" or not prof.sql:
            continue
        try:
            from api.sql_files_api import _split_cross_sql
            _pri, _sec = _split_cross_sql(prof.sql)
        except Exception:
            return
        # 2026-10-11 -- the FILE's own secondary connection counts too: the
        # engine inherits it (source_plan: "sql_file: read
        # row.secondary_connection_id"), and this rule's own message says
        # "on the feed or the file".  It read the feed only and refused the
        # owner's ONE shared file (cloud + on-prem SQL, both connections).
        sec_cid = ctx.feed_config.get("secondary_connection_id")
        if not sec_cid and prof.source_id is not None and ctx.db_manager is not None:
            try:
                row = ctx.db_manager.get_sql_file(int(prof.source_id)) or {}
                sec_cid = row.get("secondary_connection_id")
            except Exception:
                sec_cid = None
        if _sec is not None and not sec_cid:
            yield PreflightIssue(
                SEVERITY_ERROR, "CROSS_CONFIG_PARTIAL",
                f"SQL file {prof.source_id} contains a "
                f"'-- ===SECONDARY===' cross-connection section, but no "
                f"secondary connection is configured on the feed or the "
                f"file. Fix: set secondary_connection_id, or remove the "
                f"secondary section.",
            )
        return  # both profiles reference the same file — check once


@_check
def _check_same_sql_dialect_parity(ctx: _Ctx) -> Iterable[PreflightIssue]:
    """When the SAME SQL text runs on both sides (secondary reuses the
    primary source), the two connections must speak the same SQL dialect.
    DuckDB-family (s3/local) × DuckDB-family is fine — including AWS S3 ×
    on-prem S3, which differ only in ACCESS mode, resolved per connection.
    s3 × oracle reusing one SQL string is a dialect mismatch waiting to
    fail (or worse, to silently behave differently)."""
    if not ctx.secondary_reuses_primary_sql:
        return
    p, s = ctx.primary, ctx.secondary
    if not (p.connection_found and s.connection_found):
        return  # CONN_* errors already cover this
    if p.dialect and s.dialect and p.dialect != s.dialect:
        yield PreflightIssue(
            SEVERITY_WARNING, "DIALECT_MISMATCH",
            f"Both sides run the SAME SQL, but the primary "
            f"({p.describe()}) speaks {p.dialect} while the secondary "
            f"({s.describe()}) speaks {s.dialect}. The query may parse on "
            f"one and fail (or behave differently) on the other. Fix: give "
            f"the secondary side its own source (secondary_source_type / "
            f"secondary_source_id), or save the query with a dedicated "
            f"secondary SQL.",
        )


@_check
def _check_backend_capability(ctx: _Ctx) -> Iterable[PreflightIssue]:
    """Backend-aware save-time validation (2026-08-04).

    Cross-source feeds require a backend that can combine both sides —
    ``core.feed.source_plan.BACKEND_CAPABILITIES`` is the single source
    of truth (native: yes, airflow: yes, spark_connect: NO).  When Spark
    Connect is enabled, the auto-router's medium/large tiers could pick
    it for a big cross feed; the router floors that choice back to
    native and the execution-time gate refuses fail-closed, but the
    OPERATOR should learn at SAVE time that this feed will always run
    natively (capacity planning: the 10M-row tier exists precisely for
    feeds this large).  WARNING, never ERROR — the feed IS valid and
    runs correctly on native/airflow, so this check can never refuse a
    valid config.
    """
    if not (ctx.feed_config.get("secondary_connection_id")
            or ctx.secondary.connection_id):
        return
    try:
        from core.config import spark_connect as _sc_cfg
        _sc_enabled = bool(getattr(_sc_cfg, "enabled", False))
    except Exception:
        _sc_enabled = False
    if not _sc_enabled:
        return
    from core.feed.source_plan import BACKEND_CAPABILITIES
    caps = BACKEND_CAPABILITIES.get("spark_connect") or {}
    if caps.get("cross_source"):
        return  # a future Spark cross-combine lifts this warning automatically
    yield PreflightIssue(
        SEVERITY_WARNING, "BACKEND_SPARK_CONNECT_UNSUPPORTED",
        "This feed is cross-source and Spark Connect is enabled, but the "
        "spark_connect backend executes a single source only — it cannot "
        "combine the secondary side. Large runs that would auto-route to "
        "Spark Connect will run on the native backend instead (full "
        "combined output; the completeness verdict is unaffected). To use "
        "Spark for very large cross-source feeds, set the feed's "
        "execution backend to 'airflow' (its Spark job combines both "
        "sides).",
    )


@_check
def _check_onprem_context(ctx: _Ctx) -> Iterable[PreflightIssue]:
    """Operator context: name the resolved access mode when a side is
    on-prem S3 — the mode drives presigned-URL / pre-download behavior,
    and iceberg tables on such a connection take the pre-download slow
    path.  Informational only; the engine resolves modes per connection
    (api/data_grid_api.py:1074) so mixed modes are supported."""
    for prof in (ctx.primary, ctx.secondary):
        if prof.family == "s3" and prof.access_mode == "presigned":
            yield PreflightIssue(
                SEVERITY_INFO, "ONPREM_PRESIGNED",
                f"The {prof.role} side ({prof.describe()}) resolves to "
                f"on-prem presigned access: reads use boto3 pre-listing + "
                f"pre-signed URLs (never DuckDB glob / native S3 "
                f"credentials), and iceberg tables on it use the "
                f"pre-download path.",
            )


# ── Shared cross-shape detection (feeds + business reports) ──────────────
#
# 2026-08-05 BR audit: business reports hit the SAME defect shape feeds did
# (a referenced saved query carries cross-source config the executor
# ignores → half the data, reported success).  This predicate is the ONE
# place that decides "does this query_config carry a cross-source shape",
# so the feed preflight and the business-report executors can never drift
# on what "cross-source" means.  Pure function, no DB access.

def saved_query_cross_shape(query_config: Any) -> Optional[str]:
    """Classify a saved query's ``query_config`` cross-source shape.

    Returns:
      * ``"cross"``   — a secondary connection is configured (with or
        without its own secondary SQL/config): the query is cross-source
        and MUST be executed by an engine that combines both sides.
      * ``"partial"`` — a secondary SHAPE exists (secondary_query_config /
        secondary_raw_sql) but no secondary connection: half-built config;
        running it emits only the primary side's rows.
      * ``None``      — plain single-source config.
    """
    if not isinstance(query_config, dict):
        return None
    sec_cid = _as_id(query_config.get("secondary_connection_id"))
    has_shape = bool(
        (isinstance(query_config.get("secondary_query_config"), dict)
         and query_config.get("secondary_query_config"))
        or (isinstance(query_config.get("secondary_raw_sql"), str)
            and query_config.get("secondary_raw_sql", "").strip())
    )
    if sec_cid:
        return "cross"
    if has_shape:
        return "partial"
    return None


# ── Entry point ──────────────────────────────────────────────────────────


def _as_id(value: Any) -> Optional[int]:
    """Coerce a connection/source id to int; anything else (None, mocks,
    junk DB values) reads as ABSENT rather than truthy — a garbage value
    must never flip a single-source feed into the cross path."""
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.strip().isdigit():
        return int(value.strip())
    return None


def preflight_feed_cross_source(
    db_manager: Any,
    feed_config: Dict[str, Any],
) -> Optional[PreflightResult]:
    """Run every registered check against a feed config.

    Returns None when the feed is not cross-source in any detectable way
    (no explicit secondary, nothing to inherit, no half-built shape) —
    plain single-source feeds pay one source lookup at save time and
    nothing at run time.  Otherwise returns a PreflightResult; callers
    decide policy (save → HTTP 400 on errors; run → raise on errors).

    Read-only: never opens DuckDB, never touches S3, never mutates
    feed_config.
    """
    if db_manager is None or not isinstance(feed_config, dict):
        return None

    source_type = feed_config.get("source_type") or ""
    source_id = feed_config.get("source_id")
    sec_cid = _as_id(feed_config.get("secondary_connection_id"))

    # Referenced-source rows: needed both for inheritance detection and
    # for the partial-shape checks.
    saved_query_row: Optional[Dict[str, Any]] = None
    inherited_sec_cid = None
    inherited_combine = None
    if source_type == "saved_query" and source_id:
        try:
            saved_query_row = db_manager.get_query(source_id)
        except Exception as exc:
            logger.debug("[feed-crosssource] saved_query %s lookup failed "
                         "during preflight: %s", source_id, exc)
        qcfg = (saved_query_row or {}).get("query_config") or {}
        if not isinstance(qcfg, dict):
            qcfg = {}
        inherited_sec_cid = _as_id(qcfg.get("secondary_connection_id"))
        _ic = qcfg.get("combine_mode")
        inherited_combine = _ic if isinstance(_ic, str) else None
    elif source_type == "published_view" and source_id:
        # A PV publishes an upstream saved query — when THAT query is
        # cross-source, the feed inherits from it (feed_engine does the
        # same at run time).
        try:
            pv = db_manager.get_published_view(source_id)
            if isinstance(pv, dict) and pv.get("query_id"):
                saved_query_row = db_manager.get_query(pv["query_id"])
        except Exception as exc:
            logger.debug("[feed-crosssource] published_view %s lookup failed "
                         "during preflight: %s", source_id, exc)
        qcfg = (saved_query_row or {}).get("query_config") or {}
        if not isinstance(qcfg, dict):
            qcfg = {}
        inherited_sec_cid = _as_id(qcfg.get("secondary_connection_id"))
        _ic = qcfg.get("combine_mode")
        inherited_combine = _ic if isinstance(_ic, str) else None
    elif source_type == "sql_file" and source_id:
        try:
            sf = db_manager.get_sql_file(source_id)
        except Exception as exc:
            logger.debug("[feed-crosssource] sql_file %s lookup failed "
                         "during preflight: %s", source_id, exc)
            sf = None
        if isinstance(sf, dict):
            inherited_sec_cid = _as_id(sf.get("secondary_connection_id"))
            _ic = sf.get("combine_mode")
            inherited_combine = _ic if isinstance(_ic, str) else None

    effective_sec_cid = sec_cid or inherited_sec_cid
    _fc_combine = feed_config.get("combine_mode")
    if not isinstance(_fc_combine, str):
        _fc_combine = None
    combine_mode = (_fc_combine or inherited_combine or "").strip().lower()

    # Half-built saved-query shape (secondary SQL, no secondary conn)
    # must still be surfaced even though effective_sec_cid is None.
    _sq_qcfg = (saved_query_row or {}).get("query_config") or {}
    has_partial_shape = bool(
        (isinstance(_sq_qcfg.get("secondary_query_config"), dict)
         and _sq_qcfg.get("secondary_query_config"))
        or (isinstance(_sq_qcfg.get("secondary_raw_sql"), str)
            and _sq_qcfg.get("secondary_raw_sql", "").strip())
    )

    if not effective_sec_cid and not combine_mode and not has_partial_shape:
        # Cheap sql_file partial-shape probe: only when the feed is
        # sql_file-sourced (one file read, save time only).
        if source_type != "sql_file":
            return None

    # ── Build side profiles ──────────────────────────────────────────
    primary = _profile_side(
        db_manager, "primary", source_type, source_id,
        feed_config.get("connection_id"), feed_config.get("query_params"),
    )
    sec_source_type = feed_config.get("secondary_source_type") or source_type
    sec_source_id = feed_config.get("secondary_source_id") or source_id
    # 2026-10-11 -- a raw_sql SECOND side runs query_params.secondary_raw_sql
    # (source_plan.secondary_side_config, the one builder every lane uses);
    # profile it on the SQL it will run, not the primary's.
    _sec_qp = feed_config.get("query_params")
    if str(sec_source_type or "").lower() == "raw_sql" and isinstance(_sec_qp, dict):
        _sec_sql = _sec_qp.get("secondary_raw_sql")
        if isinstance(_sec_sql, str) and _sec_sql.strip():
            _sec_qp = {**_sec_qp, "sql": _sec_sql}
    secondary = _profile_side(
        db_manager, "secondary", sec_source_type, sec_source_id,
        effective_sec_cid, _sec_qp,
    )

    # sql_file feeds without any cross config: only the partial-section
    # check applies; bail out (return None) when the file has no
    # secondary section either.
    if not effective_sec_cid and not combine_mode and not has_partial_shape:
        try:
            from api.sql_files_api import _split_cross_sql
            _, _sec = _split_cross_sql(primary.sql or "")
        except Exception:
            _sec = None
        if _sec is None:
            return None

    secondary_reuses_primary_sql = (
        not feed_config.get("secondary_source_type")
        and not feed_config.get("secondary_source_id")
        and not (isinstance(_sq_qcfg.get("secondary_query_config"), dict)
                 and _sq_qcfg.get("secondary_query_config"))
        and not (isinstance(_sq_qcfg.get("secondary_raw_sql"), str)
                 and _sq_qcfg.get("secondary_raw_sql", "").strip())
    )
    if source_type == "sql_file" and primary.sql:
        # A file with a secondary section gives the secondary its own SQL.
        try:
            from api.sql_files_api import _split_cross_sql
            if _split_cross_sql(primary.sql)[1] is not None:
                secondary_reuses_primary_sql = False
        except Exception as exc:
            logger.debug("[feed-crosssource] sql_file split probe failed: %s",
                         exc)

    ctx = _Ctx(
        db_manager=db_manager,
        feed_config=feed_config,
        primary=primary,
        secondary=secondary,
        combine_mode=combine_mode,
        saved_query_row=saved_query_row,
        secondary_reuses_primary_sql=secondary_reuses_primary_sql,
    )

    issues: List[PreflightIssue] = []
    for check_fn in _CHECKS:
        try:
            issues.extend(check_fn(ctx) or [])
        except Exception as exc:
            # A crashing CHECK must not fail valid feeds — log loudly,
            # keep the verdicts the other checks produced.
            logger.warning(
                "[feed-crosssource] preflight check %s crashed: %s: %s",
                getattr(check_fn, "__name__", check_fn),
                type(exc).__name__, exc,
            )

    result = PreflightResult(
        feed_id=feed_config.get("id"),
        feed_name=feed_config.get("name") or "",
        combine_mode=combine_mode or "union",
        primary=primary,
        secondary=secondary,
        issues=issues,
    )
    logger.info(
        "[feed-crosssource] preflight feed=%s('%s') verdict=%s backend=%s "
        "primary_conn=%s(%s/%s) secondary_conn=%s(%s/%s) "
        "source=%s/%s sec_source=%s/%s combine=%s errors=%d warnings=%d%s",
        result.feed_id, result.feed_name,
        "OK" if result.ok else "REFUSED",
        feed_config.get("execution_backend") or "auto",
        primary.connection_id, primary.connection_type,
        primary.access_mode or "n/a",
        secondary.connection_id, secondary.connection_type,
        secondary.access_mode or "n/a",
        source_type, source_id, sec_source_type, sec_source_id,
        result.combine_mode, len(result.errors), len(result.warnings),
        (" issues=" + "; ".join(
            f"{i.code}" for i in issues if i.severity != SEVERITY_INFO))
        if issues else "",
    )
    return result
