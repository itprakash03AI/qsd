"""ControlFormatRepo — Phase 130 hotfix-4.

TTL-cached lookup for ``feed_control_file_formats`` rows.  Mirrors the
``BusinessCalendarRepo`` pattern so the feed engine doesn't hit the DB
on every execution.

One responsibility: given a control_file_format_id, return a resolved
``ControlFormatSpec``.  No business logic, no rendering — that's
``ControlFileWriter``'s job.
"""
from __future__ import annotations

import logging
import time as _t
from typing import Any, Mapping, Optional, Protocol

from .control_file import ControlFormatSpec

logger = logging.getLogger(__name__)


class ControlFormatDbReader(Protocol):
    """Subset of DatabaseManager that the repo needs.  Defined as a
    Protocol so tests can pass a MagicMock without monkey-patching the
    real ``core.database`` module."""

    def get_feed_control_file_format(self, fmt_id: int) -> Optional[Mapping[str, Any]]: ...


class ControlFormatRepo:
    """Loads ``ControlFormatSpec`` for a given id.  TTL-cached in
    process (default 5 minutes) so the SOD generator doesn't hit the
    DB per feed.

    Invalidated explicitly from admin CRUD endpoints when a row is
    edited.
    """

    def __init__(self, repo: ControlFormatDbReader, ttl_seconds: int = 300):
        self._repo = repo
        self._ttl_seconds = max(1, ttl_seconds)
        self._cache: dict = {}  # fmt_id -> (ControlFormatSpec, fetched_at_ts)

    def get(self, fmt_id: Optional[int]) -> Optional[ControlFormatSpec]:
        """Return a resolved spec, or ``None`` when ``fmt_id`` is falsy
        or the row doesn't exist.  Cached for the TTL window."""
        if not fmt_id:
            return None
        now = _t.monotonic()
        cached = self._cache.get(int(fmt_id))
        if cached and (now - cached[1]) < self._ttl_seconds:
            return cached[0]
        row = self._repo.get_feed_control_file_format(int(fmt_id))
        if row is None:
            return None
        try:
            spec = ControlFormatSpec.from_row(row)
        except Exception as e:
            # Bad row shape → log + return None.  The pipeline falls
            # back to the default writer; the admin UI gives the
            # operator a chance to fix the row.
            logger.warning(
                "[control_format_repo] could not parse format row id=%s: %s",
                fmt_id, e,
            )
            return None
        self._cache[int(fmt_id)] = (spec, now)
        return spec

    def invalidate(self, fmt_id: Optional[int] = None) -> None:
        """Called by admin endpoints after an edit/delete."""
        if fmt_id is None:
            self._cache.clear()
        else:
            self._cache.pop(int(fmt_id), None)
