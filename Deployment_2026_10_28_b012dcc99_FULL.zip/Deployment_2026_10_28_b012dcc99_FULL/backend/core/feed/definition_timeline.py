"""WHEN a definition change applies (2026-10-12, the owner: "if query changes
then we need to make it will be applied ... or ask user changes should be
applicable from").

A feed's definition is pinned per run (core/feed/pinning.py): a run
executes what it was admitted with, and a re-run of an old business date
executes the definition that was live FOR THAT DATE.  What was missing is
the AUTHOR's say: a corrected query that must apply to the month end
already delivered (its restatements included), or a change that must NOT
touch a date until a given business date.

THE timeline (``feed_definition_timeline``) records each definition-changing
save with the version it saved and ``applies_from``:

* a BUSINESS DATE D -- every run of a business date >= D executes it,
  re-runs and restatements included;
* NULL, "from the next run" -- every run executes it EXCEPT a re-run of a
  business date already delivered before the save (that date keeps the
  definition it was delivered with -- FR-GOV-01, unchanged).

:func:`resolve` walks the declarations NEWEST FIRST and the first one that
applies to the run's business date wins.  The first save that records a
timeline also records the definition BEFORE it (from the next run, saved a
moment earlier), so a date the change does not reach keeps the old
definition rather than falling to the live one.  None applies -> ``None``:
the caller keeps the pinned-for-date rule.
"""
from __future__ import annotations

import logging
from datetime import date, datetime, timedelta, timezone
from typing import Any, Mapping, Optional, Tuple

logger = logging.getLogger(__name__)

NEXT_RUN = "next_run"


def parse_applies_from(value: Any) -> Optional[date]:
    """``next_run`` / empty -> None; an ISO date -> that date; else ValueError."""
    if value in (None, "", NEXT_RUN):
        return None
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value)[:10])


def record_save(db, before: Mapping[str, Any], after: Mapping[str, Any], *,
                applies_from: Optional[date], user: Optional[str]) -> Optional[dict]:
    """Record a save on the timeline when it CHANGED the definition (the
    pinning hash).  Returns the entry, or None when nothing changed."""
    from core.feed.pinning import snapshot_definition
    old, new = snapshot_definition(dict(before)), snapshot_definition(dict(after))
    if old["definition_hash"] == new["definition_hash"]:
        return None
    fid = int(after.get("id") or before.get("id"))
    if not db.list_definition_timeline(fid):
        base = db.pin_feed_definition(fid, old, created_by=user)
        db.add_definition_timeline(fid, int(base["id"]), None, saved_by=user,
                                   note="the definition before the first timed change")
    ver = db.pin_feed_definition(fid, new, created_by=user)
    entry = db.add_definition_timeline(
        fid, int(ver["id"]), applies_from, saved_by=user,
        note=(f"applies to business dates from {applies_from}" if applies_from
              else "applies from the next run"))
    logger.info("[definition_timeline] feed %s version %s saved by %s: %s", fid, ver.get("version"),
                user, entry["note"])
    return entry


def resolve(db, feed_config_id: int, business_date: Any) -> Optional[Tuple[dict, dict]]:
    """``(definition, entry)`` the run of ``business_date`` executes, or None
    when the feed has no timeline / no declaration applies."""
    bd = business_date if isinstance(business_date, date) else date.fromisoformat(str(business_date)[:10])
    entries = db.list_definition_timeline(int(feed_config_id)) or []
    if not entries:
        return None
    delivered_at = None
    delivered_read = False
    for e in entries:
        af = e.get("applies_from")
        if af:
            if bd >= date.fromisoformat(str(af)[:10]):
                return _version(db, e), e
            continue
        if not delivered_read:
            delivered_at, delivered_read = db.first_delivery_at(int(feed_config_id), bd), True
        saved = _aware(e.get("saved_at"))
        if delivered_at is None or saved is None or _aware(delivered_at) >= saved:
            return _version(db, e), e
    return None


def _version(db, entry: Mapping[str, Any]) -> dict:
    ver = db.get_feed_definition_version(int(entry["version_id"]))
    if not ver or not isinstance(ver.get("definition"), dict):
        raise LookupError(f"definition version {entry['version_id']} of the timeline is unreadable")
    return dict(ver["definition"])


def _aware(v) -> Optional[datetime]:
    if v is None:
        return None
    if isinstance(v, str):
        v = datetime.fromisoformat(v.replace("Z", "+00:00"))
    return v if v.tzinfo else v.replace(tzinfo=timezone.utc)


def describe(db, feed_config_id: int) -> list:
    """The timeline in words, newest first (the feed form shows it)."""
    out = []
    for e in db.list_definition_timeline(int(feed_config_id)) or []:
        ver = db.get_feed_definition_version(int(e["version_id"])) or {}
        out.append({**e, "version": ver.get("version")})
    return out
