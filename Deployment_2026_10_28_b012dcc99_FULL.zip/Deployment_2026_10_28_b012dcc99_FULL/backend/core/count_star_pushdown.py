"""COUNT(*) pushdown for Iceberg-backed tables (2026-06-04).

When a query is purely ``SELECT COUNT(*) FROM t WHERE <prunable filters>``
the result equals ``sum(record_count)`` across files surviving the prune
— no actual scan needed.  Iceberg manifests carry ``record_count`` per
file; the pruner already returns the surviving file list.  We just sum.

Detection criteria (all required):
  1. Single statement, single SELECT
  2. Exactly one projection: ``COUNT(*)`` or ``COUNT(1)``
  3. No GROUP BY, no HAVING, no ORDER BY, no LIMIT
  4. No JOIN, no subquery in FROM
  5. WHERE clauses (if any) extract cleanly into partition_filters
     that are SUPPORTED (no `<>` unless we have file lo==hi data,
     no NOT LIKE unless prefix-decomposed by extractor)

Returns None when the query doesn't qualify (caller proceeds with
normal execution).  Returns an integer when the query qualifies AND
the file list's per-file record_counts are all populated.
"""
from __future__ import annotations
import logging
from typing import Optional, List, Dict, Any

logger = logging.getLogger(__name__)


def is_pure_count_star(sql: str) -> bool:
    """Return True iff the SQL is exactly a ``SELECT COUNT(*) FROM <single
    table> [WHERE ...]`` with no other constructs.  Cheap pre-check
    before running pruning."""
    if not sql:
        return False
    try:
        import sqlglot
        from sqlglot import expressions as exp
    except ImportError:
        return False
    try:
        parsed = sqlglot.parse_one(sql, read="duckdb")
    except Exception:
        return False
    if not isinstance(parsed, exp.Select):
        return False
    # Reject unwanted clauses.
    for arg_name in ("group", "having", "order", "limit", "qualify",
                     "windows", "distinct", "cluster", "sort"):
        if parsed.args.get(arg_name) is not None:
            return False
    # Reject JOINs.
    if parsed.args.get("joins"):
        return False
    # Exactly one projection.
    exprs = parsed.expressions
    if not exprs or len(exprs) != 1:
        return False
    only = exprs[0]
    # Unwrap aliases.
    inner = only.this if isinstance(only, exp.Alias) else only
    # Must be COUNT(*) or COUNT(1).
    if not isinstance(inner, exp.Count):
        return False
    cnt_arg = inner.this
    if isinstance(cnt_arg, exp.Star):
        pass
    elif isinstance(cnt_arg, exp.Literal) and str(cnt_arg).strip() in ("1", "1.0"):
        pass
    else:
        return False
    # FROM must be a single table (not subquery).
    # sqlglot's Select stores it under "from_" (with trailing underscore).
    from_ = parsed.args.get("from_") or parsed.args.get("from")
    if from_ is None:
        return False
    # Reject when there's a Subquery inside the FROM.
    tbls = list(from_.find_all(exp.Subquery))
    if tbls:
        return False
    return True


def compute_count_from_record_counts(
    file_list: List[Dict[str, Any]],
) -> Optional[int]:
    """Sum ``record_count`` across files.  Returns None when ANY file
    is missing its record_count (we can't return a partial count)."""
    if not file_list:
        return 0
    total = 0
    for f in file_list:
        rc = f.get("record_count")
        if rc is None:
            return None
        try:
            total += int(rc)
        except (TypeError, ValueError):
            return None
    return total
