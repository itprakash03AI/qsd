"""Brain mirror advisor — Phase 160 Slice 2 (2026-07-01).

Purpose
-------
Given the Phase 160 brain store now carries per-table query counts
(``hot_tables``), per-column usage counts (``hot_columns``), and
per-snapshot file/size aggregates (``manifest_summary``), this
module computes a **ranked list of tables worth consolidating**
into a QS-owned mirror.

This is the "advisor" phase from the 2026-07-01 DuckDB Query Cache
Brainstorm — Phase 2 in the phased plan.  It does NOT build any
mirror files.  It gives the operator evidence to decide which
tables to enable, plus a storage projection.  The actual mirror
executor (Phase 3) reads from ``mirror_candidates`` state after the
operator opts in.

Design properties
-----------------
- **Read-only**: consults the brain store; no primary DB writes.
  Advisor state is derived, not persisted.  A fresh advisor call
  always reflects current store state.
- **Fail-open**: any component that fails (missing store, missing
  data) drops the affected candidate silently.  Never raises past
  the top-level ``list_candidates`` entry point.
- **Deterministic scoring**: the same store state always produces
  the same ranked list.  Ops can trust the recommendation is stable.
- **Bounded**: caps at ``top_k`` candidates so an operator UI can
  render the list without pagination.

Formula — from brainstorm §8, adapted to available store data:

    small_file_signal = (file_count > MIN_FILES) AND
                        (avg_file_size_bytes < AVG_FILE_SIZE_CAP)
    hot_signal        = queries_7d > MIN_QUERIES_7D
    time_saved_signal = queries_7d * avg_seconds_7d > MIN_TIME_BUDGET
    candidate         = small_file_signal AND hot_signal AND time_saved_signal

    score = queries_7d * avg_seconds_7d       # projected time saved
    storage_projected_bytes = total_bytes * 3  # per brainstorm §9

The thresholds are configurable via ``brain_store.advisor_*`` keys.
Defaults match the brainstorm recommendations.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


logger = logging.getLogger(__name__)


# Default thresholds — mirror brainstorm §8 recommendations.
_DEFAULT_MIN_FILES         = 200         # small-file problem exists
_DEFAULT_AVG_FILE_SIZE_CAP = 32 * 1024 * 1024   # 32 MB
_DEFAULT_MIN_QUERIES_7D    = 20
_DEFAULT_MIN_TIME_BUDGET_S = 60          # queries_7d * avg_s > 60s
_DEFAULT_TOP_K             = 50
_DEFAULT_STORAGE_MULTIPLIER = 3.0        # per brainstorm §9


# ── config accessors ────────────────────────────────────────────────────


def _cfg_int(key: str, default: int) -> int:
    try:
        from core import config as _cfg
        return int(_cfg.get("brain_store", key, default) or default)
    except Exception:
        return default


def _cfg_float(key: str, default: float) -> float:
    try:
        from core import config as _cfg
        return float(_cfg.get("brain_store", key, default) or default)
    except Exception:
        return default


# ── data model ──────────────────────────────────────────────────────────


@dataclass
class MirrorCandidate:
    """One row in the ranked candidate list."""
    bucket:                   str
    table_prefix:             str
    queries_7d:               int
    queries_24h:              int
    avg_seconds_7d:           float
    # From manifest_summary
    file_count:               int = 0
    total_bytes:              int = 0
    avg_file_size_bytes:      float = 0.0
    # Signals + score
    small_file_signal:        bool = False
    hot_signal:               bool = False
    time_saved_signal:        bool = False
    score:                    float = 0.0
    storage_projected_bytes:  int = 0
    # Top predicate columns for the mirror's ORDER BY
    top_predicate_columns:    List[str] = field(default_factory=list)
    # Why-not (when candidate is False) — actionable diagnostic
    why_not:                  List[str] = field(default_factory=list)
    # Slice 3: operator opt-in state — UI shows a toggle per candidate
    # so admins can see current status + flip without a separate call.
    opted_in:                 bool = False
    opted_in_by:              Optional[str] = None
    opted_in_at:              Optional[str] = None

    def as_dict(self) -> Dict[str, Any]:
        return {
            "bucket":                   self.bucket,
            "table_prefix":             self.table_prefix,
            "queries_7d":               self.queries_7d,
            "queries_24h":              self.queries_24h,
            "avg_seconds_7d":           round(self.avg_seconds_7d, 3),
            "file_count":               self.file_count,
            "total_bytes":              self.total_bytes,
            "avg_file_size_bytes":      int(self.avg_file_size_bytes),
            "small_file_signal":        self.small_file_signal,
            "hot_signal":               self.hot_signal,
            "time_saved_signal":        self.time_saved_signal,
            "score":                    round(self.score, 2),
            "storage_projected_bytes":  self.storage_projected_bytes,
            "top_predicate_columns":    list(self.top_predicate_columns),
            "why_not":                  list(self.why_not),
            "opted_in":                 self.opted_in,
            "opted_in_by":              self.opted_in_by,
            "opted_in_at":              self.opted_in_at,
        }


# ── advisor ─────────────────────────────────────────────────────────────


def list_candidates(
    *,
    top_k: Optional[int] = None,
    include_ineligible: bool = False,
) -> Dict[str, Any]:
    """Return the ranked mirror-candidate list plus threshold context.

    Args:
        top_k: cap on the ranked list length.  Defaults to
            ``brain_store.advisor_top_k`` (50).
        include_ineligible: when True the response also contains
            tables that FAILED the small-file / hot / time-budget
            checks — with a ``why_not`` list explaining which
            threshold they missed.  Useful for ops debugging
            ("why isn't this hot table showing up as a candidate?").

    Response shape:
        {
            "candidates": [MirrorCandidate.as_dict()...],
            "ineligible": [MirrorCandidate.as_dict()...]   (when requested)
            "thresholds": { ...used values... },
            "total_scanned": int,
            "estimated_total_storage_bytes": int,
            "generated_at": iso8601
        }

    Never raises — a store-unavailable / no-data run returns an empty
    ``candidates`` list.
    """
    from datetime import datetime, timezone

    min_files          = _cfg_int  ("advisor_min_files",         _DEFAULT_MIN_FILES)
    avg_size_cap       = _cfg_int  ("advisor_avg_file_size_cap", _DEFAULT_AVG_FILE_SIZE_CAP)
    min_queries        = _cfg_int  ("advisor_min_queries_7d",    _DEFAULT_MIN_QUERIES_7D)
    min_time_budget    = _cfg_float("advisor_min_time_budget_s", _DEFAULT_MIN_TIME_BUDGET_S)
    storage_multiplier = _cfg_float("advisor_storage_multiplier",
                                     _DEFAULT_STORAGE_MULTIPLIER)
    k                  = int(top_k) if top_k else _cfg_int("advisor_top_k",
                                                             _DEFAULT_TOP_K)

    thresholds = {
        "min_files":               min_files,
        "avg_file_size_cap_bytes": avg_size_cap,
        "min_queries_7d":          min_queries,
        "min_time_budget_seconds": min_time_budget,
        "storage_multiplier":      storage_multiplier,
    }

    now_iso = datetime.now(timezone.utc).isoformat(timespec="seconds")

    try:
        from core.brain_duckdb_store import get_store
    except Exception as exc:
        logger.debug("advisor: store import failed: %s", exc)
        return {
            "candidates":                    [],
            "ineligible":                    [],
            "thresholds":                    thresholds,
            "total_scanned":                 0,
            "estimated_total_storage_bytes": 0,
            "generated_at":                  now_iso,
        }

    store = get_store()
    if not store.is_available():
        return {
            "candidates":                    [],
            "ineligible":                    [],
            "thresholds":                    thresholds,
            "total_scanned":                 0,
            "estimated_total_storage_bytes": 0,
            "generated_at":                  now_iso,
            "note":                          "store_unavailable",
        }

    # 1) Pull hot tables — the universe.  Cap the fetch at 4x top_k
    #    so ineligible-but-close entries survive for the diag view
    #    without being unbounded.
    try:
        hot = store.get_hot_tables(top_k=max(k * 4, 100))
    except Exception as exc:
        logger.debug("advisor: get_hot_tables failed: %s", exc)
        hot = []

    if not hot:
        return {
            "candidates":                    [],
            "ineligible":                    [],
            "thresholds":                    thresholds,
            "total_scanned":                 0,
            "estimated_total_storage_bytes": 0,
            "generated_at":                  now_iso,
            "note":                          "no_hot_tables_yet",
        }

    candidates: List[MirrorCandidate] = []
    ineligible: List[MirrorCandidate] = []

    for h in hot:
        try:
            c = _score_one(
                h, store,
                min_files=min_files,
                avg_size_cap=avg_size_cap,
                min_queries=min_queries,
                min_time_budget=min_time_budget,
                storage_multiplier=storage_multiplier,
            )
        except Exception as exc:
            logger.debug("advisor: score failure for %s: %s",
                         h.get("table_prefix"), exc)
            continue
        if (c.small_file_signal and c.hot_signal
                and c.time_saved_signal):
            candidates.append(c)
        else:
            ineligible.append(c)

    # Rank candidates by score DESC + cap at k
    candidates.sort(key=lambda x: x.score, reverse=True)
    if k > 0:
        candidates = candidates[:k]

    total_storage = sum(c.storage_projected_bytes for c in candidates)

    return {
        "candidates":                    [c.as_dict() for c in candidates],
        "ineligible":                    (
            [c.as_dict() for c in ineligible] if include_ineligible else []
        ),
        "thresholds":                    thresholds,
        "total_scanned":                 len(hot),
        "estimated_total_storage_bytes": total_storage,
        "generated_at":                  now_iso,
    }


def _score_one(
    hot_row: Dict[str, Any],
    store: Any,
    *,
    min_files: int,
    avg_size_cap: int,
    min_queries: int,
    min_time_budget: float,
    storage_multiplier: float,
) -> MirrorCandidate:
    """Build a MirrorCandidate for one hot-table row.  Never raises."""
    bucket = str(hot_row.get("bucket") or "")
    prefix = str(hot_row.get("table_prefix") or "")
    q7     = int(hot_row.get("queries_7d") or 0)
    q24    = int(hot_row.get("queries_24h") or 0)
    avg_s  = float(hot_row.get("avg_seconds_7d") or 0.0)

    c = MirrorCandidate(
        bucket=bucket, table_prefix=prefix,
        queries_7d=q7, queries_24h=q24, avg_seconds_7d=avg_s,
    )

    # Manifest summary lookup — try the current snapshot pointer.
    file_count = 0
    total_bytes = 0
    try:
        sp = store.get_snapshot_pointer(bucket, prefix) or {}
        snap = sp.get("current_snapshot_id")
        if snap:
            ms = store.get_manifest_summary(bucket, prefix, snap) or {}
            file_count = int(ms.get("file_count") or 0)
            total_bytes = int(ms.get("total_bytes") or 0)
    except Exception as exc:
        logger.debug("advisor: manifest lookup failed for %s/%s: %s",
                     bucket, prefix, exc)

    c.file_count  = file_count
    c.total_bytes = total_bytes
    c.avg_file_size_bytes = (
        (total_bytes / file_count) if file_count > 0 else 0.0
    )
    c.storage_projected_bytes = int(total_bytes * storage_multiplier)

    # Signals
    c.small_file_signal = (
        file_count > min_files
        and c.avg_file_size_bytes > 0
        and c.avg_file_size_bytes < avg_size_cap
    )
    c.hot_signal = q7 > min_queries
    c.time_saved_signal = (q7 * avg_s) > min_time_budget
    c.score = q7 * avg_s

    # Why-not diagnostics
    if not c.small_file_signal:
        if file_count == 0:
            c.why_not.append(
                "no_manifest_summary (mirror daemon hasn't populated "
                "this table yet — will land on next tick)"
            )
        elif file_count <= min_files:
            c.why_not.append(
                f"file_count={file_count} <= min_files={min_files} "
                f"(no small-file problem)"
            )
        elif c.avg_file_size_bytes >= avg_size_cap:
            c.why_not.append(
                f"avg_file_size={int(c.avg_file_size_bytes)} bytes "
                f">= cap={avg_size_cap} (files are already large; "
                f"consolidation won't help much)"
            )
    if not c.hot_signal:
        c.why_not.append(
            f"queries_7d={q7} <= min_queries_7d={min_queries} "
            f"(not queried enough to justify storage cost)"
        )
    if not c.time_saved_signal:
        c.why_not.append(
            f"queries_7d * avg_seconds_7d = {q7 * avg_s:.1f}s "
            f"<= min_time_budget={min_time_budget}s "
            f"(mirror wouldn't save meaningful total time)"
        )

    # Top predicate columns — from hot_columns, up to 5.
    # 2026-07-02 -- debug-log on any lookup failure so operators can
    # diagnose why an advisor row lacks predicate-column hints.
    try:
        top = store.get_hot_columns_for(bucket, prefix, top_k=5) or []
        c.top_predicate_columns = [str(x.get("column_name") or "")
                                   for x in top if x.get("column_name")]
    except Exception as _hot_exc:
        logger.debug(
            "advisor: get_hot_columns_for(%s, %s) suppressed %s: %s -- "
            "candidate row will have empty top_predicate_columns",
            bucket, prefix, type(_hot_exc).__name__, _hot_exc,
        )

    # Slice 3 — opt-in state so UI shows current per-table status.
    try:
        opt = store.get_mirror_opt_in(bucket, prefix)
        if opt:
            c.opted_in    = bool(opt.get("enabled"))
            c.opted_in_by = opt.get("opted_in_by")
            c.opted_in_at = opt.get("opted_in_at")
    except Exception as _opt_exc:
        logger.debug(
            "advisor: get_mirror_opt_in(%s, %s) suppressed %s: %s -- "
            "candidate row will show opted_in=False by default",
            bucket, prefix, type(_opt_exc).__name__, _opt_exc,
        )

    return c


__all__ = [
    "MirrorCandidate", "list_candidates",
]
