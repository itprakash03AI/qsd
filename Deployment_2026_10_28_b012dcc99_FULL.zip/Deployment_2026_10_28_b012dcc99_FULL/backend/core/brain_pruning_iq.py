"""Pruning effectiveness classifier — answers per-query
"is this 4000-file scan legitimate or broken pruning?"

2026-06-24 operator directive: "if some query returning valid 4000 how
we will come to knwo" + "is it really valid how we will know".

The iceberg reader already records WHAT it pruned (partition,
column_stats, supplement, bloom) in ``_out_meta["stage_drops"]`` plus
``files_after_prune`` and the ``filter_breakdown`` showing which
columns the user's WHERE touched.  But there's no SINGLE per-query
classification that tells the operator at a glance:

    "this 4000-file scan is LEGITIMATE -- no partition filter, true
     full-table query (admin export style)"

vs

    "this 4000-file scan is BROKEN -- you filtered on column X but X
     isn't a partition column AND its supplement bounds are missing
     -- brain isn't pruning.  Action: scan-now for column X."

This module owns that ONE classifier so every downstream consumer
(brain_trace, the diagnose UI, slow-query alerts) reads the SAME
verdict.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional


# ── Verdict labels ─────────────────────────────────────────────────


VERDICT_FULL_SCAN_INTENDED = "full_scan_intended"
VERDICT_PARTITION_PRUNED_WELL = "partition_pruned_well"
VERDICT_PARTITION_FILTER_INEFFECTIVE = "partition_filter_ineffective"
VERDICT_COLD_BRAIN = "cold_brain"
VERDICT_NO_FILTER_HOT_TABLE = "no_filter_hot_table"
VERDICT_PRUNING_HOSTILE_FILTER = "pruning_hostile_filter"


@dataclass(frozen=True)
class PruningVerdict:
    """One classifier output per query.

    Fields all optional / primitive so dataclasses.asdict serialises
    cleanly into brain_trace + WS payloads."""
    verdict: str
    summary: str           # One-line operator-readable explanation
    files_total: int
    files_after_prune: int
    drop_ratio: float      # 0.0..1.0 — files_after_prune / files_total
    filter_columns: List[str]
    partition_columns: List[str]
    diagnosis: str         # Multi-line actionable hint when broken
    severity: str          # "ok" | "warn" | "broken"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ── Classifier ──────────────────────────────────────────────────────


def classify(
    *,
    files_total: int,
    files_after_prune: int,
    filter_columns: Optional[List[str]] = None,
    partition_columns: Optional[List[str]] = None,
    stage_drops: Optional[Dict[str, int]] = None,
    supplement_coverage: Optional[Dict[str, bool]] = None,
    pruning_hostile_columns: Optional[List[str]] = None,
    auto_rewrite_applied: bool = False,
    threshold_files_warn: int = 500,
) -> PruningVerdict:
    """Classify one query's pruning effectiveness.

    Inputs come from ``iceberg_reader.get_iceberg_data_files`` (the
    ``_out_meta`` dict it populates) plus the SQL classifier output
    (``filter_columns`` from the WHERE clause).

    Returns:
        PruningVerdict with the human-readable summary the operator
        sees in brain_trace + the diagnose UI.  Fail-safe: when
        inputs are partial, returns a verdict marked ``ok`` rather
        than scaring the operator with a false-positive ``broken``.

    Verdict semantics:

      ``full_scan_intended``   -- no filters present, scanning
                                  everything was the user's intent
                                  (admin export / unfiltered count).

      ``partition_pruned_well``-- filters present AND files dropped
                                  by >= 90% (good pruning).

      ``no_filter_hot_table``  -- no filters AND file count >
                                  warning threshold (likely user
                                  forgot a WHERE -- gentle nudge).

      ``cold_brain``           -- filter columns present but their
                                  supplement bounds are missing
                                  (brain hasn't scanned this table
                                  yet -- recommend scan-now).

      ``pruning_hostile_filter``-- filter present but pruning-hostile
                                  pattern detected (CAST/function on
                                  partition col) AND auto_rewrite
                                  didn't fire.

                                  KNOWN LIMITATION (2026-06-25 brain
                                  deep dive): the iceberg_reader wire-
                                  in currently passes ``pruning_
                                  hostile_columns=[]`` and ``auto_
                                  rewrite_applied=False`` (hardcoded
                                  -- see the comment in iceberg_reader
                                  around the _classify_iq call).  This
                                  verdict is therefore UNREACHABLE
                                  until the SQL classifier feeds the
                                  per-query hostile-pattern list.  The
                                  pre-run warning chip on the frontend
                                  already shows hostile patterns; that
                                  data needs to land in _payload to
                                  reach this classifier.

      ``partition_filter_ineffective`` -- filters present, brain
                                  has supplement coverage, no
                                  hostile pattern, but files dropped
                                  by < 10%.  Most likely cause: the
                                  filter column isn't actually a
                                  partition column.  Silent bug
                                  masquerading as a pruning win.
    """
    filter_columns = filter_columns or []
    partition_columns = partition_columns or []
    stage_drops = stage_drops or {}
    supplement_coverage = supplement_coverage or {}
    pruning_hostile_columns = pruning_hostile_columns or []

    # Guard rails on inputs.
    if files_total <= 0:
        files_total = max(1, files_after_prune or 1)
    if files_after_prune < 0:
        files_after_prune = files_total

    drop_ratio = files_after_prune / files_total if files_total else 1.0

    # Case 1 -- no filters touched at all.
    if not filter_columns:
        if files_after_prune > threshold_files_warn:
            return PruningVerdict(
                verdict=VERDICT_NO_FILTER_HOT_TABLE,
                summary=(
                    f"No filters detected -- scanning all "
                    f"{files_after_prune:,} files (table has "
                    f"{files_total:,} total).  Likely missing a "
                    f"WHERE clause."
                ),
                files_total=files_total,
                files_after_prune=files_after_prune,
                drop_ratio=drop_ratio,
                filter_columns=filter_columns,
                partition_columns=partition_columns,
                diagnosis=(
                    "Add a partition filter (e.g. WHERE "
                    + (f"{partition_columns[0]} = ..."
                       if partition_columns
                       else "<partition_col> = ...")
                    + ").  If this is an intentional full-table "
                    + "export, switch to Reports for off-hours "
                    + "scanning."
                ),
                severity="warn",
            )
        return PruningVerdict(
            verdict=VERDICT_FULL_SCAN_INTENDED,
            summary=(
                f"Full scan ({files_after_prune:,} files) -- no "
                f"filters in query, scanning everything was the "
                f"intent."
            ),
            files_total=files_total,
            files_after_prune=files_after_prune,
            drop_ratio=drop_ratio,
            filter_columns=filter_columns,
            partition_columns=partition_columns,
            diagnosis="",
            severity="ok",
        )

    # Case 2 -- filters touched a pruning-hostile pattern AND
    # auto_rewrite didn't fix it.  Most actionable diagnosis.
    if pruning_hostile_columns and not auto_rewrite_applied:
        hostile_list = ", ".join(pruning_hostile_columns)
        return PruningVerdict(
            verdict=VERDICT_PRUNING_HOSTILE_FILTER,
            summary=(
                f"Filter on {hostile_list} is pruning-hostile -- "
                f"the brain detected the pattern but auto-rewrite "
                f"didn't apply (confidence < 1.0)."
            ),
            files_total=files_total,
            files_after_prune=files_after_prune,
            drop_ratio=drop_ratio,
            filter_columns=filter_columns,
            partition_columns=partition_columns,
            diagnosis=(
                f"Rewrite the filter so the brain can prune: e.g. "
                f"`{hostile_list} = DATE '...'` instead of "
                f"`CAST({hostile_list} AS TEXT) = '...'`.  Check the "
                f"pre-run warning chip for the exact suggestion."
            ),
            severity="warn",
        )

    # Case 3 -- filter columns present but their supplement bounds
    # are missing.  Brain hasn't scanned yet -- cold start case.
    _missing_coverage = [
        c for c in filter_columns
        if supplement_coverage.get(c) is False
    ]
    if _missing_coverage and drop_ratio > 0.5:
        cols = ", ".join(_missing_coverage)
        return PruningVerdict(
            verdict=VERDICT_COLD_BRAIN,
            summary=(
                f"Brain hasn't scanned {cols} yet -- pruning "
                f"reduced files {files_total:,} -> {files_after_prune:,} "
                f"but a cold supplement table caps the gain."
            ),
            files_total=files_total,
            files_after_prune=files_after_prune,
            drop_ratio=drop_ratio,
            filter_columns=filter_columns,
            partition_columns=partition_columns,
            diagnosis=(
                "Force a supplement scan for these columns now: "
                "POST /api/admin/iceberg/bloom/scan-now (auto-picks "
                "from history) OR POST /api/admin/iceberg/column-"
                "stats/scan with the column list.  Next query will "
                "be much faster."
            ),
            severity="warn",
        )

    # Case 4 -- filter touched, brain has coverage, no hostile, but
    # pruning STILL didn't help.  Most likely: filter column isn't
    # actually a partition column.
    if drop_ratio > 0.9 and files_after_prune > threshold_files_warn:
        # ratio > 90% means we kept >90% of files = pruning failed
        non_partition_filter_cols = [
            c for c in filter_columns
            if c not in partition_columns
        ]
        diagnosis_pieces = []
        if non_partition_filter_cols:
            diagnosis_pieces.append(
                f"Filter columns NOT in partition spec: "
                f"{', '.join(non_partition_filter_cols)}.  These "
                f"can't drive partition-level pruning."
            )
        if partition_columns:
            diagnosis_pieces.append(
                f"Available partition columns: "
                f"{', '.join(partition_columns)}.  Add one to your "
                f"WHERE clause for fast pruning."
            )
        return PruningVerdict(
            verdict=VERDICT_PARTITION_FILTER_INEFFECTIVE,
            summary=(
                f"Pruning failed -- {files_total:,} files scanned, "
                f"only {files_total - files_after_prune:,} dropped "
                f"({(1 - drop_ratio) * 100:.1f}%)."
            ),
            files_total=files_total,
            files_after_prune=files_after_prune,
            drop_ratio=drop_ratio,
            filter_columns=filter_columns,
            partition_columns=partition_columns,
            diagnosis=" ".join(diagnosis_pieces) or (
                "Check that your filter column is a partition column "
                "AND that the brain has scanned recent snapshots."
            ),
            severity="broken",
        )

    # Default -- pruning worked, all good.
    return PruningVerdict(
        verdict=VERDICT_PARTITION_PRUNED_WELL,
        summary=(
            f"Pruned {files_total:,} files -> "
            f"{files_after_prune:,} ({(1 - drop_ratio) * 100:.1f}% "
            f"dropped)."
        ),
        files_total=files_total,
        files_after_prune=files_after_prune,
        drop_ratio=drop_ratio,
        filter_columns=filter_columns,
        partition_columns=partition_columns,
        diagnosis="",
        severity="ok",
    )


def trace(verdict: PruningVerdict) -> None:
    """Record the verdict in brain_trace so it surfaces in
    files_metadata.brain_trace alongside every other brain decision.

    Best-effort -- brain_trace.is_active() check is built-in via
    the trace() function returning early when no trace is active."""
    try:
        from core.brain_trace import trace as _t
        _t(
            "pruning_iq",
            verdict.verdict,
            files_total=verdict.files_total,
            files_after_prune=verdict.files_after_prune,
            drop_ratio=round(verdict.drop_ratio, 4),
            severity=verdict.severity,
            summary=verdict.summary,
            diagnosis=verdict.diagnosis,
        )
    except Exception:
        # brain_trace import-failed (rare); never block the query
        pass


__all__ = [
    "PruningVerdict",
    "classify",
    "trace",
    "VERDICT_FULL_SCAN_INTENDED",
    "VERDICT_PARTITION_PRUNED_WELL",
    "VERDICT_PARTITION_FILTER_INEFFECTIVE",
    "VERDICT_COLD_BRAIN",
    "VERDICT_NO_FILTER_HOT_TABLE",
    "VERDICT_PRUNING_HOSTILE_FILTER",
]
