"""BF-289 — Per-execution stage tracker.

User feedback: heartbeats said "elapsed=1516s" with no information about
WHERE the time was being spent.  Was it metadata read?  File download?
The actual JOIN?  GROUP BY?  Without knowing, the user can't decide
whether to wait or cancel.

This module is a thread-safe shared state that:
  - Lets execution code register the stage it's currently in
  - Updates progress counters (files downloaded, bytes scanned)
  - Lets the heartbeat broadcast the live stage info instead of just
    elapsed seconds

Not persisted — the registry is process-local.  On pod restart all
in-flight executions are lost anyway, so persistence wouldn't help.
"""
from __future__ import annotations

import logging
import logging.handlers
import re
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Optional


# ── BF-PRUNE-PERF-LOG: per-query log file ────────────────────────────────────
# Each query gets its OWN file at  {logs_dir}/queries/{execution_id}.log
# so admins can investigate "what did MY query do, step-by-step" without
# any grep — just open the file with the matching name.
#
# Bonus master log {logs_dir}/queries/_all.log is the rolling aggregate
# (10 MB × 5 = 50 MB) for cross-query analysis ("show me every query
# whose file_prune took >30s").

_query_log_dir: Optional[Path] = None
#: The ``server.log_file`` value ``_query_log_dir`` was derived FROM.
#: 2026-09-07 -- THE MEMO IS NOW KEYED ON ITS INPUT.  It used to be keyed
#: on nothing: whichever config was live at the first stage emit owned the
#: path for the rest of the process.  Two consequences, one per
#: environment:
#:
#:   * in TESTS, a stage emit inside a ``controlled_config`` /
#:     ``QUERYSTUDIO_PATHS_*`` sandbox pinned that temp directory into
#:     every later test in the same worker -- and ``controlled_config``
#:     restores ``core.config``, which cannot reach a memo derived from it;
#:   * in PRODUCTION, changing ``server.log_file`` took effect nowhere
#:     until a restart, silently.
#:
#: Re-deriving when the INPUT changes fixes both without a reset hook that
#: nothing would call.  It costs one attribute read per emit.
_query_log_dir_source: Optional[str] = None
_query_log_dir_lock = threading.Lock()
_query_file_locks: Dict[str, threading.Lock] = {}
_query_file_lookup_lock = threading.Lock()
_master_logger: Optional[logging.Logger] = None
#: The directory ``_master_logger``'s open file handle points at.  The
#: logger holds a ``RotatingFileHandler`` on ``<dir>/_all.log``, so a
#: stale one keeps writing into a deleted temp directory.
_master_logger_dir: Optional[Path] = None
_EID_SAFE_RE = re.compile(r"[^A-Za-z0-9_-]")


def _configured_log_file() -> str:
    """``server.log_file`` as a string, or "" when it cannot be read.

    Separated so the memo has ONE input to compare, and so an unreadable
    config is a distinct, stable key rather than a value that flickers.
    """
    try:
        from core.config import server as _srv_cfg
        return str(getattr(_srv_cfg, "log_file", "") or "")
    except Exception:
        return ""


def _get_query_log_dir() -> Optional[Path]:
    global _query_log_dir, _query_log_dir_source
    main_log = _configured_log_file()
    cached = _query_log_dir
    if cached is not None and _query_log_dir_source == main_log:
        return cached
    with _query_log_dir_lock:
        if _query_log_dir is not None and _query_log_dir_source == main_log:
            return _query_log_dir
        if main_log:
            base = Path(main_log).parent / "queries"
        else:
            base = (Path(__file__).resolve().parent.parent
                    / "data" / "logs" / "queries")
        try:
            base.mkdir(parents=True, exist_ok=True)
        except Exception:
            # Do NOT memoise a failure: an unwritable directory is a
            # transient state (a PVC that has not mounted yet), and
            # caching it would disable per-query logging for the life of
            # the pod.
            return None
        _query_log_dir = base
        _query_log_dir_source = main_log
        return base


def _get_master_logger() -> Optional[logging.Logger]:
    """Aggregate rolling log used by the cross-query 'every query summary' grep."""
    global _master_logger, _master_logger_dir
    base = _get_query_log_dir()
    if base is None:
        return None
    if _master_logger is not None and _master_logger_dir == base:
        return _master_logger
    lg = logging.getLogger("query.execution.master")
    lg.setLevel(logging.INFO)
    lg.propagate = False
    try:
        h = logging.handlers.RotatingFileHandler(
            str(base / "_all.log"), maxBytes=10 * 1024 * 1024,
            backupCount=5, encoding="utf-8",
        )
        h.setLevel(logging.INFO)
        h.setFormatter(logging.Formatter(
            "%(asctime)s.%(msecs)03d | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        ))
        for old in list(lg.handlers):
            # Close, not just detach: the old handler holds an open file
            # in the PREVIOUS directory, which on a test sandbox is about
            # to be deleted.  Removing without closing leaks the handle
            # and keeps writing there on Windows.
            lg.removeHandler(old)
            try:
                old.close()
            except Exception:
                pass
        lg.addHandler(h)
    except Exception:
        return None
    _master_logger = lg
    _master_logger_dir = base
    return lg


def _safe_eid(eid: str) -> str:
    return _EID_SAFE_RE.sub("_", eid)[:80] or "unknown"


def _eid_lock(eid: str) -> threading.Lock:
    """Per-execution file write lock so concurrent stage emits don't tear lines."""
    with _query_file_lookup_lock:
        lk = _query_file_locks.get(eid)
        if lk is None:
            lk = threading.Lock()
            _query_file_locks[eid] = lk
        return lk


def cleanup_old_query_logs(retention_days: int = 7,
                            max_files: int = 1000) -> int:
    """Delete per-query log files older than retention_days, capped at
    max_files newest.  Call from a scheduled job; safe to skip.
    """
    base = _get_query_log_dir()
    if base is None:
        return 0
    try:
        files = sorted(
            (p for p in base.glob("*.log") if p.name != "_all.log"),
            key=lambda p: p.stat().st_mtime, reverse=True,
        )
    except Exception:
        return 0
    deleted = 0
    cutoff = time.time() - retention_days * 86400
    for i, p in enumerate(files):
        try:
            if i >= max_files or p.stat().st_mtime < cutoff:
                p.unlink()
                deleted += 1
        except Exception:
            pass
    return deleted


def get_query_log_path(execution_id: str) -> Optional[Path]:
    """Return the per-query log file path for this execution_id.
    Returns None if logging dir isn't writable.  Public so the admin
    UI can offer a 'Download log' button."""
    base = _get_query_log_dir()
    if base is None:
        return None
    return base / f"{_safe_eid(execution_id)}.log"


def _qlog(execution_id: str, kind: str, stage: str,
          *, prev_stage: Optional[str] = None,
          prev_duration: Optional[float] = None,
          files_total: Optional[int] = None,
          files_done: Optional[int] = None,
          bytes_done: Optional[int] = None,
          message: str = "",
          extras: Optional[dict] = None) -> None:
    """Emit one line to BOTH the per-query file and the master aggregate.

    Pipe-separated for easy grep / cut / awk:
      TS | EID=<id> | KIND=stage|extras|progress|end|begin
         | STAGE=<name> | PREV=<prev_stage>:<duration>s
         | FILES=done/total | BYTES=<MB>MB | MSG=<truncated>
         | EXTRAS=k=v;k=v
    """
    parts = [f"EID={execution_id}", f"KIND={kind}", f"STAGE={stage}"]
    if prev_stage and prev_duration is not None:
        parts.append(f"PREV={prev_stage}:{prev_duration:.3f}s")
    if files_done is not None or files_total is not None:
        # 2026-08-04 — honest label.  ``files_done`` has exactly ONE
        # incrementer in the codebase: the S3 pre-download progress
        # callback (duckdb_views._on_progress).  On the native httpfs
        # path no downloader runs, so this counter CANNOT advance — the
        # old ``FILES=0/31`` token read as stalled scan progress and cost
        # a multi-hour misdiagnosis.  Name it what it is.
        parts.append(f"PREDL_FILES={files_done or 0}/{files_total or 0}")
    if bytes_done is not None and bytes_done > 0:
        mb = bytes_done / (1024 * 1024)
        parts.append(f"BYTES={mb:.1f}MB")
    if message:
        parts.append(f"MSG={message.replace('|', '/')[:200]}")
    if extras:
        kv = ";".join(f"{k}={v}" for k, v in extras.items())
        parts.append(f"EXTRAS={kv[:300]}")
    line = " | ".join(parts)
    ts_prefix = datetime.now(timezone.utc).astimezone().strftime(
        "%Y-%m-%d %H:%M:%S.") + f"{int((time.time() % 1) * 1000):03d}"

    # Per-query file — append, FLUSH after every line so the admin can
    # `cat` it WHILE the query is hung.  flush() is enough on Windows
    # local disk; fsync was tried but caused pile-up under high heartbeat
    # rate (KIND=progress fires every 5s) and may starve the event loop
    # via worker-thread GIL contention.  Trade: a hard-power-off could
    # lose the most recent line, but `cat` works fine.
    #
    # 2026-10-07 -- NOT ON THE EVENT LOOP.  The run coroutines call
    # begin/set_stage/end ON the loop, and this was an open + append + flush
    # + close of a file (plus the master log's write) inline there -- on an
    # NFS-backed logs dir, a stall for every request on the pod per stage
    # line (measured in-process as event-loop stall samples inside _qlog).
    # From a loop thread the line is formatted HERE (so its timestamp is the
    # event's) and the I/O is handed to ONE writer thread, which keeps every
    # line in order; from any other thread it is written inline, as before.
    if _on_event_loop_thread():
        _qlog_writer_submit(execution_id, kind, ts_prefix, line)
    else:
        _qlog_write(execution_id, kind, ts_prefix, line)


def _qlog_write(execution_id: str, kind: str, ts_prefix: str, line: str) -> None:
    """The I/O half of :func:`_qlog`: the per-query file, then the master."""
    path = get_query_log_path(execution_id)
    if path is not None:
        lk = _eid_lock(execution_id)
        try:
            with lk:
                with open(path, "a", encoding="utf-8") as fh:
                    fh.write(f"{ts_prefix} | {line}\n")
                    fh.flush()
        except Exception:
            pass

    # Master aggregate (rotating) for cross-query analysis
    mlg = _get_master_logger()
    if mlg is not None:
        try:
            mlg.info(line)
        except Exception:
            pass

    # KIND=end is the last line for this execution — drop the lock
    # entry so the dict doesn't grow unbounded.
    if kind == "end":
        with _query_file_lookup_lock:
            _query_file_locks.pop(execution_id, None)


def _on_event_loop_thread() -> bool:
    """True when the calling thread is running an asyncio event loop."""
    try:
        import asyncio
        return asyncio._get_running_loop() is not None
    except Exception:
        return False


_qlog_writer_lock = threading.Lock()
_qlog_writer_pool = None


def _qlog_writer_submit(execution_id: str, kind: str, ts_prefix: str, line: str) -> None:
    """Queue one line for the single writer thread (FIFO = line order).
    If the writer cannot be had (interpreter shutting down), write inline --
    a line is never dropped to protect the loop."""
    global _qlog_writer_pool
    try:
        pool = _qlog_writer_pool
        if pool is None or getattr(pool, "_shutdown", False):
            with _qlog_writer_lock:
                pool = _qlog_writer_pool
                if pool is None or getattr(pool, "_shutdown", False):
                    from concurrent.futures import ThreadPoolExecutor
                    pool = ThreadPoolExecutor(max_workers=1,
                                              thread_name_prefix="qs-query-log")
                    _qlog_writer_pool = pool
        pool.submit(_qlog_write, execution_id, kind, ts_prefix, line)
    except Exception:
        _qlog_write(execution_id, kind, ts_prefix, line)


def flush_query_log_writer(timeout: float = 5.0) -> None:
    """Wait until every line queued so far is written.

    TEST SEAM: a test that reads a per-query log right after an event-loop
    caller wrote it calls this first; production never needs to wait (the
    writer thread is a non-daemon pool thread, drained at interpreter exit).
    """
    pool = _qlog_writer_pool
    if pool is None or getattr(pool, "_shutdown", False):
        return
    try:
        pool.submit(lambda: None).result(timeout=timeout)
    except Exception:
        pass


# Stage names — keep these stable so the frontend can localise them
# (e.g. "Downloading files (1234 / 4273)").
STAGE_INIT             = "init"
STAGE_PARTITION_DETECT = "partition_detect"        # discover partition columns per registered table
STAGE_FILTER_EXTRACT   = "filter_extract"          # parse WHERE → partition + non-partition filters
STAGE_METADATA_READ    = "metadata_read"          # iceberg metadata.json read
STAGE_MANIFEST_PRUNE   = "manifest_prune"          # iceberg manifest pruning
STAGE_FILE_PRUNE       = "file_prune"              # iceberg per-entry pruning loop
STAGE_FILE_LISTING     = "file_listing"            # S3 ListObjectsV2
STAGE_PREDOWNLOAD      = "boto3_predownload"      # BF-251 parallel boto3 download
STAGE_DUCKDB_SETUP     = "duckdb_setup"           # CREATE VIEW, register tables
STAGE_DUCKDB_EXECUTE   = "duckdb_execute"         # actual SQL execution
STAGE_PARQUET_WRITE    = "parquet_write"          # writing result parquet
STAGE_DONE             = "done"


_REGISTRY: Dict[str, dict] = {}
_LOCK = threading.Lock()


def begin_execution(execution_id: str, total_files: int = 0) -> None:
    """Initialise tracking for a new execution_id."""
    if not execution_id:
        return
    with _LOCK:
        _REGISTRY[execution_id] = {
            "stage":          STAGE_INIT,
            "stage_started":  time.monotonic(),
            "files_total":    int(total_files or 0),
            "files_done":     0,
            "bytes_done":     0,
            "rows_done":      0,
            "message":        "",
            "updated_at":     time.monotonic(),
            # BF-297: accumulate per-stage durations so the execution
            # detail UI can show "metadata=0.2s manifests=14.8s
            # download=120s execute=8s" instead of just total elapsed.
            "stage_history":  [],
            "extras":         {},  # arbitrary key→value (e.g. iceberg cache_hit)
        }
    # BF-PRUNE-PERF-LOG: opening line for this execution in the dedicated log
    _qlog(execution_id, kind="begin", stage=STAGE_INIT, files_total=total_files)


def set_stage(execution_id: str, stage: str, *,
              files_total: Optional[int] = None,
              message: str = "") -> None:
    """Mark the start of a new stage.  Resets per-stage counters.

    BF-297: when transitioning from one stage to the next, append the
    completed stage + its duration to ``stage_history`` so the execution
    detail UI can show a per-step breakdown.
    """
    if not execution_id:
        return
    now = time.monotonic()
    _prev_stage_for_log: Optional[str] = None
    _prev_dur_for_log: Optional[float] = None
    with _LOCK:
        entry = _REGISTRY.get(execution_id)
        if entry is None:
            entry = {
                "stage":         stage,
                "stage_started": now,
                "files_total":   int(files_total or 0),
                "files_done":    0,
                "bytes_done":    0,
                "rows_done":     0,
                "message":       message,
                "updated_at":    now,
                "stage_history": [],
                "extras":        {},
            }
            _REGISTRY[execution_id] = entry
        else:
            # Record the completed stage's duration before flipping
            prev_stage = entry.get("stage")
            prev_started = entry.get("stage_started", now)
            if prev_stage and prev_stage != stage:
                _prev_stage_for_log = prev_stage
                _prev_dur_for_log = round(now - prev_started, 3)
                entry.setdefault("stage_history", []).append({
                    "stage":            prev_stage,
                    "stage_label":      humanise_stage(prev_stage),
                    "duration_seconds": _prev_dur_for_log,
                    "files_done":       int(entry.get("files_done", 0)),
                    "bytes_done":       int(entry.get("bytes_done", 0)),
                })
            entry["stage"]         = stage
            entry["stage_started"] = now
            if files_total is not None:
                entry["files_total"] = int(files_total)
            entry["files_done"] = 0
            entry["bytes_done"] = 0
            entry["rows_done"]  = 0
            entry["message"]    = message
            entry["updated_at"] = now
    # BF-PRUNE-PERF-LOG: emit one line per stage transition to the
    # dedicated query log.  Outside the lock so file-IO doesn't block.
    _qlog(execution_id, kind="stage", stage=stage,
          prev_stage=_prev_stage_for_log, prev_duration=_prev_dur_for_log,
          files_total=files_total, message=message)


def add_extras(execution_id: str, **kv: Any) -> None:
    """Stash arbitrary key/value pairs (e.g. iceberg_cache_hit=True) so
    they can be surfaced in execution details alongside the stage timing.
    """
    if not execution_id:
        return
    cur_stage = ""
    with _LOCK:
        entry = _REGISTRY.get(execution_id)
        if entry is None:
            return
        entry.setdefault("extras", {}).update(kv)
        cur_stage = entry.get("stage", "")
    # BF-PRUNE-PERF-LOG: log the new extras (typically iceberg cache-hit
    # flags, per-table timings, file pruning summary).
    _qlog(execution_id, kind="extras", stage=cur_stage, extras=dict(kv))


def get_stage_history(execution_id: str) -> list:
    """Return the recorded stage history (incl. the in-flight stage)."""
    if not execution_id:
        return []
    now = time.monotonic()
    with _LOCK:
        entry = _REGISTRY.get(execution_id)
        if entry is None:
            return []
        history = list(entry.get("stage_history") or [])
        # Append the in-flight stage as a pseudo-record so callers see
        # "currently executing X for Ys" as the last row.
        cur_stage = entry.get("stage")
        if cur_stage and cur_stage != STAGE_DONE:
            history.append({
                "stage":            cur_stage,
                "stage_label":      humanise_stage(cur_stage),
                "duration_seconds": round(now - entry.get("stage_started", now), 3),
                "files_done":       int(entry.get("files_done", 0)),
                "bytes_done":       int(entry.get("bytes_done", 0)),
                "in_flight":        True,
            })
        return history


def update_progress(execution_id: str, *,
                    files_done: Optional[int] = None,
                    files_delta: Optional[int] = None,
                    bytes_done: Optional[int] = None,
                    bytes_delta: Optional[int] = None,
                    rows_done: Optional[int] = None,
                    message: Optional[str] = None,
                    log: bool = True) -> None:
    """Increment counters or set absolute values.  All optional.

    BF-PRUNE-PERF-LOG: when ``log=True`` (default), also emit a KIND=progress
    line to the per-query log file so admins can grep `output_bytes=` ticking
    even when the subprocess is mid-COPY-TO (no stage transitions firing).
    Throttled: only emits when something actually changed since last call.
    """
    if not execution_id:
        return
    _emit_log = False
    _cur_stage = ""
    _cur_files = 0
    _cur_total = 0
    _cur_bytes = 0
    _cur_msg = ""
    with _LOCK:
        entry = _REGISTRY.get(execution_id)
        if entry is None:
            return
        if files_done is not None:
            entry["files_done"] = int(files_done)
        if files_delta:
            entry["files_done"] = int(entry["files_done"]) + int(files_delta)
        if bytes_done is not None:
            entry["bytes_done"] = int(bytes_done)
        if bytes_delta:
            entry["bytes_done"] = int(entry["bytes_done"]) + int(bytes_delta)
        if rows_done is not None:
            entry["rows_done"] = int(rows_done)
        if message is not None:
            entry["message"] = message
        entry["updated_at"] = time.monotonic()
        # Snapshot for log emit (outside lock)
        if log:
            _last_emit = entry.get("_last_progress_log_emit", 0.0)
            _last_bytes = entry.get("_last_progress_log_bytes", -1)
            _last_files = entry.get("_last_progress_log_files", -1)
            _now = entry["updated_at"]
            _cur_stage = entry.get("stage", "")
            _cur_files = int(entry.get("files_done", 0))
            _cur_total = int(entry.get("files_total", 0))
            _cur_bytes = int(entry.get("bytes_done", 0))
            _cur_msg = entry.get("message") or ""
            # Emit if 5+ seconds passed AND something changed
            if (_now - _last_emit >= 5.0
                    and (_cur_bytes != _last_bytes
                         or _cur_files != _last_files)):
                _emit_log = True
                entry["_last_progress_log_emit"] = _now
                entry["_last_progress_log_bytes"] = _cur_bytes
                entry["_last_progress_log_files"] = _cur_files
    if _emit_log:
        _qlog(execution_id, kind="progress", stage=_cur_stage,
              files_done=_cur_files, files_total=_cur_total,
              bytes_done=_cur_bytes, message=_cur_msg)


def get_snapshot(execution_id: str) -> Optional[dict]:
    """Return a copy of the current stage info, or None if not tracked.

    Includes derived fields:
      - stage_elapsed_seconds: time in current stage
      - throughput_bytes_per_sec: rolling estimate from this stage's start
    """
    if not execution_id:
        return None
    with _LOCK:
        entry = _REGISTRY.get(execution_id)
        if entry is None:
            return None
        snap = dict(entry)
    now = time.monotonic()
    stage_elapsed = max(0.001, now - snap["stage_started"])
    snap["stage_elapsed_seconds"] = round(stage_elapsed, 1)
    snap["throughput_bytes_per_sec"] = (
        int(snap["bytes_done"] / stage_elapsed) if snap["bytes_done"] else 0
    )
    # 2026-08-04 — files_done/files_total count PRE-DOWNLOADED files (its
    # only incrementer is the S3 pre-download callback), NOT scanned files.
    # Consumers rendering "X / Y files" must label it as pre-download or
    # hide it on the native-httpfs path, where it can never advance.
    snap["files_semantics"] = "predownload"
    return snap


def finalise_history(execution_id: str) -> dict:
    """BF-297: snapshot the full stage history with the final stage's
    duration recorded.  Call this from the engine's finally block BEFORE
    end_execution() so the breakdown can be persisted to the executions
    table for the detail UI.

    Returns a dict suitable for files_metadata['stage_history']:
        {
          "stages":      [{"stage": "...", "duration_seconds": N, ...}, ...],
          "extras":      {...},
          "total_seconds": N,
        }
    """
    if not execution_id:
        return {"stages": [], "extras": {}, "total_seconds": 0.0}
    now = time.monotonic()
    with _LOCK:
        entry = _REGISTRY.get(execution_id)
        if entry is None:
            return {"stages": [], "extras": {}, "total_seconds": 0.0}
        history = list(entry.get("stage_history") or [])
        cur_stage = entry.get("stage")
        if cur_stage and cur_stage not in (STAGE_DONE, STAGE_INIT):
            history.append({
                "stage":            cur_stage,
                "stage_label":      humanise_stage(cur_stage),
                "duration_seconds": round(now - entry.get("stage_started", now), 3),
                "files_done":       int(entry.get("files_done", 0)),
                "bytes_done":       int(entry.get("bytes_done", 0)),
            })
        total = sum(float(h.get("duration_seconds", 0)) for h in history)
        return {
            "stages":         history,
            "extras":         dict(entry.get("extras") or {}),
            "total_seconds":  round(total, 3),
        }


def end_execution(execution_id: str) -> None:
    """Drop the tracker entry — called from the engine's finally block.
    Idempotent: missing entries are silently ignored."""
    if not execution_id:
        return
    # BF-PRUNE-PERF-LOG: closing line with full per-stage durations
    final: Optional[dict] = None
    last_stage = ""
    with _LOCK:
        entry = _REGISTRY.get(execution_id)
        if entry is not None:
            now = time.monotonic()
            history = list(entry.get("stage_history") or [])
            cur_stage = entry.get("stage")
            if cur_stage and cur_stage not in (STAGE_DONE, STAGE_INIT):
                history.append({
                    "stage":            cur_stage,
                    "duration_seconds": round(now - entry.get("stage_started", now), 3),
                })
            last_stage = cur_stage or ""
            final = {
                "stages": history,
                "extras": dict(entry.get("extras") or {}),
                "total":  round(sum(float(h.get("duration_seconds", 0)) for h in history), 3),
            }
        _REGISTRY.pop(execution_id, None)
    if final is not None:
        _summary = ";".join(
            f"{h.get('stage','?')}={h.get('duration_seconds',0):.2f}s"
            for h in final["stages"]
        )
        _qlog(execution_id, kind="end", stage=last_stage,
              message=f"total={final['total']:.2f}s breakdown=[{_summary}]",
              extras=final["extras"])


def registry_size() -> int:
    """For tests / observability."""
    with _LOCK:
        return len(_REGISTRY)


def humanise_stage(stage: str) -> str:
    """Frontend-friendly stage label."""
    return {
        STAGE_INIT:             "Initialising",
        STAGE_PARTITION_DETECT: "Detecting partition columns",
        STAGE_FILTER_EXTRACT:   "Extracting filters from WHERE",
        STAGE_METADATA_READ:    "Reading Iceberg metadata",
        STAGE_MANIFEST_PRUNE:   "Pruning manifest files",
        STAGE_FILE_PRUNE:       "Pruning files (partition + column stats)",
        STAGE_FILE_LISTING:     "Listing S3 files",
        STAGE_PREDOWNLOAD:      "Downloading files from S3",
        STAGE_DUCKDB_SETUP:     "Registering tables in DuckDB",
        STAGE_DUCKDB_EXECUTE:   "Executing SQL (join / group by / scan)",
        STAGE_PARQUET_WRITE:    "Writing result file",
        STAGE_DONE:             "Done",
    }.get(stage, stage)
