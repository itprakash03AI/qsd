import threading
import time
from typing import Any, Optional


class TTLCache:
    """Thread-safe TTL cache with maximum entry limit and proactive eviction."""

    def __init__(self, ttl_seconds: int = 300, max_entries: int = 1000):
        self._cache = {}
        self._lock = threading.Lock()
        self._ttl = ttl_seconds
        self._max_entries = max_entries

    def get(self, key: str) -> Optional[Any]:
        with self._lock:
            entry = self._cache.get(key)
            if entry and time.time() - entry['time'] < self._ttl:
                return entry['value']
            elif entry:
                del self._cache[key]
            return None

    def set(self, key: str, value: Any):
        with self._lock:
            now = time.time()
            # Evict expired entries if approaching limit
            if len(self._cache) >= self._max_entries:
                expired = [k for k, v in self._cache.items() if now - v['time'] >= self._ttl]
                for k in expired:
                    del self._cache[k]
            # If still at limit, evict oldest entry
            if len(self._cache) >= self._max_entries:
                oldest_key = min(self._cache, key=lambda k: self._cache[k]['time'])
                del self._cache[oldest_key]
            self._cache[key] = {'value': value, 'time': now}

    def invalidate(self, key: str = None):
        with self._lock:
            if key:
                self._cache.pop(key, None)
            else:
                self._cache.clear()

    def delete(self, key: str) -> bool:
        """BF-555 (2026-05-29): explicit single-key delete API.  Used
        by the connection-update endpoint to drop one entry without
        clearing the whole cache."""
        with self._lock:
            return self._cache.pop(key, None) is not None

    def delete_prefix(self, prefix: str) -> int:
        """BF-555 (2026-05-29): drop every entry whose key starts
        with ``prefix``.  Used to invalidate all schema-cache entries
        for one connection (keys are formatted ``"sql:<conn_id>:<tbl>"``
        and ``"<conn_id>:<tbl>"``).  Returns count dropped."""
        if not prefix:
            return 0
        with self._lock:
            to_drop = [k for k in self._cache if k.startswith(prefix)]
            for k in to_drop:
                self._cache.pop(k, None)
            return len(to_drop)

    def cleanup_expired(self):
        """Remove all expired entries. Call periodically (e.g. via scheduler)."""
        with self._lock:
            now = time.time()
            expired = [k for k, v in self._cache.items() if now - v['time'] >= self._ttl]
            for k in expired:
                del self._cache[k]
            return len(expired)

    @property
    def size(self) -> int:
        return len(self._cache)


# Global caches
#
# 2026-08-02 multi-pod classification (fleet-safety review): both caches
# below are PROVABLY-HARMLESS performance caches, deliberately left
# process-local — unlike the CORRECTNESS-BEARING Iceberg snapshot pointer
# (core/iceberg_snapshot_cache.SnapshotPointerCache, DB-verified) and the
# connection-derived caches (cache_layer "schema"/"partition" + the
# ConnectionManager handler cache, all bound to the "connections"
# coherence epoch):
#
#   * ``schema_cache`` — sole consumer is core/optimized_engine
#     (_get_total_columns): the column COUNT of a parquet file at a given
#     path.  Parquet files are immutable once written; an overwritten
#     path converges within the 5-min TTL on every pod, which is the same
#     bound today's single pod already has.  Cross-pod divergence window
#     <= the existing single-pod staleness window → duplicate work at
#     worst, never a different query answer.
#   * ``file_list_cache`` — sole consumer is core/query_cache
#     (get_file_mod_times): mod-time proxies feeding the result-cache
#     KEY.  A stale entry can only make a pod MISS the result cache (or
#     reuse a result within the same 2-min freshness bound that a single
#     pod already accepts); Iceberg enumeration/pruning does not flow
#     through it.
#
# If either ever gains a correctness-bearing consumer, bind it to a
# core.cache_coherence namespace instead of widening the TTL assumptions.
schema_cache = TTLCache(ttl_seconds=300, max_entries=500)     # 5 min for schemas
file_list_cache = TTLCache(ttl_seconds=120, max_entries=200)  # 2 min for file listings
