"""2026-07-15 — user-facing "Why did this query scan N files?" diagnostics.

The pruning brain stamps rich diagnostics into ``_out_meta`` during
``get_iceberg_data_files`` (scan_ledger, prunability, bloom_needed,
stats_coverage, adaptive_freshness, duplicate_data_file_refs,
snapshot_total_data_files).  Until now those only reached LOGS.

``build_brain_diagnostics`` summarises them into ONE compact, JSON-safe
per-table blob that rides the existing ``execution_stage`` extras pipeline
(key ``brain_diagnostics__{table_qual}``) so:
  - the live heartbeat WS event can narrate pruning while the query runs;
  - GET /api/executions/{id}/status exposes it for WS-drop recovery;
  - the persisted files_metadata.stage_history.extras serves the
    completed-query "Why N files?" panel.

PURE READ / SUMMARISE — this module never mutates ``_out_meta``, never
touches the file list, and every consumer treats a missing key as
"diagnostic not available" (fail-soft).  Payload is deliberately capped
(column dicts truncated, reason strings trimmed) so the heartbeat WS
frame stays small — a prior incident (see execute_api NOTE near the
heartbeat broadcast) taught us not to dump raw extras into the live
stream.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

# Hard caps so a 9000-column table can't bloat the WS frame.
_MAX_COLUMNS = 12
_MAX_REASON_CHARS = 200

#: extras-key prefix shared by producer (iceberg_reader) and consumers
#: (execute_api heartbeat + /status endpoint, frontend panel).
EXTRAS_KEY_PREFIX = "brain_diagnostics__"


def _int_or_none(v: Any) -> Optional[int]:
    try:
        return int(v) if v is not None else None
    except (TypeError, ValueError):
        return None


def _trim(s: Any, cap: int = _MAX_REASON_CHARS) -> str:
    txt = str(s or "")
    return txt if len(txt) <= cap else txt[: cap - 1] + "…"


def build_brain_diagnostics(
    out_meta: Dict[str, Any],
    *,
    table_prefix: str,
    files_scanned: int,
    files_considered: int,
    skipped_partition: int = 0,
    skipped_col_stats: int = 0,
    connection_id: Optional[int] = None,
    table_name: Optional[str] = None,
) -> Dict[str, Any]:
    """Summarise ``out_meta`` diagnostics into one compact JSON-safe dict.

    Missing keys are simply omitted (fail-soft — the UI hides that row).
    Returns ``{}`` when there is nothing worth surfacing (callers skip
    the extras push entirely in that case).
    """
    blob: Dict[str, Any] = {
        "table":               (table_prefix or "").rstrip("/"),
        "files_scanned":       int(files_scanned or 0),
        "files_considered":    int(files_considered or 0),
        "skipped_by_partition": int(skipped_partition or 0),
        "skipped_by_col_stats": int(skipped_col_stats or 0),
    }
    # table_name + connection_id let the frontend "Build now" button call
    # POST /api/admin/iceberg/bloom/scan without guessing identifiers.
    if table_name:
        blob["table_name"] = str(table_name)
    if connection_id is not None:
        blob["connection_id"] = _int_or_none(connection_id)

    if not isinstance(out_meta, dict):
        return blob

    # ── scan ledger (verdict: ok / over_count / under_count / …) ─────────
    try:
        ledger = out_meta.get("scan_ledger")
        if isinstance(ledger, dict) and ledger.get("verdict"):
            blob["scan_ledger"] = {
                "verdict":          str(ledger.get("verdict")),
                "considered":       _int_or_none(ledger.get("considered")),
                "final":            _int_or_none(ledger.get("final")),
                "declared_total":   _int_or_none(ledger.get("declared_total")),
                "delta_considered": _int_or_none(ledger.get("delta_considered")),
            }
    except Exception:  # pragma: no cover — defensive
        pass

    # ── per-column prunability profile ───────────────────────────────────
    try:
        prun = out_meta.get("prunability")
        if isinstance(prun, dict) and prun:
            out: Dict[str, Any] = {}
            for col in sorted(prun)[:_MAX_COLUMNS]:
                p = prun.get(col)
                if not isinstance(p, dict):
                    continue
                out[str(col)] = {
                    "stats_coverage_pct":   p.get("stats_coverage_pct"),
                    "bounds_overlap_ratio": p.get("bounds_overlap_ratio"),
                    "singleton_ratio":      p.get("singleton_ratio"),
                    "has_bloom":            bool(p.get("has_bloom")),
                    "bloom_needed":         bool(p.get("bloom_needed")),
                    "reason":               _trim(p.get("reason", "")),
                }
            if out:
                blob["prunability"] = out
    except Exception:  # pragma: no cover
        pass

    # ── bloom routing decision ────────────────────────────────────────────
    try:
        bn = out_meta.get("bloom_needed")
        if isinstance(bn, dict) and bn.get("columns"):
            cols = [str(c) for c in (bn.get("columns") or [])][:_MAX_COLUMNS]
            reasons = bn.get("reasons") or {}
            blob["bloom_needed"] = {
                "columns": cols,
                "reasons": {c: _trim(reasons.get(c, "")) for c in cols
                            if reasons.get(c)},
                "routed":  str(bn.get("routed") or ""),
            }
    except Exception:  # pragma: no cover
        pass

    # ── table-level stats coverage (value-independent) ───────────────────
    try:
        cov = out_meta.get("stats_coverage")
        if isinstance(cov, dict) and cov:
            out_cov: Dict[str, Any] = {}
            for col in sorted(cov)[:_MAX_COLUMNS]:
                c = cov.get(col)
                if not isinstance(c, dict):
                    continue
                out_cov[str(col)] = {
                    "files_with_bounds": _int_or_none(c.get("files_with_bounds")),
                    "total_enumerated":  _int_or_none(c.get("total_enumerated")),
                }
            if out_cov:
                blob["stats_coverage"] = out_cov
    except Exception:  # pragma: no cover
        pass

    # ── adaptive freshness (stale-snapshot detector) ─────────────────────
    try:
        af = out_meta.get("adaptive_freshness")
        if isinstance(af, dict) and (af.get("trigger") or af.get("refreshed")):
            blob["adaptive_freshness"] = {
                "trigger":   _trim(af.get("trigger", ""), 120),
                "refreshed": bool(af.get("refreshed")),
            }
    except Exception:  # pragma: no cover
        pass

    # ── duplicate manifest references + declared snapshot total ─────────
    dup = _int_or_none(out_meta.get("duplicate_data_file_refs"))
    if dup:
        blob["duplicate_data_file_refs"] = dup
    declared = _int_or_none(out_meta.get("snapshot_total_data_files"))
    if declared is not None:
        blob["snapshot_total_data_files"] = declared

    return blob


#: reserved brain-diagnostics map key carrying the per-query STAGE TIMING
#: summary (not a table qualifier).  Table quals always contain dots and
#: never collide with this sentinel, so it rides the same map the panel
#: already forwards without needing a new response field / new prop.
TIMING_MAP_KEY = "__timing__"


def build_timing_summary(
    latency_breakdown: Optional[Dict[str, Any]],
) -> Dict[str, int]:
    """Compact per-query STAGE-TIMING summary (milliseconds) for the
    "Where the time went" row of the "Why N files?" panel.

    Source — PURE READ of the already-emitted per-query latency
    breakdown (``core.brain_latency_breakdown.LatencyBreakdown.as_dict``)
    that ``execute_query_background`` persists into
    ``files_metadata['latency_breakdown']`` at completion.  The
    coldstart / s3 / compute split originates in
    ``duckdb_subprocess._attribute_child_latency`` (Phase 164); the
    planning split from the iceberg manifest walk + brain pruning
    stages.  NO new instrumentation is added here — this only reshapes
    values that already exist.

    Mapping (seconds -> ms):
      * ``coldstart_ms`` = ``coldstart_seconds`` (subprocess spawn +
        ``import duckdb`` + ``LOAD httpfs`` + S3 cred/SSL setup)
      * ``s3_ms``        = ``s3_seconds``        (parquet bytes on the wire)
      * ``compute_ms``   = ``compute_seconds``   (real DuckDB scan/aggregate)
      * ``planning_ms``  = ``metadata_seconds`` + ``pruning_seconds``
        (iceberg manifest walk + brain pruning layers, both pre-compute)
      * ``total_ms``     = ``total_seconds``

    Fail-soft: returns ``{}`` when the breakdown is missing/empty or has
    no positive total; individual keys are omitted when their source
    value isn't a finite number (never fabricated / never guessed).
    """
    if not isinstance(latency_breakdown, dict):
        return {}

    def _ms(key: str) -> Optional[int]:
        v = latency_breakdown.get(key)
        try:
            f = float(v)
        except (TypeError, ValueError):
            return None
        if f != f:  # NaN
            return None
        return int(round(f * 1000.0))

    total = _ms("total_seconds")
    if not total or total <= 0:
        # Nothing worth surfacing — no completed timing yet (fail-soft).
        return {}

    out: Dict[str, int] = {}
    for src, dst in (("coldstart_seconds", "coldstart_ms"),
                     ("s3_seconds",        "s3_ms"),
                     ("compute_seconds",   "compute_ms")):
        if src in latency_breakdown:
            m = _ms(src)
            if m is not None:
                out[dst] = m

    # planning = iceberg metadata walk + brain pruning (both pre-compute).
    plan_ms = 0
    plan_seen = False
    for k in ("metadata_seconds", "pruning_seconds"):
        if k in latency_breakdown:
            m = _ms(k)
            if m is not None:
                plan_ms += m
                plan_seen = True
    if plan_seen:
        out["planning_ms"] = plan_ms

    out["total_ms"] = total
    return out


def extract_brain_diagnostics(extras: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Pull ``brain_diagnostics__{table}`` entries out of a stage-extras
    dict, keyed by the bare table qualifier.  Fail-soft: anything that
    isn't a dict is skipped; a bad input returns ``{}``.
    """
    result: Dict[str, Any] = {}
    if not isinstance(extras, dict):
        return result
    # Snapshot: execution_stage.get_snapshot() returns a SHALLOW copy whose
    # ``extras`` dict is shared with the live registry — a worker thread can
    # add_extras() while we iterate.  list() makes iteration safe.
    try:
        items = list(extras.items())
    except Exception:  # pragma: no cover — mid-mutation race
        return result
    for k, v in items:
        try:
            if (isinstance(k, str) and k.startswith(EXTRAS_KEY_PREFIX)
                    and isinstance(v, dict)):
                result[k[len(EXTRAS_KEY_PREFIX):] or "_unknown"] = v
        except Exception:  # pragma: no cover
            continue
    return result
