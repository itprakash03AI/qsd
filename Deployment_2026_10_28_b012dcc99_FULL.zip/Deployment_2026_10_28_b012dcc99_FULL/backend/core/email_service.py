"""
Email Notification Service — SMTP-based

Sends HTML emails for:
  - Scheduled job completion / failure
  - Query execution completion (optional)
  - System alerts

Configuration (highest → lowest priority):
  1. Runtime override via configure_email() (API call)
  2. config.json  email.*  section
  3. Environment variables (legacy):
       SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD,
       SMTP_USE_TLS, SMTP_USE_SSL, EMAIL_FROM, EMAIL_FROM_NAME
"""

from __future__ import annotations

import html as _html_mod
import logging
import os
import re as _re
import smtplib
import ssl
from datetime import datetime, timezone
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import List, Optional, Tuple

logger = logging.getLogger(__name__)


def _cfg(key: str, default: str = "") -> str:
    return os.environ.get(key, default).strip()


def _cfg_bool(key: str, default: bool = True) -> bool:
    val = os.environ.get(key, "").strip().lower()
    if not val:
        return default
    return val in ("1", "true", "yes", "on")


def _cfg_int(key: str, default: int = 587) -> int:
    try:
        return int(os.environ.get(key, str(default)))
    except ValueError:
        return default


# ─── Runtime config ──────────────────────────────────────────────────────────
# Resolution order: config.json email.* > legacy SMTP_* env vars > built-in
# defaults, with anything passed to configure_email() layered on top.
#
# 2026-09-16 — the comment here used to say "can be overridden via
# /api/email/configure".  THERE IS NO SUCH ROUTE, anywhere in the tree; the
# sentence described a surface that does not exist, which is the trap
# CLAUDE.md names ("read the code, not the docstring").
#
# The resolution was also a ONE-TIME SNAPSHOT taken at module import, and
# ``configure_email`` -- the only way to refresh it -- had no caller.  That
# matters because ``core.config``'s DB overlay is attached during startup:
# whichever code first imported this module froze SMTP for the life of the
# process, and an operator changing the relay in the database afterwards
# could never take effect without a restart.  Resolution is now per call,
# and configure_email is the override LAYER it always claimed to be.
def _init_email_config() -> dict:
    try:
        from core.config import email as _ecfg
        host = _ecfg.host or _cfg("SMTP_HOST", "")
        port = _ecfg.port if _ecfg.host else _cfg_int("SMTP_PORT", 587)
        user = _ecfg.user or _cfg("SMTP_USER")
        pwd  = _ecfg.password or _cfg("SMTP_PASSWORD")
        from_addr = _ecfg.from_address or _cfg("EMAIL_FROM", "noreply@queryengine.local")
        use_tls = _ecfg.use_tls if _ecfg.host else _cfg_bool("SMTP_USE_TLS", True)
    except Exception:
        # Fallback to pure env vars if config module unavailable
        host = _cfg("SMTP_HOST", "")
        port = _cfg_int("SMTP_PORT", 587)
        user = _cfg("SMTP_USER")
        pwd  = _cfg("SMTP_PASSWORD")
        from_addr = _cfg("EMAIL_FROM", "noreply@queryengine.local")
        use_tls = _cfg_bool("SMTP_USE_TLS", True)
    return {
        "host":      host,
        "port":      port,
        "user":      user,
        "password":  pwd,
        "use_tls":   use_tls,
        "use_ssl":   _cfg_bool("SMTP_USE_SSL", False),
        "from_addr": from_addr,
        "from_name": _cfg("EMAIL_FROM_NAME", "Query Engine"),
        "enabled":   bool(host),
    }

#: Explicit overrides layered OVER the resolved config.  Empty by default,
#: so a deployment that never calls configure_email behaves exactly as the
#: import-time snapshot did -- except that it now picks up a database
#: setting applied after this module was first imported.
_email_overrides: dict = {}


def _effective_email_config() -> dict:
    """The settings a send should use, resolved NOW.

    Cheap: a handful of dict/env reads, against an SMTP round trip.  Doing
    it per call is what makes a relay change take effect without a restart.
    """
    cfg = _init_email_config()
    if _email_overrides:
        cfg.update(_email_overrides)
        cfg["enabled"] = bool(cfg.get("host"))
    return cfg


def configure_email(config: dict) -> None:
    """Override SMTP settings at runtime.

    Layered over the resolved config rather than replacing it, so an
    override of one field does not erase the rest.  Pass ``{}`` to clear.
    """
    global _email_overrides
    if not config:
        _email_overrides = {}
        logger.info("Email configuration overrides cleared")
        return
    _email_overrides.update(config)
    eff = _effective_email_config()
    logger.info("Email configuration updated (host=%s, port=%s)",
                eff.get("host"), eff.get("port"))


def get_email_config() -> dict:
    """Return current EFFECTIVE config (password masked)."""
    safe = _effective_email_config()
    if safe.get("password"):
        safe["password"] = "••••••"
    return safe


def is_email_enabled() -> bool:
    _eff = _effective_email_config()
    return bool(_eff.get("enabled") and _eff.get("host"))


#: The ONE wording for "this deployment has no mail relay".  Written for the
#: feed step ``email_receipt`` (core/feed/step_model/steps/notify.py) and
#: adopted by the feed engine's ``_send_notifications`` on 2026-09-15, when
#: that path was found never to have reached a mailbox.  Every caller that
#: declines to send for this reason quotes this constant, so an operator
#: greps ONE string across step rows, run records and logs.
NOT_CONFIGURED_REASON = (
    "the e-mail service is not configured (config email.host / email.enabled)"
)


# ─── Why the last send on THIS thread failed ─────────────────────────────────
# AQD-09 (2026-09-23).  The send functions return a bool, and every caller that
# records a failure had nothing to record but the bool: subscription history
# rows said "Email send returned False" while the real cause -- here, an empty
# ``email.host`` -- was known one line earlier and dropped.  The bool contract
# stays (callers and a dozen test doubles depend on it); the REASON is kept
# beside it, per thread, so concurrent sends on different threads cannot read
# each other's cause.  A caller that wants it clears it, sends, and reads it.
import threading as _threading

_send_failure = _threading.local()


def clear_send_failure_reason() -> None:
    """Forget the last failure on this thread -- call immediately before a send."""
    _send_failure.reason = ""


def last_send_failure_reason() -> str:
    """Why the most recent send on THIS thread returned False ("" if none)."""
    return getattr(_send_failure, "reason", "") or ""


def _fail(reason: str) -> bool:
    _send_failure.reason = reason
    return False


_EMAIL_RE = _re.compile(r'^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$')


def _valid_recipients(to_addresses: List[str]) -> List[str]:
    """Header-injection-safe recipient list (the one validation both senders use)."""
    return [a for a in (to_addresses or []) if _EMAIL_RE.match(a.strip())]


# ─── Core send function ───────────────────────────────────────────────────────

def send_email(
    to_addresses: List[str],
    subject: str,
    html_body: str,
    text_body: Optional[str] = None,
    max_retries: int = 3,
    retry_delay: float = 2.0,
) -> bool:
    """
    Send an HTML email with exponential-backoff retry.

    Returns True on success, False after all retries exhausted.
    Never raises — logs errors instead.
    """
    import time as _time

    clear_send_failure_reason()
    if not is_email_enabled():
        logger.debug("Email not configured — skipping send to %s", to_addresses)
        return _fail(NOT_CONFIGURED_REASON)

    if not to_addresses:
        return _fail("no recipient address was given")

    # Validate email addresses — reject header injection attempts
    validated = _valid_recipients(to_addresses)
    if not validated:
        logger.warning("No valid email addresses after validation: %s", to_addresses)
        return _fail(f"no valid recipient address (rejected: {', '.join(to_addresses)})")
    to_addresses = validated

    cfg = _effective_email_config()
    from_header = f"{cfg['from_name']} <{cfg['from_addr']}>" if cfg.get("from_name") else cfg["from_addr"]

    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"]    = from_header
    msg["To"]      = ", ".join(to_addresses)
    msg["Date"]    = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")

    # Plain-text fallback
    plain = text_body or _html_to_plain(html_body)
    msg.attach(MIMEText(plain, "plain", "utf-8"))
    msg.attach(MIMEText(html_body, "html",  "utf-8"))

    last_error = None
    for attempt in range(max_retries):
        try:
            if cfg.get("use_ssl"):
                context = ssl.create_default_context()
                with smtplib.SMTP_SSL(cfg["host"], cfg["port"], context=context) as server:
                    _auth_and_send(server, cfg, from_header, to_addresses, msg)
            else:
                with smtplib.SMTP(cfg["host"], cfg["port"], timeout=15) as server:
                    server.ehlo()
                    if cfg.get("use_tls"):
                        server.starttls(context=ssl.create_default_context())
                        server.ehlo()
                    _auth_and_send(server, cfg, from_header, to_addresses, msg)

            logger.info("Email sent to %s — %r (attempt %d/%d)",
                        to_addresses, subject, attempt + 1, max_retries)
            return True

        except Exception as exc:
            last_error = str(exc)
            logger.warning("Email attempt %d/%d failed for %s: %s",
                           attempt + 1, max_retries, to_addresses, exc)
            if attempt < max_retries - 1:
                delay = retry_delay * (2 ** attempt)   # 2s, 4s, 8s
                _time.sleep(delay)

    logger.error("Email failed after %d attempts to %s: %s",
                 max_retries, to_addresses, last_error)
    return _fail(f"SMTP delivery via {cfg['host']}:{cfg['port']} failed after "
                 f"{max_retries} attempt(s): {last_error}")


def send_email_with_attachment(
    to_addresses: List[str],
    subject: str,
    html_body: str,
    attachments: Optional[List[Tuple[bytes, str, str]]] = None,
    max_retries: int = 3,
    retry_delay: float = 2.0,
) -> bool:
    """Send an HTML email with optional file attachments.

    Each attachment is a tuple of (data_bytes, filename, content_type).
    Returns True on success, False after all retries exhausted.
    """
    import time as _time

    clear_send_failure_reason()
    if not is_email_enabled():
        logger.debug("Email not configured — skipping send to %s", to_addresses)
        return _fail(NOT_CONFIGURED_REASON)
    if not to_addresses:
        return _fail("no recipient address was given")

    validated = _valid_recipients(to_addresses)
    if not validated:
        logger.warning("No valid email addresses after validation: %s", to_addresses)
        return _fail(f"no valid recipient address (rejected: {', '.join(to_addresses)})")
    to_addresses = validated

    cfg = _effective_email_config()
    from_header = f"{cfg['from_name']} <{cfg['from_addr']}>" if cfg.get("from_name") else cfg["from_addr"]

    msg = MIMEMultipart("mixed")
    msg["Subject"] = subject
    msg["From"]    = from_header
    msg["To"]      = ", ".join(to_addresses)
    msg["Date"]    = datetime.now(timezone.utc).strftime("%a, %d %b %Y %H:%M:%S +0000")

    # HTML body as alternative sub-part
    body_part = MIMEMultipart("alternative")
    body_part.attach(MIMEText(_html_to_plain(html_body), "plain", "utf-8"))
    body_part.attach(MIMEText(html_body, "html", "utf-8"))
    msg.attach(body_part)

    # Attachments
    for data, filename, content_type in (attachments or []):
        part = MIMEApplication(data, Name=filename)
        part["Content-Disposition"] = f'attachment; filename="{filename}"'
        msg.attach(part)

    last_error = None
    for attempt in range(max_retries):
        try:
            if cfg.get("use_ssl"):
                context = ssl.create_default_context()
                with smtplib.SMTP_SSL(cfg["host"], cfg["port"], context=context) as server:
                    _auth_and_send(server, cfg, from_header, to_addresses, msg)
            else:
                with smtplib.SMTP(cfg["host"], cfg["port"], timeout=15) as server:
                    server.ehlo()
                    if cfg.get("use_tls"):
                        server.starttls(context=ssl.create_default_context())
                        server.ehlo()
                    _auth_and_send(server, cfg, from_header, to_addresses, msg)

            logger.info("Email with attachment sent to %s — %r (attempt %d/%d)",
                        to_addresses, subject, attempt + 1, max_retries)
            return True

        except Exception as exc:
            last_error = str(exc)
            logger.warning("Email attempt %d/%d failed for %s: %s",
                           attempt + 1, max_retries, to_addresses, exc)
            if attempt < max_retries - 1:
                _time.sleep(retry_delay * (2 ** attempt))

    logger.error("Email with attachment failed after %d attempts to %s: %s",
                 max_retries, to_addresses, last_error)
    return _fail(f"SMTP delivery via {cfg['host']}:{cfg['port']} failed after "
                 f"{max_retries} attempt(s): {last_error}")


def _auth_and_send(server: smtplib.SMTP, cfg: dict, from_addr: str, to_addrs: List[str], msg) -> None:
    # Set socket timeout on send to avoid hanging forever
    if hasattr(server, 'sock') and server.sock:
        server.sock.settimeout(30)
    if cfg.get("user") and cfg.get("password"):
        server.login(cfg["user"], cfg["password"])
    server.sendmail(from_addr, to_addrs, msg.as_string())


def _html_to_plain(html: str) -> str:
    """Very basic HTML → plain text fallback."""
    import re
    text = re.sub(r"<br\s*/?>", "\n", html, flags=re.IGNORECASE)
    text = re.sub(r"<[^>]+>", "", text)
    text = re.sub(r"&amp;",  "&",  text)
    text = re.sub(r"&lt;",   "<",  text)
    text = re.sub(r"&gt;",   ">",  text)
    text = re.sub(r"&nbsp;", " ",  text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


# ─── SMTP connection test ──────────────────────────────────────────────────────

def test_smtp_connection() -> dict:
    """Test SMTP connectivity. Returns {success, message}."""
    cfg = _effective_email_config()
    if not cfg.get("host"):
        return {"success": False, "message": "SMTP host not configured"}
    try:
        if cfg.get("use_ssl"):
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(cfg["host"], cfg["port"], context=context, timeout=10) as s:
                if cfg.get("user") and cfg.get("password"):
                    s.login(cfg["user"], cfg["password"])
        else:
            with smtplib.SMTP(cfg["host"], cfg["port"], timeout=10) as s:
                s.ehlo()
                if cfg.get("use_tls"):
                    s.starttls(context=ssl.create_default_context())
                    s.ehlo()
                if cfg.get("user") and cfg.get("password"):
                    s.login(cfg["user"], cfg["password"])
        return {"success": True, "message": f"Connected to {cfg['host']}:{cfg['port']} successfully"}
    except Exception as exc:
        return {"success": False, "message": str(exc)}


# ─── HTML email templates ──────────────────────────────────────────────────────

_BASE_STYLE = """
body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
       background: #f8fafc; margin: 0; padding: 24px; color: #0f172a; }
.card { background: #fff; border-radius: 8px; padding: 32px; max-width: 600px;
        margin: 0 auto; box-shadow: 0 1px 3px rgba(0,0,0,.1); }
.header { border-bottom: 2px solid #e2e8f0; padding-bottom: 16px; margin-bottom: 24px; }
.title { font-size: 20px; font-weight: 700; color: #1565c0; }
.label { font-size: 12px; color: #64748b; text-transform: uppercase;
         letter-spacing: .05em; margin-bottom: 4px; }
.value { font-size: 14px; color: #0f172a; margin-bottom: 16px; }
.badge-success { background: #d1fae5; color: #065f46; padding: 4px 10px;
                 border-radius: 12px; font-size: 12px; font-weight: 600; }
.badge-error   { background: #fee2e2; color: #991b1b; padding: 4px 10px;
                 border-radius: 12px; font-size: 12px; font-weight: 600; }
.footer { font-size: 12px; color: #94a3b8; margin-top: 24px; padding-top: 16px;
          border-top: 1px solid #e2e8f0; }
"""


def build_schedule_completion_email(
    schedule_name: str,
    status: str,           # "completed" | "failed"
    output_file: Optional[str],
    row_count: Optional[int],
    duration_seconds: Optional[float],
    error_message: Optional[str],
    run_at: Optional[str],
) -> tuple[str, str]:
    """Returns (subject, html_body)."""
    ok = status == "completed"
    badge_cls = "badge-success" if ok else "badge-error"
    status_label = "Completed" if ok else "Failed"

    # Sanitize user-controlled strings to prevent email header injection and HTML injection
    _safe_name = _html_mod.escape(str(schedule_name).replace("\r", "").replace("\n", ""))
    subject = f"[Query Engine] Schedule '{_safe_name}' {status_label}"

    rows_html = ""
    if row_count is not None:
        rows_html = f"<div class='label'>Rows Exported</div><div class='value'>{int(row_count):,}</div>"

    duration_html = ""
    if duration_seconds is not None:
        secs = int(duration_seconds)
        duration_html = f"<div class='label'>Duration</div><div class='value'>{secs}s</div>"

    file_html = ""
    if output_file:
        fname = _html_mod.escape(output_file.rsplit("/", 1)[-1].rsplit("\\", 1)[-1])
        file_html = f"<div class='label'>Output File</div><div class='value'>{fname}</div>"

    error_html = ""
    if not ok and error_message:
        _safe_err = _html_mod.escape(str(error_message)[:500])  # truncate to prevent huge emails
        error_html = f"""
        <div class='label'>Error</div>
        <div class='value' style='color:#991b1b;background:#fee2e2;padding:12px;border-radius:6px;font-size:13px;'>
            {_safe_err}
        </div>"""

    run_html = ""
    if run_at:
        try:
            dt = datetime.fromisoformat(run_at.replace("Z", "+00:00"))
            run_html = f"<div class='label'>Run At</div><div class='value'>{dt.strftime('%Y-%m-%d %H:%M UTC')}</div>"
        except Exception as exc:
            logging.getLogger(__name__).warning("%s failed: %s", "email_service", exc, exc_info=True)

    html = f"""<!DOCTYPE html><html><head><style>{_BASE_STYLE}</style></head><body>
<div class='card'>
  <div class='header'>
    <div class='title'>Scheduled Job Notification</div>
  </div>
  <div class='label'>Schedule</div>
  <div class='value' style='font-weight:600;'>{_safe_name}</div>
  <div class='label'>Status</div>
  <div class='value'><span class='{badge_cls}'>{status_label}</span></div>
  {run_html}
  {rows_html}
  {duration_html}
  {file_html}
  {error_html}
  <div class='footer'>Query Studio · Automated notification · Do not reply</div>
</div>
</body></html>"""
    return subject, html


def build_execution_completion_email(
    query_name: str,
    status: str,
    row_count: Optional[int],
    duration_seconds: Optional[float],
    error_message: Optional[str],
) -> tuple[str, str]:
    """Returns (subject, html_body)."""
    ok = status == "completed"
    _safe_name = _html_mod.escape(str(query_name).replace("\r", "").replace("\n", ""))
    subject = f"[Query Engine] Query '{_safe_name}' {'completed' if ok else 'failed'}"

    rows_html = f"<div class='label'>Rows</div><div class='value'>{int(row_count):,}</div>" if row_count else ""
    dur_html  = f"<div class='label'>Duration</div><div class='value'>{int(duration_seconds or 0)}s</div>" if duration_seconds else ""
    _safe_err = _html_mod.escape(str(error_message)[:500]) if error_message else ""
    err_html  = (f"<div class='label'>Error</div><div class='value' style='color:#991b1b;'>{_safe_err}</div>"
                 if not ok and _safe_err else "")

    html = f"""<!DOCTYPE html><html><head><style>{_BASE_STYLE}</style></head><body>
<div class='card'>
  <div class='header'><div class='title'>Query Execution Notification</div></div>
  <div class='label'>Query</div>
  <div class='value' style='font-weight:600;'>{_safe_name}</div>
  <div class='label'>Status</div>
  <div class='value'><span class='{'badge-success' if ok else 'badge-error'}'>{'Completed' if ok else 'Failed'}</span></div>
  {rows_html}{dur_html}{err_html}
  <div class='footer'>Query Studio · Automated notification</div>
</div></body></html>"""
    return subject, html
