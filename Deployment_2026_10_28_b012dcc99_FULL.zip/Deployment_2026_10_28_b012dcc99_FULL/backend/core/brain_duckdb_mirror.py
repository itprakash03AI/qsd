"""Brain DuckDB mirror daemon — Phase 160 (2026-07-01).

Purpose
-------
Populate the :mod:`core.brain_duckdb_store` from the primary
transactional DB on a periodic tick.  The store is the READ-side
optimisation; this daemon is the WRITE-side that keeps it fresh.

One writer, N readers
---------------------
DuckDB files support ONE writer at a time.  This daemon runs on the
scheduler-elect pod (holder of the ``SchedulerLease``) so the fleet
has exactly one writer at any moment.  Query pods open the store
read-only; there is no cross-pod write coordination beyond the
lease.

Fail-open
---------
The daemon NEVER raises past its top-level loop.  On any failure the
error is logged to :func:`BrainDuckDBStore.record_mirror_state` and
the tick is scheduled again.  A broken mirror must not degrade the
query hot path — the read-through helper simply falls through to the
primary DB when the store is empty or stale.

Components
----------
Each mirror pass runs three components, in this order:

  1. ``col_stats``          copies rows from
                            ``iceberg_column_stats_supplement`` for
                            (bucket, prefix) pairs that saw recent
                            query activity.
  2. ``snapshot_pointer``   copies the current snapshot id per table
                            from ``iceberg_metadata_key_cache``.
  3. ``hot_tables_columns`` re-computes 7-day + 24-hour rollups from
                            ``query_pruning_history``.

Manifest summaries are populated LIVE by the iceberg_reader when it
walks a snapshot (a hook we'll add in a follow-up if
``manifest_summary`` proves useful — the daemon reserves the
component slot so ``mirror_state`` shows it).
"""
from __future__ import annotations

import logging
from core.table_prefix import prefix_matches
import os
import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from core.brain_duckdb_store import BrainDuckDBStore, get_store


logger = logging.getLogger(__name__)


# ── config ────────────────────────────────────────────────────────────────


# Runtime admin toggle -- persisted in SystemSetting so an admin can
# flip the mirror on/off without a redeploy (POST /api/admin/brain/
# mirror-enabled).  Mirrors the iceberg_db_first_reader settings idiom.
MIRROR_ENABLED_SETTING_KEY = "brain_store.mirror_enabled"


def _parse_bool(raw: Any) -> Optional[bool]:
    """Coerce a stored setting to True/False, or None when unrecognised
    (so callers can fall through to the next precedence layer)."""
    if raw is None:
        return None
    if isinstance(raw, bool):
        return raw
    s = str(raw).strip().lower()
    if s in ("true", "1", "yes", "on"):
        return True
    if s in ("false", "0", "no", "off"):
        return False
    return None


# Last SUCCESSFULLY-read runtime override (None = no override row / not yet
# read).  On a transient settings-DB error we return this instead of None so
# a hiccup can't flip a mirror that was enabled ONLY via the runtime toggle
# (config yaml still False) off mid-run -- honouring the fail-open contract.
_LAST_OVERRIDE: Optional[bool] = None


def _runtime_enabled_override() -> Optional[bool]:
    """Admin runtime toggle via SystemSetting.

    Returns True/False when an admin has set the flag, or None when no
    override exists (fall through to env/config/default).  Fail-open:
    on a DB error we return the LAST successfully-read value (not None),
    so a settings-store hiccup never forces the mirror on or off -- if the
    override was the only thing keeping it on, a blip won't stop the writer
    (the supervisor still reconciles once the store recovers).
    """
    global _LAST_OVERRIDE
    try:
        from core.database import get_db_manager
        dbm = get_db_manager()
        if dbm is None or not hasattr(dbm, "get_system_setting"):
            return _LAST_OVERRIDE
        val = _parse_bool(
            dbm.get_system_setting(MIRROR_ENABLED_SETTING_KEY, default=None)
        )
        _LAST_OVERRIDE = val
        return val
    except Exception as exc:                                       # pragma: no cover
        logger.debug(
            "brain_duckdb_mirror: runtime override read failed (%s); "
            "holding last-known override=%s", exc, _LAST_OVERRIDE,
        )
        return _LAST_OVERRIDE


def _config_enabled() -> bool:
    """Effective on/off for the mirror writer.  DEFAULT OFF.

    Precedence (highest first):
      1. ``QS_BRAIN_MIRROR_ENABLED`` env var -- explicit operator/deploy.
      2. ``brain_store.mirror_enabled`` SystemSetting -- admin runtime toggle.
      3. ``brain_store.mirror_enabled`` config yaml.
      4. ``False`` -- the mirror duplicates metadata; off unless opted in.
    """
    _env = (os.environ.get("QS_BRAIN_MIRROR_ENABLED") or "").strip().lower()
    if _env in ("false", "0", "no", "off"):
        return False
    if _env in ("true", "1", "yes", "on"):
        return True
    _rt = _runtime_enabled_override()
    if _rt is not None:
        return _rt
    try:
        from core import config as _cfg
        return bool(_cfg.get("brain_store", "mirror_enabled", False))
    except Exception:
        return False


def set_mirror_enabled(enabled: bool, *, updated_by: Optional[str] = None) -> bool:
    """Admin control -- persist the mirror on/off flag to SystemSetting.

    Does NOT start/stop the daemon itself; the admin endpoint owns
    lifecycle so the caller can report whether a thread actually
    started.  Returns the value written.  Raises if the settings store
    is unavailable (the endpoint surfaces that to the operator).
    """
    from core.database import get_db_manager
    dbm = get_db_manager()
    if dbm is None or not hasattr(dbm, "set_system_setting"):
        raise RuntimeError("system settings store unavailable")
    dbm.set_system_setting(
        MIRROR_ENABLED_SETTING_KEY,
        bool(enabled),
        updated_by=updated_by,
        description="Brain DuckDB mirror writer on/off (data-duplication opt-in)",
    )
    return bool(enabled)


def _config_interval_seconds() -> int:
    try:
        from core import config as _cfg
        v = int(_cfg.get("brain_store", "mirror_interval_seconds", 300))
        return max(30, v)   # never poll faster than every 30s
    except Exception:
        return 300


def _config_hot_lookback_hours() -> int:
    """How far back the col_stats mirror should look for
    "recently active" (bucket, prefix) pairs — anything queried in
    this window is mirrored on the next tick."""
    try:
        from core import config as _cfg
        return max(1, int(_cfg.get("brain_store", "mirror_hot_lookback_hours", 24)))
    except Exception:
        return 24


def _config_hot_top_k() -> int:
    """Ceiling on how many hot (bucket, prefix) pairs to touch per
    tick.  Guards against a full-scan if a huge workload just landed."""
    try:
        from core import config as _cfg
        return max(1, int(_cfg.get("brain_store", "mirror_hot_top_k", 500)))
    except Exception:
        return 500


# ── mirror components ─────────────────────────────────────────────────────


class BrainDuckDBMirror:
    """Owns the mirror-tick loop.  One instance per pod, held by
    :func:`get_mirror`."""

    def __init__(
        self,
        *,
        db_manager: Any,
        store: Optional[BrainDuckDBStore] = None,
        interval_seconds: Optional[int] = None,
    ) -> None:
        self._db = db_manager
        self._store = store if store is not None else get_store()
        self._interval = int(interval_seconds) if interval_seconds is not None else _config_interval_seconds()
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._thread_lock = threading.Lock()
        # Last-mirror bookkeeping so col_stats mirror can incremental-copy
        # only rows newer than the last successful pass.
        self._last_col_stats_watermark: Optional[datetime] = None

    # ── lifecycle ───────────────────────────────────────────────────────

    def start(self) -> bool:
        """Start the background loop if not already running.  Returns
        True if a new thread was started."""
        if not _config_enabled():
            logger.info("brain_duckdb_mirror disabled via config")
            return False
        with self._thread_lock:
            if self._thread is not None and self._thread.is_alive():
                return False
            self._stop_event.clear()
            t = threading.Thread(
                target=self._loop, name="brain-duckdb-mirror", daemon=True,
            )
            t.start()
            self._thread = t
            return True

    def stop(self, timeout_seconds: float = 5.0) -> None:
        """Signal the loop to stop and join.  Idempotent."""
        self._stop_event.set()
        t = self._thread
        if t is not None:
            t.join(timeout=timeout_seconds)
        with self._thread_lock:
            self._thread = None

    def _loop(self) -> None:
        """Top-level loop.  Never raises."""
        # Ensure schema exists once at daemon start so readers see the
        # tables even before the first mirror tick completes.
        try:
            self._store.ensure_schema()
        except Exception as exc:                                # pragma: no cover
            logger.warning("brain_duckdb_mirror: ensure_schema failed: %s", exc)

        while not self._stop_event.is_set():
            # Re-read the effective on/off each tick so a runtime DISABLE
            # (admin flips the SystemSetting from ANY pod) actually stops
            # the writer here -- not just on the next pod restart.  This
            # is the safety-critical direction: stop duplicating metadata
            # promptly when an operator turns the mirror off.
            if not _config_enabled():
                logger.info(
                    "brain_duckdb_mirror: disabled at runtime -- "
                    "writer self-stopping"
                )
                break
            try:
                self.tick_once()
            except Exception as exc:
                # Belt-and-suspenders — tick_once already fails open.
                logger.exception("brain_duckdb_mirror tick failed: %s", exc)
            # Sleep in short slices so stop() responds quickly.
            slept = 0.0
            slice_s = 1.0
            while slept < self._interval and not self._stop_event.is_set():
                time.sleep(slice_s)
                slept += slice_s

    # ── one-tick orchestration ──────────────────────────────────────────

    def tick_once(self) -> Dict[str, Any]:
        """Run one full mirror pass across all components.

        Returns a summary dict for admin telemetry:
            {"col_stats": {"rows": N, "ok": bool},
             "snapshot_pointer": {"rows": N, "ok": bool},
             "hot_tables_columns": {"tables": N, "columns": N, "ok": bool}}

        Never raises.  Individual component failures are recorded and
        the pass continues.
        """
        summary: Dict[str, Any] = {}

        # Component 1 — col_stats
        summary["col_stats"] = self._tick_col_stats()

        # Component 2 — snapshot pointer
        summary["snapshot_pointer"] = self._tick_snapshot_pointer()

        # Component 3 — hot tables + hot columns
        summary["hot_tables_columns"] = self._tick_hot_tables_columns()

        return summary

    # ── component: col_stats ────────────────────────────────────────────

    def _tick_col_stats(self) -> Dict[str, Any]:
        """Mirror ``iceberg_column_stats_supplement`` rows for recently
        active (bucket, prefix) pairs.

        Strategy:
          * Determine "hot" (bucket, prefix) pairs from
            ``query_pruning_history`` in the last N hours (cap top-K).
          * For each pair, pull supplement rows updated since the last
            successful mirror watermark; upsert into store.

        Incremental: uses ``self._last_col_stats_watermark`` so the
        second and subsequent passes only carry the delta.
        """
        # 2026-07-13 — under the per-file grain (v3) the v2 supplement this
        # mirror copies is not written, AND the read chokepoint reads v3
        # directly (never consults this DuckDB store for v3), so mirroring is
        # pure dead weight + a misleading rows=0.  Skip cleanly (aligned:
        # nothing to mirror; the store is bypassed for v3 reads).  The grain
        # accessor has its own internal fallback, so no guard needed here.
        from core import config as _qs_cfg
        if _qs_cfg.iceberg_file_stats_grain() == "v3":
            self._store.record_mirror_state(
                component="col_stats", success=True, rows_upserted=0)
            return {"rows": 0, "ok": True, "skipped": "grain_v3"}
        try:
            hot_pairs = self._recent_hot_pairs(
                lookback_hours=_config_hot_lookback_hours(),
                top_k=_config_hot_top_k(),
            )
        except Exception as exc:
            self._store.record_mirror_state(
                component="col_stats", success=False, error=str(exc)[:2000],
            )
            return {"rows": 0, "ok": False, "error": str(exc)[:200]}

        if not hot_pairs:
            self._store.record_mirror_state(
                component="col_stats", success=True, rows_upserted=0,
            )
            return {"rows": 0, "ok": True, "note": "no_hot_pairs"}

        total_written = 0
        watermark = datetime.now(timezone.utc)
        errors: List[str] = []
        for bucket, prefix, fmt in hot_pairs:
            try:
                records = self._read_supplement_rows(
                    bucket=bucket, table_prefix=prefix, format=fmt,
                    since=self._last_col_stats_watermark,
                )
                if not records:
                    continue
                n = self._store.upsert_col_stats(records)
                total_written += n
            except Exception as exc:
                errors.append(f"{bucket}/{prefix}[{fmt}]: {str(exc)[:100]}")
                logger.debug("mirror col_stats %s/%s failed: %s",
                             bucket, prefix, exc)

        ok = not errors
        self._store.record_mirror_state(
            component="col_stats",
            success=ok,
            rows_upserted=total_written,
            error=("; ".join(errors[:5]))[:2000] if errors else None,
        )
        if ok:
            self._last_col_stats_watermark = watermark
        return {"rows": total_written, "ok": ok, "pairs": len(hot_pairs),
                "errors": errors[:5]}

    def _recent_hot_pairs(
        self, *, lookback_hours: int, top_k: int,
    ) -> List[Tuple[str, str, str]]:
        """Return top-K (bucket, table_prefix, format) tuples ordered
        by recent query count in ``query_pruning_history``.

        Raises on DB errors so the caller (``_tick_col_stats``) can
        record the failure in ``mirror_state``.  Missing imports
        (SQLAlchemy / model) return [] silently — expected when the
        model was renamed or removed.
        """
        try:
            from core.db.models import QueryPruningHistory as _QPH
        except Exception:
            return []
        try:
            from sqlalchemy import func as _sa_func
        except Exception:
            return []
        cutoff = datetime.now(timezone.utc) - timedelta(hours=lookback_hours)
        pairs: List[Tuple[str, str, str]] = []
        with self._db.get_session(read_only=True) as session:
            rows = (
                session.query(
                    _QPH.bucket, _QPH.table_prefix, _QPH.format,
                    _sa_func.count(_QPH.id).label("cnt"),
                )
                .filter(_QPH.created_at >= cutoff)
                .filter(_QPH.bucket.isnot(None))
                .filter(_QPH.table_prefix.isnot(None))
                .group_by(_QPH.bucket, _QPH.table_prefix, _QPH.format)
                .order_by(_sa_func.count(_QPH.id).desc())
                .limit(int(top_k))
                .all()
            )
            seen: Set[Tuple[str, str, str]] = set()
            for r in rows:
                key = (str(r.bucket or ""), str(r.table_prefix or ""),
                       str(r.format or "iceberg"))
                if not key[0] or not key[1] or key in seen:
                    continue
                seen.add(key)
                pairs.append(key)
        return pairs

    def _read_supplement_rows(
        self,
        *,
        bucket: str,
        table_prefix: str,
        format: str,
        since: Optional[datetime],
    ) -> List[Dict[str, Any]]:
        """Pull supplement rows for one (bucket, prefix) pair.

        When ``since`` is None (first pass or after watermark reset),
        pulls everything for the pair.  Subsequent passes pull only
        rows with ``scanned_at >= since``.
        """
        try:
            from core.db.models import IcebergColumnStatsSupplement as _ICSS
        except Exception:
            return []
        records: List[Dict[str, Any]] = []
        try:
            with self._db.get_session(read_only=True) as session:
                q = session.query(_ICSS).filter(
                    _ICSS.bucket == bucket,
                    prefix_matches(_ICSS.table_prefix, table_prefix),
                    _ICSS.format == format,
                )
                if since is not None:
                    q = q.filter(_ICSS.scanned_at >= since)
                for row in q.all():
                    records.append({
                        "bucket":       row.bucket,
                        "table_prefix": row.table_prefix,
                        "format":       row.format or "iceberg",
                        "snapshot_id":  str(row.snapshot_id or ""),
                        "file_path":    row.file_path,
                        "column_name":  row.column_name,
                        "lower_bound":  row.lower_bound,
                        "upper_bound":  row.upper_bound,
                        # Preserve UNKNOWN (None) into the brain mirror — a
                        # coerced 0 would let IS NULL pruning drop a file
                        # whose null count the writer never recorded.
                        "null_count":   (None if row.null_count is None
                                         else int(row.null_count)),
                        "row_count":    int(row.row_count or 0),
                    })
        except Exception as exc:
            logger.debug("mirror _read_supplement_rows failed: %s", exc)
        return records

    # ── component: snapshot pointer + manifest summary ──────────────────

    def _tick_snapshot_pointer(self) -> Dict[str, Any]:
        """Mirror the current snapshot id per (bucket, prefix) AND the
        per-snapshot manifest summary from ``iceberg_snapshot_cache``
        (BF-296 canonical source).  One query, two outputs — the
        table already carries bucket + table_prefix + snapshot_id +
        file_count + bytes_total.

        The "current" snapshot per (bucket, prefix) is the row with
        the max ``last_accessed`` — a heuristic that follows real
        workload, matching what queries actually see through the
        iceberg cache layers.  All observed snapshots also land in
        ``manifest_summary`` so cold-start queries have per-snapshot
        stats immediately.
        """
        try:
            from core.db.models import IcebergSnapshotCache as _ISC
        except Exception:
            self._store.record_mirror_state(
                component="snapshot_pointer", success=True, rows_upserted=0,
            )
            return {"rows": 0, "ok": True, "note": "no_model"}

        pointer_writes = 0
        summary_writes = 0
        errors: List[str] = []
        try:
            with self._db.get_session(read_only=True) as session:
                rows = session.query(_ISC).limit(
                    int(_config_hot_top_k())
                ).all()
                # Group by (bucket, prefix) to find the latest snapshot
                latest_by_pair: Dict[Tuple[str, str], Any] = {}
                for row in rows:
                    bucket = getattr(row, "bucket", None) or ""
                    prefix = getattr(row, "table_prefix", None) or ""
                    snap   = getattr(row, "snapshot_id", None)
                    if not (bucket and prefix and snap):
                        continue
                    # manifest_summary for THIS snapshot (all rows)
                    try:
                        ok = self._store.upsert_manifest_summary(
                            bucket=bucket,
                            table_prefix=prefix,
                            snapshot_id=str(snap),
                            file_count=int(getattr(row, "file_count", 0) or 0),
                            total_bytes=int(getattr(row, "bytes_total", 0) or 0),
                        )
                        if ok:
                            summary_writes += 1
                    except Exception as exc:
                        errors.append(f"summary {bucket}/{prefix}: {str(exc)[:100]}")
                    # Track the latest observed snapshot per pair for
                    # the pointer table
                    last_seen = getattr(row, "last_accessed", None) or \
                                getattr(row, "created_at", None)
                    key = (bucket, prefix)
                    prev = latest_by_pair.get(key)
                    if prev is None:
                        latest_by_pair[key] = row
                    else:
                        prev_last = getattr(prev, "last_accessed", None) or \
                                    getattr(prev, "created_at", None)
                        if last_seen and prev_last and last_seen > prev_last:
                            latest_by_pair[key] = row
                # Now upsert snapshot_pointer for the latest per pair
                for (bucket, prefix), row in latest_by_pair.items():
                    try:
                        ok = self._store.upsert_snapshot_pointer(
                            bucket=bucket,
                            table_prefix=prefix,
                            current_snapshot_id=str(
                                getattr(row, "snapshot_id", "") or ""
                            ),
                        )
                        if ok:
                            pointer_writes += 1
                    except Exception as exc:
                        errors.append(f"pointer {bucket}/{prefix}: {str(exc)[:100]}")
        except Exception as exc:
            self._store.record_mirror_state(
                component="snapshot_pointer", success=False,
                error=str(exc)[:2000],
            )
            return {"rows": 0, "ok": False, "error": str(exc)[:200]}

        ok = not errors
        total = pointer_writes + summary_writes
        self._store.record_mirror_state(
            component="snapshot_pointer",
            success=ok,
            rows_upserted=total,
            error=("; ".join(errors[:5]))[:2000] if errors else None,
        )
        return {"rows": total, "ok": ok,
                "pointer_rows": pointer_writes,
                "summary_rows": summary_writes,
                "errors": errors[:5]}

    # ── component: hot tables + hot columns ─────────────────────────────

    def _tick_hot_tables_columns(self) -> Dict[str, Any]:
        """Re-compute the 7-day/24-hour rollups from
        ``query_pruning_history`` and upsert into ``hot_tables`` +
        ``hot_columns``."""
        try:
            from core.db.models import QueryPruningHistory as _QPH
        except Exception:
            self._store.record_mirror_state(
                component="hot_tables_columns", success=True, rows_upserted=0,
            )
            return {"tables": 0, "columns": 0, "ok": True, "note": "no_model"}
        try:
            from sqlalchemy import func as _sa_func
        except Exception:
            return {"tables": 0, "columns": 0, "ok": False,
                    "error": "sqlalchemy missing"}

        now = datetime.now(timezone.utc)
        cutoff_7d = now - timedelta(days=7)
        cutoff_24h = now - timedelta(hours=24)

        table_rows: List[Dict[str, Any]] = []
        column_rows: List[Dict[str, Any]] = []
        try:
            with self._db.get_session(read_only=True) as session:
                # ── hot_tables — one aggregate query for the 7-day
                # rollup, then a lightweight 24h count-per-table
                # secondary query keyed by the same (bucket, prefix).
                q7 = (
                    session.query(
                        _QPH.bucket, _QPH.table_prefix,
                        _sa_func.count(_QPH.id).label("q7"),
                        _sa_func.avg(_QPH.metadata_seconds).label("avg_meta_s"),
                        _sa_func.max(_QPH.created_at).label("last_q"),
                    )
                    .filter(_QPH.created_at >= cutoff_7d)
                    .filter(_QPH.bucket.isnot(None))
                    .filter(_QPH.table_prefix.isnot(None))
                    .group_by(_QPH.bucket, _QPH.table_prefix)
                    .all()
                )
                # 24h counts keyed by (bucket, prefix)
                q24 = (
                    session.query(
                        _QPH.bucket, _QPH.table_prefix,
                        _sa_func.count(_QPH.id).label("q24"),
                    )
                    .filter(_QPH.created_at >= cutoff_24h)
                    .filter(_QPH.bucket.isnot(None))
                    .filter(_QPH.table_prefix.isnot(None))
                    .group_by(_QPH.bucket, _QPH.table_prefix)
                    .all()
                )
                q24_map: Dict[Tuple[str, str], int] = {}
                for r in q24:
                    q24_map[(str(r.bucket or ""), str(r.table_prefix or ""))] = int(r.q24 or 0)
                for r in q7:
                    key = (str(r.bucket or ""), str(r.table_prefix or ""))
                    table_rows.append({
                        "bucket":         key[0],
                        "table_prefix":   key[1],
                        "queries_7d":     int(r.q7 or 0),
                        "queries_24h":    q24_map.get(key, 0),
                        "avg_seconds_7d": float(r.avg_meta_s or 0.0),
                        "last_query_at":  r.last_q,
                    })

                # ── hot_columns — filter_breakdown is JSON, so we need
                # to unpack in Python.  Bounded by top-K tables from
                # table_rows so we don't scan the full history on every
                # tick.
                top_pairs = sorted(
                    table_rows, key=lambda r: r["queries_7d"], reverse=True,
                )[:_config_hot_top_k()]
                top_pair_keys = {
                    (t["bucket"], t["table_prefix"]) for t in top_pairs
                }
                col_counts: Dict[Tuple[str, str, str], Dict[str, Any]] = {}
                if top_pair_keys:
                    # One coarse fetch then Python filter — SQLAlchemy
                    # doesn't natively unpack JSON portably across
                    # sqlite/postgres.
                    rows = (
                        session.query(
                            _QPH.bucket, _QPH.table_prefix,
                            _QPH.filter_breakdown, _QPH.created_at,
                        )
                        .filter(_QPH.created_at >= cutoff_7d)
                        .filter(_QPH.bucket.isnot(None))
                        .filter(_QPH.table_prefix.isnot(None))
                        .all()
                    )
                    for r in rows:
                        key = (str(r.bucket or ""), str(r.table_prefix or ""))
                        if key not in top_pair_keys:
                            continue
                        fb = r.filter_breakdown
                        if not fb:
                            continue
                        if isinstance(fb, str):
                            import json as _json
                            try:
                                fb = _json.loads(fb)
                            except Exception:
                                continue
                        if not isinstance(fb, list):
                            continue
                        for entry in fb:
                            if not isinstance(entry, dict):
                                continue
                            col = str(entry.get("column") or "").strip()
                            if not col:
                                continue
                            ck = (key[0], key[1], col.lower())
                            slot = col_counts.setdefault(ck, {
                                "bucket":         key[0],
                                "table_prefix":   key[1],
                                "column_name":    col,
                                "usage_count_7d": 0,
                                "last_used_at":   None,
                            })
                            slot["usage_count_7d"] = int(slot["usage_count_7d"]) + 1
                            if r.created_at is not None:
                                prev = slot["last_used_at"]
                                if prev is None or r.created_at > prev:
                                    slot["last_used_at"] = r.created_at
                column_rows = list(col_counts.values())
        except Exception as exc:
            self._store.record_mirror_state(
                component="hot_tables_columns", success=False,
                error=str(exc)[:2000],
            )
            return {"tables": 0, "columns": 0, "ok": False,
                    "error": str(exc)[:200]}

        tables_written = self._store.upsert_hot_tables(table_rows)
        cols_written = self._store.upsert_hot_columns(column_rows)
        self._store.record_mirror_state(
            component="hot_tables_columns",
            success=True,
            rows_upserted=tables_written + cols_written,
        )
        return {
            "tables":  tables_written,
            "columns": cols_written,
            "ok":      True,
        }


# ── singleton ────────────────────────────────────────────────────────────


_mirror_singleton: Optional[BrainDuckDBMirror] = None
_singleton_lock = threading.Lock()


def get_mirror(db_manager: Any) -> BrainDuckDBMirror:
    """Return the process-wide mirror singleton, constructing it on
    first call.  ``db_manager`` is only consulted on construction —
    subsequent calls may pass None (or the same manager)."""
    global _mirror_singleton
    if _mirror_singleton is None:
        with _singleton_lock:
            if _mirror_singleton is None:
                _mirror_singleton = BrainDuckDBMirror(db_manager=db_manager)
    return _mirror_singleton


def reset_mirror_for_tests() -> None:
    global _mirror_singleton
    with _singleton_lock:
        if _mirror_singleton is not None:
            try:
                _mirror_singleton.stop(timeout_seconds=0.5)
            except Exception as _stop_exc:                            # pragma: no cover
                # 2026-07-02 -- test-teardown helper.  Debug-log so
                # a repeated stop() failure surfaces in test output
                # without polluting stderr.
                logger.debug(
                    "reset_mirror_for_tests: stop suppressed %s: %s",
                    type(_stop_exc).__name__, _stop_exc,
                )
        _mirror_singleton = None


def start_background(db_manager: Any) -> bool:
    """Start the mirror daemon on this pod.  Return True if newly
    started, False if disabled or already running."""
    if not _config_enabled():
        logger.info("brain_duckdb_mirror.start_background: disabled by config")
        return False
    m = get_mirror(db_manager)
    return m.start()


def stop_background() -> None:
    """Stop the daemon if running.  Idempotent."""
    global _mirror_singleton
    m = _mirror_singleton
    if m is None:
        return
    try:
        m.stop()
    except Exception:                                          # pragma: no cover
        pass


def is_running() -> bool:
    """True when the mirror writer thread is alive on THIS pod.  Used by
    the admin endpoint to report lifecycle state."""
    m = _mirror_singleton
    if m is None:
        return False
    try:
        t = getattr(m, "_thread", None)
        return bool(t is not None and t.is_alive())
    except Exception:                                          # pragma: no cover
        return False


# ── runtime reconcile / supervisor ────────────────────────────────────────
# The writer's lifecycle must track the runtime on/off toggle (config +
# SystemSetting) WITHOUT a redeploy.  ``reconcile`` brings running-state
# in line with the effective flag; ``start_supervisor`` runs it on a
# cheap interval on the writer pod(s).

_supervisor_thread: Optional[threading.Thread] = None
_supervisor_stop = threading.Event()
_supervisor_lock = threading.Lock()


def reconcile(db_manager: Any, is_leader_fn: Optional[Callable[[], bool]] = None) -> None:
    """Bring the writer's running state in line with the effective
    on/off flag.  Starts the writer when enabled and not running; stops
    it when disabled and running.  Fail-open -- never raises.

    Multi-writer safety: the DuckDB mirror store must have AT MOST ONE
    writer across the fleet.  ``is_leader_fn`` gates the writer on the
    scheduler leader lease so only the leader pod ever writes.  When
    ``is_leader_fn`` is None the caller opted out of leader-gating
    (single-pod / test) and the writer runs whenever enabled — preserving
    the pre-fix behaviour.  A non-leader that had started the writer
    (e.g. after losing the lease) stops it here."""
    try:
        _is_leader = True
        if is_leader_fn is not None:
            try:
                _is_leader = bool(is_leader_fn())
            except Exception:
                # Fail-SAFE for a single-runner: if we can't confirm
                # leadership, do NOT write (prefer no mirror over two).
                _is_leader = False
        want = _config_enabled() and _is_leader
        running = is_running()
        if want and not running:
            get_mirror(db_manager).start()
        elif not want and running:
            stop_background()
    except Exception as exc:                                       # pragma: no cover
        logger.debug("brain_duckdb_mirror.reconcile failed: %s", exc)


def start_supervisor(db_manager: Any, *, interval_seconds: int = 60,
                     is_leader_fn: Optional[Callable[[], bool]] = None) -> bool:
    """Run a lightweight reconcile loop on THIS pod so the mirror writer
    tracks the runtime toggle without a redeploy.  Idempotent.  Belongs
    on the writer pod(s) -- the dedicated scheduler pod (external mode)
    and the embedded leader.  Reconciles immediately, then every
    ``interval_seconds``.  Returns True if a new supervisor started.

    ``is_leader_fn`` is forwarded to ``reconcile`` so the WRITER only
    runs on the scheduler leader — at most one DuckDB writer fleet-wide.
    The supervisor LOOP itself may run on every pod (cheap); only the
    writer is leader-gated."""
    global _supervisor_thread
    with _supervisor_lock:
        if _supervisor_thread is not None and _supervisor_thread.is_alive():
            return False
        _supervisor_stop.clear()
        iv = max(10, int(interval_seconds))

        def _run() -> None:
            reconcile(db_manager, is_leader_fn)                    # immediate
            while not _supervisor_stop.wait(iv):
                reconcile(db_manager, is_leader_fn)

        t = threading.Thread(
            target=_run, name="brain-duckdb-mirror-supervisor", daemon=True,
        )
        t.start()
        _supervisor_thread = t
        return True


def stop_supervisor() -> None:
    """Stop the reconcile loop AND the writer.  Idempotent."""
    global _supervisor_thread
    _supervisor_stop.set()
    t = _supervisor_thread
    if t is not None:
        try:
            t.join(timeout=5.0)
        except Exception:                                          # pragma: no cover
            pass
    _supervisor_thread = None
    stop_background()


__all__ = [
    "BrainDuckDBMirror", "get_mirror", "reset_mirror_for_tests",
    "start_background", "stop_background", "is_running",
    "reconcile", "start_supervisor", "stop_supervisor",
    "set_mirror_enabled", "MIRROR_ENABLED_SETTING_KEY",
]
