"""
Global error sanitization — strips credentials, file paths, and internal details
from error messages before they reach the client.

Usage:
    from core.error_sanitizer import sanitize_error
    sanitized = sanitize_error(str(exc))
"""
import re
from typing import Any, Mapping, Optional

_PATTERNS = [
    # Database connection strings
    (re.compile(r'postgresql://[^\s@]+@'), 'postgresql://***@'),
    (re.compile(r'oracle://[^\s@]+@'), 'oracle://***@'),
    (re.compile(r'sqlite:///[^\s"\']+'), 'sqlite:///[redacted]'),
    # Proxy URLs with embedded credentials: http://user:pass@host:port
    (re.compile(r'(https?://)([^@\s]+)@', re.I), r'\1***:***@'),
    # DuckDB SET http_proxy_username/password='...' statements
    (re.compile(r"(http_proxy_(?:user_?name|password)\s*=\s*')[^']*?(')", re.I), r'\1***\2'),
    # Unix / Windows file paths (absolute)
    (re.compile(r'/home/[^\s"\']+'), '/[redacted-path]'),
    (re.compile(r'/app/[^\s"\']+'), '/[redacted-path]'),
    (re.compile(r'/tmp/[^\s"\']+'), '/[redacted-path]'),
    (re.compile(r'[A-Z]:\\[^\s"\']+'), '[redacted-path]'),
    # Proxy credentials (key=value style)
    (re.compile(r'proxy[_-]?(?:user|pass(?:word)?|url)\s*[=:]\s*\S+', re.I),
     '[proxy-creds-redacted]'),
    # Generic secrets (key=value patterns)
    (re.compile(r'(?:secret|token|api[_-]?key|password|passwd|pwd)\s*[=:]\s*\S+', re.I),
     '[credentials-redacted]'),
    # AWS keys
    (re.compile(r'AKIA[0-9A-Z]{16}'), '[aws-key-redacted]'),
    (re.compile(r'(?:aws_secret_access_key|aws_session_token)\s*[=:]\s*\S+', re.I),
     '[aws-creds-redacted]'),
]

MAX_ERROR_LENGTH = 500


def sanitize_error(msg: str) -> str:
    """Sanitize an error message by redacting credentials and paths."""
    if not msg:
        return msg
    for pattern, replacement in _PATTERNS:
        msg = pattern.sub(replacement, msg)
    if len(msg) > MAX_ERROR_LENGTH:
        msg = msg[:MAX_ERROR_LENGTH] + "... [truncated]"
    return msg


REDACTED = "***"


def _is_sensitive_key(key) -> bool:
    """A field NAME that holds a credential: the product's own encrypted-field
    list (core.crypto.SENSITIVE_FIELDS) plus the obvious name patterns."""
    k = str(key or "").strip().lower()
    if not k:
        return False
    try:
        from core.crypto import SENSITIVE_FIELDS
        if k in SENSITIVE_FIELDS:
            return True
    except Exception:  # never let a scrubber fail on import
        pass
    return any(t in k for t in ("password", "passphrase", "secret", "private_key",
                                 "api_key", "access_key", "token", "credential"))


def redact_structure(value, _depth: int = 0):
    """``value`` with every credential-named field's VALUE replaced by ``***``,
    recursively through dicts and lists; strings go through ``sanitize_error``.

    2026-10-05, live: a 422 on PUT /api/connections/{id} echoed the WHOLE
    request body -- aws_secret_access_key included -- in the response's
    ``detail[].input`` and in the WARNING log line, because pydantic puts the
    body there when a top-level field is missing.  Any client that logs error
    responses would have stored the secret.  Keys are kept (the caller needs
    to see which field it sent); only values are replaced.
    """
    if _depth > 20:
        return REDACTED
    if isinstance(value, dict):
        return {k: (REDACTED if _is_sensitive_key(k) and v not in (None, "") else
                    redact_structure(v, _depth + 1)) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [redact_structure(v, _depth + 1) for v in value]
    if isinstance(value, (bytes, bytearray)):
        value = value.decode("utf-8", errors="replace")
    if isinstance(value, str):
        return sanitize_error(value)
    return value


# 2026-09-14 -- ``str(exc)`` IS NOT A REASON.
#
# ``str(KeyError('user'))`` is the string ``'user'`` -- a quoted key and
# nothing else.  Every SQL connector's ``test_connection`` caught
# ``Exception`` and returned ``{"message": str(e)}``; both connection-test
# routes did ``detail=str(e)`` for anything that escaped.  So a saved
# connection whose credential was stored under the wrong key failed its
# test with the message ``'user'`` (docs/SPARK_K8S_LIVE_POD_2026_09_13.html
# s6).  The reason slot was FILLED and carried nothing -- the worst form of
# "unknown != empty".  IndexError / AttributeError / TypeError render the
# same way (``list index out of range`` names no list).
#
# This is the ONE renderer of an exception into a user-facing failure
# message on that path.  It names what failed (``subject``), and for a
# KeyError says WHICH field and whether the configuration actually lacks
# it -- keys only, never values.  Value redaction is delegated to
# ``core.proxy_utils.sanitize_proxy_error``, the documented superset
# scrubber (it composes ``sanitize_error`` above), rather than a third
# scrubber being written here.

# Exceptions whose ``str()`` never names the operation that raised them.
_BARE_EXCEPTIONS = (IndexError, AttributeError, TypeError, NameError,
                    AssertionError, ZeroDivisionError)


def explain_failure(exc: BaseException, *, subject: str,
                    config: Optional[Mapping[str, Any]] = None) -> str:
    """Render ``exc`` as a failure message that names ``subject`` and the
    cause -- never a bare ``'user'``.

    ``config`` is the mapping the failed operation read from; when given, a
    KeyError is classified as "the configuration has no such field" versus
    "the field is present, the lookup failed elsewhere".  Only KEY NAMES from
    it ever appear in the message.
    """
    text = _describe(exc, config)
    try:
        from core.proxy_utils import sanitize_proxy_error
        text = sanitize_proxy_error(text)
    except Exception:            # a scrubber must never break an error path
        text = sanitize_error(text)
    return f"{subject} failed: {text}"


def _refusal_sentence(exc: BaseException) -> Optional[str]:
    """2026-10-08 -- a CONNECTION the source refused (an untrusted
    certificate, a rejected login) is rendered as its remedy, not as the
    transport's text: "HTTPSConnectionPool(host=...): Max retries exceeded
    ... CERTIFICATE_VERIFY_FAILED" names no field a person can change.

    2026-10-10 -- likewise a refused RIGHT (``source_access_denial``: the
    cluster's "Access Denied: Cannot set role sb_auditor", never the Java
    frames behind it) and a DRIVER exception whose ``str()`` is its repr
    (``driver_message``: the trino client's ``TrinoUserError(type=...,
    message="...")`` renders as the message alone).  ONE classifier
    (core.connectors.base) decides all three; this only renders."""
    try:
        from core.connectors.base import (
            connection_refusal_reason, driver_message, source_access_denial,
        )
        return (connection_refusal_reason(exc)
                or source_access_denial(exc)
                or driver_message(exc))
    except Exception:            # the renderer must never break an error path
        return None


def describe_exception(exc: BaseException,
                       config: Optional[Mapping[str, Any]] = None) -> str:
    """``exc`` rendered as the sentence a person reads -- the source's
    verdict / refusal / driver message when it is one, else its own text
    with a bare exception named -- scrubbed of credentials, paths and proxy
    URLs.  No subject: for the lanes that frame the text themselves (the
    feed engine's ``Feed N @ stage=...: <this>``)."""
    text = _describe(exc, config)
    try:
        from core.proxy_utils import sanitize_proxy_error
        return sanitize_proxy_error(text)
    except Exception:            # a scrubber must never break an error path
        return sanitize_error(text)


def _describe(exc: BaseException, config: Optional[Mapping[str, Any]]) -> str:
    reason = _refusal_sentence(exc)
    if reason:
        return reason
    if isinstance(exc, KeyError):
        key = exc.args[0] if exc.args else None
        if key is None:
            return "a required field was not found (KeyError with no key name)"
        shown = f"'{key}'" if isinstance(key, str) else repr(key)
        if isinstance(config, Mapping):
            if key not in config:
                return (f"the configuration has no field {shown} -- "
                        f"add it to the connection and test again")
            return (f"KeyError {shown} raised while connecting -- the field "
                    f"is present in the configuration, so a lookup inside "
                    f"the driver or its response failed")
        return f"required field {shown} was not found (KeyError)"
    msg = str(exc).strip()
    name = type(exc).__name__
    if not msg:
        return name
    if isinstance(exc, _BARE_EXCEPTIONS):
        return f"{name}: {msg}"
    return msg
