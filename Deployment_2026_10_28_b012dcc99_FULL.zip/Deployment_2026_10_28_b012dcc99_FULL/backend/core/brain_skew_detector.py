"""Skew detector — catches "pruning illusion" patterns.

The problem:

Bucket pruning that drops file count from 1000 → 20 LOOKS like a win
in the dashboard (95% pruning).  But if all 20 buckets land on the
same hot file because the workload's customer_id distribution is
heavily skewed (one customer = 80% of rows), the scan TIME doesn't
drop proportionally.  Existing pruning health treats this as a
success; the user wonders why a "highly-pruned" query takes 30
seconds instead of 0.5.

The detection:

For each (bucket, prefix, column) where bucket pruning fires, compare
(files_after_prune / files_before_prune) to (scan_time / baseline
scan_time per file).  When the ratios diverge by more than
``skew_divergence_threshold`` (default 5x), flag the column as skewed.

Heuristic — not exact:
  * baseline_per_file = median(scan_time / files_after) over
    NON-bucket-pruned queries against the same table
  * skewed: query.scan_time / query.files_after > baseline × threshold

Output:

``SkewSignal`` records that the Writer Advisor consumes — emits
``add_sort_order(column)`` or ``add_bucket(N×4, column)`` recommendations
with the skew flag attached so the operator knows WHY the existing
bucket() didn't help.

Strategic shape: ONE class — ``SkewDetector`` — pure read-only, no
writes.  Lives next to PruningHealthAggregator + WriterAdvisor; the
three together form the "look back at history, decide what to fix"
triad.
"""
from __future__ import annotations

import logging
import statistics
import threading
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


# ── Config ────────────────────────────────────────────────────────────


def _cfg(key: str, fallback: Any) -> Any:
    try:
        from core.config import get as _g
        return _g("brain_skew_detector", key, fallback)
    except Exception:
        return fallback


def enabled() -> bool:
    """Master switch.  Default ON — purely advisory, no read-path
    impact."""
    return bool(_cfg("enabled", True))


def lookback_hours() -> int:
    return int(_cfg("lookback_hours", 168) or 168)


def skew_divergence_threshold() -> float:
    """Min ratio scan_time_per_file / baseline_per_file at which we
    flag skew.  Default 5× — conservative; aggressive setting would
    surface false positives on tables with mixed-cost queries."""
    return float(_cfg("skew_divergence_threshold", 5.0) or 5.0)


def min_queries_for_signal() -> int:
    return int(_cfg("min_queries_for_signal", 5) or 5)


# ── Dataclasses ──────────────────────────────────────────────────────


@dataclass
class SkewSignal:
    bucket:                str
    table_prefix:          str
    column:                str
    queries_observed:      int
    avg_files_after:       float
    avg_scan_seconds:      float
    baseline_per_file:     float
    observed_per_file:     float
    divergence_ratio:      float
    rationale:             str
    generated_at:          str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat(),
    )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ── The detector ─────────────────────────────────────────────────────


class SkewDetector:
    """Singleton — pure DB-read pipeline."""

    _instance_lock = threading.Lock()
    _instance: Optional["SkewDetector"] = None

    def __init__(self, db_manager: Any) -> None:
        self._db = db_manager

    @classmethod
    def get_default(cls, db_manager: Any) -> "SkewDetector":
        # 2026-06-10 audit fix — wrap the lazy-init in a lock so two
        # concurrent admin calls can't race on the singleton.
        with cls._instance_lock:
            if cls._instance is None:
                cls._instance = cls(db_manager)
            return cls._instance

    def detect_skewed_columns(
        self, window_hours: Optional[int] = None,
        bucket_filter: Optional[str] = None,
    ) -> List[SkewSignal]:
        """Walk recent history; emit skew signals where the
        scan-time-per-file ratio diverges materially from the
        table's baseline.

        Returns rows sorted by divergence_ratio desc — the most
        likely-skewed columns first.
        """
        if not enabled():
            return []
        hrs = int(window_hours or lookback_hours())
        try:
            from core.db.models import (
                QueryPruningHistory, QueryExecution, FederationExecution,
            )
            since = datetime.now(timezone.utc) - timedelta(hours=hrs)
            with self._db.get_session(read_only=True) as session:
                q = (
                    session.query(
                        QueryPruningHistory.bucket,
                        QueryPruningHistory.table_prefix,
                        QueryPruningHistory.execution_id,
                        QueryPruningHistory.files_after_prune,
                        QueryPruningHistory.filter_breakdown,
                        QueryExecution.started_at,
                        QueryExecution.completed_at,
                    )
                    .join(
                        QueryExecution,
                        QueryExecution.execution_id ==
                        QueryPruningHistory.execution_id,
                    )
                    .filter(
                        QueryPruningHistory.created_at >= since,
                        QueryPruningHistory.files_after_prune > 0,
                        QueryExecution.completed_at != None,  # noqa: E711
                    )
                )
                if bucket_filter:
                    q = q.filter(
                        QueryPruningHistory.bucket == bucket_filter,
                    )
                rows = q.limit(10_000).all()
                # 2026-09-06 -- the BQB REPORT road records its wall
                # clock in ``federation_executions``, not
                # ``query_executions``; joining only the latter made
                # every observation a report produced invisible here.
                # Measured on the wire rig: 2 pruning rows from two real
                # iceberg reports, 0 joinable to query_executions.  Same
                # defect as in brain_cost_model._compute_stats.
                q2 = (
                    session.query(
                        QueryPruningHistory.bucket,
                        QueryPruningHistory.table_prefix,
                        QueryPruningHistory.execution_id,
                        QueryPruningHistory.files_after_prune,
                        QueryPruningHistory.filter_breakdown,
                        FederationExecution.duration_seconds,
                    )
                    .join(
                        FederationExecution,
                        FederationExecution.execution_id ==
                        QueryPruningHistory.execution_id,
                    )
                    .filter(
                        QueryPruningHistory.created_at >= since,
                        QueryPruningHistory.files_after_prune > 0,
                        FederationExecution.status == "completed",
                        FederationExecution.duration_seconds > 0,
                    )
                )
                if bucket_filter:
                    q2 = q2.filter(
                        QueryPruningHistory.bucket == bucket_filter,
                    )
                fed_rows = q2.limit(10_000).all()
        except Exception as exc:
            logger.debug("SkewDetector: history read failed: %s", exc)
            return []

        # Normalise both roads to (bucket, prefix, exec_id, files_after,
        # breakdown, duration_seconds) before the analysis, so the maths
        # below has exactly one shape to reason about.
        samples_in: List[Tuple] = []
        _seen: Set[str] = set()
        for (bucket, prefix, exec_id, files_after, breakdown,
              dur) in fed_rows:
            try:
                dur = float(dur or 0.0)
            except (TypeError, ValueError):
                continue
            if dur <= 0:
                continue
            _seen.add(exec_id)
            samples_in.append((bucket, prefix, exec_id, files_after,
                               breakdown, dur))
        for (bucket, prefix, exec_id, files_after, breakdown,
              started_at, completed_at) in rows:
            if exec_id in _seen:
                continue
            if started_at is None or completed_at is None:
                continue
            sa, ca = started_at, completed_at
            if sa.tzinfo is None:
                sa = sa.replace(tzinfo=timezone.utc)
            if ca.tzinfo is None:
                ca = ca.replace(tzinfo=timezone.utc)
            samples_in.append((bucket, prefix, exec_id, files_after,
                               breakdown, (ca - sa).total_seconds()))

        # Per (bucket, prefix) baseline: median(per_file_seconds) across
        # queries whose breakdown has NO bucket-pruning-eligible columns.
        # Per (bucket, prefix, column) observation: collected from
        # queries where the column appears in the breakdown.
        baseline_samples: Dict[Tuple[str, str], List[float]] = defaultdict(list)
        col_samples: Dict[
            Tuple[str, str, str], List[Tuple[int, float]]
        ] = defaultdict(list)

        for (bucket, prefix, exec_id, files_after, breakdown,
              dur) in samples_in:
            if not bucket or not prefix:
                continue
            if dur <= 0 or files_after <= 0:
                continue
            per_file = dur / files_after
            norm_prefix = (prefix or "").rstrip("/")
            key = (bucket, norm_prefix)
            # Baseline: any query against this table that doesn't have
            # bucket-pruning hits counts toward baseline.
            looks_bucketed = self._breakdown_has_bucket_column(breakdown)
            if not looks_bucketed:
                baseline_samples[key].append(per_file)
            # Per-column sample
            if isinstance(breakdown, list):
                for fb in breakdown:
                    if not isinstance(fb, dict):
                        continue
                    col = (fb.get("column") or "").strip().lower()
                    col_kind = (fb.get("column_kind") or "").strip().lower()
                    if not col or col_kind != "bucket":
                        continue
                    col_samples[(bucket, norm_prefix, col)].append(
                        (int(files_after), per_file),
                    )

        signals: List[SkewSignal] = []
        threshold = skew_divergence_threshold()
        for (bucket, prefix, col), samples in col_samples.items():
            if len(samples) < min_queries_for_signal():
                continue
            baseline_list = baseline_samples.get((bucket, prefix), [])
            if not baseline_list:
                continue
            baseline = statistics.median(baseline_list)
            if baseline <= 0:
                continue
            observed = statistics.median([s[1] for s in samples])
            ratio = observed / baseline
            if ratio < threshold:
                continue
            avg_files = sum(s[0] for s in samples) / len(samples)
            avg_secs  = sum(s[1] * s[0] for s in samples) / len(samples)
            signals.append(SkewSignal(
                bucket            = bucket,
                table_prefix      = prefix,
                column            = col,
                queries_observed  = len(samples),
                avg_files_after   = round(avg_files, 1),
                avg_scan_seconds  = round(avg_secs, 3),
                baseline_per_file = round(baseline, 6),
                observed_per_file = round(observed, 6),
                divergence_ratio  = round(ratio, 2),
                rationale         = (
                    f"Bucket pruning fires on '{col}' but scan-time per "
                    f"file is {ratio:.1f}× the table baseline.  Likely "
                    f"value-skew: one bucket dominates the data.  "
                    f"Consider sort_order({col}) or higher bucket count."
                ),
            ))
        signals.sort(key=lambda s: -s.divergence_ratio)
        return signals

    def _breakdown_has_bucket_column(
        self, breakdown: Any,
    ) -> bool:
        if not isinstance(breakdown, list):
            return False
        for fb in breakdown:
            if isinstance(fb, dict):
                if (fb.get("column_kind") or "").lower() == "bucket":
                    return True
        return False


__all__ = [
    "SkewDetector", "SkewSignal",
    "enabled", "lookback_hours",
    "skew_divergence_threshold", "min_queries_for_signal",
]
