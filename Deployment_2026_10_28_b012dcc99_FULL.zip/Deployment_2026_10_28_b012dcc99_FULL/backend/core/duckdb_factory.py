"""
DuckDB Connection Factory — centralized creation with guaranteed cleanup.

Replaces scattered ``duckdb.connect()`` calls across the codebase with a
single context manager that:

1. Creates an in-memory DuckDB connection
2. Sets ``extension_directory`` for non-root containers
3. Optionally sets ``temp_directory`` from env
4. Guarantees ``con.close()`` in a ``finally`` block
5. Configures memory limit and thread count from env vars

Usage::

    from core.duckdb_factory import duckdb_connection

    with duckdb_connection() as con:
        result = con.execute("SELECT 42").fetchone()

    # read_only mode (no writes):
    with duckdb_connection(read_only=True) as con:
        ...

ONE CONNECTION PER QUERY IS A DECISION, AND IT IS MEASURED
----------------------------------------------------------
2026-09-07.  DuckDB's remote-file caches (external file cache, HTTP
metadata cache, parsed parquet-footer cache) live on the DatabaseInstance,
so a fresh ``:memory:`` connection per query throws away metadata the
previous query just paid S3 for.  That is real, and it was raised as "make
the caches survive a query".  Do not do it here.  What was measured, at
the wire, over a 60-file / 20-file-island report shape:

    scenario                         fresh conn   reused conn   saving
    identical query twice                   200           100      50%
    same files, different projection        180           120      33%
    DISJOINT files (one filter changed)     200           200       0%

and separately, ``enable_http_metadata_cache=true`` on a SINGLE query
changed nothing at all (100 round trips either way; DuckDB already caches
within a statement) -- so adding that pragma here is not the free win it
looks like, and it is deliberately not added.

The first row is now answered better by something else: the dataset/report
road consults ``core.dataset_result_cache`` before it ever gets here, and
an identical repeat costs **0** round trips, not 100.  So connection reuse
would buy the third row (nothing) and the second row (33% of round trips)
only.

Against that: this factory is used from ``asyncio.to_thread`` workers, so
report executions run CONCURRENTLY.  A shared DatabaseInstance carries S3
SECRETs, registered views and session-global settings, and sharing one
between two simultaneous queries for different connections is a
cross-tenant read, not a performance regression.  Making it safe needs an
EXCLUSIVE-CHECKOUT pool -- the whole
``duckdb_subprocess._pool_db_acquire/_release`` contract (fingerprint key,
catalog wipe VERIFIED by count, drop-on-error, age bound) PLUS the
concurrency that contract has never had to handle, because a pool worker
serves one request at a time by construction.

If the 33% is later judged worth having, the move is NOT a second reuse
mechanism in this file: it is to route ``federation_engine.
_execute_duckdb_s3`` onto the pool that already exists and is already on
by default (``duckdb_pool.enabled``/``db_instance_reuse``), where the
isolation contract is written, proven (tests/test_pool_db_reuse_2026_08_22
.py) and single-tenant by construction.

WHAT WOULD SETTLE IT: a counter on consecutive executions by the same
principal, classified by whether the resolved file set OVERLAPPED the
previous execution's.  Row two of the table above only pays out on
overlapping sets, and nothing in this product measures that share today.
"""
from __future__ import annotations

import logging
import os
import tempfile
from contextlib import contextmanager
from typing import Generator

import duckdb

logger = logging.getLogger(__name__)


@contextmanager
def duckdb_connection(
    *,
    read_only: bool = False,
    database: str = ":memory:",
) -> Generator[duckdb.DuckDBPyConnection, None, None]:
    """Create a DuckDB connection with standard configuration.

    Yields a configured DuckDB connection and guarantees cleanup via
    ``con.close()`` in a finally block — preventing memory leaks in
    long-running worker processes.

    Parameters
    ----------
    read_only : bool
        If True, opens the database in read-only mode.
    database : str
        Database path. Defaults to ``:memory:``.
    """
    con = duckdb.connect(database=database, read_only=read_only)
    try:
        _configure(con)
        yield con
    finally:
        try:
            con.close()
        except Exception:
            pass


def get_connection(
    *,
    database: str = ":memory:",
    read_only: bool = False,
) -> duckdb.DuckDBPyConnection:
    """Create a fully-configured DuckDB connection and RETURN it.

    Non-context-manager sibling of :func:`duckdb_connection` for callers that
    own the connection's lifetime themselves — e.g. the multi-worker executor,
    which holds the connection across a long query and closes/interrupts it
    from a separate cancel-watcher thread, so it cannot use the auto-closing
    ``with`` form.  **The caller MUST ``con.close()``.**

    2026-07-15 BUGFIX: ``core.multi_worker_executor`` has always imported this
    name (``from core.duckdb_factory import get_connection``), but it was never
    defined here — only ``duckdb_connection`` was.  The import raised
    ImportError, was swallowed, and every thread worker fell back to a RAW
    ``duckdb.connect(":memory:")`` that skips :func:`_configure` — so no
    ``extension_directory`` was set and DuckDB tried to auto-install httpfs
    into the read-only container HOME ``~/.duckdb`` → ``/.duckdb: Permission
    denied`` → all workers died and multi-worker silently fell back to
    single-worker on every query.  Defining it here routes workers through the
    same ``_configure`` (extension_directory → NFS, temp_directory, memory /
    thread limits, pushdown pragmas) the rest of the codebase uses.
    """
    con = duckdb.connect(database=database, read_only=read_only)
    try:
        _configure(con)
    except Exception:
        # _configure is best-effort (individual SETs already fail-open); never
        # fail connection creation because one pragma an older DuckDB rejects.
        logger.debug("get_connection: _configure raised (continuing)", exc_info=True)
    return con


def _configure(con: duckdb.DuckDBPyConnection) -> None:
    """Apply standard configuration to a DuckDB connection.

    Phase 139 (Tier 2.2): now reads from query_engine config (with env-var
    overrides) so admin tuning via config.json takes effect without a code
    change. ``duckdb_threads_per_query`` and ``duckdb_memory_limit_mb`` are
    the canonical knobs; env vars are kept for back-compat / one-off tweaks.
    """
    # Extension directory (for non-root containers)
    from core.file_formats import ensure_extension_directory
    ensure_extension_directory(con)

    # ── BF-599f (2026-05-31) — Disable auto-install of known extensions ─────
    # In air-gapped OpenShift, every ``LOAD httpfs`` (or any other extension
    # SET) triggers a lookup against ``extensions.duckdb.org`` to check the
    # version — this blocks for the corporate proxy connect-timeout (often
    # 30-120 s) per worker, adding minutes to multi-worker queries.
    # When ``QS_AUTOINSTALL_EXTENSIONS=false`` (operator opt-out), pin
    # ``autoinstall_known_extensions=false`` so DuckDB only LOADs from the
    # already-staged ``extension_directory`` (set above by
    # ``ensure_extension_directory``).  Pair with NFS-mounted extensions.
    _flag = (os.environ.get("QS_AUTOINSTALL_EXTENSIONS") or "").strip().lower()
    if _flag in ("false", "0", "no", "off"):
        try:
            con.execute("SET autoinstall_known_extensions=false")
        except Exception as exc:
            logger.debug("Could not pin autoinstall_known_extensions=false: %s", exc)

    # ── Memory limit: env override > config > unset ─────────────────────────
    mem_limit = os.environ.get("DUCKDB_MEMORY_LIMIT", "").strip()
    if not mem_limit:
        try:
            from core.config import query_engine as _qe
            mb = int(_qe.duckdb_memory_limit_mb)
            if mb > 0:
                mem_limit = f"{mb}MB"
        except Exception:
            mem_limit = ""
    if mem_limit:
        try:
            con.execute(f"SET memory_limit='{mem_limit}'")
        except Exception as exc:
            logger.debug("Could not set memory_limit=%s: %s", mem_limit, exc)

    # ── Thread count: env override > config > DuckDB default ────────────────
    threads = os.environ.get("DUCKDB_THREADS", "").strip()
    if not threads:
        try:
            from core.config import query_engine as _qe
            threads = str(int(_qe.duckdb_threads_per_query))
        except Exception:
            threads = ""
    if threads:
        try:
            n = int(threads)
            if n > 0:
                con.execute(f"SET threads={n}")
        except Exception as exc:
            logger.debug("Could not set threads=%s: %s", threads, exc)

    # ── Temp directory: env override, then config.json ─────────────────────
    # 2026-07-15: fall back to config.json ``paths.duckdb_temp_dir`` when the
    # env var isn't set, so the operator's NFS temp dir is honoured on the
    # in-process (factory / multi-worker thread) path — not just the
    # multi-worker spill resolver.  Matches the resolution the subprocess
    # path expects via DUCKDB_TEMP_DIR.
    temp_dir = os.environ.get("DUCKDB_TEMP_DIR", "").strip()
    if not temp_dir:
        try:
            from core.config import get as _cfg_get_tmp
            temp_dir = (_cfg_get_tmp("paths", "duckdb_temp_dir", "") or "").strip()
        except Exception:
            temp_dir = ""
    # 2026-07-16: temp_directory MUST resolve to a WRITABLE dir.  When neither
    # the env var nor config sets one (or the configured dir can't be created —
    # e.g. an NFS path with wrong perms, or config not yet deployed), DuckDB
    # falls back to creating a ``.tmp`` directory in the process CWD — which is
    # the read-only code dir inside the container.  The first spill / COPY TO
    # then dies with "failed to create directory .tmp: Permission denied" (the
    # query_native feed crash).  Try the configured dir, then a guaranteed-
    # writable local OS-temp dir; only give up if even that is unwritable.
    _local_spill = os.path.join(tempfile.gettempdir(), "qs_duckdb_spill")
    _set_temp = False
    for _cand in ([temp_dir] if temp_dir else []) + [_local_spill]:
        try:
            os.makedirs(_cand, exist_ok=True)
            con.execute(f"SET temp_directory='{_cand}'")
            _set_temp = True
            if _cand != temp_dir:
                logger.warning(
                    "duckdb temp_directory falling back to local %s "
                    "(configured=%r unset/unwritable)", _cand, temp_dir)
            break
        except Exception as exc:
            logger.warning(
                "duckdb temp_directory=%s unusable (%s); trying local fallback",
                _cand, exc)
    if not _set_temp:
        logger.error(
            "duckdb: no writable temp_directory (config/env/OS-temp all failed); "
            "spill/COPY TO may fail with '.tmp' permission errors")

    # ── BF-253: Parquet metadata cache (DuckDB ``enable_object_cache``) ─────
    # Without this, DuckDB re-reads each parquet file's footer (schema + row-
    # group stats) on every query, even when the same file was opened
    # seconds ago.  For workloads with 1000s of files repeated across queries
    # (Iceberg tables, partitioned scans), turning it on saves O(num_files)
    # round-trips to S3 per query.  Trino/Starburst do this at the connector
    # level by default; DuckDB exposes the same as a single pragma.
    # The cache is in-memory, per-connection, evicted under memory pressure.
    # Fail-open: any pragma error is logged and ignored.
    try:
        con.execute("SET enable_object_cache=true")
    except Exception as exc:
        logger.debug("Could not enable object cache: %s", exc)

    # ── BF-532 (2026-05-28): enterprise-level pushdown pragmas ──────────────
    # Snowflake / Starburst do these by default at the connector level;
    # DuckDB exposes them as single pragmas.  Each is fail-open (older
    # DuckDB versions may not have the setting — degrade silently).
    #
    # http_compression: ~20-30% S3 bandwidth saved on parquet GETs
    #   (parquet footer + page index are highly compressible).
    # http_keep_alive: keeps a connection alive BETWEEN requests.
    #   2026-09-20 — the comment that used to sit here claimed this "reuse[s]
    #   TCP connections to S3, avoiding TLS handshake per file".  Measured at
    #   a TCP relay, that is NOT what it does: with keep-alive on, DuckDB
    #   opened TWO TCP connections PER FILE, and 7,300 files meant 14,600
    #   connections and an exhausted endpoint.  The setting that actually
    #   reuses connections is ``httpfs_connection_caching`` — see
    #   core/s3_http_transport.py.  It cannot be set here: it does not exist
    #   until ``LOAD httpfs``, and this factory configures the connection
    #   before any caller loads the extension.  It is applied by the two
    #   modules that DO load httpfs, immediately after they load it.
    # preserve_insertion_order=false: lets DuckDB parallelise scans more
    #   aggressively when the SQL doesn't depend on file order.
    _pragmas_pushdown = [
        ("SET http_compression=true",       "http_compression"),
        ("SET http_keep_alive=true",        "http_keep_alive"),
        ("SET preserve_insertion_order=false", "preserve_insertion_order"),
        # BF-537 (2026-05-28): defensively pin enable_predicate_pushdown
        # AND enable_optimizer.  DuckDB defaults them to true today, but
        # an older container image or a SET in user-supplied COPY SQL
        # could flip them off.  Pinning them at connection setup is
        # idempotent and ensures partition-bound pruning still fires.
        ("SET enable_optimizer=true",       "enable_optimizer"),
        # enable_progress_bar=false avoids stderr spam in subprocess mode
        # under high-concurrency pods where the carriage-return updates
        # corrupt log scraping.
        ("SET enable_progress_bar=false",   "progress_bar_off"),
    ]
    for stmt, label in _pragmas_pushdown:
        try:
            con.execute(stmt)
        except Exception as exc:
            logger.debug("BF-532: could not set %s (older DuckDB?): %s",
                         label, exc)
