"""Generic COMPARISON: one measure, many buckets of one axis, side by side.

2026-09-17.  The requirement that prompted this was FD-04..FD-08 -- "select
two COB dates and calculate Variance and % Variance", "MTD and YTD views",
"trend by side-by-side display of daily / month-end / year-end dates".  Read
literally that is five date features.

It is not.  The mechanism was proven on the live stack BEFORE this module
existed, and the proof did not compare two dates at all -- it compared two
values of ``status``:

    SUM(CASE WHEN status = 'SETTLED' THEN amt END)
    SUM(CASE WHEN status = 'NEW'     THEN amt END)
    ROUND((settled - new) / NULLIF(new, 0) * 100, 4)

5 rows, 0.311s over 1.5M rows, hand-checked correct.  Nothing in the shape
cares that the axis is a date.  So this module compares buckets of ANY
dimension: dates give FD-04..FD-08, and ``scenario`` gives budget-vs-actual,
``version`` gives restatement analysis, ``ccy`` gives currency comparison --
with no further code.

WHAT THIS MODULE IS
    Pure.  It takes a declaration and returns SQL expression STRINGS plus the
    metadata describing what they mean.  No database, no I/O, no engine
    import beyond two shared constants.  That is what makes it testable
    exhaustively and what keeps it from becoming a second query builder.

WHAT THIS MODULE IS DELIBERATELY NOT
    A second query builder.  The expressions it emits are consumed through
    the calculated-metric ``expression`` hook that ``federation_engine``
    already evaluates -- the same hook the live proof above used.  This
    codebase is currently paying for the opposite choice in three places: one
    correct identifier-quoting helper exists and three builders ignore it
    (data quality, materialized views, NL-to-SQL), each emitting SQL no
    engine can run.  There is no fourth builder here.

TWO RULES THIS MODULE ENFORCES RATHER THAN ASSUMES

    Buckets are VALUES, never SQL.  Every literal goes through
    ``core.query_compiler.sql_literal`` -- the single inline-literal
    chokepoint, whose own docstring records that three competing renderers
    caused an outage.  A caller cannot inject SQL through a bucket value, so
    a business user can author a comparison with no SQL surface at all --
    which is the actual point of the requirement ("without technical
    support").

    ``on_missing`` is MANDATORY.  A bucket with no rows is the classic
    silent-wrong-answer: variance against an absent period reads as a 100%
    move.  ``zero``, ``null`` and ``refuse`` are all legitimate business
    answers; GUESSING is not.  There is no default.
"""
from __future__ import annotations

import calendar
import datetime as _dt
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Sequence, Tuple

# The two shared constants, imported rather than re-declared.
from core.federation_engine import VALID_AGGREGATIONS
from core.query_compiler import sql_literal

__all__ = [
    "Bucket", "Measure", "ComparisonSpec", "GeneratedColumn",
    "ComparisonError", "BUCKET_KINDS", "RULE_NAMES", "DERIVED_KINDS",
    "ON_MISSING_MODES", "resolve_rule",
]


class ComparisonError(ValueError):
    """A spec that cannot be honoured.  Always names the field and the rule.

    A refusal here is a REFUSAL, not a downgrade: the alternative is emitting
    a comparison whose numbers look plausible and are not.
    """


#: Bucket kinds.  POINT/SET/RANGE are literal; RULE expands to POINTs or a
#: RANGE against an anchor date, so every rule is expressible without one.
BUCKET_KINDS = frozenset({"point", "set", "range", "rule"})

#: Date rules.  Each is a pure function of (anchor, n) -- see ``resolve_rule``.
#: Adding one here is the ONLY place a new period shape needs to be declared.
RULE_NAMES = frozenset({
    "last_n_days",          # n POINTs: anchor, anchor-1, ... (chronological)
    "daily_in_month",       # every day of anchor's month up to anchor
    "last_n_month_ends",    # n POINTs: last calendar day of each month back
    "last_n_year_ends",     # n POINTs: 31 Dec of each year back
    "mtd",                  # one RANGE: month start .. anchor
    "ytd",                  # one RANGE: year start .. anchor
})

#: Derived columns.  Each is computed from already-generated bucket columns,
#: never from a second scan of the source.
DERIVED_KINDS = frozenset({
    "variance",         # last - first
    "variance_pct",     # (last - first) / NULLIF(first, 0) * 100
    "share_of_total",   # bucket / NULLIF(sum of all buckets, 0) * 100
    "index_to_first",   # bucket / NULLIF(first, 0) * 100
})

#: What an EMPTY bucket means.  No default, on purpose.
ON_MISSING_MODES = frozenset({"zero", "null", "refuse"})

#: Identifier guard.  Physical names reach SQL unquoted-by-us (the builder
#: quotes them), so anything that is not a plain identifier is refused rather
#: than escaped -- escaping an injection attempt is how you ship one.
_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

#: Label guard.  Labels become column aliases, so the same rule applies.
_LABEL_SAFE_RE = re.compile(r"[^A-Za-z0-9_]+")

_MAX_BUCKETS = 120          # 3 years of month-ends, with room; see _validate
_MAX_MEASURES = 24


def _ident(name: str, field_name: str) -> str:
    """A physical column name, or a refusal naming the field."""
    n = str(name or "").strip()
    if not _IDENT_RE.match(n):
        raise ComparisonError(
            f"{field_name}: {name!r} is not a plain column identifier. "
            f"Comparison axes and measures are dataset COLUMNS, not "
            f"expressions -- a computed value belongs in a calculated metric."
        )
    return n


def _label(raw: Any) -> str:
    """A deterministic, SQL-safe alias fragment for a bucket."""
    s = _LABEL_SAFE_RE.sub("_", str(raw)).strip("_")
    return s or "bucket"


@dataclass(frozen=True)
class Bucket:
    """One slice of the comparison axis.

    ``label`` is what the caller sees and what the generated alias is built
    from; it is derived from the value when not given, so two buckets can
    never silently share a column name.
    """
    kind: str
    label: str = ""
    value: Any = None                       # point
    values: Tuple[Any, ...] = ()            # set
    frm: Any = None                         # range (from)
    to: Any = None                          # range
    rule: str = ""                          # rule
    anchor: Any = None                      # rule
    n: int = 0                              # rule

    def predicate(self, axis: str, data_type: str = "") -> str:
        """The WHEN clause for this bucket, with every literal escaped."""
        q = f'"{axis}"'
        if self.kind == "point":
            return f"{q} = {sql_literal(self.value, data_type)}"
        if self.kind == "set":
            vals = ", ".join(sql_literal(v, data_type) for v in self.values)
            return f"{q} IN ({vals})"
        if self.kind == "range":
            return (f"{q} >= {sql_literal(self.frm, data_type)} AND "
                    f"{q} <= {sql_literal(self.to, data_type)}")
        raise ComparisonError(
            f"bucket kind {self.kind!r} has no predicate; RULE buckets must "
            f"be resolved with ComparisonSpec.resolved() first")


@dataclass(frozen=True)
class Measure:
    """A dataset measure and how to aggregate it within each bucket."""
    column: str
    aggregation: str = "SUM"
    label: str = ""

    def agg(self) -> str:
        a = str(self.aggregation or "SUM").upper()
        if a not in VALID_AGGREGATIONS:
            raise ComparisonError(
                f"measure {self.column!r}: aggregation {self.aggregation!r} "
                f"is not permitted. Allowed: {sorted(VALID_AGGREGATIONS)}")
        return a


@dataclass(frozen=True)
class GeneratedColumn:
    """One emitted column: the SQL, and what it MEANS.

    ``role`` and ``grain`` travel with the result on purpose.  A comparison
    widens the grid to "one row per dimension combination, N measures wide",
    and a consumer that does not know that will average a column of sums --
    the defect measured at 179x on the pivot surface.  The metadata is how a
    caller can refuse.
    """
    name: str
    expression: str
    role: str                     # bucket_measure | derived
    measure: str = ""
    bucket_label: str = ""
    derived_kind: str = ""
    data_type: str = "number"
    presence_probe: bool = False  # True for the on_missing="refuse" companion


def _last_day(year: int, month: int) -> _dt.date:
    return _dt.date(year, month, calendar.monthrange(year, month)[1])


def _as_date(value: Any, field_name: str) -> _dt.date:
    if isinstance(value, _dt.datetime):
        return value.date()
    if isinstance(value, _dt.date):
        return value
    try:
        return _dt.date.fromisoformat(str(value)[:10])
    except Exception as exc:                                  # noqa: BLE001
        raise ComparisonError(
            f"{field_name}: {value!r} is not an ISO date (YYYY-MM-DD)") from exc


def resolve_rule(rule: str, anchor: Any, n: int = 1) -> List[Bucket]:
    """Expand a date RULE into concrete POINT/RANGE buckets.

    Pure and total: same inputs, same buckets, always chronological so a
    trend reads left to right without the caller re-sorting.  Month-end
    arithmetic is calendar-aware (February, leap years) rather than
    30-day approximate -- an off-by-one here is a silently wrong period.
    """
    r = str(rule or "").strip().lower()
    if r not in RULE_NAMES:
        raise ComparisonError(
            f"bucket rule {rule!r} is not recognised. "
            f"Allowed: {sorted(RULE_NAMES)}")
    a = _as_date(anchor, f"rule {r!r} anchor")

    if r in ("mtd", "ytd"):
        start = a.replace(day=1) if r == "mtd" else a.replace(month=1, day=1)
        return [Bucket(kind="range", frm=start.isoformat(), to=a.isoformat(),
                       label=f"{r}_{a.isoformat()}")]

    count = int(n or 0)
    if count < 1:
        raise ComparisonError(f"rule {r!r}: n must be >= 1, got {n!r}")

    dates: List[_dt.date] = []
    if r == "last_n_days":
        dates = [a - _dt.timedelta(days=i) for i in range(count)]
    elif r == "daily_in_month":
        first = a.replace(day=1)
        dates = [first + _dt.timedelta(days=i)
                 for i in range((a - first).days + 1)]
    elif r == "last_n_month_ends":
        y, m = a.year, a.month
        for _ in range(count):
            dates.append(_last_day(y, m))
            m -= 1
            if m == 0:
                m, y = 12, y - 1
    elif r == "last_n_year_ends":
        dates = [_dt.date(a.year - i, 12, 31) for i in range(count)]

    dates = sorted(set(dates))
    return [Bucket(kind="point", value=d.isoformat(), label=d.isoformat())
            for d in dates]


@dataclass(frozen=True)
class ComparisonSpec:
    """A declared comparison.  Validate once, generate deterministically.

    ``axis_data_type`` is passed to the literal renderer so a date axis emits
    a typed literal rather than a quoted string -- the exact failure recorded
    in ``federation_engine._sql_literal``'s docstring, where Starburst
    rejected ``date = varchar(27)``.
    """
    axis: str
    buckets: Tuple[Bucket, ...]
    measures: Tuple[Measure, ...]
    on_missing: str
    derived: Tuple[str, ...] = ()
    axis_data_type: str = ""
    scale: int = 4

    # ── construction ────────────────────────────────────────────────────
    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "ComparisonSpec":
        """Build from the wire shape, refusing anything unusable.

        Unknown top-level keys are REFUSED rather than ignored.  Silently
        dropping an unrecognised field is how a mistyped filter key produced
        an unfiltered aggregate that looked like a report (measured at 2.35x
        on this stack).  A comparison is exactly the place that must not
        happen.
        """
        if not isinstance(d, dict):
            raise ComparisonError("comparison spec must be an object")
        known = {"axis", "buckets", "measures", "on_missing", "derived",
                 "axis_data_type", "scale"}
        unknown = sorted(set(d) - known)
        if unknown:
            raise ComparisonError(
                f"unknown field(s) {unknown} in comparison spec. "
                f"Known: {sorted(known)}. Refusing rather than ignoring them "
                f"-- a dropped field here changes the numbers silently.")

        on_missing = str(d.get("on_missing") or "").strip().lower()
        if on_missing not in ON_MISSING_MODES:
            raise ComparisonError(
                f"on_missing is required and must be one of "
                f"{sorted(ON_MISSING_MODES)}; got {d.get('on_missing')!r}. "
                f"There is no default: a bucket with no rows means different "
                f"things to different businesses, and guessing turns an "
                f"absent period into a 100% variance.")

        raw_buckets = d.get("buckets") or []
        if not isinstance(raw_buckets, list) or not raw_buckets:
            raise ComparisonError("buckets: at least one bucket is required")
        buckets = tuple(ComparisonSpec._bucket_from(b, i)
                        for i, b in enumerate(raw_buckets))

        raw_measures = d.get("measures") or []
        if not isinstance(raw_measures, list) or not raw_measures:
            raise ComparisonError("measures: at least one measure is required")
        measures = tuple(ComparisonSpec._measure_from(m, i)
                         for i, m in enumerate(raw_measures))

        derived = tuple(str(x).strip().lower() for x in (d.get("derived") or []))
        bad = sorted(set(derived) - DERIVED_KINDS)
        if bad:
            raise ComparisonError(
                f"derived: {bad} not recognised. Allowed: {sorted(DERIVED_KINDS)}")

        scale = d.get("scale", 4)
        try:
            scale = int(scale)
        except Exception as exc:                              # noqa: BLE001
            raise ComparisonError(f"scale: {scale!r} is not an integer") from exc
        if not 0 <= scale <= 12:
            raise ComparisonError(f"scale must be 0..12, got {scale}")

        spec = ComparisonSpec(
            axis=_ident(d.get("axis"), "axis"),
            buckets=buckets,
            measures=measures,
            on_missing=on_missing,
            derived=derived,
            axis_data_type=str(d.get("axis_data_type") or ""),
            scale=scale,
        )
        spec._validate()
        return spec

    @staticmethod
    def _bucket_from(b: Any, idx: int) -> Bucket:
        if not isinstance(b, dict):
            raise ComparisonError(f"buckets[{idx}] must be an object")
        kind = str(b.get("kind") or "").strip().lower()
        if kind not in BUCKET_KINDS:
            raise ComparisonError(
                f"buckets[{idx}].kind {b.get('kind')!r} is not one of "
                f"{sorted(BUCKET_KINDS)}")
        label = str(b.get("label") or "")
        if kind == "point":
            if "value" not in b:
                raise ComparisonError(f"buckets[{idx}]: POINT needs a value")
            return Bucket(kind="point", value=b["value"],
                          label=_label(label or b["value"]))
        if kind == "set":
            vals = b.get("values") or []
            if not isinstance(vals, list) or not vals:
                raise ComparisonError(
                    f"buckets[{idx}]: SET needs a non-empty values list")
            return Bucket(kind="set", values=tuple(vals),
                          label=_label(label or "_".join(map(str, vals[:3]))))
        if kind == "range":
            if "from" not in b or "to" not in b:
                raise ComparisonError(
                    f"buckets[{idx}]: RANGE needs 'from' and 'to'")
            return Bucket(kind="range", frm=b["from"], to=b["to"],
                          label=_label(label or f"{b['from']}_{b['to']}"))
        rule = str(b.get("rule") or "").strip().lower()
        if rule not in RULE_NAMES:
            raise ComparisonError(
                f"buckets[{idx}].rule {b.get('rule')!r} is not one of "
                f"{sorted(RULE_NAMES)}")
        if "anchor" not in b:
            raise ComparisonError(
                f"buckets[{idx}]: RULE needs an anchor date. It is explicit "
                f"rather than 'today' so a saved report reproduces the same "
                f"periods when it is re-run or replayed.")
        return Bucket(kind="rule", rule=rule, anchor=b["anchor"],
                      n=int(b.get("n") or 1), label=_label(label))

    @staticmethod
    def _measure_from(m: Any, idx: int) -> Measure:
        if isinstance(m, str):
            return Measure(column=_ident(m, f"measures[{idx}]"))
        if not isinstance(m, dict):
            raise ComparisonError(f"measures[{idx}] must be a string or object")
        col = _ident(m.get("column"), f"measures[{idx}].column")
        meas = Measure(column=col,
                       aggregation=str(m.get("aggregation") or "SUM"),
                       label=_label(m.get("label") or col))
        meas.agg()          # validate against the whitelist now, not at SQL time
        return meas

    def _validate(self) -> None:
        # Count RESOLVED buckets, not declared ones.  A single RULE bucket
        # with n=500 declares one and emits five hundred, so validating the
        # declared list is a guard that cannot fire on the only case wide
        # enough to need it.  Caught by its own test.
        n_buckets = len(self.resolved().buckets)
        if n_buckets > _MAX_BUCKETS:
            raise ComparisonError(
                f"buckets: this spec resolves to {n_buckets}, which exceeds "
                f"the cap of {_MAX_BUCKETS}. Each bucket adds a column per "
                f"measure, so this is a width guard, not a row cap.")
        if len(self.measures) > _MAX_MEASURES:
            raise ComparisonError(
                f"measures: {len(self.measures)} exceeds the cap of "
                f"{_MAX_MEASURES}")
        for d in self.derived:
            if d in ("variance", "variance_pct", "index_to_first") and \
                    n_buckets < 2:
                raise ComparisonError(
                    f"derived {d!r} compares buckets and needs at least two; "
                    f"this spec resolves to {n_buckets}.")

    # ── resolution ──────────────────────────────────────────────────────
    def resolved(self) -> "ComparisonSpec":
        """A copy with every RULE expanded to concrete buckets.

        Idempotent -- resolving a resolved spec returns an equal spec -- so a
        caller may resolve defensively without changing the result.
        """
        if not any(b.kind == "rule" for b in self.buckets):
            return self
        out: List[Bucket] = []
        seen: set = set()
        for b in self.buckets:
            expanded = resolve_rule(b.rule, b.anchor, b.n) \
                if b.kind == "rule" else [b]
            for e in expanded:
                if e.label in seen:
                    continue        # a rule may overlap an explicit bucket
                seen.add(e.label)
                out.append(e)
        return ComparisonSpec(
            axis=self.axis, buckets=tuple(out), measures=self.measures,
            on_missing=self.on_missing, derived=self.derived,
            axis_data_type=self.axis_data_type, scale=self.scale)

    # ── generation ──────────────────────────────────────────────────────
    def generate(self) -> List[GeneratedColumn]:
        """Expand the spec into SQL expressions plus their meaning.

        ONE scan: every bucket is a conditional aggregate over the same rows,
        not a self-join of N date-scoped subqueries.  On the S3 path a join
        would also defeat the partition pruning that takes 7,300 files to 4.
        """
        spec = self.resolved()
        cols: List[GeneratedColumn] = []

        for m in spec.measures:
            agg = m.agg()
            for b in spec.buckets:
                pred = b.predicate(spec.axis, spec.axis_data_type)
                inner = f'{agg}(CASE WHEN {pred} THEN "{m.column}" END)'
                expr = f"COALESCE({inner}, 0)" if spec.on_missing == "zero" else inner
                cols.append(GeneratedColumn(
                    name=f"{m.label or m.column}__{b.label}",
                    expression=expr, role="bucket_measure",
                    measure=m.column, bucket_label=b.label))
                if spec.on_missing == "refuse":
                    # The companion the caller checks.  Without it "no rows"
                    # and "rows summing to NULL" are indistinguishable, and a
                    # refusal that cannot tell them apart is not a refusal.
                    cols.append(GeneratedColumn(
                        name=f"{m.label or m.column}__{b.label}__present",
                        expression=f"COUNT(CASE WHEN {pred} THEN 1 END)",
                        role="bucket_measure", measure=m.column,
                        bucket_label=b.label, data_type="integer",
                        presence_probe=True))

        cols.extend(self._derived(spec))
        return cols

    def _derived(self, spec: "ComparisonSpec") -> List[GeneratedColumn]:
        out: List[GeneratedColumn] = []
        if not spec.derived:
            return out
        first, last = spec.buckets[0], spec.buckets[-1]

        for m in spec.measures:
            agg = m.agg()
            mlabel = m.label or m.column

            def bucket_expr(b: Bucket) -> str:
                pred = b.predicate(spec.axis, spec.axis_data_type)
                return f'{agg}(CASE WHEN {pred} THEN "{m.column}" END)'

            f_expr, l_expr = bucket_expr(first), bucket_expr(last)

            if "variance" in spec.derived:
                out.append(GeneratedColumn(
                    name=f"{mlabel}__variance",
                    # No COALESCE: if either side is absent the variance is
                    # UNKNOWN, and zero would read as "no change".
                    expression=f"({l_expr}) - ({f_expr})",
                    role="derived", measure=m.column, derived_kind="variance"))
            if "variance_pct" in spec.derived:
                out.append(GeneratedColumn(
                    name=f"{mlabel}__variance_pct",
                    expression=(f"ROUND((({l_expr}) - ({f_expr})) / "
                                f"NULLIF(({f_expr}), 0) * 100, {spec.scale})"),
                    role="derived", measure=m.column,
                    derived_kind="variance_pct"))
            if "index_to_first" in spec.derived:
                for b in spec.buckets:
                    out.append(GeneratedColumn(
                        name=f"{mlabel}__{b.label}__index",
                        expression=(f"ROUND(({bucket_expr(b)}) / "
                                    f"NULLIF(({f_expr}), 0) * 100, {spec.scale})"),
                        role="derived", measure=m.column,
                        bucket_label=b.label, derived_kind="index_to_first"))
            if "share_of_total" in spec.derived:
                total = " + ".join(f"COALESCE({bucket_expr(b)}, 0)"
                                   for b in spec.buckets)
                for b in spec.buckets:
                    out.append(GeneratedColumn(
                        name=f"{mlabel}__{b.label}__share",
                        expression=(f"ROUND(({bucket_expr(b)}) / "
                                    f"NULLIF(({total}), 0) * 100, {spec.scale})"),
                        role="derived", measure=m.column,
                        bucket_label=b.label, derived_kind="share_of_total"))
        return out

    # ── description ─────────────────────────────────────────────────────
    def describe(self) -> Dict[str, Any]:
        """What the caller needs to render the result HONESTLY.

        ``grain`` is the important key.  A comparison produces one row per
        dimension combination, N measures wide, and every bucket column is
        ALREADY AGGREGATED.  A consumer that averages a column of sums gets a
        number that looks plausible and is not -- measured at 179x on the
        pivot surface.  Stating the grain is what lets that consumer refuse.
        """
        spec = self.resolved()
        return {
            "axis": spec.axis,
            "on_missing": spec.on_missing,
            "buckets": [{"label": b.label, "kind": b.kind} for b in spec.buckets],
            "measures": [{"column": m.column, "aggregation": m.agg(),
                          "label": m.label or m.column} for m in spec.measures],
            "derived": list(spec.derived),
            "grain": "pre_aggregated_by_dimensions",
            "non_additive_safe": False,
            "note": ("every bucket column is already aggregated; avg/count/"
                     "min/max over these columns describe the GROUPS, not the "
                     "underlying rows"),
        }
