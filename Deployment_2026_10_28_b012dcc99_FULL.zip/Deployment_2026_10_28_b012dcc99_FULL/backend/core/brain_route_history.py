"""BrainRouteHistory -- outcome-driven route learning.

Phase 156.3 (2026-06-25) -- closes the brain's third feedback loop.

Today the brain picks ``spark_connect`` or ``multi_worker`` or
``single`` based on heuristics: file count, hostile-pattern flag,
cost-model prediction.  It never measures whether the decision was
right.  If Spark turned out to be slower than local for a SQL shape,
the brain has no way to learn -- it'll pick Spark again next time.

This module gives the brain memory:

  * ``record_outcome(sql_hash, engine, seconds, status)`` -- caller
    (execute_api) reports wall-clock after every query.  EMA-smoothed
    per (sql_hash, table, engine) so spikes don't flip the decision.
  * ``prefer_local_over_spark(sql_hash, ...) -> bool`` -- consumer
    (BrainRouter) asks "for this SQL shape, has local been faster
    than Spark in the recent past?".  Returns True only when there's
    enough evidence on BOTH sides AND local won by the configured
    margin.

Strategic guard rails:

  * Both engines must have N samples before we trust the comparison
    (``min_samples_for_decision``, default 3) -- one slow Spark
    sample shouldn't permanently flip the decision.
  * Local must be faster by a margin (``flip_savings_factor``,
    default 1.5) -- avoids flipping for noise.
  * Cleanup daemon evicts rows untouched for N days (default 30).

Fail-OPEN at every edge: any error returns False from the consumer
(brain falls through to its existing heuristics) and a silent no-op
on writes.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


# Phase 156 deep-dive R16 -- tiny per-process LRU for the route history
# DB lookups.  BrainRouter consults route_history on EVERY query; without
# a cache we'd hit the DB once per query per pod.  This LRU is purely
# additive: any DB write (record_outcome) bumps a generation so the
# next lookup for that key reads fresh.  Bounded; fail-OPEN.
_RH_LOCK = threading.Lock()
_RH_CACHE: Dict[str, Dict[str, Any]] = {}   # key -> {ts, value}
_RH_CACHE_MAX = 500
_RH_CACHE_TTL = 30  # seconds; matches typical BQB click cadence


def _rh_key(sql_hash: str, bucket: str, table_prefix: str) -> str:
    return f"{sql_hash}|{bucket}|{(table_prefix or '').rstrip('/')}"


def _rh_cache_get(key: str) -> Optional[Dict[str, dict]]:
    now = time.time()
    with _RH_LOCK:
        entry = _RH_CACHE.get(key)
        if not entry:
            return None
        if now - entry["ts"] > _RH_CACHE_TTL:
            _RH_CACHE.pop(key, None)
            return None
        return entry["value"]


def _rh_cache_put(key: str, value: Dict[str, dict]) -> None:
    now = time.time()
    with _RH_LOCK:
        if len(_RH_CACHE) >= _RH_CACHE_MAX:
            # Drop oldest 10%.
            stale = sorted(_RH_CACHE.items(), key=lambda kv: kv[1]["ts"])[: max(1, _RH_CACHE_MAX // 10)]
            for k, _ in stale:
                _RH_CACHE.pop(k, None)
        _RH_CACHE[key] = {"ts": now, "value": value}


def _rh_cache_invalidate(key: str) -> None:
    with _RH_LOCK:
        _RH_CACHE.pop(key, None)


def reset_for_tests() -> None:
    with _RH_LOCK:
        _RH_CACHE.clear()


# ── Config ────────────────────────────────────────────────────────────


def _cfg(key: str, fallback: Any) -> Any:
    try:
        from core.config import get as _g
        return _g("brain_route_history", key, fallback)
    except Exception:
        return fallback


def enabled() -> bool:
    return bool(_cfg("enabled", True))


def min_samples_for_decision() -> int:
    return int(_cfg("min_samples_for_decision", 3) or 3)


def flip_savings_factor() -> float:
    return float(_cfg("flip_savings_factor", 1.5) or 1.5)


def cleanup_ttl_days() -> int:
    return int(_cfg("cleanup_ttl_days", 30) or 30)


def ema_alpha() -> float:
    return float(_cfg("ema_alpha", 0.3) or 0.3)


# ── Producer side -- called by execute_api after every query ──────────


def record_outcome(
    *, sql_hash: str, bucket: str, table_prefix: str,
    engine: str, seconds: float, status: str = "completed",
    db_manager: Any = None,
) -> None:
    """Record the wall-clock outcome of a query.  Cheap upsert.
    Fail-OPEN."""
    if not enabled() or not sql_hash or not engine:
        return
    if db_manager is None:
        try:
            from core.database import get_db_manager
            db_manager = get_db_manager()
        except Exception:
            return
    if db_manager is None:
        return
    try:
        db_manager.brain_route_outcome_record(
            sql_hash=sql_hash, bucket=bucket,
            table_prefix=table_prefix, engine=engine,
            seconds=seconds, status=status, ema_alpha=ema_alpha(),
        )
        # Phase 156 deep-dive R16 -- invalidate the lookup cache so
        # the next consult reads the freshly-updated EMA, not a
        # 30-second-stale snapshot.
        _rh_cache_invalidate(_rh_key(sql_hash, bucket, table_prefix))
    except Exception as exc:
        logger.debug("[brain-route-history] record failed: %s", exc)


# ── Consumer side -- called by BrainRouter._decide ───────────────────


def lookup(
    sql_hash: str, bucket: str, table_prefix: str,
    db_manager: Any = None,
) -> Dict[str, dict]:
    """Return ``{engine: {ema_seconds, sample_count, ...}}`` for a
    given SQL shape + table.  Empty dict on miss."""
    if not enabled() or not sql_hash:
        return {}
    # Phase 156 deep-dive R16 -- per-process LRU short-circuit.
    cache_key = _rh_key(sql_hash, bucket, table_prefix)
    cached = _rh_cache_get(cache_key)
    if cached is not None:
        return cached
    if db_manager is None:
        try:
            from core.database import get_db_manager
            db_manager = get_db_manager()
        except Exception:
            return {}
    if db_manager is None:
        return {}
    try:
        result = db_manager.brain_route_outcome_get(
            sql_hash, bucket, table_prefix,
        ) or {}
        _rh_cache_put(cache_key, result)
        return result
    except Exception:
        return {}


def prefer_local_over_spark(
    *, sql_hash: str, bucket: str, table_prefix: str,
    db_manager: Any = None,
) -> bool:
    """Brain decision-flip helper.

    True iff:
      * BOTH ``single`` (or ``multi_worker``) AND ``spark_connect``
        each have >= ``min_samples_for_decision`` samples.
      * local EMA < spark EMA / ``flip_savings_factor``.

    When True, BrainRouter should prefer local even if its
    cost-model wanted Spark -- prior runs prove Spark wasn't faster
    here.
    """
    if not enabled() or not sql_hash:
        return False
    outcomes = lookup(sql_hash, bucket, table_prefix, db_manager)
    if not outcomes:
        return False
    spark = outcomes.get("spark_connect")
    # Fastest local-side engine (multi_worker beats single when both run).
    local_keys = ("multi_worker", "single", "multi_pod")
    local = None
    for k in local_keys:
        cur = outcomes.get(k)
        if not cur:
            continue
        if local is None or (cur.get("ema_seconds") or 0) < (local.get("ema_seconds") or 1e9):
            local = cur
    if not spark or not local:
        return False
    min_samples = min_samples_for_decision()
    if int(spark.get("sample_count") or 0) < min_samples:
        return False
    if int(local.get("sample_count") or 0) < min_samples:
        return False
    spark_t = float(spark.get("ema_seconds") or 0.0)
    local_t = float(local.get("ema_seconds") or 0.0)
    if spark_t <= 0 or local_t <= 0:
        return False
    return local_t * flip_savings_factor() < spark_t


def get_recent(limit: int = 50, db_manager: Any = None) -> list:
    """Admin telemetry -- recently observed outcomes for the chip."""
    if db_manager is None:
        try:
            from core.database import get_db_manager
            db_manager = get_db_manager()
        except Exception:
            return []
    if db_manager is None:
        return []
    try:
        return db_manager.brain_route_outcome_recent(limit) or []
    except Exception:
        return []


__all__ = [
    "enabled",
    "record_outcome",
    "lookup",
    "prefer_local_over_spark",
    "get_recent",
]
