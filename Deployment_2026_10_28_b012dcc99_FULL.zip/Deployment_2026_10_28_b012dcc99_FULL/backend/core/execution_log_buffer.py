"""Per-execution log buffer.

User feedback: "only query related logs" should be visible in the
execution-history UI alongside the stage-timing breakdown.  Today logs
go to stderr/file with a request_id tag, but the UI doesn't surface
them filtered per execution.

This module:
  - Defines a ContextVar holding the current execution_id (set by
    api/execute_api.py for the duration of the query worker)
  - Defines an ``ExecutionLogHandler(logging.Handler)`` that captures
    each log record into a per-execution list
  - Filters by ContextVar value at emit time — logs from concurrent
    requests / scheduler / health checks have a different (or absent)
    execution_id and are NOT captured into this buffer
  - Caps each buffer at ``max_records`` (default 500) and per-record
    message length (default 2KB) so a runaway logger can't OOM the
    process
  - Drains the buffer at end-of-execution; the caller persists to
    files_metadata['log_lines'] for UI replay

Async-safety: Python ContextVars propagate through ``asyncio.create_task``
and ``asyncio.to_thread`` so the buffer correctly captures logs from
both async-worker code paths and threaded sub-jobs spawned during the
execution.  ThreadPoolExecutor workers DO NOT inherit ContextVars; for
those (e.g. boto3 download threads) the orchestrator must explicitly
propagate by passing execution_id and calling ``with_execution_id()``
around the work.
"""
from __future__ import annotations

import contextvars
import logging
import threading
import time
from typing import Any, Dict, List, Optional


# ── Public ContextVar — set by api/execute_api at start of query work ────────
_CURRENT_EXEC_ID: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "querystudio_current_execution_id", default=None,
)


# ── Buffer storage (per execution_id) ────────────────────────────────────────
# Bounded by per-execution max_records, and the registry itself is bounded
# by drain-on-completion + a passive cleanup of entries older than the
# longest reasonable execution (1h).
_BUFFERS: Dict[str, List[Dict[str, Any]]] = {}
_BUFFER_LOCK = threading.Lock()
_MAX_RECORDS_PER_EXEC = 500
_MAX_MESSAGE_LEN = 2048


def with_execution_id(execution_id: Optional[str]):
    """Context manager: bind execution_id to this scope so logs emitted
    inside (including from spawned asyncio tasks and ``asyncio.to_thread``)
    land in the per-execution buffer.

    Usage:
        with with_execution_id(execution_id):
            await do_query_work()

    Idempotent: nested calls override the inner scope but restore on exit.
    """
    class _Ctx:
        def __enter__(self_inner):
            self_inner._tok = _CURRENT_EXEC_ID.set(execution_id)
            # Pre-create the buffer slot so emit() doesn't need to lock
            # twice for first-record-of-execution.
            if execution_id:
                with _BUFFER_LOCK:
                    _BUFFERS.setdefault(execution_id, [])
            return self_inner

        def __exit__(self_inner, *exc):
            _CURRENT_EXEC_ID.reset(self_inner._tok)
            return False

    return _Ctx()


def get_current_execution_id() -> Optional[str]:
    """Return the execution_id bound to this context, or None."""
    return _CURRENT_EXEC_ID.get(None)


def drain(execution_id: str) -> List[Dict[str, Any]]:
    """Pop the buffer for this execution and return the captured records.

    Call this from the engine's finally block BEFORE end_execution so the
    records can be persisted to files_metadata['log_lines'] for UI replay.
    Idempotent: missing execution_id returns an empty list.
    """
    if not execution_id:
        return []
    with _BUFFER_LOCK:
        return _BUFFERS.pop(execution_id, [])


def buffer_size(execution_id: str) -> int:
    """Test/observability helper."""
    if not execution_id:
        return 0
    with _BUFFER_LOCK:
        return len(_BUFFERS.get(execution_id, []))


def peek(execution_id: str, limit: int = 500) -> List[Dict[str, Any]]:
    """Return a SNAPSHOT of the captured log records for this execution
    WITHOUT draining the buffer.  Lets the live admin UI / curl-based
    diagnostics watch logs while the query is still running.

    Returns the most-recent ``limit`` records.  Default 500 keeps the
    response under ~100 KB.
    """
    if not execution_id:
        return []
    with _BUFFER_LOCK:
        buf = _BUFFERS.get(execution_id, [])
        # Slice copies — caller-safe snapshot.
        return list(buf[-limit:]) if len(buf) > limit else list(buf)


def _passive_cleanup_old_buffers(max_age_seconds: int = 3600) -> int:
    """Drop buffers that haven't been touched in ``max_age_seconds``.
    Called periodically (best-effort) to prevent the registry from
    growing unboundedly if drain() is missed (crashed worker, etc.).
    """
    now = time.monotonic()
    dropped = 0
    with _BUFFER_LOCK:
        for eid in list(_BUFFERS.keys()):
            recs = _BUFFERS.get(eid, [])
            if not recs:
                continue
            last = recs[-1].get("_mt", now)
            if now - last > max_age_seconds:
                _BUFFERS.pop(eid, None)
                dropped += 1
    return dropped


# ── Logging handler ──────────────────────────────────────────────────────────

class ExecutionLogHandler(logging.Handler):
    """Captures log records into per-execution buffers.

    Filters by the ContextVar; if no execution_id is set in the current
    context, the record is ignored (this handler does NOT replace the
    server's normal stderr/file logging — those handlers run in parallel).

    Captured records carry: timestamp, level, logger name, message
    (truncated to MAX_MESSAGE_LEN), and the current stage if known.
    """

    def __init__(self, level: int = logging.INFO):
        super().__init__(level=level)

    def emit(self, record: logging.LogRecord) -> None:
        execution_id = _CURRENT_EXEC_ID.get(None)
        if not execution_id:
            return
        try:
            msg = record.getMessage()
        except Exception:
            try:
                msg = str(record.msg)
            except Exception:
                return
        if len(msg) > _MAX_MESSAGE_LEN:
            msg = msg[:_MAX_MESSAGE_LEN] + "…"

        # Try to attach the current stage label so the UI can group log
        # lines under their stage in the timeline.  Best-effort lookup.
        stage_label: Optional[str] = None
        try:
            from core import execution_stage as _stg
            snap = _stg.get_snapshot(execution_id)
            if snap:
                stage_label = snap.get("stage")
        except Exception:
            pass

        rec_dict: Dict[str, Any] = {
            "ts":     record.created,            # unix timestamp (float)
            "level":  record.levelname,
            "logger": record.name,
            "msg":    msg,
            "stage":  stage_label,
            # internal: monotonic time used by passive cleanup
            "_mt":    time.monotonic(),
        }

        with _BUFFER_LOCK:
            buf = _BUFFERS.get(execution_id)
            if buf is None:
                buf = []
                _BUFFERS[execution_id] = buf
            if len(buf) >= _MAX_RECORDS_PER_EXEC:
                # Bounded — drop the oldest record (FIFO) so the most recent
                # context (the part the user usually wants) survives.
                buf.pop(0)
            buf.append(rec_dict)


# ── Installation helper ──────────────────────────────────────────────────────

_INSTALL_LOCK = threading.Lock()


def is_installed() -> bool:
    """True iff an ExecutionLogHandler is attached to the root logger NOW
    -- read from the handler list, never from a flag.  2026-09-11: the
    same defect as ``core.brain.log_capture``: a module-global
    ``_INSTALLED`` short-circuited ``install()`` before the handler scan
    below ever ran, so once anything rewrote ``logging.root.handlers``
    the flag said "attached" and no later call could repair it."""
    return any(isinstance(h, ExecutionLogHandler)
               for h in logging.getLogger().handlers)


def install(level: int = logging.INFO) -> None:
    """Attach the ExecutionLogHandler to the root logger.  Idempotent;
    repeated calls are no-ops while the handler is attached, and
    re-attach it if it has been stripped.

    Call during app startup AFTER the standard logging is configured.
    The handler runs ALONGSIDE the existing stderr/file handlers — it does
    not replace them.
    """
    with _INSTALL_LOCK:
        if is_installed():
            return
        logging.getLogger().addHandler(ExecutionLogHandler(level=level))
