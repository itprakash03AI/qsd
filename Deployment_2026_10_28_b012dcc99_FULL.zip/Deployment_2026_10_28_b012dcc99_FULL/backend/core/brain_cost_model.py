"""Brain Cost Model — replaces threshold-based routing with predicted cost.

Strategic shape (per feedback_strategic_not_patch.md):

ONE class — ``CostModel`` — owns the entire prediction pipeline.
Reads ``query_pruning_history`` joined with ``query_executions`` to
learn per-table:

  * avg bytes per source file
  * p95 seconds per byte (engine-specific)
  * historical mirror_vs_source speedup factor
  * gateway hit ratio for repeat queries

For each routing decision the engine must make (source vs mirror vs
gateway), the cost model predicts wall-clock cost and the router
picks the minimum.  This replaces the current rule-based
``files_after_prune >= 100`` threshold with a quantitative answer:
"the mirror is faster IF predicted savings exceed gateway lookup
overhead + dual-run cost."

Fail-OPEN: when the model has insufficient data (fewer than
``min_observations_for_prediction`` rows per table) it returns
``None`` from ``route_decision`` and callers fall through to the
existing threshold logic.  This means the cost model is purely
additive — never breaks existing behaviour.

Caching: per-table stats refreshed every
``stats_cache_seconds`` (default 300s).  Single in-pod cache keyed
on (bucket, prefix) so dashboard polls don't hammer the DB.
"""
from __future__ import annotations

import logging
from core.table_prefix import prefix_matches
import threading
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ── Config ────────────────────────────────────────────────────────────


def _cfg(key: str, fallback: Any) -> Any:
    try:
        from core.config import get as _g
        return _g("brain_cost_model", key, fallback)
    except Exception:
        return fallback


def enabled() -> bool:
    """Master switch.  Default ON — fail-OPEN means having it on is
    safe (we fall through to legacy threshold logic when uncertain)."""
    return bool(_cfg("enabled", True))


def lookback_hours() -> int:
    return int(_cfg("lookback_hours", 168) or 168)


def stats_cache_seconds() -> int:
    return int(_cfg("stats_cache_seconds", 300) or 300)


def min_observations_for_prediction() -> int:
    return int(_cfg("min_observations_for_prediction", 10) or 10)


def mirror_routing_overhead_seconds() -> float:
    """Fixed cost added to mirror cost estimates — captures dual-run
    canary sampling overhead + the brief mirror_decision branch."""
    return float(_cfg("mirror_routing_overhead_seconds", 0.05) or 0.05)


def gateway_lookup_overhead_seconds() -> float:
    """Fixed cost for the meta.json HEAD that gateway routing fires
    before deciding hit/miss."""
    return float(_cfg("gateway_lookup_overhead_seconds", 0.10) or 0.10)


def assumed_mirror_speedup() -> float:
    """Phase 169 -- estimated source/mirror duration ratio used when a
    mirror is ``ready`` with route hits but QS has no per-route timing to
    compute the real ratio.  Default 2.0 (the historical hardcode, kept
    as the default so behaviour is unchanged) but now operator-tunable.
    Clamped to >= 1.0 (a mirror is never assumed slower than source)."""
    try:
        v = float(_cfg("assumed_mirror_speedup", 2.0) or 2.0)
    except (TypeError, ValueError):
        v = 2.0
    return max(1.0, v)


# ── Dataclasses ──────────────────────────────────────────────────────


@dataclass
class TableStats:
    """Per-table observations the cost model uses to predict.

    2026-06-10 audit fix — switched from a bytes×seconds-per-byte model
    to a simpler seconds-per-file model.  The earlier shape used
    ``QueryExecution.file_size_bytes`` as a bytes proxy, but that field
    is the OUTPUT parquet artifact (the file the user downloads), not
    the bytes scanned at the source.  Streaming queries set it to 0,
    skewing the model toward "everything is free."  ``avg_seconds_per_
    file`` is computed directly from observed wall-clock duration ÷
    files_after_prune — same direction as reality, no proxy needed.
    """
    bucket:                  str
    table_prefix:            str
    observations:            int
    avg_files_after:         float
    avg_scan_seconds:        float
    p95_seconds_per_file:    float       # the load-bearing coefficient
    mirror_observed_speedup: float       # 1.0 = no observed mirror queries
    last_refreshed:          str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat(),
    )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class CostEstimate:
    """Predicted cost for one routing path."""
    path:                str            # "source" | "mirror" | "gateway"
    predicted_seconds:   float
    predicted_bytes:     float
    rationale:           str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class RouteDecision:
    chosen:              str
    estimates:           List[CostEstimate]
    confidence:          float          # 0..1, based on observation count
    fallback_to_threshold: bool         # True when cost model declined

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["estimates"] = [e.to_dict() for e in self.estimates]
        return d


# ── The model ────────────────────────────────────────────────────────


class CostModel:
    """Singleton — instance owns the per-table stats cache."""

    _instance_lock = threading.Lock()
    _instance: Optional["CostModel"] = None

    def __init__(self, db_manager: Any) -> None:
        self._db = db_manager
        self._cache: Dict[Tuple[str, str], TableStats] = {}
        self._cache_at: Dict[Tuple[str, str], float] = {}
        # Negative cache: (bucket, prefix) pairs that have NO observations
        # yet, with the monotonic time we last checked.  Without this a
        # cold/never-observed table re-runs the pruning⋈executions join on
        # EVERY brain-routed query (the sensor runs per query) -- a real
        # hot-path DB hit.  Same TTL as the positive cache.
        self._negative_at: Dict[Tuple[str, str], float] = {}
        self._cache_lock = threading.Lock()

    @classmethod
    def get_default(cls, db_manager: Any) -> "CostModel":
        with cls._instance_lock:
            if cls._instance is None:
                cls._instance = cls(db_manager)
            return cls._instance

    # ── Public capability ───────────────────────────────────────────

    def route_decision(
        self,
        bucket: str, prefix: str,
        files_after_prune: int,
        *,
        mirror_file_count: Optional[int] = None,
        gateway_eligible: bool = True,
    ) -> Optional[RouteDecision]:
        """Decide source vs mirror vs gateway for a single query.

        Returns ``None`` when the model has insufficient data — caller
        falls through to the legacy threshold-based logic.  This is the
        critical fail-OPEN edge: the cost model never breaks existing
        routing, it only ADDS smarter decisions where it has enough
        observations.
        """
        if not enabled():
            return None
        norm_prefix = (prefix or "").rstrip("/")
        stats = self._table_stats(bucket, norm_prefix)
        if stats is None:
            return None
        if stats.observations < min_observations_for_prediction():
            return None

        # Predict source cost — uses observed seconds-per-file directly.
        source_secs = files_after_prune * stats.p95_seconds_per_file
        source_est = CostEstimate(
            path="source", predicted_seconds=round(source_secs, 3),
            predicted_bytes=0,
            rationale=(
                f"{files_after_prune} files × "
                f"{stats.p95_seconds_per_file:.4f} p95 s/file "
                f"(observed over {stats.observations} queries)"
            ),
        )
        estimates: List[CostEstimate] = [source_est]

        # Mirror estimate — fewer files at the same per-file cost.
        if mirror_file_count is not None and mirror_file_count > 0:
            if stats.mirror_observed_speedup > 1.0:
                mirror_secs = source_secs / stats.mirror_observed_speedup
            else:
                mirror_secs = mirror_file_count * stats.p95_seconds_per_file
            mirror_secs += mirror_routing_overhead_seconds()
            estimates.append(CostEstimate(
                path="mirror",
                predicted_seconds=round(mirror_secs, 3),
                predicted_bytes=0,
                rationale=(
                    f"{mirror_file_count} mirror files × "
                    f"{stats.p95_seconds_per_file:.4f} s/file "
                    f"+ {mirror_routing_overhead_seconds():.2f}s overhead"
                ),
            ))

        # Gateway estimate — fixed lookup + (1 - hit_ratio) × source cost.
        if gateway_eligible and stats.observations > 0:
            assumed_hit_ratio = 0.5 if files_after_prune >= 1000 else 0.2
            gateway_secs = (
                gateway_lookup_overhead_seconds()
                + (1.0 - assumed_hit_ratio) * source_secs
            )
            estimates.append(CostEstimate(
                path="gateway",
                predicted_seconds=round(gateway_secs, 3),
                predicted_bytes=0,
                rationale=(
                    f"assumed hit ratio {assumed_hit_ratio:.0%} × "
                    f"source + {gateway_lookup_overhead_seconds():.2f}s lookup"
                ),
            ))

        # Pick the minimum-cost path.
        chosen = min(estimates, key=lambda e: e.predicted_seconds)
        confidence = min(1.0, stats.observations
                         / max(1, min_observations_for_prediction() * 5))
        return RouteDecision(
            chosen                 = chosen.path,
            estimates              = estimates,
            confidence             = round(confidence, 2),
            fallback_to_threshold  = False,
        )

    # ── Internal — stats refresh ────────────────────────────────────

    def _table_stats(
        self, bucket: str, prefix: str,
    ) -> Optional[TableStats]:
        key = (bucket, prefix)
        now = time.monotonic()
        ttl = stats_cache_seconds()
        with self._cache_lock:
            cached = self._cache.get(key)
            cached_at = self._cache_at.get(key, 0.0)
            if cached is not None and (now - cached_at) < ttl:
                return cached
            # Negative cache: a recent "no observations" result short-
            # circuits the DB join so cold tables don't re-query per call.
            neg_at = self._negative_at.get(key, 0.0)
            if neg_at and (now - neg_at) < ttl:
                return None
        # Refresh outside the lock so a slow DB query doesn't block
        # other lookups.
        stats = self._compute_stats(bucket, prefix)
        with self._cache_lock:
            if stats is None:
                self._negative_at[key] = now
            else:
                self._cache[key]    = stats
                self._cache_at[key] = now
                self._negative_at.pop(key, None)
        return stats

    def _compute_stats(
        self, bucket: str, prefix: str,
    ) -> Optional[TableStats]:
        """Join query_pruning_history with the execution record to learn
        per-table cost coefficients.

        TWO execution tables, because there are two roads: /api/execute
        writes ``query_executions``, the BQB report route writes
        ``federation_executions``.  Reading only the first made every
        report-produced observation invisible (2026-09-06, measured).

        All best-effort: any DB error returns None and the caller falls
        through to threshold logic.
        """
        try:
            from core.db.models import (
                QueryPruningHistory, QueryExecution, FederationExecution,
            )
            since = datetime.now(timezone.utc) - timedelta(
                hours=lookback_hours(),
            )
            # 2026-06-10 audit — switched to (files_after, duration)
            # tuples.  file_size_bytes was the OUTPUT artifact size, not
            # bytes scanned, so the previous model was systematically
            # wrong on streaming queries (output=0) + columnar queries
            # (scan ≫ output).  Seconds-per-file is the direct signal.
            observations: List[Tuple[int, float]] = []
            with self._db.get_session(read_only=True) as session:
                rows = (
                    session.query(
                        QueryPruningHistory.execution_id,
                        QueryPruningHistory.files_after_prune,
                        QueryExecution.started_at,
                        QueryExecution.completed_at,
                    )
                    .join(
                        QueryExecution,
                        QueryExecution.execution_id ==
                        QueryPruningHistory.execution_id,
                    )
                    .filter(
                        QueryPruningHistory.bucket == bucket,
                        prefix_matches(QueryPruningHistory.table_prefix, prefix),
                        QueryPruningHistory.created_at >= since,
                        QueryPruningHistory.files_after_prune > 0,
                        QueryExecution.completed_at != None,  # noqa: E711
                    )
                    .limit(2000)
                    .all()
                )
            # 2026-09-06 -- THE OTHER HALF OF THE WORKLOAD.
            #
            # ``query_executions`` is written by the /api/execute road
            # (SQL editor, saved queries).  The BQB REPORT road -- the
            # one most S3 traffic actually takes -- writes
            # ``federation_executions`` instead, with the wall clock
            # already reduced to ``duration_seconds``.  Measured on the
            # wire rig on 2026-09-06: 2 pruning rows from two real
            # iceberg reports, 0 of them joinable to query_executions,
            # both joinable to federation_executions.  So the moment the
            # pruning write site was made reachable, every observation a
            # report produced was still invisible here and the model
            # would have sat below its threshold forever while the table
            # grew -- "the table has rows" is not "the brain has input".
            #
            # Same semantic on both sides (query wall clock), so the two
            # sets are simply concatenated; execution ids are unique per
            # road, and the dedup below is belt-and-braces.
            with self._db.get_session(read_only=True) as session:
                fed_rows = (
                    session.query(
                        QueryPruningHistory.execution_id,
                        QueryPruningHistory.files_after_prune,
                        FederationExecution.duration_seconds,
                    )
                    .join(
                        FederationExecution,
                        FederationExecution.execution_id ==
                        QueryPruningHistory.execution_id,
                    )
                    .filter(
                        QueryPruningHistory.bucket == bucket,
                        prefix_matches(QueryPruningHistory.table_prefix, prefix),
                        QueryPruningHistory.created_at >= since,
                        QueryPruningHistory.files_after_prune > 0,
                        FederationExecution.status == "completed",
                        FederationExecution.duration_seconds > 0,
                    )
                    .limit(2000)
                    .all()
                )
            seen_exec: set = set()
            for (exec_id, files_after, dur) in fed_rows:
                if not files_after or files_after <= 0:
                    continue
                try:
                    dur = float(dur or 0.0)
                except (TypeError, ValueError):
                    continue
                if dur <= 0:
                    continue
                seen_exec.add(exec_id)
                observations.append((int(files_after), dur))
            for (exec_id, files_after, started_at,
                  completed_at) in rows:
                if exec_id in seen_exec:
                    continue
                if not files_after or files_after <= 0:
                    continue
                if started_at is None or completed_at is None:
                    continue
                sa = started_at
                ca = completed_at
                if sa.tzinfo is None:
                    sa = sa.replace(tzinfo=timezone.utc)
                if ca.tzinfo is None:
                    ca = ca.replace(tzinfo=timezone.utc)
                dur = (ca - sa).total_seconds()
                if dur <= 0:
                    continue
                observations.append((int(files_after), float(dur)))
            if not observations:
                return None

            total_obs = len(observations)
            avg_files_after  = sum(o[0] for o in observations) / total_obs
            avg_scan_seconds = sum(o[1] for o in observations) / total_obs
            # p95 seconds-per-file — sort (dur / files_after) ascending
            # and pick the 95th percentile.  This stays conservative on
            # slow tails so the router doesn't over-promise mirror wins.
            sec_per_file = sorted(
                o[1] / max(1, o[0]) for o in observations
            )
            if len(sec_per_file) >= 20:
                idx = int(0.95 * (len(sec_per_file) - 1))
                p95_sec_per_file = sec_per_file[idx]
            else:
                # < 20 observations: use the max — small sample +
                # conservative estimate avoids over-routing to mirror.
                p95_sec_per_file = max(sec_per_file) if sec_per_file else 0.0

            mirror_speedup = self._observed_mirror_speedup(
                bucket, prefix, since,
            )

            return TableStats(
                bucket                  = bucket,
                table_prefix            = prefix,
                observations            = total_obs,
                avg_files_after         = round(avg_files_after, 1),
                avg_scan_seconds        = round(avg_scan_seconds, 3),
                p95_seconds_per_file    = round(p95_sec_per_file, 6),
                mirror_observed_speedup = round(mirror_speedup, 2),
            )
        except Exception as exc:
            logger.debug("CostModel._compute_stats failed: %s", exc)
            return None

    def _observed_mirror_speedup(
        self, bucket: str, prefix: str, since: datetime,
    ) -> float:
        """Return ratio of source-path duration / mirror-path duration
        for queries against this table.  When no mirror data is
        observed, returns 1.0 (no observed speedup → conservative)."""
        try:
            from core.db.models import IcebergMirror
            with self._db.get_session(read_only=True) as session:
                # Cheap heuristic: if any mirror exists for this table
                # with route_hit_count > 0, assume the configured Stage
                # 1 mirror is observed faster.  Without per-route timing
                # we can't compute a precise ratio; estimate conservatively
                # as 2x (the partition_by_threshold rewrite typically
                # collapses 2000+ source files into 50-200 hive parts).
                row = (
                    session.query(IcebergMirror.route_hit_count)
                    .filter(
                        IcebergMirror.source_bucket == bucket,
                        IcebergMirror.source_prefix == prefix,
                        IcebergMirror.status == "ready",
                        IcebergMirror.route_hit_count > 0,
                    )
                    .first()
                )
                if row and row[0] > 0:
                    # Phase 169 -- this is an ESTIMATE, not an observed
                    # ratio: QS doesn't yet record per-route source-vs-
                    # mirror durations, so we can't compute the true
                    # speedup.  Kept configurable (default 2.0, the
                    # historical value) instead of a silently-hardcoded
                    # constant, so an operator can dial it to their
                    # observed reality until real per-route timing lands.
                    return assumed_mirror_speedup()
                return 1.0
        except Exception:
            return 1.0

    def state_snapshot(self) -> Dict[str, Any]:
        """For admin UI — list cached per-table stats."""
        with self._cache_lock:
            return {
                "tables": [s.to_dict() for s in self._cache.values()],
                "count":  len(self._cache),
                "cache_ttl_seconds": stats_cache_seconds(),
                "min_observations": min_observations_for_prediction(),
            }


__all__ = [
    "CostModel", "TableStats", "CostEstimate", "RouteDecision",
    "enabled", "lookback_hours", "stats_cache_seconds",
    "min_observations_for_prediction",
    "mirror_routing_overhead_seconds",
    "gateway_lookup_overhead_seconds",
]
