"""Phase 149.10 — BrainFreshness: snapshot-aware brain refresh dispatcher.

The pruning brain (149.4 bloom sidecar + BF-COL-STATS supplement) is
keyed per-file.  Iceberg data files are immutable + content-addressable
so any bloom / supplement row we've written stays valid forever.

The freshness problem: when a writer commits a NEW iceberg snapshot,
NEW data files appear with NEW paths.  Those files have ZERO bloom +
supplement coverage until something scans them.  Until then, queries
on the new snapshot get full pruning on OLD files but NO pruning on
NEW files (correct rows, just slower than ideal).

This module unifies three refresh triggers behind ONE entry point:

  1. PROACTIVE — cron daemon ticks every 1h (configurable),
     iterates watched / recently-queried tables, calls ensure_fresh
     on each.  Reliable backstop.

  2. REACTIVE — iceberg metadata-sync watcher detects a snapshot roll-
     forward; fires a fire-and-forget ensure_fresh.  Best-effort —
     watcher reliability is per-pod, not coordinated across pods,
     known multi-pod redundancy (audited 2026-06-09).

  3. LAZY — iceberg_reader.get_iceberg_data_files notices a file
     without bloom coverage and the table's snapshot has rolled since
     the last scan; queues an async ensure_fresh.  Self-heal pattern
     (same shape as BF-547 column-stats auto-heal).

ensure_fresh policy:
  * Resolve current snapshot for (bucket, prefix)
  * Resolve last_scanned_snapshot from the sidecar rows
  * SAME → no-op (cheap, idempotent — saves S3 round-trips)
  * DIFFERENT → enqueue delta scan via the existing
    scan_files_to_supplement / scan_files_for_bloom paths.
    skip_already_scanned=True dedupes per-file so only NEW files are
    scanned.
  * Throttled via _IN_FLIGHT set so the same (bucket, prefix, col)
    isn't dispatched twice concurrently across the three triggers.
  * Async — never blocks the watcher / query / cron tick.

Records a per-(bucket, prefix) freshness ledger so the admin UI can
show "covers snapshot X, current is Y, lag 2h".
"""
from __future__ import annotations

import logging
from core.table_prefix import prefix_matches
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Set, Tuple

logger = logging.getLogger(__name__)


# ── Freshness ledger ────────────────────────────────────────────────────


@dataclass
class FreshnessEntry:
    """Per-(bucket, prefix) snapshot lag record.  Surfaced to UI."""
    bucket:                  str
    table_prefix:            str
    current_snapshot:        Optional[str] = None
    last_scanned_snapshot:   Optional[str] = None
    last_scan_at:            Optional[datetime] = None
    cols_covered:            List[str] = field(default_factory=list)
    last_check_at:           datetime = field(
        default_factory=lambda: datetime.now(timezone.utc))
    last_check_source:       str = ""        # cron | watcher | lazy | manual
    last_action:             str = ""        # noop | dispatched | error
    last_error:              str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "bucket":                self.bucket,
            "table_prefix":          self.table_prefix,
            "current_snapshot":      self.current_snapshot,
            "last_scanned_snapshot": self.last_scanned_snapshot,
            "last_scan_at": (
                self.last_scan_at.isoformat() if self.last_scan_at else None
            ),
            "snapshot_in_sync": bool(
                self.current_snapshot
                and self.last_scanned_snapshot
                and self.current_snapshot == self.last_scanned_snapshot
            ),
            "cols_covered":          list(self.cols_covered),
            "last_check_at":         self.last_check_at.isoformat(),
            "last_check_source":     self.last_check_source,
            "last_action":           self.last_action,
            "last_error":            self.last_error,
        }


# ── Recent event log (ring buffer) ──────────────────────────────────────


_EVENT_LOG_LOCK = threading.Lock()
_EVENT_LOG: deque = deque(maxlen=200)


def _log_event(record: Dict[str, Any]) -> None:
    """Stash one ensure_fresh decision in the event ring.  Surfaced to
    the admin UI so operators can see WHICH trigger fired, what it did,
    and whether it deduplicated against a prior in-flight scan."""
    record.setdefault("at", datetime.now(timezone.utc).isoformat())
    with _EVENT_LOG_LOCK:
        _EVENT_LOG.appendleft(record)


def get_recent_events(limit: int = 50) -> List[Dict[str, Any]]:
    """Snapshot the latest N events (newest first) for the UI panel."""
    with _EVENT_LOG_LOCK:
        return list(_EVENT_LOG)[:max(0, limit)]


# ── In-flight throttle ──────────────────────────────────────────────────
#
# Prevents thundering herd when three triggers race (cron + watcher +
# lazy all fire for the same (bucket, prefix) within milliseconds).
# Keyed on (bucket, prefix); a refresh in flight for one col covers
# the whole table's freshness decision anyway.

_IN_FLIGHT_LOCK = threading.Lock()
_IN_FLIGHT: Set[Tuple[str, str]] = set()


def _try_acquire(bucket: str, prefix: str) -> bool:
    key = (bucket, str(prefix).rstrip("/"))
    with _IN_FLIGHT_LOCK:
        if key in _IN_FLIGHT:
            return False
        _IN_FLIGHT.add(key)
        return True


def _release(bucket: str, prefix: str) -> None:
    key = (bucket, str(prefix).rstrip("/"))
    with _IN_FLIGHT_LOCK:
        _IN_FLIGHT.discard(key)


# ── Per-table freshness ledger ──────────────────────────────────────────


_LEDGER_LOCK = threading.Lock()
_LEDGER: Dict[Tuple[str, str], FreshnessEntry] = {}


def _key(bucket: str, prefix: str) -> Tuple[str, str]:
    return (bucket or "", str(prefix or "").rstrip("/"))


def get_ledger_entry(bucket: str, prefix: str) -> Optional[FreshnessEntry]:
    with _LEDGER_LOCK:
        return _LEDGER.get(_key(bucket, prefix))


def list_ledger(limit: int = 100) -> List[Dict[str, Any]]:
    """Snapshot every (bucket, prefix) we've ever called ensure_fresh
    on, with the latest freshness facts.  UI iterates this for the
    freshness chips."""
    with _LEDGER_LOCK:
        items = list(_LEDGER.values())
    items.sort(key=lambda e: e.last_check_at, reverse=True)
    return [e.to_dict() for e in items[:max(0, limit)]]


def _record_ledger(
    bucket: str,
    prefix: str,
    *,
    current_snapshot: Optional[str] = None,
    last_scanned_snapshot: Optional[str] = None,
    last_scan_at: Optional[datetime] = None,
    cols_covered: Optional[List[str]] = None,
    source: str = "",
    action: str = "",
    error: str = "",
) -> None:
    k = _key(bucket, prefix)
    with _LEDGER_LOCK:
        e = _LEDGER.get(k)
        if e is None:
            e = FreshnessEntry(bucket=k[0], table_prefix=k[1])
            _LEDGER[k] = e
        if current_snapshot is not None:
            e.current_snapshot = current_snapshot
        if last_scanned_snapshot is not None:
            e.last_scanned_snapshot = last_scanned_snapshot
        if last_scan_at is not None:
            e.last_scan_at = last_scan_at
        if cols_covered is not None:
            e.cols_covered = list(cols_covered)
        e.last_check_at = datetime.now(timezone.utc)
        e.last_check_source = source or e.last_check_source
        e.last_action = action or e.last_action
        e.last_error = error


# ── snapshot-id resolution helpers ──────────────────────────────────────


def _resolve_current_snapshot(
    db_manager: Any,
    s3_client: Any,
    bucket: str,
    prefix: str,
) -> Optional[str]:
    """Fast read of the current snapshot_id from iceberg metadata.json.
    Uses the dedicated helper (~1-5 KB, 2 S3 calls)."""
    try:
        from core.iceberg_reader import get_iceberg_snapshot_id_only
        sid = get_iceberg_snapshot_id_only(s3_client, bucket, prefix)
        return str(sid) if sid is not None else None
    except Exception as exc:
        logger.debug(
            "brain_freshness: snapshot resolve failed for %s/%s: %s",
            bucket, prefix, exc,
        )
        return None


def _resolve_last_scanned_snapshot(
    db_manager: Any,
    bucket: str,
    prefix: str,
) -> Tuple[Optional[str], List[str], Optional[datetime]]:
    """Return ``(snapshot_id, cols_covered, scanned_at)`` for the most
    recent (bucket, prefix) row across the supplement + bloom sidecars.
    Both tables carry snapshot_id at row-write time, so the freshest
    row wins.

    None when no rows exist yet (first scan).
    """
    if db_manager is None:
        return None, [], None
    try:
        from core.db.models import (
            IcebergColumnStatsSupplement, IcebergBloomSidecar,
            IcebergFileStats,
        )
        snap: Optional[str] = None
        cols: Set[str] = set()
        scanned_at: Optional[datetime] = None
        with db_manager.get_session(read_only=True) as session:
            # Find the most recently scanned row across ALL THREE tables for
            # this (bucket, prefix): v2 supplement, bloom sidecar, AND the
            # per-file v3 table (2026-07-13 — was v2-blind, so v3-only tables
            # resolved last=None/cols=[] → ensure_fresh no-op'd → v3 went
            # STALE on snapshot advance).  The newest scanned_at wins.
            sup_row = (
                session.query(IcebergColumnStatsSupplement)
                .filter(
                    IcebergColumnStatsSupplement.bucket == bucket,
                    prefix_matches(IcebergColumnStatsSupplement.table_prefix, prefix),
                )
                .order_by(IcebergColumnStatsSupplement.scanned_at.desc())
                .first()
            )
            blm_row = (
                session.query(IcebergBloomSidecar)
                .filter(
                    IcebergBloomSidecar.bucket == bucket,
                    prefix_matches(IcebergBloomSidecar.table_prefix, prefix),
                )
                .order_by(IcebergBloomSidecar.scanned_at.desc())
                .first()
            )
            fs_row = (
                session.query(IcebergFileStats)
                .filter(
                    IcebergFileStats.bucket == bucket,
                    prefix_matches(IcebergFileStats.table_prefix, prefix),
                )
                .order_by(IcebergFileStats.scanned_at.desc())
                .first()
            )
            # Pick the newest scanned_at across the three as the watermark.
            winner = None
            for cand in (sup_row, blm_row, fs_row):
                if cand is None:
                    continue
                if winner is None or (cand.scanned_at or datetime.min) > (
                        winner.scanned_at or datetime.min):
                    winner = cand
            if winner is not None:
                snap = (winner.snapshot_id or None) or None
                scanned_at = winner.scanned_at
            # Aggregate distinct cols covered for this (bucket, prefix)
            for c in (session.query(IcebergColumnStatsSupplement.column_name)
                       .filter(
                           IcebergColumnStatsSupplement.bucket == bucket,
                           prefix_matches(IcebergColumnStatsSupplement.table_prefix, prefix),
                       ).distinct().all()):
                if c[0]:
                    cols.add(f"sup:{c[0].lower()}")
            for c in (session.query(IcebergBloomSidecar.column_name)
                       .filter(
                           IcebergBloomSidecar.bucket == bucket,
                           prefix_matches(IcebergBloomSidecar.table_prefix, prefix),
                       ).distinct().all()):
                if c[0]:
                    cols.add(f"bloom:{c[0].lower()}")
            # v3 packs all columns per file in one JSON row — take the newest
            # row's keys as the covered set (files in a snapshot share schema).
            if fs_row is not None and isinstance(fs_row.column_stats, dict):
                for k in fs_row.column_stats:
                    if k:
                        cols.add(f"sup:{str(k).lower()}")
        return snap, sorted(cols), scanned_at
    except Exception as exc:
        logger.debug(
            "brain_freshness: last-scanned resolve failed for %s/%s: %s",
            bucket, prefix, exc,
        )
        return None, [], None


def _partial_columns_db_first(db_manager: Any, bucket: str, prefix: str,
                              snapshot_id: str, cols: Any) -> Optional[Dict[str, str]]:
    """``{col_spec: reason}`` for the columns (``sup:x`` / ``bloom:x`` /
    bare ``x`` = both kinds) whose coverage of the CURRENT snapshot's files
    is KNOWN and incomplete; ``{}`` when every one is proven covered;
    ``None`` when the file list cannot be proven db-first (NO S3 here) --
    unknown is reported, never read as covered."""
    from core.bloom_coverage import (column_coverage,
                                     current_snapshot_file_keys_db_first)
    keys, _sid, _why = current_snapshot_file_keys_db_first(
        db_manager, bucket, prefix, snapshot_id=snapshot_id)
    if not keys:
        logger.debug("brain_freshness: no db-first file list for %s/%s (%s)",
                     bucket, prefix, _why)
        return None
    partial: Dict[str, str] = {}
    unknown = False
    for spec in (cols or []):
        spec = str(spec or "")
        if not spec:
            continue
        if ":" in spec:
            kinds = [("supplement" if spec.split(":", 1)[0] == "sup" else "bloom")]
            col = spec.split(":", 1)[1]
        else:
            kinds, col = ["supplement", "bloom"], spec
        for kind in kinds:
            cov = column_coverage(db_manager, bucket=bucket, table_prefix=prefix,
                                  column=col, kind=kind, file_keys=keys,
                                  snapshot_id=snapshot_id)
            if not cov.known:
                unknown = True
            elif not cov.covered:
                partial[spec] = cov.reason
    if unknown and not partial:
        return None
    return partial


# ── ensure_fresh — the unified entry point ──────────────────────────────


def ensure_fresh(
    db_manager: Any,
    s3_client_factory: Any,
    bucket: str,
    table_prefix: str,
    *,
    source: str = "manual",       # cron | watcher | lazy | manual
    columns: Optional[List[str]] = None,
    blocking: bool = False,
) -> Dict[str, Any]:
    """Single entry point — make sure brain coverage for (bucket, prefix)
    is up to date with the current iceberg snapshot.

    Returns ``{action, current_snapshot, last_scanned_snapshot, error}``
    where ``action`` ∈ {noop, dispatched, in_flight, error}.

    Best-effort.  Errors logged + stored in ledger but never raised —
    callers (watcher, cron, lazy) are not expected to handle exceptions.
    """
    out: Dict[str, Any] = {
        "action":                None,
        "current_snapshot":      None,
        "last_scanned_snapshot": None,
        "error":                 None,
        "bucket":                bucket,
        "table_prefix":          table_prefix,
        "source":                source,
    }
    prefix = (table_prefix or "").rstrip("/")
    if not (bucket and prefix):
        out["action"] = "error"
        out["error"]  = "bucket and table_prefix required"
        _log_event({**out, "reason": "missing identity"})
        return out

    # Throttle: a refresh in flight for this (bucket, prefix) means
    # whoever is in flight will pick up these new files too.
    if not _try_acquire(bucket, prefix):
        out["action"] = "in_flight"
        _log_event({**out, "reason": "throttled by in-flight scan"})
        return out

    try:
        # Resolve s3 client for this bucket
        s3 = s3_client_factory(bucket) if s3_client_factory else None
        if s3 is None:
            out["action"] = "error"
            out["error"]  = (
                f"no s3 client for bucket={bucket!r} — "
                f"freshness check skipped"
            )
            _record_ledger(bucket, prefix,
                           source=source, action="error",
                           error=out["error"])
            _log_event({**out, "reason": "no s3 client"})
            return out

        current = _resolve_current_snapshot(db_manager, s3, bucket, prefix)
        last, cols, last_scan_at = _resolve_last_scanned_snapshot(
            db_manager, bucket, prefix,
        )
        out["current_snapshot"]      = current
        out["last_scanned_snapshot"] = last

        # Same snapshot -> a cheap no-op ONLY when the columns that have
        # rows cover every file of it.  2026-10-08: ``last`` is the newest
        # row of ANY column (a per-TABLE watermark), so "snapshot unchanged"
        # said nothing about THIS column's files -- a column covered for
        # 672 of 2,688 files no-op'd here forever.  The per-file decision
        # (core/bloom_coverage.py) runs db-first, NO S3; what it cannot
        # prove stays a no-op that SAYS it could not prove it.
        if current and last and current == last:
            partial = _partial_columns_db_first(db_manager, bucket, prefix,
                                                current, columns or cols)
            if partial:
                scan_cols = sorted(partial)
                scan = None
                if blocking:
                    scan = _do_delta_scan(db_manager, s3, bucket, prefix, scan_cols, source)
                else:
                    threading.Thread(
                        target=_do_delta_scan,
                        args=(db_manager, s3, bucket, prefix, scan_cols, source),
                        name=f"brain-freshness-{bucket}/{prefix}", daemon=True,
                    ).start()
                out["action"] = "dispatched"
                _record_ledger(bucket, prefix, current_snapshot=current,
                               last_scanned_snapshot=last, last_scan_at=last_scan_at,
                               cols_covered=cols, source=source, action="dispatched")
                _log_event({**out, "reason": (
                    f"snapshot unchanged but {len(partial)} column(s) cover only "
                    f"part of its files: " + ", ".join(
                        f"{c} {partial[c]}" for c in scan_cols))})
                _apply_scan_result(out, scan, bucket, prefix, source)
                return out
            out["action"] = "noop"
            _record_ledger(
                bucket, prefix,
                current_snapshot=current,
                last_scanned_snapshot=last,
                last_scan_at=last_scan_at,
                cols_covered=cols,
                source=source, action="noop",
            )
            _log_event({**out, "reason": "snapshot unchanged" + (
                "; file-level coverage proven complete db-first"
                if partial is not None else
                "; file-level coverage not provable db-first (no proven rows "
                "store for this snapshot) -- the adaptive prefetch decides "
                "per file through the reader")})
            return out

        # Snapshot rolled forward — Phase 150: mark any mirror for this
        # (bucket, prefix) whose snapshot != current as stale.  Idempotent
        # (no-op when already stale) so duplicate calls from watcher +
        # lazy paths don't cause harm.  Best-effort: never blocks the
        # freshness dispatch.
        if current and current != last:
            try:
                from core.iceberg_mirror import (
                    on_snapshot_rollforward as _mirror_roll,
                )
                _mirror_roll(
                    db_manager, bucket, prefix,
                    current_snapshot_id=current,
                    previous_snapshot_id=last,
                )
            except Exception as _mr_exc:
                logger.debug(
                    "iceberg_mirror snapshot-rollforward dispatch failed: %s",
                    _mr_exc,
                )
            # Phase 155 (2026-06-25) -- brain sql-hash cache pinned to
            # the OLD snapshot is now stale.  Drop matching entries so
            # the next query against the new snapshot doesn't serve a
            # cached result that was computed against pre-roll data.
            # Best-effort; never blocks the freshness dispatch.
            try:
                if last:
                    from core.agg_cache import (
                        invalidate_brain_cache_for_snapshot,
                    )
                    _evicted = invalidate_brain_cache_for_snapshot(last)
                    if _evicted:
                        logger.info(
                            "[brain-freshness] snapshot roll %s -> %s "
                            "evicted %d brain-cache entries pinned to "
                            "old snapshot", last, current, _evicted,
                        )
            except Exception as _bc_exc:
                logger.debug(
                    "brain_cache invalidate on snapshot roll failed: %s",
                    _bc_exc,
                )
            # Phase 156.2 mirror -- invalidate the pruning memo too.
            # Same reason: a memo's surviving-file list was computed
            # against the OLD snapshot.  If the new snapshot dropped
            # files (e.g. a compaction commit), the memo points at
            # files that no longer exist.
            try:
                if last:
                    from core.brain_pruning_memo import (
                        invalidate_for_snapshot as _memo_invalidate,
                    )
                    _evicted_memo = _memo_invalidate(last)
                    if _evicted_memo:
                        logger.info(
                            "[brain-freshness] snapshot roll %s -> %s "
                            "evicted %d brain-memo entries pinned to "
                            "old snapshot", last, current, _evicted_memo,
                        )
            except Exception as _bm_exc:
                logger.debug(
                    "brain_memo invalidate on snapshot roll failed: %s",
                    _bm_exc,
                )
            # 2026-06-18 -- STRATEGIC CORRECTION.
            # The old call to gc_stale_snapshots() deleted every bloom
            # row whose snapshot_id didn't match the current snapshot.
            # That was wrong: iceberg files are content-addressable +
            # immutable, so a bloom row keyed by file_path is valid
            # FOREVER regardless of which snapshot first observed it.
            # Snapshot rolls in append-only iceberg tables (the common
            # QS shape) don't invalidate ANY of the prior rows -- the
            # new files just need fresh coverage, the old files keep
            # what they have.
            #
            # gc_stale_snapshots() is now a NOOP for back-compat.  The
            # correct eviction (file-keyed, not snapshot-keyed) is
            # iceberg_bloom_sidecar.evict_orphaned_files(file_set),
            # called from the full-manifest-scan path where the
            # authoritative current file_set is known.  See the
            # docstring on evict_orphaned_files for the contract.
            #
            # Net effect: snapshot rolls no longer throw away bloom
            # coverage for unchanged files -- the pruning brain
            # actually gets to USE what it learned.

        # Snapshot rolled forward (or no prior scan).  Dispatch the
        # delta scan via the existing prefetcher path so we reuse all
        # the cap / dedup / progress wiring.  Only scan cols that
        # ALREADY have some coverage (so we don't accidentally trigger
        # scans for cols nobody filters on); on first-ever scan we
        # defer to the cron daemon's history-driven planning instead.
        if not cols and not columns:
            out["action"] = "noop"
            _record_ledger(
                bucket, prefix,
                current_snapshot=current,
                last_scanned_snapshot=last,
                cols_covered=[],
                source=source, action="noop",
            )
            _log_event({**out,
                        "reason": "no prior coverage; defer to cron daemon "
                                  "(history-driven planning)"})
            return out

        # Build the col list: explicit cols arg wins; else extract from
        # the existing coverage set (strip "sup:" / "bloom:" prefixes).
        scan_cols: Set[str] = set()
        if columns:
            scan_cols.update(c.lower() for c in columns)
        else:
            for c in cols:
                if ":" in c:
                    scan_cols.add(c.split(":", 1)[1])
                else:
                    scan_cols.add(c)
        scan_cols.discard("")
        if not scan_cols:
            out["action"] = "noop"
            _log_event({**out, "reason": "no scan cols resolved"})
            return out

        # Fire async — the watcher / query / cron callers must not block.
        # blocking=True is for tests + manual admin "run now" button.
        scan = None
        if blocking:
            scan = _do_delta_scan(
                db_manager, s3, bucket, prefix, list(scan_cols), source,
            )
        else:
            t = threading.Thread(
                target=_do_delta_scan,
                args=(db_manager, s3, bucket, prefix,
                      list(scan_cols), source),
                name=f"brain-freshness-{bucket}/{prefix}",
                daemon=True,
            )
            t.start()

        out["action"] = "dispatched"
        _record_ledger(
            bucket, prefix,
            current_snapshot=current,
            last_scanned_snapshot=last,
            last_scan_at=last_scan_at,
            cols_covered=cols,
            source=source, action="dispatched",
        )
        _log_event({**out,
                    "reason": f"snapshot drift {last!r}→{current!r}; "
                              f"dispatched delta scan for cols={sorted(scan_cols)}"})
        _apply_scan_result(out, scan, bucket, prefix, source)
        return out
    except Exception as exc:
        out["action"] = "error"
        out["error"]  = f"{type(exc).__name__}: {exc}"[:300]
        _record_ledger(bucket, prefix,
                       source=source, action="error", error=out["error"])
        _log_event({**out, "reason": "unhandled exception"})
        return out
    finally:
        # On the async-dispatch path we release as soon as the thread
        # has STARTED — the in-flight throttle covers the dispatch
        # window, not the scan duration (per-target throttle inside
        # the scanner handles concurrency within a scan).  On the
        # blocking path we hold until the scan finishes.
        if blocking:
            _release(bucket, prefix)
        else:
            # release after a short delay so a burst of triggers within
            # ~100ms still dedupe to one scan
            def _delayed_release():
                time.sleep(0.1)
                _release(bucket, prefix)
            threading.Thread(
                target=_delayed_release,
                name=f"brain-freshness-release-{bucket}/{prefix}",
                daemon=True,
            ).start()


def _apply_scan_result(out: Dict[str, Any], scan: Any, bucket: str,
                       prefix: str, source: str) -> None:
    """2026-10-08 -- a BLOCKING ``ensure_fresh`` carries the scan's result:
    ``out["scan"]`` is what the scanners reported, and a scan that built
    nothing while files failed turns the action into ``error`` with the
    scanner's sentence (the ledger's ``dispatched`` written just before is
    corrected to ``error`` so the admin surface agrees with the caller).
    ``scan`` is None on the async path (and from a stubbed scanner)."""
    if not isinstance(scan, dict):
        return
    out["scan"] = scan
    if scan.get("status") == "error":
        out["action"] = "error"
        out["error"] = str(scan.get("error") or "scan failed")[:300]
        _record_ledger(bucket, prefix, source=source, action="error",
                       error=out["error"])
        return
    # The ``dispatched`` write above carried the PREVIOUS watermark (it is
    # written for the async path, where the scan has not run yet); after a
    # blocking scan that built, the scanned snapshot is the watermark.
    snap = scan.get("snapshot_id")
    if snap and scan.get("built"):
        _record_ledger(bucket, prefix, current_snapshot=str(snap),
                       last_scanned_snapshot=str(snap),
                       last_scan_at=datetime.now(timezone.utc),
                       source=source, action="dispatched")


def _do_delta_scan(
    db_manager: Any,
    s3_client: Any,
    bucket: str,
    prefix: str,
    cols: List[str],
    source: str,
) -> Dict[str, Any]:
    """Actually run the supplement + bloom delta scan for the cols that
    already have coverage.  skip_already_scanned=True absorbs the dedup
    so only NEW files (in the rolled-forward snapshot) get touched.

    Returns the scan's RESULT (2026-10-08): ``status`` ``ok`` / ``error``,
    ``files_offered`` / ``files_scanned`` / ``files_failed`` /
    ``failure_categories`` read from the scanners' summaries, ``built``,
    and ``error`` naming what failed.  A blocking ``ensure_fresh`` carries
    it in ``out["scan"]``; the async path lands it in the ledger and the
    event log."""
    t0 = time.monotonic()
    result: Dict[str, Any] = {
        "status": "ok", "error": None, "snapshot_id": None,
        "files_offered": 0, "files_scanned": 0, "files_failed": 0,
        "failure_categories": {}, "built": False, "scan_verdicts": {},
        "supplement_summary": None, "bloom_summary": None,
    }
    try:
        from core.iceberg_reader import get_iceberg_data_files
        meta: Dict[str, Any] = {}
        files = get_iceberg_data_files(
            s3_client, bucket, prefix,
            partition_filters=None, keys_only=True,
            force_fresh=False, _out_meta=meta,
        )
        snap = str(meta.get("snapshot_id") or "")
        file_keys = [f.get("key") for f in files if f.get("key")]
        result["snapshot_id"] = snap
        result["files_offered"] = len(file_keys)
        if not snap or not file_keys:
            result["status"] = "error"
            result["error"] = "no snapshot or file list resolved"
            logger.warning(
                "brain_freshness: delta scan ABORTED for %s/%s — "
                "no snapshot or file list resolved", bucket, prefix,
            )
            _record_ledger(bucket, prefix, source=source, action="error",
                           error=result["error"])
            _log_event({"bucket": bucket, "table_prefix": prefix,
                        "source": source, "action": "scan_failed",
                        "reason": result["error"]})
            return result

        sup_cols = [c for c in cols if not c.startswith("bloom:")]
        sup_cols = [c.split(":", 1)[1] if ":" in c else c for c in sup_cols]
        blm_cols = [c.split(":", 1)[1] if ":" in c else c for c in cols]

        # 2026-10-08 -- each scanner's summary is READ BACK (the one reading,
        # core.bloom_coverage.scan_verdict): a scan that scanned nothing
        # while files failed is a failure the ledger and the event say, and
        # the snapshot is NOT recorded as scanned.  Before, every file could
        # be access_denied and the ledger still advanced to "dispatched"
        # with last_scanned_snapshot = this snapshot.
        from core.bloom_coverage import scan_error, scan_verdict
        verdicts = []
        crashes: List[str] = []
        if sup_cols:
            try:
                from core.iceberg_column_stats import scan_files_to_supplement
                result["supplement_summary"] = scan_files_to_supplement(
                    db_manager=db_manager,
                    s3_client=s3_client,
                    bucket=bucket,
                    table_prefix=prefix,
                    snapshot_id=snap,
                    file_keys=file_keys,
                    target_columns=sup_cols,
                    max_workers=16,
                    skip_already_scanned=True,
                    table_name=None,
                )
                verdicts.append(scan_verdict(
                    "supplement", result["supplement_summary"], len(file_keys)))
            except Exception as exc:
                crashes.append(f"supplement scan crashed: {type(exc).__name__}: {exc}")
                logger.warning(
                    "brain_freshness: supplement delta scan failed for "
                    "%s/%s cols=%s: %s",
                    bucket, prefix, sup_cols, exc,
                )

        if blm_cols:
            try:
                from core.iceberg_bloom_sidecar import scan_files_for_bloom
                result["bloom_summary"] = scan_files_for_bloom(
                    db_manager=db_manager,
                    s3_client=s3_client,
                    bucket=bucket,
                    table_prefix=prefix,
                    snapshot_id=snap,
                    file_keys=file_keys,
                    target_columns=blm_cols,
                    max_workers=8,
                    skip_already_scanned=True,
                    table_name=None,
                )
                verdicts.append(scan_verdict(
                    "bloom", result["bloom_summary"], len(file_keys)))
            except Exception as exc:
                crashes.append(f"bloom scan crashed: {type(exc).__name__}: {exc}")
                logger.warning(
                    "brain_freshness: bloom delta scan failed for "
                    "%s/%s cols=%s: %s",
                    bucket, prefix, blm_cols, exc,
                )

        result["scan_verdicts"] = {v.kind: v.summary() for v in verdicts}
        result["files_scanned"] = sum(v.scanned for v in verdicts)
        result["files_failed"] = sum(v.failed for v in verdicts)
        result["built"] = any(v.built for v in verdicts)
        for v in verdicts:
            for cat, n in v.failure_categories.items():
                result["failure_categories"][cat] = (
                    result["failure_categories"].get(cat, 0) + int(n))
        err = scan_error(verdicts)
        if err is None and crashes and not result["built"]:
            err = "; ".join(crashes)
        elapsed = round(time.monotonic() - t0, 1)
        if err:
            result["status"] = "error"
            result["error"] = err[:300]
            logger.error(
                "brain_freshness: delta scan for %s/%s built NOTHING -- %s "
                "(files offered=%d, %s).  The scan reads through the "
                "connection's S3 client; check its credentials / region / "
                "endpoint for the bucket.",
                bucket, prefix, err, len(file_keys), source)
            # The snapshot was NOT scanned: the ledger keeps the previous
            # watermark so the next check dispatches again.
            _record_ledger(bucket, prefix, current_snapshot=snap,
                           source=source, action="error", error=result["error"])
            _log_event({
                "bucket": bucket, "table_prefix": prefix,
                "source": source, "action": "scan_failed",
                "reason": f"delta scan FAILED in {elapsed}s: {err}",
            })
            return result

        # Update ledger with the fresh snapshot we scanned
        _record_ledger(
            bucket, prefix,
            current_snapshot=snap,
            last_scanned_snapshot=snap,
            last_scan_at=datetime.now(timezone.utc),
            source=source, action="dispatched",
        )
        detail = "; ".join(v.describe() for v in verdicts) or "nothing to scan"
        if crashes:
            detail += "; " + "; ".join(crashes)
        _log_event({
            "bucket": bucket, "table_prefix": prefix,
            "source": source, "action": "scan_complete",
            "reason": f"delta scan complete in {elapsed}s "
                      f"for {len(file_keys)} files × {len(cols)} cols -- {detail}",
        })
        if result["files_failed"]:
            logger.warning(
                "brain_freshness: delta scan for %s/%s built with failures -- %s",
                bucket, prefix, detail)
        return result
    except Exception as exc:
        result["status"] = "error"
        result["error"] = f"{type(exc).__name__}: {exc}"[:300]
        logger.warning(
            "brain_freshness: delta scan crashed for %s/%s: %s",
            bucket, prefix, exc,
        )
        _record_ledger(bucket, prefix, source=source, action="error",
                       error=result["error"])
        return result


__all__ = [
    "FreshnessEntry",
    "ensure_fresh",
    "get_recent_events",
    "list_ledger",
    "get_ledger_entry",
]
