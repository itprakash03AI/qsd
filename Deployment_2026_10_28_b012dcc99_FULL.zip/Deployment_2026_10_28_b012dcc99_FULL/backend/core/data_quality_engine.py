"""
Phase 99 — Data Quality Engine.

Rule runners for freshness, schema drift, null rate, row count anomaly,
and custom SQL checks.  Each runner returns a dict compatible with
DataQualityResult.to_dict().
"""
import logging
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as _FutureTimeout
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

# ── Module-level dependencies (injected from main.py) ─────────────────────
_db_manager = None
_connection_manager = None
_cfg = None


def set_dq_engine_dependencies(db_manager=None, connection_manager=None, cfg=None):
    global _db_manager, _connection_manager, _cfg
    if db_manager:
        _db_manager = db_manager
    if connection_manager:
        _connection_manager = connection_manager
    if cfg:
        _cfg = cfg


def _dq_cfg():
    """The data_quality config section — the injected one when main.py
    wired it, else the canonical ``core.config.data_quality`` accessor
    (same object in production; the fallback exists for direct engine
    use in tests/scripts)."""
    if _cfg is not None:
        return _cfg
    from core.config import data_quality
    return data_quality


# ── Runner registry ──────────────────────────────────────────────────────

_RUNNERS: Dict[str, Any] = {}


def _register(rule_type: str):
    def decorator(fn):
        _RUNNERS[rule_type] = fn
        return fn
    return decorator


def run_rule(rule: dict) -> dict:
    """Execute a single DQ rule and return a result dict (not yet persisted)."""
    rule_type = rule.get("rule_type", "")
    runner = _RUNNERS.get(rule_type)
    if not runner:
        return _make_result(rule, passed=False, outcome=OUTCOME_ERRORED,
                            details={"error": f"Unknown rule_type: {rule_type}"})
    t0 = time.time()
    try:
        result = runner(rule)
        result["execution_ms"] = int((time.time() - t0) * 1000)
        return result
    except Exception as exc:
        logger.warning("DQ rule %s (id=%s) failed: %s", rule_type, rule.get("id"), exc)
        return _make_result(
            rule, passed=False, outcome=OUTCOME_ERRORED,
            details={"error": str(exc)},
            execution_ms=int((time.time() - t0) * 1000),
        )


def record_result(rule: dict, result_data: dict, *, db=None) -> dict:
    """★ THE persist-a-DQ-result chokepoint (2026-08-23).

    Every path that stores a result — the manual single run, its >60s
    background continuation, the admin run-all batch, and BOTH scheduled
    loops (main.py thread + daemon_registry tick) — lands here, so alert
    dispatch cannot be path-dependent.  Before this, email/webhook/Slack
    alerts fired ONLY on a manual single-rule run: the one moment a human
    was already looking at the screen.  Scheduled failures — the entire
    point of alert_channels — dispatched nothing.

    Dispatch failures are logged and never propagate: recording the
    result is the correctness half, alerting is best-effort delivery.
    """
    db = db or _db_manager
    if db is None:
        raise RuntimeError("db_manager not initialized")
    persisted = db.create_dq_result(**result_data)
    # dispatch_dq_alerts owns the WHOLE alert decision (failure-only,
    # severity threshold, cooldown) — no pre-filtering here: the same
    # fact decided in two places is how guards mask each other's bugs.
    try:
        from core import config as _cfg_module
        from core.dq_alerting import dispatch_dq_alerts
        dispatch_dq_alerts(rule, persisted, _cfg_module, db)
    except Exception as exc:
        logger.warning("DQ alert dispatch failed for rule %s: %s",
                       rule.get("id"), exc)
    return persisted


def _rule_is_due(rule: dict, now: datetime = None) -> bool:
    """Per-rule ``schedule_cron`` — consumed NOWHERE before 2026-08-23.

    The model stored it, the UI offered it ("Optional cron expression"),
    and no scheduler ever read it: a knob that looked live and was not.
    Semantics now: a rule with no cron runs on every scheduler tick (the
    historical behaviour, unchanged); a rule WITH a cron runs only when a
    cron firing time has passed since its last recorded result.  An
    invalid STORED cron runs anyway and warns — monitoring must not
    silently disable itself (the API rejects invalid crons at write time
    since today, so this arm covers only pre-fix rows).
    """
    expr = str(rule.get("schedule_cron") or "").strip()
    if not expr:
        return True
    now = now or datetime.now(timezone.utc)
    try:
        from croniter import croniter
        prev = _db_manager.get_latest_dq_result(rule["id"]) if _db_manager else None
        last_iso = (prev or {}).get("checked_at")
        if not last_iso:
            return True  # never ran → due now
        last = datetime.fromisoformat(str(last_iso).replace("Z", "+00:00"))
        if last.tzinfo is None:
            last = last.replace(tzinfo=timezone.utc)
        return croniter(expr, last).get_next(datetime) <= now
    except Exception as exc:
        logger.warning("DQ rule %s cron %r unusable — running anyway "
                       "(fail-open for monitoring): %s",
                       rule.get("id"), expr, exc)
        return True


def run_all_enabled(force: bool = False) -> List[dict]:
    """Run enabled DQ rules and persist results.  Returns result dicts.

    ``force=True`` (the admin "Run All Checks" button) runs every enabled
    rule NOW; ``force=False`` (both scheduler loops) honours each rule's
    ``schedule_cron`` via :func:`_rule_is_due`.

    2026-08-23: ``max_concurrent_checks`` and ``execution_timeout_seconds``
    had typed config accessors, admin-API exposure — and ZERO consumers
    (rules ran sequentially, unbounded).  Now: a ThreadPoolExecutor of
    ``max_concurrent_checks`` workers, and each rule gets AT LEAST
    ``execution_timeout_seconds`` before its result is recorded as an
    honest timeout failure (a CAP — it throttles and records, it does
    not kill: a hung connector thread is left to finish detached rather
    than hanging the whole batch behind it).
    """
    if not _db_manager:
        logger.warning("DQ engine: db_manager not set, skipping")
        return []

    rules = _db_manager.list_dq_rules(enabled_only=True)
    if not force:
        rules = [r for r in rules if _rule_is_due(r)]
    if not rules:
        return []

    cfg = _dq_cfg()
    workers = max(1, int(getattr(cfg, "max_concurrent_checks", 5) or 1))
    timeout_s = max(1, int(getattr(cfg, "execution_timeout_seconds", 300) or 300))

    pool = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="dq-rule")
    futures = [(rule, pool.submit(run_rule, rule)) for rule in rules]
    results = []
    try:
        for rule, fut in futures:
            try:
                result_data = fut.result(timeout=timeout_s)
            except _FutureTimeout:
                if fut.cancel():
                    detail = (f"skipped: no execution slot within {timeout_s}s "
                              f"(max_concurrent_checks={workers})")
                else:
                    detail = f"execution exceeded {timeout_s}s budget"
                logger.warning("DQ rule %s (id=%s): %s",
                               rule.get("rule_type"), rule.get("id"), detail)
                result_data = _make_result(rule, passed=False,
                                           outcome=OUTCOME_ERRORED,
                                           details={"error": detail},
                                           execution_ms=timeout_s * 1000)
            except Exception as exc:  # run_rule catches its own; belt+braces
                result_data = _make_result(rule, passed=False,
                                           outcome=OUTCOME_ERRORED,
                                           details={"error": str(exc)})
            results.append(record_result(rule, result_data))
    finally:
        # wait=False: a hung connector call must not hang the batch exit —
        # its thread finishes detached and its (late) answer is discarded.
        pool.shutdown(wait=False)
    return results


# ── Helpers ──────────────────────────────────────────────────────────────

#: A check that could not RUN.  2026-09-17 (FB-8b) -- every failure mode of
#: this engine returned ``{"passed": false, "severity": "critical"}``, so a
#: misconfigured or broken rule raised an alert INDISTINGUISHABLE from "this
#: data is actually bad".  Unknown is not empty: "the data failed" and "the
#: check never ran" lead to opposite investigations -- one pages the data
#: owner, the other pages whoever owns the rule.
OUTCOME_PASSED = "passed"
OUTCOME_FAILED = "failed"
OUTCOME_ERRORED = "errored"
OUTCOMES = frozenset({OUTCOME_PASSED, OUTCOME_FAILED, OUTCOME_ERRORED})


def _make_result(rule: dict, *, passed: bool, details: dict = None,
                 metric_value: float = None, threshold_value: float = None,
                 execution_ms: int = 0, outcome: str = "") -> dict:
    # ``passed`` stays exactly what it was for every existing reader; the
    # NEW information is ``outcome``.  An errored check keeps passed=False --
    # it has certainly not passed -- but is no longer reported as a data
    # failure by anything that reads the outcome.
    _outcome = outcome or (OUTCOME_PASSED if passed else OUTCOME_FAILED)
    if _outcome not in OUTCOMES:
        raise ValueError(
            f"outcome {_outcome!r} is not one of {sorted(OUTCOMES)}")
    return {
        "rule_id": rule["id"],
        "passed": passed,
        "outcome": _outcome,
        "severity": rule.get("severity", "warning"),
        "metric_value": metric_value,
        "threshold_value": threshold_value,
        "details": details or {},
        "execution_ms": execution_ms,
        "checked_at": datetime.now(timezone.utc),
    }


def _get_config(rule: dict, key: str, default=None):
    """Extract a value from the rule's config JSON."""
    cfg = rule.get("config") or {}
    return cfg.get(key, default)


#: The rule COLUMN each executor field falls back to when ``config`` does not
#: carry it.  2026-09-17 -- the create model's natural authoring shape
#: (``target_id`` / ``target_table`` / ``column_name``) is not what the
#: executors read, so a rule authored the obvious way returned
#: "connection_id, table_name, and column_name required" and -- per FB-8b --
#: reported that as a CRITICAL data-quality failure.  ``column_name`` alone
#: had a hand-written fallback; a single fallback among three is the tell
#: that this was noticed once and not generalised.
_FIELD_FALLBACK = {
    "connection_id": "target_id",
    "table_name":    "target_table",
    "column_name":   "column_name",
}


def _rule_field(rule: dict, key: str, default=None):
    """``config[key]``, else the rule column that means the same thing.

    ``target_id`` is ONLY a connection id when the rule targets a connection.
    On a published_view or feed rule it is that object's id, and feeding it to
    ``get_connection_raw`` would either miss or -- worse -- hit an unrelated
    connection that happens to share the number.  So that one fallback is
    conditioned; the other two mean the same thing on every target type.
    """
    cfg = rule.get("config") or {}
    if cfg.get(key) not in (None, ""):
        return cfg[key]
    col = _FIELD_FALLBACK.get(key)
    if not col:
        return default
    if key == "connection_id" and str(
            rule.get("target_type") or "connection").strip().lower() != "connection":
        return default
    val = rule.get(col)
    return default if val in (None, "") else val


def _table_expr(connection_id, table_name: str) -> str:
    """Render ``table_name`` as SQL for the connection it will run on.

    2026-09-17 (FB-8a) -- this used to be ``f'"{table_name}"'``, which quotes
    a dotted path as ONE identifier: ``FROM "tpch.tiny.nation"`` is
    MISSING_SCHEMA_NAME, while ``FROM tpch.tiny.nation`` returns 25 rows on
    the same connection.  On Trino/Starburst EVERY table is qualified, so on
    the primary source that was the whole subsystem.  The federation engine
    already resolved and quoted addresses correctly; only this half was never
    shared.  See ``core.connection_manager.qualified_table_sql``.
    """
    from core.connection_manager import qualified_table_sql
    conn = _db_manager.get_connection_raw(connection_id) if _db_manager else None
    if not conn:
        raise ValueError(f"Connection {connection_id} not found")
    cfg = conn.get("config") or {}
    return qualified_table_sql(
        table_name, conn.get("connection_type", ""),
        default_catalog=cfg.get("catalog", "") or "",
        default_schema=cfg.get("schema", "") or "",
    )


def _col_expr(connection_id, column_name: str) -> str:
    """Quote a COLUMN for the dialect that will execute the SQL.

    Same reason as ``_table_expr``: this path runs its SQL DIRECTLY on the
    connector with no transpile step, so an ANSI double quote hard-coded here
    is wrong on every engine that does not use one.
    """
    from core.sql_filter_wrapper import (
        dialect_for_connection_type, quote_identifier_for_dialect,
    )
    conn = _db_manager.get_connection_raw(connection_id) if _db_manager else None
    ctype = (conn or {}).get("connection_type", "")
    return quote_identifier_for_dialect(
        column_name, dialect_for_connection_type(ctype), always_quote=True)


def _execute_sql(connection_id: int, sql: str, limit: int = 10000) -> List[dict]:
    """Execute SQL via the appropriate connector for the given connection.
    Returns list of row dicts.
    """
    if not _db_manager:
        raise RuntimeError("db_manager not initialized")

    conn_dict = _db_manager.get_connection_raw(connection_id)
    if not conn_dict:
        raise ValueError(f"Connection {connection_id} not found")

    # 2026-09-16 -- THIS CONNECTOR WAS NEVER CLOSED.  Every data-quality
    # rule execution opened a source session and abandoned it; DQ rules run
    # on a schedule, so a pod accumulated one per rule per tick until the
    # source's idle reaper caught up.  Third instance of this exact shape
    # found today (estimate_query, the scheduled export, and this one).
    # Borrowing fixes the leak AND pools it: released on success, discarded
    # on any exception.
    from core.connection_pool import get_pooled_connector
    with get_pooled_connector(
            connection_id,
            conn_dict["connection_type"],
            conn_dict.get("config") or {},
            conn_dict.get("name", ""),
    ) as connector:
        result = connector.execute_query(sql, limit=limit)
    return result.get("rows", []) if isinstance(result, dict) else []


# ── Rule Runners ─────────────────────────────────────────────────────────

@_register("freshness")
def _run_freshness(rule: dict) -> dict:
    """Check if data has been updated within the configured threshold.

    Config:
      - max_age_hours: int (default 24)
      - check_column: str — timestamp column to MAX() (optional)
      - connection_id: int — connection to query
      - table_name: str — table or file reference
    """
    max_age_hours = _get_config(rule, "max_age_hours", 24)
    check_column = _get_config(rule, "check_column")
    connection_id = _rule_field(rule, "connection_id")
    table_name = _rule_field(rule, "table_name")
    threshold = timedelta(hours=max_age_hours)
    now = datetime.now(timezone.utc)

    if check_column and connection_id and table_name:
        # Query the max timestamp from the data
        try:
            sql = (f'SELECT MAX({_col_expr(connection_id, check_column)}) '
                   f'as max_ts FROM {_table_expr(connection_id, table_name)}')
            rows = _execute_sql(connection_id, sql, limit=1)
            if rows and rows[0].get("max_ts"):
                max_ts = rows[0]["max_ts"]
                if isinstance(max_ts, str):
                    # Parse ISO format
                    max_ts = datetime.fromisoformat(max_ts.replace("Z", "+00:00"))
                if not max_ts.tzinfo:
                    max_ts = max_ts.replace(tzinfo=timezone.utc)
                age = now - max_ts
                passed = age <= threshold
                return _make_result(
                    rule, passed=passed,
                    metric_value=age.total_seconds() / 3600,
                    threshold_value=float(max_age_hours),
                    details={
                        "max_timestamp": max_ts.isoformat(),
                        "age_hours": round(age.total_seconds() / 3600, 2),
                        "threshold_hours": max_age_hours,
                    },
                )
        except Exception as exc:
            return _make_result(rule, passed=False, outcome=OUTCOME_ERRORED,
                            details={"error": str(exc)})

    # Fallback: check lineage freshness from metadata
    if _db_manager and rule.get("target_table"):
        freshness_list = _db_manager.get_data_freshness(table_fqn=rule["target_table"])
        if freshness_list:
            freshness = freshness_list[0]
            last_ts = freshness.get("last_refresh_at") or freshness.get("last_observed_at")
            if last_ts:
                last_seen = datetime.fromisoformat(last_ts.replace("Z", "+00:00"))
                if not last_seen.tzinfo:
                    last_seen = last_seen.replace(tzinfo=timezone.utc)
                age = now - last_seen
                passed = age <= threshold
                return _make_result(
                    rule, passed=passed,
                    metric_value=age.total_seconds() / 3600,
                    threshold_value=float(max_age_hours),
                    details={
                        "last_seen": last_seen.isoformat(),
                        "age_hours": round(age.total_seconds() / 3600, 2),
                        "threshold_hours": max_age_hours,
                        "source": "lineage_metadata",
                    },
                )

    return _make_result(rule, passed=False, outcome=OUTCOME_ERRORED,
                        details={"error": "No freshness data available"})


@_register("schema_drift")
def _run_schema_drift(rule: dict) -> dict:
    """Detect if the schema has changed from a known baseline.

    Config:
      - connection_id: int
      - table_name: str
      - expected_columns: list[str] — baseline column names
      - strict: bool (default False) — if True, extra columns also fail
    """
    connection_id = _rule_field(rule, "connection_id")
    table_name = _rule_field(rule, "table_name")
    expected_columns = _get_config(rule, "expected_columns", [])
    strict = _get_config(rule, "strict", False)

    if not (connection_id and table_name):
        return _make_result(rule, passed=False, outcome=OUTCOME_ERRORED,
                            details={"error": "connection_id and table_name required"})

    # 2026-08-23: a dead `SELECT * LIMIT 0` source roundtrip lived here —
    # its result was DISCARDED (and its bare `except Exception: pass`
    # violated the silent-exception rule) while the actual comparison
    # below reads the local schema catalog.  10-60s of cold-connector
    # latency per drift check, buying nothing.  Removed.

    # Use catalog schema cache if available
    if _db_manager:
        try:
            schemas = _db_manager.list_schema_cache_entries(connection_id=connection_id)
            match = [s for s in schemas if s.get("table_name") == table_name]
            if match:
                schema_data = match[0].get("schema_data") or {}
                actual_columns = [c.get("column_name", c.get("name", ""))
                                  for c in (schema_data.get("columns") or [])]
                expected_set = set(c.lower() for c in expected_columns)
                actual_set = set(c.lower() for c in actual_columns)

                missing = expected_set - actual_set
                added = actual_set - expected_set if strict else set()
                passed = len(missing) == 0 and len(added) == 0

                return _make_result(
                    rule, passed=passed,
                    metric_value=len(missing) + len(added),
                    threshold_value=0,
                    details={
                        "expected_columns": sorted(expected_columns),
                        "actual_columns": sorted(actual_columns),
                        "missing_columns": sorted(missing),
                        "added_columns": sorted(added) if strict else [],
                        "strict_mode": strict,
                    },
                )
        except Exception as exc:
            return _make_result(rule, passed=False, outcome=OUTCOME_ERRORED,
                                    details={"error": f"Schema check failed: {exc}"})

    return _make_result(rule, passed=False, outcome=OUTCOME_ERRORED,
                        details={"error": "No schema data available"})


@_register("null_rate")
def _run_null_rate(rule: dict) -> dict:
    """Check if the null rate of a column exceeds a threshold.

    Config:
      - connection_id: int
      - table_name: str
      - column_name: str
      - max_null_pct: float (default 10.0) — max allowed null percentage
      - sample_limit: int (default 100000) — rows to sample
    """
    connection_id = _rule_field(rule, "connection_id")
    table_name = _rule_field(rule, "table_name")
    column_name = _rule_field(rule, "column_name")
    max_null_pct = float(_get_config(rule, "max_null_pct", 10.0))
    sample_limit = int(_get_config(rule, "sample_limit", 100000))

    if not (connection_id and table_name and column_name):
        return _make_result(rule, passed=False, outcome=OUTCOME_ERRORED,
                           details={"error": "connection_id, table_name, and column_name required"})

    try:
        _col = _col_expr(connection_id, column_name)
        _tbl = _table_expr(connection_id, table_name)
        sql = (
            f'SELECT COUNT(*) as total, '
            f'COUNT(CASE WHEN {_col} IS NULL THEN 1 END) as null_count '
            f'FROM (SELECT {_col} FROM {_tbl} LIMIT {sample_limit}) as _s'
        )
        rows = _execute_sql(connection_id, sql, limit=1)
        if rows:
            total = rows[0].get("total", 0)
            null_count = rows[0].get("null_count", 0)
            null_pct = (null_count / total * 100) if total > 0 else 0
            passed = null_pct <= max_null_pct

            return _make_result(
                rule, passed=passed,
                metric_value=round(null_pct, 2),
                threshold_value=max_null_pct,
                details={
                    "total_rows": total,
                    "null_count": null_count,
                    "null_pct": round(null_pct, 2),
                    "max_null_pct": max_null_pct,
                    "column": column_name,
                },
            )
    except Exception as exc:
        return _make_result(rule, passed=False, outcome=OUTCOME_ERRORED,
                            details={"error": str(exc)})

    return _make_result(rule, passed=False, outcome=OUTCOME_ERRORED,
                        details={"error": "Query returned no results"})


@_register("row_count")
def _run_row_count(rule: dict) -> dict:
    """Check if row count is within expected range or hasn't deviated anomalously.

    Config:
      - connection_id: int
      - table_name: str
      - min_rows: int (default 0)
      - max_rows: int (default 0, 0 = no upper limit)
      - deviation_pct: float (default 0, 0 = skip deviation check)
    """
    connection_id = _rule_field(rule, "connection_id")
    table_name = _rule_field(rule, "table_name")
    min_rows = int(_get_config(rule, "min_rows", 0))
    max_rows = int(_get_config(rule, "max_rows", 0))
    deviation_pct = float(_get_config(rule, "deviation_pct", 0))

    if not (connection_id and table_name):
        return _make_result(rule, passed=False, outcome=OUTCOME_ERRORED,
                           details={"error": "connection_id and table_name required"})

    try:
        sql = f'SELECT COUNT(*) as cnt FROM {_table_expr(connection_id, table_name)}'
        rows = _execute_sql(connection_id, sql, limit=1)
        if rows:
            count = rows[0].get("cnt", 0)

            # Range check
            range_ok = True
            if min_rows > 0 and count < min_rows:
                range_ok = False
            if max_rows > 0 and count > max_rows:
                range_ok = False

            # Deviation check against previous results
            deviation_ok = True
            prev_metric = None
            if deviation_pct > 0 and _db_manager:
                prev = _db_manager.get_latest_dq_result(rule["id"])
                if prev and prev.get("metric_value") is not None:
                    prev_metric = prev["metric_value"]
                    if prev_metric > 0:
                        actual_deviation = abs(count - prev_metric) / prev_metric * 100
                        if actual_deviation > deviation_pct:
                            deviation_ok = False

            passed = range_ok and deviation_ok

            details = {
                "row_count": count,
                "min_rows": min_rows,
                "max_rows": max_rows,
                "range_ok": range_ok,
            }
            if deviation_pct > 0:
                details["deviation_pct_threshold"] = deviation_pct
                details["previous_count"] = prev_metric
                details["deviation_ok"] = deviation_ok

            return _make_result(
                rule, passed=passed,
                metric_value=float(count),
                threshold_value=float(min_rows) if min_rows > 0 else float(max_rows),
                details=details,
            )
    except Exception as exc:
        return _make_result(rule, passed=False, outcome=OUTCOME_ERRORED,
                            details={"error": str(exc)})

    return _make_result(rule, passed=False, outcome=OUTCOME_ERRORED,
                        details={"error": "Query returned no results"})


@_register("custom_sql")
def _run_custom_sql(rule: dict) -> dict:
    """Run a custom SQL assertion.

    The SQL must return a single row. The check passes if:
      - The first column value is truthy (non-zero, non-null, non-empty), OR
      - If `expected_value` is set, the first column value must equal it.

    Config:
      - connection_id: int
      - sql: str — the SQL to execute
      - expected_value: any (optional) — expected value of first column
    """
    connection_id = _rule_field(rule, "connection_id")
    sql = _get_config(rule, "sql")
    expected_value = _get_config(rule, "expected_value")

    if not (connection_id and sql):
        return _make_result(rule, passed=False, outcome=OUTCOME_ERRORED,
                           details={"error": "connection_id and sql required"})

    try:
        rows = _execute_sql(connection_id, sql, limit=1)
        if not rows:
            return _make_result(rule, passed=False, outcome=OUTCOME_ERRORED,
                               details={"error": "Query returned no rows", "sql": sql})

        row = rows[0]
        first_key = list(row.keys())[0] if row else None
        actual_value = row.get(first_key) if first_key else None

        if expected_value is not None:
            passed = str(actual_value) == str(expected_value)
        else:
            passed = bool(actual_value) and actual_value != 0

        return _make_result(
            rule, passed=passed,
            metric_value=float(actual_value) if isinstance(actual_value, (int, float)) else None,
            details={
                "sql": sql,
                "result_column": first_key,
                "actual_value": actual_value,
                "expected_value": expected_value,
            },
        )
    except Exception as exc:
        return _make_result(rule, passed=False, outcome=OUTCOME_ERRORED,
                            details={"error": str(exc), "sql": sql})


# ── The rule-type vocabulary (2026-08-23) ────────────────────────────────
# THE list of rule types IS the runner registry — the API's validation
# pattern is built from this, so a new @_register'd runner is accepted by
# the API without anyone remembering to update a second hardcoded list
# (and a type the engine cannot run can never be saved).
RULE_TYPES = tuple(sorted(_RUNNERS))
