"""core/completeness_certificate.py — the Completeness Certificate (Phase 1).

2026-07-17.  A FAIL-CLOSED, OBSERVATIONAL trust artifact.  It FUSES signals the
platform ALREADY produces into a single provable-completeness verdict for a
report delivery, a feed/ETL load, or an ad-hoc query — and then renders that
verdict for storage (``to_dict``), a document footer (``to_footer_text``) and a
UI chip (``to_badge``).

WHY THIS EXISTS
───────────────
Every subsystem already emits a partial completeness signal — the Tier-1
completeness receipt, the Iceberg scan-ledger reconciliation, the snapshot id /
fingerprint, adaptive-freshness, the Completeness Sentinel's trust state, and
the reconciliation runner's source-vs-dest counts.  Individually each is a
diagnostic; NONE of them is a single, human-facing "is this delivery provably
complete?" answer.  This module is that single answer — and the ONE place in
QueryStudio that deliberately breaks the platform's fail-OPEN reflex.

TWO INVARIANTS (get these right — this is the moat)
───────────────────────────────────────────────────
1. FAIL-CLOSED.  We return ``COMPLETE`` ONLY when EVERY required signal
   AFFIRMATIVELY proves it.  Missing / ambiguous / unknown evidence yields
   ``UNVERIFIED`` — never ``COMPLETE``.  A stamp that lies is worse than none.
   The ONLY exception to fail-closed is the builder's OWN error handling: an
   internal exception degrades to ``UNVERIFIED`` (never raises, never a false
   ``COMPLETE``).
2. OBSERVATIONAL.  This module READS already-collected signals and RETURNS a
   certificate.  It never executes a query, never opens S3, never alters a
   result, never blocks anything.  Pure + deterministic given its inputs (the
   ``issued_at`` timestamp is passed IN — no wall-clock reads here).

REAL SIGNALS CONSUMED (exact field names — see the survey in the phase report)
──────────────────────────────────────────────────────────────────────────────
``out_meta["completeness"]``          → ``verdict`` (complete|INCOMPLETE|over|
                                        unverified), ``expected_rows``,
                                        ``rows_read``  (core.completeness_control)
``out_meta["scan_ledger"]``           → ``verdict`` (ok|over_count|under_count|
                                        partial_manifest_read|
                                        skipped_capped|no_declared_total),
                                        ``considered``, ``final``,
                                        ``declared_total``, ``delta_considered``
                                        (core.iceberg_reader)
``out_meta["snapshot_id"]``           → str snapshot id
``out_meta["snapshot_total_data_files"]`` → declared file count fallback
``out_meta["snapshot_fingerprint"]``  → SHA-256 (core.snapshot_fingerprint;
                                        also accepted via the arg-less path)
``out_meta["adaptive_freshness"]``    → ``trigger``, ``refreshed``
                                        (core.iceberg_reader)
``out_meta["freshness_seconds"]``     → optional age in seconds
``reconciliation``                    → source vs dest counts + break
                                        (core.reconciliation.runner run dict)
``sentinel_state``                    → Completeness Sentinel trust state
                                        (core.completeness_sentinel /
                                        completeness_control.is_quarantined)

FAIL-CLOSED VERDICT TRUTH TABLE
───────────────────────────────
  INCOMPLETE  — ANY hard-negative present:
                  completeness verdict INCOMPLETE or over
                  scan_ledger verdict over_count
                  pruning_gate unjustified > 0  (files dropped without a
                    provable reason — 2026-08-19; previously stamped into
                    out_meta, logged as "results may be missing rows", and
                    read by nothing, so such a query could be certified
                    COMPLETE)
                  file_cap capped: True  (a scan set was TRUNCATED by a size
                    cap — the BF-579 max_registered_files slice or a
                    list_s3_parquet_files listing cap — 2026-08-20; previously
                    the slice was recorded as if it were pruning and the
                    listing's truncated=True flag had no consumers)
                  reconciliation break (|source-dest| > tolerance)
                  sentinel quarantined for the subject's table(s)
  COMPLETE    — NO hard-negative AND every REQUIRED signal for the scope is
                affirmatively OK.
  UNVERIFIED  — the fail-closed default: no hard-negative, but at least one
                required signal is UNKNOWN (missing snapshot, no completeness
                verdict, no reconciliation for a load, unknown / stale
                freshness, unknown sentinel state, capped/under-count ledger).

REQUIRED SIGNALS PER SCOPE (a required signal that is not affirmatively OK ⇒
never COMPLETE)
  report / query : completeness, scan_ledger, snapshot, freshness, sentinel
  feed  (ETL load): reconciliation, sentinel
    (freshness is NOT required for a feed: a feed WRITE just produced the data,
    so it is current by construction — staleness is a READ concept, not a
    load-completion one.  A feed is COMPLETE when it provably moved every source
    row to the destination and the table is not quarantined.  If a freshness
    signal is supplied anyway it is still evaluated, but its absence never blocks
    a feed COMPLETE.)
Every signal — required or not — still contributes a HARD-NEGATIVE if present
and bad (an INCOMPLETE completeness receipt riding along an ETL load still
forces INCOMPLETE).
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

CERT_VERSION = "1.0"

# ── Verdicts ────────────────────────────────────────────────────────────────
COMPLETE = "COMPLETE"
INCOMPLETE = "INCOMPLETE"
UNVERIFIED = "UNVERIFIED"

# ── Scopes ──────────────────────────────────────────────────────────────────
SCOPE_REPORT = "report"
SCOPE_FEED = "feed"   # a feed / ETL load — proven by source-vs-dest reconciliation
SCOPE_QUERY = "query"
SCOPE_ISLAND_MIRROR = "island_mirror"  # Phase 8 — materialized-island build proof

# Per-scope REQUIRED signal set.  A required signal that is not affirmatively
# OK can never yield COMPLETE (it degrades the verdict to UNVERIFIED).
_REQUIRED_BY_SCOPE: Dict[str, tuple] = {
    SCOPE_REPORT: ("completeness", "scan_ledger", "snapshot", "freshness", "sentinel"),
    SCOPE_QUERY:  ("completeness", "scan_ledger", "snapshot", "freshness", "sentinel"),
    SCOPE_FEED:   ("reconciliation", "sentinel"),
    # A materialized island is a BUILD-TIME artifact, not a query/report
    # delivery: freshness/sentinel/scan_ledger don't apply (there is no
    # read-time WHERE-clause reconciliation to attest — the row-equivalence
    # proof IS the completeness signal).  Required: the row-count
    # equivalence ("completeness": expected=raw island rows, read=compacted
    # mirror rows) AND a pinned snapshot id (the immutability anchor the
    # fingerprint match at serve time depends on).
    SCOPE_ISLAND_MIRROR: ("completeness", "snapshot"),
}

# Internal per-signal status.
_OK = "ok"
_NEG = "negative"       # a HARD negative (drives INCOMPLETE)
_UNKNOWN = "unknown"    # evidence absent / ambiguous (drives UNVERIFIED)

# Sentinel states that mean the table is quarantined (pruning disabled / risk).
_QUARANTINE_STATES = {"PROVEN_RISK", "STATS_RECOVERY", "RECOVERING"}


# ═══════════════════════════════════════════════════════════════════════════
# Config — all fail-open to documented defaults (section completeness_certificate)
# ═══════════════════════════════════════════════════════════════════════════
def _cfg(key: str, default: Any) -> Any:
    try:
        from core.config import get as _get
        val = _get("completeness_certificate", key, default)
        return default if val is None else val
    except Exception:
        return default


def enabled() -> bool:
    try:
        return bool(_cfg("enabled", True))
    except Exception:
        return True


def default_freshness_bound_seconds() -> Optional[float]:
    try:
        v = _cfg("default_freshness_bound_seconds", None)
        return None if v is None else max(0.0, float(v))
    except Exception:
        return None


def reconciliation_tolerance_rows() -> int:
    try:
        return max(0, int(_cfg("reconciliation_tolerance_rows", 0)))
    except Exception:
        return 0


def reconciliation_tolerance_ratio() -> float:
    try:
        return max(0.0, float(_cfg("reconciliation_tolerance_ratio", 0.0)))
    except Exception:
        return 0.0


# ═══════════════════════════════════════════════════════════════════════════
# Formatting helpers (pure).
# ═══════════════════════════════════════════════════════════════════════════
def _fmt(n: Any) -> str:
    """Thousands-separated integer, or ``?`` when unknown."""
    try:
        if n is None:
            return "?"
        return f"{int(n):,}"
    except (TypeError, ValueError):
        return str(n)


def _as_int(v: Any) -> Optional[int]:
    try:
        if v is None or isinstance(v, bool):
            return None
        return int(v)
    except (TypeError, ValueError):
        return None


# ═══════════════════════════════════════════════════════════════════════════
# Pure dict → one-line footer renderer (Phase 4 — PDF / Excel export footer).
# Produces the SAME string as ``CompletenessCertificate.to_footer_text()`` from
# a plain ``to_dict()`` payload, so callers that only hold the stored dict never
# need to rebuild the dataclass.  FAIL-SAFE: any bad/missing input ⇒ "".
# ═══════════════════════════════════════════════════════════════════════════
def footer_text_from_dict(cert_dict: Any) -> str:
    """Render the one-line completeness footer from a certificate ``to_dict``.

    Mirrors ``CompletenessCertificate.to_footer_text`` exactly.  Never raises —
    a malformed / empty / non-dict input returns "" (no footer, unchanged
    export behaviour).
    """
    try:
        if not isinstance(cert_dict, dict):
            return ""
        verdict = cert_dict.get("verdict")
        if not verdict:
            return ""
        reasons = cert_dict.get("reasons")
        reasons = reasons if isinstance(reasons, list) else []

        if verdict == COMPLETE:
            parts: List[str] = ["✓ Complete"]
            snapshot_id = cert_dict.get("snapshot_id")
            if snapshot_id:
                parts.append(f"snapshot {snapshot_id}")
            rows = cert_dict.get("rows_read")
            if rows is None:
                rows = cert_dict.get("source_rows")
            if rows is not None:
                reconciled = (cert_dict.get("source_rows") is not None
                              and cert_dict.get("dest_rows") is not None)
                parts.append(f"{_fmt(rows)} rows{' reconciled' if reconciled else ''}")
            if cert_dict.get("is_stale") is False:
                parts.append("fresh")
            return " · ".join(parts)
        if verdict == INCOMPLETE:
            reason = reasons[0] if reasons else "a completeness signal failed"
            return f"✗ Incomplete · {reason}"
        # UNVERIFIED or anything unrecognised
        reason = reasons[0] if reasons else "completeness could not be proven"
        return f"⚠ Unverified · {reason}"
    except Exception:
        return ""


# ═══════════════════════════════════════════════════════════════════════════
# The certificate.
# ═══════════════════════════════════════════════════════════════════════════
@dataclass
class CompletenessCertificate:
    verdict: str
    scope: str
    subject_id: str
    issued_at: Any
    version: str = CERT_VERSION
    snapshot_id: Optional[str] = None
    snapshot_fingerprint: Optional[str] = None
    files_read: Optional[int] = None
    files_expected: Optional[int] = None
    expected_rows: Optional[int] = None
    rows_read: Optional[int] = None
    source_rows: Optional[int] = None
    dest_rows: Optional[int] = None
    freshness_seconds: Optional[float] = None
    is_stale: Optional[bool] = None
    reasons: List[str] = field(default_factory=list)
    evidence: Dict[str, Any] = field(default_factory=dict)
    contributing_signals: List[str] = field(default_factory=list)

    # ── renderers (no I/O, no external deps) ────────────────────────────────
    def to_dict(self) -> Dict[str, Any]:
        """Full serialisable form — for storage / API."""
        return {
            "verdict": self.verdict,
            "scope": self.scope,
            "subject_id": self.subject_id,
            "version": self.version,
            "issued_at": self.issued_at,
            "snapshot_id": self.snapshot_id,
            "snapshot_fingerprint": self.snapshot_fingerprint,
            "files_read": self.files_read,
            "files_expected": self.files_expected,
            "expected_rows": self.expected_rows,
            "rows_read": self.rows_read,
            "source_rows": self.source_rows,
            "dest_rows": self.dest_rows,
            "freshness_seconds": self.freshness_seconds,
            "is_stale": self.is_stale,
            "reasons": list(self.reasons),
            "evidence": dict(self.evidence),
            "contributing_signals": list(self.contributing_signals),
        }

    def to_footer_text(self) -> str:
        """One-line human string for a PDF / Excel footer."""
        if self.verdict == COMPLETE:
            parts: List[str] = ["✓ Complete"]
            if self.snapshot_id:
                parts.append(f"snapshot {self.snapshot_id}")
            rows = self.rows_read if self.rows_read is not None else self.source_rows
            if rows is not None:
                reconciled = self.source_rows is not None and self.dest_rows is not None
                parts.append(f"{_fmt(rows)} rows{' reconciled' if reconciled else ''}")
            if self.is_stale is False:
                parts.append("fresh")
            return " · ".join(parts)
        if self.verdict == INCOMPLETE:
            reason = self.reasons[0] if self.reasons else "a completeness signal failed"
            return f"✗ Incomplete · {reason}"
        # UNVERIFIED
        reason = self.reasons[0] if self.reasons else "completeness could not be proven"
        return f"⚠ Unverified · {reason}"

    def to_badge(self) -> Dict[str, Any]:
        """Compact verdict + short reason for a UI chip."""
        label = {COMPLETE: "Complete", INCOMPLETE: "Incomplete",
                 UNVERIFIED: "Unverified"}.get(self.verdict, self.verdict)
        tone = {COMPLETE: "success", INCOMPLETE: "error",
                UNVERIFIED: "warning"}.get(self.verdict, "warning")
        return {
            "verdict": self.verdict,
            "label": label,
            "tone": tone,
            "reason": self.reasons[0] if self.reasons else label,
        }


# ═══════════════════════════════════════════════════════════════════════════
# Per-signal evaluators.  Each returns (status, reason, evidence-fragment).
# status ∈ {_OK, _NEG, _UNKNOWN}.  A _NEG here is always a HARD negative.
# ═══════════════════════════════════════════════════════════════════════════
def _eval_completeness(comp: Any):
    if not isinstance(comp, dict) or comp.get("verdict") is None:
        return (_UNKNOWN, "completeness could not be proven (no completeness verdict present)", {})
    verdict = comp.get("verdict")
    exp = comp.get("expected_rows")
    got = comp.get("rows_read")
    ev = {"verdict": verdict, "expected_rows": exp, "rows_read": got}
    if verdict == "complete":
        # Prefer the receipt's own verdict_reason when present — the audited
        # file-integrity lane (Phase 2b) compares PHYSICAL rows to the PRE-delete
        # declared record_count, so the generic "expected N, read M" string
        # (expected is POST-delete) would look mismatched.  Additive: VERDICT
        # logic is unchanged; only the human reason string for the OK case.
        reason = comp.get("verdict_reason")
        if reason:
            return (_OK, str(reason), ev)
        return (_OK, f"completeness verdict complete (expected {_fmt(exp)}, read {_fmt(got)})", ev)
    if verdict == "INCOMPLETE":
        # Phase 2b (2026-07-26): honor a receipt-supplied verdict_reason on the
        # INCOMPLETE arm too (same additive pattern as the "complete" arm above)
        # — the exchange row-conservation gate stamps a specific reason
        # ("exchange row-conservation gate FAILED: …") that must survive to the
        # certificate.  VERDICT logic unchanged: still a hard negative.
        reason = comp.get("verdict_reason")
        if reason:
            return (_NEG, str(reason), ev)
        return (_NEG, f"completeness INCOMPLETE — read {_fmt(got)} of expected {_fmt(exp)} rows "
                f"(a kept file was silently skipped or deletes over-applied)", ev)
    if verdict == "over":
        return (_NEG, f"completeness over-count — read {_fmt(got)} vs expected {_fmt(exp)} rows "
                f"(deletes under-applied / MoR overcount)", ev)
    # "unverified" or anything unrecognised
    # 2026-09-16 — honour a receipt-supplied reason here too, the same
    # additive pattern the "complete" and "INCOMPLETE" arms above already
    # use.  Without it every fast-mode receipt rendered "missing
    # record_count / scan-count metadata", which is not why it is
    # unverified: fast mode HAS the record_count and deliberately never
    # counts rows.  A reader sent to look for broken metadata that is not
    # broken is worse served than one told the real reason.
    reason = comp.get("verdict_reason") if isinstance(comp, dict) else None
    if reason:
        return (_UNKNOWN, f"completeness could not be proven — {reason}", ev)
    return (_UNKNOWN, "completeness could not be proven (verdict unverified — "
            "missing record_count / scan-count metadata)", ev)


def _eval_scan_ledger(ledger: Any):
    if not isinstance(ledger, dict) or ledger.get("verdict") is None:
        return (_UNKNOWN, "no scan-ledger reconciliation — cannot prove the file set", {})
    verdict = ledger.get("verdict")
    considered = ledger.get("considered")
    final = ledger.get("final")
    declared = ledger.get("declared_total")
    delta = ledger.get("delta_considered")
    ev = {"verdict": verdict, "considered": considered, "final": final,
          "declared_total": declared, "delta_considered": delta}
    if verdict == "ok":
        return (_OK, f"scan-ledger reconciled (final {_fmt(final)} vs declared {_fmt(declared)})", ev)
    if verdict == "over_count":
        by = _as_int(delta)
        by_txt = f" by {_fmt(by)}" if by is not None else ""
        return (_NEG, f"scan-ledger over_count{by_txt} — considered {_fmt(considered)} files vs "
                f"declared {_fmt(declared)} (phantom / double-counted manifest)", ev)
    if verdict == "under_count":
        return (_UNKNOWN, f"scan-ledger under_count — final {_fmt(final)} of declared {_fmt(declared)} "
                f"files (possible partial enumeration — cannot prove complete)", ev)
    if verdict == "partial_manifest_read":
        # 2026-08-20 HARD NEGATIVE — one or more iceberg manifests could not
        # be read and contributed ZERO data files (non-strict mode returns []
        # per failed manifest).  Unlike under_count this is not "possible":
        # the enumeration is PROVABLY partial, delivered with a success
        # status — exactly what the certificate exists to make impossible.
        # (The ledger used to call this verdict "ok" / "invariant B relaxed".)
        return (_NEG, "scan-ledger partial_manifest_read — manifest read "
                "failure(s) dropped every data file those manifests "
                "referenced; the scan set is a provably partial enumeration", ev)
    if verdict == "skipped_capped":
        return (_UNKNOWN, "scan-ledger skipped (enumeration capped) — cannot prove the file set", ev)
    if verdict == "no_declared_total":
        return (_UNKNOWN, "scan-ledger skipped (snapshot declared no total-data-files) — "
                "cannot prove the file set", ev)
    return (_UNKNOWN, f"scan-ledger verdict {verdict!r} — cannot prove the file set", ev)


def _eval_pruning_gate(gate: Any):
    """2026-08-19 — the pruning gate's verdict now REACHES the certificate.

    ``core.pruning_gate`` independently re-derives the justification for every
    file the prune funnel dropped, and ``iceberg_reader`` stamps its summary
    into ``out_meta["pruning_gate"]`` and logs
    "N of M verified drop(s) were UNJUSTIFIED ... results may be missing rows".

    Nothing read it.  In the default observe mode the gate does not restore
    the files, so a query with drops the gate itself calls unjustified could
    be certified COMPLETE — the certificate's whole purpose is to make that
    impossible.  A computed-then-discarded verdict is the recurring shape of
    the defects found today, and this was the one with a certificate on top.

    ``unjustified > 0`` is a HARD NEGATIVE: the engine dropped files it could
    not justify, which is exactly "results may be missing rows".
    """
    if not isinstance(gate, dict) or gate.get("checked") is None:
        # No gate ran (disabled, or a path that does not prune) — this is not
        # a required signal, so silence here must not block COMPLETE.
        return (_UNKNOWN, "pruning gate did not run — no independent "
                          "justification for the dropped files", {})
    unjustified = _as_int(gate.get("unjustified")) or 0
    checked = _as_int(gate.get("checked")) or 0
    evd = {"unjustified": unjustified, "checked": checked,
           "mode": gate.get("mode"), "by_stage": gate.get("by_stage")}
    if unjustified > 0:
        return (_NEG,
                f"pruning gate: {unjustified} of {checked} verified drop(s) "
                f"were UNJUSTIFIED — files were pruned without a provable "
                f"reason, so rows may be missing", evd)
    return (_OK, f"pruning gate: all {checked} verified drop(s) justified", evd)


def _eval_file_cap(cap: Any):
    """2026-08-20 — a file CAP's truncation verdict now REACHES the certificate.

    Two producers stamp ``out_meta["file_cap"]`` (via
    ``core.scan_truncation.record_scan_truncation``):

      * the BF-579 ``max_registered_files`` slice in ``duckdb_views`` — the
        post-pruning file list is cut to the last N.  It was recorded in
        ``file_stats["after_pruning"]`` AFTER the slice, so the cap was
        indistinguishable from legitimate pruning, and the iceberg scan
        ledger computed its counts BEFORE the slice, so the certificate
        could stamp COMPLETE over a capped scan.
      * ``list_s3_parquet_files``'s ``truncated=True`` at its listing cap —
        flagged 2026-08-17 as "has no consumers".

    ``capped: True`` is a HARD NEGATIVE: files that survived pruning were
    dropped purely by a size cap — the result is a SUBSET with a success
    status, which is exactly what the certificate exists to make impossible.
    A cap may throttle; a correctness gate must fail.
    """
    if not isinstance(cap, dict) or not cap:
        # No cap fired (or nothing reported one) — not a required signal, so
        # silence here must not block COMPLETE.
        return (_UNKNOWN, "no file-cap signal — no scan-set truncation reported", {})
    ev = dict(cap)
    if not cap.get("capped"):
        return (_OK, "no file-cap truncation", ev)
    tables = cap.get("tables") if isinstance(cap.get("tables"), dict) else {}
    tnames = ", ".join(sorted(str(t) for t in tables)) or "?"
    dropped = _as_int(cap.get("dropped"))
    dropped_txt = (f"{_fmt(dropped)} file(s) dropped beyond the cap"
                   if dropped is not None
                   else "an UNKNOWN number of files dropped (enumeration "
                        "stopped at the cap)")
    return (_NEG,
            f"scan set TRUNCATED by a file cap on {tnames} — {dropped_txt}; "
            f"the result is a subset, not pruning", ev)


def _eval_snapshot(out_meta: Dict[str, Any]):
    sid = out_meta.get("snapshot_id")
    if sid is None or str(sid).strip() == "":
        return (_UNKNOWN, "no snapshot id — cannot pin the delivery to a table version", {})
    return (_OK, f"pinned to snapshot {sid}", {"snapshot_id": str(sid)})


def _eval_freshness(out_meta: Dict[str, Any], freshness_bound_seconds: Optional[float]):
    """Returns (status, reason, evidence, freshness_seconds, is_stale).

    Freshness is KNOWN when adaptive_freshness is present OR a freshness age was
    supplied.  Stale freshness is NOT a hard negative (the data may be complete
    yet old) — it degrades to UNVERIFIED, never INCOMPLETE.
    """
    af = out_meta.get("adaptive_freshness")
    secs = out_meta.get("freshness_seconds")
    try:
        secs = None if secs is None else float(secs)
    except (TypeError, ValueError):
        secs = None

    known = isinstance(af, dict) or secs is not None
    if not known:
        return (_UNKNOWN, "freshness unknown — cannot certify the data is current",
                {}, None, None)

    stale = False
    detail_bits: List[str] = []
    ev: Dict[str, Any] = {}
    if isinstance(af, dict):
        trigger = af.get("trigger")
        refreshed = bool(af.get("refreshed"))
        ev["adaptive_freshness"] = {"trigger": trigger, "refreshed": refreshed}
        if trigger and not refreshed:
            stale = True
            detail_bits.append(f"staleness trigger {str(trigger)!r} not refreshed")
    bound = freshness_bound_seconds
    if bound is None:
        bound = default_freshness_bound_seconds()
    if secs is not None:
        ev["freshness_seconds"] = secs
        if bound is not None and secs > bound:
            stale = True
            detail_bits.append(f"age {secs:g}s exceeds bound {bound:g}s")

    if stale:
        detail = "; ".join(detail_bits) or "stored snapshot behind current"
        return (_UNKNOWN, f"data stale ({detail}) — cannot certify fresh", ev, secs, True)
    return (_OK, "fresh (within freshness bound)", ev, secs, False)


def _extract_recon_counts(recon: Any):
    """Pull (source_rows, dest_rows, break_flag) from a reconciliation payload.

    Accepts several shapes the platform produces: the runner's run dict
    (``break_details.row_count`` + ``break_detected``), a denormalised entity
    row (``last_source_row_count`` / ``last_dest_row_count``), or an explicit
    ``{source_rows, dest_rows}``.
    """
    if not isinstance(recon, dict):
        return (None, None, None)
    src = _as_int(recon.get("source_rows"))
    dst = _as_int(recon.get("dest_rows"))
    if src is None:
        src = _as_int(recon.get("source_row_count")) or _as_int(recon.get("last_source_row_count"))
    if dst is None:
        dst = _as_int(recon.get("dest_row_count")) or _as_int(recon.get("last_dest_row_count"))
    # runner break_details / row_count shape
    rc = None
    details = recon.get("break_details") if isinstance(recon.get("break_details"), dict) else recon
    if isinstance(details, dict) and isinstance(details.get("row_count"), dict):
        rc = details["row_count"]
        if src is None:
            src = _as_int(rc.get("source"))
        if dst is None:
            dst = _as_int(rc.get("dest"))
    break_flag = None
    if "break_detected" in recon:
        break_flag = bool(recon.get("break_detected"))
    elif isinstance(rc, dict) and "match" in rc:
        break_flag = not bool(rc.get("match"))
    return (src, dst, break_flag)


def _eval_reconciliation(recon: Any, tolerances: Optional[Dict[str, Any]]):
    """Returns (status, reason, evidence, source_rows, dest_rows)."""
    src, dst, break_flag = _extract_recon_counts(recon)
    if src is None or dst is None:
        return (_UNKNOWN, "no reconciliation (source/dest row counts) — "
                "cannot prove a load complete", {}, src, dst)
    try:
        tol_rows = int((tolerances or {}).get("rows")) if (tolerances or {}).get("rows") is not None \
            else reconciliation_tolerance_rows()
    except (TypeError, ValueError):
        tol_rows = reconciliation_tolerance_rows()
    try:
        tol_ratio = float((tolerances or {}).get("ratio")) if (tolerances or {}).get("ratio") is not None \
            else reconciliation_tolerance_ratio()
    except (TypeError, ValueError):
        tol_ratio = reconciliation_tolerance_ratio()
    diff = abs(src - dst)
    import math
    tol = max(tol_rows, int(math.ceil(abs(src) * tol_ratio)))
    ev = {"source_rows": src, "dest_rows": dst, "diff": diff, "tolerance": tol}
    if break_flag is True and diff > tol:
        return (_NEG, f"reconciliation break — source {_fmt(src)} vs dest {_fmt(dst)} "
                f"(diff {_fmt(diff)} > tolerance {_fmt(tol)})", ev, src, dst)
    if diff > tol:
        return (_NEG, f"reconciliation break — source {_fmt(src)} vs dest {_fmt(dst)} "
                f"(diff {_fmt(diff)} > tolerance {_fmt(tol)})", ev, src, dst)
    return (_OK, f"reconciled source {_fmt(src)} == dest {_fmt(dst)} (within tolerance {_fmt(tol)})",
            ev, src, dst)


def _eval_sentinel(sentinel_state: Any):
    """Returns (status, reason, evidence).  Absent state ⇒ UNKNOWN (fail-closed:
    we cannot prove the table is NOT quarantined)."""
    if sentinel_state is None:
        return (_UNKNOWN, "sentinel trust state unknown — cannot prove the table is "
                "not quarantined", {})
    quarantined = False
    state_name = None
    if isinstance(sentinel_state, bool):
        quarantined = sentinel_state
        ev = {"quarantined": quarantined}
    elif isinstance(sentinel_state, dict):
        state_name = sentinel_state.get("state")
        mode = sentinel_state.get("mode")
        quarantined = (
            bool(sentinel_state.get("quarantined")) or
            (state_name in _QUARANTINE_STATES) or
            (str(mode) == "full_scan")
        )
        ev = {"state": state_name, "mode": mode, "quarantined": quarantined}
    else:
        return (_UNKNOWN, f"sentinel trust state unrecognised ({type(sentinel_state).__name__}) — "
                "cannot prove not quarantined", {})
    if quarantined:
        detail = f" (state {state_name})" if state_name else ""
        return (_NEG, f"sentinel has QUARANTINED the subject's table{detail} — "
                f"pruning is untrusted", ev)
    return (_OK, f"sentinel healthy{(' (state ' + str(state_name) + ')') if state_name else ''}", ev)


# ═══════════════════════════════════════════════════════════════════════════
# THE single chokepoint.
# ═══════════════════════════════════════════════════════════════════════════
def build_certificate(
    scope: str,
    subject_id: str,
    *,
    out_meta: Optional[Dict[str, Any]] = None,
    reconciliation: Optional[Dict[str, Any]] = None,
    sentinel_state: Any = None,
    freshness_bound_seconds: Optional[float] = None,
    tolerances: Optional[Dict[str, Any]] = None,
    issued_at: Any = None,
) -> CompletenessCertificate:
    """Fuse the already-collected signals into ONE fail-closed certificate.

    FAIL-CLOSED: returns COMPLETE only when EVERY required signal for ``scope``
    affirmatively proves it; any hard-negative ⇒ INCOMPLETE; missing / ambiguous
    evidence ⇒ UNVERIFIED (never COMPLETE).  The builder is fail-open on its OWN
    errors — an internal exception yields an UNVERIFIED certificate and never
    raises into the caller.
    """
    try:
        scope = str(scope or "").strip().lower() or SCOPE_QUERY
        om = out_meta if isinstance(out_meta, dict) else {}

        cert = CompletenessCertificate(
            verdict=UNVERIFIED, scope=scope, subject_id=str(subject_id),
            issued_at=issued_at, version=CERT_VERSION,
        )

        # ── evaluate every signal ────────────────────────────────────────
        statuses: Dict[str, str] = {}
        reasons_by_signal: Dict[str, str] = {}
        contributing: List[str] = []
        evidence: Dict[str, Any] = {}

        # completeness
        comp = om.get("completeness")
        if isinstance(comp, dict):
            contributing.append("completeness")
        s, r, ev = _eval_completeness(comp)
        statuses["completeness"] = s
        reasons_by_signal["completeness"] = r
        if ev:
            evidence["completeness"] = ev
            cert.expected_rows = _as_int(ev.get("expected_rows"))
            cert.rows_read = _as_int(ev.get("rows_read"))

        # scan_ledger
        ledger = om.get("scan_ledger")
        if isinstance(ledger, dict):
            contributing.append("scan_ledger")
        s, r, ev = _eval_scan_ledger(ledger)
        statuses["scan_ledger"] = s
        reasons_by_signal["scan_ledger"] = r
        if ev:
            evidence["scan_ledger"] = ev
            cert.files_read = _as_int(ev.get("final"))
            cert.files_expected = _as_int(ev.get("declared_total"))
        if cert.files_expected is None:
            cert.files_expected = _as_int(om.get("snapshot_total_data_files"))

        # pruning_gate — NOT a required signal (many paths never prune), but a
        # present-and-bad verdict is a hard negative like any other.
        _pg = om.get("pruning_gate")
        if isinstance(_pg, dict):
            contributing.append("pruning_gate")
        s_pg, r_pg, ev_pg = _eval_pruning_gate(_pg)
        statuses["pruning_gate"] = s_pg
        reasons_by_signal["pruning_gate"] = r_pg
        if ev_pg:
            evidence["pruning_gate"] = ev_pg

        # file_cap — NOT a required signal (most scans hit no cap), but a
        # present truncation is a hard negative like any other (2026-08-20).
        _fcap = om.get("file_cap")
        if isinstance(_fcap, dict):
            contributing.append("file_cap")
        s_fc, r_fc, ev_fc = _eval_file_cap(_fcap)
        statuses["file_cap"] = s_fc
        reasons_by_signal["file_cap"] = r_fc
        if ev_fc:
            evidence["file_cap"] = ev_fc

        # snapshot
        if om.get("snapshot_id") is not None:
            contributing.append("snapshot")
        s, r, ev = _eval_snapshot(om)
        statuses["snapshot"] = s
        reasons_by_signal["snapshot"] = r
        if ev:
            evidence["snapshot"] = ev
        cert.snapshot_id = None if om.get("snapshot_id") is None else str(om.get("snapshot_id"))
        cert.snapshot_fingerprint = om.get("snapshot_fingerprint")

        # freshness
        if isinstance(om.get("adaptive_freshness"), dict) or om.get("freshness_seconds") is not None:
            contributing.append("freshness")
        s, r, ev, secs, stale = _eval_freshness(om, freshness_bound_seconds)
        statuses["freshness"] = s
        reasons_by_signal["freshness"] = r
        if ev:
            evidence["freshness"] = ev
        cert.freshness_seconds = secs
        cert.is_stale = stale

        # reconciliation (required only for feed/ETL, but always a hard-negative
        # gate when present and broken)
        recon_present = isinstance(reconciliation, dict) and bool(reconciliation)
        if recon_present:
            contributing.append("reconciliation")
        s, r, ev, src, dst = _eval_reconciliation(reconciliation, tolerances)
        statuses["reconciliation"] = s
        reasons_by_signal["reconciliation"] = r
        if ev:
            evidence["reconciliation"] = ev
        cert.source_rows = src
        cert.dest_rows = dst

        # sentinel
        if sentinel_state is not None:
            contributing.append("sentinel")
        s, r, ev = _eval_sentinel(sentinel_state)
        statuses["sentinel"] = s
        reasons_by_signal["sentinel"] = r
        if ev:
            evidence["sentinel"] = ev

        cert.evidence = evidence
        cert.contributing_signals = contributing

        # ── FUSE (fail-closed) ────────────────────────────────────────────
        # 1) ANY hard-negative ⇒ INCOMPLETE.
        hard_negs = [name for name, st in statuses.items() if st == _NEG]
        if hard_negs:
            cert.verdict = INCOMPLETE
            cert.reasons = [reasons_by_signal[n] for n in hard_negs]
            return cert

        # 2) COMPLETE only if EVERY required signal for the scope is OK.
        required = _REQUIRED_BY_SCOPE.get(scope, _REQUIRED_BY_SCOPE[SCOPE_QUERY])
        unproven = [n for n in required if statuses.get(n) != _OK]
        if not unproven:
            cert.verdict = COMPLETE
            cert.reasons = [reasons_by_signal[n] for n in required]
            return cert

        # 3) fail-closed default — required evidence missing/ambiguous.
        cert.verdict = UNVERIFIED
        cert.reasons = [reasons_by_signal[n] for n in unproven]
        return cert

    except Exception as exc:  # FAIL-OPEN on our OWN error — never a false COMPLETE
        logger.debug("[cert] build_certificate failed (fail-closed to UNVERIFIED): %s", exc)
        return CompletenessCertificate(
            verdict=UNVERIFIED,
            scope=str(scope or "").strip().lower() or SCOPE_QUERY,
            subject_id=str(subject_id),
            issued_at=issued_at,
            version=CERT_VERSION,
            reasons=["certificate build error — verdict withheld (fail-closed)"],
        )
