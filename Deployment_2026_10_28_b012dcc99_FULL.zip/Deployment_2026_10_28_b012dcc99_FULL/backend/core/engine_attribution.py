"""WHICH ENGINE ANSWERED -- one vocabulary, stamped once, read everywhere.

2026-09-27.  The product already decided, per execution, whether DuckDB, a
Spark Connect session, a SQL connector (Starburst / Oracle / Snowflake ...)
or a cache produced the rows -- and then threw the decision away:

* ``api/execute_api.py`` persisted its Spark verdict as
  ``update_execution(..., execution_backend="spark_connect")`` while
  ``QueryExecution`` has no such column, so ``setattr`` was skipped by the
  ``hasattr`` guard and nothing was written (a defect found building this);
* the ``execution_completed`` WebSocket event carried ``engine`` on ONE of
  its nine emit sites, and the frontend dropped it;
* the federation engine picked its route in ``_try_execute_to_parquet`` and
  reported only the row count.

So a person looking at a results grid, a report, or the Executions page
could not tell whether their query ran on the source, on DuckDB, or came
from a cache -- and "why is this slow" starts with that.

THIS MODULE IS THE ONE PLACE THE KEYS AND THEIR LABELS LIVE.  A producer
stamps a KEY (the vocabulary below, or a connection type as spelled by
``core/connectors``); every reader turns the key into a label through
:func:`engine_label`.  The frontend mirrors the label table in
``frontend/src/utils/engineLabel.ts`` so a key the backend emits without a
label still renders the same word on every surface.

UNKNOWN IS NOT A LABEL.  ``engine_label(None)`` and ``engine_label("")``
return ``None``, and every surface renders that as "not recorded" -- never
as DuckDB (the common case) and never as an empty chip.
"""
from __future__ import annotations

from typing import Any, Dict, Mapping, Optional

#: Key -> label.  Keys are what producers stamp; labels are what people see.
ENGINE_LABELS: Dict[str, str] = {
    # local engine
    "duckdb":        "DuckDB",
    "single":        "DuckDB",              # execute_api's single-worker key
    "multi_worker":  "DuckDB (parallel)",
    "local":         "DuckDB",
    "s3":            "DuckDB",              # an S3 connection is read by DuckDB
    "hybrid":        "DuckDB + connector",  # federation's S3+connector join
    "cross_source":  "DuckDB (cross-source)",  # execute_api's two-connection combine
    # Spark lanes
    "spark_connect": "Spark",
    "spark_k8s":     "Spark",
    "spark_livy":    "Spark",
    "airflow":       "Spark (Airflow)",
    # caches -- the query did NOT run
    "result_cache":  "Cache",
    "agg_cache":     "Cache (aggregate)",
    "instance":      "Saved result",
    # SQL connectors, by connection type as core/connectors spells them
    "trino":         "Starburst",
    "starburst":     "Starburst",
    "oracle":        "Oracle",
    "snowflake":     "Snowflake",
    "databricks":    "Databricks",
    "athena":        "Athena",
    "postgres":      "PostgreSQL",
    "postgresql":    "PostgreSQL",
    "mysql":         "MySQL",
    "mssql":         "SQL Server",
    "sqlserver":     "SQL Server",
    "rest_api":      "REST source",
}


def engine_label(key: Any) -> Optional[str]:
    """The display label for an engine KEY, or ``None`` when nothing was
    recorded.

    A key this table does not know is returned AS THE KEY: the engine ran and
    was named, only its pretty spelling is missing -- which is a different
    fact from "nobody recorded which engine ran".
    """
    if key is None:
        return None
    k = str(key).strip()
    if not k:
        return None
    return ENGINE_LABELS.get(k.lower(), k)


def engine_for_connection_type(conn_type: Any) -> Optional[str]:
    """The engine key a query on a connection of ``conn_type`` runs on.

    An S3 or local connection is READ BY DUCKDB, so its engine is ``duckdb``;
    every other connection type is its own engine (the query runs at the
    source).  ``None`` for an unknown / empty type -- not a guess.
    """
    t = str(conn_type or "").strip().lower()
    if not t:
        return None
    if t in ("s3", "local", "file", "parquet"):
        return "duckdb"
    return t


def engine_for_routes(s3_conns: Mapping[Any, Any], sql_conns: Mapping[Any, Any]) -> str:
    """The engine key for federation's route choice.

    Mirrors ``FederationEngine._try_execute_to_parquet`` / ``_execute_query``:
    S3 only -> DuckDB; SQL connector only -> that connector (the FIRST one, as
    the engine itself picks); both -> the hybrid DuckDB join; neither -> the
    in-memory DuckDB run.  The engine calls this AFTER the route ran, so the
    key describes what happened, not what was planned.
    """
    if s3_conns and sql_conns:
        return "hybrid"
    if sql_conns:
        first = next(iter(sql_conns.values()), None) or {}
        conn_type = ""
        if isinstance(first, Mapping):
            conn_type = str(first.get("connection_type") or "")
        key = engine_for_connection_type(conn_type)
        return key or "connector"
    return "duckdb"


def engine_for_connector(connector: Any) -> Optional[str]:
    """The engine key of an already-constructed connector, or ``None``.

    ``core.connectors.get_connector`` stamps ``_engine_type`` on the bare
    connector (visible through the circuit-breaker wrapper's ``__getattr__``).
    A connector built elsewhere (a test double, a hand-made instance) is
    named by its class -- ``TrinoConnector`` -> ``trino`` -- when the class
    follows that spelling, and is otherwise NOT guessed.
    """
    if connector is None:
        return None
    for attr in ("_engine_type", "connection_type", "conn_type"):
        try:
            v = getattr(connector, attr, None)
        except Exception:                                    # noqa: BLE001
            v = None
        if isinstance(v, str) and v.strip():
            return engine_for_connection_type(v)
    name = type(connector).__name__
    if name.endswith("Connector") and len(name) > len("Connector"):
        stem = name[: -len("Connector")].lower()
        return {"restapi": "rest_api"}.get(stem, stem)
    return None


def with_engine(payload: Dict[str, Any], key: Any,
                *, field: str = "engine") -> Dict[str, Any]:
    """Return ``payload`` with ``field`` and ``field + '_label'`` set from
    ``key`` -- or unchanged when ``key`` is empty.  For WebSocket events and
    response envelopes, so the pair is always emitted together."""
    label = engine_label(key)
    if label is None:
        return payload
    payload[field] = str(key)
    payload[f"{field}_label"] = label
    return payload


__all__ = [
    "ENGINE_LABELS",
    "engine_label",
    "engine_for_connection_type",
    "engine_for_connector",
    "engine_for_routes",
    "with_engine",
]
