"""
Phase 118 — Cache Abstraction Layer for Multi-Pod Coherence

Provides two cache implementations:
  - LocalCache: Process-local dict + threading.Lock (default, zero-change behavior)
  - RedisBroadcastCache: Extends LocalCache with Redis pub/sub invalidation

Factory function `create_cache()` picks based on config `cache.coherence_mode`.
"""
from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


@dataclass
class CacheStats:
    """Per-cache hit/miss/eviction statistics."""
    name: str
    hits: int = 0
    misses: int = 0
    sets: int = 0
    deletes: int = 0
    evictions: int = 0
    size: int = 0
    max_entries: int = 0
    ttl_seconds: int = 0

    @property
    def hit_rate(self) -> float:
        total = self.hits + self.misses
        return round(self.hits / total, 4) if total > 0 else 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "hits": self.hits,
            "misses": self.misses,
            "sets": self.sets,
            "deletes": self.deletes,
            "evictions": self.evictions,
            "size": self.size,
            "max_entries": self.max_entries,
            "ttl_seconds": self.ttl_seconds,
            "hit_rate": self.hit_rate,
        }


# Sentinel: "this cache has not yet observed any coherence epoch token"
_EPOCH_UNSET = object()


class LocalCache:
    """
    Thread-safe in-memory cache with TTL and LRU eviction.

    Drop-in replacement for the dict+Lock pattern used in 32+ places.

    2026-08-02 — optional MULTI-POD COHERENCE via ``coherence_namespace``:
    when set, every local invalidation (``delete`` / ``delete_prefix`` /
    ``clear``) bumps that namespace's epoch on the Postgres-backed
    :class:`core.cache_coherence.CoherenceBus`, and every ``get`` checks
    (poll-throttled, default one tiny SELECT per 5 s per pod) whether a
    PEER pod bumped it — if so the whole local cache is dropped and
    lazily re-populated.  This is what makes an admin's connection edit
    on pod A reach the schema caches on pods B/C instead of them serving
    the OLD config/schema until TTL (600 s) expiry.

    Semantics: an epoch bump clears the ENTIRE namespace-bound cache, not
    single keys — invalidations here are rare admin events and correctness
    beats the cost of lazily re-fetching a few schemas.  With no namespace
    (the default) behaviour is byte-identical to before: process-local,
    zero DB traffic — N=1 and every existing caller are unchanged.
    All bus interaction is fail-open: bus/DB errors never break cache
    operations, they only defer peers to their pre-existing TTLs.
    """

    def __init__(self, name: str, ttl: int = 600, max_entries: int = 200,
                 coherence_namespace: Optional[str] = None,
                 coherence_bus: Any = None):
        self.name = name
        self.ttl = ttl
        self.max_entries = max_entries
        self._lock = threading.Lock()
        self._data: Dict[str, Tuple[Any, float]] = {}  # key -> (value, expire_at)
        self._access_order: List[str] = []  # LRU tracking
        self._stats = CacheStats(
            name=name, max_entries=max_entries, ttl_seconds=ttl,
        )
        self._coherence_namespace = coherence_namespace
        self._coherence_bus = coherence_bus  # None → module singleton bus
        self._coherence_token_seen: Any = _EPOCH_UNSET

    # ── multi-pod coherence plumbing (no-ops without a namespace) ──────

    def _get_bus(self) -> Any:
        if self._coherence_bus is not None:
            return self._coherence_bus
        from core.cache_coherence import get_bus
        return get_bus()

    def _coherence_sync(self) -> None:
        """Drop the local cache when a PEER pod bumped our namespace epoch.
        Called on the read path; poll-throttled inside the bus."""
        if not self._coherence_namespace:
            return
        try:
            token = self._get_bus().current_token(self._coherence_namespace)
        except Exception as exc:
            logger.debug("cache %s: coherence check failed (fail-open): %s",
                         self.name, exc)
            return
        if self._coherence_token_seen is _EPOCH_UNSET:
            # First observation = baseline; nothing to invalidate yet
            # (a brand-new pod starts with an empty cache anyway).
            self._coherence_token_seen = token
            return
        if token is not None and token != self._coherence_token_seen:
            self._coherence_token_seen = token
            with self._lock:
                dropped = len(self._data)
                self._data.clear()
                self._access_order.clear()
                self._stats.evictions += dropped
                self._stats.size = 0
            if dropped:
                logger.info(
                    "cache %s: dropped %d entries after cross-pod "
                    "invalidation (namespace=%s)",
                    self.name, dropped, self._coherence_namespace)

    def _coherence_publish(self, reason: str) -> None:
        """Announce a local invalidation fleet-wide.  Self-acknowledges the
        new token so THIS pod does not re-clear what it just surgically
        invalidated.  Fail-open: a bus/DB error never breaks the local
        invalidation that already happened.

        Burst throttle: an epoch bump means "peers: clear the whole
        namespace", so a burst of key-by-key deletes (e.g. the admin
        clear-schema-cache endpoint loops over delete()) needs only ONE
        bump — consecutive publishes within 2 s are coalesced instead of
        issuing one system_settings write per key."""
        if not self._coherence_namespace:
            return
        last = getattr(self, "_last_publish_mono", None)
        if last is not None and (time.monotonic() - last) < 2.0:
            return
        try:
            token = self._get_bus().bump(self._coherence_namespace,
                                         reason=f"{self.name}:{reason}")
            if token is not None:
                self._coherence_token_seen = token
                self._last_publish_mono = time.monotonic()
        except Exception as exc:
            logger.debug("cache %s: coherence publish failed (%s, "
                         "fail-open): %s", self.name, reason, exc)

    def get(self, key: str, default: Any = None) -> Any:
        """Get value by key. Returns default if missing or expired.

        Phase 139 (Tier 2.3): also emits a Prometheus hit/miss counter so the
        admin dashboard can show cache effectiveness over time.
        """
        self._coherence_sync()
        outcome_hit = False
        # 2026-08-10 -- bound alongside outcome_hit.  ``_result`` was assigned
        # ONLY in the hit branch and read only under ``if outcome_hit``, so it
        # was correct -- but it made two variables that must move together
        # depend on the reader noticing that they do.  Loosen that return
        # guard and it becomes an UnboundLocalError.
        _result: Any = None
        with self._lock:
            entry = self._data.get(key)
            if entry is None:
                self._stats.misses += 1
                # exit lock then telemetry
            else:
                value, expire_at = entry
                if time.time() > expire_at:
                    # Expired — evict
                    del self._data[key]
                    try:
                        self._access_order.remove(key)
                    except ValueError:
                        pass
                    self._stats.misses += 1
                    self._stats.size = len(self._data)
                else:
                    # Hit — update access order for LRU
                    self._stats.hits += 1
                    try:
                        self._access_order.remove(key)
                    except ValueError:
                        pass
                    self._access_order.append(key)
                    outcome_hit = True
                    _result = value

        # Telemetry — outside the lock to avoid contention. Fail-OPEN.
        try:
            from core.metrics import record_cache_lookup
            record_cache_lookup(self.name, hit=outcome_hit)
        except Exception:
            pass

        # Phase 139 (Tier 2.3): per-user breakdown + recent-misses ring buffer.
        # Username is read from the request context-var set by the middleware.
        try:
            _username = ""
            try:
                from core.user_context import get_current_username
                _username = get_current_username() or ""
            except Exception:
                pass
            if _username:
                record_user_lookup(self.name, _username, outcome_hit)
            if not outcome_hit:
                record_miss(self.name, key, _username)
        except Exception:
            pass

        if outcome_hit:
            return _result
        return default

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        """Set value with optional per-key TTL override. TTL=0 means no expiry.

        2026-08-02: observes the coherence epoch BEFORE inserting so that a
        cache which populates before its first read still has an epoch
        baseline — otherwise a peer-pod invalidation landing between our
        first set() and first get() would be adopted as the baseline and
        silently missed."""
        self._coherence_sync()
        effective_ttl = ttl if ttl is not None else self.ttl
        expire_at = float("inf") if effective_ttl == 0 else time.time() + effective_ttl
        with self._lock:
            self._data[key] = (value, expire_at)
            try:
                self._access_order.remove(key)
            except ValueError:
                pass
            self._access_order.append(key)
            self._stats.sets += 1
            self._stats.size = len(self._data)
            # LRU eviction
            while len(self._data) > self.max_entries and self._access_order:
                oldest = self._access_order.pop(0)
                self._data.pop(oldest, None)
                self._stats.evictions += 1
            self._stats.size = len(self._data)

    def delete(self, key: str) -> bool:
        """Delete a specific key. Returns True if key existed."""
        with self._lock:
            existed = key in self._data
            self._data.pop(key, None)
            try:
                self._access_order.remove(key)
            except ValueError:
                pass
            if existed:
                self._stats.deletes += 1
            self._stats.size = len(self._data)
        if existed:
            self._coherence_publish("delete")
        return existed

    def delete_prefix(self, prefix: str) -> int:
        """BF-555 (2026-05-29): drop every key starting with ``prefix``.
        Used by the connection-update endpoint to invalidate every
        schema-cache entry tied to one connection in a single call.
        Returns count dropped."""
        if not prefix:
            return 0
        with self._lock:
            to_drop = [k for k in self._data if k.startswith(prefix)]
            for k in to_drop:
                self._data.pop(k, None)
                try:
                    self._access_order.remove(k)
                except ValueError:
                    pass
            if to_drop:
                self._stats.deletes += len(to_drop)
                self._stats.size = len(self._data)
            dropped = len(to_drop)
        if dropped:
            self._coherence_publish("delete_prefix")
        return dropped

    def clear(self) -> int:
        """Clear all entries. Returns count of entries cleared."""
        with self._lock:
            count = len(self._data)
            self._data.clear()
            self._access_order.clear()
            self._stats.size = 0
        if count:
            self._coherence_publish("clear")
        return count

    def stats(self) -> CacheStats:
        """Return copy of current statistics."""
        with self._lock:
            self._stats.size = len(self._data)
            return CacheStats(
                name=self._stats.name,
                hits=self._stats.hits,
                misses=self._stats.misses,
                sets=self._stats.sets,
                deletes=self._stats.deletes,
                evictions=self._stats.evictions,
                size=self._stats.size,
                max_entries=self._stats.max_entries,
                ttl_seconds=self._stats.ttl_seconds,
            )

    def keys(self) -> List[str]:
        """Return list of current (non-expired) keys."""
        now = time.time()
        with self._lock:
            return [k for k, (_, exp) in self._data.items() if now <= exp]

    def __contains__(self, key: str) -> bool:
        with self._lock:
            entry = self._data.get(key)
            if entry is None:
                return False
            _, expire_at = entry
            return time.time() <= expire_at

    def __len__(self) -> int:
        return len(self._data)


class RedisBroadcastCache(LocalCache):
    """
    Extends LocalCache with Redis pub/sub invalidation for multi-pod coherence.

    On set/delete/clear, publishes an invalidation message to Redis.
    A background subscriber thread listens and evicts from local cache.
    """

    def __init__(
        self,
        name: str,
        ttl: int = 600,
        max_entries: int = 200,
        redis_client: Any = None,
        channel_prefix: str = "qs:cache:",
    ):
        super().__init__(name, ttl, max_entries)
        self._redis = redis_client
        self._channel = f"{channel_prefix}{name}"
        self._pod_id = f"{threading.get_ident()}-{id(self)}"
        self._subscriber_thread: Optional[threading.Thread] = None

        if self._redis:
            self._start_subscriber()

    def _start_subscriber(self) -> None:
        """Start background thread listening for invalidation messages."""
        def _listen():
            try:
                pubsub = self._redis.pubsub()
                pubsub.subscribe(self._channel)
                for message in pubsub.listen():
                    if message["type"] != "message":
                        continue
                    try:
                        data = message["data"]
                        if isinstance(data, bytes):
                            data = data.decode("utf-8")
                        # Format: "pod_id:action:key"
                        parts = data.split(":", 2)
                        if len(parts) < 2:
                            continue
                        sender_pod, action = parts[0], parts[1]
                        key = parts[2] if len(parts) > 2 else ""

                        # Skip messages from self
                        if sender_pod == self._pod_id:
                            continue

                        if action == "delete":
                            super(RedisBroadcastCache, self).delete(key)
                        elif action == "clear":
                            super(RedisBroadcastCache, self).clear()
                        elif action == "set":
                            # Invalidate stale local copy — peer has newer data
                            super(RedisBroadcastCache, self).delete(key)
                    except Exception:
                        pass  # best-effort
            except Exception as e:
                logger.warning("cache_subscriber_error", cache=self.name, error=str(e))

        self._subscriber_thread = threading.Thread(
            target=_listen, daemon=True, name=f"cache-sub-{self.name}",
        )
        self._subscriber_thread.start()

    def _publish(self, action: str, key: str = "") -> None:
        """Publish invalidation message to Redis."""
        if not self._redis:
            return
        try:
            msg = f"{self._pod_id}:{action}:{key}"
            self._redis.publish(self._channel, msg)
        except Exception as e:
            logger.warning("cache_publish_error", cache=self.name, error=str(e))

    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        super().set(key, value, ttl)
        self._publish("set", key)

    def delete(self, key: str) -> bool:
        existed = super().delete(key)
        if existed:
            self._publish("delete", key)
        return existed

    def delete_prefix(self, prefix: str) -> int:
        """BF-555: same prefix-delete contract as LocalCache, plus a
        single broadcast announcing the prefix so peer pods invalidate
        their L1 too."""
        dropped = super().delete_prefix(prefix)
        if dropped:
            self._publish("delete_prefix", prefix)
        return dropped

    def clear(self) -> int:
        count = super().clear()
        self._publish("clear")
        return count


# ── Registry of all cache instances ──────────────────────────────────────────

_cache_registry: Dict[str, LocalCache] = {}
_registry_lock = threading.Lock()


# ── Phase 139 (Tier 2.3) — recent-misses ring buffer + per-user breakdown ──
# Bounded ring buffer of recent cache misses across ALL layers. Helps spot
# patterns like "user keeps adding trivial whitespace and missing cache".
_RECENT_MISSES_MAX = 500
_recent_misses_lock = threading.Lock()
_recent_misses: List[Dict[str, Any]] = []

# Per-user, per-layer hit/miss counters. Used for the admin per-user table.
# Bounded to last N users to avoid unbounded growth.
_PER_USER_MAX_USERS = 200
_per_user_lock = threading.Lock()
_per_user_stats: Dict[str, Dict[str, Dict[str, int]]] = {}
# Shape: { username: { layer_name: { "hits": int, "misses": int } } }


def record_miss(layer: str, key: str, username: Optional[str] = None) -> None:
    """Append a miss record to the ring buffer. Bounded — oldest evicted first."""
    import time as _t
    with _recent_misses_lock:
        _recent_misses.append({
            "layer":    layer,
            "key":      str(key)[:512],  # truncate huge keys
            "username": username or "",
            "ts":       _t.time(),
        })
        while len(_recent_misses) > _RECENT_MISSES_MAX:
            _recent_misses.pop(0)


def get_recent_misses(limit: int = 100) -> List[Dict[str, Any]]:
    """Snapshot the recent-misses ring (newest first)."""
    from datetime import datetime, timezone
    with _recent_misses_lock:
        recent = list(_recent_misses[-limit:])
    # Reverse so newest is first; ISO-format the timestamp for JSON
    out = []
    for r in reversed(recent):
        out.append({
            "layer":    r["layer"],
            "key":      r["key"],
            "username": r["username"],
            "ts":       datetime.fromtimestamp(r["ts"], timezone.utc).isoformat(),
        })
    return out


def record_user_lookup(layer: str, username: str, hit: bool) -> None:
    """Increment per-user hit/miss counters.

    Phase 139 fix: true LRU bound on user count. On each access we remove
    and re-insert the user so dict iteration order tracks recency. When over
    cap we evict the oldest accessed user (head of insertion order). The
    previous FIFO behaviour evicted the user who showed up FIRST even if
    they were the most active — that's wrong for a quota-style telemetry.
    """
    if not username:
        return
    with _per_user_lock:
        if username in _per_user_stats:
            # Touch — move to end so it's "most recently accessed"
            _per_user_stats[username] = _per_user_stats.pop(username)
        else:
            # LRU eviction when at cap
            while len(_per_user_stats) >= _PER_USER_MAX_USERS:
                try:
                    oldest_user = next(iter(_per_user_stats))
                    _per_user_stats.pop(oldest_user, None)
                except StopIteration:
                    break
            _per_user_stats[username] = {}
        user_stats = _per_user_stats[username]
        layer_stats = user_stats.setdefault(layer, {"hits": 0, "misses": 0})
        if hit:
            layer_stats["hits"] += 1
        else:
            layer_stats["misses"] += 1


def get_per_user_stats() -> Dict[str, Dict[str, Dict[str, Any]]]:
    """Return per-user, per-layer hit/miss stats with computed hit_rate."""
    with _per_user_lock:
        out: Dict[str, Dict[str, Dict[str, Any]]] = {}
        for user, layers in _per_user_stats.items():
            out[user] = {}
            for layer, counts in layers.items():
                total = counts["hits"] + counts["misses"]
                out[user][layer] = {
                    "hits":     counts["hits"],
                    "misses":   counts["misses"],
                    "hit_rate": round(counts["hits"] / total, 4) if total > 0 else 0.0,
                }
        return out


def clear_recent_misses() -> int:
    with _recent_misses_lock:
        n = len(_recent_misses)
        _recent_misses.clear()
    return n


def clear_per_user_stats() -> int:
    with _per_user_lock:
        n = len(_per_user_stats)
        _per_user_stats.clear()
    return n


# 2026-08-02 — caches whose contents are derived from CONNECTION CONFIG
# (endpoints, credentials, catalogs).  A connection edit on one pod MUST
# invalidate these on every pod, so the factory binds them to the
# "connections" coherence namespace without their creators (e.g.
# api/connections_api.py) having to change.  Everything else stays
# process-local (pure performance caches — duplicate work, never wrong
# answers).
_DEFAULT_COHERENCE_NAMESPACES: Dict[str, str] = {
    "schema":    "connections",   # api/connections_api._schema_cache
    "partition": "connections",   # api/connections_api._partition_cache
}


def create_cache(
    name: str,
    ttl: int = 600,
    max_entries: int = 200,
    coherence_mode: str = "local",
    redis_client: Any = None,
    coherence_namespace: Optional[str] = None,
) -> LocalCache:
    """
    Factory function to create a cache instance.

    coherence_mode:
      - "local": Standard LocalCache (default, zero-change behavior)
      - "redis_broadcast": RedisBroadcastCache with pub/sub invalidation

    coherence_namespace: optional Postgres-backed cross-pod invalidation
    namespace (see LocalCache docstring).  Defaults from
    ``_DEFAULT_COHERENCE_NAMESPACES`` for known correctness-bearing
    caches; None keeps the cache purely process-local.
    """
    if coherence_namespace is None:
        coherence_namespace = _DEFAULT_COHERENCE_NAMESPACES.get(name)
    with _registry_lock:
        if name in _cache_registry:
            return _cache_registry[name]

        if coherence_mode == "redis_broadcast" and redis_client:
            cache = RedisBroadcastCache(
                name=name, ttl=ttl, max_entries=max_entries,
                redis_client=redis_client,
            )
            cache._coherence_namespace = coherence_namespace
            logger.info("cache_created cache=%s mode=redis_broadcast ttl=%d max=%d",
                        name, ttl, max_entries)
        else:
            cache = LocalCache(name=name, ttl=ttl, max_entries=max_entries,
                               coherence_namespace=coherence_namespace)
            logger.info("cache_created cache=%s mode=local ttl=%d max=%d ns=%s",
                        name, ttl, max_entries, coherence_namespace or "-")

        _cache_registry[name] = cache
        return cache


def get_all_cache_stats() -> List[Dict[str, Any]]:
    """Return stats for all registered caches."""
    with _registry_lock:
        return [c.stats().to_dict() for c in _cache_registry.values()]


def get_cache(name: str) -> Optional[LocalCache]:
    """Get a registered cache by name."""
    with _registry_lock:
        return _cache_registry.get(name)
