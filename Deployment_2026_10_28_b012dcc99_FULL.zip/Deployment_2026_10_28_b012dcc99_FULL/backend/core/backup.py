"""
Automated database backup — SQLite (file copy) and PostgreSQL (pg_dump).

Registered as an APScheduler job when `backup.enabled=true` in config.
"""
from __future__ import annotations

import glob
import logging
import os
import shutil
import subprocess
from datetime import datetime

_log = logging.getLogger(__name__)


def _resolve_pg_dump() -> str:
    """Absolute path of the ``pg_dump`` to run — explicit, else PATH.

    ``backup.pg_dump_path`` (declared in ``core/config.py`` ``_DEFAULTS``;
    an undeclared key would make this vacuous) pins the binary for hosts
    whose PATH is not under the operator's sole control.  Empty means
    "resolve on PATH", which is the previous behaviour made VISIBLE rather
    than implicit.

    Fails LOUDLY when nothing resolves.  The alternative — hand the bare
    name to the OS and let it fail — produced a FileNotFoundError with no
    indication that the problem was a missing postgres client, and a
    backup that never runs is a backup nobody notices is missing.
    """
    try:
        from core import config as _cfg
        pinned = (_cfg.backup.pg_dump_path or "").strip()
    except Exception:
        pinned = ""
    if pinned:
        if not os.path.isabs(pinned):
            raise RuntimeError(
                f"backup.pg_dump_path must be an ABSOLUTE path, got "
                f"{pinned!r} — a relative pin re-opens the PATH search it "
                "exists to close")
        if not os.path.isfile(pinned):
            raise RuntimeError(f"backup.pg_dump_path {pinned!r} does not exist")
        return pinned
    found = shutil.which("pg_dump")
    if not found:
        raise RuntimeError(
            "pg_dump not found on PATH — install the postgres client on "
            "this image or set backup.pg_dump_path to its absolute path")
    return os.path.abspath(found)


def perform_backup(db_url: str, backup_dir: str, retention_count: int = 7) -> str:
    """Create a database backup and enforce retention.

    Args:
        db_url: SQLAlchemy-style database URL.
        backup_dir: Directory to store backups.
        retention_count: Max number of backup files to keep.

    Returns:
        Path to the created backup file, or "" on unsupported DB type.
    """
    os.makedirs(backup_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    if db_url.startswith("sqlite"):
        db_path = db_url.replace("sqlite:///", "").replace("sqlite://", "")
        if not os.path.isfile(db_path):
            _log.warning("Backup skipped: SQLite file not found at %s", db_path)
            return ""
        backup_path = os.path.join(backup_dir, f"backup_{timestamp}.db")
        shutil.copy2(db_path, backup_path)
    elif db_url.startswith("postgresql"):
        backup_path = os.path.join(backup_dir, f"backup_{timestamp}.sql")
        # BF-409 — parse URL into env vars so pg_dump doesn't prompt for
        # the password (was blocking the backup scheduler entirely when
        # the URL contained credentials).  Passing the URL directly on the
        # CLI also leaks the password into `ps` output; PGPASSWORD env
        # var is the documented safe pattern.
        from urllib.parse import urlparse, unquote
        u = urlparse(db_url)
        env = os.environ.copy()
        if u.password:
            env["PGPASSWORD"] = unquote(u.password)
        if u.username:
            env["PGUSER"] = unquote(u.username)
        if u.hostname:
            env["PGHOST"] = u.hostname
        if u.port:
            env["PGPORT"] = str(u.port)
        if u.path and u.path.lstrip("/"):
            env["PGDATABASE"] = u.path.lstrip("/")
        # `sslmode` may be in the query string — propagate to pg_dump too
        from urllib.parse import parse_qs
        qs = parse_qs(u.query or "")
        if "sslmode" in qs and qs["sslmode"]:
            env["PGSSLMODE"] = qs["sslmode"][0]
        # 2026-09-13 security-hotspot triage (ruff S607/S603).
        #
        # S607 — this used to be the bare string "pg_dump", which makes the
        # OS search PATH at run time.  Whatever `pg_dump` resolves to first
        # then runs as the backend process, with PGPASSWORD already in its
        # environment, so a writable early PATH entry turns the backup
        # scheduler into a credential handout.  Writing to a PATH directory
        # normally means the host is already lost, so this is hardening and
        # not a live hole — but "which binary made this backup?" was
        # unanswerable from the logs, and that is worth fixing on its own.
        # We now resolve ONCE to an absolute path, log it, and pass that.
        #
        # S603 (no shell) is correct as it stands and stays: argv is a
        # LIST, shell=False, and no element is caller-controlled —
        # backup_path is built here from a strftime timestamp and the
        # admin-configured backup_dir, never from a request.  The database
        # URL is deliberately NOT on the command line (BF-409): it would
        # leak the password into `ps`, so credentials go via env.
        exe = _resolve_pg_dump()
        _log.info("Running pg_dump: %s -f %s", exe, backup_path)
        result = subprocess.run(
            [exe, "-f", backup_path],           # no URL arg → uses env vars
            capture_output=True, text=True, timeout=300, env=env,
        )
        if result.returncode != 0:
            _log.error("pg_dump failed (rc=%d): %s", result.returncode, result.stderr[:500])
            raise RuntimeError(f"pg_dump failed: {result.stderr[:500]}")
    else:
        _log.warning("Backup not supported for DB type: %s", db_url[:20])
        return ""

    _cleanup_old_backups(backup_dir, retention_count)
    _log.info("Backup created: %s", backup_path)
    return backup_path


def _cleanup_old_backups(backup_dir: str, keep: int) -> None:
    """Remove oldest backups beyond *keep* count."""
    files = sorted(
        glob.glob(os.path.join(backup_dir, "backup_*")),
        key=os.path.getmtime,
    )
    if len(files) > keep:
        for old in files[:-keep]:
            try:
                os.remove(old)
                _log.info("Removed old backup: %s", old)
            except OSError as exc:
                _log.warning("Failed to remove old backup %s: %s", old, exc)
