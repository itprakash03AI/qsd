"""
Cross-Source Engine -- the SQL-statement entry points.

  * ``execute_single_source_query`` -- one statement on one SQL connector,
    streamed to parquet (the SQL page's single-source run, scheduled
    ``sql_query`` jobs, raw-SQL reports).
  * ``execute_cross_source_sql`` -- two statements on two connections of
    ANY supported type, combined.  A thin adapter onto THE cross-source
    capability, ``core.executors.cross_source_combine.execute_cross_source``.

2026-10-04 -- the three in-memory engines that lived here are GONE:
``execute_cross_source_query`` (SQL x SQL, ``pd.merge``, JOIN only, the
row limit capping each SIDE), ``execute_hybrid_query`` (SQL x parquet,
``pd.merge``) and ``execute_cross_parquet_query`` (parquet x parquet,
``pd.concat`` / ``pd.merge``).  They were three of the four answers to
"how are two sources combined", each with its own gaps (no UNION on the
SQL page, the secondary of a storage side refused, a side capped before
the join).  Their callers now go through ``execute_cross_source_sql``.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

from .connectors import get_connector

logger = logging.getLogger(__name__)


# ── Output directory resolution (2026-08-09 cross-pod completion #2) ──────────
#
# The four engine entry points used to DEFAULT ``output_dir`` to the
# hardcoded pod-local path below while several call sites omitted the
# argument — cross-pod, an artifact written there is invisible to every
# other pod (and to the BR sync path, which reads the CONFIGURED
# ``paths.downloads_dir``, business_reports_api._execute_raw_sql_report).
# The default now resolves from config AT CALL TIME so a future call site
# that omits ``output_dir`` cannot reintroduce the split.  The legacy
# literal survives only as the last-ditch fallback for a broken config
# import — never as a signature default.

_LEGACY_OUTPUT_DIR = "/usr/local/querystudioapi/data/downloads"


def _default_output_dir() -> str:
    """The configured shared downloads dir (``core.config.paths.downloads_dir``
    — the same source the BR raw_sql reader uses), resolved at call time."""
    try:
        from core.config import paths as _paths
        d = str(_paths.downloads_dir)
        if d:
            return d
    except Exception as exc:  # pragma: no cover — config is always importable
        logger.error("cross_source_engine: could not resolve configured "
                     "downloads dir (%s) — falling back to legacy pod-local "
                     "path %s", exc, _LEGACY_OUTPUT_DIR)
    return _LEGACY_OUTPUT_DIR


# ── Result model ──────────────────────────────────────────────────────────────

class CrossSourceResult:
    def __init__(
        self,
        execution_id: str,
        total_rows: int,
        columns: List[str],
        duration_seconds: float,
        primary_rows: int,
        secondary_rows: int,
        df: Optional["pd.DataFrame"] = None,
        output_path: str = "",
        disclosure: Optional[Dict[str, Any]] = None,
    ):
        self.execution_id    = execution_id
        self.df              = df           # held in memory; None if result was saved to disk
        self.output_path     = output_path  # non-empty only when CSV was explicitly saved
        self.total_rows      = total_rows
        self.columns         = columns
        self.duration_seconds = duration_seconds
        self.primary_rows    = primary_rows
        self.secondary_rows  = secondary_rows
        # 2026-10-04 -- what a cross-source combine did (rows per side, caps
        # hit, key casts, pushdown), in the one disclosure vocabulary of
        # ``CombineOutcome.disclosure()``.  None on a single-source result.
        self.disclosure      = disclosure

    @property
    def truncated(self) -> bool:
        return bool((self.disclosure or {}).get("truncated"))

    def to_dict(self) -> Dict[str, Any]:
        return {
            "execution_id":     self.execution_id,
            "output_path":      self.output_path,
            "total_rows":       self.total_rows,
            "columns":          self.columns,
            "duration_seconds": self.duration_seconds,
            "primary_rows":     self.primary_rows,
            "secondary_rows":   self.secondary_rows,
        }


def _acquire(conn_id, conn_type, conn_config, name=""):
    """Borrow a connector when we know WHICH connection it is, else build one.

    2026-09-16.  This engine took connection TYPE and CONFIG but never an id,
    so it could not pool: the pool key is ``(connection_id,
    config_identity)``, and while config_identity alone isolates callers
    correctly, filing pools under a sentinel id would break
    ``invalidate_pool(connection_id)`` -- a connection edited in the UI would
    keep serving connectors built from the old settings.  The id is now
    threaded from the callers, all three of which had the connection dict in
    hand, and it stays OPTIONAL: ``None`` falls back to the unpooled path
    this engine has always used, unchanged.

    Returns a context manager either way, so the call sites read the same.
    """
    if conn_id is None:
        import contextlib

        @contextlib.contextmanager
        def _unpooled():
            # The MODULE-LEVEL get_connector on purpose, not a local import.
            # tests/test_sonar_cross_source_engine_2026_08_27.py patches
            # ``CSE.get_connector``; a function-local import resolves through
            # core.connectors directly and silently bypasses that patch, so
            # the fake is never used and a real connector gets constructed.
            # Same class as the 2026-08-18 import sweep that moved @patch
            # targets out from under seven tests.
            c = get_connector(conn_type, conn_config)
            try:
                yield c
            finally:
                try:
                    c.close()
                except Exception as exc:
                    logging.getLogger(__name__).warning(
                        "%s failed: %s", "cross_source_engine", exc,
                        exc_info=True)

        return _unpooled()
    from core.connection_pool import get_pooled_connector
    return get_pooled_connector(int(conn_id), conn_type, conn_config, name or "")


# ── Engine ────────────────────────────────────────────────────────────────────

def execute_single_source_query(
    *,
    conn_type:   str,
    conn_config: Dict[str, Any],
    sql:         str,
    output_dir:  Optional[str] = None,   # None → configured downloads dir
    execution_id: Optional[str] = None,
    row_limit:   Optional[int] = None,
    progress_callback=None,
    save_csv:    bool = True,
    consumer:    Any = None,
    cancel_event=None,
    conn_id:     Optional[int] = None,
    conn_name:   str = "",
) -> CrossSourceResult:
    """
    Execute SQL on a single SQL connector (no join) and save result as CSV.
    Used when the query runs on exactly one SQL source.

    2026-09-17 — ``conn_id``/``conn_name``.  This function took TYPE and
    CONFIG but never an id, so it built a fresh connector for every query
    and closed it, while its cross-source sibling (which does receive
    ``primary_conn_id``) has pooled since 2026-09-16.  ``POST
    /api/sql/execute`` routes the SINGLE-source case here, so the most
    common query in the product was the one path that never reused a
    connection — proven on a live container, where the pool stayed at
    ``idle=0`` across repeated executes while a catalog browse took it to
    1.  The id is OPTIONAL and ``None`` keeps the create-and-close
    behaviour every existing caller has always had, unchanged.

    Phase 131 deep-dive #11 (post-deferral): ``consumer`` (feed_config
    dict / api_user dict / username string / None) is passed to the
    credential resolver for S3-backed conn_types (athena / s3) so
    portal-auth connections work for the triggering user.  For pure
    SQL connectors (snowflake / trino / oracle / databricks) the
    consumer is a no-op — those use static credentials from config.
    """
    output_dir = output_dir or _default_output_dir()
    execution_id = execution_id or str(uuid.uuid4())
    t_start = datetime.now(timezone.utc)

    def _emit(step: str, **kwargs):
        if progress_callback:
            try:
                progress_callback({"step": step, "execution_id": execution_id, **kwargs})
            except Exception as exc:
                logging.getLogger(__name__).warning("%s failed: %s", "cross_source_engine", exc, exc_info=True)

    _emit("starting", message="Executing SQL query")
    connector = None
    _conn_cm = None
    _conn_exc: Optional[BaseException] = None
    try:
        # Phase 131 deep-dive #11 — resolve S3-backed credentials for
        # the triggering user.  Pure SQL connectors are pass-through.
        if conn_type in ("s3", "athena"):
            try:
                from core.credential_resolver import resolve_s3_for_consumer
                # BF-461: cross-source queries fan out to multiple connectors;
                # if any side's creds are near expiry, refresh BEFORE the
                # parallel fan-out kicks off.
                from core.config import aws_portal as _ap_cfg
                conn_config = resolve_s3_for_consumer(
                    conn_config, consumer,
                    min_lifetime_seconds=_ap_cfg.preflight_min_lifetime_seconds,
                )
            except Exception as _cred_exc:
                logging.getLogger(__name__).warning(
                    "[cross_source_engine] credential resolution failed for %s: %s — "
                    "falling back to raw config",
                    conn_type, _cred_exc,
                )
        # _acquire returns a context manager either way: pooled when we know
        # WHICH connection this is, the create-and-close path when we do not.
        _conn_cm = _acquire(conn_id, conn_type, conn_config, conn_name)
        connector = _conn_cm.__enter__()

        # Phase 153 strategic chokepoint: when we don't need the DataFrame
        # in memory (save_csv=True is the common path), stream directly
        # from connector -> parquet via the chokepoint helper.
        # Peak memory = chunk_size * row_bytes * queue_maxsize (NOT all-rows).
        # Closes the 170M-row Trino-report OOM gap.
        from core.connector_to_parquet import (
            execute_sql_to_parquet, execute_sql_to_dataframe,
        )

        output_path = ""
        if save_csv:
            out_dir = Path(output_dir)
            out_dir.mkdir(parents=True, exist_ok=True)
            output_path = str(out_dir / f"{execution_id}.parquet")
            meta = execute_sql_to_parquet(
                connector, sql, output_path,
                row_limit=row_limit, cancel_event=cancel_event,
            )
            n_rows = meta.get("total_rows", 0)
            col_defs = meta.get("columns") or []
            col_names = [c.get("name", "") for c in col_defs]
            df = None  # not loaded -- caller contract allows .df=None when saved.
        else:
            df, col_defs, n_rows = execute_sql_to_dataframe(
                connector, sql,
                row_limit=row_limit, cancel_event=cancel_event,
            )
            col_names = list(df.columns)

        _emit("query_done", message=f"{n_rows} rows returned", total_rows=n_rows)
        duration = (datetime.now(timezone.utc) - t_start).total_seconds()
        _emit("completed", message=f"Completed in {duration:.1f}s", total_rows=n_rows)

        return CrossSourceResult(
            execution_id=execution_id,
            df=df,
            output_path=output_path,
            total_rows=n_rows,
            columns=col_names,
            duration_seconds=round(duration, 3),
            primary_rows=n_rows,
            secondary_rows=0,
        )
    except BaseException as _exc:
        # Recorded, not sniffed.  ``sys.exc_info()`` inside the finally would
        # also report an exception this call is merely running INSIDE of --
        # call this from within an ``except:`` handler and a perfectly good
        # connector gets discarded on every clean query, silently undoing the
        # pooling.  Only an exception that actually escaped THIS block means
        # the connector is suspect.
        _conn_exc = _exc
        raise
    finally:
        if _conn_cm is not None:
            # A connector whose query raised must be DISCARDED, not returned
            # to the pool for the next caller -- releasing a broken one is how
            # a single transport failure becomes every subsequent query's
            # failure.  get_pooled_connector.__exit__ makes that decision from
            # the exception triple it is handed.
            try:
                if _conn_exc is not None:
                    _conn_cm.__exit__(type(_conn_exc), _conn_exc,
                                      _conn_exc.__traceback__)
                else:
                    _conn_cm.__exit__(None, None, None)
            except Exception as exc:
                logging.getLogger(__name__).warning("%s failed: %s", "cross_source_engine", exc, exc_info=True)


# ═══════════════════════════════════════════════════════════════════════════════
# Cross-source: two statements, two connections of ANY type, combined
# ═══════════════════════════════════════════════════════════════════════════════

def execute_cross_source_sql(
    *,
    primary_conn: Dict[str, Any],
    primary_sql: Optional[str],
    secondary_conn: Dict[str, Any],
    secondary_sql: Optional[str],
    spec: Any = None,
    combine_mode: Optional[str] = None,
    join_config: Optional[Dict[str, Any]] = None,
    output_dir: Optional[str] = None,   # None -> configured downloads dir
    execution_id: Optional[str] = None,
    row_limit: Optional[int] = None,
    side_row_cap: Optional[int] = None,
    progress_callback=None,
    cancel_event=None,
    db_manager: Any = None,
    primary_producer=None,
    secondary_producer=None,
) -> CrossSourceResult:
    """Run each side on ITS engine and combine -- through THE capability.

    ``primary_conn`` / ``secondary_conn`` are connection records (``id``,
    ``connection_type``, ``config``, ``name``) of any type the capability
    reads (every SQL connector, ``s3``, ``local``); each side's SQL arrives
    FINAL and SECURED in that side's dialect -- this adapter runs it, it
    never rewrites it.  A side whose rows come from somewhere other than a
    statement (a JSON query config over a parquet directory) passes a
    ``*_producer`` instead (see ``SideSpec``).

    ``spec`` is a ``CombineSpec``; without one, ``combine_mode`` +
    ``join_config`` are read through ``combine_spec`` (blank mode = JOIN
    when keys are given, else UNION).  ``row_limit`` bounds the COMBINED
    result (None / 0 = unlimited) and a cut is disclosed only when a row
    past it existed; ``side_row_cap`` bounds each side, disclosed per side.

    Raises -- never returns a one-sided result.
    """
    from core.executors.cross_source_combine import (
        SideSpec, combine_spec, execute_cross_source)

    output_dir = output_dir or _default_output_dir()
    execution_id = execution_id or str(uuid.uuid4())
    t_start = datetime.now(timezone.utc)
    if spec is None:
        spec = combine_spec(combine_mode, join_config or {})

    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    output_path = str(out_dir / f"{execution_id}.parquet")

    def _progress(evt: Dict[str, Any]) -> None:
        if progress_callback:
            try:
                progress_callback(evt)
            except Exception as exc:
                logger.warning("progress_callback failed: %s", exc,
                               exc_info=True)

    outcome = execute_cross_source(
        SideSpec("primary", connection=primary_conn, sql=primary_sql,
                 producer=primary_producer),
        SideSpec("secondary", connection=secondary_conn, sql=secondary_sql,
                 producer=secondary_producer),
        spec, output_path,
        row_limit=row_limit, side_row_cap=side_row_cap,
        cancel_event=cancel_event, progress=_progress,
        db_manager=db_manager, execution_id=execution_id,
    )
    duration = (datetime.now(timezone.utc) - t_start).total_seconds()
    return CrossSourceResult(
        execution_id=execution_id,
        total_rows=outcome.total_rows,
        columns=list(outcome.columns),
        duration_seconds=round(duration, 3),
        primary_rows=outcome.primary_rows,
        secondary_rows=outcome.secondary_rows,
        output_path=output_path,
        disclosure=outcome.disclosure(),
    )
