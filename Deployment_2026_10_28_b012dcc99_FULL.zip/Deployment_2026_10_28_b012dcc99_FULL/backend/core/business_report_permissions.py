"""Phase 157 (2026-06-26) -- Business Report Permissions chokepoint.

Single source of truth for ``who can do what`` on a Business Report.

Pre-Phase-157 the access checks were SCATTERED across:
  * business_reports_api -- list filter + per-endpoint guards
  * reports_api          -- _br_can_view wrapper + duplicate logic
  * Front-end role-whitelist hint
  * Share + embed token paths

That patch-pile was the cause of the 2026-05-17 "RLS bypass on report
execution" CRITICAL security incident.  Phase 157 collapses every
check into ONE module so audit + future hardening lands in one place.

Public API:
  * can_view(report, user)     -- can the user see the report card?
  * can_run(report, user)      -- can they execute / change filters?
  * can_edit(report, user)     -- can they modify the definition?
  * can_share(report, user)    -- can they grant access / mint tokens?
  * effective_access(report)   -- list of (subject, level, source)
                                   for the audit UI
  * request_access(...)        -- user clicks "Request access"
  * approve_access(...)        -- owner approves a pending request
  * deny_access(...)           -- owner denies a pending request
  * request_certification(...) -- author requests is_certified=True
  * approve_certification(...) -- admin approves
  * deny_certification(...)    -- admin denies
  * add_grant / remove_grant   -- owner-issued explicit grants
  * record_event               -- append-only audit log

Permission resolution order (FIRST match wins):
  1. Admin override (role contains admin / superuser).
  2. Owner equality (report.owner == user.username).
  3. Owner group membership (user in users_group_members for
     report.owner_group_id) -- owner-equivalent.
  4. Explicit grant (BusinessReportGrant by username AND not expired).
  5. Group grant (BusinessReportGrant by group_id where user is member,
     AND not expired).
  6. Published + role_whitelist match (legacy compat).
  7. Default DENY.

Level semantics (later levels imply earlier):
  view < runner < editor < owner

Fail-CLOSED at every edge.  When an exception fires inside the
service, the answer is DENY -- never silently approve.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ── Level hierarchy ─────────────────────────────────────────────────


_LEVEL_RANK = {"view": 1, "runner": 2, "editor": 3, "owner": 4}


import logging as _logging

from core.roles import is_admin_like as _canonical_is_admin

_log = _logging.getLogger(__name__)


def _level_at_least(have: str, need: str) -> bool:
    """``have`` level implies ``need`` level?  Owner implies all."""
    return _LEVEL_RANK.get((have or "").lower(), 0) >= _LEVEL_RANK.get(
        (need or "").lower(), 0
    )


# ── User context helpers ────────────────────────────────────────────


def _is_admin(user: Optional[Dict[str, Any]]) -> bool:
    # 2026-08-20 -- DELEGATE.  This was a private sixth answer to "is this
    # user an admin?" and it disagreed with core.roles.is_admin_like -- the
    # self-declared single source of truth -- in BOTH directions:
    #
    #   {"is_admin": True, "role": "viewer"}  canonical True   here False
    #   {"role": "Admin"}                     canonical False  here True
    #   {"roles": ["admin"]}                  canonical False  here True
    #
    # Live consequence: reports/authorization.py ORs this with the canonical
    # check for the report LIST route, while effective_level() below uses
    # only this one -- so a pre-shaped {"is_admin": True} principal was an
    # admin on the list screen and a stranger on the access-level route.
    #
    # CONVERGED ON THE STRICTER BEHAVIOUR, deliberately.  My first attempt
    # moved this copy's case-folding and ``roles``-list handling INTO the
    # canonical function, which made the two agree by WIDENING authorization.
    # tests/test_feed_permissions.py::test_uppercase_role_rejected caught it,
    # and it was right to: core.ad_auth.resolve_user_role can only ever
    # return the literal lowercase "admin" / "analyst" / "viewer", so an
    # uppercase role never arrives from the auth boundary and nothing in the
    # product emits a principal carrying a ``roles`` LIST.  Both extras
    # answered questions nothing asks, while granting admin on values the
    # rest of the product denies.  Converging on the stricter side fixes the
    # real defect ({"is_admin": True} being denied) without widening
    # anything.
    if not user:
        return False
    if _canonical_is_admin(user):
        return True

    # ``superuser`` was only ever recognised here -- it is not in
    # ADMIN_TIER_ROLES and no other surface honours it, so accepting it made
    # this route strictly more permissive than the rest of the product.  It
    # is no longer granted; log it rather than let the change be silent, so a
    # deployment that really does issue that role is visible instead of
    # mysteriously losing access.
    _r = user.get("role")
    _rs = user.get("roles") if isinstance(user.get("roles"), (list, tuple, set)) else []
    if (isinstance(_r, str) and _r.strip().lower() == "superuser") or \
            any(isinstance(x, str) and x.strip().lower() == "superuser" for x in _rs):
        _log.warning(
            "business-report admin check: role 'superuser' is NOT an admin "
            "tier role in this product (see core.roles.ADMIN_TIER_ROLES); "
            "this principal was previously granted admin HERE ONLY. "
            "username=%s", user.get("username"))
    return False


def _username(user: Optional[Dict[str, Any]]) -> str:
    if not user:
        return ""
    return str(user.get("username") or user.get("user") or "").strip()


# ── Group membership lookup ─────────────────────────────────────────


def _user_group_ids(
    username: str, db_manager: Any,
) -> List[int]:
    """Best-effort: return group ids the user is a member of.
    Fail-OPEN here (return []) because group-grants are an ADDITIVE
    access source -- absence means we just don't grant via groups."""
    if not username or db_manager is None:
        return []
    try:
        if hasattr(db_manager, "user_groups_for_username"):
            ids = db_manager.user_groups_for_username(username) or []
            return [int(x) for x in ids if x is not None]
    except Exception as exc:
        logger.debug("[br-perm] group lookup failed for %s: %s",
                     username, exc)
    return []


# ── Grant resolution ────────────────────────────────────────────────


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _grant_is_active(grant: Dict[str, Any]) -> bool:
    gu = grant.get("grant_until")
    if not gu:
        return True
    try:
        when = (gu if isinstance(gu, datetime)
                else datetime.fromisoformat(str(gu)))
        return when > _now()
    except Exception:
        # Malformed expiry => treat as expired (fail-CLOSED).
        return False


def _highest_grant_level(
    report_id: int, user: Dict[str, Any], db_manager: Any,
) -> str:
    """Return the highest ``level`` from BusinessReportGrant rows
    matching the user OR their groups.  Empty string when no grant."""
    if db_manager is None:
        return ""
    username = _username(user)
    try:
        grants = db_manager.list_br_grants(report_id) or []
    except Exception as exc:
        logger.debug("[br-perm] list_br_grants failed: %s", exc)
        return ""
    if not grants:
        return ""
    group_ids = set(_user_group_ids(username, db_manager))
    best = ""
    for g in grants:
        if not _grant_is_active(g):
            continue
        match = False
        if g.get("username") and g["username"] == username:
            match = True
        elif g.get("group_id") and int(g["group_id"]) in group_ids:
            match = True
        if not match:
            continue
        lvl = (g.get("level") or "view").lower()
        if _LEVEL_RANK.get(lvl, 0) > _LEVEL_RANK.get(best, 0):
            best = lvl
    return best


# ── Owner / owner-group check ───────────────────────────────────────


def _is_owner_or_owner_group(
    report: Dict[str, Any], user: Dict[str, Any], db_manager: Any,
) -> bool:
    username = _username(user)
    if not username:
        return False
    if (report.get("owner") or "") == username:
        return True
    owner_group_id = report.get("owner_group_id")
    if owner_group_id:
        if int(owner_group_id) in set(_user_group_ids(username, db_manager)):
            return True
    return False


def _role_whitelist_match(
    report: Dict[str, Any], user: Dict[str, Any],
) -> bool:
    wl = report.get("role_whitelist") or []
    if not wl:
        return True  # empty whitelist = no role restriction
    if not isinstance(wl, list):
        return True  # malformed -- don't restrict
    user_role = (user.get("role") or "").lower()
    user_roles = {str(r).lower() for r in (user.get("roles") or [])}
    user_roles.add(user_role) if user_role else None
    wl_lower = {str(r).lower() for r in wl}
    return bool(user_roles & wl_lower)


# ── Public API ──────────────────────────────────────────────────────


def effective_level(
    report: Dict[str, Any],
    user: Optional[Dict[str, Any]],
    db_manager: Any = None,
) -> str:
    """Return the highest level the user holds, or '' for DENY.

    Resolution order documented at the top of this module.  Fail-CLOSED
    on any error (return '').

    NOTE (2026-08-09): the batched list/search evaluation in
    ``core.reports.authorization.can_view_business_report`` (ctx branch)
    mirrors this resolution order with pre-resolved group/grant sets —
    any change to the order or sources HERE must be mirrored THERE.
    """
    try:
        if not report:
            return ""
        if _is_admin(user):
            return "owner"
        if not user or not _username(user):
            # Anonymous access only OK via share-token paths which
            # bypass this function entirely.
            return ""
        if _is_owner_or_owner_group(report, user, db_manager):
            return "owner"
        # Explicit grant -- per-user or per-group.
        gl = _highest_grant_level(
            int(report.get("id") or 0), user, db_manager,
        )
        if gl:
            return gl
        # Published + role_whitelist legacy compat.
        if report.get("is_published") and _role_whitelist_match(report, user):
            return "view"
        return ""
    except Exception as exc:
        logger.warning(
            "[br-perm] effective_level fail-CLOSED for report=%s "
            "user=%s: %s", (report or {}).get("id"),
            _username(user), exc,
        )
        return ""


def can_view(report, user, db_manager=None) -> bool:
    return _level_at_least(effective_level(report, user, db_manager), "view")


def can_run(report, user, db_manager=None) -> bool:
    return _level_at_least(effective_level(report, user, db_manager), "runner")


def can_edit(report, user, db_manager=None) -> bool:
    return _level_at_least(effective_level(report, user, db_manager), "editor")


def can_share(report, user, db_manager=None) -> bool:
    # Owner level required to grant access / mint tokens.
    return _level_at_least(effective_level(report, user, db_manager), "owner")


# ── Effective-access enumeration (UI panel) ─────────────────────────


def effective_access(
    report: Dict[str, Any], db_manager: Any,
) -> Dict[str, Any]:
    """Snapshot for the "Who has access" panel.

    Returns ``{owner, owner_group, role_whitelist, grants, share_tokens,
    embed_tokens}`` where ``grants`` is the active BusinessReportGrant
    rows (expired ones filtered out).  ``share_tokens`` + ``embed_tokens``
    are the active token rows from existing models.
    """
    out: Dict[str, Any] = {
        "owner":          report.get("owner"),
        "owner_group_id": report.get("owner_group_id"),
        "role_whitelist": report.get("role_whitelist") or [],
        "is_published":   bool(report.get("is_published")),
        "is_certified":   bool(report.get("is_certified")),
        "grants":         [],
        "share_tokens":   [],
        "embed_tokens":   [],
    }
    if db_manager is None:
        return out
    try:
        for g in db_manager.list_br_grants(report.get("id")) or []:
            if _grant_is_active(g):
                out["grants"].append(g)
    except Exception:
        pass
    try:
        if hasattr(db_manager, "list_br_share_tokens"):
            out["share_tokens"] = (
                db_manager.list_br_share_tokens(report.get("id")) or []
            )
    except Exception:
        pass
    try:
        if hasattr(db_manager, "list_br_embed_tokens"):
            out["embed_tokens"] = (
                db_manager.list_br_embed_tokens(report.get("id")) or []
            )
    except Exception:
        pass
    return out


# ── Grant management ────────────────────────────────────────────────


def add_grant(
    *,
    report_id: int,
    username: Optional[str],
    group_id: Optional[int],
    level: str,
    granted_by: str,
    grant_until: Optional[datetime] = None,
    reason: Optional[str] = None,
    db_manager: Any,
) -> Dict[str, Any]:
    """Owner-issued explicit grant.  Either username OR group_id is set."""
    if not username and not group_id:
        raise ValueError("add_grant: one of username or group_id required")
    if username and group_id:
        raise ValueError(
            "add_grant: only one of username or group_id allowed",
        )
    if (level or "").lower() not in _LEVEL_RANK:
        raise ValueError(f"add_grant: invalid level {level!r}")
    if db_manager is None:
        raise RuntimeError("add_grant: db_manager required")
    grant = db_manager.add_br_grant(
        report_id=report_id, username=username, group_id=group_id,
        level=level.lower(), granted_by=granted_by,
        grant_until=grant_until, reason=reason,
    )
    record_event(
        report_id=report_id, event_type="grant_added",
        actor=granted_by,
        subject=username or f"group:{group_id}",
        metadata={
            "level":       level,
            "grant_until": grant_until.isoformat() if grant_until else None,
            "reason":      reason,
            "grant_id":    grant.get("id"),
        },
        db_manager=db_manager,
    )
    return grant


def remove_grant(
    *, grant_id: int, actor: str, db_manager: Any,
) -> bool:
    if db_manager is None:
        return False
    grant = db_manager.get_br_grant(grant_id)
    if not grant:
        return False
    ok = db_manager.delete_br_grant(grant_id)
    if ok:
        record_event(
            report_id=grant.get("report_id"),
            event_type="grant_removed",
            actor=actor,
            subject=grant.get("username")
                    or f"group:{grant.get('group_id')}",
            metadata={"level": grant.get("level"), "grant_id": grant_id},
            db_manager=db_manager,
        )
    return bool(ok)


# ── Access-request workflow ─────────────────────────────────────────


def request_access(
    *, report_id: int, requester: str, requested_level: str = "view",
    reason: Optional[str] = None, db_manager: Any,
) -> Dict[str, Any]:
    if (requested_level or "").lower() not in _LEVEL_RANK:
        raise ValueError("request_access: invalid level")
    if db_manager is None:
        raise RuntimeError("request_access: db_manager required")
    req = db_manager.create_br_access_request(
        report_id=report_id, requester=requester,
        requested_level=requested_level.lower(), reason=reason,
    )
    record_event(
        report_id=report_id, event_type="access_requested",
        actor=requester, subject=requester,
        metadata={"requested_level": requested_level, "reason": reason,
                  "request_id": req.get("id")},
        db_manager=db_manager,
    )
    return req


def approve_access(
    *, request_id: int, decided_by: str,
    decision_note: Optional[str] = None,
    grant_until: Optional[datetime] = None,
    db_manager: Any,
) -> Dict[str, Any]:
    if db_manager is None:
        raise RuntimeError("approve_access: db_manager required")
    req = db_manager.get_br_access_request(request_id)
    if not req:
        raise ValueError(f"access request {request_id} not found")
    if (req.get("status") or "") != "pending":
        raise ValueError(
            f"access request {request_id} status={req.get('status')!r} "
            f"-- only pending requests can be approved"
        )
    grant = add_grant(
        report_id=int(req["report_id"]),
        username=req["requester"], group_id=None,
        level=req.get("requested_level") or "view",
        granted_by=decided_by, grant_until=grant_until,
        reason=req.get("reason"), db_manager=db_manager,
    )
    db_manager.decide_br_access_request(
        request_id=request_id, status="approved",
        decided_by=decided_by, decision_note=decision_note,
        granted_id=grant.get("id"),
    )
    record_event(
        report_id=int(req["report_id"]),
        event_type="access_approved",
        actor=decided_by, subject=req.get("requester"),
        metadata={
            "request_id": request_id,
            "grant_id":   grant.get("id"),
            "level":      grant.get("level"),
            "note":       decision_note,
        },
        db_manager=db_manager,
    )
    return grant


def deny_access(
    *, request_id: int, decided_by: str,
    decision_note: Optional[str] = None,
    db_manager: Any,
) -> None:
    if db_manager is None:
        raise RuntimeError("deny_access: db_manager required")
    req = db_manager.get_br_access_request(request_id)
    if not req:
        raise ValueError(f"access request {request_id} not found")
    if (req.get("status") or "") != "pending":
        raise ValueError(
            "deny_access: only pending requests can be denied"
        )
    db_manager.decide_br_access_request(
        request_id=request_id, status="denied",
        decided_by=decided_by, decision_note=decision_note,
    )
    record_event(
        report_id=int(req["report_id"]),
        event_type="access_denied",
        actor=decided_by, subject=req.get("requester"),
        metadata={"request_id": request_id, "note": decision_note},
        db_manager=db_manager,
    )


# ── Certification workflow ──────────────────────────────────────────


def request_certification(
    *, report_id: int, requested_by: str,
    rationale: Optional[str] = None, db_manager: Any,
) -> Dict[str, Any]:
    if db_manager is None:
        raise RuntimeError("request_certification: db_manager required")
    req = db_manager.create_br_cert_request(
        report_id=report_id, requested_by=requested_by,
        rationale=rationale,
    )
    record_event(
        report_id=report_id, event_type="certification_requested",
        actor=requested_by, subject=None,
        metadata={"rationale": rationale, "request_id": req.get("id")},
        db_manager=db_manager,
    )
    return req


def approve_certification(
    *, request_id: int, reviewed_by: str,
    review_note: Optional[str] = None, db_manager: Any,
) -> None:
    if db_manager is None:
        raise RuntimeError("approve_certification: db_manager required")
    req = db_manager.get_br_cert_request(request_id)
    if not req:
        raise ValueError("certification request not found")
    db_manager.decide_br_cert_request(
        request_id=request_id, status="approved",
        reviewed_by=reviewed_by, review_note=review_note,
    )
    db_manager.set_br_certified(
        report_id=int(req["report_id"]),
        certified=True, certified_by=reviewed_by,
    )
    record_event(
        report_id=int(req["report_id"]),
        event_type="certification_approved",
        actor=reviewed_by, subject=None,
        metadata={"request_id": request_id, "note": review_note},
        db_manager=db_manager,
    )


def deny_certification(
    *, request_id: int, reviewed_by: str,
    review_note: Optional[str] = None, db_manager: Any,
) -> None:
    if db_manager is None:
        raise RuntimeError("deny_certification: db_manager required")
    req = db_manager.get_br_cert_request(request_id)
    if not req:
        raise ValueError("certification request not found")
    db_manager.decide_br_cert_request(
        request_id=request_id, status="denied",
        reviewed_by=reviewed_by, review_note=review_note,
    )
    record_event(
        report_id=int(req["report_id"]),
        event_type="certification_denied",
        actor=reviewed_by, subject=None,
        metadata={"request_id": request_id, "note": review_note},
        db_manager=db_manager,
    )


# ── Audit event recorder ────────────────────────────────────────────


def record_event(
    *,
    report_id: int,
    event_type: str,
    actor: str,
    subject: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    db_manager: Any,
) -> None:
    """Append-only audit event.  Fail-OPEN on persistence error -- a
    log-write failure must NEVER block the underlying action."""
    if db_manager is None:
        return
    try:
        db_manager.add_br_permission_event(
            report_id=report_id, event_type=event_type, actor=actor,
            subject=subject, metadata=metadata or {},
        )
    except Exception as exc:
        logger.warning(
            "[br-perm] audit event persist failed (event=%s actor=%s "
            "report=%s): %s",
            event_type, actor, report_id, exc,
        )


# ── Cleanup / housekeeping ──────────────────────────────────────────


def expire_old_grants(db_manager: Any) -> int:
    """Tier 3 -- background cleanup tick.  Removes grants whose
    ``grant_until`` has passed.  Returns the count of expirations.
    Each expiration emits a ``grant_expired`` audit event."""
    if db_manager is None:
        return 0
    try:
        expired = db_manager.list_br_grants_expired_before(_now()) or []
    except Exception:
        return 0
    n = 0
    for g in expired:
        try:
            ok = db_manager.delete_br_grant(g["id"])
            if ok:
                record_event(
                    report_id=int(g["report_id"]),
                    event_type="grant_expired",
                    actor="system",
                    subject=g.get("username")
                            or f"group:{g.get('group_id')}",
                    metadata={"grant_id": g["id"], "level": g.get("level")},
                    db_manager=db_manager,
                )
                n += 1
        except Exception:
            continue
    return n


__all__ = [
    "effective_level", "can_view", "can_run", "can_edit", "can_share",
    "effective_access",
    "add_grant", "remove_grant",
    "request_access", "approve_access", "deny_access",
    "request_certification", "approve_certification", "deny_certification",
    "record_event", "expire_old_grants",
]
