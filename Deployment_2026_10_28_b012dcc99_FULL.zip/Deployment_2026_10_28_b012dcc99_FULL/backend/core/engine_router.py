"""BF-385 — Engine Router: choose the right execution backend per query.

A single configurable decision point that picks between:

  * ``single``         — original single-worker s3_full_copy path (default)
  * ``multi_worker``   — in-pod thread fan-out (Option F)
  * ``multi_pod``      — cross-pod HTTP fan-out (Option G)
  * ``spark_connect``  — Spark Connect cluster gRPC (existing scaffolding)

The decision is made by a series of routing rules evaluated top-to-bottom.
Each rule is config-driven so admins can build hybrid policies like:

  rule 1: if cross_connection or join → 'single'
  rule 2: if rows_estimate > 50_000_000 → 'spark_connect'
  rule 3: if files >= 500 and multi_pod.enabled → 'multi_pod'
  rule 4: if files >= 50 → 'multi_worker'
  default: 'single'

Returns ``EngineDecision`` so callers can log the reason in the per-query
audit trail.  Always falls through to ``single`` on any error (fail-open).

The router NEVER actually executes — it just makes the decision.  The
caller (execute_api / multi_worker_dispatcher) is responsible for
invoking the chosen backend.
"""
from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Decision types
# ─────────────────────────────────────────────────────────────────────────────


ENGINE_SINGLE        = "single"
ENGINE_MULTI_WORKER  = "multi_worker"
ENGINE_MULTI_POD     = "multi_pod"
ENGINE_SPARK_CONNECT = "spark_connect"

ALL_ENGINES = (ENGINE_SINGLE, ENGINE_MULTI_WORKER, ENGINE_MULTI_POD, ENGINE_SPARK_CONNECT)


@dataclass
class EngineDecision:
    engine: str
    reason: str
    rule:   str = ""        # name of the routing rule that fired
    # Diagnostic — what features the decision saw
    file_count:        int = 0
    row_estimate:      int = 0
    is_splittable:     bool = False
    is_cross_source:   bool = False
    has_join:          bool = False
    multi_pod_pods:    int = 0
    spark_connect_ok:  bool = False
    # 2026-09-15 -- the HONEST multi-pod state behind ``multi_pod_pods``:
    # "disabled" | "inert" (enabled, nothing discoverable -- the reason says
    # why) | "active".  A bare ``multi_pod_pods=0`` could not tell an
    # operator "turned off" from "turned on and broken".
    multi_pod_state:   str = ""
    multi_pod_reason:  str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "engine":           self.engine,
            "reason":           self.reason,
            "rule":             self.rule,
            "file_count":       self.file_count,
            "row_estimate":     self.row_estimate,
            "is_splittable":    self.is_splittable,
            "is_cross_source":  self.is_cross_source,
            "has_join":         self.has_join,
            "multi_pod_pods":   self.multi_pod_pods,
            "multi_pod_state":  self.multi_pod_state,
            "multi_pod_reason": self.multi_pod_reason,
            "spark_connect_ok": self.spark_connect_ok,
        }


@dataclass
class QueryFeatures:
    """Inputs to the routing decision.

    Phase 155 (2026-06-25): added brain-relevant fields so the
    decide_engine bridge can forward them into QueryContext for the
    brain consultation step.  All new fields are optional with safe
    defaults -- existing callers keep working unchanged.
    """
    sql:                 str
    file_count:          int = 0
    row_estimate:        int = 0
    is_cross_source:     bool = False
    # Brain-context inputs (all optional; brain skips gates whose inputs
    # are missing).
    sql_hash:            str = ""
    snapshot_id:         Optional[str] = None
    bucket:              str = ""
    table_prefix:        str = ""
    median_file_size:    int = 0
    filter_columns:      List[str] = field(default_factory=list)
    partition_columns:   List[str] = field(default_factory=list)
    manifest_stats:      Optional[Any] = None
    # 2026-06-30 deep-dive fix: these are THE missing pieces that broke
    # brain pruning end-to-end.  Populate via
    # ``core.query_feature_builder.QueryFeatureBuilder.build(...)``
    # which extracts predicates from sql / query_config, classifies
    # them by whether any references a partition column, and loads
    # manifest_stats from the iceberg-in-DB cache (with timeout).
    where_predicates:    List[Dict[str, Any]] = field(default_factory=list)
    has_prunable_predicates: bool = False
    # Deep-dive #3 (2026-06-30): signal that manifest_stats already
    # carries supplement bounds in its Layer 1 stats dicts.
    # ``evaluate_where`` reads this to skip its own duplicate supplement
    # DB load -- saves one Postgres roundtrip per query.
    manifest_stats_includes_supplement: bool = False
    # Deep-dive #7 (2026-06-30): iceberg vs parquet discriminator for
    # the supplement + bloom DB lookups.  Wrong format -> zero rows ->
    # bloom + supplement pruning both silently disabled.
    format:              str = "iceberg"
    # 2026-07-15 DATA-LOSS FIX -- ``{lower_col: iceberg_type_str}``.
    # Forwarded into brain QueryContext so the manifest-prune Layer-3
    # bloom verdict is gated on probe-encoding parity.  Empty map ->
    # bloom prune skipped (fail-open), never the old type-blind probe.
    iceberg_col_types:   Dict[str, str] = field(default_factory=dict)
    # Industrialization Phase 9 -- the Phase-3 Query Passport (a
    # QueryPassport instance or its ``.to_dict()`` payload), when the
    # caller has one.  Consulted ONLY when
    # ``industrialization.cost_routing`` is armed (core.industrialization.
    # cost_router owns that flag read); ``None`` here is the common case
    # today and changes nothing.
    passport:            Optional[Any] = None
    # 2026-10-08 -- the brain-cache hit the caller resolved ONCE
    # (``core.agg_cache.lookup_brain_cache``) and will SERVE if the
    # decision is rule=brain_cache.  Forwarded into the brain's
    # QueryContext; the brain looks nothing up itself.  ``None`` = the
    # normal rules apply.
    cached_result:       Optional[Any] = None


# ─────────────────────────────────────────────────────────────────────────────
# Backend availability checks (cheap)
# ─────────────────────────────────────────────────────────────────────────────


def _is_multi_worker_available() -> bool:
    try:
        from core.config import get_section as _cfg_section
        # BF-391: default True mirrors core/config.py _DEFAULTS
        return bool((_cfg_section("multi_worker") or {}).get("enabled", True))
    except Exception:
        return False


def _multi_pod_state() -> Dict[str, Any]:
    """ONE reading of the multi-pod state for the router (2026-09-15).

    Delegates to ``core.multi_pod_dispatcher.multi_pod_state`` -- the same
    answer the admin routes and the startup log give -- so the decision
    record never says "0 pods" where the operator screen says "inert".
    """
    try:
        from core.multi_pod_dispatcher import multi_pod_state
        return multi_pod_state()
    except Exception as exc:
        logger.debug("[router] multi_pod check failed: %s", exc)
        return {"state": "inert", "configured_enabled": False, "pods": [],
                "reason": f"multi_pod state check failed: {exc}"[:200]}


_mp_seen = threading.local()   # the state the CURRENT decision observed


def _is_multi_pod_available() -> tuple[bool, int]:
    """Returns (available, pod_count): the flag AND discovery AND the secret.

    Records the state it read on a thread-local so ``decide_engine`` can
    stamp the decision without running discovery a second time.
    """
    st = _multi_pod_state()
    _mp_seen.state = st
    return (st.get("state") == "active", len(st.get("pods") or []))


def _is_spark_connect_available() -> bool:
    try:
        from core.config import get_section as _cfg_section
        if not (_cfg_section("spark_connect") or {}).get("enabled", False):
            return False
        # Cheap availability check — exists and configured.  Caller still
        # owns final liveness probe before submission.
        # 2026-09-01 -- was ``get_spark_connect_manager``, which does not
        # exist: the ImportError fell into the ``except`` below and this
        # returned False unconditionally, so the router never routed to
        # Spark Connect even when it was enabled, configured and running.
        from core.spark_connect_session_manager import is_initialised
        return is_initialised()
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────────────────────
# Query introspection
# ─────────────────────────────────────────────────────────────────────────────


def _is_splittable_sql(sql: str) -> bool:
    """Splittable in the single-table sense.  Phase 141: a JOIN query is
    NOT splittable under this predicate even when broadcast-JOIN is
    enabled — that's a separate ``_is_broadcast_join_eligible`` predicate
    so the router can pick distinct rules for each path.
    """
    if not sql:
        return False
    try:
        from core.query_splitter import detect_unsupported
        return detect_unsupported(sql) is None
    except Exception:
        return False


def _has_join(sql: str) -> bool:
    if not sql:
        return False
    import re
    return bool(re.search(r"\bJOIN\b", sql, re.IGNORECASE))


def _is_broadcast_join_eligible(sql: str) -> bool:
    """Phase 141 — True when the SQL is a JOIN that broadcast-JOIN can
    safely split.  Used by the router to pick the multi_worker engine
    for JOIN queries that the single-table splitter would reject.

    Gated by ``multi_worker.allow_broadcast_join``: returns False unless
    the admin has explicitly opted in (default false).
    """
    if not sql or not _has_join(sql):
        return False
    try:
        from core.config import get_section as _cfg_section
        mw = _cfg_section("multi_worker") or {}
        if not mw.get("allow_broadcast_join", True):
            return False
    except Exception:
        return False
    try:
        from core.query_splitter import detect_unsupported_for_broadcast_join
        return detect_unsupported_for_broadcast_join(sql) is None
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────────────────────
# Default routing rules (overridable via config)
# ─────────────────────────────────────────────────────────────────────────────


def _get_min_files_threshold(default: int = 50) -> int:
    """Pull the in-pod threshold from multi_worker config so default rules
    stay in sync with the underlying executor's own gate.  Returns ``default``
    on any config read error."""
    try:
        from core.config import get_section as _cfg_section
        mw = _cfg_section("multi_worker") or {}
        return int(mw.get("min_files_to_split", default) or default)
    except Exception:
        return default


def _build_default_rules() -> List[Dict[str, Any]]:
    """Default routing rules.  File-count thresholds mirror the executor
    configs so admins only have to tune ONE knob (multi_worker.min_files_to_split)
    for the in-pod path."""
    mw_min = _get_min_files_threshold()
    return [
        {
            "name":   "cross_source_forces_single",
            "when":   {"is_cross_source": True},
            "engine": ENGINE_SINGLE,
            "reason": "Cross-source queries can't safely fan out (different connections per side)",
        },
        {
            "name":   "huge_to_spark",
            "when":   {"row_estimate_min": 10_000_000, "spark_connect_available": True},
            "engine": ENGINE_SPARK_CONNECT,
            "reason": "Row estimate ≥ 10M — route to Spark Connect cluster",
        },
        {
            "name":   "many_files_to_multi_pod",
            "when":   {"file_count_min": max(mw_min * 10, 500),
                       "splittable": True, "multi_pod_available": True},
            "engine": ENGINE_MULTI_POD,
            "reason": "File count ≥ 10× multi_worker threshold with worker pods available — distribute across pods",
        },
        {
            "name":   "moderate_files_to_multi_worker",
            "when":   {"file_count_min": mw_min, "splittable": True,
                        "multi_worker_available": True},
            "engine": ENGINE_MULTI_WORKER,
            "reason": "File count ≥ multi_worker.min_files_to_split + splittable SQL — in-pod thread fan-out",
        },
        # Phase 141 — broadcast-JOIN rule.  Fires AFTER the single-table
        # multi_worker rule so JOIN-less queries continue to use the
        # validated path.  ``broadcast_join_eligible`` is True only when
        # ``multi_worker.allow_broadcast_join=true`` AND the JOIN passes
        # all of the v1 safety gates (INNER only, no GROUP BY, no
        # aggregates, no DISTINCT/WINDOW/HAVING/WITH).
        {
            "name":   "join_to_broadcast_multi_worker",
            "when":   {"file_count_min": mw_min,
                        "broadcast_join_eligible": True,
                        "multi_worker_available":  True},
            "engine": ENGINE_MULTI_WORKER,
            "reason": (
                "INNER JOIN with broadcast-eligible small side — "
                "in-pod broadcast-JOIN dispatch (each worker scans its big-table "
                "chunk + the full small-table file list)"
            ),
        },
    ]


# Public symbol — computed at module load.  decide_engine() re-evaluates
# via _build_default_rules() so config changes pick up without restart.
DEFAULT_RULES: List[Dict[str, Any]] = _build_default_rules()


def _evaluate_rule(rule: Dict[str, Any], features: QueryFeatures,
                    flags: Dict[str, Any]) -> bool:
    """Return True if all conditions in ``rule['when']`` are satisfied."""
    when = rule.get("when") or {}
    if not when:
        return True   # unconditional rule

    if (v := when.get("file_count_min")) is not None and features.file_count < int(v):
        return False
    if (v := when.get("file_count_max")) is not None and features.file_count > int(v):
        return False
    if (v := when.get("row_estimate_min")) is not None and features.row_estimate < int(v):
        return False
    if (v := when.get("row_estimate_max")) is not None and features.row_estimate > int(v):
        return False

    if when.get("is_cross_source") is not None:
        if bool(when["is_cross_source"]) != features.is_cross_source:
            return False
    if when.get("splittable") is not None:
        if bool(when["splittable"]) != flags["splittable"]:
            return False
    if when.get("has_join") is not None:
        if bool(when["has_join"]) != flags["has_join"]:
            return False
    if when.get("broadcast_join_eligible") is not None:
        if bool(when["broadcast_join_eligible"]) != flags["broadcast_join_eligible"]:
            return False

    if when.get("multi_worker_available"):
        if not flags["multi_worker_available"]:
            return False
    if when.get("multi_pod_available"):
        if not flags["multi_pod_available"]:
            return False
    if when.get("spark_connect_available"):
        if not flags["spark_connect_available"]:
            return False

    return True


# ─────────────────────────────────────────────────────────────────────────────
# Public entry point
# ─────────────────────────────────────────────────────────────────────────────


def decide_engine(features: QueryFeatures) -> EngineDecision:
    """Pick the execution engine based on query features + config rules.

    Phase 155 (2026-06-25): consults ``core.brain_router`` FIRST.  When
    the brain emits a confident recommendation that doesn't conflict
    with an explicit operator override, brain wins.  Absent a brain
    recommendation, falls through to the legacy operator-config rule
    evaluation (unchanged).

    Always returns a decision; on any unexpected error, falls back to
    ``ENGINE_SINGLE`` to keep behaviour safe.

    2026-09-15: every decision is stamped with the honest multi-pod state
    (``multi_pod_state`` / ``multi_pod_reason``) so a single-pod fallback
    under ``multi_pod.enabled=true`` reads as "inert: <why>", never as a
    bare "0 pods".
    """
    def _inner(features: QueryFeatures) -> EngineDecision:
        try:
            from core.config import get_section as _cfg_section
            router_cfg = _cfg_section("engine_router") or {}
            if not router_cfg.get("enabled", True):
                return EngineDecision(
                    engine=ENGINE_SINGLE,
                    reason="engine_router.enabled = false → using original single-worker path",
                    rule="router_disabled",
                    file_count=features.file_count,
                    row_estimate=features.row_estimate,
                    is_cross_source=features.is_cross_source,
                )

            # Always rebuild default rules so changes to multi_worker.min_files_to_split
            # take effect without restart.  Custom admin rules (when non-empty) win.
            rules = router_cfg.get("rules") or _build_default_rules()
            default_engine = str(router_cfg.get("default_engine", ENGINE_SINGLE))
            if default_engine not in ALL_ENGINES:
                default_engine = ENGINE_SINGLE

            # Probe backend availability + query features ONCE (rules don't change)
            mp_enabled, mp_count = _is_multi_pod_available()
            spark_ok = _is_spark_connect_available()
            flags = {
                "splittable":               _is_splittable_sql(features.sql),
                "has_join":                 _has_join(features.sql),
                "broadcast_join_eligible":  _is_broadcast_join_eligible(features.sql),
                "multi_worker_available":   _is_multi_worker_available(),
                "multi_pod_available":      mp_enabled,
                "spark_connect_available":  spark_ok,
            }

            _has_admin_rules = bool(router_cfg.get("rules"))

            # Industrialization Phase 9 -- passport-driven cost routing.  A
            # SEPARATE, ADDITIVE consultation from the Phase-155 brain below:
            # this one asks "what does the Phase-3 Query Passport's plan-time
            # island estimate suggest?" — pure DB cost model, no S3, no SQL
            # introspection beyond what's already computed for `flags`.
            # Fail-OPEN by construction (core.industrialization.cost_router
            # owns the industrialization.cost_routing flag read): no
            # passport / UNKNOWN confidence / any error -> None -> falls
            # through to brain / operator config rules exactly as today.
            #
            # Correctness guards (HARD -- never route a query to a venue that
            # could return wrong/incomplete results):
            #   * cross-source queries NEVER consult cost-routing at all —
            #     the legacy "cross_source_forces_single" rule is the only
            #     authority there (matches its own unconditional-single
            #     policy; fanning a cross-connection query into multi_worker
            #     or Spark is unsafe regardless of size).
            #   * a "medium" (multi_worker) verdict is honoured ONLY when the
            #     SQL is actually splittable (or broadcast-JOIN eligible) --
            #     the SAME gate the legacy "moderate_files_to_multi_worker"
            #     rule enforces.  A size-only cost model has no opinion on
            #     whether fan-out is semantically safe; when it isn't, this
            #     consultation falls through instead of forcing a split.
            #   * operator-explicit rules (``router_cfg["rules"]`` non-empty)
            #     always win -- cost-routing is advisory only, same contract
            #     as the brain consultation below.
            if not features.is_cross_source and not _has_admin_rules:
                try:
                    from core.industrialization.cost_router import decide_venue_for_passport
                    _cr_key = (
                        f"{features.bucket}:{features.table_prefix}"
                        if (features.bucket or features.table_prefix) else ""
                    )
                    _cr_dec = decide_venue_for_passport(features.passport, key=_cr_key)
                    if _cr_dec is not None:
                        _cr_ok = True
                        if _cr_dec.venue == ENGINE_SPARK_CONNECT and not spark_ok:
                            _cr_ok = False
                        elif _cr_dec.venue == ENGINE_MULTI_WORKER and not (
                            flags["multi_worker_available"]
                            and (flags["splittable"] or flags["broadcast_join_eligible"])
                        ):
                            _cr_ok = False
                        if _cr_ok:
                            return EngineDecision(
                                engine=_cr_dec.venue,
                                reason=f"cost_routing: {_cr_dec.reason}",
                                rule=f"cost_routing_{_cr_dec.tier}",
                                file_count=features.file_count,
                                row_estimate=features.row_estimate,
                                is_splittable=flags["splittable"],
                                is_cross_source=features.is_cross_source,
                                has_join=flags["has_join"],
                                multi_pod_pods=mp_count,
                                spark_connect_ok=spark_ok,
                            )
                except Exception as _cr_exc:
                    logger.debug(
                        "[router] cost-routing consultation failed (%s) -- "
                        "falling through to brain / config rules", _cr_exc,
                    )

            # Phase 155 -- brain consultation (single chokepoint).  Fail-OPEN:
            # any brain error returns None -> config rules run as before.
            # Operator-explicit overrides still win: if router_cfg has a
            # custom "rules" array set, the operator has spoken; brain is
            # advisory only (logged but not enforced) so operators retain
            # absolute control.
            try:
                from core.brain_router import (
                    BrainRouter, QueryContext,
                    ROUTE_SINGLE, ROUTE_MULTI_WORKER, ROUTE_MULTI_POD,
                    ROUTE_SPARK_CONNECT, ROUTE_CACHE, ROUTE_EMPTY,
                )
                brain_ctx = QueryContext(
                    sql=features.sql,
                    sql_hash=features.sql_hash or "",
                    snapshot_id=features.snapshot_id,
                    bucket=features.bucket or "",
                    table_prefix=features.table_prefix or "",
                    file_count_unpruned=features.file_count,
                    median_file_size=features.median_file_size or 0,
                    is_cross_source=features.is_cross_source,
                    has_join=flags["has_join"],
                    filter_columns=list(features.filter_columns or []),
                    partition_columns=list(features.partition_columns or []),
                    manifest_stats=features.manifest_stats,
                    # 2026-06-30 deep-dive fix -- thread the missing inputs.
                    where_predicates=list(features.where_predicates or []),
                    has_prunable_predicates=bool(features.has_prunable_predicates),
                    manifest_stats_includes_supplement=bool(
                        features.manifest_stats_includes_supplement
                    ),
                    format=str(getattr(features, "format", "iceberg") or "iceberg"),
                    # 2026-07-15 -- bloom probe-encoding parity gate input.
                    iceberg_col_types=dict(
                        getattr(features, "iceberg_col_types", None) or {}
                    ),
                    # 2026-10-08 -- the hit the caller will serve, or None.
                    cached_result=getattr(features, "cached_result", None),
                )
                brain_rec = BrainRouter.get_default().recommend_route(brain_ctx)
                if brain_rec is not None:
                    # Map brain verdicts to actual engines.  CACHE + EMPTY
                    # both route to SINGLE (caller short-circuits via the
                    # cached path or empty-result path); the EngineDecision
                    # records the brain's reasoning either way.
                    _brain_engine_map = {
                        ROUTE_SINGLE:        ENGINE_SINGLE,
                        ROUTE_MULTI_WORKER:  ENGINE_MULTI_WORKER,
                        ROUTE_MULTI_POD:     ENGINE_MULTI_POD,
                        ROUTE_SPARK_CONNECT: ENGINE_SPARK_CONNECT,
                        ROUTE_CACHE:         ENGINE_SINGLE,
                        ROUTE_EMPTY:         ENGINE_SINGLE,
                    }
                    _mapped = _brain_engine_map.get(brain_rec.engine)
                    # Operator override: when admin set explicit "rules" in
                    # config, treat brain as ADVISORY (return brain decision
                    # only when brain.engine matches one of the configured
                    # rules' targets so operator intent isn't undermined).
                    _has_admin_rules = bool(router_cfg.get("rules"))
                    if _mapped is not None and not _has_admin_rules:
                        # Verify the chosen engine is actually available.
                        if _mapped == ENGINE_SPARK_CONNECT and not spark_ok:
                            # Brain wanted Spark but it's not available --
                            # fall through to config rules.
                            pass
                        elif (_mapped == ENGINE_MULTI_POD
                              and not flags["multi_pod_available"]):
                            pass
                        else:
                            return EngineDecision(
                                engine=_mapped,
                                reason=f"brain: {brain_rec.reason}",
                                rule=f"brain_{brain_rec.engine}",
                                file_count=features.file_count,
                                row_estimate=features.row_estimate,
                                is_splittable=flags["splittable"],
                                is_cross_source=features.is_cross_source,
                                has_join=flags["has_join"],
                                multi_pod_pods=mp_count,
                                spark_connect_ok=spark_ok,
                            )
            except Exception as _brain_exc:
                logger.debug(
                    "[router] brain consultation failed (%s) -- falling "
                    "through to config rules", _brain_exc,
                )

            for rule in rules:
                engine = str(rule.get("engine", "")).strip()
                if engine not in ALL_ENGINES:
                    continue
                if _evaluate_rule(rule, features, flags):
                    return EngineDecision(
                        engine=engine,
                        reason=str(rule.get("reason", "")),
                        rule=str(rule.get("name", "unnamed")),
                        file_count=features.file_count,
                        row_estimate=features.row_estimate,
                        is_splittable=flags["splittable"],
                        is_cross_source=features.is_cross_source,
                        has_join=flags["has_join"],
                        multi_pod_pods=mp_count,
                        spark_connect_ok=spark_ok,
                    )

            return EngineDecision(
                engine=default_engine,
                reason="no rule matched — using default engine",
                rule="default",
                file_count=features.file_count,
                row_estimate=features.row_estimate,
                is_splittable=flags["splittable"],
                is_cross_source=features.is_cross_source,
                has_join=flags["has_join"],
                multi_pod_pods=mp_count,
                spark_connect_ok=spark_ok,
            )
        except Exception as exc:
            logger.warning("[router] decision error (%s) — defaulting to single-worker",
                           exc, exc_info=True)
            return EngineDecision(
                engine=ENGINE_SINGLE,
                reason=f"router error → fail-safe to single-worker: {exc}"[:200],
                rule="error_fallback",
                file_count=features.file_count,
                row_estimate=features.row_estimate,
                is_cross_source=features.is_cross_source,
            )


    # ─────────────────────────────────────────────────────────────────────────────
    # Per-process decision history (newest first)
    # ─────────────────────────────────────────────────────────────────────────────


    import threading  # noqa: E402
    from collections import deque  # noqa: E402

    _HISTORY_LOCK = threading.Lock()
    _HISTORY: deque = deque(maxlen=200)

    _mp_seen.state = None
    decision = _inner(features)
    st = getattr(_mp_seen, "state", None)
    if st is None:                      # router disabled / early error path
        st = _multi_pod_state()
    if not decision.multi_pod_state:
        decision.multi_pod_state = str(st.get("state") or "")
        decision.multi_pod_reason = str(st.get("reason") or "")[:300]
    return decision


# ────────────────────────────────────────────────────────────────────────
# Per-process decision history (newest first)
# ────────────────────────────────────────────────────────────────────────


from collections import deque  # noqa: E402

_HISTORY_LOCK = threading.Lock()
_HISTORY: deque = deque(maxlen=200)


def record_decision(decision: EngineDecision, execution_id: str = ""):
    """Stash a routing decision for the admin UI.

    Industrialization Phase 9: ALSO stamps the chosen venue onto this
    execution's process-local passport registry entry (if one exists),
    so the calibration loop's telemetry hook
    (``core.database.add_query_performance_log``) can later read WHICH
    venue actually ran when it folds (estimate, actual) into
    ``core.industrialization.calibration``.  Best-effort + fail-open:
    no entry / any error -> no-op, never affects the routing decision
    itself (this runs strictly AFTER the decision is made).
    """
    import time
    with _HISTORY_LOCK:
        _HISTORY.append({
            "timestamp":     time.time(),
            "execution_id":  execution_id,
            **decision.to_dict(),
        })
    if execution_id:
        try:
            from core.industrialization import passport_registry as _preg
            _pp = _preg.peek(str(execution_id))
            if isinstance(_pp, dict) and not _pp.get("venue"):
                _pp = dict(_pp)
                _pp["venue"] = decision.engine
                _preg.register(str(execution_id), _pp)
        except Exception as _preg_exc:
            logger.debug("[router] passport venue stamp failed (fail-open, "
                         "no calibration sample for this run): %s", _preg_exc)


def get_decision_history(limit: int = 50) -> List[Dict[str, Any]]:
    with _HISTORY_LOCK:
        items = list(_HISTORY)
    items.reverse()
    return items[: max(0, int(limit))]
