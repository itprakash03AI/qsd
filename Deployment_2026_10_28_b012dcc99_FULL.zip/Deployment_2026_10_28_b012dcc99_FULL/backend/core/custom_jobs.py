"""BF-312 — Admin-defined custom background jobs.

Lets admins schedule any of a small set of *safe* job types on a cron
schedule via the UI.  No arbitrary code execution — every job type is
implemented in this module and validated at create time.

Job types
---------
- ``webhook``         — POST a URL on schedule (HTTP integration)
- ``sql_query``       — run a saved query against a connection
- ``iceberg_sync``    — force-reconcile a specific iceberg table
- ``cache_clear``     — invalidate a specific cache (snapshot / query / partition)

Scheduler
---------
A single asyncio loop ticks every ``custom_jobs.tick_seconds`` (default 30 s),
queries the DB for due jobs, and runs each one off the event loop via
``asyncio.to_thread``.  Concurrency-safe: each tick takes a fresh DB
session, jobs are independent, ``next_run_at`` is updated after each run.
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Dict, List, Optional, Tuple


# BF-314: dedicated thread pool for custom-job runs.  Same rationale
# as the iceberg sync — never compete with the default asyncio pool
# that other to_thread-using endpoints rely on.
_jobs_executor = ThreadPoolExecutor(
    max_workers=4, thread_name_prefix="custom-jobs")


async def _run_off_loop(fn, *args, **kwargs):
    loop = asyncio.get_running_loop()
    if kwargs:
        import functools
        return await loop.run_in_executor(_jobs_executor,
                                           functools.partial(fn, *args, **kwargs))
    return await loop.run_in_executor(_jobs_executor, fn, *args)

logger = logging.getLogger(__name__)

# Module-wide DB manager handle, set by init_custom_jobs()
_db_manager = None


def _db():
    """THE db handle this module reads (2026-10-08): what ``init_custom_jobs`` bound
    here, else the process-wide manager.  One rule, in
    ``core.database.resolve_db_manager``; never read the global bare -- a
    route on a pod that never started this daemon found None (the class
    found live in the Iceberg watcher's settings)."""
    from core.database import resolve_db_manager
    return resolve_db_manager(_db_manager)


def init_custom_jobs(db_manager) -> None:
    """Wire the DB manager — called from main.py at startup."""
    global _db_manager
    _db_manager = db_manager


# ── Cron expression validation ─────────────────────────────────────────────

VALID_JOB_TYPES = ("webhook", "sql_query", "iceberg_sync", "cache_clear")


def validate_cron(expr: str) -> Tuple[bool, str]:
    """Return (valid, error_or_normalised).

    Accepts standard 5-field cron (cronmaker.com format) plus the
    common @hourly / @daily / @weekly / @monthly shortcuts.  Uses the
    croniter library which is already a project dep.
    """
    if not expr or not isinstance(expr, str):
        return False, "cron expression is required"
    expr = expr.strip()
    try:
        from croniter import croniter
    except Exception as exc:
        return False, f"croniter unavailable: {exc}"
    if not croniter.is_valid(expr):
        return False, f"not a valid cron expression: {expr!r}"
    return True, expr


def next_n_runs(expr: str, n: int = 5,
                  base: Optional[datetime] = None) -> List[datetime]:
    """Preview the next N firings of this cron — used by the admin UI
    so an admin can sanity-check an expression before saving."""
    from croniter import croniter
    base = base or datetime.now(timezone.utc)
    it = croniter(expr, base)
    return [it.get_next(datetime) for _ in range(max(0, int(n)))]


def compute_next_run(expr: str, base: Optional[datetime] = None) -> datetime:
    """Single-step next firing.  base defaults to now()."""
    from croniter import croniter
    base = base or datetime.now(timezone.utc)
    it = croniter(expr, base)
    return it.get_next(datetime)


# ── Per-type parameter validation ──────────────────────────────────────────

def validate_parameters(job_type: str,
                          params: Optional[dict]) -> Tuple[bool, str]:
    """Each job type has its own required-parameters set.  Validation
    is strict so admins can't save a misconfigured job and only
    discover it at first run."""
    params = params or {}
    if job_type == "webhook":
        if not params.get("url"):
            return False, "webhook requires 'url'"
        if str(params.get("url", "")).startswith("file://"):
            return False, "file:// urls not allowed"
        method = (params.get("method") or "POST").upper()
        if method not in ("GET", "POST", "PUT", "DELETE", "PATCH", "HEAD"):
            return False, f"unsupported HTTP method: {method}"
        return True, ""
    if job_type == "sql_query":
        if not params.get("query_id") and not params.get("sql"):
            return False, "sql_query requires either 'query_id' or 'sql'"
        if not params.get("connection_id"):
            return False, "sql_query requires 'connection_id'"
        return True, ""
    if job_type == "iceberg_sync":
        for k in ("connection_id", "bucket", "table_prefix"):
            if not params.get(k):
                return False, f"iceberg_sync requires '{k}'"
        return True, ""
    if job_type == "cache_clear":
        cache_type = params.get("cache_type")
        if cache_type not in ("iceberg_snapshot", "iceberg_manifest",
                                "query_result", "partition", "schema"):
            return False, (f"unknown cache_type {cache_type!r}.  "
                            "Allowed: iceberg_snapshot, iceberg_manifest, "
                            "query_result, partition, schema")
        return True, ""
    return False, f"unknown job_type: {job_type!r}.  Allowed: {VALID_JOB_TYPES}"


# ── Job runners (one per type) ─────────────────────────────────────────────

def _run_webhook(params: dict) -> Dict[str, Any]:
    """Fire an HTTP request with retry on transient failures.

    BF-320 — production webhooks need retry semantics:
      - Network errors (ConnectionError, Timeout) → retry with backoff
      - 5xx server errors → retry (idempotent verbs only: GET/PUT/DELETE/HEAD)
      - 4xx client errors → fail immediately (caller misconfigured)
      - 2xx/3xx → return ok

    Retry config (params):
      - retries:        max attempts (default 3, capped 5)
      - retry_backoff:  initial sleep seconds (default 2, capped 60)
                        doubled on each attempt
      - retry_on_5xx:   default True for safe verbs, False for POST
                        (caller can override if their POST is idempotent)
    """
    import requests
    url = params["url"]
    method = (params.get("method") or "POST").upper()
    headers = params.get("headers") or {}
    body = params.get("body")
    timeout = min(300, int(params.get("timeout_seconds") or 30))
    max_retries = max(1, min(5, int(params.get("retries") or 3)))
    backoff = max(0.5, min(60.0, float(params.get("retry_backoff") or 2.0)))
    # POST defaults to NOT retrying 5xx (could be non-idempotent).
    # Safe verbs default to True; caller can override either way.
    safe_verbs = {"GET", "PUT", "DELETE", "HEAD", "OPTIONS"}
    retry_on_5xx = params.get("retry_on_5xx",
                                method in safe_verbs)

    if isinstance(body, str):
        try:
            body_obj = json.loads(body)
        except Exception:
            body_obj = body
    else:
        body_obj = body

    try:
        # 2026-09-01 -- ``build_proxies`` does not exist in core.proxy_utils
        # (the helper is ``get_boto_proxies``), so this raised ImportError on
        # every call and ``proxies`` was ALWAYS None: custom-job webhooks
        # went out ignoring the configured corporate proxy, which on an
        # on-prem deployment means they simply do not connect.
        from core.proxy_utils import get_boto_proxies
        proxies = get_boto_proxies()
    except Exception:
        proxies = None

    kwargs: Dict[str, Any] = {"headers": headers, "timeout": timeout}
    if proxies:
        kwargs["proxies"] = proxies
    if isinstance(body_obj, (dict, list)):
        kwargs["json"] = body_obj
    elif isinstance(body_obj, str):
        kwargs["data"] = body_obj

    last_exc: Optional[Exception] = None
    last_resp = None
    for attempt in range(max_retries):
        try:
            # REVIEWED 2026-09-13 (ruff S113 "request without timeout") --
            # FALSE POSITIVE.  The timeout IS set: kwargs is built above as
            # {"headers": ..., "timeout": timeout}, where timeout is
            # min(300, int(params.get("timeout_seconds") or 30)) -- capped,
            # and the `or 30` makes 0/None mean 30 rather than "wait
            # forever", which is the right fold for a timeout (unlike a row
            # cap, where `or` folding 0 into the default is the recorded
            # bug).  ruff cannot see through **kwargs.  Do not "fix" this
            # by adding a second timeout= argument: that is a TypeError.
            resp = requests.request(method, url, **kwargs)
            last_resp = resp
            # Retry transient 5xx if the verb is safe (or admin opted in)
            if 500 <= resp.status_code < 600 and retry_on_5xx and attempt < max_retries - 1:
                logger.info("webhook %s %s: %d on attempt %d/%d, retrying in %.1fs",
                             method, url, resp.status_code, attempt + 1, max_retries, backoff)
                import time as _t
                _t.sleep(backoff)
                backoff *= 2
                continue
            # Otherwise return whatever we got (caller decides if 4xx is "ok")
            return {
                "status_code":     resp.status_code,
                "ok":              resp.ok,
                "attempts":        attempt + 1,
                "response_bytes":  len(resp.content or b""),
                "response_excerpt": (resp.text or "")[:500],
            }
        except (requests.ConnectionError, requests.Timeout) as exc:
            last_exc = exc
            if attempt < max_retries - 1:
                logger.info("webhook %s %s: %s on attempt %d/%d, retrying in %.1fs",
                             method, url, type(exc).__name__,
                             attempt + 1, max_retries, backoff)
                import time as _t
                _t.sleep(backoff)
                backoff *= 2
                continue
            break
    if last_exc:
        raise last_exc
    # Exhausted retries on 5xx
    if last_resp is not None:
        return {
            "status_code":     last_resp.status_code,
            "ok":              False,
            "attempts":        max_retries,
            "response_bytes":  len(last_resp.content or b""),
            "response_excerpt": (last_resp.text or "")[:500],
            "error":           f"5xx after {max_retries} attempts",
        }
    raise RuntimeError("webhook failed with no response and no exception")


def _run_sql_query(params: dict) -> Dict[str, Any]:
    """Run a query and return summary stats.

    BF-320 — honest limitations:

    This runner is for *health-check* / *probe* / *trigger-side-effect*
    SQL — it executes via DuckDB-factory and returns row count + duration.
    It does NOT:
      - persist results to the standard executions table
      - go through the user-query auth / quota / audit path
      - support row-streaming for big results (LIMIT to bounded results)
      - cache results
      - work for SQL connector (Snowflake/Trino/Databricks) connections —
        DuckDB-factory only.  For those, schedule a regular Schedule
        instead.

    For "run a saved query and write the result somewhere" use the
    existing Schedules feature.  For "trigger a periodic mutation /
    health probe" use this runner.
    """
    if _db() is None:
        raise RuntimeError("DB manager not wired — call init_custom_jobs() first")
    connection_id = int(params["connection_id"])
    sql = params.get("sql")
    if not sql and params.get("query_id"):
        q = _db().get_query(int(params["query_id"]))
        if not q:
            raise RuntimeError(f"query_id {params['query_id']} not found")
        sql = q.get("query_sql") or q.get("sql")
    if not sql:
        raise RuntimeError("no SQL (provide either query_id or sql)")

    # Refuse SQL connector connection types up-front so the admin gets a
    # clear error instead of a confusing duckdb syntax error
    conn = _db().get_connection_raw(connection_id)
    if not conn:
        raise RuntimeError(f"connection_id {connection_id} not found")
    ctype = (conn.get("connection_type") or "").lower()
    if ctype in ("snowflake", "trino", "starburst", "databricks", "oracle", "athena"):
        raise RuntimeError(
            f"sql_query custom job runner only supports DuckDB-routed "
            f"connections (s3, local, upload).  For '{ctype}' use the "
            f"Schedules feature instead — it goes through the proper "
            f"connector path with auth/audit/persistence."
        )

    t0 = time.monotonic()
    try:
        from core.duckdb_factory import duckdb_connection
        with duckdb_connection() as con:
            # 2026-08-17 -- the removed `max_rows` param and this comment
            # ("Bound the result size") described a cap that DID NOT EXIST:
            # max_rows was read and never used, so nothing was ever bounded
            # and an admin who set it got no effect.  A COUNT(*) wrapper
            # returns one row by construction; the engine must still evaluate
            # the inner query, and a cap could not change that without
            # changing the answer.  Runner contract is explicitly "row count
            # only" -- no cap to apply, so the knob is gone rather than
            # left as a lie.  (It also carried the `or 10_000` zero-fold this
            # product treats as a defect: 0 means UNLIMITED here.)
            rows = con.execute(f"SELECT COUNT(*) FROM ({sql.rstrip(';')}) _q").fetchall()
            row_count = int(rows[0][0]) if rows else 0
    except Exception as exc:
        raise RuntimeError(f"sql run failed: {str(exc)[:300]}")
    dur = round(time.monotonic() - t0, 3)
    return {
        "row_count":          row_count,
        "duration_seconds":   dur,
        "connection_id":      connection_id,
        "note":               (
            "row_count returned via SELECT COUNT(*).  Result rows NOT "
            "persisted — use Schedules feature for that."
        ),
    }


def _run_iceberg_sync(params: dict) -> Dict[str, Any]:
    """Force-reconcile a specific iceberg table.  Reuses BF-299
    machinery and the snapshot/manifest caches."""
    from core.iceberg_metadata_sync import _build_s3_client, reconcile_table
    cid = int(params["connection_id"])
    bucket = params["bucket"]
    table_prefix = params["table_prefix"]
    client = _build_s3_client(cid)
    if client is None:
        raise RuntimeError(f"could not build S3 client for connection {cid}")
    if _db() is None:
        raise RuntimeError("DB manager not wired")
    # Make sure the table is registered as watched (so future ad-hoc
    # syncs by the BF-299 loop see it too)
    try:
        _db().upsert_watched_iceberg_table(
            connection_id=cid, bucket=bucket, table_prefix=table_prefix,
            pinned=True, enabled=True,
        )
    except Exception:
        pass
    result = reconcile_table(
        client, connection_id=cid, bucket=bucket,
        table_prefix=table_prefix, db_manager=_db(),
    )
    return {
        "snapshot_id":  result.get("snapshot_id"),
        "files_count":  result.get("files_count"),
        "seconds":      result.get("seconds"),
        "status":       result.get("status"),
        "predownload":  result.get("predownload"),
    }


def _run_cache_clear(params: dict) -> Dict[str, Any]:
    """Invalidate one of the project caches.  Whitelisted set only —
    no SQL injection / arbitrary key clearing."""
    cache_type = params["cache_type"]
    cleared = 0
    detail = ""
    if cache_type == "iceberg_snapshot":
        from core.iceberg_snapshot_cache import (
            invalidate_all_pointers, manifest_cache_clear,
        )
        n_p = invalidate_all_pointers()
        n_m = manifest_cache_clear()
        cleared = n_p + n_m
        detail = f"{n_p} pointers + {n_m} manifest L1 entries"
    elif cache_type == "iceberg_manifest":
        from core.iceberg_snapshot_cache import manifest_cache_clear
        cleared = manifest_cache_clear()
        detail = f"{cleared} manifest L1 entries"
    elif cache_type == "query_result":
        if _db() is None:
            raise RuntimeError("DB manager not wired")
        try:
            cleared = _db().clear_query_cache()
            detail = f"{cleared} query cache entries"
        except Exception as exc:
            raise RuntimeError(f"query_result clear failed: {exc}")
    elif cache_type == "partition":
        if _db() is None:
            raise RuntimeError("DB manager not wired")
        cleared = _db().delete_partition_cache()
        detail = f"{cleared} partition cache entries"
    elif cache_type == "schema":
        from core.iceberg_cache import _schema_cache, _schema_cache_lock
        with _schema_cache_lock:
            cleared = len(_schema_cache)
            _schema_cache.clear()
        detail = f"{cleared} schema cache entries"
    else:
        raise RuntimeError(f"unknown cache_type: {cache_type}")
    return {"cleared": cleared, "detail": detail, "cache_type": cache_type}


_RUNNERS: Dict[str, Callable[[dict], Dict[str, Any]]] = {
    "webhook":      _run_webhook,
    "sql_query":    _run_sql_query,
    "iceberg_sync": _run_iceberg_sync,
    "cache_clear":  _run_cache_clear,
}


def execute_one(job: dict) -> Dict[str, Any]:
    """Run a single job synchronously.  Pure function — does not touch
    DB.  Caller persists the result via update_custom_job()."""
    runner = _RUNNERS.get(job["job_type"])
    if runner is None:
        return {"status": "error", "error": f"unknown job_type: {job['job_type']}"}
    t0 = time.monotonic()
    try:
        result = runner(job.get("parameters") or {})
        dur = round(time.monotonic() - t0, 3)
        try:
            output = json.dumps(result, default=str)[:2000]
        except Exception:
            output = str(result)[:2000]
        return {
            "status":           "ok",
            "duration_seconds": dur,
            "output":           output,
        }
    except Exception as exc:
        dur = round(time.monotonic() - t0, 3)
        logger.warning("custom_job '%s' (%s) failed: %s",
                        job.get("name"), job.get("job_type"), exc,
                        exc_info=True)
        return {
            "status":           "error",
            "duration_seconds": dur,
            "error":            str(exc)[:500],
        }


def run_outcome_updates(job: Dict[str, Any], result: Dict[str, Any]) -> Dict[str, Any]:
    """The ``update_custom_job`` fields that record ONE run's outcome --
    and RELEASE the run lease the claim took (``running_since=None``).

    2026-10-10: built here once for the scheduler loop and the run-now
    route (each used to assemble its own copy).  ``next_run_at`` is NOT
    among them: the claim advanced it, and rewriting it after a slow run
    would move the schedule backwards.
    """
    updates: Dict[str, Any] = {
        "last_run_at":           datetime.now(timezone.utc),
        "last_status":           result.get("status"),
        "last_duration_seconds": result.get("duration_seconds", 0),
        "run_count":             (job.get("run_count") or 0) + 1,
        "running_since":         None,
    }
    if result.get("status") == "error":
        updates["last_error"] = result.get("error")
        updates["error_count"] = (job.get("error_count") or 0) + 1
    else:
        updates["last_error"] = None
        updates["last_output"] = result.get("output")
    return updates


# ── Scheduler loop ─────────────────────────────────────────────────────────

def _tick_seconds() -> float:
    try:
        from core.config import get as _cfg_get
        return max(5.0, float(_cfg_get("custom_jobs", "tick_seconds", 30) or 30))
    except Exception:
        return 30.0


def _enabled() -> bool:
    try:
        from core.config import get as _cfg_get
        return bool(_cfg_get("custom_jobs", "enabled", True))
    except Exception:
        return True


def _autostart_enabled() -> bool:
    try:
        from core.config import get as _cfg_get
        # 2026-09-15: was True while _DEFAULTS declares False -- the same
        # shape as the iceberg P0 (a feature DECLARED off that ARMS itself
        # the moment the key is missing).  Aligned to the declaration.
        return bool(_cfg_get("custom_jobs", "autostart", False))
    except Exception:
        return True


async def _process_due_jobs() -> Dict[str, Any]:
    """One pass: fetch due jobs from DB, run each off the event loop,
    persist last-run state.  Returns a summary dict.

    BF-314: every synchronous DB call is wrapped in asyncio.to_thread
    so the event loop stays responsive (/health, WS, query API) even
    when the scheduler tick is running.
    """
    if _db() is None:
        return {"skipped": True, "reason": "no db"}
    try:
        due = await _run_off_loop(_db().list_due_custom_jobs)
    except Exception as exc:
        logger.warning("custom_jobs list_due_custom_jobs failed: %s", exc)
        return {"error": str(exc)}
    ok = 0
    errored = 0
    skipped = 0
    for job in due:
        # ── Multi-pod atomic claim (mirrors queue_worker) ──────────────
        # Compute the NEXT firing BEFORE the claim so the claim can
        # advance next_run_at atomically — that advance IS both the
        # exactly-once gate (other pods see the row no longer due) and
        # the crash-recovery guarantee (schedule survives a mid-run
        # crash because next_run_at is already set forward).
        try:
            nxt = compute_next_run(job["cron_expression"])
        except Exception as exc:
            logger.warning("custom_jobs '%s' has invalid cron %r: %s",
                            job.get("name"), job.get("cron_expression"), exc)
            nxt = datetime.now(timezone.utc) + timedelta(hours=1)  # fallback
        # Claim the due occurrence.  On a single pod this always wins for
        # a legitimately-due job (behaviour identical to the old read-
        # then-run path); across N pods exactly one wins.
        _claim_fn = getattr(_db(), "claim_due_custom_job", None)
        if _claim_fn is None:
            # Legacy DB manager without the claim helper — fall back to
            # the pre-claim behaviour (single-pod safe; the multi-pod
            # race only re-appears on a DB layer that predates this fix).
            won = True
        else:
            try:
                won = await _run_off_loop(
                    _claim_fn, job["id"], new_next_run_at=nxt)
            except Exception as claim_exc:
                logger.warning(
                    "custom_jobs claim for '%s' failed (skipping this "
                    "tick): %s", job.get("name"), claim_exc)
                continue
        if not won:
            # Another pod owns this occurrence.
            skipped += 1
            continue

        # We own this occurrence — run the runner off the loop.
        try:
            result = await _run_off_loop(execute_one, job)
        except Exception as exc:
            result = {"status": "error", "error": str(exc)[:500],
                       "duration_seconds": 0}
        # Persist the run telemetry — also off the event loop.  NOTE:
        # next_run_at was ALREADY advanced by the atomic claim above, so
        # it is deliberately NOT written here (re-writing it post-run
        # would risk moving the schedule backward on a slow run).  The
        # same write releases the run lease the claim took.
        if result.get("status") == "error":
            errored += 1
        else:
            ok += 1
        try:
            await _run_off_loop(
                _db().update_custom_job, job["id"],
                **run_outcome_updates(job, result))
        except Exception as persist_exc:
            logger.warning(
                "custom_jobs persist for '%s' failed: %s",
                job.get("name"), persist_exc,
            )
        # Yield between jobs so /health stays responsive
        await asyncio.sleep(0)
    return {
        "ran":     ok + errored,
        "ok":      ok,
        "errors":  errored,
        "skipped": skipped,  # claimed by another pod this tick
        "ran_at":  datetime.now(timezone.utc).isoformat(),
    }


_last_summary: Dict[str, Any] = {}


def get_last_summary() -> Dict[str, Any]:
    return dict(_last_summary)


async def _scheduler_loop() -> None:
    """Forever loop — process due jobs every tick.  Cancelled on shutdown."""
    global _last_summary
    logger.info("custom_jobs scheduler loop started (tick=%.0fs)", _tick_seconds())
    while True:
        try:
            if not _enabled():
                _last_summary = {"skipped": True,
                                  "reason": "custom_jobs.enabled=false"}
            else:
                _last_summary = await _process_due_jobs()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.warning("custom_jobs scheduler error (continuing): %s", exc)
            _last_summary = {"error": str(exc)[:200]}
        try:
            await asyncio.sleep(_tick_seconds())
        except asyncio.CancelledError:
            raise


def start_custom_jobs_scheduler(db_manager) -> None:
    """Register + (optionally) start the scheduler in the central
    background_jobs registry so admin can pause / resume it."""
    init_custom_jobs(db_manager)
    try:
        from core import background_jobs as _bj
    except Exception:
        return

    async def _factory():
        await _scheduler_loop()

    _bj.register(
        name="custom_jobs_scheduler",
        description=(
            "BF-312 — runs admin-defined custom jobs (webhook / sql / "
            "iceberg sync / cache clear) on cron schedules."
        ),
        factory=_factory,
        autostart=_autostart_enabled(),
        controllable=True,
    )
