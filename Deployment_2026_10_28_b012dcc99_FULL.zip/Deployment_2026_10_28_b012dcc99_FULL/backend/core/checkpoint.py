"""
Query Checkpointing — survive server restarts during long-running queries.

Records execution intent before a query starts, marks it running, and
on startup recovers any orphaned (incomplete) executions by marking them
as failed so the user knows to retry.

Usage:
    from core.checkpoint import record_intent, mark_started, mark_completed, recover_incomplete
"""
from __future__ import annotations

import logging
import os
import socket
import time
from typing import Optional

logger = logging.getLogger(__name__)

# Module-level reference to DatabaseManager — set at startup
_db_manager = None

# 2026-08-02 multi-pod correctness: explicit pod-identity override (tests /
# operators).  When None, _pod_identity() derives it from the environment.
_pod_identity_override: Optional[str] = None


def _pod_identity() -> str:
    """Stable identity of THIS pod, stamped onto every checkpoint it writes.

    In K8s/OpenShift ``HOSTNAME`` is the pod name — unique across the fleet
    and stable across container restarts within the same pod, so a pod that
    crashes and restarts still recovers its OWN orphans (the N=1 behaviour
    users rely on).  ``QS_POD_IDENTITY`` overrides for special deployments.
    """
    if _pod_identity_override:
        return _pod_identity_override
    ident = os.environ.get("QS_POD_IDENTITY") or os.environ.get("HOSTNAME")
    if not ident:
        try:
            ident = socket.gethostname()
        except Exception:
            ident = ""
    return ident or "unknown-pod"


def init_checkpoint(db_manager, pod_identity: Optional[str] = None) -> None:
    """Set the DatabaseManager reference. Called once at startup.

    ``pod_identity``: optional explicit identity for this pod (tests /
    special deployments).  When omitted, the environment-derived identity
    is used (see :func:`_pod_identity`).
    """
    global _db_manager, _pod_identity_override
    _db_manager = db_manager
    if pod_identity is not None:
        _pod_identity_override = pod_identity or None
    logger.info("Checkpoint system initialised (pod=%s)", _pod_identity())


def record_intent(execution_id: str, query_config: dict,
                  executed_by: str = "", query_id: Optional[int] = None) -> None:
    """
    Record that we INTEND to run this execution.
    Called BEFORE the query actually starts so that if we crash between
    intent and start, recovery will find it.
    """
    if not _db_manager:
        return
    try:
        _db_manager.set_checkpoint(
            execution_id=execution_id,
            state="intent",
            query_config=query_config,
            executed_by=executed_by,
            query_id=query_id,
            timestamp=time.time(),
            owner=_pod_identity(),
        )
    except Exception as e:
        logger.warning("Failed to record checkpoint intent for %s: %s", execution_id, e)


def mark_started(execution_id: str) -> None:
    """Mark an execution as actively running."""
    if not _db_manager:
        return
    try:
        _db_manager.update_checkpoint(execution_id, state="running", timestamp=time.time())
    except Exception as e:
        logger.warning("Failed to mark checkpoint started for %s: %s", execution_id, e)


def mark_completed(execution_id: str) -> None:
    """Remove the checkpoint — execution finished (success or failure handled elsewhere)."""
    if not _db_manager:
        return
    try:
        _db_manager.delete_checkpoint(execution_id)
    except Exception as e:
        logger.warning("Failed to clear checkpoint for %s: %s", execution_id, e)


# ── The same three writes, for a caller ON THE EVENT LOOP (2026-10-07) ──────
#
# Measured in-process (12 users, 24 workers, /api/sql/execute + /api/execute
# + status polls): ~90% of every event-loop stall sample was inside these
# three functions -- ``record_intent`` in the submit route and
# ``mark_started`` / ``mark_completed`` in the background coroutines, each a
# synchronous DB write run INLINE on the loop.  On SQLite that is a writer
# lock wait; on Postgres a network round trip plus, under load, a pool
# checkout that can wait ``postgresql_pool_timeout`` (30 s) -- and while it
# waits, /health/live and every other request on the pod waits too
# (multiuser_load at 100 workers: /health/live p95 1.87 s, max 9.1 s).
#
# The submit route AWAITS the intent (``arecord_intent``): the execution row
# is written right after it in the same guarded block, so the order intent ->
# row -> run is exactly what it was.  The two later writes are SUBMITTED, not
# awaited (``mark_started_nowait`` / ``mark_completed_nowait``): they sit at
# the top of a background coroutine (before the ``try`` whose ``finally``
# releases the user's slot) and inside that ``finally`` -- a new ``await``
# in either place would be a new cancellation point that skips the release.
# They run on the dedicated ``checkpoint`` lane (core/interactive_lanes.py),
# never on asyncio's default executor, whose queue under load is the query
# traffic itself.  If ``running`` lands after the delete it is a no-op
# (``update_checkpoint`` touches only an existing row), so the lane's order
# does not matter.

async def arecord_intent(execution_id: str, query_config: dict,
                         executed_by: str = "", query_id: Optional[int] = None) -> None:
    """:func:`record_intent`, off the event loop (awaited)."""
    from core.interactive_lanes import run_in_lane
    await run_in_lane("checkpoint", record_intent, execution_id, query_config,
                      executed_by=executed_by, query_id=query_id)


def _submit(fn, execution_id: str) -> None:
    try:
        from core.interactive_lanes import submit_to_lane
        submit_to_lane("checkpoint", fn, execution_id)
    except Exception as exc:  # the lane itself failed: never lose the write
        logger.warning("checkpoint lane unavailable (%s) -- writing inline", exc)
        fn(execution_id)


def mark_started_nowait(execution_id: str) -> None:
    """:func:`mark_started`, submitted to the checkpoint lane; returns at once."""
    _submit(mark_started, execution_id)


def mark_completed_nowait(execution_id: str) -> None:
    """:func:`mark_completed`, submitted to the checkpoint lane; returns at once."""
    _submit(mark_completed, execution_id)


def _foreign_stale_seconds() -> float:
    """Age past which another pod's checkpoint is presumed orphaned.

    Must exceed the LONGEST legitimate query, or a slow job still running on
    a sibling pod would be marked failed underneath it.  The longest work-type
    timeout is SCHEDULED at 7200s, so the default is that plus a margin.

    Lower it for faster cleanup after a rollout if you never run multi-hour
    jobs; raise it if you do.  Never raises.
    """
    try:
        from core.config import get as _cfg_get
        v = float(_cfg_get("checkpoint", "foreign_stale_seconds", 9000) or 9000)
        return v if v > 0 else 9000.0
    except Exception as exc:
        logger.debug("checkpoint stale-threshold read failed: %s", exc)
        return 9000.0


def recover_incomplete() -> int:
    """
    On startup: find THIS pod's checkpointed executions (intent or running)
    and mark the corresponding execution records as 'failed' with a recovery
    message.

    2026-08-02 multi-pod correctness: recovery is scoped to checkpoints
    stamped with the recovering pod's own identity.  Before this, every pod
    boot (HPA scale-up, rolling deploy) reaped EVERY checkpoint in the
    fleet and failed all in-flight executions at once.  Because the K8s pod
    name is stable across container restarts of the same pod, a restarting
    pod still recovers exactly its own orphans — N=1 behaviour unchanged.

    Legacy rows with no owner stamp (written before this change, or by
    not-yet-upgraded pods during a rolling deploy) are recovered by ANY
    pod — identical to the pre-change behaviour, so the transition is never
    worse than the status quo and converges once the fleet is upgraded.

    Returns the number of recovered executions.
    """
    if not _db_manager:
        return 0
    try:
        me = _pod_identity()
        orphans = _db_manager.get_all_checkpoints()
        count = 0
        skipped_foreign = 0
        for cp in orphans:
            exec_id = cp["execution_id"]
            state = cp.get("state", "unknown")
            cp_owner = cp.get("owner")
            if cp_owner and cp_owner != me:
                # Another pod's execution — but is that pod still ALIVE?
                #
                # In Kubernetes HOSTNAME is the POD NAME, and pod names change
                # on EVERY deploy.  Scoping recovery to "owner == me" therefore
                # broke the single-pod case it was never meant to touch: after
                # a rollout the new pod skips the old pod's checkpoints as
                # "foreign", so those executions stay marked running FOREVER —
                # never recovered, never failed.  Before the ownership change,
                # any boot reaped them.
                #
                # A checkpoint older than every legitimate query timeout cannot
                # belong to a live execution, whoever owns it.  Adopt those;
                # keep skipping recent ones, which is the multi-pod case the
                # ownership scoping exists for.
                _age = 0.0
                try:
                    _age = max(0.0, time.time() - float(cp.get("timestamp") or 0))
                except (TypeError, ValueError):
                    _age = 0.0
                if _age < _foreign_stale_seconds():
                    skipped_foreign += 1
                    logger.debug(
                        "Checkpoint %s owned by live pod %s (we are %s, age "
                        "%.0fs) — skipping", exec_id, cp_owner, me, _age)
                    continue
                logger.warning(
                    "Adopting checkpoint %s from pod %s (we are %s): age "
                    "%.0fs exceeds the stale threshold, so its owner is gone "
                    "(pod names change on every deploy).",
                    exec_id, cp_owner, me, _age)
            logger.warning("Recovering orphaned execution %s (checkpoint state: %s)", exec_id, state)
            try:
                _db_manager.update_execution(
                    exec_id,
                    status="failed",
                    error_message=f"Server restarted while query was {state}. Please retry.",
                )
            except Exception:
                pass  # execution record may not exist if crash was before DB write
            _db_manager.delete_checkpoint(exec_id)
            count += 1
        if skipped_foreign:
            logger.info(
                "Checkpoint recovery: left %d checkpoint(s) owned by other "
                "pods untouched (multi-pod scoped recovery)", skipped_foreign)
        if count:
            logger.info("Recovered %d orphaned execution(s) from checkpoint", count)
        return count
    except Exception as e:
        logger.error("Checkpoint recovery failed: %s", e)
        return 0


#: The ``executed_by`` spelling of a published-view execution row
#: (``api.published_views_api._execute_view_saved_query``).
PUBLISHED_VIEW_EXECUTED_BY_PREFIX = "published_view:"


def recover_orphaned_published_view_executions() -> int:
    """On startup: fail published-view execution rows a dead process left
    ``pending`` or ``processing``.  Returns how many it failed.

    2026-10-07 (F11).  The published-view handler never records a
    checkpoint, so :func:`recover_incomplete` cannot see its rows -- 150
    sat ``pending`` on the rig (plus the main.py sweep only ever looked at
    ``running``, a status no executor writes to ``query_executions``).

    OWNERSHIP, the same rule as a foreign checkpoint above: such a row
    carries no owner stamp, and the published-API pod runs several
    processes under ONE pod name -- a process that restarts cannot tell its
    own dead rows from a live sibling's.  So a row is failed only when it
    is older than :func:`_foreign_stale_seconds` (default 9000 s, above the
    longest work-type timeout; PUBLISHED_API's is 1800 s): no live run on
    any pod or process can own it.  A row that DOES hold a checkpoint is
    left to :func:`recover_incomplete`.  Never raises.
    """
    if not _db_manager:
        return 0
    try:
        from datetime import datetime, timedelta, timezone
        cutoff = (datetime.now(timezone.utc)
                  - timedelta(seconds=_foreign_stale_seconds()))
        total = 0
        for status in ("pending", "processing"):
            ids = _db_manager.fail_orphaned_executions(
                executed_by_prefix=PUBLISHED_VIEW_EXECUTED_BY_PREFIX,
                statuses=(status,),
                started_before=cutoff,
                error_message=(f"Server restarted while query was {status}. "
                               f"Please retry."),
            )
            if ids:
                logger.warning(
                    "Recovered %d orphaned published-view execution(s) left "
                    "%s (older than the stale threshold): %s%s", len(ids),
                    status, ", ".join(ids[:20]),
                    " ..." if len(ids) > 20 else "")
            total += len(ids)
        return total
    except Exception:
        logger.exception("Published-view execution recovery failed")
        return 0
