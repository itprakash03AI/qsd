"""core/completeness_sentinel.py — the autonomous pruning-TRUST agent.

2026-07-16.  Goal: the system itself NOTICES when pruning has become
untrustworthy for a table, PROTECTS the data (auto-escalates that table's
trust mode), FIXES THE ROOT CAUSE (re-captures the stored per-file stats via
the watcher), and EXPLAINS to the user WHY — with the actual numbers and a
probable cause.  The user configures NOTHING per table; the Sentinel decides
on evidence and auto-recovers.

────────────────────────────────────────────────────────────────────────────
WHY THIS IS SHAPED THE WAY IT IS  (the core insight)
────────────────────────────────────────────────────────────────────────────
The iceberg watcher (``core.iceberg_metadata_sync``) opens every data file
ONCE and stores its per-file stats (lower/upper bounds + record_count) in the
DB.  EVERY query then prunes from those STORED stats and never re-opens a
file.  So pruning is only untrustworthy when the STORED STATS are:
  • INCOMPLETE — the watcher hasn't captured usable bounds for the queried
    columns across (near) all files, so some keep/drop decisions were made
    blind; OR
  • STALE — the stored stats are behind the current snapshot.
That is the PRIMARY signal, and the SMART self-heal is NOT to full-scan
(re-open every file forever) — it is to TRIGGER THE WATCHER to re-capture
this one table's stats.  full_scan is only a TEMPORARY stopgap the Sentinel
holds WHILE the watcher catches up, and it auto-lifts the moment the stored
stats are complete + fresh again (verified from the stats themselves — no
file re-open).

Genuine EVIDENCE OF LOSS (a completeness verdict of INCOMPLETE / over, a
scan-ledger over_count, or a shadow-sample divergence) is a different, harder
class: rows are actually missing or wrong, which usually means the PRUNE or
DELETE logic is broken rather than the stats.  That escalates immediately to
full_scan and recovers only under a guarded verify.

────────────────────────────────────────────────────────────────────────────
SIGNAL SEMANTICS  (do NOT conflate "ineffective" with "wrong")
────────────────────────────────────────────────────────────────────────────
HARD (genuine loss → PROVEN_RISK, full_scan immediately, guarded recovery):
  • completeness verdict INCOMPLETE or over   (rows missing / deletes wrong)
  • scan_ledger verdict over_count            (MoR delete undercount)
  • shadow-sample divergence beyond tolerance (wrong-prune, real re-read)

STATS-RISK (root cause = stored stats incomplete/stale → STATS_RECOVERY:
             trigger watcher + TEMP full_scan; auto-lifts when stats catch up):
  • stats coverage for the WHERE columns below threshold (INCOMPLETE)
  • stale snapshot / freshness trigger / scan_ledger under_count (STALE)
  Requires N occurrences in a window (one blip never escalates the mode; the
  watcher is nudged on the FIRST sighting regardless, since that is cheap).

SOFT-INEFFECTIVE (pruning barely narrows files — NOT wrong → SUSPECT, audited):
  • high prunability bounds-overlap  (pruning ineffective, not incorrect)
  • persistently ``unverified`` completeness (we COULDN'T check — never proof
    of loss on its own)
  Requires N occurrences in a window.  Escalates only to ``audited`` (turn on
  background sampling) — NEVER to full_scan.  This is the anti-false-alarm
  firewall: "ineffective / unverifiable" can never quarantine a table.

────────────────────────────────────────────────────────────────────────────
STATE MACHINE (per table, in-memory, pod-local; alerts go cross-pod via bus)
────────────────────────────────────────────────────────────────────────────
  HEALTHY ──soft×N──▶ SUSPECT ──sustained-clean+cooldown──▶ HEALTHY
     │                   (mode audited)
     ├──stats×N──▶ STATS_RECOVERY ──stats complete+fresh──▶ RECOVERING ─▶ HEALTHY
     │              (mode full_scan, watcher triggered)
     └──HARD──────▶ PROVEN_RISK ──min-quarantine+cooldown+VERIFY──▶ RECOVERING ─▶ HEALTHY
                     (mode full_scan)
A HARD signal escalates from ANY state immediately.  A HARD or fresh
STATS/soft signal during RECOVERING re-escalates.

ESCALATE-FREELY / DOWNGRADE-GUARDED (the one safety property that matters):
  Escalation makes a table MORE inclusive (fast→audited adds sampling only;
  →full_scan disables pruning = strictly more data) so it happens freely on
  evidence.  The ONLY dangerous move is DOWNGRADING full_scan→fast (it could
  re-enable a broken prune), so it is gated by: a min-quarantine floor, a
  sustained-health cooldown, AND a VERIFY that MATCHES — preferring the
  independent STORED-STATS re-check (no file re-open) and, for the loss lane,
  a shadow re-run when a re-executor is registered.  Without proof we DO NOT
  auto-downgrade (manual admin clear is the escape hatch).

Everything here is OBSERVATIONAL: the Sentinel decides MODES only.  It never
alters a query's rows or files.  Modes take effect via
``completeness_control.resolve_table_mode`` on the NEXT query.  Every entry
point is fail-open: a Sentinel exception is logged + dropped and the table
stays in its current mode.
"""
from __future__ import annotations

import logging
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, Deque, Dict, List, Optional, Tuple

import core.completeness_control as cc

logger = logging.getLogger(__name__)

# ── States ──────────────────────────────────────────────────────────────────
HEALTHY = "HEALTHY"
SUSPECT = "SUSPECT"
PROVEN_RISK = "PROVEN_RISK"
STATS_RECOVERY = "STATS_RECOVERY"
RECOVERING = "RECOVERING"

# Effective trust mode reported for a state (the actual routing is done by
# completeness_control.resolve_table_mode via quarantine / audited overrides).
_STATE_MODE = {
    HEALTHY:        cc.MODE_FAST,
    SUSPECT:        cc.MODE_AUDITED,
    PROVEN_RISK:    cc.MODE_FULL_SCAN,
    STATS_RECOVERY: cc.MODE_FULL_SCAN,
    RECOVERING:     cc.MODE_FULL_SCAN,
}

# Signal categories.
CAT_HARD = "hard"
CAT_STATS = "stats"
CAT_SOFT = "soft"


# ═══════════════════════════════════════════════════════════════════════════
# Config — all fail-open to the documented defaults.
# ═══════════════════════════════════════════════════════════════════════════
def _cfg(key: str, default: Any) -> Any:
    try:
        from core.config import get as _get
        val = _get("completeness_sentinel", key, default)
        return default if val is None else val
    except Exception:
        return default


def enabled() -> bool:
    try:
        return bool(_cfg("enabled", True))
    except Exception:
        return True


def query_triggered_resync_enabled() -> bool:
    """When True, a query that observes low stats-coverage nudges the watcher to
    reconcile that table (S3 manifest walk + per-file footer scan) inline.

    Default **FALSE** — the query path must never trigger heavy S3 background
    work: on a hybrid/misconfigured pod that couples live query latency to a
    reconcile scan and hammers the connection pool.  The scheduled metadata-sync
    daemon (worker/hybrid pod) already refreshes per-file stats on its own tick,
    so disabling the query-path nudge only changes WHEN stats recover (next
    daemon tick vs. immediately), never WHETHER.  Operators running a single
    embedded pod who want on-demand self-heal can opt in."""
    try:
        return bool(_cfg("query_triggered_resync_enabled", False))
    except Exception:
        return False


def stats_coverage_min() -> float:
    try:
        return min(1.0, max(0.0, float(_cfg("stats_coverage_min", 0.5))))
    except Exception:
        return 0.5


def overlap_max() -> float:
    try:
        return min(1.0, max(0.0, float(_cfg("overlap_max", 0.9))))
    except Exception:
        return 0.9


def soft_window_seconds() -> float:
    try:
        return max(1.0, float(_cfg("soft_window_seconds", 3600)))
    except Exception:
        return 3600.0


def soft_count() -> int:
    try:
        return max(1, int(_cfg("soft_count", 3)))
    except Exception:
        return 3


def recovery_cooldown_seconds() -> float:
    try:
        return max(0.0, float(_cfg("recovery_cooldown_seconds", 1800)))
    except Exception:
        return 1800.0


def min_quarantine_seconds() -> float:
    try:
        return max(0.0, float(_cfg("min_quarantine_seconds", 900)))
    except Exception:
        return 900.0


def require_shadow_verify_to_recover() -> bool:
    try:
        return bool(_cfg("require_shadow_verify_to_recover", True))
    except Exception:
        return True


# ═══════════════════════════════════════════════════════════════════════════
# Pure helper — INDEPENDENT stored-stats prune re-verification (NO file open).
# ═══════════════════════════════════════════════════════════════════════════
def _num(v: Any) -> Optional[float]:
    try:
        if v is None:
            return None
        return float(v)
    except (TypeError, ValueError):
        return None


def _bounds_could_match(op: str, value: Any, lo: Any, hi: Any) -> Optional[bool]:
    """Could a file with stored bounds [lo,hi] contain a row matching the
    predicate?  Returns True/False, or None when the comparison is not
    decidable (mixed/uncomparable types) — the caller then SKIPS that file
    (conservative: never fabricates a wrong-prune it cannot prove)."""
    op = str(op or "eq").lower()
    nlo, nhi = _num(lo), _num(hi)
    # Numeric path (the common case for stored min/max bounds).
    if op in ("eq", "in", "==", "="):
        vals = value if isinstance(value, (list, tuple, set)) else [value]
        decided_any = False
        for v in vals:
            nv = _num(v)
            if nv is None or nlo is None or nhi is None:
                continue
            decided_any = True
            if nlo <= nv <= nhi:
                return True
        return False if decided_any else None
    nv = _num(value)
    if nv is None or nlo is None or nhi is None:
        return None
    if op in ("lt", "<"):
        return nlo < nv          # some row could be < value
    if op in ("le", "<="):
        return nlo <= nv
    if op in ("gt", ">"):
        return nhi > nv
    if op in ("ge", ">="):
        return nhi >= nv
    return None


def stats_reverify_prune(
    *,
    op: str,
    value: Any,
    dropped_bounds: Optional[List[Dict[str, Any]]],
    lower_key: str = "lower",
    upper_key: str = "upper",
    file_key: str = "file",
) -> Dict[str, Any]:
    """Re-check a PRUNE decision using ONLY the stored per-file bounds of the
    DROPPED files — no file re-open, no data re-scan.

    A dropped file whose stored ``[lower, upper]`` COULD contain a value
    satisfying the predicate was WRONGLY pruned (the prune logic dropped a
    file that may hold matching rows → data loss).  Files whose bounds are
    uncomparable to the predicate are skipped (never flagged) so this can only
    ever report a wrong-prune it can actually prove from the stats.

    Returns ``{"ok": bool, "offending": [file,...], "checked": n,
    "skipped": n}``.  ``ok=False`` ⇒ a provable wrong-prune was found.
    """
    offending: List[Any] = []
    checked = 0
    skipped = 0
    try:
        for e in (dropped_bounds or []):
            if not isinstance(e, dict):
                skipped += 1
                continue
            lo = e.get(lower_key)
            hi = e.get(upper_key)
            verdict = _bounds_could_match(op, value, lo, hi)
            if verdict is None:
                skipped += 1
                continue
            checked += 1
            if verdict:
                offending.append(e.get(file_key))
        return {"ok": not offending, "offending": offending,
                "checked": checked, "skipped": skipped}
    except Exception as exc:
        logger.debug("[sentinel] stats reverify failed (fail-open ok): %s", exc)
        return {"ok": True, "offending": [], "checked": 0, "skipped": 0,
                "error": str(exc)}


# ═══════════════════════════════════════════════════════════════════════════
# Signal extraction from the brain's ``_out_meta`` (real field names).
# ═══════════════════════════════════════════════════════════════════════════
def _min_where_coverage(stats_coverage: Optional[Dict[str, Any]],
                        where_columns: Optional[List[str]]) -> Optional[float]:
    """Smallest per-file bounds-coverage fraction across the WHERE columns
    (or all covered columns when the WHERE set is unknown).  ``None`` when
    there is no coverage data to judge (→ cannot claim incomplete)."""
    if not isinstance(stats_coverage, dict) or not stats_coverage:
        return None
    cols = [c for c in (where_columns or []) if c in stats_coverage] or list(stats_coverage)
    worst: Optional[float] = None
    for c in cols:
        entry = stats_coverage.get(c)
        if not isinstance(entry, dict):
            continue
        total = entry.get("total_enumerated")
        got = entry.get("files_with_bounds")
        try:
            total = int(total)
            got = int(got)
        except (TypeError, ValueError):
            continue
        if total <= 0:
            continue
        frac = got / total
        worst = frac if worst is None else min(worst, frac)
    return worst


def _max_overlap(prunability: Optional[Dict[str, Any]],
                 where_columns: Optional[List[str]]) -> Optional[float]:
    if not isinstance(prunability, dict) or not prunability:
        return None
    cols = [c for c in (where_columns or []) if c in prunability] or list(prunability)
    worst: Optional[float] = None
    for c in cols:
        p = prunability.get(c)
        if not isinstance(p, dict):
            continue
        ov = p.get("bounds_overlap_ratio")
        try:
            ov = float(ov)
        except (TypeError, ValueError):
            continue
        worst = ov if worst is None else max(worst, ov)
    return worst


def extract_signals(
    out_meta: Optional[Dict[str, Any]],
    *,
    where_columns: Optional[List[str]] = None,
    resync_ctx: Optional[Dict[str, Any]] = None,
    execution_id: Optional[str] = None,
) -> Dict[str, Any]:
    """Fuse the brain's already-computed diagnostics from ``_out_meta`` into
    one normalized signals dict the Sentinel understands.  Pure read — never
    mutates ``out_meta``.  Missing keys degrade to ``None`` (no signal)."""
    sig: Dict[str, Any] = {
        "execution_id": execution_id,
        "where_columns": list(where_columns or []),
        "resync_ctx": dict(resync_ctx or {}),
    }
    if not isinstance(out_meta, dict):
        return sig
    try:
        comp = out_meta.get("completeness")
        if isinstance(comp, dict):
            sig["completeness_verdict"] = comp.get("verdict")
            sig["expected_rows"] = comp.get("expected_rows")
            sig["rows_read"] = comp.get("rows_read")
        ledger = out_meta.get("scan_ledger")
        if isinstance(ledger, dict):
            sig["scan_ledger_verdict"] = ledger.get("verdict")
            sig["scan_ledger"] = {
                "considered": ledger.get("considered"),
                "final": ledger.get("final"),
                "declared_total": ledger.get("declared_total"),
                "delta_considered": ledger.get("delta_considered"),
            }
        sig["stats_coverage_min_frac"] = _min_where_coverage(
            out_meta.get("stats_coverage"), where_columns)
        sig["prune_overlap_max"] = _max_overlap(
            out_meta.get("prunability"), where_columns)
        af = out_meta.get("adaptive_freshness")
        if isinstance(af, dict):
            # 2026-07 FIX: staleness is the explicit ``stale`` flag (True ONLY
            # when a strictly-newer metadata was actually adopted), NOT
            # ``trigger and not refreshed``.  A trigger merely means "we
            # CHECKED" — config_force / stale_by_cadence fire on healthy tables
            # whose scan then CONFIRMS the pointer is already newest (refreshed
            # stays False), which the old expression mis-counted as stale →
            # escalated fast→full_scan on every query.  Back-compat: if the
            # producer didn't stamp ``stale`` (older reader), fall back to the
            # old signal so we don't lose genuine staleness detection.
            if "stale" in af:
                sig["freshness_stale"] = bool(af.get("stale"))
            else:
                sig["freshness_stale"] = bool(af.get("trigger")) and not bool(af.get("refreshed"))
            sig["freshness"] = {"trigger": af.get("trigger"),
                                "refreshed": bool(af.get("refreshed")),
                                "stale": bool(af.get("stale"))}
        inc = out_meta.get("completeness_shadow_incident")
        if isinstance(inc, dict) and inc.get("diverged", True) and inc.get("kind"):
            sig["shadow_divergence"] = {
                "pruned_rows": inc.get("pruned_rows"),
                "full_rows": inc.get("full_rows"),
                "missing_rows": inc.get("missing_rows"),
            }
    except Exception as exc:
        logger.debug("[sentinel] extract_signals failed (fail-open): %s", exc)
    return sig


# ═══════════════════════════════════════════════════════════════════════════
# Per-table trust state.
# ═══════════════════════════════════════════════════════════════════════════
@dataclass
class TableState:
    table: str
    state: str = HEALTHY
    since: float = 0.0                         # when current state was entered
    quarantined_at: Optional[float] = None     # when full_scan lane started
    reason: str = ""
    health_clean_since: Optional[float] = None  # sustained-clean streak start
    lane: str = ""                             # "loss" | "stats" (for RECOVERING)
    pinned: Optional[str] = None               # admin manual pin (mode)
    # window of (ts, category, signal_name) soft/stats events
    events: Deque[Tuple[float, str, str]] = field(default_factory=lambda: deque(maxlen=256))
    # exec-id de-dup so two entry points for the SAME query don't double count
    last_exec: Dict[str, Optional[str]] = field(default_factory=dict)


# ═══════════════════════════════════════════════════════════════════════════
# The Sentinel.
# ═══════════════════════════════════════════════════════════════════════════
class CompletenessSentinel:
    """In-memory registry + decision engine.  Thread-safe.  Pod-local state;
    alerts propagate cross-pod via the event bus."""

    _ALERTS_MAX = 500

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._tables: Dict[str, TableState] = {}
        self._alerts: Deque[Dict[str, Any]] = deque(maxlen=self._ALERTS_MAX)

    # ── public entry point ──────────────────────────────────────────────
    def observe(
        self,
        table_prefix: Optional[str],
        signals: Optional[Dict[str, Any]] = None,
        *,
        out_meta: Optional[Dict[str, Any]] = None,
        where_columns: Optional[List[str]] = None,
        resync_ctx: Optional[Dict[str, Any]] = None,
        now: Optional[float] = None,
    ) -> Optional[str]:
        """Fuse this query's signals for ``table_prefix`` and advance the state
        machine.  Cheap, fail-open, NEVER blocks or alters the query.  Returns
        the resulting state (or ``None`` on skip/error)."""
        try:
            if not enabled():
                return None
            tp = str(table_prefix or "").strip()
            if not tp:
                return None
            if signals is None:
                signals = extract_signals(
                    out_meta, where_columns=where_columns, resync_ctx=resync_ctx)
            ts = time.time() if now is None else float(now)
            with self._lock:
                st = self._tables.get(tp)
                if st is None:
                    st = TableState(table=tp, since=ts)
                    self._tables[tp] = st
                return self._advance(st, signals, ts)
        except Exception as exc:
            # FAIL-OPEN: a decision error must never surface or change a mode.
            logger.debug("[sentinel] observe failed (fail-open, mode untouched): %s", exc)
            return None

    # ── classification ──────────────────────────────────────────────────
    def _classify(self, signals: Dict[str, Any]) -> Dict[str, Any]:
        """Split signals into hard / stats / soft findings with evidence +
        probable cause, plus a proof that stats are complete+fresh (for the
        stats-lane auto-lift)."""
        hard: List[Dict[str, Any]] = []
        stats: List[Dict[str, Any]] = []
        soft: List[Dict[str, Any]] = []

        # ---- HARD (genuine evidence of loss) --------------------------------
        cv = signals.get("completeness_verdict")
        if cv in ("INCOMPLETE", "over"):
            exp, got = signals.get("expected_rows"), signals.get("rows_read")
            delta = None
            try:
                if exp is not None and got is not None:
                    delta = int(got) - int(exp)
            except (TypeError, ValueError):
                delta = None
            if cv == "INCOMPLETE":
                cause = ("a KEPT file was silently skipped / read-failed OR "
                         "deletes over-applied — rows_read is below expected_rows")
            else:
                cause = ("deletes UNDER-applied (MoR-overcount class) — rows_read "
                         "is above expected_rows")
            hard.append({
                "name": f"completeness_{cv}", "category": CAT_HARD,
                "evidence": {"verdict": cv, "expected_rows": exp,
                             "rows_read": got, "delta": delta},
                "cause": cause,
                "action": "quarantine to full_scan; investigate prune/delete logic",
            })
        slv = signals.get("scan_ledger_verdict")
        if slv == "over_count":
            led = signals.get("scan_ledger") or {}
            hard.append({
                "name": "scan_ledger_over_count", "category": CAT_HARD,
                "evidence": {"considered": led.get("considered"),
                             "declared_total": led.get("declared_total"),
                             "delta_considered": led.get("delta_considered")},
                "cause": ("scan ledger counted MORE files than the snapshot "
                          "declared — MoR delete undercount / duplicated or "
                          "stale manifest refs"),
                "action": "quarantine to full_scan; reconcile manifests",
            })
        sd = signals.get("shadow_divergence")
        if sd:
            ev = sd if isinstance(sd, dict) else {}
            hard.append({
                "name": "shadow_divergence", "category": CAT_HARD,
                "evidence": {"pruned_rows": ev.get("pruned_rows"),
                             "full_rows": ev.get("full_rows"),
                             "missing_rows": ev.get("missing_rows")},
                "cause": ("a full-scan re-run saw MORE rows than the pruned run "
                          "— the prune logic is dropping matching rows for this "
                          "table's data (wrong-prune)"),
                "action": "quarantine to full_scan; fix prune predicate handling",
            })

        # ---- STATS-RISK (root cause = stored stats incomplete/stale) --------
        cov = signals.get("stats_coverage_min_frac")
        if cov is not None and cov < stats_coverage_min():
            stats.append({
                "name": "stats_incomplete", "category": CAT_STATS,
                "evidence": {"stats_coverage": round(float(cov), 4),
                             "threshold": stats_coverage_min(),
                             "where_columns": signals.get("where_columns")},
                "cause": ("the watcher has NOT captured usable per-file min/max "
                          "stats for the queried column(s) across all files — "
                          "some prune/keep decisions were made without bounds"),
                "action": ("trigger the watcher to (re)capture this table's "
                           "per-file column stats; hold full_scan meanwhile"),
            })
        stale = bool(signals.get("freshness_stale")) or (slv == "under_count")
        if stale:
            led = signals.get("scan_ledger") or {}
            ev: Dict[str, Any] = {"freshness_stale": bool(signals.get("freshness_stale"))}
            if slv == "under_count":
                ev["scan_ledger"] = {"considered": led.get("considered"),
                                     "declared_total": led.get("declared_total")}
            stats.append({
                "name": "stats_stale", "category": CAT_STATS,
                "evidence": ev,
                "cause": ("the stored snapshot / per-file stats are BEHIND the "
                          "current table snapshot (stale pointer) — run a "
                          "metadata refresh"),
                "action": ("trigger the watcher to refresh this table's "
                           "snapshot + stats; hold full_scan meanwhile"),
            })

        # ---- SOFT-INEFFECTIVE (pruning barely helps — NOT wrong) ------------
        ov = signals.get("prune_overlap_max")
        if ov is not None and ov > overlap_max():
            soft.append({
                "name": "high_prune_overlap", "category": CAT_SOFT,
                "evidence": {"bounds_overlap": round(float(ov), 4),
                             "threshold": overlap_max()},
                "cause": ("the query bounds overlap most files — pruning barely "
                          "narrows the scan here (INEFFECTIVE, not incorrect); "
                          "auditing with background sampling to confirm"),
                "action": "enable background shadow sampling (audited)",
            })
        if cv == "unverified":
            soft.append({
                "name": "unverified_persistent", "category": CAT_SOFT,
                "evidence": {"verdict": "unverified",
                             "expected_rows": signals.get("expected_rows"),
                             "rows_read": signals.get("rows_read")},
                "cause": ("completeness could not be verified (missing "
                          "record_count / scan-count metadata) — this is NOT "
                          "evidence of loss; auditing to gather evidence"),
                "action": "enable background shadow sampling (audited)",
            })

        # ---- proof that stats are COMPLETE + FRESH (for stats-lane lift) ----
        stats_proven_clean = (
            cov is not None and cov >= stats_coverage_min() and not stale)

        return {"hard": hard, "stats": stats, "soft": soft,
                "stats_proven_clean": stats_proven_clean}

    # ── window bookkeeping (with exec-id de-dup) ────────────────────────
    def _record_events(self, st: TableState, findings: List[Dict[str, Any]],
                       category: str, exec_id: Optional[str], ts: float) -> int:
        """Append this query's findings for ``category`` to the window and
        return the DISTINCT count in the window.  De-dups by exec id so the
        stamp-point and finalize-hook entry points for one query can't
        double-count."""
        window = soft_window_seconds()
        # prune expired
        while st.events and (ts - st.events[0][0]) > window:
            st.events.popleft()
        already = st.last_exec.get(category)
        if findings and exec_id is not None and exec_id == already:
            pass  # same query already counted for this category
        elif findings:
            for f in findings:
                st.events.append((ts, category, f.get("name", category)))
            st.last_exec[category] = exec_id
        return sum(1 for (_t, c, _n) in st.events if c == category)

    # ── the transition engine ───────────────────────────────────────────
    def _advance(self, st: TableState, signals: Dict[str, Any], ts: float) -> str:
        cls = self._classify(signals)
        hard = cls["hard"]
        stats = cls["stats"]
        soft = cls["soft"]
        exec_id = signals.get("execution_id")
        resync_ctx = signals.get("resync_ctx") or {}

        # 1) HARD signal — escalate immediately from ANY state.
        if hard:
            self._record_events(st, hard, CAT_HARD, exec_id, ts)
            if st.state != PROVEN_RISK:
                self._to_proven_risk(st, hard[0], ts)
            else:
                st.health_clean_since = None  # sustained-health streak broken
            return st.state

        # 2) STATS-RISK — nudge the watcher on FIRST sighting; escalate to a
        #    temporary full_scan only after N-in-window (avoid one-off blips).
        if stats:
            # Root-cause self-heal — OFF the query path by default
            # (query_triggered_resync_enabled=False).  A query must never nudge
            # an S3 reconcile scan; the scheduled metadata-sync daemon refreshes
            # per-file stats on its own tick.  Opt-in for single-pod installs.
            if query_triggered_resync_enabled():
                self._trigger_watcher(st, resync_ctx, stats[0])
            count = self._record_events(st, stats, CAT_STATS, exec_id, ts)
            if st.state in (PROVEN_RISK,):
                st.health_clean_since = None
                return st.state
            if st.state == STATS_RECOVERY:
                st.health_clean_since = None  # still risky — reset streak
                return st.state
            if count >= soft_count():
                self._to_stats_recovery(st, stats[0], ts)
            elif st.state == HEALTHY:
                # accumulating evidence; no mode change yet (watcher nudged).
                st.reason = "stats-risk accumulating (%d/%d)" % (count, soft_count())
            return st.state

        # 3) SOFT-INEFFECTIVE — SUSPECT (audited) after N-in-window. Never
        #    full_scan.  Does not disturb a quarantined table.
        if soft:
            if st.state in (PROVEN_RISK, STATS_RECOVERY, RECOVERING):
                st.health_clean_since = None  # not clean — delay any recovery
                return st.state
            count = self._record_events(st, soft, CAT_SOFT, exec_id, ts)
            if st.state == HEALTHY and count >= soft_count():
                self._to_suspect(st, soft[0], ts)
            elif st.state == HEALTHY:
                st.reason = "soft-signal accumulating (%d/%d)" % (count, soft_count())
            return st.state

        # 4) CLEAN observation — drive recovery per state.
        return self._on_clean(st, cls, signals, ts)

    # ── recovery ────────────────────────────────────────────────────────
    def _on_clean(self, st: TableState, cls: Dict[str, Any],
                  signals: Dict[str, Any], ts: float) -> str:
        if st.state == HEALTHY:
            return st.state

        if st.state == SUSPECT:
            # audited→fast is SAFE (both prune identically; audited only adds
            # sampling), so sustained clean + cooldown restores fast.
            if st.health_clean_since is None:
                st.health_clean_since = ts
            if (ts - st.health_clean_since) >= recovery_cooldown_seconds():
                self._restore_healthy(st, ts, "sustained clean signals")
            return st.state

        if st.state == STATS_RECOVERY:
            # Lift the moment the STORED stats are proven complete + fresh
            # (verified from the stats themselves — no file re-open), past a
            # min-quarantine floor to avoid thrash.
            if not cls["stats_proven_clean"]:
                st.health_clean_since = None
                return st.state
            if st.health_clean_since is None:
                st.health_clean_since = ts
            floor_ok = (st.quarantined_at is None
                        or (ts - st.quarantined_at) >= min_quarantine_seconds())
            if floor_ok:
                st.lane = "stats"
                self._to_recovering(st, ts, "stats complete + fresh")
                return self._verify_and_restore(st, signals, ts)
            return st.state

        if st.state == PROVEN_RISK:
            # GUARDED: only after min-quarantine floor AND sustained-health
            # cooldown do we even attempt a verify.
            if st.health_clean_since is None:
                st.health_clean_since = ts
            floor_ok = (st.quarantined_at is None
                        or (ts - st.quarantined_at) >= min_quarantine_seconds())
            cooldown_ok = (ts - st.health_clean_since) >= recovery_cooldown_seconds()
            if floor_ok and cooldown_ok:
                st.lane = "loss"
                self._to_recovering(st, ts, "sustained clean past min-quarantine")
                return self._verify_and_restore(st, signals, ts)
            return st.state

        if st.state == RECOVERING:
            return self._verify_and_restore(st, signals, ts)

        return st.state

    def _verify_and_restore(self, st: TableState, signals: Dict[str, Any],
                            ts: float) -> str:
        """Run the lane-appropriate VERIFY.  Downgrade full_scan→fast only on a
        MATCH; otherwise stay quarantined (never downgrade on doubt)."""
        ok, note = self._verify(st, signals)
        if ok:
            self._restore_healthy(st, ts, "verify passed: " + note)
        else:
            # verify could not confirm safety → fall BACK to the quarantined
            # state; do NOT downgrade.
            st.state = (STATS_RECOVERY if st.lane == "stats" else PROVEN_RISK)
            st.since = ts
            st.health_clean_since = None
            st.reason = "recovery held: " + note
            logger.info("[sentinel] table %s recovery HELD (%s) — staying "
                        "full_scan (never downgrade on doubt)", st.table, note)
        return st.state

    def _verify(self, st: TableState, signals: Dict[str, Any]) -> Tuple[bool, str]:
        # 1) Independent STORED-STATS re-check (no file re-open) when the read
        #    path supplied a reverify context (dropped files' bounds+predicate).
        rv = signals.get("reverify_ctx")
        if isinstance(rv, dict) and rv.get("dropped_bounds"):
            res = stats_reverify_prune(
                op=rv.get("op", "eq"), value=rv.get("value"),
                dropped_bounds=rv.get("dropped_bounds"))
            if not res.get("ok"):
                return (False, "stored-stats re-check found a wrong-prune: %s"
                        % (res.get("offending") or [])[:5])
            return (True, "stored-stats re-check clean (checked=%d, no file "
                    "re-open)" % res.get("checked", 0))
        # 2) Loss lane with a re-executor registered → require a shadow re-run
        #    that MATCHES (catches delete-class bugs the stats can't see).
        if st.lane == "loss" and require_shadow_verify_to_recover():
            reexec = cc.get_reexecutor()
            if reexec is None:
                return (False, "no re-executor + no reverify context — cannot "
                        "prove safe; manual clear required")
            try:
                pruned, full = reexec({"table_prefix": st.table})
                pruned, full = int(pruned), int(full)
                tol = cc.tolerance_rows()
                if (full - pruned) > tol:
                    return (False, "shadow re-run still diverges (pruned=%d "
                            "full=%d)" % (pruned, full))
                return (True, "shadow re-run matches (pruned=%d full=%d)"
                        % (pruned, full))
            except Exception as exc:
                return (False, "shadow verify errored: %s" % exc)
        # 3) Stats lane: reaching here means stats were proven complete+fresh
        #    (the on_clean gate) — that IS the verification.
        if st.lane == "stats":
            return (True, "stored stats complete + fresh")
        # 4) No way to prove → do not downgrade.
        return (False, "no verify path available — manual clear required")

    # ── state entry helpers (emit alerts, flip control-layer overrides) ──
    def _to_proven_risk(self, st: TableState, finding: Dict[str, Any], ts: float) -> None:
        prev_state, prev_mode = st.state, self._mode(st)
        cc.sentinel_clear_audited(st.table)
        cc.quarantine_table(st.table, "sentinel PROVEN_RISK: " + finding.get("name", ""))
        st.state = PROVEN_RISK
        st.since = ts
        st.quarantined_at = ts
        st.health_clean_since = None
        st.lane = "loss"
        st.reason = finding.get("name", "")
        self._alert(st, prev_state, PROVEN_RISK, prev_mode, cc.MODE_FULL_SCAN,
                    finding, severity="critical")

    def _to_stats_recovery(self, st: TableState, finding: Dict[str, Any], ts: float) -> None:
        prev_state, prev_mode = st.state, self._mode(st)
        cc.sentinel_clear_audited(st.table)
        cc.quarantine_table(st.table, "sentinel STATS_RECOVERY: " + finding.get("name", ""))
        st.state = STATS_RECOVERY
        st.since = ts
        st.quarantined_at = ts
        st.health_clean_since = None
        st.lane = "stats"
        st.reason = finding.get("name", "")
        self._alert(st, prev_state, STATS_RECOVERY, prev_mode, cc.MODE_FULL_SCAN,
                    finding, severity="warning")

    def _to_suspect(self, st: TableState, finding: Dict[str, Any], ts: float) -> None:
        prev_state, prev_mode = st.state, self._mode(st)
        cc.sentinel_set_audited(st.table, "sentinel SUSPECT: " + finding.get("name", ""))
        st.state = SUSPECT
        st.since = ts
        st.health_clean_since = None
        st.reason = finding.get("name", "")
        self._alert(st, prev_state, SUSPECT, prev_mode, cc.MODE_AUDITED,
                    finding, severity="info")

    def _to_recovering(self, st: TableState, ts: float, note: str) -> None:
        st.state = RECOVERING
        st.since = ts
        st.reason = "recovering: " + note

    def _restore_healthy(self, st: TableState, ts: float, note: str) -> None:
        prev_state, prev_mode = st.state, self._mode(st)
        cc.clear_quarantine(st.table)
        cc.sentinel_clear_audited(st.table)
        st.state = HEALTHY
        st.since = ts
        st.quarantined_at = None
        st.health_clean_since = None
        st.lane = ""
        st.reason = note
        # "restored" alert.
        self._alert(st, prev_state, HEALTHY, prev_mode, cc.MODE_FAST,
                    {"name": "restored", "category": "recovery",
                     "evidence": {"note": note},
                     "cause": "signals healthy + verify passed",
                     "action": "pruning re-enabled (fast)"},
                    severity="info", restored=True)

    def _trigger_watcher(self, st: TableState, resync_ctx: Dict[str, Any],
                         finding: Dict[str, Any]) -> None:
        """Root-cause self-heal: ask the watcher to (re)capture this table's
        per-file stats.  Fail-open, throttled inside the watcher trigger."""
        try:
            conn = resync_ctx.get("connection_id")
            bucket = resync_ctx.get("bucket")
            table_prefix = resync_ctx.get("table_prefix") or st.table
            if not (conn and bucket):
                return
            from core import iceberg_metadata_sync as _sync
            res = _sync.trigger_table_resync(
                connection_id=int(conn), bucket=str(bucket),
                table_prefix=str(table_prefix),
                reason="sentinel:" + finding.get("name", "stats-risk"))
            logger.info("[sentinel] watcher resync for %s → %s", st.table, res)
        except Exception as exc:
            logger.debug("[sentinel] watcher trigger skipped (fail-open): %s", exc)

    # ── alerting ────────────────────────────────────────────────────────
    def _mode(self, st: TableState) -> str:
        return _STATE_MODE.get(st.state, cc.MODE_FAST)

    def _alert(self, st: TableState, from_state: str, to_state: str,
               from_mode: str, to_mode: str, finding: Dict[str, Any],
               *, severity: str = "warning", restored: bool = False) -> None:
        payload = {
            "kind": "completeness_alert",
            "table": st.table,
            "restored": bool(restored),
            "from_state": from_state, "to_state": to_state,
            "from_mode": from_mode, "to_mode": to_mode,
            "trigger_signal": finding.get("name"),
            "signal_category": finding.get("category"),
            "evidence": finding.get("evidence") or {},
            "probable_cause": finding.get("cause"),
            "recommended_action": finding.get("action"),
            "severity": severity,
            "ts": _iso(),
        }
        # in-memory ring (admin endpoint).
        with self._lock:
            self._alerts.append(dict(payload))
        # cross-pod event bus (reaches UI / admin on all pods).
        try:
            from core.event_bus import publish as _publish
            _publish("completeness_alert", dict(payload))
        except Exception as exc:
            logger.debug("[sentinel] event-bus publish failed (non-fatal): %s", exc)
        # structured log.
        msg = ("[sentinel] table=%s %s→%s (mode %s→%s) trigger=%s cause=%s "
               "evidence=%s action=%s")
        args = (st.table, from_state, to_state, from_mode, to_mode,
                finding.get("name"), finding.get("cause"),
                finding.get("evidence"), finding.get("action"))
        if severity == "critical":
            logger.critical(msg, *args)
        elif severity == "warning":
            logger.warning(msg, *args)
        else:
            logger.info(msg, *args)

    # ── admin / observability surface ───────────────────────────────────
    def list_alerts(self, limit: int = 100) -> List[Dict[str, Any]]:
        with self._lock:
            items = list(self._alerts)
        items.reverse()
        return items[:max(0, limit)]

    def get_state(self, table_prefix: str) -> Optional[Dict[str, Any]]:
        with self._lock:
            st = self._tables.get(str(table_prefix or ""))
            if st is None:
                return None
            return {"table": st.table, "state": st.state, "mode": self._mode(st),
                    "reason": st.reason, "lane": st.lane,
                    "quarantined_at": st.quarantined_at, "pinned": st.pinned}

    def snapshot(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "enabled": enabled(),
                "tables": [self.get_state(t) for t in sorted(self._tables)],
                "quarantined": cc.list_quarantined(),
                "audited": cc.sentinel_audited_tables(),
                "alerts_recent": self.list_alerts(20),
            }

    def clear(self, table_prefix: str) -> bool:
        """ADMIN manual clear — force a table back to HEALTHY (fast).  This is
        the human override for the guarded-downgrade path."""
        tp = str(table_prefix or "")
        with self._lock:
            cc.clear_quarantine(tp)
            cc.sentinel_clear_audited(tp)
            st = self._tables.get(tp)
            if st is not None:
                st.state = HEALTHY
                st.quarantined_at = None
                st.health_clean_since = None
                st.lane = ""
                st.reason = "admin manual clear"
        logger.warning("[sentinel] ADMIN cleared table %s → HEALTHY (fast)", tp)
        return True

    def pin(self, table_prefix: str, mode: str) -> bool:
        """ADMIN manual pin — force a table's mode.  ``full_scan``/``audited``
        quarantine/flag it; ``fast`` clears overrides.  Escalation pins are
        always honoured; a ``fast`` pin is the admin taking responsibility for
        the downgrade."""
        tp = str(table_prefix or "")
        mode = str(mode or "").strip().lower()
        if mode not in cc._VALID_MODES:
            return False
        with self._lock:
            st = self._tables.get(tp) or TableState(table=tp, since=time.time())
            self._tables[tp] = st
            st.pinned = mode
            if mode == cc.MODE_FULL_SCAN:
                cc.sentinel_clear_audited(tp)
                cc.quarantine_table(tp, "admin pin full_scan")
                st.state = PROVEN_RISK
                st.quarantined_at = time.time()
            elif mode == cc.MODE_AUDITED:
                cc.clear_quarantine(tp)
                cc.sentinel_set_audited(tp, "admin pin audited")
                st.state = SUSPECT
            else:  # fast
                cc.clear_quarantine(tp)
                cc.sentinel_clear_audited(tp)
                st.state = HEALTHY
        logger.warning("[sentinel] ADMIN pinned table %s → %s", tp, mode)
        return True


def _iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()


# ═══════════════════════════════════════════════════════════════════════════
# Module singleton + wiring hooks.
# ═══════════════════════════════════════════════════════════════════════════
_SENTINEL: Optional[CompletenessSentinel] = None
_SENTINEL_LOCK = threading.Lock()
_OBSERVERS_REGISTERED = False


def get_sentinel() -> CompletenessSentinel:
    global _SENTINEL
    with _SENTINEL_LOCK:
        if _SENTINEL is None:
            _SENTINEL = CompletenessSentinel()
        return _SENTINEL


def observe(table_prefix: Optional[str], signals: Optional[Dict[str, Any]] = None,
            **kw: Any) -> Optional[str]:
    """Module-level convenience — fail-open delegate to the singleton."""
    try:
        return get_sentinel().observe(table_prefix, signals, **kw)
    except Exception as exc:
        logger.debug("[sentinel] module observe failed (fail-open): %s", exc)
        return None


def _on_finalize(receipt: Dict[str, Any]) -> None:
    """completeness_control finalize hook — a real INCOMPLETE/over verdict
    reaches the Sentinel here (fail-open)."""
    try:
        tp = (receipt or {}).get("table_prefix")
        if not tp:
            return
        sig = {
            "execution_id": (receipt or {}).get("execution_id"),
            "completeness_verdict": (receipt or {}).get("verdict"),
            "expected_rows": (receipt or {}).get("expected_rows"),
            "rows_read": (receipt or {}).get("rows_read"),
        }
        get_sentinel().observe(tp, sig)
    except Exception as exc:
        logger.debug("[sentinel] finalize hook failed (fail-open): %s", exc)


def _on_incident(incident: Dict[str, Any]) -> None:
    """completeness_control incident hook — a shadow divergence becomes a HARD
    signal (fail-open)."""
    try:
        if (incident or {}).get("kind") != "shadow_divergence":
            return
        tp = (incident or {}).get("table_prefix")
        if not tp:
            return
        sig = {
            "execution_id": (incident or {}).get("execution_id"),
            "shadow_divergence": {
                "pruned_rows": incident.get("pruned_rows"),
                "full_rows": incident.get("full_rows"),
                "missing_rows": incident.get("missing_rows"),
            },
        }
        get_sentinel().observe(tp, sig)
    except Exception as exc:
        logger.debug("[sentinel] incident hook failed (fail-open): %s", exc)


def init_sentinel() -> None:
    """Register the decoupled observer hooks on ``completeness_control`` so
    finalize verdicts + divergence incidents reach the Sentinel.  Idempotent;
    safe to call at startup.  A no-op registration is harmless when the
    Sentinel is disabled (observe() early-returns)."""
    global _OBSERVERS_REGISTERED
    with _SENTINEL_LOCK:
        if _OBSERVERS_REGISTERED:
            return
        try:
            cc.register_finalize_observer(_on_finalize)
            cc.register_incident_observer(_on_incident)
            _OBSERVERS_REGISTERED = True
            logger.info("[sentinel] completeness Sentinel observer hooks registered")
        except Exception as exc:
            logger.warning("[sentinel] hook registration failed (non-fatal): %s", exc)
