"""Resolve a table's DECLARED column types, so filters can be typed.

WHY THIS MODULE EXISTS
----------------------
``core.query_compiler.sql_literal`` has been able to emit typed literals
(``DATE '2026-08-13'``) since 2026-08-13, when an untyped comparison was
found to break Starburst filtering in production.  Two routes were taught to
supply a type -- the Published-View wrap (from the publisher's declared
``_where_clauses_mapping``) and federation.  The VISUAL builder was not, and
nothing in its request model could carry one, so on 2026-08-19 it still
emitted::

    WHERE "business_close_date" = '2026-08-13'
      AND "event_ts" >= '2026-08-13T00:00:00.000000Z'
      AND "is_active" = 'true'
      AND "acct_num" = '007'

Against Starburst the first three are hard failures
(``Cannot apply operator: date = varchar(10)``).  The fourth is worse: on a
varchar column storing unpadded account numbers it does not fail, it silently
matches NOTHING and reports success -- a wrong answer served as a good one.

``FilterModel.data_type`` now lets a caller state the type.  This module
covers the case where nobody did: it asks the CONNECTOR what the columns
actually are.  That keeps the fix effective without waiting on a UI release,
and the UI-supplied value always wins when present.

DESIGN NOTES
------------
* **Fail-open.**  Every failure path yields "unknown", which reproduces the
  previous quoted-string behaviour exactly.  A metadata lookup must never be
  able to fail a query that would otherwise have run.
* **Cached.**  One ``DESCRIBE`` per table per TTL, not per query.  Schemas
  change rarely; a stale entry can only mean a filter is spelled the old way,
  which is what happens today anyway.
* **Only types that CHANGE the literal are reported.**  ``varchar`` maps to
  "unknown" on purpose: a string column needs a quoted string, which is the
  default, and claiming a type there would only add risk.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

#: Seconds a resolved schema is reused.  Deliberately short-ish: the cost of
#: being wrong is a filter typed the old way, the cost of being slow is a
#: metadata round-trip on every single query.
_TTL_SECONDS = 300

#: Hard cap on cached tables, so a workspace browsing thousands of tables
#: cannot grow this without bound.
_MAX_ENTRIES = 512

_lock = threading.Lock()
#: (connection_id, table_ref) -> (expires_at, {column_lower: semantic_type})
_cache: Dict[Any, Any] = {}


def normalise_sql_type(raw: str) -> str:
    """Map an engine's type name onto the semantic types ``sql_literal`` knows.

    Returns "" for anything that does not change how a literal is spelled --
    notably every string type, where the quoted default is already correct.
    """
    t = (raw or "").strip().lower()
    if not t:
        return ""
    # Strip parameters: varchar(10), decimal(18,2), timestamp(3) with time zone
    base = t.split("(", 1)[0].strip()

    if base in ("date",):
        return "date"
    if base.startswith("timestamp") or base in ("datetime", "datetime2"):
        return "timestamp"
    if base in ("boolean", "bool", "bit"):
        return "boolean"
    if base in ("tinyint", "smallint", "int", "int2", "int4", "int8",
                "integer", "bigint", "long", "short", "byte",
                "float", "float4", "float8", "double", "real",
                "decimal", "numeric", "number"):
        return "number"
    # varchar / char / string / text / array / map / row / json / binary /
    # time / interval / uuid -- all keep the quoted-string default.
    return ""


def _split_table_ref(table_ref: str, cfg: Dict[str, Any]) -> Optional[tuple]:
    """``catalog.schema.table`` -> parts, filling gaps from the connection.

    Returns None when a catalog/schema cannot be determined, because
    ``list_columns`` needs all three and guessing would query the wrong table.
    """
    parts = [p.strip().strip('"') for p in str(table_ref or "").split(".")
             if p.strip()]
    if not parts:
        return None
    if len(parts) >= 3:
        return (parts[-3], parts[-2], parts[-1])
    catalog = cfg.get("catalog") or cfg.get("database") or ""
    schema = cfg.get("schema") or cfg.get("schema_name") or ""
    if len(parts) == 2:
        schema = parts[0]
        table = parts[1]
    else:
        table = parts[0]
    if not catalog or not schema:
        return None
    return (catalog, schema, table)


def resolve_column_types(connector: Any, table_ref: str,
                         cfg: Optional[Dict[str, Any]] = None,
                         connection_id: Any = None) -> Dict[str, str]:
    """``{column_lower: semantic_type}`` for ``table_ref``; {} when unknown."""
    if not connector or not table_ref:
        return {}
    key = (connection_id, str(table_ref).lower())
    now = time.time()
    with _lock:
        hit = _cache.get(key)
        if hit and hit[0] > now:
            return hit[1]

    parts = _split_table_ref(table_ref, cfg or {})
    if not parts:
        return {}

    try:
        cols: List[Dict[str, Any]] = connector.list_columns(*parts) or []
    except Exception as exc:
        # Fail-open: a permissions error on DESCRIBE must not fail the query.
        logger.debug("column type resolve failed for %s: %s", table_ref, exc)
        return {}

    types = {}
    for c in cols:
        try:
            name = str(c.get("name") or "").strip().lower()
            if not name:
                continue
            semantic = normalise_sql_type(str(c.get("type") or ""))
            if semantic:
                types[name] = semantic
        except Exception:
            continue

    with _lock:
        if len(_cache) >= _MAX_ENTRIES:
            _cache.clear()
        _cache[key] = (now + _TTL_SECONDS, types)
    return types


def annotate_filter_types(filters: Optional[List[Dict[str, Any]]],
                          types: Dict[str, str]) -> None:
    """Fill in each filter's missing ``data_type``, IN PLACE.

    A caller-supplied type always wins -- a publisher or a UI that states the
    type knows something the catalog may not (a varchar column that should be
    compared as a date, say).  Only the blanks are filled.
    """
    if not filters or not types:
        return
    for flt in filters:
        try:
            if not isinstance(flt, dict) or flt.get("data_type"):
                continue
            col = str(flt.get("column") or "")
            # Joined references arrive as 'table.column'; the catalog keys are
            # bare column names.
            bare = col.rsplit(".", 1)[-1].strip().strip('"').lower()
            semantic = types.get(bare) or types.get(col.strip().lower())
            if semantic:
                flt["data_type"] = semantic
        except Exception:
            continue


def clear_cache() -> None:
    """Drop every cached schema (tests, and connection edits)."""
    with _lock:
        _cache.clear()


def annotate_from_connector(filters: Optional[List[Dict[str, Any]]],
                            connector: Any, table_ref: str,
                            cfg: Optional[Dict[str, Any]] = None,
                            connection_id: Any = None) -> None:
    """Resolve types from the catalog and stamp them onto ``filters``.

    2026-08-19 -- the two calls were wired at exactly ONE dispatch, so every
    other route that builds connector SQL (scheduler, reports, published
    views, the SQL preview, the cross-source secondary leg) still emitted
    quoted strings for date/timestamp/boolean/numeric columns.  On Trino and
    Athena that is a hard error, so a date-filtered saved query that worked
    interactively still failed the moment it was SCHEDULED or PUBLISHED.

    One call, so a new route cannot half-wire it.  Fail-open throughout: a
    metadata problem leaves the filters untyped and the query running.
    """
    try:
        types = resolve_column_types(connector, table_ref, cfg, connection_id)
        annotate_filter_types(filters, types)
    except Exception as exc:
        logger.debug("filter type annotation skipped for %s: %s",
                     table_ref, exc)
