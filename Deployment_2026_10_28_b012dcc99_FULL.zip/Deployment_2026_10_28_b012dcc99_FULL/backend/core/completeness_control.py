"""core/completeness_control.py — Data-Completeness Control for the pruning brain.

2026-07-16.  Goal: make SILENT data-loss from the pruning brain DETECTABLE
without paying full-scan cost.  Cheap (metadata-only) by default; a full
scan is an opt-in PER-TABLE nuclear option only, never the default guard.

This module is a *control layer*.  It EXTENDS the existing scan-ledger /
prune-diagnostics machinery in ``core.iceberg_reader`` — it never owns the
query path and (this is the single most important invariant) a completeness
check FAILURE MUST NEVER change or block the query result.  Every public
entry point is wrapped fail-open: an exception degrades the verdict to
``"unverified"`` and the caller's file list / rows are returned untouched.

────────────────────────────────────────────────────────────────────────────
THREE TIERS (cheap-by-default)
────────────────────────────────────────────────────────────────────────────
Tier 1 — ALWAYS-ON METADATA RECEIPT (~free, no data scan)
    After a query resolves its KEPT file set we compute, from metadata only:
      expected_rows = Σ record_count(kept files) − Σ applicable delete records
      rows_read     = the SCAN count the engine actually read (wired from the
                      read path; ``None`` when the read path can't report it)
      verdict       = complete | INCOMPLETE | over | unverified
    Plus a ``prune_receipt`` — a capped, per-file audit of WHY each pruned
    file was eliminated, so every prune is auditable offline at zero scan
    cost.

    HONEST SCOPE (read this before trusting it):
      The metadata receipt catches problems on files the brain KEPT:
        • a kept file that silently failed to open / was dropped from the
          view  → rows_read << expected_rows → verdict INCOMPLETE
        • deletes over-applied on kept files                    → INCOMPLETE
        • deletes UNDER-applied (MoR overcount class)           → over
      It CANNOT catch a WRONGLY-PRUNED file: a file the brain dropped is,
      by construction, excluded from ``expected_rows`` (the prune decision
      itself removed it), so metadata alone can never notice it is missing.
      Detecting wrong-prunes needs an actual re-read — that is Tier 3's job.

Tier 2 — PER-TABLE TRUST LEVEL (config)
    ``completeness.table_modes`` (table_prefix → mode) + ``default_mode``:
      fast       (default) — pruning + the Tier-1 metadata check.
      audited    — fast + eligible for Tier-3 async sampling.
      full_scan  — DISABLE pruning for this table (route through the existing
                   kill-switches so the query does a provably-correct full
                   scan).  This is the ONLY path that forces full scans, and
                   it is opt-in per table.
    A table that Tier 3 quarantines is treated as ``full_scan`` until an
    admin clears it.

Tier 3 — ASYNC SHADOW SAMPLER (the wrong-prune catcher; OFF the hot path)
    On a SAMPLED query for an eligible table, enqueue a BACKGROUND task that
    RE-RUNS the same query+filters with pruning DISABLED and compares the
    row counts.  On divergence: LOUD alert + a completeness incident record
    + (optionally) a ``pruning_quarantine`` flag so subsequent queries fall
    back to full_scan until an admin clears it.  Bounded concurrency,
    deterministic-per-exec sampling (hash the execution id — never
    ``random`` on the hot path), and totally fail-open: a sampler error is
    logged and dropped and NEVER touches the user's result.

────────────────────────────────────────────────────────────────────────────
CONFIG KNOBS (section ``completeness``) — cheap-by-default
────────────────────────────────────────────────────────────────────────────
    metadata_check_enabled        default True    (~free, so on)
    tolerance_rows                default 0        (absolute row slack)
    tolerance_ratio               default 0.0      (fractional row slack)
    prune_receipt_max             default 200      (cap on receipt entries)
    default_mode                  default "fast"
    table_modes                   default {}       ({prefix: mode})
    shadow_sample_rate            default 0.0      (OFF)
    shadow_tables                 default []       (opt-in list)
    shadow_max_concurrent         default 2
    auto_quarantine_on_divergence default True
"""

from __future__ import annotations

import hashlib
import logging
import math
import threading
from concurrent.futures import Future, ThreadPoolExecutor
from typing import Any, Callable, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# Valid trust modes (Tier 2).
MODE_FAST = "fast"
MODE_AUDITED = "audited"
MODE_FULL_SCAN = "full_scan"
_VALID_MODES = {MODE_FAST, MODE_AUDITED, MODE_FULL_SCAN}


# ═══════════════════════════════════════════════════════════════════════════
# Config accessors — all fail-open to the documented defaults.
# ═══════════════════════════════════════════════════════════════════════════
def _cfg(key: str, default: Any) -> Any:
    try:
        from core.config import get as _get
        val = _get("completeness", key, default)
        return default if val is None else val
    except Exception:
        return default


def metadata_check_enabled() -> bool:
    try:
        return bool(_cfg("metadata_check_enabled", True))
    except Exception:
        return True


def tolerance_rows() -> int:
    try:
        return max(0, int(_cfg("tolerance_rows", 0)))
    except Exception:
        return 0


def tolerance_ratio() -> float:
    try:
        return max(0.0, float(_cfg("tolerance_ratio", 0.0)))
    except Exception:
        return 0.0


def audited_file_integrity_count_enabled() -> bool:
    """Opt-in audited/full_scan file-integrity COUNT. Default True (it only ever
    fires in audited/full_scan mode, which is itself opt-in per table)."""
    try:
        from core.config import get as _get
        return bool(_get("completeness", "audited_file_integrity_count_enabled", True))
    except Exception:
        return True


def prune_receipt_max() -> int:
    try:
        return max(0, int(_cfg("prune_receipt_max", 200)))
    except Exception:
        return 200


def default_mode() -> str:
    try:
        m = str(_cfg("default_mode", MODE_FAST) or MODE_FAST).strip().lower()
        return m if m in _VALID_MODES else MODE_FAST
    except Exception:
        return MODE_FAST


def table_modes() -> Dict[str, str]:
    try:
        raw = _cfg("table_modes", {}) or {}
        if not isinstance(raw, dict):
            return {}
        out: Dict[str, str] = {}
        for k, v in raw.items():
            m = str(v or "").strip().lower()
            if m in _VALID_MODES:
                out[str(k)] = m
        return out
    except Exception:
        return {}


def shadow_sample_rate() -> float:
    try:
        return min(1.0, max(0.0, float(_cfg("shadow_sample_rate", 0.0))))
    except Exception:
        return 0.0


def shadow_tables() -> List[str]:
    try:
        raw = _cfg("shadow_tables", []) or []
        if isinstance(raw, str):
            raw = [raw]
        return [str(x) for x in raw]
    except Exception:
        return []


def shadow_max_concurrent() -> int:
    try:
        return max(1, int(_cfg("shadow_max_concurrent", 2)))
    except Exception:
        return 2


def auto_quarantine_on_divergence() -> bool:
    try:
        return bool(_cfg("auto_quarantine_on_divergence", True))
    except Exception:
        return True


def sentinel_audited_forces_mode() -> bool:
    """When True, a table the Completeness Sentinel auto-escalated to SUSPECT is
    lifted fast→``audited`` in :func:`resolve_table_mode` — which then makes the
    reader run a full unfiltered file-integrity ``COUNT(*)`` over EVERY kept S3
    file, synchronously on the query path, on every subsequent query.

    Default **FALSE** — like :func:`quarantine_forces_full_scan`, the Sentinel is
    OBSERVATIONAL: an auto-escalation is recorded + surfaced in the verdict but
    must NEVER silently turn a fast partition-pruned query into a per-query
    full-table COUNT scan.  The escalation trigger (3 soft stats-coverage signals
    in 1h) fires on essentially every table once the auto-supplement self-heal is
    off, so honouring it on the query path is a guaranteed latency cliff /
    S3-GET storm.  Operators who genuinely want audited sampling pin the table
    explicitly via ``completeness.table_modes`` — that path is unaffected."""
    try:
        return bool(_cfg("sentinel_audited_forces_mode", False))
    except Exception:
        return False


def quarantine_forces_full_scan() -> bool:
    """When True, a shadow-divergence QUARANTINE forces the table to
    ``full_scan`` (pruning DISABLED → every data file scanned).

    Default **FALSE** — the completeness control is OBSERVATIONAL: a detected
    divergence is still recorded and surfaced in the completeness verdict
    (UNVERIFIED), but it must NEVER silently disable db-first pruning, which
    turns a fast partition-pruned query into a full-table scan.  A single
    spurious sample (e.g. compared against a stale cache while pruning code is
    in flux) would otherwise park a whole table in full-scan until an admin
    notices.  Operators who want the strict fail-safe can set this True; a
    specific table can always be pinned to full_scan explicitly via
    ``completeness.table_modes`` regardless of this flag."""
    try:
        return bool(_cfg("quarantine_forces_full_scan", False))
    except Exception:
        return False


# ═══════════════════════════════════════════════════════════════════════════
# Quarantine registry (Tier 3 → Tier 2 feedback).  In-process, thread-safe.
# A table that diverged under the shadow sampler is parked here; the mode
# resolver then routes it to full_scan until an admin clears it.
# ═══════════════════════════════════════════════════════════════════════════
_QUARANTINE: Dict[str, str] = {}
_QUARANTINE_LOCK = threading.Lock()


def quarantine_table(table_prefix: str, reason: str = "") -> None:
    try:
        with _QUARANTINE_LOCK:
            _QUARANTINE[str(table_prefix)] = str(reason or "shadow-divergence")
    except Exception:
        pass  # fail-open: never let bookkeeping break a caller


def is_quarantined(table_prefix: str) -> bool:
    try:
        with _QUARANTINE_LOCK:
            return str(table_prefix) in _QUARANTINE
    except Exception:
        return False


def clear_quarantine(table_prefix: str) -> bool:
    """Admin clear.  Returns True if a flag was actually removed."""
    try:
        with _QUARANTINE_LOCK:
            return _QUARANTINE.pop(str(table_prefix), None) is not None
    except Exception:
        return False


def list_quarantined() -> Dict[str, str]:
    try:
        with _QUARANTINE_LOCK:
            return dict(_QUARANTINE)
    except Exception:
        return {}


# ═══════════════════════════════════════════════════════════════════════════
# Sentinel AUDITED override (Completeness Sentinel → Tier 2 feedback).
# The Sentinel escalates a SOFT-signal table to ``audited`` (turn on background
# shadow sampling to gather evidence) WITHOUT the operator editing config.  This
# registry is written ONLY by the Sentinel and read ONLY by ``resolve_table_mode``
# — and it can only UPGRADE ``fast`` → ``audited`` (never downgrade), preserving
# the escalate-freely / downgrade-guarded safety property.  In-process, pod-local
# (alerts propagate cross-pod via the event bus; the mode decision is re-derived
# on each pod from the same signals).
# ═══════════════════════════════════════════════════════════════════════════
_SENTINEL_AUDIT: Dict[str, str] = {}
_SENTINEL_AUDIT_LOCK = threading.Lock()


def sentinel_set_audited(table_prefix: str, reason: str = "") -> None:
    try:
        with _SENTINEL_AUDIT_LOCK:
            _SENTINEL_AUDIT[str(table_prefix)] = str(reason or "sentinel-suspect")
    except Exception:
        pass


def sentinel_clear_audited(table_prefix: str) -> bool:
    try:
        with _SENTINEL_AUDIT_LOCK:
            return _SENTINEL_AUDIT.pop(str(table_prefix), None) is not None
    except Exception:
        return False


def sentinel_is_audited(table_prefix: str) -> bool:
    try:
        with _SENTINEL_AUDIT_LOCK:
            return str(table_prefix) in _SENTINEL_AUDIT
    except Exception:
        return False


def sentinel_audited_tables() -> Dict[str, str]:
    try:
        with _SENTINEL_AUDIT_LOCK:
            return dict(_SENTINEL_AUDIT)
    except Exception:
        return {}


# ═══════════════════════════════════════════════════════════════════════════
# Decoupled OBSERVER hooks (control-layer → Completeness Sentinel).
# ``completeness_control`` must NOT import the Sentinel (that would invert the
# dependency: the Sentinel builds ON this module).  Instead the Sentinel
# REGISTERS a callback here; the control layer invokes registered observers
# fail-open when it finalizes a verdict or records a divergence incident.  When
# no observer is registered these are inert no-ops, so this module keeps working
# exactly as before if the Sentinel is never initialised.
# ═══════════════════════════════════════════════════════════════════════════
_FINALIZE_OBSERVERS: List[Callable[[Dict[str, Any]], None]] = []
_INCIDENT_OBSERVERS: List[Callable[[Dict[str, Any]], None]] = []
_OBSERVER_LOCK = threading.Lock()


def register_finalize_observer(fn: Callable[[Dict[str, Any]], None]) -> None:
    """Register a callback invoked (fail-open) with the completeness receipt
    each time :func:`finalize_completeness` computes a verdict."""
    with _OBSERVER_LOCK:
        if fn not in _FINALIZE_OBSERVERS:
            _FINALIZE_OBSERVERS.append(fn)


def register_incident_observer(fn: Callable[[Dict[str, Any]], None]) -> None:
    """Register a callback invoked (fail-open) with each divergence incident
    recorded via :func:`record_incident` (e.g. a shadow-sampler divergence)."""
    with _OBSERVER_LOCK:
        if fn not in _INCIDENT_OBSERVERS:
            _INCIDENT_OBSERVERS.append(fn)


def clear_observers() -> None:
    """Test helper — drop all registered observers."""
    with _OBSERVER_LOCK:
        _FINALIZE_OBSERVERS.clear()
        _INCIDENT_OBSERVERS.clear()


def _notify_observers(observers: List[Callable[[Dict[str, Any]], None]],
                      payload: Dict[str, Any]) -> None:
    with _OBSERVER_LOCK:
        subs = list(observers)
    for cb in subs:
        try:
            cb(dict(payload))
        except Exception as exc:  # FAIL-OPEN: an observer must never break control
            logger.debug("[completeness] observer raised (dropped): %s", exc)


# ═══════════════════════════════════════════════════════════════════════════
# Tier 2 — per-table trust-level resolution.
# ═══════════════════════════════════════════════════════════════════════════
def resolve_table_mode(table_prefix: Optional[str]) -> str:
    """Resolve the trust mode for a table.  Fail-open → ``fast``.

    Precedence:
      1. QUARANTINE (a diverged / Sentinel-escalated table) — OBSERVATIONAL by
         default: recorded + surfaced in the verdict but does NOT force a full
         scan unless ``quarantine_forces_full_scan`` is explicitly enabled.
      2. explicit ``table_modes`` entry — LONGEST matching prefix wins so an
         operator can scope a mode to ``bucket/db.schema.table`` precisely.
      3. ``default_mode`` (itself ``fast``).
      4. Sentinel AUDITED override — UPGRADE-ONLY: applies only when the base
         resolved to ``fast``, lifting it to ``audited`` (turn on background
         sampling).  It can never downgrade an operator-pinned mode, and
         ``audited`` prunes identically to ``fast`` (it just samples), so this
         upgrade can never remove data — it only adds an evidence-gathering
         background check.
    """
    try:
        tp = str(table_prefix or "")
        # QUARANTINE is OBSERVATIONAL by default (quarantine_forces_full_scan
        # defaults False): a shadow-divergence records the table + surfaces it
        # in the verdict, but does NOT disable pruning / force a full scan.
        # Only forces full_scan when an operator explicitly opts in — otherwise
        # one spurious sample would park a whole table in full-scan.
        if is_quarantined(tp) and quarantine_forces_full_scan():
            return MODE_FULL_SCAN
        modes = table_modes()
        best_key: Optional[str] = None
        for k in modes:
            if tp == k or tp.startswith(k) or k in tp:
                if best_key is None or len(k) > len(best_key):
                    best_key = k
        base = modes[best_key] if best_key is not None else default_mode()
        # UPGRADE-ONLY: fast → audited when the Sentinel flagged this table
        # SUSPECT.  Never touches an operator's full_scan / audited pin.
        # OBSERVATIONAL BY DEFAULT (sentinel_audited_forces_mode=False): the
        # auto-escalation is recorded + surfaced in the verdict but does NOT
        # lift the mode — because MODE_AUDITED makes the reader run a full
        # unfiltered file-integrity COUNT over every kept S3 file on EVERY
        # query, and the escalation trigger fires on nearly every table once
        # auto-supplement self-heal is off.  Operators opt in per-table via
        # completeness.table_modes; that pin is honoured above regardless.
        if (base == MODE_FAST
                and sentinel_audited_forces_mode()
                and sentinel_is_audited(tp)):
            return MODE_AUDITED
        return base
    except Exception as exc:
        logger.debug("[completeness] mode resolve failed (fail-open fast): %s", exc)
        return MODE_FAST


def pruning_disabled(mode: str) -> bool:
    """True when the mode requires the reader to skip pruning (keep ALL files)."""
    return str(mode) == MODE_FULL_SCAN


# ═══════════════════════════════════════════════════════════════════════════
# Tier 1 — metadata completeness receipt + verdict.  Pure functions.
# ═══════════════════════════════════════════════════════════════════════════
def compute_expected_rows(
    kept_record_counts: Optional[List[Any]],
    pos_delete_records: int = 0,
    eq_delete_records: int = 0,
) -> Dict[str, Any]:
    """Metadata-only expected-row arithmetic (NO data scan).

    ``expected_rows = Σ record_count(kept) − Σ position-delete records``.

    Position deletes remove exactly one row each, so subtracting their count
    is exact.  EQUALITY deletes can fan out to an unknown number of rows, so
    they are reported separately (``eq_delete_records``) and NOT subtracted —
    they only widen the honest uncertainty band, they don't move the point
    estimate.  ``sum_kept`` is ``None`` when any kept file lacks a
    ``record_count`` (writer omitted it): expected_rows is then unknowable
    and the verdict becomes ``unverified`` (NOT an error).
    """
    rc_missing = False
    total = 0
    n = 0
    if kept_record_counts is None:
        rc_missing = True
    else:
        for rc in kept_record_counts:
            if rc is None:
                rc_missing = True
                continue
            try:
                total += int(rc)
                n += 1
            except (TypeError, ValueError):
                rc_missing = True
    sum_kept = None if (rc_missing and n == 0) else total
    try:
        pos = max(0, int(pos_delete_records or 0))
    except (TypeError, ValueError):
        pos = 0
    try:
        eqd = max(0, int(eq_delete_records or 0))
    except (TypeError, ValueError):
        eqd = 0
    expected = None if sum_kept is None else max(0, sum_kept - pos)
    return {
        "sum_kept_record_count": sum_kept,
        "pos_delete_records": pos,
        "eq_delete_records": eqd,
        "expected_rows": expected,
        "record_count_partial": bool(rc_missing and sum_kept is not None),
        "record_count_missing": bool(rc_missing and sum_kept is None),
    }


def completeness_verdict(
    expected_rows: Optional[int],
    rows_read: Optional[int],
    tol_abs: Optional[int] = None,
    tol_ratio: Optional[float] = None,
) -> Tuple[str, int]:
    """Pure verdict from (expected_rows, rows_read).  Returns (verdict, tol).

      complete   — |rows_read − expected| <= tolerance
      INCOMPLETE — rows_read < expected − tolerance  (a KEPT file silently
                   skipped / read-failed, or deletes over-applied — LOUD)
      over       — rows_read > expected + tolerance  (deletes UNDER-applied;
                   MoR-overcount class)
      unverified — either operand is None (metadata missing) — NOT an error
    """
    if expected_rows is None or rows_read is None:
        return ("unverified", 0)
    try:
        exp = int(expected_rows)
        got = int(rows_read)
    except (TypeError, ValueError):
        return ("unverified", 0)
    ta = tolerance_rows() if tol_abs is None else max(0, int(tol_abs))
    tr = tolerance_ratio() if tol_ratio is None else max(0.0, float(tol_ratio))
    tol = max(ta, int(math.ceil(abs(exp) * tr)))
    diff = got - exp
    if abs(diff) <= tol:
        return ("complete", tol)
    if diff < 0:
        return ("INCOMPLETE", tol)
    return ("over", tol)


def build_prune_receipt(
    entries: Optional[List[Dict[str, Any]]],
    cap: Optional[int] = None,
) -> Dict[str, Any]:
    """Compact, CAPPED per-file prune audit.

    ``entries`` is a list of ``{"file","reason","predicate","bounds"}`` dicts
    captured at the prune drop points.  Returns per-reason counts plus a
    capped sample of the raw entries so a large scan can't blow up memory or
    the diagnostics payload.
    """
    entries = entries or []
    if cap is None:
        cap = prune_receipt_max()
    by_reason: Dict[str, int] = {}
    for e in entries:
        r = str((e or {}).get("reason") or "unknown")
        by_reason[r] = by_reason.get(r, 0) + 1
    return {
        "pruned_total": len(entries),
        "by_reason": by_reason,
        "truncated": len(entries) > cap,
        "sample": entries[: max(0, cap)],
    }


def build_completeness_receipt(
    *,
    table_prefix: Optional[str],
    kept_files_count: int,
    kept_record_counts: Optional[List[Any]],
    pos_delete_records: int = 0,
    eq_delete_records: int = 0,
    mode: str = MODE_FAST,
    execution_id: Optional[str] = None,
    suspect_files: Optional[List[str]] = None,
    prune_entries: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """Assemble ``_out_meta["completeness"]`` from METADATA only (no scan).

    ``rows_read`` is left ``None`` (verdict ``unverified``) until the read
    path calls :func:`finalize_completeness`.  ALWAYS returns a dict — any
    internal failure yields a minimal ``unverified`` receipt so the caller
    can stamp it unconditionally.
    """
    try:
        exp = compute_expected_rows(
            kept_record_counts, pos_delete_records, eq_delete_records)
        receipt: Dict[str, Any] = {
            "table_prefix": str(table_prefix or ""),
            "mode": str(mode or MODE_FAST),
            "execution_id": str(execution_id) if execution_id is not None else None,
            "kept_files": int(kept_files_count or 0),
            "expected_rows": exp["expected_rows"],
            "sum_kept_record_count": exp["sum_kept_record_count"],
            "pos_delete_records": exp["pos_delete_records"],
            "eq_delete_records": exp["eq_delete_records"],
            "rows_read": None,
            "verdict": "unverified",
            "verdict_reason": None,
            "tolerance": 0,
            "suspect_files": list(suspect_files or [])[: prune_receipt_max()],
            "scope_note": (
                "metadata-only: catches read-failures / silent skips / "
                "delete mis-application on KEPT files; does NOT catch "
                "wrongly-pruned files (Tier-3 shadow sampler covers that)"
            ),
        }
        if exp["record_count_missing"]:
            receipt["verdict_reason"] = (
                "metadata missing record_count on kept files — "
                "expected_rows unknowable")
        elif exp["record_count_partial"]:
            receipt["verdict_reason"] = (
                "some kept files lack record_count — expected_rows is a "
                "lower bound; verdict tolerance widened accordingly")
        elif str(mode or MODE_FAST) == MODE_FAST:
            # 2026-09-16 — WHY a fast-mode receipt is "unverified", said out
            # loud.  It used to carry verdict_reason=None, and the
            # certificate then rendered the generic "missing record_count /
            # scan-count metadata" — which is WRONG here and expensive: the
            # record_count metadata is present and correct, so an operator
            # reading that goes hunting for broken metadata that is not
            # broken.  The truth is that fast mode DELIBERATELY never
            # produces a comparable count.
            #
            # It cannot, either: the only count the read path has is the
            # engine's FILTERED, delete-applied scan count, which by
            # construction can never prove COMPLETE on a filtered or MoR
            # query.  That is exactly why the audited lane exists and uses
            # an UNFILTERED count instead.  "Unknown" with the reason and
            # the remedy beats "unknown" with a misleading cause.
            receipt["verdict_reason"] = (
                "fast mode records a metadata expectation only and never "
                "counts rows, so completeness is NOT PROVEN — this is the "
                "designed behaviour, not missing metadata. Set this table "
                "to completeness mode 'audited' (or 'full_scan') for a "
                "proven verdict: that lane runs an UNFILTERED COUNT(*) over "
                "the kept files, which a filtered query's own row count "
                "could never substitute for.")
        if prune_entries is not None:
            receipt["prune_receipt"] = build_prune_receipt(prune_entries)
        return receipt
    except Exception as exc:
        logger.debug("[completeness] receipt build failed (fail-open): %s", exc)
        return {
            "table_prefix": str(table_prefix or ""),
            "verdict": "unverified",
            "verdict_reason": f"receipt build error: {exc}",
            "rows_read": None,
            "expected_rows": None,
        }


def finalize_completeness(
    receipt: Optional[Dict[str, Any]],
    rows_read: Optional[int],
    *,
    logger_override: Optional[logging.Logger] = None,
) -> Dict[str, Any]:
    """Fill in ``rows_read`` + compute the verdict on an existing receipt.

    SUPERSEDED, AND DELIBERATELY UNCALLED IN PRODUCTION (2026-09-16).
    ---------------------------------------------------------------
    Its docstring used to say "called from the READ PATH once the engine's
    scan count is known", and nothing called it — which read as a wiring
    gap.  It is not one.  The count this function wants is the engine's
    FILTERED, delete-applied scan count, and comparing that with the
    UNFILTERED, pre-delete metadata expectation is wrong by construction:
    on any query with a WHERE clause, or any table with delete files, it
    yields INCOMPLETE for a perfectly correct read.  Wiring it would
    manufacture false alarms on the majority of real queries, and an alarm
    that cries wolf is how a real INCOMPLETE gets ignored.

    Every lane already has the RIGHT comparison:
      * audited / full_scan -> :func:`finalize_file_integrity`, fed by
        :func:`audited_file_integrity_count`, an UNFILTERED ``COUNT(*)``
        over the kept files.  WHERE-agnostic and delete-agnostic, so it
        cannot false-INCOMPLETE.  Called from ``core/iceberg_reader.py``.
      * Tier-3 shadow sampling -> its own pruned-vs-full divergence check
        in :class:`ShadowSampler`, which raises an incident rather than a
        verdict.
      * fast (the default) -> no comparable count exists, and the receipt
        now SAYS SO in ``verdict_reason`` instead of leaving a reader to
        infer missing metadata.

    It is kept because it is the pure verdict-writer the tests exercise and
    the shape any future comparable-count lane would reuse.  If you are
    about to call it: make sure your count is UNFILTERED and PRE-delete, or
    use ``finalize_file_integrity`` instead.  LOGS LOUD on INCOMPLETE/over
    but NEVER raises and NEVER alters query data.
    """
    log = logger_override or logger
    if not isinstance(receipt, dict):
        return {"verdict": "unverified", "rows_read": rows_read,
                "verdict_reason": "no receipt to finalize"}
    try:
        expected = receipt.get("expected_rows")
        # record_count partial → expected is a lower bound; only INCOMPLETE
        # (rows_read below the lower bound) is trustworthy, so widen tolerance
        # generously upward by not flagging "over".  Handled by verdict logic
        # returning over only when strictly above; we keep the reason note.
        verdict, tol = completeness_verdict(expected, rows_read)
        receipt["rows_read"] = None if rows_read is None else int(rows_read)
        receipt["verdict"] = verdict
        receipt["tolerance"] = int(tol)
        if verdict in ("INCOMPLETE", "over"):
            suspects = receipt.get("suspect_files") or []
            log.critical(
                "[completeness] table %s verdict=%s exec=%s expected_rows=%s "
                "rows_read=%s (delta=%s, tol=%s) — RESULT RETURNED UNCHANGED "
                "(detect-and-report only). %s. Suspect kept files (capped): %s",
                receipt.get("table_prefix"), verdict,
                receipt.get("execution_id"), expected, rows_read,
                (None if (expected is None or rows_read is None)
                 else int(rows_read) - int(expected)),
                tol,
                ("a kept file was silently skipped / read-failed OR deletes "
                 "over-applied" if verdict == "INCOMPLETE"
                 else "deletes UNDER-applied (MoR-overcount class)"),
                suspects[:20],
            )
        elif verdict == "unverified":
            log.debug(
                "[completeness] table %s verdict=unverified (expected=%s "
                "rows_read=%s) — cannot check, NOT an error",
                receipt.get("table_prefix"), expected, rows_read)
        else:
            log.debug(
                "[completeness] table %s verdict=complete (expected=%s "
                "rows_read=%s tol=%s)",
                receipt.get("table_prefix"), expected, rows_read, tol)
    except Exception as exc:
        log.debug("[completeness] finalize failed (fail-open): %s", exc)
        receipt.setdefault("verdict", "unverified")
        receipt["verdict_reason"] = f"finalize error: {exc}"
    # Fan the finalized receipt out to any registered observer (the
    # Completeness Sentinel) — fail-open, off the correctness path.
    _notify_observers(_FINALIZE_OBSERVERS, receipt)
    return receipt


# ═══════════════════════════════════════════════════════════════════════════
# Phase 2b — AUDITED FILE-INTEGRITY COUNT (opt-in, WHERE-agnostic, delete-agnostic).
# The Tier-1 metadata receipt can only ever read "unverified" until the read
# path supplies rows_read — and rows_read is the FILTERED, delete-applied engine
# scan count, which by construction can never prove COMPLETE on a filtered / MoR
# query.  This lane closes that gap in the OPT-IN audited/full_scan modes with a
# CHEAP, UNFILTERED ``SELECT COUNT(*)`` over the KEPT data-file set and compares
# it to the PRE-delete declared record_count (``sum_kept_record_count``).  That
# comparison proves the KEPT FILES are PHYSICALLY INTACT (catches stale-manifest
# / truncated / replaced files) WITHOUT ever touching the user's WHERE or the
# deletes — so it CANNOT false-INCOMPLETE on a filtered or MoR query.  Fail-open
# throughout: any failure → None / verdict stays "unverified".
# ═══════════════════════════════════════════════════════════════════════════
def audited_file_integrity_count(
    bucket: str,
    kept_keys: Optional[List[str]],
    connection_id: Optional[int],
    db_manager: Any,
) -> Optional[int]:
    """UNFILTERED ``SELECT COUNT(*)`` over the KEPT S3 parquet keys (no WHERE, no
    params, no deletes).  Mirrors the proven presign + DuckDB path in
    ``completeness_reexecutor._resolve_conn`` / ``_count_over_keys``.

    ``kept_keys`` is a list of S3 keys or ``s3://`` URIs.  Empty / None → 0
    (nothing kept = 0 rows, no scan).  Any failure (no conn, presign error,
    duckdb error) → ``None`` (caller skips → verdict stays "unverified").
    NEVER raises.
    """
    try:
        if kept_keys is None or len(kept_keys) == 0:
            return 0  # nothing kept → 0 rows, no scan needed
        if db_manager is None or not connection_id:
            return None
        # Resolve the connection via the SAME credential path as query execution.
        try:
            raw = db_manager.get_connection_raw(int(connection_id))
        except Exception as exc:
            logger.debug("[completeness] file-integrity get_connection_raw(%s) "
                         "failed: %s", connection_id, exc)
            return None
        if not raw:
            return None
        conn_config = raw.get("config") or {}
        try:
            from core.s3_utilities import make_s3_client_for_conn
            s3_client = make_s3_client_for_conn(raw)
        except Exception as exc:
            logger.debug("[completeness] file-integrity make_s3_client_for_conn "
                         "failed: %s", exc)
            return None
        if s3_client is None:
            return None
        # Build the FROM clause over presigned (or raw) URIs.
        uris: List[str] = []
        for k in kept_keys:
            ks = str(k)
            uris.append(ks if ks.startswith("s3://")
                        else f"s3://{bucket}/{ks.lstrip('/')}")
        from core.s3_utilities import get_s3_access_mode, s3_urls_to_presigned
        if get_s3_access_mode(conn_config) == "presigned":
            paths = s3_urls_to_presigned(s3_client, uris, conn_config)
        else:
            paths = uris
        from core.duckdb_views import _build_iceberg_read_expr
        from_clause = _build_iceberg_read_expr(paths)
        # Lazy import (background/late call) keeps this off the import graph and
        # avoids a core→api cycle at module load, exactly like _count_over_keys.
        from api.data_grid_api import _duckdb_con_with_s3
        con = _duckdb_con_with_s3(conn_config, connection_id)
        # UNFILTERED count — NO WHERE, NO params.  This is the whole point:
        # WHERE-agnostic + delete-agnostic physical row count of the kept files.
        row = con.execute(f"SELECT COUNT(*) FROM {from_clause}").fetchone()
        return int(row[0]) if row and row[0] is not None else None
    except Exception as exc:
        logger.debug("[completeness] file-integrity count failed (fail-open): %s",
                     exc)
        return None


def finalize_file_integrity(
    receipt: Optional[Dict[str, Any]],
    physical_row_count: Optional[int],
    *,
    logger_override: Optional[logging.Logger] = None,
) -> Dict[str, Any]:
    """DELETE-AGNOSTIC, WHERE-AGNOSTIC completeness verdict.

    Compares ``physical_row_count`` (an UNFILTERED COUNT(*) over the KEPT data
    files) against ``receipt["sum_kept_record_count"]`` — the PRE-delete declared
    record_count of the kept files.  Comparing physical data-file rows to the
    declared data-file record_count proves the KEPT FILES are physically intact
    (catches stale-manifest / truncated / replaced files).  Because it never uses
    the user's WHERE and never uses deletes, it CANNOT false-INCOMPLETE on a
    filtered or MoR query.  Fail-open: any problem → verdict stays "unverified",
    NEVER raises.  Mutates and returns ``receipt``.
    """
    log = logger_override or logger
    if not isinstance(receipt, dict):
        return {"verdict": "unverified", "rows_read": physical_row_count,
                "verdict_reason": "no receipt to finalize (file-integrity)"}
    try:
        sum_kept = receipt.get("sum_kept_record_count")
        if sum_kept is None or physical_row_count is None:
            receipt.setdefault("verdict", "unverified")
            receipt["verdict_reason"] = (
                "audited file-integrity: unverified — "
                + ("declared record_count missing on kept files"
                   if sum_kept is None
                   else "physical row count unavailable"))
            return receipt
        physical = int(physical_row_count)
        verdict, tol = completeness_verdict(sum_kept, physical)
        receipt["rows_read"] = physical
        receipt["verdict"] = verdict
        receipt["tolerance"] = int(tol)
        receipt["verified_by"] = "audited_file_integrity_count"
        receipt["integrity_declared_rows"] = int(sum_kept)
        receipt["integrity_physical_rows"] = physical
        if verdict == "complete":
            receipt["verdict_reason"] = (
                f"audited file-integrity: {physical} physical rows vs "
                f"{sum_kept} declared record_count (pre-delete) — kept files "
                f"intact")
        elif verdict == "INCOMPLETE":
            receipt["verdict_reason"] = (
                f"audited file-integrity: physical {physical} < declared "
                f"{sum_kept} — a kept file is short/missing rows "
                f"(truncated/replaced/stale manifest)")
        else:  # over
            receipt["verdict_reason"] = (
                f"audited file-integrity: physical {physical} > declared "
                f"{sum_kept} — manifest under-declares (stale)")
        if verdict in ("INCOMPLETE", "over"):
            log.critical(
                "[completeness] file-integrity table %s verdict=%s exec=%s "
                "declared_record_count=%s physical_rows=%s (delta=%s, tol=%s) — "
                "RESULT RETURNED UNCHANGED (detect-and-report only). %s",
                receipt.get("table_prefix"), verdict,
                receipt.get("execution_id"), sum_kept, physical,
                physical - int(sum_kept), tol,
                ("a KEPT file is short/missing physical rows "
                 "(truncated/replaced/stale manifest)" if verdict == "INCOMPLETE"
                 else "manifest UNDER-declares record_count (stale)"))
        else:
            log.debug(
                "[completeness] file-integrity table %s verdict=complete "
                "(declared=%s physical=%s tol=%s)",
                receipt.get("table_prefix"), sum_kept, physical, tol)
    except Exception as exc:
        log.debug("[completeness] file-integrity finalize failed (fail-open): "
                  "%s", exc)
        receipt.setdefault("verdict", "unverified")
        receipt["verdict_reason"] = f"file-integrity finalize error: {exc}"
    # Fan the finalized receipt out to any registered observer (the Sentinel).
    try:
        _notify_observers(_FINALIZE_OBSERVERS, receipt)
    except Exception as exc:
        log.debug("[completeness] file-integrity observer notify failed "
                  "(fail-open): %s", exc)
    return receipt


# ═══════════════════════════════════════════════════════════════════════════
# Tier 3 — async shadow sampler (the wrong-prune catcher).
# ═══════════════════════════════════════════════════════════════════════════
def should_shadow_sample(
    execution_id: Optional[str],
    table_prefix: Optional[str],
    *,
    rate: Optional[float] = None,
    tables: Optional[List[str]] = None,
) -> bool:
    """DETERMINISTIC per-exec sampling decision (no ``random`` on the hot path).

    True when the table is on the opt-in ``shadow_tables`` list, OR when a
    stable hash of ``execution_id|table_prefix`` falls under the configured
    ``shadow_sample_rate``.  The SAME exec id always yields the SAME decision
    (idempotent, reproducible, no per-call RNG).  Fail-open → False (never
    sample on error, so an eligibility bug can't add hidden load).
    """
    try:
        tp = str(table_prefix or "")
        opt_in = tables if tables is not None else shadow_tables()
        for t in opt_in:
            if tp == t or (t and (tp.startswith(t) or t in tp)):
                return True
        r = shadow_sample_rate() if rate is None else min(1.0, max(0.0, float(rate)))
        if r <= 0.0:
            return False
        if r >= 1.0:
            return True
        seed = f"{execution_id or ''}|{tp}".encode("utf-8", "replace")
        h = int(hashlib.sha256(seed).hexdigest()[:12], 16)
        frac = (h % 1_000_000) / 1_000_000.0
        return frac < r
    except Exception as exc:
        logger.debug("[completeness] sample decision failed (fail-open): %s", exc)
        return False


# Bounded, capped record of divergence incidents (in-memory ring).
_INCIDENTS: List[Dict[str, Any]] = []
_INCIDENTS_LOCK = threading.Lock()
_INCIDENTS_MAX = 500


def record_incident(incident: Dict[str, Any]) -> None:
    try:
        with _INCIDENTS_LOCK:
            _INCIDENTS.append(dict(incident))
            if len(_INCIDENTS) > _INCIDENTS_MAX:
                del _INCIDENTS[: len(_INCIDENTS) - _INCIDENTS_MAX]
    except Exception:
        pass
    # Fan the incident out to any registered observer (the Completeness
    # Sentinel) — fail-open, so a shadow divergence becomes a HARD signal.
    _notify_observers(_INCIDENT_OBSERVERS, incident)


def list_incidents() -> List[Dict[str, Any]]:
    try:
        with _INCIDENTS_LOCK:
            return list(_INCIDENTS)
    except Exception:
        return []


class ShadowSampler:
    """Bounded background executor that re-runs sampled queries with pruning
    OFF and compares row counts to catch WRONG-PRUNES.

    The re-execution itself is supplied by the caller as ``rerun_fn`` — a
    ``Callable[[], Tuple[int, int]]`` returning ``(pruned_rows, full_rows)``.
    This keeps the sampler decoupled from the DuckDB read machinery and makes
    divergence handling unit-testable with a mock.  DIVERGENCE = the
    full-scan run saw MORE rows than the pruned run (beyond tolerance) → the
    brain wrongly pruned matching rows → data loss.

    Guarantees:
      • runs OFF the hot path (ThreadPoolExecutor, bounded concurrency),
      • NEVER touches the user's primary result,
      • a sampler error is logged and dropped (fail-open),
      • at most ``max_concurrent`` re-runs in flight (extra submits dropped).
    """

    def __init__(self, max_concurrent: Optional[int] = None):
        self._max = max_concurrent or shadow_max_concurrent()
        self._pool: Optional[ThreadPoolExecutor] = None
        self._lock = threading.Lock()
        self._inflight = 0

    def _ensure_pool(self) -> ThreadPoolExecutor:
        if self._pool is None:
            self._pool = ThreadPoolExecutor(
                max_workers=self._max,
                thread_name_prefix="qs-completeness-shadow",
            )
        return self._pool

    def submit(
        self,
        *,
        execution_id: Optional[str],
        table_prefix: Optional[str],
        rerun_fn: Callable[[], Tuple[int, int]],
        tol_abs: Optional[int] = None,
        tol_ratio: Optional[float] = None,
        out_meta: Optional[Dict[str, Any]] = None,
    ) -> Optional[Future]:
        """Enqueue a shadow re-run.  Returns the Future (tests await it) or
        ``None`` if dropped (over capacity / error).  Non-blocking."""
        try:
            with self._lock:
                if self._inflight >= self._max:
                    logger.debug(
                        "[completeness] shadow sampler at capacity (%d) — "
                        "dropping sample for %s (fail-open, bounded)",
                        self._max, table_prefix)
                    return None
                self._inflight += 1
            pool = self._ensure_pool()
            return pool.submit(
                self._run, execution_id, table_prefix, rerun_fn,
                tol_abs, tol_ratio, out_meta)
        except Exception as exc:
            logger.debug("[completeness] shadow submit failed (fail-open): %s", exc)
            with self._lock:
                self._inflight = max(0, self._inflight - 1)
            return None

    def _run(self, execution_id, table_prefix, rerun_fn,
             tol_abs, tol_ratio, out_meta) -> Optional[Dict[str, Any]]:
        try:
            # A re-executor may legitimately DECLINE a sample (context too thin
            # to faithfully re-run — e.g. an unsupported filter op / missing
            # connection).  It signals that by returning ``None``.  A declined
            # sample is NOT an error and NOT a divergence: drop it quietly so a
            # skip can never fabricate an incident or a quarantine.  Only a real,
            # COMPLETED ``(pruned, full)`` comparison can ever quarantine.
            res = rerun_fn()
            if res is None:
                logger.debug(
                    "[completeness] shadow re-run SKIPPED for %s (re-executor "
                    "declined — context insufficient to faithfully re-run). "
                    "No incident, no quarantine.", table_prefix)
                return None
            pruned_rows, full_rows = res
            pruned_rows = int(pruned_rows)
            full_rows = int(full_rows)
            ta = tolerance_rows() if tol_abs is None else max(0, int(tol_abs))
            tr = tolerance_ratio() if tol_ratio is None else max(0.0, float(tol_ratio))
            tol = max(ta, int(math.ceil(abs(full_rows) * tr)))
            diverged = (full_rows - pruned_rows) > tol
            if not diverged:
                logger.debug(
                    "[completeness] shadow OK for %s: pruned=%d full=%d "
                    "(tol=%d) — pruning is complete",
                    table_prefix, pruned_rows, full_rows, tol)
                return {"diverged": False, "pruned_rows": pruned_rows,
                        "full_rows": full_rows}
            incident = {
                "kind": "shadow_divergence",
                "table_prefix": str(table_prefix or ""),
                "execution_id": str(execution_id) if execution_id is not None else None,
                "pruned_rows": pruned_rows,
                "full_rows": full_rows,
                "missing_rows": full_rows - pruned_rows,
                "tolerance": tol,
                "quarantined": False,
            }
            if auto_quarantine_on_divergence():
                quarantine_table(
                    table_prefix,
                    f"shadow divergence: pruned={pruned_rows} full={full_rows} "
                    f"(missing {full_rows - pruned_rows})")
                incident["quarantined"] = True
            record_incident(incident)
            logger.critical(
                "[completeness] SHADOW DIVERGENCE on table %s exec=%s: "
                "pruned run saw %d rows but FULL-SCAN run saw %d "
                "(%d rows WRONGLY PRUNED, tol=%d). %s The user's original "
                "result was NOT altered — this is a background audit.",
                table_prefix, execution_id, pruned_rows, full_rows,
                full_rows - pruned_rows, tol,
                ("Table QUARANTINED → full_scan until admin clears."
                 if incident["quarantined"]
                 else "auto_quarantine disabled — NOT quarantined."))
            if isinstance(out_meta, dict):
                out_meta["completeness_shadow_incident"] = incident
            return incident
        except Exception as exc:
            # FAIL-OPEN: a sampler error must never surface or affect anything.
            logger.warning(
                "[completeness] shadow re-run FAILED for %s (dropped, "
                "fail-open): %s", table_prefix, exc)
            return None
        finally:
            with self._lock:
                self._inflight = max(0, self._inflight - 1)


# ── Re-executor injection ────────────────────────────────────────────────
# The wrong-prune check must RE-RUN the query with pruning disabled and count
# rows — that needs the query executor, which lives above the file-enumeration
# layer.  The app registers a re-executor at startup; until it does, the
# enumeration call-site enqueues NOTHING (so the feature is inert-by-default
# and cannot add hidden load).  A re-executor takes a context dict and returns
# ``(pruned_rows, full_rows)``.
_REEXECUTOR: Optional[Callable[[Dict[str, Any]], Tuple[int, int]]] = None


def set_reexecutor(fn: Optional[Callable[[Dict[str, Any]], Tuple[int, int]]]) -> None:
    global _REEXECUTOR
    _REEXECUTOR = fn


def get_reexecutor() -> Optional[Callable[[Dict[str, Any]], Tuple[int, int]]]:
    return _REEXECUTOR


# Module-level singleton.
_SAMPLER: Optional[ShadowSampler] = None
_SAMPLER_LOCK = threading.Lock()


def get_sampler() -> ShadowSampler:
    global _SAMPLER
    with _SAMPLER_LOCK:
        if _SAMPLER is None:
            _SAMPLER = ShadowSampler()
        return _SAMPLER


# ── Re-entrancy guard (recursion firewall) ─────────────────────────────────
# A shadow re-run RE-ENUMERATES the table with pruning disabled by calling back
# into the SAME reader path — which reaches this module's enqueue gate again.
# Without a guard that re-enumeration could itself enqueue another shadow sample
# → unbounded recursion / self-amplifying load.  The re-executor wraps its whole
# body in :class:`shadow_reexec_guard`, which marks the CURRENT THREAD (the
# sampler's bounded worker, where the re-run runs) so
# :func:`maybe_enqueue_shadow_sample` refuses to enqueue a nested sample.  Thread
# local (not global) so a normal query on another thread is unaffected.
_reexec_state = threading.local()


def _in_shadow_reexec() -> bool:
    return bool(getattr(_reexec_state, "active", False))


class shadow_reexec_guard:  # noqa: N801 — used as a context manager verb
    """Context manager: while active on this thread, :func:`maybe_enqueue_shadow_sample`
    is a no-op, so a shadow re-run can never enqueue another shadow re-run."""

    def __enter__(self) -> "shadow_reexec_guard":
        _reexec_state.active = True
        return self

    def __exit__(self, *_exc: Any) -> bool:
        _reexec_state.active = False
        return False


def maybe_enqueue_shadow_sample(
    *,
    execution_id: Optional[str],
    table_prefix: Optional[str],
    mode: str,
    rerun_fn: Callable[[], Tuple[int, int]],
    out_meta: Optional[Dict[str, Any]] = None,
) -> Optional[Future]:
    """Eligibility gate + enqueue, all fail-open.  Returns the Future when a
    sample was enqueued, else ``None``.  A table must be ``audited`` (or
    quarantine-forced full_scan already skips this) AND pass the deterministic
    sampling decision.  NEVER blocks or slows the caller."""
    try:
        if _in_shadow_reexec():
            # RECURSION FIREWALL: we are already inside a shadow re-run (the
            # re-executor re-enumerated this table with pruning off and that
            # re-enumeration reached this gate).  A re-run must NEVER spawn
            # another re-run.
            return None
        if str(mode) == MODE_FULL_SCAN:
            return None  # already full-scanning — nothing to shadow
        # Only audited tables are eligible for sampling; fast is Tier-1 only.
        eligible = (str(mode) == MODE_AUDITED) or (
            str(table_prefix or "") in shadow_tables())
        if not eligible:
            return None
        if not should_shadow_sample(execution_id, table_prefix):
            return None
        return get_sampler().submit(
            execution_id=execution_id,
            table_prefix=table_prefix,
            rerun_fn=rerun_fn,
            out_meta=out_meta,
        )
    except Exception as exc:
        logger.debug("[completeness] enqueue gate failed (fail-open): %s", exc)
        return None
