"""ConnectionBrain — central registry of everything QueryStudio knows
about a connection's data layout.

Architectural rule (the strategic shape):

  Discovery happens AT CONNECTION REGISTER/UPDATE TIME, never at query
  time.  The query path reads from this brain's persisted state via
  pure DB lookups.  The brain owns:

    - partition_columns per registered_table     (committed)
    - schema column lists per table              (extension point)
    - Iceberg latest metadata.json pointer       (extension point)
    - Iceberg manifest counts / file estimates   (extension point)
    - column statistics summaries                (extension point)
    - bloom filter availability flags            (extension point)

  Every slow S3 walk runs ONCE per (connection, table) — in the
  background, after the API request returns — and the result lives in
  the DB forever (until the connection is deleted or refreshed).

Public surface:

    brain = get_brain()
    brain.refresh(connection_id)    # fire-and-forget; runs everything
    brain.forget(connection_id)     # clear all learned state on delete

Adding a new discovery type: implement a new `DiscoveryStep` and
register it in `ConnectionBrain._STEPS`.  Don't touch the orchestrator.

This consolidates the bg-thread spawn (single contextvar-aware
implementation), the S3 client construction, and the connection-config
read so individual discovery modules can stay pure functions.
"""
from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Protocol

_log = logging.getLogger(__name__)


# ── DiscoveryStep protocol ─────────────────────────────────────────────


class DiscoveryStep(Protocol):
    """A single self-contained discovery pass.

    Implementations receive the shared `DiscoveryCtx` (connection raw
    config, S3 client, registered_tables list) and a write-back hook to
    persist what they learned.  They run sequentially in
    `ConnectionBrain._STEPS` order — earlier steps can populate fields
    later steps depend on.

    Steps are SYNCHRONOUS — the bg-thread runs each in turn.  Errors
    in one step are logged and don't abort the others.
    """
    name: str

    def run(self, ctx: "DiscoveryCtx") -> None:
        ...


# ── Shared discovery context ───────────────────────────────────────────


@dataclass
class DiscoveryCtx:
    """Shared state passed to every DiscoveryStep.

    Built once per refresh() call — steps mutate `learned` to record
    what they discovered, and the brain persists it all at the end.
    """
    connection_id: int
    config: Dict[str, Any]                      # decrypted
    bucket: str
    registered_tables: List[Dict[str, Any]]
    s3_client: Any
    db_manager: Any
    # Steps write their findings here.  Keys are well-known; persistence
    # is keyed off these.
    learned: Dict[str, Any] = field(default_factory=dict)


# ── ConnectionBrain orchestrator ───────────────────────────────────────


class ConnectionBrain:
    """Singleton orchestrator.  Owns the bg-thread, the contextvar
    propagation, and the discovery-step registry.

    Construction is dependency-injected so tests can pass a mock
    db_manager.  Production wiring lives in `get_brain()`.
    """

    # Registered discovery steps — order matters (later steps can use
    # earlier steps' findings via ctx.learned).  Add new steps here.
    _STEPS: List[DiscoveryStep] = []  # populated below

    def __init__(self, db_manager) -> None:
        self._db = db_manager

    # ── Public API ────────────────────────────────────────────────────

    def refresh(self, connection_id: int) -> None:
        """Fire-and-forget brain refresh.  Returns immediately;
        discovery runs on a daemon thread.

        Idempotent: re-running discovers nothing new for already-known
        tables (each DiscoveryStep is responsible for its own "skip if
        already populated" check).
        """
        self._spawn(self._refresh_inline, int(connection_id))

    def refresh_all(self) -> int:
        """Sweep every active connection that has registered_tables and
        spawn a refresh thread for each.  Called once at process startup
        from main.py so existing connections don't require a manual
        re-PUT after a pod restart / version bump.

        Returns the number of connections scheduled (caller can log).
        Each refresh runs in its own daemon thread — sweeping 50
        connections is cheap (50 daemon threads, each idle except for
        a few S3 calls).  Each DiscoveryStep short-circuits when
        partition_columns are already populated, so the sweep is a
        no-op on a warm DB.
        """
        try:
            conns = self._db.list_connections(active_only=True, limit=10_000)
        except Exception as exc:
            _log.warning("[brain] refresh_all: list_connections failed: %s", exc)
            return 0
        scheduled = 0
        for c in conns:
            cfg = c.get("config") or {}
            # Skip SQL connectors (no registered_tables) and connections
            # with empty registered_tables list.
            if not cfg.get("registered_tables"):
                continue
            try:
                self.refresh(int(c["id"]))
                scheduled += 1
            except Exception as exc:
                _log.warning(
                    "[brain] refresh_all: schedule failed for connection=%d: %s",
                    c.get("id"), exc,
                )
        if scheduled:
            _log.info(
                "[brain] startup sweep: scheduled %d connection(s) for refresh",
                scheduled,
            )
        return scheduled

    def forget(self, connection_id: int) -> None:
        """Clear all learned state for this connection.  Synchronous —
        called on delete_connection / disable.  The query path will
        re-learn on next register if the connection is reactivated.

        Current implementation is a no-op (DB caches are LRU-bounded
        and self-evict on connection re-use), but lives here as the
        extensibility point for future invalidation needs.
        """
        _log.debug("[brain] forget connection=%d", connection_id)

    # ── Inline (testable) refresh ─────────────────────────────────────

    def _refresh_inline(self, connection_id: int) -> None:
        """Synchronous body of refresh().  Runs every registered
        DiscoveryStep in turn.  Public so tests can call without
        spawning a thread."""
        ctx = self._build_ctx(connection_id)
        if ctx is None:
            return
        for step in self._STEPS:
            try:
                step.run(ctx)
            except Exception as exc:
                _log.warning(
                    "[brain] step=%s connection=%d failed (continuing): %s",
                    getattr(step, "name", type(step).__name__),
                    connection_id, exc, exc_info=True,
                )
        if ctx.learned:
            _log.info(
                "[brain] connection=%d refresh complete — learned keys=%s",
                connection_id, list(ctx.learned.keys()),
            )

    # ── Context builder ───────────────────────────────────────────────

    def _build_ctx(self, connection_id: int) -> Optional[DiscoveryCtx]:
        """Read decrypted config + build S3 client.  Returns None when
        the connection has nothing worth discovering (SQL connector,
        no bucket, no registered_tables)."""
        conn = self._db.get_connection_raw(int(connection_id))
        if not conn:
            return None
        config = dict(conn.get("config", {}) or {})
        registered = list(config.get("registered_tables") or [])
        if not registered:
            return None
        # Canonical field name across the codebase is `bucket_name`;
        # `bucket` and `s3_bucket` are legacy variants we tolerate.
        bucket = (config.get("bucket_name") or config.get("bucket")
                  or config.get("s3_bucket") or "")
        if not bucket:
            _log.debug(
                "[brain] connection=%d — no bucket_name in config, skipping",
                connection_id,
            )
            return None
        try:
            from core.s3_utilities import make_s3_client_for_conn
            s3 = make_s3_client_for_conn({"id": connection_id, "config": config})
        except Exception as exc:
            _log.warning(
                "[brain] connection=%d — could not build s3 client: %s",
                connection_id, exc,
            )
            return None
        return DiscoveryCtx(
            connection_id=int(connection_id),
            config=config,
            bucket=bucket,
            registered_tables=registered,
            s3_client=s3,
            db_manager=self._db,
        )

    # ── Background thread spawn (contextvar-aware) ───────────────────

    def _spawn(self, target: Callable, *args) -> None:
        """Single contextvar-aware bg-thread spawn.  ALL brain
        discovery uses this — extending the brain doesn't require
        re-implementing context propagation.

        Why contextvar copy:
          make_s3_client_for_conn reads aws_portal_auth._current_portal_user
          (per-user STS resolution for portal-auth connections).  Plain
          threading.Thread doesn't propagate contextvars.  copy_context()
          captures the request's vars; ctx.run re-enters them in the child.
        """
        try:
            import contextvars
            ctx = contextvars.copy_context()
            threading.Thread(
                target=ctx.run,
                args=(target,) + tuple(args),
                name=f"brain-refresh-{args[0] if args else 'unknown'}",
                daemon=True,
            ).start()
        except Exception as exc:
            _log.warning(
                "[brain] failed to spawn bg thread: %s", exc,
            )


# ── DiscoveryStep implementations ──────────────────────────────────────


class _PartitionColumnsStep:
    """Detect partition_columns for every registered_table where it's
    empty.  Walks Iceberg metadata.json (iceberg) or hive paths
    (parquet).  Persists into config.registered_tables[].partition_columns.
    """
    name = "partition_columns"

    def run(self, ctx: DiscoveryCtx) -> None:
        # Short-circuit when everything's already populated — keeps
        # log noise low for repeat-refreshes.
        needs_detection = [t for t in ctx.registered_tables
                            if not t.get("partition_columns")]
        if not needs_detection:
            return
        from core.iceberg_partition_discovery import (
            discover_partition_columns, persist_discovered_cols,
        )
        discovered = discover_partition_columns(
            ctx.s3_client, ctx.bucket, ctx.registered_tables,
        )
        if discovered:
            persist_discovered_cols(ctx.db_manager, ctx.connection_id, discovered)
            ctx.learned["partition_columns"] = discovered


# Register all steps.  Adding a new discovery type is one append.
ConnectionBrain._STEPS = [
    _PartitionColumnsStep(),
    # _SchemaCacheStep(),                  # extension point — schema warming
    # _IcebergMetadataKeyStep(),           # extension point — metadata.json pointer
    # _ColumnStatsSummaryStep(),           # extension point — stats prefetch
    # _BloomFilterAvailabilityStep(),      # extension point — bloom presence flag
]


# ── Singleton accessor ────────────────────────────────────────────────


_brain: Optional[ConnectionBrain] = None
_brain_lock = threading.Lock()


def get_brain() -> ConnectionBrain:
    """Return the process-wide brain singleton.

    Lazy-init so importing this module doesn't pull the DB manager into
    scope at module load time (avoids circular imports).
    """
    global _brain
    if _brain is not None:
        return _brain
    with _brain_lock:
        if _brain is None:
            from core.connection_manager import get_connection_manager
            cm = get_connection_manager()
            if cm is None or not hasattr(cm, "db"):
                raise RuntimeError(
                    "ConnectionBrain requires the connection_manager to be "
                    "initialised first (call set_connection_manager in main.py)"
                )
            _brain = ConnectionBrain(cm.db)
    return _brain


def set_brain_for_tests(brain: Optional[ConnectionBrain]) -> None:
    """Test hook — swap the singleton with a mock, or reset to None."""
    global _brain
    with _brain_lock:
        _brain = brain
