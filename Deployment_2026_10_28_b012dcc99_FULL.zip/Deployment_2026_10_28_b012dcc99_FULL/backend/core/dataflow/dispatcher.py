"""``Dispatcher`` — executes a dataflow run, stage by stage.

Responsibility split:
* ``DataFlowEngine`` writes definition + run rows.
* ``Dispatcher`` reads run rows, picks the next ready stage, instantiates
  the registered ``BaseStage`` class, calls ``execute(ctx)``, persists the
  ``StageResult`` back into ``dataflow_run_stages``, and emits WS events.

Execution semantics implemented here:

* **Topological DAG order** — a stage is *ready* when every predecessor
  alias is in {succeeded, skipped}.  Linear dataflows are the trivial
  case (each stage predecessors=[prev]).
* **on_failure policy** — `halt` fails the whole run; `continue` skips
  the stage and downstream branch; `branch_to` jumps to a fallback alias.
* **Branching from a stage** — ``StageResult.branched(branch_to="alias")``
  marks all aliases between current+1 and the target as `skipped`.
* **Resume** — find the first non-succeeded stage, reset it to
  not_started, dispatch from there.  Prior succeeded stages' outputs are
  threaded into ``StageContext.prev_outputs`` so resumed stages read
  upstream artefacts without re-running.
* **Rerun-single-stage** — reset only the named alias; downstream stays
  untouched (admin's call to rerun downstream is a separate request).
* **Cancellation** — engine sets a ``threading.Event``; dispatcher checks
  before each stage and inside the ``StageContext.is_cancelled()`` hook.

Scope (Phase 0):
* In-process synchronous execution only.  Each ``run()`` call drives one
  run to completion.  The thread pool that hosts these runs is owned by
  the API layer / scheduler, not by Dispatcher.
* Sub-dataflows handled by ``SubDataFlowStage`` which calls
  ``engine.start_run()`` and (optionally) blocks until the child is done
  by polling its row.
"""
from __future__ import annotations

import logging
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor, Future, wait, FIRST_COMPLETED
from datetime import datetime, timezone, timedelta
from typing import Any, Callable, Dict, List, Optional

from core.dataflow.context import StageContext, StageResult
from core.dataflow.exceptions import (
    StageExecutionError,
    UnknownStageTypeError,
    DataFlowCancelledError,
    DataFlowError,
)
from core.dataflow.registry import StageTypeRegistry, get_default_registry

logger = logging.getLogger(__name__)


# ── Stage status constants (DB enum values) ────────────────────────────────


S_NOT_STARTED = "not_started"
S_RUNNING = "running"
S_SUCCEEDED = "succeeded"
S_FAILED = "failed"
S_SKIPPED = "skipped"
S_CANCELLED = "cancelled"
S_RESCHEDULE = "reschedule"   # Phase 132.22 — sensor reschedule pending

R_PENDING = "pending"
R_RUNNING = "running"
R_SUCCEEDED = "succeeded"
R_FAILED = "failed"
R_CANCELLED = "cancelled"
R_PARTIAL = "partial"


def _to_utc_aware(dt: Optional[datetime]) -> Optional[datetime]:
    """SQLite returns naive datetimes; ensure every datetime we touch
    is UTC-aware before arithmetic."""
    if dt is None:
        return None
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _duration_seconds(start: Optional[datetime], end: Optional[datetime]) -> Optional[float]:
    s = _to_utc_aware(start)
    e = _to_utc_aware(end)
    if s is None or e is None:
        return None
    return (e - s).total_seconds()


# ── Dispatcher ─────────────────────────────────────────────────────────────


class Dispatcher:
    """One Dispatcher per pod.  Stateless across runs — each ``run()``
    call is independent and thread-safe to invoke concurrently for
    different run_ids.
    """

    def __init__(
        self,
        db_manager: Any,
        engine: Any,
        registry: Optional[StageTypeRegistry] = None,
        broadcast_fn: Optional[Callable[[Dict[str, Any]], None]] = None,
        max_parallel_stages: int = 1,
        cancel_poll_seconds: float = 2.0,
    ) -> None:
        if db_manager is None or engine is None:
            raise ValueError("Dispatcher requires db_manager + engine")
        self.db = db_manager
        self.engine = engine
        self.registry = registry or get_default_registry()
        self.broadcast_fn = broadcast_fn
        # Per-run executor for fan-out execution.  Default 1 (sequential)
        # because the ``on_failure="branch_to"`` semantic skips stages by
        # seq order — parallel dispatch can race a downstream skip-window
        # before _apply_on_failure runs.  Users with explicit-predecessor
        # DAGs (no branch_to-by-seq dependency) can pass max_parallel_stages>1.
        self.max_parallel_stages = max(1, int(max_parallel_stages))
        self.cancel_poll_seconds = max(0.5, float(cancel_poll_seconds))

    # ── Public API ──────────────────────────────────────────────────────

    def run(self, run_id: int) -> str:
        """Drive one dataflow run to completion or failure.

        Returns the final run status.  Always idempotent on the run row:
        a re-entrant call on an already-finished run is a no-op.
        """
        # Phase Z (2026-06-09) — register the DataFlow run with the
        # brain path so /diagnose/{id} (where id = str(run_id)) shows
        # DataFlow executions alongside BQB / feed / report queries.
        _df_exec_id = f"dataflow-{run_id}"
        try:
            from core.query_diagnostic_store import set_current_execution_id
            set_current_execution_id(_df_exec_id)
        except Exception:
            pass
        try:
            from core.brain.scan_plan import record_execution_path as _rep_df
            _rep_df(
                execution_id=_df_exec_id,
                branch="7_dataflow",
                has_reg=False,
                raw_sql=False,
                has_s3_reg=False,
                notes=f"dataflow_run_id={run_id}",
            )
        except Exception:
            pass
        cancel_event = threading.Event()
        self.engine._register_cancel_event(run_id, cancel_event)
        try:
            return self._run_inner(run_id, cancel_event)
        finally:
            self.engine._release_cancel_event(run_id)

    def resume(self, run_id: int) -> str:
        """Resume a failed/partial run from its first non-succeeded stage.

        Earlier succeeded stages are preserved; their outputs feed the
        resumed stages via ``ctx.prev_outputs``.
        """
        from core.db.models import DataFlowRun, DataFlowRunStage

        with self.db.get_session() as session:
            run = session.query(DataFlowRun).filter(DataFlowRun.id == run_id).first()
            if run is None:
                raise DataFlowError(f"run {run_id} not found")
            if run.status == R_SUCCEEDED:
                return R_SUCCEEDED
            # Reset every non-succeeded stage so the dispatcher will re-pick them.
            (session.query(DataFlowRunStage)
                .filter(
                    DataFlowRunStage.run_id == run_id,
                    DataFlowRunStage.status.in_([S_FAILED, S_NOT_STARTED, S_CANCELLED]),
                )
                .update(
                    {"status": S_NOT_STARTED,
                     "error": None,
                     "started_at": None,
                     "ended_at": None,
                     "duration_seconds": None},
                    synchronize_session=False,
                ))
            run.status = R_PENDING
            run.error = None
            run.ended_at = None
            run.duration_seconds = None
            session.flush()

        return self.run(run_id)

    def rerun_stage(self, run_id: int, stage_alias: str) -> str:
        """Rerun a single stage in isolation.  Downstream stages keep
        their prior status.  Caller is responsible for understanding the
        idempotency implications (warn-on-unsafe is enforced one level
        up by the API).
        """
        from core.db.models import DataFlowRun, DataFlowRunStage

        with self.db.get_session() as session:
            row = (
                session.query(DataFlowRunStage)
                .filter(
                    DataFlowRunStage.run_id == run_id,
                    DataFlowRunStage.stage_alias == stage_alias,
                )
                .first()
            )
            if row is None:
                raise DataFlowError(
                    f"run {run_id} has no stage {stage_alias!r}"
                )
            row.status = S_NOT_STARTED
            row.error = None
            row.started_at = None
            row.ended_at = None
            row.duration_seconds = None
            session.flush()

            # Run-level status: flip to running while we dispatch this one
            run = session.query(DataFlowRun).filter(DataFlowRun.id == run_id).first()
            if run is not None and run.status in (R_FAILED, R_CANCELLED, R_PARTIAL,
                                                   R_SUCCEEDED):
                # Use partial to denote a single-stage rerun — final status
                # is recomputed at the end of _run_inner.
                run.status = R_PENDING
                run.ended_at = None
                session.flush()

        return self._run_targeted(run_id, only_alias=stage_alias)

    # ── Inner driver ────────────────────────────────────────────────────

    def _run_inner(self, run_id: int, cancel_event: threading.Event) -> str:
        """Main loop — picks ready stages until everything is terminal.

        Phase 1+ enhancements:
        * Parallel fan-out: every stage in the ``ready`` batch is dispatched
          to a per-run ThreadPoolExecutor up to ``max_parallel_stages``.
        * Cross-pod cancel: between batches we re-read the run row's
          status from DB; if status='cancelled' was set on another pod
          we set the local event and bail.
        """
        from core.db.models import DataFlowRun

        # Flip run to running + record started_at if first time.
        # Phase 132.20 — also snap expected_completion_at to the actual
        # start instant (not the enqueue time), so an SLA breach reflects
        # genuine wall-clock execution duration, not queue wait.
        from datetime import timedelta
        from core.db.models import DataFlow as _DataFlow
        # BF-591: atomic claim — multi-pod resume on the same run_id used
        # to be a SELECT-then-UPDATE that both pods could pass.  The
        # conditional UPDATE pattern (only flip when status was previously
        # in the claimable set) returns rowcount=0 for the loser, who
        # bails immediately instead of double-running the same DAG and
        # clobbering each other's stage writes.
        from sqlalchemy import update as _sa_update
        _claimable = (R_PENDING, R_FAILED, R_PARTIAL, R_CANCELLED)
        with self.db.get_session() as session:
            run = session.query(DataFlowRun).filter(DataFlowRun.id == run_id).first()
            if run is None:
                raise DataFlowError(f"run {run_id} not found")
            if run.status == R_SUCCEEDED:
                return R_SUCCEEDED
            # Idempotent: if we already won this run, the second-call
            # path skips claim and proceeds (rare — happens on retry
            # after dispatcher restart).
            if run.status == R_RUNNING:
                logger.warning(
                    "[dataflow.dispatch] run %d already RUNNING — proceeding "
                    "(another dispatcher may have started it; cross-pod cancel "
                    "check will detect any conflict)",
                    run_id,
                )
            else:
                # Conditional UPDATE — returns rowcount=0 if another pod
                # beat us to the claim.
                _claimed = session.execute(
                    _sa_update(DataFlowRun)
                    .where(DataFlowRun.id == run_id)
                    .where(DataFlowRun.status.in_(_claimable))
                    .values(status=R_RUNNING)
                )
                if _claimed.rowcount == 0:
                    # Another pod / dispatcher claimed it first.  Refresh
                    # the row and return its current status (cancelled
                    # wins for cancel-during-resume races).
                    session.flush()
                    session.refresh(run)
                    if run.status == R_CANCELLED:
                        return R_CANCELLED
                    if run.status == R_SUCCEEDED:
                        return R_SUCCEEDED
                    # Already running on another pod — bail with a
                    # warning rather than racing for the same stages.
                    logger.warning(
                        "[dataflow.dispatch] run %d already claimed by "
                        "another dispatcher (status=%s); bailing",
                        run_id, run.status,
                    )
                    return run.status
            if run.started_at is None:
                run.started_at = _now()
            # Recompute SLA deadline against the actual start instant.
            # If the admin cleared sla_seconds between start_run and dispatch,
            # also clear expected_completion_at so we don't fire a false-
            # positive breach on stale state.
            try:
                wf = session.query(_DataFlow).filter(_DataFlow.id == run.dataflow_id).first()
                sla_secs = getattr(wf, "sla_seconds", None) if wf is not None else None
                if sla_secs and int(sla_secs) > 0:
                    run.expected_completion_at = run.started_at + timedelta(seconds=int(sla_secs))
                else:
                    run.expected_completion_at = None
            except Exception as _sla_exc:
                logger.debug("[dataflow.dispatch] SLA snap skipped: %s", _sla_exc)
            session.flush()

        self._broadcast({"event": "workflow_run_started", "run_id": run_id})

        # BF-590 (2026-05-29): do NOT use ``with ThreadPoolExecutor(...) as pool:``
        # — the context-manager's __exit__ calls shutdown(wait=True), which
        # blocks the entire dispatcher return path on any in-flight stage
        # (including the cancel paths we explicitly take below).  Manage
        # the pool lifetime explicitly so cancellation returns can pass
        # cancel_futures=True and skip waiting on pending submissions.
        pool = ThreadPoolExecutor(
            max_workers=self.max_parallel_stages,
            thread_name_prefix=f"wf-stage-{run_id}",
        )
        _cancelled_return = False
        try:
            while True:
                if self._check_cancelled(run_id, cancel_event):
                    self._finalise_cancelled(run_id)
                    _cancelled_return = True
                    return R_CANCELLED
                # Phase 132.25 — hard timeout enforcement.  Distinct
                # from SLA (which only flags); this proactively cancels.
                if self._check_hard_timeout(run_id):
                    cancel_event.set()
                    self._finalise_cancelled(
                        run_id, reason="hard timeout (max_run_seconds exceeded)",
                    )
                    _cancelled_return = True
                    return R_CANCELLED

                ready = self._pick_ready_stages(run_id)
                if not ready:
                    # Phase 132.22 — sensor reschedule.  If there are
                    # reschedule rows still pending, sleep until the
                    # nearest next_check_at and loop again instead of
                    # finalising.  Cooperative-cancel-aware.
                    next_due = self._next_reschedule_due(run_id)
                    if next_due is not None:
                        wait_secs = max(1.0, min(60.0,
                            (next_due - _now()).total_seconds()))
                        if cancel_event.wait(timeout=wait_secs):
                            self._finalise_cancelled(run_id)
                            _cancelled_return = True
                            return R_CANCELLED
                        continue
                    final = self._compute_final_status(run_id)
                    self._finalise(run_id, final)
                    return final

                # Submit every ready stage in parallel up to the pool size.
                futures: List[Future] = []
                for stage in ready[: self.max_parallel_stages]:
                    if self._check_cancelled(run_id, cancel_event):
                        self._finalise_cancelled(run_id)
                        _cancelled_return = True
                        return R_CANCELLED
                    futures.append(
                        pool.submit(
                            self._execute_one_stage_with_policy,
                            run_id, stage, cancel_event,
                        )
                    )
                # Block until at least one completes; loop will pick
                # up any newly-ready stages on the next iteration.
                while futures:
                    if self._check_cancelled(run_id, cancel_event):
                        # Setting the event allows in-flight stages
                        # to short-circuit cooperatively via ctx.is_cancelled().
                        self._finalise_cancelled(run_id)
                        _cancelled_return = True
                        return R_CANCELLED
                    done, futures_set = wait(
                        futures, timeout=self.cancel_poll_seconds,
                        return_when=FIRST_COMPLETED,
                    )
                    if done:
                        futures = list(futures_set)
                        break
                    # Timeout → loop back to check cancel + DB poll.
                    # The futures stay; we just re-loop the cancel check.
        except Exception as exc:
            logger.error("[dataflow.dispatch] run %d crashed: %s", run_id, exc, exc_info=True)
            self._finalise(run_id, R_FAILED, error=f"dispatcher crashed: {exc}")
            return R_FAILED
        finally:
            # BF-590: shutdown path.  Normal completion → wait for inflight
            # to drain.  Cancellation → cancel pending submissions and
            # return immediately so the caller / API thread isn't blocked.
            try:
                if _cancelled_return:
                    pool.shutdown(wait=False, cancel_futures=True)
                else:
                    pool.shutdown(wait=True)
            except Exception as _shutdown_exc:
                logger.debug("[dataflow.dispatch] pool shutdown error: %s", _shutdown_exc)

    # ── Cross-pod cancellation check ────────────────────────────────────

    def _check_cancelled(self, run_id: int, cancel_event: threading.Event) -> bool:
        """Returns True when either the local event is set OR the DB row
        was flipped to cancelled by another pod / API request.
        """
        if cancel_event.is_set():
            return True
        from core.db.models import DataFlowRun
        try:
            with self.db.get_session(read_only=True) as session:
                run = session.query(DataFlowRun).filter(
                    DataFlowRun.id == run_id
                ).first()
                if run is not None and run.status == R_CANCELLED:
                    cancel_event.set()
                    return True
        except Exception as exc:
            logger.debug("[dataflow.dispatch] cancel poll failed: %s", exc)
        return False

    def _run_targeted(self, run_id: int, only_alias: str) -> str:
        """Execute exactly one stage by alias.  Used by ``rerun_stage``.

        Doesn't drive the rest of the DAG — downstream stages keep their
        prior status.  Final run status is recomputed afterward.
        """
        cancel_event = threading.Event()
        self.engine._register_cancel_event(run_id, cancel_event)
        try:
            stage = self._load_stage_row(run_id, only_alias)
            if stage is None:
                raise DataFlowError(f"stage {only_alias!r} missing on run {run_id}")
            self._execute_one_stage_with_policy(run_id, stage, cancel_event)
            final = self._compute_final_status(run_id)
            self._finalise(run_id, final)
            return final
        finally:
            self.engine._release_cancel_event(run_id)

    # ── Stage selection ─────────────────────────────────────────────────

    def _next_reschedule_due(self, run_id: int) -> Optional[datetime]:
        """Return the earliest pending next_check_at across reschedule
        rows for the given run, or None if no row is in reschedule state.
        """
        from core.db.models import DataFlowRunStage
        with self.db.get_session(read_only=True) as session:
            rows = (
                session.query(DataFlowRunStage)
                .filter(DataFlowRunStage.run_id == run_id,
                         DataFlowRunStage.status == S_RESCHEDULE)
                .all()
            )
        if not rows:
            return None
        deadlines: List[datetime] = []
        for r in rows:
            if r.next_check_at is None:
                return _now()   # malformed — treat as immediately due
            nxt = r.next_check_at
            if nxt.tzinfo is None:
                nxt = nxt.replace(tzinfo=timezone.utc)
            deadlines.append(nxt)
        return min(deadlines) if deadlines else None

    def _pick_ready_stages(self, run_id: int) -> List[Any]:
        """Return the next batch of stages whose predecessors are all
        succeeded-or-skipped.  In Phase 0 we still execute sequentially
        (return [first_ready]) but the list shape is the future-proof
        contract for parallel dispatch.
        """
        from core.db.models import DataFlowRunStage, DataFlowStage

        with self.db.get_session(read_only=True) as session:
            run_stages = (
                session.query(DataFlowRunStage)
                .filter(DataFlowRunStage.run_id == run_id)
                .order_by(DataFlowRunStage.seq.asc())
                .all()
            )
            if not run_stages:
                return []

            status_by_alias: Dict[str, str] = {s.stage_alias: s.status for s in run_stages}

            # Pull dataflow-level stage defs once for predecessors + on_failure.
            wf_id = run_stages[0].run_id  # placeholder
            # Need dataflow_id from run row
            from core.db.models import DataFlowRun
            run = session.query(DataFlowRun).filter(DataFlowRun.id == run_id).first()
            wf_id = run.dataflow_id
            defs = {
                d.stage_alias: d for d in (
                    session.query(DataFlowStage)
                    .filter(DataFlowStage.dataflow_id == wf_id)
                    .all()
                )
            }

        # branch_to tolerance: a failed predecessor is acceptable iff this
        # stage is the explicit on_failure_target of that failed stage.
        # We build the mapping {failed_alias: target_alias} once per tick.
        tolerated: Dict[str, str] = {}
        for d in defs.values():
            if (d.on_failure == "branch_to" and
                    d.on_failure_target and
                    status_by_alias.get(d.stage_alias) == S_FAILED):
                tolerated[d.stage_alias] = d.on_failure_target

        ready: List[Any] = []
        now_utc = _now()
        for s in run_stages:
            # Phase 132.22 — reschedule rows are pickable once due
            if s.status == S_RESCHEDULE:
                nxt = s.next_check_at
                if nxt is None:
                    # Treat malformed reschedule row as immediately due
                    ready.append(s)
                    continue
                if nxt.tzinfo is None:
                    nxt = nxt.replace(tzinfo=timezone.utc)
                if nxt <= now_utc:
                    ready.append(s)
                continue
            if s.status != S_NOT_STARTED:
                continue
            wf_stage = defs.get(s.stage_alias)
            preds = (wf_stage.predecessors or []) if wf_stage else []

            blocked = False
            all_done = True
            for p in preds:
                ps = status_by_alias.get(p)
                if ps in (S_FAILED, S_CANCELLED):
                    if tolerated.get(p) == s.stage_alias:
                        # Failed predecessor with branch_to pointing here:
                        # treat as satisfied.
                        continue
                    blocked = True
                    break
                if ps != S_SUCCEEDED and ps != S_SKIPPED:
                    all_done = False
                    break
            if blocked:
                self._mark_skipped(run_id, s.stage_alias,
                                   reason="predecessor failed")
                continue
            if not all_done:
                continue
            ready.append(s)

        return ready

    def _load_stage_row(self, run_id: int, stage_alias: str) -> Optional[Any]:
        from core.db.models import DataFlowRunStage
        with self.db.get_session(read_only=True) as session:
            return (
                session.query(DataFlowRunStage)
                .filter(
                    DataFlowRunStage.run_id == run_id,
                    DataFlowRunStage.stage_alias == stage_alias,
                )
                .first()
            )

    # ── Execute one stage with retry + timeout policy ───────────────────

    def _execute_one_stage_with_policy(
        self,
        run_id: int,
        run_stage: Any,
        cancel_event: threading.Event,
    ) -> None:
        """Wraps ``_execute_one_stage`` with the retry_policy + timeout
        declared on the dataflow_stages row.

        Retry policy schema (stored on dataflow_stages.retry_policy JSON):
            {
              "max_attempts":     int   (default 1 — no retry),
              "backoff_seconds":  float (default 5),
              "exponential":      bool  (default true — multiplies backoff per attempt),
              "max_backoff_seconds": float (default 300, cap on exponential),
              "retry_on":         list[str] | "any" (optional — substring match
                                  against error message; if a list AND no
                                  substring matches, do NOT retry)
            }

        Timeout: enforced by a worker thread + join().  If the stage
        doesn't return within timeout_seconds, the stage row is marked
        failed with "timed out".  In Phase 0 we cannot forcibly kill a
        stuck Python thread — instead we set the cancel_event so the
        stage's cooperative checks observe cancellation; if the stage
        is stuck in native code it will eventually finish + be discarded.
        """
        from core.db.models import DataFlowRunStage, DataFlowStage, DataFlowRun

        alias = run_stage.stage_alias
        with self.db.get_session(read_only=True) as session:
            row = (
                session.query(DataFlowRunStage)
                .filter(DataFlowRunStage.run_id == run_id,
                        DataFlowRunStage.stage_alias == alias)
                .first()
            )
            if row is None or row.status not in (S_NOT_STARTED, S_FAILED):
                return
            run = session.query(DataFlowRun).filter(DataFlowRun.id == run_id).first()
            wf_stage = (
                session.query(DataFlowStage)
                .filter(DataFlowStage.dataflow_id == run.dataflow_id,
                        DataFlowStage.stage_alias == alias)
                .first()
            )
            retry_policy = dict((wf_stage.retry_policy if wf_stage else None) or {})
            timeout_s = wf_stage.timeout_seconds if wf_stage else None

        max_attempts = max(1, int(retry_policy.get("max_attempts", 1)))
        backoff = float(retry_policy.get("backoff_seconds", 5))
        exponential = bool(retry_policy.get("exponential", True))
        max_backoff = float(retry_policy.get("max_backoff_seconds", 300))
        retry_on = retry_policy.get("retry_on", "any")

        attempt_idx = 0
        while attempt_idx < max_attempts:
            attempt_idx += 1
            if cancel_event.is_set():
                return
            if timeout_s and timeout_s > 0:
                self._execute_with_timeout(run_id, run_stage, cancel_event, timeout_s)
            else:
                self._execute_one_stage(run_id, run_stage, cancel_event)

            # Check outcome to decide retry.
            with self.db.get_session(read_only=True) as session:
                row = (
                    session.query(DataFlowRunStage)
                    .filter(DataFlowRunStage.run_id == run_id,
                            DataFlowRunStage.stage_alias == alias)
                    .first()
                )
            if row is None:
                return
            if row.status != S_FAILED:
                return   # succeeded / skipped / cancelled — no retry
            if attempt_idx >= max_attempts:
                return
            err_msg = row.error or ""
            if not self._error_is_retryable(err_msg, retry_on):
                return
            delay = backoff * (2 ** (attempt_idx - 1) if exponential else 1)
            delay = min(delay, max_backoff)
            logger.info(
                "[dataflow.dispatch] run %d stage %s failed (attempt %d/%d), "
                "retrying after %.1fs",
                run_id, alias, attempt_idx, max_attempts, delay,
            )
            # Reset row to not_started so the next iteration picks it up.
            with self.db.get_session() as session:
                row = (
                    session.query(DataFlowRunStage)
                    .filter(DataFlowRunStage.run_id == run_id,
                            DataFlowRunStage.stage_alias == alias)
                    .first()
                )
                if row is not None:
                    row.status = S_NOT_STARTED
                    row.error = None
                    row.ended_at = None
                    session.flush()

            # Cooperative sleep — break early on cancel.
            slept = 0.0
            while slept < delay:
                if cancel_event.is_set():
                    return
                step = min(0.5, delay - slept)
                time.sleep(step)
                slept += step

    @staticmethod
    def _error_is_retryable(err_msg: str, retry_on: Any) -> bool:
        if retry_on == "any" or retry_on is None:
            return True
        if isinstance(retry_on, str):
            return retry_on in (err_msg or "")
        if isinstance(retry_on, list):
            return any(p in (err_msg or "") for p in retry_on)
        return True

    def _execute_with_timeout(
        self,
        run_id: int,
        run_stage: Any,
        cancel_event: threading.Event,
        timeout_s: float,
    ) -> None:
        """Run ``_execute_one_stage`` in a daemon worker thread; mark the
        row failed with 'timed out' if it doesn't return in time.
        """
        from core.db.models import DataFlowRunStage

        alias = run_stage.stage_alias
        done = threading.Event()
        err_box: Dict[str, BaseException] = {}

        def _worker():
            try:
                self._execute_one_stage(run_id, run_stage, cancel_event)
            except BaseException as exc:
                err_box["exc"] = exc
            finally:
                done.set()

        t = threading.Thread(target=_worker, daemon=True,
                              name=f"wf-stage-{run_id}-{alias}-timed")
        t.start()
        if not done.wait(timeout=float(timeout_s)):
            # Signal cancellation so cooperative stages exit promptly.
            cancel_event.set()
            with self.db.get_session() as session:
                row = (
                    session.query(DataFlowRunStage)
                    .filter(DataFlowRunStage.run_id == run_id,
                            DataFlowRunStage.stage_alias == alias)
                    .first()
                )
                if row is not None and row.status in (S_RUNNING, S_NOT_STARTED):
                    row.status = S_FAILED
                    row.error = f"stage timed out after {timeout_s}s"
                    row.ended_at = _now()
                    row.duration_seconds = _duration_seconds(row.started_at, row.ended_at)
                    session.flush()
            # Re-clear cancel so subsequent retries get a fair shot —
            # the cancel was specific to this stuck attempt.
            cancel_event.clear()
            return
        if "exc" in err_box:
            raise err_box["exc"]   # type: ignore[misc]

    # ── Execute one stage ───────────────────────────────────────────────

    def _execute_one_stage(self, run_id: int, run_stage: Any, cancel_event: threading.Event) -> None:
        """Materialise StageContext, call execute(), persist result."""
        from core.db.models import DataFlowRun, DataFlowRunStage, DataFlowStage

        alias = run_stage.stage_alias
        # Re-read fresh from DB so we don't operate on a detached object.
        # All ORM attribute reads happen inside the session block; we
        # capture primitives into local vars and then close the session.
        with self.db.get_session() as session:
            row = (
                session.query(DataFlowRunStage)
                .filter(
                    DataFlowRunStage.run_id == run_id,
                    DataFlowRunStage.stage_alias == alias,
                )
                .first()
            )
            if row is None:
                return
            if row.status not in (S_NOT_STARTED, S_FAILED):
                return

            run = session.query(DataFlowRun).filter(DataFlowRun.id == run_id).first()
            wf_stage = (
                session.query(DataFlowStage)
                .filter(
                    DataFlowStage.dataflow_id == run.dataflow_id,
                    DataFlowStage.stage_alias == alias,
                )
                .first()
            )

            # Materialise inputs for the StageContext.
            prev_outputs = self._collect_prev_outputs(session, run_id, alias, wf_stage)
            run_context = dict(run.context or {})
            stage_type = wf_stage.stage_type if wf_stage else row.stage_type
            # Global → step config inheritance.  The DataFlow's default_context
            # (merged with trigger_payload and any prior stage's
            # context_updates) is exposed alongside the stage-specific config
            # so stages read e.g. `oracle_url` once at the DataFlow level
            # without admins having to repeat it on every stage.  Stage-
            # specific keys override global ones — the standard "step can
            # override if needed" semantic.
            _global_params = {k: v for k, v in run_context.items()
                                if not k.startswith("_")}
            _step_params = dict(wf_stage.config or {}) if wf_stage else {}
            stage_config = {**_global_params, **_step_params}
            # Phase 132.22 — resolve {var.foo} placeholders from project
            # variables.  Lazy-loaded per run; secret variables decrypt
            # just-in-time and never leave the resolver in plaintext.
            try:
                from core.dataflow.variables import VariableResolver
                resolver = VariableResolver(self.db, dataflow_id=run.dataflow_id)
                stage_config = resolver.expand(stage_config)
                run_context = resolver.expand(run_context)
            except Exception as _var_exc:
                logger.debug("[dataflow.dispatch] var expansion skipped: %s", _var_exc)
            on_failure = wf_stage.on_failure if wf_stage else "halt"
            on_failure_target = wf_stage.on_failure_target if wf_stage else None
            # Snapshot run-level fields into locals so the closure below
            # never touches a detached ORM instance.
            run_dataflow_id = run.dataflow_id
            run_dataflow_name = run.dataflow_name
            run_dataflow_version = run.dataflow_version
            run_triggered_by = run.triggered_by
            run_run_as = getattr(run, "run_as", None)
            row_seq = row.seq

            row.status = S_RUNNING
            row.attempts = (row.attempts or 0) + 1
            row_attempts = row.attempts
            row.started_at = _now()
            row.inputs = {"prev_outputs": list(prev_outputs.keys()),
                          "run_context_keys": sorted(run_context.keys())}
            session.flush()

        self._broadcast({
            "event": "workflow_stage_started",
            "run_id": run_id,
            "stage_alias": alias,
            "stage_type": stage_type,
            "triggered_by": run_triggered_by,
        })

        ctx = StageContext(
            run_id=run_id,
            dataflow_id=run_dataflow_id,
            dataflow_name=run_dataflow_name,
            dataflow_version=run_dataflow_version,
            stage_alias=alias,
            stage_type=stage_type,
            seq=row_seq,
            config=stage_config,
            run_context=run_context,
            prev_outputs=prev_outputs,
            triggered_by=run_triggered_by,
            run_as=run_run_as,
            attempt=row_attempts,
            worker_node=self.engine.worker_node,
            cancel_event=cancel_event,
            log_emit=lambda line, _alias=alias: logger.debug("[dataflow stage %s] %s", _alias, line),
            db_manager=self.db,
            broadcast_fn=self.broadcast_fn,
        )

        try:
            stage_cls = self.registry.get(stage_type)
        except UnknownStageTypeError as exc:
            self._persist_failure(run_id, alias, str(exc), [], cancel_event=cancel_event,
                                  on_failure="halt", on_failure_target=None)
            return

        result: StageResult
        start = time.time()
        try:
            instance = stage_cls()
            result = instance.execute(ctx)
            if not isinstance(result, StageResult):
                raise StageExecutionError(
                    f"{stage_cls.__name__}.execute returned "
                    f"{type(result).__name__}, expected StageResult"
                )
        except DataFlowCancelledError:
            self._persist_cancelled(run_id, alias, ctx.drain_logs())
            return
        except Exception as exc:
            tb = traceback.format_exc()
            logs = ctx.drain_logs()
            logs.append(tb)
            self._persist_failure(
                run_id, alias, f"{type(exc).__name__}: {exc}", logs,
                cancel_event=cancel_event,
                on_failure=on_failure,
                on_failure_target=on_failure_target,
            )
            return
        duration = time.time() - start

        # Merge captured log_lines from ctx.log() + the StageResult.log_lines.
        all_logs = ctx.drain_logs() + (result.log_lines or [])
        self._persist_result(run_id, alias, result, duration, all_logs,
                             on_failure=on_failure,
                             on_failure_target=on_failure_target)

    # ── Helpers ─────────────────────────────────────────────────────────

    def _collect_prev_outputs(
        self,
        session: Any,
        run_id: int,
        alias: str,
        wf_stage: Any,
    ) -> Dict[str, Dict[str, Any]]:
        """Return a dict mapping predecessor stage_alias → outputs dict.
        Used by ``StageContext.get_input``.
        """
        from core.db.models import DataFlowRunStage

        preds = (wf_stage.predecessors or []) if wf_stage else []
        if not preds:
            return {}
        rows = (
            session.query(DataFlowRunStage)
            .filter(
                DataFlowRunStage.run_id == run_id,
                DataFlowRunStage.stage_alias.in_(preds),
            )
            .all()
        )
        return {r.stage_alias: (r.outputs or {}) for r in rows}

    def _persist_result(
        self,
        run_id: int,
        alias: str,
        result: StageResult,
        duration: float,
        log_lines: List[str],
        on_failure: str,
        on_failure_target: Optional[str],
    ) -> None:
        from core.db.models import DataFlowRun, DataFlowRunStage

        with self.db.get_session() as session:
            row = (
                session.query(DataFlowRunStage)
                .filter(
                    DataFlowRunStage.run_id == run_id,
                    DataFlowRunStage.stage_alias == alias,
                )
                .first()
            )
            if row is None:
                return

            row.outputs = result.outputs or {}
            row.log_lines = log_lines
            row.duration_seconds = duration

            if result.status == "succeeded":
                row.status = S_SUCCEEDED
                row.error = None
                row.ended_at = _now()
            elif result.status == "skipped":
                row.status = S_SKIPPED
                row.error = result.error
                row.ended_at = _now()
            elif result.status == "reschedule":
                # Phase 132.22 — sensor reschedule.  Park the stage with
                # status=reschedule + next_check_at, free the worker.  The
                # stage's next_check_at is consumed by _pick_ready_stages
                # — stages with status=reschedule + next_check_at>now() are
                # NOT picked yet; once now() catches up we re-execute.
                # ended_at INTENTIONALLY left null — the stage isn't done.
                row.status = S_RESCHEDULE
                row.error = None
                secs = result.reschedule_after_seconds or 60
                row.next_check_at = _now() + timedelta(seconds=int(secs))
            else:
                row.status = S_FAILED
                row.error = result.error or "stage failed"
                row.ended_at = _now()

            # Merge context_updates into the run's context.
            if result.context_updates:
                run = session.query(DataFlowRun).filter(DataFlowRun.id == run_id).first()
                if run is not None:
                    merged = dict(run.context or {})
                    merged.update(result.context_updates)
                    run.context = merged

            # Honour branch_to: mark every alias between current+1 and target
            # (exclusive of target) as skipped.
            if result.branch_to:
                self._honour_branch_to(session, run_id, alias, result.branch_to)

            session.flush()

        # Apply on_failure policy
        if result.status == "failed":
            self._apply_on_failure(run_id, alias, on_failure, on_failure_target)

        self._broadcast({
            "event": "workflow_stage_completed",
            "run_id": run_id,
            "stage_alias": alias,
            "status": result.status,
            "duration_seconds": duration,
            "error": result.error if result.status != "succeeded" else None,
        })

    def _persist_failure(
        self,
        run_id: int,
        alias: str,
        error: str,
        log_lines: List[str],
        cancel_event: threading.Event,
        on_failure: str,
        on_failure_target: Optional[str],
    ) -> None:
        from core.db.models import DataFlowRunStage

        with self.db.get_session() as session:
            row = (
                session.query(DataFlowRunStage)
                .filter(
                    DataFlowRunStage.run_id == run_id,
                    DataFlowRunStage.stage_alias == alias,
                )
                .first()
            )
            if row is None:
                return
            row.status = S_FAILED
            row.error = error
            row.log_lines = log_lines
            row.ended_at = _now()
            row.duration_seconds = _duration_seconds(row.started_at, row.ended_at)
            session.flush()
        self._apply_on_failure(run_id, alias, on_failure, on_failure_target)
        self._broadcast({
            "event": "workflow_stage_completed",
            "run_id": run_id,
            "stage_alias": alias,
            "status": "failed",
            "error": error,
        })

    def _persist_cancelled(self, run_id: int, alias: str, log_lines: List[str]) -> None:
        from core.db.models import DataFlowRunStage

        with self.db.get_session() as session:
            row = (
                session.query(DataFlowRunStage)
                .filter(
                    DataFlowRunStage.run_id == run_id,
                    DataFlowRunStage.stage_alias == alias,
                )
                .first()
            )
            if row is None:
                return
            row.status = S_CANCELLED
            row.error = "cancelled"
            row.log_lines = log_lines
            row.ended_at = _now()
            row.duration_seconds = _duration_seconds(row.started_at, row.ended_at)
            session.flush()

    def _apply_on_failure(
        self,
        run_id: int,
        failed_alias: str,
        on_failure: str,
        on_failure_target: Optional[str],
    ) -> None:
        """Implements the per-stage on_failure policy.

        * halt      → proactively skip every not_started stage.  The
                      run ends with status=failed.  "Halt" means the
                      whole pipeline stops, not just the failed branch.
        * continue  → do NOTHING proactively.  The cascade in
                      ``_pick_ready_stages`` will skip stages downstream
                      of the failure (those that have failed_alias as a
                      predecessor); independent branches keep running.
                      Run usually ends as partial.
        * branch_to → mark stages strictly between failed_seq and
                      target_seq as skipped.  The target is reached even
                      though its predecessor failed — see
                      ``_pick_ready_stages`` for the tolerated-failed
                      logic.
        """
        from core.db.models import DataFlowRunStage

        with self.db.get_session() as session:
            rows = (
                session.query(DataFlowRunStage)
                .filter(DataFlowRunStage.run_id == run_id)
                .order_by(DataFlowRunStage.seq.asc())
                .all()
            )
            seq_by_alias = {r.stage_alias: r.seq for r in rows}
            failed_seq = seq_by_alias.get(failed_alias)
            if failed_seq is None:
                return

            if on_failure == "halt":
                for r in rows:
                    if r.status == S_NOT_STARTED:
                        r.status = S_SKIPPED
                        r.error = "skipped — upstream halted"
                session.flush()
                return

            if on_failure == "continue":
                # Intentionally do nothing — the natural cascade in
                # _pick_ready_stages handles downstream-of-failed.
                return

            if on_failure == "branch_to" and on_failure_target:
                target_seq = seq_by_alias.get(on_failure_target)
                if target_seq is None:
                    return
                for r in rows:
                    if r.seq > failed_seq and r.seq < target_seq and r.status == S_NOT_STARTED:
                        r.status = S_SKIPPED
                        r.error = f"skipped — branched to {on_failure_target}"
                session.flush()
                return

    def _honour_branch_to(
        self,
        session: Any,
        run_id: int,
        current_alias: str,
        target_alias: str,
    ) -> None:
        from core.db.models import DataFlowRunStage

        rows = (
            session.query(DataFlowRunStage)
            .filter(DataFlowRunStage.run_id == run_id)
            .order_by(DataFlowRunStage.seq.asc())
            .all()
        )
        seq_by_alias = {r.stage_alias: r.seq for r in rows}
        cur_seq = seq_by_alias.get(current_alias)
        target_seq = seq_by_alias.get(target_alias)
        if cur_seq is None or target_seq is None:
            return
        for r in rows:
            if r.seq > cur_seq and r.seq < target_seq and r.status == S_NOT_STARTED:
                r.status = S_SKIPPED
                r.error = f"skipped — branched to {target_alias}"
        # Don't flush here; caller flushes the same session.

    def _mark_skipped(self, run_id: int, alias: str, reason: str) -> None:
        from core.db.models import DataFlowRunStage
        with self.db.get_session() as session:
            row = (
                session.query(DataFlowRunStage)
                .filter(
                    DataFlowRunStage.run_id == run_id,
                    DataFlowRunStage.stage_alias == alias,
                )
                .first()
            )
            if row is None or row.status != S_NOT_STARTED:
                return
            row.status = S_SKIPPED
            row.error = reason
            row.ended_at = _now()
            session.flush()

    # ── Run finalisation ────────────────────────────────────────────────

    def _compute_final_status(self, run_id: int) -> str:
        from core.db.models import DataFlowRunStage

        with self.db.get_session(read_only=True) as session:
            rows = (
                session.query(DataFlowRunStage)
                .filter(DataFlowRunStage.run_id == run_id)
                .all()
            )
            statuses = [r.status for r in rows]

        if not statuses:
            return R_SUCCEEDED
        if any(s == S_CANCELLED for s in statuses):
            return R_CANCELLED
        if all(s == S_SUCCEEDED for s in statuses):
            return R_SUCCEEDED
        if all(s in (S_SUCCEEDED, S_SKIPPED) for s in statuses):
            # No failures, but some stages skipped (branched / continue policy)
            return R_PARTIAL
        if any(s == S_FAILED for s in statuses):
            # If failure was tolerated by `continue` policy and downstream
            # stages succeeded after it, this is `partial`; otherwise it's
            # a hard fail.  Simplification: presence of a fail = failed.
            if any(s == S_SUCCEEDED for s in statuses[statuses.index(S_FAILED):]):
                return R_PARTIAL
            return R_FAILED
        return R_PARTIAL

    def _finalise(self, run_id: int, status: str, error: Optional[str] = None) -> None:
        from core.db.models import DataFlowRun

        sla_breached_now = False
        triggered_by = None
        dataflow_name = None
        with self.db.get_session() as session:
            run = session.query(DataFlowRun).filter(DataFlowRun.id == run_id).first()
            if run is None:
                return
            run.status = status
            if error and not run.error:
                run.error = error
            run.ended_at = _now()
            run.duration_seconds = _duration_seconds(run.started_at, run.ended_at)
            # Phase 132.20 — SLA breach check.  A breach is a flag, not a
            # status; the run still ends at its natural status (succeeded,
            # failed, partial).  ``expected_completion_at`` is set at run
            # start when DataFlow.sla_seconds > 0.
            exp = run.expected_completion_at
            if exp is not None and run.ended_at is not None:
                if exp.tzinfo is None:
                    exp = exp.replace(tzinfo=timezone.utc)
                if run.ended_at > exp:
                    run.sla_breached = True
                    sla_breached_now = True
            # Snapshot fields for broadcast so the WS handler can scope
            # the event to the right user (per-user WS filtering pattern).
            triggered_by = run.triggered_by
            dataflow_name = run.dataflow_name
            # Capture final stage outputs as the run-level outputs.
            from core.db.models import DataFlowRunStage
            last = (
                session.query(DataFlowRunStage)
                .filter(
                    DataFlowRunStage.run_id == run_id,
                    DataFlowRunStage.status == S_SUCCEEDED,
                )
                .order_by(DataFlowRunStage.seq.desc())
                .first()
            )
            if last is not None and last.outputs:
                run.outputs = last.outputs
            session.flush()
        self._broadcast({
            "event": "workflow_run_completed",
            "run_id": run_id,
            "status": status,
            "error": error,
            "sla_breached": sla_breached_now,
            "triggered_by": triggered_by,
            "dataflow_name": dataflow_name,
        })
        if sla_breached_now:
            self._broadcast({
                "event": "workflow_run_sla_breached",
                "run_id": run_id,
                "status": status,
                "triggered_by": triggered_by,
                "dataflow_name": dataflow_name,
            })

        # Phase 132.21 + 132.23 — notification policies + lineage hook
        # fire on a daemon thread so a slow SMTP / webhook / DB roundtrip
        # never blocks the dispatcher from finishing the run.  If the
        # background fire crashes, the run is already finalised — only
        # the side-effects are lost.
        self._fire_post_finalise_hooks(
            run_id=run_id, status=status, error=error,
            sla_breached=sla_breached_now,
            triggered_by=triggered_by, dataflow_name=dataflow_name,
        )

    def _fire_post_finalise_hooks(
        self, *, run_id: int, status: str, error: Optional[str],
        sla_breached: bool, triggered_by: Optional[str],
        dataflow_name: Optional[str],
    ) -> None:
        """Phase 132.24 — run notification policies + lineage off-thread.

        The dispatcher must NOT block on:
        * SMTP host that's slow / unreachable
        * Webhook policy POST that hangs at the connect
        * Lineage DB write that contends with something else

        Daemon thread → crash here cannot keep a worker pinned.  All
        per-event work has its own try/except so one bad policy doesn't
        kill the rest.
        """
        def _run_hooks() -> None:
            try:
                from core.dataflow.notification_policy import (
                    get_notification_engine,
                    EVT_RUN_FAILED, EVT_RUN_SUCCEEDED, EVT_RUN_PARTIAL,
                    EVT_RUN_CANCELLED, EVT_SLA_BREACHED,
                )
                engine = get_notification_engine()
                if engine is not None:
                    run_dict = {
                        "id": run_id, "status": status, "error": error,
                        "dataflow_id": None, "dataflow_name": dataflow_name,
                        "triggered_by": triggered_by,
                        "sla_breached": sla_breached,
                    }
                    try:
                        from core.db.models import DataFlowRun
                        with self.db.get_session(read_only=True) as session:
                            row = session.query(DataFlowRun).filter(
                                DataFlowRun.id == run_id,
                            ).first()
                            if row is not None:
                                run_dict["dataflow_id"] = row.dataflow_id
                                run_dict["started_at"] = (
                                    row.started_at.isoformat() if row.started_at else None)
                                run_dict["ended_at"]   = (
                                    row.ended_at.isoformat()   if row.ended_at   else None)
                    except Exception as _bf_exc:
                        logger.debug("[dataflow.dispatch] backfill run row failed: %s",
                                     _bf_exc)
                    event_map = {
                        R_FAILED:    EVT_RUN_FAILED,
                        R_SUCCEEDED: EVT_RUN_SUCCEEDED,
                        R_PARTIAL:   EVT_RUN_PARTIAL,
                        R_CANCELLED: EVT_RUN_CANCELLED,
                    }
                    evt_name = event_map.get(status)
                    if evt_name is not None:
                        try:
                            engine.on_run_event(evt_name, run_dict)
                        except Exception as _e1:
                            logger.debug("notify %s: %s", evt_name, _e1)
                    if sla_breached:
                        try:
                            engine.on_run_event(EVT_SLA_BREACHED, run_dict)
                        except Exception as _e2:
                            logger.debug("notify sla: %s", _e2)
            except Exception as _np_exc:
                logger.debug("[dataflow.dispatch] notification policies skipped: %s",
                             _np_exc)

            if status == R_SUCCEEDED:
                try:
                    from core.dataflow.lineage_hook import record_run_lineage
                    n = record_run_lineage(run_id, self.db)
                    if n:
                        logger.debug("[dataflow.lineage] recorded %d entries for run %d",
                                      n, run_id)
                except Exception as _lin_exc:
                    logger.debug("[dataflow.dispatch] lineage hook skipped: %s",
                                 _lin_exc)

        threading.Thread(target=_run_hooks, daemon=True,
                          name=f"wf-posthooks-{run_id}").start()

    def _check_hard_timeout(self, run_id: int) -> bool:
        """Phase 132.25 — return True when the run's wall-clock exceeds
        the DataFlow's ``max_run_seconds``.  Reads BOTH rows in one
        session.  Caller cancels the run on True.
        """
        from core.db.models import DataFlowRun, DataFlow
        try:
            with self.db.get_session(read_only=True) as session:
                run = session.query(DataFlowRun).filter(
                    DataFlowRun.id == run_id).first()
                if run is None or run.started_at is None:
                    return False
                wf = session.query(DataFlow).filter(
                    DataFlow.id == run.dataflow_id).first()
                if wf is None:
                    return False
                cap = getattr(wf, "max_run_seconds", None)
                if not cap or int(cap) <= 0:
                    return False
                started = run.started_at
                if started.tzinfo is None:
                    started = started.replace(tzinfo=timezone.utc)
                elapsed = (_now() - started).total_seconds()
                return elapsed > int(cap)
        except Exception as exc:
            logger.debug("[dataflow.dispatch] hard-timeout check failed: %s", exc)
            return False

    def _finalise_cancelled(self, run_id: int, reason: Optional[str] = None) -> None:
        from core.db.models import DataFlowRun, DataFlowRunStage

        with self.db.get_session() as session:
            run = session.query(DataFlowRun).filter(DataFlowRun.id == run_id).first()
            if run is None:
                return
            run.status = R_CANCELLED
            run.ended_at = _now()
            run.duration_seconds = _duration_seconds(run.started_at, run.ended_at)
            if reason and not run.error:
                run.error = reason
            # Phase 132.24 — sweep stage rows so the Ops Grid doesn't show
            # the run as cancelled with stages stuck in reschedule/not_started.
            # Affects: rows parked by sensor reschedule AND any pending
            # work that hadn't started yet.
            (session.query(DataFlowRunStage)
                .filter(DataFlowRunStage.run_id == run_id,
                         DataFlowRunStage.status.in_([S_RESCHEDULE, S_NOT_STARTED]))
                .update({"status": S_CANCELLED,
                          "ended_at": _now(),
                          "next_check_at": None},
                         synchronize_session=False))
            session.flush()

    # ── Broadcast ───────────────────────────────────────────────────────

    def _broadcast(self, payload: Dict[str, Any]) -> None:
        if self.broadcast_fn is None:
            return
        try:
            self.broadcast_fn(payload)
        except Exception as exc:
            logger.debug("[dataflow.dispatch] broadcast failed (non-fatal): %s", exc)


# ── Module-level singleton accessor ────────────────────────────────────────


_dispatcher: Optional[Dispatcher] = None
_dispatcher_lock = threading.Lock()


def init_dispatcher(
    db_manager: Any,
    engine: Any,
    registry: Optional[StageTypeRegistry] = None,
    broadcast_fn: Optional[Callable[[Dict[str, Any]], None]] = None,
) -> Dispatcher:
    global _dispatcher
    with _dispatcher_lock:
        _dispatcher = Dispatcher(
            db_manager=db_manager,
            engine=engine,
            registry=registry,
            broadcast_fn=broadcast_fn,
        )
    return _dispatcher


def get_dispatcher() -> Optional[Dispatcher]:
    return _dispatcher
