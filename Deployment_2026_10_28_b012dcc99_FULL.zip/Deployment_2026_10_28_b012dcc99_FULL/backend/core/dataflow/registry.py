"""Stage-type registry.

Single source of truth for which ``BaseStage`` subclasses are known to
the engine.  Two roles:

1. **In-memory lookup** during dispatch — given a stage_type string
   like ``"sql_query"`` return the class so the dispatcher can
   ``instantiate().execute(ctx)``.
2. **DB sync at startup** — write each manifest into
   ``dataflow_stage_types`` so the admin UI can list registered stages
   without importing Python.

The registry is a *class*, not a module-level dict, so tests can
construct isolated registries.  The conventional module-level singleton
is ``default_registry`` for the production code path.
"""
from __future__ import annotations

import importlib
import logging
import pkgutil
import threading
from typing import Dict, Iterable, List, Optional, Type

from core.dataflow.base import BaseStage
from core.dataflow.exceptions import UnknownStageTypeError

logger = logging.getLogger(__name__)


class StageTypeRegistry:
    """Thread-safe registry of ``BaseStage`` subclasses, keyed by NAME."""

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self._types: Dict[str, Type[BaseStage]] = {}

    # ── Mutators ────────────────────────────────────────────────────────

    def register(self, cls: Type[BaseStage]) -> None:
        """Register a single BaseStage subclass.

        Re-registering the same name is allowed (idempotent at module
        reload time) and quietly overwrites.  Different classes with
        the same NAME raises — caller bug.
        """
        if not issubclass(cls, BaseStage):
            raise TypeError(f"{cls!r} is not a BaseStage subclass")
        if not cls.NAME:
            raise ValueError(f"{cls.__name__}: NAME is empty — cannot register")
        with self._lock:
            existing = self._types.get(cls.NAME)
            if existing is not None and existing is not cls:
                # Re-registering the *exact same class* (module reload) is fine.
                # Two different classes claiming the same NAME is a bug.
                if existing.__module__ != cls.__module__ or existing.__name__ != cls.__name__:
                    raise ValueError(
                        f"Stage type name conflict: {cls.NAME!r} already registered "
                        f"as {existing.class_path()}, can't re-register as {cls.class_path()}"
                    )
            self._types[cls.NAME] = cls
            logger.debug("[dataflow.registry] registered stage type %s → %s",
                         cls.NAME, cls.class_path())

    def register_all(self, classes: Iterable[Type[BaseStage]]) -> None:
        for cls in classes:
            self.register(cls)

    def discover(self, package_name: str = "core.dataflow.stages") -> int:
        """Import every submodule of ``package_name`` so any contained
        ``BaseStage`` subclass registers itself via its ``__init_subclass__``
        hook (or via an explicit module-level ``register`` call).

        Returns the number of stage types known after discovery.
        """
        try:
            pkg = importlib.import_module(package_name)
        except ImportError as exc:
            logger.warning(
                "[dataflow.registry] cannot import %s for discovery: %s",
                package_name, exc,
            )
            return self.size()

        loaded = 0
        for _, modname, _ in pkgutil.iter_modules(pkg.__path__):
            full = f"{package_name}.{modname}"
            try:
                mod = importlib.import_module(full)
                loaded += 1
            except Exception as exc:
                logger.error("[dataflow.registry] failed to import %s: %s", full, exc)
                continue
            # Walk the imported module and register every BaseStage subclass
            # we find.  The @register decorator already registered them
            # into ``default_registry`` at first import — but a *second*
            # registry constructed later (e.g. in tests) wouldn't see
            # those classes since the module's already in sys.modules.
            # This walk makes ``discover()`` idempotent across registries.
            for attr in dir(mod):
                obj = getattr(mod, attr, None)
                if (
                    isinstance(obj, type)
                    and issubclass(obj, BaseStage)
                    and obj is not BaseStage
                    and obj.NAME
                    and obj.__module__ == full
                ):
                    try:
                        self.register(obj)
                    except Exception as exc:
                        logger.debug(
                            "[dataflow.registry] could not register %s: %s",
                            obj.NAME, exc,
                        )
        logger.info(
            "[dataflow.registry] discovery scanned %d modules under %s — %d stage types registered",
            loaded, package_name, self.size(),
        )
        return self.size()

    # ── Read accessors ──────────────────────────────────────────────────

    def get(self, name: str) -> Type[BaseStage]:
        """Look up a registered stage class by NAME.

        Raises ``UnknownStageTypeError`` if absent — callers (dispatcher,
        engine validation) treat this as a definition error.
        """
        with self._lock:
            cls = self._types.get(name)
        if cls is None:
            raise UnknownStageTypeError(f"stage type {name!r} is not registered")
        return cls

    def has(self, name: str) -> bool:
        with self._lock:
            return name in self._types

    def list_all(self) -> List[Type[BaseStage]]:
        with self._lock:
            return list(self._types.values())

    def manifests(self) -> List[Dict[str, object]]:
        """The catalogue: every registered stage type's declaration PLUS
        its live ``runnable`` / ``unavailable_reason`` verdict (2026-09-15,
        ``BaseStage.catalogue_row``).  This is what
        ``GET /api/dataflows/stage-types`` returns and what ``sync_to_db``
        reads (it copies the declared columns and ignores the verdict —
        ``dataflow_stage_types`` has no such column and a verdict about
        one pod must not be read back on another).

        ``registry.size()`` still counts what was DISCOVERED; the verdict
        on each row is what can EXECUTE here.  Those are different numbers
        on every shipped image, and this is where the difference shows.
        """
        with self._lock:
            return [cls.catalogue_row() for cls in self._types.values()]

    def size(self) -> int:
        with self._lock:
            return len(self._types)

    # ── DB sync ─────────────────────────────────────────────────────────

    def sync_to_db(self, db_manager) -> int:
        """Upsert each manifest into ``dataflow_stage_types``.

        Idempotent — safe to call at every startup.  Returns the number of
        rows written.  Tolerates DB failures (logs + returns 0) because
        a brand-new pod with an unmigrated DB should still be able to
        boot the rest of the app.
        """
        if db_manager is None:
            return 0
        from core.db.models import DataFlowStageType  # local import — avoids cycle

        written = 0
        try:
            with db_manager.get_session() as session:
                for manifest in self.manifests():
                    name = manifest["name"]
                    row = session.query(DataFlowStageType).filter(
                        DataFlowStageType.name == name
                    ).first()
                    if row is None:
                        row = DataFlowStageType(
                            name=name,
                            display_name=manifest.get("display_name"),
                            category=manifest["category"],
                            class_path=manifest["class_path"],
                            description=manifest.get("description"),
                            config_schema=manifest.get("config_schema") or {},
                            inputs_schema=manifest.get("inputs_schema") or {},
                            outputs_schema=manifest.get("outputs_schema") or {},
                            is_control_flow=bool(manifest.get("is_control_flow", False)),
                            is_active=True,
                        )
                        session.add(row)
                    else:
                        row.display_name = manifest.get("display_name")
                        row.category = manifest["category"]
                        row.class_path = manifest["class_path"]
                        row.description = manifest.get("description")
                        row.config_schema = manifest.get("config_schema") or {}
                        row.inputs_schema = manifest.get("inputs_schema") or {}
                        row.outputs_schema = manifest.get("outputs_schema") or {}
                        row.is_control_flow = bool(manifest.get("is_control_flow", False))
                        row.is_active = True
                    written += 1
                session.flush()
        except Exception as exc:
            logger.warning("[dataflow.registry] sync_to_db failed (non-fatal): %s", exc)
            return 0
        logger.info("[dataflow.registry] sync_to_db wrote %d rows", written)
        return written


# ── Module-level default singleton (production code path) ──────────────────


default_registry = StageTypeRegistry()


def get_default_registry() -> StageTypeRegistry:
    return default_registry


def register(cls: Type[BaseStage]) -> Type[BaseStage]:
    """Decorator form — ``@register`` on a stage class registers it
    with the default registry.

    Example::

        @register
        class SleepStage(BaseStage):
            NAME = "sleep"
            ...
    """
    default_registry.register(cls)
    return cls


def get_stage_class(name: str, registry: Optional[StageTypeRegistry] = None) -> Type[BaseStage]:
    """Lookup helper that falls back to the default registry."""
    return (registry or default_registry).get(name)
