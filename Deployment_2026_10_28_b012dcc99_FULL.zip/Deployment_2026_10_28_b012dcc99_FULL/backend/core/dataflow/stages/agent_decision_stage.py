"""``AgentDecisionStage`` — invoke a Phase 120 agent and branch on its decision.

Bridges the dataflow engine and the self-healing agents framework so
dataflow authors can compose agent-driven decisions into a DAG.  The
stage feeds the agent its current context, captures the decision, and
emits both ``branch_to`` (for control flow) and context_updates (so the
decision is visible to downstream stages).

Config:
    ``agent_name``      : str (required) — one of orchestrator's registered agents
    ``payload_keys``    : list[str] — copy these keys from run_context into the
                              agent's input event
    ``static_payload``  : dict — additional keys to merge into the input event
    ``branch_map``      : dict[str, str] — {decision_action: target_alias}
                              when the agent emits an action in this map,
                              the stage branches to the target.
    ``default_action_branch`` : str — alias to branch to when no map matches.
"""
from __future__ import annotations

from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_CONTROL, IDEMPOTENT_CONFIGURED,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class AgentDecisionStage(BaseStage):
    NAME = "agent_decision"
    DISPLAY_NAME = "Agent Decision"
    CATEGORY = CATEGORY_CONTROL
    IS_CONTROL_FLOW = True
    DESCRIPTION = "Invoke a Phase 120 agent and branch on its decision."
    IDEMPOTENCY = IDEMPOTENT_CONFIGURED
    CONFIG_SCHEMA = {
        "agent_name":             {"type": "string"},
        "payload_keys":           {"type": "array", "items": {"type": "string"}},
        "static_payload":         {"type": "object"},
        "branch_map":             {"type": "object"},
        "default_action_branch":  {"type": "string"},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        if not config.get("agent_name"):
            errs.append("agent_name is required")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        agent_name = ctx.get_config("agent_name")
        payload_keys = ctx.get_config("payload_keys", []) or []
        static_payload = ctx.get_config("static_payload", {}) or {}
        branch_map = ctx.get_config("branch_map", {}) or {}
        default_branch = ctx.get_config("default_action_branch")

        # Build the event payload from run_context + static_payload.
        event: Dict[str, Any] = {"source": "dataflow",
                                  "dataflow_name": ctx.dataflow_name,
                                  "stage_alias":   ctx.stage_alias}
        for k in payload_keys:
            if k in ctx.run_context:
                event[k] = ctx.run_context[k]
        event.update(static_payload)

        # Locate the orchestrator + agent.
        try:
            from core.agents import get_orchestrator  # type: ignore
            orchestrator = get_orchestrator()
        except Exception as exc:
            return StageResult.failed(error=f"agent framework unavailable: {exc}")
        if orchestrator is None or not getattr(orchestrator, "enabled", False):
            return StageResult.failed(error="agent orchestrator disabled")

        try:
            agent = orchestrator.get_agent(agent_name)
        except Exception as exc:
            return StageResult.failed(error=f"agent {agent_name!r} not found: {exc}")
        if agent is None:
            return StageResult.failed(error=f"agent {agent_name!r} not registered")

        # Run the agent
        try:
            decision = agent.decide(event, context={}) if hasattr(agent, "decide") else None
        except Exception as exc:
            return StageResult.failed(error=f"agent.decide failed: {exc}")

        action = self._extract_action(decision)
        ctx.log(f"agent {agent_name} decision: action={action}")

        outputs: Dict[str, Any] = {
            "agent":    agent_name,
            "action":   action,
            "decision": self._serialise_decision(decision),
        }
        context_updates = {"agent_last_action": action}

        target = branch_map.get(action) if action else None
        if target is None and default_branch:
            target = default_branch
        if target:
            return StageResult.branched(branch_to=target, outputs=outputs,
                                          context_updates=context_updates)
        return StageResult.succeeded(outputs=outputs, context_updates=context_updates)

    @staticmethod
    def _extract_action(decision: Any) -> str:
        """The Phase 120 ``AgentDecision`` dataclass exposes ``action``;
        be permissive about dict-shaped responses too."""
        if decision is None:
            return ""
        action = getattr(decision, "action", None)
        if action is not None:
            return str(action)
        if isinstance(decision, dict):
            return str(decision.get("action", ""))
        return str(decision)

    @staticmethod
    def _serialise_decision(decision: Any) -> Dict[str, Any]:
        if decision is None:
            return {}
        if isinstance(decision, dict):
            return decision
        # Dataclass / Pydantic-ish duck typing
        try:
            return {k: getattr(decision, k) for k in
                     ("action", "strategy", "confidence", "reasoning",
                      "max_retries", "source")
                     if hasattr(decision, k)}
        except Exception:
            return {"repr": repr(decision)}
