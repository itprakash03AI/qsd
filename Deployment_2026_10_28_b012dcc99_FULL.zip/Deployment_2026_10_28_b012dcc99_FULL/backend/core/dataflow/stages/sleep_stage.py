"""``SleepStage`` — wait N seconds.  Cooperatively cancellable."""
from __future__ import annotations

import time
from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_CONTROL, IDEMPOTENT_SAFE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class SleepStage(BaseStage):
    """Pauses the dataflow for ``seconds`` seconds.

    Config:
        ``seconds`` : int (required, >= 0)

    Cancellation: checks ``ctx.is_cancelled()`` every second so a stuck
    sleep doesn't block a cancel request.  Useful both for testing and
    as a delay between stages (e.g. wait 60s before retrying a sink).
    """

    NAME = "sleep"
    DISPLAY_NAME = "Pause / Sleep"
    CATEGORY = CATEGORY_CONTROL
    DESCRIPTION = "Pause for N seconds (cooperatively cancellable)."
    IDEMPOTENCY = IDEMPOTENT_SAFE
    CONFIG_SCHEMA = {
        "seconds": {"type": "integer", "minimum": 0},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        seconds = config.get("seconds")
        if seconds is None:
            errs.append("seconds is required")
        elif not isinstance(seconds, (int, float)) or seconds < 0:
            errs.append("seconds must be a non-negative number")
        return errs

    @classmethod
    def estimate_cost(cls, config=None):
        secs = 0
        try:
            secs = int(float((config or {}).get("seconds") or 0))
        except Exception:
            secs = 0
        return {"seconds": max(0, secs), "cents": 0}

    def execute(self, ctx: StageContext) -> StageResult:
        seconds = float(ctx.get_config("seconds", 0))
        ctx.log(f"sleeping {seconds}s")
        # Sleep in 1-second slices so cancel events are observed promptly.
        elapsed = 0.0
        while elapsed < seconds:
            if ctx.is_cancelled():
                return StageResult.failed(error="cancelled during sleep")
            slice_s = min(1.0, seconds - elapsed)
            time.sleep(slice_s)
            elapsed += slice_s
        return StageResult.succeeded(outputs={"slept_seconds": seconds})
