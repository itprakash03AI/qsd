"""SAP MEBAL DAG decomposition (Phase 132.20).

Two stages that, paired with the generic ``for_each`` stage, deliver
DAG-level visibility for SAP MEBAL downloads.  Each group becomes its
own visible iteration on the Ops Grid + Gantt — instead of all groups
hiding inside the monolithic ``sap_odata_download`` stage's
ThreadPoolExecutor.

Pipeline shape:

    sap_fetch_groups          (1 stage)
        ↓ outputs: {"groups": [{"id": 0, "codes": [...]}, ...]}
    for_each(child=sap_download_one_group)   (N parallel iterations)
        ↓ outputs: per-iteration row_count + file_path
    consolidate_files → compress → ctl → deliver → notify

Both stages reuse ``ETL/steps/sap_odata_base.py`` for the wire-level
work (auth, pagination, CSV streaming) — the new bridge code is just
config plumbing.  Credentials come from a QueryStudio Connection
(encrypted), never inline.  This follows the same pattern as
``SapOdataDownloadStage`` so existing SAP infra ports cleanly.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_SOURCE, CATEGORY_PIPELINE, IDEMPOTENT_SAFE,
    IDEMPOTENT_OVERWRITE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register
from core.dataflow.runnability import Runnability, probe_etl_targets

logger = logging.getLogger(__name__)


# Shared CONNECTION_FIELDS mapping so both stages resolve creds via a
# Connection row — same shape as SapOdataDownloadStage so admins can
# re-use one SAP connection across all three SAP stages.
_SAP_CONNECTION_FIELDS = {
    "sap_connection_id": {
        "base_url": "sap_base_url",
        "username": "sap_username",
        "password": "sap_password",
    },
}


def _get_db_manager(ctx: StageContext):
    """Resolve the DatabaseManager — prefer ctx, fall back to the
    running dataflow engine singleton."""
    db_manager = ctx.db_manager
    if db_manager is None:
        try:
            from core.dataflow.engine import get_engine
            e = get_engine()
            db_manager = e.db if e is not None else None
        except Exception:
            db_manager = None
    return db_manager


def _resolve_sap_creds(ctx: StageContext) -> Dict[str, Any]:
    """Build the full SAP runtime config the stage needs.

    Resolution order (later wins so inline-on-stage can override DB):

        1. SapTaskConfig row (when ``sap_task_id`` is set) — gives
           creds + odata_service_path + entity_set + filter_style +
           company_code_endpoint + period_mode + num_groups +
           output_dir + group_history_path + column_mapping_path +
           page_size + timeout_seconds + retries + rate limit.
        2. Connection row (when ``sap_connection_id`` is set) —
           creds only.  Use when you need the creds but want to
           configure everything else inline on the stage.
        3. Inline stage config (``ctx.get_config(...)``) — any
           non-empty value wins over the DB-loaded value.

    The single-row pattern (sap_task_id) is the recommended path:
    one global place to manage SAP service details, dataflows just
    reference it.  Inline fields are kept for backward compat and
    for ad-hoc overrides (e.g. backfill a different output_dir).
    """
    out: Dict[str, Any] = {}

    # ── 1. SapTaskConfig (the "global info" path) ─────────────────────
    task_id = ctx.get_config("sap_task_id")
    if task_id:
        try:
            from core.sap_task_loader import load_task_config
        except Exception as exc:
            raise RuntimeError(
                f"sap_task_id resolution requires core.sap_task_loader: {exc}"
            )
        db_manager = _get_db_manager(ctx)
        if db_manager is None:
            raise RuntimeError("db_manager unavailable to resolve sap_task_id")
        try:
            task_cfg = load_task_config(db_manager, int(task_id))
        except Exception as exc:
            raise RuntimeError(
                f"sap_task_id {task_id} resolution failed: {exc}"
            )
        # Project the keys we use on the stages.
        for k in (
            "sap_base_url", "sap_username", "sap_password",
            "odata_service_path", "company_code_endpoint",
            "company_code_field", "entity_set", "filter_style",
            "period_mode", "p_gjahr", "p_poper",
            "num_groups", "output_dir", "group_history_path",
            "column_mapping_path",
        ):
            v = task_cfg.get(k)
            if v not in (None, ""):
                out[k] = v
        # Name-mapped fields (SapTaskConfig name → dataflow stage name)
        if task_cfg.get("page_size") not in (None, ""):
            out["top_per_page"] = task_cfg["page_size"]
        if task_cfg.get("timeout_seconds") not in (None, ""):
            out["request_timeout_seconds"] = task_cfg["timeout_seconds"]
        for k in ("page_size", "rate_limit_rps", "max_retries", "retry_backoff"):
            v = task_cfg.get(k)
            if v not in (None, ""):
                out[k] = v

    # ── 2. Connection (legacy creds-only path) ────────────────────────
    conn_id = ctx.get_config("sap_connection_id")
    if conn_id and not task_id:
        try:
            from core.db.models import Connection
            from core.crypto import decrypt_config
        except Exception as exc:
            raise RuntimeError(
                f"SAP creds resolution requires core.db + crypto: {exc}"
            )
        db_manager = _get_db_manager(ctx)
        if db_manager is None:
            raise RuntimeError("db_manager unavailable to resolve sap_connection_id")
        with db_manager.get_session(read_only=True) as session:
            row = session.query(Connection).filter(
                Connection.id == int(conn_id)).first()
            if row is None:
                raise RuntimeError(f"sap_connection_id {conn_id} not found")
            cfg = decrypt_config(dict(row.config or {}))
        if cfg.get("base_url"):
            out["sap_base_url"] = cfg["base_url"]
        if cfg.get("username"):
            out["sap_username"] = cfg["username"]
        if cfg.get("password"):
            out["sap_password"] = cfg["password"]

    # ── 3. Inline overrides (each non-empty stage value wins) ─────────
    # NOTE: credentials are intentionally NOT in this list — they only
    # come from a Connection row (encrypted).  Same security rule as
    # the Starburst/Trino/Snowflake stages.
    for k in (
        "odata_service_path", "company_code_endpoint",
        "company_code_field", "entity_set", "filter_style",
        "page_size", "rate_limit_rps", "max_retries", "retry_backoff",
        "request_timeout_seconds", "top_per_page",
        "output_dir", "group_history_path", "column_mapping_path",
    ):
        v = ctx.get_config(k)
        if v not in (None, ""):
            out[k] = v
    return out


def _ensure_sap_base():
    """Lazy-import the ETL framework.  Mirrors the etl_bridge pattern.

    2026-08-19 — THE MODULE PATH WAS WRONG AND HAD ALWAYS BEEN WRONG.  This
    imported ``steps.sap_odata_base``, but the module lives at
    ``ETL/steps/sap/sap_odata_base.py`` — every one of the ~15 modules inside
    the ETL tree spells it ``steps.sap.sap_odata_base``.  So the try arm
    raised ModuleNotFoundError, the except arm re-raised the identical wrong
    import, and the SAP decomposed stages could never construct.  The old
    path bootstrap probed for the same wrong file (``steps/sap_odata_base.py``)
    so it never matched either and the failure looked like "ETL framework not
    installed" rather than "wrong module path".

    Two layers of fallback, both spelled wrongly, is exactly how a defect
    hides: the second attempt reads like a recovery and was a copy.
    """
    try:
        from steps.sap.sap_odata_base import SapOdataBase  # type: ignore
        from steps.sap.sap_odata_download import SapOdataDownload  # type: ignore
        return SapOdataBase, SapOdataDownload
    except ImportError:
        # Path bootstrap goes through core.etl_root, the one chokepoint.  The
        # list this replaced was (c:/DEV/outputs/ETL, /app/ETL, ./ETL): one
        # dev box's absolute path, the container path, and a CWD-relative
        # guess — with NO candidate derived from this checkout.
        from core.etl_root import ensure_etl_on_path
        ensure_etl_on_path("sap/sap_odata_base.py")
        from steps.sap.sap_odata_base import SapOdataBase  # type: ignore
        from steps.sap.sap_odata_download import SapOdataDownload  # type: ignore
        return SapOdataBase, SapOdataDownload


#: The marker ``_ensure_sap_base`` insists on — the probe below looks for
#: the tree the same way, so "installed" cannot mean two things.
_SAP_MARKER_FILE = "sap/sap_odata_base.py"

#: What ``_ensure_sap_base`` imports.  Declared once, probed by both stages.
_SAP_TARGETS = {
    "base":     ("steps.sap.sap_odata_base",     "SapOdataBase"),
    "download": ("steps.sap.sap_odata_download", "SapOdataDownload"),
}


def _sap_runnability() -> Runnability:
    """2026-09-15 — can the two SAP decomposed stages run in THIS image?

    Same question ``_ensure_sap_base`` answers at execute, asked without
    importing: the ETL tree is found by ``core.etl_root`` (with the SAP
    marker), and both target modules resolve and declare their class.
    No shipped image carries ``ETL/`` so on a stock pod this is
    ``runnable=False`` with a reason that names ``QS_ETL_ROOT``.
    """
    return probe_etl_targets(_SAP_TARGETS, required_file=_SAP_MARKER_FILE)


# ── Stage 1: fetch + bin-pack company codes ───────────────────────────────


@register
class SapFetchCompanyGroupsStage(BaseStage):
    """Fetch all SAP company codes, bin-pack them into N groups, output
    the groups list for a downstream ``for_each`` fan-out.

    Outputs:
        ``groups`` : ``[{"id": 0, "codes": [...], "size": N}, ...]``
        ``total_codes`` : int (sum of all group sizes)
        ``p_gjahr`` / ``p_poper`` : derived fiscal period (so downstream
                                       children share the same period)
    """

    NAME = "sap_fetch_company_groups"
    DISPLAY_NAME = "SAP — Fetch & Group Company Codes"
    CATEGORY = CATEGORY_SOURCE
    IDEMPOTENCY = IDEMPOTENT_SAFE
    DESCRIPTION = ("Fetch SAP company codes + bin-pack them into N groups "
                    "for downstream fan-out via for_each.  Read-only — "
                    "safe to rerun.")
    COST_SECONDS = 10
    CONFIG_SCHEMA = {
        "sap_task_id":          {"type": "integer", "lookup": "sap_tasks",
                                    "description": "(RECOMMENDED) SapTaskConfig row id. "
                                                    "Brings creds + service path + entity_set + "
                                                    "filter_style + company_code_endpoint + "
                                                    "period_mode + num_groups + output_dir + "
                                                    "history path.  Inline fields below override."},
        "sap_connection_id":    {"type": "integer", "lookup": "connections",
                                    "description": "(Alt to sap_task_id) Connection holding "
                                                    "SAP base_url/user/password only.  "
                                                    "Credentials NEVER live inline — same rule "
                                                    "as Starburst/Trino/Snowflake stages."},
        "company_code_endpoint": {"type": "string",
                                    "description": "(override) OData endpoint returning the list "
                                                    "of codes — inherited from sap_task_id."},
        "num_groups":            {"type": "integer", "minimum": 1,
                                    "description": "(override) Bin-pack count — inherited from "
                                                    "sap_task_id."},
        "group_history_path":    {"type": "string",
                                    "description": "(override) Smart bin-pack history JSON — "
                                                    "inherited from sap_task_id."},
        "period_mode":           {"type": "string",
                                    "enum": ["current", "prev_eom",
                                              "current_year_prev_poper", "explicit"],
                                    "description": "(override) current / prev_eom / "
                                                    "current_year_prev_poper (recommended for "
                                                    "month-end balance) / explicit.  Inherited "
                                                    "from sap_task_id."},
        "p_gjahr":               {"type": "string",
                                    "description": "Only for period_mode=explicit."},
        "p_poper":               {"type": "string",
                                    "description": "Only for period_mode=explicit."},
        "request_timeout_seconds": {"type": "integer"},
    }

    @classmethod
    def runnability(cls) -> Runnability:
        return _sap_runnability()

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        # 2026-09-15 — the runnability gate first: refused at save /
        # dry-run when this image cannot import the SAP ETL steps.
        errs: List[str] = cls.runnability().problems(cls.NAME)
        # Reject inline credentials — same rule as Starburst/Trino/Snowflake
        # stages.  Creds MUST come from a Connection row (encrypted) via
        # sap_task_id or sap_connection_id.
        for k in ("sap_base_url", "sap_username", "sap_password"):
            if (config.get(k) or "").strip():
                errs.append(
                    f"inline {k!r} is not allowed — store creds in a "
                    f"Connection and reference via sap_task_id (or "
                    f"sap_connection_id)"
                )
        has_task    = bool(config.get("sap_task_id"))
        has_endpoint = bool((config.get("company_code_endpoint") or "").strip())
        has_creds = bool(config.get("sap_connection_id"))
        if not has_task:
            if not has_endpoint:
                errs.append(
                    "set sap_task_id (recommended) OR company_code_endpoint inline"
                )
            if not has_creds:
                errs.append(
                    "set sap_task_id (recommended) OR sap_connection_id"
                )
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        try:
            SapOdataBase, _ = _ensure_sap_base()
            from managers.company_code_grouper import CompanyCodeGrouper  # type: ignore
        except Exception as exc:
            return StageResult.failed(error=f"SAP framework not importable: {exc}")
        try:
            cfg = _resolve_sap_creds(ctx)
        except Exception as exc:
            return StageResult.failed(error=f"SAP cred resolution failed: {exc}")

        # Non-cred fields: prefer inline stage config (already overlaid into
        # cfg by _resolve_sap_creds), fall back to task-config-derived value,
        # final fallback to a safe default for period_mode.
        inline_endpoint = ctx.get_config("company_code_endpoint")
        if inline_endpoint not in (None, ""):
            cfg["company_code_endpoint"] = inline_endpoint
        # period_mode: stage-config inline wins, else task-derived, else 'current'
        period_mode = (
            ctx.get_config("period_mode")
            or cfg.get("period_mode")
            or "current"
        )
        if ctx.get_config("p_gjahr"):
            cfg["p_gjahr"] = ctx.get_config("p_gjahr")
        if ctx.get_config("p_poper"):
            cfg["p_poper"] = ctx.get_config("p_poper")

        if not (cfg.get("company_code_endpoint") or "").strip():
            return StageResult.failed(
                error="company_code_endpoint not set (neither inline nor via sap_task_id)"
            )

        # Build a session via the existing helper.  We instantiate a
        # SapOdataBase subclass purely to reuse its session + fetch logic.
        class _Probe(SapOdataBase):
            LOG_PREFIX = "sap_fetch_groups"
        probe = _Probe(starburst_clients={}, oracle_data_manager=None,
                       logger=logger, config={})
        session = probe._build_session(cfg)

        try:
            company_codes = probe._fetch_company_codes(session, cfg)
        except Exception as exc:
            return StageResult.failed(error=f"company code fetch failed: {exc}")
        finally:
            try:
                session.close()
            except Exception:
                pass

        if not company_codes:
            return StageResult.succeeded(outputs={
                "groups": [], "total_codes": 0,
                "p_gjahr": cfg.get("p_gjahr"), "p_poper": cfg.get("p_poper"),
            })

        # Bin-pack count: inline > task-config > default 5.
        num_groups = int(
            ctx.get_config("num_groups") or cfg.get("num_groups") or 5
        )
        history_path = (
            ctx.get_config("group_history_path")
            or cfg.get("group_history_path")
            or "/usr/local/spark/nfs/bcp/batch/sap_mebal/group_history.json"
        )
        try:
            grouper = CompanyCodeGrouper(history_path, num_groups)
            packed = grouper.group_codes(company_codes)
        except Exception as exc:
            ctx.log(f"bin-pack failed ({exc}); falling back to round-robin")
            packed = [[] for _ in range(num_groups)]
            for i, c in enumerate(company_codes):
                packed[i % num_groups].append(c)

        groups = [
            {"id": idx, "codes": list(g), "size": len(g)}
            for idx, g in enumerate(packed) if g
        ]
        # Phase 132.24 — honour period_mode='explicit'.
        # Phase 132.31 — base class now also handles
        # 'prev_eom' + 'current_year_prev_poper'; we still handle
        # 'explicit' here since it reads from config not from the clock.
        if period_mode == "explicit":
            p_gjahr = (ctx.get_config("p_gjahr") or "").strip()
            p_poper = (ctx.get_config("p_poper") or "").strip()
            if not p_gjahr or not p_poper:
                return StageResult.failed(
                    error="period_mode='explicit' requires both p_gjahr and p_poper"
                )
        else:
            p_gjahr, p_poper = probe._derive_fiscal_period(period_mode)
        ctx.log(f"fetched {len(company_codes)} codes -> {len(groups)} group(s); "
                f"period={p_gjahr}/{p_poper}")
        # Phase 132.24 — also push p_gjahr/p_poper into run_context via
        # context_updates so the downstream for_each can interpolate
        # {p_gjahr} / {p_poper} in its child_config without each item
        # having to carry them.
        return StageResult.succeeded(
            outputs={
                "groups":       groups,
                "total_codes":  len(company_codes),
                "p_gjahr":      p_gjahr,
                "p_poper":      p_poper,
            },
            context_updates={
                "p_gjahr": p_gjahr,
                "p_poper": p_poper,
            },
        )


# ── Stage 2: download ONE group's MEBAL rows ──────────────────────────────


@register
class SapDownloadOneGroupStage(BaseStage):
    """Download MEBAL rows for a single company-code group.  Designed
    to be the ``child_stage_type`` of a ``for_each`` fan-out fed by
    ``sap_fetch_company_groups``.

    Reads the per-item dict produced by sap_fetch_company_groups:
        ``{"id": int, "codes": [str], "size": int}``
    via run_context overrides — the for_each stage interpolates
    ``{id}`` / ``{codes}`` into this stage's config.

    Outputs ``file_path`` + ``row_count`` so consolidate / row-count
    checks downstream can pick them up.
    """

    NAME = "sap_download_one_group"
    DISPLAY_NAME = "SAP — Download One Group"
    CATEGORY = CATEGORY_PIPELINE
    IDEMPOTENCY = IDEMPOTENT_OVERWRITE
    DESCRIPTION = ("Download MEBAL rows for a single company-code group.  "
                    "Use under for_each, fed by sap_fetch_company_groups.")
    COST_SECONDS = 60
    CONFIG_SCHEMA = {
        "sap_task_id":          {"type": "integer", "lookup": "sap_tasks",
                                   "description": "(RECOMMENDED) SapTaskConfig row id. "
                                                   "Brings creds + service path + entity_set + "
                                                   "filter_style + company_code_field + "
                                                   "output_dir + page size + retries.  "
                                                   "Inline fields below override."},
        "sap_connection_id":    {"type": "integer", "lookup": "connections",
                                   "description": "(Alt) Connection holding creds only.  "
                                                   "Credentials NEVER live inline — same rule "
                                                   "as Starburst/Trino/Snowflake stages."},
        "odata_service_path":   {"type": "string",
                                   "description": "(override) Inherited from sap_task_id."},
        # Phase 132.31 — OData entity set + filter style (must match
        # what the SAP service exposes).
        "entity_set":           {"type": "string",
                                   "description": "(override) OData function-import name "
                                                   "(default: MEBALParameters).  "
                                                   "Inherited from sap_task_id."},
        "filter_style":         {"type": "string", "enum": ["eq", "range"],
                                   "description": "(override) eq = OR-of-Companycode-eq "
                                                   "(no cross-group duplicates).  range = "
                                                   "Companycode ge first AND le last.  "
                                                   "Inherited from sap_task_id."},
        "company_code_field":   {"type": "string",
                                   "description": "(override) SAP field name "
                                                   "(default: Companycode).  Inherited "
                                                   "from sap_task_id."},
        "output_dir":           {"type": "string",
                                   "description": "(override) Inherited from sap_task_id."},
        # Per-iteration inputs (typically set by for_each interpolation):
        "group_id":             {"type": "integer", "description": "Group index."},
        "group_codes":          {"type": "array",   "description": "List of company codes."},
        "p_gjahr":              {"type": "string"},
        "p_poper":              {"type": "string"},
        "request_timeout_seconds": {"type": "integer"},
        "top_per_page":         {"type": "integer"},
    }

    @classmethod
    def runnability(cls) -> Runnability:
        return _sap_runnability()

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        # 2026-09-15 — the runnability gate first (see SapFetchCompanyGroupsStage).
        errs: List[str] = cls.runnability().problems(cls.NAME)
        # Reject inline credentials — same rule as Starburst/Trino/Snowflake.
        for k in ("sap_base_url", "sap_username", "sap_password"):
            if (config.get(k) or "").strip():
                errs.append(
                    f"inline {k!r} is not allowed — store creds in a "
                    f"Connection and reference via sap_task_id (or "
                    f"sap_connection_id)"
                )
        has_task = bool(config.get("sap_task_id"))
        if not has_task:
            if not (config.get("odata_service_path") or "").strip():
                errs.append(
                    "set sap_task_id (recommended) OR odata_service_path inline"
                )
            if not (config.get("output_dir") or "").strip():
                errs.append(
                    "set sap_task_id (recommended) OR output_dir inline"
                )
            if not config.get("sap_connection_id"):
                errs.append(
                    "set sap_task_id (recommended) OR sap_connection_id"
                )
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        try:
            SapOdataBase, _ = _ensure_sap_base()
        except Exception as exc:
            return StageResult.failed(error=f"SAP framework not importable: {exc}")
        try:
            cfg = _resolve_sap_creds(ctx)
        except Exception as exc:
            return StageResult.failed(error=f"SAP cred resolution failed: {exc}")
        # odata_service_path: inline wins, else task-derived (already in cfg).
        inline_svc = ctx.get_config("odata_service_path")
        if inline_svc not in (None, ""):
            cfg["odata_service_path"] = inline_svc
        if not (cfg.get("odata_service_path") or "").strip():
            return StageResult.failed(
                error="odata_service_path not set (neither inline nor via sap_task_id)"
            )

        group_id = ctx.get_config("group_id")
        group_codes = ctx.get_config("group_codes") or []
        p_gjahr = ctx.get_config("p_gjahr") or ""
        p_poper = ctx.get_config("p_poper") or ""
        # output_dir: inline > task-derived > legacy default.
        output_dir = (
            ctx.get_config("output_dir")
            or cfg.get("output_dir")
            or "/tmp/sap_output"
        )

        if not group_codes:
            return StageResult.failed(error="group_codes is empty — nothing to download")
        if not p_gjahr or not p_poper:
            return StageResult.failed(error="p_gjahr and p_poper must be set "
                                              "(typically interpolated from "
                                              "sap_fetch_company_groups outputs)")

        os.makedirs(output_dir, exist_ok=True)

        class _Probe(SapOdataBase):
            LOG_PREFIX = f"sap_dl_group_{group_id}"
        probe = _Probe(starburst_clients={}, oracle_data_manager=None,
                       logger=logger, config={})
        session = probe._build_session(cfg)
        try:
            result = probe._download_group(
                session=session, config=cfg, group=list(group_codes),
                group_idx=int(group_id) if group_id is not None else 0,
                p_gjahr=p_gjahr, p_poper=p_poper, output_dir=output_dir,
            )
        except Exception as exc:
            return StageResult.failed(error=f"group {group_id} download failed: {exc}")
        finally:
            try:
                session.close()
            except Exception:
                pass

        ctx.log(f"group {result.get('group_idx')}: "
                f"{result.get('row_count')} rows → {result.get('file_path')}")
        return StageResult.succeeded(outputs={
            "group_id":   result.get("group_idx"),
            "row_count":  result.get("row_count"),
            "file_path":  result.get("file_path"),
            "codes":      list(group_codes),
        })
