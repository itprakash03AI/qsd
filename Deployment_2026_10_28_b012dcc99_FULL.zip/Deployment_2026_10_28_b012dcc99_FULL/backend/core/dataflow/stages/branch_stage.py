"""``BranchStage`` — control-flow stage that jumps to a different alias
based on a context-key check.

This is the simplest possible branching primitive — full expression
evaluation is intentionally out of scope for Phase 0.  The admin says
"compare context.key == value → go to alias X, else alias Y".  Anything
more sophisticated belongs in a dedicated rule-evaluation stage or in
an AgentDecision stage.
"""
from __future__ import annotations

from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_CONTROL, IDEMPOTENT_SAFE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class BranchStage(BaseStage):
    """Compare a context key to a value; jump to one of two aliases.

    Config:
        ``key``       : str — context key to read
        ``equals``    : Any — value to compare against
        ``then_alias`` : str — branch target when equal
        ``else_alias`` : str — branch target when not equal (optional;
                                  if omitted, the dataflow continues with
                                  the natural next stage)
    """

    NAME = "branch"
    DISPLAY_NAME = "Branch (If / Else)"
    CATEGORY = CATEGORY_CONTROL
    IS_CONTROL_FLOW = True
    DESCRIPTION = "Branch to a different stage based on a context key."
    IDEMPOTENCY = IDEMPOTENT_SAFE
    CONFIG_SCHEMA = {
        "key": {"type": "string"},
        "equals": {},
        "then_alias": {"type": "string"},
        "else_alias": {"type": "string"},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        for required in ("key", "then_alias"):
            if not config.get(required):
                errs.append(f"{required} is required")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        key = ctx.get_config("key")
        expected = ctx.get_config("equals")
        actual = ctx.get_param(key)
        equal = actual == expected
        target = ctx.get_config("then_alias") if equal else ctx.get_config("else_alias")
        ctx.log(
            f"branch: context[{key!r}]={actual!r} expected={expected!r} "
            f"equal={equal} → {target or 'fall-through'}"
        )
        outputs = {"key": key, "actual": actual, "expected": expected,
                   "equal": equal, "target": target}
        if target:
            return StageResult.branched(branch_to=target, outputs=outputs)
        return StageResult.succeeded(outputs=outputs)
