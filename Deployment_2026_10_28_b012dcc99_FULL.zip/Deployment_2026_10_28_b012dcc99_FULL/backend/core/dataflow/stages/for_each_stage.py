"""``ForEachStage`` — generic DAG-level fan-out (Phase 132.20).

Runs ``child_stage_type`` once per item in a list, in parallel (bounded
concurrency).  This is the Airflow ``.expand()`` / NiFi ``Process Group``
equivalent — when intra-stage parallelism (a single stage's internal
ThreadPoolExecutor) doesn't give enough visibility / control, fan out
to DAG-level children instead.

Per-item visibility:
* Every iteration emits a ``workflow_iteration_started`` /
  ``_completed`` broadcast so the Ops view shows live progress.
* Per-item status, outputs, and error land in the stage's ``outputs``
  dict (``results: [{index, item, status, outputs, error, duration_seconds}]``)
  so post-run inspection knows exactly which items failed.
* Logs are interleaved with item prefixes so re-running one item is easy.

Failure semantics (config-driven):
* ``fail_fast=true``  — stop scheduling new children on the first
  failure; pending items are marked ``skipped``.  In-flight items are
  allowed to finish (cooperative).
* ``fail_fast=false`` (default) — every item runs; stage finishes as
  ``failed`` if any item failed (partial outputs still surfaced).

Items source — exactly one of:
* ``items``          : static list literal
* ``items_from``     : ``"stage_alias.outputs_key"`` (read from a
                        predecessor's structured outputs)
* ``items_context_key``: read a list from ``run_context[key]``

Child config interpolation:
* The child's ``config`` is a Python format-string template.  At
  execution time each item is exposed as ``{item}`` (whole value),
  and if the item is a dict, each top-level key is also injected
  (so ``{codes}`` works for ``item={"codes": [...], "id": 0}``).

Idempotency: ``configured`` — depends on the child stage's idempotency.
The dispatcher's ``rerun_stage`` re-runs the whole fan-out as a unit;
fine-grained per-item rerun is left to a future sub-dataflow variant.
"""
from __future__ import annotations

import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor, Future, as_completed
from copy import deepcopy
from typing import Any, Dict, List, Optional

from core.dataflow.base import (
    BaseStage, CATEGORY_CONTROL, IDEMPOTENT_CONFIGURED,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register, get_default_registry

logger = logging.getLogger(__name__)


@register
class ForEachStage(BaseStage):
    NAME = "for_each"
    DISPLAY_NAME = "For Each (parallel fan-out)"
    CATEGORY = CATEGORY_CONTROL
    IDEMPOTENCY = IDEMPOTENT_CONFIGURED
    DESCRIPTION = ("Run a child stage type N times in parallel, one per item "
                    "in a list.  Items can come from a static config, a "
                    "predecessor's outputs, or run_context.")
    COST_SECONDS = 30  # rough — actual cost = items * child_cost / parallelism
    CONFIG_SCHEMA = {
        # ── Items source (pick exactly one) ──
        "items":              {"type": "array",
                                 "description": "Static list of items (literal)."},
        "items_from":          {"type": "string",
                                 "description": "'stage_alias.outputs_key' to read items from "
                                                  "an upstream stage's outputs.  Example: "
                                                  "'fetch_groups.groups'."},
        "items_context_key":   {"type": "string",
                                 "description": "Key in run_context whose value is the items list."},
        # ── Child stage ──
        "child_stage_type":    {"type": "string",
                                 "description": "Stage type to instantiate per item (must be "
                                                  "registered in the stage catalogue)."},
        "child_config":         {"type": "object",
                                 "description": "Config template for each child.  Strings are "
                                                  "format-interpolated with {item} (full item) and, "
                                                  "if item is a dict, each top-level key (e.g. {codes})."},
        # ── Concurrency / failure ──
        "max_parallel":        {"type": "integer", "minimum": 1,
                                 "description": "Max concurrent children (default 5)."},
        "fail_fast":           {"type": "boolean",
                                 "description": "Stop scheduling new children on first failure "
                                                  "(default false — drain queue, report partial)."},
        "item_timeout_seconds": {"type": "integer",
                                 "description": "Per-item timeout (default unlimited)."},
        "item_var":            {"type": "string",
                                 "description": "Variable name for the item in interpolation "
                                                  "(default 'item')."},
    }

    # ── Validation ──────────────────────────────────────────────────────

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        # Exactly one items source
        sources = [bool(config.get(k))
                   for k in ("items", "items_from", "items_context_key")]
        if sum(sources) == 0:
            errs.append("must set exactly one of: items, items_from, items_context_key")
        elif sum(sources) > 1:
            errs.append("set only one of: items, items_from, items_context_key")
        if not (config.get("child_stage_type") or "").strip():
            errs.append("child_stage_type is required")
        mp = config.get("max_parallel")
        if mp is not None and (not isinstance(mp, int) or mp < 1):
            errs.append("max_parallel must be a positive integer")
        return errs

    # ── Items resolution ────────────────────────────────────────────────

    def _resolve_items(self, ctx: StageContext) -> List[Any]:
        # Static literal wins (most explicit)
        items = ctx.get_config("items")
        if items is not None:
            return list(items)
        # From predecessor outputs
        ifrom = (ctx.get_config("items_from") or "").strip()
        if ifrom:
            if "." not in ifrom:
                raise ValueError(f"items_from must be 'alias.key' (got {ifrom!r})")
            alias, _, key = ifrom.partition(".")
            outs = ctx.prev_outputs.get(alias)
            if not isinstance(outs, dict):
                raise ValueError(f"predecessor {alias!r} has no outputs dict")
            val = outs.get(key)
            if val is None:
                raise ValueError(f"predecessor {alias}.{key} is null/absent")
            if not isinstance(val, list):
                raise ValueError(f"{alias}.{key} must be a list (got {type(val).__name__})")
            return list(val)
        # From run_context
        ckey = (ctx.get_config("items_context_key") or "").strip()
        if ckey:
            val = ctx.run_context.get(ckey)
            if val is None:
                raise ValueError(f"run_context key {ckey!r} is absent")
            if not isinstance(val, list):
                raise ValueError(f"run_context[{ckey!r}] must be a list")
            return list(val)
        raise ValueError("no items source resolved")

    # ── Child config interpolation ──────────────────────────────────────

    def _interpolate(
        self, template: Any, item: Any, item_var: str,
        run_context: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Recursively walk a config template and format any string values
        with the item's fields.

        Resolution precedence (later wins):
        1. run_context (fallback — exposes the DAG-level params like
           {p_gjahr} / {business_date} from default_context + upstream
           context_updates)
        2. item's top-level dict keys (e.g. {id}, {codes} on each group)
        3. {item} / {item.field} via SimpleNamespace wrap for ergonomics

        Any KeyError / IndexError / ValueError / AttributeError leaves
        the template string verbatim so a typo doesn't crash the run.
        """
        from types import SimpleNamespace
        ctx_kwargs: Dict[str, Any] = {}
        # 1. run_context first (lowest priority)
        if run_context:
            for k, v in run_context.items():
                if not str(k).startswith("_"):
                    ctx_kwargs[k] = v
        # 2. item's top-level keys (override run_context)
        if isinstance(item, dict):
            for k, v in item.items():
                if not str(k).startswith("_"):
                    ctx_kwargs[k] = v
            item_proxy: Any = SimpleNamespace(**{
                str(k): v for k, v in item.items() if not str(k).startswith("_")
            })
        else:
            item_proxy = item
        # 3. item_var for {item} / {item.field}
        ctx_kwargs[item_var] = item_proxy

        def _walk(v: Any) -> Any:
            if isinstance(v, str):
                try:
                    return v.format(**ctx_kwargs)
                except (KeyError, IndexError, ValueError, AttributeError):
                    return v   # leave malformed templates verbatim
            if isinstance(v, dict):
                return {k: _walk(val) for k, val in v.items()}
            if isinstance(v, list):
                return [_walk(x) for x in v]
            return v

        return _walk(deepcopy(template) if template is not None else {})

    # ── Execute ─────────────────────────────────────────────────────────

    def execute(self, ctx: StageContext) -> StageResult:
        try:
            items = self._resolve_items(ctx)
        except Exception as exc:
            return StageResult.failed(error=f"items resolution failed: {exc}")

        if not items:
            ctx.log("for_each: items list is empty — no-op")
            return StageResult.succeeded(outputs={
                "item_count": 0, "succeeded": 0, "failed": 0, "results": [],
            })

        child_stage_type = (ctx.get_config("child_stage_type") or "").strip()
        if not child_stage_type:
            return StageResult.failed(error="child_stage_type is required")

        registry = get_default_registry()
        try:
            child_cls = registry.get(child_stage_type)
        except Exception as exc:
            return StageResult.failed(
                error=f"child_stage_type {child_stage_type!r} not registered: {exc}"
            )

        max_parallel = int(ctx.get_config("max_parallel") or 5)
        fail_fast = bool(ctx.get_config("fail_fast", False))
        item_timeout = ctx.get_config("item_timeout_seconds")
        item_var = (ctx.get_config("item_var") or "item").strip() or "item"
        child_template = ctx.get_config("child_config") or {}

        ctx.log(f"for_each: {len(items)} item(s), child={child_stage_type}, "
                f"max_parallel={max_parallel}, fail_fast={fail_fast}")

        results: List[Dict[str, Any]] = []
        stop_scheduling = threading.Event()

        def _run_one(idx: int, item: Any) -> Dict[str, Any]:
            if stop_scheduling.is_set():
                return {"index": idx, "item": item, "status": "skipped",
                        "outputs": {}, "error": "fail_fast: skipped"}
            if ctx.is_cancelled():
                return {"index": idx, "item": item, "status": "cancelled",
                        "outputs": {}, "error": "run cancelled"}
            try:
                child_cfg = self._interpolate(
                    child_template, item, item_var,
                    run_context=ctx.run_context,
                )
            except Exception as exc:
                return {"index": idx, "item": item, "status": "failed",
                        "outputs": {}, "error": f"child_config interpolation: {exc}"}

            # Build a child StageContext that shadows the for_each's ctx but
            # with the per-item alias + config.
            child_alias = f"{ctx.stage_alias}[{idx}]"
            child_ctx = StageContext(
                run_id=ctx.run_id,
                dataflow_id=ctx.dataflow_id,
                dataflow_name=ctx.dataflow_name,
                dataflow_version=ctx.dataflow_version,
                stage_alias=child_alias,
                stage_type=child_stage_type,
                seq=ctx.seq,   # not used downstream
                config=child_cfg,
                run_context=ctx.run_context,
                prev_outputs=ctx.prev_outputs,
                triggered_by=ctx.triggered_by,
                run_as=getattr(ctx, "run_as", None),
                attempt=1,
                worker_node=ctx.worker_node,
                cancel_event=ctx._cancel_event,
                log_emit=ctx._log_emit,
                db_manager=ctx.db_manager,
                broadcast_fn=ctx.broadcast_fn,
            )
            # Per-iteration broadcast (Ops view picks these up)
            self._broadcast(ctx, {
                "event": "workflow_iteration_started",
                "run_id": ctx.run_id, "parent_alias": ctx.stage_alias,
                "iteration": idx, "child_stage_type": child_stage_type,
            })
            t0 = time.time()
            try:
                child_inst = child_cls()
                result = child_inst.execute(child_ctx)
            except Exception as exc:
                self._broadcast(ctx, {
                    "event": "workflow_iteration_completed",
                    "run_id": ctx.run_id, "parent_alias": ctx.stage_alias,
                    "iteration": idx, "status": "failed", "error": str(exc),
                })
                return {"index": idx, "item": item, "status": "failed",
                        "outputs": {}, "error": f"{type(exc).__name__}: {exc}",
                        "duration_seconds": time.time() - t0}
            dur = time.time() - t0
            self._broadcast(ctx, {
                "event": "workflow_iteration_completed",
                "run_id": ctx.run_id, "parent_alias": ctx.stage_alias,
                "iteration": idx, "status": result.status,
                "duration_seconds": dur, "error": result.error,
            })
            if result.status == "failed" and fail_fast:
                stop_scheduling.set()
            return {"index": idx, "item": item, "status": result.status,
                    "outputs": result.outputs or {},
                    "error": result.error, "duration_seconds": dur}

        # BF-591: same hang class BF-590 fixed in dispatcher._run_inner.
        # `with TPE as pool:` calls shutdown(wait=True) on exit, which
        # blocks ANY return path on every in-flight iteration completing
        # — including the cancel path.  Manage lifetime explicitly with
        # try/finally so cancellation passes cancel_futures=True.
        # Also: cap item_timeout to a hard ceiling (1 hour) when not
        # otherwise set, so a wedged child can't pin the for-each stage
        # indefinitely.
        # BF-593: None means "use the 1h cap"; explicit 0 means "no timeout"
        # (caller opt-out).  The previous expression `item_timeout if
        # item_timeout else 3600.0` silently overrode an explicit 0
        # with the 1h cap.
        _effective_item_timeout = 3600.0 if item_timeout is None else item_timeout
        _wait_timeout = _effective_item_timeout if _effective_item_timeout > 0 else None
        pool = ThreadPoolExecutor(
            max_workers=max(1, min(max_parallel, len(items))),
            thread_name_prefix=f"foreach-{ctx.stage_alias}",
        )
        _cancelled_return = False
        try:
            futures: Dict[Future, int] = {}
            for idx, item in enumerate(items):
                futures[pool.submit(_run_one, idx, item)] = idx
            for f in as_completed(futures):
                if ctx.is_cancelled():
                    _cancelled_return = True
                    break
                try:
                    r = f.result(timeout=_wait_timeout) if _wait_timeout else f.result()
                except Exception as exc:
                    idx = futures[f]
                    r = {"index": idx, "item": items[idx], "status": "failed",
                         "outputs": {}, "error": f"future failed: {exc}"}
                results.append(r)
        finally:
            try:
                if _cancelled_return:
                    pool.shutdown(wait=False, cancel_futures=True)
                else:
                    pool.shutdown(wait=True)
            except Exception as _shutdown_exc:
                logger.debug(
                    "[for_each] pool shutdown error: %s", _shutdown_exc,
                )

        # Sort results by index for stable inspection
        results.sort(key=lambda r: r["index"])
        succeeded = sum(1 for r in results if r["status"] == "succeeded")
        failed    = sum(1 for r in results if r["status"] == "failed")
        skipped   = sum(1 for r in results if r["status"] == "skipped")
        ctx.log(f"for_each finished: {succeeded} succeeded, {failed} failed, "
                f"{skipped} skipped out of {len(items)}")

        agg = {
            "item_count":  len(items),
            "succeeded":   succeeded,
            "failed":      failed,
            "skipped":     skipped,
            "results":     results,
        }
        if failed > 0:
            return StageResult.failed(
                error=f"{failed}/{len(items)} child iteration(s) failed",
                outputs=agg,
            )
        return StageResult.succeeded(outputs=agg)

    # ── Helpers ─────────────────────────────────────────────────────────

    @staticmethod
    def _broadcast(ctx: StageContext, payload: Dict[str, Any]) -> None:
        if ctx.broadcast_fn is None:
            return
        try:
            ctx.broadcast_fn(payload)
        except Exception:
            pass   # broadcast failures are non-fatal
