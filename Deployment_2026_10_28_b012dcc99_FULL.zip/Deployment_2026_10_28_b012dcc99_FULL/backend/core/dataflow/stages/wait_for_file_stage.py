"""``WaitForFileStage`` — poll until a file exists.

Useful for waiting on an upstream system to deliver a control file
before kicking off downstream work.  Polls cooperatively so a cancel
request short-circuits the wait.

Config:
    ``path``            : str (required) — local file path
    ``poll_seconds``    : float (default 5)
    ``timeout_seconds`` : int   (default 600)
    ``min_size_bytes``  : int   (default 0) — wait until file >= this size
"""
from __future__ import annotations

import os
import time
from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_CONTROL, IDEMPOTENT_SAFE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class WaitForFileStage(BaseStage):
    NAME = "wait_for_file"
    DISPLAY_NAME = "Wait for File"
    CATEGORY = CATEGORY_CONTROL
    DESCRIPTION = "Poll until a local file appears (cooperative cancel)."
    IDEMPOTENCY = IDEMPOTENT_SAFE
    CONFIG_SCHEMA = {
        "path":             {"type": "string"},
        "poll_seconds":     {"type": "number", "minimum": 0.5},
        "timeout_seconds":  {"type": "integer", "minimum": 1},
        "min_size_bytes":   {"type": "integer", "minimum": 0},
        # Phase 132.22 — when true, the stage returns StageResult.reschedule
        # instead of blocking a worker.  Pair with timeout_seconds for the
        # total wait window; reschedule mode is for long waits (hours).
        "reschedule_mode":  {"type": "boolean",
                              "description": "Release the worker between polls and let "
                                              "the dispatcher re-pick when due (no thread tied up)."},
        "first_seen_at_key": {"type": "string",
                                "description": "When reschedule_mode, key on run_context where "
                                                "the initial check timestamp is stored across "
                                                "iterations (default: __wait_for_file_started)."},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        if not config.get("path"):
            errs.append("path is required")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        path_template = ctx.get_config("path", "")
        try:
            path = path_template.format(**ctx.run_context)
        except Exception:
            path = path_template
        poll = float(ctx.get_config("poll_seconds", 5))
        timeout = float(ctx.get_config("timeout_seconds", 600))
        min_size = int(ctx.get_config("min_size_bytes", 0))
        reschedule_mode = bool(ctx.get_config("reschedule_mode", False))

        # ── Reschedule mode ───────────────────────────────────────────
        if reschedule_mode:
            return self._execute_reschedule(ctx, path, poll, timeout, min_size)

        # ── Blocking mode (original behaviour) ────────────────────────
        deadline = time.time() + timeout
        ctx.log(f"waiting for {path} (min_size={min_size}, timeout={timeout}s)")
        while time.time() < deadline:
            if ctx.is_cancelled():
                return StageResult.failed(error="cancelled while waiting for file")
            if os.path.exists(path):
                size = os.path.getsize(path)
                if size >= min_size:
                    ctx.log(f"file ready: {path} ({size} bytes)")
                    return StageResult.succeeded(outputs={
                        "path": path, "bytes": size, "waited_seconds": int(timeout - (deadline - time.time())),
                    })
            time.sleep(min(poll, max(0.5, deadline - time.time())))
        return StageResult.failed(
            error=f"timeout after {timeout}s waiting for {path}",
            outputs={"path": path, "timed_out": True},
        )

    def _execute_reschedule(self, ctx: StageContext, path: str,
                              poll: float, timeout: float, min_size: int):
        """Single-check pass that returns immediately with one of:
        succeeded (file exists) / failed (timeout exceeded) / reschedule
        (try again after `poll` seconds).  The dispatcher re-invokes us
        on the cadence we ask for, freeing the worker between calls.
        """
        first_seen_key = ctx.get_config("first_seen_at_key",
                                          "__wait_for_file_started")
        first_seen = ctx.run_context.get(first_seen_key)
        if first_seen is None:
            first_seen = time.time()
        else:
            try:
                first_seen = float(first_seen)
            except Exception:
                first_seen = time.time()
        elapsed = time.time() - first_seen
        if os.path.exists(path):
            size = os.path.getsize(path)
            if size >= min_size:
                ctx.log(f"file ready: {path} ({size} bytes) after {int(elapsed)}s")
                return StageResult.succeeded(outputs={
                    "path": path, "bytes": size, "waited_seconds": int(elapsed),
                })
        if elapsed >= timeout:
            return StageResult.failed(
                error=f"reschedule-mode timeout after {int(elapsed)}s waiting for {path}",
                outputs={"path": path, "timed_out": True},
            )
        ctx.log(f"reschedule: file not yet ready at {path} "
                f"(elapsed={int(elapsed)}s, retry in {int(poll)}s)")
        return StageResult.reschedule(
            seconds=int(poll),
            context_updates={first_seen_key: first_seen},
            outputs={"path": path, "elapsed_seconds": int(elapsed)},
        )
