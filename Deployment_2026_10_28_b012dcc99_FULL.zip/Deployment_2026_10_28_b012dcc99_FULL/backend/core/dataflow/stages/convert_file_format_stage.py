"""``ConvertFileFormatStage`` — convert a file between CSV / Parquet / JSON.

Mirrors NiFi's ``ConvertRecord`` / Airflow's various format-conversion
operators.  Uses DuckDB's read_*/COPY combination — handles datasets
larger than memory.
"""
from __future__ import annotations

import os
from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_TRANSFORM, IDEMPOTENT_OVERWRITE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


_READERS = {
    "csv":     "read_csv_auto",
    "parquet": "read_parquet",
    "json":    "read_json_auto",
}


@register
class ConvertFileFormatStage(BaseStage):
    NAME = "convert_file_format"
    DISPLAY_NAME = "Convert File Format (CSV ↔ Parquet ↔ JSON)"
    CATEGORY = CATEGORY_TRANSFORM
    IDEMPOTENCY = IDEMPOTENT_OVERWRITE
    DESCRIPTION = ("Convert a file between csv / parquet / json formats. "
                     "DuckDB-backed — streams large datasets without loading "
                     "into Python memory.")
    CONFIG_SCHEMA = {
        "input_path":     {"type": "string",
                             "description": "Source file path.  Supports {key} interpolation."},
        "input_format":   {"type": "string", "enum": ["csv", "parquet", "json"]},
        "output_path":    {"type": "string",
                             "description": "Destination file path.  Supports {key} interpolation."},
        "output_format":  {"type": "string", "enum": ["csv", "parquet", "json"]},
        "delete_input":   {"type": "boolean",
                             "description": "Delete the input file after a successful conversion."},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        for k in ("input_path", "output_path"):
            if not (config.get(k) or "").strip():
                errs.append(f"{k} is required")
        infmt = config.get("input_format")
        outfmt = config.get("output_format")
        if infmt and infmt not in _READERS:
            errs.append(f"input_format must be csv|parquet|json, got {infmt!r}")
        if outfmt and outfmt not in _READERS:
            errs.append(f"output_format must be csv|parquet|json, got {outfmt!r}")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        def _fmt(s: str) -> str:
            try:
                return s.format(**ctx.run_context)
            except Exception:
                return s

        input_path  = _fmt(ctx.get_config("input_path") or "")
        output_path = _fmt(ctx.get_config("output_path") or "")
        input_format  = (ctx.get_config("input_format")
                         or self._guess_format(input_path))
        output_format = (ctx.get_config("output_format")
                         or self._guess_format(output_path))
        delete_input = bool(ctx.get_config("delete_input", False))

        if not os.path.exists(input_path):
            return StageResult.failed(error=f"input not found: {input_path}")

        reader = _READERS.get(input_format)
        if reader is None:
            return StageResult.failed(error=f"unsupported input_format: {input_format}")
        if output_format not in _READERS:
            return StageResult.failed(error=f"unsupported output_format: {output_format}")

        # mkdir -p the destination
        parent = os.path.dirname(output_path)
        if parent:
            os.makedirs(parent, exist_ok=True)

        try:
            import duckdb
            con = duckdb.connect(database=":memory:")
        except Exception as exc:
            return StageResult.failed(error=f"DuckDB unavailable: {exc}")

        try:
            fmt_clause = {
                "csv":     "(FORMAT 'csv', HEADER)",
                "parquet": "(FORMAT 'parquet')",
                "json":    "(FORMAT 'json')",
            }[output_format]
            escaped_in  = input_path.replace("'", "''")
            escaped_out = output_path.replace("'", "''")
            sql = (f"COPY (SELECT * FROM {reader}('{escaped_in}'))"
                   f" TO '{escaped_out}' {fmt_clause}")
            con.execute(sql)
        except Exception as exc:
            return StageResult.failed(error=f"conversion failed: {exc}")
        finally:
            try:
                con.close()
            except Exception:
                pass

        in_size  = os.path.getsize(input_path)  if os.path.exists(input_path)  else 0
        out_size = os.path.getsize(output_path) if os.path.exists(output_path) else 0
        if delete_input:
            try:
                os.remove(input_path)
            except Exception as exc:
                ctx.log(f"delete_input failed: {exc}")

        ctx.log(f"converted {input_format}→{output_format}: "
                f"{input_path} ({in_size} B) → {output_path} ({out_size} B)")
        return StageResult.succeeded(outputs={
            "input_path":   input_path,
            "output_path":  output_path,
            "input_format": input_format,
            "output_format": output_format,
            "input_bytes":  in_size,
            "output_bytes": out_size,
        })

    @staticmethod
    def _guess_format(path: str) -> str:
        ext = (path.rsplit(".", 1)[-1] or "").lower()
        if ext in ("csv", "tsv", "txt"):
            return "csv"
        if ext == "parquet":
            return "parquet"
        if ext in ("json", "jsonl", "ndjson"):
            return "json"
        return "csv"
