"""``SendEmailStage`` — real email notification, no inline SMTP creds.

The project already ships a config-driven SMTP transport at
``core.email_service.send_email`` — it reads host/port/user/password
from ``config.json`` (``email.*`` keys) or legacy ``SMTP_*`` env vars,
NOT from the DAG.  This stage is a thin wrapper around it so DAGs can
end with "send an email" without bundling credentials into stage_config.

Replaces the legacy ``send_email_notifications`` ETL bridge, which
pointed at an ETL/steps file that does not exist on disk.

Idempotency: ``unsafe`` — re-running re-sends the email.  The dispatcher
warns + requires explicit override before re-firing an unsafe stage.
"""
from __future__ import annotations

from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_NOTIFY, IDEMPOTENT_UNSAFE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class SendEmailStage(BaseStage):
    NAME = "send_email"
    DISPLAY_NAME = "Send Email"
    CATEGORY = CATEGORY_NOTIFY
    IDEMPOTENCY = IDEMPOTENT_UNSAFE
    DESCRIPTION = ("Send an email via the platform SMTP service.  Host/port/"
                    "user/password come from config.json (email.* keys) or "
                    "the SMTP_* env vars — never from the DAG.")
    COST_SECONDS = 3
    CONFIG_SCHEMA = {
        "to":       {"type": "string",
                       "description": "Recipient(s) — comma-separated.  Supports {key}."},
        "subject":  {"type": "string",
                       "description": "Subject line.  Supports {key}."},
        "body":     {"type": "string",
                       "description": "Body text.  Supports {key} interpolation against run_context."},
        "html":     {"type": "boolean",
                       "description": "Treat body as HTML (default false)."},
        "fail_on_send_error": {"type": "boolean",
                                 "description": "When true (default), an SMTP error fails "
                                                 "the stage.  When false, log + succeed."},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        if not (config.get("to") or "").strip():
            errs.append("to is required")
        if not (config.get("subject") or "").strip():
            errs.append("subject is required")
        if not (config.get("body") or "").strip():
            errs.append("body is required")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        def _fmt(s: str) -> str:
            try:
                return s.format(**ctx.run_context)
            except Exception:
                return s

        to_raw   = _fmt(ctx.get_config("to") or "")
        subject  = _fmt(ctx.get_config("subject") or "")
        body     = _fmt(ctx.get_config("body") or "")
        is_html  = bool(ctx.get_config("html", False))
        fail_on_err = bool(ctx.get_config("fail_on_send_error", True))

        recipients = [r.strip() for r in to_raw.split(",") if r.strip()]
        if not recipients:
            return StageResult.failed(error="no recipients after parsing 'to'")

        try:
            from core.email_service import send_email
        except Exception as exc:
            return StageResult.failed(error=f"email_service not importable: {exc}")

        # email_service.send_email returns bool (never raises).  It accepts
        # html_body + optional text_body.  When the user marked html=false
        # we send the body in both slots so plaintext clients get a copy.
        html_body = body if is_html else f"<pre>{body}</pre>"
        text_body = None if is_html else body
        try:
            sent = send_email(
                to_addresses=recipients,
                subject=subject,
                html_body=html_body,
                text_body=text_body,
            )
        except Exception as exc:
            msg = f"send_email crashed: {exc}"
            if fail_on_err:
                return StageResult.failed(error=msg)
            ctx.log(msg)
            return StageResult.succeeded(outputs={
                "recipients": recipients, "sent": False, "error": str(exc),
            })

        if not sent and fail_on_err:
            return StageResult.failed(
                error="send_email returned False — check email service config "
                       "(config.json email.* or SMTP_* env vars) and SMTP host reachability"
            )
        ctx.log(f"emailed {len(recipients)} recipient(s) subject={subject!r} sent={sent}")
        return StageResult.succeeded(outputs={
            "recipients": recipients,
            "sent":       bool(sent),
        })


@register
class LegacySendEmailNotificationsStage(SendEmailStage):
    """Backwards-compat alias for templates that pre-date Phase 132.20.

    Inherits the real SMTP execution path from SendEmailStage but skips
    the strict required-fields validation so existing DAG rows (which
    were created with empty ``{"task": {}}`` config) still pass
    ``create_workflow`` checks.  At runtime, if to/subject/body are
    missing, the stage returns a skipped-style success without sending
    so the DAG doesn't fail — operators see "no recipients" in the log
    and update the config.
    """
    NAME = "send_email_notifications"
    DISPLAY_NAME = "Email Notification (legacy)"
    DESCRIPTION = ("Legacy email stage — use `send_email` for new DAGs.  "
                    "Skips email when to/subject/body aren't configured "
                    "(no failure, just no-op).")

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        return []  # lenient — runtime checks instead

    def execute(self, ctx: StageContext) -> StageResult:
        # If the admin never filled in to/subject/body (legacy template
        # placeholder), succeed without sending instead of failing the run.
        if not (ctx.get_config("to") and ctx.get_config("subject")
                and ctx.get_config("body")):
            ctx.log("send_email_notifications: skipped (to/subject/body not configured)")
            return StageResult.succeeded(outputs={"sent": False, "skipped": True})
        return super().execute(ctx)
