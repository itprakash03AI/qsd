"""``HttpFetchStage`` — issue an HTTP request and capture the response.

Generic outbound HTTP for dataflows: hit a REST API, ping a webhook,
poll a status endpoint.  Uses ``httpx`` (already in the project's
dependency tree) and respects the corporate proxy config when present.

Config:
    ``url``         : str (required) — supports ``{key}`` interpolation
    ``method``      : "GET" | "POST" | "PUT" | "PATCH" | "DELETE" (default GET)
    ``headers``     : dict[str, str]
    ``params``      : dict[str, Any] — query string
    ``json_body``   : dict[str, Any] — request body (JSON)
    ``timeout_seconds`` : int (default 30)
    ``expect_status``   : int | list[int] (default 200) — fail if status doesn't match
    ``capture_body``    : bool (default true) — surface response body in outputs
"""
from __future__ import annotations

from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_SOURCE, IDEMPOTENT_CONFIGURED,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class HttpFetchStage(BaseStage):
    NAME = "http_fetch"
    DISPLAY_NAME = "HTTP Request"
    CATEGORY = CATEGORY_SOURCE
    DESCRIPTION = "Issue an HTTP request and capture the response."
    IDEMPOTENCY = IDEMPOTENT_CONFIGURED  # GET is safe; POST/PUT/DELETE depend on the endpoint
    CONFIG_SCHEMA = {
        "url":             {"type": "string"},
        "method":          {"type": "string",
                              "enum": ["GET", "POST", "PUT", "PATCH", "DELETE"]},
        "headers":         {"type": "object"},
        "params":          {"type": "object"},
        "json_body":       {"type": "object"},
        "timeout_seconds": {"type": "integer", "minimum": 1},
        "expect_status":   {"oneOf": [{"type": "integer"},
                                       {"type": "array", "items": {"type": "integer"}}]},
        "capture_body":    {"type": "boolean"},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        if not config.get("url"):
            errs.append("url is required")
        method = config.get("method", "GET").upper()
        if method not in {"GET", "POST", "PUT", "PATCH", "DELETE"}:
            errs.append(f"method {method!r} not supported")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        url_template = ctx.get_config("url", "")
        try:
            url = url_template.format(**ctx.run_context)
        except Exception:
            url = url_template
        method = ctx.get_config("method", "GET").upper()
        headers = ctx.get_config("headers", {}) or {}
        params = ctx.get_config("params", {}) or {}
        json_body = ctx.get_config("json_body")
        timeout = float(ctx.get_config("timeout_seconds", 30))
        expect = ctx.get_config("expect_status", 200)
        capture_body = bool(ctx.get_config("capture_body", True))

        try:
            client = self._open_client(timeout)
        except Exception as exc:
            return StageResult.failed(error=f"failed to create HTTP client: {exc}")

        try:
            ctx.log(f"{method} {url}")
            response = client.request(
                method=method, url=url, headers=headers,
                params=params, json=json_body,
            )
            allowed = expect if isinstance(expect, list) else [expect]
            outputs: Dict[str, Any] = {
                "status_code": response.status_code,
                "url":         str(response.url),
                "elapsed_ms":  int(response.elapsed.total_seconds() * 1000),
            }
            if capture_body:
                outputs["body"] = self._extract_body(response)
            if response.status_code not in allowed:
                return StageResult.failed(
                    error=f"unexpected status {response.status_code} (expected {allowed})",
                    outputs=outputs,
                )
            return StageResult.succeeded(outputs=outputs)
        except Exception as exc:
            return StageResult.failed(error=f"HTTP request failed: {exc}")
        finally:
            try:
                client.close()
            except Exception as _close_exc:
                ctx.log(f"http client close error: {_close_exc}")

    @staticmethod
    def _open_client(timeout: float):
        """Open an httpx client honouring the project's proxy config when present."""
        import httpx  # type: ignore
        kwargs: Dict[str, Any] = {"timeout": timeout}
        try:
            # 2026-09-01 -- ``get_httpx_proxy_kwargs`` does not exist in
            # core.proxy_utils, so this raised ImportError every time and the
            # stage always went direct, ignoring the configured proxy.
            # ``get_boto_proxies`` returns {"http": url, "https": url};
            # httpx takes a single ``proxy`` URL, and http/https are the same
            # upstream here, so either key answers.
            from core.proxy_utils import get_boto_proxies  # type: ignore
            _px = get_boto_proxies() or {}
            _px_url = _px.get("https") or _px.get("http")
            if _px_url:
                kwargs["proxy"] = _px_url
        except Exception as _proxy_exc:
            # Proxy config optional — fall back to direct connection
            # rather than failing the request.
            import logging as _hl
            _hl.getLogger(__name__).debug(
                "proxy config unavailable: %s", _proxy_exc)
        return httpx.Client(**kwargs)

    @staticmethod
    def _extract_body(response: Any) -> Any:
        """Best-effort JSON parse, fall back to text (truncated)."""
        try:
            return response.json()
        except Exception:
            text = response.text or ""
            return text[:10_000]
