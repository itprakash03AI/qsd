"""``ChecksumStage`` — compute a hash of a file or string.

BF-515 (2026-05-28): algorithm registry now imported from
``core.feed.checksum.SUPPORTED_ALGORITHMS`` so DataFlow + Feed Gen +
ControlFileWriter share ONE source of truth.  Previously DataFlow had
a smaller hardcoded set (md5/sha1/sha256/sha512) that rejected CRC32
even though feed_engine + ctl_writer accepted it — admins building a
DataFlow template to mirror a Feed Gen pipeline (BF-493) hit
"algorithm 'crc32' not in [...]" with no actionable hint.  Also picks
up alias-resolve (``MD-5`` → ``md5``) for free.
"""
from __future__ import annotations

import os
from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_QUALITY, IDEMPOTENT_SAFE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register
from core.feed.checksum import (
    SUPPORTED_ALGORITHMS,
    UnknownChecksumAlgorithm,
    compute_file_checksum,
    compute_bytes_checksum,
    normalise_algorithm,
)


_ALGORITHMS = set(SUPPORTED_ALGORITHMS)


@register
class ChecksumStage(BaseStage):
    NAME = "checksum"
    DISPLAY_NAME = "Compute Checksum"
    CATEGORY = CATEGORY_QUALITY
    DESCRIPTION = "Compute a checksum of a file or string."
    IDEMPOTENCY = IDEMPOTENT_SAFE
    CONFIG_SCHEMA = {
        "path":      {"type": "string"},
        "content":   {"type": "string"},
        "algorithm": {"type": "string", "enum": sorted(_ALGORITHMS)},
        "expected":  {"type": "string"},   # if set, fail unless checksum matches
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        if not config.get("path") and config.get("content") is None:
            errs.append("either path or content is required")
        algo_raw = config.get("algorithm", "sha256")
        try:
            normalise_algorithm(algo_raw)  # raises on unknown; accepts aliases
        except UnknownChecksumAlgorithm as exc:
            errs.append(str(exc))
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        algo_raw = ctx.get_config("algorithm", "sha256")
        path = ctx.get_config("path")
        content = ctx.get_config("content")
        expected = ctx.get_config("expected")

        try:
            algo = normalise_algorithm(algo_raw)
        except UnknownChecksumAlgorithm as exc:
            return StageResult.failed(error=str(exc))

        try:
            if path:
                try:
                    path = path.format(**ctx.run_context)
                except Exception as _tpl_exc:
                    # Templating failure is non-fatal — use raw path.
                    ctx.log(f"path templating skipped: {_tpl_exc}")
                digest = compute_file_checksum(path, algo)
                size = os.path.getsize(path)
                source = {"path": path, "bytes": size}
            else:
                if content == "from_input":
                    src = ctx.get_config("input_source", {}) or {}
                    alias = src.get("alias")
                    key = src.get("key", "content")
                    if not alias:
                        return StageResult.failed(error="input_source.alias required")
                    content = ctx.get_input(alias, key)
                    if content is None:
                        return StageResult.failed(
                            error=f"input {alias}.{key} not found")
                if not isinstance(content, (str, bytes)):
                    content = str(content)
                if isinstance(content, str):
                    raw = content.encode("utf-8")
                else:
                    raw = content
                digest = compute_bytes_checksum(raw, algo)
                source = {"bytes": len(raw)}
        except Exception as exc:
            return StageResult.failed(error=f"checksum failed: {exc}")

        ctx.log(f"{algo} digest: {digest}")
        out = {"algorithm": algo, "digest": digest, **source}
        if expected and expected.lower() != digest.lower():
            return StageResult.failed(
                error=f"checksum mismatch: got {digest}, expected {expected}",
                outputs=out,
            )
        return StageResult.succeeded(outputs=out)
