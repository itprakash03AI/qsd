"""``RowCountCheckStage`` — assert a row count against a baseline or threshold.

Reads ``row_count`` (or any named output key) from a prior stage and
fails the dataflow if it falls outside the configured bounds.  Common
use cases:

* Reject empty extracts (``min_rows: 1``).
* Catch upstream regression (``min_pct_of_baseline: 0.5``).
* Catch runaway growth (``max_rows: 10_000_000``).

Config:
    ``source_alias``         : str (required) — stage to read from
    ``source_key``           : str (default "row_count" then "sample_count")
    ``min_rows``             : int — fail if observed < this
    ``max_rows``             : int — fail if observed > this
    ``min_pct_of_baseline``  : float (0..1) — observed must be at least
                                  this fraction of context["baseline_rows"]
    ``max_pct_of_baseline``  : float — observed must be at most this
                                  multiple of context["baseline_rows"]
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from core.dataflow.base import (
    BaseStage, CATEGORY_QUALITY, IDEMPOTENT_SAFE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class RowCountCheckStage(BaseStage):
    NAME = "row_count_check"
    DISPLAY_NAME = "Row-Count Check"
    CATEGORY = CATEGORY_QUALITY
    DESCRIPTION = "Assert a row count from a prior stage against bounds."
    IDEMPOTENCY = IDEMPOTENT_SAFE
    CONFIG_SCHEMA = {
        "source_alias":          {"type": "string"},
        "source_key":            {"type": "string"},
        "min_rows":              {"type": "integer", "minimum": 0},
        "max_rows":              {"type": "integer", "minimum": 0},
        "min_pct_of_baseline":   {"type": "number", "minimum": 0},
        "max_pct_of_baseline":   {"type": "number", "minimum": 0},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        if not config.get("source_alias"):
            errs.append("source_alias is required")
        bounds = [
            config.get("min_rows"), config.get("max_rows"),
            config.get("min_pct_of_baseline"), config.get("max_pct_of_baseline"),
        ]
        if all(b is None for b in bounds):
            errs.append("at least one of min_rows/max_rows/min_pct_of_baseline/max_pct_of_baseline must be set")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        source_alias = ctx.get_config("source_alias")
        source_key = ctx.get_config("source_key")
        outputs = ctx.get_input(source_alias) or {}
        observed = self._extract_count(outputs, source_key)
        if observed is None:
            return StageResult.failed(
                error=f"could not extract row count from prev stage {source_alias!r} "
                       f"(outputs keys: {sorted(outputs.keys()) if outputs else '[]'})",
            )

        min_rows = ctx.get_config("min_rows")
        max_rows = ctx.get_config("max_rows")
        min_pct = ctx.get_config("min_pct_of_baseline")
        max_pct = ctx.get_config("max_pct_of_baseline")
        baseline = ctx.get_param("baseline_rows")

        failures: List[str] = []
        if min_rows is not None and observed < int(min_rows):
            failures.append(f"observed {observed} < min_rows {min_rows}")
        if max_rows is not None and observed > int(max_rows):
            failures.append(f"observed {observed} > max_rows {max_rows}")
        if min_pct is not None and baseline is not None:
            lower = float(baseline) * float(min_pct)
            if observed < lower:
                failures.append(f"observed {observed} < {min_pct:.0%} of baseline {baseline} ({lower:.1f})")
        if max_pct is not None and baseline is not None:
            upper = float(baseline) * float(max_pct)
            if observed > upper:
                failures.append(f"observed {observed} > {max_pct:.0%} of baseline {baseline} ({upper:.1f})")

        out = {
            "observed":  observed,
            "baseline":  baseline,
            "min_rows":  min_rows,
            "max_rows":  max_rows,
        }
        if failures:
            return StageResult.failed(error="; ".join(failures), outputs=out)
        ctx.log(f"row count {observed} within bounds")
        return StageResult.succeeded(outputs=out)

    @staticmethod
    def _extract_count(outputs: Dict[str, Any], key: Optional[str]) -> Optional[int]:
        if key:
            v = outputs.get(key)
            if isinstance(v, (int, float)):
                return int(v)
            return None
        for candidate in ("row_count", "rows", "sample_count", "count"):
            v = outputs.get(candidate)
            if isinstance(v, (int, float)):
                return int(v)
        return None
