"""``HumanApprovalStage`` — pause the dataflow until an admin approves or rejects.

Writes a ``DataFlowApprovalRequest`` row, broadcasts a notification, then
polls the row until ``status`` is decided.  Admin decides via
``POST /api/dataflows/approvals/{id}/decide``.

Config:
    ``title``           : str (required)
    ``description``     : str
    ``payload_keys``    : list[str] — copy keys from run_context into payload
    ``timeout_seconds`` : int (default 86400) — auto-expire after this window
    ``poll_seconds``    : float (default 5)
"""
from __future__ import annotations

import time
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_CONTROL, IDEMPOTENT_UNSAFE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class HumanApprovalStage(BaseStage):
    NAME = "human_approval"
    DISPLAY_NAME = "Human Approval"
    CATEGORY = CATEGORY_CONTROL
    IS_CONTROL_FLOW = True
    DESCRIPTION = "Pause until an admin approves or rejects via the API."
    # Unsafe to rerun — a second approval request would fire another
    # notification to admins.
    IDEMPOTENCY = IDEMPOTENT_UNSAFE
    CONFIG_SCHEMA = {
        "title":           {"type": "string"},
        "description":     {"type": "string"},
        "payload_keys":    {"type": "array", "items": {"type": "string"}},
        "timeout_seconds": {"type": "integer", "minimum": 1},
        "poll_seconds":    {"type": "number", "minimum": 0.5},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        if not config.get("title"):
            errs.append("title is required")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        from core.db.models import DataFlowApprovalRequest

        if ctx.db_manager is None:
            return StageResult.failed(error="db_manager unavailable")

        title = ctx.get_config("title")
        description = ctx.get_config("description")
        payload_keys = ctx.get_config("payload_keys", []) or []
        timeout_s = int(ctx.get_config("timeout_seconds", 86400))
        poll = float(ctx.get_config("poll_seconds", 5))

        payload: Dict[str, Any] = {}
        for k in payload_keys:
            if k in ctx.run_context:
                payload[k] = ctx.run_context[k]

        # Create the approval row.  Idempotency: if a pending approval
        # already exists for (run_id, stage_alias), reuse it (caused by
        # resume after a partial timeout).
        try:
            with ctx.db_manager.get_session() as session:
                existing = (
                    session.query(DataFlowApprovalRequest)
                    .filter(DataFlowApprovalRequest.run_id == ctx.run_id,
                            DataFlowApprovalRequest.stage_alias == ctx.stage_alias,
                            DataFlowApprovalRequest.status == "pending")
                    .first()
                )
                if existing is None:
                    expires_at = (datetime.now(timezone.utc)
                                  + timedelta(seconds=timeout_s))
                    row = DataFlowApprovalRequest(
                        run_id=ctx.run_id,
                        stage_alias=ctx.stage_alias,
                        dataflow_name=ctx.dataflow_name,
                        title=title,
                        description=description,
                        requested_by=ctx.triggered_by,
                        status="pending",
                        payload=payload,
                        expires_at=expires_at,
                    )
                    session.add(row)
                    session.flush()
                    session.refresh(row)
                    approval_id = row.id
                else:
                    approval_id = existing.id
        except Exception as exc:
            return StageResult.failed(error=f"failed to create approval row: {exc}")

        # Broadcast a notification so the dashboard surfaces the prompt.
        if ctx.broadcast_fn is not None:
            try:
                ctx.broadcast_fn({
                    "event":         "workflow_approval_required",
                    "approval_id":   approval_id,
                    "run_id":        ctx.run_id,
                    "stage_alias":   ctx.stage_alias,
                    "dataflow_name": ctx.dataflow_name,
                    "title":         title,
                    "severity":      "warning",
                })
            except Exception as _bx_exc:
                # WS hiccup must not block the approval flow — the row
                # is in DB and admin can still decide via the API.
                ctx.log(f"approval notification broadcast failed: {_bx_exc}")

        ctx.log(f"approval request #{approval_id} pending — polling every {poll}s")

        # Poll until decided or expired/cancelled.
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            if ctx.is_cancelled():
                return StageResult.failed(error="cancelled while awaiting approval")
            try:
                with ctx.db_manager.get_session(read_only=True) as session:
                    row = (
                        session.query(DataFlowApprovalRequest)
                        .filter(DataFlowApprovalRequest.id == approval_id)
                        .first()
                    )
                    if row is None:
                        return StageResult.failed(error="approval row vanished")
                    status = row.status
                    decided_by = row.decided_by
                    notes = row.decision_notes
            except Exception as exc:
                ctx.log(f"approval poll error: {exc}")
                status = "pending"
                decided_by = None
                notes = None
            if status == "approved":
                ctx.log(f"approval #{approval_id} approved by {decided_by}")
                return StageResult.succeeded(outputs={
                    "approval_id": approval_id, "status": status,
                    "decided_by":  decided_by, "decision_notes": notes,
                })
            if status == "rejected":
                ctx.log(f"approval #{approval_id} rejected by {decided_by}: {notes}")
                return StageResult.failed(
                    error=f"approval rejected by {decided_by}: {notes or ''}",
                    outputs={"approval_id": approval_id, "status": status,
                              "decided_by": decided_by, "decision_notes": notes},
                )
            time.sleep(min(poll, max(0.5, deadline - time.time())))

        # Mark expired
        try:
            with ctx.db_manager.get_session() as session:
                row = (
                    session.query(DataFlowApprovalRequest)
                    .filter(DataFlowApprovalRequest.id == approval_id)
                    .first()
                )
                if row is not None and row.status == "pending":
                    row.status = "expired"
                    session.flush()
        except Exception as _exp_exc:
            # Mark-as-expired is best-effort; the stage already failed.
            ctx.log(f"approval expire-update failed: {_exp_exc}")
        return StageResult.failed(
            error=f"approval timed out after {timeout_s}s",
            outputs={"approval_id": approval_id, "status": "expired"},
        )
