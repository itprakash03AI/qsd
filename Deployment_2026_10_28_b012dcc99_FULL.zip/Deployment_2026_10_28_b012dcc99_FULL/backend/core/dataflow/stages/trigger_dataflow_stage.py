"""``TriggerDataFlowStage`` — fire another DataFlow.

Mirrors Airflow's ``TriggerDagRunOperator``.  Different from
``sub_dataflow``: this is *non-blocking* — kick off the child run and
move on.  Use when the parent doesn't need the child's result, or when
you want fan-out across many DataFlows without coupling.

Combine with ``wait_for_dataflow_run`` later in the same DAG (or in a
separate downstream DAG) when you DO need to wait.
"""
from __future__ import annotations

from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_CONTROL, IDEMPOTENT_UNSAFE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class TriggerDataFlowStage(BaseStage):
    NAME = "trigger_dataflow"
    DISPLAY_NAME = "Trigger DataFlow (non-blocking)"
    CATEGORY = CATEGORY_CONTROL
    IS_CONTROL_FLOW = True
    # Unsafe-on-rerun because re-firing creates a fresh child run.
    IDEMPOTENCY = IDEMPOTENT_UNSAFE
    DESCRIPTION = ("Trigger another DataFlow's run and return immediately. "
                     "Pair with wait_for_dataflow_run downstream if you need "
                     "to block until it completes.")
    CONFIG_SCHEMA = {
        "dataflow_name":         {"type": "string",
                                    "description": "Name of the DataFlow to trigger."},
        "context_passthrough":   {"type": "array",
                                    "description": "Keys from this run's context to forward to the child."},
        "context_overrides":     {"type": "object",
                                    "description": "Extra keys merged into the child's context."},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        if not (config.get("dataflow_name") or "").strip():
            return ["dataflow_name is required"]
        return []

    def execute(self, ctx: StageContext) -> StageResult:
        from core.dataflow.engine import get_engine
        from core.dataflow.dispatcher import get_dispatcher
        import threading

        engine = get_engine()
        dispatcher = get_dispatcher()
        if engine is None or dispatcher is None:
            return StageResult.failed(error="dataflow engine not initialised")

        target = ctx.get_config("dataflow_name", "").strip()
        passthrough = ctx.get_config("context_passthrough") or []
        overrides = ctx.get_config("context_overrides") or {}

        child_ctx: Dict[str, Any] = {}
        for k in passthrough:
            if k in ctx.run_context:
                child_ctx[k] = ctx.run_context[k]
        child_ctx.update(overrides)

        try:
            child_run = engine.start_run(
                dataflow_name=target,
                context=child_ctx,
                triggered_by=f"parent_run:{ctx.run_id}",
                trigger_payload={
                    "parent_run_id":   ctx.run_id,
                    "parent_dataflow": ctx.workflow_name if hasattr(ctx, "workflow_name") else None,
                    "parent_stage":    ctx.stage_alias,
                },
                parent_run_id=ctx.run_id,
            )
        except Exception as exc:
            return StageResult.failed(error=f"failed to start child DataFlow: {exc}")

        child_id = child_run["id"]
        # Fire-and-forget — kick the dispatcher in a daemon thread so we
        # don't block this stage's slot.
        threading.Thread(
            target=lambda: dispatcher.run(child_id),
            daemon=True, name=f"trigger-{child_id}",
        ).start()
        ctx.log(f"triggered DataFlow {target!r} as run #{child_id} (non-blocking)")
        return StageResult.succeeded(outputs={
            "child_run_id":    child_id,
            "child_dataflow":  target,
            "non_blocking":    True,
        })
