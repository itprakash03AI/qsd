"""``ReadFileStage`` — read a local file into the stage's outputs."""
from __future__ import annotations

import os
from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_SOURCE, IDEMPOTENT_SAFE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class ReadFileStage(BaseStage):
    NAME = "read_file"
    DISPLAY_NAME = "Read from File"
    CATEGORY = CATEGORY_SOURCE
    DESCRIPTION = "Read a local file's contents into the stage outputs."
    IDEMPOTENCY = IDEMPOTENT_SAFE
    CONFIG_SCHEMA = {
        "path":       {"type": "string"},
        "encoding":   {"type": "string"},
        "max_bytes":  {"type": "integer", "minimum": 1},
        "required":   {"type": "boolean"},   # default true — fail if missing
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        if not config.get("path"):
            errs.append("path is required")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        path_template = ctx.get_config("path", "")
        try:
            path = path_template.format(**ctx.run_context)
        except Exception:
            path = path_template
        encoding = ctx.get_config("encoding", "utf-8")
        max_bytes = int(ctx.get_config("max_bytes", 0) or 0)
        required = bool(ctx.get_config("required", True))

        if not os.path.exists(path):
            if not required:
                return StageResult.skipped(
                    reason=f"file {path} does not exist (required=false)",
                    outputs={"path": path, "exists": False},
                )
            return StageResult.failed(error=f"file not found: {path}")

        try:
            size = os.path.getsize(path)
            with open(path, "r", encoding=encoding) as fh:
                content = fh.read(max_bytes) if max_bytes > 0 else fh.read()
            ctx.log(f"read {len(content)} chars from {path} (file size {size})")
            return StageResult.succeeded(outputs={
                "path":     path,
                "content":  content,
                "bytes":    size,
                "exists":   True,
            })
        except Exception as exc:
            return StageResult.failed(error=f"read_file failed: {exc}")
