"""Stage library.

Each stage is its own module + class.  Discovery happens via
``StageTypeRegistry.discover()`` which imports every submodule here;
each stage class registers itself via the ``@register`` decorator from
``core.dataflow.registry``.
"""
