"""``SplitRecordsStage`` — NiFi ``SplitRecord`` equivalent.

Splits one input file into N output files by row count or partition
key.  Common use case:
* sharding a 10M-row export into 1M-row chunks for parallel consumers
* partitioning by a column (e.g. ``region``, ``business_date``) so
  downstream loaders pick up only their slice

Two modes:
* ``mode='rows'``     — fixed row count per output (``rows_per_part``)
* ``mode='partition'`` — partition by column values (``partition_columns``)

Uses DuckDB ``COPY ... TO PARTITIONED_BY`` for the partition mode and
windowed batched SELECTs for the rows mode.  Output paths support
``{key}`` interpolation against ``run_context`` plus ``{part}`` for the
part number (rows mode).
"""
from __future__ import annotations

import os
from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_TRANSFORM, IDEMPOTENT_OVERWRITE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


_READERS = {
    "csv":     "read_csv_auto",
    "parquet": "read_parquet",
    "json":    "read_json_auto",
}


@register
class SplitRecordsStage(BaseStage):
    NAME = "split_records"
    DISPLAY_NAME = "Split Records (one → many)"
    CATEGORY = CATEGORY_TRANSFORM
    IDEMPOTENCY = IDEMPOTENT_OVERWRITE
    DESCRIPTION = ("NiFi SplitRecord equivalent — split one file into many "
                    "by row count or by partition key.")
    COST_SECONDS = 30
    COST_CENTS = 0
    CONFIG_SCHEMA = {
        "input_path":     {"type": "string", "description": "Source file (supports {key})."},
        "input_format":   {"type": "string", "enum": ["csv", "parquet", "json"]},
        "output_dir":     {"type": "string",
                             "description": "Where parts go (supports {key})."},
        "output_format":  {"type": "string", "enum": ["csv", "parquet", "json"]},
        "mode":           {"type": "string", "enum": ["rows", "partition"]},
        "rows_per_part":  {"type": "integer", "minimum": 1,
                             "description": "Required when mode=rows."},
        "partition_columns": {"type": "array",
                               "description": "Required when mode=partition."},
        "filename_template": {"type": "string",
                               "description": "rows mode — output filename relative to "
                                              "output_dir.  Supports {part} and {key}.  "
                                              "Default: 'part-{part:05d}.<ext>'."},
        "delete_input":    {"type": "boolean"},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        if not (config.get("input_path") or "").strip():
            errs.append("input_path is required")
        if not (config.get("output_dir") or "").strip():
            errs.append("output_dir is required")
        mode = config.get("mode") or "rows"
        if mode not in ("rows", "partition"):
            errs.append("mode must be 'rows' or 'partition'")
        if mode == "rows":
            rpp = config.get("rows_per_part")
            if not rpp or int(rpp) < 1:
                errs.append("rows_per_part must be >= 1 when mode='rows'")
        if mode == "partition":
            cols = config.get("partition_columns")
            if not cols or not isinstance(cols, list):
                errs.append("partition_columns is required when mode='partition'")
        for k in ("input_format", "output_format"):
            v = config.get(k)
            if v and v not in _READERS:
                errs.append(f"{k} must be csv|parquet|json")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        def _fmt(s: str) -> str:
            try:
                return s.format(**ctx.run_context)
            except Exception:
                return s

        input_path  = _fmt(ctx.get_config("input_path") or "")
        output_dir  = _fmt(ctx.get_config("output_dir") or "")
        input_format  = ctx.get_config("input_format")  or self._guess_format(input_path)
        output_format = ctx.get_config("output_format") or input_format
        mode = ctx.get_config("mode") or "rows"
        delete_input = bool(ctx.get_config("delete_input", False))

        if input_format not in _READERS:
            return StageResult.failed(error=f"unsupported input_format: {input_format}")
        if output_format not in _READERS:
            return StageResult.failed(error=f"unsupported output_format: {output_format}")
        if not os.path.exists(input_path):
            return StageResult.failed(error=f"input not found: {input_path}")

        os.makedirs(output_dir, exist_ok=True)

        try:
            import duckdb
            con = duckdb.connect(database=":memory:")
        except Exception as exc:
            return StageResult.failed(error=f"DuckDB unavailable: {exc}")

        try:
            if mode == "rows":
                return self._split_by_rows(
                    ctx, con, input_path, input_format, output_dir,
                    output_format, delete_input,
                )
            return self._split_by_partition(
                ctx, con, input_path, input_format, output_dir,
                output_format, delete_input,
            )
        finally:
            try:
                con.close()
            except Exception:
                pass

    # ── Mode: rows ──────────────────────────────────────────────────────
    def _split_by_rows(
        self, ctx: StageContext, con: Any, input_path: str, input_format: str,
        output_dir: str, output_format: str, delete_input: bool,
    ) -> StageResult:
        reader = _READERS[input_format]
        ext = {"csv": "csv", "parquet": "parquet", "json": "json"}[output_format]
        rows_per_part = int(ctx.get_config("rows_per_part"))
        filename_template = ctx.get_config("filename_template") or f"part-{{part:05d}}.{ext}"

        # Count to size the loop
        try:
            total = con.execute(
                f"SELECT count(*) FROM {reader}('{input_path.replace(chr(39),chr(39)*2)}')"
            ).fetchone()[0] or 0
        except Exception as exc:
            return StageResult.failed(error=f"row count failed: {exc}")
        if total == 0:
            return StageResult.succeeded(outputs={
                "input_path": input_path, "parts": 0, "rows": 0,
            })

        parts = (total + rows_per_part - 1) // rows_per_part
        fmt_clause = {
            "csv":     "(FORMAT 'csv', HEADER)",
            "parquet": "(FORMAT 'parquet')",
            "json":    "(FORMAT 'json')",
        }[output_format]
        written: List[str] = []
        for i in range(parts):
            offset = i * rows_per_part
            try:
                fname = filename_template.format(part=i, **ctx.run_context)
            except Exception:
                fname = f"part-{i:05d}.{ext}"
            outp = os.path.join(output_dir, fname).replace("\\", "/")
            sql = (
                f"COPY (SELECT * FROM {reader}('{input_path.replace(chr(39),chr(39)*2)}') "
                f"LIMIT {rows_per_part} OFFSET {offset}) "
                f"TO '{outp.replace(chr(39),chr(39)*2)}' {fmt_clause}"
            )
            try:
                con.execute(sql)
                written.append(outp)
            except Exception as exc:
                return StageResult.failed(error=f"part {i} failed: {exc}")

        if delete_input:
            try:
                os.remove(input_path)
            except Exception as exc:
                ctx.log(f"delete_input failed: {exc}")

        ctx.log(f"split {total} rows into {len(written)} part(s) of up to {rows_per_part} each")
        return StageResult.succeeded(outputs={
            "input_path": input_path,
            "parts":      len(written),
            "rows":       total,
            "part_paths": written,
        })

    # ── Mode: partition ────────────────────────────────────────────────
    def _split_by_partition(
        self, ctx: StageContext, con: Any, input_path: str, input_format: str,
        output_dir: str, output_format: str, delete_input: bool,
    ) -> StageResult:
        reader = _READERS[input_format]
        cols = ctx.get_config("partition_columns") or []
        if not cols:
            return StageResult.failed(error="partition_columns required")
        # DuckDB writes Hive-style folders.  Only parquet supports
        # PARTITION_BY natively; for csv/json we fall back to a SELECT
        # DISTINCT loop.
        fmt_clause = {
            "csv":     "(FORMAT 'csv', HEADER, PARTITION_BY ({cols}), OVERWRITE_OR_IGNORE)",
            "parquet": "(FORMAT 'parquet', PARTITION_BY ({cols}), OVERWRITE_OR_IGNORE)",
            "json":    "(FORMAT 'json', PARTITION_BY ({cols}), OVERWRITE_OR_IGNORE)",
        }[output_format].format(cols=",".join(cols))
        try:
            sql = (
                f"COPY (SELECT * FROM {reader}('{input_path.replace(chr(39),chr(39)*2)}')) "
                f"TO '{output_dir.replace(chr(39),chr(39)*2)}' {fmt_clause}"
            )
            con.execute(sql)
        except Exception as exc:
            return StageResult.failed(error=f"partition split failed: {exc}")

        if delete_input:
            try:
                os.remove(input_path)
            except Exception as exc:
                ctx.log(f"delete_input failed: {exc}")

        ctx.log(f"partitioned {input_path} by {cols} → {output_dir}")
        return StageResult.succeeded(outputs={
            "input_path":          input_path,
            "output_dir":          output_dir,
            "partition_columns":   cols,
        })

    @staticmethod
    def _guess_format(path: str) -> str:
        ext = (path.rsplit(".", 1)[-1] or "").lower()
        if ext in ("csv", "tsv", "txt"):
            return "csv"
        if ext == "parquet":
            return "parquet"
        if ext in ("json", "jsonl", "ndjson"):
            return "json"
        return "parquet"
