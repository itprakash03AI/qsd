"""``WriteFileStage`` — write text content to a local file.

Used by dataflows that produce a file as part of their pipeline
(reports, manifests, CSV exports, etc.).  Idempotent: overwriting the
same path is safe.

Config:
    ``path``    : str (required) — supports ``{key}`` interpolation
    ``content``  : str | "from_input" — content to write.  When equal to
                  the literal "from_input", pulls from an input source
                  (default: prev stage's outputs.content).
    ``input_source``  : {"alias": str, "key": str} when content="from_input"
    ``encoding``      : str (default "utf-8")
    ``ensure_parent_dir`` : bool (default true) — mkdir -p the parent
"""
from __future__ import annotations

import os
from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_SINK, IDEMPOTENT_OVERWRITE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class WriteFileStage(BaseStage):
    NAME = "write_file"
    DISPLAY_NAME = "Write to File"
    CATEGORY = CATEGORY_SINK
    DESCRIPTION = "Write text content to a local file path."
    IDEMPOTENCY = IDEMPOTENT_OVERWRITE
    CONFIG_SCHEMA = {
        "path":              {"type": "string"},
        "content":           {"type": "string"},
        "input_source":      {"type": "object"},
        "encoding":          {"type": "string"},
        "ensure_parent_dir": {"type": "boolean"},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        if not config.get("path"):
            errs.append("path is required")
        if config.get("content") is None:
            errs.append("content is required (literal text or 'from_input')")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        path_template = ctx.get_config("path", "")
        try:
            path = path_template.format(**ctx.run_context)
        except Exception:
            path = path_template
        encoding = ctx.get_config("encoding", "utf-8")
        ensure_parent = bool(ctx.get_config("ensure_parent_dir", True))
        content = ctx.get_config("content")

        if content == "from_input":
            src = ctx.get_config("input_source", {}) or {}
            alias = src.get("alias")
            key = src.get("key", "content")
            if not alias:
                return StageResult.failed(error="input_source.alias required when content='from_input'")
            value = ctx.get_input(alias, key)
            if value is None:
                return StageResult.failed(error=f"input {alias}.{key} not found in prev_outputs")
            content = str(value)
        else:
            try:
                content = str(content).format(**ctx.run_context)
            except Exception:
                content = str(content)

        try:
            if ensure_parent:
                parent = os.path.dirname(path)
                if parent:
                    os.makedirs(parent, exist_ok=True)
            with open(path, "w", encoding=encoding) as fh:
                fh.write(content)
            size = os.path.getsize(path)
            ctx.log(f"wrote {size} bytes to {path}")
            return StageResult.succeeded(outputs={
                "path":     path,
                "bytes":    size,
                "encoding": encoding,
            })
        except Exception as exc:
            return StageResult.failed(error=f"write_file failed: {exc}")
