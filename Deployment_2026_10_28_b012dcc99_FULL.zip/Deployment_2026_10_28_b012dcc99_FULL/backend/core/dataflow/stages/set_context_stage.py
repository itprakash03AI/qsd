"""``SetContextStage`` — write keys into the run's shared context bag.

Common use cases:
* Materialise computed parameters (``business_date``, ``run_label``).
* Stash a config snapshot for downstream stages to read via ``ctx.get_param``.
* Tie a dataflow to a specific feed/connection id at run start.
"""
from __future__ import annotations

from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_TRANSFORM, IDEMPOTENT_OVERWRITE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class SetContextStage(BaseStage):
    """Merge ``values`` into the run's shared context.

    Config:
        ``values`` : dict — keys & values to set
    """

    NAME = "set_context"
    DISPLAY_NAME = "Set Parameters"
    CATEGORY = CATEGORY_TRANSFORM
    DESCRIPTION = "Merge static or templated values into the run context."
    IDEMPOTENCY = IDEMPOTENT_OVERWRITE
    CONFIG_SCHEMA = {
        "values": {"type": "object"},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        values = config.get("values")
        if values is None or not isinstance(values, dict):
            errs.append("values must be an object")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        values = ctx.get_config("values", {}) or {}
        ctx.log(f"setting {len(values)} context keys: {sorted(values.keys())}")
        return StageResult.succeeded(
            outputs={"set_keys": sorted(values.keys())},
            context_updates=values,
        )
