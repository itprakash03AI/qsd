"""``SubDataFlowStage`` — invoke another dataflow from inside a dataflow.

Two modes, controlled by ``wait_for_completion``:

* ``true``  — block the parent stage until the child run terminates.
              The parent stage adopts the child's status (succeeded /
              failed / cancelled).  Outputs of the child's final stage
              are surfaced as this stage's outputs.

* ``false`` — fire-and-forget.  The child run is started and this
              stage immediately returns succeeded.  Use when the parent
              dataflow doesn't care about the child's outcome.

In *both* modes the child run records ``parent_run_id`` so the dashboard
can render the hierarchy.

Important: the dispatcher running this stage is in-process; spawning
another run.run() inside the same thread would dead-lock the executor
when run via the scheduler pool.  We solve this by:

* Wait-mode:    submit child to a fresh local thread + poll its DB row.
* Fire-mode:    submit child to the dispatcher pool (no wait).
"""
from __future__ import annotations

import threading
import time
from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_CONTROL, IDEMPOTENT_CONFIGURED,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class SubDataFlowStage(BaseStage):
    """Trigger another dataflow.

    Config:
        ``dataflow_name``        : str (required) — name of the active dataflow to invoke
        ``wait_for_completion``  : bool — block until child is done (default true)
        ``context_passthrough``  : list[str] — keys to copy from parent run_context into child
        ``context_overrides``    : dict — static overrides merged into child context
        ``poll_seconds``         : int (default 2) — DB poll interval when waiting
        ``timeout_seconds``      : int — abort wait after this many seconds (default 3600)
    """

    NAME = "sub_dataflow"
    DISPLAY_NAME = "Run Sub-DataFlow"
    CATEGORY = CATEGORY_CONTROL
    IS_CONTROL_FLOW = True
    DESCRIPTION = "Invoke another dataflow (sync wait or fire-and-forget)."
    IDEMPOTENCY = IDEMPOTENT_CONFIGURED
    CONFIG_SCHEMA = {
        "dataflow_name":       {"type": "string"},
        "wait_for_completion": {"type": "boolean"},
        "context_passthrough": {"type": "array", "items": {"type": "string"}},
        "context_overrides":   {"type": "object"},
        "poll_seconds":        {"type": "integer", "minimum": 1},
        "timeout_seconds":     {"type": "integer", "minimum": 1},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        if not config.get("dataflow_name"):
            errs.append("dataflow_name is required")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        from core.dataflow.engine import get_engine
        from core.dataflow.dispatcher import get_dispatcher

        engine = get_engine()
        dispatcher = get_dispatcher()
        if engine is None or dispatcher is None:
            return StageResult.failed(error="dataflow engine/dispatcher not initialised")

        wf_name = ctx.get_config("dataflow_name")
        wait = bool(ctx.get_config("wait_for_completion", True))
        passthrough = ctx.get_config("context_passthrough", []) or []
        overrides = ctx.get_config("context_overrides", {}) or {}
        poll_seconds = max(1, int(ctx.get_config("poll_seconds", 2)))
        timeout = max(1, int(ctx.get_config("timeout_seconds", 3600)))

        # Build child context
        child_context: Dict[str, Any] = {}
        for k in passthrough:
            if k in ctx.run_context:
                child_context[k] = ctx.run_context[k]
        child_context.update(overrides)

        child_run = engine.start_run(
            dataflow_name=wf_name,
            context=child_context,
            triggered_by=f"parent_run:{ctx.run_id}",
            trigger_payload={
                "parent_run_id":    ctx.run_id,
                "parent_workflow":  ctx.dataflow_name,
                "parent_stage":     ctx.stage_alias,
            },
            parent_run_id=ctx.run_id,
        )
        child_id = child_run["id"]
        ctx.log(f"sub-dataflow {wf_name!r} started as run #{child_id} "
                f"(wait={wait})")

        # Fire-and-forget: submit to a thread and return immediately.
        if not wait:
            threading.Thread(
                target=self._fire_and_forget_run,
                args=(dispatcher, child_id),
                daemon=True,
                name=f"wf-sub-{child_id}",
            ).start()
            return StageResult.succeeded(outputs={"child_run_id": child_id,
                                                   "wait": False})

        # Synchronous wait: run the child in a separate thread + poll
        # its DB row.  Using a separate thread keeps the parent
        # dispatcher's pool slot occupied (correct — this stage is
        # legitimately blocked) without re-entering the same thread.
        runner = threading.Thread(
            target=self._fire_and_forget_run,
            args=(dispatcher, child_id),
            daemon=True,
            name=f"wf-sub-{child_id}",
        )
        runner.start()

        from core.db.models import DataFlowRun

        deadline = time.time() + timeout
        terminal = {"succeeded", "failed", "cancelled", "partial"}
        while time.time() < deadline:
            if ctx.is_cancelled():
                return StageResult.failed(error=f"cancelled while waiting for sub-dataflow {child_id}")
            with ctx.db_manager.get_session(read_only=True) as session:
                child = session.query(DataFlowRun).filter(DataFlowRun.id == child_id).first()
                if child is not None and child.status in terminal:
                    out = {
                        "child_run_id": child_id,
                        "wait": True,
                        "status": child.status,
                        "duration_seconds": child.duration_seconds,
                        "outputs": child.outputs or {},
                    }
                    if child.status in ("failed", "cancelled"):
                        return StageResult.failed(
                            error=f"sub-dataflow {wf_name} run #{child_id} ended {child.status}: "
                                  f"{child.error or ''}",
                            outputs=out,
                        )
                    return StageResult.succeeded(outputs=out)
            time.sleep(poll_seconds)

        return StageResult.failed(
            error=f"sub-dataflow {wf_name} run #{child_id} timed out after {timeout}s",
            outputs={"child_run_id": child_id, "wait": True, "timed_out": True},
        )

    # ── helpers ─────────────────────────────────────────────────────────

    @staticmethod
    def _fire_and_forget_run(dispatcher: Any, run_id: int) -> None:
        try:
            dispatcher.run(run_id)
        except Exception:
            # The dispatcher records its own errors on the run row;
            # silent here to avoid double-logging.
            pass
