"""``WaitForDataFlowRunStage`` — cross-DAG dependency.

Mirrors Airflow's ``ExternalTaskSensor``.  Polls until a target
DataFlow's run for the same business_date (or any specified context
filter) reaches a terminal status.  Use to chain DAGs: "Run B only
after Run A succeeded for today's business_date."

Config:
    ``dataflow_name`` : str (required) — name of the upstream DataFlow.
    ``match_context_keys`` : list[str] — context keys the upstream run
        must share with this run (e.g. ["business_date"]).
    ``acceptable_statuses`` : list[str] — statuses that count as
        success (default ["succeeded"]).  Use ["succeeded", "partial"]
        to tolerate partial completion.
    ``poll_seconds`` : int (default 30).
    ``timeout_seconds`` : int (default 3600) — fail if no matching run
        reaches an acceptable status in this window.
    ``require_recent_minutes`` : int (default 0) — when > 0, the
        upstream run's started_at must be within the last N minutes
        (prevents matching a stale run from days ago).
"""
from __future__ import annotations

import time
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_CONTROL, IDEMPOTENT_SAFE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class WaitForDataFlowRunStage(BaseStage):
    NAME = "wait_for_dataflow_run"
    DISPLAY_NAME = "Wait for DataFlow Run (cross-DAG)"
    CATEGORY = CATEGORY_CONTROL
    IS_CONTROL_FLOW = True
    DESCRIPTION = ("Block until another DataFlow's run reaches a terminal "
                     "status (succeeded / partial / failed).  Use to chain "
                     "DAGs that share context such as business_date.")
    IDEMPOTENCY = IDEMPOTENT_SAFE
    CONFIG_SCHEMA = {
        "dataflow_name":         {"type": "string",
                                    "description": "Name of the upstream DataFlow to wait for."},
        "match_context_keys":    {"type": "array",
                                    "description": "Context keys (e.g. ['business_date']) the "
                                                    "matching upstream run must share with this run."},
        "acceptable_statuses":   {"type": "array",
                                    "description": "Statuses treated as success — usually "
                                                    "['succeeded'] or ['succeeded','partial']."},
        "poll_seconds":          {"type": "integer", "minimum": 1,
                                    "description": "DB poll cadence in seconds (default 30)."},
        "timeout_seconds":       {"type": "integer", "minimum": 1,
                                    "description": "Max wait in seconds (default 3600)."},
        "require_recent_minutes": {"type": "integer", "minimum": 0,
                                     "description": "Only count upstream runs whose started_at is "
                                                     "within the last N minutes.  0 = no recency check."},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        if not (config.get("dataflow_name") or "").strip():
            errs.append("dataflow_name is required")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        from core.db.models import DataFlowRun

        target_name = ctx.get_config("dataflow_name", "").strip()
        match_keys: List[str] = list(ctx.get_config("match_context_keys") or [])
        acceptable = set(ctx.get_config("acceptable_statuses") or ["succeeded"])
        poll = max(1, int(ctx.get_config("poll_seconds", 30)))
        timeout = max(poll, int(ctx.get_config("timeout_seconds", 3600)))
        recent_min = int(ctx.get_config("require_recent_minutes", 0))

        # Snapshot the context values we need to match against on the
        # upstream side.
        required: Dict[str, Any] = {k: ctx.get_param(k) for k in match_keys}

        ctx.log(f"waiting for upstream {target_name!r} matching {required}; "
                f"accept={sorted(acceptable)}, poll={poll}s, timeout={timeout}s")

        deadline = time.time() + timeout
        last_seen_status: str = ""

        while time.time() < deadline:
            if ctx.is_cancelled():
                return StageResult.failed(error="cancelled while waiting")
            try:
                with ctx.db_manager.get_session(read_only=True) as session:
                    q = (
                        session.query(DataFlowRun)
                        .filter(DataFlowRun.dataflow_name == target_name)
                        .order_by(DataFlowRun.created_at.desc())
                        .limit(50)
                        .all()
                    )
                # Pick the most recent matching run
                for run in q:
                    ctx_run = run.context or {}
                    if not all(ctx_run.get(k) == v for k, v in required.items()):
                        continue
                    if recent_min > 0 and run.started_at is not None:
                        cutoff = (datetime.now(timezone.utc)
                                   - timedelta(minutes=recent_min))
                        started = run.started_at
                        if started.tzinfo is None:
                            started = started.replace(tzinfo=timezone.utc)
                        if started < cutoff:
                            continue
                    last_seen_status = run.status
                    if run.status in acceptable:
                        ctx.log(f"upstream {target_name!r} run #{run.id} "
                                f"reached status={run.status} — proceeding")
                        return StageResult.succeeded(outputs={
                            "matched_run_id":   run.id,
                            "matched_status":   run.status,
                            "matched_at":       run.ended_at.isoformat() if run.ended_at else None,
                            "matched_outputs":  run.outputs or {},
                        })
                    if run.status in {"failed", "cancelled"}:
                        return StageResult.failed(
                            error=f"upstream {target_name!r} run #{run.id} "
                                    f"ended {run.status}",
                            outputs={"matched_run_id": run.id, "matched_status": run.status},
                        )
                    # status is pending/running — keep polling.
                    break
            except Exception as exc:
                ctx.log(f"poll error: {exc}")
            time.sleep(min(poll, max(1, deadline - time.time())))

        return StageResult.failed(
            error=f"timeout after waiting {timeout}s for upstream {target_name!r}; "
                    f"last seen status={last_seen_status or 'none'}",
            outputs={"timed_out": True, "last_seen_status": last_seen_status},
        )
