"""``NotifyStage`` — broadcast a notification event.

Wraps whatever broadcast function the dispatcher was wired with (the
WebSocket broadcaster in production).  Marked ``unsafe`` for idempotency
because re-running a notify potentially double-emails / double-pings.
The dispatcher's ``rerun_stage`` requires an explicit override before
re-firing an unsafe stage.
"""
from __future__ import annotations

from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_NOTIFY, IDEMPOTENT_UNSAFE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class NotifyStage(BaseStage):
    """Emit a notification through the dispatcher's broadcast channel.

    Config:
        ``channel``  : "ws" | "log" (default "ws")
        ``event``    : str — event name (default "workflow_notification")
        ``message``  : str — message body (supports ``{key}`` interpolation
                                against run_context)
        ``severity`` : "info" | "warning" | "error" | "success" (default "info")
    """

    NAME = "notify"
    DISPLAY_NAME = "Notification"
    CATEGORY = CATEGORY_NOTIFY
    DESCRIPTION = "Broadcast a notification message to a channel."
    IDEMPOTENCY = IDEMPOTENT_UNSAFE
    CONFIG_SCHEMA = {
        "channel":  {"type": "string", "enum": ["ws", "log"]},
        "event":    {"type": "string"},
        "message":  {"type": "string"},
        "severity": {"type": "string", "enum": ["info", "warning", "error", "success"]},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        if not config.get("message"):
            errs.append("message is required")
        channel = config.get("channel", "ws")
        if channel not in {"ws", "log"}:
            errs.append(f"channel must be ws|log, got {channel!r}")
        severity = config.get("severity", "info")
        if severity not in {"info", "warning", "error", "success"}:
            errs.append(f"severity must be info|warning|error|success, got {severity!r}")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        channel = ctx.get_config("channel", "ws")
        event = ctx.get_config("event", "workflow_notification")
        message_template = ctx.get_config("message", "")
        severity = ctx.get_config("severity", "info")

        try:
            message = message_template.format(**ctx.run_context)
        except Exception:
            message = message_template

        payload = {
            "event":         event,
            "severity":      severity,
            "message":       message,
            "run_id":        ctx.run_id,
            "dataflow_name": ctx.dataflow_name,
            "stage_alias":   ctx.stage_alias,
            "triggered_by":  ctx.triggered_by,
        }
        ctx.log(f"notify({channel}/{severity}): {message}")

        if channel == "ws" and ctx.broadcast_fn is not None:
            try:
                ctx.broadcast_fn(payload)
            except Exception as exc:
                # Notification failure is not a stage failure — log and proceed.
                ctx.log(f"broadcast failed: {exc}")
        return StageResult.succeeded(outputs={"sent": True, "channel": channel,
                                              "message": message})
