"""``LogStage`` — emit a message into the run's log_lines + the standard logger.

Useful as a checkpoint stage between heavier stages: it gives admins a
named point in the DAG where they can read context state, attach a
human-readable label, and audit progress.
"""
from __future__ import annotations

from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_NOTIFY, IDEMPOTENT_SAFE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class LogStage(BaseStage):
    """Writes a message into the stage's log_lines.

    Config:
        ``message`` : str — supports ``{key}`` interpolation against run_context.
        ``level``   : "info" | "warning" | "error" (default "info")
    """

    NAME = "log"
    DISPLAY_NAME = "Log Message"
    CATEGORY = CATEGORY_NOTIFY
    DESCRIPTION = "Emit a log line (no external side effects)."
    IDEMPOTENCY = IDEMPOTENT_SAFE
    CONFIG_SCHEMA = {
        "message": {"type": "string"},
        "level":   {"type": "string", "enum": ["info", "warning", "error"]},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        if not config.get("message"):
            errs.append("message is required")
        level = config.get("level", "info")
        if level not in {"info", "warning", "error"}:
            errs.append(f"level must be info|warning|error, got {level!r}")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        template = ctx.get_config("message", "")
        try:
            rendered = template.format(**ctx.run_context)
        except Exception:
            # Don't fail on a bad template — log it raw so the admin sees it.
            rendered = template
        ctx.log(rendered)
        return StageResult.succeeded(outputs={"message": rendered})
