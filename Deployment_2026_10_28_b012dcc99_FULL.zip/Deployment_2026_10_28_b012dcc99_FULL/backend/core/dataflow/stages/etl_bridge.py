"""ETL step bridge — exposes existing ETL/steps/* classes as DataFlow stages.

The codebase already ships a battle-tested ETL framework under
``c:/DEV/outputs/ETL/steps/`` (BaseStep + 20+ concrete steps:
StarburstToOracle, OracleToS3Parquet, S3IcebergToOracle, ConsolidateFiles,
CompressFiles, CreateCTLFile, ...).  Rather than duplicate that code we
bridge it: each ETL step type registers a DataFlow stage class that:

1. Builds a ``task`` dict from ``StageContext.config`` + ``run_context``
   + ``prev_outputs``.
2. Imports the ETL step class lazily (so QueryStudio still boots when the
   ETL framework isn't on the Python path).
3. Runs the ETL step's async ``_execute_step`` inside ``asyncio.run`` so
   the synchronous DataFlow dispatcher can drive it.
4. Surfaces ``task['totalcount']``, ``task['consolidated_file']`` and any
   other admin-declared output keys as ``StageResult.outputs``.

The bridge is intentionally a thin shim — every step's real logic lives
exactly once in ``ETL/steps/``.  Configuring an ETL step inside a DataFlow
is the same as configuring it in the original polling service: same task
dict shape, same field names.

Class design (OOP):

    class _EtlBridgeBase(BaseStage):
        ETL_MODULE: str
        ETL_CLASS:  str
        def execute(ctx): ... bridges to ETL ...

    @register class ConsolidateFilesStage(_EtlBridgeBase):
        NAME = "consolidate_files"
        DISPLAY_NAME = "Consolidate / Merge Files"
        ETL_MODULE = "steps.s3_to_file.consolidate_files"
        ETL_CLASS  = "ConsolidateFiles"

Adding a new ETL step is two lines.  The module paths below are taken
from ``ETL/configs/step_mapping.yaml`` (note ``configs``, plural — an
earlier docstring here said ``config/`` and a sweep concluded the file did
not exist), which is the OG contract from step name to Python class.

2026-09-15 — REGISTERED IS NOT RUNNABLE, AND NOW THE MANIFEST SAYS SO.
No shipped image carries ``ETL/`` (``Dockerfile.api`` copies ``backend/``,
``clockwork/`` and ``duckdb_extensions/``), so every bridge here fails at
execute unless ``QS_ETL_ROOT`` points at a mounted tree.  Until this date
nothing said so before the run: the manifest had no verdict and
``validate_config`` returned ``[]`` unconditionally.  Worse, 19 of the 25
targets declared here pointed at ``steps.<name>`` when the module lives in
a subpackage (``steps.file.*``, ``steps.oracle.*``, ``steps.s3_to_file.*``,
``steps.s3.*``, ``steps.s3_to_oracle.*``, ``steps.sap.*``) — they could not
import even where ``ETL/`` was present.  Every bridge now:

  * declares its variants ONCE (``ETL_VARIANTS`` + ``etl_variant_key``),
    which ``execute``, ``validate_config`` and ``runnability`` all read —
    one decision, three consumers;
  * reports ``runnable`` / ``unavailable_reason`` on its manifest from a
    real probe (``core.dataflow.runnability``): tree present, module path
    resolves, class declared;
  * refuses at ``validate_config`` (save + dry-run) when the variant the
    config selects cannot run here, so an author learns before a run.

A target that was never written (``pre_data_validation``) declares
``UNAVAILABLE_REASON`` instead of a path that can never import.
"""
from __future__ import annotations

import asyncio
import importlib
import logging
import sys
from pathlib import Path
from typing import Any, ClassVar, Dict, List, Tuple

from core.dataflow.base import (
    BaseStage, CATEGORY_SOURCE, CATEGORY_TRANSFORM, CATEGORY_SINK,
    CATEGORY_PIPELINE,
    IDEMPOTENT_CONFIGURED,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register
from core.dataflow.runnability import (
    Runnability, probe_etl_target, probe_etl_targets,
)
from core.etl_root import ensure_etl_on_path

logger = logging.getLogger(__name__)


# ── Path bootstrap so we can import ETL/steps/* ──────────────────────────


def _ensure_etl_on_path() -> bool:
    """Add the ETL repo root to sys.path so ``from steps.X import Y`` works.

    Returns True if the path was set up successfully OR is already there.
    Returns False if neither lookup succeeded — bridge stages then fail
    at execute time with a clear "ETL framework not installed" message.

    2026-08-19 — delegated to core.etl_root.  The list this replaced led with
    ``Path("c:/DEV/outputs/ETL")`` (one dev box's absolute path) and its only
    portable fallback, ``parents[5] / "ETL"``, was off by one: parents[5] of
    this file is the repo root's GRANDparent, so it resolved to ``C:/DEV/ETL``
    and never matched.  It also had no ``/app/ETL`` candidate, so in the
    container discovery depended entirely on the CWD.
    """
    return ensure_etl_on_path(_ETL_MARKER_FILE)


#: The file under ``ETL/steps/`` whose presence proves a tree is the ETL
#: framework.  execute()'s gate, the manifest probe and validate_config all
#: look for the SAME marker so they cannot disagree about "installed".
_ETL_MARKER_FILE = "BaseStep.py"

#: OG's unified SQL renderer (Phase 152) — one class for both locations.
_GENERATE_SQL: Tuple[str, str] = ("steps.file.generate_sql", "GenerateSQL")


# ── Shared bridge base ──────────────────────────────────────────────────


class _EtlBridgeBase(BaseStage):
    """Generic bridge: instantiate an ETL step + run its async ``_execute_step``.

    Subclasses set ``ETL_MODULE`` + ``ETL_CLASS`` to point at the target
    step.  Optionally override ``OUTPUT_KEYS`` to expose specific task[]
    fields as named outputs.
    """

    # Subclasses fill these in ────────────────────────────────────────
    ETL_MODULE: ClassVar[str] = ""
    ETL_CLASS:  ClassVar[str] = ""
    # 2026-09-15 — a stage whose target depends on config declares every
    # variant here, keyed by the label ``etl_variant_key(config)`` returns
    # (``"oncloud_spark"``, ``"iceberg"``, ...).  Empty = the single
    # (ETL_MODULE, ETL_CLASS) target.  ``etl_target(config)`` is the ONE
    # function that turns a config into a target; execute(), validate_config()
    # and the manifest verdict all go through it.
    ETL_VARIANTS: ClassVar[Dict[str, Tuple[str, str]]] = {}
    # 2026-09-15 — set when the ETL step this stage bridges to was NEVER
    # WRITTEN.  The stage stays registered (existing DAG rows and templates
    # still name it) but its manifest says why it cannot run, validate_config
    # refuses it, and execute() fails with the same sentence before any
    # import is attempted.  Preferred over leaving a module path that can
    # never resolve and hoping the ImportError reads well.
    UNAVAILABLE_REASON: ClassVar[str] = ""
    OUTPUT_KEYS: ClassVar[List[str]] = ["totalcount", "consolidated_file",
                                          "downloaded_files", "output_path",
                                          "ctl_file", "compressed_files"]
    CATEGORY = CATEGORY_TRANSFORM        # subclasses override (source/sink)
    IDEMPOTENCY = IDEMPOTENT_CONFIGURED  # depends on the underlying step

    # Phase 132.20 — credential resolution map.  Lets a stage reference an
    # encrypted Connection row by id instead of inlining username/password
    # into the DAG config.  At execute() time the bridge:
    #   1. reads each connection_id field from the stage config,
    #   2. queries Connection by id, decrypts via core.crypto.decrypt_config,
    #   3. maps named fields from connection.config → keys on the task dict.
    # Example for SAP:
    #     CONNECTION_FIELDS = {
    #         "sap_connection_id": {
    #             "base_url": "sap_base_url",
    #             "username": "sap_username",
    #             "password": "sap_password",
    #         }
    #     }
    # Backwards compat: when a connection_id key is absent / unset on the
    # stage config, the legacy inline fields are used as-is.
    CONNECTION_FIELDS: ClassVar[Dict[str, Dict[str, str]]] = {}

    # Phase 132.38 — list of stage_config field names that carry raw SQL.
    # When a subclass populates this tuple AND declares ``where_clauses``
    # in its CONFIG_SCHEMA, ``_EtlBridgeBase.execute`` wraps each listed
    # field with the publisher's Static + consumer Dynamic mapping
    # before dispatching to the underlying ETL step.  Empty (default) =
    # no wrap — stages that don't run SQL (file delivery, checksum,
    # consolidate, etc.) are untouched.
    SQL_CONFIG_FIELDS: ClassVar[tuple] = ()
    CONFIG_SCHEMA = {
        "task":              {"type": "object",
                                "description": "Initial task dict passed to the ETL step. "
                                                "Merged with run_context and prev_outputs."},
        "worker_connection": {"type": "string",
                                "description": "Worker DB connection string (Oracle)."},
        "dest_connection":   {"type": "string",
                                "description": "Destination DB connection string (Oracle)."},
        "step_name":         {"type": "string",
                                "description": "Display name for logging / status updates."},
    }

    # ── Target selection (2026-09-15: decided ONCE, read three times) ──

    @classmethod
    def etl_variant_key(cls, config: Dict[str, Any]) -> str:
        """Which ``ETL_VARIANTS`` entry this config selects.  Single-target
        stages return ``""``.  Subclasses with variants override; the
        defaulting rules (``location`` other than ``oncloud`` → onprem,
        ``format`` other than ``iceberg`` → parquet, ...) live in the
        override and nowhere else."""
        return ""

    @classmethod
    def etl_target(cls, config: Dict[str, Any]) -> Tuple[str, str]:
        """``(module, class)`` this config would import.  The one function
        execute(), validate_config() and the run log agree through."""
        if cls.ETL_VARIANTS:
            key = cls.etl_variant_key(config or {})
            if key not in cls.ETL_VARIANTS:
                raise KeyError(
                    f"{cls.NAME}.etl_variant_key returned {key!r}, not one of "
                    f"{sorted(cls.ETL_VARIANTS)} — the selector and the "
                    f"declaration disagree")
            return cls.ETL_VARIANTS[key]
        return (cls.ETL_MODULE, cls.ETL_CLASS)

    @classmethod
    def etl_targets(cls) -> Dict[str, Tuple[str, str]]:
        """Every target this stage can select, labelled — what the
        manifest verdict probes (all of them, so a dead variant is named
        before an author picks it)."""
        if cls.ETL_VARIANTS:
            return dict(cls.ETL_VARIANTS)
        return {"": (cls.ETL_MODULE, cls.ETL_CLASS)}

    # ── Runnability (the manifest verdict) ──────────────────────────

    @classmethod
    def runnability(cls) -> Runnability:
        """Can this bridge run in THIS image?  Probes the ETL tree the way
        execute() will look for it, then every variant's module path and
        class name — without importing the ETL modules.  See
        ``core.dataflow.runnability`` for what the verdict does and does
        not vouch for."""
        if cls.UNAVAILABLE_REASON:
            return Runnability.unavailable(cls.UNAVAILABLE_REASON)
        return probe_etl_targets(cls.etl_targets(), required_file=_ETL_MARKER_FILE)

    # ── Validation ──────────────────────────────────────────────────

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        """Refuse a stage this image cannot run.

        Until 2026-09-15 this returned ``[]`` unconditionally — "the task
        dict shape varies per step, defer to runtime" — which made it a
        gate that could not fail: an author saved and dry-ran a bridge
        stage on an image with no ``ETL/`` and learned at execute.  The
        task-dict shape is STILL deferred to the step (that part was
        true); what is checked here is the one thing that can be checked
        without importing the step — that the variant THIS config selects
        resolves to a module and class that exist here.  Subclasses that
        add field checks chain to this via ``super()``.
        """
        if cls.UNAVAILABLE_REASON:
            return Runnability.unavailable(cls.UNAVAILABLE_REASON).problems(cls.NAME)
        cfg = config or {}
        try:
            module, cls_name = cls.etl_target(cfg)
        except KeyError as exc:
            return [f"{cls.NAME}: {exc}"]
        key = cls.etl_variant_key(cfg) if cls.ETL_VARIANTS else ""
        label = f"{cls.NAME}[{key}]" if key else cls.NAME
        return probe_etl_target(module, cls_name,
                                required_file=_ETL_MARKER_FILE).problems(label)

    # ── Connection resolution (Phase 132.20) ───────────────────────

    def _resolve_connection_fields(
        self, ctx: StageContext, task: Dict[str, Any],
    ) -> List[str]:
        """Walk ``CONNECTION_FIELDS``, query each referenced ``Connection``
        row, decrypt its config, and merge mapped keys into ``task``.

        Returns a list of error strings — empty on success.  An empty
        connection_id (the placeholder admins haven't set yet) is treated
        as "no resolution needed" so legacy inline credentials still work.
        """
        if not self.CONNECTION_FIELDS:
            return []

        # Resolve a db_manager.  The dispatcher injects it via ctx.db_manager;
        # fall back to the singleton engine for tests/older bridge calls.
        db_manager = ctx.db_manager
        if db_manager is None:
            try:
                from core.dataflow.engine import get_engine
                e = get_engine()
                db_manager = e.db if e is not None else None
            except Exception:
                db_manager = None
        if db_manager is None:
            # Nothing to resolve against — only fail if any connection_id
            # is actually set, otherwise let the legacy inline fields fly.
            for id_key in self.CONNECTION_FIELDS:
                if ctx.config.get(id_key):
                    return [f"db_manager unavailable to resolve {id_key}"]
            return []

        from core.db.models import Connection
        from core.crypto import decrypt_config

        errs: List[str] = []
        for id_key, mapping in self.CONNECTION_FIELDS.items():
            conn_id = ctx.config.get(id_key)
            if not conn_id:
                continue  # legacy inline path — task already has the field
            try:
                conn_id_int = int(conn_id)
            except Exception:
                errs.append(f"{id_key} must be an integer connection id (got {conn_id!r})")
                continue
            try:
                with db_manager.get_session(read_only=True) as session:
                    row = session.query(Connection).filter(
                        Connection.id == conn_id_int,
                    ).first()
                    if row is None:
                        errs.append(f"connection id {conn_id_int} not found "
                                      f"(referenced by {id_key})")
                        continue
                    raw_cfg = dict(row.config or {})
                cfg = decrypt_config(raw_cfg)
            except Exception as exc:
                errs.append(f"could not resolve {id_key}={conn_id_int}: {exc}")
                continue
            # Phase 132.36 — AWS credential refresh.
            # When the Connection uses portal-based auth (no explicit
            # aws_access_key_id / aws_secret_access_key, but
            # portal_username + portal_password present), call the
            # portal flow to obtain fresh STS-issued AWS keys NOW so
            # the underlying ETL step gets working creds for the
            # current run.  Same helper as the S3 client builder
            # (core.s3_utilities) — single source of truth.  Fail-open
            # so on-prem / non-AWS connections aren't blocked by a
            # portal misconfiguration.
            try:
                from core.aws_portal_auth import inject_portal_creds
                effective_user = ctx.effective_user or "system"
                cfg = inject_portal_creds(cfg, effective_user)
            except Exception as _pe:
                # Log + continue — connections that don't use AWS at
                # all will hit this path and we shouldn't fail them.
                if logger:
                    logger.debug("portal cred injection skipped for %s: %s",
                                   id_key, _pe)
            # Merge mapped fields into the task dict.  Resolved values
            # take priority over any matching inline field (you can't
            # half-override credentials).
            for src_key, task_key in mapping.items():
                if src_key in cfg and cfg[src_key] is not None:
                    task[task_key] = cfg[src_key]
        return errs

    # ── Execute ─────────────────────────────────────────────────────

    def execute(self, ctx: StageContext) -> StageResult:
        # Phase 132.38 — apply the WHERE-mapping wrap to every SQL-bearing
        # config field this subclass declared via ``SQL_CONFIG_FIELDS``
        # BEFORE the ETL-framework gate.  The wrap is fast, side-effect-
        # free beyond a ctx.config mutation, and fail-open by design, so
        # running it unconditionally keeps the contract simple — even on
        # paths where the framework gate later returns failed, the wrap's
        # mutation of ctx.config is what tests + dry-runs need to inspect.
        for _sql_field in self.SQL_CONFIG_FIELDS:
            _orig = ctx.config.get(_sql_field)
            if isinstance(_orig, str) and _orig.strip():
                try:
                    _wrapped = self.apply_where_mapping_to_sql(_orig, ctx)
                    if _wrapped and _wrapped != _orig:
                        ctx.config[_sql_field] = _wrapped
                        ctx.log(f"WHERE-mapping wrapped {_sql_field}")
                except Exception as _w_exc:
                    ctx.log(f"WHERE-mapping wrap on {_sql_field} failed: {_w_exc}")

        # 2026-09-15 — a target that was never written fails with the same
        # sentence the manifest and validate_config carry, before any
        # path bootstrap or import is attempted.
        if self.UNAVAILABLE_REASON:
            return StageResult.failed(
                error=f"{self.NAME} cannot run: {self.UNAVAILABLE_REASON}")
        # The variant this config selects — the SAME function
        # validate_config gated on, so a stage that passed validation
        # imports exactly what validation checked.
        try:
            self.ETL_MODULE, self.ETL_CLASS = self.etl_target(ctx.config)
        except KeyError as exc:
            return StageResult.failed(error=f"{self.NAME}: {exc}")

        if not _ensure_etl_on_path():
            return StageResult.failed(
                error="ETL framework not installed (no ETL/steps/BaseStep.py "
                       "found on Python path; cannot import "
                       f"{self.ETL_MODULE}.{self.ETL_CLASS})",
            )

        try:
            mod = importlib.import_module(self.ETL_MODULE)
            cls = getattr(mod, self.ETL_CLASS)
        except Exception as exc:
            return StageResult.failed(
                error=f"failed to import {self.ETL_MODULE}.{self.ETL_CLASS}: {exc}",
            )

        # Build the task dict.  Precedence (later overrides earlier):
        #   1. config["task"]                (static admin defaults)
        #   2. config["..._*"] (top-level)   (legacy inline fields,
        #                                     e.g. sap_username on the
        #                                     SAP stage's CONFIG_SCHEMA)
        #   3. resolved connection fields    (encrypted creds via lookup)
        #   4. run_context                    (runtime parameters)
        #   5. prev_outputs                   (artefacts from earlier stages)
        task: Dict[str, Any] = {}
        if isinstance(ctx.config.get("task"), dict):
            task.update(ctx.config["task"])
        # Pass top-level scalar config fields (matching the stage's
        # CONFIG_SCHEMA) through to the underlying ETL step — many steps
        # read config keys like ``sap_username`` directly.
        for k, v in ctx.config.items():
            if k in ("task", "worker_connection", "dest_connection",
                       "step_name", "step_config"):
                continue
            if k in self.CONNECTION_FIELDS:
                continue  # connection_id keys are resolved separately below
            task.setdefault(k, v)
        # Phase 132.20 — credential resolution.  When a stage declares
        # CONNECTION_FIELDS, walk it and pull the encrypted creds off the
        # referenced Connection row.  Resolved values override inline.
        resolve_errs = self._resolve_connection_fields(ctx, task)
        if resolve_errs:
            return StageResult.failed(error="; ".join(resolve_errs))
        task.update({k: v for k, v in ctx.run_context.items()
                       if not k.startswith("_")})
        for alias, outs in ctx.prev_outputs.items():
            if isinstance(outs, dict):
                # Don't clobber explicit task keys — only fill blanks.
                for k, v in outs.items():
                    task.setdefault(k, v)

        worker_conn = ctx.get_config("worker_connection", "") or ""
        dest_conn   = ctx.get_config("dest_connection", "") or ""
        step_label  = ctx.get_config("step_name", self.NAME)

        # Instantiate the ETL step with stubbed dependencies.  Real
        # deployments wire real starburst_clients / oracle_data_manager
        # via SystemSetting / connection config; for now stubs are fine
        # — the step uses them defensively (None-checks before status writes).
        try:
            step = cls(
                starburst_clients={},
                oracle_data_manager=None,
                logger=logger,
                config=ctx.config.get("step_config", {}),
            )
        except Exception as exc:
            return StageResult.failed(error=f"failed to instantiate ETL step: {exc}")

        # Async-to-sync bridge.  asyncio.run requires no running loop —
        # the dispatcher runs each stage in its own thread, so a fresh
        # event loop here is safe.
        try:
            result = asyncio.run(step._execute_step(
                task=task,
                worker_connection_string=worker_conn,
                dest_connection_string=dest_conn,
                step_name=step_label,
            ))
        except Exception as exc:
            ctx.log(f"ETL step failed: {exc}")
            return StageResult.failed(error=f"{type(exc).__name__}: {exc}")

        # Harvest outputs — every task[] key listed in OUTPUT_KEYS plus
        # the raw return value (most steps return totalcount).
        outputs: Dict[str, Any] = {"return_value": result}
        for k in self.OUTPUT_KEYS:
            if k in task:
                outputs[k] = task[k]
        # The standard row_count alias other quality stages look for.
        if "totalcount" in task and "row_count" not in outputs:
            outputs["row_count"] = task["totalcount"]
        ctx.log(f"ETL step {self.NAME} completed — totalcount={task.get('totalcount')}")
        return StageResult.succeeded(outputs=outputs)


# ── Per-step subclasses ─────────────────────────────────────────────────
#
# One per ETL step name from config/step_mapping.yaml.  Each is a trivial
# 4-line declaration — the work all lives in _EtlBridgeBase.
#
# Naming convention: stage NAME = step_mapping yaml key in snake_case
# (e.g. "OracleToS3Parquet" → "oracle_to_s3_parquet").


@register
class CheckDependenciesStage(_EtlBridgeBase):
    NAME        = "check_dependencies"
    DISPLAY_NAME = "Check Upstream Dependencies"
    DESCRIPTION = "ETL: verify upstream deps before processing."
    CATEGORY    = CATEGORY_TRANSFORM
    ETL_MODULE  = "steps.check_dependencies"
    ETL_CLASS   = "CheckDependencies"


@register
class RenderSqlStage(_EtlBridgeBase):
    """Unified SQL renderer.  Picks generate_sql_onprem or _oncloud at
    runtime based on the ``location`` config.  Replaces the two explicit
    variants — see the user feedback "single config, not two".
    """
    NAME        = "render_sql"
    DISPLAY_NAME = "Render SQL Template"
    DESCRIPTION = "Render the SQL template for the configured location."
    CATEGORY    = CATEGORY_TRANSFORM
    # 2026-09-15 — ``steps.generate_sql_onprem`` / ``_oncloud`` never
    # existed.  OG's Phase 152 unified them: ONE ``GenerateSQL`` at
    # ``steps.file.generate_sql`` renders BOTH ``query_on_prem`` and
    # ``query_on_cloud`` (step_mapping.yaml ``file:`` / ``s3_to_file:`` /
    # ``s3_to_oracle:`` all map GenerateSQL there).  Both locations
    # therefore select the same class; ``location`` still reaches the
    # step through the task dict.
    ETL_VARIANTS = {"onprem": _GENERATE_SQL, "oncloud": _GENERATE_SQL}
    ETL_MODULE, ETL_CLASS = _GENERATE_SQL
    CONFIG_SCHEMA = {
        "location":     {"type": "string", "enum": ["onprem", "oncloud"],
                          "description": "Which Starburst route to render the SQL for."},
        "sql_template": {"type": "string",
                          "description": "SQL template with {param} placeholders."},
    }

    @classmethod
    def etl_variant_key(cls, config: Dict[str, Any]) -> str:
        # Default to onprem so a misconfigured DataFlow lands safely.
        location = str(config.get("location") or "onprem").lower().strip()
        return "oncloud" if location == "oncloud" else "onprem"

    def execute(self, ctx: StageContext) -> StageResult:
        self.ETL_MODULE, self.ETL_CLASS = self.etl_target(ctx.config)
        ctx.log(f"render_sql dispatching to {self.ETL_CLASS} "
                f"(location={self.etl_variant_key(ctx.config)})")
        return super().execute(ctx)


@register
class StarburstToFileStage(_EtlBridgeBase):
    """Unified Starburst → File bridge.

    Two config knobs combine to pick the right underlying ETL step:
      ``location`` : onprem | oncloud — which Starburst endpoint
      ``engine``   : default | spark   — whether to route through Spark
                                          for heavy extracts (>10M rows)

    Replaces four explicit variants (StarburstToFile{On,Cloud}{,Spark}).
    Same task dict, single DAG entry.
    """
    NAME        = "starburst_to_file"
    DESCRIPTION = ("Starburst → file (CSV / Parquet).  Set location=onprem|oncloud "
                     "and engine=default|spark to pick the route + execution engine.")
    CATEGORY    = CATEGORY_SOURCE
    # 2026-09-15 — paths and class names from step_mapping.yaml ``file:``.
    # The previous ``steps.starburst_to_file_onprem`` / ``StarburstToFileOnPrem``
    # existed nowhere: the modules live under ``steps.file`` and OG spells
    # the classes ``StarburstToFile_OnPrem`` (underscore).
    ETL_MODULE  = "steps.file.starburst_to_file_onprem"   # default variant
    ETL_CLASS   = "StarburstToFile_OnPrem"
    ETL_VARIANTS = {
        "onprem":        ("steps.file.starburst_to_file_onprem",
                          "StarburstToFile_OnPrem"),
        "oncloud":       ("steps.file.starburst_to_file_oncloud",
                          "StarburstToFile_OnCloud"),
        "onprem_spark":  ("steps.file.starburst_to_file_onprem_spark",
                          "StarburstToFile_OnPrem_Spark"),
        "oncloud_spark": ("steps.file.starburst_to_file_oncloud_spark",
                          "StarburstToFile_OnCloud_Spark"),
    }
    # Phase 132.34 — creds always via a Connection row (Starburst pattern).
    # Maps source_connection_id.{username, password} → trino_user / trino_password
    # at runtime so the underlying ETL step keys are unchanged.
    CONNECTION_FIELDS = {
        "source_connection_id": {
            "username": "trino_user",
            "password": "trino_password",
        },
    }
    CONFIG_SCHEMA = {
        "source_connection_id": {"type": "integer", "lookup": "connections",
                                    "description": "Starburst/Trino Connection (encrypted "
                                                    "creds).  Credentials NEVER live inline."},
        "location":     {"type": "string", "enum": ["onprem", "oncloud"],
                          "description": "Starburst route to extract from."},
        "engine":       {"type": "string", "enum": ["default", "spark"],
                          "description": "default = standard Trino client; spark = Spark JDBC for heavy loads."},
        "trino_onprem_url":    {"type": "string",
                                  "description": "Trino on-prem URL (used when location=onprem)."},
        "trino_oncloud_url":   {"type": "string",
                                  "description": "Trino cloud URL (used when location=oncloud)."},
        # Phase 132.36 — pick a saved .sql file from BQB / CQB instead of
        # pasting raw SQL into ``query_on_prem`` / ``query_on_cloud``.
        # When ``sql_file_id`` is set, its content fills BOTH legs (same
        # SQL on both routes — which is what users want 99% of the time).
        # To run different SQL per route, leave sql_file_id empty and
        # paste into query_on_prem / query_on_cloud directly.
        "sql_file_id":         {"type": "integer", "lookup": "sql_files",
                                  "description": "(RECOMMENDED) Saved .sql file "
                                                  "from BQB / CQB.  Fills both "
                                                  "query_on_prem and query_on_cloud "
                                                  "with the same SQL.  Leave inline "
                                                  "queries empty to use this."},
        "query_on_prem":       {"type": "string",
                                  "description": "(override) On-prem SQL — overrides "
                                                  "sql_file_id for this route only."},
        "query_on_cloud":      {"type": "string",
                                  "description": "(override) Cloud SQL — overrides "
                                                  "sql_file_id for this route only."},
        "output_dir":          {"type": "string", "description": "Local directory to write the file into."},
        "output_format":       {"type": "string", "enum": ["csv", "parquet", "json"]},
        "filename_template":   {"type": "string", "description": "Filename with {key} interpolation."},
        # Phase 132.38 — per-stage WHERE-clause mapping.  Same primitive
        # Published Views + Feed Gen + SqlQueryStage use.  Applied to
        # BOTH legs (query_on_prem AND query_on_cloud) after they are
        # resolved from sql_file_id, so a Static row locks the value
        # regardless of which route the run picks.
        "where_clauses":       {"type": "where_clauses",
                                  "description": "Per-stage Static / Dynamic WHERE-clause mapping."},
    }

    @classmethod
    def etl_variant_key(cls, config: Dict[str, Any]) -> str:
        location = str(config.get("location") or "onprem").lower().strip()
        engine = str(config.get("engine") or "default").lower().strip()
        key = "oncloud" if location == "oncloud" else "onprem"
        return key + ("_spark" if engine == "spark" else "")

    @classmethod
    def validate_config(cls, config):
        # 2026-09-15 — the runnability gate first (super), then the field
        # rules.  A stage that cannot run here is refused before its
        # fields are argued about.
        errs: list = list(super().validate_config(config))
        # Inline creds rejected — same rule as the rest of the platform.
        for k in ("trino_user", "trino_password"):
            if (config.get(k) or "").strip():
                errs.append(
                    f"inline {k!r} is not allowed — store creds in a "
                    f"Connection and reference via source_connection_id"
                )
        if not config.get("source_connection_id"):
            errs.append("source_connection_id is required (Connection holds Trino creds)")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        self.ETL_MODULE, self.ETL_CLASS = self.etl_target(ctx.config)

        # Phase 132.36 — load SQL from sql_file_id when inline query slots
        # are empty.  Mutates ctx.config in place so the base-class
        # task-dict builder downstream sees the resolved SQL strings.
        sql_file_id = ctx.get_config("sql_file_id")
        if sql_file_id:
            inline_prem = (ctx.get_config("query_on_prem") or "").strip()
            inline_cloud = (ctx.get_config("query_on_cloud") or "").strip()
            if not inline_prem or not inline_cloud:
                sql_text = self._load_sql_file_content(ctx, int(sql_file_id))
                if not inline_prem:
                    ctx.config["query_on_prem"] = sql_text
                if not inline_cloud:
                    ctx.config["query_on_cloud"] = sql_text
                ctx.log(
                    f"starburst_to_file loaded SQL from sql_file_id={sql_file_id} "
                    f"({len(sql_text)} chars) into "
                    f"{'both routes' if not (inline_prem or inline_cloud) else 'empty routes'}"
                )

        # Phase 132.38 — WHERE-mapping wrap is now handled generically by
        # ``_EtlBridgeBase.execute`` via the ``SQL_CONFIG_FIELDS`` tuple
        # (declared on this class below).  The previous per-stage loop
        # here was replaced so every EtlBridge subclass uses the same
        # primitive.

        ctx.log(f"starburst_to_file dispatching to {self.ETL_CLASS} "
                f"(variant={self.etl_variant_key(ctx.config)})")
        return super().execute(ctx)

    # Phase 132.38 — both legs carry SQL the publisher can categorise.
    SQL_CONFIG_FIELDS = ("query_on_prem", "query_on_cloud")

    @staticmethod
    def _load_sql_file_content(ctx: StageContext, sql_file_id: int) -> str:
        """Load the SQL body from a QueryStudio SqlFile row.

        Phase 132.36 hotfix-1: uses ``_load_sql_file_strict`` which
        raises a precise error naming the actual failure mode
        (not-found vs inactive vs missing path vs empty file vs read
        error) so admins can fix it without grepping logs.
        """
        if ctx.db_manager is None:
            raise RuntimeError(
                "db_manager unavailable to resolve sql_file_id "
                "(starburst_to_file)"
            )
        from core.dataflow.stages.sql_query_stage import SqlQueryStage
        return SqlQueryStage._load_sql_file_strict(
            ctx.db_manager, sql_file_id,
        )


# ── Starburst → Oracle: real schemas from steps/starburst_base.py ───────
# Required fields shared by both onprem + oncloud variants:
#   spark_jars, trino_user, trino_password, oracle_url, oracle_user,
#   oracle_password, plus the location-specific URL + QUERY keys.

_STARBURST_BASE_FIELDS: Dict[str, Any] = {
    # ── Connections (the user's preferred pattern) ─────────────────────
    # Connection IDs reference rows in QueryStudio's connections table,
    # which can be backed by SystemAccount entries.  Credentials are
    # resolved at run time by _EtlBridgeBase — admins NEVER paste
    # passwords into a DataFlow config.
    "source_connection_id": {"type": "integer", "lookup": "connections",
                                "description": "Starburst source connection.  Credentials "
                                                "resolve from this at run time."},
    "target_connection_id": {"type": "integer", "lookup": "connections",
                                "description": "Oracle target connection."},
    # SQL source — pick from .sql files (BQB / CQB) instead of pasting SQL
    "sql_file_id":          {"type": "integer", "lookup": "sql_files",
                                "description": "QueryStudio .sql file holding the source query."},
    "dest_table":            {"type": "string",
                                "description": "Oracle staging / target table — fully qualified "
                                                "SCHEMA.TABLE."},
    # ── Tuning knobs (rarely changed; defaults from StarburstBase) ─────
    "spark_jars":            {"type": "string",
                                "description": "Comma-separated paths to required Spark JARs."},
    "fetchsize":             {"type": "integer", "description": "JDBC fetch size (default 70000)."},
    "batch_size":            {"type": "integer", "description": "Spark write batch size (default 50000)."},
    "num_partitions":        {"type": "integer", "description": "Spark JDBC read partitions (default 10)."},
    "spark_executor_memory": {"type": "string", "description": "Spark executor memory (e.g. 15g)."},
    "spark_driver_memory":   {"type": "string", "description": "Spark driver memory (e.g. 4g)."},
    "spark_executor_memory_overhead": {"type": "string", "description": "Executor overhead memory (default 1g)."},
    "spark_driver_memory_overhead":   {"type": "string", "description": "Driver overhead memory (default 1g)."},
}


@register
class StarburstToOracleStage(_EtlBridgeBase):
    """Unified Starburst → Oracle bridge that picks on-prem or on-cloud
    at execute time based on the ``location`` config (defaults to onprem).

    Use this stage instead of the location-specific siblings — same task
    dict, one stage in the DAG, the only difference is the ``location``
    field set either as a global parameter or a per-step override.
    """
    NAME        = "starburst_to_oracle"
    DISPLAY_NAME = "Starburst → Oracle"
    DESCRIPTION = "Starburst → Oracle.  Set location=onprem|oncloud to route."
    CATEGORY    = CATEGORY_PIPELINE
    # These two resolve as declared: OG keeps flat ``steps/<name>.py``
    # back-compat shims that re-export ``steps.oracle.*`` (step_mapping.yaml
    # ``oracle:`` uses the same paths).
    ETL_MODULE  = "steps.starburst_to_oracle_onprem"   # default variant
    ETL_CLASS   = "StarburstToOracle_OnPrem"
    ETL_VARIANTS = {
        "onprem":  ("steps.starburst_to_oracle_onprem",  "StarburstToOracle_OnPrem"),
        "oncloud": ("steps.starburst_to_oracle_oncloud", "StarburstToOracle_OnCloud"),
    }
    CONFIG_SCHEMA = {
        "location": {"type": "string", "enum": ["onprem", "oncloud"],
                       "description": "Starburst route — onprem reads trino_onprem_url + query_on_prem;"
                                       " oncloud reads trino_oncloud_url + query_on_cloud."},
        **_STARBURST_BASE_FIELDS,
        "trino_onprem_url":  {"type": "string", "description": "Trino on-prem URL (used when location=onprem)."},
        "trino_oncloud_url": {"type": "string", "description": "Trino cloud URL (used when location=oncloud)."},
        "query_on_prem":     {"type": "string", "description": "SQL for on-prem extract."},
        "query_on_cloud":    {"type": "string", "description": "SQL for cloud extract."},
        # Phase 132.38 — same WHERE mapping every SQL-bearing stage has.
        "where_clauses":     {"type": "where_clauses",
                                "description": "Per-stage Static / Dynamic WHERE-clause mapping "
                                                "(applied to BOTH on-prem + on-cloud legs)."},
    }
    # Phase 132.38 — both legs receive the wrap.
    SQL_CONFIG_FIELDS = ("query_on_prem", "query_on_cloud")

    @classmethod
    def etl_variant_key(cls, config: Dict[str, Any]) -> str:
        # Default to onprem so a misconfigured DataFlow lands safely.
        location = str(config.get("location") or "onprem").lower().strip()
        return "oncloud" if location == "oncloud" else "onprem"

    def execute(self, ctx: StageContext) -> StageResult:
        self.ETL_MODULE, self.ETL_CLASS = self.etl_target(ctx.config)
        ctx.log(f"starburst_to_oracle dispatching to {self.ETL_CLASS} "
                f"(location={self.etl_variant_key(ctx.config)})")
        return super().execute(ctx)


# Note: there is intentionally ONLY ONE starburst_to_oracle stage type.
# Earlier phases registered explicit on-prem / on-cloud variants too;
# they were removed when the user clarified that the route choice should
# be a *config field* (location=onprem|oncloud), not a separate stage.


# ── Real CONFIG_SCHEMAs for the most-used X→Y "pipeline" stages.
# Pulled from each step's REQUIRED_FIELDS list + the .get() calls in
# _execute_step.  These mean the DAG builder side-drawer renders proper
# named inputs instead of a single giant JSON textarea.


_ORACLE_FIELDS: Dict[str, Any] = {
    "oracle_connection_id": {"type": "integer", "lookup": "connections",
                              "description": "Oracle connection (backed by SystemAccount).  "
                                              "Credentials resolve at run time."},
    "oracle_table":         {"type": "string",
                              "description": "Fully-qualified target / source table (SCHEMA.TABLE)."},
}

_S3_FIELDS: Dict[str, Any] = {
    "s3_connection_id": {"type": "integer", "lookup": "connections",
                          "description": "S3 connection (backed by SystemAccount).  No AWS keys in DataFlow."},
    "s3_bucket":        {"type": "string", "description": "Destination / source bucket name."},
    "s3_prefix":        {"type": "string",
                          "description": "Key prefix (e.g. fin/gl_balances/{business_date})."},
}


@register
class OracleToS3Stage(_EtlBridgeBase):
    """Unified Oracle → S3.  Picks Parquet or Iceberg writer based on
    the ``format`` config field.  Replaces the two explicit variants.
    """
    NAME        = "oracle_to_s3"
    DISPLAY_NAME = "Oracle → S3 (Parquet / Iceberg)"
    DESCRIPTION = ("Oracle → S3.  Set format=parquet|iceberg to pick the writer. "
                     "Iceberg gets ACID + time-travel; Parquet is simpler.")
    CATEGORY    = CATEGORY_PIPELINE
    # 2026-09-15 — the writers live under ``steps.oracle`` (there is no flat
    # shim for them; step_mapping.yaml dropped the oracle_to_s3 entries
    # 2026-06-22 as "not currently used anywhere").
    ETL_VARIANTS = {
        "parquet": ("steps.oracle.oracle_to_s3_parquet", "OracleToS3Parquet"),
        "iceberg": ("steps.oracle.oracle_to_s3_iceberg", "OracleToS3Iceberg"),
    }
    ETL_MODULE, ETL_CLASS = ETL_VARIANTS["parquet"]   # default variant
    CONFIG_SCHEMA = {
        "format": {"type": "string", "enum": ["parquet", "iceberg"],
                    "description": "Output format on S3 (parquet=plain files, iceberg=ACID table)."},
        **_ORACLE_FIELDS, **_S3_FIELDS,
        "source_query":          {"type": "string",
                                    "description": "SQL to run against Oracle (supports {param} placeholders)."},
        "s3_partition_columns":  {"type": "array",
                                    "description": "Columns to partition the output by."},
        "num_partitions":        {"type": "integer",
                                    "description": "Spark write partitions (default 10)."},
        "iceberg_table":         {"type": "string",
                                    "description": "Iceberg table name (only when format=iceberg)."},
        "partition_spec":        {"type": "string",
                                    "description": "Iceberg partition spec (only when format=iceberg)."},
        # Phase 132.38 — Static / Dynamic WHERE mapping applied to
        # ``source_query`` (the Oracle-side SQL) before dispatch.
        "where_clauses":         {"type": "where_clauses",
                                    "description": "Per-stage Static / Dynamic WHERE-clause mapping "
                                                    "(applied to source_query)."},
    }
    # Phase 132.38 — only the Oracle-side query is wrapped.  The Iceberg
    # /Parquet writer doesn't take SQL.
    SQL_CONFIG_FIELDS = ("source_query",)

    @classmethod
    def etl_variant_key(cls, config: Dict[str, Any]) -> str:
        fmt = str(config.get("format") or "parquet").lower().strip()
        return "iceberg" if fmt == "iceberg" else "parquet"

    def execute(self, ctx: StageContext) -> StageResult:
        self.ETL_MODULE, self.ETL_CLASS = self.etl_target(ctx.config)
        ctx.log(f"oracle_to_s3 dispatching to {self.ETL_CLASS} "
                f"(format={self.etl_variant_key(ctx.config)})")
        return super().execute(ctx)


@register
class S3ToOracleStage(_EtlBridgeBase):
    """Unified S3 → Oracle.  Picks Parquet or Iceberg reader based on the
    ``format`` config field.
    """
    NAME        = "s3_to_oracle"
    DISPLAY_NAME = "S3 → Oracle (Parquet / Iceberg)"
    DESCRIPTION = ("S3 → Oracle.  Set format=parquet|iceberg to pick the reader. "
                     "Iceberg supports snapshot_id for time-travel reads.")
    CATEGORY    = CATEGORY_PIPELINE
    # 2026-09-15 — readers live under ``steps.s3_to_oracle`` (no flat shim).
    ETL_VARIANTS = {
        "parquet": ("steps.s3_to_oracle.s3_parquet_to_oracle", "S3ParquetToOracle"),
        "iceberg": ("steps.s3_to_oracle.s3_iceberg_to_oracle", "S3IcebergToOracle"),
    }
    ETL_MODULE, ETL_CLASS = ETL_VARIANTS["parquet"]   # default variant
    CONFIG_SCHEMA = {
        "format": {"type": "string", "enum": ["parquet", "iceberg"]},
        **_ORACLE_FIELDS, **_S3_FIELDS,
        "iceberg_table":  {"type": "string",
                            "description": "Iceberg source table (when format=iceberg)."},
        "snapshot_id":    {"type": "string",
                            "description": "Optional snapshot id (when format=iceberg)."},
        "load_mode":      {"type": "string", "enum": ["append", "overwrite", "merge"],
                            "description": "How to land the rows into Oracle."},
    }

    @classmethod
    def etl_variant_key(cls, config: Dict[str, Any]) -> str:
        fmt = str(config.get("format") or "parquet").lower().strip()
        return "iceberg" if fmt == "iceberg" else "parquet"

    def execute(self, ctx: StageContext) -> StageResult:
        self.ETL_MODULE, self.ETL_CLASS = self.etl_target(ctx.config)
        ctx.log(f"s3_to_oracle dispatching to {self.ETL_CLASS} "
                f"(format={self.etl_variant_key(ctx.config)})")
        return super().execute(ctx)


@register
class S3ToS3TransformStage(_EtlBridgeBase):
    NAME        = "s3_to_s3_transform"
    DISPLAY_NAME = "S3 → S3 Transform"
    DESCRIPTION = "S3 → S3 transform.  Read one prefix, apply DuckDB SQL, write another prefix."
    CATEGORY    = CATEGORY_PIPELINE
    # 2026-09-15 — lives under ``steps.s3`` (no flat shim).
    ETL_MODULE  = "steps.s3.s3_to_s3_transform"
    ETL_CLASS   = "S3ToS3Transform"
    CONFIG_SCHEMA = {
        **_S3_FIELDS,
        "source_prefix":        {"type": "string", "description": "Source key prefix."},
        "dest_prefix":          {"type": "string", "description": "Destination key prefix."},
        "transform_sql":        {"type": "string",
                                  "description": "DuckDB SQL applied to the source files (read as 'src')."},
        "output_format":        {"type": "string", "enum": ["parquet", "csv", "json"]},
        "partition_columns":    {"type": "array",
                                  "description": "Columns to partition the output by."},
        # Phase 132.38 — Static / Dynamic WHERE mapping applied to the
        # DuckDB transform SQL before it runs.
        "where_clauses":        {"type": "where_clauses",
                                  "description": "Per-stage Static / Dynamic WHERE-clause mapping "
                                                  "(applied to transform_sql)."},
    }
    # Phase 132.38 — wrap the DuckDB transform SQL.
    SQL_CONFIG_FIELDS = ("transform_sql",)


@register
class FileToOracleStage(_EtlBridgeBase):
    """Unified File → Oracle ingest.  Picks CSV or Parquet loader based
    on the ``format`` config field.
    """
    NAME        = "file_to_oracle"
    DISPLAY_NAME = "File → Oracle (CSV / Parquet)"
    DESCRIPTION = ("File → Oracle bulk load.  Set format=csv|parquet to pick the reader.")
    CATEGORY    = CATEGORY_PIPELINE
    # 2026-09-15 — both loaders live under ``steps.oracle`` (no flat shim).
    # Note ``steps.file_to_oracle.parquet_to_oracle`` ALSO declares a
    # ``ParquetFileToOracle`` (the Spark-based file_to_oracle workflow);
    # the ``steps.oracle`` one is the sibling of the CSV loader this stage
    # already named and matches the declared module name exactly.
    ETL_VARIANTS = {
        "csv":     ("steps.oracle.csv_file_to_oracle",     "CsvFileToOracle"),
        "parquet": ("steps.oracle.parquet_file_to_oracle", "ParquetFileToOracle"),
    }
    ETL_MODULE, ETL_CLASS = ETL_VARIANTS["csv"]   # default variant
    CONFIG_SCHEMA = {
        "format": {"type": "string", "enum": ["csv", "parquet"]},
        **_ORACLE_FIELDS,
        "file_path":     {"type": "string", "description": "Local file path (supports {key} interpolation)."},
        "delimiter":     {"type": "string", "description": "CSV delimiter (default ',', csv only)."},
        "header":        {"type": "boolean", "description": "CSV has header row (default true, csv only)."},
        "infer_schema":  {"type": "boolean", "description": "Auto-infer column types (default true, csv only)."},
        "encoding":      {"type": "string", "description": "File encoding (default UTF-8, csv only)."},
        "load_mode":     {"type": "string", "enum": ["append", "overwrite", "merge"]},
    }

    @classmethod
    def etl_variant_key(cls, config: Dict[str, Any]) -> str:
        fmt = str(config.get("format") or "csv").lower().strip()
        return "parquet" if fmt == "parquet" else "csv"

    def execute(self, ctx: StageContext) -> StageResult:
        self.ETL_MODULE, self.ETL_CLASS = self.etl_target(ctx.config)
        ctx.log(f"file_to_oracle dispatching to {self.ETL_CLASS} "
                f"(format={self.etl_variant_key(ctx.config)})")
        return super().execute(ctx)


@register
class ConsolidateFilesStage(_EtlBridgeBase):
    NAME        = "consolidate_files"
    DISPLAY_NAME = "Consolidate / Merge Files"
    DESCRIPTION = "ETL: merge per-group output files into a single file."
    CATEGORY    = CATEGORY_TRANSFORM
    # 2026-09-15 — the four delivery-chain stages below take their paths
    # from step_mapping.yaml ``s3_to_file:`` (ConsolidateFiles /
    # CompressFiles / CreateCTLFile / DeliverFiles), the section whose
    # module names match what these stages already declared.  The
    # ``file:`` workflow has its own siblings (``steps.file.merge_files``,
    # ``compress_file``, ``create_ctl_file``) with different class names;
    # they are a different chain and are not what this bridge described.
    ETL_MODULE  = "steps.s3_to_file.consolidate_files"
    ETL_CLASS   = "ConsolidateFiles"


@register
class CompressFilesStage(_EtlBridgeBase):
    NAME        = "compress_files"
    DISPLAY_NAME = "Compress Files"
    DESCRIPTION = "ETL: gzip / zip the produced files."
    CATEGORY    = CATEGORY_TRANSFORM
    ETL_MODULE  = "steps.s3_to_file.compress_files"
    ETL_CLASS   = "CompressFiles"


@register
class CreateCtlFileStage(_EtlBridgeBase):
    NAME        = "create_ctl_file"
    DISPLAY_NAME = "Create Control (CTL) File"
    DESCRIPTION = "ETL: emit a CTL control file for the delivery."
    CATEGORY    = CATEGORY_SINK
    # The yaml KEY is CreateCTLFile; the CLASS is CreateControlFile.  The
    # bridge had copied the key as the class name — no module anywhere
    # declares ``CreateCTLFile``.
    ETL_MODULE  = "steps.s3_to_file.create_ctl_file"
    ETL_CLASS   = "CreateControlFile"


@register
class DeliverFilesStage(_EtlBridgeBase):
    NAME        = "deliver_files"
    DISPLAY_NAME = "Deliver Files (SFTP / S3 / NFS)"
    DESCRIPTION = "ETL: deliver files to the destination (SFTP / S3 / share)."
    CATEGORY    = CATEGORY_SINK
    ETL_MODULE  = "steps.s3_to_file.deliver_files"
    ETL_CLASS   = "DeliverFiles"
    # Phase 132.20 — SFTP / S3 creds via Connection (encrypted), not inline.
    # NFS delivery doesn't need credentials so the connection_id is optional.
    CONNECTION_FIELDS = {
        "sftp_connection_id": {
            "host":      "sftp_host",
            "port":      "sftp_port",
            "username":  "sftp_username",
            "password":  "sftp_password",
            "key_path":  "sftp_key_path",
        },
        "s3_connection_id": {
            "access_key": "s3_access_key",
            "secret_key": "s3_secret_key",
            "region":     "s3_region",
        },
    }
    CONFIG_SCHEMA = {
        "delivery_type":         {"type": "string", "enum": ["nfs", "sftp", "s3"]},
        "sftp_connection_id":    {"type": "integer", "lookup": "connections",
                                    "description": "Connection holding SFTP host/user/password "
                                                    "(only for delivery_type=sftp)."},
        "s3_connection_id":      {"type": "integer", "lookup": "connections",
                                    "description": "Connection holding S3 access_key/secret_key "
                                                    "(only for delivery_type=s3)."},
        "sftp_remote_dir":       {"type": "string"},
        "s3_bucket":             {"type": "string"},
        "s3_prefix":             {"type": "string"},
        # Legacy inline fields — kept for backwards compat.
        "sftp_host":             {"type": "string",
                                    "description": "(legacy) — prefer sftp_connection_id."},
        "sftp_port":             {"type": "integer"},
        "sftp_username":         {"type": "string",
                                    "description": "(legacy) — prefer sftp_connection_id."},
        "sftp_password":         {"type": "string",
                                    "description": "(legacy) — prefer sftp_connection_id."},
        "sftp_key_path":         {"type": "string"},
        "s3_access_key":         {"type": "string",
                                    "description": "(legacy) — prefer s3_connection_id."},
        "s3_secret_key":         {"type": "string",
                                    "description": "(legacy) — prefer s3_connection_id."},
        "s3_region":             {"type": "string"},
    }


@register
class CheckCompletenessStage(_EtlBridgeBase):
    NAME        = "check_completeness"
    DISPLAY_NAME = "Check File Completeness"
    DESCRIPTION = "ETL: post-flight integrity check (row count / checksum)."
    CATEGORY    = CATEGORY_TRANSFORM
    ETL_MODULE  = "steps.check_completeness"
    ETL_CLASS   = "CheckCompleteness"


@register
class ProcessDataStage(_EtlBridgeBase):
    NAME        = "process_data"
    DISPLAY_NAME = "Process Data (Oracle PL/SQL)"
    DESCRIPTION = "ETL: generic in-place data transform step."
    CATEGORY    = CATEGORY_TRANSFORM
    ETL_MODULE  = "steps.process_data"
    ETL_CLASS   = "ProcessData"


@register
class ClearStagingStage(_EtlBridgeBase):
    NAME        = "clear_staging"
    DISPLAY_NAME = "Clear / Truncate Staging"
    DESCRIPTION = "ETL: truncate / clear staging table or directory before load."
    CATEGORY    = CATEGORY_TRANSFORM
    ETL_MODULE  = "steps.clear_staging"
    ETL_CLASS   = "ClearStaging"


# ── Explicit pre-load / post-load Oracle procedure stages ───────────────
# Same underlying ETL classes as ClearStaging / ProcessData, registered
# under more descriptive names so admins see the intent at a glance.


_ORACLE_PROC_FIELDS: Dict[str, Any] = {
    "oracle_url":      {"type": "string", "description": "Oracle JDBC URL."},
    "oracle_user":     {"type": "string"},
    "oracle_password": {"type": "string"},
    "procedure_name":  {"type": "string",
                          "description": "Fully-qualified PL/SQL procedure (SCHEMA.PROC)."},
    "procedure_args":  {"type": "array",
                          "description": "Optional ordered list of arguments."},
}


@register
class OraclePreloadProcedureStage(_EtlBridgeBase):
    """Pre-load Oracle procedure — runs BEFORE the extract / load stages.

    Typical use: truncate staging, set partition flags, archive previous
    snapshot.  Maps to the existing ETL ClearStaging step but exposes
    procedure_name + procedure_args explicitly in the schema.
    """
    NAME        = "oracle_preload_procedure"
    DISPLAY_NAME = "Oracle Pre-load Procedure"
    DESCRIPTION = "Execute an Oracle PL/SQL procedure before the load (truncate / archive / setup)."
    CATEGORY    = CATEGORY_TRANSFORM
    ETL_MODULE  = "steps.clear_staging"
    ETL_CLASS   = "ClearStaging"
    CONFIG_SCHEMA = _ORACLE_PROC_FIELDS


@register
class OraclePostloadProcedureStage(_EtlBridgeBase):
    """Post-load Oracle procedure — runs AFTER the load + completeness check.

    Typical use: aggregate, build indices, flip rotation pointer, push
    metrics to a downstream table.  Maps to the existing ProcessData
    step but exposes procedure_name + args explicitly.
    """
    NAME        = "oracle_postload_procedure"
    DISPLAY_NAME = "Oracle Post-load Procedure"
    DESCRIPTION = "Execute an Oracle PL/SQL procedure after the load (aggregate / index / flip)."
    CATEGORY    = CATEGORY_TRANSFORM
    ETL_MODULE  = "steps.process_data"
    ETL_CLASS   = "ProcessData"
    CONFIG_SCHEMA = _ORACLE_PROC_FIELDS


@register
class PreDataValidationStage(_EtlBridgeBase):
    NAME        = "pre_data_validation"
    DISPLAY_NAME = "Pre-load Data Validation"
    DESCRIPTION = "ETL: pre-flight data shape / partition validation."
    CATEGORY    = CATEGORY_TRANSFORM
    # 2026-09-15 — THIS STEP WAS NEVER WRITTEN.  ``steps.pre_data_validation``
    # exists in no ETL tree; OG removed its step_mapping.yaml entry on
    # 2026-07-30 with "no such module".  The stage stays registered because
    # three built-in templates and any existing DAG row name it, but the
    # manifest, validate_config and execute all say this rather than let a
    # path that can never import fail as "ModuleNotFoundError".
    ETL_MODULE  = "steps.pre_data_validation"
    ETL_CLASS   = "PreDataValidation"
    UNAVAILABLE_REASON = (
        "the ETL step this stage bridges to (steps.pre_data_validation."
        "PreDataValidation) was never written — no ETL tree contains it and "
        "OG removed it from ETL/configs/step_mapping.yaml on 2026-07-30; "
        "remove the stage from the DAG or implement the step in ETL/ first")


# NOTE: ``send_email_notifications`` used to bridge to
# ``ETL/steps/send_email_notifications.py`` — a file that does not exist
# on disk.  As of Phase 132.20, the legacy NAME is registered (with
# lenient validation) by ``send_email_stage.py`` so existing templates
# keep loading.  New DAGs should use ``send_email`` instead.


@register
class SapOdataDownloadStage(_EtlBridgeBase):
    """SAP OData download (group-aware).

    Reads steps/sap_odata_download.py REQUIRED_FIELDS so the side-drawer
    renders proper inputs for every parameter.  The download is
    bin-packed across company-code groups + paginated via $top/$skip;
    a checkpoint file lets failed groups be re-run without restarting
    the whole download.
    """
    NAME        = "sap_odata_download"
    DISPLAY_NAME = "SAP — Multi-Company OData Download"
    DESCRIPTION = "SAP OData → per-group CSV files (with group-level checkpointing)."
    CATEGORY    = CATEGORY_SOURCE
    # 2026-09-15 — lives under ``steps.sap`` (step_mapping.yaml ``sap_odata:``);
    # the same wrong flat path the SAP decomposed stages carried until
    # 2026-08-19.
    ETL_MODULE  = "steps.sap.sap_odata_download"
    ETL_CLASS   = "SapOdataDownload"
    # Phase 132.20 — resolve creds from a QueryStudio Connection (encrypted),
    # so the DAG only carries an integer id, not username/password strings.
    # The Connection.config must have keys: base_url, username, password.
    CONNECTION_FIELDS = {
        "sap_connection_id": {
            "base_url": "sap_base_url",
            "username": "sap_username",
            "password": "sap_password",
        },
    }
    CONFIG_SCHEMA = {
        "sap_connection_id":     {"type": "integer", "lookup": "connections",
                                    "description": "QueryStudio Connection holding "
                                                    "the SAP base_url + username + password "
                                                    "(encrypted).  Credentials NEVER live "
                                                    "inline — same rule as Starburst/Trino "
                                                    "stages."},
        "odata_service_path":    {"type": "string",
                                    "description": "OData service path (e.g. /sap/opu/odata/sap/ZMEBAL_SRV)."},
        "company_code_endpoint": {"type": "string",
                                    "description": "Endpoint that returns the list of company codes to download."},
        "output_dir":            {"type": "string",
                                    "description": "Local directory to write the per-group CSV files into."},
        "num_groups":            {"type": "integer",
                                    "description": "Number of company-code groups for bin-packing (default 5)."},
        "max_parallel_groups":   {"type": "integer",
                                    "description": "Concurrent groups to download at once (default 3)."},
        "period_mode":           {"type": "string",
                                    "enum": ["current", "prev_eom", "explicit"],
                                    "description": "Fiscal period derivation strategy."},
        "p_gjahr":               {"type": "string",
                                    "description": "Fiscal year (only when period_mode=explicit)."},
        "p_poper":               {"type": "string",
                                    "description": "Fiscal period (only when period_mode=explicit)."},
        "group_history_path":    {"type": "string",
                                    "description": "Path to the group-history JSON (used for bin-packing)."},
        "top_per_page":          {"type": "integer",
                                    "description": "$top page size for OData pagination."},
        "request_timeout_seconds": {"type": "integer"},
    }
