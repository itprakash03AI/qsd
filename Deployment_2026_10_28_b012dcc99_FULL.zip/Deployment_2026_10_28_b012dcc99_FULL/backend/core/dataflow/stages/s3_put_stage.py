"""``S3PutStage`` — upload a local file to S3 via boto3.

Reuses any S3 connection_id configured in QueryStudio (the same
connection rows that feed_gen + Published API use).  When no
connection_id is set, falls back to environment-default AWS creds.

This is intentionally a thin wrapper — no chunked multipart uploads,
no per-byte progress, no SSE-KMS plumbing.  Those concerns belong in a
follow-up phase that integrates with the existing ``core.s3_*`` helpers
(``s3_utilities``, ``credential_manager``, ``proxy_utils``).

Config:
    ``connection_id`` : int — QueryStudio connection row (preferred)
    ``bucket``        : str (required)
    ``key``           : str (required) — supports ``{key}`` interpolation
    ``local_path``    : str — file to upload (required if ``content`` not set)
    ``content``       : str — write this literal content (if ``local_path`` absent)
    ``content_type``  : str — Content-Type header (optional)
    ``input_source``  : when local_path == "from_input" — pull from prev stage
"""
from __future__ import annotations

from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_SINK, IDEMPOTENT_SAFE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class S3PutStage(BaseStage):
    NAME = "s3_put"
    DISPLAY_NAME = "Upload to S3"
    CATEGORY = CATEGORY_SINK
    DESCRIPTION = "Upload a file or literal content to S3."
    IDEMPOTENCY = IDEMPOTENT_SAFE   # PutObject is idempotent by key
    CONFIG_SCHEMA = {
        "connection_id": {"type": "integer"},
        "bucket":        {"type": "string"},
        "key":           {"type": "string"},
        "local_path":    {"type": "string"},
        "content":       {"type": "string"},
        "content_type":  {"type": "string"},
        "input_source":  {"type": "object"},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        if not config.get("bucket"):
            errs.append("bucket is required")
        if not config.get("key"):
            errs.append("key is required")
        if not config.get("local_path") and config.get("content") is None:
            errs.append("either local_path or content is required")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        bucket = ctx.get_config("bucket")
        key_template = ctx.get_config("key", "")
        try:
            key = key_template.format(**ctx.run_context)
        except Exception:
            key = key_template
        local_path = ctx.get_config("local_path")
        content = ctx.get_config("content")
        content_type = ctx.get_config("content_type")
        connection_id = ctx.get_config("connection_id")

        # Resolve payload
        body: bytes
        try:
            if local_path:
                try:
                    local_path = local_path.format(**ctx.run_context)
                except Exception as _tpl_exc:
                    ctx.log(f"path templating skipped: {_tpl_exc}")
                with open(local_path, "rb") as fh:
                    body = fh.read()
            else:
                if content == "from_input":
                    src = ctx.get_config("input_source", {}) or {}
                    alias = src.get("alias")
                    sk = src.get("key", "content")
                    value = ctx.get_input(alias, sk) if alias else None
                    if value is None:
                        return StageResult.failed(error="from_input source not found")
                    content = value
                if isinstance(content, str):
                    body = content.encode("utf-8")
                elif isinstance(content, bytes):
                    body = content
                else:
                    body = str(content).encode("utf-8")
        except Exception as exc:
            return StageResult.failed(error=f"failed to load payload: {exc}")

        # Resolve S3 client
        try:
            client = self._open_s3_client(connection_id, ctx)
        except Exception as exc:
            return StageResult.failed(error=f"failed to open S3 client: {exc}")

        try:
            put_kwargs: Dict[str, Any] = {"Bucket": bucket, "Key": key, "Body": body}
            if content_type:
                put_kwargs["ContentType"] = content_type
            client.put_object(**put_kwargs)
            ctx.log(f"s3 put: s3://{bucket}/{key} ({len(body)} bytes)")
            return StageResult.succeeded(outputs={
                "bucket": bucket, "key": key, "bytes": len(body),
                "uri":   f"s3://{bucket}/{key}",
            })
        except Exception as exc:
            return StageResult.failed(error=f"s3 put_object failed: {exc}")

    @staticmethod
    def _open_s3_client(connection_id: Any, ctx: StageContext):
        """Open a boto3 S3 client.  Best-effort integration with the
        project's connection registry; falls back to default AWS creds.
        """
        try:
            if connection_id and ctx.db_manager is not None:
                # 2026-09-01 -- ``build_s3_client_for_connection`` does not
                # exist in core.s3_utilities and never has.  The ImportError
                # hit the handler below, so this stage ALWAYS logged
                # "connection-based S3 client unavailable" and fell back to
                # default boto3 credentials -- ignoring the connection the
                # author selected, including its endpoint, SSL settings and
                # auth mode.  On an on-prem object store that is not a
                # degraded write, it is a write to the wrong place or none
                # at all.
                from core.s3_utilities import make_s3_client_for_conn  # type: ignore
                _conn_raw = ctx.db_manager.get_connection_raw(
                    int(connection_id))
                if _conn_raw:
                    return make_s3_client_for_conn(_conn_raw)
        except Exception as exc:
            ctx.log(f"connection-based S3 client unavailable: {exc}; "
                    "falling back to default boto3 session")
        import boto3  # type: ignore
        return boto3.client("s3")
