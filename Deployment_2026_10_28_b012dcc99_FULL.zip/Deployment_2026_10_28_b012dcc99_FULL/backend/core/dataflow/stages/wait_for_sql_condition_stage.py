"""``WaitForSqlConditionStage`` — poll a SQL query until it returns truthy.

Mirrors Airflow's ``SqlSensor``.  Use to wait on:
* an upstream table being populated for today
* a status row flipping to DONE
* a row count crossing a threshold

Config:
    ``sql``           : str (required) — SQL that returns 0+ rows.
                        Considered TRUE when the first column of the
                        first row is truthy (non-null, non-zero, non-empty).
    ``sql_file_id``   : int — load SQL from a .sql file instead.
    ``saved_query_id``: int — load from a saved query.
    ``connection_id`` : int — connection to run against (placeholder;
                        currently uses DuckDB in-memory like sql_query).
    ``poll_seconds``  : int (default 30)
    ``timeout_seconds`` : int (default 3600)
"""
from __future__ import annotations

import time
from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_CONTROL, IDEMPOTENT_SAFE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class WaitForSqlConditionStage(BaseStage):
    NAME = "wait_for_sql_condition"
    DISPLAY_NAME = "Wait for SQL Condition"
    CATEGORY = CATEGORY_CONTROL
    IS_CONTROL_FLOW = True
    IDEMPOTENCY = IDEMPOTENT_SAFE
    DESCRIPTION = ("Poll a SQL query until the first column of the first row "
                     "is truthy (or until timeout).  Use to gate a DAG on a "
                     "DB state change.")
    CONFIG_SCHEMA = {
        "sql":             {"type": "string",
                              "description": "Inline SQL.  Supports {key} interpolation."},
        "sql_file_id":     {"type": "integer", "lookup": "sql_files"},
        "saved_query_id":  {"type": "integer", "lookup": "saved_queries"},
        "connection_id":   {"type": "integer", "lookup": "connections",
                              "description": "Connection to execute against (default: DuckDB in-memory)."},
        "poll_seconds":    {"type": "integer", "minimum": 1,
                              "description": "Poll cadence in seconds (default 30)."},
        "timeout_seconds": {"type": "integer", "minimum": 1,
                              "description": "Max wait time in seconds (default 3600)."},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        if not (config.get("sql") or config.get("sql_file_id")
                or config.get("saved_query_id")):
            errs.append("one of sql / sql_file_id / saved_query_id is required")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        # Reuse the same SQL-source loader as sql_query so admins get
        # consistent behaviour.
        from core.dataflow.stages.sql_query_stage import SqlQueryStage

        sql_template = ""
        if ctx.get_config("sql_file_id") and ctx.db_manager is not None:
            sql_template = SqlQueryStage._load_sql_file(
                ctx.db_manager, int(ctx.get_config("sql_file_id")))
        if not sql_template and ctx.get_config("saved_query_id") and ctx.db_manager is not None:
            sql_template = SqlQueryStage._load_saved_query_sql(
                ctx.db_manager, int(ctx.get_config("saved_query_id")))
        if not sql_template:
            sql_template = ctx.get_config("sql", "")

        if not sql_template.strip():
            return StageResult.failed(error="no SQL provided")

        try:
            sql = sql_template.format(**ctx.run_context)
        except Exception as exc:
            return StageResult.failed(error=f"SQL templating failed: {exc}")

        # BF-571/572 audit fix: normalise cross-dialect format
        # specifiers + DATE_FORMAT/format_datetime/to_iso8601 calls
        # so Starburst/Trino/MySQL SQL works on DuckDB unchanged.
        try:
            from core.duckdb_format_normaliser import normalise_strftime_formats as _norm
            sql, _ff = _norm(sql)
            if _ff:
                ctx.log(
                    f"BF-571/572 auto-fixed {len(_ff)} format specifier(s) "
                    f"in condition SQL"
                )
        except Exception:
            pass  # fail-open

        poll = max(1, int(ctx.get_config("poll_seconds", 30)))
        timeout = max(poll, int(ctx.get_config("timeout_seconds", 3600)))

        ctx.log(f"waiting for SQL condition; poll={poll}s, timeout={timeout}s")
        ctx.log(f"sql: {sql[:120]}{'…' if len(sql) > 120 else ''}")

        # Open a DuckDB connection once + reuse across polls.
        try:
            import duckdb
            con = duckdb.connect(database=":memory:")
        except Exception as exc:
            return StageResult.failed(error=f"DuckDB unavailable: {exc}")

        deadline = time.time() + timeout
        try:
            while time.time() < deadline:
                if ctx.is_cancelled():
                    return StageResult.failed(error="cancelled while polling")
                try:
                    row = con.execute(sql).fetchone()
                    if row is not None and row[0]:
                        ctx.log(f"condition met — first value = {row[0]!r}")
                        return StageResult.succeeded(outputs={
                            "first_value": row[0],
                            "row":         list(row),
                        })
                except Exception as exc:
                    ctx.log(f"poll error (will retry): {exc}")
                time.sleep(min(poll, max(1, deadline - time.time())))
        finally:
            try:
                con.close()
            except Exception:
                pass

        return StageResult.failed(
            error=f"timeout after {timeout}s without truthy result",
            outputs={"timed_out": True},
        )
