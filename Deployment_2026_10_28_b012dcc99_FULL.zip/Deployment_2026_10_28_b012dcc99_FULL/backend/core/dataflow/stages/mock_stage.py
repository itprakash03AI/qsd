"""``MockStage`` — config-driven success/failure stage used by tests.

Not registered in production by default — opt-in via the registry's
``discover()`` call.  Use cases:
* Unit-test dispatcher behaviour (success, failure, branch, skip)
  without depending on any external system.
* Smoke-test a new deployment ("admin runs a 3-stage mock dataflow").
"""
from __future__ import annotations

from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_TRANSFORM, IDEMPOTENT_SAFE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


@register
class MockStage(BaseStage):
    """Returns a result determined by stage_config.

    Config keys:
        ``result``      : "succeeded" | "failed" | "skipped" | "branch_to"  (default "succeeded")
        ``error``       : str — error message when result="failed"
        ``branch_to``   : str — stage_alias when result="branch_to"
        ``outputs``     : dict — emitted as StageResult.outputs
        ``context_updates`` : dict — merged into run_context
    """

    NAME = "mock"
    DISPLAY_NAME = "Mock Stage (testing)"
    CATEGORY = CATEGORY_TRANSFORM
    DESCRIPTION = "Config-driven success/failure stage (testing only)."
    IDEMPOTENCY = IDEMPOTENT_SAFE
    CONFIG_SCHEMA = {
        "result": {"type": "string", "enum": ["succeeded", "failed",
                                                "skipped", "branch_to"]},
        "error": {"type": "string"},
        "branch_to": {"type": "string"},
        "outputs": {"type": "object"},
        "context_updates": {"type": "object"},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        result = config.get("result", "succeeded")
        if result not in {"succeeded", "failed", "skipped", "branch_to"}:
            errs.append(f"result must be succeeded|failed|skipped|branch_to, got {result!r}")
        if result == "branch_to" and not config.get("branch_to"):
            errs.append("result='branch_to' requires a 'branch_to' alias")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        result = ctx.get_config("result", "succeeded")
        outputs = ctx.get_config("outputs", {}) or {}
        context_updates = ctx.get_config("context_updates", {}) or {}
        ctx.log(f"mock stage {ctx.stage_alias} firing with result={result}")

        if result == "failed":
            return StageResult.failed(
                error=ctx.get_config("error", "mock failure"),
                outputs=outputs,
                context_updates=context_updates,
            )
        if result == "skipped":
            return StageResult.skipped(
                reason=ctx.get_config("error", "mock skipped"),
                outputs=outputs,
                context_updates=context_updates,
            )
        if result == "branch_to":
            return StageResult.branched(
                branch_to=ctx.get_config("branch_to"),
                outputs=outputs,
                context_updates=context_updates,
            )
        return StageResult.succeeded(
            outputs=outputs,
            context_updates=context_updates,
        )
