"""``MergeRecordsStage`` — NiFi ``MergeRecord`` equivalent.

Concatenates many small input files into one larger output file.
Common use case: nightly micro-batches each landed a 50 MB part — at
the end of the window we merge them into a single 5 GB Parquet so
downstream consumers don't open 100 fragments.

Supported formats: csv / parquet / json — same set as
``ConvertFileFormatStage``.  Mixed inputs aren't supported: every
input file must be the same format.

The merge is glob-based: ``input_glob`` (e.g. ``/lake/raw/2026/05/19/*.parquet``)
selects the inputs.  At least one file must match or the stage fails
unless ``allow_empty`` is true.

Implementation: DuckDB ``COPY (SELECT * FROM read_*('glob'))`` — the
reader natively expands the glob.  No Python-side concat = handles
datasets > RAM.
"""
from __future__ import annotations

import glob as _glob
import os
from typing import Any, Dict, List

from core.dataflow.base import (
    BaseStage, CATEGORY_TRANSFORM, IDEMPOTENT_OVERWRITE,
)
from core.dataflow.context import StageContext, StageResult
from core.dataflow.registry import register


_READERS = {
    "csv":     "read_csv_auto",
    "parquet": "read_parquet",
    "json":    "read_json_auto",
}


@register
class MergeRecordsStage(BaseStage):
    NAME = "merge_records"
    DISPLAY_NAME = "Merge Records (combine many → one)"
    CATEGORY = CATEGORY_TRANSFORM
    IDEMPOTENCY = IDEMPOTENT_OVERWRITE
    DESCRIPTION = ("NiFi MergeRecord equivalent — concatenate many small "
                    "files matching a glob into one larger output file.")
    COST_SECONDS = 30
    COST_CENTS = 0
    CONFIG_SCHEMA = {
        "input_glob":   {"type": "string",
                          "description": "Glob selecting inputs (supports {key})."},
        "input_format": {"type": "string", "enum": ["csv", "parquet", "json"]},
        "output_path":  {"type": "string",
                          "description": "Merged output file (supports {key})."},
        "output_format": {"type": "string", "enum": ["csv", "parquet", "json"]},
        "delete_inputs": {"type": "boolean",
                          "description": "Delete the matched inputs after success."},
        "allow_empty":   {"type": "boolean",
                          "description": "If true, an empty glob succeeds (no-op)."},
    }

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        errs: List[str] = []
        for k in ("input_glob", "output_path"):
            if not (config.get(k) or "").strip():
                errs.append(f"{k} is required")
        for k in ("input_format", "output_format"):
            v = config.get(k)
            if v and v not in _READERS:
                errs.append(f"{k} must be csv|parquet|json, got {v!r}")
        return errs

    def execute(self, ctx: StageContext) -> StageResult:
        def _fmt(s: str) -> str:
            try:
                return s.format(**ctx.run_context)
            except Exception:
                return s

        input_glob = _fmt(ctx.get_config("input_glob") or "")
        output_path = _fmt(ctx.get_config("output_path") or "")
        input_format = ctx.get_config("input_format") or self._guess_format(input_glob)
        output_format = ctx.get_config("output_format") or self._guess_format(output_path)
        delete_inputs = bool(ctx.get_config("delete_inputs", False))
        allow_empty = bool(ctx.get_config("allow_empty", False))

        if input_format not in _READERS:
            return StageResult.failed(error=f"unsupported input_format: {input_format}")
        if output_format not in _READERS:
            return StageResult.failed(error=f"unsupported output_format: {output_format}")

        matched = sorted(_glob.glob(input_glob))
        if not matched:
            if allow_empty:
                ctx.log(f"merge_records: no inputs match {input_glob}; allow_empty=true → no-op")
                return StageResult.succeeded(outputs={
                    "input_count": 0, "output_path": output_path,
                    "skipped": True,
                })
            return StageResult.failed(error=f"no files match {input_glob}")

        parent = os.path.dirname(output_path)
        if parent:
            os.makedirs(parent, exist_ok=True)

        try:
            import duckdb
            con = duckdb.connect(database=":memory:")
        except Exception as exc:
            return StageResult.failed(error=f"DuckDB unavailable: {exc}")

        try:
            reader = _READERS[input_format]
            fmt_clause = {
                "csv":     "(FORMAT 'csv', HEADER)",
                "parquet": "(FORMAT 'parquet')",
                "json":    "(FORMAT 'json')",
            }[output_format]
            escaped_glob = input_glob.replace("'", "''")
            escaped_out  = output_path.replace("'", "''")
            sql = (f"COPY (SELECT * FROM {reader}('{escaped_glob}'))"
                   f" TO '{escaped_out}' {fmt_clause}")
            con.execute(sql)
        except Exception as exc:
            return StageResult.failed(error=f"merge failed: {exc}")
        finally:
            try:
                con.close()
            except Exception:
                pass

        in_bytes = 0
        for p in matched:
            try:
                in_bytes += os.path.getsize(p)
            except Exception:
                pass
        out_bytes = os.path.getsize(output_path) if os.path.exists(output_path) else 0

        deleted = 0
        if delete_inputs:
            for p in matched:
                try:
                    os.remove(p)
                    deleted += 1
                except Exception as exc:
                    ctx.log(f"delete failed for {p}: {exc}")

        ctx.log(
            f"merged {len(matched)} input(s) totalling {in_bytes} B → "
            f"{output_path} ({out_bytes} B); deleted={deleted}"
        )
        return StageResult.succeeded(outputs={
            "input_glob":   input_glob,
            "input_count":  len(matched),
            "input_bytes":  in_bytes,
            "output_path":  output_path,
            "output_bytes": out_bytes,
            "deleted":      deleted,
        })

    @staticmethod
    def _guess_format(path: str) -> str:
        ext = (path.rsplit(".", 1)[-1] or "").lower()
        if ext in ("csv", "tsv", "txt"):
            return "csv"
        if ext == "parquet":
            return "parquet"
        if ext in ("json", "jsonl", "ndjson"):
            return "json"
        return "parquet"
