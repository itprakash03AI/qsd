"""Proactive SLA breach scanner (Phase 132.25).

The dispatcher's _finalise flags sla_breached only at run END.  For
long-running runs (multi-hour SAP downloads, daily Spark jobs) admins
want the alert as soon as the deadline passes, NOT only after the
run finishes.

This service polls ``dataflow_runs`` every N seconds, looking for runs
where:
* status == 'running' (or 'pending' that's been pending too long)
* expected_completion_at < now()
* sla_breached is still False

When found, sets ``sla_breached=True`` (idempotent — only flips once
per run) and fires an SLA-breached event through the notification
policy engine so email / webhook / ws policies trigger immediately.

Singleton service, leader-elected via the same lease the
DataFlowScheduler uses.  Best-effort: scan failures don't block runs.
"""
from __future__ import annotations

import asyncio
import logging
import threading
from datetime import datetime, timezone
from typing import Any, Callable, Optional

logger = logging.getLogger(__name__)


class SLAScanner:
    """Periodic SLA-breach detector.  Owns nothing the dispatcher
    doesn't already own; safe to start/stop independently.
    """

    def __init__(
        self,
        db_manager: Any,
        poll_seconds: int = 60,
        is_leader_fn: Optional[Callable[[], bool]] = None,
    ) -> None:
        if db_manager is None:
            raise ValueError("SLAScanner requires db_manager")
        self.db = db_manager
        self.poll_seconds = max(15, int(poll_seconds))
        self.is_leader_fn = is_leader_fn or (lambda: True)
        self._stop = asyncio.Event()
        self._task: Optional[asyncio.Task] = None
        self._started = False

    async def start(self) -> None:
        if self._started:
            return
        self._started = True
        self._stop.clear()
        self._task = asyncio.create_task(self._run_loop(),
                                          name="dataflow-sla-scanner")
        logger.info("[dataflow.sla_scanner] started — poll=%ds",
                     self.poll_seconds)

    async def stop(self) -> None:
        if not self._started:
            return
        self._stop.set()
        if self._task is not None:
            try:
                await asyncio.wait_for(self._task, timeout=5.0)
            except asyncio.TimeoutError:
                self._task.cancel()
            except Exception as _exc:
                logger.debug("[dataflow.sla_scanner] stop exception: %s", _exc)
        self._started = False
        logger.info("[dataflow.sla_scanner] stopped")

    async def _run_loop(self) -> None:
        while not self._stop.is_set():
            try:
                if self.is_leader_fn():
                    found = await asyncio.to_thread(self._scan_once)
                    if found:
                        logger.info("[dataflow.sla_scanner] flagged %d "
                                      "new mid-flight SLA breach(es)", found)
            except Exception as exc:
                logger.error("[dataflow.sla_scanner] scan failed: %s",
                              exc, exc_info=True)
            try:
                await asyncio.wait_for(self._stop.wait(),
                                        timeout=self.poll_seconds)
            except asyncio.TimeoutError:
                continue

    def _scan_once(self) -> int:
        """One pass over running/pending runs.  Returns the number of
        newly-flagged sla_breached rows.
        """
        from core.db.models import DataFlowRun
        now = datetime.now(timezone.utc)
        flagged: list = []

        with self.db.get_session() as session:
            candidates = (
                session.query(DataFlowRun)
                .filter(
                    DataFlowRun.status.in_(["running", "pending"]),
                    DataFlowRun.sla_breached == False,  # noqa: E712
                    DataFlowRun.expected_completion_at.isnot(None),
                )
                .all()
            )
            for run in candidates:
                exp = run.expected_completion_at
                if exp is None:
                    continue
                if exp.tzinfo is None:
                    exp = exp.replace(tzinfo=timezone.utc)
                if exp >= now:
                    continue
                # Breached.  Flip the flag (only once per run).
                run.sla_breached = True
                flagged.append({
                    "id":            run.id,
                    "dataflow_id":   run.dataflow_id,
                    "dataflow_name": run.dataflow_name,
                    "status":        run.status,
                    "triggered_by":  run.triggered_by,
                    "error":         None,
                    "started_at":    run.started_at.isoformat() if run.started_at else None,
                    "ended_at":      None,
                    "sla_breached":  True,
                })
            session.flush()

        # Fire notification policies AFTER the flag is committed so a
        # crashed notification doesn't leave the flag dangling.
        for run_dict in flagged:
            try:
                from core.dataflow.notification_policy import (
                    get_notification_engine, EVT_SLA_BREACHED,
                )
                engine = get_notification_engine()
                if engine is not None:
                    engine.on_run_event(EVT_SLA_BREACHED, run_dict)
            except Exception as exc:
                logger.debug("[dataflow.sla_scanner] notify fire %d: %s",
                             run_dict.get("id"), exc)
        return len(flagged)


# ── Module-level singleton accessor ────────────────────────────────────────


_scanner: Optional[SLAScanner] = None
_lock = threading.Lock()


def init_sla_scanner(
    db_manager: Any,
    poll_seconds: int = 60,
    is_leader_fn: Optional[Callable[[], bool]] = None,
) -> SLAScanner:
    global _scanner
    with _lock:
        _scanner = SLAScanner(
            db_manager=db_manager,
            poll_seconds=poll_seconds,
            is_leader_fn=is_leader_fn,
        )
    return _scanner


def get_sla_scanner() -> Optional[SLAScanner]:
    return _scanner
