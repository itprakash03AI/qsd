"""Runnability — can a registered stage type actually execute in THIS image?

WHY THIS EXISTS (2026-09-15)
----------------------------
``registry.size()`` reported 49 stage types and the palette offered all
49, but 22 of them could not run in any shipped image: 19 ETL bridges
import ``steps.*`` from an ``ETL/`` tree that ``Dockerfile.api`` never
copies, 2 SAP decomposed stages do the same, and ``put_kafka`` needs
``kafka-python`` which lives in ``requirements-extras/``.  Nothing said so
until a run failed at execute time.  Worse, 19 of the 25 bridge targets
pointed at module paths that do not exist even where ``ETL/`` IS present
(the real modules live in ``steps.file.*``, ``steps.oracle.*``,
``steps.s3_to_file.*``, ``steps.sap.*``), so "registered" was doubly
disconnected from "runnable".

This module is the ONE probe both the manifest (palette / catalogue /
``GET /api/dataflows/stage-types``) and ``validate_config`` (save and
dry-run) consult — one answer to one question.  It follows the shape the
product already uses for the same problem: ``/api/feeds/backend-options``
reports ``available`` + ``availability_detail`` and Clockwork's catalogue
reports ``routable`` + ``routable_reason``.

THREE STATES, NOT TWO
---------------------
Unknown is not false.  A probe that could not run (an unexpected
exception, an unreadable file) must say *that* rather than claim the
stage works or that it does not.  The verdict therefore carries
``determined``; the ``reason`` text of an undetermined verdict starts with
``COULD_NOT_DETERMINE`` so a reader cannot mistake it for "confirmed
absent".  Both non-runnable states refuse at validate time — an author
must not be allowed to save a stage nobody can vouch for — but the two
messages lead to different investigations.

WHAT "RUNNABLE" MEANS (and does not)
------------------------------------
For an ETL target: the ETL tree is where the bridge's execute() gate would
find it, the module path resolves under it, and the module's source
declares (or re-exports) the class.  It deliberately does NOT import the
module — ETL step modules pull in pandas / Oracle / Spark at import and a
catalogue read must not pay for that or trigger their side effects.  So
a ``runnable=True`` verdict vouches for the module and class being
present; a transitive import failure inside the ETL module (a missing
``managers`` package, say) is still only found at execute.  It cannot,
however, produce a false ``runnable=True`` for the two defects this was
built for: an absent tree yields ``find_etl_root() is None`` and a wrong
path yields ``find_spec() is None`` — both are hard negatives.
"""
from __future__ import annotations

import importlib.util
import logging
import re
from dataclasses import dataclass
from typing import Dict, List, Mapping, Optional, Tuple

logger = logging.getLogger(__name__)

#: Prefix on the reason of every UNDETERMINED verdict.  A guard or a UI can
#: key on it; a human reading it cannot mistake it for "confirmed absent".
#: Re-exported from core/verdict_vocabulary.py (2026-09-15) so the feed
#: health probe can share the word without importing the DataFlow engine.
#: ``runnability.COULD_NOT_DETERMINE`` keeps working for every caller.
from core.verdict_vocabulary import COULD_NOT_DETERMINE


@dataclass(frozen=True)
class Runnability:
    """The verdict.  ``runnable`` is what a bool consumer reads; ``reason``
    is empty iff runnable; ``determined`` is False when the probe itself
    failed (then ``runnable`` is False and ``reason`` says why the probe
    could not answer)."""

    runnable: bool
    reason: str = ""
    determined: bool = True

    # ── constructors ────────────────────────────────────────────────────

    @classmethod
    def ok(cls) -> "Runnability":
        return cls(True, "", True)

    @classmethod
    def unavailable(cls, reason: str) -> "Runnability":
        return cls(False, reason, True)

    @classmethod
    def unknown(cls, reason: str) -> "Runnability":
        return cls(False, f"{COULD_NOT_DETERMINE}: {reason}", False)

    # ── projections ─────────────────────────────────────────────────────

    def manifest_fields(self) -> Dict[str, object]:
        """The two keys the stage manifest carries."""
        return {"runnable": bool(self.runnable),
                "unavailable_reason": "" if self.runnable else self.reason}

    def problems(self, label: str = "") -> List[str]:
        """``validate_config``-shaped: an empty list iff runnable."""
        if self.runnable:
            return []
        prefix = f"{label}: " if label else ""
        if self.determined:
            return [f"{prefix}cannot run in this image — {self.reason}"]
        return [f"{prefix}runnability could not be determined — {self.reason}"]


RUNNABLE = Runnability.ok()


# ── ETL targets ───────────────────────────────────────────────────────────


_ETL_MARKER = "BaseStep.py"


def _class_declared_in(source: str, cls_name: str) -> bool:
    """Does the module SOURCE declare or re-export ``cls_name``?

    A textual check on purpose (see the module docstring).  Matches
    ``class Name(`` / ``class Name:`` and ``from x import ..., Name`` —
    the two shapes ETL uses, the second being its back-compat shims
    (``steps/process_data.py`` re-exports ``steps.oracle.process_data``).
    """
    esc = re.escape(cls_name)
    if re.search(rf"^\s*class\s+{esc}\s*[(:]", source, re.M):
        return True
    return bool(re.search(rf"^\s*from\s+\S+\s+import\s+[^\n]*\b{esc}\b", source, re.M))


def _locate_etl_tree(required_file: str) -> Tuple[Optional[object], Optional[Runnability]]:
    """Find the ETL tree the way execute() will, and put it on ``sys.path``.

    Returns ``(root, None)`` when the tree is usable, else ``(None, verdict)``
    with the verdict every target under it shares.  Asked ONCE per stage
    by ``probe_etl_targets`` so a stage with four variants reports an
    absent tree once, not four times.
    """
    try:
        from core.etl_root import ETL_ROOT_ENV, ensure_etl_on_path, find_etl_root
    except Exception as exc:  # pragma: no cover - would be a broken checkout
        return None, Runnability.unknown(f"core.etl_root unavailable: {exc}")

    try:
        root = find_etl_root(required_file)
    except Exception as exc:
        return None, Runnability.unknown(
            f"locating the ETL tree raised {type(exc).__name__}: {exc}")
    if root is None:
        return None, Runnability.unavailable(
            f"the ETL framework is not installed in this image (no "
            f"ETL/steps/{required_file} at the checkout sibling, /app/ETL or "
            f"the CWD; set {ETL_ROOT_ENV} to the directory containing steps/)")

    # Same call execute() makes: puts the root on sys.path and imports the
    # ``steps`` package.  Runs only once the tree is known to exist, so a
    # catalogue read on an ETL-less image does not log a warning per stage.
    try:
        if not ensure_etl_on_path(required_file):
            return None, Runnability.unavailable(
                f"ETL tree {root} is present but its 'steps' package will "
                f"not import")
    except Exception as exc:
        return None, Runnability.unknown(
            f"putting ETL tree {root} on sys.path raised "
            f"{type(exc).__name__}: {exc}")
    return root, None


def _with_target(verdict: Runnability, module: str, cls_name: str) -> Runnability:
    """A tree-level verdict, stamped with the target it stops."""
    if verdict.runnable:
        return verdict
    return Runnability(False, f"{verdict.reason} — {module}.{cls_name} cannot be imported",
                       verdict.determined)


def probe_etl_target(module: str, cls_name: str,
                     required_file: str = _ETL_MARKER) -> Runnability:
    """Can ``from <module> import <cls_name>`` succeed in this image?

    ``required_file`` is the file under ``ETL/steps/`` the caller's
    execute() gate insists on — the bridges use ``BaseStep.py``, the SAP
    decomposed stages ``sap/sap_odata_base.py`` — so the probe locates the
    tree exactly the way the run would.
    """
    root, tree_verdict = _locate_etl_tree(required_file)
    if tree_verdict is not None:
        return _with_target(tree_verdict, module, cls_name)
    return _probe_target_under(root, module, cls_name)


def _probe_target_under(root: object, module: str, cls_name: str) -> Runnability:
    """The per-target half: module path resolves under the (already
    located, already on-path) tree and its source declares the class."""
    if not module or not cls_name:
        return Runnability.unavailable(
            "no ETL target declared (ETL_MODULE / ETL_CLASS empty)")
    try:
        spec = importlib.util.find_spec(module)
    except ModuleNotFoundError as exc:
        # find_spec imports the PARENT package; a missing parent is a
        # definitive "this path does not exist", not an unknown.
        return Runnability.unavailable(
            f"module {module} does not exist under ETL tree {root} "
            f"({exc.name or exc}) — check ETL/configs/step_mapping.yaml "
            f"for where the step really lives")
    except Exception as exc:
        return Runnability.unknown(
            f"find_spec({module!r}) raised {type(exc).__name__}: {exc}")
    if spec is None:
        return Runnability.unavailable(
            f"module {module} does not exist under ETL tree {root} — check "
            f"ETL/configs/step_mapping.yaml for where the step really lives")
    origin = getattr(spec, "origin", None)
    if not origin or origin in ("built-in", "frozen", "namespace"):
        return Runnability.unavailable(
            f"module {module} resolves to {origin or 'no file'} under "
            f"{root}, not a source file — class {cls_name} cannot be verified")
    try:
        with open(origin, encoding="utf-8", errors="replace") as fh:
            source = fh.read()
    except OSError as exc:
        return Runnability.unknown(
            f"module {module} resolved to {origin} but it could not be read: "
            f"{type(exc).__name__}: {exc}")
    if not _class_declared_in(source, cls_name):
        return Runnability.unavailable(
            f"module {module} ({origin}) declares no class {cls_name} — the "
            f"ETL_CLASS name is wrong for this module")
    return RUNNABLE


def probe_etl_targets(targets: Mapping[str, Tuple[str, str]],
                      required_file: str = _ETL_MARKER) -> Runnability:
    """Probe every variant a stage can select; runnable iff ALL are.

    ``targets`` maps a variant label (``"oncloud_spark"``, or ``""`` for a
    single-target stage) to ``(module, class)``.  The reason names each
    failing variant so an operator knows which config value is dead.  The
    tree-absent case is reported ONCE, not once per variant.
    """
    if not targets:
        return Runnability.unavailable("no ETL target declared")
    # The tree is the same answer for every variant — locate it ONCE.
    root, tree_verdict = _locate_etl_tree(required_file)
    if tree_verdict is not None:
        first_module, first_cls = next(iter(targets.values()))
        return _with_target(tree_verdict, first_module, first_cls)
    failures: List[Tuple[str, Runnability]] = []
    for label, (module, cls_name) in targets.items():
        v = _probe_target_under(root, module, cls_name)
        if v.runnable:
            continue
        if not v.determined:
            return v          # the probe itself broke — say that, once
        failures.append((label, v))
    if not failures:
        return RUNNABLE
    if len(targets) == 1:
        return failures[0][1]
    parts = [f"[{label or 'default'}] {v.reason}" for label, v in failures]
    return Runnability.unavailable(
        f"{len(failures)} of {len(targets)} variants cannot run: " + "; ".join(parts))


# ── Optional Python packages ──────────────────────────────────────────────


def probe_python_package(import_name: str, dist_name: str,
                         install_hint: str) -> Runnability:
    """Is ``import <import_name>`` satisfiable in this interpreter?

    Uses ``find_spec`` rather than importing, so a catalogue read never
    pays for (or is broken by) the package's import-time work.
    """
    try:
        spec = importlib.util.find_spec(import_name)
    except (ModuleNotFoundError, ValueError):
        spec = None
    except Exception as exc:
        return Runnability.unknown(
            f"find_spec({import_name!r}) raised {type(exc).__name__}: {exc}")
    if spec is None:
        return Runnability.unavailable(
            f"{dist_name} is not installed in this image ({install_hint})")
    return RUNNABLE


__all__ = [
    "COULD_NOT_DETERMINE", "RUNNABLE", "Runnability",
    "probe_etl_target", "probe_etl_targets", "probe_python_package",
]
