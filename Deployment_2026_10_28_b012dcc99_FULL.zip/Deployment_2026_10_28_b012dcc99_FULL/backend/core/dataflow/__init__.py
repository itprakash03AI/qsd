"""Generic DataFlow Engine (Phase 132).

Public surface:

    from core.dataflow import (
        DataFlowEngine, Dispatcher, DataFlowScheduler,
        BaseStage, StageContext, StageResult,
        get_engine, get_dispatcher, get_scheduler,
        init_workflow_subsystem,
    )

``init_workflow_subsystem`` is the one-call bootstrap used by main.py.
Tests typically construct their own classes directly.
"""
from __future__ import annotations

import logging
from typing import Any, Callable, Optional

from core.dataflow.base import BaseStage
from core.dataflow.context import StageContext, StageResult
from core.dataflow.dispatcher import Dispatcher, get_dispatcher, init_dispatcher
from core.dataflow.engine import (
    StageSpec, DataFlowEngine, DataFlowSpec,
    get_engine, init_engine,
)
from core.dataflow.registry import (
    StageTypeRegistry, default_registry, get_default_registry, register,
)
from core.dataflow.scheduler import (
    DataFlowScheduler, get_scheduler, init_scheduler,
)

logger = logging.getLogger(__name__)


# Phase 132.30 — stash the last init error so the 503 surface can
# expose WHY the subsystem failed.  main.py sets this in its except.
_init_error: Optional[str] = None
_init_traceback: Optional[str] = None


def set_init_error(msg: Optional[str], traceback_str: Optional[str] = None) -> None:
    """Called by main.py when init_workflow_subsystem raises so that the
    /api/dataflows/_init-status endpoint can show operators exactly what
    failed without forcing them to dig through pod logs."""
    global _init_error, _init_traceback
    _init_error = msg
    _init_traceback = traceback_str


def get_init_error() -> Optional[str]:
    return _init_error


def get_init_traceback() -> Optional[str]:
    return _init_traceback


__all__ = [
    "BaseStage", "StageContext", "StageResult",
    "StageSpec", "DataFlowSpec",
    "DataFlowEngine", "Dispatcher", "DataFlowScheduler",
    "StageTypeRegistry", "register",
    "get_engine", "get_dispatcher", "get_scheduler",
    "init_workflow_subsystem",
    "set_init_error", "get_init_error", "get_init_traceback",
]


def init_workflow_subsystem(
    db_manager: Any,
    broadcast_fn: Optional[Callable[[dict], None]] = None,
    *,
    poll_seconds: int = 30,
    max_concurrent_runs: int = 8,
    is_leader_fn: Optional[Callable[[], bool]] = None,
    auto_start_scheduler: bool = False,
) -> dict:
    """One-call bootstrap for the dataflow subsystem.

    Order:
      1. Discover stage types (populates the in-memory registry).
      2. Sync registry to ``dataflow_stage_types`` DB rows.
      3. Init the singleton ``DataFlowEngine``.
      4. Init the singleton ``Dispatcher``.
      5. Init the singleton ``DataFlowScheduler`` (NOT started — caller
         awaits ``scheduler.start()`` from an async context).

    Returns a dict with ``engine``, ``dispatcher``, ``scheduler``,
    ``stage_count`` so the caller can log + reuse.
    """
    registry = get_default_registry()
    # 1. Discover Python-defined stages
    registry.discover("core.dataflow.stages")
    # 2. Register DB-defined custom ETL-bridge stages (admin-managed)
    try:
        from core.dataflow.template_seeder import register_custom_stage_types
        custom_n = register_custom_stage_types(db_manager, registry)
        if custom_n:
            logger.info("[dataflow] registered %d DB-driven custom stage type(s)", custom_n)
    except Exception as _csexc:
        logger.warning("[dataflow] custom stage registration failed: %s", _csexc)
    # 3. Sync registry to dataflow_stage_types (UI catalogue)
    registry.sync_to_db(db_manager)
    # 4. Seed built-in templates into the DB if missing (idempotent).
    try:
        from core.dataflow.template_seeder import seed_built_in_templates
        seeded = seed_built_in_templates(db_manager)
        if seeded:
            logger.info("[dataflow] seeded %d built-in template(s) into DB", seeded)
    except Exception as _seedexc:
        logger.warning("[dataflow] template seeding failed: %s", _seedexc)

    engine = init_engine(db_manager=db_manager,
                          broadcast_fn=broadcast_fn,
                          registry=registry)
    dispatcher = init_dispatcher(db_manager=db_manager,
                                  engine=engine,
                                  registry=registry,
                                  broadcast_fn=broadcast_fn)
    scheduler = init_scheduler(db_manager=db_manager,
                                engine=engine,
                                dispatcher=dispatcher,
                                poll_seconds=poll_seconds,
                                max_concurrent_runs=max_concurrent_runs,
                                is_leader_fn=is_leader_fn)
    logger.info(
        "[dataflow] subsystem initialised — %d stage types registered, "
        "scheduler poll=%ds, max_concurrent=%d, auto_start=%s",
        registry.size(), poll_seconds, max_concurrent_runs, auto_start_scheduler,
    )
    return {
        "engine":      engine,
        "dispatcher":  dispatcher,
        "scheduler":   scheduler,
        "stage_count": registry.size(),
    }
