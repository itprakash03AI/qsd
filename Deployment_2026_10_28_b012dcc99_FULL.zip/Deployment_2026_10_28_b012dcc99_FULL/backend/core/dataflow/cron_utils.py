"""Lightweight cron-expression next-fire calculator.

We avoid a hard dependency on ``croniter`` because the broader codebase
already supports being run in air-gapped on-prem environments where
extra wheels may not be available.  If ``croniter`` is installed we
use it (it's correct, well-tested, supports timezones); otherwise we
fall back to a minimal 5-field parser that covers the common patterns
(``*/N``, exact numbers, ``,`` lists) — enough for the scheduler MVP.

Returned ``datetime`` objects are timezone-aware UTC.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone
from typing import List, Optional

logger = logging.getLogger(__name__)


def next_fire_at(
    cron_expr: str,
    now: Optional[datetime] = None,
    tz_name: str = "UTC",
) -> datetime:
    """Return the next datetime at which ``cron_expr`` fires after ``now``.

    Always returns a timezone-aware UTC datetime so the DB column types
    are consistent.  ``tz_name`` is honoured when croniter is installed;
    the fallback parser treats the expression as UTC.
    """
    base = now or datetime.now(timezone.utc)
    if base.tzinfo is None:
        base = base.replace(tzinfo=timezone.utc)

    # Prefer croniter when available — it's the production-grade path.
    try:
        import croniter  # type: ignore
        try:
            from zoneinfo import ZoneInfo  # type: ignore
            tz = ZoneInfo(tz_name)
        except Exception:
            tz = timezone.utc
        local = base.astimezone(tz)
        itr = croniter.croniter(cron_expr, local)
        nxt = itr.get_next(datetime)
        if nxt.tzinfo is None:
            nxt = nxt.replace(tzinfo=tz)
        return nxt.astimezone(timezone.utc)
    except ImportError:
        pass
    except Exception as exc:
        logger.warning("[dataflow.cron] croniter failed for %r: %s — falling back",
                       cron_expr, exc)

    return _fallback_next_fire(cron_expr, base)


# ── Fallback implementation ────────────────────────────────────────────────


def _parse_field(spec: str, lo: int, hi: int) -> List[int]:
    """Parse a single cron field (``*``, ``*/N``, ``a,b,c``, ``a-b``) into
    the explicit list of matching values.  Used by the fallback path.
    """
    if spec == "*":
        return list(range(lo, hi + 1))
    out: List[int] = []
    for part in spec.split(","):
        part = part.strip()
        if "/" in part:
            head, step = part.split("/", 1)
            step_i = int(step)
            if head == "*" or head == "":
                start = lo
                end = hi
            elif "-" in head:
                s, e = head.split("-", 1)
                start = int(s)
                end = int(e)
            else:
                start = int(head)
                end = hi
            out.extend(range(start, end + 1, step_i))
        elif "-" in part:
            s, e = part.split("-", 1)
            out.extend(range(int(s), int(e) + 1))
        else:
            out.append(int(part))
    return sorted(set(v for v in out if lo <= v <= hi))


def _fallback_next_fire(expr: str, base: datetime) -> datetime:
    """Cheap 5-field cron solver.  Iterates minute by minute up to
    one year ahead (366 * 24 * 60 ≈ 530k iterations worst-case).
    Returns the first matching minute strictly after ``base``.
    """
    parts = expr.split()
    if len(parts) != 5:
        raise ValueError(
            f"unsupported cron expression {expr!r}: expected 5 fields, got {len(parts)}"
        )
    minutes = _parse_field(parts[0], 0, 59)
    hours = _parse_field(parts[1], 0, 23)
    days_of_month = _parse_field(parts[2], 1, 31)
    months = _parse_field(parts[3], 1, 12)
    days_of_week = _parse_field(parts[4], 0, 6)  # Sun=0 … Sat=6

    candidate = (base + timedelta(minutes=1)).replace(second=0, microsecond=0)
    limit = candidate + timedelta(days=366)
    while candidate < limit:
        dow = (candidate.weekday() + 1) % 7  # cron uses Sun=0 — Python uses Mon=0
        if (
            candidate.minute in minutes and
            candidate.hour in hours and
            candidate.day in days_of_month and
            candidate.month in months and
            dow in days_of_week
        ):
            return candidate
        candidate += timedelta(minutes=1)
    raise ValueError(f"no match in a year for cron {expr!r} — likely invalid")
