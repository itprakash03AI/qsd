"""Stage execution context + result objects.

These are pure-Python dataclasses; they are NOT persisted directly.
The dispatcher materialises ``StageContext`` for each stage from the
DB state, calls ``BaseStage.execute(ctx)``, and writes the returned
``StageResult`` back into ``dataflow_run_stages``.
"""
from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


@dataclass
class StageResult:
    """Return value from ``BaseStage.execute()``.

    A stage author should never raise from execute() for *expected*
    failures — they should return ``StageResult.failed(message=...)``.
    Exceptions are caught by the dispatcher but treated as bugs (full
    traceback in the error column).
    """

    status: str = "succeeded"                      # succeeded | failed | skipped | reschedule
    outputs: Dict[str, Any] = field(default_factory=dict)
    log_lines: List[str] = field(default_factory=list)
    error: Optional[str] = None
    context_updates: Dict[str, Any] = field(default_factory=dict)
    branch_to: Optional[str] = None                # control-flow: jump to this stage_alias next
    # Phase 132.22 — sensor reschedule.  A stage returns ``reschedule``
    # to tell the dispatcher "I'm not done; release my worker and call
    # me again in N seconds".  The dispatcher persists the row as
    # ``status="reschedule"`` with ``next_check_at``, frees the worker,
    # and the scheduler re-picks it on the next tick.  Long-running
    # sensors (wait_for_file, wait_for_dataflow_run) use this to scale
    # past the worker-pool count.
    reschedule_after_seconds: Optional[int] = None

    @classmethod
    def succeeded(cls, **kwargs: Any) -> "StageResult":
        return cls(status="succeeded", **kwargs)

    @classmethod
    def failed(cls, error: str, **kwargs: Any) -> "StageResult":
        return cls(status="failed", error=error, **kwargs)

    @classmethod
    def skipped(cls, reason: Optional[str] = None, **kwargs: Any) -> "StageResult":
        return cls(status="skipped", error=reason, **kwargs)

    @classmethod
    def branched(cls, branch_to: str, **kwargs: Any) -> "StageResult":
        return cls(status="succeeded", branch_to=branch_to, **kwargs)

    @classmethod
    def reschedule(cls, seconds: int, **kwargs: Any) -> "StageResult":
        """Sensor reschedule — release the worker, retry in ``seconds``.
        Use for long-waits where blocking a worker for the full window
        wastes capacity (file sensors, cross-DAG sensors).
        """
        return cls(status="reschedule",
                    reschedule_after_seconds=max(1, int(seconds)),
                    **kwargs)


class StageContext:
    """Passed to every stage's ``execute()``.

    The context is read-mostly from a stage's perspective.  Stages should
    return a ``StageResult`` whose ``outputs`` / ``context_updates`` /
    ``branch_to`` fields drive any state change — never mutate ctx fields
    directly.
    """

    def __init__(
        self,
        *,
        run_id: int,
        dataflow_id: int,
        dataflow_name: str,
        dataflow_version: int,
        stage_alias: str,
        stage_type: str,
        seq: int,
        config: Dict[str, Any],
        run_context: Dict[str, Any],
        prev_outputs: Dict[str, Dict[str, Any]],
        triggered_by: Optional[str],
        attempt: int,
        worker_node: str,
        cancel_event: Optional[threading.Event] = None,
        log_emit: Optional[Callable[[str], None]] = None,
        db_manager: Any = None,
        broadcast_fn: Optional[Callable[[Dict[str, Any]], None]] = None,
        run_as: Optional[str] = None,
    ) -> None:
        self.run_id = run_id
        self.dataflow_id = dataflow_id
        self.dataflow_name = dataflow_name
        self.dataflow_version = dataflow_version
        self.stage_alias = stage_alias
        self.stage_type = stage_type
        self.seq = seq
        self.config = dict(config) if config else {}
        self.run_context = dict(run_context) if run_context else {}
        self.prev_outputs = dict(prev_outputs) if prev_outputs else {}
        self.triggered_by = triggered_by
        # Phase 132.20 — when the run was started with run_as=X by an
        # admin, downstream credential resolution / vault lookups should
        # use ``effective_user`` (= run_as or triggered_by) instead of
        # the actor.  Stages that don't care can ignore both.
        self.run_as = run_as
        self.attempt = attempt
        self.worker_node = worker_node
        self._cancel_event = cancel_event
        self._log_emit = log_emit
        self.db_manager = db_manager
        self.broadcast_fn = broadcast_fn
        self._log_buffer: List[str] = []

    @property
    def effective_user(self) -> Optional[str]:
        """Identity downstream auth/vault/credential resolution should
        use.  When an admin started the run with run_as=X, prefer X;
        otherwise fall back to the actor (triggered_by).
        """
        return self.run_as or self.triggered_by

    # ── Read helpers ────────────────────────────────────────────────────

    def get_input(self, source_alias: str, key: Optional[str] = None) -> Any:
        """Read a named output from a predecessor stage.

        ``get_input("query")``            → the entire outputs dict
        ``get_input("query", "row_count")`` → the row_count value or None.
        """
        outputs = self.prev_outputs.get(source_alias)
        if outputs is None:
            return None
        if key is None:
            return outputs
        return outputs.get(key)

    def get_param(self, key: str, default: Any = None) -> Any:
        """Read a value from the shared run_context.

        Run context is the parameter bag bound at run start (defaults +
        trigger payload + each stage's context_updates).
        """
        return self.run_context.get(key, default)

    def get_config(self, key: str, default: Any = None) -> Any:
        """Read a stage-config value (declared on ``dataflow_stages.config``)."""
        return self.config.get(key, default)

    # ── Cancellation cooperation ────────────────────────────────────────

    def is_cancelled(self) -> bool:
        """Long-running stages should check this between chunks and
        return ``StageResult.failed("cancelled")`` (or raise
        ``DataFlowCancelledError``) when set.
        """
        return self._cancel_event is not None and self._cancel_event.is_set()

    # ── Logging (captured into dataflow_run_stages.log_lines) ───────────

    def log(self, message: str) -> None:
        """Capture a log line into the stage's persisted ``log_lines`` JSON.
        Also forwarded to the standard Python logger via ``log_emit`` if
        wired by the dispatcher.

        Phase 132.26 — also broadcast each line via WebSocket so the run-
        detail page can live-tail without polling.  Broadcast is keyed
        on triggered_by for per-user routing.
        """
        line = str(message)
        self._log_buffer.append(line)
        if self._log_emit is not None:
            try:
                self._log_emit(line)
            except Exception:
                # Logger failures must not break stage execution.
                pass
        # Phase 132.26 — live tail via WS
        if self.broadcast_fn is not None:
            try:
                from datetime import datetime as _dt, timezone as _tz
                self.broadcast_fn({
                    "event":         "workflow_stage_log",
                    "run_id":        self.run_id,
                    "stage_alias":   self.stage_alias,
                    "line":          line,
                    "at":            _dt.now(_tz.utc).isoformat(),
                    "triggered_by":  self.triggered_by,
                    "dataflow_name": self.dataflow_name,
                })
            except Exception:
                pass

    def drain_logs(self) -> List[str]:
        """Dispatcher calls this after execute() to harvest log lines."""
        out, self._log_buffer = self._log_buffer, []
        return out
