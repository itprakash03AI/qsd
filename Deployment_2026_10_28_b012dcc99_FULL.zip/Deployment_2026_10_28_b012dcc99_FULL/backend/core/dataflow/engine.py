"""``DataFlowEngine`` — top-level facade for dataflow CRUD + run creation.

Public surface (everything the API layer calls):

* ``create_workflow(spec)``        → persists draft DataFlow + WorkflowStages.
* ``add_version(name, spec)``      → bumps version of an existing dataflow.
* ``promote(dataflow_id)``         → draft → active.
* ``archive(dataflow_id)``         → active → archived (and pauses schedules).
* ``start_run(dataflow_name, …)``  → creates pending DataFlowRun + run_stages.
* ``cancel_run(run_id, by)``       → signals cooperative cancellation.

The engine *never* dispatches stages itself — it only persists state.
Dispatch is owned by ``Dispatcher`` which is started by the API layer
(or scheduler) after a run is created.  Keeps responsibilities crisp:
engine = state, dispatcher = execution.
"""
from __future__ import annotations

import logging
import socket
import threading
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

from core.dataflow.exceptions import (
    CyclicDataFlowError,
    UnknownStageTypeError,
    DataFlowDefinitionError,
)
from core.dataflow.registry import StageTypeRegistry, get_default_registry

logger = logging.getLogger(__name__)


# ── DataFlow specification (in-memory, used at create_workflow time) ────────


class StageSpec:
    """A single stage inside a dataflow definition.

    Used as the input to ``DataFlowEngine.create_workflow``.  Kept as a
    plain class (not Pydantic) so the engine has no dependency on the
    API layer's models.
    """

    __slots__ = (
        "stage_alias", "stage_type", "seq", "predecessors", "config",
        "retry_policy", "timeout_seconds", "on_failure", "on_failure_target",
    )

    def __init__(
        self,
        stage_alias: str,
        stage_type: str,
        seq: int,
        predecessors: Optional[List[str]] = None,
        config: Optional[Dict[str, Any]] = None,
        retry_policy: Optional[Dict[str, Any]] = None,
        timeout_seconds: Optional[int] = None,
        on_failure: str = "halt",
        on_failure_target: Optional[str] = None,
    ) -> None:
        self.stage_alias = stage_alias
        self.stage_type = stage_type
        self.seq = seq
        self.predecessors = list(predecessors) if predecessors else []
        self.config = dict(config) if config else {}
        self.retry_policy = dict(retry_policy) if retry_policy else {}
        self.timeout_seconds = timeout_seconds
        self.on_failure = on_failure
        self.on_failure_target = on_failure_target


class DataFlowSpec:
    """Top-level dataflow definition (template).  Input to ``create_workflow``."""

    __slots__ = (
        "name", "description", "trigger_type", "trigger_config",
        "default_context", "stages",
    )

    def __init__(
        self,
        name: str,
        stages: List[StageSpec],
        description: Optional[str] = None,
        trigger_type: str = "manual",
        trigger_config: Optional[Dict[str, Any]] = None,
        default_context: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.name = name
        self.stages = stages
        self.description = description
        self.trigger_type = trigger_type
        self.trigger_config = dict(trigger_config) if trigger_config else {}
        self.default_context = dict(default_context) if default_context else {}


# ── Validation helpers ─────────────────────────────────────────────────────


_VALID_ON_FAILURE = {"halt", "continue", "branch_to"}


def _validate_stage_graph(
    stages: List[StageSpec],
    registry: StageTypeRegistry,
) -> None:
    """Pure-function validation — raises ``DataFlowDefinitionError``
    subclasses on any problem.  Called by ``create_workflow`` and
    ``add_version`` so bad definitions never reach the dispatcher.
    """
    if not stages:
        raise DataFlowDefinitionError("dataflow must define at least one stage")

    seen_alias: Dict[str, int] = {}
    for s in stages:
        if not s.stage_alias or not s.stage_type:
            raise DataFlowDefinitionError("every stage needs a stage_alias + stage_type")
        if s.stage_alias in seen_alias:
            raise DataFlowDefinitionError(
                f"duplicate stage_alias {s.stage_alias!r} (seq {seen_alias[s.stage_alias]} "
                f"and seq {s.seq})"
            )
        seen_alias[s.stage_alias] = s.seq

        if not registry.has(s.stage_type):
            raise UnknownStageTypeError(
                f"stage {s.stage_alias!r}: stage_type {s.stage_type!r} not registered"
            )

        if s.on_failure not in _VALID_ON_FAILURE:
            raise DataFlowDefinitionError(
                f"stage {s.stage_alias!r}: on_failure {s.on_failure!r} "
                f"must be one of {sorted(_VALID_ON_FAILURE)}"
            )
        if s.on_failure == "branch_to" and not s.on_failure_target:
            raise DataFlowDefinitionError(
                f"stage {s.stage_alias!r}: on_failure='branch_to' needs on_failure_target"
            )

        # Per-stage validate_config hook
        cls = registry.get(s.stage_type)
        errs = cls.validate_config(s.config or {})
        if errs:
            raise DataFlowDefinitionError(
                f"stage {s.stage_alias!r} config invalid: " + "; ".join(errs)
            )

    # All predecessors must point to a real alias
    for s in stages:
        for pred in s.predecessors:
            if pred not in seen_alias:
                raise DataFlowDefinitionError(
                    f"stage {s.stage_alias!r}: predecessor {pred!r} is not a defined stage"
                )
        if s.on_failure_target and s.on_failure_target not in seen_alias:
            raise DataFlowDefinitionError(
                f"stage {s.stage_alias!r}: on_failure_target "
                f"{s.on_failure_target!r} is not a defined stage"
            )

    # Cycle detection via DFS over predecessors → successors mapping
    succ: Dict[str, List[str]] = {a: [] for a in seen_alias}
    for s in stages:
        for p in s.predecessors:
            succ[p].append(s.stage_alias)

    WHITE, GREY, BLACK = 0, 1, 2
    color: Dict[str, int] = {a: WHITE for a in seen_alias}

    def dfs(node: str, path: List[str]) -> None:
        color[node] = GREY
        path.append(node)
        for nxt in succ[node]:
            if color[nxt] == GREY:
                raise CyclicDataFlowError(
                    "cycle detected in dataflow stages: " + " → ".join(path + [nxt])
                )
            if color[nxt] == WHITE:
                dfs(nxt, path)
        path.pop()
        color[node] = BLACK

    for alias in seen_alias:
        if color[alias] == WHITE:
            dfs(alias, [])


# ── DataFlowEngine ─────────────────────────────────────────────────────────


class DataFlowEngine:
    """Stateful facade.  Wraps the DB and registry; the API layer holds one
    instance.  Thread-safe via DB-level locking (no in-memory state besides
    the references to db_manager + registry).
    """

    def __init__(
        self,
        db_manager: Any,
        registry: Optional[StageTypeRegistry] = None,
        broadcast_fn: Optional[Callable[[Dict[str, Any]], None]] = None,
        worker_node: Optional[str] = None,
    ) -> None:
        if db_manager is None:
            raise ValueError("DataFlowEngine requires a db_manager")
        self.db = db_manager
        self.registry = registry or get_default_registry()
        self.broadcast_fn = broadcast_fn
        self.worker_node = worker_node or socket.gethostname()
        self._cancel_events: Dict[int, threading.Event] = {}
        self._cancel_lock = threading.Lock()

    # ── DataFlow CRUD ───────────────────────────────────────────────────

    def create_workflow(
        self,
        spec: DataFlowSpec,
        created_by: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a brand-new dataflow (version 1, draft).

        Raises ``DataFlowDefinitionError`` if the spec is bad.  Returns
        the persisted dataflow dict (id, version, status, stages).
        """
        _validate_stage_graph(spec.stages, self.registry)

        from core.db.models import DataFlow, DataFlowStage

        with self.db.get_session() as session:
            existing = (
                session.query(DataFlow)
                .filter(DataFlow.name == spec.name)
                .order_by(DataFlow.version.desc())
                .first()
            )
            if existing is not None:
                raise DataFlowDefinitionError(
                    f"dataflow {spec.name!r} already exists (version {existing.version}); "
                    f"use add_version() to bump the version"
                )

            wf = DataFlow(
                name=spec.name,
                version=1,
                status="draft",
                description=spec.description,
                trigger_type=spec.trigger_type,
                trigger_config=spec.trigger_config,
                default_context=spec.default_context,
                created_by=created_by,
            )
            session.add(wf)
            session.flush()
            for s in spec.stages:
                session.add(DataFlowStage(
                    dataflow_id=wf.id,
                    stage_alias=s.stage_alias,
                    stage_type=s.stage_type,
                    seq=s.seq,
                    predecessors=s.predecessors,
                    config=s.config,
                    retry_policy=s.retry_policy,
                    timeout_seconds=s.timeout_seconds,
                    on_failure=s.on_failure,
                    on_failure_target=s.on_failure_target,
                ))
            session.flush()
            session.refresh(wf)
            return self._workflow_dict(session, wf)

    def add_version(
        self,
        name: str,
        spec: DataFlowSpec,
        created_by: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a new draft version of an existing dataflow.

        The old version stays addressable for any in-flight runs; this
        is the editing path (since active dataflows are immutable).
        """
        _validate_stage_graph(spec.stages, self.registry)
        from core.db.models import DataFlow, DataFlowStage

        with self.db.get_session() as session:
            latest = (
                session.query(DataFlow)
                .filter(DataFlow.name == name)
                .order_by(DataFlow.version.desc())
                .first()
            )
            if latest is None:
                raise DataFlowDefinitionError(
                    f"dataflow {name!r} doesn't exist — call create_workflow()"
                )
            new_version = (latest.version or 0) + 1
            wf = DataFlow(
                name=name,
                version=new_version,
                status="draft",
                description=spec.description,
                trigger_type=spec.trigger_type,
                trigger_config=spec.trigger_config,
                default_context=spec.default_context,
                created_by=created_by,
            )
            session.add(wf)
            session.flush()
            for s in spec.stages:
                session.add(DataFlowStage(
                    dataflow_id=wf.id,
                    stage_alias=s.stage_alias,
                    stage_type=s.stage_type,
                    seq=s.seq,
                    predecessors=s.predecessors,
                    config=s.config,
                    retry_policy=s.retry_policy,
                    timeout_seconds=s.timeout_seconds,
                    on_failure=s.on_failure,
                    on_failure_target=s.on_failure_target,
                ))
            session.flush()
            session.refresh(wf)
            return self._workflow_dict(session, wf)

    def promote(self, dataflow_id: int) -> Dict[str, Any]:
        """Draft → active.  Once active a dataflow is immutable; edits
        require ``add_version``.  Also archives any prior active version
        of the same name (single-active-per-name invariant)."""
        from core.db.models import DataFlow

        with self.db.get_session() as session:
            wf = session.query(DataFlow).filter(DataFlow.id == dataflow_id).first()
            if wf is None:
                raise DataFlowDefinitionError(f"dataflow id {dataflow_id} not found")
            if wf.status != "draft":
                raise DataFlowDefinitionError(
                    f"dataflow id {dataflow_id} is {wf.status!r}, not 'draft' — cannot promote"
                )

            # Demote any currently-active version of this name to archived.
            (session.query(DataFlow)
                .filter(
                    DataFlow.name == wf.name,
                    DataFlow.status == "active",
                    DataFlow.id != wf.id,
                )
                .update({"status": "archived",
                         "updated_at": datetime.now(timezone.utc)},
                        synchronize_session=False))

            wf.status = "active"
            wf.updated_at = datetime.now(timezone.utc)
            session.flush()
            return self._workflow_dict(session, wf)

    def set_paused(self, dataflow_id: int, paused: bool) -> Dict[str, Any]:
        """Phase 132.20 — soft-pause/resume a DataFlow.

        Pausing:
        * scheduler will skip firings (it filters on is_paused)
        * manual ``start_run`` raises unless ``allow_paused=True``
        * already-running runs are NOT affected (use cancel for that)

        Resuming clears the flag.  Returns the updated workflow dict.
        """
        from core.db.models import DataFlow

        with self.db.get_session() as session:
            wf = session.query(DataFlow).filter(DataFlow.id == dataflow_id).first()
            if wf is None:
                raise DataFlowDefinitionError(f"dataflow id {dataflow_id} not found")
            wf.is_paused = bool(paused)
            wf.updated_at = datetime.now(timezone.utc)
            session.flush()
            return self._workflow_dict(session, wf)

    def set_max_run_seconds(self, dataflow_id: int,
                              max_run_seconds: Optional[int]) -> Dict[str, Any]:
        """Phase 132.25 — set/clear the HARD timeout (cancels the run when
        wall-clock exceeds the cap).  Distinct from sla_seconds (which only
        flags).  Pass None or 0 to clear.
        """
        from core.db.models import DataFlow
        with self.db.get_session() as session:
            wf = session.query(DataFlow).filter(DataFlow.id == dataflow_id).first()
            if wf is None:
                raise DataFlowDefinitionError(f"dataflow id {dataflow_id} not found")
            if max_run_seconds is not None and max_run_seconds < 0:
                raise DataFlowDefinitionError("max_run_seconds must be >= 0")
            wf.max_run_seconds = int(max_run_seconds) if max_run_seconds else None
            wf.updated_at = datetime.now(timezone.utc)
            session.flush()
            return self._workflow_dict(session, wf)

    def set_sla(self, dataflow_id: int, sla_seconds: Optional[int]) -> Dict[str, Any]:
        """Phase 132.20 — set/clear the per-run SLA budget in seconds.
        Pass None (or 0) to clear.  Affects only new runs, not in-flight.
        """
        from core.db.models import DataFlow

        with self.db.get_session() as session:
            wf = session.query(DataFlow).filter(DataFlow.id == dataflow_id).first()
            if wf is None:
                raise DataFlowDefinitionError(f"dataflow id {dataflow_id} not found")
            if sla_seconds is not None and sla_seconds < 0:
                raise DataFlowDefinitionError("sla_seconds must be >= 0")
            wf.sla_seconds = int(sla_seconds) if sla_seconds else None
            wf.updated_at = datetime.now(timezone.utc)
            session.flush()
            return self._workflow_dict(session, wf)

    def archive(self, dataflow_id: int) -> Dict[str, Any]:
        """Active → archived.  Also deactivates any schedules pointing
        at this dataflow so the scheduler stops triggering it.
        """
        from core.db.models import DataFlow, DataFlowSchedule

        with self.db.get_session() as session:
            wf = session.query(DataFlow).filter(DataFlow.id == dataflow_id).first()
            if wf is None:
                raise DataFlowDefinitionError(f"dataflow id {dataflow_id} not found")
            wf.status = "archived"
            wf.updated_at = datetime.now(timezone.utc)
            (session.query(DataFlowSchedule)
                .filter(DataFlowSchedule.dataflow_id == dataflow_id)
                .update({"is_active": False,
                         "updated_at": datetime.now(timezone.utc)},
                        synchronize_session=False))
            session.flush()
            return self._workflow_dict(session, wf)

    def list_workflows(
        self,
        name: Optional[str] = None,
        status: Optional[str] = None,
        visible_workspace_ids: Optional[List[int]] = None,
    ) -> List[Dict[str, Any]]:
        """List DataFlow definitions, optionally filtered by name/status.

        ``visible_workspace_ids`` (Phase 132.26): when None, no scoping
        (back-compat).  When set to a list (possibly empty), returns
        DataFlows whose workspace_id is NULL (global) OR in that list.
        Empty list = only globals.
        """
        from core.db.models import DataFlow

        with self.db.get_session(read_only=True) as session:
            q = session.query(DataFlow)
            if name is not None:
                q = q.filter(DataFlow.name == name)
            if status is not None:
                q = q.filter(DataFlow.status == status)
            if visible_workspace_ids is not None:
                from sqlalchemy import or_ as _or
                if visible_workspace_ids:
                    q = q.filter(_or(
                        DataFlow.workspace_id.is_(None),
                        DataFlow.workspace_id.in_(visible_workspace_ids),
                    ))
                else:
                    q = q.filter(DataFlow.workspace_id.is_(None))
            rows = q.order_by(DataFlow.name.asc(), DataFlow.version.desc()).all()
            return [self._workflow_dict(session, wf) for wf in rows]

    def set_workspace(self, dataflow_id: int,
                       workspace_id: Optional[int]) -> Dict[str, Any]:
        """Phase 132.26 — assign / clear the DataFlow's workspace scope.
        Null = global (visible to all users)."""
        from core.db.models import DataFlow
        with self.db.get_session() as session:
            wf = session.query(DataFlow).filter(DataFlow.id == dataflow_id).first()
            if wf is None:
                raise DataFlowDefinitionError(f"dataflow id {dataflow_id} not found")
            wf.workspace_id = int(workspace_id) if workspace_id else None
            wf.updated_at = datetime.now(timezone.utc)
            session.flush()
            return self._workflow_dict(session, wf)

    def get_workflow(self, dataflow_id: int) -> Optional[Dict[str, Any]]:
        from core.db.models import DataFlow

        with self.db.get_session(read_only=True) as session:
            wf = session.query(DataFlow).filter(DataFlow.id == dataflow_id).first()
            if wf is None:
                return None
            return self._workflow_dict(session, wf)

    def get_active_workflow_by_name(self, name: str) -> Optional[Dict[str, Any]]:
        from core.db.models import DataFlow

        with self.db.get_session(read_only=True) as session:
            wf = (
                session.query(DataFlow)
                .filter(DataFlow.name == name, DataFlow.status == "active")
                .first()
            )
            if wf is None:
                return None
            return self._workflow_dict(session, wf)

    # ── Run lifecycle ───────────────────────────────────────────────────

    def start_run(
        self,
        dataflow_name: str,
        context: Optional[Dict[str, Any]] = None,
        triggered_by: Optional[str] = None,
        trigger_payload: Optional[Dict[str, Any]] = None,
        parent_run_id: Optional[int] = None,
        run_as: Optional[str] = None,
        allow_paused: bool = False,
    ) -> Dict[str, Any]:
        """Persist a new ``dataflow_runs`` row + a ``dataflow_run_stages``
        row per stage in not_started state.  Returns the run dict.

        Does **not** dispatch — caller (API layer or scheduler) submits
        the run_id to the dispatcher pool.  This keeps `start_run`
        side-effect-free except for DB writes.

        ``run_as`` (Phase 132.20) — impersonation: if set, this is the
        identity downstream auth/credential resolution should use.  When
        null, the run executes as ``triggered_by``.  Audited via the
        api layer so we keep both.

        ``allow_paused`` — when False (default) a paused DataFlow refuses
        new runs.  Resume + admin-override paths pass True to bypass.
        """
        from core.db.models import (
            DataFlow, DataFlowStage, DataFlowRun, DataFlowRunStage,
        )
        from datetime import timedelta

        with self.db.get_session() as session:
            wf = (
                session.query(DataFlow)
                .filter(DataFlow.name == dataflow_name, DataFlow.status == "active")
                .first()
            )
            if wf is None:
                raise DataFlowDefinitionError(
                    f"no active dataflow named {dataflow_name!r}"
                )
            if getattr(wf, "is_paused", False) and not allow_paused:
                raise DataFlowDefinitionError(
                    f"dataflow {dataflow_name!r} is paused — resume it before running"
                )
            # Phase 132.21 — run-to-run dependency.  When the DataFlow has
            # depends_on_previous=True, refuse to start a new run if the
            # most recent run is still pending/running OR ended in a
            # non-success state.  Backfill / explicit allow_paused bypasses
            # this check (admins may need to recover from a stuck run).
            if getattr(wf, "depends_on_previous", False) and not allow_paused:
                prev = (
                    session.query(DataFlowRun)
                    .filter(DataFlowRun.dataflow_id == wf.id)
                    .order_by(DataFlowRun.id.desc())
                    .first()
                )
                if prev is not None and prev.status in (
                    "pending", "running", "failed", "partial",
                ):
                    raise DataFlowDefinitionError(
                        f"dataflow {dataflow_name!r} depends_on_previous=True and "
                        f"the previous run #{prev.id} is {prev.status!r} — "
                        f"resolve it (resume, cancel, or set allow_paused=True) "
                        f"before starting a new run"
                    )

            stages = (
                session.query(DataFlowStage)
                .filter(DataFlowStage.dataflow_id == wf.id)
                .order_by(DataFlowStage.seq.asc())
                .all()
            )
            if not stages:
                raise DataFlowDefinitionError(
                    f"dataflow {dataflow_name!r} v{wf.version} has no stages"
                )

            merged_context: Dict[str, Any] = {}
            if wf.default_context:
                merged_context.update(wf.default_context)
            if context:
                # Phase 132.38 deep-dive — strip reserved sentinel keys
                # from any nested ``_consumer_overrides`` dict so a
                # malicious caller can't smuggle a new ``where_clauses_mapping``
                # (or its underscored alias) and rewrite the publisher's
                # stage-config rules at runtime.  Belt-and-braces: the
                # stage code reads mapping from get_config(...), not from
                # overrides, so this is defence-in-depth.
                _co = context.get("_consumer_overrides") if isinstance(context, dict) else None
                if isinstance(_co, dict):
                    from core.where_clause_mapping import strip_reserved_override_keys
                    context = dict(context)
                    context["_consumer_overrides"] = strip_reserved_override_keys(_co)
                merged_context.update(context)

            # SLA snapshot: we precompute expected_completion_at against
            # *now* rather than waiting for started_at.  The dispatcher
            # recomputes it once started_at lands (see dispatcher.run).
            sla_secs = getattr(wf, "sla_seconds", None)
            run = DataFlowRun(
                dataflow_id=wf.id,
                dataflow_version=wf.version,
                dataflow_name=wf.name,
                status="pending",
                triggered_by=triggered_by,
                run_as=run_as,
                trigger_payload=trigger_payload or {},
                context=merged_context,
                parent_run_id=parent_run_id,
                worker_node=self.worker_node,
                expected_completion_at=(
                    datetime.now(timezone.utc) + timedelta(seconds=int(sla_secs))
                    if sla_secs and sla_secs > 0 else None
                ),
                sla_breached=False,
            )
            session.add(run)
            session.flush()

            for s in stages:
                session.add(DataFlowRunStage(
                    run_id=run.id,
                    stage_alias=s.stage_alias,
                    stage_type=s.stage_type,
                    seq=s.seq,
                    status="not_started",
                    attempts=0,
                ))
            session.flush()
            session.refresh(run)
            return run.to_dict()

    def cancel_run(self, run_id: int, by: Optional[str] = None) -> bool:
        """Cooperative cancel.

        1. Marks the run row status='cancelled' so a stuck run won't
           appear as forever-running on the dashboard.
        2. Sets the in-memory ``threading.Event`` (if the dispatcher is
           local to this pod) so the active stage can short-circuit.
        """
        from core.db.models import DataFlowRun

        with self.db.get_session() as session:
            run = session.query(DataFlowRun).filter(DataFlowRun.id == run_id).first()
            if run is None:
                return False
            if run.status in ("succeeded", "failed", "cancelled"):
                return True
            run.status = "cancelled"
            run.error = f"cancelled by {by or 'system'}"
            run.ended_at = datetime.now(timezone.utc)
            started = run.started_at
            if started is not None and started.tzinfo is None:
                started = started.replace(tzinfo=timezone.utc)
            if started:
                run.duration_seconds = (run.ended_at - started).total_seconds()
            session.flush()

        with self._cancel_lock:
            ev = self._cancel_events.get(run_id)
            if ev is not None:
                ev.set()
        self._broadcast({"event": "workflow_run_cancelled", "run_id": run_id,
                         "triggered_by": by})
        return True

    # ── Cancel-event plumbing (used by Dispatcher) ──────────────────────

    def _register_cancel_event(self, run_id: int, ev: threading.Event) -> None:
        with self._cancel_lock:
            self._cancel_events[run_id] = ev

    def _release_cancel_event(self, run_id: int) -> None:
        with self._cancel_lock:
            self._cancel_events.pop(run_id, None)

    # ── Broadcast helper ────────────────────────────────────────────────

    def _broadcast(self, payload: Dict[str, Any]) -> None:
        if self.broadcast_fn is None:
            return
        try:
            self.broadcast_fn(payload)
        except Exception as exc:
            logger.debug("[dataflow.engine] broadcast failed (non-fatal): %s", exc)

    # ── Internal: workflow_dict with embedded stages ────────────────────

    @staticmethod
    def _workflow_dict(session: Any, wf: Any) -> Dict[str, Any]:
        from core.db.models import DataFlowStage

        stages = (
            session.query(DataFlowStage)
            .filter(DataFlowStage.dataflow_id == wf.id)
            .order_by(DataFlowStage.seq.asc())
            .all()
        )
        d = wf.to_dict()
        d["stages"] = [s.to_dict() for s in stages]
        return d


# ── Module-level singleton accessor (production code path) ─────────────────


_engine: Optional[DataFlowEngine] = None
_engine_lock = threading.Lock()


def init_engine(
    db_manager: Any,
    broadcast_fn: Optional[Callable[[Dict[str, Any]], None]] = None,
    registry: Optional[StageTypeRegistry] = None,
) -> DataFlowEngine:
    """Set up the singleton ``DataFlowEngine``.  Called once from main.py.
    Subsequent calls overwrite — useful for tests that want a fresh engine.
    """
    global _engine
    with _engine_lock:
        _engine = DataFlowEngine(
            db_manager=db_manager,
            registry=registry,
            broadcast_fn=broadcast_fn,
        )
    return _engine


def get_engine() -> Optional[DataFlowEngine]:
    return _engine
