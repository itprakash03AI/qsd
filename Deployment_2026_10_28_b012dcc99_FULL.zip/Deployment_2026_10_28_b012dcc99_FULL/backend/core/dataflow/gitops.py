"""GitOps directory sync (Phase 132.25).

Watch a configured directory for ``*.dag.yaml`` / ``*.dag.json`` files
and apply them as DataFlow bundles.  The IaC equivalent of "kubectl
apply -R" for DataFlows: commit a YAML to a git repo, deployment syncs
it to the DB.

Bundle format mirrors the existing bundle-import endpoint:

    bundle_version: 1
    dataflow:
      name: sap_mebal_monthly
      description: ...
      trigger_type: cron
      tags: [sap, monthly]
      depends_on_previous: true
      sla_seconds: 3600
      max_run_seconds: 7200
      stages:
        - stage_alias: fetch_groups
          stage_type: sap_fetch_company_groups
          seq: 1
          config: {...}
        ...
    schedules: [...]
    notification_policies: [...]
    variables: [...]

Sync mode:
* Each file's mtime is tracked in memory (no persistent state).  On
  startup we scan everything; on each tick we apply only files whose
  mtime changed since last seen.
* "Apply" = create_workflow + add_version (if name exists) + restore
  schedules/policies/variables (inactive by default, same as the
  manual bundle-import flow — admin enables after review).
* Files outside the configured dir are ignored.  No deletes — admins
  must archive manually via UI (safety).

Config:
    dataflows.gitops_enabled: false
    dataflows.gitops_directory: /etc/querystudio/dataflows
    dataflows.gitops_poll_seconds: 30
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import threading
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class GitOpsWatcher:
    """Periodic directory scanner that imports DAG bundles from files."""

    def __init__(
        self,
        directory: str,
        engine: Any,
        db_manager: Any,
        poll_seconds: int = 30,
        is_leader_fn: Optional[Callable[[], bool]] = None,
    ) -> None:
        if not directory:
            raise ValueError("GitOpsWatcher requires a directory path")
        self.directory = os.path.abspath(directory)
        self.engine = engine
        self.db = db_manager
        self.poll_seconds = max(10, int(poll_seconds))
        self.is_leader_fn = is_leader_fn or (lambda: True)
        # path → mtime of last-applied snapshot
        self._seen: Dict[str, float] = {}
        self._stop = asyncio.Event()
        self._task: Optional[asyncio.Task] = None
        self._started = False

    async def start(self) -> None:
        if self._started:
            return
        if not os.path.isdir(self.directory):
            logger.warning("[dataflow.gitops] directory %s does not exist; "
                            "skipping watcher start", self.directory)
            return
        self._started = True
        self._stop.clear()
        self._task = asyncio.create_task(self._run_loop(),
                                          name="dataflow-gitops")
        logger.info("[dataflow.gitops] started — dir=%s poll=%ds",
                     self.directory, self.poll_seconds)

    async def stop(self) -> None:
        if not self._started:
            return
        self._stop.set()
        if self._task is not None:
            try:
                await asyncio.wait_for(self._task, timeout=5.0)
            except asyncio.TimeoutError:
                self._task.cancel()
            except Exception:
                pass
        self._started = False

    async def _run_loop(self) -> None:
        while not self._stop.is_set():
            try:
                if self.is_leader_fn():
                    applied = await asyncio.to_thread(self.scan_once)
                    if applied:
                        logger.info("[dataflow.gitops] applied %d bundle(s)", applied)
            except Exception as exc:
                logger.error("[dataflow.gitops] scan failed: %s", exc, exc_info=True)
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=self.poll_seconds)
            except asyncio.TimeoutError:
                continue

    def scan_once(self) -> int:
        """One scan pass.  Returns the number of bundles applied."""
        candidates = self._list_candidate_files()
        applied = 0
        for path in candidates:
            try:
                mtime = os.path.getmtime(path)
            except OSError:
                continue
            if self._seen.get(path) == mtime:
                continue   # unchanged since last apply
            try:
                bundle = self._load_bundle(path)
                self._apply_bundle(bundle, path)
                self._seen[path] = mtime
                applied += 1
                logger.info("[dataflow.gitops] applied %s "
                              "(name=%s, version bumped on existing)",
                              path, bundle.get("dataflow", {}).get("name"))
            except Exception as exc:
                logger.warning("[dataflow.gitops] %s failed: %s", path, exc)
        return applied

    # ── Helpers ────────────────────────────────────────────────────────

    def _list_candidate_files(self) -> List[str]:
        out: List[str] = []
        for root, _dirs, files in os.walk(self.directory):
            for f in files:
                low = f.lower()
                if low.endswith((".dag.yaml", ".dag.yml", ".dag.json")):
                    out.append(os.path.join(root, f))
        return sorted(out)

    def _load_bundle(self, path: str) -> Dict[str, Any]:
        with open(path, "r", encoding="utf-8") as fh:
            raw = fh.read()
        if path.lower().endswith(".json") or path.lower().endswith(".dag.json"):
            return json.loads(raw)
        # YAML — optional dependency.  Surface a clear message if missing.
        try:
            import yaml  # type: ignore
        except Exception as exc:
            raise RuntimeError(
                "GitOps YAML bundle requires PyYAML — install it or use "
                f".dag.json instead: {exc}"
            )
        return yaml.safe_load(raw)

    def _apply_bundle(self, bundle: Dict[str, Any], path: str) -> None:
        """Same logic as POST /api/dataflows/bundle-import, factored to
        run without a request context.  Variables / schedules / policies
        restored INACTIVE so admin reviews before going live.
        """
        if int(bundle.get("bundle_version", 0)) != 1:
            raise ValueError(f"{path}: unsupported bundle_version")
        df = bundle.get("dataflow") or {}
        if not df.get("name") or not df.get("stages"):
            raise ValueError(f"{path}: bundle.dataflow.{{name,stages}} required")
        name = df["name"]

        from core.dataflow.engine import DataFlowSpec, StageSpec
        stage_specs = [
            StageSpec(
                s["stage_alias"], s["stage_type"], seq=int(s.get("seq", 0)),
                predecessors=s.get("predecessors") or [],
                config=s.get("config") or {},
                retry_policy=s.get("retry_policy") or {},
                timeout_seconds=s.get("timeout_seconds"),
                on_failure=s.get("on_failure", "halt"),
                on_failure_target=s.get("on_failure_target"),
            )
            for s in df["stages"]
        ]
        spec = DataFlowSpec(
            name=name,
            description=df.get("description"),
            trigger_type=df.get("trigger_type", "manual"),
            trigger_config=df.get("trigger_config") or {},
            default_context=df.get("default_context") or {},
            stages=stage_specs,
        )

        existing = self.engine.list_workflows(name=name)
        if existing:
            wf = self.engine.add_version(name, spec, created_by="gitops")
        else:
            wf = self.engine.create_workflow(spec, created_by="gitops")
        wf_id = wf["id"]

        # Apply tags + SLA + deps + max_run_seconds + is_template
        try:
            from core.db.models import DataFlow
            with self.db.get_session() as session:
                row = session.query(DataFlow).filter(
                    DataFlow.id == wf_id).first()
                if row is not None:
                    row.tags = df.get("tags") or []
                    row.sla_seconds = df.get("sla_seconds")
                    row.max_run_seconds = df.get("max_run_seconds")
                    row.depends_on_previous = bool(df.get("depends_on_previous", False))
                    if df.get("is_template"):
                        row.is_template = True
                        row.template_category = df.get("template_category")
                        row.template_label = df.get("template_label")
                    session.flush()
        except Exception as exc:
            logger.warning("[gitops] tags/sla restore failed: %s", exc)

        # Schedules (inactive)
        for s in (bundle.get("schedules") or []):
            try:
                from core.db.models import DataFlowSchedule
                with self.db.get_session() as session:
                    session.add(DataFlowSchedule(
                        dataflow_id=wf_id,
                        name=s.get("name") or "imported",
                        cron_expression=s.get("cron_expression") or "",
                        calendar_rule=s.get("calendar_rule"),
                        timezone=s.get("timezone") or "UTC",
                        context_overrides=s.get("context_overrides") or {},
                        is_active=False,
                        created_by="gitops",
                    ))
            except Exception as exc:
                logger.warning("[gitops] schedule restore failed: %s", exc)

        for p in (bundle.get("notification_policies") or []):
            try:
                from core.db.models import DataFlowNotificationPolicy
                with self.db.get_session() as session:
                    session.add(DataFlowNotificationPolicy(
                        dataflow_id=wf_id,
                        name=p.get("name") or "imported",
                        event=p.get("event"),
                        channel=p.get("channel"),
                        config=p.get("config") or {},
                        is_active=False,
                        cooldown_seconds=p.get("cooldown_seconds") or 0,
                        created_by="gitops",
                    ))
            except Exception as exc:
                logger.warning("[gitops] policy restore failed: %s", exc)

        for v in (bundle.get("variables") or []):
            try:
                from core.db.models import DataFlowVariable
                with self.db.get_session() as session:
                    session.add(DataFlowVariable(
                        name=v.get("name"),
                        value=None if v.get("secret_placeholder") else v.get("value"),
                        dataflow_id=wf_id,
                        description=v.get("description"),
                        is_secret=bool(v.get("is_secret")),
                        created_by="gitops",
                    ))
            except Exception as exc:
                logger.warning("[gitops] variable restore failed: %s", exc)


# ── Module-level singleton ─────────────────────────────────────────────────


_watcher: Optional[GitOpsWatcher] = None
_lock = threading.Lock()


def init_gitops_watcher(
    directory: str,
    engine: Any,
    db_manager: Any,
    poll_seconds: int = 30,
    is_leader_fn: Optional[Callable[[], bool]] = None,
) -> Optional[GitOpsWatcher]:
    global _watcher
    with _lock:
        try:
            _watcher = GitOpsWatcher(
                directory=directory, engine=engine, db_manager=db_manager,
                poll_seconds=poll_seconds, is_leader_fn=is_leader_fn,
            )
        except Exception as exc:
            logger.warning("[dataflow.gitops] init failed: %s", exc)
            _watcher = None
    return _watcher


def get_gitops_watcher() -> Optional[GitOpsWatcher]:
    return _watcher
