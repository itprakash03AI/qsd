"""Prometheus-style /metrics exporter for the DataFlow engine.

Renders Prometheus text-format counters/gauges built from a single
DB snapshot.  No external prometheus_client dependency — we hand-roll
the format because it's stable and tiny.

Metrics exposed:
    dataflow_runs_total{status="..."}          (counter, all-time)
    dataflow_runs_24h{status="..."}            (gauge,   last 24h)
    dataflow_runs_in_flight                    (gauge)
    dataflow_runs_sla_breached_24h             (gauge)
    dataflow_definitions{status="..."}         (gauge)
    dataflow_paused                            (gauge)
    dataflow_active_schedules                  (gauge)
    dataflow_active_webhook_triggers           (gauge)
    dataflow_pending_approvals                 (gauge)
    dataflow_reschedule_pending                (gauge — sensor reschedule queue)

Designed for scraping every 30-60 seconds.  All counts read in a single
session for consistency.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone, timedelta
from typing import Any, List

logger = logging.getLogger(__name__)


def render_metrics(db_manager: Any) -> str:
    """Return Prometheus text-format metrics for the DataFlow engine.
    Never raises — errors render as a single comment line so the scrape
    succeeds with zero metrics rather than 500ing.
    """
    try:
        lines = _collect(db_manager)
    except Exception as exc:
        logger.warning("[metrics] render failed: %s", exc)
        return "# dataflow metrics unavailable: rendering failed\n"
    return "\n".join(lines) + "\n"


def _collect(db_manager: Any) -> List[str]:
    from core.db.models import (
        DataFlow, DataFlowRun, DataFlowRunStage, DataFlowSchedule,
        DataFlowApprovalRequest, DataFlowWebhookTrigger,
    )
    from sqlalchemy import func

    out: List[str] = []

    def _help_and_type(name: str, help_text: str, mtype: str) -> None:
        out.append(f"# HELP {name} {help_text}")
        out.append(f"# TYPE {name} {mtype}")

    now = datetime.now(timezone.utc)
    cutoff_24h = now - timedelta(hours=24)

    with db_manager.get_session(read_only=True) as session:
        # ── Run counters (all-time + 24h) ──
        all_by_status = dict(
            session.query(DataFlowRun.status, func.count(DataFlowRun.id))
            .group_by(DataFlowRun.status).all()
        )
        last_24h_by_status = dict(
            session.query(DataFlowRun.status, func.count(DataFlowRun.id))
            .filter(DataFlowRun.created_at >= cutoff_24h)
            .group_by(DataFlowRun.status).all()
        )
        sla_breach_24h = (
            session.query(func.count(DataFlowRun.id))
            .filter(DataFlowRun.created_at >= cutoff_24h,
                     DataFlowRun.sla_breached == True)  # noqa: E712
            .scalar() or 0
        )

        # ── Definition counts ──
        def_by_status = dict(
            session.query(DataFlow.status, func.count(DataFlow.id))
            .group_by(DataFlow.status).all()
        )
        paused_count = (
            session.query(func.count(DataFlow.id))
            .filter(DataFlow.is_paused == True)  # noqa: E712
            .scalar() or 0
        )

        # ── Operational gauges ──
        active_schedules = (
            session.query(func.count(DataFlowSchedule.id))
            .filter(DataFlowSchedule.is_active == True)  # noqa: E712
            .scalar() or 0
        )
        active_webhooks = (
            session.query(func.count(DataFlowWebhookTrigger.id))
            .filter(DataFlowWebhookTrigger.is_active == True)  # noqa: E712
            .scalar() or 0
        )
        pending_approvals = (
            session.query(func.count(DataFlowApprovalRequest.id))
            .filter(DataFlowApprovalRequest.status == "pending")
            .scalar() or 0
        )
        reschedule_pending = (
            session.query(func.count(DataFlowRunStage.id))
            .filter(DataFlowRunStage.status == "reschedule")
            .scalar() or 0
        )

    # ── Emit counters/gauges ──
    _help_and_type("dataflow_runs_total",
                    "All-time DataFlow runs by status", "counter")
    for status in ("pending", "running", "succeeded", "failed",
                    "cancelled", "partial"):
        out.append(f'dataflow_runs_total{{status="{status}"}} '
                    f'{int(all_by_status.get(status, 0))}')

    _help_and_type("dataflow_runs_24h",
                    "DataFlow runs created in the last 24 hours by status",
                    "gauge")
    for status in ("pending", "running", "succeeded", "failed",
                    "cancelled", "partial"):
        out.append(f'dataflow_runs_24h{{status="{status}"}} '
                    f'{int(last_24h_by_status.get(status, 0))}')

    in_flight = int(all_by_status.get("running", 0)) + int(all_by_status.get("pending", 0))
    _help_and_type("dataflow_runs_in_flight",
                    "Runs currently in pending/running state", "gauge")
    out.append(f"dataflow_runs_in_flight {in_flight}")

    _help_and_type("dataflow_runs_sla_breached_24h",
                    "Runs in the last 24h flagged sla_breached=True",
                    "gauge")
    out.append(f"dataflow_runs_sla_breached_24h {int(sla_breach_24h)}")

    _help_and_type("dataflow_definitions",
                    "DataFlow definitions by status", "gauge")
    for status in ("draft", "active", "archived"):
        out.append(f'dataflow_definitions{{status="{status}"}} '
                    f'{int(def_by_status.get(status, 0))}')

    _help_and_type("dataflow_paused",
                    "Active DataFlows currently soft-paused", "gauge")
    out.append(f"dataflow_paused {int(paused_count)}")

    _help_and_type("dataflow_active_schedules",
                    "Schedules with is_active=true", "gauge")
    out.append(f"dataflow_active_schedules {int(active_schedules)}")

    _help_and_type("dataflow_active_webhook_triggers",
                    "Webhook triggers with is_active=true", "gauge")
    out.append(f"dataflow_active_webhook_triggers {int(active_webhooks)}")

    _help_and_type("dataflow_pending_approvals",
                    "Approval requests awaiting decision", "gauge")
    out.append(f"dataflow_pending_approvals {int(pending_approvals)}")

    _help_and_type("dataflow_reschedule_pending",
                    "Stage rows in reschedule state (sensor queue)",
                    "gauge")
    out.append(f"dataflow_reschedule_pending {int(reschedule_pending)}")

    return out
