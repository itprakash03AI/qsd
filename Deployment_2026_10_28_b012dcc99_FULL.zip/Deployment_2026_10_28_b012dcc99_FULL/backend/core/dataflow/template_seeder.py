"""Template seeder — moves the curated starter templates from a Python
dict into the ``dataflows`` table at startup.

Why this exists:
* Templates are catalogue entries the Simple Job builder picks from.
* Admins should be able to add / edit / archive them through the UI
  without a code change.
* Templates are just DataFlow rows with ``is_template=True``.

Behaviour at startup:
* If a template with name=N already exists in the DB → SKIP (admin may
  have edited it; we don't clobber).
* If a template with name=N does NOT exist → CREATE it as a draft
  DataFlow with is_template=True + the curated category/label.

This is idempotent: safe to call on every startup.  Run order doesn't
matter — the seeder only ever ADDS rows.

This module is intentionally separate from ``templates.py`` so the
hardcoded dict can be deprecated later (Phase 132.15 will read
templates exclusively from the DB).
"""
from __future__ import annotations

import logging
from typing import Any, Dict

logger = logging.getLogger(__name__)


# ── Job-type categorisation (template_category values) ──────────────────


_CATEGORIES: Dict[str, str] = {
    "etl_createjob":                       "createJob",
    "etl_to_file":                         "file",
    "etl_starburst_to_file":               "file",
    "etl_starburst_to_file_spark_onprem":  "file",
    "etl_sap_odata_to_file":               "sap_odata",
    "etl_oracle_to_s3":                    "cloud_landing",
    "etl_s3_to_oracle":                    "cloud_return",
    "etl_file_to_oracle":                  "file_ingest",
    "etl_s3_to_s3_transform":              "cloud_transform",
    "etl_http_to_file":                    "external",
    "etl_saved_query_to_s3":               "saved_query",
    "etl_chained_after_upstream":          "cross_dag",
    "etl_wait_then_load":                  "cross_dag",
    "etl_query_convert_upload":            "saved_query",
    # BF-493 — Feed-file equivalents using native DataFlow stages.
    "feed_file_to_s3":                     "feed_file",
    "feed_file_to_local":                  "feed_file",
    "etl_shell_pipeline":                  "ad_hoc",
    "etl_orchestrator_trigger_fanout":     "orchestration",
    "etl_orchestrator_fanout":             "orchestration",
    "etl_createjob_full_onprem":           "canonical",
    "etl_file_canonical":                  "canonical",
    "etl_sap_odata_canonical":             "canonical",
    "etl_sap_odata_fanout":                "sap_odata",
    "sod_smoke_check":                     "demo",
    "cache_warmup":                        "demo",
    "conditional_demo":                    "demo",
    "sub_dataflow_chain":                  "demo",
    "wd6_report":                          "demo",
}


_LABELS: Dict[str, str] = {
    "etl_createjob":                       "ETL — Push to DB (canonical)",
    "etl_to_file":                         "ETL — To File (canonical, both sources merged)",
    "etl_starburst_to_file":               "File delivery — Starburst → File",
    "etl_starburst_to_file_spark_onprem":  "File delivery via Spark",
    "etl_sap_odata_to_file":               "SAP OData → File (group-aware)",
    "etl_oracle_to_s3":                    "Oracle → S3 (Parquet/Iceberg)",
    "etl_s3_to_oracle":                    "S3 → Oracle (Parquet/Iceberg)",
    "etl_file_to_oracle":                  "File → Oracle (CSV/Parquet)",
    "etl_s3_to_s3_transform":              "S3 → S3 transform",
    "etl_http_to_file":                    "HTTP fetch → file",
    "etl_saved_query_to_s3":               "Saved Query → File → S3 (daily snapshot)",
    "etl_chained_after_upstream":          "Cross-DAG — wait for upstream then process",
    "etl_wait_then_load":                  "Wait for SQL state, then load",
    "etl_query_convert_upload":            ".sql file → CSV → Parquet → S3",
    # BF-493 — Feed-file equivalents using native DataFlow stages.
    "feed_file_to_s3":                     "Feed File → S3 (saved-query / sql_file + CTL + email)",
    "feed_file_to_local":                  "Feed File → Local NFS (saved-query / sql_file + CTL + email)",
    "etl_shell_pipeline":                  "Shell-driven custom pipeline",
    "etl_orchestrator_trigger_fanout":     "Trigger-fanout orchestrator (non-blocking)",
    "etl_orchestrator_fanout":             "Orchestrator (sub_dataflow fan-out)",
    "etl_createjob_full_onprem":           "createJob — canonical full DAG",
    "etl_file_canonical":                  "file — canonical full pipeline",
    "etl_sap_odata_canonical":             "sap_odata — canonical full pipeline",
    "etl_sap_odata_fanout":                "SAP OData → File (DAG-level fan-out per group)",
    # Demos
    "sod_smoke_check":      "SOD smoke check (demo)",
    "cache_warmup":         "Cache warmup (demo)",
    "conditional_demo":     "Conditional branch (demo)",
    "sub_dataflow_chain":   "Sub-dataflow chain (demo)",
    "wd6_report":           "WD6 report skeleton (demo)",
}


def seed_built_in_templates(db_manager: Any) -> int:
    """Seed the curated templates as DataFlow rows.

    Returns the number of templates created.  Idempotent: skips any
    template that already exists by name.
    """
    if db_manager is None:
        logger.debug("[template_seeder] db_manager unavailable; skipping")
        return 0

    from core.dataflow.templates import _TEMPLATES
    from core.db.models import DataFlow, DataFlowStage

    created = 0
    try:
        with db_manager.get_session() as session:
            for tmpl_name, tmpl in _TEMPLATES.items():
                existing = session.query(DataFlow).filter(
                    DataFlow.name == tmpl_name,
                    DataFlow.is_template == True,  # noqa: E712
                ).first()
                if existing is not None:
                    continue

                # Create the DataFlow row
                wf = DataFlow(
                    name=tmpl_name,
                    version=1,
                    status="active",   # templates ship active for cloning
                    description=tmpl.get("description") or "",
                    trigger_type=tmpl.get("trigger_type") or "manual",
                    trigger_config=tmpl.get("trigger_config") or {},
                    default_context=tmpl.get("default_context") or {},
                    is_template=True,
                    template_category=_CATEGORIES.get(tmpl_name, "general"),
                    template_label=_LABELS.get(tmpl_name, tmpl_name),
                    created_by="system",
                )
                session.add(wf)
                session.flush()    # populate wf.id

                # Stages
                for s in (tmpl.get("stages") or []):
                    session.add(DataFlowStage(
                        dataflow_id=wf.id,
                        stage_alias=s["stage_alias"],
                        stage_type=s["stage_type"],
                        seq=s["seq"],
                        predecessors=s.get("predecessors") or [],
                        config=s.get("config") or {},
                        retry_policy=s.get("retry_policy") or {},
                        timeout_seconds=s.get("timeout_seconds"),
                        on_failure=s.get("on_failure", "halt"),
                        on_failure_target=s.get("on_failure_target"),
                    ))
                session.flush()
                created += 1
                logger.info("[template_seeder] seeded template %s (id=%d)",
                            tmpl_name, wf.id)
    except Exception as exc:
        logger.warning("[template_seeder] failed (non-fatal): %s", exc)
        return 0

    if created:
        logger.info("[template_seeder] %d new template(s) seeded into DB",
                    created)
    return created


# ── Custom stage type registration (DB-driven new bridges) ──────────────


def register_custom_stage_types(db_manager: Any, registry: Any) -> int:
    """Walk ``dataflow_custom_stage_types`` and dynamically register
    bridge stages for each active row.

    Each row points at an ETL/steps/* class.  We create a one-off
    ``_EtlBridgeBase`` subclass on the fly + register it.  The new stage
    appears in the catalogue, Simple Job picker, and DAG canvas without
    any code change.

    Idempotent: stages already in the registry are skipped (the
    registry itself dedupes by NAME so a re-call is safe).
    """
    if db_manager is None or registry is None:
        return 0
    from core.db.models import DataFlowCustomStageType
    from core.dataflow.stages.etl_bridge import _EtlBridgeBase
    from core.dataflow.base import (
        CATEGORY_SOURCE, CATEGORY_TRANSFORM, CATEGORY_SINK,
        CATEGORY_PIPELINE, CATEGORY_CONTROL, CATEGORY_QUALITY,
        CATEGORY_NOTIFY,
    )

    _CAT_MAP = {
        "source": CATEGORY_SOURCE, "transform": CATEGORY_TRANSFORM,
        "sink": CATEGORY_SINK, "pipeline": CATEGORY_PIPELINE,
        "control": CATEGORY_CONTROL, "quality": CATEGORY_QUALITY,
        "notify": CATEGORY_NOTIFY,
    }

    registered = 0
    try:
        with db_manager.get_session(read_only=True) as session:
            rows = (
                session.query(DataFlowCustomStageType)
                .filter(DataFlowCustomStageType.is_active == True)  # noqa: E712
                .all()
            )
        for row in rows:
            if registry.has(row.name):
                continue   # already registered (probably from a previous call)
            cat = _CAT_MAP.get(row.category, CATEGORY_TRANSFORM)
            # Build a new class on the fly.  The class body is just metadata
            # — execute() is inherited from _EtlBridgeBase.
            cls = type(
                f"_Custom_{row.name}",
                (_EtlBridgeBase,),
                {
                    "NAME":          row.name,
                    "CATEGORY":      cat,
                    "DESCRIPTION":   row.description or f"Custom bridge to {row.etl_module}.{row.etl_class}",
                    "IDEMPOTENCY":   row.idempotency or "configured",
                    "ETL_MODULE":    row.etl_module,
                    "ETL_CLASS":     row.etl_class,
                    "CONFIG_SCHEMA": row.config_schema or {},
                },
            )
            try:
                registry.register(cls)
                registered += 1
                logger.info(
                    "[template_seeder] registered DB-driven stage %s → %s.%s",
                    row.name, row.etl_module, row.etl_class,
                )
            except Exception as exc:
                logger.warning("[template_seeder] could not register %s: %s",
                                row.name, exc)
    except Exception as exc:
        logger.warning("[template_seeder] custom stage registration failed: %s",
                        exc)
    return registered
