"""Project Variables resolver (Phase 132.22).

Looks up values for ``{var.name}`` placeholders in stage configs at
execute() time.  Secret variables are decrypted just-in-time; the
plaintext never leaves the resolver — it lands directly in the task
dict / interpolated string the underlying ETL step receives.

Scope precedence:
1. Per-DataFlow override (dataflow_id == run.dataflow_id)
2. Global (dataflow_id IS NULL)
"""
from __future__ import annotations

import logging
import re
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


_VAR_PATTERN = re.compile(r"\{var\.([a-zA-Z_][a-zA-Z0-9_]*)\}")


class VariableResolver:
    """Loaded once per run by the dispatcher; reused across all stages
    of that run so we don't N+1 the variables table.
    """

    def __init__(self, db_manager: Any, dataflow_id: Optional[int] = None) -> None:
        self.db = db_manager
        self.dataflow_id = dataflow_id
        self._cache: Dict[str, str] = {}
        self._loaded = False

    def _load(self) -> None:
        if self._loaded:
            return
        try:
            from core.db.models import DataFlowVariable
        except Exception:
            self._loaded = True
            return
        try:
            from core.crypto import decrypt_value
        except Exception:
            decrypt_value = None  # type: ignore
        scope: Dict[str, str] = {}
        try:
            with self.db.get_session(read_only=True) as session:
                # Global first
                globals_ = session.query(DataFlowVariable).filter(
                    DataFlowVariable.dataflow_id.is_(None)).all()
                for v in globals_:
                    if v.value is None:
                        continue
                    val = v.value
                    if v.is_secret and decrypt_value is not None:
                        try:
                            val = decrypt_value(val)
                        except Exception as exc:
                            logger.debug("var %s decrypt failed: %s", v.name, exc)
                    scope[v.name] = val
                # Per-DataFlow override
                if self.dataflow_id is not None:
                    pers = session.query(DataFlowVariable).filter(
                        DataFlowVariable.dataflow_id == self.dataflow_id).all()
                    for v in pers:
                        if v.value is None:
                            continue
                        val = v.value
                        if v.is_secret and decrypt_value is not None:
                            try:
                                val = decrypt_value(val)
                            except Exception as exc:
                                logger.debug("var %s decrypt failed: %s", v.name, exc)
                        scope[v.name] = val
        except Exception as exc:
            logger.warning("VariableResolver load failed: %s", exc)
        self._cache = scope
        self._loaded = True

    def get(self, name: str, default: Any = None) -> Any:
        self._load()
        return self._cache.get(name, default)

    def expand(self, value: Any) -> Any:
        """Recursively walk a structure (dict / list / str) and replace
        every ``{var.name}`` occurrence with its resolved value.  Strings
        with no matches are returned unchanged.  Missing variables are
        left in place so the caller can decide whether to fail.
        """
        if value is None:
            return None
        if isinstance(value, str):
            if "{var." not in value:
                return value
            def _sub(m):
                name = m.group(1)
                v = self.get(name)
                return str(v) if v is not None else m.group(0)
            return _VAR_PATTERN.sub(_sub, value)
        if isinstance(value, dict):
            return {k: self.expand(v) for k, v in value.items()}
        if isinstance(value, list):
            return [self.expand(v) for v in value]
        return value
