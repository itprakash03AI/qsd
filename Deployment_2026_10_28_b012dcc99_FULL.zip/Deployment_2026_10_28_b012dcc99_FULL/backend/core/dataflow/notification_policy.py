"""Notification policy engine (Phase 132.21).

Listens for run-lifecycle events emitted by the dispatcher and fires
matching policies — email / webhook / ws broadcast.  Policies live in
``dataflow_notification_policies`` so admins manage them via UI without
touching DAGs.

Match rules (cheap, no joins):
* event matches policy.event
* policy.dataflow_id is null OR == run.dataflow_id
* policy.tag is null OR is in run's DataFlow.tags
* policy.is_active
* cooldown: now - last_fired_at >= cooldown_seconds

Fire is async + best-effort — a broken policy must not affect the run.
"""
from __future__ import annotations

import json
import logging
import threading
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# Event names — keep stable; UI + policies reference them
EVT_RUN_FAILED      = "run_failed"
EVT_RUN_SUCCEEDED   = "run_succeeded"
EVT_RUN_PARTIAL     = "run_partial"
EVT_RUN_CANCELLED   = "run_cancelled"
EVT_SLA_BREACHED    = "sla_breached"
EVT_SCHEDULE_MISSED = "schedule_missed"

ALL_EVENTS = (
    EVT_RUN_FAILED, EVT_RUN_SUCCEEDED, EVT_RUN_PARTIAL, EVT_RUN_CANCELLED,
    EVT_SLA_BREACHED, EVT_SCHEDULE_MISSED,
)


class NotificationPolicyEngine:
    """Singleton service wired at startup; the dispatcher calls
    ``on_run_event(...)`` whenever a run transitions to a notable state.
    """

    def __init__(self, db_manager: Any, broadcast_fn: Optional[Any] = None) -> None:
        self.db = db_manager
        self.broadcast_fn = broadcast_fn
        self._fire_lock = threading.Lock()

    # ── Public entry point ──────────────────────────────────────────────

    def on_run_event(self, event: str, run: Dict[str, Any]) -> int:
        """Fire matching policies for the given run-level event.

        Returns the number of policies actually fired (after cooldown
        + scope filtering).  Run argument is a plain dict (so the
        dispatcher doesn't keep a session open).
        """
        if event not in ALL_EVENTS:
            logger.debug("[notification_policy] unknown event %r — ignoring", event)
            return 0
        try:
            return self._dispatch(event, run)
        except Exception as exc:
            logger.warning("[notification_policy] on_run_event(%s) failed: %s",
                           event, exc, exc_info=True)
            return 0

    # ── Internal: load → filter → fire ─────────────────────────────────

    def _dispatch(self, event: str, run: Dict[str, Any]) -> int:
        from core.db.models import DataFlow, DataFlowNotificationPolicy

        dataflow_id = run.get("dataflow_id")
        df_tags: List[str] = []
        with self.db.get_session(read_only=True) as session:
            if dataflow_id is not None:
                wf = session.query(DataFlow).filter(DataFlow.id == dataflow_id).first()
                df_tags = list(wf.tags or []) if wf is not None else []

            policies = (
                session.query(DataFlowNotificationPolicy)
                .filter(
                    DataFlowNotificationPolicy.is_active == True,  # noqa: E712
                    DataFlowNotificationPolicy.event == event,
                )
                .all()
            )
            # Snapshot fields so we can leave the session
            snapshot = [
                {
                    "id":               p.id,
                    "name":             p.name,
                    "dataflow_id":      p.dataflow_id,
                    "tag":              p.tag,
                    "channel":          p.channel,
                    "config":           p.config or {},
                    "cooldown_seconds": p.cooldown_seconds or 0,
                    "last_fired_at":    p.last_fired_at,
                }
                for p in policies
            ]

        now = datetime.now(timezone.utc)
        fired = 0
        for pol in snapshot:
            # Scope match
            if pol["dataflow_id"] is not None and pol["dataflow_id"] != dataflow_id:
                continue
            if pol["tag"] is not None and pol["tag"] not in df_tags:
                continue
            # Cooldown
            lf = pol["last_fired_at"]
            if lf is not None and pol["cooldown_seconds"] > 0:
                if lf.tzinfo is None:
                    lf = lf.replace(tzinfo=timezone.utc)
                if (now - lf).total_seconds() < pol["cooldown_seconds"]:
                    continue
            # Fire (best-effort)
            try:
                self._fire(pol, event, run)
                self._mark_fired(pol["id"], now)
                fired += 1
            except Exception as exc:
                logger.warning(
                    "[notification_policy] fire policy %s failed: %s",
                    pol["id"], exc, exc_info=True,
                )
        return fired

    def _mark_fired(self, policy_id: int, when: datetime) -> None:
        from core.db.models import DataFlowNotificationPolicy
        try:
            with self.db.get_session() as session:
                p = session.query(DataFlowNotificationPolicy).filter(
                    DataFlowNotificationPolicy.id == policy_id,
                ).first()
                if p is not None:
                    p.last_fired_at = when
                    session.flush()
        except Exception as exc:
            logger.debug("[notification_policy] mark_fired(%s) failed: %s",
                         policy_id, exc)

    def _fire(self, policy: Dict[str, Any], event: str, run: Dict[str, Any]) -> None:
        ch = (policy.get("channel") or "").lower()
        cfg = policy.get("config") or {}
        if ch == "email":
            self._fire_email(policy, cfg, event, run)
        elif ch == "webhook":
            self._fire_webhook(policy, cfg, event, run)
        elif ch == "ws":
            self._fire_ws(policy, cfg, event, run)
        else:
            logger.warning("[notification_policy] unknown channel %r", ch)

    # ── Channel: email ─────────────────────────────────────────────────

    def _fire_email(self, policy: Dict[str, Any], cfg: Dict[str, Any],
                     event: str, run: Dict[str, Any]) -> None:
        try:
            from core.email_service import send_email, is_email_enabled
        except Exception as exc:
            logger.warning("[notification_policy] email_service unavailable: %s", exc)
            return
        # Phase 132.28 — surface SMTP-not-configured as a loud warning
        # instead of silently dropping the email.  Admins need to know
        # their policy "fired" but did nothing.
        try:
            if not is_email_enabled():
                logger.warning(
                    "[notification_policy] policy %s (%s/email) — SMTP NOT "
                    "CONFIGURED.  Email would have gone to %r.  Set "
                    "config.json email.host (or SMTP_HOST env) to enable.",
                    policy["id"], event, cfg.get("to"),
                )
                # Also push a ws event so admins watching the UI see it.
                if self.broadcast_fn is not None:
                    try:
                        self.broadcast_fn({
                            "event":       "dataflow_notification",
                            "policy_id":   policy["id"],
                            "policy_name": policy["name"],
                            "trigger":     event,
                            "severity":    "error",
                            "run_id":      run.get("id"),
                            "dataflow_name": run.get("dataflow_name"),
                            "error":       "SMTP not configured — email policy could not send",
                            "triggered_by": run.get("triggered_by"),
                        })
                    except Exception:
                        pass
                return
        except Exception as _cfg_exc:
            logger.debug("[notification_policy] SMTP check failed: %s", _cfg_exc)
        to_raw = (cfg.get("to") or "").strip()
        if not to_raw:
            logger.warning("[notification_policy] email policy %s missing 'to'", policy["id"])
            return
        recipients = [r.strip() for r in to_raw.split(",") if r.strip()]
        subj_tmpl = (cfg.get("subject")
                       or f"[QueryStudio] {event} — {{dataflow_name}} #{{run_id}}")
        body_tmpl = (cfg.get("body")
                       or "Event: {event}\nDataFlow: {dataflow_name}\n"
                          "Run id: {run_id}\nStatus: {status}\nError: {error}\n"
                          "Started: {started_at}\nEnded: {ended_at}\n")
        tmpl_ctx = {
            "event":         event,
            "run_id":        run.get("id"),
            "dataflow_name": run.get("dataflow_name"),
            "dataflow_id":   run.get("dataflow_id"),
            "status":        run.get("status"),
            "error":         run.get("error") or "",
            "started_at":    run.get("started_at") or "",
            "ended_at":      run.get("ended_at") or "",
            "triggered_by":  run.get("triggered_by") or "",
        }
        def _safe_fmt(s: str) -> str:
            try:
                return s.format(**tmpl_ctx)
            except Exception:
                return s
        subj = _safe_fmt(subj_tmpl)
        body = _safe_fmt(body_tmpl)
        send_email(
            to_addresses=recipients,
            subject=subj,
            html_body=f"<pre>{body}</pre>",
            text_body=body,
        )

    # ── Channel: webhook ───────────────────────────────────────────────

    def _fire_webhook(self, policy: Dict[str, Any], cfg: Dict[str, Any],
                       event: str, run: Dict[str, Any]) -> None:
        url = (cfg.get("url") or "").strip()
        if not url:
            logger.warning("[notification_policy] webhook policy %s missing 'url'",
                            policy["id"])
            return
        headers = cfg.get("headers") or {}
        if not isinstance(headers, dict):
            headers = {}
        headers.setdefault("Content-Type", "application/json")
        payload = {
            "policy_id":      policy["id"],
            "policy_name":    policy["name"],
            "event":          event,
            "run_id":         run.get("id"),
            "dataflow_id":    run.get("dataflow_id"),
            "dataflow_name": run.get("dataflow_name"),
            "status":         run.get("status"),
            "error":          run.get("error"),
            "started_at":     run.get("started_at"),
            "ended_at":       run.get("ended_at"),
            "triggered_by":   run.get("triggered_by"),
            "sla_breached":   bool(run.get("sla_breached")),
        }
        try:
            import requests
            requests.post(url, headers=headers,
                           data=json.dumps(payload, default=str),
                           timeout=int(cfg.get("timeout_seconds") or 10))
        except Exception as exc:
            logger.warning("[notification_policy] webhook %s POST failed: %s",
                            url, exc)

    # ── Channel: ws broadcast ──────────────────────────────────────────

    def _fire_ws(self, policy: Dict[str, Any], cfg: Dict[str, Any],
                  event: str, run: Dict[str, Any]) -> None:
        if self.broadcast_fn is None:
            return
        payload = {
            "event":        "dataflow_notification",
            "policy_id":    policy["id"],
            "policy_name":  policy["name"],
            "trigger":      event,
            "severity":     cfg.get("severity") or "warning",
            "run_id":       run.get("id"),
            "dataflow_name": run.get("dataflow_name"),
            "status":       run.get("status"),
            "error":        run.get("error"),
            "triggered_by": run.get("triggered_by"),
        }
        try:
            self.broadcast_fn(payload)
        except Exception as exc:
            logger.debug("[notification_policy] ws broadcast failed: %s", exc)


# ── Module-level singleton (set by main.py at startup) ────────────────────


_engine: Optional[NotificationPolicyEngine] = None


def init_notification_engine(
    db_manager: Any, broadcast_fn: Any = None,
) -> NotificationPolicyEngine:
    global _engine
    _engine = NotificationPolicyEngine(db_manager, broadcast_fn=broadcast_fn)
    return _engine


def get_notification_engine() -> Optional[NotificationPolicyEngine]:
    return _engine
