"""``DataFlowScheduler`` — table-driven cron service.

Single-responsibility class: poll ``dataflow_schedules`` every N seconds,
fire any rows whose ``next_run_at <= now()``, update next_run_at from the
cron expression, and submit the new run to the dispatcher's thread pool.

Separate from APScheduler because:
* Schedule state must be admin-editable without a code change.
* Leader-election piggy-backs on the existing scheduler_lease so only
  one pod fires triggers at a time.
* The dispatcher pool is dataflow-owned — APScheduler's pool is sized
  for short report jobs, not long ETL stages.

Class responsibilities:
* ``DataFlowScheduler``   — outer service (start/stop, leader gate).
* ``ScheduleTicker``      — pure tick logic (load due rows, fire, advance).
                            Split out so unit tests can drive it without
                            spinning up the async loop.
"""
from __future__ import annotations

import asyncio
import logging
import threading
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any, Callable, List, Optional

from core.dataflow.calendar_trigger import next_calendar_fire_at
from core.dataflow.cron_utils import next_fire_at

logger = logging.getLogger(__name__)


# ── ScheduleTicker (pure logic, side-effect: DB + dispatcher pool) ─────────


class ScheduleTicker:
    """One tick of the scheduler.  All the side-effecting code that the
    test suite drives directly without async."""

    def __init__(
        self,
        db_manager: Any,
        engine: Any,
        dispatcher: Any,
        executor: ThreadPoolExecutor,
    ) -> None:
        self.db = db_manager
        self.engine = engine
        self.dispatcher = dispatcher
        self.executor = executor

    def tick(self, now: Optional[datetime] = None) -> int:
        """Run a single pass: fire every due schedule, return number fired."""
        now = now or datetime.now(timezone.utc)
        if now.tzinfo is None:
            now = now.replace(tzinfo=timezone.utc)

        fired = 0
        try:
            due = self._load_due_schedules(now)
        except Exception as exc:
            logger.warning("[dataflow.scheduler] tick load failed: %s", exc)
            return 0

        for sched in due:
            try:
                # 2026-10-08: ``_fire`` SKIPS a draft / archived / paused
                # dataflow (and still advances next_run_at); counting the
                # call made ``{"fired": 1}`` a claim no run row backed.
                if self._fire(sched, now):
                    fired += 1
            except Exception as exc:
                logger.error(
                    "[dataflow.scheduler] failed to fire schedule %s (id=%s): %s",
                    sched.get("name"), sched.get("id"), exc,
                    exc_info=True,
                )
        return fired

    def _load_due_schedules(self, now: datetime) -> List[dict]:
        """Bootstrap-aware: schedules without next_run_at get one computed
        on first sight (status quo, not "missed once → fire instantly").
        """
        from core.db.models import DataFlowSchedule

        with self.db.get_session() as session:
            rows: List[DataFlowSchedule] = (
                session.query(DataFlowSchedule)
                .filter(DataFlowSchedule.is_active == True)  # noqa: E712
                .all()
            )
            due: List[dict] = []
            for s in rows:
                if s.next_run_at is None:
                    # Compute and store but don't fire on the same tick —
                    # avoids firing every active schedule the first time
                    # the scheduler starts on a fresh DB.
                    try:
                        s.next_run_at = self._compute_next(s, now)
                    except Exception as exc:
                        logger.warning(
                            "[dataflow.scheduler] schedule %s invalid: %s",
                            s.id, exc,
                        )
                    continue
                # next_run_at is comparing aware datetimes; SQLite may
                # return naive datetimes — normalise to UTC.
                nra = s.next_run_at
                if nra.tzinfo is None:
                    nra = nra.replace(tzinfo=timezone.utc)
                if nra <= now:
                    due.append(s.to_dict())
            session.flush()
            return due

    def _fire(self, sched: dict, now: datetime) -> bool:
        """Start a run, advance next_run_at, submit to the dispatcher pool.
        Returns True when a run was STARTED; False when the schedule was
        skipped (its dataflow is not active, or is paused) -- the skip
        still advances ``next_run_at``."""
        from core.db.models import DataFlow

        with self.db.get_session() as session:
            wf = session.query(DataFlow).filter(DataFlow.id == sched["dataflow_id"]).first()
            if wf is None or wf.status != "active":
                logger.info(
                    "[dataflow.scheduler] schedule %s skipped — dataflow not active",
                    sched["id"],
                )
                self._advance_next_from_sched(session, sched, now)
                return False
            # Phase 132.20 — honour pause flag.  Skip firing but DO advance
            # next_run_at so we don't catch up with a flood when un-paused.
            if getattr(wf, "is_paused", False):
                logger.info(
                    "[dataflow.scheduler] schedule %s skipped — dataflow %s is paused",
                    sched["id"], wf.name,
                )
                self._advance_next_from_sched(session, sched, now)
                return False

            # BF-523 (2026-05-28): thread the schedule's creator as
            # ``run_as`` so audit + downstream credential resolution
            # links scheduled runs back to a real user identity instead
            # of the opaque "scheduler" string.  Falls back to None
            # (executes-as-triggered_by) when the schedule has no
            # recorded creator — preserves existing behaviour for
            # rows created before the field was tracked.
            _sched_run_as = sched.get("created_by") or None
            # Make triggered_by more specific than the raw "scheduler"
            # so logs distinguish DataFlow scheduler runs from any
            # other "scheduler"-tagged source (APScheduler quartz jobs,
            # external schedulers).
            _triggered_by = (
                f"dataflow_scheduler:{sched.get('name', sched['id'])}"
            )
            run = self.engine.start_run(
                dataflow_name=wf.name,
                context=sched.get("context_overrides") or None,
                triggered_by=_triggered_by,
                run_as=_sched_run_as,
                trigger_payload={
                    "schedule_id": sched["id"],
                    "schedule_name": sched["name"],
                    "fired_at": now.isoformat(),
                    # BF-523: capture the schedule's creator in the
                    # trigger_payload too so the DataFlow run-detail
                    # page can show "scheduled by <user>" even when
                    # the schedule row is later deleted.
                    "scheduled_by": _sched_run_as,
                },
            )
            self._advance_next_from_sched(session, sched, now)

        run_id = run["id"]
        self.executor.submit(self._safe_dispatch, run_id)
        return True

    def _safe_dispatch(self, run_id: int) -> None:
        try:
            self.dispatcher.run(run_id)
        except Exception as exc:
            logger.error(
                "[dataflow.scheduler] dispatcher.run(%d) crashed: %s",
                run_id, exc, exc_info=True,
            )

    def _advance_next_from_sched(
        self,
        session: Any,
        sched: dict,
        now: datetime,
    ) -> None:
        from core.db.models import DataFlowSchedule
        row = session.query(DataFlowSchedule).filter(
            DataFlowSchedule.id == sched["id"]
        ).first()
        if row is None:
            return
        try:
            row.last_run_at = now
            row.next_run_at = self._compute_next(row, now)
        except Exception as exc:
            logger.warning(
                "[dataflow.scheduler] advance failed for schedule %s: %s",
                sched["id"], exc,
            )
            row.is_active = False
        session.flush()

    def _compute_next(self, row: Any, now: datetime) -> datetime:
        """Compute the next fire time for a schedule row — honours either
        ``calendar_rule`` JSON (preferred when present) OR
        ``cron_expression``.  Raises on bad config so the caller can
        deactivate the schedule.
        """
        tz_name = row.timezone or "UTC"
        if row.calendar_rule:
            return next_calendar_fire_at(
                row.calendar_rule, now=now, tz_name=tz_name,
                db_manager=self.db,
            )
        if row.cron_expression:
            return next_fire_at(row.cron_expression, now=now, tz_name=tz_name)
        raise ValueError("schedule has neither cron_expression nor calendar_rule")


# ── DataFlowScheduler (async outer service) ────────────────────────────────


class DataFlowScheduler:
    """Outer scheduler service.  Owns:
    * an asyncio task that ticks every ``poll_seconds``
    * a thread-pool executor that hosts dispatcher runs
    * leader-election cooperation (only ticks while leader)
    """

    def __init__(
        self,
        db_manager: Any,
        engine: Any,
        dispatcher: Any,
        poll_seconds: int = 30,
        max_concurrent_runs: int = 8,
        is_leader_fn: Optional[Callable[[], bool]] = None,
    ) -> None:
        if db_manager is None or engine is None or dispatcher is None:
            raise ValueError(
                "DataFlowScheduler requires db_manager, engine, and dispatcher"
            )
        self.db = db_manager
        self.engine = engine
        self.dispatcher = dispatcher
        self.poll_seconds = max(5, int(poll_seconds))
        self.max_concurrent_runs = max(1, int(max_concurrent_runs))
        self.is_leader_fn = is_leader_fn or (lambda: True)

        self._executor = ThreadPoolExecutor(
            max_workers=self.max_concurrent_runs,
            thread_name_prefix="wf-dispatch",
        )
        self._ticker = ScheduleTicker(
            db_manager=db_manager,
            engine=engine,
            dispatcher=dispatcher,
            executor=self._executor,
        )
        self._stop = asyncio.Event()
        self._task: Optional[asyncio.Task] = None
        self._started = False

    # ── Lifecycle ───────────────────────────────────────────────────────

    async def start(self) -> None:
        """Start the async ticker.  Returns immediately."""
        if self._started:
            return
        self._started = True
        self._stop.clear()
        self._task = asyncio.create_task(self._run_loop(), name="dataflow-scheduler")
        logger.info(
            "[dataflow.scheduler] started — poll=%ds, max_concurrent=%d",
            self.poll_seconds, self.max_concurrent_runs,
        )

    async def stop(self) -> None:
        if not self._started:
            return
        self._stop.set()
        if self._task is not None:
            try:
                await asyncio.wait_for(self._task, timeout=10.0)
            except asyncio.TimeoutError:
                self._task.cancel()
            except Exception as _stop_exc:
                # Stop-time failures are non-fatal — the executor is
                # about to be shut down anyway.
                logger.debug("[dataflow.scheduler] stop tick exception: %s",
                             _stop_exc)
        self._executor.shutdown(wait=False, cancel_futures=True)
        self._started = False
        logger.info("[dataflow.scheduler] stopped")

    # ── Inner loop ──────────────────────────────────────────────────────

    async def _run_loop(self) -> None:
        while not self._stop.is_set():
            try:
                if self.is_leader_fn():
                    fired = await asyncio.to_thread(self._ticker.tick)
                    if fired:
                        logger.info("[dataflow.scheduler] fired %d schedule(s)", fired)
                else:
                    logger.debug("[dataflow.scheduler] not leader — skip tick")
            except Exception as exc:
                logger.error("[dataflow.scheduler] tick failed: %s", exc, exc_info=True)
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=self.poll_seconds)
            except asyncio.TimeoutError:
                continue

    # ── Direct trigger (tests / API) ────────────────────────────────────

    def tick_once(self) -> int:
        """Synchronous one-shot tick.  Used by tests and the
        ``POST /api/dataflows/scheduler/tick`` debug endpoint.

        2026-10-10: gated on the SAME ``is_leader_fn`` the poll loop asks
        before every tick.  The route used to call ``_ticker.tick()``
        directly, so a POST ran a full fire pass on whichever pod served it
        -- beside the leader's loop, with no per-schedule claim -- and two
        pods (or a click beside the loop) started the same schedule twice.
        A non-leader raises :class:`NotTheScheduler`; it never ticks.
        """
        if not self.is_leader_fn():
            raise NotTheScheduler(
                "this process does not hold the scheduler singleton role "
                "(the same gate the DataFlow poll loop checks before every "
                "tick), so it does not fire schedules; run the tick on the "
                "pod that holds it")
        return self._ticker.tick()


class NotTheScheduler(RuntimeError):
    """``tick_once`` refused: this process is not the schedule-firing one."""


# ── Module-level singleton accessor ────────────────────────────────────────


_scheduler: Optional[DataFlowScheduler] = None
_scheduler_lock = threading.Lock()


def init_scheduler(
    db_manager: Any,
    engine: Any,
    dispatcher: Any,
    poll_seconds: int = 30,
    max_concurrent_runs: int = 8,
    is_leader_fn: Optional[Callable[[], bool]] = None,
) -> DataFlowScheduler:
    global _scheduler
    with _scheduler_lock:
        _scheduler = DataFlowScheduler(
            db_manager=db_manager,
            engine=engine,
            dispatcher=dispatcher,
            poll_seconds=poll_seconds,
            max_concurrent_runs=max_concurrent_runs,
            is_leader_fn=is_leader_fn,
        )
    return _scheduler


def get_scheduler() -> Optional[DataFlowScheduler]:
    return _scheduler
