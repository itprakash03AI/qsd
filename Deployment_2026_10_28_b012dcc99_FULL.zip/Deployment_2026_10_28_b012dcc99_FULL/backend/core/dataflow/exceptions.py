"""DataFlow engine exceptions.

A small, focused exception hierarchy so callers (API layer, dispatcher,
scheduler, stage authors) can distinguish *definition* errors (caught at
dataflow-create time) from *runtime* errors (caught during dispatch).
"""
from __future__ import annotations


class DataFlowError(Exception):
    """Base for all dataflow-engine errors."""


# ── Definition / validation errors (raised at create/promote time) ──────────


class DataFlowDefinitionError(DataFlowError):
    """Raised when a dataflow definition is structurally invalid:
    missing stage type, duplicate alias, cyclic predecessors, unknown
    on_failure_target, etc.  Callers should treat this as HTTP 400.
    """


class UnknownStageTypeError(DataFlowDefinitionError):
    """A workflow_stage references a stage_type that isn't registered."""


class CyclicDataFlowError(DataFlowDefinitionError):
    """The predecessors graph contains a cycle — dispatcher can't make
    progress.  Detected at create-time so admins never schedule a
    bad dataflow.
    """


# ── Runtime errors (raised during a run) ────────────────────────────────────


class DataFlowRuntimeError(DataFlowError):
    """Base for errors raised during run execution."""


class StageExecutionError(DataFlowRuntimeError):
    """Raised when a BaseStage.execute() raises — the dispatcher catches
    these, records the failure on the dataflow_run_stages row, and
    applies the stage's on_failure policy.
    """


class DataFlowCancelledError(DataFlowRuntimeError):
    """Raised by the dispatcher when an external cancel request is
    observed mid-run.  Stages can check ``ctx.is_cancelled()`` to short-
    circuit cooperatively.
    """


class DataFlowTimeoutError(DataFlowRuntimeError):
    """Raised when a stage exceeds its configured ``timeout_seconds``."""


class DataFlowVersionConflictError(DataFlowError):
    """A dataflow definition was edited after a run started; the
    dispatcher refuses to mix versions inside a single run.
    """
