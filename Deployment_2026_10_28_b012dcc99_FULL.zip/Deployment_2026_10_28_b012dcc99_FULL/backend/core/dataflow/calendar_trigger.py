"""Calendar-aware trigger resolver for dataflow schedules.

A ``calendar_rule`` on a ``workflow_schedule`` row is a small JSON
descriptor that the scheduler resolves to a concrete ``next_run_at``
timestamp.  Reuses the existing ``core.feed.calendar.BusinessCalendar``
+ holiday tables so dataflows and feeds share the same notion of
holidays / weekends / business days.

Supported rule types:

    {"type": "daily", "calendar": "US_BANKING", "hour": 9, "minute": 0,
     "skip_non_business_days": true}
        → next business day at 09:00 in the named calendar's TZ.

    {"type": "workday_n", "calendar": "US_BANKING", "n": 6,
     "hour": 10, "minute": 0}
        → 6th business day of THIS month if today is on/before it,
          else next month's WD6, at 10:00.

    {"type": "month_end", "calendar": "US_BANKING",
     "hour": 18, "minute": 30}
        → last business day of this month at 18:30 (then next month).

    {"type": "last_n_business_days_of_month", "calendar": "US_BANKING",
     "n": 6, "hour": 17, "minute": 0}
        → daily 17:00 fire WHEN we're in the last-N-business-days window.
          Outside that window, advances to the start of next month's
          window.

    {"type": "sod", "calendar": "US_BANKING", "hour": 7, "minute": 0}
    {"type": "eod", "calendar": "US_BANKING", "hour": 18, "minute": 0}
        → semantic aliases for daily(business_day, hour, minute).

    {"type": "intraday", "minute_cron": "0,30 * * * *",
     "skip_non_business_days": false}
        → wraps a sub-cron expression with optional business-day gating.

Design choices:
* Pure resolver — no DB writes, no broadcast, no side effects.  Returns
  a timezone-aware UTC ``datetime``.
* Falls back gracefully when the named calendar doesn't exist — treats
  every day as a business day so admins aren't blocked by a missing
  calendar row during initial setup.
* The dispatcher uses the same calendar API as feed_gen, so a SOD
  dataflow respects the same holiday list as the SOD feeds.
"""
from __future__ import annotations

import logging
from datetime import date as _date, datetime, time as _time, timedelta, timezone
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


# ── Public entry point ─────────────────────────────────────────────────────


def next_calendar_fire_at(
    rule: Dict[str, Any],
    *,
    now: Optional[datetime] = None,
    tz_name: str = "UTC",
    db_manager: Any = None,
) -> datetime:
    """Resolve a ``calendar_rule`` to a UTC-aware ``datetime`` strictly
    after ``now``.

    Raises ``ValueError`` for malformed rules.
    """
    if not isinstance(rule, dict) or not rule:
        raise ValueError("calendar_rule must be a non-empty dict")

    rtype = (rule.get("type") or "").strip().lower()
    if not rtype:
        raise ValueError("calendar_rule.type is required")

    tz = _resolve_tz(tz_name)
    if now is None:
        now = datetime.now(timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=timezone.utc)
    local_now = now.astimezone(tz)
    cal = _resolve_calendar(rule.get("calendar"), db_manager)

    if rtype == "daily" or rtype == "sod" or rtype == "eod":
        return _daily(local_now, cal, rule, tz)
    if rtype == "workday_n":
        return _workday_n(local_now, cal, rule, tz)
    if rtype == "month_end":
        return _month_end(local_now, cal, rule, tz)
    if rtype == "last_n_business_days_of_month":
        return _last_n_bd_window(local_now, cal, rule, tz)
    if rtype == "intraday":
        return _intraday(local_now, cal, rule, tz)
    raise ValueError(f"calendar_rule.type {rtype!r} is not supported")


# ── Helpers ────────────────────────────────────────────────────────────────


def _resolve_tz(tz_name: str):
    try:
        from zoneinfo import ZoneInfo
        return ZoneInfo(tz_name or "UTC")
    except Exception:
        return timezone.utc


def _resolve_calendar(name: Optional[str], db_manager: Any):
    """Return a ``BusinessCalendar`` instance for the named calendar, or
    a permissive "always-business-day" calendar when the name is unset
    or unknown (so the scheduler keeps firing).
    """
    if not name or db_manager is None:
        return _AlwaysBusinessCalendar()
    try:
        from core.feed.calendar import BusinessCalendar, BusinessCalendarRepo
        repo = BusinessCalendarRepo(db_manager)
        spec = repo.get(name)
        if spec is None:
            logger.warning(
                "[dataflow.calendar] calendar %r not found — falling back to "
                "always-business-day mode", name,
            )
            return _AlwaysBusinessCalendar()
        return BusinessCalendar(spec)
    except Exception as exc:
        logger.warning(
            "[dataflow.calendar] could not load calendar %r: %s — "
            "falling back to always-business-day", name, exc,
        )
        return _AlwaysBusinessCalendar()


class _AlwaysBusinessCalendar:
    """Permissive stub used when a named calendar isn't configured yet."""

    def is_business_day(self, _d: _date) -> bool:
        return True

    def previous_business_day(self, d: _date) -> _date:
        return d - timedelta(days=1)

    def previous_business_day_or_today(self, d: _date) -> _date:
        return d

    def nth_business_day_of_month(self, year: int, month: int, n: int) -> Optional[_date]:
        try:
            return _date(year, month, n)
        except ValueError:
            return None

    def is_last_n_business_days_of_month(self, d: _date, _n: int) -> bool:
        # Permissive default — always considered "in window"
        return True


# ── Rule resolvers ─────────────────────────────────────────────────────────


def _fire_time(rule: Dict[str, Any]) -> _time:
    hour = int(rule.get("hour", 0))
    minute = int(rule.get("minute", 0))
    if not (0 <= hour <= 23):
        raise ValueError(f"hour {hour} out of range")
    if not (0 <= minute <= 59):
        raise ValueError(f"minute {minute} out of range")
    return _time(hour=hour, minute=minute, second=0, microsecond=0)


def _to_utc(local_dt: datetime, tz) -> datetime:
    if local_dt.tzinfo is None:
        local_dt = local_dt.replace(tzinfo=tz)
    return local_dt.astimezone(timezone.utc)


def _daily(local_now: datetime, cal, rule: Dict[str, Any], tz) -> datetime:
    skip_non = bool(rule.get("skip_non_business_days", True))
    fire_t = _fire_time(rule)
    d = local_now.date()
    # If today is a business day and the fire time is still in the future, use today.
    candidate = datetime.combine(d, fire_t, tzinfo=tz)
    if candidate <= local_now or (skip_non and not cal.is_business_day(d)):
        d = d + timedelta(days=1)
        for _ in range(400):
            if (not skip_non) or cal.is_business_day(d):
                candidate = datetime.combine(d, fire_t, tzinfo=tz)
                break
            d = d + timedelta(days=1)
        else:
            raise ValueError("could not find a business day within 400 days")
    return _to_utc(candidate, tz)


def _workday_n(local_now: datetime, cal, rule: Dict[str, Any], tz) -> datetime:
    n = int(rule.get("n", 1))
    if n < 1 or n > 31:
        raise ValueError(f"workday_n.n={n} out of range")
    fire_t = _fire_time(rule)
    cur = local_now.date()
    # Try this month, then walk forward up to 12 months.
    for offset in range(0, 13):
        year, month = cur.year, cur.month
        if offset:
            month += offset
            while month > 12:
                month -= 12
                year += 1
        target = cal.nth_business_day_of_month(year, month, n)
        if target is None:
            continue
        candidate = datetime.combine(target, fire_t, tzinfo=tz)
        if candidate > local_now:
            return _to_utc(candidate, tz)
    raise ValueError(f"could not find WD{n} in the next 12 months")


def _month_end(local_now: datetime, cal, rule: Dict[str, Any], tz) -> datetime:
    fire_t = _fire_time(rule)
    cur = local_now.date()
    for offset in range(0, 13):
        year, month = cur.year, cur.month
        if offset:
            month += offset
            while month > 12:
                month -= 12
                year += 1
        # last day of month
        if month == 12:
            first_next = _date(year + 1, 1, 1)
        else:
            first_next = _date(year, month + 1, 1)
        last_day = first_next - timedelta(days=1)
        target = cal.previous_business_day_or_today(last_day)
        candidate = datetime.combine(target, fire_t, tzinfo=tz)
        if candidate > local_now:
            return _to_utc(candidate, tz)
    raise ValueError("could not find a month-end fire time within 12 months")


def _last_n_bd_window(local_now: datetime, cal, rule: Dict[str, Any], tz) -> datetime:
    n = int(rule.get("n", 6))
    fire_t = _fire_time(rule)
    d = local_now.date()
    for offset in range(0, 400):
        cand_d = d + timedelta(days=offset)
        if not cal.is_business_day(cand_d):
            continue
        if not cal.is_last_n_business_days_of_month(cand_d, n):
            continue
        candidate = datetime.combine(cand_d, fire_t, tzinfo=tz)
        if candidate > local_now:
            return _to_utc(candidate, tz)
    raise ValueError(f"could not find last-{n}-business-days window within 400 days")


def _intraday(local_now: datetime, cal, rule: Dict[str, Any], tz) -> datetime:
    """Intraday fires on a sub-cron, optionally gated to business days."""
    from core.dataflow.cron_utils import next_fire_at
    sub_cron = rule.get("minute_cron") or rule.get("cron")
    if not sub_cron:
        raise ValueError("intraday.minute_cron is required")
    skip_non = bool(rule.get("skip_non_business_days", False))
    base_utc = local_now.astimezone(timezone.utc)
    for _ in range(2000):
        nxt = next_fire_at(sub_cron, now=base_utc)
        # Convert to local for business-day check
        local = nxt.astimezone(tz)
        if (not skip_non) or cal.is_business_day(local.date()):
            return nxt
        base_utc = nxt
    raise ValueError(f"could not find intraday fire within 2000 iterations for cron {sub_cron!r}")
