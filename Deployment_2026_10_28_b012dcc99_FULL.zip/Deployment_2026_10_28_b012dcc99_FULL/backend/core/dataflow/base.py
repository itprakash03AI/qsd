"""``BaseStage`` — the contract every dataflow stage implements.

A *stage* is a single unit of work inside a dataflow.  Subclassing
``BaseStage`` and setting class-level metadata (NAME, CATEGORY, …) is
enough for the ``StageTypeRegistry`` to discover and register it.

Design choices:

* **Class-per-stage**, not procedural functions.  Each stage owns its
  config schema, idempotency contract, and (when needed) a hand-written
  ``validate_config`` for create-time checks.
* **Pure execute()** — receives an immutable-ish ``StageContext``,
  returns a ``StageResult``.  No global state, no module-level singletons.
* **No DB writes from inside execute()** for *state* — only ``outputs``
  go back to the run.  This makes stages trivially testable.
* **Idempotency is part of the contract.**  Authors must declare what
  rerunning a stage means (overwrite, append, or destructive).  The
  dispatcher uses this to decide whether ``rerun_stage`` is safe.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, ClassVar, Dict, List, Optional

from core.dataflow.context import StageContext, StageResult
from core.dataflow.runnability import RUNNABLE, Runnability


# ── Category constants (avoid magic strings) ───────────────────────────────


CATEGORY_SOURCE = "source"          # reads data IN
CATEGORY_TRANSFORM = "transform"    # mutates data in place
CATEGORY_SINK = "sink"              # writes data OUT
CATEGORY_PIPELINE = "pipeline"      # reads from system A + writes to system B (dual-purpose)
CATEGORY_CONTROL = "control"        # branch / wait / sub-flow
CATEGORY_QUALITY = "quality"        # validate / assert / checksum
CATEGORY_NOTIFY = "notify"          # message / log / email (no data movement)

_VALID_CATEGORIES = {
    CATEGORY_SOURCE,
    CATEGORY_TRANSFORM,
    CATEGORY_SINK,
    CATEGORY_PIPELINE,
    CATEGORY_CONTROL,
    CATEGORY_QUALITY,
    CATEGORY_NOTIFY,
}


# ── Idempotency annotations ────────────────────────────────────────────────


IDEMPOTENT_SAFE = "safe"          # rerun produces identical output (queries, reads, S3 PUT by key)
IDEMPOTENT_OVERWRITE = "overwrite"  # rerun overwrites prior output (Convert, WriteFile)
IDEMPOTENT_CONFIGURED = "configured"  # depends on stage_config (DeliverOracle: append/merge/swap)
IDEMPOTENT_UNSAFE = "unsafe"      # rerun has side effects (Email, Webhook, AuditLog) — dispatcher
                                    # warns + requires explicit override flag


# ── BaseStage ABC ──────────────────────────────────────────────────────────


class BaseStage(ABC):
    """Contract for one dataflow stage.

    Subclasses MUST:
      - set ``NAME`` (unique, used as the registry key)
      - set ``CATEGORY`` (one of the CATEGORY_* constants above)
      - implement ``execute(ctx) -> StageResult``

    Subclasses SHOULD:
      - declare ``CONFIG_SCHEMA`` describing stage_config keys
      - declare ``IDEMPOTENCY`` so the dispatcher knows whether re-run is safe
      - override ``validate_config(cfg)`` for cross-field validation
    """

    NAME: ClassVar[str] = ""
    # Human-readable label shown in the UI (palette, DAG node chips,
    # side-drawer header, catalogue cards).  When empty, falls back to a
    # Title-Cased version of NAME ("starburst_to_oracle" → "Starburst To
    # Oracle").  Pipeline stages use arrows for nicer reading
    # ("Starburst → Oracle").
    DISPLAY_NAME: ClassVar[str] = ""
    CATEGORY: ClassVar[str] = ""
    IS_CONTROL_FLOW: ClassVar[bool] = False
    DESCRIPTION: ClassVar[str] = ""
    IDEMPOTENCY: ClassVar[str] = IDEMPOTENT_SAFE
    CONFIG_SCHEMA: ClassVar[Dict[str, Any]] = {}
    INPUTS_SCHEMA: ClassVar[Dict[str, Any]] = {}
    OUTPUTS_SCHEMA: ClassVar[Dict[str, Any]] = {}
    # Phase 132.20 — pre-run cost hint.  Static baseline values per stage
    # type; overridable in ``estimate_cost(cfg)`` for config-dependent
    # estimates.  Surfaced in the DAG/Simple view "Estimate" badge so
    # users can compare DAGs before running them.
    # Units: seconds (wall-clock, p50), and USD-cents (cloud egress +
    # compute proxy).  These are deliberately rough; the goal is
    # "small vs large", not budgeting.
    COST_SECONDS: ClassVar[int] = 5
    COST_CENTS:   ClassVar[int] = 0

    # ── Identity ────────────────────────────────────────────────────────

    @classmethod
    def class_path(cls) -> str:
        return f"{cls.__module__}.{cls.__name__}"

    @classmethod
    def get_display_name(cls) -> str:
        """Pretty UI label.  Falls back to Title-Cased NAME when
        DISPLAY_NAME isn't set.
        """
        if cls.DISPLAY_NAME:
            return cls.DISPLAY_NAME
        # snake_case → Title Case
        return (cls.NAME or "").replace("_", " ").title()

    @classmethod
    def runnability(cls) -> Runnability:
        """Can this stage type execute in THIS image?  (2026-09-15)

        The default is "yes, nothing to probe" — a pure-Python stage has
        no external dependency to check.  A stage that bridges to code or
        a package the image may not carry (the ETL bridges, the SAP
        decomposed stages, ``put_kafka``) overrides this with a real probe
        from ``core.dataflow.runnability``.  Registered is not runnable;
        this is where the difference is declared.
        """
        return RUNNABLE

    @classmethod
    def _runnability_for_manifest(cls) -> Runnability:
        """``runnability()`` that can never take the catalogue down: a
        probe that raises is reported as UNDETERMINED, not as an HTTP 500
        on ``/api/dataflows/stage-types`` and not as "runnable"."""
        try:
            return cls.runnability()
        except Exception as exc:
            return Runnability.unknown(
                f"{cls.NAME}.runnability() raised {type(exc).__name__}: {exc}")

    @classmethod
    def manifest(cls) -> Dict[str, Any]:
        """The stage's DECLARATION — what ``dataflow_stage_types`` stores.

        This dict is deliberately the declaration only: the feed step
        model's ``manifest()`` is required to be a SUPERSET of these keys
        (``core/feed/step_model/contract.py``, asserted by
        ``test_feed_step_model_2026_09_05``) so one UI form renderer
        serves both catalogues.  The live ``runnable`` /
        ``unavailable_reason`` verdict is a fact about THIS image, not a
        declaration, so it is projected onto the catalogue row by
        ``StageTypeRegistry.manifests()`` (what the route and the UI read)
        via ``catalogue_row()`` below, and never persisted.
        """
        return {
            "name":            cls.NAME,
            "display_name":    cls.get_display_name(),
            "category":        cls.CATEGORY,
            "class_path":      cls.class_path(),
            "description":     cls.DESCRIPTION,
            "config_schema":   cls.CONFIG_SCHEMA,
            "inputs_schema":   cls.INPUTS_SCHEMA,
            "outputs_schema":  cls.OUTPUTS_SCHEMA,
            "is_control_flow": cls.IS_CONTROL_FLOW,
            "idempotency":     cls.IDEMPOTENCY,
            "cost_seconds":    cls.COST_SECONDS,
            "cost_cents":      cls.COST_CENTS,
        }

    @classmethod
    def catalogue_row(cls) -> Dict[str, Any]:
        """``manifest()`` plus the live verdict (2026-09-15) — the row
        ``GET /api/dataflows/stage-types`` returns, so the palette and the
        catalogue can grey out a stage this image cannot run and say why.
        Computed per call: a probe of this pod, never a stored fact."""
        return {**cls.manifest(), **cls._runnability_for_manifest().manifest_fields()}

    @classmethod
    def estimate_cost(cls, config: Optional[Dict[str, Any]] = None) -> Dict[str, int]:
        """Phase 132.20 — pre-run cost estimate for a single stage.

        Default returns the static class-level baseline.  Override for
        config-dependent estimates: e.g. ``Sleep`` returns the requested
        sleep_seconds, ``OracleLoad`` returns rows * factor.
        """
        return {"seconds": int(cls.COST_SECONDS),
                "cents":   int(cls.COST_CENTS)}

    # ── Hooks for subclasses ────────────────────────────────────────────

    @classmethod
    def validate_config(cls, config: Dict[str, Any]) -> List[str]:
        """Return a list of error strings — empty list means valid.

        Called by ``DataFlowEngine.create_workflow`` for each stage so
        bad definitions are caught at HTTP 400 time, not at run time.
        Subclasses should override for stage-specific checks.
        """
        return []

    # ── The contract ────────────────────────────────────────────────────

    @abstractmethod
    def execute(self, ctx: StageContext) -> StageResult:
        """Run this stage.  See module docstring for rules."""

    # ── Phase 132.38 — per-stage Static / Dynamic WHERE-mapping ─────────
    #
    # Same primitive Published Views and Feed Generation use.  Any SQL-
    # bearing stage that wants per-config locked-in filters AND per-run
    # consumer overrides calls ``apply_where_mapping_to_sql`` after it
    # has assembled the raw SQL string but BEFORE execution.  The
    # mapping itself lives inside the stage's own config (no schema
    # change required — just declare ``where_clauses`` in CONFIG_SCHEMA
    # alongside the other fields) and the per-run overrides flow in via
    # ``ctx.run_context["_consumer_overrides"]`` which the engine
    # dispatcher seeds from the RunStartBody's optional override map.
    @staticmethod
    def apply_where_mapping_to_sql(
        sql: Optional[str],
        ctx: "StageContext",
    ) -> Optional[str]:
        """Wrap ``sql`` with the stage's Static + Dynamic-override filters.

        Reads ``where_clauses`` off the stage config and consumer
        overrides off ``ctx.run_context["_consumer_overrides"]``.
        Returns ``sql`` unchanged when neither is present so legacy
        stages without a mapping run identically.

        Phase 132.38 SOD-equivalence: DataFlow runs (cron / event /
        manual) don't have an ``apply_to_raw_sql`` downstream
        substitutor like feeds do, so ``{{calendar_token}}`` strings
        inside a Dynamic row's default value would otherwise reach the
        executed SQL verbatim and fail.  We resolve them HERE — after
        the wrap, before returning — against ``ctx.run_context`` first
        and a today-UTC fallback for the standard date tokens
        (``business_date``, ``business_date_yyyymmdd``,
        ``business_date_iso``, ``run_date``, ``prev_business_day``).
        Publishers using DataFlow get the same calendar-token
        contract feed publishers already had at SOD.
        """
        if not sql or not isinstance(sql, str):
            return sql
        mapping = ctx.get_config("where_clauses") or []
        if not isinstance(mapping, list) or not mapping:
            return sql
        overrides_raw = ctx.run_context.get("_consumer_overrides") if ctx.run_context else None
        overrides = overrides_raw if isinstance(overrides_raw, dict) else {}
        # Build the synthetic feed-style config dict the shared helper
        # already understands so we don't re-implement the merge logic.
        fake_cfg = {
            "query_params": {"_where_clauses_mapping": mapping},
            "_consumer_overrides": overrides,
            "id": ctx.run_context.get("stage_id"),
        }
        try:
            from core.feed_where_apply import apply_where_to_raw_sql
            wrapped = apply_where_to_raw_sql(sql, fake_cfg)
            if not wrapped or wrapped == sql:
                return sql
            # Resolve any ``{{calendar_token}}`` placeholders that
            # survived the wrap.  Order:
            #   1. ctx.run_context (any caller-supplied token wins)
            #   2. _consumer_overrides (per-run dict)
            #   3. Built-in date defaults (today UTC business_date
            #      family + run_date family).
            import re as _re_tok
            from datetime import datetime as _dt_tok, timezone as _tz_tok
            _tokens: dict = {}
            _today = _dt_tok.now(_tz_tok.utc).date()
            _iso = _today.isoformat()
            _yyyymmdd = _today.strftime("%Y%m%d")
            _tokens.update({
                "business_date":            _iso,
                "business_date_iso":        _iso,
                "business_date_yyyymmdd":   _yyyymmdd,
                "run_date":                 _iso,
                "run_date_iso":             _iso,
                "run_date_yyyymmdd":        _yyyymmdd,
            })
            # run_context wins over built-ins; overrides win over both.
            if ctx.run_context:
                for k, v in ctx.run_context.items():
                    if isinstance(k, str) and not k.startswith("_") and v is not None:
                        _tokens[k] = str(v)
            for k, v in (overrides or {}).items():
                if v is not None:
                    _tokens[k] = str(v)

            def _resolve(m):
                key = m.group(1)
                if key not in _tokens:
                    return m.group(0)
                # SQL-escape single quotes so a value containing ``'``
                # cannot break out of the wrap's string literal.
                return str(_tokens[key]).replace("'", "''")

            return _re_tok.sub(r"\{\{(\w+)\}\}", _resolve, wrapped)
        except Exception as exc:
            # 2026-08-19 -- was fail-OPEN ("a bug in the wrap layer must not
            # break the stage").  But running unwrapped does not degrade the
            # stage, it WIDENS it: the stage processes rows the mapping
            # excludes and writes them downstream.  A filter is a correctness
            # gate; only a cap may quietly throttle.
            import logging as _logging
            _logging.getLogger("dataflow.where_wrap").error(
                "apply_where_mapping_to_sql FAILED (%s) -- failing the stage "
                "rather than processing unfiltered rows", exc, exc_info=True,
            )
            raise

    # ── Self-validation at class-definition time ────────────────────────

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        # Abstract intermediates (e.g. ControlFlowStage base) are allowed
        # to skip these checks via setting NAME = "" deliberately.
        if not cls.NAME:
            return
        if cls.CATEGORY not in _VALID_CATEGORIES:
            raise TypeError(
                f"{cls.__name__}: CATEGORY {cls.CATEGORY!r} not in "
                f"{sorted(_VALID_CATEGORIES)!r}"
            )
        if cls.IDEMPOTENCY not in {
            IDEMPOTENT_SAFE, IDEMPOTENT_OVERWRITE,
            IDEMPOTENT_CONFIGURED, IDEMPOTENT_UNSAFE,
        }:
            raise TypeError(
                f"{cls.__name__}: IDEMPOTENCY {cls.IDEMPOTENCY!r} invalid"
            )
