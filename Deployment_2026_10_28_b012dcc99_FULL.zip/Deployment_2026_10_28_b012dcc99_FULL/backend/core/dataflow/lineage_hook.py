"""DataFlow → QueryStudio lineage integration (Phase 132.23).

After a DataFlow run completes, walk its stage outputs and record any
"this run produced X" / "this run consumed Y" relationships into the
existing TableLineageEntry table.  This lets the QueryStudio lineage
graph answer "which DataFlow produced this file?" / "what tables does
the sap_mebal_monthly DAG touch?".

We use ``query_type="dataflow_run"`` and ``query_id=run_id`` so it
slots into the existing lineage schema with zero changes.

Output / Input detection heuristics (no static schema — stages are
free-form):

* Output paths    : keys ``output_path``, ``file_path``, ``s3_path``,
                     ``ctl_file``, ``consolidated_file`` on a stage's
                     outputs dict → recorded with access_type='write'.
* Output tables   : keys ``dest_table``, ``target_table`` →
                     access_type='write'.
* Source paths    : keys ``input_path``, ``input_glob`` on transform /
                     sink stages → access_type='read'.
* SQL stage refs  : when a stage runs raw SQL we leverage the existing
                     sqlglot-based table extraction (best effort).

Best-effort: any failure logs at debug and skips that stage.  Never
raises — lineage is a side-effect, not a contract.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List

logger = logging.getLogger(__name__)


_OUTPUT_PATH_KEYS  = ("output_path", "file_path", "s3_path",
                       "ctl_file", "consolidated_file", "compressed_files")
_OUTPUT_TABLE_KEYS = ("dest_table", "target_table", "oracle_table")
_INPUT_PATH_KEYS   = ("input_path", "input_glob")
_INPUT_TABLE_KEYS  = ("source_table",)


def record_run_lineage(run_id: int, db_manager: Any) -> int:
    """Walk a finished run's stage rows + write TableLineageEntry rows.

    Returns the number of entries created.  Best-effort: caller must not
    rely on success.
    """
    try:
        return _record(run_id, db_manager)
    except Exception as exc:
        logger.debug("[dataflow.lineage] record_run_lineage(%d) failed: %s",
                     run_id, exc)
        return 0


def _record(run_id: int, db_manager: Any) -> int:
    from core.db.models import (
        DataFlowRun, DataFlowRunStage,
    )
    entries: List[Dict[str, Any]] = []
    with db_manager.get_session(read_only=True) as session:
        run = session.query(DataFlowRun).filter(
            DataFlowRun.id == run_id).first()
        if run is None:
            return 0
        stage_rows = (
            session.query(DataFlowRunStage)
            .filter(DataFlowRunStage.run_id == run_id,
                     DataFlowRunStage.status == "succeeded")
            .order_by(DataFlowRunStage.seq.asc())
            .all()
        )
        for s in stage_rows:
            outputs = s.outputs or {}
            inputs  = s.inputs or {}

            # OUTPUT: path-like writes
            for k in _OUTPUT_PATH_KEYS:
                v = outputs.get(k)
                if isinstance(v, str) and v:
                    entries.append({
                        "table_name": v,
                        "access_type": "write",
                        "extraction_method": f"dataflow:{s.stage_type}:{k}",
                    })
                elif isinstance(v, list):
                    for item in v:
                        if isinstance(item, str) and item:
                            entries.append({
                                "table_name": item,
                                "access_type": "write",
                                "extraction_method": f"dataflow:{s.stage_type}:{k}",
                            })
            # OUTPUT: Oracle / SQL table writes
            for k in _OUTPUT_TABLE_KEYS:
                v = outputs.get(k) or (s.inputs or {}).get(k)
                if isinstance(v, str) and v:
                    entries.append({
                        "table_name": v,
                        "access_type": "write",
                        "extraction_method": f"dataflow:{s.stage_type}:{k}",
                    })

            # INPUT: file inputs
            for k in _INPUT_PATH_KEYS:
                v = inputs.get(k) or outputs.get(k)
                if isinstance(v, str) and v:
                    entries.append({
                        "table_name": v,
                        "access_type": "read",
                        "extraction_method": f"dataflow:{s.stage_type}:{k}",
                    })
            # INPUT: SQL source tables
            for k in _INPUT_TABLE_KEYS:
                v = inputs.get(k)
                if isinstance(v, str) and v:
                    entries.append({
                        "table_name": v,
                        "access_type": "read",
                        "extraction_method": f"dataflow:{s.stage_type}:{k}",
                    })

    if not entries:
        return 0

    # Dedupe and persist
    seen = set()
    deduped = []
    for e in entries:
        key = (e["table_name"], e["access_type"])
        if key in seen:
            continue
        seen.add(key)
        deduped.append({**e,
                         "query_type": "dataflow_run",
                         "query_id": run_id})

    try:
        # Use the existing upsert (replaces all for this query_id).
        db_manager.upsert_table_lineage(
            query_type="dataflow_run", query_id=run_id, entries=deduped,
        )
    except Exception as exc:
        logger.debug("[dataflow.lineage] upsert failed: %s", exc)
        return 0
    return len(deduped)
