"""Starter dataflow templates.

Each template is a plain dict in the same shape as ``WorkflowCreateBody``.
Admins clone one of these via ``POST /api/dataflows/templates/{name}/apply``
to get a working draft they can then edit + promote.

Adding a new template is a single dict append — keep the surface
minimal and curated so the UI stays scannable.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional


# ── Template registry ──────────────────────────────────────────────────────


_TEMPLATES: Dict[str, Dict[str, Any]] = {

    # ═══════════════════════════════════════════════════════════════════════
    # PRODUCTION ETL PATTERNS (mirror ETL/config/step_mapping.yaml).
    # These give admins a one-click starting point for the most common
    # pipelines.  Each template wires the standard 5-7 stage shape:
    #   pre-check → extract → transform → integrity → deliver → notify
    # ═══════════════════════════════════════════════════════════════════════

    # ── file: Starburst → File delivery ──────────────────────────────────
    "etl_starburst_to_file": {
        "name": "etl_starburst_to_file",
        "description": (
            "Standard file-delivery ETL: extract from Starburst, "
            "consolidate per-group files into a single output, compress, "
            "create a CTL control file, then deliver to the destination. "
            "Mirrors the 'file' DAG in step_mapping.yaml."
        ),
        "trigger_type": "cron",
        "default_context": {
            "business_date":   "{{business_date}}",
            "output_dir":      "/tmp/feed_output",
            "output_format":   "csv",
        },
        "stages": [
            {"stage_alias": "check_deps", "stage_type": "check_dependencies",
             "seq": 1, "config": {"task": {}}},
            {"stage_alias": "gen_sql", "stage_type": "render_sql",
             "seq": 2, "predecessors": ["check_deps"], "config": {"task": {}}},
            {"stage_alias": "extract", "stage_type": "starburst_to_file",
             "seq": 3, "predecessors": ["gen_sql"], "config": {"task": {}},
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 30}},
            {"stage_alias": "consolidate", "stage_type": "consolidate_files",
             "seq": 4, "predecessors": ["extract"], "config": {"task": {}}},
            {"stage_alias": "compress", "stage_type": "compress_files",
             "seq": 5, "predecessors": ["consolidate"], "config": {"task": {}}},
            {"stage_alias": "ctl_file", "stage_type": "create_ctl_file",
             "seq": 6, "predecessors": ["compress"], "config": {"task": {}}},
            {"stage_alias": "deliver", "stage_type": "deliver_files",
             "seq": 7, "predecessors": ["ctl_file"], "config": {"task": {}},
             "retry_policy": {"max_attempts": 3, "backoff_seconds": 60}},
            {"stage_alias": "notify", "stage_type": "send_email_notifications",
             "seq": 8, "predecessors": ["deliver"], "config": {"task": {}}},
        ],
    },

    # ═══════════════════════════════════════════════════════════════════════
    # SAP OData → File (with company-code grouping).
    # Reads from a SAP OData endpoint that returns company codes, bin-packs
    # them into groups (default 5), downloads MEBAL data per group in
    # parallel ($top/$skip pagination), then consolidates → compress → CTL
    # → deliver.  Group-level checkpointing means failed groups re-run
    # without restarting the whole download.
    # ═══════════════════════════════════════════════════════════════════════
    "etl_sap_odata_to_file": {
        "name": "etl_sap_odata_to_file",
        "description": (
            "SAP OData → file.  Fetches company codes from SAP, bin-packs "
            "them into groups, downloads MEBAL data per group in parallel "
            "(checkpointed), consolidates per-group CSVs into one file, "
            "compresses, builds a CTL control file, delivers to SFTP / "
            "NFS / S3, emails a completion notice.  SAP + delivery "
            "credentials come from QueryStudio Connections (encrypted, "
            "system-account backed) — pick connection IDs in the side "
            "drawer, never inline username/password.  SMTP comes from "
            "core.email_service (config.json email.* / SMTP_* env)."
        ),
        "trigger_type": "cron",
        "default_context": {
            "p_gjahr":      "",
            "p_poper":      "",
            "output_dir":   "/tmp/sap_output",
            "output_format": "csv",
        },
        "stages": [
            {"stage_alias": "check_deps",   "stage_type": "check_dependencies",
             "seq": 1, "config": {"task": {}}},
            {"stage_alias": "sap_download", "stage_type": "sap_odata_download",
             "seq": 2, "predecessors": ["check_deps"],
             "config": {
                 # Phase 132.20 — credentials via Connection, not inline.
                 # The Connection's encrypted config must carry: base_url,
                 # username, password.  The bridge auto-injects them into
                 # the task dict at runtime.
                 "sap_connection_id":       0,
                 "odata_service_path":      "",
                 "company_code_endpoint":   "",
                 "output_dir":              "/tmp/sap_output",
                 # Optional with sensible defaults.
                 "num_groups":              5,
                 "max_parallel_groups":     3,
                 "period_mode":             "current",
             },
             "retry_policy": {"max_attempts": 3, "backoff_seconds": 30,
                                "exponential": True}},
            {"stage_alias": "merge",        "stage_type": "consolidate_files",
             "seq": 3, "predecessors": ["sap_download"], "config": {"task": {}}},
            {"stage_alias": "completeness", "stage_type": "check_completeness",
             "seq": 4, "predecessors": ["merge"], "config": {"task": {}}},
            {"stage_alias": "compress",     "stage_type": "compress_files",
             "seq": 5, "predecessors": ["completeness"], "config": {"task": {}}},
            {"stage_alias": "ctl_file",     "stage_type": "create_ctl_file",
             "seq": 6, "predecessors": ["compress"], "config": {"task": {}}},
            {"stage_alias": "deliver",      "stage_type": "deliver_files",
             "seq": 7, "predecessors": ["ctl_file"],
             "config": {
                 "delivery_type":      "nfs",
                 # When delivery_type=sftp, set sftp_connection_id (encrypted
                 # host/user/password) + sftp_remote_dir.  Same for s3.
                 "sftp_connection_id": 0,
                 "sftp_remote_dir":    "/inbound/sap_mebal",
                 "s3_connection_id":   0,
                 "s3_bucket":          "",
                 "s3_prefix":          "sap/mebal/",
             },
             "retry_policy": {"max_attempts": 3, "backoff_seconds": 60}},
            {"stage_alias": "notify",       "stage_type": "send_email",
             "seq": 8, "predecessors": ["deliver"],
             "config": {
                 "to":      "ops@example.com",
                 "subject": "SAP MEBAL — {business_date} delivered",
                 "body":    "SAP month-end balance feed for {business_date} "
                              "completed successfully.",
             }},
        ],
    },

    # ── Oracle → S3 Parquet ETL ──────────────────────────────────────────
    "etl_oracle_to_s3": {
        "name": "etl_oracle_to_s3",
        "description": (
            "Cloud landing: extract a partition / window from Oracle and "
            "write it to S3 as Parquet.  Adds a row-count check after the "
            "write so an empty extract fails fast.  Pair with a "
            "month_end calendar rule for archival jobs."
        ),
        "trigger_type": "cron",
        "default_context": {"business_date": "{{business_date}}"},
        "stages": [
            {"stage_alias": "pre_validate", "stage_type": "pre_data_validation",
             "seq": 1, "config": {"task": {}}},
            {"stage_alias": "extract", "stage_type": "oracle_to_s3",
             "seq": 2, "predecessors": ["pre_validate"], "config": {"task": {}},
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 60}},
            {"stage_alias": "row_count_check", "stage_type": "row_count_check",
             "seq": 3, "predecessors": ["extract"],
             "config": {"source_alias": "extract", "min_rows": 1}},
            {"stage_alias": "notify", "stage_type": "send_email_notifications",
             "seq": 4, "predecessors": ["row_count_check"], "config": {"task": {}}},
        ],
    },

    # ── CSV file → Oracle ────────────────────────────────────────────────
    "etl_file_to_oracle": {
        "name": "etl_file_to_oracle",
        "description": (
            "Ingest a CSV file into an Oracle table.  Use when a "
            "vendor / upstream system drops a daily file you need "
            "loaded into the warehouse.  Pre-validate, clear staging, "
            "load, check completeness, notify."
        ),
        "trigger_type": "cron",
        "default_context": {"business_date": "{{business_date}}"},
        "stages": [
            {"stage_alias": "wait_for_file", "stage_type": "wait_for_file",
             "seq": 1,
             "config": {"path": "/incoming/{business_date}.csv",
                          "timeout_seconds": 3600, "poll_seconds": 30}},
            {"stage_alias": "pre_validate", "stage_type": "pre_data_validation",
             "seq": 2, "predecessors": ["wait_for_file"], "config": {"task": {}}},
            {"stage_alias": "clear_staging", "stage_type": "clear_staging",
             "seq": 3, "predecessors": ["pre_validate"], "config": {"task": {}}},
            {"stage_alias": "load", "stage_type": "file_to_oracle",
             "seq": 4, "predecessors": ["clear_staging"], "config": {"task": {}},
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 60}},
            {"stage_alias": "completeness", "stage_type": "check_completeness",
             "seq": 5, "predecessors": ["load"], "config": {"task": {}}},
            {"stage_alias": "notify", "stage_type": "send_email_notifications",
             "seq": 6, "predecessors": ["completeness"], "config": {"task": {}}},
        ],
    },

    # ── S3 → S3 transform ────────────────────────────────────────────────
    "etl_s3_to_s3_transform": {
        "name": "etl_s3_to_s3_transform",
        "description": (
            "S3 → S3 transform: read source data from one S3 prefix, "
            "apply format / partition / column transforms, write to a "
            "destination prefix.  Useful for landing-zone → curated "
            "promotions."
        ),
        "trigger_type": "cron",
        "default_context": {"business_date": "{{business_date}}"},
        "stages": [
            {"stage_alias": "transform", "stage_type": "s3_to_s3_transform",
             "seq": 1, "config": {"task": {}},
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 60}},
            {"stage_alias": "row_count_check", "stage_type": "row_count_check",
             "seq": 2, "predecessors": ["transform"],
             "config": {"source_alias": "transform", "min_rows": 1}},
            {"stage_alias": "notify", "stage_type": "send_email_notifications",
             "seq": 3, "predecessors": ["row_count_check"], "config": {"task": {}}},
        ],
    },

    # ── S3 Parquet → Oracle (cloud return for Parquet) ──────────────────
    "etl_s3_to_oracle": {
        "name": "etl_s3_to_oracle",
        "description": (
            "Read S3 Parquet snapshots back into Oracle.  Use for cases "
            "where downstream reporting / OLTP needs the cloud-derived "
            "data."
        ),
        "trigger_type": "cron",
        "default_context": {"business_date": "{{business_date}}"},
        "stages": [
            {"stage_alias": "clear_staging", "stage_type": "clear_staging",
             "seq": 1, "config": {"task": {}}},
            {"stage_alias": "load", "stage_type": "s3_to_oracle",
             "seq": 2, "predecessors": ["clear_staging"], "config": {"task": {}},
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 60}},
            {"stage_alias": "completeness", "stage_type": "check_completeness",
             "seq": 3, "predecessors": ["load"], "config": {"task": {}}},
            {"stage_alias": "notify", "stage_type": "send_email_notifications",
             "seq": 4, "predecessors": ["completeness"], "config": {"task": {}}},
        ],
    },

    # ═══════════════════════════════════════════════════════════════════════
    # ENTERPRISE / GENERIC PATTERNS using the new stages.

    # ── Cross-DAG dependency chain ──────────────────────────────────────
    # Wait for the upstream DataFlow's morning batch to complete before
    # running.  Pair this DataFlow's Daily Batch — Morning schedule with
    # the upstream's: the wait stage will block until the upstream's run
    # for today reaches "succeeded".
    "etl_chained_after_upstream": {
        "name": "etl_chained_after_upstream",
        "description": (
            "Cross-DAG dependency.  Waits for an upstream DataFlow's run "
            "with the same business_date to finish before doing its own "
            "work.  Set 'upstream_name' global parameter to the name of "
            "the upstream DataFlow."
        ),
        "trigger_type": "cron",
        "default_context": {
            "business_date":  "{{business_date}}",
            "upstream_name":  "etl_createjob",
        },
        "stages": [
            {"stage_alias": "wait_upstream", "stage_type": "wait_for_dataflow_run",
             "seq": 1,
             "config": {
                 "dataflow_name":         "{upstream_name}",
                 "match_context_keys":    ["business_date"],
                 "acceptable_statuses":   ["succeeded", "partial"],
                 "poll_seconds":          30,
                 "timeout_seconds":       3600,
                 "require_recent_minutes": 1440,
             }},
            {"stage_alias": "process",       "stage_type": "process_data",
             "seq": 2, "predecessors": ["wait_upstream"], "config": {"task": {}}},
            {"stage_alias": "notify",        "stage_type": "send_email_notifications",
             "seq": 3, "predecessors": ["process"], "config": {"task": {}}},
        ],
    },

    # ── Wait for upstream SQL state before processing ────────────────────
    # Useful when a non-DataFlow producer drops data into a table you
    # need to consume.  Poll a "is the partition ready?" query until
    # it returns truthy.
    "etl_wait_then_load": {
        "name": "etl_wait_then_load",
        "description": (
            "Wait for an upstream table's partition for today's business_date "
            "to be populated, then run the load.  Replaces ad-hoc cron "
            "scheduling 'long enough after the upstream finishes'."
        ),
        "trigger_type": "cron",
        "default_context": {
            "business_date": "{{business_date}}",
        },
        "stages": [
            {"stage_alias": "wait_partition", "stage_type": "wait_for_sql_condition",
             "seq": 1,
             "config": {
                 "sql": ("SELECT COUNT(*) FROM upstream.facts "
                          "WHERE business_date = '{business_date}'"),
                 "poll_seconds":    60,
                 "timeout_seconds": 7200,
             }},
            {"stage_alias": "load",           "stage_type": "starburst_to_oracle",
             "seq": 2, "predecessors": ["wait_partition"],
             "config": {"location": "onprem"},
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 60}},
            {"stage_alias": "completeness",   "stage_type": "check_completeness",
             "seq": 3, "predecessors": ["load"], "config": {"task": {}}},
            {"stage_alias": "notify",         "stage_type": "send_email_notifications",
             "seq": 4, "predecessors": ["completeness"], "config": {"task": {}}},
        ],
    },

    # ── Run a saved query, convert format, upload ───────────────────────
    # Demonstrates sql_file_id (from BQB/CQB), full-result write, format
    # conversion, S3 upload — all chained.
    "etl_query_convert_upload": {
        "name": "etl_query_convert_upload",
        "description": (
            "Run a BQB/CQB .sql file, write its results to a CSV, "
            "convert to Parquet for downstream consumers, upload to S3.  "
            "Set sql_file_id in the run_query stage."
        ),
        "trigger_type": "cron",
        "default_context": {
            "business_date":  "{{business_date}}",
            "local_dir":      "/tmp/etl_exports",
            "s3_bucket":      "",
            "s3_prefix":      "exports/{business_date}",
        },
        "stages": [
            {"stage_alias": "run_query", "stage_type": "sql_query",
             "seq": 1,
             "config": {
                 "sql_file_id":      0,      # admin picks via the .sql file dropdown
                 "output_file_path": "{local_dir}/{business_date}.csv",
                 "output_format":    "csv",
             },
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 30}},
            {"stage_alias": "row_count_check", "stage_type": "row_count_check",
             "seq": 2, "predecessors": ["run_query"],
             "config": {"source_alias": "run_query", "min_rows": 1}},
            {"stage_alias": "convert",   "stage_type": "convert_file_format",
             "seq": 3, "predecessors": ["row_count_check"],
             "config": {
                 "input_path":   "{local_dir}/{business_date}.csv",
                 "output_path":  "{local_dir}/{business_date}.parquet",
                 "input_format":  "csv",
                 "output_format": "parquet",
                 "delete_input":  True,
             }},
            {"stage_alias": "checksum",  "stage_type": "checksum",
             "seq": 4, "predecessors": ["convert"],
             "config": {
                 "path":      "{local_dir}/{business_date}.parquet",
                 "algorithm": "sha256",
             }},
            {"stage_alias": "upload",    "stage_type": "s3_put",
             "seq": 5, "predecessors": ["checksum"],
             "config": {
                 "bucket":     "{s3_bucket}",
                 "key":        "{s3_prefix}/snapshot.parquet",
                 "local_path": "{local_dir}/{business_date}.parquet",
                 "content_type": "application/octet-stream",
             },
             "retry_policy": {"max_attempts": 3, "backoff_seconds": 30,
                                "exponential": True}},
            {"stage_alias": "notify",    "stage_type": "notify",
             "seq": 6, "predecessors": ["upload"],
             "config": {
                 "message":  "Snapshot uploaded to s3://{s3_bucket}/{s3_prefix}/",
                 "severity": "success",
             }},
        ],
    },

    # ── Shell-driven ad-hoc pipeline ────────────────────────────────────
    # Demonstrates the shell_command escape hatch — useful for vendor
    # tools that aren't covered by a typed stage yet.
    "etl_shell_pipeline": {
        "name": "etl_shell_pipeline",
        "description": (
            "Generic shell-driven pipeline.  Use when the operation isn't "
            "covered by a typed stage — e.g. vendor CLI, gpg encryption, "
            "rsync to a partner."
        ),
        "trigger_type": "cron",
        "default_context": {
            "business_date": "{{business_date}}",
            "source_dir":    "/tmp/source",
            "target_host":   "partner.example.com",
        },
        "stages": [
            {"stage_alias": "prep", "stage_type": "shell_command",
             "seq": 1,
             "config": {
                 "command": "mkdir -p /tmp/staging/{business_date}",
                 "timeout_seconds": 30,
             }},
            {"stage_alias": "encrypt", "stage_type": "shell_command",
             "seq": 2, "predecessors": ["prep"],
             "config": {
                 "command": "gpg --batch --yes -e -r ops@example.com "
                            "-o /tmp/staging/{business_date}/snapshot.gpg "
                            "{source_dir}/{business_date}.csv",
                 "timeout_seconds": 120,
             }},
            {"stage_alias": "rsync", "stage_type": "shell_command",
             "seq": 3, "predecessors": ["encrypt"],
             "config": {
                 "command": "rsync -av /tmp/staging/{business_date}/ "
                            "ops@{target_host}:/incoming/",
                 "timeout_seconds": 600,
             },
             "retry_policy": {"max_attempts": 3, "backoff_seconds": 60}},
            {"stage_alias": "notify", "stage_type": "notify",
             "seq": 4, "predecessors": ["rsync"],
             "config": {"message": "Encrypted snapshot delivered to {target_host}"}},
        ],
    },

    # ── Fan-out orchestrator using trigger_dataflow ─────────────────────
    # Parent kicks off N child DataFlows (non-blocking), notifies once
    # they've all been queued.  Use when several DAGs share a daily
    # trigger event.
    "etl_orchestrator_trigger_fanout": {
        "name": "etl_orchestrator_trigger_fanout",
        "description": (
            "Orchestrator that triggers multiple child DataFlows in "
            "parallel (fire-and-forget) once a daily event arrives. "
            "Edit child_a / child_b / child_c in global params."
        ),
        "trigger_type": "cron",
        "default_context": {
            "business_date": "{{business_date}}",
            "child_a":       "etl_createjob",
            "child_b":       "etl_to_file",
            "child_c":       "etl_sap_odata_to_file",
        },
        "stages": [
            {"stage_alias": "trigger_a", "stage_type": "trigger_dataflow",
             "seq": 1,
             "config": {"dataflow_name": "{child_a}",
                          "context_passthrough": ["business_date"]}},
            {"stage_alias": "trigger_b", "stage_type": "trigger_dataflow",
             "seq": 2,
             "config": {"dataflow_name": "{child_b}",
                          "context_passthrough": ["business_date"]}},
            {"stage_alias": "trigger_c", "stage_type": "trigger_dataflow",
             "seq": 3,
             "config": {"dataflow_name": "{child_c}",
                          "context_passthrough": ["business_date"]}},
            {"stage_alias": "notify",    "stage_type": "notify",
             "seq": 4,
             "predecessors": ["trigger_a", "trigger_b", "trigger_c"],
             "config": {"message": "Fan-out batch dispatched for {business_date}"}},
        ],
    },

    # ═══════════════════════════════════════════════════════════════════════
    # Saved Query → File → S3
    # Reads a QueryStudio saved query by id, runs it via DuckDB, writes
    # the FULL result set to a local file (CSV / Parquet / JSON), then
    # uploads to S3.  Pair with a Daily Batch — Morning schedule for a
    # daily snapshot of any saved query.
    # ═══════════════════════════════════════════════════════════════════════
    "etl_saved_query_to_s3": {
        "name": "etl_saved_query_to_s3",
        "description": (
            "Saved query → S3 snapshot.  Set saved_query_id in the "
            "run_query stage to point at any QueryStudio saved query — "
            "its SQL is loaded at run time, executed via DuckDB, written "
            "to a local file (default CSV), then uploaded to S3.  Useful "
            "for nightly exports of curated reporting queries."
        ),
        "trigger_type": "cron",
        "default_context": {
            "business_date":  "{{business_date}}",
            "local_dir":      "/tmp/saved_query_exports",
            "s3_bucket":      "",
            "s3_prefix":      "exports/{business_date}",
        },
        "stages": [
            {"stage_alias": "run_query", "stage_type": "sql_query",
             "seq": 1,
             "config": {
                 "saved_query_id":   0,    # set to any saved query id before promoting
                 "output_file_path": "{local_dir}/snapshot_{business_date}.csv",
                 "output_format":    "csv",
                 "return_rows":      5,    # also capture a 5-row sample for the dashboard
             },
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 30}},
            {"stage_alias": "row_count_check", "stage_type": "row_count_check",
             "seq": 2, "predecessors": ["run_query"],
             "config": {"source_alias": "run_query", "min_rows": 1}},
            {"stage_alias": "checksum", "stage_type": "checksum",
             "seq": 3, "predecessors": ["row_count_check"],
             "config": {
                 "path":      "{local_dir}/snapshot_{business_date}.csv",
                 "algorithm": "sha256",
             }},
            {"stage_alias": "upload_to_s3", "stage_type": "s3_put",
             "seq": 4, "predecessors": ["checksum"],
             "config": {
                 "bucket":     "{s3_bucket}",
                 "key":        "{s3_prefix}/snapshot_{business_date}.csv",
                 "local_path": "{local_dir}/snapshot_{business_date}.csv",
                 "content_type": "text/csv",
             },
             "retry_policy": {"max_attempts": 3, "backoff_seconds": 30,
                                "exponential": True}},
            {"stage_alias": "notify", "stage_type": "notify",
             "seq": 5, "predecessors": ["upload_to_s3"],
             "config": {
                 "message":  "Saved query snapshot uploaded to s3://{s3_bucket}/{s3_prefix}/",
                 "severity": "success",
             }},
        ],
    },

    # ═══════════════════════════════════════════════════════════════════════
    # FEED FILE templates (BF-493 — 2026-05-27).
    # Direct DataFlow equivalents of the standard Feed Config pipeline:
    #   source (saved_query / sql_file)  →  format (csv/parquet/json)
    #   →  row count guard  →  checksum  →  CTL control file
    #   →  destination (S3 / local NFS)  →  email notification
    #
    # Mirrors what FeedConfigsPage produces today, but assembled from
    # NATIVE DataFlow stages (no ETL bridge dependency).  Pick the
    # destination variant that matches your feed.  WHERE clauses on the
    # sql_query stage use the same Static/Dynamic primitive as Feed
    # Config (Phase 132.38).
    # ═══════════════════════════════════════════════════════════════════════

    # ── Feed File → S3 (most common pattern) ────────────────────────────
    "feed_file_to_s3": {
        "name": "feed_file_to_s3",
        "description": (
            "Feed-file pipeline ending at S3.  Mirrors a standard Feed "
            "Config: pick a saved query (or .sql file), run it through "
            "DuckDB, write the FULL result set to a local CSV / Parquet "
            "file, guard against empty extracts, generate a CTL control "
            "file (record count + sha256 checksum), upload both to S3, "
            "then email completion.  Replace the placeholder values: set "
            "saved_query_id (or sql_file_id), output_filename, s3_bucket, "
            "s3_prefix, notify_to.  Static/Dynamic WHERE clauses on the "
            "run_query stage work the same way Feed Config's do."
        ),
        "trigger_type": "cron",
        "default_context": {
            "business_date":     "{{business_date}}",
            "local_dir":         "/tmp/feed_output",
            "output_filename":   "feed_{business_date}",
            "output_format":     "csv",
            "s3_bucket":         "",
            "s3_prefix":         "feeds/{business_date}",
            "notify_to":         "ops@example.com",
        },
        "stages": [
            # Step 1: run the source query and write its FULL result set
            # to a local file.  Same source picker semantics as Feed
            # Config — saved_query_id OR sql_file_id, not both.
            {"stage_alias": "run_query", "stage_type": "sql_query",
             "seq": 1,
             "config": {
                 "saved_query_id":   0,    # ← set to your saved query id
                 "sql_file_id":      0,    # ← OR set to your .sql file id (BQB/CQB)
                 "output_file_path": "{local_dir}/{output_filename}.{output_format}",
                 "output_format":    "csv",
                 "return_rows":      5,    # 5-row sample on the dashboard chip
                 # Phase 132.38 — Static rows freeze a value (locked at
                 # config time); Dynamic rows accept per-run overrides
                 # via the Trigger-with-overrides dialog.
                 "where_clauses":    [],
             },
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 30}},

            # Step 2: row-count guard — abort if the extract is empty
            # (matches Feed Config's pre-delivery row count check).
            {"stage_alias": "row_count_check", "stage_type": "row_count_check",
             "seq": 2, "predecessors": ["run_query"],
             "config": {"source_alias": "run_query", "min_rows": 1}},

            # Step 3: sha256 checksum for the data file (used by the CTL
            # file in step 4 AND for integrity-verification downstream).
            {"stage_alias": "data_checksum", "stage_type": "checksum",
             "seq": 3, "predecessors": ["row_count_check"],
             "config": {
                 "path":      "{local_dir}/{output_filename}.{output_format}",
                 "algorithm": "sha256",
             }},

            # Step 4: CTL control file — text descriptor consumers use to
            # verify the data file (record count + checksum + business
            # date).  Format mirrors Feed Config's default CTL template
            # but you can override `content` below to match your
            # downstream's expected schema.
            {"stage_alias": "ctl_file", "stage_type": "write_file",
             "seq": 4, "predecessors": ["data_checksum"],
             "config": {
                 "path":    "{local_dir}/{output_filename}.ctl",
                 "content": ("FILENAME={output_filename}.{output_format}\n"
                              "BUSINESS_DATE={business_date}\n"
                              "RECORD_COUNT={run_query.row_count}\n"
                              "SHA256={data_checksum.checksum}\n"),
                 "ensure_parent_dir": True,
             }},

            # Step 5a: upload data file to S3.  Set s3_bucket on the
            # default_context (or override per run).  S3 connection_id is
            # optional — if set, uses that QueryStudio S3 connection's
            # credentials; otherwise default boto3 chain.
            {"stage_alias": "upload_data", "stage_type": "s3_put",
             "seq": 5, "predecessors": ["ctl_file"],
             "config": {
                 "connection_id": 0,    # ← optional: QueryStudio S3 conn id
                 "bucket":        "{s3_bucket}",
                 "key":           "{s3_prefix}/{output_filename}.{output_format}",
                 "local_path":    "{local_dir}/{output_filename}.{output_format}",
                 "content_type":  "text/csv",
             },
             "retry_policy": {"max_attempts": 3, "backoff_seconds": 30,
                                "exponential": True}},

            # Step 5b: upload CTL file alongside the data file.
            {"stage_alias": "upload_ctl", "stage_type": "s3_put",
             "seq": 6, "predecessors": ["upload_data"],
             "config": {
                 "connection_id": 0,
                 "bucket":        "{s3_bucket}",
                 "key":           "{s3_prefix}/{output_filename}.ctl",
                 "local_path":    "{local_dir}/{output_filename}.ctl",
                 "content_type":  "text/plain",
             },
             "retry_policy": {"max_attempts": 3, "backoff_seconds": 30,
                                "exponential": True}},

            # Step 6: completion email.  Subject/body interpolate run_context
            # so the recipient sees what was delivered.
            {"stage_alias": "notify", "stage_type": "send_email",
             "seq": 7, "predecessors": ["upload_ctl"],
             "config": {
                 "to":      "{notify_to}",
                 "subject": "Feed delivered: {output_filename} ({business_date})",
                 "body":    ("Feed {output_filename} for {business_date} "
                              "uploaded to s3://{s3_bucket}/{s3_prefix}/.\n"
                              "Records: {run_query.row_count}\n"
                              "SHA256: {data_checksum.checksum}\n"),
                 "fail_on_send_error": False,
             }},
        ],
    },

    # ── Feed File → local NFS (no S3 upload) ────────────────────────────
    "feed_file_to_local": {
        "name": "feed_file_to_local",
        "description": (
            "Feed-file pipeline ending at a local / NFS path — no upload "
            "step.  Use when the downstream consumer reads directly from "
            "the shared volume.  Same source / WHERE-clause / row-count / "
            "checksum / CTL semantics as feed_file_to_s3, just skipping "
            "the S3 stages.  Set saved_query_id (or sql_file_id), local_dir "
            "(the NFS mount path), and notify_to."
        ),
        "trigger_type": "cron",
        "default_context": {
            "business_date":     "{{business_date}}",
            "local_dir":         "/nfs/feeds/{business_date}",
            "output_filename":   "feed_{business_date}",
            "output_format":     "csv",
            "notify_to":         "ops@example.com",
        },
        "stages": [
            {"stage_alias": "run_query", "stage_type": "sql_query",
             "seq": 1,
             "config": {
                 "saved_query_id":   0,
                 "sql_file_id":      0,
                 "output_file_path": "{local_dir}/{output_filename}.{output_format}",
                 "output_format":    "csv",
                 "return_rows":      5,
                 "where_clauses":    [],
             },
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 30}},

            {"stage_alias": "row_count_check", "stage_type": "row_count_check",
             "seq": 2, "predecessors": ["run_query"],
             "config": {"source_alias": "run_query", "min_rows": 1}},

            {"stage_alias": "data_checksum", "stage_type": "checksum",
             "seq": 3, "predecessors": ["row_count_check"],
             "config": {
                 "path":      "{local_dir}/{output_filename}.{output_format}",
                 "algorithm": "sha256",
             }},

            {"stage_alias": "ctl_file", "stage_type": "write_file",
             "seq": 4, "predecessors": ["data_checksum"],
             "config": {
                 "path":    "{local_dir}/{output_filename}.ctl",
                 "content": ("FILENAME={output_filename}.{output_format}\n"
                              "BUSINESS_DATE={business_date}\n"
                              "RECORD_COUNT={run_query.row_count}\n"
                              "SHA256={data_checksum.checksum}\n"),
                 "ensure_parent_dir": True,
             }},

            {"stage_alias": "notify", "stage_type": "send_email",
             "seq": 5, "predecessors": ["ctl_file"],
             "config": {
                 "to":      "{notify_to}",
                 "subject": "Feed delivered: {output_filename} ({business_date})",
                 "body":    ("Feed {output_filename} for {business_date} "
                              "written to {local_dir}/.\n"
                              "Records: {run_query.row_count}\n"
                              "SHA256: {data_checksum.checksum}\n"),
                 "fail_on_send_error": False,
             }},
        ],
    },

    # ── HTTP fetch → file ────────────────────────────────────────────────
    "etl_http_to_file": {
        "name": "etl_http_to_file",
        "description": (
            "Lightweight HTTP-fetch pipeline: hit an external REST endpoint, "
            "save the response body as a file, checksum it, deliver.  "
            "Useful for vendor APIs that ship daily JSON snapshots."
        ),
        "trigger_type": "cron",
        "default_context": {"business_date": "{{business_date}}"},
        "stages": [
            {"stage_alias": "fetch", "stage_type": "http_fetch", "seq": 1,
             "config": {"url": "https://example.com/api/snapshot",
                          "method": "GET", "timeout_seconds": 60,
                          "expect_status": 200},
             "retry_policy": {"max_attempts": 3, "backoff_seconds": 15,
                                "exponential": True}},
            {"stage_alias": "save", "stage_type": "write_file", "seq": 2,
             "predecessors": ["fetch"],
             "config": {"path": "/incoming/{business_date}.json",
                          "content": "from_input",
                          "input_source": {"alias": "fetch", "key": "body"}}},
            {"stage_alias": "checksum", "stage_type": "checksum", "seq": 3,
             "predecessors": ["save"],
             "config": {"path": "/incoming/{business_date}.json",
                          "algorithm": "sha256"}},
            {"stage_alias": "notify", "stage_type": "notify", "seq": 4,
             "predecessors": ["checksum"],
             "config": {"message": "HTTP snapshot {business_date} captured",
                          "severity": "success"}},
        ],
    },

    # ── Sub-dataflow orchestrator (fan-out wrapper) ─────────────────────
    "etl_orchestrator_fanout": {
        "name": "etl_orchestrator_fanout",
        "description": (
            "Parent dataflow that triggers multiple sub-dataflows in "
            "parallel (fire-and-forget) then notifies once all are "
            "queued.  Use to coordinate a batch of related ETLs from a "
            "single schedule."
        ),
        "trigger_type": "cron",
        "default_context": {"business_date": "{{business_date}}"},
        "stages": [
            {"stage_alias": "trigger_a", "stage_type": "sub_dataflow", "seq": 1,
             "config": {"dataflow_name": "etl_createjob",
                          "wait_for_completion": False,
                          "context_passthrough": ["business_date"]}},
            {"stage_alias": "trigger_b", "stage_type": "sub_dataflow", "seq": 2,
             "config": {"dataflow_name": "etl_oracle_to_s3",
                          "wait_for_completion": False,
                          "context_passthrough": ["business_date"]}},
            {"stage_alias": "trigger_c", "stage_type": "sub_dataflow", "seq": 3,
             "config": {"dataflow_name": "etl_starburst_to_file",
                          "wait_for_completion": False,
                          "context_passthrough": ["business_date"]}},
            {"stage_alias": "notify", "stage_type": "notify", "seq": 4,
             "predecessors": ["trigger_a", "trigger_b", "trigger_c"],
             "config": {"message": "Batch dispatched for {business_date}",
                          "severity": "info"}},
        ],
    },

    # ═══════════════════════════════════════════════════════════════════════
    # Canonical DAGs that mirror ETL/config/step_mapping.yaml — one
    # template per job_type bucket with the full happy-path step list.
    # Use these as the starting point when you want exactly what your
    # existing polling service runs today.
    # ═══════════════════════════════════════════════════════════════════════

    # ═══════════════════════════════════════════════════════════════════════
    # CANONICAL "Push data to DB" DAG (per user spec):
    #   1. Check Dependencies
    #   2. Clear Staging (pre-load process)
    #   3. On-Prem Load   (Starburst onprem → Oracle)
    #   4. On-Cloud Load  (Starburst oncloud → Oracle)
    #   5. Check Data Completeness
    #   6. Post Load Process
    # Both on-prem and on-cloud sources land into the same Oracle target
    # so admins covering hybrid deployments don't need two pipelines.
    # ═══════════════════════════════════════════════════════════════════════

    "etl_createjob": {
        "name": "etl_createjob",
        "description": (
            "Canonical push-to-DB ETL.\n"
            "Order: check_dependencies → preload Oracle procedure → "
            "on-prem load → on-cloud load → completeness check → postload "
            "Oracle procedure → notify.\n"
            "Both Starburst sources land into the same Oracle target.  "
            "Pre/post-load Oracle procedures are explicit stages — name "
            "the procedure in their config."
        ),
        "trigger_type": "cron",
        "default_context": {
            "business_date": "{{business_date}}",
            "p_gjahr":       "",
            "p_poper":       "",
        },
        "stages": [
            {"stage_alias": "check_deps",       "stage_type": "check_dependencies",
             "seq": 1, "config": {"task": {}}},
            {"stage_alias": "preload_proc",     "stage_type": "oracle_preload_procedure",
             "seq": 2, "predecessors": ["check_deps"],
             "config": {"procedure_name": "", "procedure_args": []}},
            {"stage_alias": "onprem_load",      "stage_type": "starburst_to_oracle",
             "seq": 3, "predecessors": ["preload_proc"],
             "config": {"location": "onprem"},
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 60}},
            {"stage_alias": "oncloud_load",     "stage_type": "starburst_to_oracle",
             "seq": 4, "predecessors": ["onprem_load"],
             "config": {"location": "oncloud"},
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 60}},
            {"stage_alias": "completeness",     "stage_type": "check_completeness",
             "seq": 5, "predecessors": ["oncloud_load"], "config": {"task": {}}},
            {"stage_alias": "postload_proc",    "stage_type": "oracle_postload_procedure",
             "seq": 6, "predecessors": ["completeness"],
             "config": {"procedure_name": "", "procedure_args": []}},
            {"stage_alias": "notify",           "stage_type": "send_email_notifications",
             "seq": 7, "predecessors": ["postload_proc"], "config": {"task": {}}},
        ],
    },

    # ═══════════════════════════════════════════════════════════════════════
    # CANONICAL "To File" DAG (per user spec):
    #   1. Check Dependencies
    #   2. Execute query + write On-Prem file
    #   3. Execute query + write On-Cloud file
    #   4. Merge both files
    #   5. Check file completeness
    #   6. Compress file (if configured)
    #   7. Create control file
    #   8. Deliver  — SFTP / S3 / NFS (configured per stage)
    # ═══════════════════════════════════════════════════════════════════════

    "etl_to_file": {
        "name": "etl_to_file",
        "description": (
            "Canonical file-delivery DAG.\n"
            "Pulls from both on-prem and on-cloud Starburst into "
            "SEPARATE files (suffix _onprem / _oncloud so they don't "
            "overwrite each other), then the merge stage consolidates "
            "both into one final output, runs completeness + compress + "
            "CTL + delivery via SFTP / S3 / NFS."
        ),
        "trigger_type": "cron",
        "default_context": {
            "business_date":     "{{business_date}}",
            "output_dir":        "/tmp/feed_output",
            "output_format":     "csv",
            "base_filename":     "feed_{business_date}",
        },
        "stages": [
            {"stage_alias": "check_deps",     "stage_type": "check_dependencies",
             "seq": 1, "config": {"task": {}}},
            # On-prem extract — writes its output with the _onprem suffix
            # so it doesn't collide with the on-cloud extract.  The merge
            # stage downstream globs both files together.
            {"stage_alias": "onprem_extract", "stage_type": "starburst_to_file",
             "seq": 2, "predecessors": ["check_deps"],
             "config": {
                 "location":         "onprem",
                 "engine":           "default",
                 "filename_template": "{base_filename}_onprem",
             },
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 30}},
            # On-cloud extract — _oncloud suffix.
            {"stage_alias": "oncloud_extract", "stage_type": "starburst_to_file",
             "seq": 3, "predecessors": ["check_deps"],
             "config": {
                 "location":         "oncloud",
                 "engine":           "default",
                 "filename_template": "{base_filename}_oncloud",
             },
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 30}},
            # Merge: reads BOTH per-location files (the consolidate step
            # auto-discovers everything in output_dir matching the base
            # filename) and writes a single merged output named after
            # base_filename (without the suffix).
            {"stage_alias": "merge",           "stage_type": "consolidate_files",
             "seq": 4, "predecessors": ["onprem_extract", "oncloud_extract"],
             "config": {"task": {
                 "consolidated_filename": "{base_filename}",
                 "delete_group_files":    True,
             }}},
            {"stage_alias": "completeness",    "stage_type": "check_completeness",
             "seq": 5, "predecessors": ["merge"], "config": {"task": {}}},
            {"stage_alias": "compress",        "stage_type": "compress_files",
             "seq": 6, "predecessors": ["completeness"],
             "config": {"task": {}, "enabled": True}},
            {"stage_alias": "ctl_file",        "stage_type": "create_ctl_file",
             "seq": 7, "predecessors": ["compress"], "config": {"task": {}}},
            {"stage_alias": "deliver",         "stage_type": "deliver_files",
             "seq": 8, "predecessors": ["ctl_file"],
             "config": {"task": {"delivery_type": "nfs"}},
             "retry_policy": {"max_attempts": 3, "backoff_seconds": 60}},
            {"stage_alias": "notify",          "stage_type": "send_email_notifications",
             "seq": 9, "predecessors": ["deliver"], "config": {"task": {}}},
        ],
    },

    # ── createJob canonical: on-prem with cloud landing + reverse load ──
    "etl_createjob_full_onprem": {
        "name": "etl_createjob_full_onprem",
        "description": (
            "Canonical createJob DAG (on-prem flavour) covering every step "
            "in step_mapping.yaml.createJob.  Pre-flight → generate SQL → "
            "clear staging → load → completeness + process → cloud landing "
            "and reverse load → notify.  Disable / delete steps you don't "
            "need."
        ),
        "trigger_type": "cron",
        "default_context": {
            "business_date": "{{business_date}}",
            "p_gjahr":       "",
            "p_poper":       "",
        },
        "stages": [
            {"stage_alias": "check_deps",         "stage_type": "check_dependencies",
             "seq": 1, "config": {"task": {}}},
            {"stage_alias": "pre_validate",       "stage_type": "pre_data_validation",
             "seq": 2, "predecessors": ["check_deps"], "config": {"task": {}}},
            {"stage_alias": "gen_sql",            "stage_type": "render_sql",
             "seq": 3, "predecessors": ["pre_validate"], "config": {"task": {}}},
            {"stage_alias": "clear_staging",      "stage_type": "clear_staging",
             "seq": 4, "predecessors": ["gen_sql"], "config": {"task": {}}},
            {"stage_alias": "extract_load",       "stage_type": "starburst_to_oracle",
             "seq": 5, "predecessors": ["clear_staging"], "config": {"location": "onprem"},
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 60}},
            {"stage_alias": "completeness",       "stage_type": "check_completeness",
             "seq": 6, "predecessors": ["extract_load"], "config": {"task": {}}},
            {"stage_alias": "process",            "stage_type": "process_data",
             "seq": 7, "predecessors": ["completeness"], "config": {"task": {}}},
            {"stage_alias": "land_to_s3",         "stage_type": "oracle_to_s3",
             "seq": 8, "predecessors": ["process"], "config": {"task": {}},
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 60}},
            {"stage_alias": "notify",             "stage_type": "send_email_notifications",
             "seq": 9, "predecessors": ["land_to_s3"], "config": {"task": {}}},
        ],
    },

    # ── file canonical: full delivery pipeline ──────────────────────────
    "etl_file_canonical": {
        "name": "etl_file_canonical",
        "description": (
            "Canonical file-delivery DAG mirroring step_mapping.yaml.file. "
            "Pre-flight → extract → consolidate → compress → CTL → deliver "
            "→ notify."
        ),
        "trigger_type": "cron",
        "default_context": {
            "business_date": "{{business_date}}",
            "output_dir":    "/tmp/feed_output",
            "output_format": "csv",
        },
        "stages": [
            {"stage_alias": "check_deps",    "stage_type": "check_dependencies",
             "seq": 1, "config": {"task": {}}},
            {"stage_alias": "gen_sql",       "stage_type": "render_sql",
             "seq": 2, "predecessors": ["check_deps"], "config": {"task": {}}},
            {"stage_alias": "extract",       "stage_type": "starburst_to_file",
             "seq": 3, "predecessors": ["gen_sql"], "config": {"task": {}},
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 30}},
            {"stage_alias": "consolidate",   "stage_type": "consolidate_files",
             "seq": 4, "predecessors": ["extract"], "config": {"task": {}}},
            {"stage_alias": "row_count_chk", "stage_type": "row_count_check",
             "seq": 5, "predecessors": ["consolidate"],
             "config": {"source_alias": "consolidate", "min_rows": 1}},
            {"stage_alias": "compress",      "stage_type": "compress_files",
             "seq": 6, "predecessors": ["row_count_chk"], "config": {"task": {}}},
            {"stage_alias": "ctl_file",      "stage_type": "create_ctl_file",
             "seq": 7, "predecessors": ["compress"], "config": {"task": {}}},
            {"stage_alias": "checksum",      "stage_type": "checksum",
             "seq": 8, "predecessors": ["ctl_file"],
             "config": {"path": "/tmp/feed_output/{business_date}.zip",
                          "algorithm": "sha256"}},
            {"stage_alias": "deliver",       "stage_type": "deliver_files",
             "seq": 9, "predecessors": ["checksum"], "config": {"task": {}},
             "retry_policy": {"max_attempts": 3, "backoff_seconds": 60}},
            {"stage_alias": "notify",        "stage_type": "send_email_notifications",
             "seq": 10, "predecessors": ["deliver"], "config": {"task": {}}},
        ],
    },

    # ── sap_odata canonical ────────────────────────────────────────────
    # ── SAP OData fan-out (DAG-level parallelism) ──────────────────────
    # Phase 132.20 — uses the generic ``for_each`` stage so each company-
    # code group becomes its own visible iteration on the Ops Grid /
    # Gantt.  Compare with ``etl_sap_odata_to_file`` which hides per-
    # group parallelism inside a single monolithic stage.
    "etl_sap_odata_fanout": {
        "name": "etl_sap_odata_fanout",
        "description": (
            "SAP OData → file with DAG-level fan-out per company group.  "
            "Step 1: fetch + bin-pack codes (sap_fetch_company_groups).  "
            "Step 2: for_each group, run sap_download_one_group in "
            "parallel (configurable concurrency, per-group failure isolation, "
            "live per-iteration status on the Ops view).  Step 3: consolidate "
            "the per-group CSVs → compress → CTL → deliver → email.  All "
            "creds via Connection ids (encrypted)."
        ),
        "trigger_type": "cron",
        "default_context": {
            "p_gjahr":      "",
            "p_poper":      "",
            "output_dir":   "/tmp/sap_output",
            "output_format": "csv",
        },
        "stages": [
            {"stage_alias": "fetch_groups",
             "stage_type": "sap_fetch_company_groups",
             "seq": 1,
             "config": {
                 "sap_connection_id":     0,
                 "company_code_endpoint": "",
                 "num_groups":             5,
                 "period_mode":            "current",
             },
             "retry_policy": {"max_attempts": 3, "backoff_seconds": 15}},

            {"stage_alias": "download_groups",
             "stage_type": "for_each",
             "seq": 2,
             "predecessors": ["fetch_groups"],
             "config": {
                 "items_from":         "fetch_groups.groups",
                 "child_stage_type":   "sap_download_one_group",
                 "max_parallel":       3,
                 "fail_fast":          False,
                 "item_var":           "group",
                 "child_config": {
                     # The for_each interpolates {id} and {codes} from each
                     # group dict.  p_gjahr / p_poper come from fetch_groups'
                     # outputs via the predecessor outputs prefill on the
                     # bridge — but we read them from run_context (set via
                     # context propagation) or pass explicitly here.
                     "sap_connection_id":    0,
                     "odata_service_path":   "",
                     "output_dir":           "{output_dir}",
                     "group_id":             "{id}",
                     "group_codes":          "{codes}",
                     "p_gjahr":              "{p_gjahr}",
                     "p_poper":              "{p_poper}",
                 },
             },
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 30}},

            {"stage_alias": "consolidate",  "stage_type": "consolidate_files",
             "seq": 3, "predecessors": ["download_groups"],
             "config": {"task": {}}},
            {"stage_alias": "completeness", "stage_type": "check_completeness",
             "seq": 4, "predecessors": ["consolidate"], "config": {"task": {}}},
            {"stage_alias": "compress",     "stage_type": "compress_files",
             "seq": 5, "predecessors": ["completeness"], "config": {"task": {}}},
            {"stage_alias": "ctl_file",     "stage_type": "create_ctl_file",
             "seq": 6, "predecessors": ["compress"], "config": {"task": {}}},
            {"stage_alias": "deliver",      "stage_type": "deliver_files",
             "seq": 7, "predecessors": ["ctl_file"],
             "config": {
                 "delivery_type":      "nfs",
                 "sftp_connection_id": 0,
                 "sftp_remote_dir":    "/inbound/sap_mebal",
             },
             "retry_policy": {"max_attempts": 3, "backoff_seconds": 60}},
            {"stage_alias": "notify",       "stage_type": "send_email",
             "seq": 8, "predecessors": ["deliver"],
             "config": {
                 "to":      "ops@example.com",
                 "subject": "SAP MEBAL fan-out — {business_date} delivered",
                 "body":    "SAP MEBAL fan-out feed for {business_date} "
                              "completed successfully.",
             }},
        ],
    },

    "etl_sap_odata_canonical": {
        "name": "etl_sap_odata_canonical",
        "description": (
            "Canonical SAP OData → file pipeline mirroring "
            "step_mapping.yaml.sap_odata.  Download → consolidate → "
            "compress → CTL → deliver → email.  Creds via Connections."
        ),
        "trigger_type": "cron",
        "default_context": {
            "p_gjahr":       "",
            "p_poper":       "",
            "output_dir":    "/tmp/sap_output",
            "output_format": "csv",
        },
        "stages": [
            {"stage_alias": "sap_download", "stage_type": "sap_odata_download",
             "seq": 1,
             "config": {
                 "sap_connection_id":     0,
                 "odata_service_path":    "",
                 "company_code_endpoint": "",
                 "output_dir":            "/tmp/sap_output",
                 "num_groups":            5,
                 "max_parallel_groups":   3,
                 "period_mode":           "current",
             },
             "retry_policy": {"max_attempts": 3, "backoff_seconds": 30,
                                "exponential": True}},
            {"stage_alias": "consolidate",  "stage_type": "consolidate_files",
             "seq": 2, "predecessors": ["sap_download"], "config": {"task": {}}},
            {"stage_alias": "row_count_chk","stage_type": "row_count_check",
             "seq": 3, "predecessors": ["consolidate"],
             "config": {"source_alias": "consolidate", "min_rows": 1}},
            {"stage_alias": "compress",     "stage_type": "compress_files",
             "seq": 4, "predecessors": ["row_count_chk"], "config": {"task": {}}},
            {"stage_alias": "ctl_file",     "stage_type": "create_ctl_file",
             "seq": 5, "predecessors": ["compress"], "config": {"task": {}}},
            {"stage_alias": "deliver",      "stage_type": "deliver_files",
             "seq": 6, "predecessors": ["ctl_file"],
             "config": {
                 "delivery_type":      "nfs",
                 "sftp_connection_id": 0,
                 "sftp_remote_dir":    "/inbound/sap_mebal",
             },
             "retry_policy": {"max_attempts": 3, "backoff_seconds": 60}},
            {"stage_alias": "notify",       "stage_type": "send_email",
             "seq": 7, "predecessors": ["deliver"],
             "config": {
                 "to":      "ops@example.com",
                 "subject": "SAP MEBAL canonical — completed",
                 "body":    "SAP canonical pipeline finished. Run-id {run_id}.",
             }},
        ],
    },

    # ── Spark-routed extract (heavy data volumes) ───────────────────────
    "etl_starburst_to_file_spark_onprem": {
        "name": "etl_starburst_to_file_spark_onprem",
        "description": (
            "File delivery using Spark for the extract phase — pick this "
            "for >10M row extracts where the regular Starburst client "
            "can't scale."
        ),
        "trigger_type": "cron",
        "default_context": {
            "business_date": "{{business_date}}",
            "output_dir":    "/tmp/feed_output",
            "output_format": "csv",
        },
        "stages": [
            {"stage_alias": "check_deps", "stage_type": "check_dependencies",
             "seq": 1, "config": {"task": {}}},
            {"stage_alias": "gen_sql",    "stage_type": "render_sql",
             "seq": 2, "predecessors": ["check_deps"], "config": {"task": {}}},
            {"stage_alias": "extract",    "stage_type": "starburst_to_file",
             "seq": 3, "predecessors": ["gen_sql"], "config": {"task": {}},
             "retry_policy": {"max_attempts": 2, "backoff_seconds": 60}},
            {"stage_alias": "consolidate","stage_type": "consolidate_files",
             "seq": 4, "predecessors": ["extract"], "config": {"task": {}}},
            {"stage_alias": "compress",   "stage_type": "compress_files",
             "seq": 5, "predecessors": ["consolidate"], "config": {"task": {}}},
            {"stage_alias": "ctl_file",   "stage_type": "create_ctl_file",
             "seq": 6, "predecessors": ["compress"], "config": {"task": {}}},
            {"stage_alias": "deliver",    "stage_type": "deliver_files",
             "seq": 7, "predecessors": ["ctl_file"], "config": {"task": {}},
             "retry_policy": {"max_attempts": 3, "backoff_seconds": 60}},
            {"stage_alias": "notify",     "stage_type": "send_email_notifications",
             "seq": 8, "predecessors": ["deliver"], "config": {"task": {}}},
        ],
    },

    # ── Daily SOD heartbeat ──────────────────────────────────────────────
    # ── 1. SOD smoke check ────────────────────────────────────────────────
    "sod_smoke_check": {
        "name": "sod_smoke_check",
        "description": (
            "Daily Start-of-Day smoke check: log a heartbeat, run a "
            "no-op SQL probe, and notify ops on completion.  Wire a "
            "schedule with calendar_rule={type:sod, calendar:US_BANKING, "
            "hour:7, minute:0} to activate."
        ),
        "trigger_type": "cron",
        "trigger_config": {},
        "default_context": {"env": "prod"},
        "stages": [
            {"stage_alias": "log_start", "stage_type": "log", "seq": 1,
             "config": {"message": "SOD smoke check started in {env}"}},
            {"stage_alias": "probe", "stage_type": "sql_query", "seq": 2,
             "predecessors": ["log_start"],
             "config": {"sql": "SELECT 1 AS ok", "return_rows": 1}},
            {"stage_alias": "notify_ops", "stage_type": "notify", "seq": 3,
             "predecessors": ["probe"],
             "config": {"message": "SOD smoke check passed", "severity": "success"}},
        ],
    },

    # ── 2. Intraday cache warmup ──────────────────────────────────────────
    "cache_warmup": {
        "name": "cache_warmup",
        "description": (
            "Intraday cache warmup dataflow.  Reads a parameter table, "
            "runs an aggregation SQL, and logs the row count.  Designed "
            "to be scheduled every 30 minutes during the business day."
        ),
        "trigger_type": "cron",
        "trigger_config": {},
        "default_context": {"tenant": "default"},
        "stages": [
            {"stage_alias": "start", "stage_type": "log", "seq": 1,
             "config": {"message": "Cache warmup tick for tenant={tenant}"}},
            {"stage_alias": "query", "stage_type": "sql_query", "seq": 2,
             "predecessors": ["start"],
             "config": {"sql": "SELECT COUNT(*) AS n FROM (SELECT 1) t",
                        "return_rows": 1}},
            {"stage_alias": "done", "stage_type": "log", "seq": 3,
             "predecessors": ["query"],
             "config": {"message": "Cache warmup complete"}},
        ],
    },

    # ── 3. Conditional branch demo ────────────────────────────────────────
    "conditional_demo": {
        "name": "conditional_demo",
        "description": (
            "Demonstrates the BranchStage.  Sets a context flag, branches "
            "to one of two paths, then converges on a notify stage.  Use "
            "as a learning example or smoke test."
        ),
        "trigger_type": "manual",
        "default_context": {"path": "happy"},
        "stages": [
            {"stage_alias": "set_flag", "stage_type": "set_context", "seq": 1,
             "config": {"values": {"path": "happy"}}},
            {"stage_alias": "decide", "stage_type": "branch", "seq": 2,
             "predecessors": ["set_flag"],
             "config": {"key": "path", "equals": "happy",
                        "then_alias": "happy_path", "else_alias": "sad_path"}},
            {"stage_alias": "happy_path", "stage_type": "log", "seq": 3,
             "config": {"message": "happy path executed"}},
            {"stage_alias": "sad_path", "stage_type": "log", "seq": 4,
             "config": {"message": "sad path executed"}},
            {"stage_alias": "notify", "stage_type": "notify", "seq": 5,
             "config": {"message": "Conditional demo complete",
                        "severity": "info"}},
        ],
    },

    # ── 4. Sub-dataflow chain ─────────────────────────────────────────────
    "sub_dataflow_chain": {
        "name": "sub_dataflow_chain",
        "description": (
            "Parent dataflow that invokes 'sod_smoke_check' as a sync "
            "sub-dataflow then notifies on completion.  Demonstrates the "
            "SubDataFlowStage."
        ),
        "trigger_type": "manual",
        "stages": [
            {"stage_alias": "invoke_sod", "stage_type": "sub_dataflow", "seq": 1,
             "config": {"dataflow_name": "sod_smoke_check",
                        "wait_for_completion": True,
                        "context_overrides": {"env": "parent-triggered"}}},
            {"stage_alias": "done", "stage_type": "notify", "seq": 2,
             "predecessors": ["invoke_sod"],
             "config": {"message": "Sub-dataflow chain complete",
                        "severity": "success"}},
        ],
    },

    # ── 5. WD6 month-end report stub ──────────────────────────────────────
    "wd6_report": {
        "name": "wd6_report",
        "description": (
            "Skeleton month-end report that fires on workday 6.  Stages "
            "are stubbed with log + sql_query; replace with real source / "
            "transform / sink stages for production use.  Pair with a "
            "calendar_rule={type:workday_n, n:6, calendar:US_BANKING}."
        ),
        "trigger_type": "cron",
        "default_context": {"month_end_label": "WD6"},
        "stages": [
            {"stage_alias": "log_start", "stage_type": "log", "seq": 1,
             "config": {"message": "WD6 report job started for {month_end_label}"}},
            {"stage_alias": "extract", "stage_type": "sql_query", "seq": 2,
             "predecessors": ["log_start"],
             "config": {"sql": "SELECT 1 AS placeholder", "return_rows": 1}},
            {"stage_alias": "notify_complete", "stage_type": "notify", "seq": 3,
             "predecessors": ["extract"],
             "config": {"message": "WD6 report job complete",
                        "severity": "success"}},
        ],
    },
}


# ── Public API ─────────────────────────────────────────────────────────────


def list_templates() -> List[Dict[str, Any]]:
    """Return a list of template summary dicts (name, description, stage_count)."""
    out: List[Dict[str, Any]] = []
    for name, tmpl in _TEMPLATES.items():
        out.append({
            "name":         name,
            "description":  tmpl.get("description"),
            "stage_count":  len(tmpl.get("stages", [])),
            "trigger_type": tmpl.get("trigger_type", "manual"),
        })
    return out


def get_template(name: str) -> Optional[Dict[str, Any]]:
    """Return the full template dict, or None if unknown."""
    tmpl = _TEMPLATES.get(name)
    if tmpl is None:
        return None
    # Deep copy to prevent callers mutating the registry
    import copy
    return copy.deepcopy(tmpl)


def register_template(name: str, template: Dict[str, Any]) -> None:
    """Programmatic registration — used by tests + future plug-ins."""
    _TEMPLATES[name] = template
