"""Standard-crontab day-of-week semantics for APScheduler — ONE chokepoint.

Phase 4 (2026-08-23).  The defect, measured before fixing:

    CronTrigger.from_crontab("0 18 * * 5")  fires on SATURDAY.

APScheduler's ``from_crontab`` claims "a standard crontab expression" and
links Wikipedia, but it passes the day-of-week field VERBATIM into
``CronTrigger`` — whose numeric weekdays are 0=Monday..6=Sunday, while
standard cron (and every crontab reference, and this product's own UI help
text: '"0 8 * * 1-5" = weekdays') means 0=Sunday..6=Saturday (7 also
Sunday).  Every schedule or feed cron typed with NUMERIC weekdays therefore
ran exactly one day late — Tue–Sat instead of Mon–Fri, Saturday instead of
Friday — silently, forever.  Named weekdays ("mon-fri") were unaffected,
which is precisely why the defect survived: examples in docs use names,
operators use numbers.

:func:`crontab_trigger` is the ONE way this codebase builds a CronTrigger
from a crontab string.  It rewrites numeric day-of-week tokens into
APScheduler day NAMES (expanding ranges/steps, handling 7=Sunday and
Sunday-crossing ranges like "5-7"), then delegates to ``from_crontab``.
Tokens without digits ("*", "mon-fri") pass through untouched.
"""
from __future__ import annotations

from typing import List, Optional

#: standard cron numeral -> day name (0 and 7 are both Sunday).
_STD_DAY_NAMES = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"]


def _expand_std_days(body: str, step: int) -> List[int]:
    """Expand a numeric day-of-week body ('3', '1-5', '5-7', '*') with a
    step into the ordered list of STANDARD cron day numbers it denotes.
    Raises ValueError on malformed input (caller surfaces it)."""
    if body == "*":
        seq = list(range(0, 7))
    elif "-" in body:
        a_s, b_s = body.split("-", 1)
        a, b = int(a_s), int(b_s)
        if not (0 <= a <= 7 and 0 <= b <= 7):
            raise ValueError(f"day-of-week out of range in {body!r}")
        # 7 == Sunday.  "5-7" = fri,sat,sun.  Normalise AFTER building the
        # inclusive walk so a trailing 7 doesn't read as a wrap to 0.
        seq = []
        cur = a
        while True:
            seq.append(0 if cur == 7 else cur)
            if cur == b:
                break
            cur += 1
            if cur > 7:  # malformed like "6-2" after exhausting 7
                raise ValueError(f"invalid day-of-week range {body!r}")
    else:
        n = int(body)
        if not (0 <= n <= 7):
            raise ValueError(f"day-of-week out of range in {body!r}")
        seq = [0 if n == 7 else n]
    if step > 1:
        seq = seq[::step]
    return seq


def normalize_crontab_dow(expr: str) -> str:
    """Rewrite the day-of-week field of a 5-field crontab expression so its
    NUMERIC tokens mean what standard cron says they mean, expressed as
    APScheduler day names.  Non-numeric tokens and malformed expressions
    are returned untouched — validation stays where it always was
    (``from_crontab`` raising loudly)."""
    fields = str(expr).split()
    if len(fields) != 5:
        return expr
    dow = fields[4]
    out_tokens: List[str] = []
    changed = False
    for tok in dow.split(","):
        if not any(ch.isdigit() for ch in tok):
            out_tokens.append(tok)
            continue
        body, step_s = (tok.split("/", 1) + ["1"])[:2] if "/" in tok else (tok, "1")
        try:
            step = int(step_s)
            days = _expand_std_days(body, max(1, step))
            names = []
            for d in days:
                name = _STD_DAY_NAMES[d]
                if name not in names:
                    names.append(name)
            out_tokens.append(",".join(names))
            changed = True
        except ValueError:
            # Malformed numeric token — keep it verbatim so from_crontab
            # raises the same loud error it always did.
            out_tokens.append(tok)
    if not changed:
        return expr
    fields[4] = ",".join(out_tokens)
    return " ".join(fields)


def crontab_trigger(expr: str, timezone: Optional[str] = None):
    """Build an APScheduler CronTrigger from a STANDARD crontab expression.

    The one sanctioned constructor — call sites must not use
    ``CronTrigger.from_crontab`` directly (its numeric weekdays are shifted
    by one day; see module docstring)."""
    from apscheduler.triggers.cron import CronTrigger
    return CronTrigger.from_crontab(normalize_crontab_dow(expr),
                                    timezone=timezone)
