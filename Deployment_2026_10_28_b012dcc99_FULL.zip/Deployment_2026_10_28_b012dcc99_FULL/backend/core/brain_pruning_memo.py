"""BrainPruningMemo -- cached pruned file list keyed by SQL shape.

Phase 156.2 (2026-06-25) -- closes the brain's second feedback loop.

Brain Phase 155 ran manifest + supplement + bloom pruning on EVERY
identical query.  Phase 156.2 memoises the surviving file list keyed
by ``(sql_hash, snapshot_id)``: same SQL against the same snapshot
returns the cached list with zero pruning work.

Strategic shape -- single chokepoint:

  * ``get_memo(sql_hash, snapshot_id)``  -- consumer entry point;
    returns the cached list or None on miss.  In-process LRU front;
    DB persistence behind it so a fresh pod warm-restarts from DB.
  * ``put_memo(...)``                    -- producer entry point;
    after the brain ran all 3 pruning layers, store the result.
  * ``invalidate_for_snapshot(...)``     -- watcher hook; called
    when a snapshot rolls forward.  Mirrors ``agg_cache.
    invalidate_brain_cache_for_snapshot``.

Bounded cost: in-process cache caps at ``MAX_ENTRIES`` (1000 default)
with LRU eviction.  DB cleanup daemon trims rows older than TTL.

Fail-OPEN at every edge: any DB or cache error returns None on read
and silently no-ops on write.
"""
from __future__ import annotations

import logging
import threading
import time

from core.table_prefix import same_prefix
from typing import Any, Dict, Optional, List

logger = logging.getLogger(__name__)


# ── Config ────────────────────────────────────────────────────────────


def _cfg(key: str, fallback: Any) -> Any:
    try:
        from core.config import get as _g
        return _g("brain_pruning_memo", key, fallback)
    except Exception:
        return fallback


def enabled() -> bool:
    """Default ON -- the brain is supposed to be smart by default."""
    return bool(_cfg("enabled", True))


def in_process_max_entries() -> int:
    # Phase 156 deep-dive R15 -- floor at 10 entries.  Operator misconfig
    # of 0 / negative would make _evict_lru_if_needed never engage
    # (when cap=0, ``len(_CACHE) >= 0`` is always True but slice
    # ``[:max(1, 0//10)]`` evicts 1 entry per call -- that's roughly
    # noop, but TTL still handles freshness).  Floor sets a sane minimum.
    raw = int(_cfg("in_process_max_entries", 1000) or 1000)
    return max(10, raw)


def in_process_ttl_seconds() -> int:
    # Phase 156 deep-dive R15 -- floor at 1 second.  Negative would
    # make every cached entry instantly expire on lookup -- correct
    # but wasteful (every read pays the DB).  Floor at 1s preserves
    # at least one-hit cacheability.
    raw = int(_cfg("in_process_ttl_seconds", 600) or 600)
    return max(1, raw)


def cleanup_ttl_hours() -> int:
    raw = int(_cfg("cleanup_ttl_hours", 72) or 72)
    return max(1, raw)


# ── In-process LRU ───────────────────────────────────────────────────


_LOCK = threading.Lock()
_CACHE: Dict[str, Dict[str, Any]] = {}    # key -> {created_at, value}
# Phase 156 deep-dive R4 -- per-snapshot generation counter.  Bumped
# on every invalidate_for_snapshot so a concurrent get_memo that
# already started its DB read can detect the invalidation happened
# and refuse to promote the (now stale) row back into the LRU.
_INVALIDATION_GEN: Dict[str, int] = {}    # snapshot_id -> bump count


def apply_config_fingerprint(sql_hash: Optional[str]) -> Optional[str]:
    """Fold the OPERATIVE pruning-config fingerprint (bloom-sidecar, s3-bloom,
    db-first on/off) into a Phase-156 memo ``sql_hash`` so a config flip busts
    stale survivor lists for an UNCHANGED snapshot (R6, 2026-07-22).

    SINGLE SOURCE OF TRUTH: every memo producer AND consumer must apply this
    identically or their keys diverge — the iceberg reader (get/put) and
    ``brain_router._consult_memo`` (the routing-hint sensor) both call it.  A
    survivor list cached under one pruning config must never be served under a
    different one (e.g. after the bloom-sidecar default flips), which would
    persist a stale over-prune (silent row loss) or a stale under-prune.

    Idempotent (a hash already carrying ``#cfg:`` is returned unchanged) and
    FAIL-OPEN (empty hash or any error → returned unchanged, config-blind key).
    """
    if not sql_hash or "#cfg:" in sql_hash:
        return sql_hash
    try:
        import hashlib
        from core.config import get as _cfg_get
        sig = "bs=%d|sb=%d|df=%d" % (
            int(bool(_cfg_get("iceberg", "bloom_sidecar_enabled", True))),
            int(bool(_cfg_get("iceberg", "s3_bloom_check_enabled", False))),
            int(bool(_cfg_get("iceberg", "db_first_enabled", True))),
        )
        return "%s#cfg:%s" % (
            # usedforsecurity=False (2026-09-13 triage, ruff S324):
            # content-addressing.  ``sig`` is THREE BOOLEANS, so the input
            # domain is 8 values -- a collision is not merely unlikely, it
            # is checkable by enumeration.  This discriminates pruning
            # memos by config; it gates nothing.  Flag does not change the
            # digest, so no memo key moves.
            sql_hash, hashlib.sha1(sig.encode("utf-8"),
                                   usedforsecurity=False).hexdigest()[:12])
    except Exception:
        return sql_hash


def _key(sql_hash: str, snapshot_id: str,
         bucket: str = "", table_prefix: str = "") -> str:
    # 2026-07-04 CORRECTNESS FIX: include table identity (bucket + prefix).
    # Keyed on (sql_hash, snapshot_id) alone, two PHYSICALLY DISTINCT tables
    # that share a normalised SQL string AND a snapshot_id collided on one
    # memo entry -> the reader scanned the OTHER table's surviving_files.
    # snapshot_id stays at the TAIL so invalidate_for_snapshot's
    # ``endswith(":{snapshot_id}")`` still matches.
    _tp = (table_prefix or "").rstrip("/")
    return f"{sql_hash}:{bucket or ''}:{_tp}:{snapshot_id or '*'}"


def _gen_for(snapshot_id: str) -> int:
    """Read the current invalidation generation for a snapshot.
    No lock -- the caller compares before/after under the lock when
    deciding whether to promote a DB result into the LRU."""
    return _INVALIDATION_GEN.get(snapshot_id or "*", 0)


# BF-PRUNE-RACE (2026-07-21): after an invalidation for a snapshot, suppress
# put_memo for THAT snapshot for a short window.  Closes the race where a query
# that began pruning WITHOUT the newly-built column stats writes its stale
# survivor list back AFTER the stats-scan invalidation fired — re-poisoning the
# just-cleared memo for the same (never-changing) snapshot.  The
# snapshot-CHANGE path was immune (new queries use a new snapshot key); the new
# same-snapshot stats-scan trigger is not, hence this guard.  A put from a query
# that started AFTER the invalidation is merely deferred one round (it re-prunes
# on the next run — always correct), so suppression is safe.
_PUT_SUPPRESS_SECONDS = 10.0
_SUPPRESS_PUT_UNTIL: Dict[str, float] = {}


def _put_suppressed(snapshot_id: str) -> bool:
    return time.monotonic() < _SUPPRESS_PUT_UNTIL.get(snapshot_id or "*", 0.0)


def _evict_lru_if_needed() -> None:
    cap = in_process_max_entries()
    if len(_CACHE) < cap:
        return
    to_drop = sorted(
        _CACHE.items(), key=lambda kv: kv[1].get("created_at", 0),
    )[: max(1, cap // 10)]
    for k, _ in to_drop:
        _CACHE.pop(k, None)


# ── Public API ───────────────────────────────────────────────────────


def get_memo(
    sql_hash: str, snapshot_id: str,
    bucket: Optional[str] = None,
    table_prefix: Optional[str] = None,
    db_manager: Any = None,
) -> Optional[Dict[str, Any]]:
    """Return the cached pruned-file list for this
    (sql_hash, snapshot_id, bucket, table_prefix), or None.

    Two-tier lookup: in-process LRU first (~microsecond), DB second
    (~ms).  Promotes DB hits into the LRU.

    2026-07-04 CORRECTNESS FIX: ``bucket``/``table_prefix`` scope the memo
    to a specific physical table.  The LRU key now includes them, and any
    DB row (fetched by sql_hash+snapshot_id, which the DB PK is keyed on)
    is VALIDATED against them before use -- so a normalised-SQL +
    snapshot_id collision across two distinct tables can't serve one
    table's file list for the other.  Identity checks are skipped when the
    caller omits both (back-compat for identity-less consumers)."""
    if not enabled() or not sql_hash or not snapshot_id:
        return None
    # R6: fold the pruning-config fingerprint in HERE — the single chokepoint
    # every producer/consumer flows through — so callers pass a RAW hash and can
    # never drift out of sync (the reader put/get and brain_router all match).
    # Idempotent: a hash already carrying "#cfg:" is returned unchanged.
    sql_hash = apply_config_fingerprint(sql_hash)

    def _identity_ok(_row: Dict[str, Any]) -> bool:
        if bucket is None and table_prefix is None:
            return True   # identity-less caller -> no cross-table serving risk asserted
        return (
            str(_row.get("bucket") or "") == str(bucket or "")
            and same_prefix(_row.get("table_prefix"), table_prefix)
        )

    key = _key(sql_hash, snapshot_id, bucket or "", table_prefix or "")
    now = time.time()
    with _LOCK:
        entry = _CACHE.get(key)
    if entry is not None:
        if now - entry.get("created_at", 0) < in_process_ttl_seconds():
            _val = entry.get("value")
            if _val is not None and _identity_ok(_val):
                return _val
        with _LOCK:
            _CACHE.pop(key, None)
    if db_manager is None:
        try:
            from core.database import get_db_manager
            db_manager = get_db_manager()
        except Exception:
            db_manager = None
    if db_manager is None:
        return None
    # Snapshot the generation BEFORE the DB read so we can detect a
    # concurrent invalidate that fired during the read.
    gen_pre = _gen_for(snapshot_id)
    try:
        row = db_manager.brain_memo_get(sql_hash, snapshot_id)
    except Exception:
        return None
    if not row:
        return None
    # Table-identity guard: the DB row is keyed only on (sql_hash,
    # snapshot_id), so a different table sharing both would return HERE.
    # Reject the mismatch (miss -> caller does the full manifest walk).
    if not _identity_ok(row):
        logger.debug(
            "[brain-memo] identity mismatch (bucket/prefix) for "
            "sql_hash=%s snapshot=%s -- treating as miss to avoid serving "
            "another table's file list.", sql_hash, snapshot_id,
        )
        return None
    # Promote into LRU IFF no invalidate happened mid-read.  Without
    # this, a concurrent brain_freshness snapshot-roll could DELETE
    # this row from the DB, then we'd re-cache the stale value into
    # the LRU and serve it on every subsequent hit until the next
    # invalidate.
    with _LOCK:
        if _gen_for(snapshot_id) != gen_pre:
            # An invalidate fired during our read -- the row we just
            # got is stale.  Don't promote.  Return it once so the
            # caller's immediate use isn't broken, but the LRU stays
            # clean.
            return row
        _evict_lru_if_needed()
        _CACHE[key] = {"created_at": now, "value": row}
    return row


def put_memo(
    *, sql_hash: str, snapshot_id: str,
    bucket: str, table_prefix: str,
    surviving_files: List[str],
    surviving_count: int,
    pruning_breakdown: Optional[Dict[str, int]] = None,
    scan_meta: Optional[Dict[str, Any]] = None,
    db_manager: Any = None,
) -> None:
    """Store a pruned-file list for future identical queries.

    F4 (2026-08-22): ``scan_meta`` carries what a replay must reproduce
    beyond the file list — join_key_bounds / join_key_distinct_values /
    file_enumeration_complete for join queries, pos/eq_delete_files for
    MoR snapshots.  The consult side VALIDATES its presence before
    serving those query shapes; a record without it is a miss for them."""
    if not enabled() or not sql_hash or not snapshot_id:
        return
    # R6: fold the pruning-config fingerprint in HERE (same single chokepoint as
    # get_memo) so a survivor list is stored under a config-aware key and can
    # never be served under a different pruning config.  Idempotent.
    sql_hash = apply_config_fingerprint(sql_hash)
    # BF-PRUNE-RACE: drop puts that race a recent invalidation for this
    # snapshot (would re-poison the just-cleared memo with a pre-stats list).
    if _put_suppressed(snapshot_id):
        logger.debug(
            "[brain-memo] put suppressed for snapshot=%s (recent invalidation "
            "— avoids re-poisoning the cleared survivor list)", snapshot_id,
        )
        return
    # SIZE GUARD (2026-07-22): a weakly-filtered big-table query yields a HUGE
    # survivor list.  Storing it risks the same Postgres "invalid memory alloc
    # request size" the snapshot cache hit, and the entry-count-bounded L1
    # (in_process_max_entries) would OOM the pod on many such blobs.  A survivor
    # list this large also means pruning wasn't selective, so caching it is low
    # value — skip fail-open (the next identical query just re-prunes).
    _max_files = int(_cfg("max_survivor_files", 200000) or 0)
    if _max_files > 0 and len(surviving_files or []) > _max_files:
        logger.debug(
            "[brain-memo] SKIP put — %d survivors exceeds cap %d "
            "(too large to cache safely; re-prune next time)",
            len(surviving_files or []), _max_files,
        )
        return
    value = {
        "sql_hash":          sql_hash,
        "snapshot_id":       snapshot_id,
        "bucket":            bucket,
        "table_prefix":      (table_prefix or "").rstrip("/"),
        "surviving_files":   list(surviving_files or []),
        "surviving_count":   int(surviving_count or 0),
        "pruning_breakdown": pruning_breakdown,
        "scan_meta":         scan_meta,
        "hit_count":         0,
    }
    key = _key(sql_hash, snapshot_id, bucket, table_prefix)
    with _LOCK:
        _evict_lru_if_needed()
        _CACHE[key] = {"created_at": time.time(), "value": value}
    if db_manager is None:
        try:
            from core.database import get_db_manager
            db_manager = get_db_manager()
        except Exception:
            return
    if db_manager is None:
        return
    try:
        db_manager.brain_memo_put(
            sql_hash=sql_hash, snapshot_id=snapshot_id,
            bucket=bucket, table_prefix=table_prefix,
            surviving_files=surviving_files,
            surviving_count=surviving_count,
            pruning_breakdown=pruning_breakdown,
            scan_meta=scan_meta,
        )
    except Exception as exc:
        logger.debug("[brain-memo] DB put failed: %s", exc)


def invalidate_for_snapshot(
    snapshot_id: str, db_manager: Any = None,
) -> int:
    """Hook 1 mirror -- called by brain_freshness when the snapshot
    rolls forward.  Drops every memo pinned to the old snapshot from
    BOTH layers (LRU + DB)."""
    if not snapshot_id:
        return 0
    suffix = f":{snapshot_id}"
    with _LOCK:
        # Phase 156 R4 -- bump generation FIRST so any concurrent
        # get_memo that already read the DB will detect the change
        # under the lock and refuse to promote a stale row.
        _INVALIDATION_GEN[snapshot_id] = _INVALIDATION_GEN.get(snapshot_id, 0) + 1
        # Open the put-suppression window so an in-flight query's stale put
        # (computed before this invalidate) can't re-poison the cleared memo.
        _SUPPRESS_PUT_UNTIL[snapshot_id] = time.monotonic() + _PUT_SUPPRESS_SECONDS
        keys = [k for k in _CACHE if k.endswith(suffix)]
        for k in keys:
            _CACHE.pop(k, None)
    evicted_lru = len(keys)
    if db_manager is None:
        try:
            from core.database import get_db_manager
            db_manager = get_db_manager()
        except Exception:
            return evicted_lru
    if db_manager is None:
        return evicted_lru
    try:
        evicted_db = int(
            db_manager.brain_memo_invalidate_snapshot(snapshot_id) or 0
        )
    except Exception:
        evicted_db = 0
    return evicted_lru + evicted_db


def reset_for_tests() -> None:
    with _LOCK:
        _CACHE.clear()
        _INVALIDATION_GEN.clear()


def get_stats(db_manager: Any = None) -> Dict[str, Any]:
    """Admin telemetry snapshot.  Combines in-process + DB stats."""
    with _LOCK:
        in_proc = len(_CACHE)
    db_stats = {"entries": 0, "total_hits": 0}
    try:
        if db_manager is None:
            from core.database import get_db_manager
            db_manager = get_db_manager()
        if db_manager is not None:
            db_stats = db_manager.brain_memo_stats() or db_stats
    except Exception:
        pass
    return {
        "enabled":           enabled(),
        "in_process_entries": in_proc,
        "in_process_max":    in_process_max_entries(),
        "in_process_ttl_s":  in_process_ttl_seconds(),
        "db_entries":        db_stats.get("entries", 0),
        "db_total_hits":     db_stats.get("total_hits", 0),
    }


__all__ = [
    "enabled",
    "get_memo",
    "put_memo",
    "invalidate_for_snapshot",
    "reset_for_tests",
    "get_stats",
]
