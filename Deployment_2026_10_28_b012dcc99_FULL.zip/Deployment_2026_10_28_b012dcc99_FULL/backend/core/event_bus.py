"""
Cross-pod event bus — PostgreSQL LISTEN/NOTIFY native, no Redis required.

This is the foundation for the multi-pod architecture (see
docs/multi-pod-architecture-plan.html).  Three goals:

  1. Publishing an event from any pod reaches subscribers in all other
     pods within milliseconds (PG NOTIFY = sub-millisecond).
  2. Backward-compatible: in single-pod / SQLite mode, events go to an
     in-memory ring buffer + local subscribers, so existing WS broadcast
     continues to work unchanged.
  3. Fire-and-forget — publish() never blocks the caller, never raises.

PR1 SCOPE: event bus exists, dual-write at chosen broadcast sites.
Existing ws_manager.broadcast_to_user() still does its in-process work;
this module ALSO publishes to the bus.  When we split pods (PR2/PR3)
the WebSocket pod will subscribe to the bus instead of relying on
in-process state.

USAGE:
    from core.event_bus import publish

    publish("execution_progress",
            {"execution_id": eid, "rows": n},
            username="alice")

    # Returns immediately; failures are logged at debug level.

For OBSERVABILITY:
    from core.event_bus import recent_events
    last_100 = recent_events(limit=100)        # ring buffer for /debug
"""
from __future__ import annotations

import json
import logging
import os
import socket
import threading
import time
import uuid
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from typing import Any, Callable, Deque, Dict, List, Optional

logger = logging.getLogger(__name__)


# ── Instance identity (self-NOTIFY de-dup) ─────────────────────────────────────
# A stable per-process origin id.  Every event we NOTIFY out is stamped with
# this id in its serialized payload.  A PG LISTEN consumer on the SAME pod will
# receive its own NOTIFY back — but the in-process subscriber path already
# delivered that event locally, so re-delivering it would double-fire.
# ``deliver_remote_event()`` drops events whose ``_origin`` == our id.  Events
# from OTHER pods carry a different id and are delivered normally.
#
# Note: the id is stamped ONLY into the NOTIFY-serialized copy (see _dispatch),
# never into the dict handed to in-process subscribers / the ring buffer, so the
# local single-pod WS payload is byte-identical to the pre-bus behaviour.
_INSTANCE_ID = "%s:%d:%s" % (socket.gethostname(), os.getpid(), uuid.uuid4().hex[:8])


def instance_id() -> str:
    """Return this process's stable event-bus origin id."""
    return _INSTANCE_ID


# ── Configuration ─────────────────────────────────────────────────────────────

# Maximum recent events kept in memory for /debug observability.
# Bounded ring buffer so this can never grow unboundedly under burst.
_MAX_RECENT = 1000

# Maximum NOTIFY payload size — PostgreSQL hard limit is 8000 bytes.
# Truncate large payloads with a flag rather than fail-silently.
_MAX_NOTIFY_BYTES = 7500


# ── Module-level state ────────────────────────────────────────────────────────

# Ring buffer of recent events — newest first.  Used by /debug endpoint
# and by tests to assert what was published.
_recent: Deque[Dict[str, Any]] = deque(maxlen=_MAX_RECENT)
_recent_lock = threading.Lock()

# In-process subscribers (used in single-pod mode).  Each subscriber is
# a callable receiving the event dict.  Wired by main.py at startup so
# ws_manager.broadcast_to_user can be invoked off-loop.
_subscribers: List[Callable[[Dict[str, Any]], None]] = []
_subscribers_lock = threading.Lock()

# Dedicated thread pool — publish() runs the actual delivery off-loop
# so the calling coroutine isn't blocked on PG round-trip or subscriber
# fan-out.  4 threads is plenty; fan-out is ms-fast.
_publish_pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="evbus-")

# Tracked futures for flush_pending() — bounded ring of the most recent
# submitted dispatch tasks.  flush_pending() waits on these specifically;
# waiting on no-ops alone races across the multi-worker pool.
_pending_futures: list = []
_pending_lock = threading.Lock()

# Backend selector: set at startup by init_event_bus() based on
# database.type config.  When None, only the in-memory path runs.
_pg_notify_callable: Optional[Callable[[str, str], None]] = None

# Counters for /debug telemetry
_counters = {
    "published":    0,
    "pg_notify_ok": 0,
    "pg_notify_err": 0,
    "subscriber_err": 0,
    "truncated":    0,
    "self_notify_skipped": 0,   # cross-pod: self-originated NOTIFYs dropped
    "remote_delivered":    0,   # cross-pod: events from OTHER pods delivered
    "listen_connects":     0,   # LISTEN consumer: successful connects
    "listen_reconnects":   0,   # LISTEN consumer: reconnect attempts after loss
    "listen_notifies":     0,   # LISTEN consumer: NOTIFYs received
    "listen_parse_err":    0,   # LISTEN consumer: malformed payloads dropped
    "relay_published":     0,   # ws fleet-routing: NOTIFY-only relays sent
    "gap_replays":         0,   # LISTEN consumer: gap-handler invocations
}
_counters_lock = threading.Lock()


# ── Public API ────────────────────────────────────────────────────────────────

def init_event_bus(*, db_manager=None, db_type: str = "sqlite") -> None:
    """Wire the event bus to the configured backend.  Called once at
    startup from main.py (or scheduler_worker.py / future query_worker.py).

    Args:
      db_manager: DatabaseManager instance — used to send pg_notify when
                  db_type is 'postgresql'.
      db_type:    'postgresql' or 'sqlite' (the latter just uses memory).
    """
    global _pg_notify_callable
    if db_type == "postgresql" and db_manager is not None:
        _pg_notify_callable = _build_pg_notify(db_manager)
        logger.info("event_bus: initialized with PostgreSQL NOTIFY backend")
    else:
        _pg_notify_callable = None
        logger.info("event_bus: initialized in IN-MEMORY mode (db_type=%s)", db_type)


def _normalise_audience(audience) -> Optional[List[str]]:
    """A de-duplicated list of non-empty usernames, or None when no list was
    given.  ``[]`` is kept: an EMPTY audience is an address too (nobody),
    never "everybody"."""
    if audience is None:
        return None
    out: List[str] = []
    for n in audience:
        if isinstance(n, str) and n.strip() and n not in out:
            out.append(n)
    return out


def recipients_of(event: Dict[str, Any]) -> Optional[List[str]]:
    """THE reader of a delivered event's address (2026-10-07).

    * ``audience`` present -> that list (possibly EMPTY: nobody);
    * else ``username`` set -> ``[username]``;
    * else ``None`` -> the event was published UNADDRESSED (a platform-wide
      event, e.g. a completeness alert) and the caller keeps its existing
      unaddressed behaviour.

    Every delivering side -- the in-process subscriber, the PG LISTEN
    consumer's fan-out, the notification outbox drain, the Redis
    subscriber -- reads the address through this one function
    (``WebSocketManager.deliver_addressed``), so a list published on one
    pod is honoured on every pod.
    """
    if not isinstance(event, dict):
        return None
    aud = event.get("audience")
    if isinstance(aud, (list, tuple)):
        return _normalise_audience(aud)
    user = event.get("username")
    if isinstance(user, str) and user:
        return [user]
    return None


def publish(event_type: str, payload: Dict[str, Any], *,
            username: Optional[str] = None,
            audience: Optional[List[str]] = None) -> None:
    """Publish an event to all subscribers (in-process + cross-pod via PG NOTIFY).

    Fire-and-forget.  Never raises, never blocks the caller.

    Args:
      event_type: Logical channel ("execution_progress", "agent_suggestion", ...)
      payload:    Event-specific data.  Must be JSON-serializable.
      username:   Optional user filter — when set, the WebSocket pod only
                  delivers to that user's connections.
      audience:   Optional LIST of usernames (2026-10-07) -- delivered to
                  exactly those users' connections on every pod (see
                  :func:`recipients_of`).  ``username`` becomes its first
                  name for a consumer that reads only the single key.  An
                  EMPTY list addresses nobody.

    Channel naming: PG NOTIFY uses a single channel ('qs_events') with
    event_type embedded in the JSON payload.  This avoids the per-channel
    LISTEN setup cost in subscribers — a single LISTEN catches everything.
    """
    event = {
        "type":     event_type,
        "username": username,
        "ts":       datetime.now(timezone.utc).isoformat(),
        **payload,
    }
    aud = _normalise_audience(audience)
    if aud is not None:
        event["audience"] = aud
        event["username"] = username or (aud[0] if aud else None)
    # Submit to thread pool — never block the caller.  Track the future
    # so flush_pending() can wait for THIS specific dispatch to complete
    # (waiting on no-op futures alone is racy across workers).
    #
    # IMPORTANT: hold ``_pending_lock`` across submit + append so a
    # concurrent flush_pending() cannot drain the tracked list between
    # those two operations and miss this dispatch.  Submitting under the
    # lock is cheap (pool.submit is non-blocking).
    try:
        with _pending_lock:
            fut = _publish_pool.submit(_dispatch, event)
            _pending_futures.append(fut)
            # Bound the list — keep only recent ones to avoid unbounded growth
            if len(_pending_futures) > 256:
                # Drop the oldest 64 — they should already be done
                del _pending_futures[:64]
    except Exception as exc:
        logger.debug("event_bus.publish submit failed (non-fatal): %s", exc)


def publish_notify_only(payload: Dict[str, Any], *,
                        username: Optional[str] = None,
                        audience: Optional[List[str]] = None) -> None:
    """Cross-pod HALF of :func:`publish` — pg_notify to PEER pods ONLY, with
    NO local subscriber fan-out (2026-08-02, ``websocket_and_progress_
    fleet_routed``).

    Used by ``WebSocketManager`` as its fleet-routing relay: the manager has
    ALREADY delivered the message to its local clients through the exact
    pre-existing code path, so only the remote half is needed.  Routing a
    manager broadcast through :func:`publish` instead would double-deliver
    locally (the in-process subscriber registered by main.py calls straight
    back into the manager).

    Guarantees / behaviour:
      * **N=1 / sqlite / unwired** — ``_pg_notify_callable`` is None →
        returns immediately.  Zero DB round-trips, zero thread hops, the
        caller's dict untouched: the local path is byte-identical to the
        pre-relay behaviour.
      * **Fire-and-forget** — the JSON encode + pg_notify run on the
        publish thread pool; the caller (usually the event loop) is never
        blocked on a DB round-trip.  Failures are counted + debug-logged,
        never raised (fail-open).
      * **Loop-proof** — a payload that already carries ``_origin`` arrived
        FROM the bus (a remote-delivered event being re-broadcast locally);
        re-relaying it would ping-pong between pods forever, so it is
        dropped here as defense-in-depth on top of the managers'
        ``local_only=True`` receive path.
      * The caller's dict is never mutated (the same object is concurrently
        used for the local WS sends); routing keys are stamped on a copy.
    """
    if _pg_notify_callable is None:
        return
    if not isinstance(payload, dict):
        return
    if "_origin" in payload:
        return
    event = dict(payload)
    if username is not None:
        event["username"] = username
    aud = _normalise_audience(audience)
    if aud is not None:
        event["audience"] = aud
    try:
        with _pending_lock:
            fut = _publish_pool.submit(_notify_only_dispatch, event)
            _pending_futures.append(fut)
            if len(_pending_futures) > 256:
                del _pending_futures[:64]
    except Exception as exc:
        logger.debug("event_bus.publish_notify_only submit failed "
                     "(non-fatal): %s", exc)


def _notify_only_dispatch(event: Dict[str, Any]) -> None:
    """Worker-thread side of :func:`publish_notify_only` — NOTIFY only, no
    ring buffer, no local subscribers.  Never raises."""
    try:
        pg = _pg_notify_callable
        if pg is None:  # backend un-wired between submit and run
            return
        notify_event = dict(event)
        notify_event["_origin"] = _INSTANCE_ID
        payload_json = json.dumps(notify_event, default=str)
        if len(payload_json.encode("utf-8")) > _MAX_NOTIFY_BYTES:
            # Keep every ROUTING key AND the terminal verdict so a
            # truncated completion/failure still tells the remote UI what
            # happened to which execution (a bare marker would silently
            # drop the completion — unacceptable).
            trunc: Dict[str, Any] = {
                "type":         event.get("type"),
                "username":     event.get("username"),
                "audience":     event.get("audience"),
                "execution_id": event.get("execution_id"),
                "ts":           event.get("ts") or event.get("timestamp"),
                "_origin":      _INSTANCE_ID,
                "_truncated":   True,
                "_orig_size":   len(payload_json),
            }
            data = event.get("data")
            if isinstance(data, dict) and data.get("status") is not None:
                trunc["data"] = {"status": data.get("status")}
            payload_json = json.dumps(trunc, default=str)
            with _counters_lock:
                _counters["truncated"] += 1
        pg(_LISTEN_CHANNEL, payload_json)
        with _counters_lock:
            _counters["pg_notify_ok"] += 1
            _counters["relay_published"] += 1
    except Exception as exc:
        with _counters_lock:
            _counters["pg_notify_err"] += 1
        logger.debug("event_bus relay NOTIFY failed (non-fatal, local WS "
                     "delivery already happened): %s", exc)


def subscribe(callback: Callable[[Dict[str, Any]], None]) -> Callable[[], None]:
    """Register an in-process subscriber.  Returns an unsubscribe function.

    PR1 use: ws_manager hooks here so events published anywhere in the
    process reach the WebSocket clients without each call site knowing
    about WebSocket internals.

    PR3 (WebSocket pod split): the WebSocket pod uses subscribe() to
    register its fan-out callback; the API pod uses subscribe() too so
    in-process WS still works during the transition.
    """
    with _subscribers_lock:
        _subscribers.append(callback)
    def _unsub():
        with _subscribers_lock:
            if callback in _subscribers:
                _subscribers.remove(callback)
    return _unsub


def is_self_originated(event: Dict[str, Any]) -> bool:
    """True when ``event`` was published by THIS process (its ``_origin`` id
    matches ours).  A PG LISTEN consumer uses this to skip its own NOTIFYs,
    which the in-process subscriber path already delivered locally."""
    try:
        return event.get("_origin") == _INSTANCE_ID
    except AttributeError:
        return False


def deliver_remote_event(event: Dict[str, Any]) -> bool:
    """Entry point for a cross-pod PG LISTEN consumer.

    Given an event dict decoded from a ``qs_events`` NOTIFY payload, apply the
    self-NOTIFY de-dup guard then fan the event out to local in-process
    subscribers (the same delivery the origin pod ran in ``_dispatch``).

    Returns:
      * ``False`` — event was self-originated (already delivered locally by the
        in-process subscriber on this pod) and was therefore SKIPPED.  This is
        the de-dup that prevents the origin pod double-delivering its own NOTIFY.
      * ``True``  — event came from ANOTHER pod and was delivered to local subs.

    Fail-open: a subscriber raising is logged and swallowed; it never propagates
    to the LISTEN loop.

    NOTE: no LISTEN loop is auto-started in this repo yet (single-pod default).
    A pod that terminates WebSockets wires a LISTEN thread that calls this for
    each NOTIFY — see the module docstring / multi-pod plan.  Kept as a factored
    seam so the de-dup + fan-out is unit-testable without a real cluster.
    """
    if not isinstance(event, dict):
        return False
    if is_self_originated(event):
        with _counters_lock:
            _counters["self_notify_skipped"] += 1
        return False
    # Remote event — deliver to local subscribers (ws_manager etc.).
    with _subscribers_lock:
        subs = list(_subscribers)
    for cb in subs:
        try:
            cb(event)
        except Exception as exc:
            with _counters_lock:
                _counters["subscriber_err"] += 1
            logger.debug("event_bus remote subscriber raised (non-fatal): %s", exc)
    # Record for observability so /debug shows cross-pod traffic too.
    with _recent_lock:
        _recent.append(event)
    with _counters_lock:
        _counters["remote_delivered"] += 1
    return True


def recent_events(limit: int = 100,
                  event_type: Optional[str] = None,
                  username: Optional[str] = None) -> List[Dict[str, Any]]:
    """Return the most-recent events from the ring buffer.

    Used by /api/admin/event-bus/recent for observability.  Filters
    optional.  Returns newest-first.
    """
    with _recent_lock:
        items = list(_recent)
    items.reverse()  # newest first
    if event_type:
        items = [e for e in items if e.get("type") == event_type]
    if username:
        items = [e for e in items if e.get("username") == username]
    return items[:limit]


def stats() -> Dict[str, Any]:
    """Return event bus telemetry — published counts, errors, backend mode."""
    with _counters_lock:
        c = dict(_counters)
    with _subscribers_lock:
        sub_count = len(_subscribers)
    with _recent_lock:
        buf_count = len(_recent)
    return {
        "backend":           "postgresql" if _pg_notify_callable else "in_memory",
        "subscriber_count":  sub_count,
        "buffer_count":      buf_count,
        **c,
    }


def flush_pending(timeout: float = 5.0) -> None:
    """Wait for all in-flight publish() dispatches to complete.  TEST USE ONLY.

    Production code should never call this — fire-and-forget is the point.

    Implementation: drain the tracked _pending_futures list.  Each call to
    publish() records its dispatch future here; we wait for every one.
    No-op padding alone is insufficient because the pool is multi-worker
    and no-ops can run on idle workers in parallel with active dispatches.
    """
    with _pending_lock:
        pending = list(_pending_futures)
        _pending_futures.clear()
    for fut in pending:
        try:
            fut.result(timeout=timeout)
        except Exception:
            pass


# ── Internals ─────────────────────────────────────────────────────────────────

def _dispatch(event: Dict[str, Any]) -> None:
    """Worker-thread side: append to ring + notify PG + fan out locally."""
    # 1. Always append to ring buffer (for observability)
    with _recent_lock:
        _recent.append(event)
    with _counters_lock:
        _counters["published"] += 1

    # 2. Cross-pod: PG NOTIFY (if enabled)
    if _pg_notify_callable is not None:
        try:
            # Stamp the origin id ONLY into the serialized NOTIFY copy — never
            # into ``event`` itself — so the in-process subscriber path and the
            # ring buffer stay byte-identical to pre-bus single-pod behaviour,
            # while the cross-pod consumer can still self-dedup on ``_origin``.
            notify_event = dict(event)
            notify_event["_origin"] = _INSTANCE_ID
            payload_json = json.dumps(notify_event, default=str)
            if len(payload_json.encode("utf-8")) > _MAX_NOTIFY_BYTES:
                # Truncate by replacing payload with a marker — keep the
                # essential routing keys (type, username, origin) intact.
                trunc = {
                    "type":      event.get("type"),
                    "username":  event.get("username"),
                    "audience":  event.get("audience"),
                    "ts":        event.get("ts"),
                    "_origin":    _INSTANCE_ID,
                    "_truncated": True,
                    "_orig_size": len(payload_json),
                }
                payload_json = json.dumps(trunc)
                with _counters_lock:
                    _counters["truncated"] += 1
            _pg_notify_callable("qs_events", payload_json)
            with _counters_lock:
                _counters["pg_notify_ok"] += 1
        except Exception as exc:
            with _counters_lock:
                _counters["pg_notify_err"] += 1
            logger.debug("event_bus PG NOTIFY failed (non-fatal): %s", exc)

    # 3. In-process: fan out to local subscribers (existing ws_manager etc.)
    with _subscribers_lock:
        subs = list(_subscribers)
    for cb in subs:
        try:
            cb(event)
        except Exception as exc:
            with _counters_lock:
                _counters["subscriber_err"] += 1
            logger.debug("event_bus subscriber raised (non-fatal): %s", exc)


def _build_pg_notify(db_manager) -> Callable[[str, str], None]:
    """Construct a callable that issues `SELECT pg_notify(channel, payload)`
    using a short-lived session.  Bound to the provided db_manager."""

    def _notify(channel: str, payload: str) -> None:
        from sqlalchemy import text
        with db_manager.get_session() as session:
            session.execute(
                text("SELECT pg_notify(:ch, :msg)"),
                {"ch": channel, "msg": payload},
            )
    return _notify


# ── Cross-pod LISTEN consumer (the receiving half) ─────────────────────────────
#
# The counterpart to the publish/NOTIFY half above.  publish() → pg_notify()
# emits on the 'qs_events' channel; THIS consumer runs on the pod(s) that
# terminate WebSockets (the API pod), holds a DEDICATED psycopg connection doing
# ``LISTEN qs_events``, and routes every inbound NOTIFY through
# :func:`deliver_remote_event` — which drops self-originated events
# (``_origin == _INSTANCE_ID``, already delivered in-process on the origin pod)
# and fans the rest out to local subscribers (→ _local_ws_dispatch → ws_manager).
#
# Without this half, cross-pod delivery is a no-op (NOTIFY into the void).  It is
# a NO-OP in sqlite / single-pod mode (the in-process subscriber path already
# delivers everything locally).

_LISTEN_CHANNEL = "qs_events"

_listener_thread: Optional[threading.Thread] = None
_listener_stop = threading.Event()
_listener_lock = threading.Lock()

# ── Gap handlers — the completion backstop (2026-08-02) ────────────────────────
# PG NOTIFY is not durable: any NOTIFY emitted while THIS pod's LISTEN
# connection was down is lost forever.  For progress ticks that is fine
# (the next tick supersedes), but a lost COMPLETION event leaves a user's
# UI hanging on a query that finished on another pod.  The listener
# therefore tracks its own outage window and, on RE-connect after a loss,
# invokes registered gap handlers with (lost_since_wall, reconnected_wall).
# main.py registers a handler that re-reads terminal execution rows from
# the DB (the durable source of truth) for that window and re-delivers
# them to local clients.  Bounded: the window is clamped to
# _GAP_MAX_WINDOW_SECONDS; handlers only fire on reconnect-after-loss
# (never on first connect, never per-NOTIFY); failures are debug-logged
# and swallowed so a bad handler can never kill the LISTEN loop.

_GAP_MAX_WINDOW_SECONDS = 900.0     # replay at most the last 15 minutes
_GAP_CLOCK_MARGIN_SECONDS = 30.0    # cross-pod wall-clock skew allowance

_gap_handlers: List[Callable[[float, float], None]] = []
_gap_handlers_lock = threading.Lock()


def register_gap_handler(
        callback: Callable[[float, float], None]) -> Callable[[], None]:
    """Register ``callback(lost_since_wall, reconnected_wall)`` to run after
    the LISTEN connection is re-established following a loss.  Returns an
    unregister function.  Handlers run on the listener thread — keep them
    quick and schedule real work elsewhere (run_coroutine_threadsafe)."""
    with _gap_handlers_lock:
        _gap_handlers.append(callback)

    def _unregister() -> None:
        with _gap_handlers_lock:
            if callback in _gap_handlers:
                _gap_handlers.remove(callback)
    return _unregister


def _fire_gap_handlers(lost_since: float, now_wall: float) -> None:
    """Invoke every gap handler with a clamped outage window.  Never raises."""
    since = max(lost_since - _GAP_CLOCK_MARGIN_SECONDS,
                now_wall - _GAP_MAX_WINDOW_SECONDS)
    with _gap_handlers_lock:
        handlers = list(_gap_handlers)
    if not handlers:
        return
    with _counters_lock:
        _counters["gap_replays"] += 1
    logger.info("event_bus: LISTEN re-established after ~%.0fs outage — "
                "running %d gap handler(s) for the missed window",
                max(0.0, now_wall - lost_since), len(handlers))
    for cb in handlers:
        try:
            cb(since, now_wall)
        except Exception as exc:
            logger.debug("event_bus gap handler raised (non-fatal): %s", exc)


def _handle_notify_payload(raw: str) -> bool:
    """Parse ONE NOTIFY payload string and route it through the self-dedup +
    fan-out seam.  NEVER raises — a malformed / non-dict payload is counted,
    logged at debug, and dropped so the listener loop survives.

    Returns deliver_remote_event's result (True delivered, False skipped/dropped).
    This is the unit-testable core of the listener — tests exercise it directly
    with JSON strings, no psycopg required.
    """
    with _counters_lock:
        _counters["listen_notifies"] += 1
    try:
        event = json.loads(raw)
    except Exception as exc:
        with _counters_lock:
            _counters["listen_parse_err"] += 1
        logger.debug("event_bus listener: bad NOTIFY payload dropped (%s): %r",
                     exc, raw[:200])
        return False
    if not isinstance(event, dict):
        with _counters_lock:
            _counters["listen_parse_err"] += 1
        logger.debug("event_bus listener: non-dict NOTIFY payload dropped: %r",
                     str(event)[:200])
        return False
    try:
        # Oversized events arrive here as the publish-side truncation marker
        # ({type, username, ts, _origin, _truncated}) — a valid dict, so they
        # degrade to a routing-only signal cross-pod rather than crashing.
        return deliver_remote_event(event)
    except Exception as exc:  # deliver_remote_event is already fail-open; defensive
        logger.debug("event_bus listener: deliver failed (non-fatal): %s", exc)
        return False


def start_listener(db_manager, db_type: str = "sqlite", *,
                   poll_timeout: float = 5.0) -> bool:
    """Start the cross-pod PG LISTEN consumer daemon.  PostgreSQL only.

    * NO-OP in sqlite / in-memory mode (single-pod in-process delivery already
      works) and when ``db_manager`` is None.
    * Idempotent — a second call while a listener is alive is a no-op
      (one listener per process).
    * Fail-open — any error is logged and swallowed; the caller's startup must
      not break because the listener could not start.

    Returns True iff a listener thread was started by THIS call.
    """
    global _listener_thread
    if db_type != "postgresql" or db_manager is None:
        logger.info("event_bus: LISTEN consumer skipped (db_type=%s) — "
                    "single-pod in-process delivery is sufficient", db_type)
        return False
    try:
        with _listener_lock:
            if _listener_thread is not None and _listener_thread.is_alive():
                logger.debug("event_bus: LISTEN consumer already running — "
                             "skipping double-start")
                return False
            _listener_stop.clear()
            t = threading.Thread(
                target=_listen_loop, args=(db_manager,),
                kwargs={"poll_timeout": poll_timeout},
                name="evbus-listen", daemon=True,
            )
            t.start()
            _listener_thread = t
            logger.info("event_bus: cross-pod LISTEN consumer started "
                        "(channel=%s)", _LISTEN_CHANNEL)
            return True
    except Exception as exc:
        logger.warning("event_bus: LISTEN consumer failed to start (%s) — "
                       "cross-pod delivery disabled; in-process WS unaffected",
                       exc)
        return False


def stop_listener(timeout: float = 5.0) -> None:
    """Signal the LISTEN consumer to stop and join briefly.  For clean shutdown
    and tests.  Safe to call when no listener is running."""
    global _listener_thread
    _listener_stop.set()
    with _listener_lock:
        t = _listener_thread
        _listener_thread = None
    if t is not None and t.is_alive():
        try:
            t.join(timeout=timeout)
        except Exception:
            pass


def listener_running() -> bool:
    """True when the LISTEN consumer daemon is alive (observability / tests)."""
    with _listener_lock:
        return _listener_thread is not None and _listener_thread.is_alive()


def _build_listen_dsn(db_manager) -> str:
    """Render a libpq DSN from the SQLAlchemy engine URL, stripping any
    ``+driver`` suffix so psycopg2 / psycopg accept it directly."""
    url = db_manager.engine.url
    try:
        dsn = url.render_as_string(hide_password=False)
    except TypeError:  # very old SQLAlchemy without the kwarg
        dsn = str(url)
    for drv in ("+psycopg2", "+psycopg", "+asyncpg", "+pg8000"):
        dsn = dsn.replace(drv, "", 1)
    return dsn


def _open_listen_connection(dsn: str):
    """Open a DEDICATED autocommit connection for LISTEN — SEPARATE from the
    SQLAlchemy pool (LISTEN holds its connection for the process lifetime, so it
    must never borrow a pooled connection).  psycopg2 preferred (prod driver),
    psycopg (v3) fallback.  Returns ``(conn, flavor)``."""
    try:
        import psycopg2
        import psycopg2.extensions as _ext
        conn = psycopg2.connect(dsn)
        conn.set_isolation_level(_ext.ISOLATION_LEVEL_AUTOCOMMIT)
        return conn, "psycopg2"
    except ImportError:
        import psycopg  # psycopg 3
        conn = psycopg.connect(dsn, autocommit=True)
        return conn, "psycopg3"


def _listen_loop(db_manager, *, poll_timeout: float = 5.0) -> None:
    """Daemon body: connect → ``LISTEN qs_events`` → block for NOTIFYs → route
    each through :func:`_handle_notify_payload`.  Reconnects with bounded
    exponential backoff on connection loss.  NEVER raises out of the thread.

    The wait is bounded by ``poll_timeout`` so the loop periodically re-checks
    the stop flag even when idle (no NOTIFYs)."""
    import select

    backoff = 1.0
    backoff_max = 30.0
    # Gap tracking (2026-08-02): wall-clock time we LOST a previously-healthy
    # LISTEN connection (None = currently healthy or never yet connected).
    # Used to fire gap handlers on re-connect so completions NOTIFYed during
    # the outage can be recovered from the DB.  First-ever connect never
    # fires handlers (nothing was missed that this pod ever subscribed to).
    lost_since: Optional[float] = None
    had_healthy_connect = False

    while not _listener_stop.is_set():
        conn = None
        flavor = None
        try:
            dsn = _build_listen_dsn(db_manager)
            conn, flavor = _open_listen_connection(dsn)
            cur = conn.cursor()
            cur.execute("LISTEN %s" % _LISTEN_CHANNEL)
            if flavor == "psycopg2":
                cur.close()
            with _counters_lock:
                _counters["listen_connects"] += 1
            logger.info("event_bus: LISTEN %s established (%s)",
                        _LISTEN_CHANNEL, flavor)
            backoff = 1.0  # reset after a healthy connect
            if lost_since is not None:
                _fire_gap_handlers(lost_since, time.time())
                lost_since = None
            had_healthy_connect = True

            # Inner receive loop — survives until the connection drops or we
            # are asked to stop.
            while not _listener_stop.is_set():
                try:
                    readable, _, _ = select.select([conn], [], [], poll_timeout)
                except (OSError, ValueError):
                    # Connection fd went away — break to reconnect.
                    break
                if not readable:
                    continue  # timeout: re-check stop flag, keep listening
                if flavor == "psycopg2":
                    conn.poll()
                    while conn.notifies:
                        note = conn.notifies.pop(0)
                        _handle_notify_payload(note.payload)
                else:  # psycopg3
                    # Drain currently-available notifications without blocking.
                    for note in conn.notifies():
                        _handle_notify_payload(note.payload)
                        if _listener_stop.is_set():
                            break
        except Exception as exc:
            # Connection error (or driver missing).  Log, back off, reconnect —
            # unless we're shutting down.
            if not _listener_stop.is_set():
                with _counters_lock:
                    _counters["listen_reconnects"] += 1
                logger.warning("event_bus: LISTEN consumer connection error "
                               "(%s) — reconnecting in %.1fs", exc, backoff)
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
        # Gap tracking: whatever path brought us here (inner-loop fd break,
        # connect failure, receive exception) — if we HAD a healthy LISTEN
        # and are not shutting down, the outage clock starts at the first
        # loss and keeps running across failed reconnect attempts.
        if (had_healthy_connect and lost_since is None
                and not _listener_stop.is_set()):
            lost_since = time.time()
        # Bounded backoff before reconnect (skipped on clean stop).
        if not _listener_stop.is_set():
            _listener_stop.wait(timeout=backoff)
            backoff = min(backoff_max, backoff * 2)

    logger.info("event_bus: LISTEN consumer stopped")
