"""Sidecar coverage is a FRACTION of the current snapshot's data files.

2026-10-08.  Live on real AWS: ``fact_tetb`` had 2,688 data files and bloom
rows for ``system_id`` on 672 of them (one older snapshot).  The adaptive
prefetcher read three ``system_id = ...`` history rows, saw that the column
HAD bloom rows, called it "already fully covered" and ranked nothing; the
tick reported ``no_input``.  The other 2,016 files could never be
bloom-pruned, and nothing could say so.

The decision used to be made per COLUMN in three places (the prefetcher's
planner, its snapshot-unchanged gate, and the maintainer's "same snapshot"
no-op).  It is now made ONCE, here, per FILE:

    a column is COVERED when its sidecar rows cover EVERY data file of the
    current snapshot; otherwise it is PARTIAL (a target for exactly the
    missing files) or UNCOVERED; and when the file list cannot be known it
    is UNKNOWN -- which is never "covered".

"What is covered" is defined as "what the scanner itself would skip": the
same ``iceberg_bloom_existing_keys`` / ``iceberg_file_stats_existing_files``
/ ``iceberg_col_stats_existing_files`` lookups that ``skip_already_scanned``
uses, so the planner and the scanner can never disagree about a file.

Two file-list sources feed the one decision:

  * :func:`current_snapshot_file_keys_db_first` -- NO S3: the watched
    table's last snapshot and the per-file rows store, served only when the
    store is PROVEN complete for that snapshot (header marker + row count).
    The planner uses it to drop proven-covered columns so ``top_n`` is not
    spent on them.  Unknown is reported as unknown.
  * the reader's own chokepoint (``get_iceberg_data_files(keys_only=True)``,
    db-first, L1-cached) -- what the scan stage, warm-on-commit and the
    maintainer already resolve; they hand its keys to :func:`column_coverage`.

Both sides are normalised to bare S3 keys: the rows store keeps the
manifest's ``s3://bucket/key`` verbatim, the sidecars key on the bare key.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

logger = logging.getLogger(__name__)

KIND_BLOOM = "bloom"
KIND_SUPPLEMENT = "supplement"

STATUS_COVERED = "covered"
STATUS_PARTIAL = "partial"
STATUS_UNCOVERED = "uncovered"
STATUS_UNKNOWN = "unknown"


def _bare_key(path: Any) -> str:
    """``s3://bucket/key`` / ``s3a://`` / bare key -> bare key."""
    s = str(path or "")
    for scheme in ("s3a://", "s3n://", "s3://"):
        if s.startswith(scheme):
            rest = s[len(scheme):]
            slash = rest.find("/")
            return rest[slash + 1:] if slash >= 0 else ""
    return s


@dataclass
class ColumnCoverage:
    """The verdict for one (table, column, kind)."""
    kind: str
    bucket: str
    table_prefix: str
    column: str
    status: str = STATUS_UNKNOWN
    files_total: Optional[int] = None       # None = the file list is unknown
    files_covered: int = 0
    missing_keys: List[str] = field(default_factory=list)
    snapshot_id: Optional[str] = None
    reason: str = ""

    @property
    def covered(self) -> bool:
        return self.status == STATUS_COVERED

    @property
    def known(self) -> bool:
        return self.status != STATUS_UNKNOWN

    def summary(self) -> Dict[str, Any]:
        """The slim shape for tick records and admin surfaces (no key lists)."""
        return {
            "kind": self.kind, "status": self.status,
            "files_total": self.files_total, "files_covered": self.files_covered,
            "files_missing": len(self.missing_keys) if self.known else None,
            "snapshot_id": self.snapshot_id, "reason": self.reason,
        }

    def to_dict(self) -> Dict[str, Any]:
        return self.summary()


def _supplement_grain() -> str:
    try:
        from core import config as _qs_config
        return str(_qs_config.iceberg_file_stats_grain() or "v3")
    except Exception:
        return "v3"


def covered_keys(db: Any, *, bucket: str, table_prefix: str, column: str,
                 kind: str, file_keys: Sequence[str], snapshot_id: str = "",
                 format: str = "iceberg") -> Optional[Set[str]]:
    """The bare keys among ``file_keys`` the scanner of ``kind`` would SKIP
    for ``column`` -- i.e. the covered ones.  ``None`` when the sidecar rows
    cannot be read (unknown, never "covered")."""
    col_l = (column or "").lower()
    prefix = (table_prefix or "").rstrip("/")
    keys = [_bare_key(k) for k in file_keys if k]
    try:
        if kind == KIND_BLOOM:
            pairs = db.iceberg_bloom_existing_keys(bucket, prefix, str(snapshot_id or ""),
                                                   format=format)
            have = {_bare_key(fp) for fp, c in pairs if c == col_l}
            return {k for k in keys if k in have}
        if kind == KIND_SUPPLEMENT:
            grain = _supplement_grain()
            if grain == "v3":
                found = db.iceberg_file_stats_existing_files(
                    bucket, prefix, str(snapshot_id or ""), format=format,
                    required_columns=[col_l], file_paths=list(keys))
            else:
                # v2 / both: the scanner's own skip set is per FILE (a file
                # with any column row is "scanned"), mirrored exactly.
                found = db.iceberg_col_stats_existing_files(
                    bucket, prefix, str(snapshot_id or ""), format=format)
            have = {_bare_key(fp) for fp in (found or []) if fp}
            return {k for k in keys if k in have}
        raise ValueError(f"unknown sidecar kind {kind!r}")
    except Exception as exc:  # noqa: BLE001
        # Unknown is reported, not guessed.
        logger.debug("[coverage] %s rows unreadable for %s/%s col=%s: %s",
                     kind, bucket, prefix, column, exc)
        return None


def column_coverage(db: Any, *, bucket: str, table_prefix: str, column: str,
                    kind: str, file_keys: Optional[Sequence[str]],
                    snapshot_id: Optional[str] = None,
                    format: str = "iceberg") -> ColumnCoverage:
    """THE decision.  ``file_keys`` is the current snapshot's data-file list
    (bare keys or URIs); ``None`` or empty means it could not be resolved and
    the verdict is UNKNOWN."""
    cov = ColumnCoverage(kind=kind, bucket=bucket,
                         table_prefix=(table_prefix or "").rstrip("/"),
                         column=(column or "").lower(),
                         snapshot_id=str(snapshot_id) if snapshot_id else None)
    keys: List[str] = []
    seen: Set[str] = set()
    for k in (file_keys or []):
        b = _bare_key(k)
        if b and b not in seen:
            seen.add(b)
            keys.append(b)
    if not keys:
        cov.reason = "file list unknown: the current snapshot's data files could not be resolved"
        return cov
    have = covered_keys(db, bucket=bucket, table_prefix=table_prefix, column=column,
                        kind=kind, file_keys=keys, snapshot_id=snapshot_id or "",
                        format=format)
    if have is None:
        cov.reason = f"{kind} rows unreadable"
        return cov
    cov.files_total = len(keys)
    cov.files_covered = len(have)
    cov.missing_keys = [k for k in keys if k not in have]
    if not cov.missing_keys:
        cov.status = STATUS_COVERED
        cov.reason = f"{kind} covers every file of the current snapshot ({len(keys)})"
    elif cov.files_covered > 0:
        cov.status = STATUS_PARTIAL
        cov.reason = (f"{kind} covers {cov.files_covered}/{len(keys)} files; "
                      f"{len(cov.missing_keys)} missing")
    else:
        cov.status = STATUS_UNCOVERED
        cov.reason = f"no {kind} rows for any of the {len(keys)} files"
    return cov


def union_missing(coverages: Iterable[ColumnCoverage], all_keys: Sequence[str]) -> List[str]:
    """The keys at least one coverage says are missing, in ``all_keys`` order.
    An UNKNOWN coverage contributes EVERY key (unknown is never covered; the
    scanner's own dedup absorbs any true duplicates)."""
    covs = list(coverages)
    if any(not c.known for c in covs):
        return [k for k in all_keys if k]
    missing: Set[str] = set()
    for c in covs:
        missing.update(c.missing_keys)
    return [k for k in all_keys if k and _bare_key(k) in missing]


def current_snapshot_file_keys_db_first(
        db: Any, bucket: str, table_prefix: str, *,
        snapshot_id: Optional[str] = None,
) -> Tuple[Optional[List[str]], Optional[str], str]:
    """``(keys, snapshot_id, reason)`` for the table's CURRENT snapshot with
    NO S3 access: the watched table's last snapshot (unless given) and the
    per-file rows store, served only when PROVEN complete for that snapshot
    (header marker ``storage_mode='rows'`` and COUNT(rows) == declared).
    ``keys`` is None whenever any of that cannot be shown; ``reason`` says
    which step could not."""
    prefix = (table_prefix or "").rstrip("/")
    sid: Optional[str] = str(snapshot_id) if snapshot_id else None
    try:
        if sid is None:
            sid = _watched_last_snapshot(db, bucket, prefix)
        if sid is None:
            return None, None, "current snapshot unknown db-first (table not watched / never synced)"
        header = db.get_iceberg_snapshot_cache(bucket, prefix, sid)
        if not isinstance(header, dict) or header.get("storage_mode") != "rows":
            return None, sid, f"rows store not written for snapshot {sid}"
        declared = int(header.get("file_count") or -1)
        actual = int(db.iceberg_snapshot_files_count(bucket, prefix, sid))
        if declared < 0 or actual != declared:
            return None, sid, (f"rows store unproven for snapshot {sid}: "
                               f"declared {declared}, present {actual}")
        paths = db.iceberg_snapshot_file_paths(bucket, prefix, sid)
        if not isinstance(paths, list):
            return None, sid, "rows store returned no list"
        keys = [_bare_key(p) for p in paths if p]
        if not keys:
            return None, sid, f"rows store holds no file for snapshot {sid}"
        return keys, sid, f"rows store proven complete for snapshot {sid} ({len(keys)} files)"
    except Exception as exc:  # noqa: BLE001
        # Unknown is reported, not guessed.
        return None, sid, f"db-first file list unreadable: {type(exc).__name__}: {exc}"[:300]


def _watched_last_snapshot(db: Any, bucket: str, prefix: str) -> Optional[str]:
    """The watcher's last recorded snapshot for the table, or None."""
    from core.db.models import WatchedIcebergTable
    from core.table_prefix import prefix_matches
    with db.get_session(read_only=True) as session:
        row = (session.query(WatchedIcebergTable.last_snapshot_id)
               .filter(WatchedIcebergTable.bucket == bucket,
                       prefix_matches(WatchedIcebergTable.table_prefix, prefix))
               .order_by(WatchedIcebergTable.last_synced_at.desc())
               .first())
    got = row[0] if row else None
    return got if isinstance(got, str) and got else None


# ── the BUILD verdict: what a scanner's summary says it did ───────────────
#
# 2026-10-08, found live on real AWS (us-east-2, connection aws-real): the
# bloom scanner answered ``scanned: 0, failed: 2000, failure_categories:
# {access_denied: 2000}`` for seven targets, and the tick above it said
# ``ok -- built 7 target(s): 7 bloom ... over 10067 file(s)``.  Every owner
# counted the files it OFFERED and the scanners it FIRED; none read what
# came back.  Enqueued is not built.  This is the ONE reading of a scanner
# summary (``scan_files_for_bloom`` / ``scan_files_to_supplement`` share the
# shape) so the prefetcher, warm-on-commit and the maintainer cannot
# disagree about whether a build happened.

@dataclass(frozen=True)
class ScanVerdict:
    """One scanner call, read back: ``scanned`` files produced rows,
    ``failed`` could not be read (by category), ``skipped`` already had
    rows.  ``built`` is "at least one file was scanned"; a call whose every
    file failed is ``failed_entirely`` and :meth:`describe` names the
    categories -- the sentence the tick's reason carries."""
    kind: str
    offered: int
    scanned: int
    skipped: int
    failed: int
    rows_inserted: int
    failure_categories: Dict[str, int] = field(default_factory=dict)

    @property
    def built(self) -> bool:
        return self.scanned > 0

    @property
    def failed_entirely(self) -> bool:
        return self.failed > 0 and self.scanned == 0

    def categories(self) -> str:
        if not self.failure_categories:
            return "unknown"
        return ", ".join(
            f"{k}" if len(self.failure_categories) == 1 else f"{k} x{v}"
            for k, v in sorted(self.failure_categories.items(),
                               key=lambda kv: (-kv[1], kv[0])))

    def describe(self) -> str:
        if self.failed_entirely:
            return (f"{self.kind} scan failed for {self.failed:,} of "
                    f"{max(self.offered, self.failed):,} file(s): "
                    f"{self.categories()}")
        if self.failed:
            return (f"{self.kind} scan: {self.scanned:,} of {self.offered:,} "
                    f"file(s) scanned, {self.failed:,} failed "
                    f"({self.categories()})")
        if self.scanned:
            return (f"{self.kind} scan: {self.scanned:,} file(s) scanned, "
                    f"{self.rows_inserted:,} row(s) written")
        if self.skipped:
            return (f"{self.kind} scan: nothing to do, {self.skipped:,} "
                    f"file(s) already had rows")
        return f"{self.kind} scan: nothing scanned"

    def summary(self) -> Dict[str, Any]:
        return {"kind": self.kind, "offered": self.offered,
                "scanned": self.scanned, "skipped": self.skipped,
                "failed": self.failed, "rows_inserted": self.rows_inserted,
                "failure_categories": dict(self.failure_categories),
                "built": self.built, "failed_entirely": self.failed_entirely}


def _int(v: Any) -> int:
    try:
        return int(v or 0)
    except (TypeError, ValueError):
        return 0


def scan_verdict(kind: str, summary: Any, offered: int) -> ScanVerdict:
    """Read a scanner summary (``{scanned, skipped, failed, rows_inserted,
    failure_categories}``) into a :class:`ScanVerdict`.  A summary that is
    not a dict (a stub, a crash swallowed upstream) is read as nothing
    scanned, so it can never count as built."""
    s = summary if isinstance(summary, dict) else {}
    cats = s.get("failure_categories")
    cats = {str(k): _int(v) for k, v in cats.items()} if isinstance(cats, dict) else {}
    return ScanVerdict(kind=str(kind), offered=_int(offered),
                       scanned=_int(s.get("scanned")), skipped=_int(s.get("skipped")),
                       failed=_int(s.get("failed")),
                       rows_inserted=_int(s.get("rows_inserted")),
                       failure_categories=cats)


def scan_error(verdicts: Iterable[ScanVerdict]) -> Optional[str]:
    """The error sentence for a build that scanned NOTHING while files
    failed, across every scanner fired -- None when some scanner built or
    nothing failed.  A scanner that scanned nothing because every file was
    skipped is not a failure."""
    vs = list(verdicts)
    if not vs or any(v.built for v in vs):
        return None
    whole = [v for v in vs if v.failed_entirely]
    if not whole:
        return None
    return "; ".join(v.describe() for v in whole)


__all__ = [
    "ColumnCoverage", "column_coverage", "covered_keys", "union_missing",
    "current_snapshot_file_keys_db_first",
    "ScanVerdict", "scan_verdict", "scan_error",
    "KIND_BLOOM", "KIND_SUPPLEMENT",
    "STATUS_COVERED", "STATUS_PARTIAL", "STATUS_UNCOVERED", "STATUS_UNKNOWN",
]
