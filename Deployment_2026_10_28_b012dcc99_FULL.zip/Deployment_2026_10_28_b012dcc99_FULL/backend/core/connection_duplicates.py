"""One S3 bucket, one connection.  The decision, made ONCE for every route.

2026-10-07, owner requirement: "If the same bucket has multiple connections we
should not allow creating a duplicate connection, else it will be an issue."
Two connections over one bucket split everything keyed on a connection --
registered tables, the schema catalog, the watched-table registry, caches and
their invalidation, RLS policies, ACL grants -- so the same data is governed
twice, cached twice and invalidated once.

Scope: S3 connection types only (the owner named buckets).  Identity is
``core.s3_storage.s3_source_identity``: the store (every AWS spelling of a
partition -- no endpoint, regional, ``s3-<region>``, VPCE generic or
``bucket.vpce-`` -- is one store; any other endpoint is its normalised host)
plus the case-folded bucket name.

* create / clone -> refused when any OTHER connection has the identity;
* edit -> refused when the edit MOVES the connection onto an identity another
  connection holds.  An edit that leaves a pre-existing duplicate where it is
  (renaming it, rotating its key) is allowed: those are surfaced to an admin
  (:func:`duplicate_groups`, the connections list), not made uneditable.

Existing duplicates are never deleted here.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Optional, Tuple

#: The connection types whose source is an S3 bucket.  Mirrors
#: ``core.federation_engine.S3_CONNECTION_TYPES`` (imported lazily there).
S3_TYPES = frozenset({"s3", "s3_minio", "s3_compatible"})


def is_s3_type(connection_type: Any) -> bool:
    return str(connection_type or "").strip().lower() in S3_TYPES


def identity_of(connection_type: Any, config: Any) -> Optional[Tuple[str, str]]:
    """The source identity, or None when it is not an S3 connection or names
    no bucket."""
    if not is_s3_type(connection_type) or not isinstance(config, dict):
        return None
    from core.s3_storage import s3_source_identity
    return s3_source_identity(config)


def describe_identity(identity: Tuple[str, str]) -> str:
    store, bucket = identity
    where = "AWS S3" if store.startswith("aws") else f"the S3 endpoint {store}"
    if store in ("aws-us-gov", "aws-cn"):
        where = f"AWS S3 ({store})"
    return f"bucket {bucket!r} on {where}"


def find_holder(connections: Iterable[Dict[str, Any]], identity: Tuple[str, str],
                *, exclude_id: Optional[int] = None) -> Optional[Dict[str, Any]]:
    """The first OTHER connection with ``identity`` (lowest id first, so the
    answer is stable), or None."""
    hits = []
    for c in connections or []:
        if exclude_id is not None and c.get("id") == exclude_id:
            continue
        if identity_of(c.get("connection_type"), c.get("config")) == identity:
            hits.append(c)
    return min(hits, key=lambda c: int(c.get("id") or 0)) if hits else None


def refusal_detail(identity: Tuple[str, str], holder: Dict[str, Any],
                   action: str) -> Dict[str, Any]:
    """The 409 body: a sentence an operator can act on, and the holder's id
    and name for a UI that wants to link to it."""
    name, cid = holder.get("name"), holder.get("id")
    return {
        "code": "duplicate_s3_bucket",
        "message": (
            f"Cannot {action}: connection {name!r} (id {cid}) already reads "
            f"{describe_identity(identity)}. One bucket has one connection -- "
            f"register more tables on {name!r}, or point this connection at a "
            f"different bucket."),
        "existing_connection": {"id": cid, "name": name},
        "bucket": identity[1],
        "store": identity[0],
    }


def check_create(connections: Iterable[Dict[str, Any]], connection_type: Any,
                 config: Any, *, action: str = "create this connection"
                 ) -> Optional[Dict[str, Any]]:
    """409 detail when creating (or cloning into) this config would duplicate
    a bucket another connection holds, else None."""
    ident = identity_of(connection_type, config)
    if ident is None:
        return None
    holder = find_holder(connections, ident)
    return refusal_detail(ident, holder, action) if holder else None


def check_update(connections: Iterable[Dict[str, Any]], connection_id: int,
                 before: Optional[Dict[str, Any]], connection_type: Any,
                 config: Any) -> Optional[Dict[str, Any]]:
    """409 detail when an EDIT moves connection ``connection_id`` onto a
    bucket another connection holds, else None.  An edit that keeps a
    pre-existing duplicate's identity unchanged is not refused."""
    ident = identity_of(connection_type, config)
    if ident is None:
        return None
    if before is not None and identity_of(before.get("connection_type"),
                                          before.get("config")) == ident:
        return None
    holder = find_holder(connections, ident, exclude_id=connection_id)
    return (refusal_detail(ident, holder, "save this connection")
            if holder else None)


def duplicate_groups(connections: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Every identity held by MORE than one connection -- the duplicates that
    predate the rule, for an admin to resolve.  Never deletes anything."""
    groups: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
    for c in connections or []:
        ident = identity_of(c.get("connection_type"), c.get("config"))
        if ident is not None:
            groups.setdefault(ident, []).append(c)
    out = []
    for ident, members in sorted(groups.items()):
        if len(members) < 2:
            continue
        members = sorted(members, key=lambda c: int(c.get("id") or 0))
        out.append({
            "store": ident[0], "bucket": ident[1],
            "connections": [{"id": m.get("id"), "name": m.get("name")}
                            for m in members],
            "message": (
                f"{len(members)} connections read "
                f"{describe_identity(ident)}: "
                + ", ".join(f"{m.get('name')!r} (id {m.get('id')})"
                            for m in members)
                + ". New duplicates are refused; merge these by moving the "
                  "registered tables onto one connection and deleting the "
                  "others."),
        })
    return out


def annotate(page: List[Dict[str, Any]],
             every_connection: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Stamp ``duplicate_bucket`` (the others + a message) on every
    connection of ``page`` that shares a bucket with ANY connection --
    judged over ``every_connection``, not just the page.  Mutates and
    returns ``page``."""
    by_id: Dict[Any, Dict[str, Any]] = {}
    for g in duplicate_groups(every_connection):
        for m in g["connections"]:
            by_id[m["id"]] = g
    for c in page:
        g = by_id.get(c.get("id"))
        if g:
            c["duplicate_bucket"] = {
                "bucket": g["bucket"], "store": g["store"],
                "others": [m for m in g["connections"] if m["id"] != c.get("id")],
                "message": g["message"],
            }
    return page


__all__ = ["S3_TYPES", "annotate", "check_create", "check_update",
           "describe_identity", "duplicate_groups", "find_holder",
           "identity_of", "is_s3_type", "refusal_detail"]
