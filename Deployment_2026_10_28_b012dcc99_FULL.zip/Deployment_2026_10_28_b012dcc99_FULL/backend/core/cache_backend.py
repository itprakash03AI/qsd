"""BF-425 — Cache backend abstraction for the S3 file pre-download cache.

Why this exists
---------------

The S3 file cache stores parquet bytes locally so DuckDB can read without
hitting S3 every time.  Today the cache lives on NFS (per the user's
deployment); tomorrow it might live on local SSD, GlusterFS, S3 (with
materialization), or anywhere else.  Each backend has different
consistency / atomicity / performance characteristics:

  - Local SSD       : POSIX, fast, no caching layer to defeat
  - NFS (shared)    : POSIX-ish, server-side atomic rename, but client
                      attribute caching (``actimeo=60`` default) means
                      stale exists/size lookups across pods
  - GlusterFS       : POSIX, distributed; rename atomicity depends on
                      volume type (replica vs distribute)
  - CephFS          : POSIX, capabilities-based, strong consistency
  - SMB/CIFS        : POSIX-ish, client cache, less reliable locking
  - S3 (s3fs-fuse)  : eventually consistent for some operations
  - S3 (native API) : not POSIX at all; needs different operations

Hardcoding NFS-specific tricks (like ``os.open + fstat`` to defeat
``actimeo``) into the cache code locks us into NFS forever.  The
``CacheBackend`` Protocol below abstracts the storage details so the
cache code (``core.s3_predownload``, ``core.duckdb_views.evict_s3_cache_lru``)
calls a small set of semantic operations and the backend handles its
own consistency model.

Migration story
---------------

Today (NFS, behind corporate proxy):
    ``proxy_cfg.enabled = true``
    ``s3_local_cache.enabled = true``
    ``s3_local_cache.cache_dir = /usr/local/querystudioapi/nfs/data/s3-cache``
    → predownload fires for every Iceberg query, results cached on NFS

Tomorrow (VPC endpoint reachable, no proxy):
    ``proxy_cfg.enabled = false``
    ``s3_local_cache.enabled = false``
    → predownload NEVER fires; DuckDB httpfs reads s3:// URLs directly
    via the VPC endpoint.  ZERO local file duplication.  No backend
    needed at all.

The user's stated end-state: "even I don't like download at all... don't
want duplicate of data".  This module is built so that switching to
that end-state is a CONFIG change — not a code change.  The
``CacheBackend`` Protocol remains as a SEAM, not a forcing function.

Protocol contract
-----------------

All implementations must:

1. **Atomic publish** — ``write_atomic`` MUST guarantee that a reader
   never observes a partial file.  POSIX rename works; S3 PUT is
   atomic; backends without atomic publish must implement it via a
   sidecar marker file.

2. **Path-traversal safe** — ``reserve_local_path`` MUST reject keys
   with ``..`` segments that would escape the cache root.

3. **Defeat backend-side caching at decision points** — ``size_if_complete``
   MUST force a fresh server round-trip on backends that cache
   attributes (NFS, SMB).  Stale "exists+size>0" for an evicted file
   is a CRITICAL bug class — see BF-424 N1.

4. **Concurrent-writer safe** — two writers of the same key MUST NOT
   produce a partial / interleaved file.  Iceberg files are immutable
   so byte-equal-anyway, but the file system pattern still has to be
   safe (each writer to its own tmp suffix, atomic rename to final).

5. **Idempotent delete** — ``delete`` MUST return False (not raise) on
   "already gone" — racing with another evictor is normal under
   multi-pod deployments.

6. **Backend-specific transient files MUST be skipped in
   ``list_for_eviction``** — NFS silly-rename ``.nfs<hex>``, partial
   uploads with ``.tmp.<...>`` suffix, etc.  See BF-424 N2.

Concrete implementations
------------------------

This module ships:

  - ``FilesystemBackend`` — covers local POSIX + NFS + GlusterFS + CephFS
    + SMB.  Single implementation because they all expose the same
    POSIX API; the NFS-safe ``os.open + fstat`` pattern works on all
    of them (slow no-op on local FS; required for NFS attribute-cache
    bypass).

Future implementations (sketched in docstrings, NOT shipped):

  - ``S3Backend`` — cache LIVES on S3.  Needs materialization to
    local disk before DuckDB reads (DuckDB needs file paths, not
    streams).  Eviction via S3 lifecycle policy or LIST + DELETE.
    Useful for cross-region cache sharing (multiple Kubernetes
    clusters reading from one cache).

  - ``NullBackend`` — explicit "no cache".  All ``size_if_complete``
    return None, all writes fail.  Used when ``s3_local_cache.enabled
    = false`` to make "no caching" a first-class mode rather than a
    code-path-bypass.  Also useful for tests.

  - ``RedisBackend`` — small files only (parquet footers, metadata
    sidecars).  Bytes go in Redis, not the FS.

Usage
-----

    from core.cache_backend import get_cache_backend, CacheBackend

    backend: CacheBackend = get_cache_backend()  # reads config

    # Cache hit check (replaces direct os.open + fstat)
    local_path = backend.size_if_complete("my-bucket", "data/file.parquet")
    if local_path is not None:
        return local_path  # DuckDB reads it

    # Atomic write (replaces tmp + os.replace dance)
    final_path = backend.write_atomic(
        "my-bucket", "data/file.parquet",
        body_iter,  # generator of bytes chunks
    )
    backend.mark_used("my-bucket", "data/file.parquet")

    # Eviction (replaces os.walk + os.stat + os.remove)
    for entry in backend.list_for_eviction():
        if total_size_so_far > budget:
            backend.delete_key(entry.key)

This file is Phase 1 of a 3-phase migration:
  Phase 1 (this commit) — define the Protocol + ship FilesystemBackend
  Phase 2 — migrate ``s3_predownload._download_one_with_retry`` to use it
  Phase 3 — migrate ``evict_s3_cache_lru`` to use it

Each phase is a separate commit + audit so we don't compound risk.
"""
from __future__ import annotations

import logging
import os
import re
import secrets
import shutil
from dataclasses import dataclass
from typing import Iterator, Optional, Protocol, runtime_checkable

logger = logging.getLogger(__name__)


# ── Data classes returned by Protocol methods ───────────────────────────────


@dataclass
class CacheEntry:
    """One entry yielded by ``list_for_eviction``.

    ``key`` is the opaque storage key (e.g., ``"bucket/path/to/file"``).
    ``local_path`` is what DuckDB would read; for object-store backends
    this is the materialization path (None until ``size_if_complete``
    is called).
    ``size_bytes`` is the on-disk / on-storage size.
    ``last_used`` is a unix timestamp for LRU sorting.  Backends that
    don't track per-file access time should fall back to mtime or
    creation-time — the semantic is "older = more evictable".
    """
    key: str
    local_path: str
    size_bytes: int
    last_used: float


@dataclass
class StorageStats:
    """Returned by ``stats()`` for monitoring + the disk-cap pre-flight."""
    total_bytes: int           # sum of cached entries
    free_bytes: int            # available space on the backend
    entry_count: int           # number of cached entries


# ── The Protocol ────────────────────────────────────────────────────────────


@runtime_checkable
class CacheBackend(Protocol):
    """Storage abstraction for the parquet cache.

    See module docstring for the full contract.
    """

    # Identity / config
    @property
    def name(self) -> str:
        """Human-readable backend name for logs (e.g., ``"filesystem"``,
        ``"s3"``, ``"null"``)."""
        ...

    @property
    def root(self) -> Optional[str]:
        """Root path / prefix for this backend (e.g., the cache_dir on
        FilesystemBackend, the S3 prefix on S3Backend).  ``None`` for
        backends with no notion of root (NullBackend)."""
        ...

    # Cache hit / size lookup
    def size_if_complete(self, bucket: str, s3_key: str) -> Optional[int]:
        """Return the size in bytes if the file is present AND complete
        (size > 0).  Return None on miss.

        IMPLEMENTATIONS MUST defeat backend-side caching that would
        hide deletes from another writer (NFS attribute cache, SMB
        client cache, S3 eventual-consistency).  See BF-424 N1.
        """
        ...

    # Path resolution (for DuckDB read)
    def reserve_local_path(self, bucket: str, s3_key: str) -> str:
        """Return the local filesystem path DuckDB would read.

        For FilesystemBackend: the path inside ``cache_dir``.
        For S3Backend: a temporary materialization path (in tmp dir).

        MUST reject path-traversal: a key with ``..`` segments that
        would escape the cache root raises ValueError.
        """
        ...

    # Atomic write
    def write_atomic(self, bucket: str, s3_key: str, body_chunks) -> int:
        """Stream bytes to the cache atomically.  Returns bytes written.

        ``body_chunks`` is an iterable of bytes (e.g., from
        ``s3_client.get_object()["Body"]``).

        MUST guarantee no reader observes a partial file.  Standard
        pattern: write to ``<final>.tmp.<unique>``, then ``os.replace``.

        Two concurrent writers of the same key MUST produce
        byte-identical content for immutable Iceberg files (the
        last-rename-wins semantics is acceptable — content is
        identical so readers don't notice which writer's bytes won).
        """
        ...

    # LRU
    def mark_used(self, bucket: str, s3_key: str) -> None:
        """LRU hint.  May be no-op on backends that don't track
        per-file access time (S3 only has LastModified).  POSIX uses
        ``os.utime``."""
        ...

    # Eviction
    def list_for_eviction(self) -> Iterator[CacheEntry]:
        """Iterate every cached entry for LRU eviction.

        SHOULD skip backend-specific transient files (NFS silly-rename
        ``.nfs<hex>``, in-flight tmp uploads, S3 multipart-upload
        markers, etc.) so they don't get ranked + deleted.
        """
        ...

    def re_stat(self, entry: CacheEntry) -> Optional[CacheEntry]:
        """Re-read this entry's size + last_used at the moment of the
        decision.  Returns a fresh ``CacheEntry`` or ``None`` if the
        entry has disappeared.

        Critical for NFS multi-pod deployments: ``list_for_eviction``
        snapshots all mtimes during the walk, but other pods may
        ``mark_used`` files DURING the walk.  Eviction must call
        ``re_stat`` at the delete-decision point to defeat the stale
        attribute cache (see BF-424 N3).  Backends without an
        attribute cache (local SSD) can return the entry unchanged.
        """
        ...

    def delete_entry(self, entry: CacheEntry) -> bool:
        """Idempotent delete by entry — preferred over ``delete_key``
        because the entry already carries the resolved local_path,
        so we avoid re-splitting + re-resolving in callers.

        Returns True iff a file was actually removed.  Returns False
        (NOT raise) on already-gone (race with another evictor or
        stale NFS attr cache showing a present file that's actually
        deleted).
        """
        ...

    def delete_key(self, bucket: str, s3_key: str) -> bool:
        """Idempotent delete by (bucket, s3_key).  Returns True iff a
        file was actually removed.  Returns False on already-gone.

        Prefer ``delete_entry(entry)`` when iterating eviction
        candidates — it skips a redundant path resolution.
        """
        ...

    # Monitoring
    def stats(self) -> StorageStats:
        """Total bytes / free bytes / entry count.  Used by the
        disk-cap pre-flight in s3_predownload."""
        ...


# ── FilesystemBackend (POSIX / NFS / GlusterFS / CephFS / SMB) ──────────────


class FilesystemBackend:
    """Single implementation covering all POSIX-like file systems.

    The NFS-safe code paths (``os.open + fstat`` instead of
    ``os.path.exists + getsize``) work transparently on all of:
      - local SSD/NVMe
      - NFS (defeats actimeo)
      - GlusterFS (defeats client cache)
      - CephFS (no-op since CephFS has strong consistency)
      - SMB (defeats client cache)

    The slight overhead on local SSD (extra open+close per check) is
    negligible; the benefit on NFS is correctness.

    Multi-pod note: this backend is INSTANCE-LOCAL.  Multiple pods
    sharing the same NFS mount each have their own
    ``FilesystemBackend`` instance pointing at the same root.  The
    shared state is on disk; the per-pod state is in-process registries
    (``_thread_local.temp_dirs``, ``_global_temp_dirs``) which the
    BF-421..424 series correctly handles via per-thread cleanup +
    startup janitor.
    """

    name = "filesystem"

    # Patterns to skip in eviction enumeration (defensive; see contract).
    # Tmp suffixes require ``{8,}`` hex chars — write_atomic generates
    # exactly 10 (4-char pid + 6-char token), s3_predownload generates
    # at least 8.  The minimum-length anchor stops legitimate user files
    # like ``report.tab`` from being silently dropped from eviction.
    _SKIP_PATTERNS = (
        re.compile(r"\.t[0-9a-f]{8,}\.\d+$"),  # legacy tmp w/ attempt
        re.compile(r"\.t[0-9a-f]{8,}$"),       # FilesystemBackend tmp
        re.compile(r"^\.nfs[0-9a-f]+$"),       # NFS silly-rename
    )

    def __init__(self, cache_root: str):
        if not cache_root:
            raise ValueError("FilesystemBackend requires a non-empty cache_root")
        self._root = os.path.abspath(cache_root)
        os.makedirs(self._root, exist_ok=True)

    @property
    def root(self) -> str:
        return self._root

    def reserve_local_path(self, bucket: str, s3_key: str) -> str:
        """Path-traversal-safe resolution.

        Rejects keys where the resolved path would escape ``self._root``.
        Real S3 keys don't contain ``..`` segments (S3 stores them
        literally), so this only fires on tampered / malicious input.

        BF-425 audit fix — defensive ``rstrip(os.sep)`` on root_norm
        in case the cache_root config value had a trailing separator
        (``os.path.abspath`` usually strips it but not on every
        platform / corner case).
        """
        local_file = os.path.normpath(os.path.join(self._root, bucket, s3_key))
        root_norm = os.path.normpath(self._root).rstrip(os.sep)
        if not local_file.startswith(root_norm + os.sep) and local_file != root_norm:
            raise ValueError(
                f"FilesystemBackend: refusing to write s3 key outside cache root: "
                f"key={bucket}/{s3_key!r} resolves to {local_file!r}"
            )
        return local_file

    def size_if_complete(self, bucket: str, s3_key: str) -> Optional[int]:
        """NFS-safe presence + size check.

        Uses ``os.open + os.fstat`` instead of ``os.path.exists +
        getsize`` to force a fresh server round-trip and bypass any
        client-side attribute cache (NFS ``actimeo``, SMB metadata
        cache).  See BF-424 N1.

        Returns None on:
          - file not present (FileNotFoundError on os.open)
          - file present but empty (size == 0) — treated as incomplete
          - any other OSError (transient backend issue → safe to retry
            as miss)
        """
        path = self.reserve_local_path(bucket, s3_key)
        path = self._long_path(path)
        try:
            fd = os.open(path, os.O_RDONLY)
        except FileNotFoundError:
            return None
        except OSError:
            return None
        try:
            st = os.fstat(fd)
            if st.st_size > 0:
                return st.st_size
            return None
        finally:
            try:
                os.close(fd)
            except OSError:
                pass

    def write_atomic(self, bucket: str, s3_key: str, body_chunks) -> int:
        """Atomic-rename pattern: <final>.t<pid><rand>.<attempt> →
        os.replace(tmp, final).

        Concurrent writers each use a unique tmp suffix (different pid
        + secrets.token_hex), so they don't clobber each other's tmp
        files.  The ``os.replace`` is atomic per-server (server-atomic
        on NFS).
        """
        final = self.reserve_local_path(bucket, s3_key)
        final_long = self._long_path(final)
        os.makedirs(self._long_path(os.path.dirname(final)), exist_ok=True)

        tmp_suffix = f".t{os.getpid() & 0xFFFF:04x}{secrets.token_hex(3)}"
        tmp = final + tmp_suffix
        tmp_long = self._long_path(tmp)

        bytes_written = 0
        try:
            with open(tmp_long, "wb") as f:
                for chunk in body_chunks:
                    if chunk:
                        f.write(chunk)
                        bytes_written += len(chunk)
            try:
                os.replace(tmp_long, final_long)
            except PermissionError:
                # Windows-specific: os.replace can fail with WinError 5
                # if another writer concurrently replaced the destination
                # OR holds it open.  POSIX rename always wins (atomic),
                # but Windows rename can lose.  Iceberg files are immutable
                # so the OTHER writer's content is byte-identical to ours
                # — accept it as a successful publish + clean up our tmp.
                if os.path.exists(final_long) and os.path.getsize(final_long) > 0:
                    try:
                        os.remove(tmp_long)
                    except OSError:
                        pass
                else:
                    raise  # final isn't there; this is a real failure
        except Exception:
            # Best-effort cleanup of the partial tmp file.
            try:
                if os.path.exists(tmp_long):
                    os.remove(tmp_long)
            except OSError:
                pass
            raise
        return bytes_written

    def mark_used(self, bucket: str, s3_key: str) -> None:
        """Touch mtime for LRU.  No-throw — failure to update mtime
        means LRU may rank the file slightly worse but doesn't break
        correctness."""
        try:
            path = self.reserve_local_path(bucket, s3_key)
            os.utime(self._long_path(path), None)
        except (OSError, ValueError):
            pass

    def list_for_eviction(self) -> Iterator[CacheEntry]:
        """Walk the cache root yielding every cached entry.

        Skips:
          - in-flight tmp downloads (.t<pid><rand>.<attempt>)
          - NFS silly-rename (.nfs<hex>)
          - empty files (size 0; treated as incomplete)
          - files under any subdirectory matching the skip patterns
        """
        if not os.path.isdir(self._root):
            return
        for root, _dirs, files in os.walk(self._root):
            for name in files:
                if any(p.search(name) for p in self._SKIP_PATTERNS):
                    continue
                full = os.path.join(root, name)
                try:
                    st = os.stat(full)
                except OSError:
                    continue  # file disappeared mid-walk
                if st.st_size <= 0:
                    continue  # treat empty as incomplete (matches size_if_complete)
                # The "key" is the path relative to root.  Backend-internal.
                rel = os.path.relpath(full, self._root)
                # Try to split into bucket/key for symmetry with the
                # other methods.  rel always has at least one path
                # separator (we write under <root>/<bucket>/<key>).
                yield CacheEntry(
                    key=rel.replace(os.sep, "/"),
                    local_path=full,
                    size_bytes=st.st_size,
                    last_used=st.st_mtime,
                )

    def delete_key(self, bucket: str, s3_key: str) -> bool:
        """Idempotent delete.  Returns False (not raise) on
        already-gone (race with another evictor or stale NFS attr
        cache showing a file present that's actually deleted)."""
        try:
            path = self.reserve_local_path(bucket, s3_key)
            os.remove(self._long_path(path))
            return True
        except FileNotFoundError:
            return False
        except (OSError, ValueError):
            return False

    def delete_entry(self, entry: CacheEntry) -> bool:
        """Idempotent delete by entry — preferred over ``delete_key``
        when iterating eviction candidates because we already have the
        resolved local_path (skips re-splitting + re-resolving).
        """
        try:
            os.remove(self._long_path(entry.local_path))
            return True
        except FileNotFoundError:
            return False
        except OSError:
            return False

    def re_stat(self, entry: CacheEntry) -> Optional[CacheEntry]:
        """BF-424 — fresh stat at decision time.

        ``list_for_eviction`` snapshots mtime during the walk, but
        other pods may ``mark_used`` the same file DURING the walk.
        Eviction must call this at the delete-decision point so the
        per-pod NFS attribute cache (``actimeo=60``) doesn't hide a
        recent touch.

        Returns a fresh ``CacheEntry`` (size + last_used updated) or
        None if the entry has disappeared.

        Uses ``os.open + fstat`` for the same NFS-safe reasoning as
        ``size_if_complete`` — opens force a fresh GETATTR RPC.
        """
        path = self._long_path(entry.local_path)
        try:
            fd = os.open(path, os.O_RDONLY)
        except FileNotFoundError:
            return None
        except OSError:
            return None
        try:
            st = os.fstat(fd)
            if st.st_size <= 0:
                return None
            return CacheEntry(
                key=entry.key,
                local_path=entry.local_path,
                size_bytes=st.st_size,
                last_used=st.st_mtime,
            )
        finally:
            try:
                os.close(fd)
            except OSError:
                pass

    def stats(self) -> StorageStats:
        """Walk the cache root and sum sizes; query disk_usage for free."""
        total = 0
        count = 0
        try:
            for _root, _dirs, files in os.walk(self._root):
                for name in files:
                    full = os.path.join(_root, name)
                    try:
                        st = os.stat(full)
                        if st.st_size > 0:
                            total += st.st_size
                            count += 1
                    except OSError:
                        continue
        except OSError:
            pass
        try:
            free = shutil.disk_usage(self._root).free
        except OSError:
            free = 0
        return StorageStats(total_bytes=total, free_bytes=free, entry_count=count)

    # ── Internal helpers ──────────────────────────────────────────────────

    @staticmethod
    def _long_path(p: str) -> str:
        """Windows MAX_PATH workaround.  No-op on Linux/Mac; on Windows
        prepends \\\\?\\ when the path approaches the 260-char limit so
        downstream open()/replace() don't fail.  Iceberg paths with
        deep partition prefixes routinely hit this on cache_dir trees."""
        if os.name == "nt" and len(p) >= 240 and not p.startswith("\\\\?\\"):
            return "\\\\?\\" + os.path.abspath(p)
        return p


# ── NullBackend (explicit no-cache mode — SHIPPED) ──────────────────────────


class NullBackend:
    """Explicit no-cache mode for tests + future direct construction.

    Aligns with the user's stated end-state: "even I don't like download
    at all... don't want duplicate of data".  When the VPC endpoint is
    reachable, the whole pre-download path is skipped via existing
    config gates and ``get_cache_backend()`` returns ``None``.

    NOTE: The current factory returns ``None`` (not ``NullBackend()``)
    when ``s3_local_cache.enabled = false`` because callers in Phase 2
    will branch on ``if backend is None`` to skip writes.  Future
    refactors may flip the factory to return ``NullBackend()`` for
    branch-free callers — at which point this class becomes the
    factory's no-cache return value.  For now it's directly
    constructible (in tests or when an operator wants to wire it up
    explicitly) and behaves correctly for all read/eviction paths.

    All read ops return None / 0 / empty.  ``write_atomic`` raises
    NotImplementedError (a caller invoking it in no-cache mode is a
    bug; raising surfaces it loudly).  ``delete_*`` returns False.
    """

    name = "null"

    @property
    def root(self) -> Optional[str]:
        return None

    def reserve_local_path(self, bucket: str, s3_key: str) -> str:
        raise NotImplementedError(
            "NullBackend has no storage — caller should not be requesting paths"
        )

    def size_if_complete(self, bucket: str, s3_key: str) -> Optional[int]:
        return None

    def write_atomic(self, bucket: str, s3_key: str, body_chunks) -> int:
        raise NotImplementedError(
            "NullBackend doesn't store anything — invoking write_atomic is a bug "
            "(check s3_local_cache.enabled before calling)"
        )

    def mark_used(self, bucket: str, s3_key: str) -> None:
        return None

    def list_for_eviction(self) -> Iterator[CacheEntry]:
        return iter(())

    def re_stat(self, entry: CacheEntry) -> Optional[CacheEntry]:
        return None

    def delete_entry(self, entry: CacheEntry) -> bool:
        return False

    def delete_key(self, bucket: str, s3_key: str) -> bool:
        return False

    def stats(self) -> StorageStats:
        return StorageStats(total_bytes=0, free_bytes=0, entry_count=0)


# ── S3Backend (FUTURE — explicit NotImplementedError until built) ───────────


class S3Backend:
    """Cache LIVES on S3.  NOT YET IMPLEMENTED — calling __init__ raises.

    A real implementation would store cached parquet bytes in an S3
    bucket (e.g., ``s3://my-cache-bucket/cache/<bucket>/<key>``) and
    materialize to local tmp before DuckDB reads.  Useful for
    multi-region deployments where the NFS mount can't span regions.

    Operations would map to:
      - size_if_complete : HeadObject; ContentLength field
      - write_atomic     : PutObject (server-atomic; no tmp dance)
      - mark_used        : HeadObject (touches LastAccessed in S3
                           Inventory if enabled); often no-op
      - list_for_eviction: ListObjectsV2 with pagination + LastModified
      - delete_entry     : DeleteObject by entry.key
      - re_stat          : HeadObject (fresh)
      - reserve_local_path: returns a tmp path under download_temp_dir;
                            size_if_complete must materialize bytes
                            there before DuckDB reads

    Trade-offs vs FilesystemBackend:
      + Geo-replicated, durable, no shared NFS dependency
      + Automatic eviction via S3 lifecycle policies
      - Materialization cost on every cache hit (defeats the point
        unless materialization itself is cached locally)
      - LIST is expensive for large caches
      - Eventually consistent (mitigated by HeadObject-after-write)

    Marked as a top-level class (not underscore-prefixed) so it's
    discoverable via grep / IDE class-list when someone needs to
    implement it.  Raises NotImplementedError early so accidental
    instantiation fails loudly.
    """

    name = "s3"

    def __init__(self, *args, **kwargs):
        raise NotImplementedError(
            "S3Backend is not yet implemented.  See the class docstring "
            "for the design.  When implementing: add to get_cache_backend() "
            "factory + the s3_local_cache.backend config knob."
        )


# ── Factory ─────────────────────────────────────────────────────────────────


def get_cache_backend(*, cache_root: Optional[str] = None) -> Optional[CacheBackend]:
    """Return the configured cache backend, or None when caching is off.

    Reads ``s3_local_cache`` config:
      - ``enabled = false`` → returns None (no caching, no duplicate
        data — matches the "VPC accessible, no downloads" end-state)
      - ``enabled = true``  → returns FilesystemBackend(cache_dir)

    ``cache_root`` override is for tests / explicit construction.

    A future ``s3_local_cache.backend = "s3"`` config knob would
    select between FilesystemBackend and S3Backend without any caller
    code change — that's the whole point of the abstraction.
    """
    if cache_root is not None:
        return FilesystemBackend(cache_root)

    try:
        from core.config import s3_local_cache as _sclc
        if not bool(_sclc.enabled):
            return None
        root = _sclc.cache_dir
        if not root:
            logger.warning(
                "[cache-backend] s3_local_cache.enabled=true but cache_dir is empty — "
                "treating as no-cache mode"
            )
            return None
        return FilesystemBackend(root)
    except Exception as exc:
        logger.warning("[cache-backend] config unavailable, no cache: %s", exc)
        return None
