"""Phase 2b — B1 hash-repartition LOCAL-SPOOL exchange executor.

Design: docs/parallel_agg_next_tier_design_2026_07_26.md §3.2-3.5, §4.

Two stages over a per-execution local-disk spool (workers share ONE pod —
the exchange is NEVER S3, NEVER the artifact store):

  Stage 1 (per worker, one SQL):
      COPY (SELECT <referenced cols>, hash(K1,K2,…) % n_buckets AS
            __qs_bucket FROM chunk_view [WHERE <original predicate>])
      TO '<spool>/w{i}.tmp' (FORMAT PARQUET, PARTITION_BY (__qs_bucket),
                             COMPRESSION ZSTD)
      then write w{i}.tmp/_MANIFEST.json and ATOMICALLY rename
      w{i}.tmp → w{i} — a crashed worker's partial spool is invisible.
      Retry once (idempotent: rerun overwrites the .tmp); second failure
      ⇒ abort the whole exchange ⇒ single-worker fallback.

  Barrier (coordinator):
      all manifests present (read from DISK — the committed truth) →
      ROW-CONSERVATION HARD GATE (§4.2) → LPT bucket→worker assignment →
      BUCKET-PARTITION ASSERTION (§4.3) → stage 2.

  Stage 2 (per worker, via the existing execute_multi_worker machinery):
      CREATE VIEW <table> AS SELECT * EXCLUDE (__qs_bucket)
      FROM read_parquet([<explicit file list for my buckets>],
                        hive_partitioning=true)
      then the ORIGINAL query SQL verbatim (the worker owns ALL rows for
      its keys ⇒ exact).  Merge = union.

CORRECTNESS GATES (F1 discipline — wrong data structurally impossible or
DETECTED, never merely unlikely):
  * Row conservation:  Σ input rows == Σ stage-1 rows_written (COPY count
    vs an independent COUNT(*) scan, per worker AND in total) == Σ stage-2
    rows_read (independent parquet-footer recount of every spool file
    against its manifest).  ANY mismatch ⇒ ConservationError ⇒ abort ⇒
    single-worker; the failure maps to a hard-negative completeness receipt
    (``conservation_receipt``) so it can NEVER read COMPLETE (§4.5).
  * Bucket-partition assertion: every non-empty bucket assigned to exactly
    one stage-2 worker, union == all buckets, pairwise disjoint — asserted
    BEFORE stage 2 dispatch.  A lost or double-owned bucket would silently
    drop / duplicate KEYS — the worst possible failure — so it is detected
    arithmetically, not hoped away.
  * Atomic manifest commit (dir rename) + lost/corrupt spool file ⇒ abort
    (NEVER "skip a bucket").
  * Disk guard: pre-flight size estimate vs ``exchange_max_spool_gb`` and
    free-disk×0.5 refuses BEFORE anything is spooled; a running byte cap
    (accounting after each COPY + a 1s polling watcher that interrupts
    in-flight connections) aborts mid-stage-1.
  * Cleanup in ``finally`` (success / error / cancel) + a 24h orphan
    sweeper for ``qs_exchange/*`` (pod-crash hygiene).

RLS: the spool is PER-EXECUTION (``<execution_id>-<random8>``, mode 0700),
never reused, never cached, never content-addressed — it only re-arranges
rows within one execution's already-RLS-scoped file list.  Spool ≠ cache.

Flags (all read by the dispatcher via ``mw_cfg.get`` — no config.py edit):
``multi_worker.exchange_enabled`` (shared with B0, default False),
``exchange_bucket_factor`` (2), ``exchange_max_spool_gb`` (20),
``exchange_min_files`` (200).
"""
from __future__ import annotations

import json
import logging
import os
import re
import shutil
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

_MANIFEST_NAME = "_MANIFEST.json"
_BUCKET_COL = "__qs_bucket"
_SAFE_ID_RE = re.compile(r"[^A-Za-z0-9_-]")

# ── Test seams (module-level so failure-injection tests can monkeypatch).
# _TEST_AFTER_STAGE1_HOOK(spool_root) runs after ALL stage-1 commits and
# BEFORE the barrier reads the manifests — the window where a lost spool
# file / truncated manifest / cancellation must be caught by the gates.
_TEST_AFTER_STAGE1_HOOK: Optional[Callable[[str], None]] = None


class ExchangeAbort(Exception):
    """Any condition that must abort the exchange ⇒ single-worker fallback."""


class ConservationError(ExchangeAbort):
    """The row-conservation hard gate fired (§4.2) — rows were lost,
    duplicated, or cannot be proven conserved.  NEVER certify COMPLETE."""


class DiskCapError(ExchangeAbort):
    """The spool byte cap was breached — abort before filling the pod disk."""


class ExchangeCancelled(ExchangeAbort):
    """cancel_event was set — abort quietly, clean the spool."""


@dataclass
class ExchangeB1Outcome:
    table: Any = None                       # pyarrow.Table
    worker_count: int = 0
    total_elapsed_s: float = 0.0
    stage1_elapsed_s: float = 0.0
    stage2_elapsed_s: float = 0.0
    n_buckets: int = 0
    spool_dir: str = ""
    spool_bytes: int = 0
    conservation: Dict[str, Any] = field(default_factory=dict)
    per_worker_summary: List[Dict[str, Any]] = field(default_factory=list)


# ─────────────────────────────────────────────────────────────────────────────
# Spool root + orphan sweeper
# ─────────────────────────────────────────────────────────────────────────────
def _spool_base() -> str:
    """``<spill>/qs_exchange`` — <spill> from the SAME writable-local-temp
    chain that fixed the DuckDB temp_directory bug (0bffc254).  Never S3."""
    from core.multi_worker_executor import _resolve_temp_dir_for_spill
    spill = _resolve_temp_dir_for_spill()
    if not spill:
        import tempfile
        spill = tempfile.gettempdir()
    return os.path.join(spill, "qs_exchange")


def sweep_orphan_spools(max_age_hours: float = 24.0,
                        base: Optional[str] = None) -> int:
    """Delete ``qs_exchange/*`` trees older than ``max_age_hours`` (pod-crash
    hygiene).  Best-effort — never raises, never touches fresh trees."""
    removed = 0
    try:
        root = base or _spool_base()
        if not os.path.isdir(root):
            return 0
        cutoff = time.time() - max_age_hours * 3600.0
        for name in os.listdir(root):
            p = os.path.join(root, name)
            try:
                if os.path.isdir(p) and os.path.getmtime(p) < cutoff:
                    shutil.rmtree(p, ignore_errors=True)
                    if not os.path.exists(p):
                        removed += 1
                        logger.info("[exchange-b1] orphan spool swept: %s", p)
            except OSError:
                continue
    except Exception as exc:
        logger.debug("[exchange-b1] orphan sweep failed (best-effort): %s",
                     exc)
    return removed


# ─────────────────────────────────────────────────────────────────────────────
# Disk guard
# ─────────────────────────────────────────────────────────────────────────────
def _estimate_spool_bytes(files: List[Any], col_fraction: float = 1.0) -> int:
    """Pre-flight spool estimate: Σ chunk file sizes × projected-column
    fraction (conservative 1.0 when the fraction is unknown).  Files with
    unknown size contribute 0 — the RUNNING byte cap is the hard guarantee;
    this estimate exists to refuse obviously-oversized exchanges early."""
    total = 0
    for f in files or []:
        try:
            if isinstance(f, dict):
                total += int(f.get("size") or f.get("bytes") or 0)
            else:
                p = str(f)
                if "://" not in p and os.path.isfile(p):
                    total += os.path.getsize(p)
        except OSError:
            continue
    frac = col_fraction if 0.0 < col_fraction <= 1.0 else 1.0
    return int(total * frac)


def _column_fraction(files: List[Any], referenced: List[str]) -> float:
    """referenced-cols / total-cols from the first local file's footer.
    Unknown ⇒ 1.0 (conservative)."""
    try:
        for f in files or []:
            p = str(f) if not isinstance(f, dict) else str(
                f.get("path") or f.get("url") or "")
            if p and "://" not in p and os.path.isfile(p):
                import pyarrow.parquet as pq
                ncols = len(pq.ParquetFile(p).schema_arrow.names)
                if ncols > 0 and referenced:
                    return min(1.0, len(referenced) / float(ncols))
                break
    except Exception:
        pass
    return 1.0


# ─────────────────────────────────────────────────────────────────────────────
# LPT bucket assignment + partition assertion (§4.3)
# ─────────────────────────────────────────────────────────────────────────────
def _assign_buckets_lpt(bucket_rows: Dict[int, int],
                        n_workers: int) -> List[List[int]]:
    """Greedy LPT: heaviest bucket → least-loaded worker (same mechanics as
    partition_aligned_join.py:392, buckets instead of partition tuples)."""
    n = max(1, int(n_workers))
    assignment: List[List[int]] = [[] for _ in range(n)]
    loads = [0] * n
    for b in sorted(bucket_rows, key=lambda k: (-bucket_rows[k], k)):
        tgt = min(range(n), key=lambda i: (loads[i], len(assignment[i]), i))
        assignment[tgt].append(b)
        loads[tgt] += int(bucket_rows[b])
    return assignment


def _assert_bucket_assignment_partition(assignment: List[List[int]],
                                        all_buckets: set) -> None:
    """PROVE the assignment is a partition of the bucket set: every bucket
    owned by exactly one stage-2 worker, union == all, pairwise disjoint.
    Raises ValueError on ANY violation — a lost bucket is silently missing
    keys; a double-owned bucket is silently duplicated keys."""
    seen: Dict[int, int] = {}
    for w_idx, buckets in enumerate(assignment or []):
        for b in buckets:
            if b in seen:
                raise ValueError(
                    f"bucket {b} assigned to BOTH worker {seen[b]} and "
                    f"worker {w_idx} — overlapping ownership would "
                    "double-count its keys")
            seen[b] = w_idx
    missing = set(all_buckets) - set(seen)
    extra = set(seen) - set(all_buckets)
    if missing:
        raise ValueError(
            f"bucket(s) {sorted(missing)} assigned to NO worker — their "
            "keys would silently vanish from the result")
    if extra:
        raise ValueError(
            f"unknown bucket(s) {sorted(extra)} in the assignment — "
            "provenance unprovable")


# ─────────────────────────────────────────────────────────────────────────────
# Row-conservation hard gate (§4.2)
# ─────────────────────────────────────────────────────────────────────────────
def _verify_row_conservation(manifests: List[Dict[str, Any]],
                             spool_root: str) -> Dict[str, Any]:
    """Recount, don't trust (feed-certificate posture): every spool file's
    parquet-footer row count is compared against its manifest entry; sums
    must reconcile input == stage-1 written == stage-2 readable.  Raises
    ``ConservationError`` on ANY mismatch, missing file, or corrupt footer
    — the caller aborts, never skips a bucket."""
    import pyarrow.parquet as pq

    stage1_total = 0
    input_total = 0
    stage2_total = 0
    for m in manifests:
        w = int(m.get("worker", -1))
        rows_written = int(m.get("rows_written", -1))
        input_rows = int(m.get("input_rows", -1))
        if w < 0 or rows_written < 0 or input_rows < 0:
            raise ConservationError(
                f"manifest for worker {w} is missing row accounting")
        if rows_written != input_rows:
            raise ConservationError(
                f"worker {w}: COPY wrote {rows_written} rows but the chunk "
                f"scan counted {input_rows} — stage 1 is a pure projection, "
                "these MUST be equal")
        stage1_total += rows_written
        input_total += input_rows

        wdir = os.path.join(spool_root, f"w{w}")
        per_bucket_recount: Dict[int, int] = {}
        declared_files = m.get("files") or []
        if rows_written > 0 and not declared_files:
            raise ConservationError(
                f"worker {w}: {rows_written} rows written but manifest "
                "lists no files")
        for fent in declared_files:
            rel = str(fent.get("path") or "")
            bucket = int(fent.get("bucket", -1))
            declared_rows = int(fent.get("rows", -1))
            fpath = os.path.join(wdir, rel)
            if not rel or bucket < 0 or declared_rows < 0:
                raise ConservationError(
                    f"worker {w}: malformed manifest file entry {fent!r}")
            if not os.path.isfile(fpath):
                raise ConservationError(
                    f"worker {w}: spool file MISSING between stages: "
                    f"{fpath} (bucket {bucket}, {declared_rows} rows) — a "
                    "lost bucket file is silently missing keys")
            try:
                actual_rows = int(pq.ParquetFile(fpath).metadata.num_rows)
            except Exception as read_exc:
                raise ConservationError(
                    f"worker {w}: spool file unreadable/corrupt: {fpath} "
                    f"({read_exc})") from read_exc
            if actual_rows != declared_rows:
                raise ConservationError(
                    f"worker {w}: spool file {fpath} has {actual_rows} rows "
                    f"but manifest declared {declared_rows}")
            per_bucket_recount[bucket] = (
                per_bucket_recount.get(bucket, 0) + actual_rows)
            stage2_total += actual_rows

        declared_buckets = {
            int(k): int(v) for k, v in (m.get("per_bucket_rows") or {}).items()
            if int(v) > 0
        }
        if per_bucket_recount != declared_buckets:
            raise ConservationError(
                f"worker {w}: per-bucket recount {per_bucket_recount} != "
                f"manifest per_bucket_rows {declared_buckets}")
        if sum(per_bucket_recount.values()) != rows_written:
            raise ConservationError(
                f"worker {w}: bucket rows sum "
                f"{sum(per_bucket_recount.values())} != rows_written "
                f"{rows_written}")

    if stage2_total != stage1_total:
        raise ConservationError(
            f"stage-2 spool recount {stage2_total} != stage-1 manifests "
            f"{stage1_total} — rows were lost or duplicated in the exchange")

    return {
        "verified": True,
        "input_rows": input_total,
        "stage1_rows_written": stage1_total,
        "stage2_rows_read": stage2_total,
    }


def conservation_receipt(cons: Dict[str, Any]) -> Dict[str, Any]:
    """Map a conservation outcome to a completeness receipt (§4.5).

    FAILURE ⇒ verdict INCOMPLETE — a HARD NEGATIVE through
    ``build_certificate`` (any hard-negative ⇒ certificate INCOMPLETE), so a
    conservation failure can NEVER read COMPLETE.
    SUCCESS ⇒ verdict "unverified" — internal exchange integrity says
    nothing about SOURCE completeness; it must never manufacture COMPLETE.
    """
    cons = cons if isinstance(cons, dict) else {}
    s1 = cons.get("stage1_rows_written")
    s2 = cons.get("stage2_rows_read")
    if cons.get("verified") is True:
        return {
            "verdict": "unverified",
            "expected_rows": s1,
            "rows_read": s2,
            "verdict_reason": (
                "exchange row-conservation verified (internal spool "
                "integrity only — source completeness is attested by the "
                "reader-chokepoint signals, not by the exchange)"),
        }
    detail = cons.get("detail") or "row conservation could not be proven"
    return {
        "verdict": "INCOMPLETE",
        "expected_rows": s1,
        "rows_read": s2,
        "verdict_reason": (
            f"exchange row-conservation gate FAILED: {detail} — result "
            "aborted, single-worker rerun required; never COMPLETE"),
    }


# ─────────────────────────────────────────────────────────────────────────────
# Stage-1 primitives
# ─────────────────────────────────────────────────────────────────────────────
def _stage1_copy(con, copy_sql: str, worker_index: int) -> int:
    """Execute the stage-1 COPY; returns DuckDB's written-row count.
    Module-level seam so failure-injection tests can kill a worker
    mid-COPY."""
    row = con.execute(copy_sql).fetchone()
    return int(row[0]) if row else 0


def _quote_ident(name: str) -> str:
    # Planner already proved plain [A-Za-z_][A-Za-z0-9_]* — quote anyway.
    return '"' + name.replace('"', '""') + '"'


def _posix(p: str) -> str:
    return str(p).replace("\\", "/")


def _scan_committed_worker_dir(wdir: str) -> List[Dict[str, Any]]:
    """Enumerate ``__qs_bucket=N/*.parquet`` under a worker spool dir with
    per-file parquet-footer row counts + byte sizes."""
    import pyarrow.parquet as pq
    out: List[Dict[str, Any]] = []
    for name in sorted(os.listdir(wdir)):
        bdir = os.path.join(wdir, name)
        if not os.path.isdir(bdir) or not name.startswith(_BUCKET_COL + "="):
            continue
        bucket = int(name.split("=", 1)[1])
        for fn in sorted(os.listdir(bdir)):
            if not fn.endswith(".parquet"):
                continue
            fpath = os.path.join(bdir, fn)
            out.append({
                "path": f"{name}/{fn}",
                "bucket": bucket,
                "rows": int(pq.ParquetFile(fpath).metadata.num_rows),
                "bytes": int(os.path.getsize(fpath)),
            })
    return out


# ─────────────────────────────────────────────────────────────────────────────
# The exchange
# ─────────────────────────────────────────────────────────────────────────────
def run_exchange_b1(
    plan,                                   # ExchangePlan (tier='b1')
    *,
    setup_sql_builder: Callable[[Any], str],
    original_sql: str,
    mw_cfg: Dict[str, Any],
    duckdb_settings: Optional[Dict[str, str]] = None,
    cancel_event: Optional[threading.Event] = None,
    progress_cb: Optional[Callable[[int, int, str], None]] = None,
    execution_id: str = "",
    cancellable: bool = True,
) -> Optional[ExchangeB1Outcome]:
    """Run the two-stage hash-spool exchange.  Returns None on ANY refusal /
    abort / failure (⇒ caller falls back to single-worker, always correct).
    NEVER returns a table unless every correctness gate passed."""
    t0 = time.monotonic()

    # Opportunistic pod-crash hygiene (never creates dirs, never raises).
    sweep_orphan_spools()

    if cancel_event is not None and cancel_event.is_set():
        logger.info("[exchange-b1] cancelled before start — nothing spooled")
        return None

    # ── Pre-flight disk guard (§3.4) — refuse BEFORE creating the spool ──
    all_files = [f for sl in plan.slices for f in (sl.get("files") or [])]
    cap_gb = float(mw_cfg.get("exchange_max_spool_gb", 20) or 20)
    cap_bytes = int(cap_gb * 1e9)
    frac = _column_fraction(all_files, plan.referenced_columns)
    est = _estimate_spool_bytes(all_files, frac)
    if est > cap_bytes:
        logger.warning(
            "[exchange-b1] REFUSE pre-flight disk cap: estimated spool "
            "%.2f GB (col_fraction=%.2f) > exchange_max_spool_gb=%.2f — "
            "single-worker stands", est / 1e9, frac, cap_gb)
        return None
    base = _spool_base()
    try:
        free = shutil.disk_usage(os.path.dirname(base) or base).free
        if est > free * 0.5:
            logger.warning(
                "[exchange-b1] REFUSE pre-flight disk cap: estimated spool "
                "%.2f GB > 50%% of free disk %.2f GB — single-worker stands",
                est / 1e9, free / 1e9)
            return None
    except OSError as du_exc:
        logger.warning("[exchange-b1] REFUSE: cannot stat free disk (%s)",
                       du_exc)
        return None

    # ── Per-execution spool root: <base>/<execid>-<rand8>, 0700, NEVER
    #    reused / cached / content-addressed (RLS §5.4: spool ≠ cache). ──
    safe_id = _SAFE_ID_RE.sub("_", str(execution_id or "exec"))[:48]
    spool_root = os.path.join(base, f"{safe_id}-{uuid.uuid4().hex[:8]}")
    os.makedirs(spool_root, mode=0o700, exist_ok=False)

    n_workers = int(plan.n_workers)
    n_buckets = int(plan.n_buckets)
    tbl = _quote_ident(plan.table_name)
    proj = ", ".join(_quote_ident(c) for c in plan.referenced_columns)
    hash_expr = ("hash(" + ", ".join(_quote_ident(k)
                                     for k in plan.key_columns)
                 + f") % {n_buckets}")
    where = f" WHERE {plan.where_sql}" if plan.where_sql else ""
    stage1_select = (f"SELECT {proj}, {hash_expr} AS {_BUCKET_COL} "
                     f"FROM {tbl}{where}")
    count_sql = f"SELECT COUNT(*) FROM {tbl}{where}"

    abort_event = threading.Event()      # disk-cap / sibling-failure abort
    bytes_lock = threading.Lock()
    spool_bytes_total = [0]
    live_cons: List[Any] = []            # for the byte-cap watcher interrupt
    cons_lock = threading.Lock()

    def _emit(done: int, total: int, msg: str) -> None:
        if progress_cb is not None:
            try:
                progress_cb(done, total, msg)
            except Exception:
                pass

    def _cancelled() -> bool:
        return ((cancel_event is not None and cancel_event.is_set())
                or abort_event.is_set())

    # ── Running byte-cap watcher: polls the spool tree; on breach sets the
    #    abort event AND interrupts in-flight COPYs (§3.4 hard cap). ──────
    watcher_stop = threading.Event()

    def _du(path: str) -> int:
        total = 0
        for dirpath, _dirs, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(dirpath, f))
                except OSError:
                    continue
        return total

    def _cap_watcher():
        while not watcher_stop.wait(1.0):
            try:
                if _du(spool_root) > cap_bytes:
                    logger.warning(
                        "[exchange-b1] running disk CAP breached mid-stage-1 "
                        "(> %.2f GB) — aborting exchange", cap_gb)
                    abort_event.set()
                    with cons_lock:
                        for c in live_cons:
                            try:
                                c.interrupt()
                            except Exception:
                                pass
                    return
            except Exception:
                continue

    def _run_stage1_worker(w_idx: int, chunk_files: List[Any]
                           ) -> Dict[str, Any]:
        """One stage-1 worker: chunk view → COUNT → COPY → footer recount →
        manifest → atomic commit.  Retries ONCE on transient failure
        (idempotent — the rerun overwrites w{i}.tmp); disk-cap / cancel
        never retry."""
        import duckdb

        class _Chunk:                        # duck-typed for the builder
            files = chunk_files
            chunk_index = w_idx
            total_size_bytes = 0

        tmp_dir = os.path.join(spool_root, f"w{w_idx}.tmp")
        final_dir = os.path.join(spool_root, f"w{w_idx}")
        last_exc: Optional[Exception] = None
        for attempt in (1, 2):
            if _cancelled():
                raise ExchangeCancelled(f"worker {w_idx} cancelled")
            con = None
            try:
                shutil.rmtree(tmp_dir, ignore_errors=True)
                shutil.rmtree(final_dir, ignore_errors=True)
                con = duckdb.connect(":memory:")
                with cons_lock:
                    live_cons.append(con)
                # BF-558e: _s1_settings, not duckdb_settings — it carries the
                # stage-1 per-worker memory_limit.  Resolved from the
                # enclosing scope at CALL time, and always assigned before
                # any worker is submitted.
                for k, v in (_s1_settings or {}).items():
                    try:
                        sv = str(v).replace("'", "''")
                        con.execute(f"SET {k}='{sv}';")
                    except Exception:
                        pass
                con.execute(setup_sql_builder(_Chunk()))
                input_rows = int(con.execute(count_sql).fetchone()[0])
                copy_sql = (
                    f"COPY ({stage1_select}) TO '{_posix(tmp_dir)}' "
                    f"(FORMAT PARQUET, PARTITION_BY ({_BUCKET_COL}), "
                    "COMPRESSION ZSTD)")
                rows_written = _stage1_copy(con, copy_sql, w_idx)
                # Per-worker conservation: COPY is a pure projection of the
                # same scan — an independent COUNT(*) must agree.
                if rows_written != input_rows:
                    raise ConservationError(
                        f"worker {w_idx}: COPY wrote {rows_written} rows "
                        f"but chunk scan counted {input_rows}")
                files_meta = _scan_committed_worker_dir(tmp_dir)
                per_bucket: Dict[str, int] = {}
                w_bytes = 0
                for fent in files_meta:
                    b = str(fent["bucket"])
                    per_bucket[b] = per_bucket.get(b, 0) + int(fent["rows"])
                    w_bytes += int(fent["bytes"])
                if sum(per_bucket.values()) != rows_written:
                    raise ConservationError(
                        f"worker {w_idx}: spool footer rows "
                        f"{sum(per_bucket.values())} != COPY count "
                        f"{rows_written}")
                # Running byte cap (accounting arm — the watcher is the
                # in-flight arm).  Breach ⇒ hard abort, no retry.
                with bytes_lock:
                    spool_bytes_total[0] += w_bytes
                    if spool_bytes_total[0] > cap_bytes:
                        abort_event.set()
                        raise DiskCapError(
                            f"spool byte cap breached: "
                            f"{spool_bytes_total[0]} > {cap_bytes} bytes "
                            f"(exchange_max_spool_gb={cap_gb})")
                manifest = {
                    "version": 1,
                    "worker": w_idx,
                    "execution_id": str(execution_id or ""),
                    "input_rows": input_rows,
                    "rows_written": rows_written,
                    "per_bucket_rows": per_bucket,
                    "files": files_meta,
                    "bytes": w_bytes,
                }
                mpath = os.path.join(tmp_dir, _MANIFEST_NAME)
                with open(mpath, "w", encoding="utf-8") as fh:
                    json.dump(manifest, fh)
                    fh.flush()
                    os.fsync(fh.fileno())
                # ATOMIC COMMIT: a crashed worker's partial spool (still
                # named .tmp) is invisible to the barrier.
                os.rename(tmp_dir, final_dir)
                return manifest
            except (DiskCapError, ExchangeCancelled):
                raise
            except Exception as exc:
                last_exc = exc
                if _cancelled() or attempt == 2:
                    raise
                logger.warning(
                    "[exchange-b1] stage-1 worker %d attempt %d failed "
                    "(%s) — retrying once (idempotent rerun)",
                    w_idx, attempt, exc)
            finally:
                if con is not None:
                    with cons_lock:
                        try:
                            live_cons.remove(con)
                        except ValueError:
                            pass
                    try:
                        con.close()
                    except Exception:
                        pass
        raise ExchangeAbort(
            f"worker {w_idx} failed after retry: {last_exc}")

    try:
        # ═════ STAGE 1 — shuffle write ══════════════════════════════════
        from concurrent.futures import ThreadPoolExecutor, as_completed
        t_s1 = time.monotonic()
        _emit(0, n_workers, "exchange-B1 stage 1: hash-spool write")
        watcher = threading.Thread(target=_cap_watcher,
                                   name="b1-cap-watcher", daemon=True)
        watcher.start()
        manifests_mem: List[Dict[str, Any]] = []
        # BF-558b/e: stage-1 workers open n_workers in-process DuckDB
        # connections DIRECTLY, so unlike stage 2 they never pass through
        # execute_multi_worker and nothing supplies a memory_limit.  Each
        # connection would then auto-detect ~75% of the pod, and n_workers
        # of them promise n x 75% — the same non-composition this program
        # fixed everywhere else.  Divide by (stage-1 workers x concurrent
        # queries), same as the multi-worker dispatch.
        #
        # Caller-supplied settings always win; fail-open leaves the PRAGMA
        # unset, i.e. exactly today's behaviour.
        # Bound to its OWN name, never by rebinding duckdb_settings: the
        # stage-2 call below reuses that parameter, and stage 2 runs a
        # DIFFERENT worker count (n_stage2), so leaking stage-1's divisor
        # into it would silently suppress stage 2's own calculation.
        _s1_settings = dict(duckdb_settings or {})
        if "memory_limit" not in _s1_settings:
            try:
                from core.multi_worker_executor import (
                    _compute_per_worker_memory_mb,
                )
                from core.worker_pool import live_query_concurrency
                _mb = _compute_per_worker_memory_mb(
                    n_workers * max(1, live_query_concurrency()))
                if _mb:
                    _s1_settings["memory_limit"] = f"{_mb}MB"
                    # A memory_limit WITHOUT a spill directory converts
                    # "uses more RAM" into "query FAILS": DuckDB cannot go
                    # out-of-core with nowhere to write, so it raises
                    # OutOfMemoryException instead of spilling.
                    # execute_multi_worker always sets both — match it.
                    if "temp_directory" not in _s1_settings:
                        from core.multi_worker_executor import (
                            _resolve_temp_dir_for_spill,
                        )
                        _spill_dir = _resolve_temp_dir_for_spill()
                        if _spill_dir:
                            _s1_settings["temp_directory"] = _spill_dir
                        else:
                            # No writable spill dir → do NOT constrain
                            # memory either, or we trade spilling for
                            # hard failures.
                            _s1_settings.pop("memory_limit", None)
                    logger.info(
                        "[exchange-b1] stage-1 per-worker memory_limit=%s "
                        "spill=%s (%d workers)",
                        _s1_settings.get("memory_limit", "<unset>"),
                        _s1_settings.get("temp_directory", "<unset>"),
                        n_workers,
                    )
            except Exception as _mem_exc:                    # pragma: no cover
                logger.debug(
                    "[exchange-b1] stage-1 memory divisor skipped "
                    "(fail-open): %s", _mem_exc,
                )
        # 2026-08-02 (defect 2): same divisor for THREADS.  Stage-1 opens
        # n_workers in-process connections directly; without a threads
        # value each defaults to the HOST core count, so the CPU quota is
        # over-promised exactly the way memory was pre-BF-558b.  Caller-
        # supplied settings win; fail-open leaves threads unset (today's
        # behaviour).
        if "threads" not in _s1_settings:
            try:
                from core.duckdb_resource_limits import (
                    resolve_thread_count_for_duckdb,
                )
                from core.worker_pool import live_query_concurrency
                _thr_div = n_workers * max(1, live_query_concurrency())
                if _thr_div > 1:
                    _t = resolve_thread_count_for_duckdb(concurrency=_thr_div)
                    if _t >= 1:
                        _s1_settings["threads"] = str(int(_t))
                        logger.info(
                            "[exchange-b1] stage-1 per-worker threads=%d "
                            "(divisor=%d)", _t, _thr_div,
                        )
            except Exception as _thr_exc:                    # pragma: no cover
                logger.debug(
                    "[exchange-b1] stage-1 thread divisor skipped "
                    "(fail-open): %s", _thr_exc,
                )
        pool = ThreadPoolExecutor(max_workers=n_workers,
                                  thread_name_prefix="b1s1")
        try:
            futs = {
                pool.submit(_run_stage1_worker, i,
                            list(plan.slices[i].get("files") or [])): i
                for i in range(n_workers)
            }
            done = 0
            first_exc: Optional[Exception] = None
            for fut in as_completed(futs):
                try:
                    manifests_mem.append(fut.result())
                except Exception as exc:
                    if first_exc is None:
                        first_exc = exc
                    abort_event.set()
                done += 1
                _emit(done, n_workers, "exchange-B1 stage 1")
            if first_exc is not None:
                raise first_exc
        finally:
            watcher_stop.set()
            try:
                pool.shutdown(wait=False, cancel_futures=True)
            except TypeError:
                pool.shutdown(wait=False)
        stage1_elapsed = time.monotonic() - t_s1

        # Test seam: lost-file / truncated-manifest / cancel injections
        # land HERE — between commit and the barrier's disk reads.
        if _TEST_AFTER_STAGE1_HOOK is not None:
            _TEST_AFTER_STAGE1_HOOK(spool_root)

        if cancel_event is not None and cancel_event.is_set():
            raise ExchangeCancelled("cancelled between stages")

        # ═════ BARRIER — manifests are read from DISK (committed truth) ═
        manifests: List[Dict[str, Any]] = []
        for i in range(n_workers):
            mpath = os.path.join(spool_root, f"w{i}", _MANIFEST_NAME)
            try:
                with open(mpath, "r", encoding="utf-8") as fh:
                    manifests.append(json.load(fh))
            except Exception as m_exc:
                raise ExchangeAbort(
                    f"manifest for worker {i} missing/unreadable "
                    f"({m_exc}) — the atomic commit contract says this "
                    "worker's spool cannot be trusted")

        # ═════ ROW-CONSERVATION HARD GATE (§4.2) ════════════════════════
        conservation = _verify_row_conservation(manifests, spool_root)

        # ═════ LPT bucket assignment + PARTITION ASSERTION (§4.3) ═══════
        bucket_rows: Dict[int, int] = {}
        bucket_files: Dict[int, List[str]] = {}
        for m in manifests:
            wdir = os.path.join(spool_root, f"w{int(m['worker'])}")
            for fent in (m.get("files") or []):
                b = int(fent["bucket"])
                bucket_rows[b] = bucket_rows.get(b, 0) + int(fent["rows"])
                bucket_files.setdefault(b, []).append(
                    os.path.join(wdir, str(fent["path"])))
        if not bucket_rows:
            logger.info(
                "[exchange-b1] zero rows spooled — nothing to exchange; "
                "single-worker fallback (cheap, correct)")
            return None
        n_stage2 = min(n_workers, len(bucket_rows))
        assignment = _assign_buckets_lpt(bucket_rows, n_stage2)
        try:
            _assert_bucket_assignment_partition(assignment,
                                                set(bucket_rows))
        except ValueError as part_exc:
            logger.warning(
                "[exchange-b1] ABORT bucket-partition assertion FIRED: %s "
                "— never dispatching stage 2, single-worker fallback",
                part_exc)
            return None

        # ═════ STAGE 2 — owned-key local compute (existing machinery) ═══
        t_s2 = time.monotonic()
        from core.query_splitter import FileChunk, SplitPlan
        from core.multi_worker_executor import execute_multi_worker

        chunks: List[Any] = []
        for w_idx, buckets in enumerate(assignment):
            my_files: List[str] = []
            for b in sorted(buckets):
                my_files.extend(bucket_files[b])
            if my_files:
                chunks.append(FileChunk(files=my_files,
                                        total_size_bytes=0,
                                        chunk_index=len(chunks)))
        split_plan = SplitPlan(
            splittable=True,
            chunks=chunks,
            partial_sql=original_sql,    # ORIGINAL SQL, verbatim — the
            merge_strategy="union",      # worker owns ALL rows for its keys
            merge_metadata={
                "exchange_b1": True,
                "exchange_shape": plan.shape,
                "key_columns": plan.key_columns,
                "n_buckets": n_buckets,
            },
        )

        def _stage2_setup(chunk) -> str:
            file_csv = ", ".join(
                "'" + _posix(f).replace("'", "''") + "'"
                for f in chunk.files)
            # Explicit file lists from the manifests — NEVER glob.
            # hive_partitioning=true reconstructs __qs_bucket from the
            # path so EXCLUDE is always valid regardless of writer
            # version; the view exposes exactly the original columns.
            return (f"CREATE OR REPLACE VIEW {tbl} AS "
                    f"SELECT * EXCLUDE ({_BUCKET_COL}) "
                    f"FROM read_parquet([{file_csv}], "
                    "hive_partitioning=true)")

        _emit(0, len(chunks), "exchange-B1 stage 2: owned-key compute")
        outcome = execute_multi_worker(
            split_plan,
            _stage2_setup,
            final_sql=original_sql,
            executor_mode="thread",
            max_workers=len(chunks),
            per_worker_timeout_s=int(
                mw_cfg.get("per_worker_timeout_seconds", 1800) or 1800),
            fallback_on_error=True,
            cancel_event=cancel_event,
            progress_cb=progress_cb,
            duckdb_settings=dict(duckdb_settings or {}),
            correlation_id=(execution_id or "exchange-b1") + "-s2",
            cancellable=cancellable,
        )
        if outcome is None or outcome.fell_back or outcome.table is None:
            logger.warning(
                "[exchange-b1] stage-2 workers failed/fell back (%s) — "
                "abort, single-worker fallback",
                getattr(outcome, "fallback_reason", "no outcome"))
            return None
        stage2_elapsed = time.monotonic() - t_s2

        return ExchangeB1Outcome(
            table=outcome.table,
            worker_count=max(n_workers, len(chunks)),
            total_elapsed_s=time.monotonic() - t0,
            stage1_elapsed_s=stage1_elapsed,
            stage2_elapsed_s=stage2_elapsed,
            n_buckets=n_buckets,
            spool_dir=spool_root,
            spool_bytes=int(spool_bytes_total[0]),
            conservation=conservation,
            per_worker_summary=outcome.to_dict().get("per_worker", []),
        )

    except ConservationError as cons_exc:
        logger.warning(
            "[exchange-b1] ABORT row-conservation gate FIRED: %s — result "
            "discarded, single-worker fallback; this failure can NEVER be "
            "certified COMPLETE", cons_exc)
        _record_conservation_failure(execution_id, str(cons_exc))
        return None
    except DiskCapError as cap_exc:
        logger.warning("[exchange-b1] ABORT disk cap: %s — single-worker "
                       "fallback", cap_exc)
        return None
    except ExchangeCancelled as can_exc:
        logger.info("[exchange-b1] cancelled (%s) — spool cleaned", can_exc)
        return None
    except Exception as exc:
        logger.warning(
            "[exchange-b1] ABORT (%s) — single-worker fallback", exc,
            exc_info=True)
        return None
    finally:
        # Cleanup on success, error, AND cancel — the spool never outlives
        # its execution.  The orphan sweeper covers pod-crash leftovers.
        shutil.rmtree(spool_root, ignore_errors=True)


def _record_conservation_failure(execution_id: str, detail: str) -> None:
    """Best-effort §4.5 wiring: stamp the hard-negative conservation receipt
    into the per-execution diagnostic store so the certificate surface can
    see WHY the exchange aborted.  (The aborted exchange never returns a
    table, so there is structurally nothing to certify COMPLETE — this
    record is the audit trail.)"""
    try:
        from core.query_diagnostic_store import record_pruning
        receipt = conservation_receipt({"verified": False, "detail": detail})
        record_pruning(str(execution_id or ""), {
            "exchange_b1_conservation": receipt,
        })
    except Exception:
        pass
