"""Business-calendar date tokens — ONE resolver for every shortcut vocabulary.

Report date shortcuts were calendar-naive: ``yesterday`` is today - 1 on a
Monday and on the day after a bank holiday alike, so every consumer edited
the date by hand on the first business day after a non-business day.  The
bank calendars already live in this product (``feed_calendars`` /
``feed_holidays``, ``core.feed.calendar``) and drive the feeds and
Clockwork's working-day schedules.  These tokens consult them::

    prev_business_day            the business day before today
    prev_business_day:LDN        ... on the calendar named LDN
    next_business_day            the business day after today
    business_month_end           the last business day of this month
    prev_business_month_end      the last business day of the previous month
    business_day_n:3             the 3rd business day of this month
    business_day_n:3:LDN         ... on LDN

They are accepted anywhere a date shortcut is accepted today, in each
vocabulary's own spelling -- bare (``prev_business_day``, a report
parameter value or a saved-query filter), ``@``-prefixed
(``@PREV_BUSINESS_DAY:LDN``, a report parameter DEFAULT and the picker),
and ``${...}`` (``${prev_business_day}``, a saved-query filter expression).
The three vocabularies (``core.parameters.resolve_business_dates``,
``core.date_resolver``, ``api.business_reports_api._resolve_param_value``)
all call :func:`resolve_calendar_token`; none re-implements it.  A decision
made twice is a bug.

THE RULE THAT MATTERS: a token that cannot be resolved REFUSES, with the
reason and the way out -- never a silent fall back to plain calendar days.
A filter that silently became ``today - 1`` on a Monday would return the
wrong rows with a green status, which is the defect this exists to remove.
So an unknown calendar refuses naming the calendars that exist; no calendar
named and no deployment default (``feed_generation.default_calendar``)
refuses saying which key to set; a date beyond the calendar's populated
horizon refuses with the calendar's own words (FR-SCH-02).
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Any, Optional

logger = logging.getLogger(__name__)

#: The vocabulary.  ``needs_n`` = the token takes a positional integer
#: (``business_day_n:3``).  Order is the order a picker offers them.
CALENDAR_TOKENS: tuple = (
    {"token": "prev_business_day", "needs_n": False,
     "label": "previous business day",
     "description": "the business day before today on the named calendar "
                    "(skips weekends and holidays)"},
    {"token": "next_business_day", "needs_n": False,
     "label": "next business day",
     "description": "the business day after today on the named calendar"},
    {"token": "business_month_end", "needs_n": False,
     "label": "last business day of this month",
     "description": "the last business day of the current month"},
    {"token": "prev_business_month_end", "needs_n": False,
     "label": "last business day of last month",
     "description": "the last business day of the previous month"},
    {"token": "business_day_n", "needs_n": True,
     "label": "Nth business day of this month",
     "description": "the Nth business day of the current month, e.g. "
                    "business_day_n:3"},
)

_TOKEN_NAMES = tuple(t["token"] for t in CALENDAR_TOKENS)
_NEEDS_N = {t["token"]: bool(t["needs_n"]) for t in CALENDAR_TOKENS}

#: The config key naming the calendar a bare token resolves on.
DEFAULT_CALENDAR_CONFIG_KEY = "feed_generation.default_calendar"

#: How far a walk may go before the calendar is declared over-restricted --
#: a year of consecutive non-business days is beyond any real configuration.
_WALK_CAP_DAYS = 366


class CalendarTokenRefused(ValueError):
    """A calendar token that cannot be rendered.  A ``ValueError`` so the
    API's existing 400 mapping and every ``except ValueError`` reads it as a
    caller's problem, never a 500 -- and never a silent fallback."""


@dataclass(frozen=True)
class ParsedToken:
    value: str                 # as the caller wrote it
    name: str                  # one of CALENDAR_TOKENS
    n: Optional[int]           # business_day_n's N
    calendar: Optional[str]    # as written; None = the deployment default


@dataclass
class ResolvedToken:
    value: str
    name: str
    n: Optional[int]
    calendar: str              # the calendar's stored spelling
    calendar_source: str       # 'named' | 'default'
    today: date
    resolved: date
    #: The non-business days the walk stepped over, oldest first:
    #: ``[{"date": "2026-09-26", "reason": "weekend"}, ...]``.
    skipped: list = field(default_factory=list)
    explanation: str = ""

    def to_dict(self) -> dict:
        return {
            "value": self.value, "token": self.name, "n": self.n,
            "calendar": self.calendar, "calendar_source": self.calendar_source,
            "today": self.today.isoformat(),
            "resolved": self.resolved.isoformat(),
            "skipped": list(self.skipped),
            "explanation": self.explanation,
        }


# ── Parsing ──────────────────────────────────────────────────────────────

def _strip_syntax(value: str) -> str:
    """``${x}`` -> ``x``, ``@X`` -> ``X``; a bare token unchanged."""
    v = str(value).strip()
    if v.startswith("${") and v.endswith("}"):
        v = v[2:-1].strip()
    if v.startswith("@"):
        v = v[1:].strip()
    return v


def parse_calendar_token(value: Any) -> Optional[ParsedToken]:
    """The token's parts, or None when ``value`` is not a calendar token at
    all (so a caller can pass it to the next vocabulary).  A value that IS
    one of these tokens but malformed (``business_day_n`` without its N,
    too many parts) REFUSES here -- it must not fall through as a literal."""
    if not isinstance(value, str):
        return None
    inner = _strip_syntax(value)
    if not inner:
        return None
    parts = [p.strip() for p in inner.split(":")]
    name = parts[0].lower()
    if name not in _TOKEN_NAMES:
        return None
    rest = parts[1:]
    n: Optional[int] = None
    if _NEEDS_N[name]:
        if not rest or not rest[0].lstrip("+").isdigit() or int(rest[0]) < 1:
            raise CalendarTokenRefused(
                f"{value!r}: {name} needs a positive N, e.g. "
                f"{name}:3 (the 3rd business day of the month)"
                + (f"; got {rest[0]!r}" if rest else ""))
        n = int(rest[0])
        rest = rest[1:]
    if len(rest) > 1:
        raise CalendarTokenRefused(
            f"{value!r}: too many parts -- the form is "
            f"{name}{':N' if _NEEDS_N[name] else ''}[:CALENDAR]")
    calendar = rest[0] if rest and rest[0] else None
    return ParsedToken(value=str(value), name=name, n=n, calendar=calendar)


def is_calendar_token(value: Any) -> bool:
    """True when ``value`` is one of these tokens -- INCLUDING a malformed
    one, so the caller resolves (and is refused) rather than treating the
    text as a literal date."""
    try:
        return parse_calendar_token(value) is not None
    except CalendarTokenRefused:
        return True


# ── The calendar ─────────────────────────────────────────────────────────

def default_calendar_name() -> Optional[str]:
    """``feed_generation.default_calendar`` -- the calendar a bare token
    resolves on.  Empty = undeclared."""
    try:
        from core.config import get as _cfg_get
        raw = _cfg_get("feed_generation", "default_calendar", "")
    except Exception:                                 # noqa: BLE001
        raw = ""
    raw = str(raw or "").strip()
    return raw or None


def _db_or_refuse(db: Any):
    if db is not None:
        return db
    from core.database import get_db_manager
    mgr = get_db_manager()
    if mgr is None:
        raise CalendarTokenRefused(
            "the business calendars cannot be read: no database manager is "
            "available in this process")
    return mgr


def calendar_names(db: Any = None) -> list:
    """The ACTIVE calendars' names, as stored.  Refuses (with the reason)
    when they cannot be listed -- an empty list would read as 'none'."""
    mgr = _db_or_refuse(db)
    try:
        rows = mgr.list_feed_calendars(is_active=True) or []
    except Exception as exc:                          # noqa: BLE001
        raise CalendarTokenRefused(
            f"the business calendars could not be listed: "
            f"{type(exc).__name__}: {exc}") from exc
    return [str(r.get("name")) for r in rows if r.get("name")]


def _pick_calendar(parsed: ParsedToken, db: Any) -> tuple:
    """``(stored_name, source)`` or a refusal naming the calendars."""
    names = calendar_names(db)
    wanted = parsed.calendar
    source = "named"
    if not wanted:
        wanted = default_calendar_name()
        source = "default"
        if not wanted:
            raise CalendarTokenRefused(
                f"{parsed.value!r} names no calendar and no deployment "
                f"default is declared -- write the calendar into the token "
                f"({parsed.name}{':N' if parsed.n is not None else ''}"
                f":<CALENDAR>) or set {DEFAULT_CALENDAR_CONFIG_KEY}.  "
                f"Calendars: {names or 'none defined'}")
    if wanted in names:
        return wanted, source
    folded = [n for n in names if n.casefold() == str(wanted).casefold()]
    if len(folded) == 1:
        return folded[0], source
    where = ("the deployment default calendar "
             f"({DEFAULT_CALENDAR_CONFIG_KEY})" if source == "default"
             else "the calendar named in the token")
    raise CalendarTokenRefused(
        f"{parsed.value!r}: {where} is {wanted!r}, which is not an active "
        f"business calendar.  Calendars: {names or 'none defined'}")


def _load_calendar(name: str, db: Any):
    from core.feed.calendar import BusinessCalendar, BusinessCalendarRepo
    try:
        spec = BusinessCalendarRepo(db).get(name)
    except Exception as exc:                          # noqa: BLE001
        raise CalendarTokenRefused(
            f"calendar {name!r} could not be loaded: "
            f"{type(exc).__name__}: {exc}") from exc
    if spec is None:
        raise CalendarTokenRefused(
            f"calendar {name!r} could not be loaded (it is listed but its "
            f"row or holidays could not be read)")
    return BusinessCalendar(spec)


# ── Resolution ───────────────────────────────────────────────────────────

def _reason(cal, d: date) -> str:
    if cal.is_holiday(d):
        return "holiday"
    if cal.is_weekend(d):
        return "weekend"
    return "non-business day"


def _walk(cal, start: date, step: int, skipped: list) -> date:
    """From ``start`` in direction ``step`` to the first business day,
    recording every day stepped over."""
    d = start
    for _ in range(_WALK_CAP_DAYS):
        if cal.is_business_day(d):
            return d
        skipped.append({"date": d.isoformat(), "reason": _reason(cal, d)})
        d += timedelta(days=step)
    raise CalendarTokenRefused(
        f"no business day within {_WALK_CAP_DAYS} days of {start.isoformat()} "
        f"on calendar {cal.spec.name!r} -- the calendar is over-restricted")


def _last_day_of_month(d: date) -> date:
    import calendar as _cal
    return d.replace(day=_cal.monthrange(d.year, d.month)[1])


def _fmt_day(iso: str) -> str:
    d = date.fromisoformat(iso)
    return f"{d.day} {d.strftime('%b')}"


def _explain(res: ResolvedToken) -> str:
    label = next((t["label"] for t in CALENDAR_TOKENS if t["token"] == res.name),
                 res.name)
    if res.n is not None:
        label = label.replace("Nth", f"{res.n}{_ordinal(res.n)}")
    head = f"{res.resolved.isoformat()} = {label} ({res.calendar}"
    head += ", deployment default)" if res.calendar_source == "default" else ")"
    if not res.skipped:
        return head
    parts = [f"{_fmt_day(s['date'])} {s['reason']}" for s in res.skipped]
    return head + "; skipped " + ", ".join(parts)


def _ordinal(n: int) -> str:
    if 10 <= n % 100 <= 20:
        return "th"
    return {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")


def resolve_calendar_token(value: Any, *, today: Optional[date] = None,
                           db: Any = None) -> ResolvedToken:
    """Resolve one token to a date on its calendar, or REFUSE.

    ``today`` is the caller's notion of today (each vocabulary has its own
    -- ``core.parameters`` uses the local date, ``core.date_resolver`` the
    UTC date -- and this function does not pick between them).  ``db``
    defaults to the process-wide DatabaseManager.
    """
    parsed = parse_calendar_token(value)
    if parsed is None:
        raise CalendarTokenRefused(
            f"{value!r} is not a business-calendar token; the tokens are "
            f"{', '.join(_TOKEN_NAMES)}")
    mgr = _db_or_refuse(db)
    name, source = _pick_calendar(parsed, mgr)
    cal = _load_calendar(name, mgr)
    t = today or date.today()
    skipped: list = []
    from core.feed.calendar import CalendarHorizonError
    try:
        if parsed.name == "prev_business_day":
            resolved = _walk(cal, t - timedelta(days=1), -1, skipped)
        elif parsed.name == "next_business_day":
            resolved = _walk(cal, t + timedelta(days=1), +1, skipped)
        elif parsed.name == "business_month_end":
            resolved = _walk(cal, _last_day_of_month(t), -1, skipped)
        elif parsed.name == "prev_business_month_end":
            resolved = _walk(cal, t.replace(day=1) - timedelta(days=1), -1,
                             skipped)
        elif parsed.name == "business_day_n":
            resolved = cal.nth_business_day_of_month(t.year, t.month,
                                                     int(parsed.n))
            if resolved is None:
                raise CalendarTokenRefused(
                    f"{parsed.value!r}: {t.strftime('%B %Y')} has fewer than "
                    f"{parsed.n} business days on calendar {name!r}")
        else:                                          # pragma: no cover
            raise CalendarTokenRefused(f"{parsed.value!r}: unhandled token")
    except CalendarHorizonError as exc:
        raise CalendarTokenRefused(f"{parsed.value!r}: {exc}") from exc
    except RuntimeError as exc:
        raise CalendarTokenRefused(f"{parsed.value!r}: {exc}") from exc
    # The walk records days in walking order; a backward walk lists them
    # newest first -- present them oldest first either way.
    skipped.sort(key=lambda s: s["date"])
    out = ResolvedToken(value=str(value), name=parsed.name, n=parsed.n,
                        calendar=name, calendar_source=source, today=t,
                        resolved=resolved, skipped=skipped)
    out.explanation = _explain(out)
    return out


def resolve_if_calendar_token(value: Any, *, today: Optional[date] = None,
                              db: Any = None) -> Optional[str]:
    """The ISO date when ``value`` is a calendar token (refusing when it
    cannot be rendered); None when it is not one, so the caller carries on
    with its own vocabulary.  The ONE entry point the three vocabularies
    call."""
    if not is_calendar_token(value):
        return None
    return resolve_calendar_token(value, today=today, db=db).resolved.isoformat()


def token_vocabulary() -> list:
    """What a picker offers: the tokens with their labels and whether they
    take an N.  Every spelling a vocabulary accepts is derived from
    ``token`` (``@TOKEN``, ``${token}``, bare)."""
    return [dict(t) for t in CALENDAR_TOKENS]
