"""Entitlement-aware sharing for MATERIALISED downloads (2026-08-30).

The Download Centre is per-creator: your export is yours, and a colleague who
can open the same report — even one granted to them through their group —
cannot fetch the file you produced.  That is deliberately safe and obviously
incomplete: group grants govern the report, not the artifact it produced.

Why an ACL column would be wrong
--------------------------------
A download is a MATERIALISED file, filtered at generation time for exactly one
principal.  Handing it to a group by ACL alone hands rows scoped to one user to
people whose scope differs — the row-security equivalent of emailing your
filtered extract to the whole department.  Two conditions must BOTH hold:

  1. **Entitlement to the source.**  The reader must independently pass the
     source object's own read check — the same chokepoint the product already
     uses, so group grants, owner-group and publication are honoured here
     without a second, drifting copy of the rule.

  2. **Proven scope equality.**  The reader's resolved row-security scope must
     equal the scope the file was generated under.  This is NOT a username or
     group comparison: two members of one group have identical predicates under
     a group-bound policy and DIFFERENT predicates under a ``${user.username}``
     policy, so only the resolved predicates can decide it.

Condition 2 alone is not sufficient and must never be used alone: with
row-security disabled every caller signs the distinguished ``rls1:open``
constant, so a scope-only rule would make every download world-readable the
moment the feature is switched off.  Condition 1 is what keeps that case
correct — with RLS off there IS no row filtering, so anyone entitled to the
report would see those very rows if they ran it themselves.

Reuse, not reinvention
----------------------
The scope half is ``core.row_security.signature.scope_signature`` — already THE
keying chokepoint for "serving one caller's stored report bytes to another"
(the report-instance layer).  It resolves the dataset's tables through the same
strict computer the enforcement rewriter uses, folds the policy fingerprint so
any policy edit invalidates old signatures, and RAISES rather than guessing.
Nothing here hashes anything itself.

FAIL-CLOSED throughout: an unstamped row, an unreadable source, an
unresolvable scope or any exception at all yields "no share" — which is
today's behaviour, so every failure mode degrades to creator-only.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

#: Source kinds a download may be shared through.  A row whose ``source_kind``
#: is not listed here is never shareable — an unknown kind is an unknown
#: entitlement rule, and an unknown rule cannot be satisfied.
SOURCE_BUSINESS_REPORT = "business_report"
SOURCE_FEED = "feed"

_SUPPORTED_KINDS = (SOURCE_BUSINESS_REPORT, SOURCE_FEED)

#: The ``rls_signature`` a FEED download row must carry (FR-DEL-12,
#: 2026-09-03).  A feed's deliverable is the feed's ONE canonical output —
#: generated under the feed's own identity, the same bytes a counterparty
#: receives — not a per-principal materialisation like a report export.
#: So the scope-equality half of the rule does not apply: whoever passes
#: the FEED's own read check (``core.feed.permissions.can_view_feed`` —
#: owner, group member, admin) may fetch what the feed produced; that IS
#: "the download carries the same access rule as the feed".  The stamp is
#: still REQUIRED and must be exactly this constant: a feed row stamped
#: with a real per-principal signature was generated some other way and
#: is refused — this module never guesses which rule a row meant.
FEED_CANONICAL_SCOPE = "feed:canonical"


def stamp_for_business_report(report: Optional[Dict[str, Any]],
                              user_ctx: Any, db: Any) -> Dict[str, Any]:
    """Columns to persist so a business-report export CAN later be shared.

    Returns ``{}`` when the scope cannot be established with certainty — the
    row is then simply not shareable, which is exactly today's behaviour.  A
    partial stamp is never returned: ``may_share`` requires all three fields,
    but leaving a half-filled row would be a trap for the next reader of this
    code.
    """
    try:
        report_id = (report or {}).get("id")
        if not report_id:
            return {}
        from core.row_security.signature import scope_signature
        dataset_id = (report or {}).get("dataset_id")
        signature = scope_signature(user_ctx, dataset_id=dataset_id, db=db)
        if not signature:
            return {}
        return {"source_kind": SOURCE_BUSINESS_REPORT,
                "source_id": str(report_id),
                # "" is a REAL value here: a report with no dataset signs a
                # global scope.  NULL means "never stamped", which refuses.
                "source_dataset_id": str(dataset_id) if dataset_id else "",
                "rls_signature": signature}
    except Exception as exc:
        # Not an error: an export whose scope we cannot sign is still served
        # and still registered — it just stays creator-only.
        logger.debug("download not stamped for sharing (report=%s): %s",
                     (report or {}).get("id"), exc)
        return {}


def may_share(record: Optional[Dict[str, Any]], user: Optional[Dict[str, Any]],
              *, db: Any = None, memo: Optional[Dict[Any, Any]] = None) -> bool:
    """May ``user`` read this download through an entitlement rather than
    ownership?

    Requires ALL of: a complete stamp, a supported source kind, the reader
    passing the SOURCE's own read check, and the reader's resolved scope
    signature equalling the one the file was generated under.

    ``memo`` — a caller-owned dict for ONE request.  The Download Centre
    list runs this per row, and a scope signature costs a full scan of the
    three policy tables (``compute_policy_fingerprint`` has no cache), so
    an unmemoised page of 100 rows was measured at 100 report loads and
    100 policy scans.  Scoped to the request deliberately: a longer-lived
    cache would have to be invalidated on every policy edit, and a stale
    entry here is a wrong authorization decision.
    """
    if not record or not user:
        return False
    stamp = (record.get("rls_signature") or "")
    kind = (record.get("source_kind") or "")
    source_id = (record.get("source_id") or "")
    # Cheap dict-only rejection first: an unstamped row is the overwhelming
    # majority and must not cost a database read on every download.
    if not (stamp and kind and source_id):
        return False
    if kind not in _SUPPORTED_KINDS:
        logger.debug("download share refused: unsupported source kind %r", kind)
        return False
    try:
        if db is None:
            db = _default_db()
        if db is None:
            return False
        # The dataset the stamp was signed against, taken from the ROW.
        # Re-deriving it from the live report would drift (published
        # snapshot vs draft; a report repointed after the export), and a
        # signature compared against a different dataset is meaningless.
        raw_ds = record.get("source_dataset_id")
        if raw_ds is None:
            return False  # pre-stamp row — not shareable
        dataset_id = int(raw_ds) if str(raw_ds).strip() else None
        source = _memoised(memo, ("src", kind, source_id),
                           lambda: _load_source(kind, source_id, db))
        if not source:
            return False
        if not _reader_entitled(kind, source, user, db):
            return False
        if kind == SOURCE_FEED:
            # FR-DEL-12 — the feed's own access rule, already passed
            # above, IS the whole rule for the feed's canonical output.
            # The stamp must still SAY canonical: a feed row carrying a
            # per-principal signature was materialised some other way,
            # and serving it on the canonical rule would hand one
            # scope's rows to another (fail closed).
            return stamp == FEED_CANONICAL_SCOPE
        from core.row_security.signature import scope_signature
        reader_sig = _memoised(
            memo, ("sig", dataset_id),
            lambda: scope_signature(user, dataset_id=dataset_id, db=db))
        if reader_sig != stamp:
            # Entitled to the report, but the file holds another scope's rows.
            logger.info("download share refused: reader scope differs from the "
                        "scope %s was generated under", record.get("file_id"))
            return False
        return True
    except Exception as exc:
        logger.warning("download share check failed (%s) — refusing",
                       exc)
        return False


# ── internals ───────────────────────────────────────────────────────────

def _memoised(memo: Optional[Dict[Any, Any]], key: Any, produce):
    """Compute once per request.  ``memo=None`` disables memoisation
    entirely, so a caller that does not opt in keeps today's semantics.
    A produced ``None`` is cached too — a vanished source must not be
    re-queried once per row."""
    if memo is None:
        return produce()
    if key not in memo:
        memo[key] = produce()
    return memo[key]


def _default_db():
    """The same startup-bound manager scope_signature falls back to."""
    try:
        from core.row_security import api as _rs_api
        return _rs_api._db_manager
    except Exception:
        return None


def _load_source(kind: str, source_id: str, db: Any):
    if kind == SOURCE_BUSINESS_REPORT:
        return db.get_business_report(int(source_id))
    if kind == SOURCE_FEED:
        return db.get_feed_config(int(source_id))
    return None


def _reader_entitled(kind: str, source: Dict[str, Any],
                     user: Dict[str, Any], db: Any) -> bool:
    if kind == SOURCE_BUSINESS_REPORT:
        from core.reports.authorization import can_view_business_report
        return bool(can_view_business_report(source, user, db))
    if kind == SOURCE_FEED:
        # FR-DEL-12 / FR-SEC-04 — the feed's OWN read chokepoint, so
        # owner-, group- and admin-grants are honoured here without a
        # second, drifting copy of the rule.
        from core.feed.permissions import can_view_feed
        return bool(can_view_feed(source, user, db))
    return False
