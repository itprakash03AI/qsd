"""
Shared audit helper — fire-and-forget audit logging for API endpoints.

Usage:
    from core.audit import audit_event
    audit_event(_db_manager, user, request, "delete_connection", "connection", conn_id)

BF-WS-NOBLOCK-5: The DB write is now actually fire-and-forget — submitted
to a small dedicated thread pool so async route handlers don't block the
event loop while the audit row is INSERT'd.  The previous version did a
synchronous write in the calling thread, which on a slow DB starved the
asyncio loop and contributed to WebSocket heartbeat misses.
"""
import logging
from concurrent.futures import ThreadPoolExecutor

_log = logging.getLogger(__name__)

# Small dedicated pool — audit writes are tiny + lightweight; 4 threads
# is plenty even under bursty traffic.  Daemon threads die with process.
_audit_pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="audit-")


def _do_audit(db_manager, username, action, resource_type, resource_id,
              ip, ua, details):
    try:
        db_manager.audit(
            username,
            action,
            resource_type=resource_type,
            resource_id=str(resource_id) if resource_id is not None else None,
            ip_address=ip,
            user_agent=ua,
            details=details,
        )
    except Exception as exc:
        _log.warning("Audit log failed (non-fatal): %s", exc)


def audit_event(
    db_manager,
    user: dict,
    request=None,
    action: str = "",
    resource_type: str = None,
    resource_id=None,
    details: dict = None,
) -> None:
    """Fire-and-forget audit log entry.  Never raises, never blocks the caller.

    The DB INSERT is submitted to a dedicated thread pool so async
    handlers don't pay the latency cost of the audit write inline.

    Tests can call ``flush_pending()`` to wait for all pending audit
    writes to complete before making assertions.
    """
    try:
        username = (user or {}).get("username", "guest")
        ip = None
        ua = None
        if request is not None:
            ip = request.client.host if getattr(request, "client", None) else None
            ua_raw = request.headers.get("user-agent", "") if hasattr(request, "headers") else ""
            ua = ua_raw[:500] if ua_raw else None
        fut = _audit_pool.submit(
            _do_audit, db_manager, username, action,
            resource_type, resource_id, ip, ua, details,
        )
        # Track futures for tests; bounded to last ~64 to avoid leak
        _PENDING.append(fut)
        if len(_PENDING) > 64:
            del _PENDING[:32]
    except Exception as exc:
        _log.warning("Audit submit failed (non-fatal): %s", exc)


# Track recent futures so tests can wait for them — bounded ring buffer.
_PENDING: list = []


def flush_pending(timeout: float = 5.0) -> None:
    """Wait for all in-flight audit writes to complete.

    Intended for test code only — production handlers should never call
    this since the whole point is fire-and-forget.
    """
    pending = list(_PENDING)
    _PENDING.clear()
    for fut in pending:
        try:
            fut.result(timeout=timeout)
        except Exception as _flush_exc:
            # The actual audit failure was already logged inside
            # _do_audit; we just don't want flush_pending() itself to
            # raise if a worker errored.
            _log.debug("Audit flush ignored prior failure: %s", _flush_exc)
