"""BrainCoordinator — single arbiter across all pruning-brain daemons.

The problem:

Today the brain runs FIVE independent daemons:
  * supplement scanner (5-min cron)
  * bloom adaptive prefetch (6h cron)
  * iceberg mirror cron (6h cron)
  * output gateway cleanup (6h cron)
  * pruning alerts dispatcher (30-min cron)

Each ticks on its own schedule.  When S3 bandwidth is saturated (slow
proxy, high concurrent query load, mid-month batch reload), all five
compete and the supplement scanner — the most latency-sensitive — gets
starved.  Nothing coordinates them.

The fix:

A single ``BrainCoordinator`` class owns the runtime arbitration.
On each tick it:
  1. Reads bandwidth observation from the supplement scanner's
     ``adaptive_state`` (rolling per-file latency).
  2. Reads workload forecaster predictions for the next 24h.
  3. Reads cost model's per-table stats freshness.
  4. Computes a per-component budget — when bandwidth is tight,
     defer mirror cron + gateway cleanup; keep supplement + bloom
     active because those directly serve pruning.
  5. Records the decision into an event ring the admin UI surfaces.

The coordinator does NOT replace the individual daemon ticks — they
still run on their own schedules.  Instead it sets a "pressure level"
flag each daemon checks on entry; high pressure → daemon skips this
tick and records the deferral reason.

Strategic shape: ONE class with capabilities — pressure level,
forecasted hot tables, defer ledger, recent decisions.
"""
from __future__ import annotations

import logging
import threading
from collections import deque
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# ── Config ────────────────────────────────────────────────────────────


def _cfg(key: str, fallback: Any) -> Any:
    try:
        from core.config import get as _g
        return _g("brain_coordinator", key, fallback)
    except Exception:
        return fallback


def enabled() -> bool:
    """Master switch.  Default ON — coordinator is read-only + sets
    a pressure flag; daemons can ignore it (they fall through to their
    own scheduled tick logic)."""
    return bool(_cfg("enabled", True))


def cron_interval_minutes() -> int:
    """How often the coordinator tick runs.  Default 5m — faster than
    the supplement scanner's 5m budget so pressure flag is fresh."""
    return int(_cfg("cron_interval_minutes", 5) or 5)


def pressure_threshold_seconds_per_file() -> float:
    """Avg per-file footer read seconds above which we declare
    bandwidth pressure.  Default 0.5s — slow proxy / VPN territory."""
    return float(_cfg("pressure_threshold_seconds_per_file", 0.5) or 0.5)


# ── Dataclasses ──────────────────────────────────────────────────────


@dataclass
class CoordinatorDecision:
    component:    str        # "mirror" | "gateway" | "alerts" | ...
    action:       str        # "proceed" | "defer" | "throttle"
    reason:       str
    pressure:     str        # "low" | "high"
    fired_at:     str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat(),
    )

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class CoordinatorReport:
    pressure:                  str
    avg_per_file_seconds:      float
    decisions:                 List[CoordinatorDecision]
    forecast_hot_tables:       List[Tuple[str, str]]
    skew_signals:              int
    writer_recommendations:    int
    cost_model_tables_cached:  int
    started_at:                str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat(),
    )

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["decisions"] = [x.to_dict() for x in self.decisions]
        d["forecast_hot_tables"] = [list(t) for t in self.forecast_hot_tables]
        return d


# ── The coordinator ──────────────────────────────────────────────────


_RECENT_REPORTS: deque = deque(maxlen=50)
_REPORTS_LOCK = threading.Lock()
_PRESSURE_LOCK = threading.Lock()
_CURRENT_PRESSURE: str = "low"
_CURRENT_PRESSURE_AT: Optional[str] = None


def get_current_pressure() -> str:
    """Cheap read for sub-daemons.  Returns "low" or "high"."""
    with _PRESSURE_LOCK:
        return _CURRENT_PRESSURE


def get_current_pressure_state() -> Dict[str, Any]:
    with _PRESSURE_LOCK:
        return {
            "pressure":   _CURRENT_PRESSURE,
            "updated_at": _CURRENT_PRESSURE_AT,
        }


def _set_pressure(value: str) -> None:
    global _CURRENT_PRESSURE, _CURRENT_PRESSURE_AT
    with _PRESSURE_LOCK:
        _CURRENT_PRESSURE = value
        _CURRENT_PRESSURE_AT = datetime.now(timezone.utc).isoformat()


class BrainCoordinator:
    """Singleton arbiter."""

    _instance_lock = threading.Lock()
    _instance: Optional["BrainCoordinator"] = None

    def __init__(self, db_manager: Any) -> None:
        self._db = db_manager

    @classmethod
    def get_default(cls, db_manager: Any) -> "BrainCoordinator":
        # 2026-06-10 audit fix — wrap lazy-init in a lock so two
        # concurrent admin endpoint / daemon-tick calls don't race
        # on the singleton.
        with cls._instance_lock:
            if cls._instance is None:
                cls._instance = cls(db_manager)
            return cls._instance

    def coordinator_tick(self) -> CoordinatorReport:
        """Single arbitration pass.  Reads bandwidth signal from
        supplement scanner, forecaster hot tables, cost-model cache,
        skew + writer-advisor counts — emits per-component decisions
        + sets the process-wide pressure flag.
        """
        avg_per_file = self._read_bandwidth_signal()
        threshold = pressure_threshold_seconds_per_file()
        pressure = "high" if avg_per_file >= threshold else "low"
        _set_pressure(pressure)

        decisions = self._decide(pressure, avg_per_file)
        forecast_tables = self._forecast_hot_tables()
        skew_count = self._skew_signal_count()
        writer_count = self._writer_recommendation_count()
        cost_tables_cached = self._cost_model_cache_size()

        report = CoordinatorReport(
            pressure                  = pressure,
            avg_per_file_seconds      = round(avg_per_file, 4),
            decisions                 = decisions,
            forecast_hot_tables       = forecast_tables,
            skew_signals              = skew_count,
            writer_recommendations    = writer_count,
            cost_model_tables_cached  = cost_tables_cached,
        )
        with _REPORTS_LOCK:
            _RECENT_REPORTS.appendleft(report.to_dict())
        return report

    # ── Internal ────────────────────────────────────────────────────

    # 2026-06-10 audit follow-up — TTL-cache the heavy reads.  The
    # coordinator ticks every 5 min by default; without caching that's
    # 4 full DB scans (forecaster + skew + writer-advisor + cost model
    # status) every tick.  At a busy deployment with 100k queries/day
    # × 168h that's a non-trivial DB hit ~288×/day for stats that
    # don't materially change minute-to-minute.  TTL set to 4 minutes
    # so cache refreshes JUST before each tick reads it — same
    # accuracy, ~1/12 the DB load.
    _heavy_cache: Dict[str, Tuple[float, Any]] = {}
    _heavy_cache_lock = threading.Lock()
    _HEAVY_CACHE_TTL_SECONDS = 240.0

    def _cached_heavy(self, key: str, compute) -> Any:
        import time as _t
        now = _t.monotonic()
        with self._heavy_cache_lock:
            entry = self._heavy_cache.get(key)
            if entry is not None and (now - entry[0]) < self._HEAVY_CACHE_TTL_SECONDS:
                return entry[1]
        # Compute OUTSIDE the lock so a slow DB read doesn't block
        # other readers.  Lost-update race is acceptable — two ticks
        # computing the same value is no-op idempotent.
        try:
            value = compute()
        except Exception as exc:
            logger.debug("coordinator heavy compute failed for %s: %s",
                         key, exc)
            return None
        with self._heavy_cache_lock:
            self._heavy_cache[key] = (now, value)
        return value

    def _read_bandwidth_signal(self) -> float:
        """Returns the rolling avg per-file footer-read seconds from
        the supplement scanner.  Falls back to 0 when the ring is
        empty (cold start = no pressure assumed)."""
        try:
            from core.iceberg_metadata_sync import adaptive_state
            state = adaptive_state()
            return float(state.get("avg_per_file_seconds") or 0.0)
        except Exception as exc:
            logger.debug("coordinator: bandwidth read failed: %s", exc)
            return 0.0

    def _decide(
        self, pressure: str, avg_per_file: float,
    ) -> List[CoordinatorDecision]:
        decisions: List[CoordinatorDecision] = []
        if pressure == "high":
            # Defer heavy multi-file scans (mirror builds, bloom prefetch)
            decisions.append(CoordinatorDecision(
                component="iceberg_mirror_daemon",
                action="defer",
                reason=(
                    f"bandwidth pressure {avg_per_file:.3f}s/file ≥ "
                    f"{pressure_threshold_seconds_per_file():.2f}s — "
                    f"deferring mirror builds to keep supplement scanner "
                    f"on schedule"
                ),
                pressure=pressure,
            ))
            decisions.append(CoordinatorDecision(
                component="bloom_adaptive_prefetch",
                action="throttle",
                reason=(
                    "bandwidth pressure — throttling bloom prefetch "
                    "to top-3 forecasted hot tables only"
                ),
                pressure=pressure,
            ))
            decisions.append(CoordinatorDecision(
                component="iceberg_column_stats_sync",
                action="proceed",
                reason=(
                    "supplement is the load-bearing component for "
                    "pruning — keep running; adaptive backpressure "
                    "shrinks the per-tick cap"
                ),
                pressure=pressure,
            ))
        else:
            decisions.append(CoordinatorDecision(
                component="all",
                action="proceed",
                reason=(
                    f"bandwidth healthy ({avg_per_file:.3f}s/file < "
                    f"{pressure_threshold_seconds_per_file():.2f}s)"
                ),
                pressure=pressure,
            ))
        return decisions

    def _forecast_hot_tables(self) -> List[Tuple[str, str]]:
        def _compute():
            from core.brain_forecaster import WorkloadForecaster
            wf = WorkloadForecaster.get_default(self._db)
            return wf.forecasted_targets()[:10]
        return self._cached_heavy("forecast_hot_tables", _compute) or []

    def _skew_signal_count(self) -> int:
        def _compute():
            from core.brain_skew_detector import SkewDetector
            sd = SkewDetector.get_default(self._db)
            return len(sd.detect_skewed_columns())
        return int(self._cached_heavy("skew_signal_count", _compute) or 0)

    def _writer_recommendation_count(self) -> int:
        def _compute():
            from core.writer_advisor import WriterAdvisor
            wa = WriterAdvisor.get_default(self._db)
            return len(wa.compute_all())
        return int(
            self._cached_heavy("writer_recommendation_count", _compute)
            or 0
        )

    def _cost_model_cache_size(self) -> int:
        # In-memory dict read — cheap; no caching needed.
        try:
            from core.brain_cost_model import CostModel
            cm = CostModel.get_default(self._db)
            return int(cm.state_snapshot().get("count") or 0)
        except Exception as exc:
            logger.debug("coordinator: cost model state failed: %s",
                         exc)
            return 0


def recent_reports(limit: int = 20) -> List[Dict[str, Any]]:
    with _REPORTS_LOCK:
        return list(_RECENT_REPORTS)[: max(1, min(50, int(limit)))]


# ── Scheduler registration ───────────────────────────────────────────


def coordinator_tick(db_manager: Any) -> Dict[str, Any]:
    """Single tick — pulled out so admin /tick endpoint can force-run."""
    if not enabled():
        return {"skipped_reason": "brain_coordinator.enabled=false"}
    coord = BrainCoordinator.get_default(db_manager)
    report = coord.coordinator_tick()
    return report.to_dict()


def register_coordinator_daemon(
    scheduler: Any, db_manager: Any,
) -> Optional[str]:
    """Always register — tick reads ``enabled()`` and short-circuits
    when off.  Same runtime-flippable pattern as other brain daemons."""
    if scheduler is None:
        return None
    minutes = max(1, cron_interval_minutes())
    job_id = "brain_coordinator_daemon"
    try:
        def _tick():
            # 2026-06-24 -- honour admin pause via core.background_jobs.
            try:
                from core.background_jobs import is_paused as _bj_paused
                if _bj_paused("brain_coordinator_daemon"):
                    return {"status": "skipped", "reason": "paused by admin"}
            except Exception:
                pass
            try:
                return coordinator_tick(db_manager)      # the ledger reads the result (2026-10-07)
            except Exception as exc:
                logger.warning("coordinator_tick error: %s", exc,
                               exc_info=True)
        scheduler.add_job(
            _tick, "interval", minutes=minutes,
            id=job_id, replace_existing=True,
            max_instances=1, coalesce=True,
        )
        if enabled():
            logger.info(
                "brain_coordinator daemon scheduled every %dm (job_id=%s)",
                minutes, job_id,
            )
        else:
            logger.info(
                "brain_coordinator daemon scheduled every %dm but "
                "brain_coordinator.enabled=false — tick will no-op until "
                "the flag flips (job_id=%s)", minutes, job_id,
            )

        # 2026-06-24 -- ALSO register in core.background_jobs.
        try:
            from core import background_jobs as _bj_bc

            def _factory():
                return None

            _bj_bc.register(
                name="brain_coordinator_daemon",
                description=(
                    f"Phase 149 -- brain coordinator.  Every {minutes}m, "
                    f"reads supplement-scanner bandwidth pressure and "
                    f"decides whether to defer / throttle heavy brain "
                    f"workers (mirror builds, bloom prefetch) so the "
                    f"hot-path scanner stays on schedule.  No-ops when "
                    f"brain_coordinator.enabled=false."
                ),
                factory=_factory,
                autostart=True,
                controllable=True,
            )
            logger.info(
                "[brain_coordinator_daemon] registered in "
                "background_jobs registry -- visible in admin UI",
            )
        except Exception as _bj_bc_exc:
            logger.debug(
                "[brain_coordinator_daemon] background_jobs "
                "registration failed (non-fatal): %s", _bj_bc_exc,
            )
        return job_id
    except Exception as exc:
        logger.warning("register_coordinator_daemon failed: %s", exc)
        return None


__all__ = [
    "BrainCoordinator", "CoordinatorReport", "CoordinatorDecision",
    "coordinator_tick", "register_coordinator_daemon",
    "recent_reports", "get_current_pressure",
    "get_current_pressure_state",
    "enabled", "cron_interval_minutes",
    "pressure_threshold_seconds_per_file",
]
