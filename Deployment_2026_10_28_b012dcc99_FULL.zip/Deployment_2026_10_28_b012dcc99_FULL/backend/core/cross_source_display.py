"""A saved cross-source query's ``raw_sql`` that holds the query builder's
LABELLED DISPLAY instead of the primary statement (2026-10-07, F8
cross-source follow-up).

The query builder shows a cross-source run as two labelled statements::

    -- Primary (<primary connection>)
    SELECT ... FROM primary_table ... ;

    -- Secondary (<secondary connection>) — INNER JOIN on a = b
    SELECT ... FROM secondary_table ... ;

Until 2026-10-07 its Save stored that WHOLE text as ``raw_sql`` (the
secondary statement was also stored, separately, as ``secondary_raw_sql``),
and the published-view road ran ``raw_sql`` on the PRIMARY connection --
both statements, the second against the wrong source.  The builder now saves
the primary statement alone.  Rows saved before keep the display text; this
reads the primary statement out of it, by the builder's own label layout:
the text before the line starting ``-- Secondary (``, with a leading
``-- Primary (`` line removed.  Anything else is returned unchanged.
"""
from __future__ import annotations

import re
from typing import Optional

__all__ = ["primary_statement_of"]

_SECONDARY_LABEL = re.compile(r"^[ \t]*-- Secondary \(.*$", re.MULTILINE)
_PRIMARY_LABEL = re.compile(r"\A\s*-- Primary \([^\n]*\n")


def primary_statement_of(raw_sql: Optional[str]) -> Optional[str]:
    """The primary statement of a stored cross-source ``raw_sql``: the text
    as written when it carries no builder labels, else the part under the
    ``-- Primary (...)`` label and above the ``-- Secondary (...)`` one."""
    if not raw_sql or not _SECONDARY_LABEL.search(raw_sql):
        return raw_sql
    m = _SECONDARY_LABEL.search(raw_sql)
    head = raw_sql[:m.start()] if m else raw_sql
    head = _PRIMARY_LABEL.sub("", head, count=1).strip()
    return head or raw_sql
