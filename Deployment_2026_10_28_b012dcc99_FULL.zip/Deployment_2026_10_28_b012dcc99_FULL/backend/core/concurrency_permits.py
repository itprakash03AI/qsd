"""One definition of "how many permits should this semaphore have".

2026-08-20 found that a concurrency knob configured as 0 built
``asyncio.Semaphore(0)`` — a semaphore nobody can ever acquire.  That is an
outage, not a limit, and it is the exact inverse of what 0 means everywhere
else in this product: ``0 = UNLIMITED`` (row caps, file caps, result caps,
``max_result_rows``, ``max_output_rows``).  An operator typing the spelling
that means "no restriction" got "no service".

The fix was applied to three modules — published_views_api, etl_engine,
feed_engine — each with its own private copy of the helper.  The 2026-08-22
audit found the other two semaphore constructors untouched
(published_views/warmup.py and graphql_api.py), which is the predictable end
state of a fix that is COPIED rather than SHARED: the next site added does not
inherit it either.

So the helper lives here once and the call sites import it.  Same rule as
``resolve_s3_region`` after the region default was found in 19 modules: a
value that must be identical everywhere gets exactly one implementation.
"""
from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

# The stand-in for "unlimited".  Not math.inf: asyncio.Semaphore wants an int,
# and a bound this high is unreachable in a pod that would OOM long before it
# — while still being a real number the diagnostics can print.
UNLIMITED_PERMITS = 10_000


def sem_permits(configured, *, name: str) -> int:
    """Permit count for a concurrency semaphore, honouring 0 = UNLIMITED.

    Anything unparseable is also treated as unlimited: a malformed knob must
    not be able to take the service down, and the log line names the value so
    the operator can see what was read.
    """
    try:
        n = int(configured)
    except (TypeError, ValueError):
        n = 0
    if n > 0:
        return n
    logger.info(
        "[%s] concurrency configured as %r — treating as UNLIMITED "
        "(0 means no restriction product-wide); a zero-permit semaphore "
        "would deadlock every request", name, configured)
    return UNLIMITED_PERMITS
