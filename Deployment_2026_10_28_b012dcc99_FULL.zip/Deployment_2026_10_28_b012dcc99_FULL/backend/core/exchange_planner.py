"""Phase 2a — B0 zero-copy exchange planner (partition-aligned aggregation).

Design: docs/parallel_agg_next_tier_design_2026_07_26.md §3.3 Tier 0.

B0 is the partition-aligned-JOIN mechanism (Phase 144 + fda14249 join-key
gate + aed5aa00 island heal) applied to ONE table.  When the grouping /
window key K of a shape the splitter refuses today (exact COUNT(DISTINCT),
MEDIAN / PERCENTILE per group, window OVER (PARTITION BY k), GROUP BY with
aggregate HAVING, non-decomposable aggregates per group) is a **superset of
the table's hive partition columns**, whole partition tuples are LPT-
assigned to workers.  Each worker then owns ALL rows for its partition
values, runs the **original, unmodified SQL**, and the coordinator merge is
a plain union.  Zero data movement — no shuffle, no spool, no new S3
behaviour.

Correctness proof sketch (why original-SQL-per-worker + union is EXACT):
  * K ⊇ hive partition cols ⇒ two rows agreeing on K agree on every
    partition column ⇒ they live under the same partition tuple ⇒ (by the
    disjoint+complete assignment asserted below) they are scanned by the
    SAME worker.  Hence every GROUP BY group / window partition is entirely
    worker-local, so per-worker evaluation of the original SQL equals the
    global evaluation restricted to that worker's groups, and the union of
    per-worker results is exactly the global result.
  * The converse direction is why K ⊂ partition cols (a proper subset) must
    REFUSE: one K-group would span several partition tuples that LPT may
    scatter across workers.
  * Assignment is proven disjoint AND complete by `_assert_slices_partition`
    (multiset equality between ⋃ slices and the input file list) before a
    plan is returned — never assumed.

FAIL-CLOSED: `plan_exchange` returns a non-splittable plan (⇒ the existing
refusal stands ⇒ single-worker, always correct) on ANY doubt: unparseable
SQL, JOIN / subquery / CTE / set-op / DISTINCT / QUALIFY / ORDER BY /
LIMIT, expression keys, key not a superset of the partition columns, files
missing hive segments, fewer than 2 partition tuples, cross-bucket file
lists, effective workers < 2.

RLS: the file list this planner receives is already post-RLS (resolved at
dispatch).  B0 only re-arranges OWNERSHIP within that list — it never adds,
drops, or widens files.

Flag: ``multi_worker.exchange_enabled`` (inline default False, read by the
dispatcher — no config.py change).  Flag OFF ⇒ this module is never called
on the dispatch path.
"""
from __future__ import annotations

import logging
import re
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

# Reuse the battle-tested PA-JOIN primitives — B0 must NOT duplicate them.
from core.partition_aligned_join import (
    extract_hive_partitions,
    detect_common_partition_columns,
    _path_of,
)

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Plan dataclass (mirrors PartitionAlignedJoinPlan's shape)
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class ExchangePlan:
    """Outcome of exchange planning.  ``splittable=True`` ⇒ ``slices`` holds
    one entry per worker.

    B0 (tier='b0'): each slice = all files of the partition tuples that
    worker owns (zero-copy — worker runs the original SQL directly).
    B1 (tier='b1', Phase 2b): each slice = that worker's STAGE-1 read chunk
    (arbitrary file split — ownership is established by the hash spool, not
    by the chunking), plus the B1-only fields below.
    """
    splittable: bool = False
    skip_reason: str = ""
    tier: str = "b0"                      # 'b0' (2a) | 'b1' (2b hash spool)
    shape: str = ""                       # 'group_by' | 'window'
    key_columns: List[str] = field(default_factory=list)
    partition_columns: List[str] = field(default_factory=list)
    table_name: str = ""
    # Each slice: {"partition_values": (tuple, ...), "files": [...],
    #              "tuple_count": int, "total_files": int}
    slices: List[Dict[str, Any]] = field(default_factory=list)
    n_workers: int = 0
    # ── B1-only (hash-repartition spool exchange) ───────────────────────
    n_buckets: int = 0                    # n_workers × bucket_factor
    referenced_columns: List[str] = field(default_factory=list)
    where_sql: str = ""                   # rendered WHERE (qualifier-free)


def _refuse(reason: str) -> ExchangePlan:
    return ExchangePlan(splittable=False, skip_reason=reason)


# ─────────────────────────────────────────────────────────────────────────────
# Key extraction — SQL side of the key ⊇ partition-cols proof
# ─────────────────────────────────────────────────────────────────────────────
def _alias_shadow_refusal(outer, key_names, exp) -> Optional[str]:
    """2026-07-26 audit fix (CRITICAL wrong-data): a GROUP BY / window
    PARTITION BY name that matches a projection ALIAS may bind to the alias
    EXPRESSION instead of a base column.  DuckDB binds a real column first,
    but when the name is NOT a physical column of the scan (the classic
    case: a hive-path-only partition name read through a view without
    hive_partitioning), ``GROUP BY z`` binds to ``… AS z`` — the planner
    would then prove ownership against the base/path column while the query
    actually groups by the expression, so one key group spans partition
    tuples across workers and the union DUPLICATES groups with partial
    aggregates (empirically: COUNT(DISTINCT) 15+15 instead of 30).
    Fail-closed: refuse whenever a key name matches a projection alias
    whose (alias-unwrapped) body is not that same plain column."""
    for p in outer.expressions:
        try:
            alias = (p.alias_or_name or "").lower()
        except Exception:
            alias = ""
        if not alias or alias not in key_names:
            continue
        body = p.this if isinstance(p, exp.Alias) else p
        if not (isinstance(body, exp.Column)
                and (body.name or "").lower() == alias):
            return (f"key {alias!r} matches a projection alias for a "
                    "non-column expression — the key may bind to the alias, "
                    "making partition/bucket ownership unprovable (refusing, "
                    "fail-closed)")
    return None



def _extract_exchange_key(sql: str) -> Tuple[Optional[str],
                                             Optional[frozenset],
                                             str, str]:
    """Return ``(shape, key_columns, table_name, refuse_reason)``.

    ``shape``/``key_columns`` are None on refusal (fail-closed) with
    ``refuse_reason`` populated.  Mirrors the `_equi_join_columns` posture:
    proof comes from the AST; anything unprovable refuses.

    Accepted shapes:
      * ``group_by`` — single-table SELECT with GROUP BY on plain columns
        (any aggregates, WHERE, HAVING — the worker runs the ORIGINAL SQL
        over whole groups, so even non-decomposable / DISTINCT aggregates
        and aggregate HAVING are exact).  K = the GROUP BY columns.
      * ``window`` — single-table SELECT whose every window has a plain-
        column PARTITION BY; no GROUP BY, no bare aggregates outside
        windows.  K = the columns common to EVERY window's PARTITION BY
        (each window's partition must independently satisfy K ⊇ hive cols,
        so the intersection is what we prove against).
    """
    if not sql:
        return None, None, "", "empty SQL"
    if ";" in sql:
        return None, None, "", "multi-statement SQL — refusing (fail-closed)"
    try:
        import sqlglot
        from sqlglot import exp
    except Exception:
        return None, None, "", "sqlglot unavailable — cannot prove the key"
    try:
        tree = sqlglot.parse_one(sql, read="duckdb")
    except Exception:
        return None, None, "", "SQL unparseable — cannot prove the key"
    if tree is None or not isinstance(tree, exp.Select):
        return None, None, "", ("outermost statement is not a plain SELECT "
                                "— refusing")
    outer = tree

    # ── Structural gates (any hit ⇒ refuse) ─────────────────────────────
    if next(iter(tree.find_all(exp.Join)), None) is not None:
        return None, None, "", "contains JOIN — B0 is single-table only"
    if next(iter(tree.find_all(exp.Subquery)), None) is not None:
        return None, None, "", "contains a subquery / derived table"
    if next(iter(tree.find_all(exp.With)), None) is not None:
        return None, None, "", "contains a CTE"
    for so in (exp.Union, exp.Intersect, exp.Except):
        if next(iter(tree.find_all(so)), None) is not None:
            return None, None, "", "contains a set operation"
    if any(getattr(s, "args", {}).get("distinct")
           for s in tree.find_all(exp.Select)):
        return None, None, "", ("contains SELECT DISTINCT — row-level "
                                "distinct is Phase 2b (B1)")
    qualify_t = getattr(exp, "Qualify", None)
    if qualify_t is not None and \
            next(iter(tree.find_all(qualify_t)), None) is not None:
        return None, None, "", "contains QUALIFY — not proven for B0"
    # Nested SELECTs of any kind (beyond the Subquery node) refuse.
    if sum(1 for _ in tree.find_all(exp.Select)) != 1:
        return None, None, "", "contains a nested SELECT"
    # A global ORDER BY / LIMIT / OFFSET cannot survive a plain union merge
    # (the merger concatenates, never re-sorts) — refuse, single-worker.
    if outer.args.get("order") is not None:
        return None, None, "", ("contains ORDER BY — union merge cannot "
                                "reproduce a global sort")
    if outer.args.get("limit") is not None or \
            outer.args.get("offset") is not None:
        return None, None, "", ("contains LIMIT/OFFSET — union merge cannot "
                                "reproduce a global limit")

    # ── FROM must be exactly one plain table ────────────────────────────
    from_arg = outer.args.get("from") or outer.args.get("from_")
    src = getattr(from_arg, "this", None) if from_arg is not None else None
    if not isinstance(src, exp.Table):
        return None, None, "", ("FROM is not a single plain table — "
                                "refusing")
    if src.args.get("pivots"):
        return None, None, "", "contains PIVOT/UNPIVOT — refusing"
    if outer.args.get("laterals"):
        return None, None, "", "contains LATERAL — refusing"
    table_name = src.alias_or_name or ""

    group = outer.args.get("group")
    windows = list(tree.find_all(exp.Window))

    # ── Shape: GROUP BY ─────────────────────────────────────────────────
    if group is not None:
        if windows:
            return None, None, table_name, (
                "mixes GROUP BY and window functions — not proven for B0")
        if not group.expressions:
            return None, None, table_name, (
                "GROUP BY ALL / empty — key not provable")
        keys: List[str] = []
        for g in group.expressions:
            if not isinstance(g, exp.Column) or not g.name:
                return None, None, table_name, (
                    f"GROUP BY key {g.sql(dialect='duckdb')!r} is not a "
                    "plain column — expression keys refuse (fail-closed)")
            keys.append(g.name.lower())
        shadow = _alias_shadow_refusal(outer, set(keys), exp)
        if shadow:
            return None, None, table_name, shadow
        return "group_by", frozenset(keys), table_name, ""

    # ── Shape: window (no GROUP BY) ─────────────────────────────────────
    if windows:
        # Bare aggregates OUTSIDE a window would make the query a global
        # aggregate — refuse (matrix #6/#9 territory).
        for agg in tree.find_all(exp.AggFunc):
            anc = agg.parent
            inside_window = False
            while anc is not None:
                if isinstance(anc, exp.Window):
                    inside_window = True
                    break
                anc = anc.parent
            if not inside_window:
                return None, None, table_name, (
                    "contains an aggregate outside a window with no GROUP "
                    "BY — global aggregates cannot B0-align")
        common: Optional[set] = None
        for w in windows:
            part = w.args.get("partition_by") or []
            if not part:
                return None, None, table_name, (
                    "window has no PARTITION BY — global window order "
                    "cannot be partition-aligned (stays single-worker)")
            wcols: set = set()
            for p in part:
                if not isinstance(p, exp.Column) or not p.name:
                    return None, None, table_name, (
                        f"window PARTITION BY key "
                        f"{p.sql(dialect='duckdb')!r} is not a plain column")
                wcols.add(p.name.lower())
            common = wcols if common is None else (common & wcols)
        if not common:
            return None, None, table_name, (
                "windows share no common PARTITION BY column")
        # Guard EVERY window key (not just the common set) — any window
        # partitioning by an alias-shadowed name breaks its own ownership.
        all_wcols = set()
        for w in windows:
            for p in (w.args.get("partition_by") or []):
                if isinstance(p, exp.Column) and p.name:
                    all_wcols.add(p.name.lower())
        shadow = _alias_shadow_refusal(outer, all_wcols, exp)
        if shadow:
            return None, None, table_name, shadow
        return "window", frozenset(common), table_name, ""

    # No GROUP BY and no window: nothing here needs B0 (plain SELECTs and
    # whitelisted aggregates split today; global DISTINCT/rank shapes are
    # honest refusals per the design matrix).
    return None, None, table_name, (
        "no GROUP BY / window PARTITION BY key — shape has no "
        "partition-alignable key")


# ─────────────────────────────────────────────────────────────────────────────
# Bucket identity — cross-bucket file lists refuse (planner uncertainty)
# ─────────────────────────────────────────────────────────────────────────────
def _bucket_identity(path: str) -> Optional[Tuple[str, ...]]:
    """A coarse storage identity for a file path; None = cannot classify
    (⇒ caller refuses).  s3://bucket/…  → ('s3', bucket);
    http(s)://host/seg/… → ('http', host, seg) (path-style presigned);
    anything without a scheme → ('local',)."""
    p = str(path or "")
    if not p:
        return None
    low = p.lower()
    if low.startswith("s3://") or low.startswith("s3a://"):
        rest = p.split("://", 1)[1]
        bucket = rest.split("/", 1)[0]
        return ("s3", bucket.lower()) if bucket else None
    if low.startswith("http://") or low.startswith("https://"):
        rest = p.split("://", 1)[1]
        parts = rest.split("/")
        if len(parts) < 2 or not parts[0] or not parts[1]:
            return None
        return ("http", parts[0].lower(), parts[1].lower())
    if "://" in low:
        return None                     # unknown scheme — refuse
    return ("local",)


# ─────────────────────────────────────────────────────────────────────────────
# Disjoint + complete assignment assertion (the exactness precondition)
# ─────────────────────────────────────────────────────────────────────────────
def _assert_slices_partition(slices: List[Dict[str, Any]],
                             files: List[Any]) -> None:
    """Prove the slices form a PARTITION of ``files``: every file assigned
    to exactly one worker, union == input, nothing duplicated or dropped.
    Raises ``ValueError`` on any violation — the planner converts that into
    a refusal (⇒ single-worker), never a wrong answer."""
    input_counter = Counter(_path_of(f) for f in (files or []))
    assigned_counter: Counter = Counter()
    total_assigned = 0
    for sl in slices or []:
        for f in sl.get("files") or []:
            assigned_counter[_path_of(f)] += 1
            total_assigned += 1
    if assigned_counter != input_counter:
        missing = input_counter - assigned_counter
        extra = assigned_counter - input_counter
        raise ValueError(
            "B0 slice assignment is not a partition of the input file "
            f"list: missing={dict(list(missing.items())[:3])} "
            f"duplicated/extra={dict(list(extra.items())[:3])} "
            f"(assigned {total_assigned} of {sum(input_counter.values())})")


# ─────────────────────────────────────────────────────────────────────────────
# Planner
# ─────────────────────────────────────────────────────────────────────────────
def plan_exchange(
    sql: str,
    files: List[Any],
    *,
    max_workers: int = 4,
    min_files: int = 50,
) -> ExchangePlan:
    """Tier-0 (B0) exchange planning: partition-tuple → worker assignment
    for single-table GROUP BY / window shapes whose key ⊇ the hive
    partition columns.  Fail-closed: any doubt returns splittable=False
    (⇒ the existing refusal stands ⇒ single-worker, always correct)."""
    try:
        if not files:
            return _refuse("empty file list")
        if len(files) < max(1, int(min_files)):
            return _refuse(f"only {len(files)} files (<{min_files} "
                           "min_files threshold)")

        # ── SQL side of the proof: shape + key K ────────────────────────
        shape, key_cols, table_name, why = _extract_exchange_key(sql)
        if shape is None or key_cols is None:
            return _refuse(f"key extraction refused: {why}")

        # ── Cross-bucket refusal (planner uncertainty) ──────────────────
        idents = set()
        for f in files:
            ident = _bucket_identity(_path_of(f))
            if ident is None:
                return _refuse("file path with unclassifiable storage "
                               "scheme — refusing (fail-closed)")
            idents.add(ident)
            if len(idents) > 1:
                return _refuse("files span multiple buckets/hosts — "
                               "cross-bucket islands refuse B0")

        # ── Path side of the proof: hive partition columns ──────────────
        partition_cols = detect_common_partition_columns({"__t": files})
        if not partition_cols:
            return _refuse("no hive partition columns detected in file "
                           "paths — cannot align")
        pset = {c.lower() for c in partition_cols}

        # ── THE gate: K must be a SUPERSET of the partition columns.
        # (K may be finer than the partitioning — every K-group still lives
        #  inside one partition tuple.  K ⊂ partition cols would let one
        #  group span tuples on different workers ⇒ refuse.)
        if not pset.issubset(key_cols):
            return _refuse(
                f"{shape} key {sorted(key_cols)} is not a superset of the "
                f"hive partition column(s) {partition_cols} — a key group "
                "could straddle partition tuples across workers (wrong "
                "data).  Single-worker stays correct.")

        # ── Group files by partition tuple; every file must carry every
        #    partition value (aed5aa00 posture: missing segment ⇒ refuse).
        grouped: Dict[Tuple[str, ...], List[Any]] = {}
        for f in files:
            parts = extract_hive_partitions(_path_of(f))
            tup = tuple(parts.get(c, "") for c in partition_cols)
            if any(v == "" for v in tup):
                return _refuse(
                    f"file {_path_of(f)!r} is missing hive segment(s) for "
                    f"{partition_cols} — ownership unprovable, refusing")
            grouped.setdefault(tup, []).append(f)

        tuples = sorted(grouped.keys())        # determinism
        if len(tuples) < 2:
            return _refuse(
                f"only {len(tuples)} partition tuple — no parallelism to "
                "gain; single-worker faster than dispatch overhead")

        # ── LPT bin-packing — identical mechanics to
        #    partition_aligned_join.py:384-412, single table. ─────────────
        _max_workers_clamped = max(1, int(max_workers))
        n_workers = min(_max_workers_clamped, len(tuples))
        if n_workers < 2:
            return _refuse(
                f"effective worker count {n_workers} < 2 "
                f"(max_workers={max_workers}, tuples={len(tuples)}) — "
                "no parallelism to gain")

        def _tuple_weight(tup: Tuple[str, ...]) -> int:
            return len(grouped.get(tup, []))

        weighted = sorted(tuples, key=_tuple_weight, reverse=True)
        worker_load: List[int] = [0] * n_workers
        worker_tuples: List[List[Tuple[str, ...]]] = \
            [[] for _ in range(n_workers)]
        for tup in weighted:
            target = min(range(n_workers), key=lambda i: worker_load[i])
            worker_tuples[target].append(tup)
            worker_load[target] += _tuple_weight(tup)

        slices: List[Dict[str, Any]] = []
        for w_idx in range(n_workers):
            my_tuples = worker_tuples[w_idx]
            my_files: List[Any] = []
            for tup in my_tuples:
                my_files.extend(grouped.get(tup, []))
            slices.append({
                "partition_values": tuple(my_tuples),
                "files":            my_files,
                "tuple_count":      len(my_tuples),
                "total_files":      worker_load[w_idx],
            })

        # ── PROVE disjoint + complete before returning the plan ─────────
        _assert_slices_partition(slices, files)

        return ExchangePlan(
            splittable=True,
            tier="b0",
            shape=shape,
            key_columns=sorted(key_cols),
            partition_columns=list(partition_cols),
            table_name=table_name,
            slices=slices,
            n_workers=n_workers,
        )
    except Exception as exc:
        # ANY planner error refuses — single-worker is always correct.
        logger.debug("[exchange-b0] planning failed (fail-closed): %s", exc)
        return _refuse(f"planner error (fail-closed): {exc}")


# ═════════════════════════════════════════════════════════════════════════════
# Phase 2b — B1 hash-repartition local-spool exchange planning
# ═════════════════════════════════════════════════════════════════════════════
#
# B1 unlocks the SAME keyed shapes as B0 (exact COUNT(DISTINCT) / MEDIAN /
# percentile per group, window OVER (PARTITION BY k), aggregate HAVING) when
# the key is NOT hive-partition-aligned: rows are hash(K)-repartitioned into
# n_buckets via a per-execution LOCAL-DISK spool, each stage-2 worker owns a
# disjoint set of buckets (⇒ ALL rows for its keys), runs the ORIGINAL SQL
# verbatim, and the merge is a plain union.  The dispatcher tries B0 FIRST
# (zero-copy, cheaper); B1 only when B0 refuses.
#
# HONEST LIMITS (stay refused — hash exchange cannot unlock them):
#   * exact GLOBAL percentile / MEDIAN (no GROUP BY) — hash partitioning
#     destroys rank order (design matrix #6; needs a range exchange).
#   * windows with ORDER BY but no PARTITION BY (global total order, #9).
#   * key-less global COUNT(DISTINCT) — needs a final-SQL merge step, not a
#     plain union; deliberately out of B1 v1 (matrix #3e follow-on).

# Identifier discipline (fail-closed): every identifier B1 splices into
# stage-1/2 SQL must be a plain [A-Za-z_][A-Za-z0-9_]* name.  Anything else
# (quoted exotics, dots, unicode) refuses — single-worker is always correct.
_PLAIN_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

# The spool's private column — a query that touches it would collide.
_BUCKET_COL = "__qs_bucket"

# Non-deterministic function families.  The WHERE clause is evaluated in
# stage 1 (spool filter) AND again by the original SQL in stage 2 — a
# non-deterministic predicate would silently drop/keep different rows on the
# second pass ⇒ refuse.  Names compared underscore-insensitively.
_NONDET_FN_NAMES = {
    "random", "rand", "uuid", "uuidv4", "uuidv7", "genrandomuuid",
    "now", "today", "currentdate", "currenttime", "currenttimestamp",
    "currentlocaltime", "currentlocaltimestamp", "getcurrenttime",
    "getcurrenttimestamp", "transactiontimestamp", "statementtimestamp",
    "setseed",
}


def _norm_fn_name(name: str) -> str:
    return (name or "").replace("_", "").strip().lower()


def _b1_details(sql: str) -> Tuple[Optional[List[str]], str, str, str]:
    """B1-specific SQL facts: ``(referenced_columns, where_sql,
    real_table_name, refuse_reason)``.  ``referenced_columns`` is None on
    refusal (fail-closed).  Assumes ``_extract_exchange_key`` already
    accepted the statement (single plain-table SELECT, keyed shape)."""
    try:
        import sqlglot
        from sqlglot import exp
    except Exception:
        return None, "", "", "sqlglot unavailable — cannot prove projection"
    try:
        tree = sqlglot.parse_one(sql, read="duckdb")
    except Exception:
        return None, "", "", "SQL unparseable"
    if not isinstance(tree, exp.Select):
        return None, "", "", "not a plain SELECT"

    # ── real table name (NOT the alias — stage 1/2 recreate the view) ───
    from_arg = tree.args.get("from") or tree.args.get("from_")
    src = getattr(from_arg, "this", None) if from_arg is not None else None
    if not isinstance(src, exp.Table):
        return None, "", "", "FROM is not a single plain table"
    if src.args.get("db") or src.args.get("catalog"):
        return None, "", "", ("schema/catalog-qualified table — cannot "
                              "recreate the view name, refusing")
    table_name = src.name or ""
    if not _PLAIN_IDENT_RE.match(table_name):
        return None, "", "", (f"table name {table_name!r} is not a plain "
                              "identifier — refusing (fail-closed)")

    # ── SELECT * (outside aggregates) makes the projection unresolvable ─
    for star in tree.find_all(exp.Star):
        anc = star.parent
        inside_agg = False
        while anc is not None:
            if isinstance(anc, exp.AggFunc):
                inside_agg = True        # COUNT(*) — contributes no columns
                break
            anc = anc.parent
        if not inside_agg:
            return None, "", table_name, (
                "SELECT * — projection unresolvable, the spool would need "
                "every column (fail-closed)")

    # ── referenced columns (projection + WHERE + HAVING + windows) ──────
    cols: set = set()
    for c in tree.find_all(exp.Column):
        nm = (c.name or "")
        if not _PLAIN_IDENT_RE.match(nm):
            return None, "", table_name, (
                f"column {nm!r} is not a plain identifier — refusing")
        cols.add(nm.lower())
    if not cols:
        return None, "", table_name, "no referenced columns found — refusing"
    if _BUCKET_COL in cols:
        return None, "", table_name, (
            f"query references reserved column {_BUCKET_COL!r} — refusing")

    # ── WHERE: strip table qualifiers, refuse non-determinism ───────────
    where_sql = ""
    where_arg = tree.args.get("where")
    if where_arg is not None:
        where_copy = where_arg.copy()
        for fn in where_copy.find_all(exp.Func):
            candidates = {
                _norm_fn_name(getattr(fn, "key", "") or ""),
                _norm_fn_name(getattr(fn, "name", "") or ""),
                _norm_fn_name(type(fn).__name__),
            }
            try:
                candidates.add(_norm_fn_name(fn.sql_name()))
            except Exception:
                pass
            if candidates & _NONDET_FN_NAMES:
                return None, "", table_name, (
                    "WHERE contains a non-deterministic function — it would "
                    "be evaluated twice (stage 1 spool + stage 2 original "
                    "SQL) and silently lose rows; refusing (fail-closed)")
        for c in where_copy.find_all(exp.Column):
            # Single-table query ⇒ qualifiers are redundant; stage-1 SQL
            # runs against the bare chunk view.
            c.set("table", None)
        try:
            where_sql = where_copy.this.sql(dialect="duckdb")
        except Exception:
            return None, "", table_name, "WHERE clause unrenderable — refusing"

    return sorted(cols), where_sql, table_name, ""


def plan_exchange_b1(
    sql: str,
    files: List[Any],
    *,
    max_workers: int = 4,
    min_files: int = 200,
    bucket_factor: int = 2,
) -> ExchangePlan:
    """Tier-1 (B1) hash-repartition spool planning.  Fail-closed: any doubt
    returns splittable=False (⇒ the existing refusal stands ⇒ single-worker,
    always correct).  The dispatcher must try ``plan_exchange`` (B0) FIRST —
    B1 pays for row movement and should only run when B0 cannot align."""
    try:
        if not files:
            return _refuse("empty file list")
        if len(files) < max(1, int(min_files)):
            return _refuse(f"only {len(files)} files (<{min_files} "
                           "exchange_min_files threshold — single-worker/B0 "
                           "wins below the exchange overhead floor)")

        # ── SQL side: same keyed-shape gates as B0 ──────────────────────
        shape, key_cols, _alias, why = _extract_exchange_key(sql)
        if shape is None or key_cols is None:
            return _refuse(f"key extraction refused: {why}")

        ref_cols, where_sql, table_name, why2 = _b1_details(sql)
        if ref_cols is None:
            return _refuse(f"B1 projection/table extraction refused: {why2}")

        # Key columns must be plain identifiers too (hash(K…) is spliced).
        ordered_keys = sorted(key_cols)
        for k in ordered_keys:
            if not _PLAIN_IDENT_RE.match(k):
                return _refuse(f"key column {k!r} is not a plain identifier")
        missing = [k for k in ordered_keys if k not in set(ref_cols)]
        if missing:
            return _refuse(f"key column(s) {missing} not in the referenced-"
                           "column set — projection proof failed")

        # ── worker/bucket shape ─────────────────────────────────────────
        n_workers = min(max(1, int(max_workers)), len(files))
        if n_workers < 2:
            return _refuse(
                f"effective worker count {n_workers} < 2 "
                f"(max_workers={max_workers}, files={len(files)}) — "
                "no parallelism to gain")
        n_buckets = n_workers * max(1, int(bucket_factor))

        # ── stage-1 chunks: LPT by size when known, else spread by count.
        def _size_of(f: Any) -> int:
            try:
                if isinstance(f, dict):
                    return int(f.get("size") or f.get("bytes") or 0)
                p = str(f)
                if "://" not in p:
                    import os as _os
                    return int(_os.path.getsize(p))
            except Exception:
                pass
            return 0

        weighted = sorted(files, key=_size_of, reverse=True)
        loads = [0] * n_workers
        counts = [0] * n_workers
        buckets_files: List[List[Any]] = [[] for _ in range(n_workers)]
        for f in weighted:
            tgt = min(range(n_workers), key=lambda i: (loads[i], counts[i]))
            buckets_files[tgt].append(f)
            loads[tgt] += _size_of(f)
            counts[tgt] += 1

        slices: List[Dict[str, Any]] = [
            {"files": bf, "total_files": len(bf), "total_bytes": loads[i]}
            for i, bf in enumerate(buckets_files)
        ]

        # ── PROVE stage-1 chunks are a partition of the input files ─────
        _assert_slices_partition(slices, files)

        return ExchangePlan(
            splittable=True,
            tier="b1",
            shape=shape,
            key_columns=ordered_keys,
            partition_columns=[],
            table_name=table_name,
            slices=slices,
            n_workers=n_workers,
            n_buckets=n_buckets,
            referenced_columns=list(ref_cols),
            where_sql=where_sql,
        )
    except Exception as exc:
        # ANY planner error refuses — single-worker is always correct.
        logger.debug("[exchange-b1] planning failed (fail-closed): %s", exc)
        return _refuse(f"planner error (fail-closed): {exc}")
