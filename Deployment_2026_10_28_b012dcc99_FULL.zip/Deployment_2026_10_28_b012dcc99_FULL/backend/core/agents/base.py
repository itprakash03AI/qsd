"""
Base classes for QueryStudio self-healing agents.

Phase 120: Rule-based agent framework with swappable decision engine.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, Optional


class AgentAction(Enum):
    """Possible actions an agent can take."""
    RETRY_WITH_FIX = "retry_with_fix"
    NOTIFY_USER = "notify_user"
    LOG_AND_SKIP = "log_and_skip"
    ESCALATE = "escalate"


@dataclass
class AgentDecision:
    """Result of an agent's decide() call."""
    action: AgentAction
    reason: str
    fix_applied: Optional[str] = None
    retry_params: Optional[Dict[str, Any]] = None
    confidence: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        # Clamp confidence to [0.0, 1.0]
        self.confidence = max(0.0, min(1.0, float(self.confidence)))


class BaseAgent(ABC):
    """Abstract base class for all QueryStudio agents.

    Each agent follows an observe → decide → act lifecycle:
    1. ``can_handle(event)`` — does this agent care about this event?
    2. ``decide(event, context)`` — analyze + return a decision
    3. ``act(decision, event, context)`` — execute the decision
    4. ``observe_result(decision, result)`` — optional learning hook
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique agent identifier (e.g. 'query_resilience')."""

    @property
    @abstractmethod
    def description(self) -> str:
        """Human-readable description."""

    @abstractmethod
    def can_handle(self, event: Dict[str, Any]) -> bool:
        """Return True if this agent can handle the given event."""

    @abstractmethod
    def decide(self, event: Dict[str, Any], context: Dict[str, Any]) -> AgentDecision:
        """Analyze event + context, return a decision."""

    @abstractmethod
    def act(self, decision: AgentDecision, event: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the decision.  Returns result dict."""

    def observe_result(self, decision: AgentDecision, result: Dict[str, Any]) -> None:
        """Optional: learn from outcome (for future rule tuning).  Default no-op."""
