"""
QueryStudio Self-Healing Agents — Phase 120.

Three autonomous agents that observe, decide, and act:
  1. QueryResilienceAgent — auto-fix + retry failed queries
  2. DQMonitorAgent       — autonomous data quality profiling
  3. DataPipelineAgent    — auto-profile uploaded files

Usage::

    from core.agents import get_orchestrator, init_orchestrator

    # At startup (main.py)
    init_orchestrator(config_dict, db_manager)

    # On query failure (execute_api.py)
    orch = get_orchestrator()
    if orch:
        result = orch.handle_event("query_failed", {...})
"""

from .base import AgentAction, AgentDecision, BaseAgent
from .orchestrator import get_orchestrator, init_orchestrator

__all__ = [
    "AgentAction",
    "AgentDecision",
    "BaseAgent",
    "get_orchestrator",
    "init_orchestrator",
]
