"""The agent suggestion a FAILED query carries to the screen -- one answer, every road.

2026-10-07.  "Which fix strategy is this error?" is decided by the rules
engine (``core.agents.decision_engine.RulesEngine``).  Four roads report a
failed query to the user:

  * the pre-validation refusal of ``POST /api/execute`` (HTTP 400, detail
    ``{type: sql_pre_validation_failed, error, agent_suggestion}``);
  * ``execute_query_background`` (DuckDB / S3 / local -- WebSocket
    ``execution_failed``);
  * ``execute_sql_connector_background`` (Trino / Starburst / Snowflake /
    Oracle / Databricks behind ``/api/execute``);
  * ``execute_cross_query_background`` and ``/api/sql/execute``.

Only the first two attached a suggestion, and the second only when the
orchestrator was ENABLED (``agents.enabled`` defaults false) -- so the
query builder grew its own regex copy of the patterns to fill the gap,
which knew DuckDB's wording and nothing else.  A Trino user never saw "Add
GROUP BY clause".  Every road now asks THIS function, the frontend renders
what it is sent and decides nothing.

The orchestrator's answer wins when it gave one (it may run a different
engine); otherwise the rules engine classifies the error, exactly as the
pre-validation refusal always did.  ``None`` means the engine has no
strategy for this error -- never a guess.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

AGENT_NAME = "query_resilience"


def strategy_of_agent_result(agent_result: Optional[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """The (strategy, reason, cte_analysis) an orchestrator result names, or None.

    The orchestrator answers in two shapes (BF-242): RETRY_WITH_FIX
    ``{"retrying": True, "strategy", "reason"}`` and NOTIFY_USER
    ``{"action": "notify", "metadata": {"strategy", "description"}}``.
    """
    if not isinstance(agent_result, dict):
        return None
    meta = agent_result.get("metadata") or {}
    strategy = agent_result.get("strategy") or meta.get("strategy")
    if not strategy or strategy == "none":
        return None
    out: Dict[str, Any] = {
        "agent": AGENT_NAME,
        "strategy": strategy,
        "reason": agent_result.get("reason") or meta.get("description") or "",
    }
    cte = ((agent_result.get("retry_params") or {}).get("cte_analysis")
           or agent_result.get("cte_analysis") or meta.get("cte_analysis"))
    if cte:
        out["cte_analysis"] = cte
    return out


def suggestion_for_failure(error_message: str, error_type: str = "",
                           *, db_manager: Any = None,
                           agent_result: Optional[Dict[str, Any]] = None,
                           ) -> Optional[Dict[str, Any]]:
    """``{agent, strategy, reason}`` for a failed query, or None.

    Never raises: a classification failure must not turn a query failure
    into a different failure.  It is logged and the road reports the error
    without a suggestion.
    """
    from_orchestrator = strategy_of_agent_result(agent_result)
    if from_orchestrator is not None:
        return from_orchestrator
    if not error_message:
        return None
    try:
        from core.agents.decision_engine import RulesEngine
        verdict = RulesEngine(db_manager=db_manager).classify_error(
            str(error_message), error_type or "", {})
    except Exception as exc:
        logger.warning("agent suggestion: the rules engine could not classify "
                       "the error (%s: %s) -- reported without a suggestion",
                       type(exc).__name__, exc)
        return None
    strategy = (verdict or {}).get("strategy")
    if not strategy or strategy == "none":
        return None
    return {
        "agent": AGENT_NAME,
        "strategy": strategy,
        "reason": (verdict or {}).get("description", "") or "",
    }
