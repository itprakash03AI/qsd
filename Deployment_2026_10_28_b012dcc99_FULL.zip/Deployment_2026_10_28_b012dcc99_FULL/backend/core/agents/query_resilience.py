"""
Query Resilience Agent — auto-fix and retry failed queries.

Phase 120: Classifies query errors via the decision engine and applies
fix strategies (partition filter, credential refresh, memory reduction, etc.).
"""

import logging
from typing import Any, Dict, Optional

from .base import AgentAction, AgentDecision, BaseAgent
from .decision_engine import DecisionEngine

logger = logging.getLogger(__name__)


class QueryResilienceAgent(BaseAgent):
    """Auto-diagnoses and retries failed queries based on error classification."""

    def __init__(self, engine: DecisionEngine, config: Dict[str, Any]):
        self._engine = engine
        self._config = config.get("query_resilience", {})
        self._max_retries = self._config.get("max_retries", 2)
        self._backoff = self._config.get("backoff_seconds", 5)

    @property
    def name(self) -> str:
        return "query_resilience"

    @property
    def description(self) -> str:
        return "Automatically diagnoses and retries failed queries"

    def can_handle(self, event: Dict[str, Any]) -> bool:
        return event.get("type") == "query_failed"

    def decide(self, event: Dict[str, Any], context: Dict[str, Any]) -> AgentDecision:
        error_msg = event.get("error_message", "")
        error_type = event.get("error_type", "")

        classification = self._engine.classify_error(error_msg, error_type, context)
        strategy = classification.get("strategy", "none")
        max_retries = min(classification.get("max_retries", 0), self._max_retries)

        # Strategy disabled in config?
        if not self._is_strategy_enabled(strategy):
            return AgentDecision(
                action=AgentAction.LOG_AND_SKIP,
                reason=f"Strategy '{strategy}' disabled in config",
                confidence=classification.get("confidence", 0.0),
                metadata=classification,
            )

        # No retry for this error type
        if max_retries <= 0:
            return AgentDecision(
                action=AgentAction.NOTIFY_USER,
                reason=classification.get("description", "Non-retryable error"),
                confidence=classification.get("confidence", 0.0),
                metadata=classification,
            )

        # Max retries exceeded?
        retry_count = event.get("retry_count", 0)
        if retry_count >= max_retries:
            return AgentDecision(
                action=AgentAction.ESCALATE,
                reason=f"Max retries ({max_retries}) reached for strategy '{strategy}'",
                confidence=1.0,
                metadata=classification,
            )

        # Apply fix strategy
        fix_result = self._apply_fix(strategy, event, context)
        if fix_result:
            return AgentDecision(
                action=AgentAction.RETRY_WITH_FIX,
                reason=classification.get("description", ""),
                fix_applied=strategy,
                retry_params=fix_result,
                confidence=classification.get("confidence", 1.0),
                metadata=classification,
            )

        return AgentDecision(
            action=AgentAction.LOG_AND_SKIP,
            reason=f"Fix strategy '{strategy}' returned no actionable result",
            confidence=0.0,
            metadata=classification,
        )

    def act(self, decision: AgentDecision, event: Dict[str, Any],
            context: Dict[str, Any]) -> Dict[str, Any]:
        """Return retry params — the caller (execute_api) handles the actual retry."""
        return {
            "retrying": True,
            "strategy": decision.fix_applied,
            "reason": decision.reason,
            "retry_params": decision.retry_params or {},
            "backoff_seconds": self._backoff,
            "retry_count": event.get("retry_count", 0) + 1,
        }

    def _is_strategy_enabled(self, strategy: str) -> bool:
        """Check if a strategy is enabled in config."""
        strategy_config_map = {
            "add_partition_filter": "auto_add_partition_filter",
            "refresh_credentials": "auto_refresh_credentials",
            "reinstall_extension": "auto_reinstall_extensions",
            "reduce_memory": "auto_reduce_memory",
        }
        config_key = strategy_config_map.get(strategy)
        if config_key:
            return self._config.get(config_key, True)
        # Strategies without explicit toggles are always enabled
        return True

    def _apply_fix(self, strategy: str, event: Dict[str, Any],
                   context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Dispatch to the appropriate fix function."""
        dispatch = {
            "add_partition_filter": self._fix_add_partition_filter,
            "refresh_credentials": self._fix_refresh_credentials,
            "reinstall_extension": self._fix_reinstall_extension,
            "reduce_memory": self._fix_reduce_memory,
            "refresh_schema": self._fix_refresh_schema,
            "retry_with_backoff": self._fix_retry_with_backoff,
            # BF-280 / BF-283: SQL-rewrite strategies — the actual rewrite
            # is performed by api.execute_api._apply_agent_fix which calls
            # sql_auto_fix.  We just need to return a non-None payload here
            # so the orchestrator emits AgentAction.RETRY_WITH_FIX (and the
            # caller dispatches the rewritten retry).
            "qualify_ambiguous_columns": self._fix_external_sql_rewrite,
            "add_group_by":              self._fix_external_sql_rewrite,
        }
        fn = dispatch.get(strategy)
        if fn:
            try:
                return fn(event, context)
            except Exception as exc:
                logger.warning("Fix strategy '%s' failed: %s", strategy, exc)
                return None
        return None


    def _fix_external_sql_rewrite(self, event: Dict, context: Dict) -> Optional[Dict]:
        """BF-280 / BF-283: stub that signals "the actual SQL rewrite
        will be applied by execute_api._apply_agent_fix via sql_auto_fix".
        Returning a non-None dict makes the orchestrator emit
        RETRY_WITH_FIX so the dispatch flow reaches that handler."""
        return {"rewrite_via": "sql_auto_fix"}

    # ── Fix Strategies ────────────────────────────────────────────────────

    def _fix_add_partition_filter(self, event: Dict, context: Dict) -> Optional[Dict]:
        """Suggest retry with reduced scope — CTE-aware partition analysis.

        Phase 122D: When raw_sql contains CTEs, analyze which base tables
        are missing partition filters and suggest specific columns.
        """
        query_config = event.get("query_config", {})
        raw_sql = event.get("raw_sql", "") or query_config.get("raw_sql", "")

        # Phase 122D: CTE-aware partition analysis
        if raw_sql and self._config.get("cte_partition_analysis", True):
            try:
                from core.sql_partition_extractor import analyze_cte_partition_needs
                # Build partition_columns from event context
                _part_cols = self._get_partition_columns(event, context)
                if _part_cols:
                    cte_analysis = analyze_cte_partition_needs(raw_sql, _part_cols)
                    if cte_analysis:
                        _table_hints = ", ".join(
                            f"{t}({', '.join(cs)})" for t, cs in cte_analysis.items()
                        )
                        return {
                            "suggestion": "add_partition_filter",
                            "cte_analysis": cte_analysis,
                            "original_query_config": query_config,
                            "message": f"CTE query timed out. Base tables needing "
                                       f"partition filters: {_table_hints}",
                        }
            except Exception as exc:
                logger.debug("CTE partition analysis failed (falling through): %s", exc)

        return {
            "suggestion": "add_partition_filter",
            "original_query_config": query_config,
            "message": "Query timed out — consider adding partition filters",
        }

    def _get_partition_columns(self, event: Dict, context: Dict) -> Dict:
        """Extract partition_columns dict from event context for CTE analysis."""
        # Try registered tables from event
        tables = event.get("tables", [])
        query_config = event.get("query_config", {})
        registered = query_config.get("registered_tables") or []

        part_cols = {}
        for rt in registered:
            if isinstance(rt, dict):
                name = rt.get("name", "")
                pcols = rt.get("partition_columns", [])
                if name and pcols:
                    part_cols[name] = pcols
        return part_cols

    def _fix_refresh_credentials(self, event: Dict, context: Dict) -> Optional[Dict]:
        """Signal that presigned URLs / STS tokens should be refreshed before retry."""
        return {
            "suggestion": "refresh_credentials",
            "connection_id": event.get("connection_id"),
            "message": "S3 token expired — refreshing credentials for retry",
        }

    def _fix_reinstall_extension(self, event: Dict, context: Dict) -> Optional[Dict]:
        """Signal DuckDB extension reinstall needed."""
        return {
            "suggestion": "reinstall_extension",
            "message": "DuckDB extension missing — will reinstall on retry",
        }

    def _fix_reduce_memory(self, event: Dict, context: Dict) -> Optional[Dict]:
        """Reduce row limit to lower memory pressure."""
        query_config = event.get("query_config", {})
        current_limit = query_config.get("row_limit", 100000)
        new_limit = min(current_limit, 10000)
        return {
            "suggestion": "reduce_memory",
            "original_row_limit": current_limit,
            "new_row_limit": new_limit,
            "message": f"OOM — reducing row limit from {current_limit} to {new_limit}",
        }

    def _fix_refresh_schema(self, event: Dict, context: Dict) -> Optional[Dict]:
        """Signal schema cache invalidation needed."""
        return {
            "suggestion": "refresh_schema",
            "connection_id": event.get("connection_id"),
            "message": "Column mismatch — schema cache will be refreshed on retry",
        }

    def _fix_retry_with_backoff(self, event: Dict, context: Dict) -> Optional[Dict]:
        """Simple backoff retry for transient network errors."""
        return {
            "suggestion": "retry_with_backoff",
            "backoff_seconds": self._backoff,
            "message": "Transient network error — retrying with backoff",
        }
