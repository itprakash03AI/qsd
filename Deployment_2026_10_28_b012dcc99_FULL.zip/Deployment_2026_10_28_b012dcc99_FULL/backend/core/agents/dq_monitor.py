"""
Data Quality Monitor Agent — autonomous profiling and anomaly detection.

Phase 120: Runs on schedule (APScheduler), profiles tables, compares to
baselines, and dispatches DQ alerts via the existing alerting infrastructure.
"""

import logging
from typing import Any, Dict, List

from .base import AgentAction, AgentDecision, BaseAgent
from .decision_engine import DecisionEngine

logger = logging.getLogger(__name__)

# Strong references to in-flight alert webhooks -- see the create_task
# call below.  Entries remove themselves via add_done_callback.
_DQ_WEBHOOK_TASKS: set = set()


class DQMonitorAgent(BaseAgent):
    """Periodically profiles data sources and detects anomalies."""

    def __init__(self, engine: DecisionEngine, config: Dict[str, Any]):
        self._engine = engine
        self._config = config.get("dq_monitor", {})

    @property
    def name(self) -> str:
        return "dq_monitor"

    @property
    def description(self) -> str:
        return "Periodically profiles data sources and detects anomalies"

    def can_handle(self, event: Dict[str, Any]) -> bool:
        return event.get("type") in ("dq_scheduled_scan", "dq_manual_scan")

    def decide(self, event: Dict[str, Any], context: Dict[str, Any]) -> AgentDecision:
        """Collect anomalies from context and evaluate via decision engine."""
        anomalies = event.get("anomalies", [])

        # If this is a scheduled scan, anomalies may not be pre-populated.
        # In production the orchestrator's run_dq_monitor() would profile tables
        # and populate anomalies before calling decide(). For now, pass through.

        evaluation = self._engine.evaluate_dq(anomalies, context)

        if evaluation.get("action") == "none":
            return AgentDecision(
                action=AgentAction.LOG_AND_SKIP,
                reason=evaluation.get("message", "No anomalies detected"),
                confidence=evaluation.get("confidence", 1.0),
                metadata=evaluation,
            )

        severity = evaluation.get("severity", "info")
        triggered = evaluation.get("triggered_rules", [])

        if severity == "critical":
            return AgentDecision(
                action=AgentAction.NOTIFY_USER,
                reason=f"Critical DQ issue: {evaluation.get('message', '')}",
                confidence=evaluation.get("confidence", 1.0),
                metadata={**evaluation, "anomalies": anomalies},
            )

        if triggered:
            return AgentDecision(
                action=AgentAction.NOTIFY_USER,
                reason=f"{len(triggered)} DQ rule(s) triggered",
                confidence=evaluation.get("confidence", 1.0),
                metadata={**evaluation, "anomalies": anomalies},
            )

        return AgentDecision(
            action=AgentAction.LOG_AND_SKIP,
            reason="Anomalies below thresholds",
            confidence=evaluation.get("confidence", 1.0),
            metadata=evaluation,
        )

    def act(self, decision: AgentDecision, event: Dict[str, Any],
            context: Dict[str, Any]) -> Dict[str, Any]:
        """Dispatch alerts for triggered DQ rules.

        Phase 125: Real alert dispatch via notification queue + webhooks.
        1) Enqueue in-app notifications (delivered via notification_poller → WebSocket)
        2) Fire webhooks for external integrations (Slack, Teams, generic)
        """
        triggered = decision.metadata.get("triggered_rules", [])
        alerts_sent = 0
        db = context.get("db_manager")
        _do_notify = self._config.get("notify_admins", True)
        _do_webhook = self._config.get("webhooks_enabled", True)

        for rule_hit in triggered:
            try:
                logger.info("DQ Agent alert: %s (severity=%s, column=%s, table=%s)",
                            rule_hit.get("message"), rule_hit.get("severity"),
                            rule_hit.get("column"), rule_hit.get("table"))

                # 1) Enqueue in-app notification for admin users
                if db and _do_notify:
                    try:
                        from core.notification_queue import enqueue
                        enqueue(db.session_factory, {
                            "type": "dq_alert",
                            "severity": rule_hit.get("severity", "warning"),
                            "title": f"Data Quality: {(rule_hit.get('severity') or 'warning').title()}",
                            "message": rule_hit.get("message", ""),
                            "table": rule_hit.get("table", ""),
                            "column": rule_hit.get("column", ""),
                            "metric": rule_hit.get("metric", ""),
                            "actual_value": rule_hit.get("actual_value"),
                            "threshold": rule_hit.get("threshold"),
                        })
                    except Exception as nq_exc:
                        logger.debug("DQ notification enqueue failed: %s", nq_exc)

                # 2) Fire webhooks for external integrations
                if db and _do_webhook:
                    try:
                        from core.webhook_dispatcher import fire_webhooks
                        import asyncio
                        _payload = {
                            "severity": rule_hit.get("severity"),
                            "message": rule_hit.get("message"),
                            "table": rule_hit.get("table"),
                            "column": rule_hit.get("column"),
                            "metric": rule_hit.get("metric"),
                            "actual_value": rule_hit.get("actual_value"),
                        }
                        try:
                            _loop = asyncio.get_running_loop()
                            # 2026-08-17: keep a STRONG reference.  The loop
                            # holds only a weak one, so a fire-and-forget
                            # alert webhook could be garbage-collected before
                            # it ran (CPython #88831) -- the alert would
                            # simply never arrive, silently.
                            # NOT core.bg_tasks.track_bg_task here: that wraps
                            # asyncio.create_task, and this is a SYNC agent
                            # method whose own docstring warns sync callers
                            # off it.  Scheduling on the loop we just resolved
                            # keeps the existing semantics exactly.
                            _t = _loop.create_task(fire_webhooks(
                                "dq_alert", None, _payload, db))
                            _DQ_WEBHOOK_TASKS.add(_t)
                            _t.add_done_callback(_DQ_WEBHOOK_TASKS.discard)
                        except RuntimeError:
                            # No running event loop — skip async webhook
                            logger.debug("DQ webhook skipped: no running event loop")
                    except Exception as wh_exc:
                        logger.debug("DQ webhook dispatch failed: %s", wh_exc)

                alerts_sent += 1
            except Exception as exc:
                logger.warning("Failed to dispatch DQ alert: %s", exc)

        return {
            "agent": self.name,
            "alerts_sent": alerts_sent,
            "triggered_rules": len(triggered),
            "reason": decision.reason,
        }

    def profile_table(self, table_name: str, connection_id: int,
                      duckdb_con=None) -> Dict[str, Any]:
        """Profile a single table — returns stats dict.

        This method is available for the API endpoint to call for manual
        one-off profiling.  Returns basic stats (row_count, columns, null counts).
        """
        if duckdb_con is None:
            return {"error": "No DuckDB connection provided"}

        try:
            from core.file_formats import get_format_adapter, is_supported_extension
            import os

            # Normalize backslashes for DuckDB SQL (Windows paths with \t, \n break)
            table_name = table_name.replace("\\", "/")

            ext = os.path.splitext(table_name)[1].lower()
            if ext and is_supported_extension(ext):
                adapter = get_format_adapter(ext)
                read_expr = adapter.duckdb_read_expr(table_name)
            else:
                # Escape single quotes in path for DuckDB SQL
                read_expr = f"read_parquet('{table_name.replace(chr(39), chr(39)+chr(39))}')"

            # Row count
            row_count = duckdb_con.execute(
                f"SELECT COUNT(*) FROM {read_expr}"
            ).fetchone()[0]

            # Column metadata
            cols = duckdb_con.execute(
                f"DESCRIBE SELECT * FROM {read_expr}"
            ).fetchall()

            columns = {}
            for col_name, col_type, *_ in cols:
                null_count = duckdb_con.execute(
                    f'SELECT COUNT(*) FROM {read_expr} WHERE "{col_name}" IS NULL'
                ).fetchone()[0]
                columns[col_name] = {
                    "type": col_type,
                    "null_count": null_count,
                    "null_pct": null_count / max(row_count, 1),
                }

            return {
                "table_name": table_name,
                "connection_id": connection_id,
                "row_count": row_count,
                "col_count": len(cols),
                "columns": columns,
            }
        except Exception as exc:
            logger.warning("Failed to profile table '%s': %s", table_name, exc)
            return {"error": str(exc), "table_name": table_name}

    def compare_to_baseline(self, current: Dict[str, Any],
                            baseline: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Compare current profile to baseline, return list of anomalies.

        Thresholds are config-driven via the decision engine (dq_monitor section).
        """
        anomalies: List[Dict[str, Any]] = []
        if not baseline or not current:
            return anomalies

        # Config-driven thresholds (from decision engine)
        _drop = self._config.get("row_count_drop_threshold", 0.3)
        _spike = self._config.get("row_count_spike_threshold", 3.0)
        _null_delta = self._config.get("null_delta_threshold", 0.2)
        _null_abs = self._config.get("null_threshold", 0.5)

        # Row count ratio
        baseline_rows = baseline.get("row_count", 0)
        current_rows = current.get("row_count", 0)
        if baseline_rows > 0:
            ratio = current_rows / baseline_rows
            if ratio < _drop or ratio > _spike:
                anomalies.append({"metric": "row_count_ratio", "value": ratio})

        # Per-column checks
        baseline_cols = set(baseline.get("columns", {}).keys())
        current_cols = set(current.get("columns", {}).keys())

        # New columns
        added = current_cols - baseline_cols
        if added:
            anomalies.append({"metric": "schema_columns_added", "value": len(added),
                              "column": ", ".join(sorted(added))})

        # Removed columns
        removed = baseline_cols - current_cols
        if removed:
            anomalies.append({"metric": "schema_columns_removed", "value": len(removed),
                              "column": ", ".join(sorted(removed))})

        # Null % delta
        for col in current_cols & baseline_cols:
            curr_null = current["columns"][col].get("null_pct", 0)
            base_null = baseline["columns"][col].get("null_pct", 0)
            delta = curr_null - base_null
            if delta > _null_delta:
                anomalies.append({"metric": "null_pct_delta", "value": delta, "column": col})
            if curr_null > _null_abs:
                anomalies.append({"metric": "null_pct", "value": curr_null, "column": col})

        return anomalies
