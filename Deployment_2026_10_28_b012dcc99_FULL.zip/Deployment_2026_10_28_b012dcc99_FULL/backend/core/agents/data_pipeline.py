"""
Data Pipeline Agent — auto-profile uploaded files and suggest improvements.

Phase 120: Runs after file upload, profiles columns, detects data quality
issues (high nulls, numeric-as-text, etc.), and notifies the user.
"""

import logging
from typing import Any, Dict, List

from .base import AgentAction, AgentDecision, BaseAgent
from .decision_engine import DecisionEngine

logger = logging.getLogger(__name__)


class DataPipelineAgent(BaseAgent):
    """Profiles new data uploads and suggests quality improvements."""

    def __init__(self, engine: DecisionEngine, config: Dict[str, Any]):
        self._engine = engine
        self._config = config.get("data_pipeline", {})

    @property
    def name(self) -> str:
        return "data_pipeline"

    @property
    def description(self) -> str:
        return "Profiles new data uploads and suggests quality improvements"

    def can_handle(self, event: Dict[str, Any]) -> bool:
        return event.get("type") == "file_uploaded"

    def decide(self, event: Dict[str, Any], context: Dict[str, Any]) -> AgentDecision:
        if not self._config.get("auto_profile_uploads", True):
            return AgentDecision(
                action=AgentAction.LOG_AND_SKIP,
                reason="Auto-profiling disabled in config",
                confidence=1.0,
                metadata={},
            )

        file_path = event.get("file_path", "")
        if not file_path:
            return AgentDecision(
                action=AgentAction.LOG_AND_SKIP,
                reason="No file path in event",
                confidence=1.0,
                metadata={},
            )

        profile = self._profile_file(file_path)
        issues = profile.get("issues", [])

        if not issues:
            return AgentDecision(
                action=AgentAction.LOG_AND_SKIP,
                reason="No data quality issues detected in upload",
                confidence=1.0,
                metadata={"profile": profile},
            )

        return AgentDecision(
            action=AgentAction.NOTIFY_USER,
            reason=f"Found {len(issues)} data quality issue(s) in uploaded file",
            confidence=1.0,
            metadata={"profile": profile, "issues": issues},
        )

    def act(self, decision: AgentDecision, event: Dict[str, Any],
            context: Dict[str, Any]) -> Dict[str, Any]:
        """Return profiling results to caller — displayed as upload feedback."""
        return {
            "agent": self.name,
            "file_path": event.get("file_path"),
            "table_name": event.get("table_name"),
            "issues": decision.metadata.get("issues", []),
            "profile": decision.metadata.get("profile", {}),
            "reason": decision.reason,
        }

    def _profile_file(self, file_path: str) -> Dict[str, Any]:
        """Quick profile of an uploaded file using DuckDB."""
        try:
            import os
            from core.duckdb_factory import duckdb_connection
            from core.file_formats import get_format_adapter, is_supported_extension

            # Normalize backslashes for DuckDB SQL (Windows paths with \t, \n break)
            file_path = file_path.replace("\\", "/")

            ext = os.path.splitext(file_path)[1].lower()
            if not ext or not is_supported_extension(ext):
                return {"row_count": 0, "col_count": 0, "columns": [], "issues": []}

            adapter = get_format_adapter(ext)
            with duckdb_connection() as con:
                if adapter.needs_duckdb:
                    adapter.setup_duckdb(con)
                read_expr = adapter.duckdb_read_expr(file_path)

                # Row count
                row_count = con.execute(
                    f"SELECT COUNT(*) FROM {read_expr}"
                ).fetchone()[0]

                # Column metadata
                cols_raw = con.execute(
                    f"DESCRIBE SELECT * FROM {read_expr}"
                ).fetchall()

                issues: List[Dict[str, Any]] = []
                columns = []
                for col_name, col_type, *_ in cols_raw:
                    null_count = con.execute(
                        f'SELECT COUNT(*) FROM {read_expr} WHERE "{col_name}" IS NULL'
                    ).fetchone()[0]
                    null_pct = null_count / max(row_count, 1)

                    columns.append({
                        "name": col_name,
                        "type": col_type,
                        "null_pct": round(null_pct, 4),
                    })

                    # High null detection
                    if null_pct > 0.5:
                        issues.append({
                            "type": "high_nulls",
                            "column": col_name,
                            "null_pct": round(null_pct, 4),
                            "message": f"Column '{col_name}' has {null_pct:.0%} null values",
                        })

                    # Numeric-as-text detection
                    if self._config.get("suggest_type_fixes", True) and col_type == "VARCHAR":
                        if self._is_numeric_column(con, read_expr, col_name):
                            issues.append({
                                "type": "numeric_as_text",
                                "column": col_name,
                                "message": f"Column '{col_name}' appears numeric but stored as text",
                            })

                return {
                    "row_count": row_count,
                    "col_count": len(cols_raw),
                    "columns": columns,
                    "issues": issues,
                }
        except Exception as exc:
            logger.warning("Failed to profile file '%s': %s", file_path, exc)
            return {"row_count": 0, "col_count": 0, "columns": [], "issues": [],
                    "error": str(exc)}

    @staticmethod
    def _is_numeric_column(con, read_expr: str, col_name: str) -> bool:
        """Check if a VARCHAR column actually contains numeric data."""
        try:
            con.execute(
                f'SELECT CAST("{col_name}" AS DOUBLE) FROM {read_expr} '
                f'WHERE "{col_name}" IS NOT NULL LIMIT 10'
            )
            return True
        except Exception:
            return False
