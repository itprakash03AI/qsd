"""
Decision engines for QueryStudio agents.

Phase 120: Rules-based engine (default) with LLM engine scaffold.
The ``DecisionEngine`` ABC defines the interface; ``RulesEngine`` is the
production implementation.  ``LLMEngine`` is a disabled scaffold for future
Claude/OpenAI integration.
"""

import logging
import re
import threading
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

# BF-414 follow-up — module-level lock that guards lazy-init of per-instance
# ``_rate_lock`` for LLMEngine instances created via ``LLMEngine.__new__``
# (used by some legacy test fixtures).  Without this, two threads could
# both miss the attr on the same instance and each create a separate Lock,
# overwriting each other's assignment and ending up with no actual mutual
# exclusion.  Production code (which goes through ``__init__``) never
# triggers the lazy-init path, but the guard is cheap and removes the race.
_LLM_LAZY_INIT_LOCK = threading.Lock()

logger = logging.getLogger(__name__)


class DecisionEngine(ABC):
    """Interface for agent decision-making — rules or LLM."""

    @abstractmethod
    def classify_error(self, error_msg: str, error_type: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Classify a query error and suggest a fix strategy.

        Returns dict with keys: strategy, description, max_retries, confidence, source.
        """

    @abstractmethod
    def evaluate_dq(self, anomalies: List[Dict[str, Any]], context: Dict[str, Any]) -> Dict[str, Any]:
        """Given detected anomalies, decide severity and action.

        Returns dict with keys: action, severity, message, confidence, source.
        """


# ── Error classification rules ───────────────────────────────────────────────

# Phase 142+: each pattern is now multi-dialect — alternates for DuckDB,
# Trino/Starburst, Snowflake, Databricks (Spark), Oracle, Athena, and REST/
# generic HTTP error shapes.  Order matters: more-specific rules MUST come
# before "binder error" and other generic catch-alls or they'll be shadowed.
QUERY_FIX_RULES: List[Dict[str, Any]] = [
    {
        # DB lock / deadlock: PostgreSQL/SQLite/Oracle/MySQL lock contention
        # under concurrent writes.  MUST come BEFORE the generic timeout rule
        # — error messages like "Lock wait timeout" contain the substring
        # "timeout" and would otherwise be misclassified.
        "pattern": (
            r"deadlock detected|deadlock found|"
            r"lock wait timeout|could not obtain lock|"
            r"database is locked|"
            r"ora-00060|ora-00054|"
            r"resource busy"
        ),
        "strategy": "retry_with_backoff",
        "description": (
            "DB lock/deadlock — retry with backoff.  If persistent, lower "
            "concurrent write fan-out or batch upserts"
        ),
        "max_retries": 2,
    },
    {
        # Timeout: DuckDB cancels via cancel_event, Trino "Query exceeded the
        # maximum execution time of …s", Snowflake "Statement reached its
        # statement timeout limit", Oracle ORA-01013, HTTP 408.  IMPORTANT:
        # match only TIME-related "exceeded" so we don't shadow OOM's
        # "Query exceeded per-node memory limit".  Lock-timeout rule above
        # claims those before this one.
        "pattern": (
            r"timeout|exceeded \d+ ?s|cancelled after|"
            r"query exceeded.*(execution time|time limit|\d+ ?(s|sec|min))|"
            r"statement.*timeout|"
            r"ora-01013|user requested cancel|"
            r"http 408|408 request timeout"
        ),
        "strategy": "add_partition_filter",
        "description": "Query timed out — add partition filter to reduce scan",
        "max_retries": 1,
    },
    {
        # Expired credentials: AWS/S3 STS, Snowflake auth token, Oracle ORA-01017.
        "pattern": (
            r"expiredtoken|expired token|token.*expired|"
            r"authentication token has expired|"
            r"ora-01017|invalid username/password|"
            r"http 401|401 unauthorized|"
            r"signature.*expired|requesttimetoo(skewed|new)"
        ),
        "strategy": "refresh_credentials",
        "description": "Auth/credentials expired — refresh and retry",
        "max_retries": 2,
    },
    {
        "pattern": r"extension.*not found|failed to load|extension is unknown",
        "strategy": "reinstall_extension",
        "description": "DuckDB extension missing — install and retry",
        "max_retries": 1,
    },
    {
        # Result set too large — Snowflake's "size of the result set is too
        # large" + similar.  Distinct from OOM: the warehouse can compute the
        # result, the client just can't fetch it.  Fix is LIMIT or paginate.
        # MUST come BEFORE the OOM rule below.
        "pattern": (
            r"size of the result set is too large|"
            r"result set is too large to be returned|"
            r"max result size exceeded|"
            r"response size exceeded"
        ),
        "strategy": "reduce_memory",
        "description": (
            "Result set too large for client fetch — add a LIMIT N to the "
            "query or use streaming/pagination (offset+limit)"
        ),
        "max_retries": 1,
    },
    {
        # OOM: DuckDB, Trino "Query exceeded per-node memory", Spark
        # "OutOfMemoryError".  (Snowflake's result-too-large is handled by
        # the more-specific rule above.)
        "pattern": (
            r"out of memory|memory limit|allocation.*failed|"
            r"exceeded per-node memory|"
            r"java\.lang\.outofmemoryerror|outofmemoryerror|"
            r"ora-04030|out of process memory"
        ),
        "strategy": "reduce_memory",
        "description": "OOM — reduce row limit to lower memory usage",
        "max_retries": 1,
    },
    {
        # GROUP BY: DuckDB "must appear in GROUP BY", Trino "must be a constant
        # or aggregate", Snowflake "is not a valid group by expression",
        # Spark "is not in the GROUP BY clause", Oracle ORA-00979.
        # BF-237/BF-283: must come BEFORE the generic "binder error" rule.
        # 2026-10-07: Trino/Starburst's EXPRESSION_NOT_AGGREGATE reads
        # "'x' must be an aggregate expression or appear in GROUP BY clause"
        # -- no "the", so none of the alternates above matched it and a
        # Trino user never saw "Add GROUP BY clause".  Its error NAME is
        # matched too: the sentence is Trino's to reword, the name is API.
        "pattern": (
            r"must appear in the group by clause|"
            r"must be part of an aggregate function|"
            r"aggregate functions.*must.*group by|"
            r"is not a valid group by expression|"
            r"is not in the group by clause|"
            r"not a grouping column|"
            r"ora-00979|not a group by expression|"
            r"must be a constant or aggregate|"
            r"must be an aggregate expression or appear in group by|"
            r"expression_not_aggregate"
        ),
        "strategy": "add_group_by",
        "description": "Mixing aggregate (SUM/AVG/COUNT/…) with non-aggregated columns — add a GROUP BY for the non-aggregated columns",
        "max_retries": 1,
    },
    {
        # Ambiguous column: DuckDB "Ambiguous reference", Trino "Column .. is
        # ambiguous", Snowflake "ambiguous column reference",
        # Spark "Reference .. is ambiguous", Oracle ORA-00918.
        # BF-277: must come BEFORE the generic "binder error" rule.
        # 2026-10-07: Snowflake says "ambiguous column name 'X'".
        "pattern": (
            r"ambiguous reference to column|"
            r"column .* is ambiguous|"
            r"ambiguous column reference|"
            r"ambiguous column name|"
            r"reference .* is ambiguous|"
            r"ora-00918|column ambiguously defined"
        ),
        "strategy": "qualify_ambiguous_columns",
        "description": "Column exists in multiple FROM tables — qualify with table alias (e.g. a.col)",
        "max_retries": 0,
    },
    {
        # Column not found: DuckDB binder, Trino "Column .* not found",
        # Snowflake "invalid identifier", Spark "cannot resolve",
        # Oracle ORA-00904 "invalid identifier".
        "pattern": (
            r"column.*not found|no column.*named|binder error|"
            r"column .* not found|"
            r"invalid identifier|"
            r"cannot resolve.*reference|"
            r"ora-00904|"
            r"unresolved column"
        ),
        "strategy": "refresh_schema",
        "description": "Column mismatch — refresh schema cache and suggest correction",
        "max_retries": 1,
    },
    {
        # Permission/access denied: HTTP 403, S3 AccessDenied, Snowflake
        # "Insufficient privileges", Oracle ORA-00942 (table or view does
        # not exist — usually permission), Databricks "PERMISSION_DENIED".
        "pattern": (
            r"permission denied|access denied|forbidden|http 403|"
            r"403 forbidden|"
            r"insufficient privileges|"
            r"ora-00942|table or view does not exist|"
            r"permission_denied|"
            r"not authorized to perform"
        ),
        "strategy": "check_permissions",
        "description": "Access denied — verify credentials and permissions",
        "max_retries": 0,
    },
    {
        # SSL/TLS: corporate proxy issues common across all HTTP clients.
        # MUST come BEFORE the connection-reset rule below — TLS errors often
        # include "connection aborted" or "broken pipe" in their message text.
        "pattern": (
            r"ssl.*handshake|certificate verify failed|ssl.*error|tls.*error|"
            r"sslerror|certificate.*expired|self.signed certificate|"
            r"unable to get local issuer|cert.*untrusted"
        ),
        "strategy": "check_proxy_config",
        "description": "SSL/TLS error — check proxy CA bundle or certificate configuration",
        "max_retries": 0,
    },
    {
        # Network/S3 transient: DuckDB curl, generic 5xx, slowdown
        # signals from S3/Snowflake.  500/502/503 are retryable.
        "pattern": (
            r"could not open remote file|failed to download|curl error|"
            r"http 50[023]|50[023] (internal server error|bad gateway|service unavailable)|"
            r"slowdown|503 slow down|"
            r"too many requests|http 429|429 too many"
        ),
        "strategy": "retry_with_backoff",
        "description": "Network/S3 transient error — retry with backoff",
        "max_retries": 2,
    },
    {
        # DNS resolution failure: WSAHOST_NOT_FOUND (Windows 11001),
        # getaddrinfo on Linux/Mac, hostname typos, VPN-disconnected
        # internal hostnames.  Distinct from generic conn-refused because
        # the FIX is different — retry won't help if the hostname is
        # mistyped.  MUST come BEFORE the connection-reset rule below.
        "pattern": (
            r"getaddrinfo failed|name resolution failed|"
            r"name or service not known|"
            r"nodename nor servname|"
            r"errno 11001|wsahost_not_found|"
            r"could not resolve host|"
            r"dns resolution|dns lookup failed"
        ),
        "strategy": "verify_path",
        "description": (
            "DNS lookup failed — hostname can't be resolved. Action: "
            "check the host spelling in connection config, verify VPN/"
            "proxy is connected (for internal hosts), test with "
            "`nslookup <host>` from the same machine. Retrying without "
            "fixing DNS will keep failing."
        ),
        "max_retries": 0,
    },
    {
        "pattern": (
            r"connection refused|econnrefused|connection reset|econnreset|"
            r"connection aborted|connection timed out|"
            r"broken pipe|epipe"
        ),
        "strategy": "retry_with_backoff",
        "description": "Connection refused/reset — transient network error, retry with backoff",
        "max_retries": 2,
    },
    {
        # boto3/urllib3 pool exhaustion under high concurrency.  Surfaces as
        # a warning normally, but can become an exception if pool is fully
        # saturated AND the request times out waiting.  Action: bump
        # config.json s3.max_pool_connections OR reduce max_workers.
        "pattern": (
            r"connection pool is full|pool is full, discarding|"
            r"http(s)?connectionpool.*max retries|"
            r"poolmanager.*pool"
        ),
        "strategy": "retry_with_backoff",
        "description": (
            "S3 connection pool saturated — increase config.json "
            "s3.max_pool_connections (default 64) or lower max_workers"
        ),
        "max_retries": 1,
    },
    {
        "pattern": (
            r"no space left on device|disk full|cannot write|out of disk|"
            r"errno 28|enospc|"
            r"insufficient.*disk space"
        ),
        "strategy": "check_disk_space",
        "description": "Disk full — check temp directory space and clean up old files",
        "max_retries": 0,
    },
    {
        # Syntax: DuckDB parser, Trino "line 1:5 mismatched input",
        # Snowflake "Syntax error in line", Oracle ORA-00900/00936.
        "pattern": (
            r"parser error|syntax error|unterminated quote|unexpected token|"
            r"mismatched input|"
            r"ora-00900|invalid sql statement|"
            r"ora-00936|missing expression|"
            r"unexpected end of statement"
        ),
        "strategy": "check_sql_syntax",
        "description": "SQL syntax error — review query for typos or invalid SQL",
        "max_retries": 0,
    },
    {
        # Path / object not found: S3 NoSuchKey, Trino "does not exist",
        # generic 404, REST API "endpoint not found".
        "pattern": (
            r"no files found|read_parquet.*empty|^0 files matched|"
            r"nosuchkey|no such key|"
            r"http 404|404 not found|"
            r"object .* does not exist|"
            r"table .* does not exist|table or view not found|"
            r"path does not exist"
        ),
        "strategy": "verify_path",
        "description": "Path/object not found — verify S3 prefix, table name, or endpoint URL",
        "max_retries": 0,
    },
    {
        # Iceberg snapshot expired or missing — common after compaction or
        # expire_snapshots maintenance.  Refresh metadata cache to pick up
        # the new current snapshot.
        "pattern": (
            r"snapshot.*not found|snapshot id .* does not exist|"
            r"snapshot has expired|snapshot.*expired|"
            r"manifest.*not found|"
            r"metadata file.*not found|metadata.json.*not found"
        ),
        "strategy": "refresh_schema",
        "description": (
            "Iceberg snapshot expired or removed (compaction / "
            "expire_snapshots) — refresh metadata cache and retry"
        ),
        "max_retries": 1,
    },
    {
        # Type mismatch / cast errors: DuckDB "Could not convert", Trino
        # "Cannot cast", Snowflake "Numeric value is not recognized",
        # Spark "cannot be cast to", Oracle ORA-01722 / ORA-01858.
        # Fix is data-shaped — refresh schema so suggester can spot the
        # offending column.
        "pattern": (
            r"could not convert.*to|cannot cast|invalid input syntax for type|"
            r"numeric value .* is not recognized|"
            r"is not a valid date|is not a valid timestamp|"
            r"value cannot be cast to|"
            r"ora-01722|invalid number|"
            r"ora-01858|non-numeric character|"
            r"data type mismatch"
        ),
        "strategy": "check_sql_syntax",
        "description": (
            "Type/cast mismatch — column type doesn't match the literal or "
            "function arg.  Wrap with CAST(... AS <type>) or fix the input."
        ),
        "max_retries": 0,
    },
    {
        # Division by zero: DuckDB "division by zero", Trino + Snowflake
        # similar, Oracle ORA-01476.  Trivial fix is NULLIF or WHERE filter.
        "pattern": (
            r"division by zero|divide by zero|"
            r"divisor cannot be zero|"
            r"ora-01476"
        ),
        "strategy": "check_sql_syntax",
        "description": (
            "Division by zero — wrap denominator in NULLIF(denominator, 0) "
            "to return NULL instead of erroring, or filter rows where the "
            "denominator is 0"
        ),
        "max_retries": 0,
    },
    {
        # Numeric overflow / arithmetic out-of-range: aggregations on huge
        # values overflow integer types.  DuckDB "overflow", Snowflake
        # "Numeric value out of range", Oracle ORA-01426.
        "pattern": (
            r"numeric (value )?(out of range|overflow)|"
            r"arithmetic overflow|integer overflow|"
            r"value out of range|"
            r"ora-01426|numeric overflow"
        ),
        "strategy": "check_sql_syntax",
        "description": (
            "Numeric overflow in aggregate or arithmetic — CAST input to "
            "BIGINT or DECIMAL(38,…) before SUM/AVG to avoid the smaller "
            "default integer type wrapping around"
        ),
        "max_retries": 0,
    },
    {
        # Concurrent modification: Iceberg commit conflict, S3 If-Match
        # PreconditionFailed, optimistic-locking version mismatch.  Retry
        # the commit; the engine refreshes the base snapshot automatically.
        "pattern": (
            r"commit conflict|concurrent modification|"
            r"validation failed.*snapshot|"
            r"preconditionfailed|412 precondition failed|"
            r"optimistic.*lock|version conflict"
        ),
        "strategy": "retry_with_backoff",
        "description": (
            "Concurrent commit conflict — another writer raced ahead.  "
            "Retry; the engine will rebase on the latest snapshot"
        ),
        "max_retries": 2,
    },
    {
        # Warehouse / compute resource suspended or quota exceeded:
        # Snowflake suspended warehouse, AWS service quota, Databricks
        # cluster terminated, Oracle resource limit.
        "pattern": (
            r"warehouse.*suspended|warehouse is not running|"
            r"cluster.*terminated|cluster.*not (available|running)|"
            r"quota (exceeded|reached)|service.*quota|"
            r"limitexceeded|"
            r"ora-00018|maximum number of sessions exceeded"
        ),
        "strategy": "check_permissions",
        "description": (
            "Compute resource unavailable (warehouse suspended / cluster "
            "terminated / quota exceeded) — resume the resource or request "
            "a quota increase from the cloud provider"
        ),
        "max_retries": 0,
    },
    {
        # Parquet/file-format corruption: bad magic bytes, truncated footer.
        # Indicates the writer crashed mid-flush or the file is non-parquet.
        # Refresh metadata so the orphan file is dropped from the catalogue.
        "pattern": (
            r"invalid magic|bad magic|"
            r"parquet (file|footer).*(corrupt|invalid|too small)|"
            r"unexpected end of (stream|file)|"
            r"footer.*magic.*expected|"
            r"file is not a parquet"
        ),
        "strategy": "refresh_schema",
        "description": (
            "Corrupt or non-parquet file in the dataset — likely a writer "
            "crashed mid-flush.  Refresh metadata to drop orphans, or "
            "re-run the producer to overwrite"
        ),
        "max_retries": 1,
    },
]

# ── DQ threshold rules ────────────────────────────────────────────────────────

DQ_RULES: List[Dict[str, Any]] = [
    {"metric": "null_pct", "op": ">", "threshold": 0.5, "severity": "critical",
     "action": "alert", "message": "Column has >50% null values"},
    {"metric": "null_pct_delta", "op": ">", "threshold": 0.2, "severity": "warning",
     "action": "alert", "message": "Null % increased by >20% vs baseline"},
    {"metric": "row_count_ratio", "op": "<", "threshold": 0.3, "severity": "warning",
     "action": "alert", "message": "Row count dropped >70% vs baseline"},
    {"metric": "row_count_ratio", "op": ">", "threshold": 3.0, "severity": "warning",
     "action": "alert", "message": "Row count tripled vs baseline — unexpected spike"},
    {"metric": "schema_columns_added", "op": ">", "threshold": 0, "severity": "info",
     "action": "notify", "message": "New columns detected in schema"},
    {"metric": "schema_columns_removed", "op": ">", "threshold": 0, "severity": "critical",
     "action": "alert", "message": "Columns removed from schema — potential breaking change"},
    {"metric": "freshness_hours", "op": ">", "threshold": 48, "severity": "warning",
     "action": "alert", "message": "Data not updated in >48 hours"},
]


def _match_rule(value: float, op: str, threshold: float) -> bool:
    """Evaluate a threshold comparison."""
    if op == ">":
        return value > threshold
    if op == "<":
        return value < threshold
    if op == ">=":
        return value >= threshold
    if op == "<=":
        return value <= threshold
    if op == "==":
        return value == threshold
    return False


class RulesEngine(DecisionEngine):
    """Pattern-matching rules engine.  No external dependencies.

    Three layers of admin control — all keyed under the ``agents`` config
    section so nothing in this file needs editing for site-specific tweaks:

    1. ``agents.query_fix_rules_path`` (str, optional)
         Path to a JSON file containing a full replacement for QUERY_FIX_RULES.
         When set, the built-in list is IGNORED and only the file's rules
         apply (in order).  Use this when you want full control of the
         ruleset for a specific deployment.  File schema is the same as
         the in-code list — see QUERY_FIX_RULES at the top of this module.

    2. ``agents.disabled_strategies`` (list[str], optional)
         List of strategy names to filter out from the built-in rules
         (e.g. ["check_disk_space", "reduce_memory"]).  Useful when a
         built-in rule's auto-retry doesn't fit your environment.

    3. ``agents.custom_query_fix_rules`` (list[dict], optional)
         APPENDS rules to the active ruleset.  Each rule:
             pattern:     regex string (Python re, case-insensitive)
             strategy:    one of _AUTO_RETRY_STRATEGIES or "none"
             description: human-readable hint surfaced to admin/agent
             max_retries: 0-3
             priority:    "before" | "after" (default before)
         "before" rules are checked BEFORE the active ruleset (override
         built-in classification).  "after" rules act as catch-alls.

    Bad regex / unknown-key rules are logged + skipped so one typo doesn't
    disable the whole engine.  All rules are compiled once at __init__
    so classify_error doesn't pay regex compile cost per call.
    """

    def __init__(self, config: Dict[str, Any] | None = None,
                 db_manager: Any = None):
        self._config = config or {}
        # BF-352: optional DB-backed config — when supplied, agent_config rows
        # MERGE INTO the file config (DB takes precedence per-key).  Allows
        # admins/agents to tune behaviour at runtime without a pod restart.
        self._db = db_manager
        if db_manager is not None:
            try:
                db_overrides = db_manager.agent_config_get_all() or {}
                if db_overrides:
                    # Shallow merge — DB keys win.  Sub-dicts like dq_monitor
                    # are merged at the second level too so a single DB row
                    # can override one threshold without losing others.
                    merged = dict(self._config)
                    for k, v in db_overrides.items():
                        if (k in merged and isinstance(merged[k], dict)
                                and isinstance(v, dict)):
                            sub = dict(merged[k])
                            sub.update(v)
                            merged[k] = sub
                        else:
                            merged[k] = v
                    self._config = merged
                    logger.info("[rules-engine] merged %d DB config override(s)",
                                len(db_overrides))
            except Exception as exc:
                logger.warning(
                    "[rules-engine] DB config load failed (%s) — using file "
                    "config only.  Action: check DB connectivity + "
                    "agent_config table exists (alembic upgrade head).",
                    exc,
                )

        # Config-driven DQ thresholds — DB rows can also overwrite these via
        # the merged self._config dq_monitor dict.
        dq_cfg = self._config.get("dq_monitor", {})
        self._null_threshold = dq_cfg.get("null_threshold", 0.5)
        self._row_spike_threshold = dq_cfg.get("row_count_spike_threshold", 3.0)
        self._row_drop_threshold = dq_cfg.get("row_count_drop_threshold", 0.3)
        self._freshness_hours = dq_cfg.get("freshness_hours", 48)
        self._null_delta_threshold = dq_cfg.get("null_delta_threshold", 0.2)

        # Resolve the active built-in ruleset.  Priority order:
        #   1. DB (agent_rules table, kind='query_fix') — admin-editable
        #   2. File path (agents.query_fix_rules_path)
        #   3. In-code QUERY_FIX_RULES (filtered by disabled_strategies)
        self._active_rules = self._resolve_active_rules()

        # Custom user-defined rules — compiled once at construction so we
        # don't re-compile every classify_error call.  Bad regexes are
        # logged + skipped so one typo doesn't disable the whole engine.
        self._custom_rules_before, self._custom_rules_after = self._compile_custom_rules()

    def _resolve_active_rules(self) -> List[Dict[str, Any]]:
        """Build the active built-in rules list.

        Priority:
          1. DB (agent_rules table) when db_manager available — admin
             can edit rules from the UI.  Auto-seeds from QUERY_FIX_RULES
             on first run when the table is empty.
          2. agents.query_fix_rules_path JSON file (full replacement).
          3. In-code QUERY_FIX_RULES filtered by agents.disabled_strategies.

        Each surviving rule gets ``_compiled`` (a re.Pattern) attached so
        classify_error can skip the per-call re.compile.
        """
        # ── Priority 1: DB ─────────────────────────────────────────────
        if self._db is not None:
            try:
                # Auto-seed: insert built-in defaults if the table has no
                # query_fix rows yet.  Idempotent — safe on every boot.
                seeded = self._db.agent_rules_seed_if_empty(
                    "query_fix", QUERY_FIX_RULES)
                if seeded > 0:
                    logger.info(
                        "[rules-engine] seeded %d built-in query_fix rules into "
                        "agent_rules table (first boot or table cleared)", seeded)
                # Also seed DQ rules — accessed by evaluate_dq separately
                self._db.agent_rules_seed_if_empty("dq", DQ_RULES)
                # 2026-10-07: the seed is a one-time COPY -- a pattern fixed
                # in QUERY_FIX_RULES never reached a seeded install (Trino's
                # GROUP BY wording kept classifying as nothing on every rig).
                # Unedited seeded rows follow the code; admin edits stay.
                sync = getattr(self._db, "agent_rules_sync_seeds", None)
                if callable(sync):
                    sync("query_fix", QUERY_FIX_RULES)

                # Edge case: if rows EXIST but admin disabled all, the
                # resolved set should be empty (admin's intent), NOT fall
                # back to in-code rules.  Distinguish via total count.
                total = self._db.agent_rules_count("query_fix")
                rows = self._db.agent_rules_list("query_fix", enabled_only=True)
                if total > 0:
                    db_rules = [
                        {
                            "pattern":     r["pattern"],
                            "strategy":    r["strategy"],
                            "description": r["description"],
                            "max_retries": int(r["max_retries"] or 0),
                        }
                        for r in rows
                        if r.get("pattern") and r.get("strategy")
                    ]
                    logger.info(
                        "[rules-engine] loaded %d enabled query_fix rules "
                        "from DB (%d total, %d disabled)",
                        len(db_rules), total, total - len(db_rules))
                    return self._compile_rule_list(db_rules)
            except Exception as exc:
                logger.warning(
                    "[rules-engine] DB rule load failed (%s) — falling back to "
                    "file/in-code rules.  Action: alembic upgrade head OR "
                    "check DB connectivity.",
                    exc,
                )

        # ── Priority 2: File ───────────────────────────────────────────
        rules: List[Dict[str, Any]] = []
        path = self._config.get("query_fix_rules_path") or ""
        if path:
            try:
                import json as _json
                with open(path, "r", encoding="utf-8") as fh:
                    loaded = _json.load(fh)
                if not isinstance(loaded, list):
                    raise ValueError(
                        f"agents.query_fix_rules_path={path!r}: file must contain "
                        f"a JSON array of rule dicts, got {type(loaded).__name__}"
                    )
                for idx, r in enumerate(loaded):
                    if (isinstance(r, dict) and r.get("pattern")
                            and r.get("strategy")):
                        rules.append(dict(r))
                    else:
                        logger.warning(
                            "agents.query_fix_rules_path[%d] missing required "
                            "'pattern' or 'strategy' — skipped (file=%s)",
                            idx, path,
                        )
                logger.info(
                    "[rules-engine] loaded %d query_fix_rules from %s "
                    "(built-in defaults bypassed)",
                    len(rules), path,
                )
            except FileNotFoundError:
                logger.warning(
                    "agents.query_fix_rules_path=%r not found — falling back "
                    "to built-in QUERY_FIX_RULES.  Action: create the file "
                    "or unset the config key.",
                    path,
                )
                rules = list(QUERY_FIX_RULES)
            except Exception as exc:
                logger.warning(
                    "agents.query_fix_rules_path=%r failed to load (%s) — "
                    "falling back to built-in QUERY_FIX_RULES",
                    path, exc,
                )
                rules = list(QUERY_FIX_RULES)
        else:
            rules = list(QUERY_FIX_RULES)

        # Drop rules whose strategy is admin-disabled
        disabled = set(self._config.get("disabled_strategies") or [])
        if disabled:
            before_count = len(rules)
            rules = [r for r in rules if r.get("strategy") not in disabled]
            if len(rules) < before_count:
                logger.info(
                    "[rules-engine] %d built-in rule(s) disabled via "
                    "agents.disabled_strategies=%s",
                    before_count - len(rules), sorted(disabled),
                )

        return self._compile_rule_list(rules)

    @staticmethod
    def _compile_rule_list(rules: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Pre-compile each rule's pattern.  Bad regexes are logged + dropped
        so one typo doesn't disable the whole engine.  Used for DB-loaded,
        file-loaded, AND in-code rule paths."""
        compiled: List[Dict[str, Any]] = []
        for r in rules:
            try:
                r["_compiled"] = re.compile(r["pattern"], re.IGNORECASE | re.DOTALL)
                compiled.append(r)
            except re.error as exc:
                logger.warning(
                    "[rules-engine] invalid regex in rule strategy=%r "
                    "pattern=%r (%s) — rule SKIPPED",
                    r.get("strategy"), r.get("pattern"), exc,
                )
        return compiled

    def _compile_custom_rules(self) -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        """Validate + compile admin-supplied regex rules.  Returns (before, after)."""
        before: List[Dict[str, Any]] = []
        after: List[Dict[str, Any]] = []
        raw_rules = self._config.get("custom_query_fix_rules", []) or []
        if not isinstance(raw_rules, list):
            logger.warning("custom_query_fix_rules must be a list, got %s — ignored",
                           type(raw_rules).__name__)
            return before, after
        for idx, rule in enumerate(raw_rules):
            if not isinstance(rule, dict):
                logger.warning("custom_query_fix_rules[%d] must be a dict — skipped", idx)
                continue
            pattern = rule.get("pattern")
            strategy = rule.get("strategy", "none")
            if not pattern or not isinstance(pattern, str):
                logger.warning("custom_query_fix_rules[%d] missing or invalid 'pattern' — skipped", idx)
                continue
            try:
                # Compile + validate the regex; case-insensitive matches the
                # built-in pattern semantics (we lowercase error_msg before searching).
                compiled = re.compile(pattern, re.IGNORECASE | re.DOTALL)
            except re.error as exc:
                logger.warning(
                    "custom_query_fix_rules[%d] has invalid regex %r — skipped (%s)",
                    idx, pattern, exc,
                )
                continue
            entry = {
                "pattern":      pattern,
                "_compiled":    compiled,
                "strategy":     str(strategy),
                "description":  str(rule.get("description") or "Custom rule"),
                "max_retries":  int(rule.get("max_retries", 0) or 0),
                "_custom":      True,  # mark for source tag
            }
            priority = (rule.get("priority") or "before").lower()
            (before if priority == "before" else after).append(entry)
        if before or after:
            logger.info("RulesEngine: %d custom rules loaded (%d before, %d after built-ins)",
                        len(before) + len(after), len(before), len(after))
        return before, after

    def _match_rule_list(self, error_lower: str, rules: List[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
        for rule in rules:
            compiled = rule.get("_compiled")
            try:
                if compiled is not None:
                    if compiled.search(error_lower):
                        return rule
                elif re.search(rule["pattern"], error_lower):
                    return rule
            except Exception:
                continue
        return None

    def classify_error(self, error_msg: str, error_type: str, context: Dict[str, Any]) -> Dict[str, Any]:
        error_lower = (error_msg or "").lower()

        # Phase 142+: check admin custom 'before' rules first
        rule = self._match_rule_list(error_lower, self._custom_rules_before)
        if rule:
            return {
                "strategy":    rule["strategy"],
                "description": rule["description"],
                "max_retries": rule["max_retries"],
                "confidence":  1.0,
                "source":      "rules_engine_custom",
            }

        # Active built-in rules (post-config-overrides + disable-list).
        # Uses the pre-compiled patterns built once in __init__.
        rule = self._match_rule_list(error_lower, self._active_rules)
        if rule:
            return {
                "strategy":    rule["strategy"],
                "description": rule["description"],
                "max_retries": rule["max_retries"],
                "confidence":  1.0,
                "source":      "rules_engine",
            }

        # Phase 142+: admin custom 'after' rules — catch-alls
        rule = self._match_rule_list(error_lower, self._custom_rules_after)
        if rule:
            return {
                "strategy":    rule["strategy"],
                "description": rule["description"],
                "max_retries": rule["max_retries"],
                "confidence":  1.0,
                "source":      "rules_engine_custom",
            }

        return {
            "strategy": "none",
            "description": "No matching rule for this error",
            "max_retries": 0,
            "confidence": 0.0,
            "source": "rules_engine",
        }

    def _get_dq_rules(self) -> List[Dict[str, Any]]:
        """Return DQ rules with config-driven thresholds applied."""
        return [
            {"metric": "null_pct", "op": ">", "threshold": self._null_threshold,
             "severity": "critical", "action": "alert",
             "message": f"Column has >{self._null_threshold*100:.0f}% null values"},
            {"metric": "null_pct_delta", "op": ">", "threshold": self._null_delta_threshold,
             "severity": "warning", "action": "alert",
             "message": f"Null % increased by >{self._null_delta_threshold*100:.0f}% vs baseline"},
            {"metric": "row_count_ratio", "op": "<", "threshold": self._row_drop_threshold,
             "severity": "warning", "action": "alert",
             "message": f"Row count dropped >{(1-self._row_drop_threshold)*100:.0f}% vs baseline"},
            {"metric": "row_count_ratio", "op": ">", "threshold": self._row_spike_threshold,
             "severity": "warning", "action": "alert",
             "message": f"Row count spiked >{self._row_spike_threshold:.0f}x vs baseline"},
            {"metric": "schema_columns_added", "op": ">", "threshold": 0, "severity": "info",
             "action": "notify", "message": "New columns detected in schema"},
            {"metric": "schema_columns_removed", "op": ">", "threshold": 0, "severity": "critical",
             "action": "alert", "message": "Columns removed from schema — potential breaking change"},
            {"metric": "freshness_hours", "op": ">", "threshold": self._freshness_hours,
             "severity": "warning", "action": "alert",
             "message": f"Data not updated in >{self._freshness_hours}h"},
        ]

    def evaluate_dq(self, anomalies: List[Dict[str, Any]], context: Dict[str, Any]) -> Dict[str, Any]:
        """Evaluate anomalies against DQ rules, return highest severity action."""
        if not anomalies:
            return {"action": "none", "severity": "info", "message": "No anomalies",
                    "confidence": 1.0, "source": "rules_engine", "triggered_rules": []}

        rules = self._get_dq_rules()
        triggered = []
        for anomaly in anomalies:
            metric = anomaly.get("metric", "")
            value = anomaly.get("value", 0)
            for rule in rules:
                if rule["metric"] == metric and _match_rule(value, rule["op"], rule["threshold"]):
                    triggered.append({**rule, "actual_value": value, "column": anomaly.get("column")})

        if not triggered:
            return {"action": "none", "severity": "info", "message": "Anomalies below thresholds",
                    "confidence": 1.0, "source": "rules_engine", "triggered_rules": []}

        # Return highest severity
        severity_order = {"critical": 3, "warning": 2, "info": 1}
        triggered.sort(key=lambda r: severity_order.get(r["severity"], 0), reverse=True)
        top = triggered[0]
        return {
            "action": top["action"],
            "severity": top["severity"],
            "message": top["message"],
            "confidence": 1.0,
            "source": "rules_engine",
            "triggered_rules": triggered,
        }


class LLMEngineUnavailable(RuntimeError):
    """``agents.decision_engine`` is ``"llm"`` and this server cannot honour it.

    2026-09-15.  With ``llm`` configured and no ``anthropic``/``openai`` SDK
    installed (both are extras -- ``requirements-extras/agents.txt`` -- not
    in the default image), or no API key, ``LLMEngine`` used to log ONE
    warning and become the rules engine.  The operator believed decisions
    were LLM-made; they were not, and nothing they could query said so.
    A configured policy that quietly becomes a different policy is the
    "decision made twice" defect: the config said one thing, the process
    did another.

    Now the engine REFUSES: this is raised from ``__init__`` (nothing can
    hold a half-built LLM engine), the orchestrator catches it and starts
    NO agents, and the refusal is reported in ``/api/admin/agents/health``
    and ``/config`` as ``decision_engine_status`` (``routable: false`` +
    the reason -- the Clockwork task-type convention).  Choosing ``llm`` in
    the admin API is refused up front with the same reason.  Wanting the
    rules engine is spelled ``agents.decision_engine = "rules"``.
    """


class LLMEngine(DecisionEngine):
    """Claude / OpenAI LLM for intelligent error classification and DQ evaluation.

    Phase 125: Full implementation with rules-first optimization, rate limiting,
    timeout guards, and graceful fallback to RulesEngine on any LLM CALL
    failure.  CONFIGURATION failure is not a call failure: an ``llm`` engine
    that cannot be built raises ``LLMEngineUnavailable`` (2026-09-15).

    Admin enables via config::

        agents.decision_engine: "llm"
        agents.llm_provider: "claude"        # or "openai"
        agents.llm_api_key: "sk-..."
        agents.llm_model: "claude-sonnet-4-20250514"
        agents.llm_rules_first: true         # skip LLM when rules match
        agents.llm_max_calls_per_hour: 100
        agents.llm_timeout_seconds: 10
    """

    # Valid fix strategies the LLM may return (whitelist for safety)
    _VALID_STRATEGIES = frozenset({
        "add_partition_filter", "refresh_credentials", "reinstall_extension",
        "reduce_memory", "refresh_schema", "check_permissions",
        "retry_with_backoff", "check_proxy_config", "check_disk_space",
        "check_sql_syntax", "verify_path", "none",
    })

    # Class-level defaults so tests / call sites that bypass __init__ via
    # __new__() still have sane values for these attributes.  __init__
    # overrides per-instance from the config dict.
    _rate_window_seconds = 3600

    def __init__(self, config: Dict[str, Any] | None = None,
                 db_manager: Any = None):
        self._config = config or {}
        # Fallback engine inherits the same DB so admin rule edits apply
        # whether the LLM path or the rules-first short-circuit is in play.
        self._fallback = RulesEngine(config, db_manager=db_manager)
        self._enabled = self._config.get("decision_engine") == "llm"
        self._client = None
        self._provider = "claude"
        self._model = self._config.get("llm_model", "claude-sonnet-4-20250514")
        self._timeout = self._config.get("llm_timeout_seconds", 10)
        self._rules_first = self._config.get("llm_rules_first", True)
        self._max_calls_per_hour = self._config.get("llm_max_calls_per_hour", 100)
        # Window length for rate limiting — exposed so admins can switch from
        # hourly (3600) to per-minute (60) for tighter throttling without code.
        self._rate_window_seconds = int(self._config.get("llm_rate_window_seconds", 3600))
        # Simple sliding-window rate limiter
        self._call_count = 0
        self._window_start = 0.0
        # BF-414 — concurrent threads can both observe "fresh window", reset
        # the counter, and bypass the limit (race in check-then-increment).
        # A single lock + a single ``_check_and_increment`` method makes the
        # operation atomic.
        self._rate_lock = threading.Lock()

        if self._enabled:
            reason = self._init_client()
            if reason:
                # REFUSE, never downgrade.  See LLMEngineUnavailable.
                logger.error("LLM decision engine REFUSED: %s", reason)
                raise LLMEngineUnavailable(reason)

    #: provider -> (import module, pip name)
    _PROVIDER_SDKS = {
        "claude": ("anthropic", "anthropic"),
        "openai": ("openai", "openai"),
    }

    @classmethod
    def unavailability(cls, config: Dict[str, Any] | None) -> str:
        """Why an ``llm`` engine built from ``config`` would be refused --
        ``""`` when it would not.  OFFLINE: no client is built, no network.

        The same check ``__init__`` runs, exposed so the admin API can refuse
        ``decision_engine="llm"`` at the moment it is chosen (with the reason)
        instead of at the next restart.  Only the provider, the key's
        presence and the SDK's importability are checked; a key that the
        provider rejects surfaces on the first call as a call failure (which
        still falls back to rules -- that is a transient, not a config).
        """
        cfg = config or {}
        provider = str(cfg.get("llm_provider") or "claude")
        if provider not in cls._PROVIDER_SDKS:
            return (f"agents.llm_provider={provider!r} is not a known provider "
                    f"(one of: {', '.join(sorted(cls._PROVIDER_SDKS))})")
        api_key = str(cfg.get("llm_api_key") or "")
        sa_name = str(cfg.get("llm_system_account") or "")
        if not api_key and sa_name:
            api_key, sa_reason = cls._resolve_system_account_key(sa_name)
            if not api_key:
                return (f"agents.llm_system_account={sa_name!r} yielded no API "
                        f"key: {sa_reason}")
        if not api_key:
            return ("no API key: set agents.llm_api_key or "
                    "agents.llm_system_account")
        module, package = cls._PROVIDER_SDKS[provider]
        import sys
        import importlib.util
        if module in sys.modules:
            # Already imported (or deliberately blanked with None, the
            # standard way a test removes an SDK).  find_spec would read
            # ``__spec__`` off the module object, which a stub lacks.
            found = sys.modules[module] is not None
        else:
            try:
                found = importlib.util.find_spec(module) is not None
            except (ImportError, ValueError):
                found = False
        if not found:
            return (f"the {package!r} SDK is not installed on this server "
                    f"(it is an extra: requirements-extras/agents.txt), so "
                    f"agents.llm_provider={provider!r} cannot be used")
        return ""

    def _init_client(self) -> str:
        """Build the LLM client.  Returns the refusal reason, ``""`` on success."""
        reason = self.unavailability(self._config)
        if reason:
            return reason
        provider = str(self._config.get("llm_provider") or "claude")
        api_key = str(self._config.get("llm_api_key") or "")
        if not api_key:
            api_key, _ = self._resolve_system_account_key(
                str(self._config.get("llm_system_account") or ""))
        try:
            if provider == "claude":
                from anthropic import Anthropic
                self._client = Anthropic(api_key=api_key)
            else:
                from openai import OpenAI
                self._client = OpenAI(api_key=api_key)
        except Exception as exc:
            # find_spec said the module exists; the import or the constructor
            # still failed (a broken install, an SDK that rejects the key
            # shape).  A configuration this server cannot honour.
            return (f"the {provider!r} SDK could not be initialised: "
                    f"{type(exc).__name__}: {exc}")
        self._provider = provider
        logger.info("LLM decision engine initialized (provider=%s, model=%s)",
                    provider, self._model)
        return ""

    @staticmethod
    def _resolve_system_account_key(sa_name: str) -> tuple:
        """``(api_key, reason)`` from a SystemAccount row, through the ONE
        credential chokepoint (``core.qs_credentials.resolve_system_account``,
        the same call ``get_connector`` makes).

        Until 2026-09-15 this was a placeholder that logged at DEBUG and
        returned ``""`` -- a configured ``llm_system_account`` was never
        read, and the engine then "fell back to rules" for lack of a key.
        A kv secret's ``api_key``/``token`` or a DB/AD account's
        ``password`` is the key.
        """
        if not sa_name:
            return "", "no llm_system_account configured"
        try:
            from core.qs_credentials import resolve_system_account
            creds = resolve_system_account(sa_name) or {}
        except Exception as exc:
            return "", f"{type(exc).__name__}: {exc}"
        for field in ("api_key", "token", "secret", "password"):
            val = creds.get(field) if isinstance(creds, dict) else None
            if val:
                return str(val), ""
        return "", ("the account resolved but carries none of api_key / token "
                    "/ secret / password")

    def _ensure_rate_lock(self) -> None:
        """Lazy-init guard — protected by a module-level lock so two threads
        racing on ``__new__``-created instances can't each install their own
        Lock and end up not synchronizing against each other (BF-414)."""
        if getattr(self, "_rate_lock", None) is not None:
            return
        with _LLM_LAZY_INIT_LOCK:
            if getattr(self, "_rate_lock", None) is None:
                self._rate_lock = threading.Lock()

    def _check_rate_limit(self) -> bool:
        """Return True if a slot is available (without consuming it).

        For accurate counting under concurrency, prefer
        ``_try_consume_slot()`` which does check-and-increment atomically.
        """
        import time
        self._ensure_rate_lock()
        _window = getattr(self, "_rate_window_seconds", None) or 3600
        with self._rate_lock:
            now = time.time()
            if now - self._window_start >= _window:
                self._call_count = 0
                self._window_start = now
            return self._call_count < self._max_calls_per_hour

    def _increment_call_count(self) -> None:
        """Legacy unconditional increment.  Retained for backward compat —
        new code should call ``_try_consume_slot()`` instead so the
        check + increment happens atomically."""
        import time
        self._ensure_rate_lock()
        _window = getattr(self, "_rate_window_seconds", None) or 3600
        with self._rate_lock:
            now = time.time()
            if now - self._window_start >= _window:
                self._call_count = 0
                self._window_start = now
            self._call_count += 1

    def _try_consume_slot(self) -> bool:
        """Atomic check-and-increment.  Returns True iff a slot was reserved.

        BF-414 — previous ``_check_rate_limit`` + ``_increment_call_count``
        was a non-atomic pair.  Two concurrent callers could both observe
        "fresh window", both reset the counter, and both bypass the limit.
        Single critical section here closes the race.

        Defensive — some legacy test fixtures use
        ``LLMEngine.__new__(LLMEngine)`` and bypass ``__init__``, so the
        lock + window-seconds attributes may be missing; lazy-init them
        here so production callers get atomicity AND tests still pass.
        """
        import time
        self._ensure_rate_lock()
        _window = getattr(self, "_rate_window_seconds", None) or 3600
        with self._rate_lock:
            now = time.time()
            if now - self._window_start >= _window:
                self._call_count = 0
                self._window_start = now
            if self._call_count >= self._max_calls_per_hour:
                return False
            self._call_count += 1
            return True

    def classify_error(self, error_msg: str, error_type: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Classify a query error using LLM with rules-first optimization."""
        if not self._enabled or not self._client:
            return self._fallback.classify_error(error_msg, error_type, context)

        # Rules-first: if rules engine finds a high-confidence match, skip LLM
        if self._rules_first:
            rules_result = self._fallback.classify_error(error_msg, error_type, context)
            if rules_result.get("confidence", 0) >= 1.0 and rules_result.get("strategy") != "none":
                return rules_result

        # Atomic rate-limit reservation (BF-414).  Counts the slot only when
        # we actually intend to use it, and avoids the previous race where
        # two callers could both reset the window and bypass the limit.
        if not self._try_consume_slot():
            logger.debug("LLM rate limit exceeded (%d/%d/hr), using rules fallback",
                         self._call_count, self._max_calls_per_hour)
            return self._fallback.classify_error(error_msg, error_type, context)

        try:
            result = self._call_llm_classify(error_msg, error_type)
            return result
        except Exception as exc:
            # BF-414 — sanitize before logging so an Anthropic/OpenAI
            # ``AuthenticationError`` repr (which can include the API key)
            # never leaks into central logs.
            try:
                from core.error_sanitizer import sanitize_error as _sanitize
                _safe = _sanitize(str(exc))
            except Exception:
                _safe = type(exc).__name__
            logger.warning("LLM classify_error failed, falling back to rules: %s", _safe)
            return self._fallback.classify_error(error_msg, error_type, context)

    def _call_llm_classify(self, error_msg: str, error_type: str) -> Dict[str, Any]:
        """Make the actual LLM API call for error classification."""
        import concurrent.futures

        strategies_list = ", ".join(sorted(self._VALID_STRATEGIES - {"none"}))
        system_prompt = (
            "You are a database query error classifier for an enterprise analytics platform. "
            "Given an error message and type, classify it and suggest a fix strategy.\n\n"
            f"Valid strategies: {strategies_list}\n"
            "Use 'none' if no strategy applies.\n\n"
            "Respond with ONLY a JSON object (no markdown, no explanation):\n"
            '{"strategy": "<strategy_name>", "description": "<brief explanation>", '
            '"max_retries": <0-2>, "confidence": <0.0-1.0>}'
        )

        user_msg = f"Error message: {error_msg[:1000]}\nError type: {error_type}"

        def _call():
            if self._provider == "claude":
                response = self._client.messages.create(
                    model=self._model,
                    max_tokens=200,
                    system=system_prompt,
                    messages=[{"role": "user", "content": user_msg}],
                )
                return response.content[0].text
            else:  # openai
                response = self._client.chat.completions.create(
                    model=self._model,
                    max_tokens=200,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_msg},
                    ],
                )
                return response.choices[0].message.content

        # Run in thread with timeout to avoid blocking the event loop.
        # BF-414 — previously used ``with ThreadPoolExecutor(...) as
        # executor`` which on TimeoutError calls ``shutdown(wait=True)``
        # in __exit__ and BLOCKS until the still-running LLM SDK call
        # eventually returns (the SDK doesn't honour Python-level cancel).
        # We now use a try/finally with ``shutdown(wait=False,
        # cancel_futures=True)`` so the timeout actually returns.
        executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        try:
            future = executor.submit(_call)
            raw = future.result(timeout=self._timeout)
        finally:
            executor.shutdown(wait=False, cancel_futures=True)

        # Parse JSON response
        import json as _json
        parsed = _json.loads(raw.strip())

        # Validate strategy (whitelist)
        strategy = parsed.get("strategy", "none")
        if strategy not in self._VALID_STRATEGIES:
            strategy = "none"

        return {
            "strategy": strategy,
            "description": parsed.get("description", ""),
            "max_retries": min(int(parsed.get("max_retries", 0)), 2),
            "confidence": max(0.0, min(1.0, float(parsed.get("confidence", 0.5)))),
            "source": "llm_engine",
        }

    def evaluate_dq(self, anomalies: List[Dict[str, Any]], context: Dict[str, Any]) -> Dict[str, Any]:
        """Evaluate DQ anomalies using LLM with rules-first optimization."""
        if not self._enabled or not self._client:
            return self._fallback.evaluate_dq(anomalies, context)

        # Rules-first for DQ — if rules triggered, use them (cheaper + deterministic)
        if self._rules_first:
            rules_result = self._fallback.evaluate_dq(anomalies, context)
            if rules_result.get("action") != "none":
                return rules_result

        # No anomalies to evaluate
        if not anomalies:
            return self._fallback.evaluate_dq(anomalies, context)

        # Atomic rate-limit reservation (BF-414).
        if not self._try_consume_slot():
            return self._fallback.evaluate_dq(anomalies, context)

        try:
            result = self._call_llm_evaluate_dq(anomalies)
            return result
        except Exception as exc:
            try:
                from core.error_sanitizer import sanitize_error as _sanitize
                _safe = _sanitize(str(exc))
            except Exception:
                _safe = type(exc).__name__
            logger.warning("LLM evaluate_dq failed, falling back to rules: %s", _safe)
            return self._fallback.evaluate_dq(anomalies, context)

    def _call_llm_evaluate_dq(self, anomalies: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Make the actual LLM API call for DQ evaluation."""
        import concurrent.futures
        import json as _json

        system_prompt = (
            "You are a data quality analyst for an enterprise analytics platform. "
            "Given a list of detected anomalies, assess overall severity and recommended action.\n\n"
            "Valid actions: alert, notify, none\n"
            "Valid severities: critical, warning, info\n\n"
            "Respond with ONLY a JSON object (no markdown):\n"
            '{"action": "<action>", "severity": "<severity>", '
            '"message": "<summary>", "confidence": <0.0-1.0>}'
        )
        user_msg = f"Anomalies detected:\n{_json.dumps(anomalies[:20], default=str)}"

        def _call():
            if self._provider == "claude":
                response = self._client.messages.create(
                    model=self._model,
                    max_tokens=200,
                    system=system_prompt,
                    messages=[{"role": "user", "content": user_msg}],
                )
                return response.content[0].text
            else:
                response = self._client.chat.completions.create(
                    model=self._model,
                    max_tokens=200,
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_msg},
                    ],
                )
                return response.choices[0].message.content

        # BF-414 — same fix as ``_call_llm_classify``: avoid blocking
        # ``__exit__`` on TimeoutError.
        executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        try:
            future = executor.submit(_call)
            raw = future.result(timeout=self._timeout)
        finally:
            executor.shutdown(wait=False, cancel_futures=True)

        parsed = _json.loads(raw.strip())

        # Validate action
        action = parsed.get("action", "none")
        if action not in ("alert", "notify", "none"):
            action = "none"
        severity = parsed.get("severity", "info")
        if severity not in ("critical", "warning", "info"):
            severity = "info"

        return {
            "action": action,
            "severity": severity,
            "message": parsed.get("message", ""),
            "confidence": max(0.0, min(1.0, float(parsed.get("confidence", 0.5)))),
            "source": "llm_engine",
            "triggered_rules": [],  # LLM doesn't use rules
        }
