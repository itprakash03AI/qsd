"""
Agent Orchestrator — routes events to agents and logs decisions.

Phase 120: Central coordinator for all self-healing agents.
"""

import json
import logging
from typing import Any, Dict, Optional

from .base import AgentAction, AgentDecision, BaseAgent
from .decision_engine import (DecisionEngine, LLMEngine, LLMEngineUnavailable,
                              RulesEngine)

logger = logging.getLogger(__name__)


class AgentOrchestrator:
    """Routes events to registered agents, tracks decisions in DB."""

    def __init__(self, config: Dict[str, Any], db_manager=None):
        self._config = config.get("agents", {})
        self._enabled = self._config.get("enabled", False)
        self._db = db_manager
        self._agents: Dict[str, BaseAgent] = {}
        #: Why the orchestrator did not start although agents.enabled is
        #: true -- "" when it started.  Read by decision_engine_status().
        self._refusal_reason: str = ""
        self._engine_type: str = str(self._config.get("decision_engine", "rules"))
        self._effective_engine: str = ""

        if not self._enabled:
            logger.info("Agent orchestrator disabled (agents.enabled=false)")
            return

        # Build decision engine — pass db_manager so the engine can pull
        # admin-managed rules + config overrides from the agent_rules /
        # agent_config tables.  Falls back to in-code rules when DB unavailable.
        engine_type = self._engine_type
        if engine_type == "llm":
            try:
                engine: DecisionEngine = LLMEngine(self._config, db_manager=db_manager)
            except LLMEngineUnavailable as exc:
                # 2026-09-15 -- REFUSE, do not downgrade.  The engine used to
                # become the rules engine with a warning; the operator then
                # believed decisions were LLM-made.  No agent runs until the
                # configuration is honoured or changed on purpose.  Same
                # posture as main.py's pod-role misconfig: never take the
                # pod down, never let it go unnoticed.
                self._refusal_reason = str(exc)
                self._enabled = False
                logger.error(
                    "Agent orchestrator REFUSED to start: agents.decision_engine"
                    "='llm' but %s.  No agent will run until this is fixed; to "
                    "run the rules engine DELIBERATELY set "
                    "agents.decision_engine='rules'.  Reported by "
                    "GET /api/admin/agents/health (decision_engine_status).", exc)
                return
            self._effective_engine = "llm"
        else:
            engine = RulesEngine(self._config, db_manager=db_manager)
            self._effective_engine = "rules"

        # Register agents (lazy imports to avoid circular deps)
        self._register_agents(engine)
        logger.info("Agent orchestrator started: %d agents, engine=%s",
                     len(self._agents), engine_type)

    def _register_agents(self, engine: DecisionEngine) -> None:
        """Import and instantiate enabled agents."""
        # Query Resilience
        qr_cfg = self._config.get("query_resilience", {})
        if qr_cfg.get("enabled", True):
            try:
                from .query_resilience import QueryResilienceAgent
                self._agents["query_resilience"] = QueryResilienceAgent(engine, self._config)
            except Exception as exc:
                logger.warning("Failed to load QueryResilienceAgent: %s", exc)

        # DQ Monitor
        dq_cfg = self._config.get("dq_monitor", {})
        if dq_cfg.get("enabled", True):
            try:
                from .dq_monitor import DQMonitorAgent
                self._agents["dq_monitor"] = DQMonitorAgent(engine, self._config)
            except Exception as exc:
                logger.warning("Failed to load DQMonitorAgent: %s", exc)

        # Data Pipeline
        dp_cfg = self._config.get("data_pipeline", {})
        if dp_cfg.get("enabled", True):
            try:
                from .data_pipeline import DataPipelineAgent
                self._agents["data_pipeline"] = DataPipelineAgent(engine, self._config)
            except Exception as exc:
                logger.warning("Failed to load DataPipelineAgent: %s", exc)

    @property
    def enabled(self) -> bool:
        return self._enabled

    @property
    def refusal_reason(self) -> str:
        """Why agents.enabled=true still started nothing; "" when it did."""
        return getattr(self, "_refusal_reason", "")

    def decision_engine_status(self) -> Dict[str, Any]:
        """What was configured, what is running, and why they differ.

        ``routable`` follows the Clockwork task-type convention: a thing
        that is offered but cannot run says so with a reason, instead of
        quietly being something else.
        """
        refusal = self.refusal_reason
        configured = getattr(self, "_engine_type", "rules")
        effective = getattr(self, "_effective_engine", "") or None
        if refusal:
            reason = refusal
        elif not self._enabled:
            reason = "orchestrator disabled (agents.enabled=false)"
        else:
            reason = ""
        return {
            "configured": configured,
            "effective": effective,
            "routable": bool(self._enabled and effective == configured),
            "reason": reason,
        }

    def is_agent_enabled(self, agent_name: str) -> bool:
        return self._enabled and agent_name in self._agents

    # Known agent registry — used by list_agents() so DISABLED agents
    # still appear in the admin UI (with enabled=false) so admin can see
    # what's available to toggle on.  Without this, disabled agents are
    # invisible until an orchestrator restart.
    _ALL_AGENTS = (
        ("query_resilience", "Auto-fixes failed queries based on error pattern"),
        ("dq_monitor",       "Detects data quality anomalies (null spike, schema drift, freshness)"),
        ("data_pipeline",    "Auto-profiles uploads and suggests type fixes"),
    )

    def list_agents(self) -> list:
        """Return summary of ALL known agents with their current state.

        Includes disabled agents so the admin UI can render them with
        enabled=false rather than hiding them.  Without this, an admin
        wouldn't know an agent existed unless they restarted the
        orchestrator after enabling it in config."""
        out: list = []
        for name, desc in self._ALL_AGENTS:
            instance = self._agents.get(name)
            if instance is not None:
                out.append({
                    "name":        instance.name,
                    "description": instance.description,
                    "enabled":     True,
                })
                continue
            # Disabled or failed-to-load — distinguish via config.
            # Three distinct cases (in priority order):
            #   1. Orchestrator master switch off (agents.enabled=false)
            #   2. Per-agent enabled=false in config sub-section
            #   3. Per-agent enabled=true but instantiation raised
            sub_cfg = self._config.get(name, {}) or {}
            enabled_in_cfg = bool(sub_cfg.get("enabled", True))
            if self.refusal_reason:
                reason = f"orchestrator refused to start: {self.refusal_reason}"
            elif not self._enabled:
                reason = "orchestrator disabled (agents.enabled=false)"
            elif not enabled_in_cfg:
                reason = f"disabled in config (agents.{name}.enabled=false)"
            else:
                reason = "failed to load — check startup logs"
            out.append({
                "name":        name,
                "description": desc,
                "enabled":     False,
                "reason":      reason,
            })
        return out

    def handle_event(self, event_type: str, event: Dict[str, Any],
                     context: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """Main entry point — called from existing code paths.

        Returns agent result dict if an agent handled the event, else None.
        Agent failures are logged but NEVER propagate to the caller.

        This is intentionally synchronous — all current agent operations
        (rules matching, dict construction, DB logging) are fast in-memory
        or single-row DB writes.  If future agents need async I/O (LLM API),
        wrap those calls in asyncio.run_in_executor() at the agent level.
        """
        if not self._enabled:
            return None

        context = context or {}
        full_event = {"type": event_type, **event}

        for name, agent in self._agents.items():
            if not agent.can_handle(full_event):
                continue
            try:
                decision = agent.decide(full_event, context)

                # Audit trail
                self._log_decision(name, event_type, event, decision)

                if decision.action == AgentAction.RETRY_WITH_FIX:
                    result = agent.act(decision, full_event, context)
                    agent.observe_result(decision, result)
                    return result

                if decision.action == AgentAction.NOTIFY_USER:
                    return {"agent": name, "action": "notify",
                            "reason": decision.reason, "metadata": decision.metadata}

                # LOG_AND_SKIP / ESCALATE — do nothing, continue
            except Exception as exc:
                logger.warning("Agent '%s' failed on event '%s': %s",
                               name, event_type, exc, exc_info=True)
                # Agent failure NEVER blocks the normal flow

        return None

    def _log_decision(self, agent_name: str, event_type: str,
                      event: Dict[str, Any], decision: AgentDecision) -> None:
        """Persist decision to DB audit trail."""
        if not self._db:
            return
        try:
            self._db.create_agent_decision({
                "agent_name": agent_name,
                "event_type": event_type,
                "execution_id": event.get("execution_id"),
                "action": decision.action.value,
                "reason": decision.reason,
                "fix_applied": decision.fix_applied,
                "confidence": decision.confidence,
                "metadata_json": json.dumps(decision.metadata, default=str),
            })
        except Exception as exc:
            logger.warning("Failed to log agent decision: %s", exc)

    def run_dq_monitor(self) -> Optional[Dict[str, Any]]:
        """Scheduled entry point for the DQ monitor agent.

        Profiles local tables, compares to stored baselines, detects anomalies,
        and dispatches alerts via the DQMonitorAgent decision pipeline.
        """
        if not self.is_agent_enabled("dq_monitor"):
            return None
        try:
            agent = self._agents["dq_monitor"]
            all_anomalies = []

            # Profile local tables (they have DuckDB-accessible data on disk)
            if self._db:
                try:
                    local_tables = self._db.list_local_tables()
                    if local_tables:
                        from core.duckdb_factory import duckdb_connection
                        with duckdb_connection() as con:
                            for lt in local_tables[:50]:  # cap at 50 tables per scan
                                lt_name = lt.get("table_name") or lt.get("name", "")
                                lt_path = lt.get("file_path", "")
                                lt_id = lt.get("id", 0)
                                if not lt_path:
                                    continue
                                try:
                                    current = agent.profile_table(lt_path, lt_id, duckdb_con=con)
                                    if current.get("error"):
                                        continue
                                    # Load baseline from previous scan (stored in agent_decisions metadata)
                                    baseline = self._load_dq_baseline(lt_path)
                                    if baseline:
                                        anomalies = agent.compare_to_baseline(current, baseline)
                                        for a in anomalies:
                                            a["table"] = lt_name
                                        all_anomalies.extend(anomalies)
                                    # Store current profile as new baseline
                                    self._save_dq_baseline(lt_path, current)
                                except Exception as tbl_exc:
                                    logger.debug("DQ scan: skipping table '%s': %s", lt_name, tbl_exc)
                except Exception as prof_exc:
                    logger.warning("DQ monitor: profiling phase failed: %s", prof_exc)

            event = {"type": "dq_scheduled_scan", "anomalies": all_anomalies}
            context = {"db_manager": self._db}
            decision = agent.decide(event, context)
            self._log_decision("dq_monitor", "dq_scheduled_scan", event, decision)
            if decision.action in (AgentAction.NOTIFY_USER, AgentAction.RETRY_WITH_FIX):
                return agent.act(decision, event, context)
        except Exception as exc:
            logger.warning("DQ monitor scheduled run failed: %s", exc, exc_info=True)
        return None

    def _load_dq_baseline(self, table_path: str) -> Optional[Dict[str, Any]]:
        """Load the last stored DQ baseline for a table from agent decisions."""
        if not self._db:
            return None
        try:
            decisions = self._db.list_agent_decisions(limit=1, agent_name="dq_baseline")
            # Search recent baselines for this specific table
            for d in self._db.list_agent_decisions(limit=200, agent_name="dq_baseline"):
                meta = d.get("metadata_json")
                if meta:
                    parsed = json.loads(meta) if isinstance(meta, str) else meta
                    if parsed.get("table_path") == table_path:
                        return parsed.get("profile")
        except Exception:
            pass
        return None

    def _save_dq_baseline(self, table_path: str, profile: Dict[str, Any]) -> None:
        """Store a DQ baseline profile as an agent decision log entry."""
        if not self._db:
            return
        try:
            self._db.create_agent_decision({
                "agent_name": "dq_baseline",
                "event_type": "dq_baseline_snapshot",
                "action": "log_and_skip",
                "reason": f"Baseline profile for {table_path}",
                "confidence": 1.0,
                "metadata_json": json.dumps({
                    "table_path": table_path,
                    "profile": profile,
                }, default=str),
            })
        except Exception as exc:
            logger.debug("DQ baseline save failed for '%s': %s", table_path, exc)


# ── Module-level singleton ────────────────────────────────────────────────────

_orchestrator: Optional[AgentOrchestrator] = None


def init_orchestrator(config: Dict[str, Any], db_manager=None) -> AgentOrchestrator:
    """Initialize the global orchestrator singleton.  Called once at startup."""
    global _orchestrator
    _orchestrator = AgentOrchestrator(config, db_manager)
    return _orchestrator


def get_orchestrator() -> Optional[AgentOrchestrator]:
    """Return the global orchestrator (None if not initialized or disabled)."""
    return _orchestrator
