"""What kind of database error is this -- answered once, for every engine.

2026-10-02.  ``api/datasets_api.py`` decided "is this a duplicate?" with
``"UNIQUE constraint" in str(e)`` at eight sites.  That is SQLite's sentence
(``UNIQUE constraint failed: business_datasets.name``).  PostgreSQL -- the
metadata store of every deployment -- says ``duplicate key value violates
unique constraint "business_datasets_name_key"`` (lower case), so a duplicate
dataset / column / metric / class / hierarchy / condition name answered a 500
"contact support" in production and the documented 409 "already exists" only
under the test suite's SQLite.  Found live on the Docker rig.  Another
engine's vocabulary, applied as if it were the only one.
"""
from __future__ import annotations

from typing import Optional

#: Message fragments, lower-cased, that mean a UNIQUE / primary-key violation
#: and nothing else.  A NOT NULL or foreign-key violation is ALSO an
#: IntegrityError -- and is NOT a duplicate, so the type alone never decides.
_UNIQUE_TOKENS = (
    "unique constraint",        # sqlite: "UNIQUE constraint failed: t.c"
                                # postgres: "... violates unique constraint ..."
    "duplicate key",            # postgres: "duplicate key value violates ..."
    "uniqueviolation",          # psycopg2.errors.UniqueViolation in the repr
    "duplicate entry",          # mysql / mariadb
    "unique key constraint",    # sql server
)

_UNIQUE_TYPE_NAMES = {"UniqueViolation"}     # psycopg2 / psycopg


def is_unique_violation(exc: Optional[BaseException]) -> bool:
    """True when ``exc`` -- or anything in its cause chain (bounded) -- is a
    uniqueness violation, on any engine the product stores metadata in."""
    seen = 0
    cur = exc
    while cur is not None and seen < 8:
        seen += 1
        if {k.__name__ for k in type(cur).__mro__} & _UNIQUE_TYPE_NAMES:
            return True
        orig = getattr(cur, "orig", None)            # sqlalchemy wraps the driver's
        if orig is not None and type(orig).__name__ in _UNIQUE_TYPE_NAMES:
            return True
        msg = str(cur).lower()
        if any(tok in msg for tok in _UNIQUE_TOKENS):
            return True
        nxt = cur.__cause__ if cur.__cause__ is not None else cur.__context__
        cur = nxt if nxt is not cur else None
    return False
