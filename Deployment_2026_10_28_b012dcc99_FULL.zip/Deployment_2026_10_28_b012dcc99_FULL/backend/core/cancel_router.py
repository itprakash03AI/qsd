"""
Cross-pod query cancellation router (2026-08-02 multi-pod correctness).

PROBLEM: in embedded-executor mode the cancel API used to act only on
in-process state (worker pool, ``cancellation_flags`` / ``running_tasks``
module dicts) on whichever pod received the HTTP request, then marked the
DB record ``cancelled`` UNCONDITIONALLY.  With >1 replica the query often
runs on a different pod: the cancel found nothing, the DB lied that it
worked, the query kept burning a >1 GB engine elsewhere and later raced a
``completed`` status over ``cancelled``.

DESIGN (no new infrastructure — the shared app DB is the bus):
  * ``signal_local_cancel()``   — signal every IN-PROCESS handle; returns
    whether anything local was actually found.  This is the N=1 fast path
    and is byte-identical in effect to the old inline code.
  * durable record — when nothing local is found, the cancel API stamps
    ``query_executions.cancel_requested = TRUE`` (additive nullable column)
    in the shared DB *in the same write* that sets ``status='cancelled'``.
  * ``poll_cancel_requests()``  — every pod runs a small watcher loop
    (main.py); the pod that OWNS the running task finds the flag and
    signals its local handles.  Signalling is idempotent, so non-owning
    pods and repeat sweeps are no-ops.
  * sticky status — ``DatabaseManager.update_execution`` refuses to
    overwrite a terminal ``cancelled`` with a late ``completed``/``failed``
    when ``cancel_requested`` is stamped, closing the status race.

External-executor mode is untouched: its task queue already IS a durable
shared cancel channel (``request_task_cancel`` / ``is_task_cancelled``).
"""
from __future__ import annotations

import logging
from typing import List

logger = logging.getLogger(__name__)


def signal_local_cancel(execution_id: str) -> bool:
    """Signal every in-process cancellation handle for ``execution_id``.

    Returns True only when at least one LOCAL handle was found and
    signalled — i.e. this pod actually owns some part of the execution.
    Never raises; each probe fails soft (cancellation must not 500 because
    one registry is unavailable).
    """
    if not execution_id:
        return False
    found = False

    # 1. BF-584/585 per-user queue — the execution may still be WAITING for
    #    a slot (no pool task / cancel_event exists yet).
    try:
        from core.query_queue import get_queue_manager
        if get_queue_manager().cancel_queued(execution_id):
            found = True
    except Exception as exc:
        logger.debug("[cancel-router] queued-cancel probe failed for %s: %s",
                     execution_id, exc)

    # 2. Worker pool task (the normal running case).
    try:
        from core.worker_pool import get_pool
        if get_pool().cancel_by_execution_id(execution_id):
            found = True
    except RuntimeError:
        # Pool not initialised (early startup / tests) — registries below
        # are the legacy fallback, same as the old inline cancel path.
        logger.debug("[cancel-router] worker pool unavailable for %s",
                     execution_id)
    except Exception as exc:
        logger.debug("[cancel-router] pool cancel probe failed for %s: %s",
                     execution_id, exc)

    # 3. Module-level registries (pre-pool / streaming paths).
    try:
        from core.execution_state import cancellation_flags, running_tasks
        ev = cancellation_flags.get(execution_id)
        if ev is not None:
            ev.set()
            found = True
        task = running_tasks.get(execution_id)
        if task is not None and not task.done():
            try:
                # Thread-safe: the watcher may call from a worker thread
                # while the task lives on the event loop.
                task.get_loop().call_soon_threadsafe(task.cancel)
            except Exception:
                task.cancel()
            found = True
    except Exception as exc:
        logger.debug("[cancel-router] registry cancel probe failed for %s: %s",
                     execution_id, exc)

    return found


def poll_cancel_requests(db_manager) -> List[str]:
    """One watcher sweep: find executions with a durable cross-pod cancel
    request and try to effect them LOCALLY.  Only the pod that owns the
    running task finds anything; everywhere else this is a no-op.

    Returns the execution_ids that were signalled locally this sweep.
    """
    if db_manager is None:
        return []
    try:
        pending = db_manager.get_cancel_requested_executions()
    except Exception as exc:
        logger.debug("[cancel-router] cancel-request poll failed: %s", exc)
        return []
    effected: List[str] = []
    for eid in pending:
        try:
            if signal_local_cancel(eid):
                effected.append(eid)
                logger.info("[cancel-router] honoured cross-pod cancel for %s "
                            "(this pod owns the running task)", eid)
        except Exception as exc:
            logger.debug("[cancel-router] local signal failed for %s: %s",
                         eid, exc)
    return effected
