"""BrainPrewarm -- predictive warm-up driven by co-access learning.

Phase 155 (2026-06-25) -- the brain's "anticipates the next query"
layer.  When a query finishes on table A, the co-access learner
predicts the top-N tables most-likely-queried next.  This module
fires async warm-up tasks for those tables:

  * Pre-load the iceberg manifest list on the API pod (KB-size --
    NOT data files).  Next query against the predicted table avoids
    the initial metadata fetch.
  * Send a keep-warm ping to the Spark Connect session manager so
    the cluster doesn't idle-shut-down between predicted queries.

Constraints honoured (per Phase 155 plan):
  * No data file reads.  Manifest list is metadata.
  * No writer-side dependency.
  * Bounded cost: cap predictions to top-N (default 3) so a single
    co-access table doesn't trigger 50 warm-ups.
  * Throttled: never fires the same warm-up twice within a window
    (15s default) so a burst of queries on the same table doesn't
    spam the warm-up loop.

Strategic shape:
  * One public function: ``trigger_after_query(bucket, prefix)``.
  * Reads from existing ``iceberg_co_access``; never writes.
  * Fires async daemons threads; never blocks the calling query.
"""
from __future__ import annotations

import logging
import threading
import time
from typing import Any

logger = logging.getLogger(__name__)


# ── Config ────────────────────────────────────────────────────────────


def _cfg(key: str, fallback: Any) -> Any:
    try:
        from core.config import get as _g
        return _g("brain_prewarm", key, fallback)
    except Exception:
        return fallback


def enabled() -> bool:
    """Master switch.  Default True.  Fail-OPEN -- module errors
    never break query execution."""
    return bool(_cfg("enabled", True))


def top_n() -> int:
    """Cap on neighbours to pre-warm per call.  Default 3."""
    return int(_cfg("top_n", 3) or 3)


def throttle_seconds() -> int:
    """Don't re-fire a warm-up for the same target within this window."""
    return int(_cfg("throttle_seconds", 15) or 15)


# ── In-flight throttle ────────────────────────────────────────────────


_THROTTLE_LOCK = threading.Lock()
_LAST_WARMED: dict = {}    # cache_id -> last warm-up timestamp


def _try_acquire(cache_id: str) -> bool:
    now = time.monotonic()
    with _THROTTLE_LOCK:
        last = _LAST_WARMED.get(cache_id, 0)
        if now - last < throttle_seconds():
            return False
        _LAST_WARMED[cache_id] = now
        return True


def reset_for_tests() -> None:
    with _THROTTLE_LOCK:
        _LAST_WARMED.clear()


# ── Public API ────────────────────────────────────────────────────────


def trigger_after_query(
    bucket: str, table_prefix: str,
    db_manager: Any = None,
    s3_client_factory: Any = None,
) -> None:
    """Fire async warm-ups for predicted-next tables.

    Called AFTER a query completes (success or failure -- co-access
    pattern is the same).  Non-blocking -- spawns daemon threads.
    Fail-OPEN: any error logs at debug; never propagates.

    Args:
      bucket:           The bucket of the table this query touched.
      table_prefix:     The table's iceberg prefix.
      db_manager:       Optional override; falls back to
                         ``core.database.get_db_manager()``.
      s3_client_factory: Optional s3 client factory; used by the
                         manifest pre-load path.  When omitted,
                         falls back to query_history_prefetcher's
                         default factory.
    """
    if not enabled():
        return
    try:
        _do_trigger(bucket, table_prefix, db_manager, s3_client_factory)
    except Exception as exc:
        logger.debug(
            "[brain-prewarm] trigger non-fatal for %s/%s: %s",
            bucket, table_prefix, exc,
        )


def _do_trigger(
    bucket: str, table_prefix: str,
    db_manager: Any,
    s3_client_factory: Any,
) -> None:
    if not bucket or not table_prefix:
        return

    # Predict top-N neighbours from the co-access learner.
    try:
        from core.iceberg_co_access import (
            _cache_id as _build_cache_id,
            predict_co_accessed,
        )
    except Exception:
        return
    target = _build_cache_id(bucket, table_prefix)
    neighbours = predict_co_accessed(target, limit=top_n())
    if not neighbours:
        return

    for cache_id in neighbours:
        if not _try_acquire(cache_id):
            continue
        # Parse the cache_id back into (bucket, prefix).  Format is
        # ``"{bucket}/{prefix}/metadata/"`` -- iceberg_co_access uses
        # this exact shape (verified at module level there).
        try:
            parts = cache_id.rstrip("/").split("/", 1)
            if len(parts) < 2:
                continue
            n_bucket = parts[0]
            n_prefix = parts[1].rsplit("/metadata", 1)[0]
        except Exception:
            continue

        # Spawn ONE daemon thread per neighbour so a slow warm-up
        # on one doesn't block the others.
        threading.Thread(
            target=_warmup_one,
            args=(n_bucket, n_prefix, db_manager, s3_client_factory),
            name=f"brain-prewarm-{n_bucket}/{n_prefix}",
            daemon=True,
        ).start()


def _warmup_one(
    bucket: str, prefix: str,
    db_manager: Any,
    s3_client_factory: Any,
) -> None:
    """Warm path for a single predicted neighbour:
      1. Resolve the current iceberg snapshot pointer (1 small S3 GET).
      2. Pre-fetch the manifest list (1 small S3 GET).
      3. Best-effort ping the Spark Connect manager so the cluster
         stays warm.
    """
    try:
        if db_manager is None:
            try:
                from core.database import get_db_manager
                db_manager = get_db_manager()
            except Exception:
                pass
        if s3_client_factory is None:
            try:
                from core.query_history_prefetcher import (
                    make_default_s3_client_factory,
                )
                if db_manager is not None:
                    s3_client_factory = make_default_s3_client_factory(db_manager)
            except Exception:
                pass
        if db_manager is None or s3_client_factory is None:
            return
        # The brain_freshness ensure_fresh() helper already does
        # snapshot resolution + manifest pre-load via its non-blocking
        # path.  Reusing it means we get the freshness ledger update
        # for free + don't duplicate the metadata-read code.
        try:
            from core.brain_freshness import ensure_fresh
            ensure_fresh(
                db_manager, s3_client_factory,
                bucket, prefix,
                source="prewarm",  # distinct from cron / watcher / lazy
                blocking=False,
            )
        except Exception as _ef_exc:
            logger.debug(
                "[brain-prewarm] ensure_fresh for %s/%s failed: %s",
                bucket, prefix, _ef_exc,
            )

        # Keep the Spark Connect cluster warm.  Best-effort: the
        # session manager either has a no-op ping or doesn't; if
        # missing, swallow + move on.
        try:
            # 2026-09-01 -- was ``get_spark_connect_manager``, which does not
            # exist, so this raised ImportError every sweep and the ping
            # never happened.  The module IS the manager; ``keep_warm`` is
            # still optional, and its absence stays a no-op exactly as the
            # comment above intends.
            from core import spark_connect_session_manager as _scm
            if _scm.is_initialised() and hasattr(_scm, "keep_warm"):
                _scm.keep_warm()
        except Exception as _sc_exc:
            logger.debug(
                "[brain-prewarm] spark keep-warm failed: %s", _sc_exc,
            )
    except Exception as exc:
        logger.debug(
            "[brain-prewarm] warmup-one error for %s/%s: %s",
            bucket, prefix, exc,
        )


def in_flight_count() -> int:
    """Phase 156 deep-dive R23 -- public accessor for the throttle
    ring size.  Admin telemetry endpoint used to reach into the
    ``_LAST_WARMED`` internal directly, which would silently break
    on any refactor.  This helper is the contract."""
    with _THROTTLE_LOCK:
        return len(_LAST_WARMED)


__all__ = [
    "trigger_after_query",
    "enabled",
    "top_n",
    "throttle_seconds",
    "reset_for_tests",
    "in_flight_count",
]
