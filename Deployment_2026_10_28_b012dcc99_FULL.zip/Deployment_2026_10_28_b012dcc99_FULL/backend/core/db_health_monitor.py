"""DBHealthMonitor -- tracks Postgres latency for the brain's degraded mode.

When the metadata DB (Postgres) gets slow, the brain's pruning DB
lookups (manifest_stats / supplement / bloom) compound the slowness:
every query pays the 2s timeout penalty + falls back to scan-all anyway.

This monitor watches recent DB call outcomes.  When the monitor flips
to ``degraded``, the brain's QueryFeatureBuilder SKIPS the DB load
entirely; the brain falls back to non-DB sensors (cost_model,
coordinator, hostile_pattern) so queries still route correctly via
engine_router's config rules.  Self-heals: the first fast DB call
after a degraded window resets the monitor to healthy.

Design properties:
  * Stateless OUTSIDE the singleton -- the monitor IS the state.
  * Thread-safe (single lock; tiny critical section).
  * Constant-memory (bounded ring of recent latencies).
  * Operator-tunable via env vars OR config knobs.
  * Surfaces snapshot for /status + Prometheus counter for /metrics.

Per memory feedback_single_chokepoint_pattern, feedback_pruning_is_the_brain.
"""
from __future__ import annotations

import collections
import logging
import os
import threading
import time
from typing import Deque, Dict, Optional


logger = logging.getLogger(__name__)


class DBHealthMonitor:
    """Bounded-memory monitor of recent DB call outcomes.

    Health state:
      * ``healthy``:    last N calls below latency threshold OR all OK
      * ``degraded``:   M consecutive timeouts OR p95(latency_window) > threshold
      * Transitions log at INFO level (operator visibility)

    Counters surfaced for /metrics:
      * total_calls, total_timeouts, total_failures, transitions_to_degraded
    """

    # Defaults; overridable via env / .from_env().
    DEFAULT_WINDOW_SIZE          = 32        # rolling latency window
    DEFAULT_TIMEOUT_RATIO        = 0.30      # >= 30% timeouts in window = degraded
    DEFAULT_CONSECUTIVE_TIMEOUTS = 3         # 3 in a row = degraded immediately
    DEFAULT_P95_DEGRADED_MS      = 1500.0    # 1.5s p95 latency = degraded
    DEFAULT_RECOVERY_FAST_MS     = 100.0     # call < 100ms while degraded = recovered

    def __init__(
        self,
        window_size:          int   = DEFAULT_WINDOW_SIZE,
        timeout_ratio:        float = DEFAULT_TIMEOUT_RATIO,
        consecutive_timeouts: int   = DEFAULT_CONSECUTIVE_TIMEOUTS,
        p95_degraded_ms:      float = DEFAULT_P95_DEGRADED_MS,
        recovery_fast_ms:     float = DEFAULT_RECOVERY_FAST_MS,
    ) -> None:
        self.window_size          = max(4, int(window_size))
        self.timeout_ratio        = float(timeout_ratio)
        self.consecutive_timeouts = max(1, int(consecutive_timeouts))
        self.p95_degraded_ms      = float(p95_degraded_ms)
        self.recovery_fast_ms     = float(recovery_fast_ms)

        self._lock     = threading.Lock()
        self._latencies: Deque[float] = collections.deque(maxlen=self.window_size)
        self._consecutive_timeout = 0
        self._degraded = False

        # Cumulative counters (never reset; exposed via /metrics)
        self.total_calls               = 0
        self.total_timeouts            = 0
        self.total_failures            = 0
        self.transitions_to_degraded   = 0
        self.transitions_to_healthy    = 0
        self.degraded_since_unix       = 0.0

    # ── recording ──────────────────────────────────────────────────────

    def record_call(
        self,
        latency_ms: float,
        succeeded:  bool = True,
        was_timeout: bool = False,
    ) -> None:
        """Record one DB call outcome.

        Args:
          latency_ms:  measured wall-clock duration in milliseconds.
          succeeded:   True if the call returned a result (even an empty
                        one); False on raised exception (not timeout).
          was_timeout: True if the wrapper timed out and abandoned the
                        result.  Counted SEPARATELY from succeeded=False
                        (timeouts are the headline degraded-mode signal).
        """
        with self._lock:
            self.total_calls += 1
            self._latencies.append(float(latency_ms))
            if was_timeout:
                self.total_timeouts += 1
                self._consecutive_timeout += 1
            else:
                self._consecutive_timeout = 0
            if not succeeded and not was_timeout:
                self.total_failures += 1
            self._reevaluate_health(latency_ms, was_timeout)

    def _reevaluate_health(self, last_latency_ms: float, was_timeout: bool) -> None:
        """Decide whether to flip the degraded flag.  Called inside the
        lock; never blocks (constant-time computations)."""
        was_degraded = self._degraded
        # Degraded triggers (any one):
        #   1. N consecutive timeouts
        #   2. >= timeout_ratio of recent window were timeouts
        #   3. p95 latency >= threshold
        if self._consecutive_timeout >= self.consecutive_timeouts:
            self._degraded = True
        elif len(self._latencies) >= self.window_size:
            recent_timeout_count = sum(
                1 for ms in self._latencies if ms >= self.p95_degraded_ms
            )
            if recent_timeout_count / self.window_size >= self.timeout_ratio:
                self._degraded = True
            else:
                p95 = self._compute_p95()
                if p95 >= self.p95_degraded_ms:
                    self._degraded = True

        # Recovery trigger: a single fast call below recovery threshold
        # while degraded = self-heal.  No "stayed-healthy for N calls"
        # requirement -- the first proof of life is enough.
        if was_degraded and not was_timeout \
                and last_latency_ms <= self.recovery_fast_ms:
            self._degraded = False

        # Log state transitions at INFO (operator-visible).
        if not was_degraded and self._degraded:
            self.transitions_to_degraded += 1
            self.degraded_since_unix = time.time()
            logger.warning(
                "DB-degraded: postgres latency exceeded thresholds "
                "(consecutive_timeouts=%d, last_ms=%.0f).  Brain will "
                "skip manifest_stats DB lookups until recovery.",
                self._consecutive_timeout, last_latency_ms,
            )
        elif was_degraded and not self._degraded:
            self.transitions_to_healthy += 1
            dur = time.time() - self.degraded_since_unix
            self.degraded_since_unix = 0.0
            logger.info(
                "DB-healthy: postgres recovered (last call %.0fms after "
                "%.1fs in degraded mode).  Brain resumes manifest_stats "
                "DB lookups.", last_latency_ms, dur,
            )

    def _compute_p95(self) -> float:
        """p95 latency from the rolling window.  Caller holds lock."""
        if not self._latencies:
            return 0.0
        sorted_ms = sorted(self._latencies)
        idx = int(0.95 * (len(sorted_ms) - 1))
        return sorted_ms[idx]

    # ── querying ───────────────────────────────────────────────────────

    def is_degraded(self) -> bool:
        """Cheap check used on the query hot path.  Single read of a
        bool under the lock."""
        with self._lock:
            return self._degraded

    def snapshot(self) -> Dict[str, object]:
        """Diagnostic snapshot for /status + Prometheus /metrics."""
        with self._lock:
            p95 = self._compute_p95()
            return {
                "degraded":                  self._degraded,
                "consecutive_timeout":       self._consecutive_timeout,
                "window_size":               self.window_size,
                "recent_call_count":         len(self._latencies),
                "recent_p95_ms":             round(p95, 1),
                "total_calls":               self.total_calls,
                "total_timeouts":            self.total_timeouts,
                "total_failures":            self.total_failures,
                "transitions_to_degraded":   self.transitions_to_degraded,
                "transitions_to_healthy":    self.transitions_to_healthy,
                "degraded_since_unix":       self.degraded_since_unix,
                "thresholds": {
                    "timeout_ratio":         self.timeout_ratio,
                    "consecutive_timeouts":  self.consecutive_timeouts,
                    "p95_degraded_ms":       self.p95_degraded_ms,
                    "recovery_fast_ms":      self.recovery_fast_ms,
                },
            }

    # ── factory ────────────────────────────────────────────────────────

    @classmethod
    def from_env(cls) -> "DBHealthMonitor":
        """Construct from env vars so ops can tune per-pod without
        a code change.  Unset vars fall back to safe defaults."""
        def _intenv(k: str, d: int) -> int:
            try:
                return int(os.environ.get(k, "") or d)
            except (TypeError, ValueError):
                return d
        def _floatenv(k: str, d: float) -> float:
            try:
                return float(os.environ.get(k, "") or d)
            except (TypeError, ValueError):
                return d
        return cls(
            window_size          = _intenv("QS_DB_HEALTH_WINDOW",
                                            cls.DEFAULT_WINDOW_SIZE),
            timeout_ratio        = _floatenv("QS_DB_HEALTH_TIMEOUT_RATIO",
                                              cls.DEFAULT_TIMEOUT_RATIO),
            consecutive_timeouts = _intenv("QS_DB_HEALTH_CONSECUTIVE_TIMEOUTS",
                                            cls.DEFAULT_CONSECUTIVE_TIMEOUTS),
            p95_degraded_ms      = _floatenv("QS_DB_HEALTH_P95_DEGRADED_MS",
                                              cls.DEFAULT_P95_DEGRADED_MS),
            recovery_fast_ms     = _floatenv("QS_DB_HEALTH_RECOVERY_FAST_MS",
                                              cls.DEFAULT_RECOVERY_FAST_MS),
        )


# ── module-level singleton ──────────────────────────────────────────────


_singleton: Optional[DBHealthMonitor] = None
_singleton_lock = threading.Lock()


def get_monitor() -> DBHealthMonitor:
    """Process-wide DBHealthMonitor, lazily constructed from env."""
    global _singleton
    if _singleton is None:
        with _singleton_lock:
            if _singleton is None:
                _singleton = DBHealthMonitor.from_env()
    return _singleton


def reset_monitor() -> None:
    """Test hook -- drop the singleton so the next get_monitor()
    call re-reads env."""
    global _singleton
    with _singleton_lock:
        _singleton = None


__all__ = ["DBHealthMonitor", "get_monitor", "reset_monitor"]
