"""BF-428G — Admin API for the pluggable S3 reader system.

Endpoints:
  GET  /api/admin/s3-readers/status   — list available readers + current
                                          config (default + per-conn map +
                                          master switch state)
  PUT  /api/admin/s3-readers/config   — update default + per_connection map
                                          + Athena settings + auto_route +
                                          master switch
  POST /api/admin/s3-readers/test     — run a synthetic dry-run against a
                                          named reader (returns can_handle
                                          + a sample read against an empty
                                          file list to validate config
                                          without burning S3 calls)

All endpoints require admin role.  Mutations are audited via
core.audit.audit_event.

Design notes:
  - Config is held in JSON (core/config.py default + persisted via the
    admin config endpoint).  This API READS via the typed accessors and
    WRITES via the same path other admin sections use (set_config /
    write_config).  We don't introduce a new persistence layer.
  - Validation: reader names against the registry (unknown name = 400);
    per_connection keys must be int-coercible.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from api.deps import require_admin
from core.audit import audit_event
# BF-430D — module-level imports.  These were previously per-call to avoid
# theoretical circular imports, but neither core.s3_readers nor core.config
# imports from api.* so the cycle never existed.  Hoisting them removes ~7
# duplicate import lines and makes the call sites cleaner.
from core.s3_readers import (
    ReadRequest,
    available_readers,
    get_reader,
    set_router,
)
from core.s3_readers import telemetry as _telemetry
from core.config import s3_readers as _s3r_cfg
# BF-430D — import the module rather than binding ``set`` directly so
# tests can patch ``core.config.set`` and have the patch take effect on
# our call site.  ``from core.config import set as _config_set`` would
# bind a new name in this module, defeating those patches.
import core.config as _core_config
from core.error_sanitizer import sanitize_error

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/admin/s3-readers", tags=["admin", "s3-readers"])


# ── Request / response shapes ────────────────────────────────────────────


class S3ReadersStatusResponse(BaseModel):
    available: List[str]
    default: str
    per_connection: Dict[str, str]
    auto_route_enabled: bool
    integration_enabled: bool
    athena_workgroup: str
    athena_database: str
    athena_output_location: str
    athena_poll_interval_seconds: float
    athena_timeout_seconds: int
    s3_select_max_file_bytes: int
    pyarrow_max_rows: int
    pyarrow_default_region: str


class ReaderMetadata(BaseModel):
    """One reader's UI-facing metadata.  BF-428K — backend is the
    single source of truth for the reader list + descriptions; frontend
    consumes via ``s3Readers.metadata()`` instead of hardcoding."""
    name: str
    output_kind: str
    label: str
    description: str


# Friendly labels + descriptions live here so a future reader doesn't
# require touching 3 frontend files (BQB chip, CQB menu, AdminSection).
_READER_METADATA: Dict[str, Dict[str, str]] = {
    "direct_httpfs": {
        "label": "Direct httpfs",
        "description": "DuckDB httpfs reads s3:// directly. Best when "
                        "VPC endpoint is reachable; declines under proxy.",
    },
    "full_predownload": {
        "label": "Full predownload",
        "description": "Boto3 downloads ENTIRE files to NFS. Safe "
                        "fallback; transfers all bytes.",
    },
    "smart_predownload": {
        "label": "Smart predl (cache)",
        "description": "PyArrow + s3fs filtered read, persisted to NFS "
                        "cache. Cache hits = 0 S3 cost on repeat.",
    },
    "pyarrow_s3fs": {
        "label": "PyArrow + S3FS",
        "description": "PyArrow + s3fs in-memory read. Column projection "
                        "+ row-group pruning; transfers ~5-20% of file "
                        "bytes.",
    },
    "s3_select": {
        "label": "S3 Select (1-file)",
        "description": "Server-side WHERE pushdown via S3 Select. "
                        "Single-file scans only; transfers only "
                        "matching rows.",
    },
    "athena": {
        "label": "Athena (server-side)",
        "description": "AWS Athena (Presto-on-S3) runs SQL inside AWS. "
                        "ZERO bytes through proxy. Needs database + "
                        "output_location config.",
    },
}


class S3ReadersConfigUpdate(BaseModel):
    default: Optional[str] = Field(None, description="Reader name or 'auto'")
    per_connection: Optional[Dict[str, str]] = Field(
        None, description="connection_id (string) -> reader_name")
    auto_route_enabled: Optional[bool] = None
    integration_enabled: Optional[bool] = Field(
        None, description="MASTER SWITCH — controls whether queries actually "
                          "route through the new system")
    athena_workgroup: Optional[str] = None
    athena_database: Optional[str] = None
    athena_output_location: Optional[str] = None
    athena_poll_interval_seconds: Optional[float] = None
    athena_timeout_seconds: Optional[int] = None
    s3_select_max_file_bytes: Optional[int] = None
    pyarrow_max_rows: Optional[int] = None
    pyarrow_default_region: Optional[str] = None


class S3ReadersTestRequest(BaseModel):
    reader: str = Field(..., description="Reader name to test")
    bucket: str = Field("test-bucket", description="Bucket for synthetic ReadRequest")
    s3_keys: List[str] = Field(default_factory=lambda: ["test-key.parquet"])
    sql: Optional[str] = None
    projection: Optional[List[str]] = None


class S3ReadersTestResponse(BaseModel):
    reader: str
    can_handle: bool
    can_handle_error: Optional[str] = None
    config_summary: Dict[str, Any]


# BF-430D — single source of truth for the scalar fields update_config
# accepts.  Computed from S3ReadersConfigUpdate to prevent drift between
# the Pydantic schema and the for-loop that persists them.  Excludes the
# fields that need custom validation (default, per_connection).
_PASSTHROUGH_FIELDS: tuple = tuple(
    name for name in S3ReadersConfigUpdate.model_fields.keys()
    if name not in ("default", "per_connection")
)


# BF-430D — config-summary keys per reader.  Replaces the hardcoded
# if/elif ladder in the test endpoint with a data-driven map; adding a
# new reader's relevant config keys is now a single edit instead of a
# code change in the handler.  Empty list = name + output_kind only.
_READER_CONFIG_SUMMARY_KEYS: Dict[str, tuple] = {
    "athena": ("athena_workgroup", "athena_database", "athena_output_location"),
    "s3_select": ("s3_select_max_file_bytes",),
    "pyarrow_s3fs": ("pyarrow_max_rows", "pyarrow_default_region"),
    "smart_predownload": ("cache_parquet_compression", "arrow_temp_prefix"),
}


# ── GET /status ──────────────────────────────────────────────────────────


@router.get("/status", response_model=S3ReadersStatusResponse)
async def get_status(_user=Depends(require_admin)):
    """List registered readers + current config."""
    per_conn_raw = _s3r_cfg.per_connection
    per_conn = {str(k): str(v) for k, v in per_conn_raw.items()} \
        if isinstance(per_conn_raw, dict) else {}

    return S3ReadersStatusResponse(
        available=available_readers(),
        default=_s3r_cfg.default,
        per_connection=per_conn,
        auto_route_enabled=_s3r_cfg.auto_route_enabled,
        integration_enabled=_s3r_cfg.integration_enabled,
        athena_workgroup=_s3r_cfg.athena_workgroup,
        athena_database=_s3r_cfg.athena_database,
        athena_output_location=_s3r_cfg.athena_output_location,
        athena_poll_interval_seconds=_s3r_cfg.athena_poll_interval_seconds,
        athena_timeout_seconds=_s3r_cfg.athena_timeout_seconds,
        s3_select_max_file_bytes=_s3r_cfg.s3_select_max_file_bytes,
        pyarrow_max_rows=_s3r_cfg.pyarrow_max_rows,
        pyarrow_default_region=_s3r_cfg.pyarrow_default_region,
    )


# ── GET /readers — UI-facing reader metadata ───────────────────────────


@router.get("/readers", response_model=List[ReaderMetadata])
async def list_readers(_user=Depends(require_admin)):
    """Return UI metadata for every registered reader.  BF-428K —
    frontend consumes this instead of hardcoding the reader list, so
    a future Phase doesn't need to touch BQB/CQB/Admin .tsx files."""
    out: List[ReaderMetadata] = []
    for name in available_readers():
        r = get_reader(name)
        meta = _READER_METADATA.get(name, {})
        out.append(ReaderMetadata(
            name=name,
            output_kind=getattr(r, "output_kind", "unknown") if r else "unknown",
            label=meta.get("label", name),
            description=meta.get("description", ""),
        ))
    return out


# ── GET /telemetry — BF-430C ─────────────────────────────────────────────


@router.get("/telemetry")
async def get_telemetry(_user=Depends(require_admin)):
    """Return per-reader counters + roll-up.  Used by the admin UI to
    show which readers are actually picked, their success rates,
    cache-hit rates, throughput, etc.  Operators use this data to
    tune cost_overrides for their workload.

    Counters are in-memory per-process (die on restart).  For
    persistent metrics use Prometheus / Grafana.
    """
    return {
        "overall": _telemetry.overall(),
        "by_reader": _telemetry.snapshot(),
    }


@router.post("/telemetry/reset")
async def reset_telemetry(user=Depends(require_admin)):
    """Clear all telemetry counters.  Useful when an admin wants to
    measure a specific time window after a config change."""
    n = _telemetry.reset()
    audit_event(
        user.get("username") if isinstance(user, dict) else None,
        "s3_readers.telemetry_reset",
        details={"readers_reset": n},
    )
    return {"reset": n}


# ── PUT /config ──────────────────────────────────────────────────────────


def _set_cfg(key: str, value: Any) -> None:
    """Persist via core.config.set (the path other admin sections
    already use; named ``set`` not ``set_config`` despite shadowing
    the builtin)."""
    _core_config.set("s3_readers", key, value)


@router.put("/config")
async def update_config(payload: S3ReadersConfigUpdate,
                        user=Depends(require_admin)):
    """Update one or more s3_readers settings.  Validates reader names
    against the registry; rejects unknown names with 400.
    """
    avail = set(available_readers())
    allowed_default = avail | {"auto"}

    changes: Dict[str, Any] = {}

    # Validate default
    if payload.default is not None:
        if payload.default not in allowed_default:
            raise HTTPException(
                status_code=400,
                detail=f"unknown reader {payload.default!r} — "
                       f"available: {sorted(allowed_default)}",
            )
        _set_cfg("default", payload.default)
        changes["default"] = payload.default

    # Validate per_connection
    if payload.per_connection is not None:
        normalised: Dict[str, str] = {}
        for k, v in payload.per_connection.items():
            try:
                int(k)
            except (TypeError, ValueError):
                raise HTTPException(
                    status_code=400,
                    detail=f"per_connection key {k!r} must be int-coercible",
                )
            if v not in avail:
                raise HTTPException(
                    status_code=400,
                    detail=f"per_connection[{k}]={v!r} is not a registered reader",
                )
            normalised[str(k)] = v
        _set_cfg("per_connection", normalised)
        changes["per_connection"] = normalised

    # BF-430D — pass-through scalars derived from the Pydantic schema (single
    # source of truth = S3ReadersConfigUpdate).  Adding a new scalar to the
    # model is enough; this loop picks it up automatically.
    for field in _PASSTHROUGH_FIELDS:
        v = getattr(payload, field, None)
        if v is not None:
            _set_cfg(field, v)
            changes[field] = v

    # Reset router so config changes take effect on next get_router()
    set_router(None)

    audit_event(
        user.get("username") if isinstance(user, dict) else None,
        "s3_readers.config_updated",
        details={"changes": changes},
    )
    return {"updated": changes}


# ── POST /test ───────────────────────────────────────────────────────────


@router.post("/test", response_model=S3ReadersTestResponse)
async def test_reader(payload: S3ReadersTestRequest,
                       _user=Depends(require_admin)):
    """Synthetic dry-run against a named reader: validates can_handle
    against a constructed ReadRequest.  Does NOT execute read() — the
    test is config-validation only (no S3 calls, no AWS spend)."""
    reader = get_reader(payload.reader)
    if reader is None:
        raise HTTPException(
            status_code=404,
            detail=f"reader {payload.reader!r} not registered",
        )

    req = ReadRequest(
        bucket=payload.bucket,
        s3_keys=payload.s3_keys,
        sql=payload.sql,
        projection=payload.projection,
        s3_client=None,  # no real client — most readers will decline
    )

    can_handle = False
    err: Optional[str] = None
    try:
        can_handle = bool(reader.can_handle(req))
    except Exception as exc:
        err = sanitize_error(str(exc))

    # BF-430D — data-driven config summary.  Replaces the hardcoded
    # if/elif ladder; adding a reader's relevant config keys is now a
    # single edit in _READER_CONFIG_SUMMARY_KEYS.
    summary: Dict[str, Any] = {"name": reader.name,
                                "output_kind": reader.output_kind}
    for key in _READER_CONFIG_SUMMARY_KEYS.get(payload.reader, ()):
        try:
            summary[key] = getattr(_s3r_cfg, key)
        except Exception:
            # A typo'd or removed config key shouldn't blank the whole
            # response — the reader's name + output_kind are what the UI
            # needs to render the result regardless.
            continue

    return S3ReadersTestResponse(
        reader=payload.reader,
        can_handle=can_handle,
        can_handle_error=err,
        config_summary=summary,
    )
