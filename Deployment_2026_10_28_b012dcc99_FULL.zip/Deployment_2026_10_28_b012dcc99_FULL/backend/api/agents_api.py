"""
Admin API for Self-Healing Agents — Phase 120.

Endpoints for viewing agent config, decision history, stats, and dry-run testing.
"""

import logging
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from core.db_async import adb
# BF-352 audit fix: import require_admin directly so FastAPI invokes it as a
# real dependency (the existing `Depends(lambda: _require_admin)` indirection
# returns the function reference, NOT the result of calling it — the admin
# check was effectively bypassed).  New CRUD + health endpoints use this
# direct import.  Leaving the older endpoints untouched to avoid regressing
# whatever request flow they currently work with.
from api.deps import require_admin as _admin_dep

logger = logging.getLogger(__name__)
router = APIRouter(tags=["agents"])

# ── Dependency injection (set from main.py) ───────────────────────────────────

_db_manager = None
_get_current_user = None
_require_admin = None


def set_agents_dependencies(db_manager, get_current_user_dep, require_admin_dep):
    global _db_manager, _get_current_user, _require_admin
    _db_manager = db_manager
    _get_current_user = get_current_user_dep
    _require_admin = require_admin_dep


# ── Pydantic models ──────────────────────────────────────────��───────────────


class AgentConfigResponse(BaseModel):
    enabled: bool
    decision_engine: str
    agents: list


class AgentTestRequest(BaseModel):
    error_message: str = Field(..., min_length=1)
    error_type: str = "Exception"


# ── Endpoints ─────────────────────────────────────────────────────────────────


@router.get("/api/admin/agents/config")
async def get_agents_config(user: dict = Depends(_admin_dep)):
    """Return current agent configuration and registered agents."""
    from core.agents import get_orchestrator
    from core.config import _cfg

    orch = get_orchestrator()
    agents_cfg = _cfg.get("agents", {})
    qr_cfg = agents_cfg.get("query_resilience", {})

    return {
        "enabled": agents_cfg.get("enabled", False),
        "decision_engine": agents_cfg.get("decision_engine", "rules"),
        # 2026-09-15: configured vs EFFECTIVE engine, with the refusal reason
        # when they differ.  ``decision_engine`` above is what the config
        # says; this is what the process does.
        "decision_engine_status": (orch.decision_engine_status() if orch
                                   else _no_orchestrator_status(agents_cfg)),
        "llm_provider": agents_cfg.get("llm_provider", ""),
        "llm_model": agents_cfg.get("llm_model", ""),
        "auto_retry_enabled": qr_cfg.get("auto_retry_enabled", True),
        "agents": orch.list_agents() if orch and orch.enabled else [],
        "config": {
            "query_resilience": qr_cfg,
            "dq_monitor": agents_cfg.get("dq_monitor", {}),
            "data_pipeline": agents_cfg.get("data_pipeline", {}),
        },
    }


def _no_orchestrator_status(agents_cfg: dict) -> dict:
    return {"configured": agents_cfg.get("decision_engine", "rules"),
            "effective": None, "routable": False,
            "reason": "agent orchestrator not initialised on this pod"}


_LLM_KEYS = ("decision_engine", "llm_provider", "llm_api_key", "llm_system_account")


@router.put("/api/admin/agents/config")
async def update_agents_config(
    body: dict,
    user: dict = Depends(_admin_dep),
):
    """Update agents configuration section (admin only).

    Phase 125: Allows admins to toggle auto-retry, LLM engine, DQ alerting, etc.
    Only whitelisted keys are accepted to prevent config corruption.
    Changes are in-process only (same pattern as other admin config endpoints).
    """
    from core.config import set as cfg_set, get as cfg_get

    # 2026-09-15 -- refuse an ``llm`` engine THIS server cannot run, at the
    # moment it is chosen and with the reason, before anything is written.
    # Persisting it would only make the next restart refuse to start any
    # agent (LLMEngineUnavailable); the admin learns here instead.
    if any(k in body for k in _LLM_KEYS):
        from core.config import _cfg as _cfg_root
        _merged = {**(_cfg_root.get("agents", {}) or {}),
                   **{k: body[k] for k in _LLM_KEYS if k in body}}
        if str(_merged.get("decision_engine") or "rules") == "llm":
            from core.agents.decision_engine import LLMEngine
            _reason = LLMEngine.unavailability(_merged)
            if _reason:
                raise HTTPException(
                    status_code=400,
                    detail=(f"agents.decision_engine='llm' cannot be honoured "
                            f"on this server: {_reason}.  Nothing was changed; "
                            f"install the SDK / set the key, or choose "
                            f"decision_engine='rules' deliberately."))

    _ALLOWED_TOP = {
        "enabled", "decision_engine", "llm_provider", "llm_api_key",
        "llm_model", "llm_system_account", "llm_max_calls_per_hour",
        "llm_timeout_seconds", "llm_rules_first", "max_decision_log_days",
    }
    _ALLOWED_SUB = {
        "query_resilience": {
            "enabled", "max_retries", "backoff_seconds",
            "auto_add_partition_filter", "auto_refresh_credentials",
            "auto_reinstall_extensions", "auto_reduce_memory",
            "cte_partition_analysis", "auto_retry_enabled", "auto_retry_strategies",
        },
        "dq_monitor": {
            "enabled", "schedule_minutes", "null_threshold",
            "row_count_spike_threshold", "row_count_drop_threshold",
            "freshness_hours", "connections", "webhooks_enabled", "notify_admins",
        },
        "data_pipeline": {
            "enabled", "auto_profile_uploads", "suggest_type_fixes",
        },
    }

    updated: Dict[str, Any] = {}
    username = (user or {}).get("username", "admin")
    for key, value in body.items():
        if key in _ALLOWED_TOP:
            cfg_set("agents", key, value)
            # BF-352: also persist to agent_config table so the change
            # survives pod restart.  RulesEngine reads from DB on init.
            if _db_manager is not None:
                try:
                    _db_manager.agent_config_set(
                        key, value, updated_by=username,
                        description=f"agents.{key}",
                    )
                except Exception as exc:
                    logger.warning("agent_config_set failed for %s: %s", key, exc)
            updated[key] = value
        elif key in _ALLOWED_SUB and isinstance(value, dict):
            current_sub = cfg_get("agents", key) or {}
            for sub_key, sub_val in value.items():
                if sub_key in _ALLOWED_SUB[key]:
                    current_sub[sub_key] = sub_val
                    updated[f"{key}.{sub_key}"] = sub_val
            cfg_set("agents", key, current_sub)
            if _db_manager is not None:
                try:
                    _db_manager.agent_config_set(
                        key, current_sub, updated_by=username,
                        description=f"agents.{key}",
                    )
                except Exception as exc:
                    logger.warning("agent_config_set failed for %s: %s", key, exc)

    if not updated:
        raise HTTPException(400, "No valid config keys provided")

    logger.info("Agent config updated by %s: %s",
                 username, list(updated.keys()))
    return {"detail": "Updated", "updated": updated, "persisted": _db_manager is not None}


# ── BF-352: CRUD for agent_rules table ───────────────────────────────────────


@router.get("/api/admin/agents/rules")
async def list_agent_rules(
    kind: Optional[str] = None, enabled_only: bool = False,
    user: dict = Depends(_admin_dep),
):
    """List agent rules (query_fix or dq).  ?kind=query_fix narrows by family."""
    if not _db_manager:
        raise HTTPException(status_code=503, detail="Database not available")
    if kind and kind not in ("query_fix", "dq"):
        raise HTTPException(400, "kind must be 'query_fix' or 'dq'")
    return await adb(_db_manager.agent_rules_list, kind=kind,
                     enabled_only=enabled_only)


class AgentRuleUpsert(BaseModel):
    # Optional fields use Optional[T] = None so Pydantic v2 doesn't reject
    # the inferred non-Optional type when value is null.
    id:          Optional[int]   = None
    kind:        str             = "query_fix"
    enabled:     bool            = True
    priority:    int             = 0
    name:        Optional[str]   = None
    description: str
    severity:    Optional[str]   = None
    action:      Optional[str]   = None
    pattern:     Optional[str]   = None
    strategy:    Optional[str]   = None
    max_retries: Optional[int]   = None
    metric:      Optional[str]   = None
    op:          Optional[str]   = None
    threshold:   Optional[float] = None
    message:     Optional[str]   = None


@router.post("/api/admin/agents/rules")
async def upsert_agent_rule(
    body: AgentRuleUpsert,
    user: dict = Depends(_admin_dep),
):
    """Create or update an agent rule (whitelisted fields only).

    INSERT (id absent): full validation — kind required + pattern/strategy
    for query_fix or metric/op/threshold for dq.
    UPDATE (id present): only validate fields actually provided in the
    request body (Pydantic-level partial update via exclude_unset).
    """
    if not _db_manager:
        raise HTTPException(status_code=503, detail="Database not available")
    is_update = body.id is not None
    # Only fields explicitly supplied — defaults are NOT auto-applied on update
    supplied = body.model_dump(exclude_unset=True)

    if is_update:
        # Patch — required-field rules don't apply because the existing row
        # already has them.  Just validate the fields actually being changed.
        if "kind" in supplied and supplied["kind"] not in ("query_fix", "dq"):
            raise HTTPException(400, "kind must be 'query_fix' or 'dq'")
    else:
        # Insert — all required fields must be present in this request
        kind = supplied.get("kind", "query_fix")
        if kind not in ("query_fix", "dq"):
            raise HTTPException(400, "kind must be 'query_fix' or 'dq'")
        if kind == "query_fix" and not (supplied.get("pattern") and supplied.get("strategy")):
            raise HTTPException(400, "query_fix rule requires 'pattern' AND 'strategy'")
        if kind == "dq" and not (supplied.get("metric") and supplied.get("op")
                                  and supplied.get("threshold") is not None):
            raise HTTPException(400, "dq rule requires 'metric', 'op', 'threshold'")

    # Validate regex eagerly so admin sees the error immediately (applies
    # to both insert AND update paths whenever pattern is changed).
    if supplied.get("pattern"):
        import re as _re
        try:
            _re.compile(supplied["pattern"])
        except _re.error as exc:
            raise HTTPException(400, f"Invalid regex: {exc}")

    username = (user or {}).get("username", "admin")
    return await adb(_db_manager.agent_rules_upsert, supplied, updated_by=username)


@router.delete("/api/admin/agents/rules/{rule_id}")
async def delete_agent_rule(
    rule_id: int, user: dict = Depends(_admin_dep),
):
    if not _db_manager:
        raise HTTPException(status_code=503, detail="Database not available")
    ok = await adb(_db_manager.agent_rules_delete, int(rule_id))
    if not ok:
        raise HTTPException(404, f"Rule {rule_id} not found")
    return {"deleted": True, "id": rule_id}


@router.get("/api/admin/agents/health")
async def get_agents_health(user: dict = Depends(_admin_dep)):
    """Per-agent runtime health: registered, last decision, last action,
    error count over 24h, last error reason.

    Sources from agent_decisions table — no in-memory state needed so the
    endpoint is multi-pod safe."""
    from core.agents import get_orchestrator
    orch = get_orchestrator()
    if not _db_manager:
        raise HTTPException(status_code=503, detail="Database not available")
    registered = orch.list_agents() if (orch and orch.enabled) else []
    health = await adb(_db_manager.get_agent_health) if hasattr(
        _db_manager, "get_agent_health") else {}
    from core.config import _cfg as _cfg_root
    return {
        "orchestrator_enabled": bool(orch.enabled if orch else False),
        # 2026-09-15: an orchestrator that REFUSED (llm configured, no SDK /
        # key) is not "disabled" -- it says why here.
        "decision_engine_status": (
            orch.decision_engine_status() if orch
            else _no_orchestrator_status(_cfg_root.get("agents", {}) or {})),
        "agents": [
            {**a, **(health.get(a["name"], {}))}
            for a in registered
        ],
    }


@router.get("/api/admin/agents/history")
async def get_agents_history(
    limit: int = 100,
    agent_name: Optional[str] = None,
    user: dict = Depends(_admin_dep),
):
    """Return agent decision audit trail."""
    if not _db_manager:
        raise HTTPException(status_code=503, detail="Database not available")
    return _db_manager.list_agent_decisions(limit=min(limit, 500), agent_name=agent_name)


@router.get("/api/admin/agents/stats")
async def get_agents_stats(user: dict = Depends(_admin_dep)):
    """Return agent decision stats (counts by agent × action)."""
    if not _db_manager:
        raise HTTPException(status_code=503, detail="Database not available")
    return await adb(_db_manager.get_agent_stats)


@router.post("/api/admin/agents/test")
async def test_agent_rules(
    body: AgentTestRequest,
    user: dict = Depends(_admin_dep),
):
    """Dry-run an error message through the rules engine. Does NOT execute any fix.
    Uses the same DB-backed rules as production so admin sees what would
    actually happen, not just what the in-code defaults would do."""
    from core.agents.decision_engine import RulesEngine

    engine = RulesEngine(db_manager=_db_manager)
    classification = engine.classify_error(body.error_message, body.error_type, {})
    return {
        "input": {"error_message": body.error_message, "error_type": body.error_type},
        "classification": classification,
    }
