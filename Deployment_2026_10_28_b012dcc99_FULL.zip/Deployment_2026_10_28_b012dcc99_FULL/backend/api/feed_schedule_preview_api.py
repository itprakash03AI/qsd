"""Schedule preview — "what does this declaration MEAN in concrete dates".

BRD §2.1 (2026-09-02): the feed authoring UI lets an author declare a
schedule as one of five kinds (``core.feed.schedule``).  The UI cannot
render "next runs: Fri 30 Oct, Mon 30 Nov" itself, and it is RIGHT not
to try: business days depend on DB holiday rows and on the server
config ``feed_generation.default_weekend_days`` (see
``core.feed.calendar``) even when no calendar is attached.  A preview
computed in the browser would diverge from what ``due_on`` will do at
runtime, and a wrong preview is worse than none.

One read-only route:

* ``GET /api/feeds/schedule-preview`` — next N dates the declaration is
  DUE, computed with the SAME ``parse_schedule`` + ``due_on`` +
  ``BusinessCalendar`` the scheduler itself uses.  Nothing is
  reimplemented here, so the preview cannot drift from runtime.

Three states, three explicitly different response shapes (an
event-driven feed rendered as an empty date list would read to the
author as "this will never run", and "due on no day in the window" must
not look event-driven either):

* ``mode="dates"``            — ``due_dates`` is a non-empty list;
* ``mode="no_due_dates_in_window"`` — a DATE rule with no matching day
  in the bounded window; carries NO ``due_dates`` key, carries a
  ``message`` saying so (real case: workday 15 in a month with fewer
  than 15 business days);
* ``mode="event_driven"``     — ``on_completion_of`` has no date rule
  at all; carries ``upstream_feed`` and NO ``due_dates``/``window``.

Calendar honesty (requirement traced to ``core/feed/etl_dependency``,
which reports COULD-NOT-TELL for a named-but-missing calendar rather
than excusing the dependency): a calendar that is NAMED but does not
resolve is a 422 refusal, never a silent "every day is a business day"
preview.  When NO calendar is named anywhere, the preview honestly runs
with ``BusinessCalendar(None)`` — exactly what runtime ``due_on`` does —
and the response's ``calendar`` block says so (``resolved=False,
source="none"``) so the UI can display which calendar the dates were
computed against.
"""
from __future__ import annotations

import json
import logging
from datetime import date, datetime, timedelta, timezone
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from api.deps import get_current_user
from core.feed.calendar import BusinessCalendar, BusinessCalendarRepo
from core.feed.schedule import Due, ScheduleError, due_on, parse_schedule

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/feeds", tags=["feeds"])

# Module-level dependency (same wiring pattern as api/run_surface_api.py).
_db_manager: Any = None


def set_feed_schedule_preview_dependencies(db_manager: Any) -> None:
    global _db_manager
    _db_manager = db_manager


# Bounds.  The walk is over CALENDAR days, one due_on per day, so the
# worst case is MAX_HORIZON_DAYS pure-function calls — bounded by
# construction, an author cannot declare a rule that makes it spin.
DEFAULT_COUNT = 5
MAX_COUNT = 20
DEFAULT_HORIZON_DAYS = 90
MAX_HORIZON_DAYS = 366


def _parse_start_date(raw: Optional[str]) -> date:
    """Today (UTC) when unspecified; a 422 REFUSAL when malformed —
    same judgement as run_surface: an author who typed a date and got
    today's preview would read it as that date's answer."""
    if not raw:
        return datetime.now(timezone.utc).date()
    try:
        return date.fromisoformat(str(raw)[:10])
    except ValueError:
        raise HTTPException(
            status_code=422,
            detail=f"start_date {raw!r} is not an ISO date (YYYY-MM-DD)")


@router.get("/schedule-preview")
def schedule_preview(
    declaration: Optional[str] = Query(
        default=None,
        description="JSON-encoded UNSAVED schedule declaration, e.g. "
                    '{"kind": "month_end"} — the exact dict the author '
                    "is about to save"),
    feed_id: Optional[int] = Query(
        default=None,
        description="Existing feed whose STORED schedule_declaration "
                    "and calendar_name should be previewed"),
    calendar_name: Optional[str] = Query(
        default=None,
        description="Calendar override; beats the declaration's own "
                    "calendar_name and the feed's stored one"),
    count: int = Query(default=DEFAULT_COUNT, ge=1, le=MAX_COUNT),
    horizon_days: int = Query(default=DEFAULT_HORIZON_DAYS, ge=1,
                              le=MAX_HORIZON_DAYS),
    start_date: Optional[str] = Query(default=None),
    user: dict = Depends(get_current_user),
):
    """Next ``count`` dates this schedule is DUE, within a bounded window.

    Precedence when BOTH ``declaration`` and ``feed_id`` are given: the
    ``declaration`` wins.  The whole point of a preview is the UNSAVED
    choice — an author editing feed 55's schedule is asking "what would
    THIS mean", and answering from the stored row would preview the
    thing they are replacing.  The ``feed_id`` still contributes its
    stored ``calendar_name`` as a fallback (an edited kind usually
    keeps the feed's calendar), and a dangling ``feed_id`` is still a
    404 — a typo'd id must not silently fall back to "no stored
    calendar".

    Calendar resolution order: explicit ``calendar_name`` param → the
    declaration's own ``calendar_name`` field → the feed's stored
    column.  A resolved name that does not exist in ``feed_calendars``
    is a 422 refusal (see module docstring), never a silent
    every-day-is-a-business-day preview.
    """
    if _db_manager is None:          # pragma: no cover - wiring guard
        raise HTTPException(status_code=503,
                            detail="schedule preview not wired to a database")
    start = _parse_start_date(start_date)

    # ── Resolve the declaration (unsaved input wins; see docstring) ────────
    stored_calendar_name: Optional[str] = None
    if feed_id is not None:
        fc = _db_manager.get_feed_config(feed_id)
        if fc is None:
            raise HTTPException(status_code=404,
                                detail=f"feed {feed_id} not found")
        stored_calendar_name = fc.get("calendar_name")

    if declaration is not None:
        try:
            decl = json.loads(declaration)
        except json.JSONDecodeError as exc:
            raise HTTPException(
                status_code=422,
                detail=f"declaration is not valid JSON: {exc}")
    elif feed_id is not None:
        decl = fc.get("schedule_declaration")
        if decl is None:
            raise HTTPException(
                status_code=422,
                detail=f"feed {feed_id} has no schedule_declaration — it is "
                       "on the legacy cron-only path; there is no declared "
                       "rule to preview")
    else:
        raise HTTPException(
            status_code=422,
            detail="provide either 'declaration' (JSON, the unsaved "
                   "authoring choice) or 'feed_id' (an existing feed's "
                   "stored declaration)")

    # ── Parse with the runtime's own parser; its message IS the answer ─────
    try:
        schedule = parse_schedule(decl)
    except ScheduleError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    if schedule is None:
        raise HTTPException(
            status_code=422,
            detail="declaration is JSON null — there is no rule to preview")

    # ── Resolve the calendar, refusing to excuse a named-but-missing one ───
    cal_name: Optional[str] = None
    cal_source = "none"
    if calendar_name and calendar_name.strip():
        cal_name, cal_source = calendar_name.strip(), "request"
    elif schedule.calendar_name:
        cal_name, cal_source = schedule.calendar_name, "declaration"
    elif stored_calendar_name:
        cal_name, cal_source = stored_calendar_name, "feed"

    if cal_name:
        try:
            spec = BusinessCalendarRepo(_db_manager).get(cal_name)
        except Exception as exc:
            # Same judgement as etl_dependency: a calendar we FAILED TO
            # READ yields could-not-tell, never a preview computed on
            # a calendar we never read.
            raise HTTPException(
                status_code=503,
                detail=f"calendar {cal_name!r} could not be loaded ({exc}); "
                       "refusing to preview against a calendar that was "
                       "never read")
        if spec is None:
            raise HTTPException(
                status_code=422,
                detail=f"calendar {cal_name!r} (from {cal_source}) does not "
                       "exist or is inactive.  Refusing to preview as if "
                       "every day were a business day — a wrong preview is "
                       "worse than none (same judgement as the dependency "
                       "gate's COULD-NOT-TELL for a named-but-missing "
                       "calendar)")
        cal = BusinessCalendar(spec)
        calendar_block = {
            "name": cal_name,
            "source": cal_source,
            "resolved": True,
            "weekend_days": list(spec.weekend_days),
            "holiday_count": (len(spec.holidays_explicit)
                              + len(spec.holidays_recurring_md)),
        }
    else:
        # No calendar named ANYWHERE.  Runtime due_on runs with
        # BusinessCalendar(None) in exactly this case — every calendar
        # day is a business day — so the honest preview matches it and
        # SAYS SO, rather than inventing weekend arithmetic runtime
        # will not apply.
        cal = BusinessCalendar(None)
        calendar_block = {
            "name": None,
            "source": "none",
            "resolved": False,
            "note": "no calendar attached — every calendar day counts as "
                    "a business day, matching what due_on(calendar=None) "
                    "will do at runtime.  Attach a calendar_name for "
                    "weekend/holiday-aware dates.",
        }

    schedule_block: dict = {"kind": schedule.kind}
    if schedule.workday_n is not None:
        schedule_block["workday_n"] = schedule.workday_n
    if schedule.cron_expression is not None:
        schedule_block["cron_expression"] = schedule.cron_expression
        # due_on answers only the calendar-filter half of a cron rule
        # (BRD §6); pretending these dates are firing times would be a
        # wrong preview.
        schedule_block["note"] = (
            "cron preview shows the calendar-filter half only: every "
            "business day the cron is ALLOWED to fire.  The cron's own "
            "minute/hour/day fields are owned by APScheduler and are "
            "not evaluated here.")

    # ── Event-driven: a distinct answer, never an empty list ───────────────
    first = due_on(schedule, start, cal)
    if first is Due.EVENT_DRIVEN:
        return {
            "mode": "event_driven",
            "upstream_feed": schedule.upstream_feed,
            "message": f"this feed runs when feed "
                       f"{schedule.upstream_feed!r} completes — it has no "
                       "date rule, so there are no scheduled dates to "
                       "preview.  This is NOT 'never runs'.",
            "schedule": schedule_block,
            "calendar": calendar_block,
        }

    # ── Bounded forward walk (one due_on per calendar day) ─────────────────
    window_end = start + timedelta(days=horizon_days - 1)
    due_dates: list = []
    d = start
    verdict = first
    while d <= window_end and len(due_dates) < count:
        if d != start:
            verdict = due_on(schedule, d, cal)
        # Identity comparison, deliberately: Due.__bool__ raises for
        # EVENT_DRIVEN, and a rule cannot change kind mid-walk, but the
        # comparison must not depend on that.
        if verdict is Due.DUE:
            due_dates.append(d.isoformat())
        d += timedelta(days=1)

    window = {"start": start.isoformat(), "end": window_end.isoformat(),
              "days": horizon_days}
    if not due_dates:
        return {
            "mode": "no_due_dates_in_window",
            "message": f"this date rule is due on no day between "
                       f"{window['start']} and {window['end']} "
                       f"({horizon_days} days).  It is a date rule — not "
                       "event-driven — but no day in this window satisfies "
                       "it (real example: workday 15 in a month with fewer "
                       "than 15 business days).  Widen horizon_days or "
                       "check the rule.",
            "window": window,
            "schedule": schedule_block,
            "calendar": calendar_block,
        }
    # 2026-10-13 -- each due RUN day with the business date its data is
    # for (schedule.business_date_for: the same mapping SOD uses).  For a
    # rule of the run day itself the two are equal.
    from core.feed.schedule import business_date_for
    tasks = [{"runs_on": x, "business_date": business_date_for(schedule, date.fromisoformat(x), cal).isoformat()}
             for x in due_dates]
    schedule_block["business_date"] = schedule.business_date
    return {
        "mode": "dates",
        "due_dates": due_dates,
        "tasks": tasks,
        "count_requested": count,
        "count_found": len(due_dates),
        "window_exhausted": len(due_dates) < count,
        "window": window,
        "schedule": schedule_block,
        "calendar": calendar_block,
    }
