"""★ Request bodies whose SHAPE decides the numbers must refuse unknown keys.

2026-09-17 (FB-22).  Measured on the live stack: a business report executed
with ``{"filters": [...]}`` -- where the field is named ``extra_filters`` --
returned **HTTP 200, five regions, large plausible totals, and no WHERE
clause at all**::

    AFRICA reported  45,230,223,902.22
    AFRICA truth     19,205,642,405.48      -> 2.35x TOO HIGH, silently

Confirmed general: ``{"extra_filterz": [...]}`` and
``{"totally_made_up_key": 123}`` were all accepted and all produced no WHERE.

Pydantic ignores unknown fields by default, which is the right default for a
body whose fields are *options*.  It is the wrong default for a body whose
fields decide WHICH ROWS ARE COUNTED.  This is the CLAUDE.md §4 invariant on
the reporting surface -- "a filter that cannot be rendered must refuse, never
silently drop (it would return MORE rows)" -- and it returned more rows'
worth of value while still looking like a report.

What makes it the dangerous kind rather than the annoying kind: there is no
symptom.  The status is 200, the shape is right, the totals are the right
order of magnitude, and the only way to notice is to recompute from source or
read the generated SQL.  A user who mistypes a key gets a confident wrong
answer, and so does everyone they forward it to.

IT IS A CONTRACT CHANGE, deliberately.  A client already sending a stray key
will now get a 422 that names it.  That is the point: it was already being
ignored, so the client was already not getting what it asked for -- the 422
is the first time anyone finds out.  Applied only to bodies where a dropped
field changes the RESULT, not to every model in the API.
"""
from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class StrictRequestModel(BaseModel):
    """A request body that REFUSES unknown fields instead of ignoring them.

    Pydantic's ``extra="forbid"`` already produces a 422 naming the offending
    key and listing nothing else, which is exactly the diagnosis the caller
    needs -- "extra_forbidden: filters".  No custom handler is required and
    none is added: a second error-shaping site would be one more place for
    the two answers to drift.
    """

    model_config = ConfigDict(extra="forbid")
