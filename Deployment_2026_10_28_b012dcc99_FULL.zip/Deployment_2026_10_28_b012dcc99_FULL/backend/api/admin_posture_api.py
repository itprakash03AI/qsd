"""Admin ``GET /api/admin/effective-posture`` -- the effective-posture card.

One read-only route, admin-only.  Every value is computed by
``core.effective_posture.collect_posture`` so the UI, a test fed a
fabricated fleet and an operator's curl all see the same answer; this
module holds nothing but the wiring (the same pattern as
``api/feed_daemons_api.py``: a module-level ``_db_manager`` set once from
``main.py``).
"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException

from api.deps import require_admin
from core.db_async import adb
from core.effective_posture import collect_posture

router = APIRouter(prefix="/api/admin", tags=["posture"])

_db_manager: Any = None


def set_posture_dependencies(db_manager: Any) -> None:
    global _db_manager
    _db_manager = db_manager


@router.get("/effective-posture")
async def get_effective_posture(user: dict = Depends(require_admin)):
    """Every default-off gate and daemon: configured value, effective value
    (``on`` / ``off`` / ``COULD_NOT_DETERMINE``), where it runs, why, and a
    cheap consequence.  Unknown is never reported as off."""
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Database not available")
    return await adb(collect_posture, _db_manager)
