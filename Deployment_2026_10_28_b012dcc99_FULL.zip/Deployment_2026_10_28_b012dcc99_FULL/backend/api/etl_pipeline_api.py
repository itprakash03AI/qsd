"""ETL Pipeline API — CRUD, trigger, webhook, circuit breakers (Phase 127)."""
import asyncio
import hashlib
import hmac
import logging
from datetime import datetime, timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field

from api.deps import get_current_user, require_admin
from core.db_async import adb

logger = logging.getLogger(__name__)
router = APIRouter(tags=["etl-pipelines"])


# BF-NONBLOCK-AUDIT-5
async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)

# Module-level dependencies
_db_manager = None
_auth_cfg = None
_broadcast_fn = None


def set_etl_pipeline_dependencies(db_manager, auth_cfg, broadcast_fn=None):
    global _db_manager, _auth_cfg, _broadcast_fn
    _db_manager = db_manager
    _auth_cfg = auth_cfg
    _broadcast_fn = broadcast_fn


# ── Pydantic Models ──────────────────────────────────────────────────────────

class EtlPipelineCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    source_connection_id: int
    source_s3_prefix: str = Field(..., min_length=1)
    source_file_pattern: Optional[str] = None
    dest_s3_bucket: str = Field(..., min_length=1)
    dest_s3_prefix: str = Field(..., min_length=1)
    dest_connection_id: Optional[int] = None
    dest_partition_columns: Optional[List[str]] = None
    transform_rules: Optional[dict] = None
    processing_mode: str = Field(default="overwrite", pattern="^(overwrite|append|merge|watermark)$")
    merge_key_columns: Optional[List[str]] = None
    watermark_column: Optional[str] = None
    execution_backend: str = Field(default="auto", pattern="^(auto|native|spark_connect|spark_submit|airflow)$")
    fallback_backend: Optional[str] = None
    size_thresholds: Optional[dict] = None
    spark_driver_memory: Optional[str] = None
    spark_executor_memory: Optional[str] = None
    spark_executor_cores: Optional[int] = None
    spark_num_executors: Optional[int] = None
    spark_extra_conf: Optional[dict] = None
    native_duckdb_memory_limit: Optional[str] = None
    trigger_type: str = Field(default="schedule", pattern="^(schedule|kafka|s3_sensor|external)$")
    trigger_config: Optional[dict] = None
    airflow_dag_id: Optional[str] = None
    airflow_pool: Optional[str] = None
    depends_on_pipeline_id: Optional[int] = None
    depends_on_pipeline_ids: Optional[List[int]] = None
    trigger_mode: str = Field(default="any", pattern="^(any|all)$")
    dependency_wait_timeout_seconds: int = 3600
    sla_deadline_time: Optional[str] = Field(
        None, pattern=r"^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$"
    )
    sla_notify_emails: Optional[str] = None
    sla_notify_webhook: Optional[str] = Field(None, min_length=8)


class EtlPipelineUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    is_active: Optional[bool] = None
    source_connection_id: Optional[int] = None
    source_s3_prefix: Optional[str] = None
    source_file_pattern: Optional[str] = None
    dest_s3_bucket: Optional[str] = None
    dest_s3_prefix: Optional[str] = None
    dest_connection_id: Optional[int] = None
    dest_partition_columns: Optional[List[str]] = None
    transform_rules: Optional[dict] = None
    processing_mode: Optional[str] = None
    merge_key_columns: Optional[List[str]] = None
    watermark_column: Optional[str] = None
    execution_backend: Optional[str] = None
    fallback_backend: Optional[str] = None
    size_thresholds: Optional[dict] = None
    spark_driver_memory: Optional[str] = None
    spark_executor_memory: Optional[str] = None
    spark_executor_cores: Optional[int] = None
    spark_num_executors: Optional[int] = None
    spark_extra_conf: Optional[dict] = None
    native_duckdb_memory_limit: Optional[str] = None
    trigger_type: Optional[str] = None
    trigger_config: Optional[dict] = None
    airflow_dag_id: Optional[str] = None
    airflow_pool: Optional[str] = None
    depends_on_pipeline_id: Optional[int] = None
    depends_on_pipeline_ids: Optional[List[int]] = None
    trigger_mode: Optional[str] = Field(None, pattern="^(any|all)$")
    dependency_wait_timeout_seconds: Optional[int] = None
    sla_deadline_time: Optional[str] = Field(
        None, pattern=r"^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$"
    )
    sla_notify_emails: Optional[str] = None
    sla_notify_webhook: Optional[str] = Field(None, min_length=8)


class EtlWebhookPayload(BaseModel):
    """Payload POSTed by Spark job on completion."""
    execution_id: str
    state: str = Field(..., pattern="^(completed|failed)$")
    output_path: Optional[str] = None
    error: Optional[str] = None
    input_row_count: Optional[int] = None
    output_row_count: Optional[int] = None
    output_file_count: Optional[int] = None
    output_size_bytes: Optional[int] = None
    watermark_value_after: Optional[str] = None
    source_s3_paths: Optional[List[str]] = None
    dest_s3_paths: Optional[List[str]] = None
    spark_app_id: Optional[str] = None


class EtlTriggerRequest(BaseModel):
    trigger_type: str = Field(default="manual")
    triggered_by: Optional[str] = None


# ── Pipeline CRUD ─────────────────────────────────────────────────────────────

@router.post("/api/etl-pipelines")
async def create_pipeline(body: EtlPipelineCreate, user=Depends(require_admin)):
    # SSRF validation on webhook URL (Phase 132-A)
    if body.sla_notify_webhook:
        try:
            from core.url_safety import validate_url_safety
            validate_url_safety(body.sla_notify_webhook)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=f"Webhook URL blocked: {exc}")
    data = body.model_dump(exclude_none=True)
    data["created_by"] = user.get("username", "admin")
    data["created_at"] = datetime.now(timezone.utc)
    data["updated_at"] = datetime.now(timezone.utc)
    try:
        result = await _adb(_db_manager.create_etl_pipeline, data)
    except Exception as exc:
        if "UNIQUE" in str(exc).upper():
            raise HTTPException(status_code=409, detail=f"Pipeline name '{body.name}' already exists")
        raise HTTPException(status_code=500, detail=str(exc))
    _audit("etl_pipeline_created", user, {"pipeline_id": result["id"], "name": body.name})
    return result


@router.get("/api/etl-pipelines/dependency-graph")
async def get_dependency_graph(user=Depends(get_current_user)):
    """Return pipeline dependency graph as adjacency list."""
    pipelines = await _adb(_db_manager.list_etl_pipelines)
    graph = []
    for p in pipelines:
        graph.append({
            "id": p["id"],
            "name": p["name"],
            "depends_on": p.get("depends_on_pipeline_id"),
            "is_active": p.get("is_active", True),
            "execution_backend": p.get("execution_backend", "auto"),
        })
    return graph


@router.get("/api/etl-pipelines")
async def list_pipelines(
    is_active: Optional[bool] = Query(None),
    execution_backend: Optional[str] = Query(None),
    user=Depends(get_current_user),
):
    return await _adb(_db_manager.list_etl_pipelines,
                      is_active=is_active, execution_backend=execution_backend)


@router.get("/api/etl-pipelines/{pipeline_id}")
async def get_pipeline(pipeline_id: int, user=Depends(get_current_user)):
    result = await _adb(_db_manager.get_etl_pipeline, pipeline_id)
    if not result:
        raise HTTPException(status_code=404, detail="Pipeline not found")
    return result


@router.put("/api/etl-pipelines/{pipeline_id}")
async def update_pipeline(pipeline_id: int, body: EtlPipelineUpdate, user=Depends(require_admin)):
    # SSRF validation on webhook URL (Phase 132-A)
    if body.sla_notify_webhook:
        try:
            from core.url_safety import validate_url_safety
            validate_url_safety(body.sla_notify_webhook)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=f"Webhook URL blocked: {exc}")
    data = body.model_dump(exclude_none=True)
    if not data:
        raise HTTPException(status_code=400, detail="No fields to update")
    result = await _adb(_db_manager.update_etl_pipeline, pipeline_id, data)
    if not result:
        raise HTTPException(status_code=404, detail="Pipeline not found")
    _audit("etl_pipeline_updated", user, {"pipeline_id": pipeline_id, "fields": list(data.keys())})
    return result


@router.delete("/api/etl-pipelines/{pipeline_id}")
async def deactivate_pipeline(pipeline_id: int, user=Depends(require_admin)):
    success = await _adb(_db_manager.deactivate_etl_pipeline, pipeline_id)
    if not success:
        raise HTTPException(status_code=404, detail="Pipeline not found")
    _audit("etl_pipeline_deactivated", user, {"pipeline_id": pipeline_id})
    return {"detail": "Pipeline deactivated"}


# ── Pipeline Trigger ──────────────────────────────────────────────────────────

@router.post("/api/etl-pipelines/{pipeline_id}/trigger")
async def trigger_pipeline(pipeline_id: int, body: EtlTriggerRequest = None,
                           user=Depends(require_admin)):
    from core.etl_engine import trigger_pipeline as _trigger, EtlEngineNotInitialised

    body = body or EtlTriggerRequest()

    # BF-518 (2026-05-28): prevent triggered_by spoofing.  Previous code
    # accepted ANY string in the request body, so an admin could
    # attribute a pipeline run to another user, corrupting audit trails
    # and lineage.  Now the server-side rule is:
    #   * default (no body field) → the authenticated user
    #   * explicit value matches the authenticated user → accept
    #   * explicit value matches a registered system_account name → accept
    #     (legitimate impersonation for batch / scheduled contexts)
    #   * anything else → 400 with a clear explanation
    _auth_user = user.get("username", "admin")
    _claimed = (body.triggered_by or "").strip()
    if not _claimed:
        triggered_by = _auth_user
    elif _claimed == _auth_user:
        triggered_by = _auth_user
    else:
        # Validate against system_accounts registry.  An admin may
        # legitimately trigger AS a system_account when wiring a new
        # pipeline or testing batch credentials.
        _is_system_account = False
        try:
            _accounts = await _adb(_db_manager.list_system_accounts) or []
            _is_system_account = any(
                (a.get("username") or a.get("name")) == _claimed
                for a in _accounts
            )
        except Exception as _sa_exc:
            logger.debug("BF-518 system_account lookup failed: %s", _sa_exc)
        if not _is_system_account:
            raise HTTPException(
                status_code=400,
                detail=(
                    f"triggered_by={_claimed!r} not accepted.  Audit "
                    f"integrity requires triggered_by to match either the "
                    f"authenticated user ({_auth_user!r}) or a registered "
                    f"system_account name.  Omit the field to record the "
                    f"run as {_auth_user!r}."
                ),
            )
        triggered_by = _claimed
        logger.info(
            "BF-518: admin %s triggered pipeline %s AS system_account %s",
            _auth_user, pipeline_id, _claimed,
        )

    try:
        execution = await _trigger(pipeline_id, body.trigger_type, triggered_by)
    except EtlEngineNotInitialised as exc:
        # FB-34: the route cannot work on this pod -- say so, with the
        # reason, as a 503 (an availability statement; `from None` declares
        # the detail authored so the chokepoint passes it through).
        raise HTTPException(status_code=503, detail=str(exc)) from None
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except Exception as exc:
        logger.error("ETL trigger failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))

    _audit("etl_pipeline_triggered", user, {
        "pipeline_id": pipeline_id,
        "execution_id": execution.get("execution_id"),
        "backend": execution.get("execution_backend_used"),
    })
    return execution


# ── Execution History ─────────────────────────────────────────────────────────

@router.get("/api/etl-pipelines/{pipeline_id}/executions")
async def list_executions(
    pipeline_id: int,
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    status: Optional[str] = Query(None),
    user=Depends(get_current_user),
):
    pipeline = await _adb(_db_manager.get_etl_pipeline, pipeline_id)
    if not pipeline:
        raise HTTPException(status_code=404, detail="Pipeline not found")
    return await _adb(_db_manager.list_etl_executions,
                      pipeline_id, limit=limit, offset=offset, status=status)


@router.get("/api/etl-pipeline-executions/{exec_id}")
async def get_execution(exec_id: int, user=Depends(get_current_user)):
    result = await _adb(_db_manager.get_etl_execution, exec_id)
    if not result:
        raise HTTPException(status_code=404, detail="Execution not found")
    return result


# ── Webhook (Spark callback) ─────────────────────────────────────────────────

@router.post("/api/webhooks/etl-complete")
async def etl_webhook(body: EtlWebhookPayload, request: Request):
    """Callback endpoint for Spark job completion.

    When webhook_secret is configured, validates HMAC-SHA256 signature
    from X-Webhook-Signature header. Without secret, falls back to
    network-level access control via K8s NetworkPolicy.
    """
    from core.config import etl_pipelines as _etl_cfg
    if not _etl_cfg.enabled:
        raise HTTPException(status_code=503, detail="ETL pipelines not enabled")

    # HMAC signature validation when secret is configured
    secret = _etl_cfg.webhook_secret
    if secret:
        sig_header = request.headers.get("X-Webhook-Signature", "")
        if not sig_header:
            raise HTTPException(status_code=401, detail="Missing X-Webhook-Signature header")
        raw_body = await request.body()
        expected = hmac.new(secret.encode(), raw_body, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(f"sha256={expected}", sig_header):
            logger.warning("[etl_webhook] Invalid HMAC signature from %s", request.client.host if request.client else "unknown")
            raise HTTPException(status_code=401, detail="Invalid webhook signature")

    from core.etl_engine import handle_etl_completion, EtlEngineNotInitialised

    metrics = {
        "input_row_count": body.input_row_count,
        "output_row_count": body.output_row_count,
        "output_file_count": body.output_file_count,
        "output_size_bytes": body.output_size_bytes,
        "watermark_value_after": body.watermark_value_after,
        "source_s3_paths": body.source_s3_paths,
        "dest_s3_paths": body.dest_s3_paths,
    }

    try:
        result = await handle_etl_completion(
            execution_id=body.execution_id,
            state=body.state,
            output_path=body.output_path,
            error=body.error,
            metrics=metrics,
        )
    except EtlEngineNotInitialised as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from None    # FB-34
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except Exception as exc:
        logger.error("ETL webhook handler failed: %s", exc)
        raise HTTPException(status_code=500, detail=str(exc))

    # Update spark_app_id if provided
    if body.spark_app_id and result:
        await adb(_db_manager.update_etl_execution, result["id"], {"spark_app_id": body.spark_app_id})

    return {"detail": "ok", "execution_id": body.execution_id}


# ── Admin Config ──────────────────────────────────────────────────────────────

@router.get("/api/admin/etl-pipelines/config")
async def get_config(user=Depends(require_admin)):
    from core.config import get as _cfg_get
    section = "etl_pipelines"
    keys = [
        "enabled", "max_concurrent_pipelines", "default_dag_id",
        "execution_history_retention_days", "cleanup_interval_hours",
        "poll_interval_seconds", "size_thresholds", "spark_defaults",
        "native_defaults", "on_complete", "sla", "dead_letter",
    ]
    return {k: _cfg_get(section, k) for k in keys}


_ETL_CONFIG_TYPES = {
    "enabled": bool, "max_concurrent_pipelines": int, "default_dag_id": str,
    "execution_history_retention_days": int, "cleanup_interval_hours": int,
    "poll_interval_seconds": int, "size_thresholds": dict, "spark_defaults": dict,
    "native_defaults": dict, "on_complete": dict, "sla": dict, "dead_letter": dict,
}


@router.put("/api/admin/etl-pipelines/config")
async def update_config(body: dict, user=Depends(require_admin)):
    from core.config import set as _cfg_set
    allowed_keys = set(_ETL_CONFIG_TYPES.keys())
    filtered = {k: v for k, v in body.items() if k in allowed_keys}
    if not filtered:
        raise HTTPException(status_code=400, detail="No valid config keys provided")
    # Phase 132-G: Type validation before persisting
    for k, v in filtered.items():
        expected = _ETL_CONFIG_TYPES.get(k)
        # bool is subclass of int in Python — reject bools for int-typed keys
        if expected is int and isinstance(v, bool):
            raise HTTPException(
                status_code=400,
                detail=f"Key '{k}' must be int, got bool",
            )
        if expected and not isinstance(v, expected):
            raise HTTPException(
                status_code=400,
                detail=f"Key '{k}' must be {expected.__name__}, got {type(v).__name__}",
            )
    for k, v in filtered.items():
        _cfg_set("etl_pipelines", k, v)
    _audit("etl_config_updated", user, {"keys": list(filtered.keys())})
    return {"detail": "Config updated", "keys": list(filtered.keys())}


# ── Circuit Breakers ──────────────────────────────────────────────────────────

@router.get("/api/admin/etl-pipelines/circuit-breakers")
async def get_circuit_breakers(user=Depends(require_admin)):
    from core.etl_engine import get_circuit_breaker_status
    return get_circuit_breaker_status()


@router.post("/api/admin/etl-pipelines/circuit-breakers/{backend}/reset")
async def reset_circuit_breaker(backend: str, user=Depends(require_admin)):
    from core.etl_engine import reset_circuit_breaker as _reset
    if not _reset(backend):
        raise HTTPException(status_code=404, detail=f"Unknown backend: {backend}")
    _audit("etl_circuit_breaker_reset", user, {"backend": backend})
    return {"detail": f"Circuit breaker '{backend}' reset"}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _audit(action: str, user: dict, details: dict = None):
    """Fire-and-forget audit log."""
    # 2026-08-20 -- THIS HAS NEVER LOGGED ANYTHING.  core.audit defines
    # audit_event / flush_pending / _do_audit; there is no ``audit_log``, so
    # the import raised ImportError on every call and the bare
    # ``except Exception: pass`` swallowed it.  Same defect in feed_api.
    try:
        from core.audit import audit_event
        audit_event(
            _db_manager,
            user or {},
            action=action,
            details=details,
        )
    except Exception:
        pass
