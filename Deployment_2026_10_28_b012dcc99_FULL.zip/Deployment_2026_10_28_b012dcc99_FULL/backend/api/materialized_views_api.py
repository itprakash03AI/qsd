"""
Materialized Views API — CRUD + refresh + scheduling for local parquet caches.

Endpoints:
  GET    /api/materialized-views                   — list all materialized views
  GET    /api/materialized-views/storage           — storage usage summary (admin)
  GET    /api/materialized-views/{id}              — get single view
  POST   /api/materialized-views                   — create a new view
  PUT    /api/materialized-views/{id}              — update view metadata / schedule
  DELETE /api/materialized-views/{id}              — delete view + local files
  POST   /api/materialized-views/{id}/refresh      — trigger a manual refresh
  GET    /api/materialized-views/{id}/status       — lightweight status poll
  GET    /api/materialized-views/{id}/schema       — read parquet schema from disk
"""

from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime, timezone
from typing import Optional

from core.error_sanitizer import sanitize_error
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from core.parquet_utils import read_resolved_schema
from core.db_async import adb

logger = logging.getLogger(__name__)

router = APIRouter(tags=["materialized-views"])

# ── Module-level singletons — populated by set_mv_dependencies() at startup ───
_db_manager   = None
_engine       = None
_conn_manager = None
_ws_manager   = None
_mv_cfg       = None

# _register_s3_views — legacy wiring slot.  main.py still assigns
# core.duckdb_views.register_s3_views here at startup, but since the
# 2026-08-23 consolidation the refresh implementation lives in
# core.mv_manager (which imports register_s3_views directly), so nothing in
# THIS module reads it any more.  Kept so main.py's assignment stays valid.
_register_s3_views = None


def set_mv_dependencies(db_manager, engine, conn_manager, ws_manager, mv_cfg):
    global _db_manager, _engine, _conn_manager, _ws_manager, _mv_cfg
    _db_manager   = db_manager
    _engine       = engine
    _conn_manager = conn_manager
    _ws_manager   = ws_manager
    _mv_cfg       = mv_cfg


# ── Pydantic models ────────────────────────────────────────────────────────────

class MaterializedViewCreateModel(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    description: Optional[str] = None
    connection_id: int
    table_name: str
    table_format: str = "parquet"
    partition_filter: Optional[dict] = None
    query_filter: Optional[str] = None
    schedule_config: Optional[dict] = None
    # BF-430A — per-MV reader override (registered name in core.s3_readers).
    # NULL/empty = use the global s3_readers config (default + per_connection).
    reader_override: Optional[str] = Field(None, max_length=64,
                                            pattern=r"^([a-z][a-z0-9_]*)?$")


class MaterializedViewUpdateModel(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    partition_filter: Optional[dict] = None
    query_filter: Optional[str] = None
    schedule_config: Optional[dict] = None
    is_active: Optional[bool] = None
    # BF-430A — per-MV reader override (empty string clears).
    reader_override: Optional[str] = Field(None, max_length=64,
                                            pattern=r"^([a-z][a-z0-9_]*)?$")


# ── Helper functions ───────────────────────────────────────────────────────────
#
# 2026-08-23 — CONSOLIDATION.  This module used to carry a private copy of the
# MV refresh (and of the schedule helpers).  The copy had drifted from
# core.mv_manager's: this one honoured the per-MV ``reader_override``
# (BF-430A) and streamed via Arrow, while the mv_manager one — used by the
# worker task path — silently ignored the override and converted row-by-row.
# The same MV refreshed DIFFERENTLY depending on which door triggered it.
# core/mv_manager.py is now the ONE implementation; these names remain so
# APScheduler jobs persisted with the textual reference
# ``api.materialized_views_api:_refresh_materialized_view_sync`` still
# resolve, and so main.py's wiring keeps working.

from core.mv_manager import (  # noqa: E402
    refresh_materialized_view_sync as _refresh_materialized_view_sync,
    setup_mv_schedule as _setup_mv_schedule,
    remove_mv_schedule as _remove_mv_schedule,
    validate_schedule_config as _validate_schedule_config,
    mv_refresh_is_stale as _mv_refresh_is_stale,
)


# ── Endpoints ──────────────────────────────────────────────────────────────────

from api.deps import get_current_user, require_admin, get_workspace_id  # noqa: E402
from core.roles import is_admin_like  # noqa: E402


# ── Ownership gates ─────────────────────────────────────────────────────────
# SECURITY 2026-08-17: six by-id routes bound `_user` and then never read it.
# Any authenticated user -- including a `viewer` -- could read, update, refresh
# and DELETE any other user's materialized view; the delete path additionally
# does `shutil.rmtree` on the MV's storage directory, so it destroyed data.
# The list and create routes in this same file ARE scoped (workspace_id /
# created_by), which makes this a per-route oversight rather than a policy.

def _mv_require_read(mv: dict, _user: dict, request: Optional[Request]) -> None:
    """Owner, admin, a legacy unowned MV, or same workspace.

    Deliberately permissive: an MV is a shared team artefact and the list route
    is workspace-scoped, so tightening reads to owner-only would break normal
    collaboration.  What this DOES close is the cross-workspace read.
    """
    if is_admin_like(_user):
        return
    if mv.get("created_by") == (_user or {}).get("username"):
        return
    mv_ws = mv.get("workspace_id")
    if mv_ws is None:
        return              # legacy / unscoped MV -- visible as it always was
    try:
        caller_ws = get_workspace_id(request) if request else None
    except Exception:
        caller_ws = None
    if caller_ws is not None and mv_ws == caller_ws:
        return
    raise HTTPException(404, "Materialized view not found")


def _mv_require_write(mv: dict, _user: dict) -> None:
    """Only the owner or an admin may mutate or destroy an MV."""
    if is_admin_like(_user):
        return
    if mv.get("created_by") == (_user or {}).get("username"):
        return
    if not mv.get("created_by"):
        return              # legacy unowned MV -- do not strand it
    raise HTTPException(403, "You do not own this materialized view")


@router.get("/api/materialized-views")
async def list_materialized_views(connection_id: Optional[int] = None,
                                   request: Request = None,
                                   _user: dict = Depends(get_current_user)):
    try:
        workspace_id = get_workspace_id(request) if request else None
        mvs = await adb(_db_manager.list_materialized_views, connection_id=connection_id, workspace_id=workspace_id)
        return mvs
    except Exception as e:
        logger.error("List MVs failed: %s", e, exc_info=True)
        raise HTTPException(500, f"Operation failed: {sanitize_error(str(e))}")


@router.get("/api/materialized-views/storage")
async def get_mv_storage(_user: dict = Depends(require_admin)):
    try:
        mvs = await adb(_db_manager.list_materialized_views, active_only=False)
        total_size = sum(mv.get("size_bytes", 0) for mv in mvs)
        max_bytes = _mv_cfg.max_size_mb * 1024 * 1024
        return {
            "total_views": len(mvs),
            "max_views": _mv_cfg.max_views,
            "total_size_bytes": total_size,
            "max_size_bytes": max_bytes,
            "usage_pct": round(total_size / max_bytes * 100, 1) if max_bytes else 0,
        }
    except Exception as e:
        raise HTTPException(500, f"Operation failed: {sanitize_error(str(e))}")


@router.get("/api/materialized-views/{mv_id}")
async def get_materialized_view(mv_id: int, request: Request = None,
                                _user: dict = Depends(get_current_user)):
    mv = await adb(_db_manager.get_materialized_view, mv_id)
    if not mv:
        raise HTTPException(404, "Materialized view not found")
    _mv_require_read(mv, _user, request)  # SECURITY 2026-08-17
    return mv


@router.post("/api/materialized-views")
async def create_materialized_view(body: MaterializedViewCreateModel,
                                    request: Request = None,
                                    _user: dict = Depends(get_current_user)):
    try:
        # Validate connection exists
        conn = await adb(_db_manager.get_connection, body.connection_id)
        if not conn:
            raise HTTPException(404, "Connection not found")

        # Check max views
        existing = await adb(_db_manager.list_materialized_views, active_only=False)
        if len(existing) >= _mv_cfg.max_views:
            raise HTTPException(400, f"Maximum {_mv_cfg.max_views} materialized views reached")

        # Check name uniqueness
        if await adb(_db_manager.get_materialized_view_by_name, body.name):
            raise HTTPException(400, f"Materialized view '{body.name}' already exists")

        # Validate table exists in connection
        reg_tables = conn.get("config", {}).get("registered_tables", [])
        if not any(rt["name"] == body.table_name for rt in reg_tables):
            raise HTTPException(400, f"Table '{body.table_name}' not found in connection")

        # BF-430A — validate reader_override against the live registry so the
        # admin gets fast feedback rather than silent router fallback later.
        _ro_in = (body.reader_override or "").strip() or None
        if _ro_in:
            from core.s3_readers import available_readers as _avail_readers
            _avail = set(_avail_readers())
            if _ro_in not in _avail:
                raise HTTPException(
                    400,
                    f"reader_override={_ro_in!r} is not a registered reader. "
                    f"Available: {sorted(_avail)}",
                )

        # Validate the schedule BEFORE creating the row — a bad cron
        # expression used to 500 AFTER the MV existed, so the retry then
        # failed with "already exists".
        if body.schedule_config:
            try:
                _validate_schedule_config(body.schedule_config)
            except ValueError as _sched_err:
                raise HTTPException(400, str(_sched_err))

        mv = await adb(_db_manager.create_materialized_view,
            name=body.name,
            description=body.description,
            connection_id=body.connection_id,
            table_name=body.table_name,
            table_format=body.table_format,
            partition_filter=body.partition_filter,
            query_filter=body.query_filter,
            schedule_config=body.schedule_config,
            reader_override=_ro_in,  # BF-430A
            created_by=_user.get("username", ""),
            workspace_id=get_workspace_id(request) if request else None,
        )

        # Set up schedule if provided.  setup returns (job_id, next_run) and
        # THIS route persists them — one writer for the job-id fact.
        if body.schedule_config:
            job_id, next_run = _setup_mv_schedule(mv["id"], body.schedule_config,
                                                  mv["name"])
            if job_id:
                mv = await adb(_db_manager.update_materialized_view, mv["id"],
                               apscheduler_job_id=job_id,
                               next_refresh_at=next_run) or mv
            else:
                # A schedule that silently never fires is a 200 with nothing
                # useful in it — say so.
                mv["schedule_warning"] = (
                    "Schedule saved, but the scheduler is not running on "
                    "this pod — auto-refresh will NOT fire until a pod "
                    "with the scheduler re-saves this schedule.")

        return mv
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Create MV failed: %s", e, exc_info=True)
        raise HTTPException(500, f"Operation failed: {sanitize_error(str(e))}")


@router.put("/api/materialized-views/{mv_id}")
async def update_materialized_view(mv_id: int, body: MaterializedViewUpdateModel,
                                    _user: dict = Depends(get_current_user)):
    try:
        mv = await adb(_db_manager.get_materialized_view, mv_id)
        if not mv:
            raise HTTPException(404, "Materialized view not found")
        _mv_require_write(mv, _user)  # SECURITY 2026-08-17

        updates = body.dict(exclude_unset=True)

        # Handle name uniqueness
        if "name" in updates and updates["name"] != mv["name"]:
            if await adb(_db_manager.get_materialized_view_by_name, updates["name"]):
                raise HTTPException(400, f"Name '{updates['name']}' already taken")

        # BF-430A — validate reader_override on update (empty string clears).
        if "reader_override" in updates:
            _ro_upd = (updates["reader_override"] or "").strip() or None
            if _ro_upd:
                from core.s3_readers import available_readers as _avail_readers
                _avail = set(_avail_readers())
                if _ro_upd not in _avail:
                    raise HTTPException(
                        400,
                        f"reader_override={_ro_upd!r} is not a registered reader. "
                        f"Available: {sorted(_avail)}",
                    )
            updates["reader_override"] = _ro_upd

        # Handle schedule change.
        # 2026-08-23 — the fresh job id used to be written by the setup
        # helper and then OVERWRITTEN with None by the **updates write below:
        # the live job kept firing but the DB forgot it existed, so it could
        # never be shown, replaced or removed — every schedule edit leaked
        # one more concurrently-refreshing job.  The helper now returns
        # (job_id, next_run) and this route persists them in its ONE write.
        _schedule_warning = None
        if "schedule_config" in updates:
            try:
                if updates["schedule_config"]:
                    _validate_schedule_config(updates["schedule_config"])
            except ValueError as _sched_err:
                raise HTTPException(400, str(_sched_err))

            # Remove old schedule
            if mv.get("apscheduler_job_id"):
                _remove_mv_schedule(mv["apscheduler_job_id"])
            updates["apscheduler_job_id"] = None
            updates["next_refresh_at"] = None

            # Set new schedule
            if updates["schedule_config"]:
                job_id, next_run = _setup_mv_schedule(
                    mv_id, updates["schedule_config"],
                    updates.get("name", mv["name"]))
                if job_id:
                    updates["apscheduler_job_id"] = job_id
                    updates["next_refresh_at"] = next_run
                else:
                    _schedule_warning = (
                        "Schedule saved, but the scheduler is not running "
                        "on this pod — auto-refresh will NOT fire until a "
                        "pod with the scheduler re-saves this schedule.")

        result = await adb(_db_manager.update_materialized_view, mv_id, **updates)
        if result is not None and _schedule_warning:
            result["schedule_warning"] = _schedule_warning
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Update MV %d failed: %s", mv_id, e, exc_info=True)
        raise HTTPException(500, f"Operation failed: {sanitize_error(str(e))}")


@router.delete("/api/materialized-views/{mv_id}")
async def delete_materialized_view(mv_id: int, _user: dict = Depends(get_current_user)):
    try:
        mv = await adb(_db_manager.get_materialized_view, mv_id)
        if not mv:
            raise HTTPException(404, "Materialized view not found")
        _mv_require_write(mv, _user)  # SECURITY 2026-08-17 -- this path rmtree()s

        # Remove scheduler job
        if mv.get("apscheduler_job_id"):
            _remove_mv_schedule(mv["apscheduler_job_id"])

        # Remove local files
        import shutil
        mv_dir = os.path.join(_mv_cfg.storage_dir, str(mv_id))
        if os.path.exists(mv_dir):
            shutil.rmtree(mv_dir)

        await adb(_db_manager.delete_materialized_view, mv_id)
        return {"status": "deleted", "id": mv_id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Delete MV %d failed: %s", mv_id, e, exc_info=True)
        raise HTTPException(500, f"Operation failed: {sanitize_error(str(e))}")


@router.post("/api/materialized-views/{mv_id}/refresh")
async def refresh_materialized_view(mv_id: int, _user: dict = Depends(get_current_user)):
    mv = await adb(_db_manager.get_materialized_view, mv_id)
    if not mv:
        raise HTTPException(404, "Materialized view not found")
    _mv_require_write(mv, _user)  # SECURITY 2026-08-17
    if mv["status"] == "refreshing":
        # A refresh heartbeats the row every 30s; "refreshing" with a stale
        # heartbeat means the owning process died mid-build.  Without this
        # check a restart mid-refresh bricked the MV forever: status never
        # left "refreshing", so this 409 held for good and the UI's Refresh
        # button stayed disabled with no way forward.
        if not _mv_refresh_is_stale(mv):
            raise HTTPException(409, "Refresh already in progress")
        logger.warning("MV %d: stale 'refreshing' status (dead build) — "
                       "allowing a new refresh.", mv_id)

    # Run in background thread
    loop = asyncio.get_running_loop()
    loop.run_in_executor(None, _refresh_materialized_view_sync, mv_id)
    return {"status": "refresh_started", "id": mv_id}


@router.get("/api/materialized-views/{mv_id}/status")
async def get_mv_status(mv_id: int, request: Request = None,
                        _user: dict = Depends(get_current_user)):
    mv = await adb(_db_manager.get_materialized_view, mv_id)
    if not mv:
        raise HTTPException(404, "Materialized view not found")
    _mv_require_read(mv, _user, request)  # SECURITY 2026-08-17
    return {
        "id": mv["id"],
        "name": mv["name"],
        "status": mv["status"],
        "row_count": mv["row_count"],
        "file_count": mv["file_count"],
        "size_bytes": mv["size_bytes"],
        "last_refresh_at": mv["last_refresh_at"],
        "last_refresh_duration": mv["last_refresh_duration"],
        "last_error": mv["last_error"],
    }


@router.get("/api/materialized-views/{mv_id}/schema")
async def get_mv_schema(mv_id: int, request: Request = None,
                        _user: dict = Depends(get_current_user)):
    """Read schema from local parquet files of a materialized view."""
    mv = await adb(_db_manager.get_materialized_view, mv_id)
    if not mv:
        raise HTTPException(404, "Materialized view not found")
    _mv_require_read(mv, _user, request)  # SECURITY 2026-08-17
    if mv["status"] != "ready":
        raise HTTPException(400, "Materialized view not ready — refresh first")

    # BF-NONBLOCK-AUDIT: glob + parquet schema read are sync FS/IO; wrapped
    # in asyncio.to_thread so directories with hundreds of parquet files
    # don't block the event loop.
    mv_dir = os.path.join(_mv_cfg.storage_dir, str(mv_id))
    import glob as _glob_mod

    def _read_mv_schema():
        pq_files = sorted(_glob_mod.glob(os.path.join(mv_dir, "*.parquet")))
        if not pq_files:
            return None
        return read_resolved_schema(pq_files[0]), len(pq_files)

    res = await asyncio.to_thread(_read_mv_schema)
    if res is None:
        raise HTTPException(400, "No parquet files found — refresh needed")
    try:
        columns, file_count = res
        return {"columns": columns, "source": mv["name"], "file_count": file_count}
    except Exception as e:
        logger.error("MV schema read failed for %d: %s", mv_id, e)
        raise HTTPException(500, f"Failed to read schema: {e}")
