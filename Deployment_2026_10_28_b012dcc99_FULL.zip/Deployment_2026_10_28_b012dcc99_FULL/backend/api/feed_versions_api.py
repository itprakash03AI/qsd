"""Feed definition version history — list, one, diff, restore (2026-09-27).

Thin shell over ``core.feed.definition_history``:

* ``GET  /api/feeds/{id}/versions``                 — newest first, each
  with the fields it changed against the previous version (no values);
* ``GET  /api/feeds/{id}/versions/{version}``        — one snapshot, secrets
  masked exactly as ``GET /api/feeds/{id}`` masks them;
* ``GET  /api/feeds/{id}/versions/diff?from_version=&to_version=`` — the
  field-level diff, masked;
* ``POST /api/feeds/{id}/versions/{version}/restore`` — goes through THE
  update (``feed_api.update_feed``, the one place a feed is written), so
  every rule that route enforces -- name immutability once run, filename
  vocabulary, cross-source preflight, calendar / group validity, the
  acceptance hold -- applies to a restore exactly as to an edit.  Refused
  (409) for a retired feed: a retirement is a stated lifecycle decision
  and a restore must not undo it by the side door.

The view gate is the feed's own (``_require_feed``): the other principal
sees a 403/404, never the definition.  ``version`` in the path is the
feed's monotonic version NUMBER (what the UI shows), not the row id.
"""
from __future__ import annotations

import logging
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from api.deps import get_current_user
from core.db_async import adb
from core.feed import definition_history as _history

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/feeds", tags=["feed-versions"])


def _feed_api():
    # The feed routes' module globals (db manager, the view gate, the
    # masker, the update route) are bound at app wiring; import lazily so
    # this module never imports feed_api at collection time.
    from api import feed_api
    return feed_api


def _db() -> Any:
    db = _feed_api()._db_manager
    if db is None:  # pragma: no cover - wiring guard
        raise HTTPException(status_code=503,
                            detail="feed versions not wired to a database")
    return db


def _version_row(feed_id: int, version: int) -> dict:
    rows = _db().list_feed_definition_versions(int(feed_id)) or []
    for row in rows:
        if int(row.get("version") or 0) == int(version):
            return row
    raise HTTPException(
        status_code=404,
        detail=f"Feed {feed_id} has no definition version {version}")


def _masked(definition: Any) -> dict:
    mask = _feed_api()._mask_feed_secrets
    return mask(dict(definition or {})) or {}


def _summary(row: dict, previous: Optional[dict]) -> dict:
    """A list entry: the row without its definition, plus what changed."""
    out = {k: v for k, v in row.items() if k != "definition"}
    out["changed_fields"] = _history.changed_fields(
        (previous or {}).get("definition") if previous else None,
        row.get("definition") or {})
    return out


@router.get("/{feed_id}/versions")
async def list_feed_versions(feed_id: int,
                             user: dict = Depends(get_current_user)):
    await _feed_api()._require_feed(feed_id, user, write=False)
    rows = await adb(_db().list_feed_definition_versions, feed_id)
    rows = list(rows or [])           # newest first
    items = []
    for i, row in enumerate(rows):
        previous = rows[i + 1] if i + 1 < len(rows) else None
        items.append(_summary(row, previous))
    return {"feed_id": feed_id, "count": len(items), "items": items}


@router.get("/{feed_id}/versions/diff")
async def diff_feed_versions(
        feed_id: int,
        from_version: int = Query(..., ge=1),
        to_version: int = Query(..., ge=1),
        user: dict = Depends(get_current_user)):
    await _feed_api()._require_feed(feed_id, user, write=False)
    a = await adb(_version_row, feed_id, from_version)
    b = await adb(_version_row, feed_id, to_version)
    changes = _history.diff_definitions(
        a.get("definition") or {}, b.get("definition") or {},
        mask=_feed_api()._mask_feed_secrets)
    return {"feed_id": feed_id, "from_version": from_version,
            "to_version": to_version, "count": len(changes),
            "changes": changes}


@router.get("/{feed_id}/versions/{version}")
async def get_feed_version(feed_id: int, version: int,
                           user: dict = Depends(get_current_user)):
    await _feed_api()._require_feed(feed_id, user, write=False)
    row = await adb(_version_row, feed_id, version)
    row = dict(row)
    row["definition"] = _masked(row.get("definition"))
    return row


@router.post("/{feed_id}/versions/{version}/restore")
async def restore_feed_version(feed_id: int, version: int,
                               user: dict = Depends(get_current_user)):
    fa = _feed_api()
    feed = await fa._require_feed(feed_id, user, write=True)
    from core.feed import lifecycle as _lifecycle
    retiring = await adb(_lifecycle.retirement_active, _db(), feed_id)
    if retiring:
        raise HTTPException(
            status_code=409,
            detail=f"Feed {feed.get('name')!r} is retired (quarantine until "
                   f"{retiring.get('quarantine_until')}); a retired feed's "
                   f"definition is not restorable.  POST "
                   f"/api/feeds/{feed_id}/unretire first.")
    row = await adb(_version_row, feed_id, version)
    payload = _history.restore_payload(
        row.get("definition") or {}, fa.FeedConfigUpdate.model_fields.keys())
    if not payload:
        raise HTTPException(
            status_code=422,
            detail=f"Version {version} carries no restorable field")
    try:
        body = fa.FeedConfigUpdate(**payload)
    except Exception as exc:
        raise HTTPException(
            status_code=422,
            detail=f"Version {version} does not validate against today's "
                   f"feed model: {exc}")
    # THE update: every rule the edit route enforces applies here.
    result = await fa.update_feed(feed_id, body, user)
    fa._audit("feed_version_restored", user,
              {"feed_id": feed_id, "version": version,
               "version_id": row.get("id")})
    latest = await adb(_db().get_latest_feed_definition_version, feed_id)
    return {"feed_id": feed_id, "restored_version": version,
            "now_version": (latest or {}).get("version"),
            "restored_fields": sorted(payload.keys()),
            "feed": result}
