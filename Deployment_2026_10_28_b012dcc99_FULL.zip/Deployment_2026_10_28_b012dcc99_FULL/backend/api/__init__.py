"""QueryStudio backend API package.

Marks ``api`` as a regular package so ``from api.<module> import ...`` (see
main.py) resolves regardless of the process CWD / how the app is launched.
Mirrors the sibling ``core`` package.
"""
