"""The Download Centre surface — every route keyed by a ``file_id``.

2026-08-30.  These nine routes were spread across three large routers
(``queries_api``, ``data_grid_api``, ``admin_api``) that are overwhelmingly
NOT downloads, so the Download Centre could not be given its own pod without
also exposing the query API, the grid API and the admin API on it.  Serving a
500 MB export and previewing an old result therefore ran inside the QS API
pod — and ``preview`` / ``chart-data`` / ``pivot-data`` submit their DuckDB
work to ``worker_pool.get_pool().executor``, the SAME thread pool
``reports_api``, ``schedules_api`` and ``sql_query_api`` use to execute
queries.  Browsing your old files competed with everyone's new ones.

This module is the single owner of that surface.

WHY A ROUTE TABLE RATHER THAN MOVED BODIES
------------------------------------------
The handler functions deliberately stay in their existing modules and are
registered here by reference.  Copying the bodies would have produced a second
definition of rules this session was spent collapsing into one (the Download
Centre had four different visibility rules across three listings as recently
as this morning), and it would have detached ~40 existing tests that call
``queries_api.download_file`` / ``data_grid_api.download_file_direct`` /
``admin_api.list_exports`` directly — leaving them green while testing objects
no longer on any route.

So: each route is defined EXACTLY ONCE, right here; each handler keeps its
home next to the helpers it shares (``_resolve_download_path``,
``_duckdb_preview``, ``_enforce_download_ownership``); and the host modules
no longer register these paths themselves.  Every decorator replaced below was
verified to be path-only — no ``response_model``, ``status_code`` or
route-level ``Depends`` to reproduce — and ``test_downloads_router_surface``
pins the mounted route table against this list.

The ``/api/exports`` route is part of this surface despite its name and its
old home in the admin module: it is what the Download Centre page actually
calls to list files.
"""
from __future__ import annotations

import logging

from fastapi import APIRouter

logger = logging.getLogger(__name__)

router = APIRouter(tags=["downloads"])


def _register() -> None:
    """Bind the handlers to their paths.

    Imports are function-local so importing this module cannot force the three
    host modules to load at import time in a mode that does not want them.
    """
    from api.admin_api import list_exports
    from api.data_grid_api import (
        chart_data_download_file, download_file_direct, pivot_data_download_file,
        preview_download_file,
    )
    from api.queries_api import (
        delete_download, download_file, list_downloads, update_download_retention,
    )

    # ── listing ──────────────────────────────────────────────────────────
    router.add_api_route("/api/downloads", list_downloads, methods=["GET"])
    router.add_api_route("/api/exports", list_exports, methods=["GET"])

    # ── the bytes ────────────────────────────────────────────────────────
    router.add_api_route("/api/downloads/{file_id}", download_file,
                         methods=["GET"])
    router.add_api_route("/api/downloads/{file_id}/download",
                         download_file_direct, methods=["GET"])

    # ── inspection (these start DuckDB over the stored file) ─────────────
    router.add_api_route("/api/downloads/{file_id}/preview",
                         preview_download_file, methods=["GET"])
    router.add_api_route("/api/downloads/{file_id}/chart-data",
                         chart_data_download_file, methods=["GET"])
    router.add_api_route("/api/downloads/{file_id}/pivot-data",
                         pivot_data_download_file, methods=["GET"])

    # ── lifecycle ────────────────────────────────────────────────────────
    router.add_api_route("/api/downloads/{file_id}/retention",
                         update_download_retention, methods=["PATCH"])
    router.add_api_route("/api/downloads/{file_id}", delete_download,
                         methods=["DELETE"])


_register()

#: The surface this module owns, as (path, method) pairs.  Kept as data so a
#: test can assert the mounted table equals it — a route silently lost during
#: a future edit would otherwise 404 in production and nowhere else.
DOWNLOAD_ROUTES = (
    ("/api/downloads", "GET"),
    ("/api/exports", "GET"),
    ("/api/downloads/{file_id}", "GET"),
    ("/api/downloads/{file_id}/download", "GET"),
    ("/api/downloads/{file_id}/preview", "GET"),
    ("/api/downloads/{file_id}/chart-data", "GET"),
    ("/api/downloads/{file_id}/pivot-data", "GET"),
    ("/api/downloads/{file_id}/retention", "PATCH"),
    ("/api/downloads/{file_id}", "DELETE"),
)
