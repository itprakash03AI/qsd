"""The run surface — the operator's screen at 04:50 (BRD §13.1).

Thin HTTP shell over ``core.feed.run_surface``.  Six questions in one call:

* ``GET /api/run-surface`` — what is running across the FLEET, what is blocked
  and ON WHAT, and what failed with which step and error;
* ``?feed_config_id=`` adds that feed's delivery record and its decisions;
* ``?feed_run_id=`` adds the fan-out view, so "re-run file 738" has a 738 to
  point at.

Read-only, deliberately.  Every control an operator needs — re-run, skip,
force-complete, re-deliver — already has its own endpoint with its own guard
(§13.2), and each of those guards exists for a reason.  A screen that also
acted would be a second place to get them wrong.

The sections are independent: one unreadable table costs one answer, not the
whole screen, and the response NAMES the gaps.  At 04:50 five working answers
and one honest gap beat a 500 — and beat six empty tables, which would read as
"nothing to report".
"""
import logging
from datetime import date, datetime, timezone
from typing import Any, Optional

from fastapi import APIRouter, Depends, HTTPException, Query

from api.deps import get_current_user
from core.feed import run_surface

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/run-surface", tags=["run-surface"])

# Module-level dependency (same wiring pattern as api/feed_api.py).
_db_manager: Any = None


def set_run_surface_dependencies(db_manager: Any) -> None:
    global _db_manager
    _db_manager = db_manager


def _parse_business_date(raw: Optional[str]) -> date:
    """Today (UTC) when unspecified; a REFUSAL when malformed.

    Never a silent fallback to today: an operator who typed a date and got
    today's screen would read it as that date's answer, which is how a quiet
    night gets confused with a broken one.
    """
    if not raw:
        return datetime.now(timezone.utc).date()
    try:
        return date.fromisoformat(str(raw)[:10])
    except ValueError:
        raise HTTPException(
            status_code=422,
            detail=f"business_date {raw!r} is not an ISO date (YYYY-MM-DD). "
                   f"Refusing rather than defaulting to today — you would "
                   f"read today's screen as that date's answer.")


@router.get("")
async def get_run_surface(
    business_date: Optional[str] = Query(default=None),
    feed_config_id: Optional[int] = Query(default=None),
    feed_run_id: Optional[int] = Query(default=None),
    user: dict = Depends(get_current_user),
):
    """The screen.  See the module docstring for what each section answers."""
    if _db_manager is None:          # pragma: no cover - wiring guard
        raise HTTPException(status_code=503,
                            detail="run surface not wired to a database")
    bd = _parse_business_date(business_date)
    import asyncio
    # 2026-09-27 -- scoped to the feeds the caller may VIEW, by the SAME
    # rule as /api/feeds and the Today board (feed_api._visible_feed_ids);
    # admin, support and a no-auth deployment see the fleet.  The per-feed
    # sections are gated by the feed's own view gate, and a run id is
    # resolved to its feed and gated the same way -- the surface must never
    # name a feed its reader is refused on the next click.
    from api import feed_api as _fa
    visible: Optional[set] = None
    if not _fa._sees_every_feed(user):
        visible = await asyncio.to_thread(_fa._visible_feed_ids, user)
    if feed_config_id is not None:
        await _fa._require_feed(int(feed_config_id), user, write=False)
    if feed_run_id is not None:
        run = await asyncio.to_thread(_db_manager.get_feed_run,
                                      int(feed_run_id))
        if not run:
            raise HTTPException(status_code=404,
                                detail=f"Feed run {feed_run_id} not found")
        await _fa._require_feed(int(run.get("feed_config_id") or 0), user,
                                write=False)
    # 2026-09-28 -- the report-promise section is scoped by the REPORT view
    # rule (core.reports.authorization.can_view_business_report, the one
    # every report route applies), never by feed ids: a report is not a
    # feed.  Admin / support / a no-auth deployment pass it for every row.
    from api.business_reports_api import _br_can_view as _report_can_view

    def _report_visible(report: dict) -> bool:
        try:
            return bool(_report_can_view(report, user))
        except Exception:                             # noqa: BLE001 -- fail closed
            return False

    surface = await asyncio.to_thread(
        run_surface.build_surface, _db_manager,
        business_date=bd, feed_config_id=feed_config_id,
        feed_run_id=feed_run_id, visible_feed_ids=visible,
        report_visible=_report_visible)
    if surface.get("unavailable_sections"):
        # A degraded screen is still served — but the degradation is logged,
        # because a section that is unreadable every night is a defect nobody
        # will notice from the UI alone.
        logger.warning(
            "[run_surface] served with %d unavailable section(s): %s",
            len(surface["unavailable_sections"]),
            ", ".join(surface["unavailable_sections"]))
    return surface
