"""Read-only status for the feed daemons (BRD §12, §13.1).

One screen answering "is the machinery that watches the feeds actually
running, and if not, exactly why not" — for the Kafka arrival consumer,
the SLA watcher and the Netcool sender.  A daemon whose state nobody can
see is how "the consumer registered, reported success and did nothing"
survives for months.

Read-only, deliberately.  Every control an operator needs already has
its own endpoint with its own guard (§13.2) — a status screen that also
acted would be a second place to get those guards wrong.  This router
exposes exactly one GET and nothing else, and a test asserts that.

The sections are independent: one daemon whose status read raises costs
one answer, not the whole screen, and the response NAMES the gap — at
04:50 two working answers and one honest gap beat a 500, and beat three
empty objects, which would read as "nothing running, nothing wrong".
"""
from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends

from api.deps import get_current_user

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/feed-daemons", tags=["feed-daemons"])

# Module-level dependency (same wiring pattern as api/run_surface_api.py).
_db_manager: Any = None


def set_feed_daemons_dependencies(db_manager: Any) -> None:
    global _db_manager
    _db_manager = db_manager


def _not_running_reason(daemon_name: str) -> str:
    """Why a daemon with no refusal machinery of its own is not running.

    Distinguishes the two OPPOSITE findings: "gated off this pod by pod
    role" (fine — it runs elsewhere) and "should be running here and is
    not" (a defect: its startup failed).
    """
    try:
        from core.config import scheduler as _sched_cfg
        from core.pod_role import current as _pod_role_current
        if _pod_role_current().should_run(daemon_name,
                                          scheduler_mode=_sched_cfg.mode):
            return (f"{daemon_name} should run on THIS pod and is not — "
                    f"its startup failed; grep the log for its init "
                    f"warning")
        return (f"{daemon_name} is gated off this pod by pod role — it "
                f"runs on the worker/scheduler pod, so ask that pod's "
                f"status surface")
    except Exception as exc:  # noqa: BLE001 — an unreadable pod role still yields a reason
        return (f"{daemon_name} is not running, and the pod role could "
                f"not be read to say why: {exc}")


def _kafka_status() -> dict:
    from core.feed import kafka_arrivals
    return kafka_arrivals.get_status()


def _sla_watcher_status() -> dict:
    """The SLA watcher's own status (2026-09-07).

    This used to reach into ``_thread`` and ``_raised`` because the module
    kept no status — so the one number that mattered, how many alerts the
    pass DETECTED AND REFUSED, was not readable from anywhere: it was
    computed inside ``evaluate_once`` and dropped.  The module now owns
    ``get_status()`` and this reads it.

    The generic ``_not_running_reason`` guess is used ONLY when the daemon
    stated no reason of its own.  A STATED refusal always wins: the guess
    would blame pod role for an unset environment, sending the operator to
    the wrong pod to look for a config key that is missing on every pod.
    """
    from core.feed import sla_watcher
    status = sla_watcher.get_status()
    if not status["running"] and not status["refusal"]:
        status["refusal"] = _not_running_reason(sla_watcher.DAEMON_NAME)
    # 2026-09-28 -- the report-SLO half of the same pass (core/reports/slo.py):
    # its counters ride ``last_pass.report_slo``; the open breach alerts it
    # holds are its own map, read here beside the feed watcher's.
    try:
        from core.reports import slo as _report_slo
        status["open_report_slo_alerts"] = _report_slo.open_alerts()
    except Exception as exc:                          # noqa: BLE001
        status["open_report_slo_alerts"] = None
        status["report_slo_unavailable"] = f"{type(exc).__name__}: {exc}"
    return status


def _netcool_sender_status() -> dict:
    from core.feed import netcool_sender
    session_factory = (getattr(_db_manager, "SessionLocal", None)
                       if _db_manager is not None else None)
    return netcool_sender.get_status(session_factory=session_factory)


_SECTIONS = (
    ("kafka_arrivals", _kafka_status),
    ("sla_watcher", _sla_watcher_status),
    ("netcool_sender", _netcool_sender_status),
)


@router.get("/status")
async def feed_daemons_status(user: dict = Depends(get_current_user)):  # noqa: B008 — FastAPI idiom
    """Running or not, the refusal reason when not, last-pass counters,
    and (for the sender) queue depth and dead-letter count."""
    out: dict = {"daemons": {}, "unavailable_sections": []}
    for name, read in _SECTIONS:
        try:
            out["daemons"][name] = read()
        except Exception as exc:  # noqa: BLE001 — one broken section costs one answer, not the screen
            # "empty" and "could not be read" are opposite findings —
            # the gap is NAMED, never rendered as a healthy-looking
            # absence.
            logger.error("[feed_daemons] %s status unreadable: %s",
                         name, exc)
            out["daemons"][name] = None
            out["unavailable_sections"].append(name)
    return out
