"""
Data Lineage API (Phase 26 + Phase 49 table-level + Phase 51 column-level + Phase 52 history)

Endpoints:
  GET /api/lineage/connection/{id}
  GET /api/lineage/report/{id}
  GET /api/lineage/query/{id}
  GET /api/lineage/graph
  --- Phase 49 ---
  GET /api/lineage/table/{catalog}/{schema}/{table}
  GET /api/lineage/table/search
  GET /api/lineage/query/{id}/tables
  POST /api/lineage/reparse
  --- Phase 51 ---
  GET /api/lineage/query/{id}/columns    column lineage for a SQL query
  GET /api/lineage/column/impact         all queries consuming a specific column
  --- Phase 52 ---
  GET /api/lineage/snapshots             list snapshots (filterable by query_type, query_id)
  GET /api/lineage/snapshots/{id}        snapshot detail
  GET /api/lineage/snapshots/diff        diff two snapshots (a=id&b=id)
  GET /api/lineage/freshness             all freshness records
  GET /api/lineage/freshness/stale       stale tables only
  PUT /api/lineage/freshness/threshold   update stale threshold for a table
  POST /api/lineage/freshness/mark-refreshed  mark a table as manually refreshed
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional


# BF-NONBLOCK-AUDIT-5: async lineage routes were calling sync DB
# inline.  Plain `def` routes are auto-threaded by FastAPI; only the
# async ones need wrapping.
async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)

from fastapi import APIRouter, Depends, HTTPException, Query as FastQuery  # noqa: E402

# SECURITY 2026-08-17: this module had ZERO authorization -- all 17 routes were
# anonymous, three of them MUTATING.  `_require_db()` reads like a guard in a
# diff but is only a DB-availability check (api/deps.require_db), and there is
# no router-level dependency and no auth middleware anywhere in this app, so a
# route with no dependency is genuinely open to the internet.
#
# What was exposed: `/api/lineage/graph` returns the ENTIRE cross-system
# dependency graph (every connection, query, report and physical table);
# `POST /reparse` is self-described in its own docstring as "Admin endpoint"
# and had no admin check; `PUT /freshness/threshold` and
# `POST /freshness/mark-refreshed` let anyone silence a staleness alarm for any
# table.
#
# Authentication is applied at the ROUTER so a newly added route inherits it
# rather than defaulting open -- this module's failure mode was precisely that
# each new route was written without a dependency.  The three mutators carry an
# additional admin gate.
from api.deps import get_current_user as _user_dep, require_admin as _admin_dep  # noqa: E402

logger = logging.getLogger(__name__)

router = APIRouter(dependencies=[Depends(_user_dep)])

_db_manager = None


def set_lineage_dependencies(db_manager):
    global _db_manager
    _db_manager = db_manager


def _require_db():
    from api.deps import require_db as _central_require_db
    return _central_require_db()


# ── Internal graph builders ──────────────────────────────────────────────────

def _build_connection_downstream(db, conn_id: int) -> Dict[str, Any]:
    """All entities downstream of a connection."""
    with db.get_session() as session:
        from core.database import (
            Connection, SqlSavedQuery, MaterializedView,
        )
        conn = session.query(Connection).filter(Connection.id == conn_id).first()
        if not conn:
            return {}

        downstream = []

        # MaterializedViews directly on this connection
        mvs = session.query(MaterializedView).filter(
            MaterializedView.connection_id == conn_id,
            MaterializedView.is_active,
        ).all()
        for mv in mvs:
            downstream.append({"type": "materialized_view", "id": mv.id, "name": mv.name, "downstream": []})

        # SqlSavedQueries on this connection (primary or secondary)
        from sqlalchemy import or_
        sqls = session.query(SqlSavedQuery).filter(
            or_(
                SqlSavedQuery.primary_connection_id == conn_id,
                SqlSavedQuery.secondary_connection_id == conn_id,
            ),
            SqlSavedQuery.is_active,
        ).all()
        for sq in sqls:
            sql_node = {"type": "sql_query", "id": sq.id, "name": sq.name, "downstream": []}
            sql_node["downstream"] = _sql_query_downstream(session, sq.id)
            downstream.append(sql_node)

        return {
            "node": {"type": "connection", "id": conn.id, "name": conn.name},
            "upstream": [],
            "downstream": downstream,
        }


def _sql_query_downstream(session, sq_id: int) -> List[Dict[str, Any]]:
    from core.database import DashboardWidget, Dashboard, Schedule
    result = []

    widgets = session.query(DashboardWidget).filter(
        DashboardWidget.widget_type == "sql_query",
        DashboardWidget.source_id == sq_id,
    ).all()
    dash_ids = {w.dashboard_id for w in widgets}
    for did in dash_ids:
        dash = session.query(Dashboard).filter(Dashboard.id == did, Dashboard.is_active).first()
        if dash:
            result.append({"type": "dashboard", "id": dash.id, "name": dash.name, "downstream": []})

    scheds = session.query(Schedule).filter(
        Schedule.source_type == "sql_query",
        Schedule.source_id == sq_id,
        Schedule.is_active,
    ).all()
    for s in scheds:
        result.append({"type": "schedule", "id": s.id, "name": s.name, "downstream": []})

    return result


def _parquet_query_downstream(session, pq_id: int) -> List[Dict[str, Any]]:
    from core.database import DashboardWidget, Dashboard, Schedule
    result = []

    widgets = session.query(DashboardWidget).filter(
        DashboardWidget.widget_type == "saved_query",
        DashboardWidget.source_id == pq_id,
    ).all()
    dash_ids = {w.dashboard_id for w in widgets}
    for did in dash_ids:
        dash = session.query(Dashboard).filter(Dashboard.id == did, Dashboard.is_active).first()
        if dash:
            result.append({"type": "dashboard", "id": dash.id, "name": dash.name, "downstream": []})

    scheds = session.query(Schedule).filter(
        Schedule.source_type == "saved_query",
        Schedule.source_id == pq_id,
        Schedule.is_active,
    ).all()
    for s in scheds:
        result.append({"type": "schedule", "id": s.id, "name": s.name, "downstream": []})

    return result


@router.get("/api/lineage/connection/{connection_id}")
def get_connection_lineage(connection_id: int):
    db = _require_db()
    result = _build_connection_downstream(db, connection_id)
    if not result:
        raise HTTPException(status_code=404, detail="Connection not found")
    return result


@router.get("/api/lineage/query/{query_id}")
def get_query_lineage(query_id: int, type: str = FastQuery(default="sql")):
    db = _require_db()
    with db.get_session() as session:
        if type == "sql":
            from core.database import SqlSavedQuery, Connection
            sq = session.query(SqlSavedQuery).filter(SqlSavedQuery.id == query_id).first()
            if not sq:
                raise HTTPException(status_code=404, detail="SQL query not found")
            upstream = []
            conn = session.query(Connection).filter(Connection.id == sq.primary_connection_id).first()
            if conn:
                upstream.append({"type": "connection", "id": conn.id, "name": conn.name, "upstream": []})
            if sq.secondary_connection_id:
                sc = session.query(Connection).filter(Connection.id == sq.secondary_connection_id).first()
                if sc:
                    upstream.append({"type": "connection", "id": sc.id, "name": f"{sc.name} (secondary)", "upstream": []})
            return {
                "node": {"type": "sql_query", "id": sq.id, "name": sq.name},
                "upstream": upstream,
                "downstream": _sql_query_downstream(session, sq.id),
            }
        else:
            from core.database import SavedQuery
            pq = session.query(SavedQuery).filter(SavedQuery.id == query_id).first()
            if not pq:
                raise HTTPException(status_code=404, detail="Parquet query not found")
            return {
                "node": {"type": "parquet_query", "id": pq.id, "name": pq.name},
                "upstream": [],
                "downstream": _parquet_query_downstream(session, pq.id),
            }


def _graph_connections(session, m, add_node, add_edge) -> None:
    """Connections, materialized views, saved queries -- the storage layer."""
    for c in session.query(m.Connection).filter(m.Connection.is_active).all():
        add_node("connection", c.id, c.name)
    for mv in session.query(m.MaterializedView).filter(
            m.MaterializedView.is_active).all():
        add_edge(f"connection:{mv.connection_id}",
                 add_node("materialized_view", mv.id, mv.name))
    for sq in session.query(m.SqlSavedQuery).filter(
            m.SqlSavedQuery.is_active).all():
        sk = add_node("sql_query", sq.id, sq.name)
        add_edge(f"connection:{sq.primary_connection_id}", sk)
        if sq.secondary_connection_id:
            add_edge(f"connection:{sq.secondary_connection_id}", sk)
    for pq in session.query(m.SavedQuery).filter(m.SavedQuery.is_active).all():
        add_node("parquet_query", pq.id, pq.name)


def _graph_consumers(session, m, add_node, add_edge) -> None:
    """Dashboards and schedules -- what reads the queries.  (FB-60: the
    legacy parametric Report node is gone; raw_sql finance reports are added
    by _graph_business.)"""
    for d in session.query(m.Dashboard).filter(m.Dashboard.is_active).all():
        dk = add_node("dashboard", d.id, d.name)
        for w in session.query(m.DashboardWidget).filter(
                m.DashboardWidget.dashboard_id == d.id).all():
            add_edge(f"{_query_node_type(w.widget_type)}:{w.source_id}", dk)
    for s in session.query(m.Schedule).filter(m.Schedule.is_active).all():
        add_edge(f"{_query_node_type(s.source_type)}:{s.source_id}",
                 add_node("schedule", s.id, s.name))


def _graph_tables(session, m, add_node, add_edge) -> None:
    """Phase 49 physical-table nodes, deduplicated by FQN."""
    entries = session.query(m.TableLineageEntry).all()
    by_fqn: Dict[str, Dict] = {}
    for te in entries:
        fqn = _make_table_fqn(te.table_catalog, te.table_schema, te.table_name)
        by_fqn.setdefault(fqn, {"connection_id": te.connection_id})
    for fqn, info in by_fqn.items():
        tk = add_node("table", fqn, fqn)
        if info["connection_id"]:
            add_edge(f"connection:{info['connection_id']}", tk)
    for te in entries:
        fqn = _make_table_fqn(te.table_catalog, te.table_schema, te.table_name)
        add_edge(f"table:{fqn}", f"{te.query_type}:{te.query_id}")


def _graph_business(session, add_node, add_edge) -> None:
    """2026-08-17 -- business datasets + BUSINESS reports.

    This graph previously contained only the legacy Report model, so business
    reports (the primary report type) were invisible to impact analysis.
    """
    from core.db.models import BusinessDataset, BusinessReport
    for ds in session.query(BusinessDataset).all():
        dk = add_node("dataset", ds.id, ds.name)
        for cid in (ds.connection_ids or []):
            add_edge(f"connection:{cid}", dk)
    for br in session.query(BusinessReport).all():
        bk = add_node("business_report", br.id, br.name)
        for ds_id in (br.dataset_id, br.merged_dataset_id):
            if ds_id:
                add_edge(f"dataset:{ds_id}", bk)
        # raw_sql-backed BRs also hang off their backing query nodes.
        if br.raw_sql_saved_query_id:
            add_edge(f"sql_query:{br.raw_sql_saved_query_id}", bk)
        if br.raw_saved_query_id:
            add_edge(f"parquet_query:{br.raw_saved_query_id}", bk)


@router.get("/api/lineage/graph")
def get_full_lineage_graph():
    """Return entire dependency graph as { nodes[], edges[] } — includes table nodes (Phase 49).

    2026-08-17: split into four builders.  This was one 129-line function with
    a cognitive complexity of 74 (Sonar S3776 threshold is 15), almost all of
    it the same shape repeated fifteen times::

        key = f"connection:{x.connection_id}"
        if key in seen_nodes:
            edges.append({"source": key, "target": node_key})

    ``add_edge`` now owns that membership test.  It requires BOTH ends to be
    known nodes, which is behaviour-identical: at every original call site the
    target had just been returned by ``add_node``, so only the source was ever
    in question -- except the table->query edge, which already checked both.
    """
    db = _require_db()
    nodes: List[Dict[str, Any]] = []
    edges: List[Dict[str, Any]] = []
    seen_nodes: set = set()

    def add_node(ntype: str, nid: Any, name: str) -> str:
        key = f"{ntype}:{nid}"
        if key not in seen_nodes:
            seen_nodes.add(key)
            nodes.append({"id": key, "type": ntype, "label": name})
        return key

    def add_edge(source: str, target: str) -> None:
        """Link two nodes -- silently skipped unless BOTH are in the graph."""
        if source in seen_nodes and target in seen_nodes:
            edges.append({"source": source, "target": target})

    with db.get_session() as session:
        from core import database as m
        _graph_connections(session, m, add_node, add_edge)
        _graph_consumers(session, m, add_node, add_edge)
        _graph_tables(session, m, add_node, add_edge)
        _graph_business(session, add_node, add_edge)

    return {"nodes": nodes, "edges": edges}


# ── Phase 49: Table-level lineage endpoints ──────────────────────────────────

def _query_node_type(source_type: str) -> str:
    """Widget/schedule ``source_type`` -> graph node type."""
    return (source_type or "").replace("saved_query", "parquet_query")


def _canon_query_type(qt: str) -> str:
    """Route vocabulary -> STORAGE vocabulary for lineage entries.

    Storage always writes ``sql_query`` / ``parquet_query``, but the routes
    historically accepted ``sql`` / ``parquet`` (and the UI sent them) — the
    mismatched literal went straight into the DB filter and matched NOTHING,
    so /query/{id}/tables and /query/{id}/columns answered a permanent
    empty 200.  Same fact, two vocabularies: normalise at the boundary.
    """
    q = (qt or "").strip().lower()
    return {
        "sql": "sql_query",
        "parquet": "parquet_query",
        "saved_query": "parquet_query",
    }.get(q, q or "sql_query")


def _make_table_fqn(catalog: Optional[str], schema: Optional[str], table: str) -> str:
    parts = [p for p in [catalog, schema, table] if p]
    return ".".join(parts)


def _table_matches_source(table: str, source_tables) -> bool:
    """Does a dataset's free-form ``source_tables`` name this physical table?

    Entries are strings like ``schema.table`` or ``s3://bucket/prefix/name``,
    so this is an HONEST name match -- callers flag it via ``match_basis``
    rather than presenting it as resolved lineage.
    """
    tbl = (table or "").lower()
    if not tbl:
        return False
    for st in (source_tables or []):
        st_tbl = str((st or {}).get("table") or "").lower()
        if not st_tbl:
            continue
        last = (st_tbl.rstrip("/").split("/")[-1].split(".")[-1]
                if "/" in st_tbl else st_tbl.split(".")[-1])
        if tbl in (st_tbl, last):
            return True
    return False


def _impact_query_name(session, m, qt, qid):
    """Display name of one lineage query (FB-60: the legacy parametric
    reports this used to return are gone; raw_sql finance reports are
    collected by the caller's add_br)."""
    if qt == "sql_query":
        row = session.query(m.SqlSavedQuery).filter(
            m.SqlSavedQuery.id == qid).first()
    elif qt == "parquet_query":
        row = session.query(m.SavedQuery).filter(
            m.SavedQuery.id == qid).first()
    else:
        return None
    return row.name if row else None


@router.get("/api/lineage/table/impact")
def get_table_impact_q(table: str, schema: str = "", catalog: str = ""):
    """Impact analysis by query params — reaches tables of ANY name arity.

    2026-08-23: the path route below can only express catalog.schema.table,
    but most tables in this product are 1-part registered names whose
    catalog/schema are NULL — their impact was unreachable BY CONSTRUCTION
    and the UI rendered an empty tree for them.  One implementation serves
    both routes.
    """
    if not (table or "").strip():
        raise HTTPException(status_code=400, detail="table is required")
    return _table_impact_payload(_require_db(), catalog.strip() or None,
                                 schema.strip() or None, table.strip())


@router.get("/api/lineage/table/{catalog}/{schema}/{table}")
def get_table_impact(catalog: str, schema: str, table: str):
    """Impact analysis: given a physical table, what queries/reports/dashboards depend on it.

    2026-08-17: split into three helpers.  This was a single 113-line function
    with a cognitive complexity of 61 (Sonar S3776 threshold is 15) -- five
    levels of nesting over query-type dispatch, report fan-out, dashboard
    fan-out and two dedup sets.  Behaviour is unchanged; the dedup sets and
    the honest ``match_basis`` labelling are preserved exactly.
    """
    return _table_impact_payload(_require_db(), catalog, schema, table)


def _table_impact_payload(db, catalog, schema, table):
    entries = db.get_queries_for_table(catalog, schema, table)
    # 2026-08-17: NO early return on empty entries any more -- a table can be
    # modelled by a business DATASET (and thus consumed by business reports)
    # without any TableLineageEntry ever having been extracted for it.

    query_list: List[Dict[str, Any]] = []
    downstream_dashboards: List[Dict[str, Any]] = []
    downstream_business_reports: List[Dict[str, Any]] = []
    seen_dashboards: set = set()
    seen_brs: set = set()

    def add_br(br, basis: str) -> None:
        if br.id not in seen_brs:
            seen_brs.add(br.id)
            downstream_business_reports.append(
                {"id": br.id, "name": br.name, "match_basis": basis})

    with db.get_session() as session:
        from core import database as m
        from core.db.models import BusinessDataset, BusinessReport
        from sqlalchemy import or_ as _sql_or

        for entry in (entries or []):
            qt, qid = entry["query_type"], entry["query_id"]
            query_list.append({"query_type": qt, "query_id": qid,
                               "access_type": entry["access_type"]})
            name = _impact_query_name(session, m, qt, qid)
            if name:
                query_list[-1]["name"] = name

            # raw_sql BUSINESS reports riding this query are downstream of the
            # table too (previously invisible here).
            if qt in ("sql_query", "parquet_query"):
                br_filter = (BusinessReport.raw_sql_saved_query_id == qid
                             if qt == "sql_query"
                             else BusinessReport.raw_saved_query_id == qid)
                for br in session.query(BusinessReport).filter(br_filter).all():
                    add_br(br, f"raw_sql via {qt} {qid}")

        # Datasets that MODEL this physical table, and the business reports on
        # them.  Name match -- disclosed via match_basis, never as resolved.
        for ds in session.query(BusinessDataset).all():
            if not _table_matches_source(table, ds.source_tables):
                continue
            for br in session.query(BusinessReport).filter(_sql_or(
                    BusinessReport.dataset_id == ds.id,
                    BusinessReport.merged_dataset_id == ds.id)).all():
                add_br(br, f"dataset '{ds.name}' source_tables name match")

    # Dashboards whose finance-report tiles read a downstream report.  (FB-60:
    # this used to be dashboards over LEGACY report tiles; the key keeps its
    # meaning -- dashboards affected by the table -- for the successor.)
    if downstream_business_reports:
        with db.get_session() as session:
            from core import database as m
            br_ids = {int(b["id"]) for b in downstream_business_reports}
            for w in session.query(m.DashboardWidget).filter(
                    m.DashboardWidget.widget_type == "business_report",
                    m.DashboardWidget.source_id.in_(br_ids)).all():
                if w.dashboard_id in seen_dashboards:
                    continue
                dash = session.query(m.Dashboard).filter(
                    m.Dashboard.id == w.dashboard_id, m.Dashboard.is_active).first()
                if dash:
                    seen_dashboards.add(dash.id)
                    downstream_dashboards.append({"id": dash.id, "name": dash.name})

    return {
        "table": _make_table_fqn(catalog, schema, table),
        "queries": query_list,
        "downstream_dashboards": downstream_dashboards,
        "downstream_business_reports": downstream_business_reports,
    }


@router.get("/api/lineage/table/search")
def search_table_lineage(q: str = FastQuery(default=""), limit: int = FastQuery(default=50)):
    """Search for tables by name/schema/catalog."""
    db = _require_db()
    if not q:
        return []
    return db.search_table_lineage(q, limit=limit)


@router.get("/api/lineage/query/{query_id}/tables")
def get_query_tables(query_id: int, type: str = FastQuery(default="sql")):
    """List physical tables referenced by a query."""
    db = _require_db()
    return db.get_table_lineage_for_query(_canon_query_type(type), query_id)


@router.post("/api/lineage/reparse")
def reparse_all_lineage(_admin: Dict[str, Any] = Depends(_admin_dep)):
    """Admin endpoint: re-extract table lineage for all saved SQL queries.

    SECURITY 2026-08-17: the docstring said "Admin endpoint" and there was no
    admin check -- an anonymous caller could force a mass re-parse of every
    saved SQL query in the system.
    """
    db = _require_db()
    from core.sql_lineage_parser import extract_and_store_lineage
    from core.config import lineage as _lineage_cfg

    max_batch = _lineage_cfg.max_reparse_batch
    succeeded = 0
    failed = 0
    errors = []

    with db.get_session() as session:
        from core.database import SqlSavedQuery, Connection
        queries = session.query(SqlSavedQuery).filter(
            SqlSavedQuery.is_active
        ).limit(max_batch).all()

        # Connection-type lookup from the REAL column.  The old code probed
        # ``c.type`` — an attribute that does not exist on Connection (it is
        # ``connection_type``) — so every reparse forced the duckdb dialect
        # on every source.
        conn_types = {}
        for c in session.query(Connection).all():
            conn_types[c.id] = getattr(c, "connection_type", None) or "duckdb"

        for sq in queries:
            try:
                conn_type = conn_types.get(sq.primary_connection_id, "duckdb")
                extract_and_store_lineage(
                    db, "sql_query", sq.id, sq.primary_sql,
                    connection_id=sq.primary_connection_id,
                    connection_type=conn_type,
                )
                succeeded += 1
            except Exception as e:
                failed += 1
                errors.append({"query_id": sq.id, "name": sq.name, "error": str(e)})

    return {"total": succeeded + failed, "succeeded": succeeded, "failed": failed, "errors": errors[:20]}


# ── Phase 51: Column-level lineage endpoints ──────────────────────────────────

@router.get("/api/lineage/query/{query_id}/columns")
async def get_query_column_lineage(query_id: int, query_type: str = "sql_query"):
    """Return column-level lineage entries for a SQL saved query."""
    db = _require_db()
    qt = _canon_query_type(query_type)
    entries = await _adb(db.get_column_lineage_for_query, qt, query_id)
    return {"query_id": query_id, "query_type": qt, "columns": entries, "count": len(entries)}


@router.get("/api/lineage/column/impact")
async def get_column_impact(table: str, column: str):
    """Return all queries that consume a specific source column.

    Query params: table=<table_name>&column=<col_name>
    """
    db = _require_db()
    entries = await _adb(db.get_column_impact, table, column)
    return {
        "source_table": table,
        "source_column": column,
        "affected_queries": entries,
        "count": len(entries),
    }


# ── Phase 52: Lineage Snapshots ───────────────────────────────────────────────

@router.get("/api/lineage/snapshots")
async def list_lineage_snapshots(
    query_type: Optional[str] = None,
    query_id:   Optional[int] = None,
    limit:      int = FastQuery(50, ge=1, le=500),
):
    """List lineage snapshots, optionally filtered by query_type and query_id."""
    db = _require_db()
    rows = await _adb(db.get_lineage_snapshots, query_type=query_type, query_id=query_id, limit=limit)
    return {"snapshots": rows, "count": len(rows)}


@router.get("/api/lineage/snapshots/diff")
async def diff_lineage_snapshots(a: int, b: int):
    """Diff two snapshots by ID. Returns tables/columns added/removed between them."""
    db = _require_db()
    snap_a = await _adb(db.get_lineage_snapshot, a)
    snap_b = await _adb(db.get_lineage_snapshot, b)
    if not snap_a:
        raise HTTPException(status_code=404, detail=f"Snapshot {a} not found")
    if not snap_b:
        raise HTTPException(status_code=404, detail=f"Snapshot {b} not found")

    def _table_set(snap: Dict[str, Any]) -> set:
        return {t.get("table_name", "") for t in snap.get("snapshot_data", {}).get("tables", [])}

    def _col_set(snap: Dict[str, Any]) -> set:
        return {
            f"{c.get('source_table', '')}.{c.get('source_column', '')} → {c.get('target_column', '')}"
            for c in snap.get("snapshot_data", {}).get("columns", [])
        }

    tables_a, tables_b = _table_set(snap_a), _table_set(snap_b)
    cols_a,   cols_b   = _col_set(snap_a),   _col_set(snap_b)

    return {
        "snapshot_a": {"id": a, "captured_at": snap_a.get("captured_at")},
        "snapshot_b": {"id": b, "captured_at": snap_b.get("captured_at")},
        "tables": {
            "added":   sorted(tables_b - tables_a),
            "removed": sorted(tables_a - tables_b),
            "unchanged": sorted(tables_a & tables_b),
        },
        "columns": {
            "added":   sorted(cols_b - cols_a),
            "removed": sorted(cols_a - cols_b),
        },
    }


@router.get("/api/lineage/snapshots/{snapshot_id}")
async def get_lineage_snapshot(snapshot_id: int):
    """Return a single snapshot with full table + column data."""
    db = _require_db()
    snap = await _adb(db.get_lineage_snapshot, snapshot_id)
    if not snap:
        raise HTTPException(status_code=404, detail="Snapshot not found")
    return snap


# ── Phase 52: Data Freshness ──────────────────────────────────────────────────

@router.get("/api/lineage/freshness")
async def get_freshness_all():
    """Return freshness status for all tracked tables (recomputes staleness first)."""
    db = _require_db()
    from core.freshness_tracker import recompute_all_freshness_statuses
    def _inner():
        recompute_all_freshness_statuses(db)
        return db.get_data_freshness()
    rows = await asyncio.to_thread(_inner)
    return {"tables": rows, "count": len(rows)}


@router.get("/api/lineage/freshness/stale")
async def get_stale_tables():
    """Return only tables currently considered stale."""
    db = _require_db()
    from core.freshness_tracker import get_stale_tables
    stale = await asyncio.to_thread(get_stale_tables, db)
    return {"stale_tables": stale, "count": len(stale)}


@router.put("/api/lineage/freshness/threshold")
async def update_freshness_threshold(
        body: Dict[str, Any],
        _admin: Dict[str, Any] = Depends(_admin_dep)):
    """Update the stale threshold for a specific table.

    Body: { "table_fqn": "schema.table", "stale_threshold_hours": 48 }

    SECURITY 2026-08-17: admin-gated.  This is a monitoring control -- an
    anonymous caller could widen any table's staleness window and hide a
    broken pipeline.
    """
    db = _require_db()
    table_fqn = body.get("table_fqn", "").strip()
    hours = int(body.get("stale_threshold_hours", 24))
    if not table_fqn:
        raise HTTPException(status_code=400, detail="table_fqn required")
    if hours < 1:
        raise HTTPException(status_code=400, detail="stale_threshold_hours must be >= 1")
    updated = await _adb(db.update_freshness_threshold, table_fqn, hours)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Table '{table_fqn}' not found in freshness registry")
    return updated


@router.post("/api/lineage/freshness/mark-refreshed")
async def mark_table_refreshed(
        body: Dict[str, Any],
        _admin: Dict[str, Any] = Depends(_admin_dep)):
    """Manually mark a table as refreshed (resets freshness clock).

    Body: { "table_fqn": "schema.table" }

    SECURITY 2026-08-17: admin-gated -- resetting the freshness clock silences
    a staleness alarm, so it must not be anonymous.
    """
    db = _require_db()
    table_fqn = body.get("table_fqn", "").strip()
    if not table_fqn:
        raise HTTPException(status_code=400, detail="table_fqn required")
    updated = await _adb(db.mark_table_refreshed, table_fqn)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Table '{table_fqn}' not found in freshness registry")
    return updated


# ── 2026-08-17: Business reports join the lineage graph ──────────────────────
#
# Until today this module queried ONLY the legacy ``Report`` model — business
# reports (the PRIMARY report type) were invisible, so "what breaks if I
# change this dataset" had no answer for them.  Two additions close that:
#
#   GET /api/lineage/business-report/{id}   what a business report depends on
#   GET /api/lineage/dataset/{id}/impact    what consumes a dataset (reverse)
#
# HONESTY CONTRACT: every upstream claim carries a ``resolution`` entry:
#   * "resolved"      — statically resolved from stored metadata (datasets,
#                       saved/SQL queries, sql files, connections).
#   * "reference"     — the dependency object is identified but its OWN
#                       upstream is not expanded here (published/federation
#                       views carry frozen query configs; expanding them
#                       would be guesswork, so we link the node and stop).
#   * "parsed"        — best-effort static SQL parse (inline raw_sql_override
#                       via core.sql_lineage_parser.extract_table_refs); the
#                       table list is as good as the parse.
#   * "unresolvable"  — we KNOW there is a dependency but cannot resolve it
#                       statically (e.g. inline SQL the parser rejects).


def _dataset_node(session, dataset_id: Optional[int],
                  resolution: List[Dict[str, Any]],
                  label: str = "dataset") -> Optional[Dict[str, Any]]:
    """Resolve a BusinessDataset into a lineage node with its connections
    and physical tables.  Appends one resolution entry."""
    if not dataset_id:
        return None
    from core.db.models import BusinessDataset, Connection
    ds = session.query(BusinessDataset).filter(
        BusinessDataset.id == int(dataset_id)).first()
    if not ds:
        resolution.append({
            "source": label, "ref": int(dataset_id), "status": "unresolvable",
            "note": f"dataset {dataset_id} not found (deleted?)",
        })
        return None
    node: Dict[str, Any] = {
        "type": "dataset", "id": ds.id, "name": ds.name, "upstream": [],
    }
    for cid in (ds.connection_ids or []):
        conn = session.query(Connection).filter(Connection.id == cid).first()
        node["upstream"].append({
            "type": "connection", "id": cid,
            "name": (conn.name if conn else f"connection {cid}"),
            "upstream": [],
        })
    for st in (ds.source_tables or []):
        tbl = (st or {}).get("table")
        if tbl:
            node["upstream"].append({
                "type": "table", "id": tbl, "name": tbl,
                "connection_id": (st or {}).get("connection_id"),
                "upstream": [],
            })
    if ds.base_query:
        resolution.append({
            "source": label, "ref": ds.id, "status": "parsed",
            "note": "dataset has a custom base_query; source_tables list is "
                    "the modelled truth, the SQL itself is not re-parsed here",
        })
    else:
        resolution.append({"source": label, "ref": ds.id, "status": "resolved"})
    return node


def _upstream_raw_sql(session, br, upstream, resolution) -> None:
    """The four mutually-compatible raw_sql backings.

    Resolved in the SAME precedence order the execution path uses
    (override > file > sql query > parquet).  Extracted 2026-08-17: inline,
    this branch alone carried most of _business_report_upstream's cognitive
    complexity of 52 (Sonar S3776 threshold is 15).
    """
    from core.db.models import (
        Connection, SavedQuery, SqlFile, SqlSavedQuery, TableLineageEntry,
    )
    # Four mutually-compatible backings, resolved in the same precedence
    # order the execution path uses (override > file > sql query > parquet).
    if br.raw_saved_query_id:
        pq = session.query(SavedQuery).filter(
            SavedQuery.id == br.raw_saved_query_id).first()
        upstream.append({
            "type": "parquet_query", "id": br.raw_saved_query_id,
            "name": (pq.name if pq else f"saved_query {br.raw_saved_query_id}"),
            "upstream": [],
        })
        resolution.append({
            "source": "raw_saved_query", "ref": br.raw_saved_query_id,
            "status": ("resolved" if pq else "unresolvable"),
        })
    if br.raw_sql_saved_query_id:
        sq = session.query(SqlSavedQuery).filter(
            SqlSavedQuery.id == br.raw_sql_saved_query_id).first()
        sq_node: Dict[str, Any] = {
            "type": "sql_query", "id": br.raw_sql_saved_query_id,
            "name": (sq.name if sq else
                     f"sql_query {br.raw_sql_saved_query_id}"),
            "upstream": [],
        }
        if sq:
            conn = session.query(Connection).filter(
                Connection.id == sq.primary_connection_id).first()
            if conn:
                sq_node["upstream"].append({
                    "type": "connection", "id": conn.id,
                    "name": conn.name, "upstream": []})
            for te in session.query(TableLineageEntry).filter(
                    TableLineageEntry.query_type == "sql_query",
                    TableLineageEntry.query_id == sq.id).all():
                fqn = _make_table_fqn(te.table_catalog, te.table_schema,
                                      te.table_name)
                sq_node["upstream"].append({
                    "type": "table", "id": fqn, "name": fqn,
                    "upstream": []})
        upstream.append(sq_node)
        resolution.append({
            "source": "raw_sql_saved_query",
            "ref": br.raw_sql_saved_query_id,
            "status": ("resolved" if sq else "unresolvable"),
        })
    if br.raw_sql_file_id:
        sf = session.query(SqlFile).filter(
            SqlFile.id == br.raw_sql_file_id).first()
        sf_node: Dict[str, Any] = {
            "type": "sql_file", "id": br.raw_sql_file_id,
            "name": (sf.name if sf else f"sql_file {br.raw_sql_file_id}"),
            "upstream": [],
        }
        if sf:
            for cid in [sf.connection_id, sf.secondary_connection_id]:
                if cid:
                    conn = session.query(Connection).filter(
                        Connection.id == cid).first()
                    sf_node["upstream"].append({
                        "type": "connection", "id": cid,
                        "name": (conn.name if conn else f"connection {cid}"),
                        "upstream": []})
        upstream.append(sf_node)
        resolution.append({
            "source": "raw_sql_file", "ref": br.raw_sql_file_id,
            "status": ("reference" if sf else "unresolvable"),
            "note": ("file content lives on NFS and is not parsed here; "
                     "linked connections are resolved" if sf
                     else "sql file not found"),
        })
    if br.raw_sql_override:
        # Best-effort STATIC parse of the inline SQL — honest about it.
        tables: List[str] = []
        parse_ok = False
        try:
            from core.sql_lineage_parser import extract_table_refs
            refs = extract_table_refs(br.raw_sql_override) or []
            tables = sorted({
                _make_table_fqn(getattr(r, "catalog", None),
                                getattr(r, "schema", None),
                                getattr(r, "table", None) or getattr(r, "name", ""))
                for r in refs
            } - {""})
            parse_ok = True
        except Exception as parse_exc:
            logger.info("[lineage] raw_sql_override parse failed for "
                        "business report %s: %s", br.id, parse_exc)
        for t in tables:
            upstream.append({"type": "table", "id": t, "name": t,
                             "upstream": [],
                             "via": "raw_sql_override (parsed)"})
        resolution.append({
            "source": "raw_sql_override", "ref": None,
            "status": ("parsed" if parse_ok and tables else
                       "unresolvable"),
            "note": ("tables extracted by static SQL parse — as good as "
                     "the parse" if parse_ok and tables else
                     "inline SQL could not be statically parsed"),
        })

    # Connection overrides apply on top of whatever source is configured.



def _business_report_upstream(session, br) -> Dict[str, Any]:
    """Upstream lineage for one BusinessReport ORM row + honesty ledger."""
    from core.db.models import (
        Connection, FederationView, PublishedView,
    )
    upstream: List[Dict[str, Any]] = []
    resolution: List[Dict[str, Any]] = []

    # Datasets — every BR has a primary dataset; merged is optional.
    n = _dataset_node(session, br.dataset_id, resolution, "dataset")
    if n:
        upstream.append(n)
    n = _dataset_node(session, br.merged_dataset_id, resolution, "merged_dataset")
    if n:
        n["name"] = f"{n['name']} (merged)"
        upstream.append(n)

    src_type = (br.data_source_type or "saved_query")

    if src_type == "federation_view" and br.federation_view_id:
        fv = session.query(FederationView).filter(
            FederationView.id == br.federation_view_id).first()
        upstream.append({
            "type": "federation_view", "id": br.federation_view_id,
            "name": (fv.name if fv else f"federation_view {br.federation_view_id}"),
            "upstream": ([
                {"type": "connection", "id": fv.primary_conn_id,
                 "name": f"connection {fv.primary_conn_id}", "upstream": []},
                {"type": "connection", "id": fv.secondary_conn_id,
                 "name": f"connection {fv.secondary_conn_id}", "upstream": []},
            ] if fv else []),
        })
        resolution.append({
            "source": "federation_view", "ref": br.federation_view_id,
            "status": ("reference" if fv else "unresolvable"),
            "note": ("view's frozen query configs are not re-parsed; "
                     "connections are resolved" if fv
                     else "federation view not found"),
        })

    if src_type == "published_view" and br.published_view_id:
        pv = session.query(PublishedView).filter(
            PublishedView.id == br.published_view_id).first()
        upstream.append({
            "type": "published_view", "id": br.published_view_id,
            "name": (pv.name if pv else f"published_view {br.published_view_id}"),
            "upstream": [],
        })
        resolution.append({
            "source": "published_view", "ref": br.published_view_id,
            "status": ("reference" if pv else "unresolvable"),
            "note": ("published view's frozen query_config snapshot is not "
                     "re-parsed here" if pv else "published view not found"),
        })

    if src_type == "raw_sql":
        _upstream_raw_sql(session, br, upstream, resolution)
    for cid, lbl in [(br.raw_connection_override_id, "connection_override"),
                     (br.secondary_connection_id, "secondary_connection")]:
        if cid:
            conn = session.query(Connection).filter(Connection.id == cid).first()
            upstream.append({
                "type": "connection", "id": cid,
                "name": ((conn.name if conn else f"connection {cid}")
                         + f" ({lbl})"),
                "upstream": [],
            })
            resolution.append({"source": lbl, "ref": cid,
                               "status": ("resolved" if conn else "unresolvable")})

    return {"upstream": upstream, "resolution": resolution,
            "data_source_type": src_type}


def _business_report_downstream(session, report_id: int) -> List[Dict[str, Any]]:
    """What consumes a business report: published views + subscriptions."""
    from core.db.models import PublishedView, ReportSubscription
    result: List[Dict[str, Any]] = []
    for pv in session.query(PublishedView).filter(
            PublishedView.source_type == "business_report",
            PublishedView.business_report_id == int(report_id),
            PublishedView.is_active).all():
        result.append({"type": "published_view", "id": pv.id,
                       "name": pv.name, "downstream": []})
    subs = session.query(ReportSubscription).filter(
        ReportSubscription.report_type == "business_report",
        ReportSubscription.report_id == int(report_id)).all()
    for s in subs:
        if getattr(s, "is_active", True):
            result.append({"type": "subscription", "id": s.id,
                           "name": s.name, "downstream": []})
    return result


@router.get("/api/lineage/business-report/{report_id}")
def get_business_report_lineage(report_id: int):
    """Full lineage for a BUSINESS report (the primary report type).

    Response is honest about static resolvability: see the ``resolution``
    list (resolved | reference | parsed | unresolvable per source).
    """
    db = _require_db()
    with db.get_session() as session:
        from core.db.models import BusinessReport
        br = session.query(BusinessReport).filter(
            BusinessReport.id == report_id).first()
        if not br:
            raise HTTPException(status_code=404,
                                detail="Business report not found")
        up = _business_report_upstream(session, br)
        return {
            "node": {"type": "business_report", "id": br.id, "name": br.name,
                     "owner": br.owner,
                     "is_published": bool(br.is_published)},
            "data_source_type": up["data_source_type"],
            "upstream": up["upstream"],
            "downstream": _business_report_downstream(session, br.id),
            "resolution": up["resolution"],
        }


@router.get("/api/lineage/dataset/{dataset_id}/impact")
def get_dataset_impact(dataset_id: int):
    """Impact analysis: what consumes this dataset — the question that pays
    for business-report lineage ("what breaks if I change this dataset")."""
    db = _require_db()
    with db.get_session() as session:
        from core.db.models import BusinessDataset, BusinessReport
        from sqlalchemy import or_
        ds = session.query(BusinessDataset).filter(
            BusinessDataset.id == dataset_id).first()
        if not ds:
            raise HTTPException(status_code=404, detail="Dataset not found")
        brs = session.query(BusinessReport).filter(or_(
            BusinessReport.dataset_id == dataset_id,
            BusinessReport.merged_dataset_id == dataset_id,
        )).all()
        reports = []
        for br in brs:
            reports.append({
                "type": "business_report", "id": br.id, "name": br.name,
                "owner": br.owner, "is_published": bool(br.is_published),
                "via": ("merged_dataset" if br.merged_dataset_id == dataset_id
                        and br.dataset_id != dataset_id else "dataset"),
                "downstream": _business_report_downstream(session, br.id),
            })
        return {
            "node": {"type": "dataset", "id": ds.id, "name": ds.name},
            "business_reports": reports,
            "count": len(reports),
        }
# ── 2026-08-23: ONE lineage-tree endpoint for every graph node ───────────────
#
# The UI's detail panel used to map node types onto routes itself and fell
# back to /api/lineage/report/{id} for dashboard / schedule /
# materialized_view — and for the newer dataset / business_report graph
# nodes.  A dashboard node with id 5 therefore rendered REPORT 5's lineage
# tree: a different entity's answer presented as this one's.  The mapping is
# a server-side fact; it lives here now, and the panel calls this one route
# for every node type.

def _node_tree_dashboard(session, m, nid: int) -> Optional[Dict[str, Any]]:
    dash = session.query(m.Dashboard).filter(m.Dashboard.id == nid).first()
    if not dash:
        return None
    upstream: List[Dict[str, Any]] = []
    seen: set = set()
    for w in session.query(m.DashboardWidget).filter(
            m.DashboardWidget.dashboard_id == nid).all():
        ntype = _query_node_type(w.widget_type)
        key = (ntype, w.source_id)
        if not w.source_id or key in seen:
            continue
        seen.add(key)
        name = None
        if ntype == "sql_query":
            row = session.query(m.SqlSavedQuery).filter(
                m.SqlSavedQuery.id == w.source_id).first()
            name = row.name if row else None
        elif ntype == "parquet_query":
            row = session.query(m.SavedQuery).filter(
                m.SavedQuery.id == w.source_id).first()
            name = row.name if row else None
        upstream.append({"type": ntype, "id": w.source_id,
                         "name": name or f"{ntype} {w.source_id}",
                         "upstream": []})
    return {"node": {"type": "dashboard", "id": dash.id, "name": dash.name},
            "upstream": upstream, "downstream": []}


def _node_tree_schedule(session, m, nid: int) -> Optional[Dict[str, Any]]:
    s = session.query(m.Schedule).filter(m.Schedule.id == nid).first()
    if not s:
        return None
    upstream: List[Dict[str, Any]] = []
    ntype = _query_node_type(s.source_type)
    if s.source_id:
        upstream.append({"type": ntype, "id": s.source_id,
                         "name": f"{ntype} {s.source_id}", "upstream": []})
    return {"node": {"type": "schedule", "id": s.id, "name": s.name},
            "upstream": upstream, "downstream": []}


def _node_tree_materialized_view(session, m, nid: int) -> Optional[Dict[str, Any]]:
    mv = session.query(m.MaterializedView).filter(
        m.MaterializedView.id == nid).first()
    if not mv:
        return None
    upstream: List[Dict[str, Any]] = []
    conn = session.query(m.Connection).filter(
        m.Connection.id == mv.connection_id).first()
    upstream.append({
        "type": "connection", "id": mv.connection_id,
        "name": (conn.name if conn else f"connection {mv.connection_id}"),
        "upstream": [{"type": "table", "id": mv.table_name,
                      "name": mv.table_name, "upstream": []}],
    })
    return {"node": {"type": "materialized_view", "id": mv.id, "name": mv.name},
            "upstream": upstream, "downstream": []}


def _node_tree_dataset(session, nid: int) -> Optional[Dict[str, Any]]:
    resolution: List[Dict[str, Any]] = []
    ds_node = _dataset_node(session, nid, resolution)
    if not ds_node:
        return None
    from core.db.models import BusinessReport
    from sqlalchemy import or_ as _or
    downstream = []
    for br in session.query(BusinessReport).filter(_or(
            BusinessReport.dataset_id == nid,
            BusinessReport.merged_dataset_id == nid)).all():
        downstream.append({"type": "business_report", "id": br.id,
                           "name": br.name,
                           "downstream": _business_report_downstream(session, br.id)})
    return {"node": {"type": "dataset", "id": ds_node["id"],
                     "name": ds_node["name"]},
            "upstream": ds_node["upstream"], "downstream": downstream,
            "resolution": resolution}


@router.get("/api/lineage/node/{node_type}/{node_id}")
def get_node_lineage(node_type: str, node_id: int):
    """Uniform lineage tree for ANY graph node type — see block comment."""
    db = _require_db()
    nt = (node_type or "").strip().lower()

    if nt == "connection":
        result = _build_connection_downstream(db, node_id)
        if not result:
            raise HTTPException(status_code=404, detail="Connection not found")
        return result
    if nt in ("sql_query", "parquet_query", "sql", "parquet"):
        return get_query_lineage(
            node_id, type=("sql" if nt in ("sql_query", "sql") else "parquet"))
    if nt == "business_report":
        return get_business_report_lineage(node_id)

    with db.get_session() as session:
        from core import database as m
        if nt == "dashboard":
            tree = _node_tree_dashboard(session, m, node_id)
        elif nt == "schedule":
            tree = _node_tree_schedule(session, m, node_id)
        elif nt == "materialized_view":
            tree = _node_tree_materialized_view(session, m, node_id)
        elif nt == "dataset":
            tree = _node_tree_dataset(session, node_id)
        else:
            raise HTTPException(status_code=400,
                                detail=f"Unknown node type '{node_type}'")
        if tree is None:
            raise HTTPException(status_code=404,
                                detail=f"{node_type} {node_id} not found")
        return tree
