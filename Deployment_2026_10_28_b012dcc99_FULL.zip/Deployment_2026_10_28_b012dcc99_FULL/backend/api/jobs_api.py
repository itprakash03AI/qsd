"""Job-queue API — the thin frontend surface (Industrialization Phase 2).

Submit / status / stream / cancel over the ``query_jobs`` substrate.
Nothing here does heavy work on the event loop: every DB touch rides
``asyncio.to_thread`` and the stream endpoint is a pure poll-and-relay.

The MAIN entry point for queued execution is the flag-gated branch inside
``POST /api/execute`` (transparent to existing clients).  These endpoints
are the first-class job surface on top of the same substrate:

  * ``POST /api/jobs/submit``      — enqueue (requires queue_mode armed)
  * ``GET  /api/jobs``             — my recent jobs
  * ``GET  /api/jobs/{id}``        — job status (+ relayed submit response)
  * ``GET  /api/jobs/{id}/stream`` — SSE status stream to terminal state
  * ``POST /api/jobs/{id}/cancel`` — cooperative cancel
  * ``GET  /api/jobs/queue/stats`` — admin observability

Authorization: submitting requires execute access; reading/cancelling a
job requires being its enqueuer or an admin (job ids are UUIDs, but
unguessability is not an authz model).
"""
from __future__ import annotations

import asyncio
import json
import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse

from api.deps import get_current_user, require_execute_access
from api.models.query_models import ExecuteQueryRequest
from core.roles import is_admin_like

logger = logging.getLogger(__name__)

router = APIRouter()

_STREAM_POLL_SECONDS = 0.5
_STREAM_MAX_SECONDS = 3600.0


def _queue():
    from core.jobqueue import get_job_queue
    return get_job_queue()


def _require_queue_mode():
    from core.industrialization import flags
    fl = flags()
    if not fl.is_enabled("queue_mode"):
        raise HTTPException(status_code=409, detail={
            "type": "queue_mode_disabled",
            "message": "The job queue is not armed on this deployment",
            "explain": fl.explain("queue_mode"),
        })


async def _load_owned_job(job_id: str, user: dict) -> dict:
    job = await asyncio.to_thread(_queue().get, job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")
    if not is_admin_like(user):
        username = (user or {}).get("username") or ""
        if job.get("enqueued_by") != username:
            # Same posture as executions: don't confirm existence.
            raise HTTPException(status_code=404, detail="Job not found")
    return job


def _public_view(job: dict) -> dict:
    """Response shape: job state + parsed submit-response relay.  Never
    identity/RLS payloads (executor-side data, not API material)."""
    out = dict(job)
    raw = out.pop("response_json", None)
    if raw:
        try:
            out["response"] = json.loads(raw)
        except Exception:
            out["response"] = None
    return out


@router.post("/api/jobs/submit")
async def submit_job(request: ExecuteQueryRequest,
                     _user: dict = Depends(require_execute_access)):
    """Enqueue a query job and return immediately with its id (no waiting
    — unlike the transparent /api/execute branch, this surface is for
    clients that want explicit job semantics)."""
    # SECURITY AUDIT 2026-08-03 (S5): share/embed tokens minted a full
    # analyst principal here too — scope them exactly like /api/execute
    # (rejects raw SQL, restricts to the token's shared object).
    from api.deps import enforce_token_execute_scope as _ets
    _ets(_user, request)
    _require_queue_mode()
    try:
        from core.jobqueue.execute_bridge import _enqueue_from_request
        outcome = await asyncio.to_thread(_enqueue_from_request, request, _user)
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("[jobs_api] enqueue failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail={
            "type": "enqueue_failed",
            "message": "Could not enqueue the job; the inline endpoint "
                       "POST /api/execute remains available",
        })
    if outcome.attached_to:
        # Phase 5 single-flight: this request rides an identical live
        # execution — poll this job id; the result propagates onto it.
        return {"job_id": outcome.job_id, "status": "attached",
                "attached_to": outcome.attached_to, "single_flight": True}
    return {"job_id": outcome.job_id, "status": "queued"}


@router.get("/api/jobs")
async def list_my_jobs(limit: int = 50,
                       _user: dict = Depends(get_current_user)):
    username = (_user or {}).get("username") or ""
    jobs = await asyncio.to_thread(_queue().list_for_user, username, limit)
    return {"jobs": jobs}


@router.get("/api/jobs/queue/stats")
async def queue_stats(_user: dict = Depends(get_current_user)):
    if not is_admin_like(_user):
        raise HTTPException(status_code=403, detail="Admin only")
    from core.industrialization import flags
    counts = await asyncio.to_thread(_queue().counts_by_status)
    out = {"counts": counts, "queue_mode": flags().explain("queue_mode")}
    # Phase 5 — fleet-wide inflight view (running count + priced memory,
    # per lane / per user).  Best-effort observability, never fatal.
    try:
        out["fleet"] = await asyncio.to_thread(_queue().fleet_inflight)
        out["fleet_admission"] = flags().explain("fleet_admission")
        out["single_flight"] = flags().explain("single_flight")
    except Exception as exc:
        logger.warning("[jobs_api] fleet_inflight failed: %s", exc)
    return out


@router.get("/api/jobs/{job_id}")
async def get_job(job_id: str, _user: dict = Depends(get_current_user)):
    job = await _load_owned_job(job_id, _user)
    out = _public_view(job)
    # M3 (2026-07-23): armed queue_mode with no executor must never hang
    # silently — an old still-queued job is surfaced as STRANDED (age
    # checked in DB time by the queue).  Fail-open annotation: any error
    # here changes nothing about the response.
    if job.get("status") == "queued":
        try:
            if await asyncio.to_thread(_queue().is_stranded, job_id):
                out["stranded"] = True
                out["stranded_reason"] = (
                    "Job has been queued past the stranded threshold with "
                    "no executor progress — no executor role appears to be "
                    "claiming jobs. The inline endpoint POST /api/execute "
                    "remains available; an admin should check the executor "
                    "deployment / jobqueue flags.")
                logger.error(
                    "[jobs_api] STRANDED job %s: queued past "
                    "jobqueue.stranded_after_seconds with no executor "
                    "progress (queue_mode armed but nothing is claiming)",
                    job_id)
        except Exception as exc:
            logger.warning("[jobs_api] stranded annotation failed for %s: %s",
                           job_id, exc)
    return out


@router.get("/api/jobs/{job_id}/result/arrow")
async def get_job_result_arrow(job_id: str,
                               offset: int = Query(0, ge=0),
                               limit: int = Query(10000, ge=1, le=100000),
                               _user: dict = Depends(get_current_user)):
    """Industrialization Phase 6 — page/range read of the job's result
    ARTIFACT as an Arrow IPC stream.

    Reads ONLY the Arrow record batches that intersect
    ``[offset, offset+limit)`` — a page of a 100M-row result never pulls
    the whole artifact into pod RAM.

    Authorization = the Phase-5 grant chain, with no new sharing path:
    the job must belong to the caller (or admin), and a result handle
    lands on a FOLLOWER's row only via the propagation sweep, which
    requires the leader to be ``share_verified`` (identical rendered RLS
    predicates proven through enforcement).  Reading someone else's job
    is a 404 (existence not confirmed), exactly like ``GET /api/jobs/{id}``.

    404 with ``type=no_artifact`` means the result was delivered inline
    (small result / flag off / store fallback) — use the existing
    ``/api/executions/{id}/results`` surfaces.
    """
    from fastapi.responses import Response

    job = await _load_owned_job(job_id, _user)   # owner/admin or 404
    try:
        from core.industrialization import is_enabled as _ind_enabled
        _armed = _ind_enabled("result_artifacts")
    except Exception:
        _armed = False
    if not _armed:
        raise HTTPException(status_code=404, detail={
            "type": "no_artifact",
            "message": "Result artifacts are not armed on this deployment — "
                       "use the inline result endpoints",
        })
    if job.get("status") != "succeeded" or not job.get("result_handle"):
        raise HTTPException(status_code=409, detail={
            "type": "no_result",
            "message": f"Job status is '{job.get('status')}' — no result "
                       "to read yet",
        })

    execution_id = job["result_handle"]

    def _read():
        from core.artifacts import get_artifact_service
        return get_artifact_service().read_range_for_execution(
            execution_id, offset, limit)

    from core.artifacts import ArtifactNotFound, ArtifactRangeError
    try:
        payload, meta = await asyncio.to_thread(_read)
    except ArtifactRangeError as exc:
        raise HTTPException(status_code=416, detail=str(exc))
    except ArtifactNotFound:
        raise HTTPException(status_code=404, detail={
            "type": "no_artifact",
            "message": ("No result artifact for this job (inline result) — "
                        "use GET /api/executions/"
                        f"{execution_id}/results"),
        })
    except Exception as exc:
        logger.error("[jobs_api] artifact range read failed for job %s: %s",
                     job_id, exc, exc_info=True)
        raise HTTPException(status_code=503, detail={
            "type": "artifact_read_failed",
            "message": "Artifact store read failed — the inline result "
                       "endpoints remain available",
        })

    return Response(
        content=payload,
        media_type="application/vnd.apache.arrow.stream",
        headers={
            "X-Total-Rows": str(meta.get("total_rows", 0)),
            "X-Offset": str(meta.get("offset", offset)),
            "X-Rows-In-Page": str(meta.get("rows_in_page", 0)),
        },
    )


@router.post("/api/jobs/{job_id}/cancel")
async def cancel_job(job_id: str, _user: dict = Depends(get_current_user)):
    await _load_owned_job(job_id, _user)   # authz + 404
    mode = await asyncio.to_thread(_queue().cancel, job_id)
    return {"job_id": job_id, "cancel": mode}


@router.get("/api/jobs/{job_id}/stream")
async def stream_job(job_id: str, _user: dict = Depends(get_current_user)):
    """Server-sent-events stream of job state transitions until terminal.
    Pure DB poll + relay — any API pod can stream any job (state lives in
    the shared store, pods are stateless)."""
    await _load_owned_job(job_id, _user)   # authz + 404 up-front

    async def _events():
        last_sig: Optional[tuple] = None
        loop_deadline = asyncio.get_event_loop().time() + _STREAM_MAX_SECONDS
        while True:
            try:
                job = await asyncio.to_thread(_queue().get, job_id)
            except Exception as exc:
                yield f"event: error\ndata: {json.dumps({'error': str(exc)[:500]})}\n\n"
                return
            if job is None:
                yield "event: gone\ndata: {}\n\n"
                return
            sig = (job.get("status"), job.get("result_handle"),
                   bool(job.get("response_json")), job.get("attempts"))
            if sig != last_sig:
                last_sig = sig
                yield "data: " + json.dumps(_public_view(job), default=str) + "\n\n"
            if job.get("status") in ("succeeded", "failed", "cancelled"):
                return
            if asyncio.get_event_loop().time() >= loop_deadline:
                yield "event: timeout\ndata: {}\n\n"
                return
            await asyncio.sleep(_STREAM_POLL_SECONDS)

    return StreamingResponse(_events(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no"})
