"""
Suggest / Intelligence API (Phases 46, 47, 48)

Endpoints:
  GET  /api/suggest/tables          — ranked table suggestions (Phase 46)
  GET  /api/suggest/columns         — ranked column suggestions (Phase 46)
  GET  /api/suggest/top-tables      — most-used tables (Phase 46)
  GET  /api/suggest/schema          — column schema for a table (cache + usage stats)
  GET  /api/suggest/last-result     — schema + stats of last completed execution
  GET  /api/suggest/docs            — keyword search over user_guide + architecture HTML
  GET  /api/suggest/chatbot-patterns — column classification patterns for the AI Assistant
  POST /api/analyze-query           — pre-execution rule analysis (Phase 47)
  POST /api/nl-to-sql               — pattern-based NL→SQL generation (Phase 48)
"""
from __future__ import annotations

import asyncio

import logging
import re as _re
from pathlib import Path as _Path
from html.parser import HTMLParser as _HTMLParser
from typing import List, Optional, Any, Dict

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from api.deps import get_current_user, require_admin

logger = logging.getLogger(__name__)
router = APIRouter()


# BF-NONBLOCK-AUDIT-6: every sync DB call inside an
# `async def` route is wrapped via this helper.
async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)

# Injected from main.py _startup()
_db_manager = None


def set_suggest_dependencies(db_manager) -> None:
    global _db_manager
    _db_manager = db_manager


# ── Phase 46 — Table / Column Suggestions ─────────────────────────────────────

@router.get("/api/suggest/tables")
async def suggest_tables(
    prefix: str = "",
    connection_id: Optional[int] = None,
    limit: int = 20,
    _user: dict = Depends(get_current_user),
):
    """Return tables ranked by historical usage frequency."""
    return await _adb(_db_manager.get_table_suggestions, 
        prefix=prefix, connection_id=connection_id, limit=min(limit, 50)
    )


@router.get("/api/suggest/columns")
async def suggest_columns(
    table_name: str = "",
    connection_id: Optional[int] = None,
    limit: int = 30,
    _user: dict = Depends(get_current_user),
):
    """Return columns for a table ranked by usage frequency."""
    return await _adb(_db_manager.get_column_suggestions, 
        table_name=table_name, connection_id=connection_id, limit=min(limit, 100)
    )


@router.get("/api/suggest/top-tables")
async def top_tables(
    connection_id: Optional[int] = None,
    limit: int = 50,
    _user: dict = Depends(get_current_user),
):
    """Return most-used tables overall."""
    return await _adb(_db_manager.get_top_tables, connection_id=connection_id, limit=min(limit, 100))


# ── Phase 47 — Query Analysis ─────────────────────────────────────────────────

class AnalyzeQueryRequest(BaseModel):
    sql: str
    connection_type: str = "duckdb"
    partition_columns: List[str] = []


@router.post("/api/analyze-query")
async def analyze_query(body: AnalyzeQueryRequest, _user: dict = Depends(get_current_user)):
    """Analyze SQL for common anti-patterns and return warnings."""
    from core.query_analyzer import analyze_query as _analyze, warnings_to_dicts
    warnings = _analyze(
        sql=body.sql,
        connection_type=body.connection_type,
        partition_columns=body.partition_columns,
    )
    return {
        "warnings": warnings_to_dicts(warnings),
        "warning_count": len(warnings),
        "has_errors": any(w.severity == "error" for w in warnings),
    }


# ── Phase 48 — Natural Language to SQL ───────────────────────────────────────

class NLToSQLRequest(BaseModel):
    question: str
    connection_id: Optional[int] = None
    tables: List[str] = []                       # available table names
    columns: Dict[str, List[str]] = {}           # table → [col, ...]
    connection_type: str = "duckdb"
    default_schema: Optional[str] = None
    dataset_id: Optional[int] = None             # Phase 57: semantic dataset context
    use_schema_cache: bool = True                 # Phase 57: enrich from schema_cache
    result_columns: Optional[List[str]] = None   # Phase 114-H: current result columns
    result_row_count: Optional[int] = None       # Phase 114-H: current result row count
    conversation_context: Optional[List[str]] = None  # Last N successful SQLs for context carry-over


async def _nl_semantic_context(body, _user):
    """Build the FULL semantic context for a dataset, enforcing VISIBILITY.

    404 (not 403) on a dataset the caller may not see, so the route is not
    an existence oracle.
    """
    from core.nl_to_sql import build_semantic_context
    ds = await _adb(_db_manager.get_dataset_full, body.dataset_id)
    if not ds:
        raise HTTPException(status_code=404, detail=f"Dataset {body.dataset_id} not found.")
    # SECURITY 2026-08-22 — this route handed out the FULL semantic
    # context (column names, synonyms, pre-defined condition
    # where-clauses, metric expressions) of ANY dataset by id, with no
    # visibility check: a private draft's metadata was readable by every
    # authenticated user.  Same rule as GET /api/datasets/{id}
    # (published OR owner/group/admin), same shared resolver, and 404
    # (not 403) so the route is not an existence oracle.
    from core.entitlements import dataset_can_view
    if not await _adb(dataset_can_view, ds, _user, db=_db_manager):
        raise HTTPException(status_code=404,
                            detail=f"Dataset {body.dataset_id} not found.")
    ctx = build_semantic_context(ds)
    if body.connection_type and body.connection_type != "duckdb":
        ctx.connection_type = body.connection_type
    if body.default_schema:
        ctx.default_schema = body.default_schema
    # Merge caller-supplied extra tables/columns
    for t in body.tables:
        if t not in ctx.tables:
            ctx.tables.append(t)
    for t, cols in body.columns.items():
        if t not in ctx.columns:
            ctx.columns[t] = cols
    return ctx


async def _nl_schema_cache_context(body):
    """Build a schema-cache-enriched context (connection + tables, no dataset).

    Falls back to the plain context when no table had a cache row -- a cache
    MISS is not an error, and enriching from nothing would lose the caller's
    own column types.
    """
    from core.nl_to_sql import SchemaContext, enrich_from_schema_cache
    base_ctx = SchemaContext(
        tables=body.tables, columns=body.columns,
        connection_type=body.connection_type, default_schema=body.default_schema,
    )
    cache_rows = []
    for t in body.tables[:10]:
        cached = await _adb(_db_manager.get_schema_cache, body.connection_id, t)
        if cached:
            cache_rows.append(cached)
    if cache_rows:
        return enrich_from_schema_cache(base_ctx, cache_rows)
    return base_ctx


def _nl_apply_semantic_glossary(ctx, question, semantic_rewrites, _cfg):
    """Rewrite the question through the dataset's synonyms and friendly names.

    Only in the semantic path (Phase 57); records each rewrite so the caller
    can show what it did to the question.
    """
    from core.nl_to_sql import SemanticSchemaContext, apply_glossary
    # Apply dataset synonym glossary (Phase 57 — only in semantic path)
    if not (isinstance(ctx, SemanticSchemaContext)
            and _cfg.semantic_layer.synonym_matching_enabled):
        return question
    flat_synonyms = {}
    for table_syns in ctx.synonyms.values():
        flat_synonyms.update(table_syns)
    flat_friendly = {}
    for table_fn in ctx.friendly_names.values():
        flat_friendly.update(table_fn)
    combined = {**flat_synonyms, **flat_friendly}
    rewritten = apply_glossary(question, combined)
    if rewritten != question:
        semantic_rewrites.append(f"semantic: '{question}' → '{rewritten}'")
        question = rewritten
    return question


async def _nl_feedback_response(question, ctx, semantic_rewrites, _cfg):
    """Decide whether a previously RATED NL→SQL pair answers this question.

    Returns the cached response, or None to let the converter run.  Only a
    positive rating above the auto-return threshold short-circuits.
    """
    from core.nl_to_sql import SemanticSchemaContext, result_to_dict
    # ── Feedback loop: check previously rated NL→SQL pairs ──────────────
    if not _cfg.suggestion_corrections.nl_feedback_lookup_enabled:
        return None
    _min_sim = _cfg.suggestion_corrections.nl_feedback_min_similarity
    _auto_threshold = _cfg.suggestion_corrections.nl_feedback_auto_return_threshold
    _fb_matches = await _adb(_db_manager.search_nl_feedback, question, min_similarity=_min_sim, limit=5)
    for _fb in _fb_matches:
        if _fb["rating"] != 1 or _fb["_similarity"] < _auto_threshold:
            continue
        # High-confidence match with positive feedback — return cached SQL
        from core.nl_to_sql import NLToSQLResult
        _fb_result = NLToSQLResult(
            sql=_fb["sql"],
            pattern_matched="learned_feedback",
            confidence=min(0.95, 0.7 + _fb["_similarity"] * 0.25),
            explanation=f"Matched a previously confirmed query (similarity: {_fb['_similarity']:.0%})",
            warnings=[],
        )
        if semantic_rewrites:
            _fb_result.semantic_rewrites = semantic_rewrites
        _fb_response = result_to_dict(_fb_result)
        _fb_response["feedback_source"] = True
        _fb_response["feedback_similarity"] = _fb["_similarity"]
        if isinstance(ctx, SemanticSchemaContext) and ctx.dataset_name:
            _fb_response["semantic_mode"] = True
            _fb_response["dataset_name"] = ctx.dataset_name
        return _fb_response
    return None


@router.post("/api/nl-to-sql")
async def nl_to_sql(body: NLToSQLRequest, _user: dict = Depends(get_current_user)):
    """Convert a natural language question to SQL using pattern matching.

    Phase 57 enhancement: When dataset_id is provided, uses semantic layer metadata
    (friendly names, synonyms, pre-defined conditions) for higher accuracy.
    When only connection_id + tables are available, enriches from schema_cache
    for accurate column type detection (esp. Iceberg tables).
    """
    from core.nl_to_sql import (
        nl_to_sql as _convert, SchemaContext, SemanticSchemaContext,
        result_to_dict, apply_glossary,
    )
    from core import config as _cfg

    semantic_rewrites = []

    # ── Path A: dataset_id → full semantic context ────────────────────────
    if body.dataset_id and _cfg.chatbot.semantic_context_enabled:
        ctx = await _nl_semantic_context(body, _user)

    # ── Path B: schema_cache enrichment (connection + tables, no dataset) ─
    elif body.connection_id and body.tables and body.use_schema_cache and _cfg.chatbot.semantic_context_enabled:
        ctx = await _nl_schema_cache_context(body)

    # ── Path C: plain context (no semantic data) ──────────────────────────
    else:
        ctx = SchemaContext(
            tables=body.tables, columns=body.columns,
            connection_type=body.connection_type, default_schema=body.default_schema,
        )

    # Apply config glossary substitution (existing)
    question = apply_glossary(body.question, _cfg.chatbot.glossary)
    if question != body.question:
        semantic_rewrites.append(f"glossary: '{body.question}' → '{question}'")

    question = _nl_apply_semantic_glossary(ctx, question, semantic_rewrites, _cfg)

    _fb_response = await _nl_feedback_response(
        question, ctx, semantic_rewrites, _cfg)
    if _fb_response is not None:
        return _fb_response

    result = _convert(question, ctx, conversation_context=body.conversation_context)
    if semantic_rewrites:
        result.semantic_rewrites = semantic_rewrites
    if question != body.question and not result.semantic_rewrites:
        result.explanation = "[Glossary applied] " + result.explanation

    response = result_to_dict(result)
    # Include dataset context metadata for frontend display
    if isinstance(ctx, SemanticSchemaContext) and ctx.dataset_name:
        response["semantic_mode"] = True
        response["dataset_name"] = ctx.dataset_name
    return response


@router.post("/api/nl-to-sql/semantic")
async def nl_to_sql_semantic(body: NLToSQLRequest, _user: dict = Depends(get_current_user)):
    """Semantic-aware NL→SQL. Requires dataset_id. Alias of /api/nl-to-sql with semantic path."""
    if not body.dataset_id:
        raise HTTPException(status_code=400, detail="dataset_id is required for /api/nl-to-sql/semantic")
    return await nl_to_sql(body, _user)


@router.get("/api/suggest/schema")
async def suggest_schema(
    q: str = "",
    connection_id: Optional[int] = None,
    _user: dict = Depends(get_current_user),
):
    """
    Return column schema for a table name.
    Resolution order:
      1. Exact match in DB schema cache (fast, populated after schema browser opens)
      2. Column usage stats (populated after queries run against the table)
      3. Fuzzy/prefix table match → repeat steps 1–2 for best match
    """
    if not q:
        return {"table": "", "columns": [], "message": "Provide ?q=table_name"}

    # 1 — exact schema cache hit
    if connection_id:
        cached = await _adb(_db_manager.get_schema_cache, connection_id, q)
        if cached:
            schema_data = (cached.get("schema_data") or {})
            cols = schema_data.get("columns", [])
            return {"table": q, "connection_id": connection_id, "source": "schema_cache", "columns": cols}

    # 2 — column usage stats (exact table name)
    col_stats = await _adb(_db_manager.get_column_suggestions, table_name=q, connection_id=connection_id, limit=60)
    if col_stats:
        return {
            "table": q,
            "connection_id": col_stats[0].get("connection_id"),
            "source": "usage_stats",
            "columns": [
                {"name": c["object_name"], "type": "—", "use_count": c.get("use_count", 0)}
                for c in col_stats
            ],
        }

    # 3 — fuzzy prefix match
    matches = await _adb(_db_manager.get_table_suggestions, prefix=q, connection_id=connection_id, limit=3)
    if not matches:
        return {
            "table": q, "columns": [],
            "message": f"No schema found for '{q}'. Open the schema browser for this table first, or run a query that references it.",
        }

    best = matches[0]
    best_name = best.get("object_name", q)
    best_conn  = best.get("connection_id")

    if best_conn:
        cached = await _adb(_db_manager.get_schema_cache, best_conn, best_name)
        if cached:
            schema_data = (cached.get("schema_data") or {})
            cols = schema_data.get("columns", [])
            hint = f"Closest match: '{best_name}'" if best_name.lower() != q.lower() else None
            return {"table": best_name, "connection_id": best_conn, "source": "schema_cache",
                    "columns": cols, "message": hint}

    col_stats = await _adb(_db_manager.get_column_suggestions, table_name=best_name, connection_id=best_conn, limit=60)
    hint = f"Closest match: '{best_name}'" if best_name.lower() != q.lower() else None
    return {
        "table": best_name,
        "connection_id": best_conn,
        "source": "usage_stats",
        "message": hint,
        "columns": [
            {"name": c["object_name"], "type": "—", "use_count": c.get("use_count", 0)}
            for c in col_stats
        ],
    }


def _last_completed_execution_row(session, _user):
    """Decide WHOSE most recent completed execution this caller may see."""
    from core.database import QueryExecution as _QE
    q = (
        session.query(_QE)
        .filter(_QE.status == "completed", _QE.output_file.isnot(None))
    )
    # SECURITY 2026-08-23 (Phase 2A): this returned the GLOBAL most
    # recent execution -- another user's columns, row count and a
    # 300-char preview of their SQL (literals included) -- to any
    # authenticated caller.  Non-admins now see only their OWN last
    # result: the same executed_by rule GET /api/executions applies.
    from core.roles import is_admin_like as _ial
    if not _ial(_user):
        _uid = ((_user or {}).get("user_id")
                or (_user or {}).get("username") or "")
        q = q.filter(_QE.executed_by == _uid)
    return q.order_by(_QE.started_at.desc()).first()


def _result_file_columns(output_file):
    """Read a result parquet's column names and types via DuckDB DESCRIBE."""
    from core.duckdb_factory import duckdb_connection
    with duckdb_connection() as con:
        desc_rows = con.execute(
            f"DESCRIBE SELECT * FROM read_parquet('{output_file}') LIMIT 0"
        ).fetchall()
        return [{"name": r[0], "type": r[1]} for r in desc_rows]


@router.get("/api/suggest/last-result")
def last_result_info(_user: dict = Depends(get_current_user)):
    """
    Return schema and row count for the most recent completed execution.
    Reads the stored parquet output via DuckDB — no LLM required.

    2026-06-03 — converted async→sync.  Body has zero awaits; FastAPI
    auto-dispatches sync endpoints to the threadpool so the
    session.query() + DuckDB con.execute() don't block the loop.
    """
    import os as _os

    try:
        with _db_manager.get_session() as session:
            row = _last_completed_execution_row(session, _user)
            if not row:
                return {"found": False, "message": "No completed executions with result files found."}
            output_file = row.output_file
            execution_id = row.execution_id
            total_rows   = row.total_rows or 0
            started_at   = row.started_at.isoformat() if row.started_at else None
            _qc = row.query_config if isinstance(row.query_config, dict) else {}
            sql_preview  = (_qc.get("sql") or _qc.get("raw_sql") or "")[:300]

        if not _os.path.exists(output_file):
            return {"found": False, "message": "Result file has been deleted from disk."}

        columns = _result_file_columns(output_file)

        return {
            "found": True,
            "execution_id": execution_id,
            "columns": columns,
            "total_rows": total_rows,
            "executed_at": started_at,
            "sql_preview": sql_preview,
        }
    except Exception as exc:
        logger.warning("last-result: %s", exc)
        return {"found": False, "message": str(exc)}


# ── Docs knowledge base ───────────────────────────────────────────────────────

# Module-level cache: list of {"heading", "text", "source", "keywords": set}
_docs_sections: Optional[List[Dict[str, Any]]] = None
_DOCS_STOPWORDS = {
    "the","a","an","is","are","was","were","be","been","being","have","has","had",
    "do","does","did","will","would","could","should","may","might","must","can",
    "to","of","in","on","at","by","for","with","from","and","or","not","this",
    "that","it","its","as","i","you","we","they","what","how","when","where",
    "which","who","all","any","if","so","but","more","also","use","using","used",
}

class _SectionParser(_HTMLParser):
    """Extract heading+body sections from HTML."""
    def __init__(self):
        super().__init__()
        self.sections: List[Dict[str, str]] = []
        self._heading = ""
        self._body: List[str] = []
        self._in_head = False
        self._in_script = False

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style"):
            self._in_script = True
        elif tag in ("h1", "h2", "h3", "h4"):
            self._flush()
            self._in_head = True

    def handle_endtag(self, tag):
        if tag in ("script", "style"):
            self._in_script = False
        elif tag in ("h1", "h2", "h3", "h4"):
            self._in_head = False

    def handle_data(self, data):
        if self._in_script:
            return
        data = data.strip()
        if not data:
            return
        if self._in_head:
            self._heading = data
        else:
            self._body.append(data)

    def _flush(self):
        text = " ".join(self._body).strip()
        # Remove CSS noise (lines with lots of { : ; })
        text = _re.sub(r'[^\s]+\s*:\s*[^;]+;', '', text)
        text = _re.sub(r'\s+', ' ', text).strip()
        if self._heading and len(text) > 20:
            self.sections.append({"heading": self._heading, "text": text[:800]})
        self._body = []


def _tokenize(text: str) -> set:
    """Extract lowercase tokens (3+ chars) including uppercase sigils like S3, SQL, CSV."""
    lc = text.lower()
    tokens = set(_re.findall(r'\b[a-z][a-z0-9]{2,}\b', lc))          # normal words
    # Also capture short uppercase acronyms from original: S3, SQL, CSV, API, LLM …
    tokens |= set(w.lower() for w in _re.findall(r'\b[A-Z][A-Z0-9]{1,4}\b', text))
    tokens -= _DOCS_STOPWORDS
    return tokens


# ── Built-in knowledge base for features not covered by HTML docs ─────────────
_BUILTIN_KB: List[Dict[str, str]] = [
    {
        "heading": "Circuit Breaker",
        "text": (
            "The circuit breaker protects connections from cascade failures. "
            "It has three states: CLOSED (normal), OPEN (blocking requests after repeated failures), "
            "and HALF_OPEN (testing recovery). Configure thresholds in config.json under 'circuit_breaker'. "
            "View live state at Admin → Circuit Breakers. The breaker opens after N consecutive failures "
            "and resets after a cool-down window. WebSocket events broadcast state changes in real time."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Query Cache",
        "text": (
            "Query results are cached as parquet files to avoid re-running identical queries. "
            "The cache key includes file modification times so stale data is never served. "
            "A 'base-data cache' reuses the same parquet when only the SELECT list changes. "
            "Cache entries are invalidated when the underlying connection or file changes. "
            "Manage cache at Admin → Cache. Use DELETE /api/admin/cache to clear manually."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Anomaly Detection",
        "text": (
            "Anomaly detection runs z-score analysis on scheduled query results. "
            "When a scheduled run produces a metric value more than N standard deviations "
            "from the historical mean, an anomaly alert is raised and sent as a notification. "
            "Configure sensitivity in config.json under 'anomaly_detection'. "
            "View detected anomalies at Admin → Anomalies."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Connection Pooling",
        "text": (
            "Per-connection pools manage DuckDB and file-based connections to avoid overhead "
            "from creating a new connection on every query. Idle connections are evicted after "
            "a configurable timeout. Pool stats are visible at Admin → Connection Pools. "
            "Configure pool sizes in config.json under 'connection_pool'."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Arrow IPC Streaming",
        "text": (
            "Large query results can be streamed in Apache Arrow IPC format for high-throughput "
            "data transfer to BI tools or Python clients. Use GET /api/executions/{id}/results/arrow "
            "with Accept: application/vnd.apache.arrow.stream. Arrow format avoids JSON serialization "
            "overhead and is ideal for datasets with millions of rows."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Idempotency & Deduplication",
        "text": (
            "Executions support idempotency keys to prevent duplicate runs. If the same query "
            "is submitted twice within 10 minutes with the same key, the second request returns "
            "the first result without re-executing. Shadow executions wait on an asyncio.Event "
            "for in-flight identical queries, saving server resources."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "NL-to-SQL (Natural Language to SQL)",
        "text": (
            "The NL-to-SQL engine converts plain English to SQL using 11 built-in patterns "
            "(no LLM required). Patterns include: top N by column, average/sum per group, "
            "distinct values, min/max, date range, recent rows, filter equals, count, group-by count, "
            "show all. Use the chat assistant or the NL panel in the SQL editor. "
            "Example: 'top 10 customers by revenue', 'average salary by department', "
            "'orders where status is pending', 'sales between 2025-01-01 and 2025-12-31'."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Query Analyzer",
        "text": (
            "The query analyzer checks SQL for performance and correctness issues before execution. "
            "It detects: SELECT_STAR (missing column list), S3_LIMIT_NO_PUSHDOWN (LIMIT won't speed up S3 scans), "
            "MISSING_PARTITION_FILTER (no partition column in WHERE), CROSS_JOIN (cartesian product), "
            "UNBOUNDED_GROUP_BY, FULL_TABLE_SCAN, and DDL_DML_STATEMENT. "
            "Warnings appear as a banner above query results. "
            "API: POST /api/analyze-query."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Table & Column Lineage",
        "text": (
            "QueryStudio tracks which tables and columns each saved query reads from and writes to. "
            "Table lineage shows an interactive DAG (directed acyclic graph) with table → query edges. "
            "Column lineage shows how each output column is derived (direct copy, renamed, computed, "
            "aggregated, casted, star_expansion). View lineage at the Lineage page. "
            "Lineage is extracted automatically when queries are saved using sqlglot AST parsing."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Materialized Views",
        "text": (
            "Materialized views pre-compute and store query results as parquet files for fast access. "
            "They can be refreshed manually or on a schedule. Create at Data → Materialized Views. "
            "A materialized view stores the output of any SQL query and serves it from disk "
            "on subsequent reads, bypassing re-execution. Useful for slow aggregation queries."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Scheduled Queries",
        "text": (
            "Queries can be scheduled to run automatically using cron expressions or simple intervals. "
            "Go to a saved query → Schedule tab to set up a schedule. "
            "The scheduler uses APScheduler and supports: every N minutes, hourly, daily, weekly, cron. "
            "Results are stored as executions and can trigger anomaly detection alerts. "
            "Scheduled runs respect the same RBAC permissions as manual runs."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "S3 Connections & Live Streaming",
        "text": (
            "S3 connections query data directly from S3 using DuckDB's httpfs extension. "
            "IMPORTANT: SELECT * LIMIT 500 does NOT speed up S3 — a full scan is still required "
            "because LIMIT is not pushed down to S3. Use partition filters (WHERE year=2024) to reduce scans. "
            "S3 live streaming streams results row-by-row as they are read. "
            "Configure S3 credentials (access_key, secret_key, region, endpoint) in Connections."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "DuckDB Connections",
        "text": (
            "DuckDB is the default local analytics engine. It can query parquet, CSV, JSON, and Iceberg files. "
            "DuckDB runs in a subprocess to isolate crashes from the FastAPI server. "
            "Use file paths or S3 URIs directly in SQL: SELECT * FROM read_parquet('data/*.parquet'). "
            "Multiple files: read_parquet(['file1.parquet', 'file2.parquet']). "
            "Glob patterns: read_parquet('s3://bucket/prefix/**/*.parquet')."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Snowflake, Trino, Databricks, Oracle Connectors",
        "text": (
            "QueryStudio supports external connectors: Snowflake (account + credentials), "
            "Trino (host + catalog + schema), Databricks (server hostname + HTTP path + token), "
            "Oracle (host + port + service name + credentials). "
            "Configure at Connections → New Connection → choose type. "
            "Each connector runs queries in the target system and streams results back."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Exporting Results",
        "text": (
            "Query results can be exported from the data grid. Click the Export button (↓) in the results toolbar. "
            "Supported formats: CSV, Parquet, Excel (XLSX), JSON. "
            "Large exports run as background downloads. Exported files appear in the Downloads panel. "
            "S3-backed files can be promoted to local tables for repeated querying."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Query Builder (Visual)",
        "text": (
            "The visual Query Builder lets you construct queries without writing SQL. "
            "Select tables, choose join conditions, pick columns, add filters and sort. "
            "The builder generates SQL which can be previewed and executed. "
            "Use Query Builder → New Query. Supports multi-table joins, aggregations, and GROUP BY."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "SQL Editor",
        "text": (
            "The SQL Editor provides a Monaco-based code editor for writing queries. "
            "Features: syntax highlighting, auto-complete (Ctrl+Space), multi-tab support, "
            "run selected text (Ctrl+Enter), query history, NL-to-SQL panel (right drawer). "
            "Tabs are preserved across page reloads. Stale tabs show a placeholder after 5 minutes of inactivity. "
            "Use the NL toggle button to open the natural language assistant inline."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Workspaces",
        "text": (
            "Workspaces let you organise queries, connections, and views into named groups. "
            "Create workspaces at the top navigation bar. Switching workspaces filters the "
            "query list, connections, and materialized views to that workspace. "
            "Queries can be shared across workspaces."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "RBAC — Roles and Permissions",
        "text": (
            "QueryStudio has three built-in roles: admin, analyst, viewer. "
            "Admin: full access including user management, config, and admin endpoints. "
            "Analyst: can create/run/schedule queries and manage connections. "
            "Viewer: read-only access to results and shared queries. "
            "Assign roles at Admin → Users. Auth supports LDAP/AD and local password."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Audit Log & Compliance",
        "text": (
            "All query executions, login events, config changes, and admin actions are recorded "
            "in the audit log. View at Admin → Audit Log. "
            "Compliance reports can be exported as CSV. "
            "The audit log captures: user, action, resource, timestamp, IP address, and outcome."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "How to Execute a Query",
        "text": (
            "To run a query: 1) Go to SQL Editor or Query Builder. "
            "2) Type or build your SQL. 3) Press Ctrl+Enter or click the Run button (▶). "
            "Results appear in the Data Grid below the editor. "
            "You can also run from the assistant: type your question, generate SQL, then click 'Use in SQL Editor'. "
            "For scheduled runs, open the query → Schedule tab."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Data Grid — Sort, Filter, Chart, Pivot",
        "text": (
            "The data grid supports: column sorting (click header), advanced filters (funnel icon), "
            "column visibility toggle, freeze/pin columns, export (CSV/Parquet/Excel). "
            "Switch to Chart view to visualise data as bar, line, pie, or scatter chart. "
            "Switch to Pivot view for Excel-style cross-tabulation with row/column/value fields. "
            "Column stats (min, max, avg, null count) are available per column."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Auto-Suggest (Table & Column Suggestions)",
        "text": (
            "As you write SQL, QueryStudio tracks table and column usage. "
            "The assistant can suggest the most-used tables (say 'what tables are available?') "
            "and columns for any table (say 'columns in orders'). "
            "Suggestions are ranked by usage frequency. Schema cache is populated when you "
            "open the schema browser or run queries."
        ),
        "source": "Built-in KB",
    },
    {
        "heading": "Finance Reports with parameters",
        "text": (
            "A finance report can declare parameters (Report Builder > Parameters) that "
            "consumers fill in at run time without editing the definition. "
            "A report over a SQL query or .sql file uses {param_name} placeholders in the SQL; "
            "a dataset report binds each parameter to a column. "
            "Published reports can be shared with viewers who only see the parameter form. "
            "(The separate 'parametric reports' feature was retired in favour of this.)"
        ),
        "source": "Built-in KB",
    },
]


def _load_docs() -> List[Dict[str, Any]]:
    global _docs_sections
    if _docs_sections is not None:
        return _docs_sections

    docs_root = _Path(__file__).parent.parent.parent  # c:/DEV/outputs
    html_files = [
        (docs_root / "user_guide.html",              "User Guide"),
        (docs_root / "ARCHITECTURE.html",            "Architecture"),
        (docs_root / "technical-learning-guide.html","Tech Guide"),
        (docs_root / "feature-tracking.html",        "Feature Tracking"),
        (docs_root / "plan.html",                    "Plan"),
    ]
    sections: List[Dict[str, Any]] = []

    # 1. Parse HTML files
    for path, source in html_files:
        if not path.exists():
            continue
        try:
            html = path.read_text(encoding="utf-8", errors="replace")
            parser = _SectionParser()
            parser.feed(html)
            for s in parser.sections:
                full_text = s["heading"] + " " + s["text"]
                kw = _tokenize(full_text)
                sections.append({
                    "heading":        s["heading"],
                    "text":           s["text"],
                    "source":         source,
                    "keywords":       kw,
                    "heading_tokens": _tokenize(s["heading"]),
                })
        except Exception as exc:
            logger.warning("docs: failed to load %s — %s", path, exc)

    # 2. Add built-in knowledge base entries
    for entry in _BUILTIN_KB:
        full_text = entry["heading"] + " " + entry["text"]
        kw = _tokenize(full_text)
        sections.append({
            "heading":        entry["heading"],
            "text":           entry["text"],
            "source":         entry["source"],
            "keywords":       kw,
            "heading_tokens": _tokenize(entry["heading"]),
        })

    _docs_sections = sections  # cache — cleared only on module reload
    logger.info("Docs knowledge base loaded: %d sections (%d HTML + %d built-in)",
                len(sections), len(sections) - len(_BUILTIN_KB), len(_BUILTIN_KB))
    return _docs_sections


def _phrase_score(query_lc: str, q_words: List[str],
                  head_lc: str, full_lc: str) -> float:
    """Score how well the query matches as a PHRASE, not as loose tokens.

    A whole-query hit short-circuits (heading ×10, body ×5); otherwise each
    bigram scores (heading ×4, body ×2).
    """
    if query_lc in head_lc:
        return 10.0
    if query_lc in full_lc:
        return 5.0
    phrase_score = 0.0
    for i in range(len(q_words) - 1):
        bigram = q_words[i] + " " + q_words[i + 1]
        if bigram in head_lc:
            phrase_score += 4
        elif bigram in full_lc:
            phrase_score += 2
    return phrase_score


def _score_doc_section(s: Dict[str, Any], q_tokens: set, query_lc: str,
                       q_words: List[str]) -> float:
    """Score one docs section against the query; decides its rank."""
    full_lc = (s["heading"] + " " + s["text"]).lower()
    head_lc = s["heading"].lower()

    heading_overlap = len(q_tokens & s["heading_tokens"])
    body_overlap    = len(q_tokens & s["keywords"])

    # Phrase match: query as a whole or as bigrams in heading / body
    phrase_score = _phrase_score(query_lc, q_words, head_lc, full_lc)

    # Substring bonus for tokens not already counted
    substr_bonus = sum(
        1.5 for t in q_tokens
        if len(t) >= 4 and t in full_lc and t not in s["keywords"]
    )

    score = heading_overlap * 4 + body_overlap + substr_bonus + phrase_score
    # Freshness boost for built-in KB
    if s["source"] == "Built-in KB":
        score *= 1.2
    return score


def _search_docs(query: str, top_k: int = 3) -> List[Dict[str, Any]]:
    """
    Score sections by token overlap + phrase matching.
    Scoring weights:
      • heading exact-phrase match   ×10
      • heading token overlap        ×4 each
      • body exact-phrase match      ×5
      • body token overlap           ×1 each
      • substring bonus (4+ chars)   ×1.5 each
      • built-in KB section          ×1.2 multiplier (freshest docs)
    """
    sections = _load_docs()
    q_tokens = _tokenize(query)
    if not q_tokens:
        return []

    query_lc = query.strip().lower()
    # Build 2-word phrases from the query for phrase matching
    q_words = [w for w in _re.split(r'\s+', query_lc) if len(w) >= 3]

    scored = []
    for s in sections:
        score = _score_doc_section(s, q_tokens, query_lc, q_words)
        if score >= 1:
            scored.append((score, s))

    scored.sort(key=lambda x: x[0], reverse=True)
    results = []
    seen_headings: set = set()
    for score, s in scored:
        if len(results) >= top_k:
            break
        # Deduplicate near-identical headings
        hkey = s["heading"].lower()[:40]
        if hkey in seen_headings:
            continue
        seen_headings.add(hkey)
        results.append({
            "heading": s["heading"],
            "excerpt": s["text"][:500] + ("…" if len(s["text"]) > 500 else ""),
            "source":  s["source"],
            "score":   round(score, 1),
        })
    return results


@router.get("/api/suggest/docs")
async def suggest_docs(
    q: str = "",
    _user: dict = Depends(get_current_user),
):
    """
    Keyword search over the QueryStudio user guide and architecture docs.
    Returns the top matching sections (heading + excerpt) — no LLM needed.
    """
    if not q or len(q.strip()) < 3:
        return {"results": [], "message": "Provide ?q=your+question"}

    results = _search_docs(q.strip(), top_k=3)
    return {
        "query": q,
        "results": results,
        "found": len(results) > 0,
    }


# ── Phase: Grid Data Query ────────────────────────────────────────────────────

# Negative lookahead: prevent capturing prepositions/articles as column names.
# E.g. "average by month" must NOT capture "by" as the column.
# Column capture: supports multi-word columns like "currency amount" → matched via _resolve_column
_NO_PREP    = r'(?!(?:by|the|a|an|in|from|for|to|of|all|each|per|and|or|my)\b)'
# Multi-word column pattern: captures "col_name" or "col name" (1-3 words)
_COL        = r'([\w]+(?:\s+[\w]+){0,2})'
_MAX_RE     = _re.compile(r'\bmax(?:imum)?\s+(?:of\s+)?' + _COL, _re.I)
_MIN_RE     = _re.compile(r'\bmin(?:imum)?\s+(?:of\s+)?' + _COL, _re.I)
_AVG_RE     = _re.compile(r'\b(?:avg|average|mean)\s+(?:of\s+)?' + _COL, _re.I)
# SUM + TOTAL handled together
_SUM_RE     = _re.compile(r'\b(?:sum|total)\s+(?:of\s+)?' + _COL, _re.I)
_TOPN_RE    = _re.compile(r'\btop\s+(\d+)\s+(?:rows?\s+)?(?:by\s+)?' + _COL, _re.I)
# Distinct: accept both "in" and "of" as separators → "distinct values in status"
_DIST_RE    = _re.compile(r'\bdistinct(?:\s+values?)?\s+(?:(?:of|in)\s+)?' + _COL, _re.I)
_COUNTW_RE  = _re.compile(r'\bcount\s+where\s+([\w]+)\s*(?:=|is|equals?)\s*["\']?([^"\']+?)["\']?(?:\s|$)', _re.I)
_GROUPBY_RE = _re.compile(r'\b(?:count|group|aggregate)\s+by\s+' + _COL, _re.I)
_FILTER_RE  = _re.compile(r'\b(?:show|where|filter|rows?\s+where)\s+([\w]+)\s*(?:=|is|equals?)\s*["\']?([^"\']+?)["\']?(?:\s|$)', _re.I)
_FIRSTN_RE  = _re.compile(r'\b(?:first|top)\s+(\d+)\b', _re.I)
_TREND_RE   = _re.compile(
    r'\b(?:trend(?:ing)?|over\s+time|by\s+(?:month|week|day|year|quarter|date)'
    r'|monthly|weekly|daily|yearly|quarterly|growth|change\s+over|time\s+series)\b', _re.I)
_SUMMARY_RE = _re.compile(
    r'\b(?:summar(?:y|ize|ise)|overview|describe(\s+(?:this|the)\s+data)?'
    r'|profile|insights?|whats?\s+interesting|analyze\s+(this\s+)?data|quick\s+(look|stats?)'
    r'|tell\s+me\s+about\s+(this|the)\s+data)\b', _re.I)
_OUTLIER_RE = _re.compile(
    r'\b(?:outlier|anomal|unusual|extreme\s+values?|spikes?|dips?|weird|suspicious)\b', _re.I)
_XBYY_RE    = _re.compile(
    r'\b(\w+)\s+by\s+(\w+)\b', _re.I)  # "revenue by entity", "sum of X by Y"
# Extended agg function recognition — covers all common SQL aggregate functions
_AGG_WORDS  = (r'sum|total|avg|average|mean|count|min|max|minimum|maximum'
               r'|aggregate|agg|median|mode|stddev|stdev|variance|var')
_XBYY_AGG_RE = _re.compile(
    r'\b(' + _AGG_WORDS + r')\s+(?:of\s+)?' + _COL + r'\s+(?:by|per|grouped?\s+by|for\s+each)\s+' + _COL, _re.I)
# "aggregate by currency" (no explicit value col → auto-detect numeric)
_AGG_BY_RE    = _re.compile(
    r'\b(?:aggregate|agg|summarize|summarise|group|rollup)\s+(?:by|per)\s+' + _COL, _re.I)
_BOTTOMN_RE   = _re.compile(r'\bbottom\s+(\d+)\s+(?:rows?\s+)?(?:by\s+)?' + _COL, _re.I)
_MEDIAN_RE    = _re.compile(r'\bmedian\s+(?:of\s+)?' + _COL, _re.I)
_PERCENTILE_RE = _re.compile(r'\bpercentile\s+(\d+)\s+(?:of\s+)?' + _COL, _re.I)
_STDDEV_RE    = _re.compile(r'\b(?:std\s*dev(?:iation)?|stdev|variance|var)\s+(?:of\s+)?' + _COL, _re.I)
_CORR_RE      = _re.compile(r'\bcorrelation\s+(?:between\s+)?(\w+)\s+(?:and|vs|versus)\s+(\w+)', _re.I)
_NULLCOL_RE   = _re.compile(r'count\s+null[s]?\s+per\s+column|null[s]?\s+per\s+col|null\s+count', _re.I)
_NULLIN_RE    = _re.compile(r'\bnull[s]?\s+in\s+(\w+)|\bshow\s+null[s]?\s+(?:in\s+)?(\w+)', _re.I)
_ANYNULL_RE   = _re.compile(r'\brows?\s+with\s+any\s+null\b|missing\s+values?\s+in\s+any', _re.I)
_DUPES_RE     = _re.compile(r'\bduplicat(?:es?|ion)?\s+(?:in\s+|by\s+|of\s+)?(\w+)', _re.I)
_SAMPLE_RE    = _re.compile(r'\brandom\s+sample\s+(?:of\s+)?(\d+)', _re.I)
_PIVOT_RE     = _re.compile(r'\bpivot\s+(\w+)\s+by\s+(\w+)', _re.I)
_FREQDIST_RE  = _re.compile(r'\bfrequency\s+distribution\s+(?:of\s+)?(\w+)', _re.I)
_MOSTCOMMON_RE = _re.compile(r'\bmost\s+common\s+(?:values?\s+in\s+)?(\w+)', _re.I)
_SORTBY_RE    = _re.compile(r'\bsort(?:ed)?\s+by\s+(\w+)(?:\s+(asc(?:ending)?|desc(?:ending)?))?', _re.I)
_RUNNING_RE   = _re.compile(
    r'\b(?:running\s+total|cumulative\s+sum?)\s+(?:of\s+)?(\w+)(?:\s+(?:by|over|order(?:ed)?\s+by)\s+(\w+))?', _re.I)
_YTD_RE       = _re.compile(r'\b(?:this\s+year|year[\s-]to[\s-]date|ytd)\b', _re.I)
_MTD_RE       = _re.compile(r'\b(?:this\s+month|month[\s-]to[\s-]date|mtd)\b', _re.I)
_LASTMONTH_RE = _re.compile(r'\blast\s+month\b', _re.I)
_LAST7_RE     = _re.compile(r'\blast\s+7\s+days?\b', _re.I)
_LAST30_RE    = _re.compile(r'\blast\s+30\s+days?\b', _re.I)
_LAST90_RE    = _re.compile(r'\blast\s+90\s+days?\b', _re.I)
_LASTQUARTER_RE = _re.compile(r'\blast\s+quarter\b', _re.I)
_THISQUARTER_RE = _re.compile(r'\b(?:this\s+quarter|quarter[\s-]to[\s-]date|qtd)\b', _re.I)


# ── Helpers for smart column detection ────────────────────────────────────────

_DATE_COL_PATTERNS  = _re.compile(
    r'^(date|time|day|month|year|period|quarter|fiscal|posted|created|updated|entry|timestamp)', _re.I)
# Word-boundary-aware patterns: terms must appear as whole tokens separated by
# _ - . or start/end of string, so "sap_account" ≠ "count" and "corporate" ≠ "rate".
_NUM_COL_PATTERNS   = _re.compile(
    r'(?:(?:^|(?<=[_\-\. ]))'
    r'(amount|price|total|revenue|qty|quantity|count|metric|rate|value|balance'
    r'|debit|credit|cost|profit|salary|score|weight|volume|fee|charge)'
    r'(?=$|[_\-\. ]))', _re.I)
_CAT_COL_PATTERNS   = _re.compile(
    r'(?:(?:^|(?<=[_\-\. ]))'
    r'(status|type|category|entity|source|currency|country|region|code|flag'
    r'|class|group|segment|channel|brand|product|dept|division)'
    r'(?=$|[_\-\. ]))', _re.I)


def _pick_date_col(cols: List[str]) -> Optional[str]:
    """Find the most likely date/time column."""
    for c in cols:
        if _DATE_COL_PATTERNS.search(c):
            return c
    # Fallback: anything ending in _at, _date, _time
    for c in cols:
        if c.lower().endswith(('_at', '_date', '_time', '_dt')):
            return c
    return None


def _pick_num_col(cols: List[str]) -> Optional[str]:
    """Find the most likely numeric measure column (excluding date columns)."""
    for c in cols:
        if _NUM_COL_PATTERNS.search(c) and not _DATE_COL_PATTERNS.search(c):
            return c
    return None


def _pick_cat_col(cols: List[str]) -> Optional[str]:
    """Find the most likely categorical column."""
    for c in cols:
        if _CAT_COL_PATTERNS.search(c):
            return c
    return None


def _resolve_column(col: str, available: List[str]) -> str:
    """Best-match a user-typed column name against the real column list.
    Priority: exact → space↔underscore normalised → prefix → substring → as-is.
    Handles multi-word user input like "currency amount" matching "currency_amount".

    SQL-INJECTION INVARIANT (reviewed 2026-09-13, ruff S608) — READ BEFORE
    EDITING.  Every return value of this function is interpolated into a
    DuckDB double-quoted identifier, ``f'"{col}"'``, on ~15 call sites in
    this module.  Two of the paths below return the CALLER'S STRING
    UNCHANGED — the empty-``available`` guard, and the final no-match
    ``return col``.  That is safe today, but NOT because of anything this
    function does.  It rests on two invariants OUTSIDE it:

      1. Every ``col`` argument comes from a capture group of one of this
         module's question regexes, and every one of those groups is
         ``[BACKSLASH-w]+`` (see ``_COL``) or ``(BACKSLASH-w+)``.  A double quote
         cannot appear in a match, so the raw passthrough cannot close the
         identifier.
      2. Every ``available`` list is double-quote-escaped where the
         untrusted list enters — ``data_query`` builds it as
         ``[str(c).replace(CHR34, CHR34 * 2) for c in body.columns]``,
         because ``columns`` is supplied by the CLIENT.

    So the validator is the REGEX and the entry-point escape, not this
    matcher.  Widening ``_COL`` to accept punctuation (a natural-looking
    change — "let users quote a column with spaces or a dot") would turn
    both passthroughs into SQL injection against DuckDB, which can read
    files and, with httpfs loaded, reach S3 with the pod's credentials.
    If you widen it, escape here instead.
    """
    if not available:
        return col
    col = col.strip()
    cl = col.lower()
    # Normalise: spaces → underscores for comparison (user says "currency amount", col is "currency_amount")
    cl_norm = cl.replace(" ", "_")
    # 1. Exact match (case-insensitive)
    for c in available:
        if c.lower() == cl:
            return c
    # 2. Normalised match (space↔underscore)
    for c in available:
        if c.lower() == cl_norm:
            return c
    # 3. Prefix match
    for c in available:
        lo = c.lower()
        if lo.startswith(cl) or lo.startswith(cl_norm):
            return c
    # 4. Substring match
    for c in available:
        lo = c.lower()
        if cl_norm in lo or cl in lo:
            return c
    return col


class DataQueryRequest(BaseModel):
    question: str
    execution_id: Optional[str] = None   # from a completed query execution
    file_id: Optional[str] = None        # from a downloaded S3 / upload file
    columns: List[str] = []


def _owned_execution_output(session, execution_id, user, not_found):
    """Resolve an execution id to its output file, enforcing the EXECUTION
    OWNER rule.

    Returns ``(path, None)``, ``(None, None)`` when the id names nothing,
    or ``(None, not_found)`` for a caller who does not own it -- the same
    answer as a missing id, so there is no existence oracle.
    """
    from core.database import QueryExecution as _QE
    from fastapi import HTTPException as _HTTPExc
    row = (
        session.query(_QE)
        .filter(_QE.execution_id == execution_id,
                _QE.status == "completed",
                _QE.output_file.isnot(None))
        .first()
    )
    if not row:
        return None, None
    try:
        from api.data_grid_api import _enforce_execution_ownership
        _enforce_execution_ownership(execution_id, user)
    except _HTTPExc:
        return None, not_found
    return row.output_file, None


def _owned_download_path(session, file_id, user, not_found):
    """Resolve a download file id to its path, enforcing the DOWNLOAD OWNER
    rule.  Same tri-state answer as :func:`_owned_execution_output`."""
    from core.database import DownloadFile as _DF
    from fastapi import HTTPException as _HTTPExc
    drow = (
        session.query(_DF)
        .filter(_DF.file_id == file_id)
        .first()
    )
    if not drow:
        return None, None
    try:
        from api.data_grid_api import _enforce_download_ownership
        _enforce_download_ownership(
            {"created_by": drow.created_by,
             "execution_id": drow.execution_id},
            user,
        )
    except _HTTPExc:
        return None, not_found
    return drow.file_path, None


def _lookup_owned_result_path(execution_id, file_id, user, not_found):
    """Look up the result path for either id in ONE session, owner-checked.

    The execution id is tried first and the file id only when it produced
    nothing -- the original precedence.  An ownership refusal from either
    stops the lookup rather than falling through to the other id.
    """
    with _db_manager.get_session() as session:
        output_file = None
        if execution_id:
            output_file, _err = _owned_execution_output(
                session, execution_id, user, not_found)
            if _err:
                return None, _err
        if not output_file and file_id:
            output_file, _err = _owned_download_path(
                session, file_id, user, not_found)
            if _err:
                return None, _err
    return output_file, None


def _resolve_owned_result_file(execution_id, file_id, user) -> tuple:
    """Resolve an execution/download reference to its result file, enforcing
    OWNERSHIP.  Returns ``(path, None)`` on success, ``(None, message)`` on
    any failure -- the assistant endpoints answer 200 with a message, and a
    non-owner gets the same "not found" as a missing id (no existence
    oracle).

    SECURITY 2026-08-23 (Phase 2A): ``data-query`` and ``data-profile`` both
    resolved these ids with NO ownership check -- any authenticated user
    could aggregate, filter and read sample rows out of ANOTHER user's
    query results by guessing/enumerating execution or file ids, straight
    past the per-owner gates on /api/executions/{id}/results.  The two
    endpoints also carried two copies of the resolution logic; this is the
    one copy, and it reuses the ownership rules already owned by
    data_grid_api (execution owner / download owner).
    """
    import os as _os

    _NOT_FOUND = "File not found. Run a query first or check the file ID."
    if not execution_id and not file_id:
        return None, "Provide execution_id or file_id."

    try:
        output_file, _err = _lookup_owned_result_path(
            execution_id, file_id, user, _NOT_FOUND)
    except Exception as exc:
        return None, str(exc)
    if _err:
        return None, _err

    if not output_file:
        return None, _NOT_FOUND
    if not _os.path.exists(output_file):
        return None, "Result file has been deleted from disk."
    return output_file, None


def _dq_grouped_aggregate(ql, avail, sp):
    """Decide a grouped aggregate ("sum of X by Y").

    Checked FIRST so "sum of X by Y" beats plain "sum of X".  Refuses
    with a message when a numeric aggregate is asked of an ID/text
    column -- the answer would be meaningless, not wrong-but-useful.
    """
    sql = None
    answer_prefix = ""
    if m := _XBYY_AGG_RE.search(ql):
        agg_fn_map = {
            "sum": "SUM", "total": "SUM", "aggregate": "SUM", "agg": "SUM",
            "avg": "AVG", "average": "AVG", "mean": "AVG",
            "count": "COUNT",
            "min": "MIN", "minimum": "MIN",
            "max": "MAX", "maximum": "MAX",
            "median": "MEDIAN", "mode": "MODE",
            "stddev": "STDDEV", "stdev": "STDDEV",
            "variance": "VARIANCE", "var": "VARIANCE",
        }
        agg_fn  = agg_fn_map.get(m.group(1).lower(), "SUM")
        val_col = _resolve_column(m.group(2), avail)
        grp_col = _resolve_column(m.group(3), avail)
        # Detect likely non-numeric (ID / text) columns when a numeric agg is requested
        _ID_COL_RE = _re.compile(
            r'(?:_id|_key|_code|_num|_no|_ref|_uuid|^id$|^pk$|_name|_label|_desc)', _re.I)
        _numeric_agg = agg_fn in ("SUM", "AVG", "MEDIAN", "STDDEV", "VARIANCE", "MODE")
        if _numeric_agg and _ID_COL_RE.search(val_col):
            return {
                "found": False,
                "message": (
                    f"'{val_col}' looks like a text/ID column — {agg_fn.lower()} is not meaningful on it.\n"
                    f"Try: **count {val_col} by {grp_col}** to count rows per group, "
                    f"or pick a numeric column like debit_amount or balance."
                ),
                "sql": None,
            }
        agg_expr = "COUNT(*)" if agg_fn == "COUNT" else f"ROUND({agg_fn}(TRY_CAST(\"{val_col}\" AS DOUBLE)), 2)"
        sql = (
            f"SELECT \"{grp_col}\", {agg_expr} AS {agg_fn.lower()}_{val_col} "
            f"FROM read_parquet('{sp}') "
            f"GROUP BY \"{grp_col}\" ORDER BY {agg_fn.lower()}_{val_col} DESC NULLS LAST LIMIT 50"
        )
        answer_prefix = f"{agg_fn.title()} of {val_col} by {grp_col}"
    if sql is None:
        return None
    return sql, answer_prefix

def _dq_scalar_aggregate(ql, avail, sp):
    """Decide a single-value aggregate: max / min / avg / sum.

    avg and sum refuse an ID/text column for the same reason the
    grouped form does.
    """
    sql = None
    answer_prefix = ""
    if m := _MAX_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        sql = f"SELECT MAX(\"{col}\") AS max_{col} FROM read_parquet('{sp}')"
        answer_prefix = f"Maximum of {col}"
    elif m := _MIN_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        sql = f"SELECT MIN(\"{col}\") AS min_{col} FROM read_parquet('{sp}')"
        answer_prefix = f"Minimum of {col}"
    elif m := _AVG_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        if _re.search(r'(?:_id|_key|_code|_num|_no|_ref|_uuid|^id$|^pk$|_name|_label|_desc)', col, _re.I):
            return {"found": False, "message": f"'{col}' looks like a text/ID column — avg is not meaningful on it. Try a numeric column like debit_amount or balance.", "sql": None}
        sql = f"SELECT ROUND(TRY_CAST(AVG(TRY_CAST(\"{col}\" AS DOUBLE)) AS DOUBLE), 4) AS avg_{col} FROM read_parquet('{sp}')"
        answer_prefix = f"Average of {col}"
    elif m := _SUM_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        if _re.search(r'(?:_id|_key|_code|_num|_no|_ref|_uuid|^id$|^pk$|_name|_label|_desc)', col, _re.I):
            return {"found": False, "message": f"'{col}' looks like a text/ID column — sum is not meaningful on it. Try a numeric column like debit_amount or balance.", "sql": None}
        sql = f"SELECT ROUND(SUM(TRY_CAST(\"{col}\" AS DOUBLE)), 2) AS sum_{col} FROM read_parquet('{sp}')"
        answer_prefix = f"Sum of {col}"
    if sql is None:
        return None
    return sql, answer_prefix

def _dq_ranking_or_distinct(ql, avail, sp):
    """Decide a row-window or spread question: bottom N, median,
    percentile, top N, or the distinct values of a column."""
    sql = None
    answer_prefix = ""
    if m := _BOTTOMN_RE.search(ql):
        n = min(int(m.group(1)), 100)
        col = _resolve_column(m.group(2), avail)
        sql = f"SELECT * FROM read_parquet('{sp}') ORDER BY TRY_CAST(\"{col}\" AS DOUBLE) ASC NULLS LAST LIMIT {n}"
        answer_prefix = f"Bottom {n} by {col}"
    elif m := _MEDIAN_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        sql = f"SELECT ROUND(MEDIAN(TRY_CAST(\"{col}\" AS DOUBLE)), 4) AS median_{col} FROM read_parquet('{sp}')"
        answer_prefix = f"Median of {col}"
    elif m := _PERCENTILE_RE.search(ql):
        pct = max(1, min(int(m.group(1)), 99))
        col = _resolve_column(m.group(2), avail)
        sql = f"SELECT ROUND(QUANTILE_CONT(TRY_CAST(\"{col}\" AS DOUBLE), {pct/100}), 4) AS p{pct}_{col} FROM read_parquet('{sp}')"
        answer_prefix = f"{pct}th percentile of {col}"
    elif m := _TOPN_RE.search(ql):
        n = min(int(m.group(1)), 100)
        col = _resolve_column(m.group(2), avail)
        sql = f"SELECT * FROM read_parquet('{sp}') ORDER BY \"{col}\" DESC NULLS LAST LIMIT {n}"
        answer_prefix = f"Top {n} by {col}"
    elif m := _DIST_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        sql = f"SELECT DISTINCT \"{col}\" FROM read_parquet('{sp}') ORDER BY 1 LIMIT 100"
        answer_prefix = f"Distinct values of {col}"
    if sql is None:
        return None
    return sql, answer_prefix

def _dq_count_or_filter(ql, avail, sp):
    """Decide a counting or row-filtering question: count where X = v,
    count/group by X, aggregate by X, or rows where X = v."""
    sql = None
    answer_prefix = ""
    if m := _COUNTW_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        val = m.group(2).strip()
        sql = f"SELECT COUNT(*) AS count FROM read_parquet('{sp}') WHERE LOWER(CAST(\"{col}\" AS VARCHAR)) = LOWER('{val.replace(chr(39), chr(39)+chr(39))}')"
        answer_prefix = f"Count where {col} = {val}"
    elif m := _GROUPBY_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        sql = f"SELECT \"{col}\", COUNT(*) AS count FROM read_parquet('{sp}') GROUP BY \"{col}\" ORDER BY count DESC LIMIT 50"
        answer_prefix = f"Count by {col}"
    elif m := _AGG_BY_RE.search(ql):
        # "aggregate by currency" → auto-detect a numeric column, group by the named col
        grp_col = _resolve_column(m.group(1), avail)
        num_col = _pick_num_col(avail)
        if num_col:
            sql = (
                f"SELECT \"{grp_col}\", COUNT(*) AS row_count, "
                f"ROUND(SUM(TRY_CAST(\"{num_col}\" AS DOUBLE)), 2) AS sum_{num_col}, "
                f"ROUND(AVG(TRY_CAST(\"{num_col}\" AS DOUBLE)), 2) AS avg_{num_col}, "
                f"ROUND(MIN(TRY_CAST(\"{num_col}\" AS DOUBLE)), 2) AS min_{num_col}, "
                f"ROUND(MAX(TRY_CAST(\"{num_col}\" AS DOUBLE)), 2) AS max_{num_col} "
                f"FROM read_parquet('{sp}') "
                f"GROUP BY \"{grp_col}\" ORDER BY sum_{num_col} DESC NULLS LAST LIMIT 50"
            )
            answer_prefix = f"Aggregate stats of {num_col} by {grp_col}"
        else:
            sql = (
                f"SELECT \"{grp_col}\", COUNT(*) AS row_count "
                f"FROM read_parquet('{sp}') "
                f"GROUP BY \"{grp_col}\" ORDER BY row_count DESC LIMIT 50"
            )
            answer_prefix = f"Count by {grp_col} (no numeric column detected)"
    elif m := _FILTER_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        val = m.group(2).strip()
        sql = f"SELECT * FROM read_parquet('{sp}') WHERE LOWER(CAST(\"{col}\" AS VARCHAR)) = LOWER('{val.replace(chr(39), chr(39)+chr(39))}') LIMIT 50"
        answer_prefix = f"Rows where {col} = {val}"

    # ── Trend / time-series ───────────────────────────────────────────────────
    if sql is None:
        return None
    return sql, answer_prefix

def _dq_trend(ql, avail, sp):
    """Decide a time-series question, choosing the date column, the value
    column and the granularity; falls back to a sample when the result
    has no date column."""
    sql = None
    answer_prefix = ""
    if _TREND_RE.search(ql):
        date_col = _pick_date_col(avail)
        num_col  = _pick_num_col(avail)
        # Allow user to specify columns: "trend of amount by month"
        if m2 := _re.search(r'trend\s+(?:of\s+)?(\w+)', ql):
            num_col = _resolve_column(m2.group(1), avail) or num_col
        if m2 := _re.search(r'by\s+(month|week|day|year|quarter)', ql, _re.I):
            granularity = m2.group(1).lower()
        else:
            granularity = "month"
        trunc_map = {"day": "day", "week": "week", "month": "month",
                     "quarter": "quarter", "year": "year"}
        gran = trunc_map.get(granularity, "month")
        if date_col and num_col:
            sql = (
                f"SELECT DATE_TRUNC('{gran}', TRY_CAST(\"{date_col}\" AS DATE)) AS period, "
                f"COUNT(*) AS row_count, "
                f"ROUND(SUM(TRY_CAST(\"{num_col}\" AS DOUBLE)), 2) AS total_{num_col}, "
                f"ROUND(AVG(TRY_CAST(\"{num_col}\" AS DOUBLE)), 2) AS avg_{num_col} "
                f"FROM read_parquet('{sp}') "
                f"WHERE \"{date_col}\" IS NOT NULL "
                f"GROUP BY 1 ORDER BY 1"
            )
            answer_prefix = f"Trend of {num_col} by {gran} (via {date_col})"
        elif date_col:
            sql = (
                f"SELECT DATE_TRUNC('{gran}', TRY_CAST(\"{date_col}\" AS DATE)) AS period, "
                f"COUNT(*) AS row_count "
                f"FROM read_parquet('{sp}') "
                f"WHERE \"{date_col}\" IS NOT NULL "
                f"GROUP BY 1 ORDER BY 1"
            )
            answer_prefix = f"Row count by {gran}"
        else:
            sql = f"SELECT * FROM read_parquet('{sp}') LIMIT 10"
            answer_prefix = "No date column detected — showing sample"

    # ── Summary / profile ─────────────────────────────────────────────────────
    if sql is None:
        return None
    return sql, answer_prefix

def _dq_summary_or_outliers(ql, avail, sp):
    """Decide a whole-dataset summary (DuckDB SUMMARIZE) or a >2-sigma
    outlier scan."""
    sql = None
    answer_prefix = ""
    if _SUMMARY_RE.search(ql):
        # DuckDB SUMMARIZE gives min/max/avg/std/q25/q50/q75/null% per column
        sql = f"SUMMARIZE SELECT * FROM read_parquet('{sp}')"
        answer_prefix = "Dataset summary (all columns)"

    # ── Outlier / extreme values ──────────────────────────────────────────────
    elif _OUTLIER_RE.search(ql):
        num_col = _pick_num_col(avail)
        if m2 := _re.search(r'outlier[s]?\s+(?:in\s+)?(\w+)', ql):
            num_col = _resolve_column(m2.group(1), avail) or num_col
        if num_col:
            sql = (
                f"WITH stats AS ("
                f"  SELECT AVG(TRY_CAST(\"{num_col}\" AS DOUBLE)) AS mu, "
                f"         STDDEV(TRY_CAST(\"{num_col}\" AS DOUBLE)) AS sigma "
                f"  FROM read_parquet('{sp}')"
                f") "
                f"SELECT * FROM read_parquet('{sp}'), stats "
                f"WHERE ABS(TRY_CAST(\"{num_col}\" AS DOUBLE) - mu) > 2 * sigma "
                f"ORDER BY ABS(TRY_CAST(\"{num_col}\" AS DOUBLE) - mu) DESC NULLS LAST "
                f"LIMIT 50"
            )
            answer_prefix = f"Outliers in {num_col} (>2σ from mean)"
        else:
            sql = f"SELECT * FROM read_parquet('{sp}') LIMIT 10"
            answer_prefix = "No numeric column detected — showing sample"

    # ── Std dev / variance ───────────────────────────────────────────────────
    if sql is None:
        return None
    return sql, answer_prefix

def _dq_spread_or_correlation(ql, avail, sp):
    """Decide a std-dev/variance question or a two-column correlation."""
    sql = None
    answer_prefix = ""
    if m := _STDDEV_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        label = "variance" if "variance" in ql else "std_dev"
        fn = "VARIANCE" if "variance" in ql else "STDDEV"
        sql = (
            f"SELECT ROUND({fn}(TRY_CAST(\"{col}\" AS DOUBLE)), 4) AS {label}_{col}, "
            f"ROUND(AVG(TRY_CAST(\"{col}\" AS DOUBLE)), 4) AS mean_{col}, "
            f"ROUND(MIN(TRY_CAST(\"{col}\" AS DOUBLE)), 4) AS min_{col}, "
            f"ROUND(MAX(TRY_CAST(\"{col}\" AS DOUBLE)), 4) AS max_{col} "
            f"FROM read_parquet('{sp}')"
        )
        answer_prefix = f"{label.replace('_',' ').title()} of {col}"

    # ── Correlation ──────────────────────────────────────────────────────────
    elif m := _CORR_RE.search(ql):
        colA = _resolve_column(m.group(1), avail)
        colB = _resolve_column(m.group(2), avail)
        sql = (
            f"SELECT ROUND(CORR(TRY_CAST(\"{colA}\" AS DOUBLE), TRY_CAST(\"{colB}\" AS DOUBLE)), 4) AS correlation, "
            f"COUNT(*) AS n FROM read_parquet('{sp}')"
        )
        answer_prefix = f"Correlation between {colA} and {colB}"

    # ── Null checks ──────────────────────────────────────────────────────────
    if sql is None:
        return None
    return sql, answer_prefix

def _dq_null_question(ql, avail, sp):
    """Decide a null question: nulls per column, nulls in one column, or
    rows carrying any null at all."""
    sql = None
    answer_prefix = ""
    if _NULLCOL_RE.search(ql):
        # Build a query counting nulls per column dynamically
        if avail:
            null_exprs = ", ".join(
                f"SUM(CASE WHEN \"{c}\" IS NULL THEN 1 ELSE 0 END) AS null_{c}" for c in avail[:30]
            )
            sql = f"SELECT {null_exprs} FROM read_parquet('{sp}')"
            answer_prefix = "Null count per column"
        else:
            sql = f"SELECT * FROM read_parquet('{sp}') LIMIT 5"
            answer_prefix = "Sample (no column info)"
    elif m := _NULLIN_RE.search(ql):
        col = _resolve_column(m.group(1) or m.group(2), avail)
        sql = f"SELECT * FROM read_parquet('{sp}') WHERE \"{col}\" IS NULL LIMIT 50"
        answer_prefix = f"Rows where {col} is null"
    elif _ANYNULL_RE.search(ql):
        if avail:
            cond = " OR ".join(f"\"{c}\" IS NULL" for c in avail[:30])
            sql = f"SELECT * FROM read_parquet('{sp}') WHERE {cond} LIMIT 50"
            answer_prefix = "Rows with any null value"
        else:
            sql = f"SELECT * FROM read_parquet('{sp}') LIMIT 10"
            answer_prefix = "Sample rows"

    # ── Duplicates ───────────────────────────────────────────────────────────
    if sql is None:
        return None
    return sql, answer_prefix

def _dq_duplicates_or_sample(ql, avail, sp):
    """Decide a duplicate-value scan or a random row sample."""
    sql = None
    answer_prefix = ""
    if m := _DUPES_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        sql = (
            f"SELECT \"{col}\", COUNT(*) AS occurrences "
            f"FROM read_parquet('{sp}') "
            f"GROUP BY \"{col}\" HAVING COUNT(*) > 1 "
            f"ORDER BY occurrences DESC LIMIT 50"
        )
        answer_prefix = f"Duplicate values in {col}"

    # ── Random sample ────────────────────────────────────────────────────────
    elif m := _SAMPLE_RE.search(ql):
        n = min(int(m.group(1)), 500)
        sql = f"SELECT * FROM read_parquet('{sp}') USING SAMPLE {n}"
        answer_prefix = f"Random sample of {n} rows"

    # ── Pivot ────────────────────────────────────────────────────────────────
    if sql is None:
        return None
    return sql, answer_prefix

def _dq_pivot_or_frequency(ql, avail, sp):
    """Decide a pivot (rendered as a GROUP BY so no schema is needed up
    front) or a frequency distribution / most-common-values question."""
    sql = None
    answer_prefix = ""
    if m := _PIVOT_RE.search(ql):
        val_col = _resolve_column(m.group(1), avail)
        grp_col = _resolve_column(m.group(2), avail)
        # Use GROUP BY aggregation (works for any schema without knowing pivot values upfront)
        sql = (
            f"SELECT \"{grp_col}\", "
            f"COUNT(*) AS row_count, "
            f"ROUND(SUM(TRY_CAST(\"{val_col}\" AS DOUBLE)), 2) AS sum_{val_col}, "
            f"ROUND(AVG(TRY_CAST(\"{val_col}\" AS DOUBLE)), 2) AS avg_{val_col} "
            f"FROM read_parquet('{sp}') "
            f"GROUP BY \"{grp_col}\" ORDER BY sum_{val_col} DESC NULLS LAST LIMIT 50"
        )
        answer_prefix = f"Pivot of {val_col} by {grp_col}"

    # ── Frequency distribution / most common ─────────────────────────────────
    elif m := (_FREQDIST_RE.search(ql) or _MOSTCOMMON_RE.search(ql)):
        col = _resolve_column(m.group(1), avail)
        total_expr = "COUNT(*) OVER ()"
        sql = (
            f"SELECT \"{col}\", COUNT(*) AS frequency, "
            f"ROUND(100.0 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct "
            f"FROM read_parquet('{sp}') "
            f"GROUP BY \"{col}\" ORDER BY frequency DESC LIMIT 30"
        )
        answer_prefix = f"Frequency distribution of {col}"

    # ── Running total / cumulative sum ───────────────────────────────────────
    if sql is None:
        return None
    return sql, answer_prefix

def _dq_running_total(ql, avail, sp):
    """Decide a running-total question, ordering by the named column, else
    a date column, else row order."""
    sql = None
    answer_prefix = ""
    if m := _RUNNING_RE.search(ql):
        val_col  = _resolve_column(m.group(1), avail)
        sort_raw = m.group(2)
        sort_col = _resolve_column(sort_raw, avail) if sort_raw else (_pick_date_col(avail) or None)
        if sort_col:
            sql = (
                f"WITH t AS (SELECT *, ROW_NUMBER() OVER () AS _rn FROM read_parquet('{sp}')) "
                f"SELECT \"{sort_col}\", \"{val_col}\", "
                f"ROUND(SUM(TRY_CAST(\"{val_col}\" AS DOUBLE)) OVER (ORDER BY \"{sort_col}\" ROWS UNBOUNDED PRECEDING), 2) "
                f"AS cumulative_{val_col} FROM t ORDER BY \"{sort_col}\" LIMIT 200"
            )
            answer_prefix = f"Running total of {val_col} by {sort_col}"
        else:
            sql = (
                f"WITH t AS (SELECT ROW_NUMBER() OVER () AS row_num, \"{val_col}\" FROM read_parquet('{sp}')) "
                f"SELECT row_num, \"{val_col}\", "
                f"ROUND(SUM(TRY_CAST(\"{val_col}\" AS DOUBLE)) OVER (ORDER BY row_num ROWS UNBOUNDED PRECEDING), 2) "
                f"AS cumulative_{val_col} FROM t LIMIT 200"
            )
            answer_prefix = f"Running total of {val_col} (row order)"

    # ── Date-relative filters ─────────────────────────────────────────────────
    if sql is None:
        return None
    return sql, answer_prefix

def _dq_date_window_clause(ql, date_col):
    """Decide WHICH date window the question named, as (where, label).

    The chain is ordered, and the trailing else IS "last quarter" -- the
    caller has already established that one of the eight patterns matched,
    so there is no "no window" outcome to fall through to.
    """
    if _YTD_RE.search(ql):
        where  = f"TRY_CAST(\"{date_col}\" AS DATE) >= DATE_TRUNC('year', CURRENT_DATE)"
        label  = "Year-to-date"
    elif _MTD_RE.search(ql):
        where  = f"TRY_CAST(\"{date_col}\" AS DATE) >= DATE_TRUNC('month', CURRENT_DATE)"
        label  = "Month-to-date"
    elif _LASTMONTH_RE.search(ql):
        where  = (f"TRY_CAST(\"{date_col}\" AS DATE) >= DATE_TRUNC('month', CURRENT_DATE - INTERVAL '1 month') "
                  f"AND TRY_CAST(\"{date_col}\" AS DATE) < DATE_TRUNC('month', CURRENT_DATE)")
        label  = "Last month"
    elif _LAST7_RE.search(ql):
        where  = f"TRY_CAST(\"{date_col}\" AS DATE) >= CURRENT_DATE - INTERVAL '7 days'"
        label  = "Last 7 days"
    elif _LAST30_RE.search(ql):
        where  = f"TRY_CAST(\"{date_col}\" AS DATE) >= CURRENT_DATE - INTERVAL '30 days'"
        label  = "Last 30 days"
    elif _LAST90_RE.search(ql):
        where  = f"TRY_CAST(\"{date_col}\" AS DATE) >= CURRENT_DATE - INTERVAL '90 days'"
        label  = "Last 90 days"
    elif _THISQUARTER_RE.search(ql):
        where  = f"TRY_CAST(\"{date_col}\" AS DATE) >= DATE_TRUNC('quarter', CURRENT_DATE)"
        label  = "This quarter"
    else:  # last quarter
        where  = (f"TRY_CAST(\"{date_col}\" AS DATE) >= DATE_TRUNC('quarter', CURRENT_DATE - INTERVAL '3 months') "
                  f"AND TRY_CAST(\"{date_col}\" AS DATE) < DATE_TRUNC('quarter', CURRENT_DATE)")
        label  = "Last quarter"
    return where, label


def _dq_date_window(ql, avail, sp):
    """Decide a date-relative row filter (YTD / MTD / last N days / quarter).

    Refuses with a message when the result carries no date column: a date
    filter that cannot be rendered must never be dropped, because dropping
    it returns MORE rows than the question asked for.
    """
    # ── Date-relative filters ─────────────────────────────────────────────────
    if not (_YTD_RE.search(ql) or _MTD_RE.search(ql) or _LASTMONTH_RE.search(ql) or
            _LAST7_RE.search(ql) or _LAST30_RE.search(ql) or _LAST90_RE.search(ql) or
            _LASTQUARTER_RE.search(ql) or _THISQUARTER_RE.search(ql)):
        return None
    date_col = _pick_date_col(avail)
    if not date_col:
        return {"found": False, "message": "No date column detected in the current result. "
                "Date filters need a column whose name contains date, time, created, posted, etc.",
                "sql": None}
    where, label = _dq_date_window_clause(ql, date_col)
    sql = f"SELECT * FROM read_parquet('{sp}') WHERE {where} LIMIT 500"
    answer_prefix = f"{label} rows (filtered by {date_col})"
    return sql, answer_prefix

def _dq_sort_or_total_count(ql, avail, sp):
    """Decide a sort-by-column question or the bare total row count."""
    sql = None
    answer_prefix = ""
    # ── Sort by column ────────────────────────────────────────────────────────
    if m := _SORTBY_RE.search(ql):
        col = _resolve_column(m.group(1), avail)
        direction = "ASC" if (m.group(2) or "desc").lower().startswith("asc") else "DESC"
        sql = f"SELECT * FROM read_parquet('{sp}') ORDER BY \"{col}\" {direction} NULLS LAST LIMIT 100"
        answer_prefix = f"Sorted by {col} {direction.lower()}"

    elif _re.search(r'\bcount\b', ql):
        sql = f"SELECT COUNT(*) AS total_rows FROM read_parquet('{sp}')"
        answer_prefix = "Total row count"

    # ── Smart fallback: detect column names in prompt → auto-aggregate ─────
    if sql is None:
        return None
    return sql, answer_prefix

def _dq_columns_named_in_prompt(ql, avail):
    """Decide which result columns the question mentions, by literal
    substring first and then by resolving each non-stop word."""
    # Try to find any column name mentioned in the user prompt
    _matched_cols = []
    for _c in avail:
        _c_norm = _c.lower().replace("_", " ")
        if _c.lower() in ql or _c_norm in ql:
            _matched_cols.append(_c)
    # Also try resolving individual words (2+ chars, not stop words)
    _stop = {"the", "a", "an", "in", "from", "for", "to", "of", "all", "each",
             "per", "and", "or", "my", "by", "on", "is", "it", "be", "do",
             "show", "me", "get", "what", "how", "this", "that", "with", "can"}
    for _word in ql.split():
        if len(_word) > 2 and _word not in _stop:
            _resolved = _resolve_column(_word, avail)
            if _resolved != _word and _resolved not in _matched_cols:
                _matched_cols.append(_resolved)
    return _matched_cols


def _dq_column_name_fallback(ql, avail, sp):
    """Last resort: auto-aggregate whatever columns the question named.

    Returns None -- NOT a sample query -- when nothing is recognised, so
    the caller's own "sample of N rows" default stays the single place
    that decides what an unrecognised question answers with.
    """
    sql = None
    answer_prefix = ""
    # ── Smart fallback: detect column names in prompt → auto-aggregate ─────
    if not avail:
        return None
    _matched_cols = _dq_columns_named_in_prompt(ql, avail)
    if not _matched_cols:
        return None
    # Separate into numeric-looking and categorical
    _num_matched = [c for c in _matched_cols if _NUM_COL_PATTERNS.search(c)]
    _cat_matched = [c for c in _matched_cols if c not in _num_matched]
    if _num_matched and _cat_matched:
        # "currency amount" → SUM(amount) GROUP BY currency
        nc = _num_matched[0]
        gc = _cat_matched[0]
        sql = (
            f"SELECT \"{gc}\", COUNT(*) AS row_count, "
            f"ROUND(SUM(TRY_CAST(\"{nc}\" AS DOUBLE)), 2) AS sum_{nc}, "
            f"ROUND(AVG(TRY_CAST(\"{nc}\" AS DOUBLE)), 2) AS avg_{nc} "
            f"FROM read_parquet('{sp}') "
            f"GROUP BY \"{gc}\" ORDER BY sum_{nc} DESC NULLS LAST LIMIT 50"
        )
        answer_prefix = f"Auto-detected: aggregate {nc} by {gc}"
    elif _num_matched:
        nc = _num_matched[0]
        sql = (
            f"SELECT ROUND(SUM(TRY_CAST(\"{nc}\" AS DOUBLE)), 2) AS sum_{nc}, "
            f"ROUND(AVG(TRY_CAST(\"{nc}\" AS DOUBLE)), 4) AS avg_{nc}, "
            f"ROUND(MIN(TRY_CAST(\"{nc}\" AS DOUBLE)), 2) AS min_{nc}, "
            f"ROUND(MAX(TRY_CAST(\"{nc}\" AS DOUBLE)), 2) AS max_{nc}, "
            f"COUNT(*) AS row_count "
            f"FROM read_parquet('{sp}')"
        )
        answer_prefix = f"Auto-detected: stats for {nc}"
    elif _cat_matched:
        gc = _cat_matched[0]
        sql = (
            f"SELECT \"{gc}\", COUNT(*) AS row_count "
            f"FROM read_parquet('{sp}') "
            f"GROUP BY \"{gc}\" ORDER BY row_count DESC LIMIT 50"
        )
        answer_prefix = f"Auto-detected: count by {gc}"
    if sql is None:
        return None
    return sql, answer_prefix


def _dq_match(ql, avail, sp):
    """Decide what SQL a natural-language question becomes, IN PRIORITY ORDER.

    The tuple below IS the priority: each matcher answers only for the
    patterns it owns and returns None otherwise, so the first one that
    recognises the question wins -- exactly as the single if/elif chain
    this replaced did.  REORDERING IT CHANGES ANSWERS: "sum of X by Y" is
    also a match for "sum of X", which is why the grouped form is first.

    Returns ``(sql, answer_prefix)``; ``(None, "")`` when nothing matched
    (the caller then samples rows); or a ready response ``dict`` when a
    matcher refuses the question outright.
    """
    for matcher in (
            _dq_grouped_aggregate,
            _dq_scalar_aggregate,
            _dq_ranking_or_distinct,
            _dq_count_or_filter,
            _dq_trend,
            _dq_summary_or_outliers,
            _dq_spread_or_correlation,
            _dq_null_question,
            _dq_duplicates_or_sample,
            _dq_pivot_or_frequency,
            _dq_running_total,
            _dq_date_window,
            _dq_sort_or_total_count,
            _dq_column_name_fallback,
    ):
        outcome = matcher(ql, avail, sp)
        if outcome is not None:
            return outcome
    return None, ""


def _json_safe_records(df):
    """Replace NaN/Inf with None so the rows survive JSON encoding.

    DuckDB SUMMARIZE returns NaN for the numeric stats of non-numeric
    columns, and NaN is not JSON-serializable -- the whole response used
    to fail, not just the cell.
    """
    # Sanitize NaN/Inf — not JSON-serializable (SUMMARIZE returns them for non-numeric cols)
    import math as _math
    rows = []
    for record in df.to_dict(orient="records"):
        clean = {}
        for k, v in record.items():
            if isinstance(v, float) and (_math.isnan(v) or _math.isinf(v)):
                clean[k] = None
            else:
                clean[k] = v
        rows.append(clean)
    return rows


@router.post("/api/suggest/data-query")
def data_query(body: DataQueryRequest, _user: dict = Depends(get_current_user)):
    """Run a natural-language aggregate query against an execution output or downloaded file.
    2026-06-03 — converted async→sync; only await was _adb wrapping the
    session, now plain sync (FastAPI threadpool dispatches sync endpoints)."""
    output_file, _err = _resolve_owned_result_file(
        body.execution_id, body.file_id, _user)
    if _err:
        return {"found": False, "message": _err}

    q   = body.question.strip()
    ql  = q.lower()
    sp  = output_file.replace("'", "''")   # safe path for DuckDB string literal

    sql = None
    answer_prefix = ""

    # Known column names for fuzzy resolution.  SANITISED ONCE, at the only
    # entry point for caller-supplied identifiers: every branch below
    # interpolates these names into double-quoted SQL identifiers, and a
    # column name containing a double-quote would otherwise break out of the
    # quoting into arbitrary DuckDB SQL (local file reads included).
    # Doubling the quote here makes every downstream "{col}" interpolation a
    # valid, inert identifier -- one chokepoint instead of ~30 escape sites.
    # THE escape for the client-supplied column list.  ``body.columns`` is
    # request data and every element can reach a DuckDB quoted identifier
    # through ``_resolve_column`` (see its docstring for the full
    # invariant), so the doubling happens HERE, once, at the boundary --
    # not at the ~15 interpolation sites, where one missed site is a hole.
    avail = [str(c).replace('"', '""') for c in (body.columns or [])]

    # ── Check grouped agg FIRST so "sum of X by Y" beats plain "sum of X" ──────
    outcome = _dq_match(ql, avail, sp)
    if isinstance(outcome, dict):
        return outcome              # a matcher refused, with its reason
    sql, answer_prefix = outcome
    if not sql:
        limit = 10
        if m2 := _FIRSTN_RE.search(ql):
            limit = min(int(m2.group(1)), 100)
        sql = f"SELECT * FROM read_parquet('{sp}') LIMIT {limit}"
        answer_prefix = f"Sample of {limit} rows"

    try:
        from core.duckdb_factory import duckdb_connection
        with duckdb_connection() as con:
            df = con.execute(sql).fetchdf()
            columns = list(df.columns)
            rows = _json_safe_records(df)
        return {
            "found": True,
            "answer": answer_prefix,
            "sql": sql,
            "columns": columns,
            "rows": rows[:100],
            "row_count": len(rows),
        }
    except Exception as exc:
        logger.warning("data-query failed: %s | sql=%s", exc, sql)
        return {"found": False, "message": f"Query failed: {exc}", "sql": sql}


# ── NL Feedback (Learning Loop) ───────────────────────────────────────────────

class NLFeedbackRequest(BaseModel):
    question: str
    sql: str
    connection_type: str = "duckdb"
    tables_hint: Optional[str] = None
    rating: int = 1   # 1 = thumbs-up, -1 = thumbs-down


@router.post("/api/suggest/feedback")
async def save_nl_feedback(body: NLFeedbackRequest, _user: dict = Depends(get_current_user)):
    """Save user thumbs-up/down rating for a NL→SQL pair (learning loop)."""
    db = _require_db()
    await _adb(db.save_nl_feedback, 
        question=body.question,
        sql=body.sql,
        connection_type=body.connection_type,
        tables_hint=body.tables_hint,
        rating=body.rating,
    )
    return {"saved": True, "rating": body.rating}


# ── Suggestion Corrections (Smart Agg + Join Learning) ────────────────────────

class SuggestionCorrectionRequest(BaseModel):
    correction_type: str            # "agg" | "join" | "chart" | "pivot"
    context_key: str                # column name (agg), "left||right" (join), preset key (chart/pivot)
    corrected_value: str            # function (agg), JSON (join), "1"/"-1" rating (chart/pivot)
    original_value: Optional[str] = None
    context_extra: Optional[str] = None


@router.post("/api/suggest/correction")
async def save_suggestion_correction(
    body: SuggestionCorrectionRequest,
    _user: dict = Depends(get_current_user),
):
    """Save user correction for aggregation function or join columns."""
    from core import config as _cfg
    if not _cfg.suggestion_corrections.enabled:
        return {"saved": False, "reason": "suggestion_corrections disabled"}
    if body.correction_type not in ("agg", "join", "chart", "pivot"):
        raise HTTPException(status_code=422, detail="correction_type must be 'agg', 'join', 'chart', or 'pivot'")
    db = _require_db()
    username = (_user or {}).get("username")
    result = await _adb(db.save_suggestion_correction, 
        correction_type=body.correction_type,
        context_key=body.context_key,
        corrected_value=body.corrected_value,
        original_value=body.original_value,
        context_extra=body.context_extra,
        username=username,
    )
    return {"saved": True, "correction": result}


@router.get("/api/suggest/corrections/agg")
async def get_agg_corrections(_user: dict = Depends(get_current_user)):
    """Return all aggregation corrections for client-side cache."""
    db = _require_db()
    corrections = await _adb(db.get_all_agg_corrections)
    return {"corrections": corrections}


@router.get("/api/suggest/corrections/join")
async def get_join_corrections(_user: dict = Depends(get_current_user)):
    """Return all join corrections for client-side cache."""
    db = _require_db()
    corrections = await _adb(db.get_all_join_corrections)
    return {"corrections": corrections}


@router.get("/api/suggest/corrections/chart")
async def get_chart_corrections(
    connection_id: Optional[int] = None,
    _user: dict = Depends(get_current_user),
):
    """Return all chart preset feedback for client-side filtering/reordering."""
    db = _require_db()
    corrections = await _adb(db.get_chart_feedback, connection_id)
    return {"corrections": corrections}


@router.get("/api/suggest/corrections/pivot")
async def get_pivot_corrections(
    connection_id: Optional[int] = None,
    _user: dict = Depends(get_current_user),
):
    """Return all pivot preset feedback for client-side filtering/reordering."""
    db = _require_db()
    corrections = await _adb(db.get_pivot_feedback, connection_id)
    return {"corrections": corrections}


def _correction_join_conditions(correction):
    """Normalise a stored join CORRECTION row into join conditions, or None.

    Corrections store {leftColumn, rightColumn}; usage stats store
    {left_on, right_on}.  Unparseable JSON -- and a row with no
    ``corrected_value`` at all -- yields None: one bad row must not lose the
    suggestions either side of it.  Taking the ROW rather than the value is
    deliberate, so the subscript stays inside this try.
    """
    import json as _json
    try:
        raw_conds = _json.loads(correction["corrected_value"])
        # Normalize: corrections store {leftColumn, rightColumn}; usage stores {left_on, right_on}
        return [{"left_on": cc.get("leftColumn") or cc.get("left_on", ""),
                 "right_on": cc.get("rightColumn") or cc.get("right_on", "")}
                for cc in raw_conds]
    except Exception:
        return None


def _learned_join_suggestions(corrections, pair_key, seen_keys):
    """Pick the learned join conditions for this table pair, skipping
    dismissed ones.  Highest priority, so it seeds ``seen_keys``."""
    import json as _json
    out = []
    # 1. Learned corrections (highest priority) — exclude dismissed
    for c in corrections:
        if c.get("context_key", "").lower() != pair_key:
            continue
        if c.get("corrected_value") == "__dismissed__":
            continue
        conditions = _correction_join_conditions(c)
        if conditions is None:
            continue
        cond_key = _json.dumps(conditions, sort_keys=True)
        if cond_key not in seen_keys:
            seen_keys.add(cond_key)
            out.append({
                "conditions": conditions,
                "source": "learned",
                "use_count": c.get("use_count", 1),
            })
    return out


def _popular_join_suggestions(usage, seen_keys):
    """Pick join conditions by USAGE frequency, minus anything already learned."""
    import json as _json
    out = []
    # 2. Usage frequency
    for u in usage:
        try:
            data = _json.loads(u.get("table_name", "{}"))
            conditions = [{"left_on": _lk, "right_on": r}
                          for _lk, r in zip(data.get("left_on", []), data.get("right_on", []))]
        except Exception:
            continue
        cond_key = _json.dumps(conditions, sort_keys=True)
        if cond_key not in seen_keys:
            seen_keys.add(cond_key)
            out.append({
                "conditions": conditions,
                "source": "popular",
                "use_count": u.get("use_count", 1),
            })
    return out


@router.get("/api/suggest/popular-joins")
async def get_popular_joins(
    left_table: str,
    right_table: str,
    connection_id: Optional[int] = None,
    limit: int = 5,
    _user: dict = Depends(get_current_user),
):
    """Return most-used join conditions for a table pair (corrections + usage stats)."""
    db = _require_db()
    pair_key = "||".join(sorted([left_table.lower(), right_table.lower()]))

    suggestions = []
    seen_keys = set()

    corrections = await _adb(db.get_all_join_corrections, limit=50)
    suggestions.extend(
        _learned_join_suggestions(corrections, pair_key, seen_keys))

    usage = await _adb(db.get_popular_join_pairs, pair_key, connection_id, limit=limit)
    suggestions.extend(_popular_join_suggestions(usage, seen_keys))

    return {"suggestions": suggestions[:limit], "pair_key": pair_key}


@router.get("/api/suggest/popular-aggs")
async def get_popular_aggs(
    table: str = "",
    connection_id: Optional[int] = None,
    limit: int = 10,
    _user: dict = Depends(get_current_user),
):
    """Return most-used aggregation combos for a table (corrections + usage stats)."""
    import re as _re
    db = _require_db()
    suggestions = []
    seen_keys = set()

    # 1. Learned corrections (highest priority) — exclude dismissed
    corrections = await _adb(db.get_all_agg_corrections, limit=100)
    for c in corrections:
        if c.get("corrected_value") == "__dismissed__":
            continue
        col_name = c.get("context_key", "")
        val = c.get("corrected_value", "SUM")
        distinct = False
        fn = val
        if val == "COUNT_DISTINCT":
            fn, distinct = "COUNT", True
        combo_key = f"{fn}({'DISTINCT ' if distinct else ''}{col_name})"
        if combo_key not in seen_keys:
            seen_keys.add(combo_key)
            suggestions.append({
                "combo": f"{fn}({col_name})",
                "column": col_name,
                "function": fn,
                "distinct": distinct,
                "source": "learned",
                "use_count": c.get("use_count", 1),
            })

    # 2. Usage frequency
    usage = await _adb(db.get_popular_agg_combos, table_name=table or None,
                                       connection_id=connection_id, limit=limit)
    for u in usage:
        obj = u.get("object_name", "")
        m = _re.match(r'^(\w+)\((.+)\)$', obj)
        if not m:
            continue
        fn, col = m.group(1), m.group(2)
        combo_key = obj
        if combo_key not in seen_keys:
            seen_keys.add(combo_key)
            suggestions.append({
                "combo": obj,
                "column": col,
                "function": fn,
                "distinct": False,
                "source": "popular",
                "use_count": u.get("use_count", 1),
            })

    return {"suggestions": suggestions[:limit]}


@router.get("/api/nl-to-sql/examples")
async def nl_to_sql_examples(
    dataset_id: Optional[int] = None,
    _user: dict = Depends(get_current_user),
):
    """Return example prompts. When dataset_id provided, includes semantic + time intelligence examples."""
    from core import config as _cfg
    examples = [
        {"prompt": "top 10 customers by revenue",        "pattern": "top N by column"},
        {"prompt": "count orders",                        "pattern": "count rows"},
        {"prompt": "average salary by department",        "pattern": "average per group"},
        {"prompt": "total revenue by region",             "pattern": "sum per group"},
        {"prompt": "show all products",                   "pattern": "show all rows"},
        {"prompt": "orders where status is pending",      "pattern": "filter equals"},
        {"prompt": "distinct values of category in products", "pattern": "distinct values"},
        {"prompt": "min and max price in products",       "pattern": "min/max"},
        {"prompt": "orders grouped by status",            "pattern": "group by count"},
        {"prompt": "sales between 2026-01-01 and 2026-03-31", "pattern": "date range"},
        {"prompt": "recent 7 days of events",             "pattern": "recent rows"},
    ]
    # Phase 57 — time intelligence examples
    if _cfg.chatbot.time_intelligence_enabled:
        examples += [
            {"prompt": "YTD revenue by region",                    "pattern": "year-to-date"},
            {"prompt": "MTD sales by product",                     "pattern": "month-to-date"},
            {"prompt": "same period last year revenue by region",  "pattern": "SPLY comparison"},
            {"prompt": "revenue this month vs last month",         "pattern": "period-over-period"},
            {"prompt": "running total of revenue by date",         "pattern": "running total"},
            {"prompt": "percentage of total revenue by region",    "pattern": "percent of total"},
            {"prompt": "3 month moving average of sales",          "pattern": "moving average"},
            {"prompt": "month over month growth of revenue",       "pattern": "growth rate"},
            {"prompt": "rank customers by revenue",                "pattern": "rank"},
        ]
    # Phase 57 — dataset condition examples
    if dataset_id:
        ds = await _adb(_db_manager.get_dataset_full, dataset_id)
        if ds:
            for cond in (ds.get("conditions") or []):
                examples.append({
                    "prompt": f"show {cond.get('label') or cond['name']}",
                    "pattern": "pre-defined condition",
                    "condition_name": cond["name"],
                })
    return {"examples": examples}


@router.get("/api/suggest/chatbot-patterns")
async def chatbot_patterns(_user: dict = Depends(get_current_user)):
    """
    Return the full chatbot configuration:
    - Column classification patterns (numeric/category/date/id)
    - FAQ keyword→answer map
    - Business glossary (term→SQL fragment) for NL-to-SQL substitution
    All values are read from config.json under the 'chatbot' section.
    """
    from core import config as _cfg
    return {
        "numeric_patterns":  _cfg.chatbot.numeric_patterns,
        "category_patterns": _cfg.chatbot.category_patterns,
        "date_patterns":     _cfg.chatbot.date_patterns,
        "id_patterns":       _cfg.chatbot.id_patterns,
        "faq":               _cfg.chatbot.faq,
        "glossary":          _cfg.chatbot.glossary,
    }


# ── Phase 77 — Smart Predictions: Data Profile & Chart Recommendations ───────

class DataProfileRequest(BaseModel):
    execution_id: Optional[str] = None
    file_id: Optional[str] = None
    columns: List[str] = []


def _set_profile_statement_timeout(con):
    """Cap a profile query at 30s; older DuckDB builds have no such setting."""
    # Set query timeout (30 seconds) to prevent long-running profiles
    try:
        con.execute("SET statement_timeout='30s'")
    except Exception:
        pass  # older DuckDB versions may not support this


def _profile_type_from_data(con, qcol, sample_clause):
    """Decide a column's profile type from DuckDB's typeof() on one sampled row.

    Answers "unknown" for every uncertainty -- an unreadable column, an
    empty sample, or a type none of the three families claims.  Unknown is
    NOT categorical here; the caller treats them the same, but the reason
    differs.
    """
    # Detect from actual data type
    try:
        dt_rows = con.execute(
            f"SELECT typeof(\"{qcol}\") FROM ({sample_clause}) LIMIT 1"
        ).fetchall()
        raw_type = str(dt_rows[0][0]).upper() if dt_rows else ""
    except Exception:
        return "unknown"
    if any(t in raw_type for t in ("INT", "FLOAT", "DOUBLE", "DECIMAL", "NUMERIC", "BIGINT", "SMALLINT", "TINYINT")):
        return "numeric"
    if any(t in raw_type for t in ("DATE", "TIME", "TIMESTAMP", "INTERVAL")):
        return "temporal"
    if any(t in raw_type for t in ("VARCHAR", "TEXT", "BLOB", "ENUM")):
        return "categorical"
    return "unknown"


def _classify_profile_column(con, col_name, qcol, sample_clause):
    """Decide a column's profile type: by NAME pattern first, then by its
    actual data type.  Order matters -- the name patterns are the cheap
    answer and they are checked date, numeric, categorical."""
    # Classify column type using existing patterns
    if _DATE_COL_PATTERNS.search(col_name):
        return "temporal"
    if _NUM_COL_PATTERNS.search(col_name):
        return "numeric"
    if _CAT_COL_PATTERNS.search(col_name):
        return "categorical"
    return _profile_type_from_data(con, qcol, sample_clause)


def _clean_profile_number(v):
    """Drop NaN/Inf, which are not JSON-serializable, keeping everything else."""
    # Clean NaN/Inf values
    import math as _math
    if v is None:
        return None
    try:
        if _math.isnan(v) or _math.isinf(v):
            return None
    except (TypeError, ValueError):
        pass
    return v


def _iqr_outlier_count(con, qcol, sample_clause, p25, p75, iqr_multiplier):
    """Count rows outside the IQR fence.

    0 when the quartiles are unknown or the count itself fails -- this is
    an advisory number on a profile screen, so it must never fail the
    column it describes.
    """
    if p25 is None or p75 is None:
        return 0
    iqr = p75 - p25
    lower_bound = p25 - iqr_multiplier * iqr
    upper_bound = p75 + iqr_multiplier * iqr
    try:
        return con.execute(f"""
            SELECT COUNT(*) FROM ({sample_clause})
            WHERE TRY_CAST("{qcol}" AS DOUBLE) < {lower_bound}
               OR TRY_CAST("{qcol}" AS DOUBLE) > {upper_bound}
        """).fetchone()[0]
    except Exception:
        return 0


def _profile_numeric_column(con, qcol, sample_clause, iqr_multiplier):
    """Profile a numeric column: nulls, min/max/mean/median/stddev, quartiles
    and an IQR outlier count.  Returns (fields, nulls, null_pct)."""
    stats = con.execute(f"""
        SELECT
            COUNT(*) AS total,
            COUNT(*) - COUNT("{qcol}") AS nulls,
            MIN(TRY_CAST("{qcol}" AS DOUBLE)) AS min_val,
            MAX(TRY_CAST("{qcol}" AS DOUBLE)) AS max_val,
            ROUND(AVG(TRY_CAST("{qcol}" AS DOUBLE)), 4) AS mean_val,
            ROUND(MEDIAN(TRY_CAST("{qcol}" AS DOUBLE)), 4) AS median_val,
            ROUND(STDDEV_SAMP(TRY_CAST("{qcol}" AS DOUBLE)), 4) AS std_dev,
            ROUND(QUANTILE_CONT(TRY_CAST("{qcol}" AS DOUBLE), 0.25), 4) AS p25,
            ROUND(QUANTILE_CONT(TRY_CAST("{qcol}" AS DOUBLE), 0.75), 4) AS p75
        FROM ({sample_clause})
    """).fetchone()
    nulls = stats[1] or 0
    total = stats[0] or 1
    null_pct = round(nulls / total, 4) if total > 0 else 0
    p25 = stats[7]
    p75 = stats[8]
    outlier_count = _iqr_outlier_count(
        con, qcol, sample_clause, p25, p75, iqr_multiplier)

    _clean = _clean_profile_number
    return {
        "nulls": nulls, "null_pct": null_pct,
        "min_val": _clean(stats[2]), "max_val": _clean(stats[3]),
        "mean_val": _clean(stats[4]), "median_val": _clean(stats[5]),
        "std_dev": _clean(stats[6]), "p25": _clean(p25), "p75": _clean(p75),
        "outlier_count": outlier_count,
    }, nulls, null_pct


def _profile_temporal_column(con, qcol, sample_clause):
    """Profile a temporal column: nulls, date range and distinct months.
    Returns (fields, nulls, null_pct)."""
    stats = con.execute(f"""
        SELECT
            MIN(TRY_CAST("{qcol}" AS DATE)) AS min_date,
            MAX(TRY_CAST("{qcol}" AS DATE)) AS max_date,
            COUNT(DISTINCT DATE_TRUNC('month', TRY_CAST("{qcol}" AS DATE))) AS distinct_months,
            COUNT(*) - COUNT("{qcol}") AS nulls,
            COUNT(*) AS total
        FROM ({sample_clause})
    """).fetchone()
    nulls = stats[3] or 0
    total = stats[4] or 1
    null_pct = round(nulls / total, 4) if total > 0 else 0
    return {
        "nulls": nulls, "null_pct": null_pct,
        "min_date": str(stats[0]) if stats[0] else None,
        "max_date": str(stats[1]) if stats[1] else None,
        "distinct_months": stats[2] or 0,
    }, nulls, null_pct


def _profile_categorical_column(con, qcol, sample_clause, max_top_values):
    """Profile a categorical (or unknown-type) column: nulls, distinct count
    and the top values.  Returns (fields, nulls, null_pct)."""
    stats = con.execute(f"""
        SELECT COUNT(DISTINCT "{qcol}"), COUNT(*) - COUNT("{qcol}"), COUNT(*)
        FROM ({sample_clause})
    """).fetchone()
    distinct = stats[0] or 0
    nulls = stats[1] or 0
    total = stats[2] or 1
    null_pct = round(nulls / total, 4) if total > 0 else 0

    top_vals = con.execute(f"""
        SELECT "{qcol}" AS value, COUNT(*) AS count
        FROM ({sample_clause})
        WHERE "{qcol}" IS NOT NULL
        GROUP BY "{qcol}" ORDER BY count DESC LIMIT {max_top_values}
    """).fetchall()
    top_values = [{"value": str(r[0]), "count": r[1]} for r in top_vals]

    return {
        "nulls": nulls, "null_pct": null_pct,
        "distinct": distinct,
        "top_values": top_values,
    }, nulls, null_pct


def _profile_one_column(con, col_name, sample_clause, iqr_multiplier,
                        max_top_values):
    """Profile one column, recording a per-column error instead of failing
    the whole request.

    A column that errored contributes NOTHING to the dataset-level null
    totals -- its numbers were never computed, and 0 is a measurement.
    Returns (profile, nulls, null_pct).
    """
    qcol = col_name.replace('"', '""')
    col_type = _classify_profile_column(con, col_name, qcol, sample_clause)

    profile: Dict[str, Any] = {"name": col_name, "type": col_type}

    try:
        if col_type == "numeric":
            fields, nulls, null_pct = _profile_numeric_column(
                con, qcol, sample_clause, iqr_multiplier)
        elif col_type == "temporal":
            fields, nulls, null_pct = _profile_temporal_column(
                con, qcol, sample_clause)
        else:  # categorical / unknown
            fields, nulls, null_pct = _profile_categorical_column(
                con, qcol, sample_clause, max_top_values)
        profile.update(fields)
    except Exception as col_exc:
        logger.warning("data-profile: error profiling column %s: %s", col_name, col_exc)
        profile["error"] = str(col_exc)
        return profile, 0, 0
    return profile, nulls, null_pct


def _duplicate_row_estimate(con, sample_clause, total_rows, sample_limit):
    """Estimate duplicate rows within the sample; 0 when the count fails."""
    # ── Duplicate row count (approximate) ──────────────────────────────
    try:
        distinct_rows = con.execute(
            f"SELECT COUNT(*) FROM (SELECT DISTINCT * FROM ({sample_clause}))"
        ).fetchone()[0]
    except Exception:
        return 0
    sample_count = min(total_rows, sample_limit)
    return max(0, sample_count - distinct_rows)


def _profile_result_file(con, sp, body, sample_limit, max_top_values,
                         iqr_multiplier):
    """Build the whole profile payload for one result file.

    Columns the caller did not name are DISCOVERED by DESCRIBE, and a file
    bigger than the sample limit is profiled on a DuckDB sample -- every
    number below is therefore about the sample, not the file.
    """
    _set_profile_statement_timeout(con)

    # ── Get total row count ──────────────────────────────────────────
    total_rows = con.execute(
        f"SELECT COUNT(*) FROM read_parquet('{sp}')"
    ).fetchone()[0]

    # ── Discover columns via DESCRIBE if not provided ────────────────
    if not body.columns:
        desc = con.execute(
            f"DESCRIBE SELECT * FROM read_parquet('{sp}') LIMIT 0"
        ).fetchall()
        body.columns = [r[0] for r in desc]

    # ── Use a CTE with optional LIMIT for large files ────────────────
    sample_clause = f"SELECT * FROM read_parquet('{sp}')"
    if total_rows > sample_limit:
        sample_clause = f"SELECT * FROM read_parquet('{sp}') USING SAMPLE {sample_limit}"

    col_profiles = []
    total_nulls = 0
    high_null_cols = []

    for col_name in body.columns:
        profile, nulls, null_pct = _profile_one_column(
            con, col_name, sample_clause, iqr_multiplier, max_top_values)
        total_nulls += nulls
        if null_pct > 0.5:
            high_null_cols.append(col_name)
        col_profiles.append(profile)

    duplicate_rows = _duplicate_row_estimate(
        con, sample_clause, total_rows, sample_limit)

    return {
        "row_count": total_rows,
        "columns": col_profiles,
        "data_quality": {
            "total_nulls": total_nulls,
            "duplicate_rows": duplicate_rows,
            "columns_with_high_nulls": high_null_cols,
        },
    }


@router.post("/api/suggest/data-profile")
async def data_profile(body: DataProfileRequest, _user: dict = Depends(get_current_user)):
    """Statistical profiling of result data — outliers, nulls, distributions, data quality."""
    import os as _os
    from core.config import smart_predictions as _sp_cfg

    if not _sp_cfg.enabled:
        raise HTTPException(status_code=403, detail="Smart predictions feature is disabled.")

    db = _require_db()

    # ── Resolve output file — ONE resolver, ownership enforced ────────────
    output_file, _err = await _adb(
        _resolve_owned_result_file, body.execution_id, body.file_id, _user)
    if _err:
        return {"error": _err}

    sp = output_file.replace("'", "''")
    sample_limit = _sp_cfg.profile_sample_limit
    max_top_values = _sp_cfg.profile_max_top_values
    iqr_multiplier = _sp_cfg.outlier_iqr_multiplier

    from core.duckdb_factory import duckdb_connection
    with duckdb_connection() as con:
        try:
            return _profile_result_file(
                con, sp, body, sample_limit, max_top_values, iqr_multiplier)
        except Exception as exc:
            logger.warning("data-profile: %s", exc)
            return {"error": str(exc)}


class ChartRecommendRequest(BaseModel):
    columns: List[Dict[str, Any]] = []   # [{name, type, distinct_estimate, null_pct}]
    connection_id: Optional[int] = None
    max_suggestions: int = 5


def _note_low_cardinality(col, distinct, low_card_cats, very_low_card):
    """Record a categorical column in the low-cardinality buckets a bar or
    pie chart needs (<20 and <8 distinct)."""
    if 0 < distinct <= 20:
        low_card_cats.append(col)
    if 0 < distinct <= 8:
        very_low_card.append(col)


def _classify_chart_columns(columns):
    """Sort the result's columns into the buckets the chart heuristics read.

    Returns (temporals, numerics, categoricals, low_card_cats, very_low_card).
    The declared type wins; a name pattern decides when it is absent.  The
    "categorical or unknown / name pattern" test and the final else did
    IDENTICAL work (same three appends), so they are one branch here.
    """
    # Classify columns
    temporals = []
    numerics = []
    categoricals = []
    low_card_cats = []  # distinct < 20
    very_low_card = []  # distinct < 8

    for col in columns:
        name = col.get("name", "")
        null_pct = col.get("null_pct", 0) or 0
        if null_pct > 0.8:
            continue  # skip high-null columns
        col_type = col.get("type", "unknown")
        distinct = col.get("distinct_estimate", -1)

        # Classify by provided type or name patterns
        if col_type == "temporal" or _DATE_COL_PATTERNS.search(name):
            temporals.append(col)
        elif col_type == "numeric" or _NUM_COL_PATTERNS.search(name):
            numerics.append(col)
        else:
            categoricals.append(col)
            _note_low_cardinality(col, distinct, low_card_cats, very_low_card)

    return temporals, numerics, categoricals, low_card_cats, very_low_card


@router.post("/api/suggest/chart-recommendations")
async def chart_recommendations(body: ChartRecommendRequest, _user: dict = Depends(get_current_user)):
    """Server-side heuristic chart recommendations based on column metadata."""
    from core.config import smart_predictions as _sp_cfg

    if not _sp_cfg.enabled:
        raise HTTPException(status_code=403, detail="Smart predictions feature is disabled.")

    max_suggestions = min(body.max_suggestions, _sp_cfg.max_chart_suggestions)
    suggestions = []

    (temporals, numerics, categoricals, low_card_cats,
     very_low_card) = _classify_chart_columns(body.columns)

    rank = 0

    # 1. temporal + numeric -> line chart (time series)
    if temporals and numerics:
        rank += 1
        suggestions.append({
            "rank": rank,
            "chart_type": "line",
            "x_column": temporals[0]["name"],
            "y_column": numerics[0]["name"],
            "agg": "sum",
            "title": f'{numerics[0]["name"]} over time',
            "reason": "Temporal column detected — line chart shows time-series trend",
            "confidence": 0.95,
        })

    # 2. low-cardinality categorical + numeric -> bar chart
    if low_card_cats and numerics:
        rank += 1
        suggestions.append({
            "rank": rank,
            "chart_type": "bar",
            "x_column": low_card_cats[0]["name"],
            "y_column": numerics[0]["name"],
            "agg": "sum",
            "title": f'{numerics[0]["name"]} by {low_card_cats[0]["name"]}',
            "reason": "Low-cardinality category with numeric measure — bar chart",
            "confidence": 0.90,
        })

    # 3. categorical only -> pie chart (if distinct < 8)
    if very_low_card and numerics:
        cat = very_low_card[0]
        rank += 1
        suggestions.append({
            "rank": rank,
            "chart_type": "pie",
            "x_column": cat["name"],
            "y_column": numerics[0]["name"] if numerics else cat["name"],
            "agg": "sum" if numerics else "count",
            "title": f'{cat["name"]} composition',
            "reason": "Very low cardinality — pie chart shows distribution",
            "confidence": 0.85,
        })

    # 4. two numerics -> scatter
    if len(numerics) >= 2:
        rank += 1
        suggestions.append({
            "rank": rank,
            "chart_type": "scatter",
            "x_column": numerics[0]["name"],
            "y_column": numerics[1]["name"],
            "agg": "sum",
            "title": f'{numerics[0]["name"]} vs {numerics[1]["name"]}',
            "reason": "Two numeric columns — scatter plot shows correlation",
            "confidence": 0.80,
        })

    # 5. categorical + temporal + numeric -> grouped bar
    if categoricals and temporals and numerics and very_low_card:
        rank += 1
        suggestions.append({
            "rank": rank,
            "chart_type": "grouped_bar",
            "x_column": temporals[0]["name"],
            "y_column": numerics[0]["name"],
            "series_column": very_low_card[0]["name"],
            "agg": "sum",
            "title": f'{numerics[0]["name"]} by {temporals[0]["name"]} per {very_low_card[0]["name"]}',
            "reason": "Temporal + category + numeric — grouped bar chart",
            "confidence": 0.85,
        })

    return {
        "suggestions": suggestions[:max_suggestions],
        "total_columns": len(body.columns),
        "classified": {
            "temporal": len(temporals),
            "numeric": len(numerics),
            "categorical": len(categoricals),
        },
    }


# ── Phase 84D — NL Learning Engine Endpoints ──────────────────────────────────

class NLLearningFeedbackRequest(BaseModel):
    """Phase 84D: Learning feedback using history_id for reinforcement."""
    history_id: int
    was_edited: bool = False
    executed_sql: Optional[str] = None
    execution_success: bool = True
    feedback_score: Optional[int] = None  # +1 or -1


def _require_db():
    from api.deps import require_db as _central_require_db
    return _central_require_db()


@router.post("/api/suggest/nl-feedback")
async def record_nl_feedback(body: NLLearningFeedbackRequest,
                              user: dict = Depends(get_current_user)):
    """Record user feedback on an NL-to-SQL result. Used to reinforce learning. Phase 84."""
    try:
        from core.nl_learning_engine import process_feedback
        process_feedback(
            body.history_id, body.was_edited, body.executed_sql,
            body.execution_success, body.feedback_score
        )
    except Exception as exc:
        logger.debug("nl-feedback error: %s", exc)
    return {"detail": "feedback recorded"}


@router.get("/api/suggest/nl-patterns")
async def get_nl_patterns(limit: int = Query(default=50, le=200),
                           user: dict = Depends(require_admin)):
    """Admin: view learned NL patterns sorted by score. Phase 84."""
    db = _require_db()
    return await _adb(db.get_top_nl_patterns, limit=limit)


@router.delete("/api/suggest/nl-patterns/{pattern_id}")
async def delete_nl_pattern(pattern_id: int, user: dict = Depends(require_admin)):
    """Admin: remove a learned pattern. Phase 84."""
    db = _require_db()
    deleted = await _adb(db.delete_nl_pattern, pattern_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Pattern not found")
    return {"detail": "deleted"}


@router.get("/api/suggest/nl-synonyms")
async def get_nl_synonyms(user: dict = Depends(require_admin)):
    """Admin: view learned synonym mappings. Phase 84."""
    db = _require_db()
    return await _adb(db.get_nl_synonyms)


@router.get("/api/suggest/nl-history")
async def get_nl_history(
    limit: int = Query(default=100, le=1000),
    user: dict = Depends(require_admin),
):
    """Admin: view NL query history. Phase 84."""
    db = _require_db()
    return await _adb(db.get_nl_query_history, limit=limit)


# ── Phase 95 — Local LLM Status & Reload ─────────────────────────────────────

@router.get("/api/suggest/llm-status")
async def get_llm_status(user: dict = Depends(require_admin)):
    """Admin: view local LLM model status (embedder + SQL generator). Phase 95."""
    from core import config as cfg
    result: Dict[str, Any] = {
        "enabled": cfg.local_llm.enabled,
        "config": {
            "model_path": cfg.local_llm.model_path or None,
            "model_name": cfg.local_llm.model_name or None,
            "embedder_model": cfg.local_llm.embedder_model,
            "embedder_enabled": cfg.local_llm.embedder_enabled,
            "sql_generation_enabled": cfg.local_llm.sql_generation_enabled,
            "n_ctx": cfg.local_llm.n_ctx,
            "max_tokens": cfg.local_llm.max_tokens,
            "temperature": cfg.local_llm.temperature,
            "finance_domain_hints": cfg.local_llm.finance_domain_hints,
            "backend": "transformers",
        },
    }
    # Embedder status
    try:
        from core.nl_learning_engine import get_embedder_status
        result["embedder"] = get_embedder_status()
    except Exception:
        result["embedder"] = {"loaded": False, "error": "import failed"}
    # SQL generator status
    try:
        from core.local_llm import get_status as get_llm_gen_status
        result["sql_generator"] = get_llm_gen_status()
    except Exception:
        result["sql_generator"] = {"loaded": False, "error": "import failed"}
    return result


@router.post("/api/suggest/llm-reload")
async def reload_llm(user: dict = Depends(require_admin)):
    """Admin: reload local LLM models (swap model without server restart). Phase 95."""
    from core import config as cfg
    results: Dict[str, Any] = {}

    # Reload embedder
    if cfg.local_llm.embedder_enabled:
        try:
            from core.nl_learning_engine import init_embedder, clear_embedding_cache
            clear_embedding_cache()
            ok = init_embedder(cfg.local_llm.embedder_model)
            results["embedder"] = {"reloaded": ok, "model": cfg.local_llm.embedder_model}
        except Exception as exc:
            results["embedder"] = {"reloaded": False, "error": str(exc)}
    else:
        results["embedder"] = {"reloaded": False, "reason": "disabled"}

    # Reload SQL generator
    if cfg.local_llm.sql_generation_enabled and cfg.local_llm.model_path:
        try:
            from core.local_llm import reload_model
            ok = reload_model(
                model_path=cfg.local_llm.model_path,
                n_ctx=cfg.local_llm.n_ctx,
                n_gpu_layers=cfg.local_llm.n_gpu_layers,
                model_name=cfg.local_llm.model_name,
            )
            results["sql_generator"] = {"reloaded": ok, "model": cfg.local_llm.model_path}
        except Exception as exc:
            results["sql_generator"] = {"reloaded": False, "error": str(exc)}
    else:
        results["sql_generator"] = {"reloaded": False, "reason": "disabled or no model_path"}

    return results


# ── Phase 114-G — NL Conversation Memory ──────────────────────────────────────



@router.get("/api/assistant/conversations")
async def list_conversations(
    limit: int = Query(default=50, ge=1, le=200),
    user: dict = Depends(get_current_user),
):
    db = _require_db()
    return await _adb(db.list_nl_conversations, user.get("username", ""), limit=limit)


@router.get("/api/assistant/conversations/current")
async def get_or_create_conversation(user: dict = Depends(get_current_user)):
    db = _require_db()
    return await _adb(db.get_or_create_nl_conversation, user.get("username", ""))


class ConversationUpdate(BaseModel):
    messages: Optional[List[Dict[str, Any]]] = None
    title: Optional[str] = None
    context: Optional[Dict[str, Any]] = None


@router.put("/api/assistant/conversations/{conv_id}")
async def update_conversation(
    conv_id: int,
    body: ConversationUpdate,
    user: dict = Depends(get_current_user),
):
    db = _require_db()
    result = await _adb(db.update_nl_conversation, 
        conv_id, user.get("username", ""),
        messages=body.messages, title=body.title, context=body.context,
    )
    if not result:
        raise HTTPException(404, f"Conversation {conv_id} not found")
    return result


@router.post("/api/assistant/conversations")
async def create_conversation(
    body: ConversationUpdate = None,
    user: dict = Depends(get_current_user),
):
    db = _require_db()
    return await _adb(db.create_nl_conversation, 
        user_id=user.get("username", ""),
        title=body.title if body else None,
        messages=body.messages if body else [],
        context=body.context if body else None,
    )


# ── Phase 114-I — Explain This Data ──────────────────────────────────────────

class ExplainDataRequest(BaseModel):
    columns: List[str]
    sample_data: List[Dict[str, Any]]  # first N rows
    column_types: Optional[Dict[str, str]] = None  # col → "numeric"|"string"|"date"


def _explain_detect_type(ctype, vals):
    """Decide a column's type when the caller did not declare one.

    A value that float() accepts is numeric; everything else is a string.
    """
    # Auto-detect type if not provided
    if ctype or not vals:
        return ctype
    sample = vals[0]
    if isinstance(sample, (int, float)):
        return "numeric"
    try:
        float(sample)
        return "numeric"
    except (ValueError, TypeError):
        return "string"


def _explain_numeric_stats(vals):
    """min/max/mean/median (+stdev when there is more than one value).

    Values float() rejects are skipped, not fatal -- a declared-numeric
    column with a stray string still profiles.
    """
    import statistics
    nums = []
    for v in vals:
        try:
            nums.append(float(v))
        except (ValueError, TypeError):
            pass
    if not nums:
        return {}
    stat = {
        "min": min(nums),
        "max": max(nums),
        "mean": round(statistics.mean(nums), 4),
        "median": round(statistics.median(nums), 4),
    }
    if len(nums) > 1:
        stat["stdev"] = round(statistics.stdev(nums), 4)
    return stat


def _explain_date_stats(vals):
    """Earliest/latest day and the distinct-day count, on the YYYY-MM-DD prefix."""
    dates = []
    for v in vals:
        try:
            dates.append(str(v)[:10])
        except Exception:
            pass
    if not dates:
        return {}
    return {
        "min_date": min(dates),
        "max_date": max(dates),
        "distinct_count": len(set(dates)),
    }


def _explain_string_stats(vals):
    """Distinct count and the five most common values, as strings."""
    from collections import Counter
    strs = [str(v) for v in vals]
    distinct = set(strs)
    top5 = Counter(strs).most_common(5)
    return {
        "distinct_count": len(distinct),
        "top_values": [{"value": v, "count": c} for v, c in top5],
    }


def _explain_column_stat(col, rows, col_types):
    """Profile one column of the sample; decides which stat family applies."""
    vals = [r.get(col) for r in rows if r.get(col) is not None]
    null_count = sum(1 for r in rows if r.get(col) is None)
    total = len(rows)

    ctype = _explain_detect_type(col_types.get(col, ""), vals)

    stat: Dict[str, Any] = {"type": ctype, "null_count": null_count, "total": total}

    if ctype == "numeric":
        stat.update(_explain_numeric_stats(vals))
    elif ctype == "date":
        stat.update(_explain_date_stats(vals))
    else:
        stat.update(_explain_string_stats(vals))
    return stat


def _explain_insights(col_stats, rows, cols):
    """Turn the per-column stats into the sentences the UI shows."""
    # Generate insights
    insights = []
    numeric_cols = [c for c, s in col_stats.items() if s.get("type") == "numeric"]
    if numeric_cols:
        best = max(numeric_cols, key=lambda c: col_stats[c].get("mean", 0))
        insights.append(f"Highest average value is in '{best}' ({col_stats[best].get('mean', 0):.2f}).")
    high_null = [c for c, s in col_stats.items() if s["null_count"] > s["total"] * 0.1]
    if high_null:
        insights.append(f"Columns with >10% nulls: {', '.join(high_null)}.")
    if len(rows) > 0:
        insights.append(f"Sample contains {len(rows)} rows across {len(cols)} columns.")
    return insights


@router.post("/api/assistant/explain-data")
async def explain_data(body: ExplainDataRequest, _user: dict = Depends(get_current_user)):
    """Compute per-column stats and generate insights from sample data. No DB round-trip."""
    cols = body.columns
    rows = body.sample_data or []
    col_types = body.column_types or {}

    col_stats: Dict[str, Any] = {}
    for col in cols:
        col_stats[col] = _explain_column_stat(col, rows, col_types)

    insights = _explain_insights(col_stats, rows, cols)

    return {"column_stats": col_stats, "insights": insights, "row_count": len(rows)}
