"""Phase 132.33 — live SAP-OData passthrough endpoints.

Two routes, admin-only:

  GET  /api/sap-passthrough/{task_id}/schema
       → what consumers can filter on + what columns come back.

  POST /api/sap-passthrough/{task_id}/query
       body: {"filters": {...}, "top": 1000, "skip": 0,
                "period_mode_override": "current"}
       → mapped JSON page from SAP.

Auth + rate limit:
  * admin-only (re-uses ``require_admin`` dependency).
  * Per-task RPM bucket enforced by the engine; over-limit ⇒ HTTP 429.

This API is API-first: consumers don't go through BQB or saved-query
SQL — every call hits SAP live with `p_timestamp=now()`, returns rows
mapped via the same ``column_mapping.json`` the ETL pipeline uses.

Generic by design: no SAP column names hardcoded in this module.  Add
a new SapTaskConfig with a different column_mapping.json and the same
endpoint serves it.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

# Import auth dependencies at module load — these are singletons inside
# api.deps that get their backing state wired by ``init_deps()`` at
# startup.  We can reference them in route signatures via ``Depends(...)``
# safely because FastAPI calls them at request-time.
from api.deps import require_admin as _admin_dep

logger = logging.getLogger(__name__)
router = APIRouter(tags=["sap-passthrough"])

# Module-level deps injected by main.py at startup
_db_manager = None
_audit = lambda *a, **k: None


def set_sap_passthrough_dependencies(
    db_manager: Any,
    get_current_user_dep: Any = None,    # kept for signature parity
    require_admin_dep: Any = None,        # kept for signature parity
    audit_fn: Any = None,
) -> None:
    """Wire the passthrough engine + audit hook.  Auth deps are resolved
    via ``api.deps`` directly (single source of truth) — the function
    keeps the same signature as its peers for symmetry.
    """
    global _db_manager, _audit
    _db_manager = db_manager
    if audit_fn is not None:
        _audit = audit_fn


def _require_deps() -> None:
    if _db_manager is None:
        raise HTTPException(
            status_code=503,
            detail="sap_passthrough_api dependencies not initialised",
        )


def _engine():
    """Lazy-init the engine on first request — avoids ordering issues
    when this module is imported before main.py wires deps.
    """
    from core.sap_passthrough import get_passthrough, init_passthrough
    eng = get_passthrough()
    if eng is None:
        eng = init_passthrough(_db_manager)
    return eng


def _username_of(user: Any) -> str:
    if isinstance(user, dict):
        return user.get("username") or user.get("user") or user.get("name") or "anon"
    return getattr(user, "username", None) or getattr(user, "name", None) or "anon"


# ── Body model ─────────────────────────────────────────────────────────


class SapPassthroughQueryBody(BaseModel):
    filters: Dict[str, Any] = Field(default_factory=dict)
    top:     int = Field(default=1000, ge=1, le=100000)
    skip:    int = Field(default=0, ge=0)
    period_mode_override: Optional[str] = None


# ── Routes ─────────────────────────────────────────────────────────────


@router.get("/api/sap-passthrough/{task_id}/schema")
async def passthrough_schema(
    task_id: int, user: dict = Depends(_admin_dep),
) -> Dict[str, Any]:
    """Return the filterable + output column schema for a passthrough task.

    Generic — column names come from the column_mapping.json on disk
    (no SAP-specific assumptions in this module).  Admin-only.
    """
    _require_deps()
    try:
        return _engine().describe_schema(task_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except FileNotFoundError as exc:
        # column_mapping.json missing — actionable config problem, surface
        # the path so admin can fix it (this is admin-only).
        raise HTTPException(status_code=500, detail=str(exc))
    except Exception:  # pragma: no cover — last-line defence
        # Audit NIT — do NOT echo str(exc) to clients; could leak
        # stack/internals.  Full detail in server log via .exception().
        logger.exception("[sap_passthrough] schema lookup failed task_id=%s",
                          task_id)
        raise HTTPException(
            status_code=500,
            detail="internal error resolving schema — see server logs",
        )


@router.post("/api/sap-passthrough/{task_id}/query")
async def passthrough_query(
    task_id: int, body: SapPassthroughQueryBody,
    user: dict = Depends(_admin_dep),
) -> Dict[str, Any]:
    """Execute a live SAP-OData query for ``task_id``.

    Required-filter rules enforced by the engine; missing required
    filters ⇒ HTTP 400.  Per-task RPM exceeded ⇒ HTTP 429.  Admin-only.

    Top/skip pagination is forwarded to SAP via $top/$skip; the
    response's ``has_more`` + ``next_skip`` let the caller resume.
    """
    _require_deps()
    try:
        result = _engine().query(
            task_id,
            filters=body.filters or {},
            top=body.top,
            skip=body.skip,
            period_mode_override=body.period_mode_override,
        )
    except PermissionError as exc:
        # Rate limit — 429 + Retry-After hint
        raise HTTPException(
            status_code=429, detail=str(exc),
            headers={"Retry-After": "60"},
        )
    except ValueError as exc:
        # Missing required filters / unknown task / disabled passthrough
        raise HTTPException(status_code=400, detail=str(exc))
    except FileNotFoundError as exc:
        raise HTTPException(status_code=500, detail=str(exc))
    except RuntimeError as exc:
        # SAP ETL framework missing or session build failure
        raise HTTPException(status_code=503, detail=str(exc))
    except Exception:
        # Audit NIT — generic 500 so str(exc) can't leak stack/SAP-
        # internals to the caller.  Full detail in server logs.
        logger.exception("[sap_passthrough] query failed task_id=%s", task_id)
        raise HTTPException(
            status_code=500,
            detail="internal error executing SAP query — see server logs",
        )

    _audit({"username": _username_of(user)}, "sap_passthrough.query",
            target=f"sap_task:{task_id}",
            details={"returned": result.get("returned"),
                       "has_more": result.get("has_more"),
                       "skip": result.get("skip"), "top": result.get("top"),
                       "task_name": result.get("task_name"),
                       "filter_keys": sorted((body.filters or {}).keys())})
    return result
