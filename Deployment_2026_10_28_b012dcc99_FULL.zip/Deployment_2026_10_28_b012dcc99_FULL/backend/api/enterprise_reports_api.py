"""
Enterprise Reports API (Phases 23B, 23C, 23F, 23G, 23H)

23B — Report Bookmarks (saved parameter sets)
23C — Conditional Formatting rules
23F — Threshold Alert rules + evaluation
23G — Row-Level Security policies
23H — Cloud Delivery config + delivery history
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query as QParam, Request
from pydantic import BaseModel, Field

from api.deps import aget_verified_user, get_verified_user, is_owner_or_shared
from core.roles import is_admin_like

logger = logging.getLogger(__name__)

router = APIRouter()


# BF-NONBLOCK-AUDIT-5: every async route in this file calls sync DB
# methods inline.  This helper offloads them via asyncio.to_thread so
# the event loop stays free for /health probes and WS pings.
async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)

_db_manager = None
_auth_cfg   = None
_email_svc  = None


def set_enterprise_dependencies(db_manager, auth_cfg, email_service=None):
    global _db_manager, _auth_cfg, _email_svc
    _db_manager = db_manager
    _auth_cfg   = auth_cfg
    _email_svc  = email_service


# Phase 1 SECURITY (2026-07-23): the forgeable local ``_get_user`` (base64-
# decode the Basic header, TRUST the username, fall back to "anonymous") is
# GONE.  Identity comes from api.deps.get_verified_user/aget_verified_user —
# the verified boundary (session lookup / real password check; optional
# config-gated X-API-Key service auth).  Unauthenticated/forged → 401.


async def _require_report_view(report_id: int, user: dict) -> dict:
    """R5 (2026-08-17): object-level view gate for report-scoped routes.

    Several routes in this file authenticated the caller but never checked
    whether the caller may VIEW report ``report_id`` (IDOR): rls/preview,
    bookmarks, formatting, alert-rule listing.

    FB-60 (2026-09-26): ``report_id`` is a FINANCE report id -- the legacy
    parametric entity is decommissioned and its rows migrate to finance
    reports (their bookmarks / formats / alerts / RLS rows re-pointed with
    them by backend/migrate_reports.py).  The gate is the ONE finance-report
    view rule (``can_view_business_report``: owner / admin / published within
    role_whitelist / grants).  404 both for a missing and a denied report
    (no existence oracle).  auth.type='none' guest is admin → dev mode
    unchanged.
    """
    report = await _adb(_db_manager.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404, detail=f"Report {report_id} not found")
    from core.reports.authorization import can_view_business_report
    if not can_view_business_report(report, user, _db_manager):
        raise HTTPException(status_code=404, detail=f"Report {report_id} not found")
    return report


async def _require_report_edit(report_id: int, user: dict) -> dict:
    """The finance-report EDIT gate for the write routes of this family
    (F7 follow-up, 2026-09-26): formatting and alert rules change what every
    consumer of the report sees or receives, so they take the same rule the
    builder's PUT takes -- owner / admin / explicit editor grant
    (``business_reports_api._br_can_edit``).  Order: the view gate first, so
    a stranger gets the non-oracle 404; a viewer who may see but not edit
    gets 403."""
    report = await _require_report_view(report_id, user)
    from api.business_reports_api import _br_can_edit
    if not _br_can_edit(report, user):
        raise HTTPException(status_code=403,
                            detail="Only the report owner, an admin or an editor "
                                   "can change this report's settings")
    return report


def _require_admin(request: Request) -> dict:
    """Admin gate for RLS-policy + cloud-delivery management.

    Runs as a sync Depends (FastAPI executes it in the threadpool, keeping
    blocking auth I/O off the event loop).

    Phase 1 SECURITY: identity is now VERIFIED, and the role gate itself is
    fixed — the old check tested ``_auth_cfg.enabled``, an attribute that
    does not exist on ``_AuthCfg``, so the 403 could NEVER fire and any
    caller could manage RLS policies.  Gate on the real auth mode, the same
    pattern as ``api.deps.require_admin``.  ``is_admin_like`` covers
    admin/super_admin roles plus the ``is_admin`` flag (break-glass
    super_admin keeps working).
    """
    user = get_verified_user(request)          # 401 on forged/missing auth
    # AUTHZ-3 (2026-08-22): gate through ``deps._auth_genuinely_disabled()`` —
    # the ONE helper written to close the config-load-failure bypass.  The old
    # ``getattr(_auth_cfg,"type","none") != "none"`` test opened EVERY admin
    # route here (RLS policy CRUD, formatting overwrite, alert-evaluate,
    # cloud-delivery config) whenever a missing/corrupt ConfigMap defaulted
    # ``auth.type`` to 'none' — precisely at a pod restart, when DB-backed
    # sessions survive.  ``_auth_genuinely_disabled`` returns False then, so a
    # non-admin is still 403'd; a module never wired (``_auth_cfg is None``)
    # no longer short-circuits the gate either.
    from api.deps import _auth_genuinely_disabled
    if not _auth_genuinely_disabled() and not is_admin_like(user):
        raise HTTPException(status_code=403, detail="Admin required")
    return user


# ═══════════════════════════════════════════════════════════════════════════════
# 23B — Report Bookmarks
# ═══════════════════════════════════════════════════════════════════════════════

class BookmarkCreate(BaseModel):
    name:         str
    param_values: Dict[str, Any] = {}


@router.get("/api/reports/{report_id}/bookmarks")
async def list_bookmarks(report_id: int, request: Request):
    user = await aget_verified_user(request)
    # R5 (2026-08-17): view gate on the report the bookmarks belong to.
    await _require_report_view(report_id, user)
    return {"bookmarks": await _adb(_db_manager.list_bookmarks, report_id, user["username"])}


@router.post("/api/reports/{report_id}/bookmarks", status_code=201)
async def save_bookmark(report_id: int, body: BookmarkCreate, request: Request):
    user = await aget_verified_user(request)
    # R5 (2026-08-17): view gate — no bookmarking reports you cannot view.
    await _require_report_view(report_id, user)
    bm = await _adb(_db_manager.save_bookmark,
        report_id=report_id, username=user["username"],
        name=body.name, param_values=body.param_values,
    )
    return bm


@router.delete("/api/reports/bookmarks/{bookmark_id}")
async def delete_bookmark(bookmark_id: int, request: Request):
    user = await aget_verified_user(request)
    ok = await _adb(_db_manager.delete_bookmark, bookmark_id, user["username"])
    if not ok:
        raise HTTPException(status_code=404, detail="Bookmark not found")
    return {"deleted": True, "bookmark_id": bookmark_id}


# ═══════════════════════════════════════════════════════════════════════════════
# 23C — Conditional Formatting
# ═══════════════════════════════════════════════════════════════════════════════

class ConditionalFormatRuleIn(BaseModel):
    column_name:     str
    rule_order:      int = 0
    condition_type:  str  # value_range | equals | contains | not_null | is_null | top_n | bottom_n
    condition_value: Optional[Any] = None
    bg_color:        Optional[str] = None
    text_color:      Optional[str] = None
    icon:            str = "none"
    bold:            bool = False
    is_enabled:      bool = True


class ConditionalFormatsRequest(BaseModel):
    rules: List[ConditionalFormatRuleIn]


@router.get("/api/reports/{report_id}/formatting")
async def get_formatting(report_id: int, request: Request):
    # Phase 1 Part-1b SECURITY: was anonymous-callable (consumed no identity).
    user = await aget_verified_user(request)   # 401 on forged/missing auth
    # R5 (2026-08-17): object-level view gate (was: any authenticated user
    # could read any report's formatting rules).
    await _require_report_view(report_id, user)
    return {"rules": await _adb(_db_manager.get_conditional_formats, report_id)}


@router.put("/api/reports/{report_id}/formatting")
async def save_formatting(report_id: int, body: ConditionalFormatsRequest,
                          request: Request):
    # Phase 1 Part-1b SECURITY: anonymous callers could rewrite the
    # report-wide formatting rules everyone sees.  F7 follow-up (2026-09-26):
    # the report's OWN edit gate (owner / admin / editor grant), not a
    # global admin gate -- a report's presentation belongs to its editors.
    user = await aget_verified_user(request)
    await _require_report_edit(report_id, user)
    await _adb(_db_manager.save_conditional_formats,
        report_id, [r.model_dump() for r in body.rules]
    )
    return {"report_id": report_id, "count": len(body.rules)}


# ═══════════════════════════════════════════════════════════════════════════════
# 23F — Threshold Alert Rules
# ═══════════════════════════════════════════════════════════════════════════════

class AlertRuleCreate(BaseModel):
    name:              str
    column_name:       str
    aggregation:       str = "last"
    operator:          str
    threshold_value:   float
    channels:          List[str] = ["email"]
    recipients:        Optional[str] = None
    slack_webhook:     Optional[str] = None
    cooldown_minutes:  int = 60


class AlertRuleUpdate(BaseModel):
    name:             Optional[str] = None
    column_name:      Optional[str] = None
    aggregation:      Optional[str] = None
    operator:         Optional[str] = None
    threshold_value:  Optional[float] = None
    channels:         Optional[List[str]] = None
    recipients:       Optional[str] = None
    slack_webhook:    Optional[str] = None
    cooldown_minutes: Optional[int] = None
    is_enabled:       Optional[bool] = None


@router.get("/api/reports/{report_id}/alerts")
async def list_alert_rules(report_id: int, request: Request):
    # Phase 1 Part-1b SECURITY: was anonymous-callable (consumed no identity)
    # and rule rows expose recipients + slack_webhook.
    user = await aget_verified_user(request)   # 401 on forged/missing auth
    # R5 (2026-08-17): object-level view gate — rule rows expose recipients
    # and slack webhooks of a report's alerting config.
    await _require_report_view(report_id, user)
    # AUTHZ-4: the webhook is a bearer secret; a viewer of a public report is
    # not entitled to it (the history route is owner-or-admin for strictly
    # less than this).
    _rules = await _adb(_db_manager.list_alert_rules, report_id)
    return {"rules": _redact_rules(_rules, user)}


@router.post("/api/reports/{report_id}/alerts", status_code=201)
async def create_alert_rule(report_id: int, body: AlertRuleCreate, request: Request):
    user = await aget_verified_user(request)
    # R5 (2026-08-17): no alerting on reports you cannot view (an alert
    # mails the report's metric values outward).  F7 follow-up (2026-09-26):
    # authoring a rule on a report is EDITING it -- owner / admin / editor.
    await _require_report_edit(report_id, user)
    _validate_webhook(body.slack_webhook)          # AUTHZ-4
    rule = await _adb(_db_manager.create_alert_rule,
        report_id=report_id, name=body.name, column_name=body.column_name,
        operator=body.operator, threshold_value=body.threshold_value,
        aggregation=body.aggregation, channels=body.channels,
        recipients=body.recipients, slack_webhook=body.slack_webhook,
        cooldown_minutes=body.cooldown_minutes, created_by=user["username"],
    )
    return rule


# AUTHZ-4 (2026-08-22) — the webhook is BOTH a bearer secret and an
# outbound-fetch target.  Both halves are handled here so no route can
# inherit one and miss the other.
_WEBHOOK_SCHEMES = ("http", "https")


def _validate_webhook(url: Optional[str]) -> Optional[str]:
    """Reject a webhook URL that would be an SSRF primitive.

    ``core.url_safety.validate_url_safety`` has been the codebase's SSRF
    chokepoint since Phase 132-A and is used by ten modules — this route
    family simply never inherited it, so any user who could VIEW a report
    could set a URL the server would then fetch.  Scheme is checked here
    because the shared validator reasons about hosts and IPs, not schemes,
    and ``ftp://`` resolves to a perfectly ordinary hostname.
    """
    if not url:
        return url
    from urllib.parse import urlparse

    from core.url_safety import validate_url_safety
    if urlparse(url).scheme.lower() not in _WEBHOOK_SCHEMES:
        raise HTTPException(
            status_code=400,
            detail="slack_webhook must be an http(s) URL")
    try:
        validate_url_safety(url)
    except ValueError as exc:
        raise HTTPException(status_code=400,
                            detail=f"slack_webhook rejected: {exc}") from exc
    return url


def _redact_rules(rules, user) -> list:
    """Strip ``slack_webhook`` from rules the caller does not own.

    The listing stays view-gated so a viewer can still see that alerting
    exists and on what — it is the SECRET that is owner-or-admin, matching
    the history route's reasoning rather than contradicting it.
    """
    out = []
    for r in (rules or []):
        d = dict(r) if not isinstance(r, dict) else dict(r)
        if d.get("slack_webhook") and not is_owner_or_shared(d, user):
            d["slack_webhook"] = None
            d["slack_webhook_redacted"] = True
        out.append(d)
    return out


async def _require_alert_rule_owner_or_admin(rule_id: int, request: Request) -> dict:
    """Phase 1 Part-1b SECURITY: alert-rule mutations were anonymous-callable.

    Verified identity (401) + owner-or-admin on the rule's created_by column
    — the codebase-wide api.deps.is_owner_or_shared rule (AlertRule rows have
    no is_shared/is_public, so this reduces to exactly owner-or-admin; legacy
    rows with created_by=NULL are admin-only — fail-CLOSED).  auth.type='none'
    guest is admin → dev mode unchanged.  404 shape for a missing rule is
    preserved (only for authenticated callers, matching pre-change behavior
    minus the anonymity).
    """
    user = await aget_verified_user(request)   # 401 on forged/missing auth
    rule = await _adb(_db_manager.get_alert_rule, rule_id)
    if not rule:
        raise HTTPException(status_code=404, detail="Alert rule not found")
    if not is_owner_or_shared(rule, user):
        raise HTTPException(status_code=403,
                            detail="Not authorized to modify this alert rule")
    return user


@router.put("/api/reports/alerts/{rule_id}")
async def update_alert_rule(rule_id: int, body: AlertRuleUpdate, request: Request):
    await _require_alert_rule_owner_or_admin(rule_id, request)
    _validate_webhook(body.slack_webhook)          # AUTHZ-4
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    result = await _adb(_db_manager.update_alert_rule, rule_id, **updates)
    if not result:
        raise HTTPException(status_code=404, detail="Alert rule not found")
    return result


@router.delete("/api/reports/alerts/{rule_id}")
async def delete_alert_rule(rule_id: int, request: Request):
    await _require_alert_rule_owner_or_admin(rule_id, request)
    ok = await _adb(_db_manager.delete_alert_rule, rule_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Alert rule not found")
    return {"deleted": True, "rule_id": rule_id}


@router.get("/api/reports/alerts/{rule_id}/history")
async def get_alert_history(rule_id: int, request: Request,
                             limit: int = QParam(default=50, ge=1, le=500)):
    # Phase 1 Part-1b SECURITY: was anonymous-callable (consumed no identity)
    # and history rows expose sent_to destinations.
    # R5 (2026-08-17): object-level gate — the SAME owner-or-admin rule the
    # update/delete routes at :281/:291 already apply (history rows expose
    # sent_to destinations, which belong to the rule owner).
    await _require_alert_rule_owner_or_admin(rule_id, request)
    return {"history": await _adb(_db_manager.list_alert_history, rule_id, limit)}


@router.post("/api/reports/{report_id}/alerts/evaluate")
async def evaluate_alerts(report_id: int, request: Request,
                          _user: dict = Depends(_require_admin)):
    """Manually trigger alert evaluation against latest execution result.

    The automatic path is IN-PROCESS (core.delivery_engine.
    evaluate_alerts_for_schedule after scheduled runs) — it never calls this
    HTTP route, so gating it breaks no automation.

    Phase 1 Part-1b SECURITY: an anonymous POST with attacker-chosen rows
    could fire email/Slack notifications through every configured rule.
    Operational trigger → admin-gated via the fixed _require_admin (401
    anonymous / 403 non-admin; auth.type='none' guest is admin → dev mode
    unchanged).  A service X-API-Key principal is api_consumer, never
    admin-tier, so the opt-in hatch cannot fire notifications either.
    """
    body = await request.json()
    rows = body.get("rows", [])
    triggered = await _adb(_db_manager.evaluate_alert_rules, report_id, rows)

    notifications = []
    for rule in triggered:
        # Fire notifications
        _fire_alert_notifications(rule, rule.get("actual_value"))
        notifications.append({
            "rule_id":   rule["id"],
            "rule_name": rule["name"],
            "actual":    rule.get("actual_value"),
            "threshold": rule["threshold_value"],
        })

    return {"triggered": len(triggered), "notifications": notifications}


def _fire_alert_notifications(rule: dict, actual_value: float) -> None:
    """Send alert notifications via email and/or Slack (best-effort)."""
    import threading

    def _send():
        try:
            report_name = f"Report #{rule['report_id']}"
            msg = (f"Alert '{rule['name']}' triggered on {report_name}.\n"
                   f"Column '{rule['column_name']}': actual={actual_value}, "
                   f"threshold={rule['threshold_value']} ({rule['operator']})")

            channels = rule.get("channels") or []
            if "email" in channels and rule.get("recipients") and _email_svc:
                for addr in rule["recipients"].split(","):
                    addr = addr.strip()
                    if addr:
                        try:
                            _email_svc.send_email(
                                to=addr,
                                subject=f"[QueryStudio Alert] {rule['name']}",
                                body=msg,
                            )
                        except Exception as e:
                            logger.warning("Alert email failed to %s: %s", addr, e)

            if "slack" in channels and rule.get("slack_webhook"):
                import urllib.request as _urlreq
                import json as _json

                # AUTHZ-4 defence in depth: rules stored BEFORE the set-time
                # guard existed are still in the table, and a DNS record can
                # be re-pointed after a rule was accepted.  So validate at
                # the moment of the fetch as well.
                #
                # The refusal DROPS the channel rather than raising: raising
                # here is swallowed by the outer handler, which would also
                # skip the history rows for the email that already went out,
                # and leaving "slack" in ``channels`` would record a delivery
                # that never happened.  A refusal must not be recorded as a
                # send.
                from core.url_safety import validate_url_safety as _vus
                try:
                    _vus(rule["slack_webhook"])
                    _slack_ok = True
                except ValueError as _ssrf:
                    logger.error(
                        "Alert rule %s: REFUSING to POST to an unsafe "
                        "slack_webhook (%s) — the channel is dropped for "
                        "this evaluation and no history row is written.",
                        rule.get("id"), _ssrf)
                    channels = [c for c in channels if c != "slack"]
                    _slack_ok = False
            else:
                _slack_ok = False

            if _slack_ok:
                payload = {"text": f":warning: *QueryStudio Alert*\n{msg}"}
                req = _urlreq.Request(
                    rule["slack_webhook"],
                    data=_json.dumps(payload).encode(),
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with _urlreq.urlopen(req, timeout=10):
                    pass

            # Record in history
            for ch in channels:
                _db_manager.record_alert(
                    rule_id=rule["id"], actual_value=actual_value,
                    threshold_value=rule["threshold_value"],
                    channel=ch, sent_to=rule.get("recipients") or rule.get("slack_webhook") or "",
                )
        except Exception as e:
            logger.error("Alert notification failed for rule %s: %s", rule.get("id"), e)

    threading.Thread(target=_send, daemon=True).start()


# ═══════════════════════════════════════════════════════════════════════════════
# 23H — Cloud Delivery
# ═══════════════════════════════════════════════════════════════════════════════

class CloudDeliveryConfigIn(BaseModel):
    provider:         str = Field(pattern="^(s3|azure|gcs)$")
    bucket:           Optional[str] = None
    prefix_template:  Optional[str] = None
    # 2026-08-30: default was ["pdf"] — a format the scheduler cannot
    # produce, stored and never read.  Delivery uploads the run's artifact
    # in the format the run produced; non-empty formats are refused below.
    formats:          List[str] = []
    zip_bundle:       bool = False
    connection_id:    Optional[int] = None
    is_enabled:       bool = True


@router.get("/api/schedules/{schedule_id}/cloud-delivery")
async def get_cloud_delivery(schedule_id: int,
                              _user: dict = Depends(_require_admin)):
    cfg = await _adb(_db_manager.get_cloud_delivery_config, schedule_id)
    if not cfg:
        raise HTTPException(status_code=404, detail="No cloud delivery config found")
    return cfg


@router.put("/api/schedules/{schedule_id}/cloud-delivery")
async def save_cloud_delivery(schedule_id: int, body: CloudDeliveryConfigIn,
                               _user: dict = Depends(_require_admin)):
    """Save the schedule's cloud delivery config.

    2026-08-30 — this endpoint used to accept ANY config with a 200 while
    nothing consumed the row (the Phase 23H store had no reader).  The
    scheduler now delivers to S3 after every successful run
    (core.scheduler._deliver_to_cloud); everything the scheduler cannot
    honour is REFUSED here with the reason, instead of stored as a promise
    that would silently never happen:

      * azure / gcs — no upload machinery exists in this codebase.
      * formats     — the run's artifact is uploaded in the format the run
                      produced (csv or parquet); there is no conversion step.
      * a missing bucket / dangling connection_id — would only surface as a
                      2 a.m. delivery failure.
    """
    if body.provider != "s3":
        raise HTTPException(
            status_code=400,
            detail=(f"Cloud delivery provider '{body.provider}' is not "
                    "implemented in this deployment — only 's3' is wired to "
                    "the scheduler. Refusing to store a config that would "
                    "return 200 and then silently never deliver."))
    if not (body.bucket or "").strip():
        raise HTTPException(
            status_code=400,
            detail="S3 cloud delivery requires a 'bucket'.")
    if body.formats:
        raise HTTPException(
            status_code=400,
            detail=("Format conversion is not supported: the scheduled run's "
                    "artifact is delivered in the format it was produced "
                    "(csv or parquet, zipped when zip_bundle is set). "
                    "Omit 'formats'."))
    schedule = await _adb(_db_manager.get_schedule, schedule_id)
    if not schedule:
        raise HTTPException(status_code=404,
                            detail=f"Schedule {schedule_id} not found")
    if body.connection_id is not None:
        conn = await _adb(_db_manager.get_connection_raw, body.connection_id)
        if not conn:
            raise HTTPException(
                status_code=400,
                detail=(f"connection_id {body.connection_id} does not exist — "
                        "delivery credentials would be unresolvable."))
    cfg = await _adb(_db_manager.save_cloud_delivery_config, schedule_id, **body.model_dump())
    return cfg


@router.get("/api/schedules/{schedule_id}/delivery-history")
async def get_delivery_history(schedule_id: int,
                                limit: int = QParam(default=100, ge=1, le=1000),
                                _user: dict = Depends(_require_admin)):
    history = await _adb(_db_manager.list_delivery_history, schedule_id=schedule_id, limit=limit)
    return {"history": history, "count": len(history)}
