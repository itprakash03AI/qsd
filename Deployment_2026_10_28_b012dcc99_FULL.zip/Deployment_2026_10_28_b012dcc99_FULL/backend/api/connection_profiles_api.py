"""
Connection Profiles API (Phase 24B)

Endpoints:
  GET    /api/connection-profiles                — list all profiles
  POST   /api/connection-profiles                — create profile (admin)
  GET    /api/connection-profiles/active         — active profile + its mappings
  PUT    /api/connection-profiles/{id}           — update name/description (admin)
  DELETE /api/connection-profiles/{id}           — delete profile + mappings (admin)
  POST   /api/connection-profiles/{id}/activate  — activate (deactivates all others) (admin)
  POST   /api/connection-profiles/deactivate     — clear active profile (admin)
  GET    /api/connection-profiles/{id}/mappings  — list mappings for a profile
  PUT    /api/connection-profiles/{id}/mappings  — replace all mappings atomically (admin)
"""
from __future__ import annotations

import asyncio
import logging
from typing import List, Optional

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from core.roles import ADMIN_TIER_ROLES

logger = logging.getLogger(__name__)

router = APIRouter()


# BF-NONBLOCK-AUDIT-5
async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)

_db_manager = None
_auth_cfg   = None


def set_profile_dependencies(db_manager, auth_cfg):
    global _db_manager, _auth_cfg
    _db_manager = db_manager
    _auth_cfg   = auth_cfg


def _require_db():
    from api.deps import require_db as _central_require_db
    return _central_require_db()


def _get_user(request: Request) -> Optional[dict]:
    """Resolve the current user including role — same pattern as reports_api."""
    if not _auth_cfg or _auth_cfg.type == "none":
        return {"username": "guest", "role": "admin", "is_admin": True}
    auth_header = request.headers.get("Authorization", "")
    if not auth_header:
        return None
    if auth_header.startswith("Bearer "):
        try:
            from main import _get_session
            return _get_session(auth_header[7:])
        except Exception:
            return None
    try:
        from core.ad_auth import authenticate_user, decode_basic_header
        username, password = decode_basic_header(auth_header)
        return authenticate_user(username, password)
    except Exception:
        return None


def _require_admin(request: Request) -> dict:
    """Raise 403 if auth is enabled and the user is not admin."""
    if not _auth_cfg or _auth_cfg.type == "none":
        return {"username": "guest", "role": "admin", "is_admin": True}
    user = _get_user(request)
    if not user or user.get("role") not in ADMIN_TIER_ROLES:
        raise HTTPException(403, "Requires admin role")
    return user


def _require_auth(request: Request) -> dict:
    """SECURITY 2026-08-17: authentication for the READ routes.

    `GET /api/connection-profiles`, `/active` and `/{id}/mappings` took no
    ``request`` at all, so all three were anonymous while every write route in
    this file already called ``_require_admin``.  The mappings route is the
    sharp one -- it returns the source-connection -> target-connection
    redirection map, i.e. exactly which environment a given connection is
    silently being pointed at.
    """
    if not _auth_cfg or _auth_cfg.type == "none":
        return {"username": "guest", "role": "admin", "is_admin": True}
    user = _get_user(request)
    if not user:
        raise HTTPException(401, "Authentication required")
    return user


# ── Pydantic models ────────────────────────────────────────────────────────────

class CreateProfileRequest(BaseModel):
    name:        str
    description: Optional[str] = None


class UpdateProfileRequest(BaseModel):
    name:        Optional[str] = None
    description: Optional[str] = None


class ProfileMappingItem(BaseModel):
    source_connection_id: int
    target_connection_id: int
    description:          Optional[str] = None


class SetMappingsRequest(BaseModel):
    mappings: List[ProfileMappingItem] = []


# ── Endpoints ──────────────────────────────────────────────────────────────────

@router.get("/api/connection-profiles")
async def list_connection_profiles(request: Request):
    """List all connection profiles."""
    _require_auth(request)  # SECURITY 2026-08-17
    db = _require_db()
    return {"profiles": await _adb(db.list_connection_profiles)}


@router.get("/api/connection-profiles/active")
async def get_active_profile(request: Request):
    """Return the currently active profile and its mappings, or null."""
    _require_auth(request)  # SECURITY 2026-08-17
    db = _require_db()
    # BF-NONBLOCK-AUDIT-5: 2 sequential DB calls — single thread block.
    def _inner():
        profile = db.get_active_profile()
        if not profile:
            return {"profile": None, "mappings": []}
        return {"profile": profile,
                "mappings": db.get_profile_mappings(profile["id"])}
    return await asyncio.to_thread(_inner)


@router.post("/api/connection-profiles")
async def create_connection_profile(req: CreateProfileRequest, request: Request):
    """Create a new connection profile (admin only)."""
    _require_admin(request)
    db = _require_db()
    user = _get_user(request)
    profile = await _adb(db.create_connection_profile,
        name=req.name,
        description=req.description,
        is_active=False,
        created_by=user.get("username"),
    )
    return profile


@router.put("/api/connection-profiles/{profile_id}")
async def update_connection_profile(profile_id: int, req: UpdateProfileRequest, request: Request):
    """Update a profile's name or description (admin only)."""
    _require_admin(request)
    db = _require_db()
    updates = req.model_dump(exclude_none=True)
    if not updates:
        raise HTTPException(400, "No fields to update")
    result = await _adb(db.update_connection_profile, profile_id, **updates)
    if not result:
        raise HTTPException(404, f"Profile {profile_id} not found")
    return result


@router.delete("/api/connection-profiles/{profile_id}")
async def delete_connection_profile(profile_id: int, request: Request):
    """Delete a profile and all its mappings (admin only)."""
    _require_admin(request)
    db = _require_db()
    ok = await _adb(db.delete_connection_profile, profile_id)
    if not ok:
        raise HTTPException(404, f"Profile {profile_id} not found")
    return {"deleted": True}


@router.post("/api/connection-profiles/{profile_id}/activate")
async def activate_connection_profile(profile_id: int, request: Request):
    """Activate this profile (deactivates all others). Admin only."""
    _require_admin(request)
    db = _require_db()
    def _inner():
        if not db.activate_connection_profile(profile_id):
            return None
        return db.get_active_profile()
    profile = await asyncio.to_thread(_inner)
    if profile is None:
        raise HTTPException(404, f"Profile {profile_id} not found")
    return {"activated": True, "profile": profile}


@router.post("/api/connection-profiles/deactivate")
async def deactivate_all_profiles(request: Request):
    """Clear the active profile (no-profile mode). Admin only."""
    _require_admin(request)
    db = _require_db()
    await _adb(db.deactivate_all_profiles)
    return {"deactivated": True}


@router.get("/api/connection-profiles/{profile_id}/mappings")
async def get_profile_mappings(profile_id: int, request: Request):
    """List all connection mappings for a profile.

    Admin-gated: this is the connection redirection map, and its sibling PUT
    is already admin-only.  A read that discloses what the write configures
    belongs at the same level.
    """
    _require_admin(request)  # SECURITY 2026-08-17
    db = _require_db()
    return {"mappings": await _adb(db.get_profile_mappings, profile_id)}


@router.put("/api/connection-profiles/{profile_id}/mappings")
async def set_profile_mappings(profile_id: int, req: SetMappingsRequest, request: Request):
    """Replace all mappings for a profile atomically (admin only)."""
    _require_admin(request)
    db = _require_db()
    mappings = [m.model_dump() for m in req.mappings]
    result = await _adb(db.set_profile_mappings, profile_id, mappings)
    return {"mappings": result}
