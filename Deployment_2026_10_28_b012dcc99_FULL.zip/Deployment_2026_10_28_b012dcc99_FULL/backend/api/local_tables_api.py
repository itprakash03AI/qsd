"""
Local Tables API — CRUD, file upload/promote, preview, profile, and table favorites.

Extracted from main.py (Phase 29 enterprise refactoring).

Initialization:
    Call ``set_local_table_dependencies(...)`` once at startup (in main.py after
    all core components are created).

Endpoints:
  GET    /api/local-tables                    — list local tables
  GET    /api/local-tables/storage            — disk usage stats (admin/analyst)
  GET    /api/local-tables/{lt_id}            — get single local table
  POST   /api/local-tables                    — create local table record
  PUT    /api/local-tables/{lt_id}            — update local table
  DELETE /api/local-tables/{lt_id}            — delete local table + storage
  POST   /api/local-tables/promote            — promote download file → local table
  POST   /api/local-tables/upload             — upload CSV/Excel/JSON/Parquet file
  GET    /api/local-tables/{lt_id}/schema     — read parquet schema

  POST   /api/tables/preview                  — preview first N rows of any table type
  POST   /api/tables/profile                  — column-level stats
  POST   /api/tables/favorite                 — toggle table favorite
  GET    /api/tables/favorites                — list favorites for current user
"""
from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime, timezone
from typing import Optional

from fastapi import APIRouter, Body, Depends, HTTPException, Query as FastQuery, Request
from pydantic import BaseModel, Field

from api.deps import get_current_user, require_role, get_workspace_id
from core.audit import audit_event
from core.parquet_utils import read_resolved_schema
from core.db_async import adb

logger = logging.getLogger(__name__)

router = APIRouter(tags=["Local Tables"])

# ── Module-level singletons — populated by set_local_table_dependencies() ────

_db_manager = None
_engine = None
_ws_manager = None
_lt_cfg = None
_mv_cfg = None
_paths = None
_light_executor = None


def set_local_table_dependencies(db_manager, engine, ws_manager, lt_cfg, mv_cfg, paths,
                                  light_executor=None) -> None:
    """Called once from main.py after all core components are created."""
    global _db_manager, _engine, _ws_manager, _lt_cfg, _mv_cfg, _paths, _light_executor
    _db_manager = db_manager
    _engine = engine
    _ws_manager = ws_manager
    _lt_cfg = lt_cfg
    _mv_cfg = mv_cfg
    _paths = paths
    _light_executor = light_executor


def _get_light_executor():
    """Return the dedicated streaming/metadata executor (injected at startup)."""
    return _light_executor


# ── Pydantic models ────────────────────────────────────────────────────────────

class LocalTableCreateModel(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    description: Optional[str] = None
    visibility: str = "public"
    auto_discard_days: int = 10


class LocalTableUpdateModel(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    visibility: Optional[str] = None
    auto_discard_days: Optional[int] = None
    is_active: Optional[bool] = None


class LocalTablePromoteModel(BaseModel):
    file_id: str
    name: str = Field(min_length=1, max_length=255)
    description: Optional[str] = None
    visibility: str = "public"
    auto_discard_days: int = 10


# ── Sync helper functions ──────────────────────────────────────────────────────

def _promote_download_sync(lt_id: int, source_path: str, username: str = "unknown"):
    """Copy a download parquet file into local table storage and read metadata."""
    import shutil
    import pyarrow.parquet as _pq

    lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt_id))
    os.makedirs(lt_dir, exist_ok=True)

    try:
        # Copy parquet file (don't move — keeps download intact)
        dest = os.path.join(lt_dir, "data.parquet")
        shutil.copy2(source_path, dest)

        # Read schema + metadata
        pf = _pq.ParquetFile(dest)
        row_count = pf.metadata.num_rows
        size_bytes = os.path.getsize(dest)
        schema_cols = read_resolved_schema(dest)

        _db_manager.update_local_table(
            lt_id,
            status="ready",
            row_count=row_count,
            file_count=1,
            size_bytes=size_bytes,
            schema_json=schema_cols,
            last_accessed_at=datetime.now(timezone.utc),
        )
        logger.info("Local table %d promoted successfully: %d rows, %d bytes", lt_id, row_count, size_bytes)
        try:
            _ws_manager.broadcast_to_user_sync(username, {"type": "local_table_ready", "id": lt_id, "status": "ready", "row_count": row_count, "username": username})
        except Exception as e:
            logger.error("WebSocket broadcast failed after local table %d promote: %s", lt_id, e, exc_info=True)
    except Exception as e:
        logger.error("Local table promote failed for %d: %s", lt_id, e, exc_info=True)
        _db_manager.update_local_table(lt_id, status="failed", last_error=str(e))
        try:
            _ws_manager.broadcast_to_user_sync(username, {"type": "local_table_failed", "id": lt_id, "error": str(e), "username": username})
        except Exception as ws_exc:
            logger.error("WebSocket broadcast failed after local table %d promote error: %s", lt_id, ws_exc, exc_info=True)


def _upload_file_to_local_table_sync(lt_id: int, temp_path: str, original_filename: str,
                                      sheet_name: str = None, username: str = "unknown"):
    """Convert uploaded file (CSV/Excel/JSON/Parquet) to local parquet."""
    from core.file_formats import get_format_adapter

    lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt_id))
    os.makedirs(lt_dir, exist_ok=True)
    dest = os.path.join(lt_dir, "data.parquet")
    ext = os.path.splitext(original_filename)[1].lower()

    try:
        adapter = get_format_adapter(ext)
        if not adapter.needs_duckdb:
            # Parquet: direct file copy, no DuckDB needed
            adapter.convert_to_parquet(temp_path, dest, duckdb_con=None, sheet=sheet_name)
        else:
            from core.duckdb_factory import duckdb_connection
            with duckdb_connection() as con:
                adapter.convert_to_parquet(temp_path, dest, con, sheet=sheet_name)

        # Read final parquet metadata
        import pyarrow.parquet as pq
        pf = pq.ParquetFile(dest)
        row_count = pf.metadata.num_rows
        size_bytes = os.path.getsize(dest)
        schema_cols = read_resolved_schema(dest)

        _db_manager.update_local_table(
            lt_id,
            status="ready",
            row_count=row_count,
            file_count=1,
            size_bytes=size_bytes,
            schema_json=schema_cols,
            last_accessed_at=datetime.now(timezone.utc),
        )
        logger.info("Local table %d uploaded successfully: %d rows, %d bytes", lt_id, row_count, size_bytes)
        try:
            _ws_manager.broadcast_to_user_sync(username, {"type": "local_table_ready", "id": lt_id, "status": "ready", "row_count": row_count, "username": username})
        except Exception as e:
            logger.error("WebSocket broadcast failed after local table %d upload: %s", lt_id, e, exc_info=True)

        # Phase 120: Data Pipeline Agent — profile uploaded file
        try:
            from core.agents import get_orchestrator as _get_orch
            _orch = _get_orch()
            if _orch and _orch.enabled:
                _agent_result = _orch.handle_event("file_uploaded", {
                    "file_path": dest,
                    "table_name": original_filename,
                    "local_table_id": lt_id,
                    "row_count": row_count,
                    "size_bytes": size_bytes,
                })
                # handle_event returns {"metadata": {"issues": [...]}} for NOTIFY_USER
                _agent_issues = (_agent_result or {}).get("metadata", {}).get("issues", [])
                if _agent_issues:
                    _ws_manager.broadcast_to_user_sync(username, {
                        "type": "agent_suggestion",
                        "agent": "data_pipeline",
                        "local_table_id": lt_id,
                        "table_name": original_filename,
                        "issues": _agent_issues,
                        "reason": _agent_result.get("reason", ""),
                        "username": username,
                    })
        except Exception as _agent_exc:
            logger.debug("Agent hook failed (non-fatal): %s", _agent_exc)
    except Exception as e:
        logger.error("Local table upload failed for %d: %s", lt_id, e, exc_info=True)
        _db_manager.update_local_table(lt_id, status="failed", last_error=str(e))
        try:
            _ws_manager.broadcast_to_user_sync(username, {"type": "local_table_failed", "id": lt_id, "error": str(e), "username": username})
        except Exception as ws_exc:
            logger.error("WebSocket broadcast failed after local table %d upload error: %s", lt_id, ws_exc, exc_info=True)
    finally:
        # Cleanup temp file
        try:
            os.unlink(temp_path)
        except Exception as e:
            logger.error("Failed to cleanup temp file %s: %s", temp_path, e, exc_info=True)


def _append_file_to_local_table_sync(lt_id: int, temp_path: str, original_filename: str,
                                      sheet_name: str = None, username: str = "unknown"):
    """Append an uploaded file to an existing local table as a new parquet part."""
    import glob as _glob_mod
    from core.file_formats import get_format_adapter

    lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt_id))
    os.makedirs(lt_dir, exist_ok=True)
    ext = os.path.splitext(original_filename)[1].lower()

    # Determine next part index
    existing = sorted(_glob_mod.glob(os.path.join(lt_dir, "*.parquet")))
    # Support both 'data.parquet' (old) and 'part_NNNN.parquet' names
    next_idx = len(existing)
    dest = os.path.join(lt_dir, f"part_{next_idx:04d}.parquet")

    try:
        adapter = get_format_adapter(ext)
        if not adapter.needs_duckdb:
            adapter.convert_to_parquet(temp_path, dest, duckdb_con=None, sheet=sheet_name)
        else:
            from core.duckdb_factory import duckdb_connection
            with duckdb_connection() as con:
                adapter.convert_to_parquet(temp_path, dest, con, sheet=sheet_name)

        # Recount all parts
        import pyarrow.parquet as pq
        all_parts = sorted(_glob_mod.glob(os.path.join(lt_dir, "*.parquet")))
        total_rows = 0
        total_size = 0
        for p in all_parts:
            pf = pq.ParquetFile(p)
            total_rows += pf.metadata.num_rows
            total_size += os.path.getsize(p)

        # Schema from first file
        schema_cols = []
        if all_parts:
            schema_cols = read_resolved_schema(all_parts[0])

        _db_manager.update_local_table(
            lt_id,
            status="ready",
            row_count=total_rows,
            file_count=len(all_parts),
            size_bytes=total_size,
            schema_json=schema_cols,
            last_accessed_at=datetime.now(timezone.utc),
        )
        logger.info("Local table %d append: %d rows appended, total %d rows", lt_id, pq.ParquetFile(dest).metadata.num_rows, total_rows)
        try:
            _ws_manager.broadcast_to_user_sync(username, {"type": "local_table_ready", "id": lt_id, "status": "ready", "row_count": total_rows, "username": username})
        except Exception as e:
            logger.error("WebSocket broadcast failed after local table %d append: %s", lt_id, e, exc_info=True)

        # Phase 120: Data Pipeline Agent — profile appended file
        try:
            from core.agents import get_orchestrator as _get_orch
            _orch = _get_orch()
            if _orch and _orch.enabled:
                _agent_result = _orch.handle_event("file_uploaded", {
                    "file_path": dest,
                    "table_name": original_filename,
                    "local_table_id": lt_id,
                    "row_count": total_rows,
                    "size_bytes": total_size,
                })
                # handle_event returns {"metadata": {"issues": [...]}} for NOTIFY_USER
                _agent_issues = (_agent_result or {}).get("metadata", {}).get("issues", [])
                if _agent_issues:
                    _ws_manager.broadcast_to_user_sync(username, {
                        "type": "agent_suggestion",
                        "agent": "data_pipeline",
                        "local_table_id": lt_id,
                        "table_name": original_filename,
                        "issues": _agent_issues,
                        "reason": _agent_result.get("reason", ""),
                        "username": username,
                    })
        except Exception as _agent_exc:
            logger.debug("Agent hook failed (non-fatal): %s", _agent_exc)
    except Exception as e:
        logger.error("Local table append failed for %d: %s", lt_id, e, exc_info=True)
        _db_manager.update_local_table(lt_id, status="failed", last_error=str(e))
        try:
            _ws_manager.broadcast_to_user_sync(username, {"type": "local_table_failed", "id": lt_id, "error": str(e), "username": username})
        except Exception as ws_exc:
            logger.error("WebSocket broadcast failed after local table %d append error: %s", lt_id, ws_exc, exc_info=True)
    finally:
        try:
            os.unlink(temp_path)
        except Exception as e:
            logger.error("Failed to cleanup temp file %s: %s", temp_path, e, exc_info=True)


def _cleanup_expired_local_tables():
    """Auto-discard public local tables unused beyond their auto_discard_days."""
    import shutil
    expired = _db_manager.list_expired_local_tables()
    count = 0
    for lt in expired:
        try:
            lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt["id"]))
            if os.path.isdir(lt_dir):
                shutil.rmtree(lt_dir)
            _db_manager.delete_local_table(lt["id"])
            count += 1
            logger.info("Auto-discarded local table %d (%s) — unused for %d+ days",
                        lt["id"], lt["name"], lt["auto_discard_days"])
        except Exception as e:
            logger.warning("Failed to discard local table %d: %s", lt["id"], e, exc_info=True)
    if count > 0:
        try:
            _ws_manager.broadcast_sync({"type": "local_tables_cleanup", "discarded_count": count})
        except Exception as e:
            logger.error("WebSocket broadcast failed after local tables cleanup: %s", e, exc_info=True)
        logger.info("Auto-discard cleaned up %d expired local tables", count)


# ── Table resolver helper ──────────────────────────────────────────────────────

def _resolve_table_duckdb_sql(table_path: str, connection_id: int = None) -> tuple:
    """Resolve a table_path to a DuckDB-compatible FROM clause + optional DuckDB connection.

    Returns (from_clause: str, con: duckdb.Connection | None, needs_close: bool).
    If con is returned, caller must close it.
    """

    if table_path.startswith("__materialized__:"):
        mv_name = table_path.replace("__materialized__:", "")
        mv_rec = _db_manager.get_materialized_view_by_name(mv_name)
        if not mv_rec or mv_rec["status"] != "ready":
            raise ValueError(f"Materialized view '{mv_name}' not found or not ready")
        mv_dir = os.path.join(_mv_cfg.storage_dir, str(mv_rec["id"]))
        import glob as _gm
        pq_files = _gm.glob(os.path.join(mv_dir, "*.parquet"))
        if not pq_files:
            raise ValueError(f"No parquet files for MV '{mv_name}'")
        from core.path_utils import to_duckdb_path as _to_ddb_lt
        paths_str = ", ".join(f"'{_to_ddb_lt(p)}'" for p in pq_files)
        return f"read_parquet([{paths_str}], hive_partitioning=true)", None, False

    if table_path.startswith("__local__:"):
        lt_name = table_path.replace("__local__:", "")
        lt_rec = _db_manager.get_local_table_by_name(lt_name)
        if not lt_rec or lt_rec["status"] != "ready":
            raise ValueError(f"Local table '{lt_name}' not found or not ready")
        lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt_rec["id"]))
        import glob as _gm2
        pq_files = _gm2.glob(os.path.join(lt_dir, "*.parquet"))
        if not pq_files:
            raise ValueError(f"No parquet files for local table '{lt_name}'")
        from core.path_utils import to_duckdb_path as _to_ddb_lt
        paths_str = ", ".join(f"'{_to_ddb_lt(p)}'" for p in pq_files)
        return f"read_parquet([{paths_str}], hive_partitioning=true)", None, False

    if table_path.startswith("__registered__:"):
        reg_name = table_path.replace("__registered__:", "")
        if not connection_id:
            raise ValueError("connection_id required for registered table preview")
        conn_record = _db_manager.get_connection_raw(connection_id)
        if not conn_record:
            raise ValueError(f"Connection {connection_id} not found")
        cfg = conn_record.get("config", {})
        registered_tables = cfg.get("registered_tables", [])
        tdef = None
        for t in registered_tables:
            if t["name"] == reg_name:
                tdef = t
                break
        if not tdef:
            raise ValueError(f"Registered table '{reg_name}' not found in connection")
        from api.data_grid_api import _duckdb_con_with_s3
        con = _duckdb_con_with_s3(cfg, connection_id=connection_id)
        fmt = tdef.get("format", "parquet")
        prefix = tdef["s3_prefix"].rstrip("/")
        bucket = cfg["bucket_name"]
        if fmt == "iceberg":
            from core.s3_utilities import get_s3_access_mode as _lt_get_s3_mode
            if _lt_get_s3_mode(cfg) == "presigned":
                raise RuntimeError(
                    "Iceberg format is not supported for on-prem S3 local tables. "
                    "Use parquet format instead (iceberg_scan requires DuckDB native S3 auth "
                    "which conflicts with on-prem pre-signed URL flow)."
                )
            from_clause = f"iceberg_scan('s3://{bucket}/{prefix}')"
        elif fmt == "csv":
            if _lt_get_s3_mode(cfg) == "presigned":
                from core.s3_utilities import list_s3_csv_files as _lt_list_csv, s3_urls_to_presigned as _lt_presign_csv, make_s3_client_for_conn as _lt_make_s3_csv
                _lt_s3_csv = _lt_make_s3_csv({"id": connection_id, "config": cfg})
                _lt_csv_files = _lt_list_csv(_lt_s3_csv, bucket, prefix)
                if not _lt_csv_files:
                    raise RuntimeError(f"No CSV files found for '{reg_name}' on on-prem S3 under s3://{bucket}/{prefix}/")
                _lt_csv_files = _lt_presign_csv(_lt_s3_csv, _lt_csv_files, cfg)
                _lt_esc_csv = lambda v: v.replace("'", "''")
                _lt_csv_paths = ", ".join(f"'{_lt_esc_csv(f)}'" for f in _lt_csv_files)
                from_clause = f"read_csv_auto([{_lt_csv_paths}])"
            else:
                from_clause = f"read_csv_auto('s3://{bucket}/{prefix}/**/*.csv')"
        else:
            # Presigned mode: glob crashes DuckDB — use boto3 pre-listing + pre-signed URLs
            if _lt_get_s3_mode(cfg) == "presigned":
                from core.s3_utilities import list_s3_parquet_files as _lt_list, s3_urls_to_presigned as _lt_presign, make_s3_client_for_conn as _lt_make_s3
                _lt_s3 = _lt_make_s3({"id": connection_id, "config": cfg})
                _lt_files = _lt_list(_lt_s3, bucket, prefix)
                if not _lt_files:
                    raise RuntimeError(
                        f"No parquet files found for '{reg_name}' on on-prem S3 under s3://{bucket}/{prefix}/"
                    )
                _lt_files = _lt_presign(_lt_s3, _lt_files, cfg)
                _lt_esc = lambda v: v.replace("'", "''")
                _lt_paths = ", ".join(f"'{_lt_esc(f)}'" for f in _lt_files)
                from_clause = f"read_parquet([{_lt_paths}], hive_partitioning=true, union_by_name=true)"
            else:
                from_clause = f"read_parquet('s3://{bucket}/{prefix}/**/*.parquet', hive_partitioning=true)"
        return from_clause, con, True

    # Raw file path — local parquet, csv, excel, json, etc.
    norm = table_path.replace("\\", "/")
    from core.file_formats import get_format_adapter, is_supported_extension, parse_sheet_from_path
    norm, _sheet = parse_sheet_from_path(norm)
    import os as _rp_os
    _rp_ext = _rp_os.path.splitext(norm)[1].lower()
    if _rp_ext and _rp_ext != ".parquet":
        if is_supported_extension(_rp_ext):
            return get_format_adapter(_rp_ext).duckdb_read_expr(norm, sheet=_sheet), None, False
    # Default: parquet with hive partitioning (local path or extensionless)
    return f"read_parquet('{norm}', hive_partitioning=true)", None, False


# ── Local Table CRUD endpoints ────────────────────────────────────────────────

@router.get("/api/local-tables")
async def list_local_tables(visibility: Optional[str] = None,
                            created_by: Optional[str] = None,
                            request: Request = None,
                            _user: dict = Depends(get_current_user)):
    workspace_id = get_workspace_id(request) if request else None
    return await adb(_db_manager.list_local_tables, visibility=visibility, created_by=created_by,
                                          workspace_id=workspace_id)


@router.get("/api/local-tables/storage")
async def local_tables_storage(_user: dict = Depends(require_role("admin", "analyst"))):
    """Disk usage stats for local tables."""
    tables = await adb(_db_manager.list_local_tables, active_only=False)
    total_bytes = sum(lt.get("size_bytes", 0) for lt in tables)
    return {
        "total_tables": len(tables),
        "max_tables": _lt_cfg.max_tables,
        "total_size_bytes": total_bytes,
        "max_size_bytes": _lt_cfg.max_size_mb * 1024 * 1024,
        "storage_dir": _lt_cfg.storage_dir,
    }


@router.get("/api/local-tables/{lt_id}")
async def get_local_table(lt_id: int, _user: dict = Depends(get_current_user)):
    lt = await adb(_db_manager.get_local_table, lt_id)
    if not lt:
        raise HTTPException(404, "Local table not found")
    return lt


@router.post("/api/local-tables")
async def create_local_table(body: LocalTableCreateModel,
                             request: Request = None,
                             _user: dict = Depends(require_role("admin", "analyst"))):
    # Check limits
    existing = await adb(_db_manager.list_local_tables)
    if len(existing) >= _lt_cfg.max_tables:
        raise HTTPException(400, f"Maximum local tables ({_lt_cfg.max_tables}) reached")
    if await adb(_db_manager.get_local_table_by_name, body.name):
        raise HTTPException(400, f"Local table '{body.name}' already exists")

    username = _user.get("username", "unknown") if _user else "unknown"
    workspace_id = get_workspace_id(request) if request else None
    lt = await adb(_db_manager.create_local_table, 
        name=body.name,
        description=body.description,
        source_type="manual_create",
        visibility=body.visibility,
        auto_discard_days=body.auto_discard_days,
        storage_path=os.path.join(_lt_cfg.storage_dir, "placeholder"),
        created_by=username,
        status="pending",
        workspace_id=workspace_id,
    )
    # Update storage_path with actual ID
    await adb(_db_manager.update_local_table, lt["id"], storage_path=os.path.join(_lt_cfg.storage_dir, str(lt["id"])))
    return {**lt, "storage_path": os.path.join(_lt_cfg.storage_dir, str(lt["id"]))}


@router.put("/api/local-tables/{lt_id}")
async def update_local_table(lt_id: int, body: LocalTableUpdateModel,
                             _user: dict = Depends(require_role("admin", "analyst"))):
    lt = await adb(_db_manager.get_local_table, lt_id)
    if not lt:
        raise HTTPException(404, "Local table not found")

    updates = body.dict(exclude_unset=True)
    if "name" in updates and updates["name"] != lt["name"]:
        if await adb(_db_manager.get_local_table_by_name, updates["name"]):
            raise HTTPException(400, f"Local table '{updates['name']}' already exists")

    result = await adb(_db_manager.update_local_table, lt_id, **updates)
    return result


@router.delete("/api/local-tables/{lt_id}")
async def delete_local_table(lt_id: int,
                             _user: dict = Depends(require_role("admin", "analyst"))):
    lt = await adb(_db_manager.get_local_table, lt_id)
    if not lt:
        raise HTTPException(404, "Local table not found")

    import shutil
    lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt_id))
    if os.path.isdir(lt_dir):
        shutil.rmtree(lt_dir)

    await adb(_db_manager.delete_local_table, lt_id)
    try:
        _username = _user.get("username", "unknown") if _user else "unknown"
        _ws_manager.broadcast_to_user_sync(_username, {"type": "local_table_deleted", "id": lt_id, "name": lt["name"], "username": _username})
    except Exception as e:
        logger.error("WebSocket broadcast failed after local table %d delete: %s", lt_id, e, exc_info=True)
    audit_event(_db_manager, _user, None, "delete_local_table", "local_table", lt_id)
    return {"status": "deleted", "id": lt_id}


@router.post("/api/local-tables/promote")
async def promote_to_local_table(body: LocalTablePromoteModel,
                                 request: Request = None,
                                 _user: dict = Depends(require_role("admin", "analyst"))):
    """Promote a download file to a local table (copies parquet)."""
    # Check limits
    existing = await adb(_db_manager.list_local_tables)
    if len(existing) >= _lt_cfg.max_tables:
        raise HTTPException(400, f"Maximum local tables ({_lt_cfg.max_tables}) reached")
    if await adb(_db_manager.get_local_table_by_name, body.name):
        raise HTTPException(400, f"Local table '{body.name}' already exists")

    # Find the download file
    dl = await adb(_db_manager.get_download_file, body.file_id)
    if not dl:
        raise HTTPException(404, f"Download file '{body.file_id}' not found")
    # SECURITY 2026-08-30: this route read a file_id and COPIED the file
    # into a local table with no ownership check at all — only
    # require_role("admin","analyst").  Proven by execution: an analyst
    # who does not own the export promoted it into a visibility="public"
    # table, publishing rows another principal's row-security scope had
    # filtered.  Every other reader of these rows goes through
    # _enforce_download_ownership; this one bypassed it entirely, which
    # made the Download Centre's whole visibility rule optional.
    #
    # allow_service=False for the same reason the Download Centre uses
    # it: the caller is an ordinary QueryStudio user, not the token
    # consumer a published-view/embed execution was run for.
    from api.data_grid_api import _enforce_download_ownership
    await adb(_enforce_download_ownership, dl, _user, allow_service=False)
    # ...and do not promote something already retired: the Download
    # Centre refuses to serve it, so copying it into a new table would
    # be a way around the retention that retired it.
    from core.download_retention import download_refusal
    _refusal = download_refusal(dl)
    if _refusal:
        raise HTTPException(410, _refusal)
    if not dl.get("file_path", "").endswith(".parquet"):
        raise HTTPException(400, "Only parquet files can be promoted to local tables")
    source_path = dl["file_path"]
    if not os.path.isfile(source_path):
        raise HTTPException(400, "Download file no longer exists on disk")

    username = _user.get("username", "unknown") if _user else "unknown"
    workspace_id = get_workspace_id(request) if request else None
    lt = await adb(_db_manager.create_local_table, 
        name=body.name,
        description=body.description,
        source_type="download_promote",
        source_file_id=body.file_id,
        original_filename=dl.get("filename", ""),
        visibility=body.visibility,
        auto_discard_days=body.auto_discard_days,
        storage_path=os.path.join(_lt_cfg.storage_dir, "placeholder"),
        created_by=username,
        status="processing",
        workspace_id=workspace_id,
    )
    await adb(_db_manager.update_local_table, lt["id"], storage_path=os.path.join(_lt_cfg.storage_dir, str(lt["id"])))

    loop = asyncio.get_running_loop()
    loop.run_in_executor(None, _promote_download_sync, lt["id"], source_path, username)
    return {**lt, "status": "processing"}


@router.post("/api/local-tables/excel-sheets")
async def list_excel_sheets_from_upload(request: Request,
                                        _user: dict = Depends(require_role("admin", "analyst"))):
    """List worksheet names from an uploaded Excel file."""
    form = await request.form()
    file = form.get("file")
    if not file:
        raise HTTPException(400, "No file provided")

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in (".xlsx", ".xls"):
        raise HTTPException(400, "Only Excel files (.xlsx, .xls) have worksheets")

    import tempfile
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=ext, dir=str(_paths.data_dir))
    try:
        while True:
            chunk = await file.read(1024 * 1024)
            if not chunk:
                break
            tmp.write(chunk)
        tmp.close()

        import pandas as pd
        xls = pd.ExcelFile(tmp.name)
        sheets = xls.sheet_names
        xls.close()
        return {"sheets": sheets, "filename": file.filename}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Failed to read Excel sheets: {e}")
    finally:
        try:
            os.unlink(tmp.name)
        except Exception:
            pass


@router.get("/api/local-tables/excel-sheets")
async def list_excel_sheets_by_path(file_path: str = FastQuery(..., description="Local/NFS path to Excel file"),
                                     _user: dict = Depends(get_current_user)):
    """List worksheet names from a local/NFS Excel file path."""
    ext = os.path.splitext(file_path)[1].lower()
    if ext not in (".xlsx", ".xls"):
        raise HTTPException(400, "Only Excel files (.xlsx, .xls) have worksheets")

    # BF-147: Path traversal guard — restrict to data directory
    if _paths:
        _resolved = os.path.realpath(file_path)
        _base = os.path.realpath(str(_paths.data_dir))
        if not _resolved.startswith(_base + os.sep) and _resolved != _base:
            raise HTTPException(403, "Path outside allowed directory")

    if not os.path.isfile(file_path):
        raise HTTPException(404, f"File not found: {file_path}")

    try:
        import pandas as pd
        xls = pd.ExcelFile(file_path)
        sheets = xls.sheet_names
        xls.close()
        return {"sheets": sheets, "filename": os.path.basename(file_path)}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(500, f"Failed to read Excel sheets: {e}")


@router.post("/api/local-tables/upload")
async def upload_local_table(request: Request,
                             _user: dict = Depends(require_role("admin", "analyst"))):
    """Upload a file (CSV/Excel/JSON/Parquet/.dat) and create a local table."""
    # Early size rejection before buffering the entire body
    content_length = request.headers.get("content-length")
    if content_length:
        try:
            if int(content_length) > _lt_cfg.max_upload_size_bytes + 65536:  # 64KB overhead for form boundaries
                raise HTTPException(400, f"File exceeds max upload size ({_lt_cfg.max_upload_size_mb} MB)")
        except (ValueError, TypeError):
            pass

    form = await request.form()
    file = form.get("file")
    if not file:
        raise HTTPException(400, "No file provided")

    name = form.get("name", "").strip()
    if not name:
        name = os.path.splitext(file.filename)[0]
    description = form.get("description", "").strip() or None
    visibility = form.get("visibility", "public").strip()
    auto_discard_days = int(form.get("auto_discard_days", "10"))
    sheet_name = form.get("sheet_name", "").strip() or None

    # Check limits
    existing = await adb(_db_manager.list_local_tables)
    if len(existing) >= _lt_cfg.max_tables:
        raise HTTPException(400, f"Maximum local tables ({_lt_cfg.max_tables}) reached")
    if await adb(_db_manager.get_local_table_by_name, name):
        raise HTTPException(400, f"Local table '{name}' already exists")

    # Validate extension
    ext = os.path.splitext(file.filename)[1].lower()
    allowed = {".csv", ".tsv", ".txt", ".dat", ".xlsx", ".xls", ".json", ".parquet"}
    if ext not in allowed:
        raise HTTPException(400, f"Unsupported file type: {ext}. Allowed: {', '.join(sorted(allowed))}")

    # Save to temp file
    import tempfile
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=ext, dir=str(_paths.data_dir))
    size = 0
    try:
        while True:
            chunk = await file.read(1024 * 1024)  # 1MB chunks
            if not chunk:
                break
            size += len(chunk)
            if size > _lt_cfg.max_upload_size_bytes:
                tmp.close()
                os.unlink(tmp.name)
                raise HTTPException(400, f"File exceeds max upload size ({_lt_cfg.max_upload_size_mb} MB)")
            tmp.write(chunk)
        tmp.close()
    except HTTPException:
        raise
    except Exception as e:
        tmp.close()
        try:
            os.unlink(tmp.name)
        except Exception as cleanup_exc:
            logger.error("Failed to cleanup temp file %s after upload error: %s", tmp.name, cleanup_exc, exc_info=True)
        raise HTTPException(500, f"Failed to save upload: {e}")

    username = _user.get("username", "unknown") if _user else "unknown"
    workspace_id = get_workspace_id(request)
    lt = await adb(_db_manager.create_local_table, 
        name=name,
        description=description,
        source_type="file_upload",
        original_filename=file.filename,
        visibility=visibility,
        auto_discard_days=auto_discard_days,
        storage_path=os.path.join(_lt_cfg.storage_dir, "placeholder"),
        created_by=username,
        status="processing",
        workspace_id=workspace_id,
    )
    await adb(_db_manager.update_local_table, lt["id"], storage_path=os.path.join(_lt_cfg.storage_dir, str(lt["id"])))

    loop = asyncio.get_running_loop()
    loop.run_in_executor(None, _upload_file_to_local_table_sync, lt["id"], tmp.name, file.filename, sheet_name, username)
    return {**lt, "status": "processing"}


@router.post("/api/local-tables/{lt_id}/append")
async def append_to_local_table(lt_id: int, request: Request,
                                _user: dict = Depends(require_role("admin", "analyst"))):
    """Append rows to an existing local table by uploading a file."""
    lt = await adb(_db_manager.get_local_table, lt_id)
    if not lt:
        raise HTTPException(404, "Local table not found")
    if lt["status"] not in ("ready", "failed"):
        raise HTTPException(400, f"Local table is not in a state that allows appending (status: {lt['status']})")

    # Early size rejection
    content_length = request.headers.get("content-length")
    if content_length:
        try:
            if int(content_length) > _lt_cfg.max_upload_size_bytes + 65536:
                raise HTTPException(400, f"File exceeds max upload size ({_lt_cfg.max_upload_size_mb} MB)")
        except (ValueError, TypeError):
            pass

    form = await request.form()
    file = form.get("file")
    if not file:
        raise HTTPException(400, "No file provided")
    sheet_name = form.get("sheet_name", "").strip() or None

    ext = os.path.splitext(file.filename)[1].lower()
    allowed = {".csv", ".tsv", ".txt", ".dat", ".xlsx", ".xls", ".json", ".parquet"}
    if ext not in allowed:
        raise HTTPException(400, f"Unsupported file type: {ext}. Allowed: {', '.join(sorted(allowed))}")

    import tempfile
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=ext, dir=str(_paths.data_dir))
    size = 0
    try:
        while True:
            chunk = await file.read(1024 * 1024)
            if not chunk:
                break
            size += len(chunk)
            if size > _lt_cfg.max_upload_size_bytes:
                tmp.close()
                os.unlink(tmp.name)
                raise HTTPException(400, f"File exceeds max upload size ({_lt_cfg.max_upload_size_mb} MB)")
            tmp.write(chunk)
        tmp.close()
    except HTTPException:
        raise
    except Exception as e:
        tmp.close()
        try:
            os.unlink(tmp.name)
        except Exception as cleanup_exc:
            logger.error("Failed to cleanup temp file %s after append upload error: %s", tmp.name, cleanup_exc, exc_info=True)
        raise HTTPException(500, f"Failed to save upload: {e}")

    await adb(_db_manager.update_local_table, lt_id, status="processing")
    _username = _user.get("username", "unknown") if _user else "unknown"
    loop = asyncio.get_running_loop()
    loop.run_in_executor(None, _append_file_to_local_table_sync, lt_id, tmp.name, file.filename, sheet_name, _username)
    return {"id": lt_id, "status": "processing", "message": "Append in progress"}


@router.get("/api/local-tables/{lt_id}/schema")
async def get_local_table_schema(lt_id: int, _user: dict = Depends(get_current_user)):
    """Read schema from local parquet files of a local table."""
    lt = await adb(_db_manager.get_local_table, lt_id)
    if not lt:
        raise HTTPException(404, "Local table not found")

    # Return cached schema if available
    if lt.get("schema_json"):
        return {"columns": lt["schema_json"], "source": lt["name"]}

    if lt["status"] != "ready":
        raise HTTPException(400, "Local table not ready")

    lt_dir = os.path.join(_lt_cfg.storage_dir, str(lt_id))
    import glob as _glob_mod
    pq_files = sorted(_glob_mod.glob(os.path.join(lt_dir, "*.parquet")))
    if not pq_files:
        raise HTTPException(400, "No parquet files found")

    try:
        columns = read_resolved_schema(pq_files[0])
        return {"columns": columns, "source": lt["name"], "file_count": len(pq_files)}
    except Exception as e:
        raise HTTPException(500, f"Failed to read schema: {e}")


# ── Table Preview / Profile / Favorites (Phase 1 UX) ─────────────────────────

def _secure_sql_for_user(sql: str, user: dict, connection_id) -> str:
    """Apply row/column security to a preview/profile SQL before it runs.

    2026-07-06 RLS FIX: these endpoints ran ``SELECT * FROM <table>`` raw, so a
    non-admin received rows/columns a policy should have removed.  secure_sql is
    a no-op when row-security is disabled, when the user is an admin, or when no
    policy matches -- so this is safe for every deployment.  FAIL-CLOSED: if
    enforcement errors, raise rather than return unfiltered rows."""
    try:
        from core.row_security.api import _is_enabled as _rs_is_enabled
        if not _rs_is_enabled():
            return sql
        from core.row_security import secure_sql as _rs_secure
        return _rs_secure(sql, dialect="duckdb", user_ctx=user,
                          connection_id=connection_id) or sql
    except HTTPException:
        raise
    except Exception as _rs_exc:
        raise HTTPException(403, f"row-security enforcement failed: {_rs_exc}")


@router.post("/api/tables/preview")
async def preview_table(body: dict = Body(...), _user: dict = Depends(get_current_user)):
    """Preview first N rows of any table type.
    Body: { table_path, connection_id (optional), limit (default 100) }
    """
    table_path = body.get("table_path")
    connection_id = body.get("connection_id")
    limit = min(body.get("limit", 100), 1000)

    if not table_path:
        raise HTTPException(400, "table_path is required")

    try:
        loop = asyncio.get_running_loop()

        def _do_preview():
            from core.duckdb_factory import duckdb_connection as _ddb_conn
            from_clause, con, needs_close = _resolve_table_duckdb_sql(table_path, connection_id)
            # RLS: secure the row-returning SELECT (no-op when RLS off/admin).
            _sel_sql = _secure_sql_for_user(
                f"SELECT * FROM {from_clause} LIMIT {limit}", _user, connection_id)
            if con:
                # Use pre-existing connection from resolver
                try:
                    result = con.execute(_sel_sql).fetchdf()
                    columns = [{"name": col, "type": str(result[col].dtype)} for col in result.columns]
                    rows = result.values.tolist()
                    try:
                        count_result = con.execute(f"SELECT COUNT(*) FROM {from_clause}").fetchone()
                        total_estimate = count_result[0] if count_result else len(rows)
                    except Exception:
                        total_estimate = len(rows)
                    return {"columns": columns, "rows": rows, "total_rows_estimate": total_estimate}
                finally:
                    if needs_close:
                        con.close()
            else:
                with _ddb_conn() as local_con:
                    result = local_con.execute(_sel_sql).fetchdf()
                    columns = [{"name": col, "type": str(result[col].dtype)} for col in result.columns]
                    rows = result.values.tolist()
                    try:
                        count_result = local_con.execute(f"SELECT COUNT(*) FROM {from_clause}").fetchone()
                        total_estimate = count_result[0] if count_result else len(rows)
                    except Exception:
                        total_estimate = len(rows)
                    return {"columns": columns, "rows": rows, "total_rows_estimate": total_estimate}

        result = await loop.run_in_executor(_get_light_executor(), _do_preview)
        return result

    except ValueError as e:
        # ValueError messages are intended for the user (validation feedback)
        raise HTTPException(400, str(e))
    except Exception as e:
        # 500 errors hide the raw exception — full trace stays in server log
        from core.error_sanitizer import sanitize_error
        logger.exception("Table preview failed")
        raise HTTPException(500, f"Preview failed: {sanitize_error(str(e))}")


@router.post("/api/tables/profile")
async def profile_table(body: dict = Body(...), _user: dict = Depends(get_current_user)):
    """Column-level stats: min, max, null_count, distinct_count.
    Body: { table_path, connection_id (optional), columns (optional list), sample_size (default 10000) }
    """
    table_path = body.get("table_path")
    connection_id = body.get("connection_id")
    requested_columns = body.get("columns")  # None = all columns
    sample_size = min(body.get("sample_size", 10000), 100000)

    if not table_path:
        raise HTTPException(400, "table_path is required")

    try:
        loop = asyncio.get_running_loop()

        def _do_profile():
            from core.duckdb_factory import duckdb_connection as _ddb_conn
            from_clause, con, needs_close = _resolve_table_duckdb_sql(table_path, connection_id)

            def _run_profile(local_con):
                schema_result = local_con.execute(
                    f"SELECT * FROM {from_clause} LIMIT 0"
                ).description
                all_columns = [(desc[0], desc[1]) for desc in schema_result]
                if requested_columns:
                    all_columns = [(n, t) for n, t in all_columns if n in requested_columns]
                # RLS: secure the sample source so per-column MIN/MAX/distinct
                # can't leak restricted cell values (no-op when RLS off/admin).
                _sample_sql = _secure_sql_for_user(
                    f"SELECT * FROM {from_clause} LIMIT {sample_size}",
                    _user, connection_id)
                sample_clause = f"({_sample_sql})"
                profiles = []
                for col_name, col_type in all_columns:
                    safe_col = f'"{col_name}"'
                    try:
                        stats = local_con.execute(f"""
                            SELECT
                                COUNT(*) as total,
                                COUNT({safe_col}) as non_null,
                                approx_count_distinct({safe_col}) as distinct_count,
                                MIN({safe_col}::VARCHAR) as min_val,
                                MAX({safe_col}::VARCHAR) as max_val
                            FROM {sample_clause}
                        """).fetchone()
                        total, non_null, distinct_count, min_val, max_val = stats
                        null_count = total - non_null
                        null_pct = round(null_count / total * 100, 1) if total > 0 else 0
                        profiles.append({
                            "name": col_name, "type": str(col_type),
                            "total": total, "null_count": null_count,
                            "null_pct": null_pct, "distinct_count": distinct_count,
                            "min": min_val, "max": max_val,
                        })
                    except Exception as col_exc:
                        profiles.append({"name": col_name, "type": str(col_type), "error": str(col_exc)})
                return {"columns": profiles, "sample_size": sample_size}

            if con:
                try:
                    return _run_profile(con)
                finally:
                    if needs_close:
                        con.close()
            else:
                with _ddb_conn() as local_con:
                    return _run_profile(local_con)

        result = await loop.run_in_executor(_get_light_executor(), _do_profile)
        return result

    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        from core.error_sanitizer import sanitize_error
        logger.exception("Table profile failed")
        raise HTTPException(500, f"Profile failed: {sanitize_error(str(e))}")


@router.post("/api/tables/favorite")
async def toggle_table_favorite(body: dict = Body(...), _user: dict = Depends(get_current_user)):
    """Toggle a table as favorite for the current user.
    Body: { table_path, table_name, connection_id (optional), table_type (optional) }
    Returns: { favorited: true/false }
    """
    table_path = body.get("table_path")
    table_name = body.get("table_name")
    connection_id = body.get("connection_id")
    table_type = body.get("table_type")

    if not table_path or not table_name:
        raise HTTPException(400, "table_path and table_name are required")

    username = _user.get("username", "guest") if _user else "guest"

    try:
        added = await adb(_db_manager.toggle_table_favorite, 
            username=username,
            table_path=table_path,
            table_name=table_name,
            connection_id=connection_id,
            table_type=table_type,
        )
        return {"favorited": added}
    except Exception as e:
        logger.error("Toggle favorite failed: %s", e, exc_info=True)
        raise HTTPException(500, f"Failed to toggle favorite: {e}")


@router.get("/api/tables/favorites")
async def list_table_favorites(connection_id: int = None, _user: dict = Depends(get_current_user)):
    """List table favorites for the current user."""
    username = _user.get("username", "guest") if _user else "guest"
    try:
        favorites = await adb(_db_manager.list_table_favorites, username=username, connection_id=connection_id)
        return {"favorites": favorites}
    except Exception as e:
        logger.error("List favorites failed: %s", e, exc_info=True)
        raise HTTPException(500, f"Failed to list favorites: {e}")
