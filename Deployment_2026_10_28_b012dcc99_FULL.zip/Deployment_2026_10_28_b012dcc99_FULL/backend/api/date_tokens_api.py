"""Date tokens — the vocabulary a picker offers and a preview of what a token
resolves to TODAY (2026-09-28).

* ``GET /api/date-tokens`` — the business-calendar tokens
  (``core.business_calendar_tokens.CALENDAR_TOKENS``), the plain shortcuts,
  the active calendars and the deployment default, so the parameter editor
  offers exactly what the resolvers accept and nothing else.
* ``GET /api/date-tokens/preview?value=`` — what ``value`` resolves to right
  now, through the SAME resolvers a run uses (``core.date_resolver
  .resolve_filter_tokens`` for every plain spelling, ``core
  .business_calendar_tokens.resolve_calendar_token`` for a calendar token),
  with the calendar used and the days skipped.  A token that cannot be
  rendered answers ``refused`` with the reason -- as a 200, because this is
  a preview and the reason IS the answer; the run itself refuses with 400.

Read-only; any signed-in user (a report viewer previews its own defaults).
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Optional

from fastapi import APIRouter, Depends, Query

from api.deps import get_current_user

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/date-tokens", tags=["date-tokens"])

_db_manager: Any = None


def set_date_tokens_dependencies(db_manager: Any) -> None:
    global _db_manager
    _db_manager = db_manager


#: The plain (calendar-naive) shortcuts, one spelling each, for the picker.
#: The @-form is what a report parameter default stores; the resolvers
#: accept the bare and ${...} forms of the same words.
PLAIN_TOKENS: tuple = (
    "@TODAY", "@YESTERDAY", "@MONTH_START", "@MONTH_END", "@YEAR_START",
    "@YEAR_END", "@LAST_7_DAYS", "@LAST_30_DAYS", "@LAST_90_DAYS",
    "@QUARTER_START", "@QUARTER_END",
)


@router.get("")
async def list_date_tokens(user: dict = Depends(get_current_user)) -> dict:
    from core.business_calendar_tokens import (
        DEFAULT_CALENDAR_CONFIG_KEY, CalendarTokenRefused, calendar_names,
        default_calendar_name, token_vocabulary,
    )
    calendars: Optional[list]
    calendars_unavailable: Optional[str] = None
    try:
        calendars = calendar_names(_db_manager)
    except CalendarTokenRefused as exc:
        calendars, calendars_unavailable = None, str(exc)
    return {
        "calendar_tokens": token_vocabulary(),
        "plain_tokens": list(PLAIN_TOKENS),
        # None = could not be listed (named below); [] = none defined.
        "calendars": calendars,
        "calendars_unavailable": calendars_unavailable,
        "default_calendar": default_calendar_name(),
        "default_calendar_config_key": DEFAULT_CALENDAR_CONFIG_KEY,
    }


def preview_token(value: str, db: Any = None) -> dict:
    """The preview body for one value (pure over the resolvers; the route
    is a shell around it so the tests can drive it directly)."""
    from core.business_calendar_tokens import (
        CalendarTokenRefused, is_calendar_token, resolve_calendar_token,
    )
    raw = str(value or "")
    out: dict = {"value": raw, "kind": "literal", "resolved": None,
                 "calendar": None, "explanation": None, "refused": None,
                 "skipped": []}
    if not raw.strip():
        return out
    if is_calendar_token(raw):
        out["kind"] = "calendar"
        try:
            res = resolve_calendar_token(
                raw, today=datetime.now(timezone.utc).date(), db=db)
        except CalendarTokenRefused as exc:
            out["refused"] = str(exc)
            return out
        out.update({"resolved": res.resolved.isoformat(),
                    "calendar": res.calendar,
                    "calendar_source": res.calendar_source,
                    "explanation": res.explanation,
                    "skipped": list(res.skipped)})
        return out
    from core.date_resolver import resolve_filter_tokens
    try:
        resolved = (resolve_filter_tokens([{"value": raw}]) or [{}])[0].get("value")
    except CalendarTokenRefused as exc:               # pragma: no cover
        out["refused"] = str(exc)
        return out
    if isinstance(resolved, str) and resolved != raw:
        out.update({"kind": "plain", "resolved": resolved,
                    "explanation": f"{resolved} = {raw} (plain calendar days)"})
    return out


@router.get("/preview")
async def preview_date_token(
        value: str = Query(..., description="the token or literal to preview"),
        user: dict = Depends(get_current_user)) -> dict:
    return preview_token(value, _db_manager)
