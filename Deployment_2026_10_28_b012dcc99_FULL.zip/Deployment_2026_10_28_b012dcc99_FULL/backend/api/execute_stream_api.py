"""
S3 Streaming execution endpoints — DuckDB httpfs direct queries.

5 endpoints:
- POST /api/execute/stream          — full streaming query
- POST /api/execute/stream/schema   — lightweight column discovery
- POST /api/execute/stream/paginate — paginated S3 streaming
- POST /api/execute/stream/chart-data — chart aggregation on S3
- POST /api/execute/stream/pivot-data — pivot aggregation on S3

Extracted from main.py for maintainability.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import threading
import time
import uuid

from fastapi import APIRouter, HTTPException, Depends, Request
from fastapi.responses import JSONResponse

from api.deps import get_current_user
from core import config as cfg
from api.models.query_models import (
    StreamQueryRequest, StreamSchemaRequest, StreamPaginateRequest,
    StreamChartRequest, StreamPivotRequest,
)
from core.query_converter import (
    convert_query_config_to_engine, translate_join_columns,
    rewrite_registered_refs,
)
from core.error_detection import jsonify_value, jsonify_rows, raise_if_s3_auth_error, classify_duckdb_error, is_connection_error
from core.s3_utilities import extract_partition_filters_from_query
from core.s3_storage import build_s3_config
from core.parquet_engine_v2 import ParquetQueryEngine
from core.duckdb_views import cleanup_temp_downloads
from core.json_utils import sanitize_for_json
from core.execution_log_buffer import with_execution_id as _with_execution_id
from core.stream_observability import (
    begin_stream_execution as _begin_stream_execution,
    set_stream_stage as _set_stream_stage,
    finalise_stream_execution as _finalise_stream_execution,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["streaming"])

# ── Module-level singletons — populated by set_stream_dependencies() ──────
_db_manager = None
_ws_manager = None
_paths = None
_qe_cfg = None
_limits_cfg = None
_register_s3_views_fn = None
_get_light_executor_fn = None


def set_stream_dependencies(db_manager, paths, qe_cfg, limits_cfg,
                            register_s3_views_fn, get_light_executor_fn,
                            ws_manager=None):
    """Call once from main.py after all components are initialised."""
    global _db_manager, _ws_manager, _paths, _qe_cfg, _limits_cfg
    global _register_s3_views_fn, _get_light_executor_fn
    _db_manager = db_manager
    _ws_manager = ws_manager
    _paths = paths
    _qe_cfg = qe_cfg
    _limits_cfg = limits_cfg
    _register_s3_views_fn = register_s3_views_fn
    _get_light_executor_fn = get_light_executor_fn


# ── BF-484 (2026-05-27) — Refuse to silently return empty rows when ───────
# CREATE VIEW failed (auth / network).  register_s3_views stamps a
# ``_qs_register_failures`` dict on the connection so the caller can
# distinguish "0 files matched the filter" (legitimately empty) from
# "CREATE VIEW failed and we lost data" (silent data loss).  Mirrors BF-474
# for the streaming path.
def _raise_if_registration_failed(con, conn_id) -> None:
    """Raise HTTPException(502) with an actionable hint when register_s3_views
    stamped one or more table failures on the connection.  No-op when the
    dict is missing (older builds) or empty (no failures).

    Status 502 (bad gateway) is appropriate: the upstream auth/network is
    broken; the request itself was well-formed.  We use HTTPException so the
    outer ``except HTTPException: raise`` branch in the streaming endpoint
    passes our actionable message through unmodified — RuntimeError would
    be re-classified by ``_raise_stream_http_error`` and the hint lost.
    """
    failures = getattr(con, "_qs_register_failures", None) or {}
    if not failures:
        return

    # BF-476 stamp on the connection takes priority — it pinpoints the
    # empty-cred cause more precisely than the generic 403 hint.
    no_creds = getattr(con, "_qs_duckdb_no_creds_reason", None)
    primary_cause = no_creds or "S3 auth failure (HTTP 403) or network error"

    _tables = ", ".join(sorted(failures.keys()))
    _first = next(iter(failures.values())) if failures else {}
    _hint = (
        f"refusing to emit empty output: register_s3_views failed for "
        f"{len(failures)} table(s) [{_tables}]. "
        f"Likely cause: {primary_cause}. "
        f"First failure: {_first.get('error_type', '?')} — "
        f"{_first.get('error_message', '')[:200]}. "
        f"Action: verify connection {conn_id} S3 credentials are valid."
    )

    # Evict the pool entry so the NEXT query gets a fresh DuckDB connection
    # with newly-resolved creds (defense-in-depth — the BF-484 refresh on
    # checkout should already cover this, but eviction prevents
    # corner-cases where the same stale token gets handed out twice).
    try:
        from api.data_grid_api import evict_s3_pool, _PooledS3Con
        if conn_id is not None:
            evict_s3_pool(conn_id)
        # Mark THIS wrapper as already-returned + close the underlying
        # DuckDB connection, so the caller's ``finally: con.close()`` does
        # NOT push the stale-cred connection back into the (now-empty)
        # pool.  Without this, the eviction is silently undone.
        if isinstance(con, _PooledS3Con):
            try:
                object.__setattr__(con, "_returned", True)
            except Exception:
                pass
            try:
                object.__getattribute__(con, "_con").close()
            except Exception:
                pass
    except Exception:
        pass

    raise HTTPException(
        status_code=502,
        detail={
            "message": _hint,
            "error_code": "S3_VIEW_REGISTRATION_FAILED",
            "failed_tables": list(failures.keys()),
        },
    )


# ── Stream Cancel Registry (Phase 72) ────────────────────────────────────
_active_streams: dict[str, threading.Event] = {}
_streams_lock = threading.Lock()


class StreamCancelledError(Exception):
    """Raised when a streaming query is cancelled by the user."""
    pass


# ── Phase 107-C: S3 detection-first guardrail helper ────────────────────
def _check_stream_s3_guardrail(*, conn_id, primary_tables, partition_filters,
                                source: str, user: dict | None) -> None:
    """Inline guardrail for streaming endpoints. Raises HTTPException 400 only
    if cfg.s3_full_scan_action == 'block'. Default action is 'log' (no-op here)."""
    try:
        from core.query_guardrails import check_s3_full_scan
        _gr = check_s3_full_scan(
            db=_db_manager,
            connection_id=conn_id,
            tables=list(primary_tables or []),
            has_partition_filter=bool(partition_filters),
            source=source,
            user=(user or {}).get("username") if isinstance(user, dict) else None,
        )
        if _gr.is_full_scan and _gr.action == "block":
            raise HTTPException(status_code=400, detail=_gr.message)
    except HTTPException:
        raise
    except Exception as e:
        logger.warning("Streaming guardrail check failed: %s", e)


def _register_stream() -> str:
    """Register a new stream and return its ID. Enforces max_active_streams."""
    stream_id = uuid.uuid4().hex[:16]
    max_streams = cfg.streaming.max_active_streams
    with _streams_lock:
        if len(_active_streams) >= max_streams:
            raise HTTPException(
                status_code=429,
                detail=f"Too many active streams ({max_streams}). Try again later.",
            )
        _active_streams[stream_id] = threading.Event()
    return stream_id


def _unregister_stream(stream_id: str):
    """Remove a stream from the registry."""
    with _streams_lock:
        _active_streams.pop(stream_id, None)


def _check_cancelled(stream_id: str):
    """Check if this stream has been cancelled; raise StreamCancelledError if so."""
    evt = _active_streams.get(stream_id)
    if evt and evt.is_set():
        raise StreamCancelledError(f"Stream {stream_id} cancelled by user")


def get_active_stream_count() -> int:
    """Return the number of currently active streams (for admin/metrics)."""
    with _streams_lock:
        return len(_active_streams)


# ── Helper: stream endpoint error → correct HTTP status code ─────────────
def _raise_stream_http_error(exc: Exception, label: str) -> None:
    """Raise HTTPException with the correct status code for a stream error (Phase 79).

    - CircuitOpenError  → 503 (service unavailable, circuit is open)
    - Connection errors → 503 (network/auth failure, not a code bug)
    - Other errors      → 500 with user-friendly DuckDB message
    """
    from core.circuit_breaker import CircuitOpenError
    if isinstance(exc, CircuitOpenError):
        logger.warning(
            "[stream] Circuit breaker OPEN — fast-failing '%s': %s (retry_after=%.0fs)",
            label, exc, getattr(exc, "retry_after", 0),
        )
        raise HTTPException(
            status_code=503,
            detail={
                "detail": f"Connection circuit breaker is open — {exc}",
                "error_code": "CIRCUIT_OPEN",
                "retry_after": getattr(exc, "retry_after", None),
            },
        )
    if is_connection_error(exc):
        from core.proxy_utils import sanitize_proxy_error as _sanitize
        logger.warning(
            "[stream] Connection unavailable for '%s' — returning 503: %s",
            label, _sanitize(str(exc))[:300],
        )
        raise HTTPException(
            status_code=503,
            detail={
                "detail": (
                    f"{label} — connection unavailable. "
                    "Use the background query mode (Run button) for stale-result fallback."
                ),
                "error_code": "CONNECTION_UNAVAILABLE",
            },
        )
    raise HTTPException(status_code=500, detail=f"{label}: {classify_duckdb_error(exc)}")


# ── Helper: fix stale EXCLUDE columns from Iceberg schema evolution ──────
def _fix_stale_excludes(con, sql: str) -> str:
    """Remove EXCLUDE columns that don't exist in actual DuckDB views.

    Handles Iceberg schema evolution: a saved query config may reference
    columns (via right_column_aliases) that have since been dropped.
    Pattern: (SELECT * EXCLUDE ("col1", "col2"), "col1" AS "a1", "col2" AS "a2" FROM "viewname")
    """
    _EXCL_PATTERN = re.compile(
        r'\(SELECT \* EXCLUDE \(([^)]+)\)'       # group 1: exclude list
        r'((?:\s*,\s*"[^"]+"\s+AS\s+"[^"]+")*)'  # group 2: rename list
        r'\s+FROM\s+"([^"]+)"\)'                  # group 3: view/table name
    )

    def _fix_match(m):
        exclude_str = m.group(1)
        renames_str = m.group(2)
        table_name = m.group(3)
        try:
            cols_result = con.execute(f'SELECT * FROM "{table_name}" LIMIT 0')
            actual_cols = {desc[0] for desc in cols_result.description}
        except Exception:
            return m.group(0)  # can't validate, leave as-is

        exclude_cols = [c.strip().strip('"') for c in exclude_str.split(',')]
        valid_excludes = [c for c in exclude_cols if c in actual_cols]

        if len(valid_excludes) == len(exclude_cols):
            return m.group(0)  # all columns exist, no change

        if not valid_excludes:
            logger.warning("Stripped all EXCLUDE columns for '%s' (schema evolution): %s",
                           table_name, exclude_cols)
            return f'(SELECT * FROM "{table_name}")'

        valid_set = set(valid_excludes)
        new_excludes = ", ".join(f'"{c}"' for c in valid_excludes)
        _REN_RE = re.compile(r'"([^"]+)"\s+AS\s+"[^"]+"')
        new_renames = [rm.group(0) for rm in _REN_RE.finditer(renames_str) if rm.group(1) in valid_set]
        renames_part = (", " + ", ".join(new_renames)) if new_renames else ""
        logger.warning("Stripped stale EXCLUDE columns for '%s': %s",
                       table_name, [c for c in exclude_cols if c not in valid_set])
        return f'(SELECT * EXCLUDE ({new_excludes}){renames_part} FROM "{table_name}")'

    return _EXCL_PATTERN.sub(_fix_match, sql)


# ── ${user.*} principal variables in editor SQL (2026-08-29) ────────────
def _render_user_vars(sql, user, label: str):
    """Render ``${user.*}`` in author-typed SQL — the REPORT renderer, on the
    editor path.

    Reports resolve ``${user.username|role|groups|is_admin|<attr>}`` at
    execution time (``core.reports.user_sql_vars`` — the ONE renderer; do not
    add a second).  The streaming editor routes did not, so the same saved
    SQL ran as a report and was a raw syntax error here.  Byte-identical
    no-op when the SQL has no ``${``.

    Rendered against the VERIFIED session user only (the ``Depends``-resolved
    dict every streaming route already passes) — never a body-supplied
    identity field.  ``None`` renders as the anonymous principal rather than
    passing tokens through: a token that one route 400s and another ships raw
    to the engine is the split-surface defect this codebase keeps paying for.

    ValueError = unknown token = authoring error → 400 with the message
    intact (it names the bad variable and the available vocabulary).

    MUST run BEFORE row security: ``secure_sql`` parses the SQL, and ``${``
    does not parse — and the cursor-session key downstream is derived from
    the rendered+secured text, so two principals whose values differ can
    never share one cursor.
    """
    if not sql or "${" not in sql:
        return sql
    from core.reports.user_sql_vars import resolve_user_sql_vars
    try:
        return resolve_user_sql_vars(sql, user, label=label)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


# ── Common helper: build inner SQL from request ─────────────────────────
def _apply_row_security(sql: str, user, conn_id, request_id=None) -> str:
    """SECURITY AUDIT 2026-08-03 (S8): single RLS chokepoint for ALL five
    streaming endpoints (stream / schema / paginate / chart-data /
    pivot-data).  Pre-fix, secure_sql ran ONLY for raw_sql and ONLY on
    /api/execute/stream — the structured query_config branch (and every
    other streaming endpoint) built SQL via get_duckdb_sql() and executed
    it with NO row/column policies applied.  Fail-CLOSED: any policy
    failure refuses the query with 403 (mirrors the previous raw_sql
    behaviour) unless row_security.fail_open is set."""
    try:
        from core.row_security import secure_sql as _rs_secure
        return _rs_secure(
            sql,
            dialect="duckdb",
            user_ctx=user,
            connection_id=conn_id,
            request_id=request_id,
        )
    except Exception as _rs_exc:
        raise HTTPException(
            status_code=403,
            detail=f"Row-security policy enforcement failed: {_rs_exc}",
        )


def _stream_body(request, inner_sql: str) -> str:
    """The statement a streaming endpoint wraps (its page LIMIT, its
    aggregation, its schema probe) -- ONE rule for all five endpoints
    (2026-10-06, ``core.statement_bounds``).

    Raw SQL is the statement a person wrote: its ORDER BY / LIMIT / OFFSET
    are its answer and stay inside the wrapper (they were stripped here, so
    ``... order by x limit 3 offset 150000`` streamed the first page of the
    WHOLE table, offset dropped).  SQL ``_build_inner_sql`` GENERATED from a
    query config carries the compiler's row cap, which is removed (the
    owner's decision: "Query Builder limit: show all rows"); its OFFSET is
    kept."""
    from core.statement_bounds import statement_body, strip_generated_limit
    if getattr(request, "raw_sql", None):
        return statement_body(inner_sql)
    return strip_generated_limit(inner_sql)


def _build_inner_sql(request, cfg, registered_tables, bucket, conn_id,
                     user=None, request_id=None):
    """Build inner SQL from raw_sql or query_config. Returns (sql, partition_filters, primary_tables).

    When ``user`` is provided, row/column security policies are applied to the
    produced SQL (both the raw_sql and the structured query_config branches)."""
    if request.raw_sql:
        raw_sql = request.raw_sql
        # ${user.*} FIRST (authoring vocabulary → concrete values), THEN row
        # security (values → this caller's permitted rows).  See
        # _render_user_vars for why this order is load-bearing.
        raw_sql = _render_user_vars(raw_sql, user, "editor SQL (stream)")
        # S8: secure BEFORE filter extraction so partition pruning sees the
        # secured SQL (same ordering the old per-endpoint block used).
        if user is not None:
            raw_sql = _apply_row_security(raw_sql, user, conn_id, request_id)

        # ── SQL Dialect Translation ──────────────────────────────────────────
        # Auto-translate cross-platform SQL (Starburst/Snowflake/Trino/MySQL/…)
        # to DuckDB so users can paste the same shared query into CQB/BQB.
        try:
            from core.sql_dialect_translator import translate_to_duckdb as _translate
            raw_sql, _dialect = _translate(raw_sql)
            if _dialect:
                logger.info("stream: SQL dialect '%s' translated → duckdb", _dialect)
        except Exception as _te:
            logger.debug("stream: SQL translation skipped (fail-open): %s", _te)

        # ── Filter extraction for raw SQL (Phase 122B parity, BF-NON-PARTITION-PRUNE) ──
        # Extract BOTH partition AND non-partition filter values from the SQL
        # WHERE clause.  Partition filters drive manifest pruning; non-partition
        # filters drive Iceberg column-stats pruning at the file level.
        pf = None
        try:
            from core.sql_partition_extractor import (
                extract_combined_filters_for_iceberg,
            )
            from core.iceberg_partition_resolver import resolve_partition_columns
            _rt_part_cols: dict = {}
            # Lazy s3 client for tier-3 (iceberg metadata) fallback
            _stream_s3 = None
            for _rt in (registered_tables or []):
                _rt_name = _rt.get("name")
                if not _rt_name:
                    continue
                if (_rt.get("format") == "iceberg"
                        and bucket and _rt.get("s3_prefix")
                        and _stream_s3 is None):
                    try:
                        from core.s3_utilities import make_s3_client_for_conn
                        _stream_s3 = make_s3_client_for_conn(
                            {"id": conn_id, "config": cfg},
                        )
                    except Exception:
                        _stream_s3 = None
                # 3-tier resolution: admin config → partition_cache → iceberg metadata
                _resolved = resolve_partition_columns(
                    registered_table=_rt,
                    db_manager=_db_manager,
                    connection_id=conn_id,
                    table_name=_rt_name,
                    s3_client=_stream_s3,
                    bucket=bucket,
                    table_prefix=_rt.get("s3_prefix"),
                )
                if _resolved:
                    _rt_part_cols[_rt_name] = _resolved
            # Empty pc map is OK — combined helper still pulls non-partition filters.
            _combined = extract_combined_filters_for_iceberg(
                raw_sql, _rt_part_cols, dialect="duckdb"
            )
            if _combined:
                pf = _combined
                _pc_set = {c.lower() for cs in _rt_part_cols.values() for c in cs}
                _part_n = sum(1 for f in pf if f.get("col", "").lower() in _pc_set)
                _np_n = len(pf) - _part_n
                logger.info(
                    "stream raw SQL filter extraction: %d partition + %d non-partition filter(s)",
                    _part_n, _np_n,
                )
        except Exception as _pf_err:
            logger.debug(
                "stream: raw SQL filter extraction failed (fail-open): %s", _pf_err
            )

        # For raw SQL, ALL registered tables are primary (user controls joins in SQL).
        # This ensures _all_primary_empty detection works correctly in register_s3_views.
        _raw_primary = {t["name"] for t in (registered_tables or [])} or None
        return raw_sql, pf, _raw_primary

    if request.query_config:
        # Resolve dynamic date expressions (${today}, ${today-7d}, …) in filter values
        try:
            from core.date_resolver import CalendarTokenRefused, resolve_value
            if request.query_config.filters:
                for _f in request.query_config.filters:
                    _f.value = resolve_value(_f.value)
        except CalendarTokenRefused:
            raise          # a filter that cannot be rendered refuses (400)
        except Exception as e:
            logger.debug("Failed to resolve filter values, proceeding with originals: %s", e)
        engine_config = convert_query_config_to_engine(request.query_config)
        translate_join_columns(engine_config)
        s3_engine = ParquetQueryEngine(
            base_path=str(_paths.parquet_dir),
            chunk_size=_qe_cfg.chunk_size,
            s3_config=build_s3_config(cfg),
        )
        if registered_tables:
            s3_engine._registered_tables = registered_tables
            s3_engine._s3_conn_config = cfg
            s3_engine._s3_bucket = bucket
            s3_engine._s3_conn_id = conn_id
        inner_sql = s3_engine.get_duckdb_sql(engine_config)
        inner_sql = rewrite_registered_refs(inner_sql, registered_tables)
        # S8: structured branch was the RLS bypass — apply policies to the
        # generated SQL.  Done AFTER rewrite_registered_refs so table refs
        # match the same view names raw SQL uses (policy table_ref parity).
        if user is not None:
            inner_sql = _apply_row_security(inner_sql, user, conn_id, request_id)
        pf, _pf_warnings = extract_partition_filters_from_query(request.query_config)
        if _pf_warnings:
            import logging as _log
            _log.getLogger(__name__).warning("Partition filter warnings: %s", _pf_warnings)
        # Extract primary table names (FROM clause) for scoped partition pruning
        _pt = set()
        for _qf in (request.query_config.files or []):
            _fname = _qf if isinstance(_qf, str) else str(_qf)
            if _fname.startswith("__registered__:"):
                _pt.add(_fname.replace("__registered__:", ""))
        return inner_sql, pf, _pt or None

    raise HTTPException(status_code=400, detail="Provide query_config or raw_sql")


def _resolve_connection(request, endpoint_name: str,
                       allow_sql_connectors: bool = False,
                       user=None):
    """Resolve connection_id and validate the connection type.

    2026-08-21 — ``allow_sql_connectors`` opens this to Starburst/Trino,
    Snowflake, Databricks, Oracle and Athena.  Until now every streaming
    endpoint was S3-only, so an interactive Starburst query had no path here:
    it went through /api/execute, materialised its ENTIRE result to a local
    parquet, and the grid stayed empty until that finished.  Operator, on a
    query Starburst itself answers in 7 seconds: "i see 1gb file created n did
    not show any data in grid....user will close n will not use".

    Only endpoints that can actually SERVE a SQL connector pass True — the
    others keep the S3-only refusal rather than accepting a request they would
    fail on later.
    """
    conn_id = getattr(request, 'connection_id', None)
    if not conn_id and hasattr(request, 'query_config') and request.query_config:
        conn_id = request.query_config.connection_id
    if not conn_id:
        raise HTTPException(status_code=400, detail="connection_id is required")

    conn = _db_manager.get_connection_raw(conn_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")

    # -- SECURITY 2026-08-23 (Phase 2A): connection ENTITLEMENT ------------
    # All five streaming endpoints run SQL with this connection's stored
    # credentials and none of them ever asked whether the caller may USE
    # the connection -- any authenticated user could stream another
    # analyst's private connection by id.  ONE chokepoint (this resolver is
    # the single place a stream turns an id into a decrypted record), the
    # SAME decision as /api/execute and /api/sql/execute
    # (core.entitlements.denied_connection_ids), the same non-oracle 404.
    if user is not None:
        from core.entitlements import denied_connection_ids as _dci
        if _dci(user, [conn_id], db=_db_manager):
            raise HTTPException(status_code=404,
                                detail="Connection not found")

    _ctype = conn.get("connection_type")
    if _ctype != "s3":
        _ok = False
        if allow_sql_connectors:
            try:
                from core.connectors import SQL_CONNECTOR_TYPES
                _ok = _ctype in SQL_CONNECTOR_TYPES
            except Exception as _sc_exc:
                logger.debug("SQL connector types unavailable: %s", _sc_exc)
        if not _ok:
            raise HTTPException(
                status_code=400,
                detail=f"Streaming {endpoint_name} only supported for S3 "
                       f"connections")

    return conn_id, conn, conn.get("config", {})


# BQB streaming's referenced-table extraction moved to ``core.query_hints``
# so feed_engine can call the same logic without an api→core layering hazard.
# Local re-export keeps the original symbol for in-module callers.
from core.query_hints import extract_referenced_tables as _get_refs  # noqa: E402


def _want_fresh_iceberg(request) -> bool:
    """Derive force_fresh_iceberg from request's cache_strategy.

    Streaming endpoints don't have Published View / schedule callers, so we
    only check cache_strategy (set by the UI "bypass cache" toggle).
    """
    qc = getattr(request, "query_config", None)
    if not qc:
        return False
    from core.iceberg_freshness_bound import wants_newest_snapshot
    return wants_newest_snapshot(getattr(qc, "cache_strategy", "auto"))


# ═══════════════════════════════════════════════════════════════════════════
# POST /api/execute/stream/cancel — Cancel a running streaming query
# ═══════════════════════════════════════════════════════════════════════════
@router.post("/api/execute/stream/cancel")
async def cancel_stream(request: Request, _user: dict = Depends(get_current_user)):
    """Cancel a running streaming query by stream_id."""
    if not cfg.streaming.cancel_enabled:
        raise HTTPException(status_code=403, detail="Stream cancellation is disabled")
    body = await request.json()
    stream_id = body.get("stream_id")
    if not stream_id:
        raise HTTPException(status_code=400, detail="stream_id is required")
    with _streams_lock:
        evt = _active_streams.get(stream_id)
    if not evt:
        raise HTTPException(status_code=404, detail="Stream not found or already completed")
    evt.set()
    logger.info("Stream %s: cancel requested by %s", stream_id, _user.get("username", "?"))
    return {"status": "cancelled", "stream_id": stream_id}


# ═══════════════════════════════════════════════════════════════════════════
# POST /api/execute/stream — DuckDB httpfs streaming (direct S3 query)
# ═══════════════════════════════════════════════════════════════════════════
@router.post("/api/execute/stream")
async def stream_query(request: StreamQueryRequest, _user: dict = Depends(get_current_user)):
    """Stream query results directly from S3 via DuckDB httpfs."""
    try:
        from core.aws_portal_auth import _current_portal_user
        _current_portal_user.set(_user.get("username", ""))
    except Exception:
        pass

    t0 = time.monotonic()
    conn_id, conn, _cfg = await asyncio.to_thread(
        _resolve_connection, request, "query", False, _user)
    stream_id = _register_stream() if cfg.streaming.cancel_enabled else uuid.uuid4().hex[:16]
    executed_by = _user.get("username", "")

    # ── BQB-parity observability (Option B) ────────────────────────────────
    # Persist a query_executions row for this stream so the perf chip
    # (/api/executions/{id}) finds total duration + per-stage timing
    # + captured logs.  Background path already does this; streaming
    # was the only BQB path missing it.  Helper is fail-open.
    try:
        _qc_for_record = request.model_dump() if hasattr(request, "model_dump") else {}
    except Exception:
        _qc_for_record = {}
    _begin_stream_execution(_db_manager, stream_id, _qc_for_record, executed_by)
    _set_stream_stage(stream_id, "starting", message="Streaming query initiated")

    # Phase 141 row/column security now runs inside _build_inner_sql (S8 —
    # single chokepoint for raw_sql AND query_config across all five
    # streaming endpoints).

    async def _ws_broadcast(payload: dict):
        if _ws_manager and executed_by:
            try:
                await _ws_manager.broadcast_to_user(executed_by, payload)
            except Exception:
                pass

    try:
        from api.data_grid_api import _duckdb_con_with_s3

        registered_tables = _cfg.get("registered_tables", [])
        bucket = (_cfg.get("bucket_name") or "").strip()
        inner_sql, pf, _pt = _build_inner_sql(request, _cfg, registered_tables, bucket, conn_id,
                                              user=_user, request_id=stream_id)

        # Phase 107-C: detect S3 full scan (default action="log", no behavior change)
        _check_stream_s3_guardrail(conn_id=conn_id, primary_tables=_pt, partition_filters=pf,
                                    source="stream_query", user=_user)

        stripped_sql = _stream_body(request, inner_sql)
        stream_sql = f"SELECT * FROM ({stripped_sql}) _stream LIMIT {request.limit}"
        _fresh = _want_fresh_iceberg(request)

        # Notify frontend: query starting (shows spinner)
        await _ws_broadcast({
            "type": "stream_query_started",
            "stream_id": stream_id,
            "connection_id": conn_id,
            "timestamp": time.time(),
        })

        loop = asyncio.get_running_loop()

        def _run_stream():
            nonlocal stream_sql
            # Bind log buffer + stage tracking to THIS execution so the
            # chip can show what happened.  Context manager scopes the
            # contextvar to the worker thread that emits log records.
            with _with_execution_id(stream_id):
                _set_stream_stage(stream_id, "register_views",
                                  message="Registering S3 views")
                if stream_id and stream_id in _active_streams:
                    _check_cancelled(stream_id)
                con = _duckdb_con_with_s3(_cfg, connection_id=conn_id)
                try:
                    _refs = _get_refs(registered_tables, stream_sql)
                    _rc, _all_empty, _fstats = _register_s3_views_fn(con, registered_tables, bucket, conn_id, _cfg,
                                          referenced_tables=_refs or None, partition_filters=pf,
                                          primary_tables=_pt, force_fresh_iceberg=_fresh,
                                          db_manager=_db_manager, reader_override=getattr(getattr(request, "query_config", None), "reader_override", None),
                                          joins=getattr(getattr(request, "query_config", None), "joins", None),
                                          raw_sql_present=bool(getattr(getattr(request, "query_config", None), "raw_sql", None)),  # JOIN-PRUNER + BF-375
                                          # 2026-08-22 — was
                                          # request.query_config.raw_sql,
                                          # a field QueryConfigModel does
                                          # not declare, so getattr always
                                          # returned None and the binding
                                          # check was DEAD on the exact
                                          # path the bug was reported on.
                                          # `stream_sql` is the statement
                                          # actually being executed.
                                          raw_sql=stream_sql)
                    # BF-514 (2026-05-28): partial-failure detection.  BF-484
                    # only fired the check when EVERY primary table was empty,
                    # missing the case where some tables fail S3 auth and
                    # others return rows — yielding silent partial data loss.
                    # The helper short-circuits on empty failures dict, so
                    # calling it unconditionally is safe.
                    _raise_if_registration_failed(con, conn_id)  # BF-484 + BF-514
                    if _all_empty:
                        return {"columns": [], "rows": [], "all_primary_empty": True, "file_stats": _fstats}
                    if stream_id and stream_id in _active_streams:
                        _check_cancelled(stream_id)
                    _set_stream_stage(stream_id, "duckdb_execute",
                                      message="Executing DuckDB query")
                    if "EXCLUDE" in stream_sql:
                        stream_sql = _fix_stale_excludes(con, stream_sql)
                    result = con.execute(stream_sql)
                    if stream_id and stream_id in _active_streams:
                        _check_cancelled(stream_id)
                    _set_stream_stage(stream_id, "serialise",
                                      message="Fetching result rows")
                    columns = [desc[0] for desc in result.description]
                    rows = result.fetchall()
                    return {"columns": columns, "rows": [list(r) for r in rows], "file_stats": _fstats}
                finally:
                    con.close()
                    cleanup_temp_downloads()

        _stream_timeout = float(_qe_cfg.query_timeout_seconds) if _qe_cfg else 1800.0
        try:
            data = await asyncio.wait_for(
                loop.run_in_executor(_get_light_executor_fn(), _run_stream),
                timeout=_stream_timeout,
            )
        except asyncio.TimeoutError:
            _to_min = int(_stream_timeout // 60)
            logger.error("Stream query: timed out after %.0fs", _stream_timeout)
            raise HTTPException(status_code=504, detail=f"S3 streaming query timed out after {_to_min} minutes")

        elapsed = time.monotonic() - t0
        rows_safe = [[jsonify_value(c) for c in row] for row in data["rows"]]

        logger.info("Stream query: rows=%d, cols=%d, elapsed=%.2fs",
                     len(rows_safe), len(data["columns"]), elapsed)
        resp = {
            "columns": data["columns"],
            "rows": rows_safe,
            "total_rows": len(rows_safe),
            "streaming": True,
            "limit": request.limit,
            "elapsed_seconds": round(elapsed, 2),
            "connection_id": conn_id,
            "stream_id": stream_id,
        }
        if data.get("file_stats"):
            resp["file_stats"] = data["file_stats"]

        # Notify frontend: query complete (hides spinner, shows results)
        await _ws_broadcast({
            "type": "stream_query_completed",
            "stream_id": stream_id,
            "total_rows": len(rows_safe),
            "elapsed_seconds": round(elapsed, 2),
            "connection_id": conn_id,
            "pruning_applied": bool(data.get("file_stats")),
        })

        # BQB-parity: persist stage_history + log_lines for the perf chip
        _finalise_stream_execution(
            _db_manager, stream_id,
            status="completed",
            total_rows=len(rows_safe),
            file_size_bytes=0,  # streaming returns rows inline, no parquet artifact
        )

        return JSONResponse(content=resp, headers={"X-Stream-Id": stream_id})
    except StreamCancelledError:
        logger.info("Stream query %s: cancelled", stream_id)
        _finalise_stream_execution(_db_manager, stream_id, status="cancelled")
        return JSONResponse(status_code=499, content={"detail": "Query cancelled", "stream_id": stream_id})
    except HTTPException:
        raise
    except Exception as e:
        raise_if_s3_auth_error(e)
        logger.error("Stream query error: %s", e, exc_info=True)
        # BQB-parity: persist failed execution + captured logs for the chip
        _finalise_stream_execution(
            _db_manager, stream_id,
            status="failed",
            error_message=str(e),
        )
        # Notify frontend: query failed (hides spinner, shows error)
        try:
            await _ws_broadcast({
                "type": "stream_query_failed",
                "stream_id": stream_id,
                "error": str(e)[:300],
                "connection_id": conn_id,
            })
        except Exception:
            pass
        # Phase 120: Agent observe streaming query failure
        try:
            from core.agents import get_orchestrator as _get_orch
            from core.proxy_utils import sanitize_proxy_error as _sanitize_err
            _orch = _get_orch()
            if _orch and _orch.enabled:
                _orch.handle_event("query_failed", {
                    "error_message": _sanitize_err(str(e)),
                    "error_type": type(e).__name__,
                    "connection_id": conn_id,
                    "query_config": request.model_dump() if hasattr(request, "model_dump") else {},
                    "raw_sql": getattr(request, "raw_sql", "") or "",
                    "retry_count": 0,
                    "tables": [f.path for f in (request.query_config.files if hasattr(request, "query_config") and hasattr(request.query_config, "files") else [])],
                    "streaming": True,
                })
        except Exception as _agent_exc:
            logger.debug("Agent hook failed (non-fatal): %s", _agent_exc)
        _raise_stream_http_error(e, "Streaming query failed")
    finally:
        if stream_id and stream_id in _active_streams:
            _unregister_stream(stream_id)


# ═══════════════════════════════════════════════════════════════════════════
# POST /api/execute/stream/schema — lightweight column discovery
# ═══════════════════════════════════════════════════════════════════════════
@router.post("/api/execute/stream/schema")
async def stream_schema(request: StreamSchemaRequest, _user: dict = Depends(get_current_user)):
    """Lightweight column discovery for S3 streaming."""
    t0 = time.monotonic()
    conn_id, conn, _cfg = await asyncio.to_thread(
        _resolve_connection, request, "schema", False, _user)
    stream_id = _register_stream() if cfg.streaming.cancel_enabled else None

    try:
        from api.data_grid_api import _duckdb_con_with_s3

        registered_tables = _cfg.get("registered_tables", [])
        bucket = (_cfg.get("bucket_name") or "").strip()
        inner_sql, pf, _pt = _build_inner_sql(request, _cfg, registered_tables, bucket, conn_id,
                                              user=_user, request_id=stream_id)
        stripped_sql = _stream_body(request, inner_sql)
        _fresh = _want_fresh_iceberg(request)

        loop = asyncio.get_running_loop()
        _refs = _get_refs(registered_tables, stripped_sql)

        def _run_schema():
            nonlocal stripped_sql
            if stream_id:
                _check_cancelled(stream_id)
            con = _duckdb_con_with_s3(_cfg, connection_id=conn_id)
            try:
                _rc, _all_empty, _fstats = _register_s3_views_fn(con, registered_tables, bucket, conn_id, _cfg,
                                      referenced_tables=_refs or None, partition_filters=pf,
                                      primary_tables=_pt, force_fresh_iceberg=_fresh,
                                      db_manager=_db_manager, reader_override=getattr(getattr(request, "query_config", None), "reader_override", None),
                                      joins=getattr(getattr(request, "query_config", None), "joins", None),
                                          raw_sql_present=bool(getattr(getattr(request, "query_config", None), "raw_sql", None)),  # JOIN-PRUNER + BF-375
                                          # 2026-08-22 — was
                                          # request.query_config.raw_sql,
                                          # a field QueryConfigModel does
                                          # not declare, so getattr always
                                          # returned None and the binding
                                          # check was DEAD on the exact
                                          # path the bug was reported on.
                                          # `stream_sql` is the statement
                                          # actually being executed.
                                          raw_sql=stripped_sql)
                # BF-514 — unconditional check for partial-failure path.
                _raise_if_registration_failed(con, conn_id)  # BF-484 + BF-514
                if _all_empty:
                    return {"columns": [], "total_columns": 0, "estimated_rows": 0, "all_primary_empty": True, "file_stats": _fstats}
                if stream_id:
                    _check_cancelled(stream_id)
                if "EXCLUDE" in stripped_sql:
                    stripped_sql = _fix_stale_excludes(con, stripped_sql)

                # Step 1: Schema via LIMIT 0 (reads parquet footer only — fast)
                schema_result = con.execute(f"SELECT * FROM ({stripped_sql}) _schema LIMIT 0")
                columns = [{"name": desc[0], "type": desc[1]} for desc in schema_result.description]

                # Step 2: Sample to detect empty columns
                empty_set = set()
                if request.sample_rows > 0 and len(columns) > 0:
                    try:
                        sample_sql = f"SELECT * FROM ({stripped_sql}) _sample LIMIT {request.sample_rows}"
                        sample_result = con.execute(sample_sql)
                        sample_rows = sample_result.fetchall()
                        if sample_rows:
                            col_names = [desc[0] for desc in sample_result.description]
                            for i, cname in enumerate(col_names):
                                if all(row[i] is None for row in sample_rows):
                                    empty_set.add(cname)
                    except Exception as e:
                        logger.warning("Stream schema: empty detection failed: %s", e)

                for col in columns:
                    col["empty"] = col["name"] in empty_set

                if stream_id:
                    _check_cancelled(stream_id)

                # Step 3: Estimate total rows
                estimated_rows = -1
                try:
                    count_result = con.execute(f"SELECT COUNT(*) FROM ({stripped_sql}) _c")
                    estimated_rows = int(count_result.fetchone()[0])
                except Exception:
                    pass

                _res = {"columns": columns, "total_columns": len(columns), "estimated_rows": estimated_rows}
                if _fstats:
                    _res["file_stats"] = _fstats
                return _res
            finally:
                con.close()
                cleanup_temp_downloads()

        result = await asyncio.wait_for(
            loop.run_in_executor(_get_light_executor_fn(), _run_schema),
            timeout=60.0,
        )
        result["elapsed_seconds"] = round(time.monotonic() - t0, 2)
        if stream_id:
            result["stream_id"] = stream_id
        logger.info("Stream schema: %d columns, %d estimated rows, %.2fs",
                     result["total_columns"], result["estimated_rows"], result["elapsed_seconds"])
        return JSONResponse(content=result, headers={"X-Stream-Id": stream_id} if stream_id else {})

    except StreamCancelledError:
        logger.info("Stream schema %s: cancelled", stream_id)
        return JSONResponse(status_code=499, content={"detail": "Query cancelled", "stream_id": stream_id})
    except asyncio.TimeoutError:
        raise HTTPException(status_code=504, detail="Schema discovery timed out after 60 seconds") from None
    except HTTPException:
        raise
    except Exception as e:
        raise_if_s3_auth_error(e)
        logger.error("Stream schema error: %s", e, exc_info=True)
        # Phase 120: Agent observe streaming schema failure
        try:
            from core.agents import get_orchestrator as _get_orch
            from core.proxy_utils import sanitize_proxy_error as _sanitize_err
            _orch = _get_orch()
            if _orch and _orch.enabled:
                _orch.handle_event("query_failed", {
                    "error_message": _sanitize_err(str(e)),
                    "error_type": type(e).__name__,
                    "connection_id": conn_id,
                    "streaming": True,
                })
        except Exception as _agent_exc:
            logger.debug("Agent hook failed (non-fatal): %s", _agent_exc)
        _raise_stream_http_error(e, "Schema discovery failed")
    finally:
        if stream_id:
            _unregister_stream(stream_id)


# ═══════════════════════════════════════════════════════════════════════════
# POST /api/execute/stream/paginate — paginated S3 streaming via DuckDB
# ═══════════════════════════════════════════════════════════════════════════
async def _paginate_via_sql_cursor(request, conn_id, conn, _user, t0,
                                   stream_id=None):
    """One page of a SQL-connector query, served from a live forward cursor.

    Writes nothing to disk.  The session holds the cursor open between pages
    so scrolling costs one fetch, and is reaped on idle with the query
    cancelled AT THE SOURCE rather than left running on the cluster.
    """
    sql = (getattr(request, "raw_sql", None) or "").strip()
    if not sql:
        raise HTTPException(
            status_code=400,
            detail="raw_sql is required to stream a SQL connector")

    _ctype = conn.get("connection_type")
    username = (_user or {}).get("username", "")
    page = int(getattr(request, "page", 1) or 1)
    page_size = int(getattr(request, "page_size", 100) or 100)

    # -- ROW & COLUMN SECURITY: the same chokepoint /api/execute uses -------
    # 2026-08-22.  This route was added yesterday and executed `raw_sql`
    # VERBATIM.  That made it a privilege escalation, not a shortcut: the
    # identical SELECT sent through /api/execute is rewritten by `secure_sql`
    # to the caller's permitted rows and columns, so a non-admin who flipped
    # the grid streaming toggle saw EVERY region of a table whose policy
    # limits them to one.  Same shape as 2026-08-19, when
    # `execute_sql_connector_background` had no row security: a query that is
    # filtered on one route and unfiltered on another is worse than one never
    # filtered at all, because the filtered route is the one that gets
    # reviewed.
    #
    # Fail CLOSED throughout.  A rewrite that cannot be completed means we
    # cannot prove which rows this user may see, and "cannot prove" must
    # never resolve to "send them all".
    try:
        from core.row_security import (
            PolicyResolutionError as _RsResErr, secure_sql as _rs_secure)
        from core.stream_cursor_session import (
            CursorCancelled as _CursorCancelled,
            PageTooFarAhead as _PageTooFar,
        )
        from fastapi.encoders import jsonable_encoder as _jsonable
        from core.sql_filter_wrapper import (
            dialect_for_connection_type as _dial_rs)
    except Exception as _rs_imp_exc:
        # Deliberately NOT fail-open.  The import sits in its OWN try: doing
        # it inside the guarded block below would leave `_RsResErr` undefined
        # in that block's own `except` clause -- a NameError raised while
        # handling an error, which is how this codebase has hidden five bugs.
        logger.error("Row-security module unavailable - refusing to stream "
                     "%s without it: %s", _ctype, _rs_imp_exc, exc_info=True)
        raise HTTPException(
            status_code=500,
            detail="Row-security enforcement unavailable; query refused")

    # ${user.*} FIRST (authoring vocabulary → concrete values), THEN row
    # security — same order as every other editor surface; see
    # _render_user_vars.  Rendering before securing also feeds the rendered
    # text into the cursor-session key below, so two principals whose values
    # differ can never share one cursor.
    sql = _render_user_vars(sql, _user, "editor SQL (stream cursor)")

    try:
        sql = await asyncio.to_thread(
            _rs_secure, sql,
            dialect=_dial_rs(_ctype),
            user_ctx=_user,
            connection_id=conn_id,
            request_id=getattr(request, "execution_id", None),
        )
    except _RsResErr as _rs_exc:
        logger.error("Row-security rewrite failed on the cursor path: %s",
                     _rs_exc)
        raise HTTPException(
            status_code=403,
            detail=f"Row-security policy enforcement failed: {_rs_exc}")
    except HTTPException:
        raise
    except Exception as _rs_other:
        logger.error("Row-security rewrite errored on the cursor path: %s",
                     _rs_other, exc_info=True)
        raise HTTPException(
            status_code=403,
            detail="Row-security policy enforcement failed")

    # The session is keyed on the SECURED sql, so two users whose policies
    # rewrite the same input differently can never share one cursor.
    _cancel_evt = _active_streams.get(stream_id) if stream_id else None

    def _run():
        from core.connectors import get_connector
        from core.stream_cursor_session import read_page_via_cursor
        connector = get_connector(_ctype, conn.get("config", {}) or {},
                                  conn_id, conn.get("name", "") or "")
        # dialect enables the ENGINE-side seek for far jumps on
        # stable-ORDER-BY statements (2026-08-22) — without it a deep
        # "last page" click fast-forwards row by row through the pod.
        return read_page_via_cursor(
            connector, sql, conn_id, username, page, page_size,
            cancel_event=_cancel_evt, dialect=_dial_rs(_ctype))

    loop = asyncio.get_running_loop()
    _page_timeout = 1800.0
    try:
        _page_timeout = float(cfg.query_engine.query_timeout_seconds)
    except Exception as _to_exc:
        logger.debug("Stream paginate: page timeout falls back to %.0fs: %s",
                     _page_timeout, _to_exc)
    try:
        out = await asyncio.wait_for(
            loop.run_in_executor(_get_light_executor_fn(), _run),
            timeout=_page_timeout,
        )
    except asyncio.TimeoutError:
        logger.error("Stream paginate (%s cursor): page=%d timed out after "
                     "%.0fs", _ctype, page, _page_timeout)
        raise HTTPException(
            status_code=504,
            detail=f"Streaming query timed out after "
                   f"{int(_page_timeout // 60)} minutes")
    except (StreamCancelledError, _CursorCancelled):
        logger.info("Stream paginate (%s cursor): page=%d cancelled by user",
                    _ctype, page)
        raise HTTPException(status_code=499, detail="Query cancelled")
    except _PageTooFar as _ff_exc:
        # A page too far beyond the cursor to fast-forward in one request.
        # That is a bad REQUEST, not a server failure.  Narrowed from
        # `ValueError` on 2026-08-22: that caught the whole class, so a
        # driver or get_connector ValueError was reported to the user as a
        # 400 "scroll forward" hint.
        #
        # STRUCTURED detail (2026-08-22): a bare string here read to the
        # operator as "Starburst fails above 2 million rows".  The body now
        # carries code / rows_ahead / the bound / which pages ARE reachable
        # / the Download-Centre pointer, so the grid can render a CTA
        # instead of an error toast.  (With a stable ORDER BY this path is
        # not reached at all — the session seeks engine-side.)
        logger.info("Stream paginate (%s cursor): page=%d refused: %s",
                    _ctype, page, _ff_exc)
        _detail = (_ff_exc.to_detail() if hasattr(_ff_exc, "to_detail")
                   else str(_ff_exc))
        raise HTTPException(status_code=400, detail=_detail)
    except Exception as exc:
        from api.connector_errors import raise_if_source_error as _rise
        _rise(exc, _ctype, context="Streaming query failed")            # FB-41
        logger.error("Stream paginate (%s cursor): page=%d failed: %s",
                     _ctype, page, exc, exc_info=True)
        raise HTTPException(status_code=500,
                            detail=f"Streaming query failed: {str(exc)[:300]}")

    rows = out.get("rows") or []
    jsonify_rows(rows)
    # 2026-08-22 -- connectors describe columns as [{"name":..,"type":..}];
    # every other paginate response, and DataGridViewer, uses a plain list of
    # NAMES.  Returning the dicts made `row[col]` index by "[object Object]",
    # which no row has, so the grid classified EVERY column as empty and then
    # threw.  Normalise at the wire edge rather than teach the grid a second
    # shape.
    cols = [
        (c.get("name") if isinstance(c, dict) else str(c))
        for c in (out.get("columns") or [])
    ]
    _seen = int(out.get("rows_seen") or 0)
    _done = bool(out.get("exhausted"))

    # total_rows is only KNOWN once the cursor is exhausted.  Reporting a
    # guess would be a wrong number presented as a fact, so while more rows
    # may exist we report what we have seen and flag it.
    logger.info(
        "Stream paginate (%s cursor): page=%d rows=%d seen=%d exhausted=%s "
        "re_exec=%d elapsed=%.2fs — no file written",
        _ctype, page, len(rows), _seen, _done,
        int(out.get("re_executions") or 0), time.monotonic() - t0)

    _body = {
        "columns": cols,
        "rows": rows,
        "total_rows": _seen if _done else -1,
        "filtered_rows": _seen if _done else -1,
        "total_rows_exact": _done,
        "rows_seen": _seen,
        "page": page,
        "page_size": page_size,
        "total_pages": ((_seen + page_size - 1) // page_size) if _done else -1,
        "has_more": (not _done) or (page * page_size < _seen),
        "streaming": True,
        "source": "sql_cursor",
        # A backward jump past the retained window re-runs the query.  With no
        # outer ORDER BY the engine need not return rows in the same order
        # twice, so page boundaries can shift under the user.  The session
        # computed this and the response used to drop it, leaving the grid
        # unable to say anything.
        "re_executions": int(out.get("re_executions") or 0),
        "order_unstable": bool(out.get("order_unstable")),
        # The CANCELLABLE id, not the session key.  The session key is not in
        # `_active_streams`, so returning it made /stream/cancel answer 404
        # and the grid Cancel button a no-op on this path.
        "stream_id": stream_id or out.get("session_key"),
        "session_key": out.get("session_key"),
    }
    # jsonable_encoder, NOT the raw dict.  Returning a plain dict let
    # FastAPI encode it; JSONResponse hands the body straight to
    # json.dumps with no `default=`, which RAISES on any type
    # jsonify_rows does not already cover (UUID, Enum, numpy scalars,
    # Oracle LOB wrappers) — types FastAPI would have handled.  A 500 on
    # page 1 of a perfectly good query.
    return JSONResponse(
        content=_jsonable(_body),
        headers={"X-Stream-Id": stream_id} if stream_id else {})


@router.post("/api/execute/stream/paginate")
async def stream_paginate(request: StreamPaginateRequest, http_request: Request = None,
                          _user: dict = Depends(get_current_user)):
    """Paginated query results — from S3 via DuckDB, or straight from a live
    SQL-connector cursor with NO file written."""
    t0 = time.monotonic()
    conn_id, conn, _cfg = await asyncio.to_thread(
        _resolve_connection, request, "pagination", True, _user)

    # ── 2026-08-21 — SQL CONNECTORS BROWSE FROM A LIVE CURSOR ────────────
    # No parquet is written for interactive browsing.  Scrolling forward is
    # exactly what a forward-only cursor does, so there is no row cap; a
    # backward jump past the retained window re-executes and says so.  A user
    # who wants the whole result asks for the background download, which is
    # what the Download Centre is for.
    if conn.get("connection_type") != "s3":
        # Registered like every other streaming route: registration is what
        # enforces `max_active_streams`, and what lets the grid Cancel button
        # reach the running query.  The early `return` used to jump over it.
        _cur_sid = _register_stream() if cfg.streaming.cancel_enabled else None
        try:
            return await _paginate_via_sql_cursor(request, conn_id, conn,
                                                  _user, t0, _cur_sid)
        finally:
            if _cur_sid:
                _unregister_stream(_cur_sid)
    stream_id = _register_stream() if cfg.streaming.cancel_enabled else None
    if not stream_id:
        # Need a stable id for the chip even when cancel is disabled.
        stream_id = uuid.uuid4().hex[:16]
    executed_by = _user.get("username", "")

    # ── BQB-parity observability (Option B) ────────────────────────────────
    # Only instrument page 1 so we don't spam query_executions with one
    # row per page nav.  Subsequent pages are pure result-window queries
    # against the same dataset; the chip references the page-1 execution.
    _obs_active = (getattr(request, "page", 1) or 1) == 1
    if _obs_active:
        try:
            _qc_for_record = request.model_dump() if hasattr(request, "model_dump") else {}
        except Exception:
            _qc_for_record = {}
        _begin_stream_execution(_db_manager, stream_id, _qc_for_record, executed_by)
        _set_stream_stage(stream_id, "starting", message="Streaming paginate page 1")

    try:
        from api.data_grid_api import _duckdb_con_with_s3, _build_where

        registered_tables = _cfg.get("registered_tables", [])
        bucket = (_cfg.get("bucket_name") or "").strip()
        inner_sql, pf, _pt = _build_inner_sql(request, _cfg, registered_tables, bucket, conn_id,
                                              user=_user, request_id=stream_id)

        # Phase 107-C: detect S3 full scan (default action="log", no behavior change)
        _check_stream_s3_guardrail(conn_id=conn_id, primary_tables=_pt, partition_filters=pf,
                                    source="stream_paginate", user=_user)

        stripped_sql = _stream_body(request, inner_sql)
        _fresh = _want_fresh_iceberg(request)
        if request.query_config and hasattr(convert_query_config_to_engine(request.query_config), 'joins'):
            engine_config = convert_query_config_to_engine(request.query_config)
            if engine_config.joins:
                logger.info("Stream paginate: JOIN query detected, tables=%d, sql_preview=%.200s",
                            1 + len(engine_config.joins), inner_sql)

        loop = asyncio.get_running_loop()
        _refs = _get_refs(registered_tables, stripped_sql)

        def _run_paginated():
            # `nonlocal` must precede every use in the function body; it used
            # to sit ~30 lines below, which was fine until the view
            # registration above began reading stripped_sql too (2026-08-22).
            nonlocal stripped_sql
            _p0 = time.monotonic()
            if stream_id:
                _check_cancelled(stream_id)
            logger.info("STREAM-DIAG: _run_paginated START (conn=%s, refs=%s, primary=%s)", conn_id, _refs, _pt)
            # Bind log buffer + stages on page 1 only (matches the
            # query_executions row written outside the executor).
            # Initialise both `con` and `_maybe_ctx` to None so the unified
            # finally below can clean up whichever was actually acquired,
            # even when _duckdb_con_with_s3 raises (bad creds / proxy down).
            _maybe_ctx = _with_execution_id(stream_id) if _obs_active else None
            if _maybe_ctx is not None:
                _maybe_ctx.__enter__()
            con = None
            try:
                if _obs_active:
                    _set_stream_stage(stream_id, "register_views",
                                      message="Registering S3 views")
                con = _duckdb_con_with_s3(_cfg, connection_id=conn_id)
                logger.info("STREAM-DIAG: DuckDB connection ready (%.2fs)", time.monotonic() - _p0)
                _p1 = time.monotonic()
                _iceberg_total, _all_empty, _fstats = _register_s3_views_fn(con, registered_tables, bucket, conn_id, _cfg,
                                   referenced_tables=_refs or None, partition_filters=pf,
                                   primary_tables=_pt, force_fresh_iceberg=_fresh,
                                   db_manager=_db_manager, reader_override=getattr(getattr(request, "query_config", None), "reader_override", None),
                                   joins=getattr(getattr(request, "query_config", None), "joins", None),
                                          raw_sql_present=bool(getattr(getattr(request, "query_config", None), "raw_sql", None)),  # JOIN-PRUNER + BF-375
                                          # 2026-08-22 — was
                                          # request.query_config.raw_sql,
                                          # a field QueryConfigModel does
                                          # not declare, so getattr always
                                          # returned None and the binding
                                          # check was DEAD on the exact
                                          # path the bug was reported on.
                                          # `stream_sql` is the statement
                                          # actually being executed.
                                          raw_sql=stripped_sql)
                logger.info("STREAM-DIAG: views registered (%.2fs), iceberg_records=%d",
                            time.monotonic() - _p1, _iceberg_total)
                # BF-514 — unconditional check for partial-failure path.
                _raise_if_registration_failed(con, conn_id)  # BF-484 + BF-514
                if _all_empty:
                    return {"columns": [], "rows": [], "total_rows": 0, "filtered_rows": 0,
                            "page": request.page, "page_size": request.page_size,
                            "total_pages": 0, "streaming": True,
                            "elapsed_seconds": round(time.monotonic() - _p0, 3),
                            "all_primary_empty": True, "file_stats": _fstats}

                if stream_id:
                    _check_cancelled(stream_id)

                if "EXCLUDE" in stripped_sql:
                    stripped_sql = _fix_stale_excludes(con, stripped_sql)

                def _sq(n):
                    return '"' + str(n).replace('"', '""') + '"'

                # Build WHERE clause from adv_filters
                where_clause = ""
                where_params = []
                if request.adv_filters:
                    # Resolve date expressions in advanced filters
                    try:
                        from core.date_resolver import resolve_adv_filters
                        _resolved_af = resolve_adv_filters(request.adv_filters)
                    except Exception:
                        _resolved_af = request.adv_filters
                    _schema_r = con.execute(f"SELECT * FROM ({stripped_sql}) _schema LIMIT 0")
                    _valid = [desc[0] for desc in _schema_r.description]
                    where_clause, where_params = _build_where(_resolved_af, _valid)

                # Build ORDER BY
                order_clause = ""
                if request.sort_column:
                    direction = "ASC" if request.sort_direction == "asc" else "DESC"
                    order_clause = f' ORDER BY {_sq(request.sort_column)} {direction}'

                offset = (request.page - 1) * request.page_size
                data_sql = f"SELECT * FROM ({stripped_sql}) _s{where_clause}{order_clause} LIMIT {request.page_size} OFFSET {offset}"

                _p4 = time.monotonic()
                logger.info("STREAM-DIAG: page=%d, offset=%d, SQL=%.300s", request.page, offset, data_sql)
                if _obs_active:
                    _set_stream_stage(stream_id, "duckdb_execute",
                                      message="Executing DuckDB query")
                result = con.execute(data_sql, where_params) if where_params else con.execute(data_sql)
                if stream_id:
                    _check_cancelled(stream_id)
                if _obs_active:
                    _set_stream_stage(stream_id, "serialise",
                                      message="Fetching result rows")
                all_columns = [desc[0] for desc in result.description]
                raw_rows = result.fetchall()

                columns = all_columns
                rows = [dict(zip(columns, row)) for row in raw_rows] if raw_rows else []
                logger.info("STREAM-DIAG: OK, %d rows, %d/%d cols (%.2fs)",
                            len(raw_rows), len(columns), len(all_columns), time.monotonic() - _p4)

                # Total rows from Iceberg metadata
                rows_returned = len(raw_rows)
                if rows_returned < request.page_size:
                    total_rows = (request.page - 1) * request.page_size + rows_returned
                elif _iceberg_total > 0:
                    # 2026-07-15 MoR correctness — _iceberg_total is the
                    # manifest record_count sum over surviving files: it is
                    # delete-BLIND (V2 merge-on-read overcount) and counts
                    # WHOLE files that merely overlap a partition filter.
                    # Trust it only for plain append-only, filter-free scans
                    # (fast path unchanged); otherwise run an exact COUNT over
                    # the (now delete-aware) registered views.
                    _mor_deletes_present = any(
                        (_fs or {}).get("mor_delete_files")
                        for _fs in (_fstats or {}).values())
                    _filters_present = (
                        bool(where_clause) or bool(pf)
                        or bool(re.search(r"\bwhere\b", stripped_sql, re.IGNORECASE)))
                    if _mor_deletes_present or _filters_present:
                        try:
                            _cnt_sql = f"SELECT COUNT(*) FROM ({stripped_sql}) _s{where_clause}"
                            _cnt_cur = (con.execute(_cnt_sql, where_params)
                                        if where_params else con.execute(_cnt_sql))
                            total_rows = int(_cnt_cur.fetchone()[0])
                            logger.info(
                                "STREAM-DIAG: exact COUNT total=%d (manifest sum "
                                "%d untrusted: mor_deletes=%s filters=%s)",
                                total_rows, _iceberg_total,
                                _mor_deletes_present, _filters_present)
                        except Exception as _cnt_exc:
                            # Fail-open: never fail the page over the total.
                            # With deletes present the manifest sum is a KNOWN
                            # overcount — show unknown (-1) rather than a
                            # wrong number; without deletes keep old behaviour.
                            total_rows = -1 if _mor_deletes_present else _iceberg_total
                            logger.warning(
                                "STREAM-DIAG: exact COUNT for total_rows failed "
                                "(%s) — falling back to %s", _cnt_exc,
                                "-1 (unknown; manifest sum is delete-blind)"
                                if _mor_deletes_present else "manifest record_count sum")
                    else:
                        total_rows = _iceberg_total
                else:
                    total_rows = -1
                    if request.query_config and not (request.query_config.joins and len(request.query_config.joins) > 0):
                        _qt_names = []
                        for _qf in (request.query_config.files or []):
                            if _qf.startswith("__registered__:"):
                                _qt_names.append(_qf.replace("__registered__:", ""))
                        if len(_qt_names) == 1:
                            try:
                                _sc = _db_manager.get_schema_cache(conn_id, _qt_names[0])
                                if _sc and _sc.get("schema_data", {}).get("num_rows"):
                                    total_rows = int(_sc["schema_data"]["num_rows"])
                            except Exception:
                                pass
                filtered_rows = total_rows
                logger.info("STREAM-DIAG: total_rows=%d (iceberg_metadata=%d)", total_rows, _iceberg_total)

                total_pages = max(1, (filtered_rows + request.page_size - 1) // request.page_size) if filtered_rows > 0 else -1

                _resp = {
                    "columns": columns,
                    "rows": rows,
                    "total_rows": total_rows,
                    "filtered_rows": filtered_rows,
                    "page": request.page,
                    "page_size": request.page_size,
                    "total_pages": total_pages,
                    "streaming": True,
                    "elapsed_seconds": round(time.monotonic() - _p0, 3),
                }
                if _fstats:
                    _resp["file_stats"] = _fstats
                return _resp
            finally:
                if con is not None:
                    con.close()
                cleanup_temp_downloads()
                if _maybe_ctx is not None:
                    try:
                        _maybe_ctx.__exit__(None, None, None)
                    except Exception as _ctx_exc:
                        logger.debug("[stream_obs] contextvar exit failed: %s", _ctx_exc)

        # Check if client already disconnected
        if http_request and await http_request.is_disconnected():
            logger.info("Stream paginate: client disconnected before execution, skipping")
            if stream_id:
                _unregister_stream(stream_id)
            return {"columns": [], "rows": [], "total_rows": 0, "page": 1,
                    "page_size": request.page_size, "total_pages": 0}

        _page_timeout = float(_qe_cfg.query_timeout_seconds) if _qe_cfg else 1800.0
        try:
            result = await asyncio.wait_for(
                loop.run_in_executor(_get_light_executor_fn(), _run_paginated),
                timeout=_page_timeout,
            )
        except asyncio.TimeoutError:
            _to_min = int(_page_timeout // 60)
            logger.error("Stream paginate: timed out after %.0fs for page=%d", _page_timeout, request.page)
            raise HTTPException(status_code=504, detail=f"S3 query timed out after {_to_min} minutes")

        jsonify_rows(result["rows"])

        elapsed = time.monotonic() - t0
        if stream_id:
            result["stream_id"] = stream_id
        logger.info("Stream paginate: page=%d, rows=%d, cols=%d, elapsed=%.2fs",
                     request.page, len(result["rows"]), len(result.get("columns", [])), elapsed)
        if _obs_active:
            _finalise_stream_execution(
                _db_manager, stream_id,
                status="completed",
                total_rows=int(result.get("filtered_rows") or result.get("total_rows") or len(result.get("rows") or [])),
                file_size_bytes=0,
            )
        return JSONResponse(content=result, headers={"X-Stream-Id": stream_id} if stream_id else {})

    except StreamCancelledError:
        logger.info("Stream paginate %s: cancelled", stream_id)
        if _obs_active:
            _finalise_stream_execution(_db_manager, stream_id, status="cancelled")
        return JSONResponse(status_code=499, content={"detail": "Query cancelled", "stream_id": stream_id})
    except HTTPException:
        raise
    except Exception as e:
        raise_if_s3_auth_error(e)
        logger.error("Stream paginate error: %s", e, exc_info=True)
        if _obs_active:
            _finalise_stream_execution(
                _db_manager, stream_id,
                status="failed",
                error_message=str(e),
            )
        # Phase 120: Agent observe streaming paginate failure
        try:
            from core.agents import get_orchestrator as _get_orch
            from core.proxy_utils import sanitize_proxy_error as _sanitize_err
            _orch = _get_orch()
            if _orch and _orch.enabled:
                _orch.handle_event("query_failed", {
                    "error_message": _sanitize_err(str(e)),
                    "error_type": type(e).__name__,
                    "connection_id": conn_id,
                    "streaming": True,
                })
        except Exception as _agent_exc:
            logger.debug("Agent hook failed (non-fatal): %s", _agent_exc)
        _raise_stream_http_error(e, "Streaming pagination failed")
    finally:
        if stream_id:
            _unregister_stream(stream_id)


# ═══════════════════════════════════════════════════════════════════════════
# POST /api/execute/stream/chart-data — Chart aggregation on full S3 dataset
# ═══════════════════════════════════════════════════════════════════════════
@router.post("/api/execute/stream/chart-data")
async def stream_chart_data(request: StreamChartRequest, _user: dict = Depends(get_current_user)):
    """Chart aggregation directly from S3 — runs GROUP BY on the full dataset."""
    t0 = time.monotonic()
    conn_id, conn, _cfg = await asyncio.to_thread(
        _resolve_connection, request, "chart", False, _user)
    stream_id = _register_stream() if cfg.streaming.cancel_enabled else None

    try:
        from api.data_grid_api import _duckdb_con_with_s3, _q

        registered_tables = _cfg.get("registered_tables", [])
        bucket = (_cfg.get("bucket_name") or "").strip()
        inner_sql, pf, _pt = _build_inner_sql(request, _cfg, registered_tables, bucket, conn_id,
                                              user=_user, request_id=stream_id)

        # Phase 107-C: detect S3 full scan (default action="log", no behavior change)
        _check_stream_s3_guardrail(conn_id=conn_id, primary_tables=_pt, partition_filters=pf,
                                    source="stream_chart_data", user=_user)

        stripped_sql = _stream_body(request, inner_sql)
        _fresh = _want_fresh_iceberg(request)
        _refs = _get_refs(registered_tables, stripped_sql)
        loop = asyncio.get_running_loop()

        def _run_chart():
            nonlocal stripped_sql
            if stream_id:
                _check_cancelled(stream_id)
            con = _duckdb_con_with_s3(_cfg, connection_id=conn_id)
            try:
                _rc, _all_empty, _fstats = _register_s3_views_fn(con, registered_tables, bucket, conn_id, _cfg,
                                      referenced_tables=_refs or None, partition_filters=pf,
                                      primary_tables=_pt, force_fresh_iceberg=_fresh,
                                      db_manager=_db_manager, reader_override=getattr(getattr(request, "query_config", None), "reader_override", None),
                                   joins=getattr(getattr(request, "query_config", None), "joins", None),
                                          raw_sql_present=bool(getattr(getattr(request, "query_config", None), "raw_sql", None)),  # JOIN-PRUNER + BF-375
                                          # 2026-08-22 — was
                                          # request.query_config.raw_sql,
                                          # a field QueryConfigModel does
                                          # not declare, so getattr always
                                          # returned None and the binding
                                          # check was DEAD on the exact
                                          # path the bug was reported on.
                                          # `stream_sql` is the statement
                                          # actually being executed.
                                          raw_sql=stripped_sql)
                # BF-514 — unconditional check for partial-failure path.
                _raise_if_registration_failed(con, conn_id)  # BF-484 + BF-514
                if _all_empty:
                    return {"x_col": request.x_col, "y_col": request.y_col,
                            "agg": request.agg, "multi": False,
                            "grand_total": 0, "data": [],
                            "all_primary_empty": True}
                if stream_id:
                    _check_cancelled(stream_id)
                if "EXCLUDE" in stripped_sql:
                    stripped_sql = _fix_stale_excludes(con, stripped_sql)

                source = f"({stripped_sql}) _src"
                agg_fn = {"sum": "SUM", "avg": "AVG", "max": "MAX", "min": "MIN", "count": "COUNT"}.get(request.agg, "SUM")
                _eff_top_n = min(request.top_n, _limits_cfg.stream_chart_top_n) if request.top_n else _limits_cfg.stream_chart_top_n
                _eff_max_series = min(request.max_series, _limits_cfg.stream_chart_max_series) if request.max_series else _limits_cfg.stream_chart_max_series

                if request.series_col:
                    # Multi-series chart
                    top_series_sql = f"""
                        SELECT COALESCE(CAST({_q(request.series_col)} AS VARCHAR), '(blank)'),
                               {agg_fn}(TRY_CAST({_q(request.y_col)} AS DOUBLE)) AS total
                        FROM {source} GROUP BY 1 ORDER BY total DESC NULLS LAST LIMIT {_eff_max_series}
                    """
                    top_series = [str(r[0]) for r in con.execute(top_series_sql).fetchall()]

                    agg_sql = f"""
                        SELECT CAST({_q(request.x_col)} AS VARCHAR) AS label,
                               COALESCE(CAST({_q(request.series_col)} AS VARCHAR), '(blank)') AS series,
                               {agg_fn}(TRY_CAST({_q(request.y_col)} AS DOUBLE)) AS value
                        FROM {source} GROUP BY 1, 2
                    """
                    import pandas as pd
                    raw_df = con.execute(agg_sql).fetchdf()
                    raw_df.columns = ["label", "series", "value"]
                    raw_df = raw_df[raw_df["series"].isin(top_series)]
                    pivot = raw_df.pivot_table(index="label", columns="series", values="value", aggfunc="sum")
                    pivot = pivot.head(_eff_top_n)
                    grand_total = float(pivot.values[~pd.isna(pivot.values)].sum()) if pivot.size > 0 else 0.0
                    data = []
                    for label in pivot.index:
                        row_dict = {"label": str(label)}
                        for s in top_series:
                            v = pivot.loc[label, s] if s in pivot.columns else None
                            row_dict[s] = None if (v is None or pd.isna(v)) else float(v)
                        data.append(row_dict)
                    return sanitize_for_json({"x_col": request.x_col, "y_col": request.y_col, "agg": request.agg,
                            "series_col": request.series_col, "series": top_series, "multi": True,
                            "grand_total": grand_total, "data": data})
                else:
                    # Single-series chart
                    agg_sql = f"""
                        SELECT CAST({_q(request.x_col)} AS VARCHAR) AS label,
                               {agg_fn}(TRY_CAST({_q(request.y_col)} AS DOUBLE)) AS value,
                               COUNT(*) AS cnt
                        FROM {source} GROUP BY {_q(request.x_col)}
                        ORDER BY value DESC NULLS LAST LIMIT {_eff_top_n}
                    """
                    rows = con.execute(agg_sql).fetchall()
                    grand_total = sum(r[1] for r in rows if r[1] is not None)
                    data = [{"label": str(r[0]), "value": float(r[1]) if r[1] is not None else 0, "count": int(r[2])} for r in rows]
                    return sanitize_for_json({"x_col": request.x_col, "y_col": request.y_col, "agg": request.agg,
                            "multi": False, "grand_total": grand_total, "data": data})
            finally:
                con.close()
                cleanup_temp_downloads()

        result = await asyncio.wait_for(
            loop.run_in_executor(_get_light_executor_fn(), _run_chart),
            timeout=300.0,
        )
        result["elapsed_seconds"] = round(time.monotonic() - t0, 3)
        return result

    except StreamCancelledError:
        logger.info("Stream chart %s: cancelled", stream_id)
        return JSONResponse(status_code=499, content={"detail": "Query cancelled", "stream_id": stream_id})
    except asyncio.TimeoutError:
        raise HTTPException(status_code=504, detail="Chart query timed out") from None
    except HTTPException:
        raise
    except Exception as e:
        raise_if_s3_auth_error(e)
        logger.error("Stream chart error: %s", e, exc_info=True)
        # Phase 120: Agent observe streaming chart failure
        try:
            from core.agents import get_orchestrator as _get_orch
            from core.proxy_utils import sanitize_proxy_error as _sanitize_err
            _orch = _get_orch()
            if _orch and _orch.enabled:
                _orch.handle_event("query_failed", {
                    "error_message": _sanitize_err(str(e)),
                    "error_type": type(e).__name__,
                    "connection_id": conn_id,
                    "streaming": True,
                })
        except Exception as _agent_exc:
            logger.debug("Agent hook failed (non-fatal): %s", _agent_exc)
        _raise_stream_http_error(e, "Stream chart failed")
    finally:
        if stream_id:
            _unregister_stream(stream_id)


# ═══════════════════════════════════════════════════════════════════════════
# POST /api/execute/stream/pivot-data — Pivot aggregation on full S3 dataset
# ═══════════════════════════════════════════════════════════════════════════
@router.post("/api/execute/stream/pivot-data")
async def stream_pivot_data(request: StreamPivotRequest, _user: dict = Depends(get_current_user)):
    """Pivot aggregation directly from S3 — runs GROUP BY on the full dataset."""
    t0 = time.monotonic()
    conn_id, conn, _cfg = await asyncio.to_thread(
        _resolve_connection, request, "pivot", False, _user)
    stream_id = _register_stream() if cfg.streaming.cancel_enabled else None

    try:
        from api.data_grid_api import _duckdb_con_with_s3, _q, _AGG_MAP

        registered_tables = _cfg.get("registered_tables", [])
        bucket = (_cfg.get("bucket_name") or "").strip()
        inner_sql, pf, _pt = _build_inner_sql(request, _cfg, registered_tables, bucket, conn_id,
                                              user=_user, request_id=stream_id)

        # Phase 107-C: detect S3 full scan (default action="log", no behavior change)
        _check_stream_s3_guardrail(conn_id=conn_id, primary_tables=_pt, partition_filters=pf,
                                    source="stream_pivot_data", user=_user)

        stripped_sql = _stream_body(request, inner_sql)
        _fresh = _want_fresh_iceberg(request)
        _refs = _get_refs(registered_tables, stripped_sql)

        row_fields = [f.strip() for f in request.row_fields.split(",") if f.strip()]
        values = json.loads(request.values)
        loop = asyncio.get_running_loop()

        def _run_pivot():
            nonlocal stripped_sql
            if stream_id:
                _check_cancelled(stream_id)
            con = _duckdb_con_with_s3(_cfg, connection_id=conn_id)
            try:
                _rc, _all_empty, _fstats = _register_s3_views_fn(con, registered_tables, bucket, conn_id, _cfg,
                                      referenced_tables=_refs or None, partition_filters=pf,
                                      primary_tables=_pt, force_fresh_iceberg=_fresh,
                                      db_manager=_db_manager, reader_override=getattr(getattr(request, "query_config", None), "reader_override", None),
                                   joins=getattr(getattr(request, "query_config", None), "joins", None),
                                          raw_sql_present=bool(getattr(getattr(request, "query_config", None), "raw_sql", None)),  # JOIN-PRUNER + BF-375
                                          # 2026-08-22 — was
                                          # request.query_config.raw_sql,
                                          # a field QueryConfigModel does
                                          # not declare, so getattr always
                                          # returned None and the binding
                                          # check was DEAD on the exact
                                          # path the bug was reported on.
                                          # `stream_sql` is the statement
                                          # actually being executed.
                                          raw_sql=stripped_sql)
                # BF-514 — unconditional check for partial-failure path.
                _raise_if_registration_failed(con, conn_id)  # BF-484 + BF-514
                if _all_empty:
                    return {"row_fields": row_fields,
                            "col_field": request.col_field or None,
                            "values": values, "total_rows": 0,
                            "rows": [], "col_values": [],
                            "grand_totals": {},
                            "all_primary_empty": True}
                if stream_id:
                    _check_cancelled(stream_id)
                if "EXCLUDE" in stripped_sql:
                    stripped_sql = _fix_stale_excludes(con, stripped_sql)

                source = f"({stripped_sql}) _src"

                # Build aggregation expressions
                agg_exprs = []
                agg_aliases = []
                for i, v in enumerate(values):
                    alias = f"val_{i}"
                    fn = v["function"]
                    col = v.get("column", "*")
                    if fn == "count_rows":
                        agg_exprs.append(f"COUNT(*) AS {alias}")
                    elif fn == "count_distinct":
                        agg_exprs.append(f'COUNT(DISTINCT {_q(col)}) AS {alias}')
                    else:
                        sql_fn = _AGG_MAP.get(fn, "SUM")
                        agg_exprs.append(f'{sql_fn}(TRY_CAST({_q(col)} AS DOUBLE)) AS {alias}')
                    agg_aliases.append(alias)

                if not request.col_field:
                    # Simple pivot: GROUP BY row_fields
                    group_cols = ", ".join(f'CAST({_q(rf)} AS VARCHAR) AS {_q(rf)}' for rf in row_fields)
                    sql = f"SELECT {group_cols}, {', '.join(agg_exprs)} FROM {source} GROUP BY {', '.join(str(i+1) for i in range(len(row_fields)))} ORDER BY {agg_aliases[0]} DESC NULLS LAST LIMIT {request.top_n}"
                    rows = con.execute(sql).fetchall()
                    total_rows = int(con.execute(f"SELECT COUNT(*) FROM {source}").fetchone()[0])
                    grand_sql = f"SELECT {', '.join(agg_exprs)} FROM {source}"
                    grand_row = con.execute(grand_sql).fetchone()
                    grand_totals = {agg_aliases[i]: (float(grand_row[i]) if grand_row[i] is not None else 0) for i in range(len(agg_aliases))}
                    result_rows = []
                    for row in rows:
                        d = {}
                        for j, rf in enumerate(row_fields):
                            d[rf] = str(row[j]) if row[j] is not None else "(blank)"
                        for j, alias in enumerate(agg_aliases):
                            d[alias] = float(row[len(row_fields) + j]) if row[len(row_fields) + j] is not None else 0
                        result_rows.append(d)
                    return sanitize_for_json({"row_fields": row_fields, "col_field": None, "values": values,
                            "total_rows": total_rows, "rows": result_rows, "col_values": [],
                            "grand_totals": grand_totals})
                else:
                    # Cross-tab pivot
                    col_vals_sql = f"SELECT DISTINCT CAST({_q(request.col_field)} AS VARCHAR) FROM {source} ORDER BY 1 LIMIT 20"
                    col_values = [str(r[0]) for r in con.execute(col_vals_sql).fetchall() if r[0] is not None]
                    group_cols = ", ".join(f'CAST({_q(rf)} AS VARCHAR) AS {_q(rf)}' for rf in row_fields)
                    ct_exprs = []
                    for cv in col_values:
                        cv_esc = cv.replace("'", "''")
                        for i, v in enumerate(values):
                            fn = v["function"]
                            col = v.get("column", "*")
                            alias = f"val_{i}__{cv.replace(' ', '_')}"
                            if fn == "count_rows":
                                ct_exprs.append(f"COUNT(CASE WHEN CAST({_q(request.col_field)} AS VARCHAR) = '{cv_esc}' THEN 1 END) AS \"{alias}\"")
                            else:
                                sql_fn = _AGG_MAP.get(fn, "SUM")
                                ct_exprs.append(f"{sql_fn}(CASE WHEN CAST({_q(request.col_field)} AS VARCHAR) = '{cv_esc}' THEN TRY_CAST({_q(col)} AS DOUBLE) END) AS \"{alias}\"")
                    sql = f"SELECT {group_cols}, {', '.join(ct_exprs)} FROM {source} GROUP BY {', '.join(str(i+1) for i in range(len(row_fields)))} LIMIT {request.top_n}"
                    rows_data = con.execute(sql).fetchall()
                    desc = [d[0] for d in con.execute(f"SELECT {group_cols}, {', '.join(ct_exprs)} FROM {source} GROUP BY {', '.join(str(i+1) for i in range(len(row_fields)))} LIMIT 0").description]
                    total_rows = int(con.execute(f"SELECT COUNT(*) FROM {source}").fetchone()[0])
                    grand_sql = f"SELECT {', '.join(agg_exprs)} FROM {source}"
                    grand_row = con.execute(grand_sql).fetchone()
                    grand_totals = {agg_aliases[i]: (float(grand_row[i]) if grand_row[i] is not None else 0) for i in range(len(agg_aliases))}
                    result_rows = []
                    for row in rows_data:
                        d = {desc[j]: (str(row[j]) if j < len(row_fields) else (float(row[j]) if row[j] is not None else 0)) for j in range(len(row))}
                        result_rows.append(d)
                    return sanitize_for_json({"row_fields": row_fields, "col_field": request.col_field, "values": values,
                            "total_rows": total_rows, "rows": result_rows, "col_values": col_values,
                            "grand_totals": grand_totals})
            finally:
                con.close()
                cleanup_temp_downloads()

        result = await asyncio.wait_for(
            loop.run_in_executor(_get_light_executor_fn(), _run_pivot),
            timeout=300.0,
        )
        result["elapsed_seconds"] = round(time.monotonic() - t0, 3)
        return result

    except StreamCancelledError:
        logger.info("Stream pivot %s: cancelled", stream_id)
        return JSONResponse(status_code=499, content={"detail": "Query cancelled", "stream_id": stream_id})
    except asyncio.TimeoutError:
        raise HTTPException(status_code=504, detail="Pivot query timed out") from None
    except HTTPException:
        raise
    except Exception as e:
        raise_if_s3_auth_error(e)
        logger.error("Stream pivot error: %s", e, exc_info=True)
        # Phase 120: Agent observe streaming pivot failure
        try:
            from core.agents import get_orchestrator as _get_orch
            from core.proxy_utils import sanitize_proxy_error as _sanitize_err
            _orch = _get_orch()
            if _orch and _orch.enabled:
                _orch.handle_event("query_failed", {
                    "error_message": _sanitize_err(str(e)),
                    "error_type": type(e).__name__,
                    "connection_id": conn_id,
                    "streaming": True,
                })
        except Exception as _agent_exc:
            logger.debug("Agent hook failed (non-fatal): %s", _agent_exc)
        _raise_stream_http_error(e, "Stream pivot failed")
    finally:
        if stream_id:
            _unregister_stream(stream_id)
