"""User-draft REST API — Phase 142 — Enterprise context preservation.

Endpoints:
  GET    /api/user/drafts/{key}    → load my draft ({content: null, set: false} if absent)
  PUT    /api/user/drafts/{key}    → upsert my draft
  DELETE /api/user/drafts/{key}    → delete my draft (idempotent)
  GET    /api/user/drafts          → list MY drafts (summaries only)
  GET    /api/user/drafts/prefix/{p} → list MY drafts under prefix `p`
  GET    /api/admin/drafts/stats   → admin stats (count, bytes, users)

All endpoints auth-scoped: drafts are PER USER.  The path's ``{key}`` is
namespaced by the frontend (e.g. ``cqb.sql.5`` for CQB SQL on conn 5).

Rate-limited (30 PUTs/min/user) so a buggy hook can't hammer the DB.

ISOLATED FROM QUERY LOAD (2026-10-07).  On the Docker login rig at 100
concurrent workers a draft save went p50 0.3 s -> 4.6 s, p95 10.3 s, max
13.4 s: the builder writes it (debounced 2 s) while the user types, and
nothing about a one-row upsert takes seconds.  Two shared queues stood in
front of it: the principal was resolved by a SYNC dependency (anyio's worker
threads, shared by every sync dependency and route on the pod), and the DB
call ran on asyncio's DEFAULT executor (``asyncio.to_thread``, ~16-32
threads shared by ~600 call sites, under load the query traffic's own
queue).  Now the principal comes from ``api.deps.aget_current_user`` (the
middleware's resolution, on the loop) and every DB call runs on the
dedicated ``drafts`` lane (``core/interactive_lanes.py``, 4 threads that
serve nothing else).  Drafts never pass query admission and never did; now
they also never wait behind it.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List

from fastapi import APIRouter, Depends, HTTPException, Path, Request
from pydantic import BaseModel

from api.deps import aget_current_user, require_admin
from core.audit import audit_event

logger = logging.getLogger(__name__)
router = APIRouter(tags=["user-drafts"])


# ── Pydantic schemas ───────────────────────────────────────────────────────


class DraftUpsertBody(BaseModel):
    content: Any   # any JSON-serialisable value


# ── Module wiring ──────────────────────────────────────────────────────────


_db_manager = None


def set_user_drafts_dependencies(db_manager) -> None:
    global _db_manager
    _db_manager = db_manager


def _db():
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Database not ready")
    return _db_manager


async def _adb(fn, *args, **kwargs):
    # 2026-10-07: the dedicated drafts lane, never the default executor.
    from core.interactive_lanes import run_in_lane
    return await run_in_lane("drafts", fn, *args, **kwargs)


def _config_caps() -> Dict[str, int]:
    """Resolve config caps with safe fallbacks if config isn't loaded yet."""
    try:
        from core.config import user_drafts as _cfg
        return {
            "per_draft_max_bytes": int(_cfg.per_draft_max_mb * 1024 * 1024),
            "per_user_max_bytes":  int(_cfg.per_user_max_mb * 1024 * 1024),
            "retention_days":      int(_cfg.retention_days),
            "enabled":             bool(_cfg.enabled),
        }
    except Exception:
        return {
            "per_draft_max_bytes": 5 * 1024 * 1024,
            "per_user_max_bytes":  50 * 1024 * 1024,
            "retention_days":      30,
            "enabled":             True,
        }


def _check_enabled() -> None:
    caps = _config_caps()
    if not caps["enabled"]:
        raise HTTPException(
            status_code=503,
            detail="user_drafts feature is disabled in config",
        )


# ── Rate limiting (simple in-memory; mirrors existing patterns) ────────────


import time  # noqa: E402
import threading  # noqa: E402
_RATE_LOCK = threading.Lock()
_RATE_BUCKET: Dict[str, List[float]] = {}
_RATE_LIMIT_PUTS_PER_MIN = 30


def _check_put_rate(username: str) -> None:
    """Raise HTTP 429 when ``username`` exceeds 30 PUTs/min.  Bucket is
    rotated lazily — entries older than 60s are dropped on read."""
    if not username:
        return
    now = time.time()
    with _RATE_LOCK:
        bucket = _RATE_BUCKET.setdefault(username, [])
        # Drop old timestamps
        cutoff = now - 60.0
        bucket[:] = [t for t in bucket if t >= cutoff]
        if len(bucket) >= _RATE_LIMIT_PUTS_PER_MIN:
            raise HTTPException(
                status_code=429,
                detail=(f"draft save rate limit exceeded "
                         f"({_RATE_LIMIT_PUTS_PER_MIN}/min) — "
                         "increase the hook's debounce interval"),
            )
        bucket.append(now)


# ── Endpoints ──────────────────────────────────────────────────────────────


@router.get("/api/user/drafts/{key:path}")
async def get_draft(
    key: str = Path(..., description="Draft key (e.g. 'cqb.sql.5')"),
    user: dict = Depends(aget_current_user),
) -> Dict[str, Any]:
    _check_enabled()
    username = (user or {}).get("username", "")
    if not username:
        raise HTTPException(status_code=401, detail="unauthenticated")
    draft = await _adb(_db().get_user_draft, username, key)
    if draft is None:
        # AQD-02 (2026-09-23): "no draft yet" is an ANSWER, not an error.
        # This used to 404, so /dashboards and /schedules -- which ask for the
        # draft of a NEW item, a key that cannot exist yet -- painted a console
        # error on every single visit.  Its sibling, /api/user-preferences,
        # was changed for exactly that reason (FB-35) to answer
        # {value: null, set: false}; two per-user key-value stores answering
        # "is this key set?" two different ways was the same question with two
        # answers.  Same shape here, with the key this store calls `content`.
        return {"key": key, "content": None, "set": False}
    return {**draft, "set": True}


@router.put("/api/user/drafts/{key:path}")
async def put_draft(
    body: DraftUpsertBody,
    request: Request,
    key: str = Path(..., description="Draft key"),
    user: dict = Depends(aget_current_user),
) -> Dict[str, Any]:
    _check_enabled()
    username = (user or {}).get("username", "")
    if not username:
        raise HTTPException(status_code=401, detail="unauthenticated")
    _check_put_rate(username)
    caps = _config_caps()
    try:
        updated = await _adb(
            _db().upsert_user_draft,
            username, key, body.content,
            caps["per_draft_max_bytes"],
            caps["per_user_max_bytes"],
        )
    except ValueError as exc:
        # Size cap exceeded → 413
        raise HTTPException(status_code=413, detail=str(exc))
    # Fire-and-forget audit (no resource_id needed — username + key uniquely id it)
    audit_event(
        _db(), user, request, "upsert_user_draft",
        resource_type="user_draft", resource_id=key,
        details={"size_bytes": updated.get("size_bytes", 0)},
    )
    # Return summary (omit content — caller already has it)
    return {
        "draft_key":  updated["draft_key"],
        "size_bytes": updated["size_bytes"],
        "updated_at": updated["updated_at"],
    }


@router.delete("/api/user/drafts/{key:path}", status_code=204)
async def delete_draft(
    request: Request,
    key: str = Path(..., description="Draft key"),
    user: dict = Depends(aget_current_user),
):
    _check_enabled()
    username = (user or {}).get("username", "")
    if not username:
        raise HTTPException(status_code=401, detail="unauthenticated")
    await _adb(_db().delete_user_draft, username, key)
    audit_event(
        _db(), user, request, "delete_user_draft",
        resource_type="user_draft", resource_id=key,
    )
    return None


@router.get("/api/user/drafts")
async def list_drafts(
    user: dict = Depends(aget_current_user),
) -> List[Dict[str, Any]]:
    _check_enabled()
    username = (user or {}).get("username", "")
    if not username:
        raise HTTPException(status_code=401, detail="unauthenticated")
    return await _adb(_db().list_user_drafts, username)


@router.get("/api/user/drafts-by-prefix/{prefix:path}")
async def list_drafts_by_prefix(
    prefix: str = Path(..., description="Key prefix"),
    user: dict = Depends(aget_current_user),
) -> List[Dict[str, Any]]:
    _check_enabled()
    username = (user or {}).get("username", "")
    if not username:
        raise HTTPException(status_code=401, detail="unauthenticated")
    return await _adb(_db().list_user_drafts_by_prefix, username, prefix)


@router.get("/api/admin/drafts/stats")
async def admin_draft_stats(
    user: dict = Depends(require_admin),
) -> Dict[str, Any]:
    """Admin-only summary: total drafts, bytes, unique users."""
    _check_enabled()
    return await _adb(_db().user_draft_stats)
