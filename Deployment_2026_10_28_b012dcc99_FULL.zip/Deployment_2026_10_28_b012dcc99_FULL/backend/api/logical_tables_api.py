"""Phase 146-B — Admin API for logical tables + bindings.

Class-based router: all endpoints hang off ``router`` at the bottom.
Business logic delegated to
:class:`core.logical_table_service.LogicalTableService`; this module
is thin HTTP-plumbing only, matching the pattern used by the other
admin API modules in the tree.

Endpoints:
  * ``GET  /api/admin/logical-tables``                       -- list
  * ``POST /api/admin/logical-tables``                       -- create
  * ``GET  /api/admin/logical-tables/{id}``                  -- detail
  * ``PUT  /api/admin/logical-tables/{id}``                  -- update
  * ``DELETE /api/admin/logical-tables/{id}``                -- delete
  * ``GET  /api/admin/logical-tables/{id}/bindings``         -- list bindings
  * ``POST /api/admin/logical-tables/{id}/bindings``         -- create binding
  * ``POST /api/admin/logical-tables/{id}/bindings/bulk-add`` -- bulk upsert
  * ``PUT  /api/admin/logical-tables/bindings/{binding_id}`` -- update binding
  * ``DELETE /api/admin/logical-tables/bindings/{binding_id}`` -- delete
  * ``GET  /api/admin/logical-tables/by-connection/{conn_id}`` -- reverse
  * ``GET  /api/admin/published-views/{pv_id}/compat-report`` -- (in
       existing admin_api.py; the delegating call lives there)

All endpoints require admin role.
"""
from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from api.deps import require_admin


_LOG = logging.getLogger(__name__)


# ── Pydantic models ────────────────────────────────────────────────────


class LogicalTableCreate(BaseModel):
    logical_name: str = Field(min_length=1, max_length=100)
    description:  Optional[str] = None


class LogicalTableUpdate(BaseModel):
    logical_name: Optional[str] = Field(None, min_length=1, max_length=100)
    description:  Optional[str] = None


class BindingCreate(BaseModel):
    connection_id: int
    physical_ref:  str = Field(min_length=1, max_length=500)


class BindingUpdate(BaseModel):
    physical_ref:  str = Field(min_length=1, max_length=500)


class BulkAddBinding(BaseModel):
    connection_id: int
    physical_ref:  str = Field(min_length=1, max_length=500)


class BulkAddRequest(BaseModel):
    bindings: List[BulkAddBinding] = Field(min_length=1, max_length=200)


# ── Router ─────────────────────────────────────────────────────────────


router = APIRouter(prefix="/api/admin/logical-tables", tags=["admin"])


def _db():
    from core.database import get_db_manager
    return get_db_manager()


def _service():
    from core.logical_table_service import get_service
    return get_service()


def _require_admin(user):
    """Fallback local guard for tests that inject a bare dict.
    In prod the ``Depends(require_admin)`` upstream already enforces
    it.  Here to keep unit tests hermetic.

    Uses the centralized ``is_admin_like`` helper so support-role
    users are accepted the same way as elsewhere in the tree.
    """
    if user is None:
        return
    if not isinstance(user, dict):
        return
    from core.roles import is_admin_like
    if not is_admin_like(user):
        raise HTTPException(403, "Admin role required")


# ── LogicalTable CRUD ──────────────────────────────────────────────────


@router.get("")
async def list_logical_tables(
    user: dict = Depends(require_admin),  # actual auth wired in main app
) -> List[Dict[str, Any]]:
    """List every logical table.  Admin only."""
    _require_admin(user)
    return _db().list_logical_tables()


@router.post("", status_code=201)
async def create_logical_table(
    body: LogicalTableCreate,
    user: dict = Depends(require_admin),
) -> Dict[str, Any]:
    _require_admin(user)
    # Refuse duplicates loudly (SQLAlchemy IntegrityError is generic).
    if _db().get_logical_table_by_name(body.logical_name):
        raise HTTPException(409, f"logical_name={body.logical_name!r} exists")
    row = _db().create_logical_table(
        logical_name=body.logical_name,
        description=body.description or "",
        created_by=(user or {}).get("username", ""),
    )
    _service().invalidate(logical_name=body.logical_name)
    return row


@router.get("/{lt_id}")
async def get_logical_table(
    lt_id: int, user: dict = Depends(require_admin),
) -> Dict[str, Any]:
    _require_admin(user)
    row = _db().get_logical_table(lt_id)
    if not row:
        raise HTTPException(404, "logical table not found")
    return row


@router.put("/{lt_id}")
async def update_logical_table(
    lt_id: int, body: LogicalTableUpdate,
    user: dict = Depends(require_admin),
) -> Dict[str, Any]:
    _require_admin(user)
    payload = {k: v for k, v in body.dict(exclude_unset=True).items()
               if v is not None}
    if not payload:
        raise HTTPException(400, "no fields to update")
    row = _db().update_logical_table(lt_id, **payload)
    if not row:
        raise HTTPException(404, "logical table not found")
    _service().invalidate(logical_name=row["logical_name"])
    return row


@router.delete("/{lt_id}", status_code=204)
async def delete_logical_table(
    lt_id: int, user: dict = Depends(require_admin),
):  # NB: no `-> None` return annotation -- on some FastAPI versions a return
    # annotation on a 204 route raises "Status code 204 must not have a
    # response body" at import (startup crash).  Matches the other 204 routes.
    _require_admin(user)
    row = _db().get_logical_table(lt_id)
    if not row:
        raise HTTPException(404, "logical table not found")
    ok = _db().delete_logical_table(lt_id)
    if not ok:
        raise HTTPException(500, "delete failed")
    _service().invalidate(logical_name=row["logical_name"])


# ── Binding CRUD ───────────────────────────────────────────────────────


@router.get("/{lt_id}/bindings")
async def list_bindings(
    lt_id: int, user: dict = Depends(require_admin),
) -> List[Dict[str, Any]]:
    _require_admin(user)
    if not _db().get_logical_table(lt_id):
        raise HTTPException(404, "logical table not found")
    return _db().list_bindings_for_logical(lt_id)


@router.post("/{lt_id}/bindings", status_code=201)
async def create_binding(
    lt_id: int, body: BindingCreate,
    user: dict = Depends(require_admin),
) -> Dict[str, Any]:
    _require_admin(user)
    lt = _db().get_logical_table(lt_id)
    if not lt:
        raise HTTPException(404, "logical table not found")
    if _db().get_logical_binding(lt_id, body.connection_id):
        raise HTTPException(
            409,
            f"binding exists for logical={lt['logical_name']!r} "
            f"connection_id={body.connection_id}",
        )
    row = _db().create_logical_binding(
        logical_table_id=lt_id,
        connection_id=body.connection_id,
        physical_ref=body.physical_ref,
        created_by=(user or {}).get("username", ""),
    )
    _service().invalidate(
        logical_name=lt["logical_name"], connection_id=body.connection_id,
    )
    return row


@router.post("/{lt_id}/bindings/bulk-add")
async def bulk_add_bindings(
    lt_id: int, body: BulkAddRequest,
    user: dict = Depends(require_admin),
) -> Dict[str, Any]:
    """Idempotent bulk create-or-update.  Common flow: "set bindings
    for these N connections in one call".  Returns summary counts +
    the resulting bindings."""
    _require_admin(user)
    lt = _db().get_logical_table(lt_id)
    if not lt:
        raise HTTPException(404, "logical table not found")
    created = 0
    updated = 0
    results = []
    for item in body.bindings:
        pre = _db().get_logical_binding(lt_id, item.connection_id)
        row = _db().upsert_logical_binding(
            logical_table_id=lt_id,
            connection_id=item.connection_id,
            physical_ref=item.physical_ref,
            created_by=(user or {}).get("username", ""),
        )
        if pre is None:
            created += 1
        else:
            updated += 1
        results.append(row)
    _service().invalidate(logical_name=lt["logical_name"])
    return {
        "created": created,
        "updated": updated,
        "bindings": results,
    }


@router.put("/bindings/{binding_id}")
async def update_binding(
    binding_id: int, body: BindingUpdate,
    user: dict = Depends(require_admin),
) -> Dict[str, Any]:
    _require_admin(user)
    row = _db().update_logical_binding(
        binding_id, physical_ref=body.physical_ref,
    )
    if not row:
        raise HTTPException(404, "binding not found")
    # Look up logical name for cache invalidation.
    lt = _db().get_logical_table(row["logical_table_id"])
    if lt:
        _service().invalidate(
            logical_name=lt["logical_name"],
            connection_id=row["connection_id"],
        )
    return row


@router.delete("/bindings/{binding_id}", status_code=204)
async def delete_binding(
    binding_id: int, user: dict = Depends(require_admin),
):  # no `-> None` -- see delete_logical_table above (204 + return annotation
    # crashes at import on some FastAPI versions).
    _require_admin(user)
    # Snapshot for cache invalidation BEFORE delete.
    from core.db.models import LogicalTableBinding
    db = _db()
    with db.get_session(read_only=True) as session:
        b = session.query(LogicalTableBinding).filter(
            LogicalTableBinding.id == binding_id,
        ).first()
        b_snap = b.to_dict() if b else None
    if not b_snap:
        raise HTTPException(404, "binding not found")
    ok = db.delete_logical_binding(binding_id)
    if not ok:
        raise HTTPException(500, "delete failed")
    lt = db.get_logical_table(b_snap["logical_table_id"])
    if lt:
        _service().invalidate(
            logical_name=lt["logical_name"],
            connection_id=b_snap["connection_id"],
        )


@router.get("/by-connection/{conn_id}")
async def list_bindings_by_connection(
    conn_id: int, user: dict = Depends(require_admin),
) -> List[Dict[str, Any]]:
    """Reverse lookup: every logical binding on a given connection.
    Feeds the "Bound logical tables" panel on the connection edit
    page (Phase 146-C UI)."""
    _require_admin(user)
    rows = _db().list_bindings_for_connection(conn_id)
    # Enrich with logical_name so the UI doesn't need a second call.
    for r in rows:
        lt = _db().get_logical_table(r["logical_table_id"])
        r["logical_name"] = lt["logical_name"] if lt else None
    return rows


# ── Phase 146-C: compat-report + connection-scoped dependent-PV lookup ──


# Compat-report lives at a PV-scoped path (per TRACKING.md's
# ``GET /api/admin/published-views/{id}/compat-report``) rather than
# under logical-tables; we mount it here to avoid a second router
# file for one endpoint, since the resolver logic lives with the
# service.  Uses a distinct APIRouter so the prefix differs.
_pv_router = APIRouter(prefix="/api/admin/published-views", tags=["admin"])


@_pv_router.get("/{pv_id}/compat-report")
async def pv_compat_report(
    pv_id: int, user: dict = Depends(require_admin),
) -> Dict[str, Any]:
    """Full matrix of (logical_name × allowed_engine_connection) ->
    state.  Feeds the admin "Compatibility" tab so a rename / edit /
    binding-drift shows up without a fresh publish."""
    _require_admin(user)
    pv = _db().get_published_view(pv_id)
    if not pv:
        raise HTTPException(404, "published view not found")
    qc = pv.get("query_config") or {}
    sql = (qc.get("raw_sql") or qc.get("custom_sql") or "").strip()
    secondary_sql = (qc.get("secondary_raw_sql") or "").strip()
    # Union primary + secondary engine sets so cross-source PVs
    # get one combined matrix.
    engines: List[int] = []
    if pv.get("connection_id") is not None:
        engines.append(int(pv["connection_id"]))
    for cid in pv.get("allowed_engine_connections") or []:
        if int(cid) not in engines:
            engines.append(int(cid))
    if qc.get("secondary_connection_id") is not None:
        if int(qc["secondary_connection_id"]) not in engines:
            engines.append(int(qc["secondary_connection_id"]))
    combined_sql = "\n".join(x for x in (sql, secondary_sql) if x)
    if not combined_sql or "__logical__:" not in combined_sql.lower():
        return {
            "pv_id":       pv_id,
            "slug":        pv.get("slug"),
            "referenced": [],
            "engines":    engines,
            "matrix":     [],
            "note":       "PV does not reference any __logical__: names",
        }
    matrix = _service().compat_matrix(
        combined_sql, allowed_engine_connections=engines,
    )
    matrix["pv_id"] = pv_id
    matrix["slug"] = pv.get("slug")
    return matrix


@_pv_router.get("/by-connection/{conn_id}/dependent")
async def dependent_pvs_for_connection(
    conn_id: int, user: dict = Depends(require_admin),
) -> List[Dict[str, Any]]:
    """Every active PV that includes ``conn_id`` in its
    ``allowed_engine_connections`` OR uses it as the primary /
    secondary connection.  Feeds the "Dependent published views"
    panel on the connection edit page so an admin sees who breaks
    if the connection is removed."""
    _require_admin(user)
    dependents = []
    for pv in _db().list_published_views(active_only=True):
        _matches = False
        if pv.get("connection_id") == conn_id:
            _matches = True
        elif conn_id in (pv.get("allowed_engine_connections") or []):
            _matches = True
        else:
            qc = pv.get("query_config") or {}
            if qc.get("secondary_connection_id") == conn_id:
                _matches = True
        if _matches:
            dependents.append({
                "id":          pv["id"],
                "slug":        pv["slug"],
                "name":        pv["name"],
                "role":        (
                    "primary"     if pv.get("connection_id") == conn_id
                    else "engine" if conn_id in (
                        pv.get("allowed_engine_connections") or []
                    )
                    else "secondary"
                ),
                "is_active":   pv.get("is_active", True),
            })
    return dependents
