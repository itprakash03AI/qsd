"""FB-38 (2026-09-19) -- Iceberg time travel is a CAPABILITY a view declares,
asked ONCE, before a request that depends on it is answered.

Every published lane advertises ``?snapshot_id=`` / ``?as_of_timestamp=``,
and only the saved_query handler implements them -- the business_report and
federation handlers accepted both and returned CURRENT data with HTTP 200.
Measured on the rig: the travelled and the ignored answer differed by
138,033,109.63 in sum(amt); the response shape, columns and status were
identical.  A mistyped snapshot id silently changed the answer instead of
failing.  The limitation lived in a Python comment ("time travel:
saved_query-only ... unused") and nothing reached the caller.

Even the saved_query lane travels only when the frozen query reads an
ICEBERG table: an S3 parquet file, a local file or a SQL-connector saved
query (no ``FOR VERSION AS OF`` is emitted anywhere in this codebase) has no
snapshot to travel to, and the parameter was stashed into ``query_config``
and consumed by nothing.

This module answers "can THIS view travel?" once.  The dispatcher and the
three handlers refuse from it; ``GET /api/v1/views/{slug}`` reports it as
``time_travel_supported`` so a consumer can ask before it pulls -- the same
shape as ``/api/feeds/backend-options`` (available + detail), Clockwork
(routable + reason) and row-security (``materialize_views_available`` +
``_unavailable_reason``).

The answer is tri-state.  ``None`` means "could not tell" (the connection
that would say whether a registered table is Iceberg could not be read) and
the caller refuses as a 503, never as "no".  Unknown is not empty.
"""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Optional, Tuple

#: Source types whose handler implements ``snapshot_id`` / ``as_of_timestamp``.
#: A plugin that registers a new source type in ``_SOURCE_HANDLERS`` and
#: implements time travel adds itself here; otherwise its views refuse.
TIME_TRAVEL_SOURCE_TYPES = frozenset({"saved_query"})

_ICEBERG_PREFIX = "__iceberg__:"
_REGISTERED_PREFIX = "__registered__:"


def _ref_path(ref: Any) -> str:
    if isinstance(ref, str):
        return ref
    if isinstance(ref, dict):
        return str(ref.get("path") or ref.get("name") or "")
    return ""


def _registered_iceberg_names(connection_config: Optional[Dict[str, Any]]) -> Dict[str, str]:
    """{lower_name: name} of the connection's registered tables whose
    ``format`` is iceberg (the marker ``core.duckdb_views`` branches on)."""
    out: Dict[str, str] = {}
    for tbl in (connection_config or {}).get("registered_tables") or []:
        if not isinstance(tbl, dict):
            continue
        name = tbl.get("name")
        if name and str(tbl.get("format") or "parquet").lower() == "iceberg":
            out[str(name).lower()] = str(name)
    return out


def iceberg_table_refs(query_config: Dict[str, Any],
                       connection_config: Optional[Dict[str, Any]] = None) -> List[str]:
    """The Iceberg tables a frozen ``query_config`` reads: ``__iceberg__:x``
    refs, ``__registered__:x`` / bare refs whose registered table is
    iceberg, and -- for a raw_sql query with no ``files`` -- registered
    iceberg names that appear in the SQL text."""
    registered = _registered_iceberg_names(connection_config)
    names: List[str] = []
    refs: Iterable[Any] = (query_config or {}).get("files") or []
    for ref in refs:
        path = _ref_path(ref).strip()
        if not path:
            continue
        if path.startswith(_ICEBERG_PREFIX):
            names.append(path[len(_ICEBERG_PREFIX):].strip())
        elif path.startswith(_REGISTERED_PREFIX):
            bare = path[len(_REGISTERED_PREFIX):].strip()
            if bare.lower() in registered:
                names.append(registered[bare.lower()])
        elif "/" not in path and ":" not in path and path.lower() in registered:
            names.append(registered[path.lower()])
    raw_sql = str((query_config or {}).get("raw_sql") or "")
    if raw_sql and registered:
        low = raw_sql.lower()
        for lname, name in registered.items():
            if re.search(r"\b" + re.escape(lname) + r"\b", low):
                names.append(name)
    return sorted(set(names))


def time_travel_capability(pv: Dict[str, Any],
                           connection_config: Optional[Dict[str, Any]] = None,
                           *, connection_unreadable: Optional[str] = None,
                           ) -> Tuple[Optional[bool], Optional[str]]:
    """(supported, reason).  ``supported`` is True, False, or None when the
    answer could not be determined (``connection_unreadable`` says why).
    ``reason`` is written for the consumer and is None only when supported."""
    src = str(pv.get("source_type") or "saved_query")
    slug = pv.get("slug") or "{slug}"
    if src not in TIME_TRAVEL_SOURCE_TYPES:
        return False, (
            f"Time travel (?snapshot_id= / ?as_of_timestamp=) is not implemented "
            f"for a view whose source_type is '{src}': only a saved_query view "
            f"over an Iceberg table can read a named snapshot.  The request is "
            f"refused rather than answered with CURRENT data under a historical "
            f"label.  GET /api/v1/views/{slug} reports time_travel_supported.")
    qc = pv.get("query_config") or {}
    tables = iceberg_table_refs(qc, connection_config)
    if tables:
        return True, None
    if connection_unreadable:
        return None, (
            f"Whether this view supports time travel could not be determined: "
            f"{connection_unreadable}.  The request is refused rather than "
            f"answered with data of unknown vintage; retry, or ask an "
            f"administrator to check connection {qc.get('connection_id')!r}.")
    return False, (
        f"Time travel (?snapshot_id= / ?as_of_timestamp=) is not available on "
        f"this view: its frozen query reads no Iceberg table (S3 parquet, "
        f"local files and SQL-connector sources have no snapshots to travel "
        f"to), so a snapshot would be ignored and CURRENT data returned.  The "
        f"request is refused instead.  GET /api/v1/views/{slug} reports "
        f"time_travel_supported.")
