"""Columnar CSV / JSON-lines encoding for the bulk Published API (2026-10-04).

WHY
---
The bulk text encoders turned every decoded batch into Python dicts
(``RecordBatch.to_pylist`` + ``sanitize_for_json`` per cell) and then wrote
each dict through ``csv.DictWriter`` / ``json.dumps``.  Measured live: a
10,000,000-row ``/bulk?format=csv`` took 152 s (~66k rows/s); in process,
on a 10-column report-shaped dataset, ~29k rows/s for CSV and ~20k rows/s
for JSONL.  Every cell paid for a Python object, a type dispatch and a dict
lookup.

This module formats a batch COLUMN BY COLUMN with Arrow compute kernels
(C++) and assembles the rows with ``binary_join_element_wise`` -- no
per-row Python object exists on the common types.

THE CONTRACT IS THE OLD BYTES
-----------------------------
The rendering a consumer already parses is the contract, so every value is
spelled exactly as the row encoder spelled it (``sanitize_for_json`` then
``csv`` / ``json.dumps``) -- proven byte-for-byte across the type matrix by
``tests/test_bulk_text_encoding_2026_10_04.py``:

* CSV -- the ``excel`` dialect: ``,`` separated, ``\\r\\n`` after every row
  (the header too), QUOTE_MINIMAL (a field containing ``,`` ``"`` ``\\r`` or
  ``\\n`` is quoted, ``"`` doubled), NULL = empty field, and a ROW OF ONE
  EMPTY FIELD is written ``""`` (csv's rule, so a one-column NULL row is not
  a blank line).  No BOM.
* JSONL -- one ``json.dumps(..., ensure_ascii=False, separators=(",",
  ":"))`` object per line, ``\\n`` terminated.
* Values -- ints as digits; floats as Python ``repr`` (``1.0``, ``1e+16``,
  ``1.5e-05``, ``-0.0``) with NaN / +-inf -> NULL; booleans ``True`` /
  ``False`` in CSV, ``true`` / ``false`` in JSON; decimals with <= 15
  significant digits as the nearest float's repr (``100.00`` -> ``100.0``),
  wider ones as the exact decimal text (a JSON STRING, BF-560); dates
  ``YYYY-MM-DD``; timestamps ISO-8601 ``T``-separated, fraction only when
  non-zero (6 digits; 9 for a nanosecond remainder), a zoned value in its
  zone's wall time with ``+HH:MM``.

Types this module does not format natively (time, duration, binary,
nested, half-float, a timestamp outside years 1..9999 or a zone with a
seconds offset, a JSON string carrying a rare control character) are
formatted PER CELL through the very functions the row encoder used -- so
an unusual column costs speed, never bytes.

One deliberate difference, documented in the skill: CSV with DUPLICATE
column names.  The row encoder built a dict per row, so every duplicate
header carried the LAST duplicate's value (a silent wrong-column read).
Each CSV column now carries its own value.  JSONL keeps the dict
semantics (one key, the last value, at the first key's position): a JSON
object cannot carry a key twice.
"""
from __future__ import annotations

import csv
import io
import json
import re
from collections.abc import Callable, Sequence
from typing import Any

from core.json_utils import sanitize_for_json

__all__ = ["csv_header", "csv_rows", "json_array_items", "json_row_texts",
           "jsonl_rows"]

#: The reference spelling of a float -- what ``csv`` and ``json`` wrote.
_FLOAT_REPR = float.__repr__

_UNIT_PER_SECOND = {"s": 1, "ms": 1_000, "us": 1_000_000, "ns": 1_000_000_000}

# Years a Python ``datetime`` can hold.  Outside them the row encoder got a
# different object (a pandas Timestamp, or an error), so such a column is
# formatted per cell -- never guessed at natively.
_MIN_TS_S = -62135596800          # 0001-01-01T00:00:00
_MAX_TS_S = 253402300799          # 9999-12-31T23:59:59


def _pa():
    import pyarrow as pa
    return pa


def _pc():
    import pyarrow.compute as pc
    return pc


def _dumps(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, allow_nan=False,
                      separators=(",", ":"))


# ══════════════════════════════════════════════════════════════════════════
# The per-cell reference (the row encoder's own functions) -- the fallback
# ══════════════════════════════════════════════════════════════════════════

def _csv_cell_text(value) -> str:
    """What ``csv.writer`` wrote for one sanitized value, before quoting."""
    v = sanitize_for_json(value)
    if v is None:
        return ""
    if isinstance(v, float):
        return _FLOAT_REPR(v)
    return str(v)


def _json_cell_text(value) -> str:
    return _dumps(sanitize_for_json(value))


def _per_cell(arr, fn: Callable[[Any], str]):
    pa = _pa()
    return pa.array([fn(v) for v in arr.to_pylist()], type=pa.string())


# ══════════════════════════════════════════════════════════════════════════
# Shared value text (identical in CSV and JSON for the numeric types)
# ══════════════════════════════════════════════════════════════════════════

def _float_repr_text(arr):
    """``repr`` of each float value (float32 widened to the double Python
    sees); nulls and non-finite values come back as None (the caller
    decides how NULL is spelled).

    Arrow's float->string cast prints the same SHORTEST round-trip digits
    as Python's ``repr`` but a different presentation: ``1`` for ``1.0``,
    ``1e-7`` for ``1e-07``, exponent form from 1e14 and fixed form down to
    1e-6.  The two presentations Python uses are rebuilt from it where the
    digits are unambiguous -- fixed for 1e-4 <= |x| < 1e16 when Arrow wrote
    fixed (append ``.0`` to an integral text), exponent outside that range
    when Arrow wrote exponent (pad the exponent to two digits).  The cells
    where the two disagree on the FORM (1e14 <= |x| < 1e16 written in
    exponent form by Arrow, |x| < 1e-4 written fixed) are formatted by
    ``repr`` itself, cell by cell."""
    pa, pc = _pa(), _pc()
    if arr.type != pa.float64():
        arr = arr.cast(pa.float64())
    finite = pc.fill_null(pc.is_finite(arr), False)
    text = arr.cast(pa.string())
    absx = pc.abs(arr)
    has_e = pc.match_substring(text, "e")
    in_fixed_range = pc.or_(pc.greater_equal(absx, 1e-4), pc.equal(absx, 0.0))
    in_fixed_range = pc.and_(in_fixed_range, pc.less(absx, 1e16))
    fixed_ok = pc.and_(pc.invert(has_e), in_fixed_range)
    exp_ok = pc.and_(has_e, pc.invert(in_fixed_range))
    fixed_text = pc.if_else(
        pc.match_substring(text, "."), text,
        pc.binary_join_element_wise(text, pa.scalar(".0"), ""))
    # RE2 rewrites take one digit per group reference: \1 then a literal 0.
    exp_text = pc.replace_substring_regex(text, r"e([+-])([0-9])$", r"e\10\2")
    out = pc.if_else(fixed_ok, fixed_text, exp_text)
    hard = pc.and_(finite, pc.invert(pc.or_(fixed_ok, exp_ok)))
    if pc.any(hard).as_py():
        vals = pc.filter(arr, hard).to_pylist()
        out = pc.replace_with_mask(
            out, hard, pa.array(list(map(_FLOAT_REPR, vals)), type=pa.string()))
    return pc.if_else(finite, out, pa.scalar(None, pa.string()))


def _decimal_text(arr):
    """``sanitize_for_json(Decimal)``: <= 15 significant digits -> the
    nearest float (correctly rounded parse of the exact text), else the
    exact text.  Returns (text, is_wide) -- ``is_wide`` marks the cells that
    are decimal TEXT (a JSON string), None where NULL, or None for the whole
    column when no cell can be wide."""
    pa, pc = _pa(), _pc()
    exact = arr.cast(pa.string())
    wide = _wide_decimals(arr, exact)
    narrow_text = _narrow_decimal_repr(arr, exact)
    if wide is None:
        return narrow_text, None
    return pc.if_else(wide, exact, narrow_text), wide


def _narrow_decimal_repr(arr, exact):
    """``repr(float(d))`` for a decimal of <= 15 significant digits, from
    its exact text.

    Such a decimal round-trips through a double, and no OTHER decimal of
    <= 15 digits maps to the same double, so the double's shortest repr
    has exactly the decimal's digits: ``repr`` of it is the exact text with
    trailing fractional zeros dropped (``100.00`` -> ``100.0``, ``-1.50``
    -> ``-1.5``, ``5`` -> ``5.0``) -- while ``|d| >= 1e-4``, where repr
    writes fixed notation (``|d| < 1e16`` always holds at <= 15 digits and
    scale >= 0).  A non-zero ``|d| < 1e-4`` is written in exponent form,
    and a scientific exact text (``0E-10``) is not digits-and-a-point:
    those cells (and a negative-scale type) go through the float path."""
    import decimal
    pa, pc = _pa(), _pc()
    ty = arr.type
    if ty.scale < 0:
        return _float_repr_text(exact.cast(pa.float64()))
    if ty.scale == 0:
        text = pc.binary_join_element_wise(exact, pa.scalar(".0"), "")
    else:
        text = pc.replace_substring_regex(
            pc.replace_substring_regex(exact, r"0+$", ""), r"\.$", ".0")
    # Arrow (like Decimal's own str) writes scientific text when the
    # adjusted exponent is below -6 -- ``0E-10`` is a zero of scale 10.
    hard = pc.match_substring(exact, "E")
    if ty.scale >= 5:                    # only then can 0 < |d| < 1e-4 occur
        absd = pc.abs(arr)
        tiny = pc.and_(pc.less(absd, pa.scalar(decimal.Decimal("0.0001"), type=ty)),
                       pc.not_equal(absd, pa.scalar(decimal.Decimal(0), type=ty)))
        hard = pc.or_(hard, tiny)
    if pc.any(hard).as_py():
        text = pc.if_else(hard, _float_repr_text(exact.cast(pa.float64())), text)
    return text


def _wide_decimals(arr, exact):
    """Which cells have MORE than 15 significant digits -- the coefficient
    ``Decimal.as_tuple().digits`` counts, i.e. the unscaled integer.

    ``|unscaled| >= 10**15``  <=>  ``|value| >= 10**(15 - scale)``: one
    decimal comparison.  A type whose precision is <= 15 cannot hold a wide
    value at all (None).  The text form is counted only where the
    threshold cannot be written in the column's own type (negative
    scale)."""
    import decimal
    pa, pc = _pa(), _pc()
    ty = arr.type
    if ty.precision <= 15:
        return None
    if ty.scale >= 0:
        try:
            threshold = pa.scalar(decimal.Decimal(10) ** (15 - ty.scale), type=ty)
            return pc.greater_equal(pc.abs(arr), threshold)
        except (pa.ArrowException, decimal.DecimalException, TypeError, ValueError):
            pass
    digits = pc.utf8_ltrim(
        pc.replace_substring_regex(exact, r"[Ee].*$|[-+.]", ""), "0")
    return pc.greater(pc.max_element_wise(pc.utf8_length(digits), 1), 15)


def _timestamp_text(arr):
    """``datetime.isoformat()`` / ``pandas.Timestamp.isoformat()`` -- the
    to_pylist object for each unit -- or None when a value cannot be
    formatted natively (the caller then formats the column per cell)."""
    pa, pc = _pa(), _pc()
    ty = arr.type
    unit, tz = ty.unit, ty.tz
    if tz and not _is_fixed_zone(tz):
        # A NAMED zone: its offsets come from a tz database, and Arrow's is
        # not Python's -- they disagree (past 2037 Arrow keeps applying the
        # zone's DST rule; the pytz zone pyarrow hands Python stops there).
        # The row encoder's object decides, cell by cell.  (A materialised
        # parquet's zoned column is UTC -- the native path below.)
        return None
    per = _UNIT_PER_SECOND[unit]
    raw = arr.cast(pa.int64())
    mm = pc.min_max(raw)
    lo, hi = mm["min"].as_py(), mm["max"].as_py()
    if lo is None:                                   # all NULL
        return pa.nulls(len(arr), pa.string())
    local = arr
    offset_s = None
    if tz:
        local = pc.local_timestamp(arr)
        local_raw = local.cast(pa.int64())
        offset_s = pc.divide(pc.subtract(local_raw, raw), per)
        if pc.any(pc.not_equal(
                pc.subtract(offset_s, pc.multiply(pc.divide(offset_s, 60), 60)),
                0)).as_py():
            return None                              # a seconds offset (LMT)
        lmm = pc.min_max(local_raw)
        lo, hi = min(lo, lmm["min"].as_py()), max(hi, lmm["max"].as_py())
    if lo // per < _MIN_TS_S or hi // per > _MAX_TS_S:
        return None
    secs = pc.floor_temporal(local, unit="second")
    base = pc.binary_replace_slice(
        secs.cast(pa.timestamp("s")).cast(pa.string()), 10, 11, "T")
    if unit == "s":
        text = base
    else:
        frac = pc.subtract(local.cast(pa.int64()), secs.cast(pa.int64()))
        nonzero = pc.not_equal(frac, 0)
        if unit == "ms":
            digits = pc.binary_join_element_wise(
                pc.utf8_lpad(frac.cast(pa.string()), 3, "0"), pa.scalar("000"), "")
        elif unit == "us":
            digits = pc.utf8_lpad(frac.cast(pa.string()), 6, "0")
        else:                                        # ns
            micro = pc.divide(frac, 1000)
            sub_us = pc.not_equal(pc.subtract(frac, pc.multiply(micro, 1000)), 0)
            digits = pc.if_else(
                sub_us,
                pc.utf8_lpad(frac.cast(pa.string()), 9, "0"),
                pc.utf8_lpad(micro.cast(pa.string()), 6, "0"))
        dotted = pc.binary_join_element_wise(pa.scalar("."), digits, "")
        text = pc.binary_join_element_wise(
            base, pc.if_else(nonzero, dotted, pa.scalar("")), "")
    if offset_s is not None:
        sign = pc.if_else(pc.less(offset_s, 0), pa.scalar("-"), pa.scalar("+"))
        a = pc.abs(offset_s)
        hh = pc.utf8_lpad(pc.divide(a, 3600).cast(pa.string()), 2, "0")
        mins = pc.divide(pc.subtract(a, pc.multiply(pc.divide(a, 3600), 3600)), 60)
        mm_s = pc.utf8_lpad(mins.cast(pa.string()), 2, "0")
        text = pc.binary_join_element_wise(text, sign, hh, pa.scalar(":"), mm_s, "")
    return text


_FIXED_ZONE = re.compile(r"^[+-]\d{2}:\d{2}$")


def _is_fixed_zone(tz: str) -> bool:
    """UTC or a fixed ``+HH:MM`` offset -- an offset no tz database can
    disagree about."""
    return tz == "UTC" or bool(_FIXED_ZONE.match(tz))


def _kind(ty) -> str:
    pa = _pa()
    t = pa.types
    if t.is_dictionary(ty):
        return "dictionary"
    if t.is_boolean(ty):
        return "bool"
    if t.is_integer(ty):
        return "int"
    if t.is_float32(ty) or t.is_float64(ty):
        return "float"
    if t.is_decimal(ty):
        return "decimal"
    if t.is_string(ty) or t.is_large_string(ty) or getattr(t, "is_string_view", lambda _x: False)(ty):
        return "string"
    if t.is_date32(ty) or t.is_date64(ty):
        return "date"
    if t.is_timestamp(ty):
        return "timestamp"
    if t.is_null(ty):
        return "null"
    return "other"


def _as_string(arr):
    pa = _pa()
    return arr if arr.type == pa.string() else arr.cast(pa.string())


# ══════════════════════════════════════════════════════════════════════════
# CSV
# ══════════════════════════════════════════════════════════════════════════

_CSV_NEEDS_QUOTES = r'[,"\r\n]'


def _csv_quote(text):
    """QUOTE_MINIMAL over a non-null string array."""
    pa, pc = _pa(), _pc()
    needs = pc.match_substring_regex(text, _CSV_NEEDS_QUOTES)
    if not pc.any(needs).as_py():
        return text
    quoted = pc.binary_join_element_wise(
        pa.scalar('"'), pc.replace_substring(text, '"', '""'), pa.scalar('"'), "")
    return pc.if_else(needs, quoted, text)


class _CellFormatter:
    """Formats ONE column as non-null field text for one output syntax.

    ``column`` decodes a dictionary column, picks the method named for the
    column's kind, and fills NULL with the syntax's spelling.  A method
    returning None means "not natively formattable": the column is then
    formatted per cell through ``cell`` -- the row encoder's own function --
    so an unusual value costs speed, never bytes."""

    null_text = ""

    def cell(self, value) -> str:                    # pragma: no cover - abstract
        raise NotImplementedError

    def column(self, arr):
        pa = _pa()
        kind = _kind(arr.type)
        if kind == "dictionary":
            arr = arr.dictionary_decode()
            kind = _kind(arr.type)
        if kind == "null":
            return pa.array([self.null_text] * len(arr), type=pa.string())
        method = getattr(self, "kind_" + kind, None)
        text = method(arr) if method is not None else None
        if text is None:
            return self.finish_per_cell(_per_cell(arr, self.cell))
        return _as_string(text).fill_null(self.null_text)

    def finish_per_cell(self, text):
        return text

    # shared by both syntaxes
    def kind_int(self, arr):
        return arr.cast(_pa().string())

    def kind_float(self, arr):
        return _float_repr_text(arr)


class _CsvCells(_CellFormatter):
    """csv.writer's text for each value (QUOTE_MINIMAL applied)."""

    null_text = ""

    def cell(self, value) -> str:
        return _csv_cell_text(value)

    def finish_per_cell(self, text):
        return _csv_quote(text)

    def kind_bool(self, arr):
        pa, pc = _pa(), _pc()
        return pc.if_else(arr, pa.scalar("True"), pa.scalar("False"))

    def kind_decimal(self, arr):
        return _decimal_text(arr)[0]

    def kind_date(self, arr):
        return arr.cast(_pa().string())

    def kind_timestamp(self, arr):
        return _timestamp_text(arr)

    def kind_string(self, arr):
        return _csv_quote(_as_string(arr).fill_null(""))


_CSV_CELLS = _CsvCells()


def _csv_column(arr):
    """One column as non-null CSV field text (quoted where csv quotes)."""
    return _CSV_CELLS.column(arr)


def csv_header(names: Sequence[str]) -> bytes:
    """The header line exactly as ``csv.DictWriter.writeheader`` wrote it."""
    buf = io.StringIO()
    csv.writer(buf).writerow(list(names))
    return buf.getvalue().encode("utf-8")


def _string_array_bytes(arr) -> bytes:
    """The concatenated UTF-8 payload of a non-null string array."""
    import numpy as np
    pa = _pa()
    if len(arr) == 0:
        return b""
    bufs = arr.buffers()
    width = 8 if arr.type == pa.large_string() else 4
    dtype = np.int64 if width == 8 else np.int32
    offs = np.frombuffer(bufs[1], dtype=dtype, count=len(arr) + 1,
                         offset=arr.offset * width)
    start, end = int(offs[0]), int(offs[-1])
    return bytes(memoryview(bufs[2])[start:end])


def csv_rows(batch) -> bytes:
    """Every row of ``batch`` as CSV lines (``\\r\\n`` terminated)."""
    pa, pc = _pa(), _pc()
    n = batch.num_rows
    if n == 0:
        return b""
    ncols = batch.num_columns
    if ncols == 0:
        return b"\r\n" * n
    cells = [_csv_column(batch.column(i)) for i in range(ncols)]
    if ncols == 1:
        # csv's rule: a row that is ONE empty field is written '""'.
        only = cells[0]
        row = pc.if_else(pc.equal(only, ""), pa.scalar('""'), only)
    else:
        row = pc.binary_join_element_wise(*cells, ",")
    line = pc.binary_join_element_wise(row, pa.scalar(""), "\r\n")
    return _string_array_bytes(line)


# ══════════════════════════════════════════════════════════════════════════
# JSON
# ══════════════════════════════════════════════════════════════════════════

_JSON_SPECIAL = r'[\x00-\x1f"\\]'
_JSON_RARE_CONTROL = r'[\x00-\x07\x0b\x0e-\x1f]'
_JSON_SHORT_ESCAPES = (("\n", "\\n"), ("\r", "\\r"), ("\t", "\\t"),
                       ("\x08", "\\b"), ("\x0c", "\\f"))


def _json_string_literal(arr):
    """``json.dumps(s, ensure_ascii=False)`` per value; None where NULL.
    Returns None when a value carries a control character json spells as
    ``\\u00XX`` (the caller formats that column per cell)."""
    pa, pc = _pa(), _pc()
    s = _as_string(arr)
    if pc.any(pc.match_substring_regex(s, _JSON_SPECIAL)).as_py():
        if pc.any(pc.match_substring_regex(s, _JSON_RARE_CONTROL)).as_py():
            return None
        s = pc.replace_substring(s, "\\", "\\\\")
        s = pc.replace_substring(s, '"', '\\"')
        for raw, esc in _JSON_SHORT_ESCAPES:
            s = pc.replace_substring(s, raw, esc)
    return pc.binary_join_element_wise(pa.scalar('"'), s, pa.scalar('"'), "")


def _quoted(text):
    pa, pc = _pa(), _pc()
    return pc.binary_join_element_wise(pa.scalar('"'), text, pa.scalar('"'), "")


class _JsonCells(_CellFormatter):
    """json.dumps's text for each (sanitized) value."""

    null_text = "null"

    def cell(self, value) -> str:
        return _json_cell_text(value)

    def kind_bool(self, arr):
        return arr.cast(_pa().string())              # true / false

    def kind_decimal(self, arr):
        pc = _pc()
        dtext, wide = _decimal_text(arr)
        if wide is None:
            return dtext
        return pc.if_else(wide, _quoted(dtext), dtext)

    def kind_date(self, arr):
        return _quoted(arr.cast(_pa().string()))

    def kind_timestamp(self, arr):
        iso = _timestamp_text(arr)
        return None if iso is None else _quoted(iso)

    def kind_string(self, arr):
        return _json_string_literal(arr)


_JSON_CELLS = _JsonCells()


def _json_column(arr):
    """One column as non-null JSON value text."""
    return _JSON_CELLS.column(arr)


def _json_layout(names: Sequence[str]) -> list[tuple]:
    """(key text, column index) per OUTPUT key, with the row encoder's dict
    semantics for duplicate names: first position, last value."""
    last = {}
    for i, name in enumerate(names):
        last[name] = i
    seen, layout = set(), []
    for name in names:
        if name in seen:
            continue
        seen.add(name)
        layout.append((_dumps(name), last[name]))
    return layout


def json_row_texts(batch):
    """Every row of ``batch`` as one JSON object text (a string array)."""
    pa, pc = _pa(), _pc()
    n = batch.num_rows
    layout = _json_layout(batch.schema.names)
    if not layout:
        return pa.array(["{}"] * n, type=pa.string())
    parts: list[Any] = []
    for pos, (key, idx) in enumerate(layout):
        parts.append(pa.scalar(("{" if pos == 0 else ",") + key + ":"))
        parts.append(_json_column(batch.column(idx)))
    parts.append(pa.scalar("}"))
    return pc.binary_join_element_wise(*parts, "")


def jsonl_rows(batch) -> bytes:
    """Every row of ``batch`` as JSON lines (``\\n`` terminated)."""
    pa, pc = _pa(), _pc()
    if batch.num_rows == 0:
        return b""
    rows = json_row_texts(batch)
    return _string_array_bytes(pc.binary_join_element_wise(rows, pa.scalar(""), "\n"))


def json_array_items(batch, *, first: bool) -> bytes:
    """Rows of ``batch`` as the comma-separated items of a JSON array --
    led by ``,`` unless they are the array's first items."""
    pa, pc = _pa(), _pc()
    if batch.num_rows == 0:
        return b""
    rows = json_row_texts(batch)
    body = _string_array_bytes(pc.binary_join_element_wise(pa.scalar(""), rows, ","))
    # every item is now led by "," -- the array's first one must not be
    return body[1:] if first else body
