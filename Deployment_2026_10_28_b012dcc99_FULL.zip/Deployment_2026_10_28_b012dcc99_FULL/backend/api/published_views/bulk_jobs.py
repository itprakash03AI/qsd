"""The SHARED registry of background bulk builds (2026-10-03).

``POST /api/v1/views/{slug}/bulk/prepare`` starts a build that can run for
hours; ``GET .../bulk/jobs/{id}`` polls it.  The registry was a dict in the
process that took the POST.  Behind a Service with two published-api
replicas -- and on a pod running two uvicorn workers -- a poll reaches a
sibling process about half the time.  That sibling answered 404 "POST
prepare again", and the second POST started a SECOND build of the same
dataset in the sibling (its own dict knew of no build in flight): the
multi-hour Starburst materialisation the prepare door exists to run ONCE.

THE SHAPE
---------
* ``pv_bulk_prepare_jobs`` -- one row per job, written by the process that
  runs it: at creation, at every status change, and every
  ``HEARTBEAT_SECONDS`` while queued / running (the job's public fields --
  progress included -- and ``heartbeat_at``).
* ``pv_bulk_prepare_claims`` -- "which job builds this dataset": the
  primary key IS the claim (first INSERT wins), and replacing a finished or
  dead job is a compare-and-swap on ``job_id``.  The key is the sha256 of
  the bulk slot's PATH, which every process computes identically on the
  shared cache volume.
* A ``queued`` / ``running`` row whose heartbeat is older than
  ``STALE_AFTER_SECONDS`` belongs to a process that ended (a restart, a
  worker exit): it is reported -- and recorded -- ``failed`` with a reason
  that says to POST prepare again, never "in flight" forever.

The local dict in ``published_views_api`` stays the LIVE object for the
process running the build (the asyncio task, the freshest progress); this
store is how every OTHER process sees it.  Every function here is
fail-soft: a store error is logged and the caller keeps the per-process
behaviour it had before, so a database blip never fails a request that
would otherwise succeed.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import socket
import time
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

#: How often the building process refreshes its row while queued / running.
HEARTBEAT_SECONDS = 10.0
#: A queued / running row whose heartbeat is older than this is dead.
STALE_AFTER_SECONDS = 60.0
#: Terminal rows (and their claims) are kept this long, like the local dict.
TERMINAL_RETENTION_SECONDS = 3600.0
#: Opportunistic prune cadence per process.
_PRUNE_EVERY_SECONDS = 60.0

#: The job's public fields mirrored into ``body`` (never ``_task``/``_dkey``).
_BODY_FIELDS = ("view_id", "started_at", "error", "dataset_path",
                "total_rows", "total_mode", "dataset_version",
                "parts_completed", "rows_so_far", "write_ladder", "scan_plan")

DEAD_OWNER_ERROR = (
    "The process running this bulk build stopped (a pod restart or a worker "
    "exit) before it finished. POST /bulk/prepare again; a dataset that was "
    "completed is answered from the cache without re-executing.")

_last_prune = 0.0


def owner_id() -> str:
    """This process, as the row names it."""
    return f"{socket.gethostname()}:{os.getpid()}"


def dataset_key(cached_path: Any) -> str:
    """The cross-process identity of one bulk dataset: its slot's path."""
    return hashlib.sha256(str(cached_path).encode("utf-8")).hexdigest()


def _engine():
    from core.database import get_db_manager
    mgr = get_db_manager()
    engine = getattr(mgr, "engine", None) if mgr is not None else None
    if engine is None or not hasattr(engine, "begin"):
        raise RuntimeError("no metadata database is configured")
    from core.db.engine_memo import ensure_table
    from core.db.models import PvBulkPrepareClaim, PvBulkPrepareJob
    ensure_table(engine, PvBulkPrepareJob.__table__)
    ensure_table(engine, PvBulkPrepareClaim.__table__)
    return engine


def _jsonable(v: Any) -> Any:
    try:
        json.dumps(v)
        return v
    except (TypeError, ValueError):
        return str(v)


def _body_of(job: dict) -> str:
    return json.dumps({k: _jsonable(job.get(k)) for k in _BODY_FIELDS
                       if job.get(k) is not None})


def _row_to_job(row) -> dict:
    job = {
        "job_id": row.job_id, "slug": row.slug, "status": row.status,
        "created_at": row.created_at, "finished_at": row.finished_at,
        "heartbeat_at": row.heartbeat_at, "owner": row.owner,
        "started_at": None, "error": None,
    }
    try:
        job.update(json.loads(row.body or "{}"))
    except (TypeError, ValueError):
        pass
    return job


def is_dead(job: dict, now: Optional[float] = None) -> bool:
    """A queued / running job whose heartbeat stopped."""
    if job.get("status") not in ("queued", "running"):
        return False
    t = time.time() if now is None else now
    return t - float(job.get("heartbeat_at") or 0) > STALE_AFTER_SECONDS


def save(job: dict, *, dkey: Optional[str] = None,
         now: Optional[float] = None) -> bool:
    """Insert or refresh the row for ``job`` (and its heartbeat).  True when
    written."""
    from sqlalchemy import text as _t
    t = time.time() if now is None else now
    params = {
        "job_id": job["job_id"], "dkey": dkey or job.get("_shared_dkey") or "",
        "view_id": job.get("view_id"), "slug": job.get("slug") or "",
        "status": job.get("status") or "queued", "owner": owner_id(),
        "created_at": float(job.get("created_at") or t), "hb": t,
        "finished_at": job.get("finished_at"), "body": _body_of(job),
    }
    try:
        eng = _engine()
        with eng.begin() as conn:
            res = conn.execute(_t(
                "UPDATE pv_bulk_prepare_jobs SET status = :status, "
                "heartbeat_at = :hb, finished_at = :finished_at, body = :body "
                "WHERE job_id = :job_id"), params)
            if res.rowcount == 0:
                conn.execute(_t(
                    "INSERT INTO pv_bulk_prepare_jobs (job_id, dataset_key, "
                    "view_id, slug, status, owner, created_at, heartbeat_at, "
                    "finished_at, body) VALUES (:job_id, :dkey, :view_id, "
                    ":slug, :status, :owner, :created_at, :hb, :finished_at, "
                    ":body)"), params)
        return True
    except Exception as exc:
        logger.warning("[pv-bulk-jobs] could not record job %s in the shared "
                       "registry (siblings will not see it): %s",
                       job.get("job_id"), exc)
        return False


def get(job_id: str, now: Optional[float] = None) -> Optional[dict]:
    """The job as every process sees it, or None.  A dead queued / running
    job is recorded failed on the way out."""
    from sqlalchemy import text as _t
    try:
        eng = _engine()
        with eng.begin() as conn:
            row = conn.execute(_t(
                "SELECT job_id, slug, status, owner, created_at, heartbeat_at, "
                "finished_at, body FROM pv_bulk_prepare_jobs "
                "WHERE job_id = :job_id"), {"job_id": job_id}).first()
    except Exception as exc:
        logger.warning("[pv-bulk-jobs] shared registry unreadable for job "
                       "%s: %s", job_id, exc)
        return None
    if row is None:
        return None
    job = _row_to_job(row)
    if is_dead(job, now):
        _mark_dead(job, now)
    return job


def _mark_dead(job: dict, now: Optional[float] = None) -> None:
    from sqlalchemy import text as _t
    t = time.time() if now is None else now
    job.update({"status": "failed", "finished_at": t,
                "error": DEAD_OWNER_ERROR})
    try:
        eng = _engine()
        with eng.begin() as conn:
            conn.execute(_t(
                "UPDATE pv_bulk_prepare_jobs SET status = 'failed', "
                "finished_at = :t, body = :body WHERE job_id = :job_id "
                "AND status IN ('queued', 'running') AND heartbeat_at = :hb"),
                {"t": t, "body": _body_of(job), "job_id": job["job_id"],
                 "hb": job.get("heartbeat_at")})
        logger.warning("[pv-bulk-jobs] job %s (owner %s) stopped "
                       "heartbeating -- recorded failed", job["job_id"],
                       job.get("owner"))
    except Exception as exc:
        logger.debug("[pv-bulk-jobs] could not record dead job %s: %s",
                     job.get("job_id"), exc)


def current_for(dkey: str, now: Optional[float] = None) -> Optional[dict]:
    """The job that claims dataset ``dkey`` (any process), or None."""
    from sqlalchemy import text as _t
    try:
        eng = _engine()
        with eng.begin() as conn:
            claim = conn.execute(_t(
                "SELECT job_id FROM pv_bulk_prepare_claims "
                "WHERE dataset_key = :k"), {"k": dkey}).first()
    except Exception as exc:
        logger.warning("[pv-bulk-jobs] shared claims unreadable: %s", exc)
        return None
    if claim is None:
        return None
    return get(claim[0], now)


def claim(dkey: str, job_id: str, *, previous_job_id: Optional[str],
          now: Optional[float] = None) -> Optional[str]:
    """Make ``job_id`` THE build of ``dkey``.  Returns the job id that holds
    the claim afterwards -- ``job_id`` when this call won, a sibling's when
    one won the race (join it), or None when the store failed (the caller
    keeps the per-process behaviour)."""
    from sqlalchemy import text as _t
    from sqlalchemy.exc import IntegrityError
    t = time.time() if now is None else now
    params = {"k": dkey, "j": job_id, "t": t, "prev": previous_job_id}

    def _holder(conn_engine) -> Optional[str]:
        with conn_engine.begin() as conn:
            row = conn.execute(_t(
                "SELECT job_id FROM pv_bulk_prepare_claims "
                "WHERE dataset_key = :k"), params).first()
        return row[0] if row is not None else None

    try:
        eng = _engine()
        if previous_job_id is not None:
            with eng.begin() as conn:
                res = conn.execute(_t(
                    "UPDATE pv_bulk_prepare_claims SET job_id = :j, "
                    "claimed_at = :t WHERE dataset_key = :k AND job_id = :prev"),
                    params)
            if res.rowcount == 1:
                return job_id
            holder = _holder(eng)
            if holder is not None:
                return holder             # a sibling replaced it first: join
            # the claim row was pruned meanwhile: claim it fresh below
        try:
            with eng.begin() as conn:
                conn.execute(_t(
                    "INSERT INTO pv_bulk_prepare_claims (dataset_key, "
                    "job_id, claimed_at) VALUES (:k, :j, :t)"), params)
            return job_id
        except IntegrityError:
            return _holder(eng)           # a sibling claimed it first: join
    except Exception as exc:
        logger.warning("[pv-bulk-jobs] could not claim dataset %s for job %s "
                       "(per-process dedup only): %s", dkey[:12], job_id, exc)
        return None


def forget(job_id: str) -> None:
    """Drop a job row that never ran (it lost the claim race)."""
    from sqlalchemy import text as _t
    try:
        eng = _engine()
        with eng.begin() as conn:
            conn.execute(_t("DELETE FROM pv_bulk_prepare_jobs "
                            "WHERE job_id = :j"), {"j": job_id})
    except Exception as exc:
        logger.debug("[pv-bulk-jobs] could not drop job %s: %s", job_id, exc)


def prune(now: Optional[float] = None, *, force: bool = False) -> int:
    """Delete terminal rows past ``TERMINAL_RETENTION_SECONDS`` and claims
    whose job is gone.  At most once per minute per process unless forced.
    Returns rows deleted."""
    global _last_prune
    from sqlalchemy import text as _t
    t = time.time() if now is None else now
    if not force and t - _last_prune < _PRUNE_EVERY_SECONDS:
        return 0
    _last_prune = t
    try:
        eng = _engine()
        with eng.begin() as conn:
            a = conn.execute(_t(
                "DELETE FROM pv_bulk_prepare_jobs WHERE status IN "
                "('ready', 'failed') AND finished_at < :cut"),
                {"cut": t - TERMINAL_RETENTION_SECONDS}).rowcount or 0
            b = conn.execute(_t(
                "DELETE FROM pv_bulk_prepare_claims WHERE job_id NOT IN "
                "(SELECT job_id FROM pv_bulk_prepare_jobs)")).rowcount or 0
        return int(a) + int(b)
    except Exception as exc:
        logger.debug("[pv-bulk-jobs] prune skipped: %s", exc)
        return 0
