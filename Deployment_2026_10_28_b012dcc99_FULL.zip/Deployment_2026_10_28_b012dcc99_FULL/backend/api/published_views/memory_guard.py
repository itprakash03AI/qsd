"""The published API's per-worker memory guard, as HTTP (2026-10-04).

``core/process_memory.py`` decides (THE rule: this process's RSS against
its share of the pod limit, the pod's working set against the limit, after
one give-back of retained memory); this module is the one place that turns
the decision into a response and the one place that asks for a give-back
after large work.

Refused (503 + ``Retry-After`` + ``X-QS-Refused: memory_pressure``, the
sentence naming the numbers): every NEW piece of large work --

* ``GET /bulk`` (and ``.jsonl`` / ``.csv`` / ``.arrow``) -- a long-lived
  stream whose encoder holds Python rows;
* ``GET /bulk/manifest`` -- materialises the unbounded dataset on a miss;
* ``POST /bulk/prepare`` -- a NEW background build (joining or reusing an
  existing one is not new work and is never refused);
* ``GET /data`` on a cache MISS -- a materialisation of up to
  ``dataset_row_cap`` + 1 rows.

Never refused: a ``/data`` cache HIT (or a dedup join that ends in one) --
it reads one page of a file -- and anything already running.

Why refuse rather than start: a worker the kernel OOM-kills takes EVERY
request in flight on it down with it, cached reads included (measured live
2026-10-04: "Child process [N] died", RemoteDisconnected, 100 concurrent
consumers stalled).  A 503 with a retry time costs one caller one retry.
"""
from __future__ import annotations

from fastapi import HTTPException

#: The header a client (and a test) can key on without parsing the sentence.
REFUSED_HEADER = "X-QS-Refused"
REFUSED_VALUE = "memory_pressure"


def refuse_under_memory_pressure(kind: str) -> None:
    """Raise 503 when this worker must not start ``kind`` now; else return."""
    from core.process_memory import memory_pressure_verdict
    verdict = memory_pressure_verdict(kind)
    if verdict is None:
        return
    raise HTTPException(
        status_code=503,
        detail=verdict.sentence(),
        headers={"Retry-After": str(verdict.retry_after),
                 REFUSED_HEADER: REFUSED_VALUE},
    )


def large_work_finished(kind: str) -> None:
    """Large work ended (stream closed, materialisation done): give the
    memory its allocators retained back to the OS, off the request path."""
    from core.process_memory import request_release
    request_release(kind)
