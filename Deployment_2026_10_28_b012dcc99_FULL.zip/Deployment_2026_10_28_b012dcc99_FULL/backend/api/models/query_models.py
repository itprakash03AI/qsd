"""
Pydantic request/response models for the QueryStudio API.

Extracted from main.py to keep the main module focused on app wiring,
middleware, and startup/shutdown logic.
"""
from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from typing import Any, Dict, List, Optional, Union


# ── Connection type pattern (shared constant) ────────────────────────────────
ALL_CONN_TYPES = "^(s3|local|upload|trino|starburst|snowflake|databricks|oracle|athena|rest_api)$"

# H1 (2026-10-07): a client-generated correlation id (a uuid in practice) --
# letters, digits, '-' and '_' only, so it is safe in a log line and a WS frame.
CLIENT_REQUEST_ID_PATTERN = r"^[A-Za-z0-9_-]{1,64}$"


# ── S3 / Connection models ───────────────────────────────────────────────────

class S3ConfigModel(BaseModel):
    bucket_name: str
    region_name: str = "us-east-1"
    auth_mode: str = "keys"                  # keys | iam_role | profile | assume_role
    aws_access_key_id: Optional[str] = None
    aws_secret_access_key: Optional[str] = None
    aws_profile: Optional[str] = None        # named profile / SSO profile
    role_arn: Optional[str] = None           # for assume_role
    role_session_name: str = "parquet-engine"
    external_id: Optional[str] = None        # cross-account assume_role
    endpoint_url: Optional[str] = None
    ssl_verify: Union[bool, str] = True      # True | False | "/path/to/ca-bundle.pem"


class ConnectionConfigModel(BaseModel):
    name: str
    connection_type: str = Field(pattern=ALL_CONN_TYPES)
    config: dict
    is_shared: Optional[bool] = None


class ConnectionTestRequest(BaseModel):
    connection_type: str = Field(pattern=ALL_CONN_TYPES)
    config: dict
    connection_id: Optional[int] = None  # set when testing an existing saved connection


# ── Query builder models ─────────────────────────────────────────────────────

class JoinConfigModel(BaseModel):
    left_file: str
    right_file: str
    left_on: List[str]
    right_on: List[str]
    how: str = Field(default="inner", pattern="^(inner|left|right|outer)$")
    right_column_aliases: Optional[Dict[str, str]] = None  # conflicting right-col → alias


#: Legacy operator spellings the UI has always emitted, mapped to the canonical
#: name.  2026-08-25: the BQB filter picker offers ``neq`` and ``like``
#: (business-query/types.ts:70,75) while FilterModel only ever accepted ``ne``
#: and ``contains`` — so two of its eight operators returned 422 on every Run.
#: The frontend's own preview-SQL generators understand ``neq``, so the SQL
#: rendered correctly and the operator looked supported until the server
#: refused it.
#:
#: Normalised at the wire boundary, not in the picker: the picker is not the
#: only producer (saved queries, report parameters and API clients carry the
#: same spellings), and rows already stored with a legacy value are repaired by
#: reading them through this model.
#:
#: CLOSED map, deliberately.  An unrecognised operator must still 422 — a
#: silently dropped filter is a WRONG ANSWER, not a cosmetic problem.
_OPERATOR_ALIASES = {
    "neq": "ne",
    "like": "contains",
    "not_like": "not_contains",
}


class FilterModel(BaseModel):
    column: str
    operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte|in|not_in|contains|not_contains|between|is_null|is_not_null)$")

    @field_validator("operator", mode="before")
    @classmethod
    def _canonicalise_operator(cls, v):
        """Map a legacy spelling onto its canonical name BEFORE the pattern
        check.  Anything unrecognised is passed through untouched so the
        pattern still rejects it."""
        if isinstance(v, str):
            return _OPERATOR_ALIASES.get(v.strip().lower(), v)
        return v
    value: Any = None  # None for is_null / is_not_null
    # 2026-08-19 -- the column's DECLARED type, so the compiler can emit a
    # typed literal instead of a quoted string.  Without it every filter
    # reached Starburst as varchar and a DATE column failed with
    # "Cannot apply operator: date = varchar(10)".  Optional and free-form:
    # absent means "unknown", which keeps the old quoted-string behaviour, so
    # a varchar column holding '2026-08-13' does not break the other way.
    data_type: Optional[str] = None


class OrderByModel(BaseModel):
    column: str
    direction: str = Field(default="asc", pattern="^(asc|desc)$")

    @field_validator("direction", mode="before")
    @classmethod
    def _lower_direction(cls, v):
        """Edge-case sweep 2026-09-24: the window-function builder defaults
        its ORDER BY to 'ASC' / 'DESC', which this pattern refused with a 422
        -- every window function with an ordering was unrunnable.  The
        direction is case-insensitive SQL; canonicalise it."""
        return v.strip().lower() if isinstance(v, str) else v


class AggregationModel(BaseModel):
    column: str
    function: str = Field(pattern="^(SUM|AVG|COUNT|MIN|MAX|sum|avg|count|min|max)$")
    alias: Optional[str] = None
    distinct: bool = False  # COUNT(DISTINCT col)


class HavingModel(BaseModel):
    column: str
    function: str = Field(pattern="^(SUM|AVG|COUNT|MIN|MAX|sum|avg|count|min|max)$")
    operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte)$")
    value: Any


class ComputedColumnModel(BaseModel):
    expression: str
    alias: str


class CaseWhenClauseModel(BaseModel):
    when_column: str
    when_operator: str = Field(pattern="^(eq|ne|gt|gte|lt|lte|in|is_null|is_not_null)$")
    when_value: Any = None
    then_value: str


class CaseExpressionModel(BaseModel):
    when_clauses: List[CaseWhenClauseModel]
    else_value: Optional[str] = None
    alias: str


class WindowFunctionModel(BaseModel):
    function: str = Field(pattern="^(ROW_NUMBER|RANK|DENSE_RANK|LAG|LEAD|SUM|AVG|COUNT|MIN|MAX|row_number|rank|dense_rank|lag|lead|sum|avg|count|min|max)$")
    alias: str
    column: Optional[str] = None
    partition_by: Optional[List[str]] = None
    order_by: Optional[List[OrderByModel]] = None
    offset: Optional[int] = None       # LAG/LEAD
    default_value: Optional[str] = None # LAG/LEAD


class PartitionConfigModel(BaseModel):
    """Progressive, partition-by-partition result loading (2026-09-05).

    Read at build time by ``api.published_views_api._partition_config``,
    which resolves it out of the published view's frozen ``query_config``.

    DECLARED HERE BECAUSE PYDANTIC DROPS WHAT IS NOT DECLARED.  When the
    feature shipped, ``partition_config`` had readers and no producer:
    ``QueryConfigModel`` did not declare it, so
    ``QueryConfigModel(files=[...], partition_config={...}).model_dump()``
    returned a dict WITHOUT it, the save returned 200 and stored nothing,
    and the whole scan-partition lane was unreachable BY CONSTRUCTION on
    every view that could exist.  That is the same defect the ``raw_sql``
    and Phase 154 comments below already record -- twice is a pattern,
    three times is this file's most expensive habit.

    A TYPED model rather than ``Optional[dict]`` on purpose: a dict would
    round-trip an author's typo (``max_bucket``) as silently as pydantic
    dropped the whole field, and the planner would then use its default
    while the artifact showed the author's number nowhere.

    ``column`` is what turns the feature on; ``enabled=False`` turns it
    off without losing the column.

    ``extra="forbid"`` (2026-09-05, round 2).  A typed model that SILENTLY
    DROPS an undeclared key gives back the same 200-that-stored-nothing the
    paragraph above records: ``max_bucket`` (singular) would validate, be
    discarded, and the planner would run its default while the author's
    number appeared nowhere.  ``raw_sql``, ``flow_id`` and
    ``partition_config`` itself have each been that bug in this repo, so the
    posture here is that an unknown key is a 422 naming the key, never a
    shrug.  BOTH LANES ride this one model -- the published view's
    ``QueryConfigModel.partition_config`` and, since round 2, the dataset's
    ``source_tables[*].partition_config`` (validated by
    ``api.datasets_api._validate_partition_configs``) -- because a knob that
    is checked on one lane and waved through on the other is the asymmetry
    that made this a finding.
    """
    model_config = ConfigDict(extra="forbid")

    column: Optional[str] = Field(default=None, max_length=256)
    enabled: bool = True
    max_buckets: int = Field(default=64, ge=1, le=10_000)
    max_concurrent: int = Field(default=2, ge=1, le=32)
    target_rows_per_bucket: Optional[int] = Field(default=None, ge=1)
    # Pins CARDINALITY bucketing (values per bucket).  With
    # bucket_strategy="fixed" a plan that cannot fit REFUSES rather than
    # repacking -- two instructions that cannot both be honoured.
    bucket_size: Optional[int] = Field(default=None, ge=1)
    bucket_strategy: str = Field(default="auto", pattern="^(auto|fixed)$")
    # The CHEAP probe escape hatch: a dimension-table query naming the
    # partition values.  Setting it turns the pre-flight COUNT(*) ON by
    # default, because a configured probe is a PROMISE of coverage and the
    # count is what lets G3 falsify it.
    discovery_sql: Optional[str] = None
    discovery_with_counts: bool = True
    discovery_wrap: bool = False
    # None => on iff discovery_sql is set.  False WAIVES the coverage
    # proof, and the waiver is recorded in the plan artifact.
    preflight_count: Optional[bool] = None
    max_discovery_values: int = Field(default=200_000, ge=1)
    # Rows per part file while a bucket streams to disk.  Read by BOTH
    # lanes at ``core.federation_engine`` :3496 and
    # ``api.published_views_api`` :1382 -- it was READ on both and
    # DECLARABLE on neither, so the only way to move it was the global
    # ``feed_generation.parts_rows_per_part``.  ``ge=1`` on purpose: the
    # reader folds a falsy value into that global default
    # (``cfg.get("rows_per_part") or _parts_rows_per_part()``), so a
    # declared 0 would mean "the global", not the writer's own
    # "never rotate" -- two meanings for one number.  Refused at the door
    # instead; None is how you say "use the global".
    rows_per_part: Optional[int] = Field(default=None, ge=1)


class QueryConfigModel(BaseModel):
    files: List[str]
    joins: Optional[List[JoinConfigModel]] = None
    filters: Optional[List[FilterModel]] = None
    columns: Optional[List[str]] = None
    # Edge-case sweep 2026-09-24: limit -5 ran UNLIMITED (25 of 25 rows).
    # 0 keeps its meaning; a negative is refused (422 naming the field).
    limit: Optional[int] = Field(default=None, ge=0)
    offset: int = Field(default=0, ge=0)
    order_by: Optional[List[OrderByModel]] = None
    group_by: Optional[List[str]] = None
    aggregations: Optional[List[AggregationModel]] = None
    # Advanced SQL features
    distinct: bool = False
    having: Optional[List[HavingModel]] = None
    filter_logic: str = Field(default="AND", pattern="^(AND|OR|and|or)$")
    computed_columns: Optional[List[ComputedColumnModel]] = None
    case_expressions: Optional[List[CaseExpressionModel]] = None
    column_aliases: Optional[Dict[str, str]] = None
    window_functions: Optional[List[WindowFunctionModel]] = None
    # Stored with the query so saved SQL-connector queries re-execute against the right connection
    connection_id: Optional[int] = None
    # Optional Spark Connect routing hints (frontend passes these from /api/execute/estimate).
    # If estimated_rows >= spark_connect.row_threshold, the query routes to Spark Connect
    # instead of DuckDB. engine_override="spark"/"duckdb" forces a specific engine.
    estimated_rows: Optional[int] = None
    engine_override: Optional[str] = Field(default=None, pattern="^(spark|duckdb)$")
    # BF-428I + BF-430A — per-query S3 reader override.  Maps to the
    # registered name in core.s3_readers (e.g. "smart_predownload",
    # "pyarrow_s3fs", "athena").  NULL = use the global s3_readers config
    # (default + per_connection).  Validated by the router at pick time —
    # unknown names degrade to "auto" with a logged warning rather than 400.
    # Pattern is permissive on purpose so future readers can register without
    # touching this enum; the registry is the source of truth.
    reader_override: Optional[str] = Field(default=None, max_length=64,
                                            pattern=r"^[a-z][a-z0-9_]*$")
    # Phase 154 (2026-06-25) — cross-connection round-trip.  Operator
    # surfaced "published api is not implemented for cross source ...
    # OnPrem S3 + AWS S3".  Root cause: BQB persisted these fields at
    # the TOP-LEVEL of the execute payload but the SAVE path went
    # through QueryConfigModel which did not declare them -- Pydantic
    # silently dropped them on model_dump.  Consequence:
    #   * BQB cross-conn Save -> primary-only persisted
    #   * Load -> handleLoadSavedQuery never restores cross-conn UI
    #   * Publish -> PV snapshot has no secondary -> PV runtime falls
    #     through to primary-only execution.
    # The PV runtime (published_views_api.py:1456-1495) ALREADY supports
    # the cross path (both `local` and `s3` build a secondary
    # ParquetQueryEngine); the bug was upstream at SAVE.  Declaring the
    # fields here closes the round-trip.
    secondary_connection_id: Optional[int] = None
    secondary_query_config: Optional[dict] = None
    secondary_raw_sql: Optional[str] = None
    combine_mode: Optional[str] = Field(default=None, pattern="^(union|join)$")
    join_config: Optional[dict] = None
    # 2026-08-22 — the PRIMARY raw_sql was never declared here, so the exact
    # Phase 154 defect documented above kept happening to the MAIN query:
    # BQB's buildQueryConfig() writes ``raw_sql: sqlText`` on SAVE
    # (BusinessQueryBuilder.tsx ~2677), Pydantic silently dropped it, and
    # every consumer that prefers raw_sql (feed_sql_resolver, feed engine,
    # published views, datasets-from-saved-query) fell back to REBUILDING
    # the SQL from the visual state — the user's SQL-mode edits vanished
    # without a trace.  ``secondary_raw_sql`` was declared in the Phase 154
    # fix; its primary twin was not — the one-of-two-twins defect class.
    raw_sql: Optional[str] = None
    # 2026-09-05 -- progressive partition scan.  Readers existed
    # (published_views_api._partition_config resolves it out of the
    # published view's frozen query_config); no WRITER did, because this
    # model did not declare the field, so every save dropped it silently
    # and the feature was off with no supported way to turn it on.
    partition_config: Optional[PartitionConfigModel] = None


# ── Save / Execute request models ────────────────────────────────────────────


#: Keys a STORED query_config may carry that do not shape the query -- written
#: by the published-view snapshot (management.py), legacy BQB rows
#: (``custom_sql``) and source routing.  Tolerated at the HTTP boundary and
#: dropped, exactly as before; everything else unknown is refused.
QUERY_CONFIG_TOLERATED_KEYS = frozenset({
    "custom_sql", "source_type", "sql_file_id", "sql_query_id",
    "business_report_id", "federation_view_id", "_where_clauses_mapping",
})


class QueryConfigRequestModel(QueryConfigModel):
    """A query_config as it ARRIVES over HTTP: an unknown top-level key is
    REFUSED, naming it (edge-case sweep 2026-09-24).

    Measured: ``{"filterz": [...]}`` -- ``filters`` misspelt -- ran with no
    WHERE clause and returned all 25 of 25 rows behind a 200: the FB-22 class,
    fixed for reports and never for the query builder.  Only the TOP level is
    strict; nested models stay lenient because the builder still sends
    ``right_suffix`` on joins and ``_partition`` on partition filters.  The
    server-side rebuilds of STORED configs (published views, saved queries by
    id, federation views) keep the lenient parent class.
    """

    @model_validator(mode="before")
    @classmethod
    def _refuse_unknown_top_level(cls, data):
        if not isinstance(data, dict):
            return data
        unknown = sorted(k for k in data
                         if k not in cls.model_fields and k not in QUERY_CONFIG_TOLERATED_KEYS)
        if unknown:
            raise ValueError(
                f"query_config has unrecognised key(s) {unknown}; refusing rather "
                f"than running the query without them (a misspelt 'filters' would "
                f"return every row). Recognised: {sorted(cls.model_fields)}.")
        return {k: v for k, v in data.items() if k not in QUERY_CONFIG_TOLERATED_KEYS}


class SaveQueryRequest(BaseModel):
    name: str
    description: Optional[str] = None
    query_config: QueryConfigRequestModel
    created_by: Optional[str] = None


class ExecuteQueryRequest(BaseModel):
    # Edge-case sweep 2026-09-24: an unknown top-level key is refused (422
    # naming it).  The in-repo callers that sent one were bugs: the reader
    # override at the top level (ignored -- it lives in query_config), a
    # cross-join preview in an invented vocabulary (already a 400), and a
    # saved-query preview's ``limit`` (ignored -- a 10-row preview ran the
    # whole query), which is now declared below.
    model_config = ConfigDict(extra="forbid")

    query_id: Optional[int] = None
    query_config: Optional[QueryConfigRequestModel] = None
    output_format: str = Field(default="csv", pattern="^(csv|json)$")
    executed_by: Optional[str] = None
    connection_id: Optional[int] = None
    raw_sql: Optional[str] = None  # SQL editor mode: bypass visual query builder
    # 2026-10-03 -- the catalog / schema the author BROWSED to in the query
    # builder.  A typed statement's bare table names are qualified with them
    # (core.sql_connector_dialect.qualify_unqualified_tables) BEFORE row
    # security and the cache key see it, so "select * from TRADES" under
    # QS_DEMO / FIN reads QS_DEMO.FIN.TRADES -- and its policy applies.
    default_catalog: Optional[str] = Field(default=None, max_length=255)
    default_schema: Optional[str] = Field(default=None, max_length=255)
    # Cache strategy: auto = use cache if available; bypass = skip cache (no store);
    #                 refresh = skip cache lookup but store fresh result
    cache_strategy: str = Field(default="auto", pattern="^(auto|bypass|refresh)$")
    # Cross-connection join / union fields
    secondary_connection_id: Optional[int] = None
    secondary_query_config: Optional[dict] = None
    secondary_raw_sql: Optional[str] = None  # SQL editor mode: raw SQL for secondary connection
    combine_mode: str = "union"   # "union" | "join"
    join_config: Optional[dict] = None
    # Async control fields
    wait: bool = False                     # Block until complete (external executor mode only)
    wait_timeout: int = Field(default=30, ge=1, le=300)  # Max seconds to wait
    callback_url: Optional[str] = None    # Webhook POST on completion/failure
    idempotency_key: Optional[str] = None  # Client-generated UUID to prevent duplicate submissions
    params: Optional[Dict[str, Any]] = None  # Phase 86: {{param}} substitution for raw_sql
    # BF-PRE-VALIDATE-TIMEOUT: client opt-out for pre-validation.  Default
    # False (validation runs).  Useful when the client wants to bypass the
    # 5s budget gate — e.g. a "Run anyway" button after a previous timeout,
    # or for queries the client knows are well-formed.
    skip_pre_validate: bool = False
    # A row cap for a SAVED query run by ``query_id`` (a preview): applied on
    # top of the stored limit, never widening it.  0 / absent = no extra cap.
    limit: Optional[int] = Field(default=None, ge=0)
    # H1 (2026-10-07): the client's correlation id for THIS run.  The POST is
    # what waits in the slot queue, so the client cannot know the execution
    # id until the wait is over; every ``execution_queued`` event carries this
    # id instead, and ``POST /api/execute/queued/cancel`` ends the wait by it.
    client_request_id: Optional[str] = Field(
        default=None, max_length=64, pattern=CLIENT_REQUEST_ID_PATTERN)


class CancelQueuedRequest(BaseModel):
    """``POST /api/execute/queued/cancel`` (H1): end the caller's OWN slot
    wait by the ``client_request_id`` its POST carried."""
    model_config = ConfigDict(extra="forbid")

    client_request_id: str = Field(
        min_length=1, max_length=64, pattern=CLIENT_REQUEST_ID_PATTERN)


class UpdateQueryRequest(BaseModel):
    name:         Optional[str] = None
    description:  Optional[str] = None
    query_config: Optional[QueryConfigRequestModel] = None
    change_note:  Optional[str] = None


class ShareQueryRequest(BaseModel):
    expires_hours: Optional[int] = None


class ShareDashboardRequest(BaseModel):
    expires_hours: Optional[int] = None


# ── Streaming (DuckDB httpfs) models ─────────────────────────────────────────

class StreamQueryRequest(BaseModel):
    query_config: Optional[QueryConfigRequestModel] = None
    raw_sql: Optional[str] = None
    connection_id: Optional[int] = None
    limit: int = Field(default=500, ge=1, le=5000)


class StreamPaginateRequest(BaseModel):
    query_config: Optional[QueryConfigRequestModel] = None
    raw_sql: Optional[str] = None
    connection_id: Optional[int] = None
    page: int = Field(default=1, ge=1)
    page_size: int = Field(default=100, ge=1, le=5000)
    sort_column: Optional[str] = None
    sort_direction: str = Field(default="asc")
    adv_filters: Optional[str] = None
    columns: Optional[str] = None


class StreamSchemaRequest(BaseModel):
    query_config: Optional[QueryConfigRequestModel] = None
    raw_sql: Optional[str] = None
    connection_id: Optional[int] = None
    sample_rows: int = Field(default=100, ge=0, le=1000)


class StreamChartRequest(BaseModel):
    query_config: Optional[QueryConfigRequestModel] = None
    raw_sql: Optional[str] = None
    connection_id: Optional[int] = None
    x_col: str
    y_col: str
    agg: str = "sum"
    top_n: int = 50
    series_col: Optional[str] = None
    max_series: int = 10


class StreamPivotRequest(BaseModel):
    query_config: Optional[QueryConfigRequestModel] = None
    raw_sql: Optional[str] = None
    connection_id: Optional[int] = None
    row_fields: str          # comma-separated
    values: str              # JSON array
    col_field: Optional[str] = None
    top_n: int = 50


class EstimateRequest(BaseModel):
    query_config: QueryConfigRequestModel
    connection_id: Optional[int] = None


# ── Preview / Join models ────────────────────────────────────────────────────

class PreviewSqlRequest(BaseModel):
    query_config: QueryConfigRequestModel
    connection_id: Optional[int] = None


class JoinPreviewRequest(BaseModel):
    connection_id: Optional[int] = None
    left_file: str
    right_file: str
    left_on: List[str]
    right_on: List[str]
    how: str = "inner"


# ── Batch execution models ───────────────────────────────────────────────────

class BatchQueryItem(BaseModel):
    query_id: Optional[int] = None
    query_config: Optional[QueryConfigRequestModel] = None
    raw_sql: Optional[str] = None
    connection_id: Optional[int] = None
    output_format: str = Field(default="csv", pattern="^(csv|json)$")
    cache_strategy: str = Field(default="auto", pattern="^(auto|bypass|refresh)$")
    callback_url: Optional[str] = None
    priority: int = Field(default=5, ge=0, le=9)
    label: Optional[str] = None   # caller-defined label for tracking


class BatchSubmitRequest(BaseModel):
    queries: List[BatchQueryItem] = Field(..., min_length=1, max_length=50)


# ── Worker pool / Admin config models ────────────────────────────────────────

class WorkerPoolConfigUpdate(BaseModel):
    interactive_max_concurrent: Optional[int] = None
    interactive_default_timeout: Optional[int] = None
    interactive_max_queue: Optional[int] = None
    report_max_concurrent: Optional[int] = None
    report_default_timeout: Optional[int] = None
    report_max_queue: Optional[int] = None
    scheduled_max_concurrent: Optional[int] = None
    scheduled_default_timeout: Optional[int] = None
    scheduled_max_queue: Optional[int] = None
    export_max_concurrent: Optional[int] = None
    export_default_timeout: Optional[int] = None
    export_max_queue: Optional[int] = None
    system_max_concurrent: Optional[int] = None
    system_default_timeout: Optional[int] = None
    system_max_queue: Optional[int] = None


class AppConfigUpdateRequest(BaseModel):
    limits: Optional[dict] = None
    features: Optional[dict] = None


class QueueConfigUpdateRequest(BaseModel):
    backend: Optional[str] = None
    redis_url: Optional[str] = None
    redis_password: Optional[str] = None
    redis_db: Optional[int] = None
    redis_ssl: Optional[bool] = None
    key_prefix: Optional[str] = None
    task_ttl_hours: Optional[int] = None


# ── Cache invalidation ───────────────────────────────────────────────────────

class CacheInvalidateSourceRequest(BaseModel):
    table_name:    Optional[str] = None   # registered table name (e.g. "orders")
    file_prefix:   Optional[str] = None   # S3/local prefix (e.g. "data/orders/")
    connection_id: Optional[int] = None   # invalidate all queries for a connection


# ── Registered table model ───────────────────────────────────────────────────

class RegisteredTableModel(BaseModel):
    name: str = Field(min_length=1, max_length=128, pattern=r"^[a-zA-Z_][a-zA-Z0-9_.]*$")
    s3_prefix: str = Field(min_length=1)
    format: str = Field(pattern="^(iceberg|parquet|csv)$")
    description: str = ""


# ── Materialized view models ─────────────────────────────────────────────────

class MaterializedViewCreateModel(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    description: Optional[str] = None
    connection_id: int
    table_name: str
    table_format: str = "parquet"
    partition_filter: Optional[dict] = None
    query_filter: Optional[str] = None
    schedule_config: Optional[dict] = None


class MaterializedViewUpdateModel(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    partition_filter: Optional[dict] = None
    query_filter: Optional[str] = None
    schedule_config: Optional[dict] = None
    is_active: Optional[bool] = None


# ── Local table models ───────────────────────────────────────────────────────

class LocalTableCreateModel(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    description: Optional[str] = None
    visibility: str = "public"
    auto_discard_days: int = 10


class LocalTableUpdateModel(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    visibility: Optional[str] = None
    auto_discard_days: Optional[int] = None
    is_active: Optional[bool] = None


class LocalTablePromoteModel(BaseModel):
    file_id: str
    name: str = Field(min_length=1, max_length=255)
    description: Optional[str] = None
    visibility: str = "public"
    auto_discard_days: int = 10


# ── Auth / User models (used in main.py auth section) ────────────────────────

class LoginRequest(BaseModel):
    username: str
    password: str


class SubjectExportRequest(BaseModel):
    username: str


class UserPayload(BaseModel):
    username: str
    password: Optional[str] = None
    role: str = "viewer"
