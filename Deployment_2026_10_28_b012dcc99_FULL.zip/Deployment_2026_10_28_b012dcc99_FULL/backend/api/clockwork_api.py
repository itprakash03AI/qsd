"""Clockwork authoring API — 2026-09-10.

Plan: docs/CLOCKWORK_PLATFORM_PLAN_V2_2026_09_10.html (§1 job model, §2
catalogue, §4 placeholders, §6 validation, §7 UI), plus v1 for tenancy and
authority.

Routes (all under /api/clockwork; every one takes the REAL auth
dependency — never ``Depends(lambda: f)``):

    GET    /access                       the scope verdict (also for scope=none)
    GET    /task-types                   catalogue + routability
    GET    /placeholders                 vocabulary + masks
    GET    /calendars                    calendars a job may bind
    GET    /connections                  connections the caller may target
    GET    /jobs                         list (visible jobs only)
    POST   /jobs                         create (one version snapshot)
    POST   /jobs/validate                validate_job() on a draft
    POST   /preview                      next N occurrences, placeholders resolved
    GET    /jobs/{id}                    one job
    PUT    /jobs/{id}                    save; body.expected_version; 409 on mismatch
    DELETE /jobs/{id}
    POST   /jobs/{id}/enable             {enabled}; enabling runs the enable gate
    POST   /jobs/{id}/fire               a manual REQUEST ROW; returns its fire_key
    GET    /jobs/{id}/fires              run history (reflected), steps nested; 424 when
                                         Clockwork's DDL is absent (reason in detail)
    GET    /jobs/{id}/why-not-run        the row-backed verdict
    GET    /jobs/{id}/versions
    GET    /jobs/{id}/requests           manual requests for the job
    GET    /jobs/{id}/health
    PUT    /jobs/{id}/secrets/{name}     REFUSED (400): no secret lives on a job
    DELETE /jobs/{id}/secrets/{name}     REFUSED (400)
    GET    /fires/{fire_key}
    POST   /fires/{fire_key}/resume      a NEW manual occurrence; needs idempotent=true
    POST   /fires/{fire_key}/resolution  records a resolution; never rewrites status.
                                         On a CLAIMED fire: admin-only, note required,
                                         retires the CLAIMED request (RESOLVED) and
                                         lifts the run-now refusal (2026-09-11)
    GET    /alerts · POST /alerts/{id}/ack
    GET    /deployments · GET /health
    GET    /schema                       schema state: every Clockwork-owned DDL
                                         file, its status, the exact SQL and the
                                         psql command (admin)
    POST   /schema/apply                 apply what is missing, in manifest order (admin)
    POST   /schema/views                 re-run the views + arbiter index (admin)
    GET    /settings · PUT /settings     (PUT: admin)
    GET    /templates · POST /templates · GET/PUT/DELETE /templates/{id}  (writes: admin)

Bodies are plain ``dict`` and validated by hand.  A Pydantic 422 echoes
``input`` — a job body carries bind values, headers and connection ids,
and the refusal must not replay it.  Invisible resources are 404, not
403.  Auth MODE is never consulted here.
"""
from __future__ import annotations

import asyncio
import logging
import re
import secrets
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from api.deps import get_current_user, require_admin
from core.clockwork import catalogue as _cat
from core.clockwork import core_bridge as _core
from core.clockwork import dispatch_views as _dv
from core.clockwork import explain as _explain
from core.clockwork import fire_log as _fl
from core.clockwork import placeholders as _ph
from core.clockwork import query_templates as _qt
from core.clockwork import schema_admin as _sa
from core.clockwork import scope as _scope
from core.db.mixin_clockwork import ClockworkRequestOutstanding, outstanding_request_reason
from core.clockwork.validation import (
    ValidationContext, definition_of, schedule_warnings, validate_job,
)
from core.entitlements import can_edit, can_view, denied_connection_ids
from core.roles import is_admin_like, is_support

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/clockwork", tags=["clockwork"])

_db_manager: Any = None

TENANT_DEFAULT = "querystudio"
NO_SCOPE = "-"

#: The tick settings, EXACTLY the keys the Clockwork core declares in
#: ``clockwork.config.SETTINGS_SCHEMA`` -- the pod reads this table at boot
#: and REFUSES TO START on a key it does not declare, so a key stored here
#: that the core does not know is a scheduler that never comes up.  A test
#: pins this tuple to the core's schema (name, default and order); the
#: value is validated by the core's own schema on PUT.  (2026-09-10: the
#: authoring plane shipped five keys of its own -- tick_seconds,
#: max_jobs_per_tick, ... -- none of which the core declared.)
SETTINGS_DECLARED: tuple = (
    ("tick_schedule", "* * * * *",
     "How often a deployment RE-READS the job rows and evaluates each row's cron, as a "
     "cron expression in UTC.  This is not the fire schedule; each job carries its own."),
    ("max_rows_per_tick", 500,
     "Row cap per tick.  Reaching it is ALERTED, never silently truncated.  0 is refused."),
    ("missed_window_policy", "skip_and_alert",
     "skip_and_alert (default, matches house catchup=False) or fire."),
    ("misfire_grace_seconds", 300,
     "An occurrence older than this is MISSED.  A manual request older than this EXPIRES."),
    ("stale_claim_alert_seconds", 3600,
     "A claim still CLAIMED after this long is alerted as an UNKNOWN outcome needing a human."),
)
SETTINGS_NOTE = ("a deployment reads its settings ONCE, at startup; a change takes effect "
                 "when the Clockwork deployment restarts")

_RESOLUTION_VERDICTS = ("confirmed_ran", "confirmed_did_not_run", "completed_by_hand")
# The template rules live in core/clockwork/query_templates.py (pinned equal
# to the core's sql_scalar): oracle only, one SELECT, binds from the SQL.
_TEMPLATE_CONNECTION_TYPES = _qt.TEMPLATE_CONNECTION_TYPES
_TEMPLATE_NAME_RE = _qt.TEMPLATE_NAME_RE


def set_clockwork_dependencies(db_manager: Any) -> None:
    global _db_manager
    _db_manager = db_manager


async def _adb(fn, *args, **kwargs):
    return await asyncio.to_thread(fn, *args, **kwargs)


def _db():
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Database not initialized")
    return _db_manager


def _username(user: Optional[dict]) -> str:
    return str((user or {}).get("username", "") or "")


def _now() -> datetime:
    return datetime.now(timezone.utc)


# ── Scope: the component must be visible for this principal ────────────


def _component_visible(user: dict) -> Optional[bool]:
    """The admin visibility map's verdict for the scheduler key, or None
    when it cannot be consulted (default show)."""
    db = _db_manager
    if db is None:
        return None
    role = str((user or {}).get("role", "") or "viewer")
    try:
        resolved = db.get_ui_visibility_resolved(role, known_components=[_scope.SCHEDULER_COMPONENT_KEY])
    except Exception as exc:                                    # noqa: BLE001
        logger.debug("[clockwork] visibility lookup failed (default show): %s", exc)
        return None
    if not resolved:            # super_admin → {} == show everything
        return None
    return bool(resolved.get(_scope.SCHEDULER_COMPONENT_KEY, True))


async def _clockwork_user(user: dict = Depends(get_current_user)) -> dict:
    """Every scheduler route: the REAL auth dependency, then the component
    gate — an admin hiding the scheduler for a role hides its API too."""
    visible = await _adb(_component_visible, user)
    if _scope.scope_for(user, visible) == _scope.SCOPE_NONE:
        raise HTTPException(status_code=403, detail=(
            f"component '{_scope.SCHEDULER_COMPONENT_KEY}' is disabled for role "
            f"'{(user or {}).get('role')}' by the admin visibility map"))
    return user


def _require_author(user: dict) -> None:
    if not _scope.can_author(user):
        raise HTTPException(status_code=403, detail=(
            f"role '{(user or {}).get('role')}' may read the scheduler but not author jobs"))


# ── Per-job entitlement ────────────────────────────────────────────────


def _resource(job: dict) -> dict:
    return {"created_by": job.get("created_by"), "owner_group_id": job.get("owner_group_id"),
            "is_public": False}


def _in_list(job: dict, key: str, user: dict) -> bool:
    me = _username(user).lower()
    if not me:
        return False
    if str(job.get("owner") or "").lower() == me:
        return True
    acl = job.get("access") or {}
    return me in {str(x).lower() for x in (acl.get(key) or [])}


def _can_view(job: dict, user: dict) -> bool:
    if can_view(_resource(job), user, db=_db_manager):
        return True
    return any(_in_list(job, k, user) for k in ("edit", "enable", "fire"))


def _can_edit(job: dict, user: dict) -> bool:
    if is_support(user):
        return False
    if can_edit(_resource(job), user, db=_db_manager):
        return True
    return _scope.can_author(user) and _in_list(job, "edit", user)


def _can_enable(job: dict, user: dict) -> bool:
    return _can_edit(job, user) or (not is_support(user) and _in_list(job, "enable", user))


def _can_fire(job: dict, user: dict) -> bool:
    return _can_edit(job, user) or (not is_support(user) and _in_list(job, "fire", user))


async def _visible_job(job_id: int, user: dict) -> dict:
    job = await _adb(_db().get_clockwork_job, int(job_id))
    if not job or not _can_view(job, user):
        raise HTTPException(status_code=404, detail="Job not found")
    return job


# ── Validation context ─────────────────────────────────────────────────


def _fire_environment(authority: Optional[str]) -> str:
    db = _db()
    if authority:
        dep = db.get_clockwork_deployment(str(authority))
        if dep and dep.get("environment"):
            return str(dep["environment"])
    try:
        from core.config import deploy_environment
        return str(deploy_environment() or "")
    except Exception:                                           # noqa: BLE001
        return ""


def _schedule_check():
    """The core's ONE schedule parser when it is loadable; else the
    cron-only fallback that refuses a working-day expression by name."""
    try:
        return _core.load_core().schedule.check_expression
    except _core.CoreUnavailable:
        return None


def _ctx(user: dict, authority: Optional[str]) -> ValidationContext:
    db = _db()
    reported = db.list_clockwork_task_types()
    deployments = db.list_clockwork_deployments()
    types = {t["name"]: t for t in _cat.merged_catalogue(reported, deployments)}
    return ValidationContext(
        connection_lookup=lambda cid: db.get_connection(int(cid)),
        denied_connections=lambda ids: denied_connection_ids(user, list(ids), db=db),
        template_lookup=lambda tid: db.get_clockwork_template(int(tid)),
        calendar_lookup=lambda cid: db.get_feed_calendar(int(cid)),
        system_account_lookup=lambda sid: db.get_system_account(int(sid)),
        task_types=types,
        fire_environment=_fire_environment(authority),
        schedule_check=_schedule_check(),
    )


def _validate(definition: dict, user: dict, *, for_enable: bool) -> List[dict]:
    return validate_job(definition, _ctx(user, definition.get("authority")), for_enable=for_enable)


def _warnings(definition: dict) -> List[dict]:
    """The schedule warnings a VALID definition carries (cron's ORed
    day-of-month / day-of-week above all).  Never silent: returned beside
    every validate and every save."""
    return schedule_warnings(definition, ValidationContext(schedule_check=_schedule_check()))


def _refuse(problems: List[dict]) -> None:
    raise HTTPException(status_code=400, detail={"ok": False, "problems": problems})


def _core_unavailable(reason: str) -> HTTPException:
    """The dispatcher's validator cannot be consulted: refused WITH THE
    REASON (plan v2 §10: scoped, never a boot failure, never a stored
    guess).  424 Failed Dependency rather than 503, for the same reason the
    fire-log routes use it: the house HTTPException chokepoint replaces
    every 5xx detail with a generic string (CWE-209), and the reason is the
    whole point -- "install the clockwork package" must reach the screen."""
    return HTTPException(status_code=424, detail={
        "ok": False, "code": "clockwork_core_unavailable",
        "problems": [{"path": "dispatch", "message": reason}]})


def _http_from_not_dispatchable(exc: Any) -> HTTPException:
    """``ClockworkNotDispatchable`` from the row's writer -> the HTTP verdict:
    424 when the core could not be consulted, 400 with the core's words
    otherwise."""
    if getattr(exc, "core_unavailable", False):
        return _core_unavailable(exc.problems[0]["message"] if exc.problems else str(exc))
    return HTTPException(status_code=400, detail={"ok": False, "problems": list(exc.problems)})


def _dispatch_projection(definition: dict):
    """The projection a manual fire snapshots onto its request.  Refuses
    (400, the core's words) or 503 (core unavailable); never returns None."""
    from core.clockwork.core_bridge import CoreUnavailable
    db = _db()
    try:
        projection = db.project_clockwork_job(definition)
    except CoreUnavailable as exc:
        raise _core_unavailable(exc.reason)
    if projection.definition is None:
        _refuse(projection.problems)
    return projection


def _dispatch_verdict(definition: dict) -> dict:
    """``{"ok", "problems", "warnings"}`` for a validate response -- the
    core's verdict, or the reason it could not be asked, never an
    exception."""
    from core.clockwork.projection import project_or_reasons
    db = _db()
    p = project_or_reasons(definition, calendar_lookup=db.clockwork_projection_calendar,
                           template_lookup=db.get_clockwork_template)
    return {"ok": p.definition is not None, "problems": list(p.problems),
            "warnings": list(p.warnings)}


#: The most bytes of JSON one job definition may be.
#:
#: 2026-09-11: there was no limit anywhere on this surface, and a 1 GB
#: definition was ACCEPTED -- parsed, validated, projected and stored.  A job
#: is six properties and at most ``validation.MAX_STEPS`` steps; a megabyte is
#: already two orders of magnitude past any real one, and the check is on the
#: PARSED body rather than on the request stream because that is where this
#: module can see it (the streaming limit belongs to the ASGI server, and is
#: a deployment knob, not a route's).
MAX_DEFINITION_BYTES = 1048576


def _refuse_oversize(body: Any, what: str, limit: int = MAX_DEFINITION_BYTES) -> None:
    """Refuse a body whose JSON is bigger than ``limit``.  Cheap: the body
    has already been parsed by the time a route sees it, and re-serialising
    it is the only way to measure what was actually sent."""
    import json as _json
    try:
        size = len(_json.dumps(body, default=str).encode("utf-8"))
    except (TypeError, ValueError):                     # not serialisable
        return                                          # the validator says so
    if size > limit:
        raise HTTPException(status_code=413, detail={"ok": False, "problems": [
            {"path": "", "message": (f"the {what} is {size} bytes of JSON; at most {limit} "
                                     f"is accepted.  A job is six properties and a short "
                                     f"step list; a body this size is not one")}]})


def _clean_definition(body: dict) -> dict:
    if not isinstance(body, dict):
        raise HTTPException(status_code=400, detail={"ok": False, "problems": [
            {"path": "", "message": "body must be a JSON object"}]})
    _refuse_oversize(body, "job definition")
    d = {k: v for k, v in body.items() if k not in ("expected_version", "id", "version", "secrets",
                                                    "created_by", "created_at", "updated_by",
                                                    "updated_at", "owner_group_id")}
    d.setdefault("tenant", TENANT_DEFAULT)
    d.setdefault("enabled", False)
    d.setdefault("access", {"edit": [], "enable": [], "fire": []})
    d.setdefault("misfire_grace_seconds", 300)
    d.setdefault("timezone", "UTC")
    if "idempotent" not in d:
        d["idempotent"] = None
    return d


def _core_calendar(core: Any, definition: dict):
    """The CORE's calendar for a definition -- the very object the
    dispatcher walks -- or (None, problem).  Built through the projection's
    own translation so the preview cannot disagree with the fire."""
    from core.clockwork.projection import _calendar as project_calendar
    from core.clockwork.projection import _weekend_days as project_weekend
    db = _db()
    cal_id = definition.get("calendar_id")
    if cal_id is not None:
        problems: List[dict] = []
        spec = project_calendar(definition, db.clockwork_projection_calendar(int(cal_id)), problems)
        if problems:
            return None, problems[0]["message"]
        try:
            return core.calendar.parse_calendar(spec), None
        except core.calendar.CalendarError as exc:
            return None, str(exc)
    days = definition.get("weekend_days")
    if days is None:
        return None, "a job must bind a calendar or declare its weekend days"
    weekend = project_weekend(days)
    if weekend is None:
        return None, "weekend_days must be ISO weekday numbers (Mon=1 .. Sun=7)"
    return core.calendar.Calendar.weekend_only(frozenset(weekend)), None


def _health_for(job_id: int, rows: List[dict]) -> dict:
    mine = [r for r in rows if int(r.get("job_id") or -1) == int(job_id)]
    if not mine:
        return {"state": "never_probed", "checked_at": None, "checked_by": None,
                "reason": "no deployment has probed this job"}
    latest = sorted(mine, key=lambda r: str(r.get("checked_at") or ""))[-1]
    return {"state": latest.get("state") or "never_probed", "checked_at": latest.get("checked_at"),
            "checked_by": latest.get("deployment_id"), "reason": latest.get("reason")}


def _parse_key(fire_key: str) -> tuple:
    parts = str(fire_key or "").split("|")
    if len(parts) != 4:
        raise HTTPException(status_code=400, detail="fire_key must be tenant|job_id|scope|stamp")
    return parts[0], parts[1], parts[2], parts[3]


# ── Access / catalogue / vocabulary ────────────────────────────────────


@router.get("/access")
async def clockwork_access(user: dict = Depends(get_current_user)):
    """The scope verdict.  Served even when scope is 'none' so the frontend
    can READ the rule instead of re-deriving it."""
    visible = await _adb(_component_visible, user)
    return _scope.access_payload(user, visible)


@router.get("/task-types")
async def clockwork_task_types(user: dict = Depends(_clockwork_user)):
    db = _db()
    reported = await _adb(db.list_clockwork_task_types)
    deployments = await _adb(db.list_clockwork_deployments)
    return {"task_types": _cat.merged_catalogue(reported, deployments), "deployments": deployments}


@router.get("/placeholders")
async def clockwork_placeholders(user: dict = Depends(_clockwork_user)):
    return {"placeholders": _ph.vocabulary(), "masks": _ph.documented_masks()}


@router.get("/schedule-grammar")
async def clockwork_schedule_grammar(user: dict = Depends(_clockwork_user)):
    """THE CONTRACT for a schedule builder: the one ``cron`` field, its two
    dialects (a five-field cron, or ``wd N HH:MM``), the working-day
    ranges, the identity rule, and what is refused.  Read from the core --
    the same parser the dispatcher runs -- so the builder and the fire
    cannot disagree.  424 with the reason when the core is not loadable."""
    try:
        core = await _adb(_core.load_core)
    except _core.CoreUnavailable as exc:
        raise _core_unavailable(exc.reason)
    grammar = core.schedule.grammar()
    grammar["warning_example"] = {
        "expression": "20 0 1-3 * 1-5",
        "warnings": core.schedule.cron_warnings("20 0 1-3 * 1-5"),
        "meant": "wd 1 00:20",
    }
    return grammar


@router.get("/calendars")
async def clockwork_calendars(user: dict = Depends(_clockwork_user)):
    """The calendar picker.  2026-09-11 audit (item 6): a calendar whose
    holidays could not be READ was served as ``holiday_count: 0`` -- unknown
    rendered as empty -- for a calendar the projection REFUSES (a job cannot
    fire against a calendar nobody can read).  Now ``holiday_count`` is
    ``null`` with ``holidays_error`` naming the failure, and the picker
    disables it with that reason."""
    db = _db()
    rows = await _adb(db.list_feed_calendars, True)
    out = []
    for c in rows:
        count: Optional[int] = None
        error: Optional[str] = None
        try:
            count = len(await _adb(db.list_feed_holidays, int(c["id"])))
        except Exception as exc:                                # noqa: BLE001 - reported, never 0
            error = f"{type(exc).__name__}: {exc}"[:300]
            logger.warning("[clockwork] holidays of calendar %s could not be read: %s", c.get("id"), error)
        out.append({"id": c["id"], "name": c["name"], "version": c.get("version") or 1,
                    "weekend_days": list(c.get("weekend_days") or []),
                    "holiday_count": count, "holidays_error": error,
                    "horizon_end": c.get("horizon_end"), "owner": c.get("owner")})
    return {"calendars": out}


@router.get("/connections")
async def clockwork_connections(user: dict = Depends(_clockwork_user)):
    """The target picker: only connections the AUTHOR may use."""
    db = _db()
    rows = await _adb(db.list_connections, True, 1000, 0)
    ids = [int(c["id"]) for c in rows]
    denied = set(int(x) for x in await _adb(denied_connection_ids, user, ids, db=db))
    out = []
    for c in rows:
        if int(c["id"]) in denied:
            continue
        cfg = c.get("config") if isinstance(c.get("config"), dict) else {}
        sa_ref = cfg.get("system_account_id")
        acct = None
        if sa_ref not in (None, ""):
            try:
                a = await _adb(db.get_system_account, int(sa_ref))
            except (TypeError, ValueError):
                a = None
            if a:
                acct = {"id": a["id"], "name": a["name"], "environment": a.get("environment"),
                        "use_vault": bool(a.get("use_vault")), "is_active": bool(a.get("is_active"))}
        out.append({"id": c["id"], "name": c["name"], "connection_type": c.get("connection_type"),
                    "is_shared": bool(c.get("is_shared")), "system_account": acct})
    return {"connections": out}


# ── Jobs ───────────────────────────────────────────────────────────────


@router.get("/jobs")
async def list_jobs(user: dict = Depends(_clockwork_user)):
    db = _db()
    jobs = [j for j in await _adb(db.list_clockwork_jobs) if _can_view(j, user)]
    health_rows = await _adb(db.list_clockwork_job_health)
    avail = await _adb(_fl.availability, db.engine)
    dispatch = await _adb(_dv.availability, db.engine)
    # one read: the outstanding manual request per listed job (item 1, 2026-09-11)
    outstanding = await _adb(db.outstanding_clockwork_manual_requests, [int(j["id"]) for j in jobs])
    now = _now()
    conn_cache: Dict[int, Optional[dict]] = {}
    out = []
    for j in jobs:
        conn = None
        if j.get("connection_id") is not None:
            cid = int(j["connection_id"])
            if cid not in conn_cache:
                conn_cache[cid] = await _adb(db.get_connection, cid)
            c = conn_cache[cid]
            conn = {"id": c["id"], "name": c["name"], "type": c.get("connection_type")} if c else None
        nxt, nxt_reason = await _adb(_next_occurrence, j, now)
        last = None
        last_error = None
        if avail["available"]:
            try:
                lf = await _adb(_fl.latest_fire, db.engine, j.get("tenant") or TENANT_DEFAULT, j["id"])
                if lf:
                    last = {"fire_key": lf["fire_key"], "status": lf["status"],
                            "scheduled_fire": lf["scheduled_fire"], "completed_at": lf["completed_at"],
                            "resolution": await _adb(db.get_clockwork_fire_resolution, lf["fire_key"])}
            except Exception as exc:                            # noqa: BLE001
                # 2026-09-11: a read failure is NOT "no fire on record".  This
                # was swallowed at DEBUG and the verdict below was then computed
                # over ``last=None`` -- ALLOWED, "no fire is on record for this
                # job" -- for a fire the list could not see.  Unknown is unsafe.
                last_error = f"{type(exc).__name__}: {exc}"
                logger.warning("[clockwork] latest_fire failed for job %s: %s", j["id"], last_error)
        out.append({
            "id": j["id"], "name": j["name"], "description": j.get("description") or "",
            "enabled": bool(j.get("enabled")), "cron": j["cron"], "timezone": j.get("timezone") or "UTC",
            "owner": j.get("owner") or "", "idempotent": j.get("idempotent"),
            "authority": j.get("authority"), "version": j.get("version"),
            "next_occurrence_at": nxt, "next_occurrence_reason": nxt_reason,
            "last_fire": last, "connection": conn,
            "health": _health_for(j["id"], health_rows), "step_count": len(j.get("steps") or []),
            "can_edit": _can_edit(j, user), "can_fire": _can_fire(j, user),
            "dispatchable": bool(j.get("dispatchable")),
            # THE RUN-NOW GATE, the server's verdict on the row the list
            # shows, so the list's button cannot offer what the route refuses
            # (the route re-reads the latest fire at request time).
            "run_now": _run_now_from_list(j, last, avail, read_error=last_error,
                                          outstanding=outstanding.get(int(j["id"]))),
        })
    return {"jobs": out, "total": len(out), "fire_log": avail, "dispatch": dispatch}


def _run_now_from_list(job: dict, last: Optional[dict], avail: dict,
                       read_error: Optional[str] = None,
                       outstanding: Optional[dict] = None) -> dict:
    """The list already read the latest fire (or learned the log is
    unreadable); the verdict over that, in the same shape ``GET /jobs/{id}``
    serves.  ``read_error`` is a latest-fire read that FAILED on a readable
    log: refused with the reason, never read as "no fire"."""
    if read_error:
        return {"allowed": False, "code": "read_failed",
                "reason": (f"the latest fire could not be read, so its status is unknown and run now "
                           f"cannot be gated on it: {read_error}")}
    if not avail.get("available") and avail.get("code") != "table_missing":
        return {"allowed": False, "code": avail.get("code") or "unavailable",
                "reason": (f"the fire log could not be read, so the latest fire's status is unknown "
                           f"and run now cannot be gated on it: {avail.get('reason')}")}
    allowed, reason = run_now_verdict(job, last, outstanding)
    return {"allowed": allowed, "reason": reason, "code": None}


@router.post("/jobs/validate")
async def validate_draft(body: dict, user: dict = Depends(_clockwork_user)):
    """The authoring verdict, plus the DISPATCHER's verdict on the projected
    definition under ``dispatch``.  A draft (enabled=false) may be saved
    with dispatch problems -- they stop enable and fire, not the save -- so
    they join ``problems`` only when the draft is enabled."""
    d = _clean_definition(body)
    problems = await _adb(_validate, d, user, for_enable=bool(d.get("enabled")))
    dispatch = await _adb(_dispatch_verdict, d)
    if d.get("enabled") and not dispatch["ok"]:
        problems = problems + [p for p in dispatch["problems"] if p not in problems]
    warnings = await _adb(_warnings, d)
    return {"ok": not problems, "problems": problems, "warnings": warnings,
            "dispatch": dispatch}


@router.post("/jobs", status_code=201)
async def create_job(body: dict, request: Request, user: dict = Depends(_clockwork_user)):
    from core.db.mixin_clockwork import ClockworkNotDispatchable
    _require_author(user)
    db = _db()
    d = _clean_definition(body)
    problems = await _adb(_validate, d, user, for_enable=bool(d.get("enabled")))
    if problems:
        _refuse(problems)
    if await _adb(db.get_clockwork_job_by_name, d["name"]):
        _refuse([{"path": "name", "message": f"a job named {d['name']!r} already exists"}])
    try:
        job = await _adb(db.create_clockwork_job, d, created_by=_username(user))
    except ClockworkNotDispatchable as exc:
        raise _http_from_not_dispatchable(exc)
    await _adb(db.audit, _username(user), "clockwork_job_create", resource_type="clockwork_job",
               resource_id=str(job["id"]), details={"name": job["name"]})
    job["warnings"] = job.get("dispatch_warnings") or await _adb(_warnings, d)
    return job


#: The most placeholder requests one preview will resolve.
#:
#: 2026-09-11.  ``count`` was capped at 50 and ``placeholders`` was never
#: length-checked at all, and the per-occurrence x per-placeholder loop ran
#: INLINE in the async coroutine rather than through ``_adb`` -- so the work
#: was done on the event loop, where it blocks every other request this
#: worker is serving.  Measured on this tree: 100k placeholders = a 14.5 s
#: stall, 1M = 144.7 s.  Fifty is already far past what a job can carry
#: (``validation.MAX_STEPS`` steps x their binds), so the cap costs the UI
#: nothing.
MAX_PREVIEW_PLACEHOLDERS = 200

#: The most occurrences a preview computes.  Unchanged; named so the two
#: multiplicands of the loop's cost are both visible in one place.
MAX_PREVIEW_COUNT = 50


def _preview_occurrences(core, schedule, start, tz, cal, count, reqs,
                         job_id: str, expression: str) -> Tuple[List[dict], List[dict]]:
    """The occurrence walk and the placeholder resolution -- SYNCHRONOUS, and
    called through ``_adb`` so it runs on a worker thread.

    It is pure CPU over the request body (``count`` x ``len(reqs)`` calls
    into the core's renderer), and the event loop is not where that belongs;
    see :data:`MAX_PREVIEW_PLACEHOLDERS`.
    """
    try:
        instants = core.schedule.next_occurrences(schedule, start, tz, cal, count)
    except core.schedule.ScheduleError as exc:
        return [], [{"path": "cron", "message": str(exc)}]
    zone = ZoneInfo(tz)
    occurrences = []
    for seq, inst in enumerate(instants, start=1):
        occ = core.occurrence.Occurrence(
            tenant=TENANT_DEFAULT, job_id=job_id, scope=NO_SCOPE,
            cron_expression=expression, scheduled_fire=inst.due, timezone=tz,
            calendar=cal, identity_fire=None if inst.identity == inst.due else inst.identity)
        values: Dict[str, Optional[str]] = {}
        occ_problems: List[str] = []
        for r in reqs:
            try:
                values[r["ref"]] = core.placeholders.resolve_text(
                    r["placeholder"], occ.job_id, occ.scope, occ.scheduled_fire, tz, cal,
                    r.get("format") or "", fire_key=occ.fire_key)
            except core.placeholders.PlaceholderError as exc:
                values[r["ref"]] = None
                occ_problems.append(f"{r['ref']}: {exc}")
        resolved = {row["placeholder"]: row["value"]
                    for row in core.placeholders.preview(inst.due, tz, cal)}
        resolved["FIRE_KEY"] = occ.fire_key
        resolved["JOB_ID"] = occ.job_id
        resolved["SCOPE"] = occ.scope
        occurrences.append({
            "seq": seq,
            "scheduled_at_utc": inst.due.isoformat(),
            "scheduled_at_local": inst.due.astimezone(zone).isoformat(),
            "identity_at_utc": inst.identity.isoformat(),
            "fire_key": occ.fire_key,
            "values": values,
            "resolved": resolved,
            "problems": occ_problems,
        })
    return occurrences, []


@router.post("/preview")
async def preview(body: dict, user: dict = Depends(_clockwork_user)):
    """Next N occurrences with every requested placeholder resolved through
    its declared mask -- computed by the CORE (the same parser, calendar
    walk and renderer the dispatcher runs), so what the screen shows is what
    the procedure gets.  The only clock read is here, at the route.

    ``cron`` holds the schedule expression: a five-field cron, or
    ``wd N HH:MM``.  Beside the occurrences: ``schedule`` (kind, description),
    ``warnings`` (cron's ORed fields), and for a working-day schedule each
    occurrence's ``identity_at_utc`` -- the month anchor its fire key carries,
    distinct from the due instant.
    """
    if not isinstance(body, dict):
        raise HTTPException(status_code=400, detail="body must be a JSON object")
    _refuse_oversize(body, "preview request")
    _require_author(user)
    try:
        core = await _adb(_core.load_core)
    except _core.CoreUnavailable as exc:
        raise _core_unavailable(exc.reason)
    problems: List[dict] = []
    warnings: List[dict] = []
    expression = str(body.get("cron") or body.get("schedule") or "").strip()
    schedule = None
    try:
        schedule = core.schedule.parse_schedule(expression)
        warnings = [{"path": "cron", "message": w}
                    for w in core.schedule.check_expression(expression)[1]]
    except core.schedule.ScheduleError as exc:
        problems.append({"path": "cron", "message": str(exc)})
    tz = str(body.get("timezone") or "UTC")
    try:
        ZoneInfo(tz)
    except (ZoneInfoNotFoundError, ValueError, KeyError):
        problems.append({"path": "timezone", "message": f"{tz!r} is not a known IANA timezone"})
    count = body.get("count", 10)
    if not isinstance(count, int) or isinstance(count, bool) or count < 1 or count > MAX_PREVIEW_COUNT:
        problems.append({"path": "count",
                         "message": f"count must be an integer from 1 to {MAX_PREVIEW_COUNT}"})
        count = 10
    reqs = body.get("placeholders") or []
    if not isinstance(reqs, list):
        problems.append({"path": "placeholders", "message": "placeholders must be a list of {ref, placeholder, format}"})
        reqs = []
    elif len(reqs) > MAX_PREVIEW_PLACEHOLDERS:
        # REFUSED, not truncated.  A preview that silently resolved the
        # first 200 of 1,000 would show a screen that is not the job.
        problems.append({
            "path": "placeholders",
            "message": (f"at most {MAX_PREVIEW_PLACEHOLDERS} placeholders may be previewed "
                        f"at once (got {len(reqs)}); the preview resolves count x "
                        f"placeholders values and an unbounded list is a request that "
                        f"occupies this worker for minutes")})
        reqs = []
    start = _now()
    if body.get("from_utc"):
        try:
            start = datetime.fromisoformat(str(body["from_utc"]).replace("Z", "+00:00"))
            if start.tzinfo is None:
                start = start.replace(tzinfo=timezone.utc)
        except ValueError:
            problems.append({"path": "from_utc", "message": "from_utc must be an ISO-8601 timestamp"})
    cal = None
    cal_meta = None
    definition = {"calendar_id": body.get("calendar_id"), "weekend_days": body.get("weekend_days")}
    if definition["calendar_id"] is not None and definition["weekend_days"] is not None:
        problems.append({"path": "weekend_days", "message": "declare a calendar OR weekend days, not both"})
    else:
        cal, cal_problem = await _adb(_core_calendar, core, definition)
        if cal_problem:
            problems.append({"path": "calendar_id", "message": cal_problem})
        elif definition["calendar_id"] is not None and cal is not None:
            cal_meta = {"id": definition["calendar_id"], "name": cal.name, "version": cal.version,
                        "horizon_end": cal.horizon_end.isoformat() if cal.horizon_end else None,
                        "holidays": cal.holiday_count}
    vocabulary = core.placeholders.ALL_PLACEHOLDERS
    for i, r in enumerate(reqs):
        if not isinstance(r, dict) or not isinstance(r.get("ref"), str) or not isinstance(r.get("placeholder"), str):
            problems.append({"path": f"placeholders[{i}]", "message": "each entry is {ref, placeholder, format}"})
        elif r["placeholder"] not in vocabulary:
            problems.append({"path": f"placeholders[{i}].placeholder",
                             "message": f"unknown placeholder {r['placeholder']!r}; valid: {', '.join(vocabulary)}"})
        elif r["placeholder"] in core.placeholders.DATE_PLACEHOLDERS:
            try:
                core.placeholders.check_format(r.get("format") or "")
            except core.placeholders.PlaceholderError as exc:
                problems.append({"path": f"placeholders[{i}].format", "message": str(exc)})
    weekend_days = sorted(d + 1 for d in cal.weekend) if cal is not None else []
    schedule_meta = ({"kind": schedule.kind, "expression": schedule.expression,
                      "description": schedule.describe()} if schedule is not None else None)
    if problems:
        return {"occurrences": [], "calendar": cal_meta, "weekend_days": weekend_days,
                "schedule": schedule_meta, "warnings": warnings, "problems": problems}

    job_id = str(body.get("job_id", "draft"))
    # OFF THE EVENT LOOP.  Every other database-or-CPU call in this module
    # goes through ``_adb``; this loop did not, and it is the one that scales
    # with the request body.
    occurrences, walk_problems = await _adb(
        _preview_occurrences, core, schedule, start, tz, cal, count, reqs,
        job_id, expression)
    return {"occurrences": occurrences, "calendar": cal_meta, "weekend_days": weekend_days,
            "schedule": schedule_meta, "warnings": warnings, "problems": walk_problems}


@router.get("/jobs/{job_id}")
async def get_job(job_id: int, user: dict = Depends(_clockwork_user)):
    job = await _visible_job(job_id, user)
    job["can_edit"] = _can_edit(job, user)
    job["can_enable"] = _can_enable(job, user)
    job["can_fire"] = _can_fire(job, user)
    job["run_now"] = await _run_now_state(job)
    return job


@router.put("/jobs/{job_id}")
async def update_job(job_id: int, body: dict, user: dict = Depends(_clockwork_user)):
    from core.db.mixin_clockwork import ClockworkNotDispatchable, ClockworkVersionConflict
    job = await _visible_job(job_id, user)
    if not _can_edit(job, user):
        raise HTTPException(status_code=403, detail="You may view this job but not edit it")
    if not isinstance(body, dict) or not isinstance(body.get("expected_version"), int) \
            or isinstance(body.get("expected_version"), bool):
        raise HTTPException(status_code=400, detail={"ok": False, "problems": [
            {"path": "expected_version", "message": "expected_version (the version you loaded) is required"}]})
    d = _clean_definition(body)
    problems = await _adb(_validate, d, user, for_enable=bool(d.get("enabled")))
    if problems:
        _refuse(problems)
    if d["name"] != job["name"]:
        other = await _adb(_db().get_clockwork_job_by_name, d["name"])
        if other and int(other["id"]) != int(job_id):
            _refuse([{"path": "name", "message": f"a job named {d['name']!r} already exists"}])
    try:
        updated = await _adb(_db().update_clockwork_job, int(job_id), d,
                             expected_version=int(body["expected_version"]),
                             updated_by=_username(user), note=str(body.get("note") or "saved")[:255])
    except ClockworkVersionConflict as exc:
        raise HTTPException(status_code=409, detail={
            "message": f"the job was saved by someone else: you loaded version {exc.expected}, "
                       f"the row is at version {exc.actual}.  Reload and re-apply your change.",
            "expected_version": exc.expected, "current_version": exc.actual})
    except ClockworkNotDispatchable as exc:
        raise _http_from_not_dispatchable(exc)
    if not updated:
        raise HTTPException(status_code=404, detail="Job not found")
    await _adb(_db().audit, _username(user), "clockwork_job_update", resource_type="clockwork_job",
               resource_id=str(job_id), details={"version": updated["version"]})
    updated["warnings"] = updated.get("dispatch_warnings") or await _adb(_warnings, d)
    return updated


@router.delete("/jobs/{job_id}")
async def delete_job(job_id: int, user: dict = Depends(_clockwork_user)):
    job = await _visible_job(job_id, user)
    if not _can_edit(job, user):
        raise HTTPException(status_code=403, detail="You may view this job but not delete it")
    pending = await _adb(_db().list_clockwork_manual_requests, job_id=int(job_id), status="PENDING")
    if pending:
        raise HTTPException(status_code=409, detail=(
            f"{len(pending)} manual request(s) are still PENDING for this job; a deployment may "
            f"claim them.  Wait for them to resolve, then delete."))
    n = await _adb(_db().delete_clockwork_job, int(job_id))
    await _adb(_db().audit, _username(user), "clockwork_job_delete", resource_type="clockwork_job",
               resource_id=str(job_id), details={"name": job["name"]})
    return {"deleted": int(n)}


@router.post("/jobs/{job_id}/enable")
async def set_enabled(job_id: int, body: dict, user: dict = Depends(_clockwork_user)):
    from core.db.mixin_clockwork import ClockworkNotDispatchable, ClockworkVersionConflict
    job = await _visible_job(job_id, user)
    if not _can_enable(job, user):
        raise HTTPException(status_code=403, detail="You may view this job but not enable or disable it")
    if not isinstance(body, dict) or not isinstance(body.get("enabled"), bool):
        raise HTTPException(status_code=400, detail={"ok": False, "problems": [
            {"path": "enabled", "message": "enabled must be true or false"}]})
    d = definition_of(job)
    d["enabled"] = bool(body["enabled"])
    note = "enabled" if d["enabled"] else "disabled"
    if d["enabled"]:
        if not d.get("authority"):
            deployments = await _adb(_db().list_clockwork_deployments)
            if len(deployments) == 1:
                d["authority"] = deployments[0]["deployment_id"]
                note = f"enabled; authority bound to {d['authority']!r} (the sole reported deployment)"
        problems = await _adb(_validate, d, user, for_enable=True)
        if problems:
            _refuse(problems)
    try:
        updated = await _adb(_db().update_clockwork_job, int(job_id), d,
                             expected_version=int(job["version"]), updated_by=_username(user), note=note)
    except ClockworkVersionConflict as exc:
        raise HTTPException(status_code=409, detail={
            "message": "the job changed underneath this request; reload and retry",
            "expected_version": exc.expected, "current_version": exc.actual})
    except ClockworkNotDispatchable as exc:
        # The row's writer refused to store an ENABLED job the dispatcher
        # would not run.  Enabling is exactly the gate this exists for.
        raise _http_from_not_dispatchable(exc)
    await _adb(_db().audit, _username(user), "clockwork_job_" + ("enable" if d["enabled"] else "disable"),
               resource_type="clockwork_job", resource_id=str(job_id))
    return updated


def run_now_verdict(job: dict, latest_fire: Optional[dict],
                    outstanding: Optional[dict] = None) -> Tuple[bool, str]:
    """THE run-now gate, as data: ``(allowed, reason)``.  Pure; the UI
    renders the server's verdict (``run_now`` on the job and the list) and
    never a copy of the rule -- the UI may not offer an action the server
    refuses.

    2026-09-11 audit: ``outstanding`` is the job's PENDING or CLAIMED manual
    request, if any.  Two "run now" requests for one job were two PENDING
    rows under two fresh keys, both claimed, both run (proved on the memory
    backend and on a real PostgreSQL).  The MECHANISM is the partial unique
    index ``models.MANUAL_ARBITER_INDEX`` -- the INSERT loses, not a check
    -- and this verdict is the honest early answer the UI shows so the
    button says why before the constraint has to.

    2026-09-10 audit: "run now" read neither ``enabled``, ``idempotent``
    nor the last fire, while ``resume`` -- which re-drives FEWER steps --
    required all three.  The whole-job re-drive was gated less.  The gate:

      * a DISABLED job may not be hand-fired.  ``enabled`` is the one bit
        that means "this job may run"; a job is commonly disabled BECAUSE it
        must not run, and the dispatch view no longer carries its requests
        anyway (the view decides; this refusal is the honest early answer).
        Not widened: a "dry run of a disabled job" would be a feature with
        its own explicit allowance, not an omission.
      * the latest fire still CLAIMED: still running, or a dead pod.  Same
        refusal as resume -- resolve the row first.
      * the latest fire UNKNOWN and unresolved: its side effect may have
        happened.  Allowed only when the job DECLARES idempotent = true (as
        resume requires) or a human has recorded a resolution on the row.
      * SUCCESS / FAILED / SKIPPED_MISSED / REFUSED are KNOWN answers; the
        operator sees them and decides -- run-now exists to re-drive a
        missed or refused occurrence, which a non-idempotent job may need.
    """
    if not job.get("enabled"):
        return False, ("the job is disabled; a disabled job is not hand-fired -- enable it "
                       "and request again")
    if outstanding:
        return False, outstanding_request_reason(outstanding)
    if not latest_fire:
        return True, "no fire is on record for this job"
    status = str(latest_fire.get("status") or "").upper()
    if status == "CLAIMED":
        res = latest_fire.get("resolution")
        if res:
            # 2026-09-11 (audit remainder, item 1): a human asserted the
            # occurrence is finished -- deliberately, audited, admin-only,
            # with a note (the route enforces that).  The row stays CLAIMED
            # (the column is Clockwork's); the resolution is what lifts this.
            return True, (f"the latest fire {latest_fire.get('fire_key')} is still CLAIMED, but a "
                          f"resolution ({res.get('verdict')}) was recorded by {res.get('resolved_by')}")
        return False, (f"the latest fire {latest_fire.get('fire_key')} is still CLAIMED (running, "
                       f"or a dead pod); resolve it first -- an admin records a resolution on that "
                       f"fire, which retires its request and lifts this refusal")
    if status == "UNKNOWN" and not latest_fire.get("resolution"):
        if job.get("idempotent") is True:
            return True, ("the latest fire's answer was lost, but the job declares "
                          "idempotent = true")
        return False, (f"the latest fire {latest_fire.get('fire_key')} is UNKNOWN -- its side "
                       f"effect may have happened -- and the job does not declare idempotent = "
                       f"true; record a resolution on that fire first")
    return True, f"the latest fire is {status or 'recorded'}"


async def _run_now_state(job: dict) -> dict:
    """``{"allowed", "reason", "code"}`` -- :func:`run_now_verdict` over the
    latest fire, READ HERE.  Served on the job (``GET /jobs/{id}``) and on
    the list so the UI renders the server's verdict rather than a copy of
    the rule, and applied by the fire route.  A fire log that cannot be
    READ refuses with its reason (``code`` = the reader's; unknown is
    unsafe); a fire log not deployed yet (``table_missing``) has no fire to
    protect and does not block."""
    latest = None
    try:
        latest = await _adb(_fl.latest_fire, _db().engine, job.get("tenant") or TENANT_DEFAULT, job["id"])
    except _fl.FireLogUnavailable as exc:
        if exc.code != "table_missing":
            return {"allowed": False, "code": exc.code,
                    "reason": (f"the fire log could not be read, so the latest fire's status is "
                               f"unknown and run now cannot be gated on it: {exc.reason}")}
    if latest is not None:
        latest["resolution"] = await _adb(_db().get_clockwork_fire_resolution, latest["fire_key"])
    outstanding = await _adb(_db().outstanding_clockwork_manual_request, int(job["id"]))
    allowed, reason = run_now_verdict(job, latest, outstanding)
    return {"allowed": allowed, "reason": reason, "code": None}


async def _refuse_unless_arbitrated() -> None:
    """The fire routes write a request only when the constraint that makes
    it the ONLY outstanding one exists (``dispatch_views.manual_arbiter``,
    read from the catalogue).  Absent, 424 with the reason: a request
    nothing arbitrates would be written as if it were, and the second
    press would run the job twice."""
    arbiter = await _adb(_dv.manual_arbiter, _db().engine)
    if not arbiter["present"]:
        raise HTTPException(status_code=424, detail={
            "code": "manual_arbiter_missing",
            "reason": f"manual requests cannot be arbitrated: {arbiter['reason']}"})


def _http_from_outstanding(exc: Exception) -> HTTPException:
    return HTTPException(status_code=409, detail=f"run now is refused: {exc}")


async def _refuse_unless_fireable(job: dict) -> None:
    state = await _run_now_state(job)
    if state["allowed"]:
        return
    if state["code"]:
        raise HTTPException(status_code=424, detail={"reason": state["reason"], "code": state["code"]})
    raise HTTPException(status_code=409, detail=f"run now is refused: {state['reason']}")


@router.post("/jobs/{job_id}/fire", status_code=202)
async def fire_now(job_id: int, request: Request, user: dict = Depends(_clockwork_user)):
    """A manual fire is a REQUEST ROW under its own key.  QueryStudio never
    executes the job; the Clockwork deployment claims the request."""
    job = await _visible_job(job_id, user)
    if not _can_fire(job, user):
        raise HTTPException(status_code=403, detail="You may view this job but not fire it")
    problems = await _adb(_validate, definition_of(job), user, for_enable=True)
    if problems:
        _refuse(problems)
    # THE DISPATCHER'S OWN VERDICT, before the request exists: a request the
    # dispatcher would refuse must not be written as if it could fire.  The
    # projection is SNAPSHOTTED onto the request (the definition the person
    # saw when they pressed the button); the job's cron and authority are
    # read live by the dispatch view.
    projection = await _adb(_dispatch_projection, definition_of(job))
    # THE RUN-NOW GATE (enabled, outstanding request, latest fire) comes
    # AFTER the verdicts on the definition: what is wrong with the JOB is
    # the more useful answer, and "enable it first" would send the person
    # to a button that refuses for the reason they should have been told
    # here.
    await _refuse_unless_fireable(job)
    await _refuse_unless_arbitrated()
    now = _now()
    tenant = job.get("tenant") or TENANT_DEFAULT
    scope = f"manual:{secrets.token_hex(6)}"
    key = _ph.fire_key_for(tenant, job["id"], scope, now)
    try:
        row = await _adb(_db().create_clockwork_manual_request, {
            "job_id": int(job_id), "kind": "run_now", "fire_key": key, "job_version": job["version"],
            "tenant": tenant, "scope": scope, "definition": projection.definition,
            "requested_by": _username(user), "requested_at": now, "status": "PENDING",
            "reason": "run now",
        })
    except ClockworkRequestOutstanding as exc:
        # THE CONSTRAINT SPOKE: a second request landed between the verdict
        # above and this INSERT (two operators, a retry after a slow 202,
        # curl).  The index picked the winner; this one lost.
        raise _http_from_outstanding(exc)
    await _adb(_db().audit, _username(user), "clockwork_job_fire", resource_type="clockwork_job",
               resource_id=str(job_id), details={"fire_key": key})
    return {"fire_key": key, "request_id": row["id"], "status": "PENDING",
            "note": ("queued as a manual request; the Clockwork deployment with authority "
                     f"{job.get('authority')!r} claims it on its next tick, or marks it "
                     "REFUSED / EXPIRED with the reason")}


@router.get("/jobs/{job_id}/fires")
async def list_fires(job_id: int, limit: int = Query(50, ge=1, le=500), offset: int = Query(0, ge=0),
                     user: dict = Depends(_clockwork_user)):
    job = await _visible_job(job_id, user)
    try:
        fires, total = await _adb(_fl.list_fires, _db().engine, job.get("tenant") or TENANT_DEFAULT,
                                  job["id"], limit=limit, offset=offset)
    except _fl.FireLogUnavailable as exc:
        raise HTTPException(status_code=424, detail={"reason": exc.reason, "code": exc.code})
    res = await _adb(_db().list_clockwork_fire_resolutions, [f["fire_key"] for f in fires])
    for f in fires:
        f["resolution"] = res.get(f["fire_key"])
    return {"job_id": job["id"], "fires": fires, "total": total}


@router.get("/jobs/{job_id}/why-not-run")
async def why_not_run(job_id: int, at: Optional[str] = Query(None),
                      user: dict = Depends(_clockwork_user)):
    job = await _visible_job(job_id, user)
    db = _db()
    now = _now()
    if at:
        try:
            now = datetime.fromisoformat(at.replace("Z", "+00:00"))
            if now.tzinfo is None:
                now = now.replace(tzinfo=timezone.utc)
        except ValueError:
            raise HTTPException(status_code=400, detail="at must be an ISO-8601 timestamp")
    expected, key, expected_problem = await _adb(_expected_occurrence, job, now)
    fire_row, reason = None, ""
    if expected is not None:
        try:
            fire_row = await _adb(_fl.get_fire, db.engine, key)
        except _fl.FireLogUnavailable as exc:
            reason = exc.reason
    deployments = await _adb(db.list_clockwork_deployments)
    alerts = await _adb(db.list_clockwork_alerts, job_id=int(job_id), unacknowledged_only=True,
                        include_global=False)
    return _explain.explain(job, now=now, fire_row=fire_row, fire_log_reason=reason,
                            deployments=deployments, alerts=alerts, expected_at=expected,
                            expected_key=key, expected_problem=expected_problem)


def _next_occurrence(job: dict, now: datetime) -> tuple:
    """``(next due instant as ISO text, reason)`` for the list, through the
    CORE -- the one parser that knows ``wd N HH:MM``.  The cron-only
    backend reading is the fallback only when the core is absent; before
    2026-09-10 the list used it for every job, so a healthy working-day
    job listed as "none computed" (``CroniterBadCronError``, swallowed).
    Exactly one of the pair is set: no instant without a reason."""
    tz = job.get("timezone") or "UTC"
    expression = str(job.get("cron") or "")
    try:
        core = _core.load_core()
    except _core.CoreUnavailable as exc:
        try:
            return _ph.next_occurrences(expression, tz, now, 1)[0].isoformat(), None
        except Exception as fallback:                            # noqa: BLE001
            return None, f"the core is unavailable ({exc.reason}) and the cron-only reading refused: {fallback}"
    try:
        schedule = core.schedule.parse_schedule(expression)
    except core.schedule.ScheduleError as exc:
        return None, str(exc)
    cal, problem = _core_calendar(core, definition_of(job))
    if problem and schedule.kind != "cron":
        return None, problem
    try:
        instants = core.schedule.next_occurrences(schedule, now, tz, cal, 1)
    except (core.schedule.ScheduleError, core.calendar.CalendarError, ValueError) as exc:
        return None, str(exc)
    if not instants:
        return None, "the schedule yields no further occurrence"
    return instants[0].due.isoformat(), None


def _expected_occurrence(job: dict, now: datetime) -> tuple:
    """``(due instant, fire key, problem)`` of the most recent occurrence,
    through the CORE -- the key a working-day schedule carries is the month
    anchor, not the due instant, and only the core's parser knows that.
    Without the core, a cron expression is evaluated by the backend's own
    cron-only reading and a working-day expression yields nothing (the
    verdict then says REFUSED with the core's absence as the reason).

    Exactly one of ``(instant, key)`` or ``problem`` is set.  The problem
    is the core's OWN reason (2026-09-15: ``0 0 31 2 *`` -- "day 31 does
    not exist in February"); before, it was dropped here and the verdict
    fell back to a cron-only reading whose ``CroniterBadDateError`` reached
    the client as a bare class name."""
    tenant = job.get("tenant") or TENANT_DEFAULT
    tz = job.get("timezone") or "UTC"
    try:
        core = _core.load_core()
    except _core.CoreUnavailable as unavailable:
        try:
            expected = _ph.most_recent_occurrence(job["cron"], tz, now)
        except Exception as fallback:                           # noqa: BLE001
            return None, None, (f"the core is unavailable ({unavailable.reason}) and the "
                                f"cron-only reading refused: {type(fallback).__name__}: "
                                f"{fallback}")
        return expected, _ph.fire_key_for(tenant, job["id"], NO_SCOPE, expected), ""
    cal, _problem = _core_calendar(core, definition_of(job))
    try:
        occ = core.occurrence.build_occurrence(tenant, job["id"], job["cron"], None, now=now,
                                               tz_name=tz, calendar=cal)
    except core.occurrence.OccurrenceError as exc:
        return None, None, str(exc)
    return occ.scheduled_fire, occ.fire_key, ""


@router.get("/jobs/{job_id}/versions")
async def list_versions(job_id: int, user: dict = Depends(_clockwork_user)):
    job = await _visible_job(job_id, user)
    return {"job_id": job["id"], "versions": await _adb(_db().list_clockwork_job_versions, int(job_id))}


@router.get("/jobs/{job_id}/requests")
async def list_requests(job_id: int, user: dict = Depends(_clockwork_user)):
    job = await _visible_job(job_id, user)
    return {"job_id": job["id"], "requests": await _adb(_db().list_clockwork_manual_requests,
                                                        job_id=int(job_id))}


@router.get("/jobs/{job_id}/health")
async def job_health(job_id: int, user: dict = Depends(_clockwork_user)):
    job = await _visible_job(job_id, user)
    rows = await _adb(_db().list_clockwork_job_health, int(job_id))
    return {"job_id": job["id"], "health": _health_for(job["id"], rows), "probes": rows}


_SECRETS_REFUSAL = (
    "no secret lives on a job, by design (plan v2 §3.1): bind a connection whose system "
    "account maps the credential in Vault.  Nothing is stored and nothing can be read back."
)


@router.put("/jobs/{job_id}/secrets/{name}")
async def set_job_secret(job_id: int, name: str, body: dict, user: dict = Depends(_clockwork_user)):
    await _visible_job(job_id, user)
    raise HTTPException(status_code=400, detail=_SECRETS_REFUSAL)


@router.delete("/jobs/{job_id}/secrets/{name}")
async def delete_job_secret(job_id: int, name: str, user: dict = Depends(_clockwork_user)):
    await _visible_job(job_id, user)
    raise HTTPException(status_code=400, detail=_SECRETS_REFUSAL)


# ── Fires ──────────────────────────────────────────────────────────────


async def _fire_and_job(fire_key: str, user: dict) -> tuple:
    tenant, job_id, _scope_, _stamp = _parse_key(fire_key)
    try:
        job = await _visible_job(int(job_id), user)
    except ValueError:
        raise HTTPException(status_code=404, detail="Fire not found")
    try:
        fire = await _adb(_fl.get_fire, _db().engine, fire_key)
    except _fl.FireLogUnavailable as exc:
        raise HTTPException(status_code=424, detail={"reason": exc.reason, "code": exc.code})
    if fire is None:
        raise HTTPException(status_code=404, detail="Fire not found")
    return fire, job


@router.get("/fires/{fire_key}")
async def get_fire(fire_key: str, user: dict = Depends(_clockwork_user)):
    fire, _job = await _fire_and_job(fire_key, user)
    fire["resolution"] = await _adb(_db().get_clockwork_fire_resolution, fire_key)
    return fire


@router.post("/fires/{fire_key}/resume", status_code=202)
async def resume_fire(fire_key: str, body: dict, user: dict = Depends(_clockwork_user)):
    """'Resume from step N' is a NEW manual occurrence carrying the parent's
    key.  Refused unless the job DECLARES idempotent = true — NULL is
    unknown, and unknown is unsafe."""
    fire, job = await _fire_and_job(fire_key, user)
    if not _can_fire(job, user):
        raise HTTPException(status_code=403, detail="You may view this job but not fire it")
    if job.get("idempotent") is not True:
        raise HTTPException(status_code=409, detail=(
            "re-drive is disabled: the job does not declare idempotent = true "
            + ("(it is declared NOT idempotent)" if job.get("idempotent") is False
               else "(idempotency was never declared, and unknown is unsafe)")))
    if str(fire.get("status") or "").upper() == "CLAIMED":
        # 2026-09-11: a recorded resolution lifts this, as it lifts run now.
        if not await _adb(_db().get_clockwork_fire_resolution, fire_key):
            raise HTTPException(status_code=409, detail=(
                "the parent fire is still CLAIMED; resolve it first -- an admin records a "
                "resolution on it, which retires its request and lifts this refusal"))
    steps = job.get("steps") or []
    fs = (body or {}).get("from_step") if isinstance(body, dict) else None
    if not isinstance(fs, int) or isinstance(fs, bool) or fs < 1 or fs > len(steps):
        raise HTTPException(status_code=400, detail=f"from_step must be an integer from 1 to {len(steps)}")
    problems = await _adb(_validate, definition_of(job), user, for_enable=True)
    if problems:
        _refuse(problems)
    projection = await _adb(_dispatch_projection, definition_of(job))
    # A resume is a manual request like any other: one outstanding per job.
    outstanding = await _adb(_db().outstanding_clockwork_manual_request, int(job["id"]))
    if outstanding:
        raise _http_from_outstanding(ClockworkRequestOutstanding(int(job["id"]), outstanding))
    await _refuse_unless_arbitrated()
    now = _now()
    tenant = job.get("tenant") or TENANT_DEFAULT
    scope = f"resume:{secrets.token_hex(6)}"
    key = _ph.fire_key_for(tenant, job["id"], scope, now)
    try:
        row = await _adb(_db().create_clockwork_manual_request, {
            "job_id": int(job["id"]), "kind": "resume", "fire_key": key, "parent_fire_key": fire_key,
            "tenant": tenant, "scope": scope, "definition": projection.definition,
            "from_step": fs, "job_version": job["version"], "requested_by": _username(user),
            "requested_at": now, "status": "PENDING",
            "reason": f"resume from step {fs} of {fire_key}",
        })
    except ClockworkRequestOutstanding as exc:
        raise _http_from_outstanding(exc)
    await _adb(_db().audit, _username(user), "clockwork_fire_resume", resource_type="clockwork_job",
               resource_id=str(job["id"]), details={"fire_key": key, "parent": fire_key, "from_step": fs})
    return {"fire_key": key, "request_id": row["id"], "status": "PENDING", "parent_fire_key": fire_key}


@router.post("/fires/{fire_key}/resolution")
async def record_resolution(fire_key: str, body: dict, user: dict = Depends(_clockwork_user)):
    """Records a human's resolution beside a stuck row.  NEVER rewrites the
    fire log's status — that column is Clockwork's."""
    fire, job = await _fire_and_job(fire_key, user)
    if not _can_fire(job, user):
        raise HTTPException(status_code=403, detail="You may view this job but not resolve its fires")
    verdict = (body or {}).get("verdict") if isinstance(body, dict) else None
    note = (body or {}).get("note", "") if isinstance(body, dict) else ""
    if verdict not in _RESOLUTION_VERDICTS:
        raise HTTPException(status_code=400, detail=f"verdict must be one of {', '.join(_RESOLUTION_VERDICTS)}")
    if not isinstance(note, str) or len(note) > 2000:
        raise HTTPException(status_code=400, detail="note must be text of at most 2000 characters")
    status = str(fire.get("status") or "").upper()
    if status not in ("CLAIMED", "UNKNOWN", "FAILED"):
        raise HTTPException(status_code=409, detail=(
            f"a resolution is recorded on a CLAIMED, UNKNOWN or FAILED fire; this one is {fire.get('status')}"))
    claimed = status == "CLAIMED"
    if claimed:
        # 2026-09-11 (audit remainder, item 1).  A CLAIMED fire is a pod
        # that is still running, or one that died mid-fire.  Resolving it
        # asserts that an occurrence which MAY HAVE RUN is finished, and
        # it lifts the run-now refusal and retires the CLAIMED request
        # that holds the job's slot -- so it is a deliberate, audited,
        # ADMIN-ONLY act with a reason.  Never a sweep; never silent.
        if not is_admin_like(user):
            raise HTTPException(status_code=403, detail=(
                "resolving a CLAIMED fire asserts that an occurrence which may have run is "
                "finished, retires its request and lifts the run-now refusal; that is an "
                "admin's act -- ask an admin to record it (an UNKNOWN or FAILED fire you may "
                "resolve yourself)"))
        if not note.strip():
            raise HTTPException(status_code=400, detail=(
                "a resolution on a CLAIMED fire needs a note saying what you checked at the "
                "target and why the occurrence is finished (the pod is gone, the target shows "
                "the run complete, ...)"))
    res = await _adb(_db().record_clockwork_fire_resolution, fire_key, job_id=int(job["id"]),
                     verdict=verdict, note=note, resolved_by=_username(user),
                     retire_claimed_request=claimed)
    retired = res.pop("retired_request", None)
    await _adb(_db().audit, _username(user), "clockwork_fire_resolution", resource_type="clockwork_job",
               resource_id=str(job["id"]),
               details={"fire_key": fire_key, "verdict": verdict, "fire_status": status,
                        "retired_request_id": None if retired is None else retired.get("id"),
                        "lifts_run_now": claimed})
    fire["resolution"] = res
    fire["retired_request"] = retired
    return fire


# ── Alerts / deployments / health ──────────────────────────────────────


@router.get("/alerts")
async def list_alerts(job_id: Optional[int] = Query(None), unacknowledged: bool = Query(False),
                      user: dict = Depends(_clockwork_user)):
    db = _db()
    if job_id is not None:
        await _visible_job(job_id, user)
        rows = await _adb(db.list_clockwork_alerts, job_id=int(job_id), unacknowledged_only=unacknowledged,
                          include_global=is_admin_like(user) or is_support(user))
        return {"alerts": await _adb(_with_notifications, db, rows)}
    rows = await _adb(db.list_clockwork_alerts, unacknowledged_only=unacknowledged)
    if not (is_admin_like(user) or is_support(user)):
        visible = {j["id"] for j in await _adb(db.list_clockwork_jobs) if _can_view(j, user)}
        rows = [a for a in rows if a.get("job_id") in visible]
    return {"alerts": await _adb(_with_notifications, db, rows)}


def _with_notifications(db: Any, alerts: List[dict]) -> List[dict]:
    """Each alert carries what the notifier did about it (``notification``:
    the ledger row, or None when the notifier has not seen it yet) -- so the
    page can say WHO was told, or that nobody was (``status: unrouted``).
    A ledger read failure leaves the alerts intact with ``notification``
    stated as unreadable, never a 500 on the alerts page."""
    try:
        ledger = {int(r["alert_id"]): r for r in
                  db.list_clockwork_alert_notifications(alert_ids=[int(a["id"]) for a in alerts])}
    except Exception as exc:  # noqa: BLE001
        logger.warning("[clockwork.notify] ledger unreadable for the alerts list: %s", exc)
        return [{**a, "notification": {"status": "unreadable", "error": str(exc)[:200]}} for a in alerts]
    return [{**a, "notification": ledger.get(int(a["id"]))} for a in alerts]


@router.post("/alerts/{alert_id}/ack")
async def ack_alert(alert_id: int, user: dict = Depends(_clockwork_user)):
    db = _db()
    rows = [a for a in await _adb(db.list_clockwork_alerts) if int(a["id"]) == int(alert_id)]
    if not rows:
        raise HTTPException(status_code=404, detail="Alert not found")
    a = rows[0]
    if a.get("job_id") is None:
        if not is_admin_like(user):
            raise HTTPException(status_code=404, detail="Alert not found")
    else:
        job = await _visible_job(int(a["job_id"]), user)
        if not _can_edit(job, user):
            raise HTTPException(status_code=403, detail="You may view this alert but not acknowledge it")
    return await _adb(db.acknowledge_clockwork_alert, int(alert_id), by=_username(user))


@router.get("/deployments")
async def list_deployments(user: dict = Depends(_clockwork_user)):
    return {"deployments": await _adb(_db().list_clockwork_deployments)}


@router.get("/health")
async def clockwork_health(user: dict = Depends(_clockwork_user)):
    db = _db()
    deployments = await _adb(db.list_clockwork_deployments)
    rows = await _adb(db.list_clockwork_job_health)
    jobs = [j for j in await _adb(db.list_clockwork_jobs) if _can_view(j, user)]
    avail = await _adb(_fl.availability, db.engine)
    now = _now()
    stale = []
    for d in deployments:
        try:
            lt = datetime.fromisoformat(str(d.get("last_tick_at")).replace("Z", "+00:00")) if d.get("last_tick_at") else None
            if lt and lt.tzinfo is None:
                lt = lt.replace(tzinfo=timezone.utc)
        except ValueError:
            lt = None
        d["seconds_since_tick"] = (now - lt).total_seconds() if lt else None
        if lt is None or (now - lt).total_seconds() > 300:
            stale.append(d["deployment_id"])
    return {
        "deployments": deployments, "stale_deployments": stale,
        "jobs": [{"job_id": j["id"], "name": j["name"], "enabled": bool(j.get("enabled")),
                  "authority": j.get("authority"), "dispatchable": bool(j.get("dispatchable")),
                  "health": _health_for(j["id"], rows)} for j in jobs],
        "fire_log": avail,
        # The two halves of the seam to the dispatcher, each stated: the
        # projection views it reads, and the core package whose validator
        # every enabled job passed through.
        "dispatch": await _adb(_dv.availability, db.engine),
        # 2026-09-11 -- the constraint behind "one outstanding manual
        # request per job"; absent, the fire routes answer 424.
        "manual_arbiter": await _adb(_dv.manual_arbiter, db.engine),
        "core": await _adb(_core.core_status),
        # Whether anyone is TOLD: the notifier's ledger by status.  An
        # ``unrouted`` count above zero is an alert that reached nobody.
        "alert_notifier": await _adb(_notifier_status, db),
    }


def _notifier_status(db: Any) -> dict:
    from core.clockwork import notifier as _nf
    try:
        settings = _nf.Settings.from_config()
        summary = db.clockwork_alert_notifier_summary()
    except Exception as exc:  # noqa: BLE001 - health must answer
        return {"available": False, "reason": f"{type(exc).__name__}: {exc}"[:300]}
    return {"available": True, "enabled": settings.enabled, "poll_seconds": settings.poll_seconds,
            "fallback_configured": bool(settings.fallback_emails or settings.fallback_usernames),
            "daemon": _nf.DAEMON_NAME, **summary}


# ── Schema state, and the manual way out (2026-09-11)
#
# Everything here is automated: the API start applies the Clockwork-owned
# DDL (``core/clockwork/schema_admin.ensure_schema``) the way it makes the
# dispatch views.  These routes exist for when it could NOT -- no privilege,
# a shape that conflicts, a dialect Clockwork ships no DDL for -- and for
# the operator who wants to see, before anything runs, exactly what would be
# executed.  Admin-only: the answer carries DDL and the shape of the claim
# table.


@router.get("/schema")
async def get_schema(user: dict = Depends(require_admin)):
    """What the database actually has, read from its catalogue.

    ``scripts`` is every Clockwork-owned DDL file in its declared apply
    order, each with a status (``satisfied`` / ``missing`` / ``conflict`` /
    ``manual`` / ``unknown`` -- "cannot tell" is deliberately not "not
    present"), the reason, the EXACT SQL, and the ``psql`` command for doing
    it by hand without this API.  ``views`` and ``manual_arbiter`` are the
    two pieces of QueryStudio-owned projection that live in the same place,
    and ``history`` is the ledger of what was applied here."""
    db = _db()
    return {
        "schema": await _adb(_sa.plan, db.engine),
        "views": await _adb(_dv.availability, db.engine),
        "views_ddl": _dv.ddl_text(),
        "manual_arbiter": await _adb(_dv.manual_arbiter, db.engine),
        "manual_arbiter_ddl": _dv.MANUAL_ARBITER_DDL,
        "fire_log": await _adb(_fl.availability, db.engine),
        "core": await _adb(_core.core_status),
        "history": await _adb(db.list_clockwork_schema_migrations, 200),
    }


@router.post("/schema/apply")
async def apply_schema(body: Optional[dict] = None, user: dict = Depends(require_admin)):
    """Apply Clockwork-owned DDL that is missing, in manifest order.

    ``{"script_ids": [...]}`` narrows it; omitted means "everything the
    manifest declares".  Never destructive, never a DROP, and a script whose
    postcondition already holds is skipped rather than re-run.  The result
    carries one outcome per script with the reason verbatim -- the same
    words the startup log uses."""
    payload = body if isinstance(body, dict) else {}
    ids = payload.get("script_ids")
    if ids is not None and (not isinstance(ids, list)
                            or not all(isinstance(i, str) and i for i in ids)):
        raise HTTPException(status_code=400,
                            detail="script_ids must be a list of script ids, or absent")
    db = _db()
    outcome = await _adb(_sa.apply, db.engine, ids, _username(user) or "admin",
                         db.record_clockwork_schema_migration)
    return {"result": outcome, "schema": await _adb(_sa.plan, db.engine)}


@router.post("/schema/views")
async def apply_schema_views(user: dict = Depends(require_admin)):
    """Re-run the QueryStudio-owned half: the two dispatch views, the
    per-dialect credentials view and the manual-request arbiter index.  The
    API start does this too; this is the button for when that failed."""
    db = _db()
    outcome = await _adb(_dv.ensure_views, db.engine)
    return {"result": outcome,
            "views": await _adb(_dv.availability, db.engine),
            "manual_arbiter": await _adb(_dv.manual_arbiter, db.engine)}


# ── Settings ───────────────────────────────────────────────────────────


@router.get("/settings")
async def get_settings(user: dict = Depends(_clockwork_user)):
    stored = {r["key"]: r for r in await _adb(_db().list_clockwork_settings)}
    declared = {k for k, _d, _doc in SETTINGS_DECLARED}
    out = []
    for k, default, doc in SETTINGS_DECLARED:
        r = stored.get(k)
        out.append({"key": k, "value": r["value"] if r else default, "default": default,
                    "description": doc, "updated_by": r["updated_by"] if r else None,
                    "updated_at": r["updated_at"] if r else None, "is_default": r is None})
    # A row the core does not declare would REFUSE the pod's start by name.
    # Such rows cannot be written through this API any more, but one left
    # by an earlier build must be visible, not silently skipped.
    stray = sorted(k for k in stored if k not in declared)
    return {"settings": out, "note": SETTINGS_NOTE,
            "undeclared_rows": stray,
            "undeclared_note": ("these rows are NOT declared by the Clockwork core and will "
                                "refuse its start by name; delete them" if stray else "")}


def _validate_setting(core: Any, key: str, value: Any) -> List[dict]:
    """ONE key through the core's own schema: the same coercion and the same
    validators the pod applies at boot, so a value stored here is a value the
    pod will accept."""
    schema = core.settings_schema
    if key not in schema.names():
        return [{"path": key, "message": f"unknown setting; the Clockwork core declares: "
                                         f"{', '.join(schema.names())}"}]
    try:
        typed = core.coerce_text(schema, {key: value}, "clockwork.settings")
        schema.parse(typed)
    except (core.param_error, core.config_error) as exc:
        return [{"path": key, "message": str(exc)}]
    if isinstance(value, bool) or not isinstance(value, (int, str)):
        return [{"path": key, "message": "a setting value is text or an integer"}]
    return []


@router.put("/settings")
async def put_settings(body: dict, user: dict = Depends(require_admin)):
    if not isinstance(body, dict) or not body:
        raise HTTPException(status_code=400, detail="body must be {key: value, ...}")
    try:
        core = await _adb(_core.load_core)
    except _core.CoreUnavailable as exc:
        # A value the core has not validated must not be stored: the pod
        # refuses to start on one it does not accept.
        raise _core_unavailable(exc.reason)
    problems: List[dict] = []
    for k, v in body.items():
        problems.extend(_validate_setting(core, str(k), v))
    if problems:
        _refuse(problems)
    docs = {k: doc for k, _d, doc in SETTINGS_DECLARED}
    out = []
    for k, v in body.items():
        out.append(await _adb(_db().set_clockwork_setting, k, v, updated_by=_username(user),
                              description=docs.get(k)))
    await _adb(_db().audit, _username(user), "clockwork_settings_update", resource_type="clockwork_settings",
               details={"keys": list(body)})
    return {"updated": out, "note": SETTINGS_NOTE}


# ── Query templates ────────────────────────────────────────────────────


def _clean_template(body: dict, *, partial: bool) -> dict:
    if not isinstance(body, dict):
        raise HTTPException(status_code=400, detail="body must be a JSON object")
    _refuse_oversize(body, "query template")
    problems = []
    out: Dict[str, Any] = {}
    if "name" in body or not partial:
        n = body.get("name")
        if not isinstance(n, str) or not _TEMPLATE_NAME_RE.fullmatch(n):
            problems.append({"path": "name", "message": "name: letters, digits, '_' or '-', starting with a letter"})
        else:
            out["name"] = n
    if "description" in body:
        if body["description"] is not None and not isinstance(body["description"], str):
            problems.append({"path": "description", "message": "description must be text"})
        else:
            out["description"] = body["description"]
    if "connection_type" in body or not partial:
        ct = str(body.get("connection_type") or "").lower()
        if ct not in _TEMPLATE_CONNECTION_TYPES:
            problems.append({"path": "connection_type",
                             "message": f"connection_type must be one of {', '.join(_TEMPLATE_CONNECTION_TYPES)} "
                                        f"(the dispatcher runs a template on an Oracle session only)"})
        else:
            out["connection_type"] = ct
    if "sql_text" in body or not partial:
        s = body.get("sql_text")
        text = s.strip().rstrip(";").strip() if isinstance(s, str) else ""
        # The CORE's statement rules (core/clockwork/query_templates.py is
        # pinned equal): what the dispatcher refuses before the claim is
        # refused here at CREATE, under the same words.
        why = _qt.statement_problems(text) if isinstance(s, str) else ["sql_text must be text"]
        if why:
            problems.extend({"path": "sql_text", "message": w} for w in why)
        else:
            out["sql_text"] = text
            out["binds"] = _qt.bind_names_of(text)
    if "is_active" in body:
        if not isinstance(body["is_active"], bool):
            problems.append({"path": "is_active", "message": "is_active must be true or false"})
        else:
            out["is_active"] = body["is_active"]
    if "side_effect_free" in body:
        # 2026-09-11 (audit remainder, item 3): the author's declaration.
        # A bool, nothing coerced: "yes" is not a declaration.
        if not isinstance(body["side_effect_free"], bool):
            problems.append({"path": "side_effect_free",
                             "message": "side_effect_free must be true or false -- it is a declaration "
                                        "that the statement reaches no PL/SQL that writes"})
        else:
            out["side_effect_free"] = body["side_effect_free"]
    for k in body:
        if k not in ("name", "description", "connection_type", "sql_text", "is_active", "side_effect_free",
                     "binds", "id", "version", "created_by", "created_at", "updated_by", "updated_at"):
            problems.append({"path": k, "message": f"unknown field {k!r}"})
    if problems:
        _refuse(problems)
    return out


@router.get("/templates")
async def list_templates(user: dict = Depends(_clockwork_user)):
    return {"templates": await _adb(_db().list_clockwork_templates)}


@router.post("/templates", status_code=201)
async def create_template(body: dict, user: dict = Depends(require_admin)):
    data = _clean_template(body, partial=False)
    if any(t["name"] == data["name"] for t in await _adb(_db().list_clockwork_templates)):
        _refuse([{"path": "name", "message": f"a template named {data['name']!r} already exists"}])
    row = await _adb(_db().create_clockwork_template, data, created_by=_username(user))
    await _adb(_db().audit, _username(user), "clockwork_template_create", resource_type="clockwork_template",
               resource_id=str(row["id"]))
    return row


@router.get("/templates/{template_id}")
async def get_template(template_id: int, user: dict = Depends(_clockwork_user)):
    row = await _adb(_db().get_clockwork_template, int(template_id))
    if not row:
        raise HTTPException(status_code=404, detail="Template not found")
    return row


@router.put("/templates/{template_id}")
async def update_template(template_id: int, body: dict, user: dict = Depends(require_admin)):
    data = _clean_template(body, partial=True)
    row = await _adb(_db().update_clockwork_template, int(template_id), data, updated_by=_username(user))
    if not row:
        raise HTTPException(status_code=404, detail="Template not found")
    await _adb(_db().audit, _username(user), "clockwork_template_update", resource_type="clockwork_template",
               resource_id=str(template_id))
    return row


@router.delete("/templates/{template_id}")
async def delete_template(template_id: int, user: dict = Depends(require_admin)):
    """A template a job snapshots is not deletable (409, naming the jobs):
    the job's projection would go NULL on the next re-projection and the
    job would leave the dispatch view.  Retire it (``is_active: false``,
    which re-projects and alerts the bound jobs) or unbind the jobs first.
    The same rule as deleting a bound calendar (``feed_api``, 409)."""
    from core.db.mixin_clockwork import ClockworkTemplateInUse
    try:
        n = await _adb(_db().delete_clockwork_template, int(template_id))
    except ClockworkTemplateInUse as exc:
        raise HTTPException(status_code=409, detail={
            "reason": str(exc), "code": "template_in_use", "jobs": exc.jobs})
    if not n:
        raise HTTPException(status_code=404, detail="Template not found")
    await _adb(_db().audit, _username(user), "clockwork_template_delete", resource_type="clockwork_template",
               resource_id=str(template_id))
    return {"deleted": int(n)}
