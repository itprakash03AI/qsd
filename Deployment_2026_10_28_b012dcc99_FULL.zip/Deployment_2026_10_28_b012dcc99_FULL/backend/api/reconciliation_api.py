"""Reconciliation API (Phase 133).

CRUD for ReconciliationEntity rows, on-demand check + reload, dashboard
summary, run history.  Every endpoint is auth-gated; create / update /
delete require admin-or-author.  The 2-hour background scheduler lives
in :mod:`core.reconciliation_scheduler` and reuses the same runner the
on-demand endpoints call.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from api.deps import get_current_user
from core.db_async import adb
from core.reconciliation import run_check, trigger_reload

logger = logging.getLogger(__name__)
router = APIRouter(tags=["reconciliation"])

# Module-level deps — set at startup by set_reconciliation_dependencies().
_db_manager = None
_broadcast_fn = None


def set_reconciliation_dependencies(db_manager, broadcast_fn=None):
    global _db_manager, _broadcast_fn
    _db_manager = db_manager
    _broadcast_fn = broadcast_fn


def _ensure_ready() -> None:
    if _db_manager is None:
        raise HTTPException(503, "Reconciliation service not initialised")


# ── Pydantic models ─────────────────────────────────────────────────


class _ReconciliationCommon(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    source_connection_id: int
    dest_connection_id:   int
    etl_connection_id:    Optional[int] = None
    # Recon-report SQL — three shapes (precedence in this order):
    #   1. sql_file_id — pointer to a SqlFile row.  Content is loaded
    #      from disk at run time; honours PRIMARY / SECONDARY markers
    #      so one .sql file can carry dialect-specific halves.
    #   2. query — inline single SQL used on both sides.
    #   3. source_query + dest_query — used when dialects differ.
    sql_file_id:  Optional[int] = None
    # Phase 133-F UX — independent .sql file per side (higher precedence
    # than sql_file_id).
    source_sql_file_id: Optional[int] = None
    dest_sql_file_id:   Optional[int] = None
    query:        Optional[str] = None
    source_query: Optional[str] = None
    dest_query:   Optional[str] = None
    comparison_mode:    str = Field(
        default="row_count",
        pattern="^(row_count|row_count_sum|row_by_row|checksum)$")
    comparison_columns: List[str] = Field(default_factory=list)
    key_columns:        List[str] = Field(default_factory=list)
    max_rows_compared:  int = Field(default=50000, ge=1, le=1000000)
    tolerance:        float = 0.0
    tolerance_pct:    float = 0.0
    dag_ids:          List[Any] = Field(default_factory=list)
    business_date_template:  str = "{{business_date}}"
    auto_reload_on_break:    bool = False
    reload_package_template: Optional[str] = None
    schedule_enabled:        bool = True
    check_interval_hours:    int = Field(default=2, ge=1, le=168)
    # Phase 133-E — dynamic parameterize via WhereClauseMapping.  Each
    # row: {column, operator, value, mode} (mode = static | dynamic).
    # See core.where_clause_mapping for the shared contract.
    where_clauses_mapping: Optional[List[Dict[str, Any]]] = None


class ReconciliationCreate(_ReconciliationCommon):
    is_active: bool = True

    def model_post_init(self, __context):
        # At least ONE of the four SQL shapes must be present.
        has_file = self.sql_file_id is not None
        has_two_files = (self.source_sql_file_id is not None
                         and self.dest_sql_file_id is not None)
        has_one  = bool((self.query or "").strip())
        has_pair = (bool((self.source_query or "").strip())
                     and bool((self.dest_query or "").strip()))
        if not (has_file or has_two_files or has_one or has_pair):
            raise ValueError(
                "must supply `sql_file_id`, BOTH `source_sql_file_id` "
                "and `dest_sql_file_id`, `query`, OR both "
                "`source_query` and `dest_query`"
            )


class ReconciliationUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    is_active: Optional[bool] = None
    source_connection_id: Optional[int] = None
    dest_connection_id:   Optional[int] = None
    etl_connection_id:    Optional[int] = None
    sql_file_id:  Optional[int] = None
    source_sql_file_id: Optional[int] = None
    dest_sql_file_id:   Optional[int] = None
    query:        Optional[str] = None
    source_query: Optional[str] = None
    dest_query:   Optional[str] = None
    comparison_mode:    Optional[str] = Field(
        None, pattern="^(row_count|row_count_sum|row_by_row|checksum)$")
    comparison_columns: Optional[List[str]] = None
    key_columns:        Optional[List[str]] = None
    max_rows_compared:  Optional[int] = Field(None, ge=1, le=1000000)
    tolerance:        Optional[float] = None
    tolerance_pct:    Optional[float] = None
    dag_ids:          Optional[List[Any]] = None
    business_date_template:  Optional[str] = None
    auto_reload_on_break:    Optional[bool] = None
    reload_package_template: Optional[str] = None
    schedule_enabled:        Optional[bool] = None
    check_interval_hours:    Optional[int] = Field(None, ge=1, le=168)
    where_clauses_mapping:   Optional[List[Dict[str, Any]]] = None


class CheckRequest(BaseModel):
    business_date: Optional[str] = Field(
        None, description="YYYY-MM-DD override (else resolved from template)",
    )
    # Phase 133-E — per-trigger consumer overrides for Dynamic rows on
    # the entity's ``where_clauses_mapping``.  Keyed by column name;
    # values replace the publisher's Dynamic default for THIS run only.
    # Static rows always apply and cannot be overridden here.
    query_param_overrides: Optional[Dict[str, Any]] = Field(
        None,
        description="Per-trigger overrides for Dynamic where-clause rows. "
                    "Keyed by column name.  Static rows ignore this.",
    )


class ReloadRequest(BaseModel):
    business_date: Optional[str] = None


# ── Endpoints ───────────────────────────────────────────────────────


def _require_operator_role(user: Optional[dict]) -> None:
    """Phase 4 (2026-08-23): reconciliation executes arbitrary SQL (and,
    via reload, arbitrary PL/SQL) with STORED connection credentials.  The
    /reconciliation route is admin/analyst in the UI, but that RoleGuard is
    client-side only -- the API accepted any authenticated user."""
    from core.roles import is_admin_like
    role = (user or {}).get("role", "viewer")
    if is_admin_like(user) or role in ("admin", "analyst", "super_admin"):
        return
    raise HTTPException(403, "Requires role: admin or analyst")


async def _require_visible_connections(user: Optional[dict], *conn_ids) -> None:
    """Phase 4 (2026-08-23): SECURITY.  create/check/reload accepted ANY
    connection id with no visibility check -- any authenticated user could
    point an entity at another user's private connection and run arbitrary
    SQL through its stored credentials (row DATA comes back in row_by_row
    examples, not just counts), and reload ran an arbitrary PL/SQL block on
    any etl_connection_id.  This is the same hole connections_api closed on
    2026-08-17; reconciliation never received the guard.  ONE chokepoint:
    delegate to connections_api._require_connection_access (404 on
    invisible, same non-oracle semantics)."""
    from api.connections_api import _require_connection_access
    for cid in conn_ids:
        if cid:
            await _require_connection_access(int(cid), user)


@router.get("/api/reconciliation/dashboard")
async def get_dashboard(user: dict = Depends(get_current_user)):
    """Summary panel for the dashboard tab."""
    _ensure_ready()
    return await adb(_db_manager.get_reconciliation_dashboard)


@router.get("/api/reconciliation/entities")
async def list_entities(
    is_active: Optional[bool] = Query(None),
    status:    Optional[str]  = Query(None),
    user:      dict           = Depends(get_current_user),
):
    """List reconciliation entities, optionally filtered.

    Each carries ``runnable_by_you``: whether THIS caller may run it, by the
    same guard ``check`` applies (``_require_visible_connections``).
    2026-09-25 (click crawl, as an analyst): "Check now" was offered on an
    entity over a connection not shared with them, and answered 404
    "Connection not found" -- the guard is right not to say more, so the
    page must know beforehand.  A guard that errors for another reason
    reads as runnable (the check itself will then say what is wrong)."""
    _ensure_ready()
    rows = await adb(_db_manager.list_reconciliation_entities,
                     is_active=is_active, status=status)
    out = []
    for e in rows or []:
        runnable = True
        try:
            await _require_visible_connections(
                user, e.get("source_connection_id"), e.get("dest_connection_id"))
        except HTTPException as exc:
            runnable = exc.status_code not in (403, 404)
        except Exception:
            runnable = True
        out.append({**e, "runnable_by_you": runnable})
    return out


@router.get("/api/reconciliation/entities/{entity_id}")
async def get_entity(entity_id: int, user: dict = Depends(get_current_user)):
    _ensure_ready()
    ent = await adb(_db_manager.get_reconciliation_entity, entity_id)
    if not ent:
        raise HTTPException(404, "Reconciliation entity not found")
    return ent


@router.post("/api/reconciliation/entities", status_code=201)
async def create_entity(body: ReconciliationCreate,
                         user: dict = Depends(get_current_user)):
    _ensure_ready()
    _require_operator_role(user)
    await _require_visible_connections(
        user, body.source_connection_id, body.dest_connection_id,
        body.etl_connection_id)
    # Slug-like uniqueness check.
    existing = await adb(_db_manager.get_reconciliation_entity_by_name,
                          body.name)
    if existing:
        raise HTTPException(
            409, f"Reconciliation entity {body.name!r} already exists",
        )
    data = body.model_dump()
    data["created_by"] = user.get("username", "unknown")
    return await adb(_db_manager.create_reconciliation_entity, data)


@router.put("/api/reconciliation/entities/{entity_id}")
async def update_entity(entity_id: int, body: ReconciliationUpdate,
                         user: dict = Depends(get_current_user)):
    _ensure_ready()
    ent = await adb(_db_manager.get_reconciliation_entity, entity_id)
    if not ent:
        raise HTTPException(404, "Reconciliation entity not found")
    # Owner-or-admin gate (mirrors Published Views).
    from core.roles import is_admin_like
    if ent.get("created_by") != user.get("username") and not is_admin_like(user):
        raise HTTPException(
            403, "Only the entity owner or an admin can update this entity",
        )
    _require_operator_role(user)
    payload = body.model_dump(exclude_none=True)
    if not payload:
        raise HTTPException(400, "No fields to update")
    await _require_visible_connections(
        user, payload.get("source_connection_id"),
        payload.get("dest_connection_id"),
        payload.get("etl_connection_id"))
    out = await adb(_db_manager.update_reconciliation_entity,
                     entity_id, payload)
    if not out:
        raise HTTPException(404, "Reconciliation entity not found")
    return out


@router.delete("/api/reconciliation/entities/{entity_id}")
async def deactivate_entity(entity_id: int,
                              user: dict = Depends(get_current_user)):
    _ensure_ready()
    ent = await adb(_db_manager.get_reconciliation_entity, entity_id)
    if not ent:
        raise HTTPException(404, "Reconciliation entity not found")
    from core.roles import is_admin_like
    if ent.get("created_by") != user.get("username") and not is_admin_like(user):
        raise HTTPException(403, "Owner or admin only")
    ok = await adb(_db_manager.deactivate_reconciliation_entity, entity_id)
    return {"deactivated": bool(ok), "id": entity_id}


@router.get("/api/reconciliation/entities/{entity_id}/runs")
async def list_runs(entity_id: int,
                     limit: int = Query(50, ge=1, le=500),
                     user: dict = Depends(get_current_user)):
    """Recent run history for one entity (newest first)."""
    _ensure_ready()
    return await adb(_db_manager.list_reconciliation_runs, entity_id, limit)


@router.post("/api/reconciliation/entities/{entity_id}/check")
async def check_now(entity_id: int,
                     body: Optional[CheckRequest] = None,
                     user: dict = Depends(get_current_user)):
    """Run the comparison now and return the freshly-created run row.

    The dashboard's "Check Now" button hits this endpoint.  Same code
    path the 2-hour scheduler uses, just with ``triggered_by='user'``.
    """
    _ensure_ready()
    _require_operator_role(user)
    entity = await adb(_db_manager.get_reconciliation_entity, entity_id)
    if not entity:
        raise HTTPException(404, "Reconciliation entity not found")
    await _require_visible_connections(
        user, entity.get("source_connection_id"),
        entity.get("dest_connection_id"))
    biz = (body.business_date if body else None)
    # Stash consumer overrides on the in-memory entity so the runner
    # picks them up via ``entity_dict["_consumer_overrides"]`` (same
    # channel the feed engine + dataflow engine use).  Reserved
    # sentinel keys are stripped via the shared deny-set so a caller
    # cannot smuggle a new mapping at runtime, regardless of which
    # spelling (with or without the leading underscore) they try.
    from core.where_clause_mapping import strip_reserved_override_keys
    overrides = strip_reserved_override_keys(
        body.query_param_overrides if body else None,
    )
    if overrides:
        entity["_consumer_overrides"] = overrides
    try:
        run_dict, break_flag = await asyncio.to_thread(
            run_check, entity, _db_manager,
            "user", user.get("username", "unknown"), biz, _broadcast_fn,
        )
    except Exception as exc:
        logger.exception(
            "[reconciliation-api] check_now failed entity=%s", entity_id,
        )
        raise HTTPException(500, f"Reconciliation check failed: {exc}")
    return {"run": run_dict, "break_detected": bool(break_flag)}


@router.post("/api/reconciliation/entities/{entity_id}/reload")
async def reload_now(entity_id: int,
                      body: Optional[ReloadRequest] = None,
                      user: dict = Depends(get_current_user)):
    """Fire the Oracle reload PL/SQL package right now.  Admin / owner
    only — this kicks off an actual ETL rerun."""
    _ensure_ready()
    entity = await adb(_db_manager.get_reconciliation_entity, entity_id)
    if not entity:
        raise HTTPException(404, "Reconciliation entity not found")
    from core.roles import is_admin_like
    if entity.get("created_by") != user.get("username") and \
       not is_admin_like(user):
        raise HTTPException(
            403, "Only the entity owner or an admin can trigger reload",
        )
    _require_operator_role(user)
    await _require_visible_connections(
        user, entity.get("etl_connection_id"))
    biz = (body.business_date if body else None)
    try:
        result = await asyncio.to_thread(
            trigger_reload, entity, _db_manager, biz,
            user.get("username", "unknown"),
        )
    except Exception as exc:
        logger.exception(
            "[reconciliation-api] reload_now failed entity=%s", entity_id,
        )
        raise HTTPException(500, f"Reload failed: {exc}")
    return result
