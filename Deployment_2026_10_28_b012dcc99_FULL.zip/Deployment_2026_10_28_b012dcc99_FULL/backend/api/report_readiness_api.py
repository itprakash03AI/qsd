"""Business-date readiness and the SLO of a finance report (2026-09-28).

Thin HTTP shell over ``core.reports.readiness`` and ``core.reports.slo``:

* ``GET  /api/business-reports/{id}/readiness`` -- is the DATA for the
  business date complete?  The date is ``?business_date=`` when given, else
  the report's date parameter (``?p_<name>=`` values, else its default,
  through the one shortcut resolver so ``@PREV_BUSINESS_DAY:LDN`` renders or
  REFUSES), else today.  The report's VIEW rule.
* ``GET/PUT /api/business-reports/{id}/readiness/dependencies`` -- the
  declaration, in the feed dependency vocabulary (the same pydantic row,
  the same validators: the catalogue, the upstream calendar, expected rows,
  declared arrival sources).  PUT takes the EDIT rule.
* ``GET/PUT/DELETE /api/business-reports/{id}/slo`` -- the promise (a
  local time, an IANA zone, an optional business calendar), its live
  status for a date, and its breach ledger.  PUT REFUSES a promise on a
  report with no readiness dependencies: "fresh" cannot be measured on a
  report that declares what fresh means nowhere.

The gates are the report's own (``_br_can_view`` / ``_br_can_edit``): a
stranger gets the non-oracle 404, a viewer who may not edit gets 403.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import date, datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field

from api.deps import get_current_user
from api.feed_api import FeedDependencyRow
from core.db_async import adb

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/business-reports", tags=["report-readiness"])


# ── the report's own gates ─────────────────────────────────────────────────

def _db():
    from api.business_reports_api import _require_db
    return _require_db()


async def _require_view(report_id: int, user: dict) -> dict:
    from api.business_reports_api import _br_can_view
    db = _db()
    report = await adb(db.get_business_report, int(report_id))
    if not report or not _br_can_view(report, user):
        raise HTTPException(status_code=404, detail="Report not found")
    return report


async def _require_edit(report_id: int, user: dict) -> dict:
    from api.business_reports_api import _br_can_edit
    report = await _require_view(report_id, user)
    if not _br_can_edit(report, user):
        raise HTTPException(
            status_code=403,
            detail="Only the report owner, an admin or an editor can change "
                   "this report's readiness dependencies or its SLO")
    return report


def _parse_date(raw: Optional[str]) -> Optional[date]:
    if not raw:
        return None
    try:
        return date.fromisoformat(str(raw)[:10])
    except ValueError:
        raise HTTPException(
            status_code=422,
            detail=f"business_date {raw!r} is not an ISO date (YYYY-MM-DD)")


def _p_params(request: Request) -> Dict[str, Any]:
    """``?p_<name>=<value>`` -- the report parameter values the viewer is
    showing, so readiness is asked about the date on screen.  Both
    spellings are offered (``p_asof`` -> ``asof`` AND ``p_asof``), because
    a report's parameters are themselves often named ``p_...``; the date
    chooser reads only the name the report declares, so the extra key is
    inert."""
    out: Dict[str, Any] = {}
    for key, value in request.query_params.multi_items():
        if key.startswith("p_") and len(key) > 2:
            out[key[2:]] = value
            out[key] = value
    return out


# ── readiness ──────────────────────────────────────────────────────────────

@router.get("/{report_id}/readiness")
async def get_report_readiness(report_id: int, request: Request,
                               business_date: Optional[str] = Query(default=None),
                               user: dict = Depends(get_current_user)):
    """Whether the report's DATA for the business date is complete, from the
    same gate the feeds wait on.  Unknown is never complete."""
    from api.business_reports_api import _resolve_param_value
    from core.reports import readiness as _rd
    report = await _require_view(report_id, user)
    db = _db()
    explicit = _parse_date(business_date)
    if explicit is not None:
        result = await asyncio.to_thread(
            _rd.evaluate_readiness, db, report, explicit,
            choice=_rd.BusinessDateChoice(explicit, _rd.SOURCE_REQUEST, None))
    else:
        # ``_resolve_param_value`` raises CalendarTokenRefused (a ValueError)
        # for a token that cannot be rendered; main.py answers it with 400
        # and the reason -- no calendar is guessed here.
        result = await asyncio.to_thread(
            _rd.readiness_for_run, db, report, _p_params(request),
            resolve=_resolve_param_value)
    return result.to_dict()


class ReportDependenciesReplace(BaseModel):
    """The declaration: which parameter is the business date, and the
    dependencies -- the SAME pydantic row the feed route takes (one
    vocabulary, one validator set)."""
    business_date_param: Optional[str] = Field(default=None, max_length=100)
    dependencies: List[FeedDependencyRow] = Field(default_factory=list)


def _dependencies_payload(db, report: dict) -> dict:
    rows = db.list_report_dependency_mappings(int(report["id"]), active_only=False)
    types = db.list_etl_dependency_types(None) or []
    by_id = {int(t["id"]): t for t in types}
    for r in rows:
        t = by_id.get(int(r.get("dependency_type_id") or 0))
        if t:
            r["dependency_type"] = t["dependency_type"]
    subject = db.get_report_readiness_subject(int(report["id"])) or {}
    params = db.list_report_parameters(int(report["id"])) or []
    return {
        "report_id": int(report["id"]),
        "business_date_param": subject.get("business_date_param"),
        "items": rows,
        "available_types": types,
        "parameters": [{"name": p.get("name"), "label": p.get("label"),
                        "parameter_type": p.get("parameter_type"),
                        "default_value": p.get("default_value")}
                       for p in params],
        "date_parameters": [p.get("name") for p in params
                            if str(p.get("parameter_type") or "") in ("date", "date_range")],
    }


@router.get("/{report_id}/readiness/dependencies")
async def list_report_readiness_dependencies(report_id: int,
                                             user: dict = Depends(get_current_user)):
    report = await _require_view(report_id, user)
    return await adb(_dependencies_payload, _db(), report)


@router.put("/{report_id}/readiness/dependencies")
async def replace_report_readiness_dependencies(
        report_id: int, body: ReportDependenciesReplace,
        user: dict = Depends(get_current_user)):
    """Atomic bulk replace, validated BEFORE anything is written with the
    feed route's own checks (a typo here is a report that reads COULD NOT
    TELL every morning for ever)."""
    from api import feed_api as _fa
    report = await _require_edit(report_id, user)
    db = _db()
    types = await adb(db.list_etl_dependency_types, None)
    valid_type_ids = {int(t["id"]) for t in (types or [])}
    seen: set = set()
    for row in body.dependencies:
        if int(row.dependency_type_id) not in valid_type_ids:
            raise HTTPException(
                status_code=400,
                detail=f"dependency_type_id={row.dependency_type_id} is not in "
                       f"the catalogue (GET /api/feed-dependency-types)")
        key = row.dependency_key.strip()
        if not key:
            raise HTTPException(status_code=400, detail="dependency_key cannot be empty")
        if (int(row.dependency_type_id), key) in seen:
            raise HTTPException(status_code=400,
                                detail=f"dependency {key!r} is declared twice")
        seen.add((int(row.dependency_type_id), key))
        if row.expected_rows is not None and int(row.expected_rows) <= 0:
            raise HTTPException(
                status_code=400,
                detail=f"expected_rows={row.expected_rows} for {key!r} is not a "
                       f"row count. Leave it unset to mean NO CHECK.")
        await _fa._require_valid_calendar_name(row.calendar_name)
    if body.business_date_param:
        params = await adb(db.list_report_parameters, int(report["id"]))
        names = {str(p.get("name")) for p in (params or [])}
        if body.business_date_param not in names:
            raise HTTPException(
                status_code=400,
                detail=f"business_date_param {body.business_date_param!r} is not "
                       f"a parameter of this report. Parameters: "
                       f"{sorted(names) or 'none'}")
    declared = await _fa._validated_arrival_sources(body.dependencies, user)
    rows = []
    for idx, row in enumerate(body.dependencies):
        sources, mode = declared[idx]
        rows.append({
            "dependency_type_id": int(row.dependency_type_id),
            "dependency_key": row.dependency_key.strip(),
            "description": row.description or None,
            "calendar_name": row.calendar_name or None,
            "expected_rows": (int(row.expected_rows)
                              if row.expected_rows is not None else None),
            "arrival_sources": sources or None,
            "require_mode": (mode if sources else None),
            "is_active": bool(row.is_active),
        })
    await adb(db.replace_report_dependency_mappings, int(report["id"]), rows)
    await adb(db.upsert_report_readiness_subject, int(report["id"]),
              business_date_param=body.business_date_param,
              updated_by=(user or {}).get("username"))
    await _fa._watch_declared_iceberg_tables(declared)
    _fa._audit("report_readiness_dependencies_replaced", user, {
        "report_id": int(report["id"]), "count": len(rows),
        "business_date_param": body.business_date_param})
    return await adb(_dependencies_payload, db, report)


# ── the SLO ────────────────────────────────────────────────────────────────

class ReportSloUpsert(BaseModel):
    serve_by: str = Field(..., min_length=1, max_length=8)      # HH:MM local
    timezone: str = Field(..., min_length=1, max_length=64)     # IANA zone
    calendar_name: Optional[str] = Field(default=None, max_length=100)
    is_active: bool = True


def _slo_payload(db, report: dict, business_date: Optional[date],
                 now: Optional[datetime] = None) -> dict:
    from core.reports import slo as _slo
    rid = int(report["id"])
    slo = db.get_report_slo(rid)
    out: Dict[str, Any] = {"report_id": rid, "slo": slo, "status": None,
                           "breaches": [], "business_date": None}
    if slo is None:
        return out
    bd = business_date or datetime.now(timezone.utc).date()
    out["business_date"] = bd.isoformat()
    try:
        out["status"] = _slo.slo_status(db, report, slo, bd, now=now).to_dict()
    except Exception as exc:                          # noqa: BLE001
        logger.error("[report_slo] status of report %s @ %s unreadable: %s",
                     rid, bd, exc)
        out["status"] = {"status": _slo.STATUS_COULD_NOT_EVALUATE,
                         "detail": f"{type(exc).__name__}: {exc}",
                         "business_date": bd.isoformat(), "report_id": rid}
    try:
        out["breaches"] = db.list_report_slo_breaches(rid, limit=30)
    except Exception as exc:                          # noqa: BLE001
        out["breaches"] = None
        out["breaches_unavailable"] = f"{type(exc).__name__}: {exc}"
    return out


@router.get("/{report_id}/slo")
async def get_report_slo(report_id: int,
                         business_date: Optional[str] = Query(default=None),
                         user: dict = Depends(get_current_user)):
    """The promise, its live status for the date (today when omitted) and
    the recent breaches.  ``slo`` is null when none is declared."""
    report = await _require_view(report_id, user)
    return await adb(_slo_payload, _db(), report, _parse_date(business_date))


@router.put("/{report_id}/slo")
async def put_report_slo(report_id: int, body: ReportSloUpsert,
                         user: dict = Depends(get_current_user)):
    from api import feed_api as _fa
    from core.feed.acting_time import validate_sla_declaration
    report = await _require_edit(report_id, user)
    db = _db()
    fault = validate_sla_declaration(body.serve_by, body.timezone)
    if fault:
        raise HTTPException(status_code=400, detail=f"SLO refused: {fault}")
    await _fa._require_valid_calendar_name(body.calendar_name)
    declared = await adb(db.count_report_dependency_mappings, int(report["id"]))
    if not declared:
        raise HTTPException(
            status_code=400,
            detail="SLO refused: this report declares no readiness dependencies, "
                   "so 'fresh' cannot be measured. Declare at least one under "
                   "Readiness & SLO (PUT .../readiness/dependencies) first.")
    row = await adb(db.upsert_report_slo, int(report["id"]), {
        "serve_by": body.serve_by.strip(),
        "timezone": body.timezone.strip(),
        "calendar_name": (body.calendar_name or None),
        "is_active": bool(body.is_active),
        "created_by": (user or {}).get("username"),
    })
    _fa._audit("report_slo_declared", user, {
        "report_id": int(report["id"]), "serve_by": row["serve_by"],
        "timezone": row["timezone"], "calendar_name": row["calendar_name"],
        "is_active": row["is_active"]})
    return await adb(_slo_payload, db, report, None)


@router.delete("/{report_id}/slo")
async def delete_report_slo(report_id: int, user: dict = Depends(get_current_user)):
    from api import feed_api as _fa
    report = await _require_edit(report_id, user)
    removed = await adb(_db().delete_report_slo, int(report["id"]))
    if not removed:
        raise HTTPException(status_code=404, detail="This report has no SLO")
    _fa._audit("report_slo_removed", user, {"report_id": int(report["id"])})
    return {"report_id": int(report["id"]), "removed": True}
