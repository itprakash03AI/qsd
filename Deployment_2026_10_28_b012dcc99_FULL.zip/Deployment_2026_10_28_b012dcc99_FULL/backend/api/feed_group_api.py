"""Operational feed groups — a first-class managed entity (2026-09-02).

The dashboard used to group feeds by OWNER, which is an ACL attribute
(``feed_configs.owner_group_id`` → user entitlement groups).  What the
operator actually manages is an OPERATIONAL grouping — "the EOD_RISK
feeds", administered as one unit and ACTED ON as one unit — the way the
OG ETL groups its workflows.  This router is that entity:

* CRUD on ``feed_groups`` (modelled on the feed-calendar admin routes —
  the closest existing managed reference entity attached to feeds);
* membership — one group per feed (``feed_configs.feed_group_id``; a
  feed in two groups would make "run the group" ambiguous, and that
  ambiguity would surface at 04:30 as a double trigger), with a bulk
  route so an operator does not edit 40 feeds one at a time;
* group-level operations — rerun the group's runs for a business date,
  and release everything the group is waiting on.  Both return
  PER-ITEM outcomes, never one aggregate "done": a group action that
  reports success while three feeds failed is the defect class the
  bulk work already fixed once.

Authorisation: the principal is ALWAYS ``Depends(get_current_user)``,
never the request body (this codebase has shipped IDORs from a
body-supplied principal), and a group ACTION requires authority over
EVERY feed it would touch — including, for dependency skips, feeds
OUTSIDE the group that share a released tracking row (the row is
global; releasing it releases them too, and pretending otherwise would
release feeds the caller never named).

The skip path REUSES the run/dependency-skip machinery in
``core.feed.dependency_skip`` (``assert_skip`` — durable audit or
refusal — and ``type_ids_for_key``) plus the reason/date/gate helpers
from ``api.feed_ops_api``: one skip vocabulary, one audit shape, not a
second path with different semantics.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from api.deps import get_current_user, require_admin

logger = logging.getLogger(__name__)
router = APIRouter(tags=["feed-groups"])

# Module-level dependencies (same wiring pattern as api/feed_ops_api.py —
# main.py calls the setter at startup).
_db_manager: Any = None


def set_feed_group_dependencies(db_manager: Any) -> None:
    global _db_manager
    _db_manager = db_manager


def _db() -> Any:
    if _db_manager is None:               # pragma: no cover - wiring guard
        raise HTTPException(status_code=503,
                            detail="feed group API not wired to a database")
    return _db_manager


def _audit(action: str, user: dict, details: dict = None):
    """Fire-and-forget audit log (same chokepoint as feed_api._audit)."""
    try:
        from core.audit import audit_event
        audit_event(_db_manager, user or {}, action=action, details=details)
    except Exception:
        pass


def _can_act(feed: dict, user: dict) -> bool:
    """Same resolver as feed_api._can_rerun_feed / feed_ops._can_skip —
    owner / read-write group member / admin."""
    from core.feed.permissions import can_act_on_feed
    return can_act_on_feed(feed, user, _db_manager)


def _require_group(db: Any, group_id: int) -> dict:
    group = db.get_feed_group(int(group_id))
    if not group:
        raise HTTPException(status_code=404,
                            detail=f"feed group {group_id} not found")
    return group


def _clean_group_name(name) -> str:
    """The group NAME is identity (unique, referenced by operators and
    audit rows).  A blank one is refused with the fix named — the free
    text field is display_label."""
    cleaned = str(name or "").strip()
    if not cleaned:
        raise HTTPException(
            status_code=422,
            detail="name is required and must not be blank: it is the "
                   "group's identity (unique per environment, used in "
                   "audit and operator speech).  Give it a short stable "
                   "name like EOD_RISK; free text belongs in "
                   "display_label.")
    return cleaned


def _refuse_duplicate_group_name(db: Any, name: str,
                                 exclude_id: Optional[int] = None) -> None:
    existing = db.get_feed_group_by_name(name)
    if existing and (exclude_id is None
                     or int(existing["id"]) != int(exclude_id)):
        state = "" if existing.get("is_active") else " (currently inactive)"
        raise HTTPException(
            status_code=409,
            detail=f"A feed group named {name!r} already exists as id "
                   f"{existing['id']}{state}.  Group names are unique per "
                   f"environment — reuse that group (or reactivate it via "
                   f"PUT /api/feed-groups/{existing['id']}), or choose a "
                   f"different name.")


# ── request models ────────────────────────────────────────────────────


class FeedGroupCreate(BaseModel):
    name: str
    display_label: Optional[str] = Field(default=None, max_length=255)
    description: Optional[str] = None
    is_active: bool = True
    # 2026-09-27 -- the daily close-out digest's recipients (comma-separated).
    notification_email: Optional[str] = Field(default=None, max_length=500)


class FeedGroupUpdate(BaseModel):
    name: Optional[str] = None
    display_label: Optional[str] = Field(default=None, max_length=255)
    description: Optional[str] = None
    is_active: Optional[bool] = None
    notification_email: Optional[str] = Field(default=None, max_length=500)


class GroupMembershipBody(BaseModel):
    """Bulk membership edit — both directions in one call."""
    assign: List[int] = Field(default_factory=list)
    unassign: List[int] = Field(default_factory=list)


class GroupRerunBody(BaseModel):
    #: YYYY-MM-DD; None = today (UTC), same default as bulk-rerun.
    business_date: Optional[str] = None


class GroupSkipBody(BaseModel):
    reason: str
    #: 2026-09-27 -- the same vocabulary as the run / dependency skips
    #: (``GET /api/feed-dependencies/skip-reasons``); refused when absent.
    reason_category: Optional[str] = None
    #: YYYY-MM-DD; None = today (UTC).
    business_date: Optional[str] = None


# ══════════════════════════════════════════════════════════════════════
#  CRUD
# ══════════════════════════════════════════════════════════════════════


@router.get("/api/feed-groups")
async def list_feed_groups(
        is_active: Optional[bool] = Query(default=None),
        user: dict = Depends(get_current_user)):
    """All feed groups, each with a live ``feed_count``."""
    return _db().list_feed_groups(is_active=is_active)


@router.post("/api/feed-groups", status_code=201)
async def create_feed_group(body: FeedGroupCreate,
                            user: dict = Depends(require_admin)):
    db = _db()
    name = _clean_group_name(body.name)
    _refuse_duplicate_group_name(db, name)
    payload = body.model_dump(exclude_unset=True)
    payload["name"] = name
    payload["created_by"] = user.get("username")
    try:
        group = db.create_feed_group(payload)
    except Exception as exc:
        # Same race-window backstop as the calendar route: the UNIQUE
        # constraint is the last line, the pre-check the friendly one.
        if "unique" in str(exc).lower() or "IntegrityError" in type(exc).__name__:
            raise HTTPException(
                status_code=409,
                detail=f"A feed group named {name!r} already exists")
        raise
    _audit("feed_group_created", user, {"id": group["id"], "name": name})
    group["feed_count"] = 0
    return group


@router.get("/api/feed-groups/{group_id}")
async def get_feed_group(group_id: int,
                         user: dict = Depends(get_current_user)):
    db = _db()
    group = _require_group(db, group_id)
    group["feed_count"] = db.count_feeds_in_group(group_id)
    return group


@router.put("/api/feed-groups/{group_id}")
async def update_feed_group(group_id: int, body: FeedGroupUpdate,
                            user: dict = Depends(require_admin)):
    db = _db()
    _require_group(db, group_id)
    payload = body.model_dump(exclude_unset=True)
    if "name" in payload:
        payload["name"] = _clean_group_name(payload["name"])
        _refuse_duplicate_group_name(db, payload["name"],
                                     exclude_id=group_id)
    if not payload:
        raise HTTPException(status_code=400, detail="No fields to update")
    group = db.update_feed_group(group_id, payload)
    _audit("feed_group_updated", user,
           {"id": group_id, "keys": list(payload.keys())})
    group["feed_count"] = db.count_feeds_in_group(group_id)
    return group


@router.delete("/api/feed-groups/{group_id}", status_code=204)
async def delete_feed_group(
        group_id: int,
        detach_feeds: bool = Query(default=False),
        user: dict = Depends(require_admin)):
    """Delete a group.

    A group that still has feeds is REFUSED (409, with the count) unless
    ``?detach_feeds=true`` makes the intent explicit — silently orphaning
    40 feeds is the failure this refusal exists to prevent.  With
    ``detach_feeds=true`` every member feed's ``feed_group_id`` is set to
    NULL (the feeds themselves are never deleted — a group is a grouping,
    not an owner) and the group row is removed.
    """
    db = _db()
    group = _require_group(db, group_id)
    n = db.count_feeds_in_group(group_id)
    if n and not detach_feeds:
        raise HTTPException(
            status_code=409,
            detail=f"Feed group {group['name']!r} still has {n} feed(s).  "
                   f"Move them to another group first (PUT "
                   f"/api/feed-groups/<other>/feeds), or pass "
                   f"?detach_feeds=true to delete the group and leave its "
                   f"feeds UNGROUPED — the feeds themselves are never "
                   f"deleted either way.")
    if not db.delete_feed_group(group_id, detach_feeds=bool(detach_feeds)):
        raise HTTPException(status_code=404,
                            detail=f"feed group {group_id} not found")
    _audit("feed_group_deleted", user,
           {"id": group_id, "name": group.get("name"),
            "detached_feeds": n if detach_feeds else 0})
    return None


# ══════════════════════════════════════════════════════════════════════
#  Membership
# ══════════════════════════════════════════════════════════════════════


def _slim_feed(f: dict) -> dict:
    """Metadata projection — deliberately NO destination_config /
    backend_config, so this route can never leak a delivery credential
    and needs no masking pass."""
    return {k: f.get(k) for k in (
        "id", "name", "display_name", "is_active", "source_type",
        "frequency_category", "priority", "sla_from", "sla_to",
        "owner_group_id", "feed_group_id", "etl_id", "created_by",
    )}


@router.get("/api/feed-groups/{group_id}/feeds")
async def list_feeds_in_group(group_id: int,
                              user: dict = Depends(get_current_user)):
    db = _db()
    group = _require_group(db, group_id)
    feeds = [_slim_feed(f) for f in db.list_feed_configs_in_group(group_id)]
    return {"group_id": int(group_id), "group_name": group["name"],
            "is_active": group.get("is_active"),
            "feeds": feeds, "feed_count": len(feeds)}


@router.put("/api/feed-groups/{group_id}/feeds")
async def set_group_membership(group_id: int, body: GroupMembershipBody,
                               user: dict = Depends(get_current_user)):
    """Bulk assign/unassign so an operator does not edit 40 feeds one at
    a time.  Validation-first: unknown ids, an id in both lists, an
    inactive target group, or a feed the caller cannot act on refuse the
    WHOLE call before anything is written — a half-applied bulk edit is
    worse than a refused one.  Assignment IS reassignment (one group per
    feed: an assigned feed already in another group is MOVED, stated in
    the response as ``moved_from``)."""
    db = _db()
    group = _require_group(db, group_id)
    assign = [int(i) for i in body.assign]
    unassign = [int(i) for i in body.unassign]
    if not assign and not unassign:
        raise HTTPException(
            status_code=422,
            detail="Both assign and unassign are empty — nothing to do.  "
                   "Name the feed ids to add under 'assign' and/or the "
                   "ids to remove under 'unassign'.")
    both = sorted(set(assign) & set(unassign))
    if both:
        raise HTTPException(
            status_code=422,
            detail=f"feed ids {both} appear in BOTH assign and unassign — "
                   f"ambiguous, so nothing was changed.  Put each id in "
                   f"exactly one list.")
    if assign and not group.get("is_active"):
        raise HTTPException(
            status_code=409,
            detail=f"Feed group {group['name']!r} is inactive — reactivate "
                   f"it first (PUT /api/feed-groups/{group_id} with "
                   f"is_active=true) or assign to an active group.  "
                   f"Unassigning from it stays allowed.")

    feeds: Dict[int, dict] = {}
    missing: List[int] = []
    for fid in {*assign, *unassign}:
        f = db.get_feed_config(fid)
        if f:
            feeds[fid] = f
        else:
            missing.append(fid)
    if missing:
        raise HTTPException(
            status_code=422,
            detail=f"feed ids {sorted(missing)} do not exist — nothing was "
                   f"changed.  Check the ids (GET /api/feeds lists them); "
                   f"a typo must not silently move only part of the set.")

    denied = sorted({feeds[fid].get("name") or str(fid)
                     for fid in feeds if not _can_act(feeds[fid], user)})
    if denied:
        raise HTTPException(
            status_code=403,
            detail=f"you cannot act on: {denied}.  Group membership is a "
                   f"feed edit, so it needs the same authority as editing "
                   f"each feed (owner / read-write group member / admin) — "
                   f"nothing was changed.")

    moved_from = {fid: feeds[fid].get("feed_group_id") for fid in assign
                  if feeds[fid].get("feed_group_id")
                  and int(feeds[fid]["feed_group_id"]) != int(group_id)}
    result = db.set_feed_group_membership(group_id, assign, unassign)
    # Unassign ids that were valid feeds but NOT members of this group:
    # named explicitly, not silently absorbed.
    not_in_group = sorted(set(unassign) - set(result["unassigned"]))
    _audit("feed_group_membership_changed", user, {
        "group_id": int(group_id), "assigned": result["assigned"],
        "unassigned": result["unassigned"],
        "moved_from_other_groups": moved_from,
    })
    return {
        "group_id": int(group_id),
        "group_name": group["name"],
        "assigned": result["assigned"],
        "unassigned": result["unassigned"],
        "moved_from": moved_from,
        "not_in_group": not_in_group,
        "feed_count": db.count_feeds_in_group(group_id),
    }


# ══════════════════════════════════════════════════════════════════════
#  Group-level operations — the point of the feature
# ══════════════════════════════════════════════════════════════════════


def _require_authority_over_all(feeds: List[dict], user: dict,
                                *, action: str) -> None:
    """A group action needs authority over EVERY feed it would touch —
    partial authority silently shrinking the action's scope is how a
    group 'rerun' quietly reruns half a group."""
    denied = sorted({f.get("name") or f"feed_config {f.get('id')}"
                     for f in feeds if not _can_act(f, user)})
    if denied:
        raise HTTPException(
            status_code=403,
            detail=f"{action} would touch feeds you cannot act on: "
                   f"{denied}.  A group action needs authority over EVERY "
                   f"feed it touches (owner / read-write group member / "
                   f"admin) — running just your subset silently would make "
                   f"'the group ran' a lie.  Ask an admin, or act on your "
                   f"own feeds individually.")


def _bd_or_today(raw: Optional[str]):
    from api.feed_ops_api import _parse_bd
    if raw is None:
        return datetime.now(timezone.utc).date()
    return _parse_bd(raw, where="business_date")


@router.post("/api/feed-groups/{group_id}/rerun")
async def rerun_feed_group(group_id: int, body: GroupRerunBody,
                           background_tasks: BackgroundTasks,
                           user: dict = Depends(get_current_user)):
    """Re-run the group's feed_runs for a business date.

    Per-item outcomes, never one aggregate: every member feed appears in
    ``items`` with what actually happened to it — ``triggered``,
    ``skipped_inactive``, ``no_run_for_date`` or ``failed`` — so three
    failures inside a "success" cannot hide.
    """
    db = _db()
    group = _require_group(db, group_id)
    feeds = db.list_feed_configs_in_group(group_id)
    if not feeds:
        raise HTTPException(
            status_code=409,
            detail=f"Feed group {group['name']!r} has no feeds — nothing "
                   f"to rerun.  Assign feeds first (PUT /api/feed-groups/"
                   f"{group_id}/feeds).")
    _require_authority_over_all(feeds, user,
                                action=f"rerunning group {group['name']!r}")
    bd = _bd_or_today(body.business_date)

    actor = user.get("username", "unknown")
    items: List[dict] = []
    triggered = failed = skipped = blocked_by_window = 0

    # FR-OPS-04 (2026-09-03) — a group rerun STARTS runs, so an active
    # deployment window blocks each matching member, per-item outcome
    # named.  An UNREADABLE window store fails OPEN, loudly (same
    # posture as feed_api._refuse_if_deployment_window: a settings blip
    # must not stop the group; a genuine window still blocks).
    _window_cache: dict = {}

    def _window_for(feed_: dict):
        fid_ = int(feed_["id"])
        if fid_ not in _window_cache:
            try:
                from core.feed.deployment_window import (
                    blocking_window_for_feed,
                )
                _window_cache[fid_] = blocking_window_for_feed(db, feed_)
            except Exception as exc:
                logger.error(
                    "[feed_group_api] deployment windows could not be "
                    "read for feed %s (%s) — window NOT ENFORCED for "
                    "this item (fail-open)", fid_, exc)
                _window_cache[fid_] = None
        return _window_cache[fid_]

    for feed in feeds:
        item = {"feed_config_id": int(feed["id"]),
                "feed_name": feed.get("name"), "run_id": None}
        if not feed.get("is_active"):
            item["outcome"] = "skipped_inactive"
            skipped += 1
            items.append(item)
            continue
        _win = _window_for(feed)
        if _win is not None:
            item["outcome"] = "blocked_by_deployment_window"
            item["window_id"] = _win.get("id")
            item["detail"] = (
                f"deployment window {_win.get('id')} active until "
                f"{_win.get('ends_at')}: {_win.get('reason')} — runs "
                f"must not START during it (in-flight runs untouched)")
            blocked_by_window += 1
            items.append(item)
            continue
        try:
            run = db.get_feed_run_by_feed_date(int(feed["id"]), bd)
        except Exception as exc:
            run = None
            item["detail"] = f"run lookup failed: {exc}"
        if not run:
            item["outcome"] = "no_run_for_date"
            item.setdefault(
                "detail",
                f"no feed_run exists for {bd.isoformat()} — the SOD "
                f"generator creates them; to execute outside a run use "
                f"POST /api/feeds/{feed['id']}/execute.")
            failed += 1
            items.append(item)
            continue
        item["run_id"] = int(run["id"])
        try:
            prior_retries = int(run.get("retry_count") or 0)
            db.update_feed_run(int(run["id"]), {
                "status": "pending",
                "started_at": None,
                "completed_at": None,
                "error": None,
                "action_decision": "RUN",
                "action_reason": f"Group rerun ({group['name']}) by {actor}",
                "triggered_by": "rerun",
                "triggered_by_user": actor,
                "retry_count": prior_retries + 1,
            })

            async def _exec(_fid=int(feed["id"]), _rid=int(run["id"])):
                from core.feed_engine import execute_feed
                await execute_feed(_fid, trigger_type="rerun",
                                   triggered_by=actor, feed_run_id=_rid)

            background_tasks.add_task(_exec)
            item["outcome"] = "triggered"
            triggered += 1
        except Exception as exc:
            # One broken row must not abort the rest of the group, and
            # must not vanish into an aggregate either.
            item["outcome"] = "failed"
            item["detail"] = f"{type(exc).__name__}: {exc}"
            failed += 1
        items.append(item)

    _audit("feed_group_rerun", user, {
        "group_id": int(group_id), "group_name": group["name"],
        "business_date": bd.isoformat(), "triggered": triggered,
        "failed": failed, "skipped_inactive": skipped,
        "blocked_by_deployment_window": blocked_by_window,
    })
    return {"group_id": int(group_id), "group_name": group["name"],
            "business_date": bd.isoformat(), "items": items,
            "triggered": triggered, "failed": failed,
            "skipped_inactive": skipped,
            "blocked_by_deployment_window": blocked_by_window}


@router.post("/api/feed-groups/{group_id}/skip-dependencies")
async def skip_group_dependencies(group_id: int, body: GroupSkipBody,
                                  user: dict = Depends(get_current_user)):
    """Release everything the group is waiting on for a business date.

    Same machinery, same audit shape as the run/dependency skip routes
    in feed_ops_api — ``assert_skip`` writes the durable tracking rows
    and audit events, or refuses.  The tracking row is GLOBAL, so a
    write can release feeds OUTSIDE the group that share it; those are
    included in the authority check (you release what you release, not
    what you named) and reported under ``also_released``.

    Per-item outcomes per member feed: ``released``, ``not_blocked``,
    ``no_pending_run``, ``no_dependencies`` or ``failed``.
    """
    db = _db()
    from api.feed_ops_api import _clean_reason, _gate
    group = _require_group(db, group_id)
    skip_reason = _clean_reason(body.reason, body.reason_category)
    reason = skip_reason.as_text()
    bd = _bd_or_today(body.business_date)
    feeds = db.list_feed_configs_in_group(group_id)
    if not feeds:
        raise HTTPException(
            status_code=409,
            detail=f"Feed group {group['name']!r} has no feeds — nothing "
                   f"to skip.  Assign feeds first (PUT /api/feed-groups/"
                   f"{group_id}/feeds).")

    from core.feed.dependency_skip import (
        SkipAuditUnrecordable, assert_skip, type_ids_for_key,
    )

    # 1. What is each member actually waiting on?
    items: List[dict] = []
    plan: List[dict] = []          # members with a real blocking set
    from core.feed.etl_dependency import effective_etl_id
    for feed in feeds:
        item = {"feed_config_id": int(feed["id"]),
                "feed_name": feed.get("name"), "run_id": None}
        # 2026-09-27 — "has no dependencies" is answered by the MAPPINGS
        # under the feed's effective etl_id (explicit, else its own id),
        # not by whether the explicit column is set: a member whose
        # dependencies were authored under its own id used to be reported
        # as having none, and its held run was never released here.
        etl_id = effective_etl_id(feed)
        if not db.list_etl_dependency_mappings(int(etl_id)):
            item["outcome"] = "no_dependencies"
            items.append(item)
            continue
        run = db.get_feed_run_by_feed_date(int(feed["id"]), bd)
        if not run:
            item["outcome"] = "no_pending_run"
            item["detail"] = f"no feed_run for {bd.isoformat()}"
            items.append(item)
            continue
        item["run_id"] = int(run["id"])
        if str(run.get("status") or "") != "pending":
            item["outcome"] = "no_pending_run"
            item["detail"] = (f"run is {run.get('status')!r}, not waiting "
                              f"on dependencies")
            items.append(item)
            continue
        verdicts = _gate(db, int(etl_id), bd)
        blocking = sorted(v.dependency_name for v in verdicts.blocking) \
            if verdicts is not None else []
        if not blocking:
            item["outcome"] = "not_blocked"
            items.append(item)
            continue
        plan.append({"feed": feed, "run": run, "etl_id": int(etl_id),
                     "blocking": blocking, "item": item})
        items.append(item)

    if not plan:
        raise HTTPException(
            status_code=409,
            detail=f"nothing in group {group['name']!r} is blocked by any "
                   f"dependency for {bd.isoformat()} — no assertion was "
                   f"written.  GET /api/feed-dependencies/blocking?"
                   f"business_date={bd.isoformat()} lists what IS blocking.")

    # 2. Which tracking rows those blocks imply, and who ELSE they release
    #    (the row is global — see the dependency-level skip route).
    written_types_by_key: Dict[str, set] = {}
    for p in plan:
        for key in p["blocking"]:
            written_types_by_key.setdefault(key, set()).update(
                type_ids_for_key(db, p["etl_id"], bd, key))
    unresolvable = sorted(k for k, t in written_types_by_key.items() if not t)
    if unresolvable:
        raise HTTPException(
            status_code=500,
            detail=f"could not resolve the dependency type for "
                   f"{unresolvable} — nothing was skipped; retry, and if "
                   f"it persists check the mapping rows.")

    member_run_ids = {int(p["run"]["id"]) for p in plan}
    released_by_key: Dict[str, List[dict]] = {}
    sharers: List[dict] = []          # runs outside the group
    sharer_feeds: Dict[int, dict] = {}
    try:
        from core.feed.dependency_index import build_blocking_index
        index = build_blocking_index(db, business_date=bd)
    except Exception as exc:                       # pragma: no cover
        logger.error("[feed_groups] blocking index unreadable: %s", exc)
        index = {"by_dependency": {}}
    for key, types in written_types_by_key.items():
        released = [p["run"] for p in plan if key in p["blocking"]]
        entry = (index.get("by_dependency") or {}).get(key)
        for r in (entry or {}).get("runs", []):
            if int(r["id"]) in member_run_ids:
                continue
            r_types = set(type_ids_for_key(db, int(r["etl_id"]), bd, key))
            if r_types & types:
                released.append(r)
                fid = int(r["feed_config_id"])
                if fid not in sharer_feeds:
                    sharer_feeds[fid] = db.get_feed_config(fid) or {
                        "id": fid, "name": r.get("feed_name")}
                if all(int(s["id"]) != int(r["id"]) for s in sharers):
                    sharers.append(r)
        released_by_key[key] = released

    # 3. Authority over EVERYTHING the writes would release.
    _require_authority_over_all(
        feeds + list(sharer_feeds.values()), user,
        action=f"skipping the dependencies of group {group['name']!r}")

    # 4. Write — per KEY, so one unrecordable audit fails that key's
    #    feeds and not the whole morning.  assert_skip is the same
    #    durable-audit chokepoint the run/dependency skip routes use.
    asserted_at = datetime.now(timezone.utc)
    actor = str(user.get("username") or "unknown")
    failed_keys: Dict[str, str] = {}
    for key, types in written_types_by_key.items():
        try:
            for type_id in sorted(types):
                assert_skip(
                    db, dependency_type_id=type_id, dependency_key=key,
                    business_date=bd, reason=reason, actor=actor,
                    affected_runs=released_by_key[key],
                    asserted_at=asserted_at, source="group_skip_api",
                    reason_category=skip_reason.category)
        except SkipAuditUnrecordable as exc:
            failed_keys[key] = str(exc)

    # 5. Per-member outcomes + flip the now-admitted runs (fail-soft: the
    #    assertion is durable and the dep poller converges).
    released_count = 0
    for p in plan:
        ok = [k for k in p["blocking"] if k not in failed_keys]
        bad = [k for k in p["blocking"] if k in failed_keys]
        p["item"]["skipped_dependencies"] = ok
        if bad:
            p["item"]["outcome"] = "failed"
            p["item"]["detail"] = (
                f"audit could not be recorded for {bad} — those "
                f"dependencies were NOT skipped: "
                + "; ".join(failed_keys[k] for k in bad))
        else:
            p["item"]["outcome"] = "released"
            released_count += 1
        try:
            after = _gate(db, p["etl_id"], bd)
            if after is not None and after.admitted:
                from core.feed.dependency_skip import release_admitted_run
                release_admitted_run(
                    db, int(p["run"]["id"]),
                    f"group {group['name']} dependencies skipped by {actor}: "
                    f"{reason}", etl_id=int(p["etl_id"]), source="group_skip")
        except Exception as exc:
            logger.error("[feed_groups] could not flip run %s after skip "
                         "(%s) — the dep poller will", p["run"].get("id"), exc)

    # The sharers were RELEASED by the same global rows (that is why they
    # were in the authority check) — flip them too, exactly as the
    # dependency-level skip route does: "go anyway" means NOW for every
    # run the write released, not just the ones inside the group.
    # Fail-soft per run: the assertion is durable, the dep poller
    # converges.
    for r in sharers:
        try:
            after = _gate(db, int(r["etl_id"]), bd)
            if after is not None and after.admitted:
                from core.feed.dependency_skip import release_admitted_run
                release_admitted_run(
                    db, int(r["id"]),
                    f"dependency shared with group {group['name']} skipped by "
                    f"{actor}: {reason}", etl_id=int(r["etl_id"]),
                    source="group_skip_shared")
        except Exception as exc:
            logger.error("[feed_groups] could not flip shared run %s after "
                         "skip (%s) — the dep poller will", r.get("id"), exc)

    _audit("feed_group_skip_dependencies", user, {
        "group_id": int(group_id), "group_name": group["name"],
        "business_date": bd.isoformat(), "reason": reason,
        "skipped_keys": sorted(set(written_types_by_key) - set(failed_keys)),
        "failed_keys": sorted(failed_keys),
        "also_released": [int(r["id"]) for r in sharers],
    })
    return {
        "group_id": int(group_id),
        "group_name": group["name"],
        "business_date": bd.isoformat(),
        "reason": reason,
        "reason_category": skip_reason.category,
        "asserted_by": actor,
        "asserted_at": asserted_at.isoformat(),
        "items": items,
        "released": released_count,
        "also_released": [{
            "feed_run_id": int(r["id"]),
            "feed_config_id": int(r["feed_config_id"]),
            "feed_name": r.get("feed_name"),
        } for r in sharers],
        "failed_dependencies": failed_keys,
    }
