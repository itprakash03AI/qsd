"""Phase 100 — User Preferences API.

Per-user key-value store for guided tour completion state, UI preferences,
and onboarding progress.  Persists to the `user_preferences` table.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Dict, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from api.deps import get_current_user

logger = logging.getLogger(__name__)
router = APIRouter()


# BF-NONBLOCK-AUDIT-5
async def _adb(_fn, *args, **kwargs):
    return await asyncio.to_thread(_fn, *args, **kwargs)

# ── Dependency injection (set from main.py startup) ─────────────────────────
_db_manager = None


def set_user_preferences_dependencies(db_manager):
    """Called once from main.py _startup()."""
    global _db_manager
    _db_manager = db_manager


def _require_db():
    from api.deps import require_db as _central_require_db
    return _central_require_db()


# ── Pydantic models ─────────────────────────────────────────────────────────

class PrefSet(BaseModel):
    key: str = Field(..., min_length=1, max_length=200)
    value: Optional[str] = None


class PrefBulkSet(BaseModel):
    preferences: Dict[str, Optional[str]] = Field(..., min_length=1)


# ── Endpoints ────────────────────────────────────────────────────────────────

@router.get("/api/user-preferences")
async def list_preferences(user: dict = Depends(get_current_user)):
    """Return all preferences for the current user as a {key: value} dict."""
    db = _require_db()
    username = (user or {}).get("username", "")
    prefs = await _adb(db.get_user_preferences, username)
    return {"preferences": prefs}


@router.get("/api/user-preferences/{key}")
async def get_preference(key: str, user: dict = Depends(get_current_user)):
    """Return a single preference value.

    FB-35 (2026-09-19): an ABSENT preference answered 404, and the UI asks
    for ``tours_completed`` on every navigation, so every page load put
    "Failed to load resource: 404" in the browser console -- a console
    that is always red is a console nobody reads, and the next genuine
    error lands in the same place.  Absent is not an error for a
    preference: ``{"key", "value": null, "set": false}`` with 200.
    ``set`` is true when a non-null value is stored (the store returns
    None for both "never set" and "set to null", so those two are one
    answer here -- and both mean "nothing to apply" to a client).
    """
    db = _require_db()
    username = (user or {}).get("username", "")
    val = await _adb(db.get_user_preference, username, key)
    return {"key": key, "value": val, "set": val is not None}


@router.put("/api/user-preferences")
async def set_preference(body: PrefSet, user: dict = Depends(get_current_user)):
    """Create or update a single preference."""
    db = _require_db()
    username = (user or {}).get("username", "")
    result = await _adb(db.set_user_preference, username, body.key, body.value)
    return result


@router.put("/api/user-preferences/bulk")
async def set_preferences_bulk(body: PrefBulkSet, user: dict = Depends(get_current_user)):
    """Set multiple preferences at once."""
    db = _require_db()
    username = (user or {}).get("username", "")
    # BF-NONBLOCK-AUDIT-5: bulk set runs all writes in a single thread
    # so we don't pingpong between event loop and worker N times.
    def _bulk():
        for key, value in body.preferences.items():
            db.set_user_preference(username, key, value)
        return dict(body.preferences)
    results = await asyncio.to_thread(_bulk)
    return {"preferences": results}


@router.delete("/api/user-preferences/{key}")
async def delete_preference(key: str, user: dict = Depends(get_current_user)):
    """Delete a single preference."""
    db = _require_db()
    username = (user or {}).get("username", "")
    deleted = await _adb(db.delete_user_preference, username, key)
    if not deleted:
        raise HTTPException(404, f"Preference '{key}' not found")
    return {"detail": "deleted"}
