"""
Report Bursting API (Phase 23E)

The #1 enterprise reporting differentiator — run one report per distinct value
of a dimension column and deliver each slice to the right recipient.

Workflow:
  1. POST /api/reports/{id}/burst — define burst job (column, recipients, format)
  2. System queries distinct values of burst_column from the report's source
  3. One BurstTask is created per value
  4. Each task runs the report filtered to its value, generates output, delivers it
  5. GET /api/reports/burst/{job_id} — check progress

Delivery options:
  - email:  attach PDF/Excel to per-value email
  - s3:     write to s3_prefix/{value}/filename.ext

Example: Burst "Monthly Sales" by "region" column
  → APAC team gets APAC-only PDF
  → EMEA team gets EMEA-only PDF
  → Each delivered to their email automatically

Report families (2026-08-30): a burst job names its family EXPLICITLY via
``report_type`` — the same vocabulary the subscriptions table uses.  FB-60
(2026-09-26): only ``business_report`` remains; ``report`` (the legacy
parametric family) is refused with the decommission reason.  Business
reports execute through ``run_business_report_to_df`` (the identical seam
subscription delivery dispatches to) and are sliced in-memory from that one
owner-scoped run; see ``_execute_family_report`` / ``_slice_business_frame``.
"""
from __future__ import annotations

import logging
import threading
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException, Query as QParam, Request
from pydantic import BaseModel, Field

from api.deps import aget_verified_user, is_owner_or_shared
from core.db_async import adb

logger = logging.getLogger(__name__)

router = APIRouter()

_db_manager     = None
_auth_cfg       = None
_email_svc      = None


def set_burst_dependencies(db_manager, auth_cfg, email_service=None):
    global _db_manager, _auth_cfg, _email_svc
    _db_manager     = db_manager
    _auth_cfg       = auth_cfg
    _email_svc      = email_service


# Phase 1 SECURITY (2026-07-23): the forgeable local ``_get_user`` (base64-
# decode the Basic header, TRUST the username, fall back to "anonymous") is
# GONE.  Identity comes from api.deps.aget_verified_user — the verified
# boundary (session lookup / real password check; optional config-gated
# X-API-Key service auth).  Unauthenticated/forged → 401, fail-CLOSED.


# ── Pydantic ──────────────────────────────────────────────────────────────────

class BurstJobRequest(BaseModel):
    burst_column:      str
    base_params:       Dict[str, Any] = {}
    output_format:     str = Field(default="pdf", pattern="^(pdf|excel|csv)$")
    delivery_type:     str = Field(default="email", pattern="^(email|s3)$")
    recipient_map:     Optional[Dict[str, str]] = None   # {"APAC": "apac@co.com", ...}
    default_recipient: Optional[str] = None
    s3_prefix:         Optional[str] = None
    # 2026-08-30 — which report FAMILY the id resolves against.  EXPLICIT,
    # never inferred.  FB-60 (2026-09-26): the legacy ``report`` family is
    # decommissioned; it is still ACCEPTED by the model so the refusal can
    # name the reason (a pattern 422 would read as a typo).  Default is the
    # only family that runs.
    report_type:       str = Field(default="business_report",
                                   pattern="^(report|business_report)$")


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/api/reports/{report_id}/burst-jobs")
async def list_burst_jobs(report_id: int, request: Request,
                          limit: int = QParam(default=20, ge=1, le=100)):
    # Phase 1 Part-1b SECURITY: was anonymous-callable (consumed no identity).
    await aget_verified_user(request)          # 401 on forged/missing auth
    return {"jobs": await adb(_db_manager.list_burst_jobs, report_id, limit=limit)}


@router.post("/api/reports/{report_id}/burst", status_code=202)
async def trigger_burst(report_id: int, body: BurstJobRequest, request: Request):
    """Create a burst job and start processing in the background."""
    user = await aget_verified_user(request)   # 401 on forged/missing auth

    # R1 (2026-08-17): object-level view gate — bursting mails the report's
    # data to arbitrary recipients, so the trigger must be able to VIEW the
    # report.  Same entitlements rule + 404 denial shape as the canonical
    # GET (no existence oracle).  Family-dispatched (2026-08-30): the id is
    # resolved ONLY against the table body.report_type names — never both,
    # never guessed — so a colliding legacy/business id can neither leak the
    # wrong report's data nor authorize against the wrong row.
    if body.report_type != "business_report":
        from core.reports.legacy_parametric import refusal
        raise HTTPException(status_code=400, detail=refusal(
            "burst report_type 'report'",
            instead="Burst the finance report with report_type='business_report'."))
    report = await adb(_db_manager.get_business_report, report_id)
    if not report:
        raise HTTPException(status_code=404,
                            detail=f"Report {report_id} not found")
    from core.reports.authorization import can_view_business_report
    if not can_view_business_report(report, user, _db_manager):
        raise HTTPException(status_code=404,
                            detail=f"Report {report_id} not found")

    if body.delivery_type == "email" and not body.default_recipient and not body.recipient_map:
        raise HTTPException(status_code=400,
                            detail="Provide default_recipient or recipient_map for email delivery")
    if body.delivery_type == "s3" and not body.s3_prefix:
        raise HTTPException(status_code=400, detail="Provide s3_prefix for S3 delivery")

    # Persist the family ON the job row (observability): burst_jobs has no
    # report_type column and jobs of both families share the report_id
    # space, so a reserved marker inside the stored base_params is what lets
    # GET /burst-jobs rows be told apart.  Legacy rows stay byte-identical
    # (no marker added); execution reads body.report_type, never the marker.
    stored_params = (dict(body.base_params, __report_type__="business_report")
                     if body.report_type == "business_report"
                     else body.base_params)
    job = await adb(_db_manager.create_burst_job,
        report_id=report_id, burst_column=body.burst_column,
        output_format=body.output_format, delivery_type=body.delivery_type,
        base_params=stored_params, recipient_map=body.recipient_map,
        default_recipient=body.default_recipient, s3_prefix=body.s3_prefix,
        created_by=user["username"],
    )

    # R8 (2026-08-17): audit the trigger — bursting distributes report data
    # outward; previously no audit row was written anywhere on this surface.
    from core.audit import audit_event
    audit_event(_db_manager, user, request, "report_burst_triggered", "report",
                report_id,
                details={"job_id": job["id"], "burst_column": body.burst_column,
                         "delivery_type": body.delivery_type,
                         "output_format": body.output_format,
                         "report_type": body.report_type})

    threading.Thread(
        target=_run_burst_job,
        # R1: pass the FULL verified principal — the execute chokepoint
        # keeps admin/group semantics in every auth mode.
        args=(job["id"], report_id, body, user),
        daemon=True,
    ).start()

    return {"job_id": job["id"], "status": "started",
            "message": "Burst job queued. Poll GET /api/reports/burst/{job_id} for progress."}


@router.get("/api/reports/burst/{job_id}")
async def get_burst_job(job_id: int, request: Request):
    # Phase 1 Part-1b SECURITY: was anonymous-callable (consumed no identity).
    await aget_verified_user(request)          # 401 on forged/missing auth
    job = await adb(_db_manager.get_burst_job, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Burst job not found")
    tasks = await adb(_db_manager.list_burst_tasks, job_id)
    return {"job": job, "tasks": tasks}


@router.post("/api/reports/burst/{job_id}/cancel")
async def cancel_burst_job(job_id: int, request: Request):
    # Phase 1 Part-1b SECURITY: anonymous callers could cancel ANY job.
    # Now: verified identity required (401), and cancellation is
    # owner-or-admin via the job's created_by column — the same ownership
    # rule as api.deps.is_owner_or_shared everywhere else (BurstJob rows
    # have no is_shared/is_public, so this reduces to exactly
    # owner-or-admin; legacy rows with created_by=NULL are admin-only —
    # fail-CLOSED).  auth.type='none' guest is admin → dev mode unchanged.
    user = await aget_verified_user(request)   # 401 on forged/missing auth
    job = await adb(_db_manager.get_burst_job, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Burst job not found")
    if not is_owner_or_shared(job, user):
        raise HTTPException(status_code=403,
                            detail="Not authorized to cancel this burst job")
    if job["status"] not in ("pending", "running"):
        raise HTTPException(status_code=409, detail=f"Cannot cancel job in status '{job['status']}'")
    await adb(_db_manager.update_burst_job, job_id, status="cancelled")
    return {"job_id": job_id, "status": "cancelled"}


# ── Background burst runner ───────────────────────────────────────────────────

def _run_burst_job(job_id: int, report_id: int, body: BurstJobRequest,
                   principal) -> None:
    """Execute burst job in background thread.

    ``principal``: the verified user dict of the triggering caller (R1) —
    forwarded to the execute chokepoint so every slice runs under THEIR
    view/RLS scope.  A bare username string is still accepted for backwards
    compatibility (resolved server-side by the chokepoint).

    R3 (2026-08-17): both execution passes run UNBOUNDED (limit=None; falsy
    means unlimited — the reports_api engines omit the cap entirely).  The
    old hardcoded limit=100000 silently truncated TWICE: a burst dimension
    value first appearing after row 100k got NO task/file/email and the job
    ended "done"; any slice over 100k was cut and mailed as complete — zero
    disclosure either way.
    """
    try:
        _db_manager.update_burst_job(job_id, status="running",
                                     started_at=datetime.now(timezone.utc))

        # Step 1: Get distinct values of burst_column from unfiltered report.
        # UNBOUNDED — every distinct value must produce a task (R3).
        # Family-dispatched (2026-08-30): a business report runs through the
        # SAME executor subscription delivery uses (run_business_report_to_df)
        # so burst and subscription cannot diverge on what "run this report"
        # means — owner-scoped RLS, verified artifact, id resolved against
        # business_reports only.
        try:
            full_df = _execute_family_report(report_id, body.base_params,
                                             principal, body.report_type)
        except Exception as exc:
            _db_manager.update_burst_job(job_id, status="failed",
                                         error_message=f"Failed to fetch distinct values: {exc}",
                                         completed_at=datetime.now(timezone.utc))
            return

        if body.burst_column not in full_df.columns:
            _db_manager.update_burst_job(job_id, status="failed",
                                         error_message=f"Column '{body.burst_column}' not found in report",
                                         completed_at=datetime.now(timezone.utc))
            return

        distinct_values = [str(v) for v in full_df[body.burst_column].dropna().unique()
                           if str(v).strip()]
        if not distinct_values:
            _db_manager.update_burst_job(job_id, status="done",
                                         total_tasks=0,
                                         completed_at=datetime.now(timezone.utc))
            return

        # Step 2: Create one BurstTask per distinct value
        recipient_map = body.recipient_map or {}
        task_defs = []
        for val in distinct_values:
            recipient = (recipient_map.get(val)
                         or body.default_recipient
                         or (f"{val.lower().replace(' ', '_')}@{body.s3_prefix or 'output'}"
                             if body.delivery_type == "s3" else None))
            task_defs.append({"dimension_value": val, "recipient": recipient})

        tasks = _db_manager.create_burst_tasks(job_id, task_defs)
        _db_manager.update_burst_job(job_id, total_tasks=len(tasks))

        done = 0
        failed = 0

        # Step 3: Run each task
        for task in tasks:
            # Check if job was cancelled
            current = _db_manager.get_burst_job(job_id)
            if current and current.get("status") == "cancelled":
                break

            task_id = task["id"]
            val = task["dimension_value"]
            recipient = task["recipient"]

            _db_manager.update_burst_task(task_id, status="running",
                                           started_at=datetime.now(timezone.utc))
            try:
                # Run report filtered to this dimension value.
                # UNBOUNDED (R3) — a slice is delivered complete, never a
                # silent 100k cut mailed as the whole answer.
                if body.report_type == "business_report":
                    # Business reports: slice the ONE owner-scoped run
                    # in-memory.  Re-executing with {burst_column: val} would
                    # be a data-distribution bug, not an option:
                    # _build_report_filters turns only DECLARED parameters
                    # (with a lov_column_id) into filters and SILENTLY
                    # IGNORES anything else — an undeclared burst column
                    # would mail EVERY recipient the FULL dataset labelled
                    # as their slice.  Slicing the frame that produced the
                    # distinct values is exact by construction.
                    slice_df = _slice_business_frame(full_df,
                                                     body.burst_column, val)
                else:
                    # Unreachable: trigger_burst refuses every other family.
                    from core.reports.legacy_parametric import refusal
                    raise RuntimeError(refusal("burst report_type 'report'"))

                # Generate output file
                output_path = _generate_output(job_id, task_id, val, slice_df,
                                                body.output_format)

                # Deliver
                _deliver_burst_task(task_id, output_path, recipient,
                                    body.delivery_type, body.output_format,
                                    body.s3_prefix, val)

                _db_manager.update_burst_task(task_id, status="done",
                                               output_file=output_path,
                                               completed_at=datetime.now(timezone.utc))
                done += 1
            except Exception as exc:
                error_str = str(exc)
                logger.error("Burst task %s failed: %s", task_id, error_str)
                _db_manager.update_burst_task(task_id, status="failed",
                                               error_message=error_str,
                                               completed_at=datetime.now(timezone.utc))
                failed += 1

            _db_manager.update_burst_job(job_id, done_tasks=done, failed_tasks=failed)

        final_status = "done" if failed == 0 else ("failed" if done == 0 else "partial")
        _db_manager.update_burst_job(job_id, status=final_status,
                                     completed_at=datetime.now(timezone.utc))

    except Exception as exc:
        logger.error("Burst job %s crashed: %s", job_id, exc, exc_info=True)
        _db_manager.update_burst_job(job_id, status="failed",
                                     error_message=str(exc),
                                     completed_at=datetime.now(timezone.utc))


def _execute_family_report(report_id: int, param_values: Dict[str, Any],
                           principal, report_type: str):
    """Run the burst's base report for its FAMILY; returns a DataFrame.

    ``report_type="report"`` (legacy parametric): REFUSED -- FB-60.

    ``report_type="business_report"``: ``run_business_report_to_df`` — the
    EXACT function core.delivery_engine dispatches business-report
    subscriptions to, so the two delivery surfaces share one definition of
    "run this report":

      * id resolves against the ``business_reports`` table only (no legacy
        id collision);
      * IDENTITY: executes at the report OWNER's RLS scope
        (core.scheduler._resolve_owner_user_ctx — the F1 chokepoint).  An
        owner whose scope cannot be established is marked
        ``rls_unresolved`` and the row-security rewriter REFUSES governed
        tables (raises → the burst job records a visible failure) instead
        of reading them unfiltered.  The triggering caller's own view
        access was already enforced at POST time (can_view_business_report,
        the same authorization-to-distribute model subscriptions use); the
        username below is the audit identity, exactly as in subscription
        delivery.
      * limit=None — falsy means UNLIMITED (R3): the distinct-value pass
        and every slice are complete, never a silent cut.
    """
    if report_type == "business_report":
        from api.business_reports_api import run_business_report_to_df
        username = (principal.get("username") if isinstance(principal, dict)
                    else principal)
        return run_business_report_to_df(report_id, param_values, username,
                                         limit=None)
    from core.reports.legacy_parametric import refusal
    raise ValueError(refusal(f"burst report_type {report_type!r}"))


def _slice_business_frame(full_df, column: str, value: str):
    """One recipient's slice of the single owner-scoped business-report run.

    Rows are matched by the same stringification that produced the distinct
    task values (``str(v)`` over ``unique()``), so every row of the full run
    with a non-null burst value lands in exactly one recipient's slice.

    EMPTY-SLICE DECISION (2026-08-30): a business slice is carved from the
    very frame that enumerated the distinct values, so an empty slice is an
    internal inconsistency (slicer and enumeration disagree), not "no data".
    We FAIL the task loudly — never silently skip it, and never deliver an
    empty document that looks like real data to a recipient who cannot tell
    it from a genuine zero-row answer.
    """
    sliced = full_df[full_df[column].astype(str) == str(value)].copy()
    if sliced.empty:
        raise RuntimeError(
            f"Burst slice for {column}={value!r} matched no rows of the run "
            f"that enumerated it — refusing to deliver an empty file as if "
            f"it were this recipient's data (internal inconsistency; the "
            f"task is failed, not skipped)."
        )
    return sliced


def _generate_output(job_id: int, task_id: int, value: str,
                     df, fmt: str) -> str:
    """Write DataFrame to a temp file in the requested format. Returns file path."""
    import tempfile
    import os
    safe_val = "".join(c if c.isalnum() or c in "-_" else "_" for c in str(value))
    suffix = f".{fmt}" if fmt != "excel" else ".xlsx"
    fd, path = tempfile.mkstemp(
        prefix=f"burst_{job_id}_{task_id}_{safe_val}_",
        suffix=suffix,
    )
    os.close(fd)

    if fmt == "csv":
        df.to_csv(path, index=False)
    elif fmt in ("excel", "xlsx"):
        df.to_excel(path, index=False)
    elif fmt == "pdf":
        try:
            # 2026-10-04: through THE door (core.reports.pdf_engine.
            # render_pdf) -- a budgeted child process, never this process.
            from core.reports.pdf_engine import render_pdf
            from api.pdf_export_api import _build_pdf_html, _build_pdf_css
            cfg = _db_manager.get_pdf_config(
                # job → report_id not directly available here; use defaults
                0
            ) if _db_manager else {}
            fmt_rules = []
            html = _build_pdf_html(df, f"Burst: {value}", {}, cfg, fmt_rules)
            css  = _build_pdf_css(cfg)
            pdf_bytes = render_pdf(html, css)
            with open(path, "wb") as f:
                f.write(pdf_bytes)
        except Exception as exc:
            # 2026-08-30 — this used to write a CSV and return it as if the
            # PDF had been produced.  The burst task then reported SUCCESS and
            # the recipient received a file in a format they did not ask for,
            # named as though nothing had gone wrong; with weasyprint absent
            # (it was missing from the old py313 overlay) that was EVERY burst
            # PDF, silently, forever.  Delivering the wrong artifact and
            # calling it success is worse than failing: a failure is visible
            # and fixable, a silent format swap is neither.
            logger.error(
                "[burst] PDF generation failed — refusing to deliver a "
                "different format under the recipient's PDF request: %s", exc)
            from core.reports.pdf_engine import PdfRenderRefused
            if isinstance(exc, PdfRenderRefused):
                # Too large for the render budget: installing anything will
                # not help -- the sentence names the limit and the way out.
                raise RuntimeError(
                    f"PDF generation failed for this burst task: {exc}") from exc
            raise RuntimeError(
                f"PDF generation failed for this burst task: {exc}. "
                f"Install the 'weasyprint' extra on this deployment, or set "
                f"the burst format to csv/excel explicitly."
            ) from exc
    return path


def _deliver_burst_task(task_id: int, output_path: str, recipient: Optional[str],
                        delivery_type: str, fmt: str, s3_prefix: Optional[str],
                        dimension_value: str) -> None:
    """Deliver the generated file to email or S3."""
    if delivery_type == "email" and recipient and _email_svc:
        try:
            subject = f"Report: {dimension_value}"
            body_text = f"Please find your report for {dimension_value} attached."
            _email_svc.send_email_with_attachment(
                to=recipient, subject=subject, body=body_text,
                attachment_path=output_path,
            )
            _db_manager.record_delivery(
                delivery_type="email", destination=recipient, status="delivered",
                burst_task_id=task_id, file_format=fmt,
            )
        except Exception as exc:
            _db_manager.record_delivery(
                delivery_type="email", destination=recipient or "", status="failed",
                burst_task_id=task_id, error_message=str(exc),
            )
            raise

    elif delivery_type == "s3" and s3_prefix:
        import os
        filename = os.path.basename(output_path)
        safe_val = "".join(c if c.isalnum() or c in "-_" else "_"
                           for c in str(dimension_value))
        s3_key = s3_prefix.rstrip("/") + f"/{safe_val}/{filename}"
        try:
            import boto3
            from botocore.config import Config as BotoConfig
            from core.proxy_utils import get_boto_proxies
            _px = get_boto_proxies()
            s3 = boto3.client("s3", config=BotoConfig(proxies=_px) if _px else None)
            bucket = s3_prefix.split("/")[0] if "/" in s3_prefix else s3_prefix
            s3.upload_file(output_path, bucket, s3_key)
            _db_manager.record_delivery(
                delivery_type="s3", destination=s3_key, status="delivered",
                burst_task_id=task_id, file_format=fmt,
            )
        except Exception as exc:
            _db_manager.record_delivery(
                delivery_type="s3", destination=s3_key, status="failed",
                burst_task_id=task_id, error_message=str(exc),
            )
            raise
