"""
raw_sql report ENGINES — formerly the Parametric Reports API (FB-60, 2026-09-26).

There are NO routes in this module any more.  The parametric ``reports``
entity was decommissioned (docs/FABLE_BRIEF_2026_09_22.html §1): its successor
is a finance (business) report with ``data_source_type='raw_sql'``, and
``business_reports_api._as_legacy_report`` adapts that row into the dict shape
the two engines below take.  What stays, because the successor runs on it:

  _run_parquet_report   — a saved parquet query + {param} filters → CSV/parquet
  _run_sql_report       — a SQL saved query / .sql file / inline SQL on a
                          connection (primary + optional secondary) → result store
  substitute_filter_params, _auto_append_sql_where, validate_param_values,
  resolve_business_dates — the parameter contract those engines apply
  _assert_owner_group_membership_rpt — the R6 group-membership rule the
                          finance-report create/update routes reuse

Callers: core.reports.sources (the headless registry), core.scheduler
(scheduled finance reports), api.dashboards_api (tile export),
api.business_reports_api (interactive raw_sql runs).  The module path is
unchanged because those callers and their tests patch
``api.reports_api._run_sql_report`` / ``_run_parquet_report`` by name.

Parameter substitution:
  SQL sources:     {param_name} in SQL → type-safe string replacement
  Parquet sources: {param_name} in filter.value → replaced with param value
  Date shortcuts:  today, yesterday, month_start, -7d, etc. → ISO date
"""

from __future__ import annotations

import logging
import re
from datetime import date as _date, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

import pandas as pd

from fastapi import HTTPException

from core.roles import is_admin_like
from core.sql_filter_wrapper import dialect_for_connection_type

logger = logging.getLogger(__name__)

def _cfg_parquet() -> Path:
    from core.config import paths as _p
    return Path(str(_p.parquet_dir))

def _cfg_uploads(conn_id=None) -> str:
    from core.config import paths as _p
    base = str(_p.upload_dir)
    return f"{base}/{conn_id}" if conn_id else base

_db_manager  = None


def set_report_dependencies(db_manager, ws_manager=None, loop=None):
    """Bind the DB the engines fall back to when a caller passes no ``db``.

    ``ws_manager`` / ``loop`` are accepted and ignored: the websocket progress
    path went with the entity's execute route (FB-60).  The signature is kept
    so ``main.py``, ``main_with_s3.py`` and ``core.daemon_registry`` call it
    unchanged.
    """
    global _db_manager
    _db_manager = db_manager


def _assert_owner_group_membership_rpt(user: dict, owner_group_id) -> None:
    """R6 (2026-08-17): a non-admin may only assign a report to a group THEY
    belong to — otherwise ownership could be handed to (or hidden inside) an
    arbitrary group.  Mirrors ``api.datasets_api._assert_owner_group_membership``
    (the dataset sibling).  Fail-closed on lookup errors."""
    if not owner_group_id or is_admin_like(user or {}):
        return
    username = str((user or {}).get("username", "") or "")
    ok = False
    try:
        db = _require_db()
        ok = bool(username) and int(owner_group_id) in {
            int(g) for g in (db.user_groups_for_username(username) or [])}
    except HTTPException:
        raise
    except Exception as exc:
        logger.warning("report owner_group membership lookup failed "
                       "(fail-closed): %s", exc)
        ok = False
    if not ok:
        raise HTTPException(
            status_code=403,
            detail="You can only assign a report to a group you are a member of")


# ── Parameter substitution ────────────────────────────────────────────────────

# 2026-08-29 - ONE implementation, not two.  This module carried a verbatim
# copy of ``core.parameters.substitute_sql_params`` and its regex, differing
# only in whitespace and comments, while ``core.scheduler`` already imported
# the core one -- the same ``{param}`` placeholder had two maintainers and
# nothing but luck kept them agreeing.  Aliased, not renamed, so every
# existing call site keeps working unchanged.
from core.parameters import PARAM_RE as _PARAM_RE, substitute_sql_params


def substitute_filter_params(filters: list, param_values: dict) -> list:
    """Replace {param_name} in parquet filter values with actual param values."""
    if not filters or not param_values:
        return filters
    result = []
    for f in filters:
        new_f = dict(f)
        val_str = str(f.get("value", ""))
        m = _PARAM_RE.fullmatch(val_str)
        if m:
            param_name = m.group(1)
            if param_name in param_values:
                substituted = param_values[param_name]
                # Empty list/tuple → drop this filter entirely so ALL rows are
                # returned (multiselect with nothing selected = no restriction).
                if isinstance(substituted, (list, tuple)) and len(substituted) == 0:
                    continue
                new_f["value"] = substituted
                # When the substituted value is a non-empty list, upgrade
                # eq → in so the parquet engine can evaluate it correctly.
                if isinstance(substituted, (list, tuple)) and new_f.get("operator") in ("eq", "=", None, ""):
                    new_f["operator"] = "in"
        result.append(new_f)
    return result


def _auto_append_sql_where(sql: str, param_schema: list, param_values: dict,
                           referenced_params: set,
                           dialect: str = "duckdb") -> str:
    """Auto-append WHERE conditions for partition params not already in the SQL.

    If the user selected param values but didn't wire them as {param_name}
    placeholders, we inject WHERE conditions so partition filtering is automatic.
    Skips params already handled by {placeholder} substitution.

    2026-08-09 dialect fix (source-agnostic audit §3): identifiers used to
    be hardcoded ANSI ``"col"``.  Spark SQL (Databricks) treats ``"col"``
    as a STRING LITERAL, so the injected predicate compared two constants
    → constant-false → the report silently returned ZERO rows and was
    marked successful.  ``dialect`` is the target engine's dialect
    (callers resolve it via ``dialect_for_connection_type``, the same
    source the RLS rewrite uses); backtick-quoting engines get backticks,
    everyone else keeps the ANSI double quote.

    2026-09-05 — ``mysql`` is in the backtick set and the old map had no
    mysql key, so a MySQL connection resolved to ``duckdb`` here and got
    ANSI double quotes: on MySQL (without ANSI_QUOTES) ``"col"`` is a
    STRING LITERAL, the same constant-comparison bug this dialect argument
    was added for on Databricks. Resolving through the one vocabulary
    fixes it.
    """
    # 2026-09-05 -- A FOURTH hand-maintained backtick list, retired.
    #
    # This one omitted ``bigquery``, so a BigQuery connection got ANSI
    # double quotes -- and ``"col"`` is a STRING LITERAL there, exactly the
    # constant-comparison bug the ``dialect`` argument was added for on
    # Databricks.  A list of engines that use backticks is a fact about
    # sqlglot's grammars, and keeping a copy of it here meant this file had
    # to be edited every time that set changed.  It was not.
    #
    # ``quote_identifier_for_dialect`` DERIVES the delimiters by probing
    # sqlglot per dialect and then VERIFIES by parsing the rendered text
    # back with the target's own grammar: an identifier that reads back as
    # a literal is refused rather than emitted.  That round trip is what
    # this hand-written function could never do.
    from core.sql_filter_wrapper import (IdentifierRenderError,
                                         quote_identifier_for_dialect)

    def _qcol(name: str) -> str:
        try:
            # always_quote: this call site has ALWAYS emitted a quoted
            # identifier, and the defect was the DELIMITER, not the
            # decision to quote.  Letting the renderer choose bare-where-
            # safe would change the emitted SQL on every dialect -- wider
            # than the bug, and three existing tests correctly caught that.
            return quote_identifier_for_dialect(name, dialect,
                                                always_quote=True)
        except IdentifierRenderError as exc:
            # REFUSE rather than emit something the engine reads as a
            # constant.  This clause is AND-ed into a WHERE: a literal
            # there is a constant-false predicate (silently zero rows) or,
            # negated, a dropped filter (silently MORE rows).  Widening is
            # the direction that must never happen.
            raise ValueError(
                f"Cannot render the parameter column {name!r} for "
                f"'{dialect or 'the target engine'}': {exc}") from exc

    conditions = []
    for p in param_schema:
        name = p["name"]
        if name in referenced_params:
            continue  # already handled via {param_name} substitution
        val = param_values.get(name)
        if val is None or val == "":
            continue

        col = _qcol(name)  # column name = param name (partition columns)
        if isinstance(val, (list, tuple)):
            if len(val) == 0:
                continue
            safe_parts = [str(v).replace("'", "''") for v in val]
            in_list = ", ".join(f"'{v}'" for v in safe_parts)
            conditions.append(f'{col} IN ({in_list})')
        else:
            ptype = p.get("type", "string")
            if ptype == "number":
                try:
                    conditions.append(f'{col} = {float(val)}')
                except (ValueError, TypeError):
                    safe = str(val).replace("'", "''")
                    conditions.append(f"{col} = '{safe}'")
            elif ptype == "boolean":
                bval = "TRUE" if str(val).lower() in ("true", "1", "yes") else "FALSE"
                conditions.append(f'{col} = {bval}')
            else:
                safe = str(val).replace("'", "''")
                conditions.append(f"{col} = '{safe}'")

    if not conditions:
        return sql

    extra_where = " AND ".join(conditions)

    # Wrap original SQL as subquery and apply WHERE on top.
    # This is safe regardless of the original SQL structure (subqueries, CTEs, etc.)
    stripped = sql.strip().rstrip(";")
    return f"SELECT * FROM ({stripped}) _auto_filtered WHERE {extra_where}"


def validate_param_values(param_schema: list, param_values: dict) -> List[str]:
    """Return list of validation error messages (empty = valid)."""
    errors = []
    for p in param_schema:
        name = p["name"]
        val  = param_values.get(name)
        if p.get("required") and (val is None or str(val).strip() == ""):
            errors.append(f"Required parameter '{p.get('label', name)}' is missing")
    return errors


# ── Business date resolver ────────────────────────────────────────────────────
#
# 2026-09-28 -- ONE resolver.  This module carried a byte-for-byte COPY of
# ``core.parameters.resolve_business_dates`` (and of its shortcut list): a
# second implementation of the same vocabulary is a second answer waiting to
# drift, and it could never have learned the business-calendar tokens.  The
# names stay importable from here because callers patch them by this path.
from core.parameters import (  # noqa: E402,F401 -- re-exported
    BUSINESS_DATE_SHORTCUTS, resolve_business_dates,
)


def _require_db():
    """Raise 503 when the DB manager hasn't been injected yet."""
    from api.deps import require_db as _central_require_db
    return _central_require_db()


# ── Internal execution helpers ────────────────────────────────────────────────

def _cast_scalar(v):
    """Try int → float → str so PyArrow type-matching works on numeric columns."""
    s = str(v).strip()
    try:
        return int(s)
    except (ValueError, TypeError):
        pass
    try:
        return float(s)
    except (ValueError, TypeError):
        pass
    return s


def _resolve_virtual_file_refs(files: list, db=None) -> list:
    """Resolve virtual table prefixes to parquet file paths.

    2026-09-26 (F3 round 3) -- ONE resolver, ``core.local_parquet_road
    .resolve_local_ref`` (the road resolves refs itself and keeps the logical
    name for row security); this wrapper stays for callers that want paths
    only.  ``__local__:name`` / ``__materialized__:name`` -> the table's
    parquet path; ``__registered__:`` / ``__federation__:`` / a missing
    table -> ``ValueError`` naming it; a plain path is returned as-is.
    ``db``: explicit DatabaseManager for scheduler-pod callers (2026-08-20);
    falls back to the module global wired by set_report_dependencies.
    """
    from core.local_parquet_road import resolve_local_ref
    db = db if db is not None else _db_manager
    return [resolve_local_ref(f, db, where="report")[0] for f in files]


def _run_parquet_report(report: dict, param_values: dict, row_limit: Optional[int],
                        output_path: str, emit,
                        user_ctx: Optional[Dict[str, Any]] = None,
                        db=None) -> int:
    """Execute the parquet saved query backing this report.

    Phase 131 deep-dive #13 — accepts ``user_ctx`` so RLS policies are
    enforced on parquet-engine reports too.  Mechanism: we build the
    equivalent DuckDB SQL via ``build_query_sql``, call ``secure_sql``,
    and if it rewrites the query (RLS matched) we execute the secured
    SQL directly via DuckDB.  Otherwise we fall through to the existing
    OptimizedParquetEngine path which keeps pyarrow predicate pushdown
    and column pruning.  Trade-off documented inline.
    """
    # 2026-08-20 — explicit db for scheduler-pod callers (the
    # `_exec_business_report` precedent); module-global fallback otherwise.
    db = db if db is not None else _db_manager
    saved_q  = db.get_query(report["saved_query_id"])
    qc_dict  = dict(saved_q["query_config"])

    # 2026-08-05 BR cross-source audit — REFUSE, never silently halve.
    # This engine executes the PRIMARY side only (OptimizedParquetEngine /
    # single DuckDB pass).  A saved query carrying cross-source config
    # (secondary_connection_id / secondary_query_config / secondary_raw_sql)
    # used to run here single-source and report success — the exact defect
    # the 2026-08-04 feed audit found in published views (half the data,
    # certified complete).  UNKNOWN = UNSAFE: refuse with the fix named.
    from core.feed.cross_source_preflight import saved_query_cross_shape
    _cross_shape = saved_query_cross_shape(qc_dict)
    if _cross_shape is not None:
        raise ValueError(
            f"Report {report.get('id')}: saved query {report['saved_query_id']} "
            f"is cross-source ({_cross_shape} shape: it carries "
            f"secondary_connection_id / a secondary SQL side), but the "
            f"parquet report engine executes the primary side only — running "
            f"it would silently emit HALF the data. Fix: back the report "
            f"with a SQL saved query (cross-source supported), or re-save "
            f"the query without its secondary side."
        )

    # Phase 111 resolved virtual table prefixes (__local__:, __materialized__:)
    # to parquet paths HERE, before the engine.  2026-09-26 (F3 round 3): the
    # road resolves them itself (``core.local_parquet_road.resolve_local_refs``,
    # ``db=db`` below) and keeps the LOGICAL NAME on the DuckDB road -- a
    # path has no name for a row-security policy to match, so a governed
    # local table read through a report came back unfiltered.

    # ── Step 1: find which params are handled by existing {placeholder} filters ──
    original_filters = list(qc_dict.get("filters") or [])
    handled_by_placeholder: set = set()
    for f in original_filters:
        m = _PARAM_RE.fullmatch(str(f.get("value", "")))
        if m:
            handled_by_placeholder.add(m.group(1))

    # ── Step 2: substitute {param_name} placeholders in existing filters ────────
    if qc_dict.get("filters"):
        qc_dict["filters"] = substitute_filter_params(qc_dict["filters"], param_values)
    else:
        qc_dict["filters"] = []

    # ── Step 3: auto-apply any report param not already handled via placeholder ─
    # This lets users add parameters by column name without needing to pre-wire
    # {param_name} placeholders in the saved query's filter definitions.
    for p in (report.get("parameters") or []):
        name = p["name"]
        if name in handled_by_placeholder:
            continue  # already handled via {param_name} substitution
        val = param_values.get(name)
        if val is None or val == "":
            continue  # nothing provided

        if isinstance(val, (list, tuple)):
            if len(val) == 0:
                continue  # empty list = no restriction (all rows)
            # Cast each element for PyArrow type compatibility
            cast_vals = [_cast_scalar(v) for v in val]
            if len(cast_vals) == 1:
                qc_dict["filters"].append({"column": name, "operator": "eq", "value": cast_vals[0]})
            else:
                qc_dict["filters"].append({"column": name, "operator": "in", "value": cast_vals})
        else:
            qc_dict["filters"].append({"column": name, "operator": "eq", "value": _cast_scalar(val)})

    # Apply row_limit override
    if row_limit:
        qc_dict["limit"] = row_limit

    # ── R7 (2026-08-17): SQL-connector-backed saved query ────────────────────
    # A saved query built against a SQL connector (Trino/Starburst/…) stores
    # ``connection_id`` + a table reference (``catalog.schema.table``) in
    # ``files``.  This function used to hand that reference to
    # OptimizedParquetEngine as a parquet PATH — every such report failed.
    # Route it through the connector instead, the same way
    # core.scheduler._exec_parquet_query already does for scheduled runs
    # (build SQL via parquet_engine_v2, stream via execute_sql_to_parquet).
    _sq_conn_id = qc_dict.get("connection_id")
    if _sq_conn_id:
        _sq_conn = db.get_connection_raw(_sq_conn_id)
        if _sq_conn and _sq_conn.get("connection_type", "") in _SQL_CONN_TYPES:
            return _run_sql_connector_saved_query(
                report, qc_dict, _sq_conn, output_path, emit, user_ctx)

    # 2026-09-26 (F3 / M4) -- ONE local parquet road.  This door used to
    # build ``optimized_engine.QueryConfig`` by hand (six fields; a saved
    # query with GROUP BY / DISTINCT / OR / HAVING / offset ran WITHOUT them
    # and showed detail rows under a green status, M0 refused them) and
    # carried its own row-security bridge: build the DuckDB SQL, ask
    # ``secure_sql`` to rewrite, run on DuckDB only when a policy matched.
    # Both decisions now live in ``core.local_parquet_road.run_local_parquet``:
    # the six-field shape keeps the optimized engine (its predicate pushdown
    # and, on purpose, NO engine limit -- see the 2026-09-15 note below);
    # any shape beyond it, and any query a policy rewrites, runs on DuckDB.
    #
    # 2026-09-15 -- DELIBERATELY NO engine ``limit`` on this door (kept).
    # The note of that day says this path applies the author's bound
    # downstream and needs the untruncated frame for an honest "3 of 10"
    # disclosure.  ONE answer per door: the DuckDB road is uncapped here
    # too (the row-security branch it replaces wrapped the secured SQL in
    # ``LIMIT {row_limit}`` -- two cap answers on one door).  Whether this
    # door should cap at all is an owner question recorded in
    # docs/DECOMPOSITION_PLAN_2026_09_26.html (M4, "open").
    #
    # Row security: gated on ``row_security.enabled`` (ON by default since
    # 2026-09-26, F0).  A rewrite that FAILS fails CLOSED -- an RLS-enabled
    # deployment must produce SQL-buildable queries, because the alternative
    # is running without policy enforcement.  A no-op rewrite hands back the
    # SQL byte-identical, so the road only switches engines when a policy
    # REALLY applied (it records ``row_security`` as the reason).
    _rs_user = user_ctx or _background_principal(report)
    _rls_active = False
    try:
        from core.row_security.api import _is_enabled as _rs_is_enabled
        _rls_active = bool(_rs_is_enabled())
    except Exception:
        _rls_active = False

    _secure = None
    if _rls_active:
        def _secure(sql: str) -> str:
            try:
                from core.row_security import secure_sql as _rs_secure
                return _rs_secure(
                    sql, dialect="duckdb",
                    user_ctx=_rs_user, connection_id=None,
                    request_id=str(report.get("id") or ""),
                )
            except Exception as _rs_exc:
                # RLS ON: fail closed.  Never run the fast path around a
                # policy we could not apply.
                raise ValueError(
                    f"Row-security enforcement failed for parquet report {report.get('id')}: {_rs_exc}"
                )

    emit({"type": "execution_progress", "data": {"status": "processing"}})

    from core.local_parquet_road import run_local_parquet, run_s3_parquet, OPTIMIZED as _OPT
    _where = f"report {report.get('id')} (saved query {report.get('saved_query_id')})"
    # 2026-09-26 (F3 round 3) -- a saved query on an S3 connection takes the
    # S3 road (the one resolver, registered tables as views named by their
    # registered name so a policy matches).  Until today it fell into the
    # local road with S3 keys and failed on a missing local file.
    _s3_conn = None
    if _sq_conn_id:
        _c = db.get_connection_raw(_sq_conn_id)
        if _c and str(_c.get("connection_type") or "").lower() == "s3":
            _s3_conn = _c
    if _s3_conn is not None:
        _run = run_s3_parquet(
            qc_dict, _s3_conn, where=_where, secure=_secure, apply_limit=False,
            request_id=str(report.get("id") or ""))
    else:
        _run = run_local_parquet(
            qc_dict, data_dir=str(_cfg_parquet()), where=_where,
            secure=_secure, apply_limit=False,
            request_id=str(report.get("id") or ""), db=db)
    if _run.engine != _OPT:
        logger.info("[reports] %s ran on duckdb (%s)", _where, ",".join(_run.reasons))
    chunks = list(_run.chunks)
    df = pd.concat(chunks, ignore_index=True) if chunks else pd.DataFrame()

    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    if output_path.endswith(".parquet"):
        # Phase 154 strategic chokepoint -- bounded parquet write.
        from core.connector_to_parquet import df_to_parquet_streaming
        df_to_parquet_streaming(df, output_path)
    else:
        df.to_csv(output_path, index=False)
    return len(df)


def _run_sql_connector_saved_query(report: dict, qc_dict: dict, conn_record: dict,
                                   output_path: str, emit,
                                   user_ctx: Optional[Dict[str, Any]] = None) -> int:
    """R7 (2026-08-17): execute a SQL-connector-backed SAVED QUERY as a report.

    Mirrors ``core.scheduler._exec_parquet_query``'s connector branch (the
    path that already worked for scheduled runs): the saved query's
    query_config is compiled to SQL by the parquet engine's SQL builder and
    streamed through the Phase-154 ``execute_sql_to_parquet`` chokepoint.

    A falsy ``qc_dict['limit']`` means UNLIMITED — both builders omit LIMIT
    entirely when it is falsy; never fold 0/None into a cap (the
    ``or 1_000_000`` fold was removed from the scheduler on 2026-08-14 after
    it silently truncated a 70M-row feed).

    Row-security is applied to the built SQL with the CONNECTOR's dialect —
    same hard-fail contract as ``_run_sql_report`` (a policy failure refuses
    the run rather than running unfiltered).
    """
    from core.connectors import get_connector
    from core.parquet_engine_v2 import ParquetQueryEngine as _PQE

    # 2026-09-05 round 2 -- the SAME chokepoint the interactive run, the
    # preview, the published-view runner and the scheduler use.  This was
    # ``files[0]`` verbatim, so a report over ``__registered__:sales`` on a
    # SQL connector rendered ``FROM sales AS __registered__`` and reported
    # a DIFFERENT TABLE's rows as the report's answer.  Refuses rather than
    # de-qualifies, for the same reason the scheduler does: a report is
    # DELIVERED, so a wrong answer under a green status is the one outcome
    # nobody would catch.  ``QueryNotExpressible`` is a ValueError, the
    # same shape the missing-table raise below already used.
    from core.parquet_engine_v2 import native_from_ref as _native_from_ref_rpt
    table_ref = _native_from_ref_rpt(
        qc_dict.get("files"), qc_dict.get("joins"),
        str(conn_record.get("connection_type", "")).lower())
    if table_ref is None:
        table_ref = (qc_dict.get("files") or [None])[0]
    if not table_ref:
        raise ValueError(
            f"Report {report.get('id')}: SQL-connector saved query has no "
            "table reference in query_config.files")

    # 2026-09-26 (F3 / M1, D8) -- EVERY stored field crosses through the ONE
    # converter.  This site named nine of the seventeen fields by hand and
    # passed ``aggregations`` / ``joins`` as the stored dicts, which the
    # builder reads as objects (``agg.function``): a report over a saved
    # query with a SUM died here with AttributeError (the scheduler's D1,
    # on the report lane).  ``distinct`` / ``having`` / ``filter_logic`` and
    # the computed, CASE and window columns were not passed at all.  Falsy
    # limit still means UNLIMITED -- the converter carries it verbatim.
    from core.query_converter import engine_config_from_stored
    engine_cfg = engine_config_from_stored(
        qc_dict, where=f"report {report.get('id')} (saved query "
                       f"{report.get('saved_query_id')})")
    engine_cfg.files = [table_ref]
    # SQL build only — no file I/O happens for a bare build.
    # 2026-08-19 -- pass the TARGET dialect.  Without it the builder emits
    # DuckDB shape (double-quoted identifiers + LIMIT), which on Databricks
    # makes every identifier a STRING LITERAL and on Oracle is ORA-00933.
    # 2026-08-19 -- TYPE the filters here too.  Wired at only one dispatch,
    # a date-filtered saved query that ran interactively still failed the
    # moment it was SCHEDULED ("Cannot apply operator: date = varchar").
    # The connector is constructed HERE rather than below, because the type
    # lookup needs it before the SQL is built.  Construction is lazy in every
    # connector (the socket opens on first use), so this is only a reorder.
    connector = get_connector(conn_record["connection_type"],
                              conn_record.get("config", {}))
    from core.column_types import annotate_from_connector as _annot
    _annot(engine_cfg.filters, connector, table_ref,
           conn_record.get("config") or {}, conn_record.get("id"))
    sql_str = _PQE(base_path=".").build_query_sql(
        engine_cfg, table_ref,
        dialect=str(conn_record.get("connection_type", "")).lower())

    _rs_user = user_ctx or _background_principal(report)
    try:
        from core.row_security import secure_sql as _rs_secure
        _dialect = dialect_for_connection_type(
            conn_record.get("connection_type"))
        sql_str = _rs_secure(
            sql_str, dialect=_dialect, user_ctx=_rs_user,
            connection_id=conn_record.get("id"),
            request_id=str(report.get("id") or ""),
        )
    except Exception as _rs_exc:
        raise ValueError(
            f"Row-security enforcement failed for report {report.get('id')}: {_rs_exc}")

    emit({"type": "execution_progress", "data": {"status": "querying"}})

    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)

    from core.connector_to_parquet import execute_sql_to_parquet
    try:
        if output_path.endswith(".csv"):
            # Sync download path wants CSV — stream to a sibling parquet
            # first (bounded memory), then convert.
            _tmp_pq = output_path[:-4] + ".__sqlconn__.parquet"
            meta = execute_sql_to_parquet(connector, sql_str, _tmp_pq,
                                          chunk_size=50_000)
            try:
                pd.read_parquet(_tmp_pq).to_csv(output_path, index=False)
            finally:
                try:
                    Path(_tmp_pq).unlink()
                except Exception as _rm_exc:
                    logger.debug("temp parquet cleanup failed for %s: %s",
                                 _tmp_pq, _rm_exc)
        else:
            meta = execute_sql_to_parquet(connector, sql_str, output_path,
                                          chunk_size=50_000)
    finally:
        # execute_sql_to_parquet deliberately does NOT close the connector
        # (caller-owned lifecycle) — we own it here, so close it.
        try:
            connector.close()
        except Exception as _close_exc:
            logger.debug("connector close failed after report export: %s",
                         _close_exc)

    return int(meta.get("total_rows", 0) or 0)


_FILE_CONN_TYPES = frozenset({"s3", "local", "upload"})
# 2026-09-05 -- was a literal frozenset restating the same six types.  It
# is now the registry's own answer to "is this a SQL connector", DERIVED
# from core.connectors._REGISTRY: this file used to be one of four
# disagreeing vocabularies for that one question, and a set spelled out
# here can silently claim (or omit) a type the connector factory does
# not agree with.  Same value today -- the point is that it stays the
# same value tomorrow.
from core.connectors import (  # noqa: E402 -- grouped with the sets it replaced
    SQL_EXECUTABLE_TYPES as _SQL_CONN_TYPES,
)


def _resolve_data_dir(conn: dict) -> str:
    """Resolve the data directory for a file-based connection."""
    ctype = conn["connection_type"]
    _pq = str(_cfg_parquet())
    if ctype == "s3":
        return conn["config"].get("bucket", _pq)
    elif ctype == "local":
        return conn["config"].get("path", _pq)
    elif ctype == "upload":
        return _cfg_uploads(conn['id'])
    return _pq


def _resolve_primary_connection(report: dict, sql_q: Optional[dict],
                                db=None) -> dict:
    """Resolve which Connection to use for the primary SQL query.

    Resolution order (Phase 24A + 24B):
      1. report['connection_override_id']  — explicit per-report override
      2. sql_q['primary_connection_id']    — existing default (unchanged behaviour)
      Then: apply active ConnectionProfile mapping (Phase 24B; no-op when no profile active)

    Phase 131 deep-dive #13: ``sql_q`` may be None when the report runs
    a SqlFile source (sql_override + connection_override_id provided
    inline by _as_legacy_report).  We require connection_override_id in
    that case — there's nothing else to fall back on.

    Raises ValueError if the resolved connection does not exist or
    cannot be determined.
    """
    override_id = report.get("connection_override_id")
    if override_id:
        base_conn_id = override_id
    elif sql_q and sql_q.get("primary_connection_id"):
        base_conn_id = sql_q["primary_connection_id"]
    else:
        raise ValueError(
            "Cannot resolve primary connection: no connection_override_id "
            "on the report and no sql_saved_query was loaded"
        )
    # Phase 24B: apply active profile substitution (returns base_conn_id unchanged if no profile)
    db = db if db is not None else _db_manager
    final_conn_id = db.resolve_connection_via_profile(base_conn_id)
    conn = db.get_connection_raw(final_conn_id)
    if not conn:
        raise ValueError(f"Connection {final_conn_id} not found")
    return conn


# 2026-09-05 -- ``_RS_DIALECT_MAP`` lived here and was the ORIGIN every other
# copy in the codebase cited.  It knew nine connection types; it did not know
# postgres, mysql, sqlserver, redshift or bigquery, so a report on any of
# those had its row-security predicate, its ``${user.*}`` rendering and its
# auto-appended WHERE all built in DUCKDB grammar and shipped to an engine
# that is not DuckDB.  A missing key is not a neutral omission: it is a wrong
# answer that looks like a default.  Every site below now asks
# ``core.sql_filter_wrapper.dialect_for_connection_type`` -- one vocabulary,
# and ``s3`` / ``local`` / ``upload`` still resolve to duckdb via its
# fallback, which is the same answer those three entries spelled out.


def _report_owner(report: dict) -> Optional[str]:
    """Who owns this report — across BOTH record vocabularies.

    2026-08-29.  Every background path read ``report["owner"]``, and NEITHER
    record provides that key: a legacy ``Report.to_dict()`` names the field
    ``created_by`` (core/db/models.py), and ``_as_legacy_report`` did not copy
    a BusinessReport's ``owner`` across.  So the owner was ALWAYS None, and
    every fallback that depends on it silently used its literal default --
    the scheduled principal was the string "scheduled" rather than a person,
    and the ``${user.*}`` owner re-resolution could never fire, rendering an
    empty scope and delivering ZERO ROWS marked completed.

    The view gate at the top of this module already reads both spellings; this
    is the same rule, in one place, for the execution paths.
    """
    return report.get("owner") or report.get("created_by") or None


def _background_principal(report: dict) -> Dict[str, Any]:
    """The principal a background run executes as — for row-security AND for
    ``${user.*}`` rendering, so one run gives one answer to "who is this".

    2026-08-29.  This was a hand-rolled placeholder carrying
    ``rls_unresolved``, and that flag makes the rewriter REFUSE every governed
    table.  So a scheduled report over a governed table could never succeed on
    this path, while ``_exec_business_report`` resolved the owner properly and
    did — the same report, scheduled two ways, one working and one impossible.
    Worse, the owner WAS being resolved in the same execution for rendering
    and then withheld from row-security.

    Resolution failure still returns the MARKED placeholder, and that marker
    is load-bearing rather than decorative: an unresolved principal matches no
    grant, and this engine ships an unmatched table UNFILTERED (see the
    comment in row_security/rewriter.py).  Stripping a principal's groups
    therefore WIDENS.  This change converts only PROVABLE owner scope into
    filtered rows; it can never turn a refusal into an unfiltered read.
    """
    owner = _report_owner(report)
    # Resolve EAGERLY only when row-security could actually rewrite: that is
    # the only consumer that needs the real scope up front.  When it could
    # not -- the engine off, or (2026-09-26, F0: ON by default now) armed
    # over a policy set that is readable and EMPTY -- the placeholder is
    # equivalent for row-security, and ``${user.*}`` still resolves the
    # owner LAZILY through ReportPrincipal, so a scheduled report with no
    # variables costs no directory lookup at all.  Paying for one on every
    # background run regardless would be a per-run round trip bought for
    # nothing.  An UNREADABLE policy store resolves eagerly: the rewriter
    # refuses a governed table for an unresolved principal, and resolving
    # can only give it more to go on -- never less.
    _rls_on = True
    try:
        from core.row_security.cache_scope import shared_slot_is_safe
        _rls_on = not shared_slot_is_safe()
    except Exception:
        _rls_on = True
    if owner and _rls_on:
        try:
            from core.scheduler import _resolve_owner_user_ctx
            resolved = _resolve_owner_user_ctx(owner)
            if resolved:
                return resolved
        except Exception as exc:
            logger.warning(
                "[reports] owner scope resolution failed for %r — running at "
                "the unresolved placeholder, which REFUSES governed tables "
                "rather than reading them unfiltered: %s", owner, exc)
    return {"username": owner or "scheduled", "role": "viewer",
            "rls_unresolved": True}


def _run_sql_report(report: dict, param_values: dict, row_limit: Optional[int],
                    execution_id: str, emit,
                    user_ctx: Optional[Dict[str, Any]] = None,
                    db=None) -> int:
    """Execute the SQL saved query backing this report.

    Phase 131 deep-dive #10 — accepts `user_ctx` so row-security policies
    (enterprise_reports_api / core.row_security) are enforced.  Previously
    secure_sql was never called for reports — RLS policies were defined
    but silently bypassed.  When user_ctx is None (background / scheduled
    runs), the report owner's identity is used as the principal.

    Supports three modes:
      1. Single SQL source
      2. Cross-source SQL-to-SQL join
      3. Hybrid SQL-to-Parquet join (Starburst + S3)

    RESULT CACHE (2026-09-07).  This function carries the raw-SQL road's
    ONE cache consult, between "every side's SQL is final and post-RLS"
    and "pick an engine".  ``core.dataset_result_cache`` had covered only
    the FederationEngine road, which a ``raw_sql`` business report never
    enters -- so the identical Starburst / Snowflake / Oracle /
    cross-source report re-executed on every run.  The write-through is in
    ``_finish``, the single return path, so it cannot be wired into one
    branch and forgotten in another.  See
    ``dataset_result_cache.build_identity_for_sql_report`` for what is in
    the key and why a source with nothing to fingerprint is deliberately
    neither stored nor served.
    """
    import os as _os_rc
    from core.cross_source_engine import (
        execute_single_source_query, execute_cross_source_sql,
    )
    # 2026-08-09 cross-pod completion #2: the engines used to DEFAULT
    # output_dir to a hardcoded pod-local path while these call sites
    # omitted it — the artifact landed where no other pod (and no BR sync
    # reader, business_reports_api._execute_raw_sql_report) could find it.
    # Pass the configured SHARED downloads dir explicitly; the engine
    # default now also resolves from config as the belt-and-braces.
    from core.config import paths as _csx_paths
    _shared_output_dir = str(_csx_paths.downloads_dir)

    # Phase 131 deep-dive #13: sql_saved_query_id may be None when the
    # report is backed by a published .sql file (resolved by
    # _as_legacy_report → sql_override + connection_override_id).
    # 2026-08-20 — explicit db for scheduler-pod callers (the
    # `_exec_business_report` precedent); module-global fallback otherwise.
    db = db if db is not None else _db_manager
    _sql_q_id = report.get("sql_saved_query_id")
    sql_q = db.get_sql_query(_sql_q_id) if _sql_q_id else None
    if not sql_q and not report.get("sql_override"):
        raise ValueError(
            f"Report {report.get('id')}: no SQL source — missing both "
            "sql_saved_query and sql_override"
        )

    primary_conn = _resolve_primary_connection(report, sql_q, db=db)  # Phase 24A/24B

    # Use sql_override if set, otherwise use the saved query's SQL
    raw_sql = report.get("sql_override") or sql_q["primary_sql"]

    # The principal for THIS execution.  Hoisted above the substitution steps
    # (2026-08-29) because Step 0 needs it too — it is a pure expression with
    # no dependency on the SQL, so the move is behaviour-preserving.  When the
    # caller supplies none (scheduled / background runs) the report OWNER is
    # the principal, which is what makes ${user.*} and row-security agree
    # instead of resolving against two different identities.
    _rs_user = user_ctx or _background_principal(report)

    # ── Step 0: resolve ${user.*} against the live principal ─────────────────
    # Must precede Step 1: substitute_sql_params matches {name} where name is
    # [a-zA-Z_][a-zA-Z0-9_]*, which cannot match {user.groups} (the dot), so
    # the two are independent today — ordering the general renderer first
    # keeps them independent if that pattern is ever widened.
    # No-op (byte-identical) for SQL that references no ${user.*}.
    from core.reports.user_sql_vars import (ReportPrincipal,
                                            resolve_user_sql_vars)
    # ``_rs_user`` carries ``rls_unresolved`` on background runs, and that flag
    # is what tells the renderer to re-resolve the OWNER's real scope: a
    # placeholder's empty group list is the placeholder's emptiness, not a fact
    # about the owner, and rendering it as one delivers an empty file labelled
    # success.  Passing the same object row-security gets keeps the two
    # agreeing on who this is even when the owner cannot be resolved.
    # ONE principal for this execution, shared by both SQL sides below: a
    # cross-source report must not resolve its two halves against two
    # separately-looked-up identities.  Resolves lazily on first use.
    _sql_principal = ReportPrincipal(_rs_user, _report_owner(report))
    # The engine this SQL will actually run on: a variable must render to
    # something that engine ACCEPTS, not merely to standard SQL.
    _pri_dialect_for_vars = dialect_for_connection_type(
        primary_conn.get("connection_type"))
    resolved_sql = resolve_user_sql_vars(
        raw_sql, _sql_principal,
        label=f"report {report.get('id')} primary SQL",
        dialect=_pri_dialect_for_vars)

    # ── Step 1: substitute {param_name} placeholders in SQL ──────────────────
    primary_sql = substitute_sql_params(resolved_sql, param_values, report["parameters"])

    # ── Step 2: auto-append WHERE for unreferenced partition params ───────────
    # Same concept as Parquet Step 3: if a param has a value but isn't wired as
    # {param_name} in the SQL, inject it as a WHERE condition automatically.
    # 2026-08-09: quote injected identifiers in the TARGET engine's dialect
    # (Databricks reads "col" as a string literal → constant-false predicate
    # → silent zero rows).  Same dialect map the RLS rewrite below uses.
    _pri_append_dialect = dialect_for_connection_type(
        primary_conn.get("connection_type"))
    referenced_params = set(_PARAM_RE.findall(raw_sql))
    primary_sql = _auto_append_sql_where(primary_sql, report.get("parameters") or [],
                                          param_values, referenced_params,
                                          dialect=_pri_append_dialect)

    # ── Step 2b: Phase 131 deep-dive #10 — apply row-security ────────────────
    # Rewrites SQL to enforce row + column policies defined in
    # enterprise_reports_api.  No-op when feature is disabled, when user
    # is admin, or when no policy matches.  Wrapped in defensive try so
    # a policy parser hiccup doesn't take down the report; security
    # team can audit via row_security_audit_log table.
    # (``_rs_user`` is resolved above, before Step 0.)
    try:
        from core.row_security import secure_sql as _rs_secure
        _pri_dialect = dialect_for_connection_type(
            primary_conn.get("connection_type"))
        primary_sql = _rs_secure(
            primary_sql, dialect=_pri_dialect,
            user_ctx=_rs_user, connection_id=primary_conn.get("id"),
            request_id=execution_id,
        )
    except Exception as _rs_exc:
        # Hard-fail on policy enforcement failures (matches sql_query_api pattern).
        # Silent passes would defeat the security purpose.
        raise ValueError(f"Row-security enforcement failed for report {report.get('id')}: {_rs_exc}")

    emit({"type": "execution_progress", "data": {"status": "querying"}})

    # 2026-08-11 — the cross-source spec may come from EITHER source:
    #   * a SqlSavedQuery (``sql_q``) — the long-standing path;
    #   * the REPORT itself, when it is backed by a cross-connection ``.sql``
    #     file (business_reports_api._as_legacy_report lifts the file's
    #     secondary section + secondary_connection_id/combine_mode/join_config
    #     onto the legacy dict).  That shape used to be REFUSED by two gates.
    # Field names are identical in both, so one spec serves both branches.
    _cross_src = (sql_q if (sql_q and sql_q.get("secondary_connection_id")
                            and sql_q.get("secondary_sql")) else None)
    if _cross_src is None and report.get("secondary_connection_id") \
            and report.get("secondary_sql"):
        _cross_src = report
    is_cross = _cross_src is not None

    if is_cross:
        sec_id = db.resolve_connection_via_profile(_cross_src["secondary_connection_id"])
        secondary_conn = db.get_connection_raw(sec_id)
        if not secondary_conn:
            # NEVER fall through to the single-source branch here: that would
            # run the primary side and report it as the whole answer.
            raise ValueError(
                f"Report {report.get('id')}: secondary connection "
                f"{_cross_src['secondary_connection_id']} could not be "
                f"resolved — refusing to emit only the primary side's rows.")
        raw_secondary = _cross_src["secondary_sql"]
        # Step 0 for the OTHER side.  A cross-source report that resolved only
        # its primary SQL would ship the unresolved literal into the join —
        # the "fixed in one of two siblings" shape.  Same principal, so both
        # halves of one report see one identity.
        resolved_secondary = resolve_user_sql_vars(
            raw_secondary, _sql_principal,
            label=f"report {report.get('id')} secondary SQL",
            dialect=dialect_for_connection_type(
                secondary_conn.get("connection_type")))
        secondary_sql = substitute_sql_params(
            resolved_secondary, param_values, report["parameters"]
        )
        # Auto-WHERE for secondary SQL too
        # 2026-08-09: same dialect-aware quoting as the primary side.
        _sec_append_dialect = dialect_for_connection_type(
            secondary_conn.get("connection_type"))
        sec_referenced = set(_PARAM_RE.findall(raw_secondary))
        secondary_sql = _auto_append_sql_where(secondary_sql, report.get("parameters") or [],
                                                param_values, sec_referenced,
                                                dialect=_sec_append_dialect)

        # Phase 131 deep-dive #10 — RLS rewrite for the secondary SQL
        # (cross-source path).  Same policy enforcement as primary.
        try:
            from core.row_security import secure_sql as _rs_secure
            _sec_dialect = dialect_for_connection_type(
                secondary_conn.get("connection_type"))
            secondary_sql = _rs_secure(
                secondary_sql, dialect=_sec_dialect,
                user_ctx=_rs_user, connection_id=secondary_conn.get("id"),
                request_id=execution_id,
            )
        except Exception as _rs_exc:
            raise ValueError(f"Row-security enforcement failed for report {report.get('id')} secondary: {_rs_exc}")

        pri_type = primary_conn["connection_type"]
        sec_type = secondary_conn["connection_type"]
        pri_is_sql  = pri_type in _SQL_CONN_TYPES
        sec_is_sql  = sec_type in _SQL_CONN_TYPES
        sec_is_file = sec_type in _FILE_CONN_TYPES
        pri_is_file = pri_type in _FILE_CONN_TYPES

        _combine_mode = (_cross_src.get("combine_mode") or "").strip().lower()
    else:
        secondary_conn = None
        secondary_sql = ""
        _combine_mode = ""

    # ══ RESULT CACHE (2026-09-07) — THE ONE consult on the raw-SQL road ══
    #
    # Placed HERE and nowhere else because this is the single point at
    # which every side's SQL is FINAL: ${user.*} resolved (Step 0), params
    # substituted (Step 1), partition WHEREs auto-appended (Step 2) and
    # ``row_security.secure_sql`` applied to BOTH sides (Step 2b) -- and
    # no engine has been chosen yet, so one gate serves the single-source,
    # cross-source, hybrid and cross-connection-combine branches alike.
    #
    # AFTER the RLS rewrite is not an accident: a cached body must not be
    # able to outlive the policy that shaped it.  The principal is in the
    # key UNCONDITIONALLY (never gated on row_security.enabled), because a
    # scope a config flag can switch off is how one slot comes to be
    # shared by two principals.
    #
    # ``core.dataset_result_cache`` covered ONLY the FederationEngine road
    # (``8379f4ff``); a raw_sql report never reaches that function.  Same
    # gate implementation, same key builder, same fail-the-gate freshness
    # posture -- see ``build_identity_for_sql_report``.
    _rc_identity = None
    _rc_key = ""
    _rc_out = _os_rc.path.join(_shared_output_dir, f"{execution_id}.parquet")
    try:
        from core import dataset_result_cache as _drc
        _rc_identity = _drc.build_identity_for_sql_report(
            report_id=report.get("id"),
            primary_sql=primary_sql,
            primary_connection_id=primary_conn.get("id"),
            secondary_sql=secondary_sql,
            secondary_connection_id=(secondary_conn or {}).get("id"),
            combine_mode=_combine_mode,
            join_config=(_cross_src or {}).get("join_config") or {},
            row_limit=row_limit,
            user_ctx=_rs_user,
        )
        _rc_dec = _drc.lookup(identity=_rc_identity, output_path=_rc_out,
                              db_manager=db)
        _rc_key = _rc_dec.key
        if _rc_dec.served:
            # The artifact is at the path every caller of this function
            # locates by execution_id, so a hit is indistinguishable from
            # a run except in cost -- and it DISCLOSES itself on the wire.
            emit({"type": "execution_progress",
                  "data": {"status": "completed",
                            "rows": _rc_dec.row_count,
                            "cache_hit": True,
                            "cache_freshness": _rc_dec.freshness,
                            "cache_age_seconds": _rc_dec.age_seconds}})
            logger.info(
                "[%s] raw-SQL report %s served from result cache: "
                "%d rows, freshness=%s age=%.1fs — no connector touched",
                execution_id, report.get("id"), _rc_dec.row_count,
                _rc_dec.freshness, _rc_dec.age_seconds)
            return int(_rc_dec.row_count)
    except Exception as _rc_exc:
        # Fail-open in BOTH directions: a broken cache must not break a
        # report, and a miss must cost nothing but this try block.
        logger.debug("[%s] raw-SQL result-cache consult skipped: %s",
                     execution_id, _rc_exc)

    def _finish(total_rows: int) -> int:
        """THE single return path, so the write-through cannot be wired
        into one of the two roads and forgotten on the other.

        Best-effort: the answer is already produced, so a store failure
        costs a future miss and nothing else.  The identity is the SAME
        object the lookup used, so the store key cannot drift from the
        lookup key.
        """
        if _rc_identity is not None:
            try:
                if _os_rc.path.exists(_rc_out):
                    from core import dataset_result_cache as _drc_w
                    _cols_n = 0
                    try:
                        import pyarrow.parquet as _pq_w
                        _cols_n = len(_pq_w.ParquetFile(_rc_out).schema.names)
                    except Exception:
                        _cols_n = 0
                    _drc_w.store(identity=_rc_identity, output_path=_rc_out,
                                  row_count=int(total_rows or 0),
                                  column_count=_cols_n,
                                  source_tables=[], db_manager=db,
                                  key=_rc_key)
                else:
                    logger.debug(
                        "[%s] raw-SQL result not stored: no artifact at %s",
                        execution_id, _rc_out)
            except Exception as _rc_w_exc:
                logger.debug("[%s] raw-SQL result-cache store skipped: %s",
                             execution_id, _rc_w_exc)
        return int(total_rows or 0)

    if is_cross:
        # ── THE cross-source capability (2026-10-04) ────────────────────────
        # One road for every combination -- SQL x SQL, SQL x file, file x SQL,
        # file x file -- through core.executors.cross_source_combine: each
        # side on its own engine, combined in DuckDB (it spills), never a
        # one-sided answer.  This replaced FOUR branches: the feed-shaped
        # combine below and three in-memory ``pd.merge`` engines
        # (execute_cross_source_query / execute_hybrid_query, deleted) which
        # had no UNION and capped EACH SIDE at row_limit before joining.
        #
        # ``row_limit`` now bounds the COMBINED result only (a cut side
        # changes the answer invisibly; a cut result is a disclosable cut).
        #
        # RESULT SHAPE is kept per spelling, because saved layouts address
        # columns by name:
        #   * combine_mode union/join (the .sql-file reports) -- the combine
        #     shape they always had (right keys dropped, ``_primary`` /
        #     ``_secondary``);
        #   * no combine_mode (a SQL saved query) -- the pandas ``merge``
        #     shape those reports always had (``_a`` / ``_b``, ``_sql`` /
        #     ``_parquet`` for a hybrid; same-named keys folded to one).
        import json as _x_json
        from core.executors.cross_source_combine import (
            CrossSourceRefusal, combine_spec, parquet_config_producer,
            saved_sql_query_spec)

        _x_jc = _cross_src.get("join_config") or {}
        try:
            if _cross_src is sql_q:
                # A SQL-page saved query: ITS spec, the one the SQL page and
                # a scheduled run use -- one answer for one saved query.
                _x_spec = saved_sql_query_spec(
                    _cross_src.get("combine_mode"), _x_jc,
                    hybrid=bool((pri_is_sql and sec_is_file)
                                or (pri_is_file and sec_is_sql)))
            else:
                # A cross-connection .sql file: the feed's spec (union by
                # default, the combine shape) -- the same file feeds and
                # reports, so it combines the same way in both.
                _x_spec = combine_spec(_combine_mode, _x_jc,
                                       default_mode="union")
        except CrossSourceRefusal as _x_ref:
            raise ValueError(f"Report {report.get('id')}: {_x_ref}")

        def _file_side(conn, text, label):
            """A FILE side's text is either SQL over its registered tables /
            files (runs as a statement) or -- the legacy hybrid spelling --
            a JSON query config / a bare file name (runs as a config)."""
            t = (text or "").strip()
            if t.startswith("{"):
                try:
                    qc = _x_json.loads(t)
                except (ValueError, TypeError):
                    qc = {"files": [t]}
            elif t.split(None, 1)[:1] and t.split(None, 1)[0].upper() in (
                    "SELECT", "WITH", "(", "VALUES", "FROM"):
                return text, None
            else:
                qc = {"files": [t]}
            return None, parquet_config_producer(
                qc, _resolve_data_dir(conn), db=db, request_id=execution_id,
                where=f"report {report.get('id')} {label} parquet side")

        _p_sql, _p_prod = ((primary_sql, None) if not pri_is_file
                           else _file_side(primary_conn, primary_sql, "primary"))
        _s_sql, _s_prod = ((secondary_sql, None) if not sec_is_file
                           else _file_side(secondary_conn, secondary_sql,
                                           "secondary"))
        result = execute_cross_source_sql(
            primary_conn=primary_conn, primary_sql=_p_sql,
            secondary_conn=secondary_conn, secondary_sql=_s_sql,
            primary_producer=_p_prod, secondary_producer=_s_prod,
            spec=_x_spec,
            output_dir=_shared_output_dir,
            execution_id=execution_id,
            # Bounds the COMBINED result only -- never a side.
            row_limit=row_limit,
            db_manager=db,
        )
        emit({"type": "execution_progress",
              "data": {"status": "combined", "rows": result.total_rows,
                       "cross_source": getattr(result, "disclosure", None)}})
    else:
        # Phase 131 deep-dive #11 — pass user_ctx so S3/Athena reports
        # work for the triggering user's portal session (closes the
        # credential gap deferred from deep-dive #9).
        result = execute_single_source_query(
            conn_type=primary_conn["connection_type"],
            conn_config=primary_conn["config"],
            sql=primary_sql,
            output_dir=_shared_output_dir,
            execution_id=execution_id,
            row_limit=row_limit,
            consumer=_rs_user,
        )

    return _finish(result.total_rows)
