"""
Subscription API — Phase 60 (Delivery & Alerts)

CRUD + lifecycle endpoints for report delivery subscriptions.
"""
from __future__ import annotations

import asyncio
import logging
import secrets
from datetime import datetime, timezone
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import Field
from api.strict_request import StrictRequestModel  # AQD-03: unknown keys are refused, not ignored

from api.deps import get_current_user, require_admin
from core import config
from core.delivery_engine import (SCHEDULE_GRAMMAR, compute_next_send,
                                  deliver_subscription, schedule_problem)
from core.roles import ADMIN_TIER_ROLES
from core.db_async import adb

logger = logging.getLogger(__name__)
router = APIRouter()

# ── Injected dependencies ─────────────────────────────────────────────────────

_db_manager = None


def set_subscription_dependencies(db_manager):
    global _db_manager
    _db_manager = db_manager
    logger.info("SubscriptionAPI dependencies injected")


# ── Pydantic models ───────────────────────────────────────────────────────────

class SubscriptionCreate(StrictRequestModel):
    report_id: int
    report_type: str = "business_report"
    name: str = Field(..., min_length=1, max_length=255)
    recipient_emails: List[str] = Field(..., min_length=1)
    frequency: str = Field(..., min_length=1,
                           description=f"When to send: {SCHEDULE_GRAMMAR}.",
                           examples=["0 6 * * *", "@daily"])
    timezone: str = Field("UTC", description="IANA timezone the schedule is read in.")
    output_format: str = "pdf"                          # pdf | excel | csv
    param_values: Optional[dict] = None


class SubscriptionUpdate(StrictRequestModel):
    name: Optional[str] = None
    recipient_emails: Optional[List[str]] = None
    frequency: Optional[str] = Field(None, description=f"When to send: {SCHEDULE_GRAMMAR}.")
    timezone: Optional[str] = None
    output_format: Optional[str] = None
    param_values: Optional[dict] = None
    is_active: Optional[bool] = None


# ── CRUD endpoints ────────────────────────────────────────────────────────────

@router.post("/api/subscriptions")
async def create_subscription(body: SubscriptionCreate, user: dict = Depends(get_current_user)):
    cfg = config.delivery
    if not cfg.enabled:
        raise HTTPException(status_code=403, detail="Delivery feature is disabled")

    username = user.get("username", "anonymous")

    # Validate limits.  BF-NONBLOCK-AUDIT: list_subscriptions is a sync DB
    # query.  Per-user it's bounded by max_subscriptions_per_user, but
    # admins listing all could scan thousands of rows.  asyncio.to_thread
    # keeps the event loop free during the scan.
    existing = await asyncio.to_thread(_db_manager.list_subscriptions, created_by=username)
    if len(existing) >= cfg.max_subscriptions_per_user:
        raise HTTPException(status_code=400,
                            detail=f"Maximum {cfg.max_subscriptions_per_user} subscriptions per user")
    if len(body.recipient_emails) > cfg.max_recipients_per_subscription:
        raise HTTPException(status_code=400,
                            detail=f"Maximum {cfg.max_recipients_per_subscription} recipients per subscription")
    if body.output_format not in ("pdf", "excel", "csv"):
        raise HTTPException(status_code=400, detail="Invalid output_format (pdf|excel|csv)")

    # ── Authorization-to-distribute (create-time gate, fail-closed) ──────────
    # DESIGN (core.reports.authorization): a delivery executes at the report
    # OWNER's RLS scope and mails the same bytes to every recipient, so only
    # a principal who can already VIEW the report may point a subscription at
    # it.  Re-checked at every send by core.delivery_engine._authorize_delivery.
    if body.report_type == "business_report":
        br = await adb(_db_manager.get_business_report, body.report_id)
        if not br:
            raise HTTPException(status_code=404, detail="Business report not found")
        from core.reports.authorization import can_view_business_report
        if not can_view_business_report(br, user, _db_manager):
            raise HTTPException(
                status_code=403,
                detail="You do not have view access to this business report — "
                       "cannot subscribe recipients to its owner-scoped extract")

        # ── Save-time parameter preflight (2026-08-05) ───────────────────────
        # Fail at CONFIG time, not on the overnight run: a required report
        # parameter with no value on this subscription and no default would
        # make EVERY scheduled send fail.  Refuse the save and name the fix.
        from core.reports.subscription_preflight import preflight_subscription_params
        _problems = await adb(preflight_subscription_params, br,
                              body.param_values, _db_manager)
        if _problems:
            raise HTTPException(
                status_code=400,
                detail="This subscription cannot run as saved: "
                       + "; ".join(_problems))
    else:
        # FB-60 (2026-09-26): the legacy "report" family is decommissioned;
        # refused by name at authoring time (and again at every send by
        # core.delivery_engine._authorize_delivery for rows that predate this).
        from core.reports.legacy_parametric import refusal
        raise HTTPException(status_code=400, detail=refusal(
            f"subscription report_type {body.report_type!r}",
            instead="Subscribe to the finance report (report_type='business_report')."))

    # Recipient audience policy (delivery.allowed_recipient_domains; empty = allow all)
    from core.reports.authorization import validate_recipients
    _invalid = validate_recipients(body.recipient_emails)
    if _invalid:
        raise HTTPException(
            status_code=400,
            detail="Recipients violate the delivery audience policy: "
                   + ", ".join(str(i) for i in _invalid))

    # Compute first send time. AQD-08: say WHICH input is wrong and what it
    # must look like, instead of "Invalid cron expression or timezone".
    _sched_problem = schedule_problem(body.frequency, body.timezone)
    if _sched_problem:
        raise HTTPException(status_code=400, detail=_sched_problem)
    next_send = compute_next_send(body.frequency, body.timezone)
    if not next_send:
        raise HTTPException(status_code=400, detail=(
            f"frequency {body.frequency!r} in timezone {body.timezone!r} "
            "produced no next send time"))

    token = secrets.token_urlsafe(32)

    sub = await adb(_db_manager.create_subscription, 
        report_id=body.report_id,
        report_type=body.report_type,
        name=body.name,
        created_by=username,
        recipient_emails=body.recipient_emails,
        frequency=body.frequency,
        timezone=body.timezone,
        output_format=body.output_format,
        param_values=body.param_values,
        is_active=True,
        next_send_at=next_send,
        unsubscribe_token=token,
    )
    return sub


@router.get("/api/subscriptions")
async def list_subscriptions(report_id: Optional[int] = None,
                             report_type: Optional[str] = None,
                             user: dict = Depends(get_current_user)):
    username = user.get("username", "anonymous")
    role = user.get("role", "viewer")
    # Admins (and super_admin) see all; others see own
    created_by = None if role in ADMIN_TIER_ROLES else username
    # BF-NONBLOCK-AUDIT: when called by an admin (created_by=None), the
    # query scans every subscription row.  Wrapped in to_thread so the
    # scan doesn't pin the event loop on large orgs.
    return await asyncio.to_thread(
        _db_manager.list_subscriptions,
        created_by=created_by, report_id=report_id, report_type=report_type,
    )


@router.get("/api/subscriptions/{sub_id}")
async def get_subscription(sub_id: int, user: dict = Depends(get_current_user)):
    sub = await adb(_db_manager.get_subscription, sub_id)
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    _check_ownership(sub, user)
    return sub


@router.put("/api/subscriptions/{sub_id}")
async def update_subscription(sub_id: int, body: SubscriptionUpdate, user: dict = Depends(get_current_user)):
    sub = await adb(_db_manager.get_subscription, sub_id)
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    _check_ownership(sub, user)

    cfg = config.delivery
    updates = {k: v for k, v in body.model_dump().items() if v is not None}

    if "recipient_emails" in updates and len(updates["recipient_emails"]) > cfg.max_recipients_per_subscription:
        raise HTTPException(status_code=400,
                            detail=f"Maximum {cfg.max_recipients_per_subscription} recipients")
    if "recipient_emails" in updates:
        from core.reports.authorization import validate_recipients
        _invalid = validate_recipients(updates["recipient_emails"])
        if _invalid:
            raise HTTPException(
                status_code=400,
                detail="Recipients violate the delivery audience policy: "
                       + ", ".join(str(i) for i in _invalid))

    if "output_format" in updates and updates["output_format"] not in ("pdf", "excel", "csv"):
        raise HTTPException(status_code=400, detail="Invalid output_format")

    # ── Save-time parameter preflight on param changes (2026-08-05) ──────────
    # Same gate as create: changed parameters that cannot resolve must be
    # refused NOW, not discovered as failures on the overnight run.
    if "param_values" in updates and sub.get("report_type") == "business_report":
        br = await adb(_db_manager.get_business_report, sub["report_id"])
        if br:
            from core.reports.subscription_preflight import preflight_subscription_params
            _problems = await adb(preflight_subscription_params, br,
                                  updates["param_values"], _db_manager)
            if _problems:
                raise HTTPException(
                    status_code=400,
                    detail="This subscription cannot run as saved: "
                           + "; ".join(_problems))

    # Recompute next_send if frequency or timezone changed
    freq = updates.get("frequency", sub["frequency"])
    tz = updates.get("timezone", sub.get("timezone", "UTC"))
    if "frequency" in updates or "timezone" in updates:
        _sched_problem = schedule_problem(freq, tz)
        if _sched_problem:
            raise HTTPException(status_code=400, detail=_sched_problem)
        next_send = compute_next_send(freq, tz)
        if not next_send:
            raise HTTPException(status_code=400, detail=(
                f"frequency {freq!r} in timezone {tz!r} produced no next send time"))
        updates["next_send_at"] = next_send

    result = await adb(_db_manager.update_subscription, sub_id, **updates)
    return result


@router.delete("/api/subscriptions/{sub_id}")
async def delete_subscription(sub_id: int, user: dict = Depends(get_current_user)):
    sub = await adb(_db_manager.get_subscription, sub_id)
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    _check_ownership(sub, user)
    await adb(_db_manager.delete_subscription, sub_id)
    return {"detail": "Subscription deleted"}


# ── Lifecycle endpoints ───────────────────────────────────────────────────────

@router.post("/api/subscriptions/{sub_id}/test-send")
async def test_send(sub_id: int, user: dict = Depends(get_current_user)):
    """Execute the subscription immediately (test delivery)."""
    sub = await adb(_db_manager.get_subscription, sub_id)
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    _check_ownership(sub, user)

    try:
        # F-P3A-10 (2026-08-23): a test send is a FULL report execution +
        # render + SMTP — inline it pinned the event loop (and with it every
        # request on the pod) for the whole delivery.
        result = await asyncio.to_thread(deliver_subscription, sub_id)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Delivery failed: {exc}")

    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@router.post("/api/subscriptions/{sub_id}/pause")
async def pause_subscription(sub_id: int, user: dict = Depends(get_current_user)):
    sub = await adb(_db_manager.get_subscription, sub_id)
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    _check_ownership(sub, user)
    await adb(_db_manager.update_subscription, sub_id, is_active=False)
    return {"detail": "Subscription paused"}


@router.post("/api/subscriptions/{sub_id}/resume")
async def resume_subscription(sub_id: int, user: dict = Depends(get_current_user)):
    sub = await adb(_db_manager.get_subscription, sub_id)
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    _check_ownership(sub, user)
    next_send = compute_next_send(sub["frequency"], sub.get("timezone", "UTC"))
    await adb(_db_manager.update_subscription, sub_id, is_active=True, next_send_at=next_send)
    return {"detail": "Subscription resumed", "next_send_at": next_send.isoformat() if next_send else None}


@router.get("/api/subscriptions/{sub_id}/history")
async def subscription_history(sub_id: int, limit: int = 50, user: dict = Depends(get_current_user)):
    sub = await adb(_db_manager.get_subscription, sub_id)
    if not sub:
        raise HTTPException(status_code=404, detail="Subscription not found")
    _check_ownership(sub, user)
    return await adb(_db_manager.list_subscription_deliveries, sub_id, limit=limit)


# ── One-click unsubscribe (no auth required) ─────────────────────────────────

def _unsubscribe_token_expiry_reason(sub: dict) -> str:
    """"" if the token is still valid, else why it is not.

    Separated from the route so the rule is testable without a live DB and
    an HTTP client, and so there is ONE place that decides what "expired"
    means for an unsubscribe link.

    FAILS OPEN on an unreadable timestamp.  A subscriber clicking
    unsubscribe must not be told "no" because a date would not parse — the
    whole point of a one-click link is that it works — and an unbounded
    token is the status quo this replaces, not a new exposure.  The
    ambiguity is logged.
    """
    try:
        days = int(config.delivery.unsubscribe_token_expiry_days)
    except Exception as exc:                            # pragma: no cover
        logger.warning("[unsubscribe] expiry not enforced, config unreadable: %s", exc)
        return ""
    if days <= 0:
        return ""                                       # 0 = never expires

    issued = sub.get("created_at")
    if not issued:
        logger.warning("[unsubscribe] subscription %s has no created_at — "
                       "token age unknown, allowing", sub.get("id"))
        return ""
    try:
        if isinstance(issued, str):
            issued_dt = datetime.fromisoformat(issued.replace("Z", "+00:00"))
        else:
            issued_dt = issued
        if issued_dt.tzinfo is None:
            # Naive timestamps come back from some DAOs; read as UTC rather
            # than let the subtraction raise and silently allow every token.
            issued_dt = issued_dt.replace(tzinfo=timezone.utc)
    except Exception as exc:
        logger.warning("[unsubscribe] subscription %s created_at %r "
                       "unreadable (%s) — allowing", sub.get("id"), issued, exc)
        return ""

    age_days = (datetime.now(timezone.utc) - issued_dt).total_seconds() / 86400.0
    if age_days > days:
        return (f"issued {age_days:.0f} days ago, limit is {days} "
                f"(delivery.unsubscribe_token_expiry_days)")
    return ""


@router.get("/api/unsubscribe/{token}")
async def unsubscribe(token: str):
    """One-click unsubscribe.  PUBLIC — no auth, the token IS the credential.

    2026-09-15 — ``delivery.unsubscribe_token_expiry_days`` shipped at 365
    and NOTHING compared anything to it: an unsubscribe link worked forever.
    The 404 on this route has always read "Invalid or **expired** unsubscribe
    link", which described a check that did not exist — the declaration was
    even in the user-facing string.

    The token is issued ONCE, at subscription creation
    (``create_subscription(unsubscribe_token=...)``), and is never rotated
    anywhere in the codebase, so the row's ``created_at`` IS the token's
    issue time and no new column is needed.  If rotation is ever added, the
    issue time must move with it — a rotated token inheriting an old
    ``created_at`` would be born expired.

    0 = never expires (the product-wide rule).
    """
    sub = await adb(_db_manager.get_subscription_by_unsubscribe_token, token)
    if not sub:
        raise HTTPException(status_code=404, detail="Invalid or expired unsubscribe link")

    expired_reason = _unsubscribe_token_expiry_reason(sub)
    if expired_reason:
        # SAME status and SAME message as an unknown token, deliberately.
        # Distinguishing them would turn this unauthenticated route into an
        # oracle that confirms a token was once real.  The operator gets the
        # distinction in the log, where it is not attacker-readable.
        logger.info("[unsubscribe] refused an EXPIRED token for subscription "
                    "%s: %s", sub.get("id"), expired_reason)
        raise HTTPException(status_code=404, detail="Invalid or expired unsubscribe link")

    await adb(_db_manager.update_subscription, sub["id"], is_active=False)
    return {"detail": f"Successfully unsubscribed from '{sub['name']}'"}


# ── Admin: delivery config ────────────────────────────────────────────────────

@router.get("/api/admin/delivery/config")
async def get_delivery_config(user: dict = Depends(require_admin)):
    return config.get_section("delivery")


@router.put("/api/admin/delivery/config")
async def update_delivery_config(body: dict, user: dict = Depends(require_admin)):
    current = config.get_section("delivery")
    for k, v in body.items():
        if k in current:
            config.set("delivery", k, v)
    return config.get_section("delivery")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _check_ownership(sub: dict, user: dict):
    """Ensure user owns the subscription or is admin/super_admin."""
    role = user.get("role", "viewer")
    username = user.get("username", "")
    if role not in ADMIN_TIER_ROLES and sub.get("created_by") != username:
        raise HTTPException(status_code=403, detail="Not authorised to access this subscription")
