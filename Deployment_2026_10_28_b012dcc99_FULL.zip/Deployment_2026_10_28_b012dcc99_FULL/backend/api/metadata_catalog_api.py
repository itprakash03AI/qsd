"""
Metadata Catalog API — Phase 88 / Phase 92

Endpoints:
  GET  /api/catalog/tables              — all connections with their registered table metadata
  GET  /api/catalog/tables?connection_id=N — single connection
  GET  /api/catalog/tables/{conn}/{table}/metadata   — raw Iceberg JSON
  GET  /api/catalog/tables/{conn}/{table}/preview    — top-N rows preview (Phase 92)
  GET  /api/catalog/tables/{conn}/{table}/health     — file health analysis (Phase 92)
  PUT  /api/catalog/tables/{conn}/{table}/description — admin description edit (Phase 92)
  POST /api/catalog/favorites/toggle    — toggle table favorite (Phase 92)
  GET  /api/catalog/favorites           — list current user's favorites (Phase 92)

Phase 92 enhancements:
- Data freshness (last_updated_at from S3 LastModified)
- File health (avg file size, small-file warning)
- Favorites (star/unstar tables, My Tables tab)
- Admin-editable descriptions stored in table_descriptions table
- Data preview (top-N rows via DuckDB)
- Preview count (usage proxy)
"""
from __future__ import annotations

import asyncio
import logging
import os
from concurrent.futures import ThreadPoolExecutor
from functools import partial
from typing import Dict, FrozenSet, List, Optional

from fastapi import APIRouter, Body, Depends, HTTPException, Query as QParam
from pydantic import BaseModel

from api.deps import get_current_user
from core.roles import ADMIN_TIER_ROLES

logger = logging.getLogger(__name__)

router = APIRouter(tags=["metadata-catalog"])

# ── Module-level singletons — set via set_metadata_catalog_dependencies() ────
_db_manager   = None
_conn_manager = None
_auth_cfg     = None

_catalog_executor = ThreadPoolExecutor(
    max_workers=4,
    thread_name_prefix="meta-catalog",
)


def set_metadata_catalog_dependencies(db_manager, conn_manager, auth_cfg):
    """Wire shared singletons from main.py at startup."""
    global _db_manager, _conn_manager, _auth_cfg
    _db_manager   = db_manager
    _conn_manager = conn_manager
    _auth_cfg     = auth_cfg


# ── Internal helpers ──────────────────────────────────────────────────────────

def _sample_s3_stats(conn_raw: dict, table_def: dict, max_files: int = 20) -> dict:
    """
    Sample files to extract stats.  For **Iceberg** tables, uses metadata
    (``load_iceberg_table_info`` / ``get_iceberg_data_files``) so only
    *active-snapshot* files are counted — never orphaned / old-snapshot files.
    For plain parquet, uses boto3 ``list_objects_v2`` (no metadata available).

    Returns:
      - partition_columns, sample_partition_values (up to 10 per col)
      - file_count, last_updated_at, avg_file_size_mb, small_file_warning
    """
    empty: dict = {
        "partition_columns": [], "sample_partition_values": {}, "file_count": 0,
        "last_updated_at": None, "avg_file_size_mb": None, "small_file_warning": False,
    }
    try:
        from core.s3_utilities import extract_hive_parts, make_s3_client_for_conn
    except ImportError:
        return empty

    try:
        cfg = conn_raw.get("config", {})
        bucket = cfg.get("bucket_name", "")
        if not bucket:
            return empty

        s3 = make_s3_client_for_conn(conn_raw)
        prefix = table_def.get("s3_prefix", "")
        fmt = table_def.get("format", "parquet")

        # ── Iceberg: use metadata for active files only ──────────────
        if fmt == "iceberg":
            return _sample_s3_stats_iceberg(conn_raw, cfg, bucket, prefix, s3, max_files)

        # ── Plain parquet / CSV: boto3 listing ───────────────────────
        list_prefix = (prefix.rstrip("/") + "/") if prefix else ""

        files: List[str] = []
        sizes: List[int] = []
        latest_modified = None

        paginator = s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=bucket, Prefix=list_prefix):
            for obj in page.get("Contents", []):
                key = obj["Key"]
                if not key.lower().endswith(".parquet") or key.split("/")[-1].startswith("."):
                    continue
                files.append(f"s3://{bucket}/{key}")
                sizes.append(obj.get("Size", 0))
                lm = obj.get("LastModified")
                if lm and (latest_modified is None or lm > latest_modified):
                    latest_modified = lm
                if len(files) >= max_files:
                    break
            if len(files) >= max_files:
                break

        if not files:
            return {**empty, "file_count": 0}

        # Hive partition extraction
        part_values: Dict[str, set] = {}
        for f in files:
            parts = extract_hive_parts(f)
            for k, v in parts.items():
                part_values.setdefault(k, set()).add(v)

        sample_vals = {col: sorted(vals)[:10] for col, vals in part_values.items()}

        # File size health
        avg_mb = (sum(sizes) / len(sizes) / 1_048_576) if sizes else None
        small_file_warning = avg_mb is not None and avg_mb < 64.0

        return {
            "partition_columns": list(part_values.keys()),
            "sample_partition_values": sample_vals,
            "file_count": len(files),
            "last_updated_at": latest_modified.isoformat() if latest_modified else None,
            "avg_file_size_mb": round(avg_mb, 2) if avg_mb is not None else None,
            "small_file_warning": small_file_warning,
        }

    except Exception as exc:
        logger.debug("_sample_s3_stats: error for %s/%s: %s",
                     conn_raw.get("id"), table_def.get("name"), exc)
        return empty


def _sample_s3_stats_iceberg(
    conn_raw: dict, cfg: dict, bucket: str, prefix: str, s3, max_files: int,
) -> dict:
    """Iceberg-specific stats using metadata — only active-snapshot files.

    BF-70: Replaces raw list_objects_v2 which included orphaned files from
    old snapshots, causing slow catalog loads and wrong file counts.
    """
    empty: dict = {
        "partition_columns": [], "sample_partition_values": {}, "file_count": 0,
        "last_updated_at": None, "avg_file_size_mb": None, "small_file_warning": False,
    }
    try:
        from core.iceberg_service import load_iceberg_table_info
        from core.s3_utilities import extract_hive_parts
    except ImportError:
        return empty

    try:
        info = load_iceberg_table_info(bucket, prefix, cfg)

        data_files = info.data_files  # list of {file_path, size_bytes, record_count}
        if not data_files:
            return {**empty, "file_count": 0}

        # Use snapshot timestamp as freshness indicator
        snapshot_ts = None
        if info.snapshot_id:
            try:
                # Snapshot summary has a "created-at" ms timestamp; fall back to None
                snapshot_ts = None  # Will use None if unavailable
            except Exception:
                pass

        # Collect sizes from manifest metadata (no S3 head_object needed)
        sizes = [df.get("size_bytes", 0) or 0 for df in data_files]
        file_count = len(data_files)

        # Sample up to max_files for partition extraction
        sample = data_files[:max_files]
        part_values: Dict[str, set] = {}
        for df in sample:
            fp = df.get("file_path", "")
            parts = extract_hive_parts(fp)
            for k, v in parts.items():
                part_values.setdefault(k, set()).add(v)

        sample_vals = {col: sorted(vals)[:10] for col, vals in part_values.items()}

        # Partition spec columns (more reliable than hive path extraction)
        partition_columns = list(part_values.keys())
        if not partition_columns and info.partition_spec:
            partition_columns = [ps.get("source_column", ps.get("name", ""))
                                 for ps in info.partition_spec]

        # File size health
        avg_mb = (sum(sizes) / len(sizes) / 1_048_576) if sizes else None
        small_file_warning = avg_mb is not None and avg_mb < 64.0

        return {
            "partition_columns": partition_columns,
            "sample_partition_values": sample_vals,
            "file_count": file_count,
            "last_updated_at": None,  # Iceberg doesn't expose per-file LastModified from manifests
            "avg_file_size_mb": round(avg_mb, 2) if avg_mb is not None else None,
            "small_file_warning": small_file_warning,
        }

    except Exception as exc:
        logger.debug("_sample_s3_stats_iceberg: error for %s/%s: %s",
                     conn_raw.get("id", "?"), prefix, exc)
        return empty


# Keep old name as alias so existing mocks in tests still resolve.
_sample_partition_info = _sample_s3_stats


def _get_record_count_from_cache(connection_id: int, table_name: str) -> Optional[int]:
    """Try to retrieve a record count from the iceberg file cache. Returns None if not cached."""
    try:
        from core.iceberg_cache import ice_cache_key, ice_cache_get
        key = ice_cache_key(connection_id, table_name, None)
        entry = ice_cache_get(key)
        if entry and entry.get("record_count"):
            return int(entry["record_count"])
    except Exception:
        pass
    return None


def _build_table_metadata(conn_raw: dict, table_def: dict,
                           is_favorite: bool = False,
                           desc_info: Optional[dict] = None) -> dict:
    """
    Build metadata dict for a single registered table.
    Called in a thread pool executor so S3 calls don't block the event loop.
    """
    connection_id = conn_raw.get("id")
    table_name = table_def.get("name", "")
    fmt = (table_def.get("format") or "parquet").lower()
    s3_prefix = table_def.get("s3_prefix", "")
    # Description: prefer DB-stored over table_def (admin may have updated it)
    description = ""
    preview_count = 0
    if desc_info:
        description = desc_info.get("description") or table_def.get("description") or ""
        preview_count = desc_info.get("preview_count") or 0
    else:
        description = table_def.get("description") or ""

    record_count = _get_record_count_from_cache(connection_id, table_name)

    # Rich S3 sampling (partition info + freshness + file health)
    stats = _sample_s3_stats(conn_raw, table_def, max_files=20)

    columns: List[dict] = []
    snapshot_id: Optional[int] = None
    format_version: Optional[int] = None
    if fmt == "iceberg":
        try:
            from core.iceberg_service import get_iceberg_schema
            cfg = conn_raw.get("config", {})
            bucket = cfg.get("bucket_name", "")
            schema_info = get_iceberg_schema(bucket, s3_prefix, cfg)
            columns = schema_info.get("columns", [])
            snapshot_id = schema_info.get("snapshot_id")
            format_version = schema_info.get("format_version")
            if not record_count and schema_info.get("num_rows"):
                record_count = schema_info["num_rows"]
        except Exception as e:
            logger.debug("Could not load Iceberg schema for %s: %s", table_name, e)

    # LOCAL COLUMN CATALOG fallback (2026-08-23).  The live path above only
    # fills columns for iceberg, and even then silently yields [] when the
    # source is unreachable; plain parquet never gets columns here at all.
    # So the Data Catalog card showed an empty schema for every parquet
    # table and for ANY table when S3/Starburst was down -- the reported
    # "we should have saved all columns in our local db" dead-end.  Serve
    # the columns we already saved, via the sanctioned read-only
    # ColumnCatalog store (the single write chokepoint is untouched).
    columns_source = "source" if columns else None
    if not columns:
        try:
            from core.schema_catalog import ColumnCatalog
            _entry = ColumnCatalog(_db_manager).get_entry(connection_id, table_name)
            _saved = (_entry or {}).get("columns") or []
            if _saved:
                columns = [{"name": c["name"],
                            "type": c.get("data_type") or "unknown",
                            "nullable": c.get("nullable", True)}
                           for c in _saved if c.get("name")]
                columns_source = "catalog"
                if not record_count:
                    _rows = (_entry or {}).get("row_estimate")
                    if isinstance(_rows, int) and not isinstance(_rows, bool):
                        record_count = _rows
        except Exception as _cat_exc:
            logger.debug("catalog column fallback failed for %s: %s",
                         table_name, _cat_exc)

    return {
        "name": table_name,
        "format": fmt,
        "s3_prefix": s3_prefix,
        "description": description,
        "file_count": stats["file_count"],
        "record_count": record_count,
        "partition_columns": stats["partition_columns"],
        "sample_partition_values": stats["sample_partition_values"],
        "columns": columns,
        "columns_source": columns_source,
        "snapshot_id": snapshot_id,
        "format_version": format_version,
        # Phase 92 enrichments
        "last_updated_at": stats["last_updated_at"],
        "avg_file_size_mb": stats["avg_file_size_mb"],
        "small_file_warning": stats["small_file_warning"],
        "is_favorite": is_favorite,
        "preview_count": preview_count,
    }


def _build_connection_catalog(conn: dict,
                               favorites_set: FrozenSet = frozenset(),
                               descriptions: dict = {}) -> Optional[dict]:
    """
    Build catalog entry for a single connection.
    Returns None if not an S3/local connection.
    """
    conn_id = conn.get("id")
    conn_type = conn.get("connection_type", "")

    if conn_type not in ("s3", "local", "upload"):
        return None

    try:
        conn_raw = _db_manager.get_connection_raw(conn_id)
    except Exception:
        return None

    if not conn_raw:
        return None

    cfg = conn_raw.get("config", {})
    registered_tables = cfg.get("registered_tables", [])

    if not registered_tables:
        return {
            "id": conn_id,
            "name": conn.get("name", ""),
            "connection_type": conn_type,
            "tables": [],
        }

    tables = []
    for table_def in registered_tables:
        table_name = table_def.get("name", "")
        is_fav = (conn_id, table_name) in favorites_set
        desc_info = descriptions.get((conn_id, table_name))
        try:
            meta = _build_table_metadata(conn_raw, table_def,
                                          is_favorite=is_fav, desc_info=desc_info)
            tables.append(meta)
        except Exception as exc:
            logger.warning("Catalog: failed to get metadata for %s/%s: %s",
                           conn_id, table_name, exc)
            tables.append({
                "name": table_name,
                "format": table_def.get("format", "parquet"),
                "s3_prefix": table_def.get("s3_prefix", ""),
                "description": table_def.get("description") or "",
                "file_count": 0,
                "record_count": None,
                "partition_columns": [],
                "sample_partition_values": {},
                "last_updated_at": None,
                "avg_file_size_mb": None,
                "small_file_warning": False,
                "is_favorite": is_fav,
                "preview_count": 0,
            })

    return {
        "id": conn_id,
        "name": conn.get("name", ""),
        "connection_type": conn_type,
        "tables": tables,
    }


def _build_table_preview(conn_raw: dict, table_def: dict, limit: int = 10) -> dict:
    """
    Execute SELECT * LIMIT N against a registered table's parquet files.
    Returns {"columns": [...], "rows": [...]} or {"columns": [], "rows": [], "error": "..."}.
    """
    try:
        import duckdb
        from core.s3_utilities import (
            make_s3_client_for_conn, list_s3_parquet_files,
            s3_urls_to_presigned, get_s3_access_mode,
        )
    except ImportError as e:
        return {"columns": [], "rows": [], "error": str(e)}

    cfg = conn_raw.get("config", {})
    bucket = cfg.get("bucket_name", "")
    prefix = table_def.get("s3_prefix", "")
    fmt = table_def.get("format", "parquet")

    try:
        s3 = make_s3_client_for_conn(conn_raw)

        if fmt == "iceberg":
            # BF-70: Use Iceberg metadata for active files only — never raw S3 listing
            try:
                from core.iceberg_service import get_iceberg_active_files
                files = get_iceberg_active_files(bucket, prefix, cfg)[:3]
            except Exception as ice_exc:
                logger.debug("_build_table_preview: Iceberg metadata fallback for %s: %s", prefix, ice_exc)
                # Fallback to raw listing only if Iceberg metadata unavailable
                data_prefix = (prefix.rstrip("/") + "/data/") if prefix else "data/"
                files = list_s3_parquet_files(s3, bucket, data_prefix, max_files=3)
                if not files:
                    files = list_s3_parquet_files(s3, bucket, prefix, max_files=3)
        else:
            files = list_s3_parquet_files(s3, bucket, prefix, max_files=3)

        if not files:
            return {"columns": [], "rows": [], "error": "No parquet files found in this table"}

        access_mode = get_s3_access_mode(cfg)

        # BF-103: On-prem S3 (presigned mode) — DuckDB httpfs sends HEAD
        # requests on presigned URLs which Dell ECS / MinIO reject (presigned
        # was signed for GET, not HEAD).  Fix: download via boto3, read local.
        if access_mode == "presigned":
            import tempfile
            import shutil
            local_files: List[str] = []
            _tmp_dir = tempfile.mkdtemp(prefix="catalog_preview_")
            try:
                for f in files:
                    # Parse s3://bucket/key from the full path
                    _path = f.replace("s3://", "")
                    _bucket = _path.split("/", 1)[0]
                    _key = _path.split("/", 1)[1] if "/" in _path else ""
                    _local = os.path.join(_tmp_dir, os.path.basename(_key))
                    s3.download_file(_bucket, _key, _local)
                    local_files.append(_local)

                from core.duckdb_factory import duckdb_connection
                with duckdb_connection() as con:
                    if len(local_files) == 1:
                        path_expr = f"'{local_files[0]}'"
                    else:
                        paths = ", ".join(f"'{lf}'" for lf in local_files)
                        path_expr = f"[{paths}]"
                    df = con.execute(f"SELECT * FROM read_parquet({path_expr}) LIMIT {limit}").fetchdf()
            finally:
                shutil.rmtree(_tmp_dir, ignore_errors=True)
        else:
            # Native mode — DuckDB reads directly from S3 via httpfs
            from core.duckdb_factory import duckdb_connection
            with duckdb_connection() as con:
                try:
                    con.execute("LOAD httpfs;")
                except Exception:
                    con.execute("INSTALL httpfs; LOAD httpfs;")
                try:
                    # 2026-10-06 -- the shared S3 transport (connection
                    # caching + the retry floor), after the LOAD; fail-open.
                    from core.s3_http_transport import apply_s3_http_transport
                    apply_s3_http_transport(con, label="catalog preview")
                except Exception:              # noqa: BLE001
                    pass

                # 2026-09-26 -- endpoint / ssl / url-style / region /
                # credentials / proxy from the ONE resolver (core.s3_access).
                from core.s3_access import resolve_s3_access
                resolve_s3_access(cfg).apply_to_duckdb(con, proxy=True)

                if len(files) == 1:
                    path_expr = f"'{files[0]}'"
                else:
                    paths = ", ".join(f"'{f}'" for f in files)
                    path_expr = f"[{paths}]"
                df = con.execute(f"SELECT * FROM read_parquet({path_expr}) LIMIT {limit}").fetchdf()

        columns = list(df.columns)
        rows: List[dict] = []
        for row in df.to_dict(orient="records"):
            clean: dict = {}
            for k, v in row.items():
                if hasattr(v, "item"):
                    clean[k] = v.item()
                elif v != v:  # NaN
                    clean[k] = None
                else:
                    clean[k] = v
            rows.append(clean)
        return {"columns": columns, "rows": rows}

    except Exception as exc:
        logger.debug("_build_table_preview: error for %s/%s: %s",
                     conn_raw.get("id"), table_def.get("name"), exc)
        return {"columns": [], "rows": [], "error": str(exc)}


def _build_parquet_metadata(conn_raw: dict, table_def: dict) -> dict:
    """BF-69: Read parquet file schema reliably via the unified
    ``core.schema_reader.read_parquet_schema_for_conn`` helper.

    Step 3 of REFACTOR_PLAN_SCHEMA_READER.md — the previous inline
    "build S3 client → call safe_read_parquet_schema" idiom has moved
    into the shared helper.  Behaviour unchanged: same iceberg
    /data/-subdir fallback, same return shape.  Downloads file
    locally for on-prem S3 (Dell ECS) when needed; merges hive
    partition columns from file paths.
    """
    table_name = table_def.get("name", "")
    s3_prefix = table_def.get("s3_prefix", "")
    table_format = (table_def.get("format") or "parquet").lower()

    try:
        from core.s3_utilities import make_s3_client_for_conn
        from core.schema_reader import read_parquet_schema_for_conn
    except ImportError as e:
        return {"table_name": table_name, "format": table_format,
                "s3_prefix": s3_prefix, "error": str(e)}

    cfg = conn_raw.get("config", {})
    bucket = cfg.get("bucket_name", "")

    try:
        s3 = make_s3_client_for_conn(conn_raw)

        # For Iceberg, look in /data/ subdirectory first, fall back to root prefix
        search_prefix = s3_prefix
        if table_format == "iceberg":
            search_prefix = (s3_prefix.rstrip("/") + "/data/") if s3_prefix else "data/"

        try:
            result = read_parquet_schema_for_conn(conn_raw, bucket, search_prefix, s3_client=s3)
        except ValueError:
            # Iceberg /data/ prefix had no files — try root prefix
            if table_format == "iceberg" and search_prefix != s3_prefix:
                result = read_parquet_schema_for_conn(conn_raw, bucket, s3_prefix, s3_client=s3)
            else:
                raise

        return {
            "table_name": table_name,
            "connection_id": conn_raw.get("id"),
            "format": table_format,
            "s3_prefix": s3_prefix,
            "columns": result["columns"],
            "num_rows": result["num_rows"],
            "num_files": result["num_files"],
            "partition_columns": result.get("partition_columns", []),
        }

    except Exception as exc:
        logger.debug("_build_parquet_metadata error for %s: %s", table_name, exc)
        return {
            "table_name": table_name, "format": table_format,
            "s3_prefix": s3_prefix,
            "columns": [], "error": str(exc),
        }


# ── Main catalog endpoint ─────────────────────────────────────────────────────

@router.get("/api/catalog/tables")
async def get_metadata_catalog(
    connection_id: Optional[int] = QParam(default=None, description="Filter to a single connection"),
    _user: dict = Depends(get_current_user),
):
    """
    Return a catalog of all registered tables across S3 connections.

    Phase 92 additions: is_favorite, description, last_updated_at, avg_file_size_mb,
    small_file_warning, preview_count per table.
    """
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Metadata Catalog not initialised")

    try:
        all_conns = _db_manager.list_connections(active_only=True)
    except Exception as exc:
        logger.error("Catalog: failed to list connections: %s", exc)
        raise HTTPException(status_code=500, detail=f"Failed to list connections: {exc}")

    # RLS: the Data Catalog must honour the SAME connection visibility as
    # every other surface -- a private connection's table names, prefixes
    # and columns are not org-public.  Reuse connections_api._connection_
    # visible_to so the rule has one definition, not a second spelling.
    from api.connections_api import _connection_visible_to
    _visible = []
    for _c in all_conns:
        if await _connection_visible_to(_c, _user):
            _visible.append(_c)
    all_conns = _visible

    if connection_id is not None:
        all_conns = [c for c in all_conns if c.get("id") == connection_id]
        if not all_conns:
            raise HTTPException(status_code=404, detail=f"Connection {connection_id} not found")

    s3_conns = [c for c in all_conns if c.get("connection_type") in ("s3", "local", "upload")]
    if not s3_conns:
        return {"connections": [], "total_tables": 0, "total_connections": 0}

    # Pre-load favorites and descriptions for the current user (one DB call each)
    username = _user.get("username", "guest")
    favorites_set: FrozenSet = frozenset()
    descriptions: dict = {}
    try:
        favs = _db_manager.list_table_favorites(username)
        favorites_set = frozenset(
            (f["connection_id"], f["table_name"]) for f in favs
        )
    except Exception:
        pass
    try:
        all_descs = _db_manager.list_table_descriptions()
        descriptions = {(d["connection_id"], d["table_name"]): d for d in all_descs}
    except Exception:
        pass

    loop = asyncio.get_running_loop()

    async def _process_conn(conn: dict):
        try:
            fn = partial(_build_connection_catalog, conn,
                         favorites_set=favorites_set, descriptions=descriptions)
            return await loop.run_in_executor(_catalog_executor, fn)
        except Exception as exc:
            logger.warning("Catalog: error processing connection %s: %s", conn.get("id"), exc)
            return None

    results = await asyncio.gather(*[_process_conn(c) for c in s3_conns])

    connections_out: List[dict] = [r for r in results if r is not None]
    connections_out.sort(key=lambda c: (len(c["tables"]) == 0, c["name"].lower()))

    total_tables = sum(len(c["tables"]) for c in connections_out)

    return {
        "connections": connections_out,
        "total_tables": total_tables,
        "total_connections": len(connections_out),
    }


# ── Per-table endpoints ───────────────────────────────────────────────────────

@router.get("/api/catalog/tables/{connection_id}/{table_name}/metadata")
async def get_table_metadata(
    connection_id: int,
    table_name: str,
    current_user: dict = Depends(get_current_user),
):
    """Return full Iceberg metadata JSON for a specific table."""
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Metadata Catalog not initialised")
    conn_raw = _db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    # SECURITY: reads schema via STORED credentials -- gate on visibility.
    await _require_catalog_conn_visible(conn_raw, current_user)

    cfg = conn_raw.get("config", {})
    registered_tables = cfg.get("registered_tables") or []
    table_def = next((t for t in registered_tables if t.get("name") == table_name), None)
    if not table_def:
        raise HTTPException(status_code=404, detail=f"Table '{table_name}' not found in connection")

    s3_prefix = table_def.get("s3_prefix", "")
    table_format = (table_def.get("format") or "").lower()

    if table_format == "iceberg":
        try:
            from core.iceberg_service import get_iceberg_schema
            bucket = cfg.get("bucket_name", "")
            info_dict = get_iceberg_schema(bucket, s3_prefix, cfg)
            return {
                "table_name": table_name,
                "connection_id": connection_id,
                "format": "iceberg",
                "s3_prefix": s3_prefix,
                **info_dict,
            }
        except Exception as exc:
            logger.warning("Iceberg metadata failed for %s, falling back to parquet schema: %s",
                           table_name, exc)
            # Fall through to parquet schema reader below

    # Parquet (or Iceberg fallback): read schema via DuckDB from parquet files
    loop = asyncio.get_running_loop()
    try:
        result = await loop.run_in_executor(
            _catalog_executor, _build_parquet_metadata, conn_raw, table_def
        )
        return result
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to load metadata: {exc}")


@router.get("/api/catalog/tables/{connection_id}/{table_name}/preview")
async def get_table_preview(
    connection_id: int,
    table_name: str,
    limit: int = QParam(default=10, ge=1, le=100),
    _user: dict = Depends(get_current_user),
):
    """
    Return a preview of the first *limit* rows from a registered table. Phase 92.
    Supports both cloud S3 (native creds) and on-prem S3 (presigned URLs).
    Also increments the preview_count usage counter.
    """
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Metadata Catalog not initialised")
    conn_raw = _db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    # SECURITY: reads source rows via STORED credentials -- gate first.
    await _require_catalog_conn_visible(conn_raw, _user)

    cfg = conn_raw.get("config", {})
    registered_tables = cfg.get("registered_tables") or []
    table_def = next((t for t in registered_tables if t.get("name") == table_name), None)
    if not table_def:
        raise HTTPException(status_code=404, detail=f"Table '{table_name}' not found")

    # RLS FIX (2026-07-06): this preview reads raw ``read_parquet(...)`` source
    # rows, which row-security (keyed on table/view names) can't cleanly filter.
    # When row-security is enabled, restrict the raw preview to admins (who
    # bypass RLS anyway); a policy-restricted user must use the RLS-enforced
    # query grid instead of getting unfiltered source rows here.  No-op when
    # row-security is disabled.  Fail-closed on error.
    try:
        from core.row_security.api import _is_enabled as _rs_is_enabled
        from core.roles import is_admin_like
        if _rs_is_enabled() and not is_admin_like(_user):
            raise HTTPException(
                status_code=403,
                detail="Table preview is restricted while row-security is "
                       "enabled -- use the query grid, which enforces "
                       "row/column policies.",
            )
    except HTTPException:
        raise
    except Exception as _rls_exc:
        raise HTTPException(status_code=403, detail=f"row-security check failed: {_rls_exc}")

    # NOTE: `loop` is used again below for the preview executor -- do not
    # drop this binding when editing the fire-and-forget block.
    loop = asyncio.get_running_loop()

    # Async: increment usage counter (fire and forget)
    # asyncio.to_thread (a coroutine) rather than loop.run_in_executor
    # (a Future) -- track_bg_task wraps create_task, which requires a
    # coroutine.  Same off-loop execution, strong-ref tracked.
    from core.bg_tasks import track_bg_task as _track
    _track(asyncio.to_thread(
        _db_manager.increment_table_preview_count,
        connection_id, table_name))

    try:
        result = await loop.run_in_executor(
            _catalog_executor, _build_table_preview, conn_raw, table_def, limit
        )
        return result
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Preview failed: {exc}")


@router.get("/api/catalog/tables/{connection_id}/{table_name}/health")
async def get_table_health(
    connection_id: int,
    table_name: str,
    _user: dict = Depends(get_current_user),
):
    """
    Return detailed file health analysis for a registered table. Phase 92.
    Samples up to 50 files: file count, size stats, freshness, partition info.
    """
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Metadata Catalog not initialised")
    conn_raw = _db_manager.get_connection_raw(connection_id)
    if not conn_raw:
        raise HTTPException(status_code=404, detail="Connection not found")
    # SECURITY: samples S3 via STORED credentials -- gate first.
    await _require_catalog_conn_visible(conn_raw, _user)

    cfg = conn_raw.get("config", {})
    registered_tables = cfg.get("registered_tables") or []
    table_def = next((t for t in registered_tables if t.get("name") == table_name), None)
    if not table_def:
        raise HTTPException(status_code=404, detail=f"Table '{table_name}' not found")

    loop = asyncio.get_running_loop()
    stats = await loop.run_in_executor(
        _catalog_executor, _sample_s3_stats, conn_raw, table_def, 50
    )

    # Health score: 100 base, penalties for issues
    score = 100
    issues = []
    if stats["file_count"] == 0:
        score = 0
        issues.append("No files found")
    else:
        avg = stats.get("avg_file_size_mb")
        if avg is not None and avg < 10:
            score -= 40
            issues.append(f"Very small files (avg {avg:.1f} MB — consider compaction)")
        elif avg is not None and avg < 64:
            score -= 20
            issues.append(f"Small files (avg {avg:.1f} MB)")
        lu = stats.get("last_updated_at")
        if lu:
            from datetime import datetime, timezone
            try:
                dt = datetime.fromisoformat(lu.replace("Z", "+00:00"))
                days = (datetime.now(timezone.utc) - dt).days
                if days > 30:
                    score -= 20
                    issues.append(f"Stale data ({days} days since last update)")
            except Exception:
                pass

    return {
        "table_name": table_name,
        "connection_id": connection_id,
        "health_score": max(0, score),
        "issues": issues,
        **stats,
    }


@router.put("/api/catalog/tables/{connection_id}/{table_name}/description")
async def update_table_description(
    connection_id: int,
    table_name: str,
    body: dict = Body(...),
    _user: dict = Depends(get_current_user),
):
    """Update (or create) the admin-editable description for a registered table. Phase 92."""
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Metadata Catalog not initialised")

    # Only admin role can edit descriptions
    if _user.get("role") not in ADMIN_TIER_ROLES:
        raise HTTPException(status_code=403, detail="Admin role required to edit table descriptions")

    description = body.get("description", "")
    username = _user.get("username", "admin")

    try:
        result = _db_manager.upsert_table_description(connection_id, table_name, description, username)
        return result
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to save description: {exc}")


# ── Favorites endpoints ───────────────────────────────────────────────────────

@router.post("/api/catalog/favorites/toggle")
async def toggle_catalog_favorite(
    body: dict = Body(...),
    _user: dict = Depends(get_current_user),
):
    """
    Toggle a table as favorite/unfavorite for the current user. Phase 92.
    Body: {connection_id, table_name, table_path?}
    Returns: {is_favorite: bool, table_name: str}
    """
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Metadata Catalog not initialised")

    username = _user.get("username", "guest")
    conn_id = body.get("connection_id")
    table_name = body.get("table_name", "")
    table_path = body.get("table_path") or f"__registered__:{table_name}"

    try:
        is_fav = _db_manager.toggle_table_favorite(
            username=username,
            table_path=table_path,
            table_name=table_name,
            connection_id=conn_id,
            table_type="registered",
        )
        return {"is_favorite": is_fav, "table_name": table_name, "connection_id": conn_id}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to toggle favorite: {exc}")


@router.get("/api/catalog/favorites")
async def list_catalog_favorites(
    connection_id: Optional[int] = QParam(default=None, description="Filter to a single connection"),
    _user: dict = Depends(get_current_user),
):
    """Return the current user's favorited catalog tables. Phase 92."""
    if _db_manager is None:
        raise HTTPException(status_code=503, detail="Metadata Catalog not initialised")

    username = _user.get("username", "guest")
    try:
        favs = _db_manager.list_table_favorites(username, connection_id=connection_id)
        return {"favorites": favs, "count": len(favs)}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to list favorites: {exc}")


# ── Local column catalog (2026-08-22) ─────────────────────────────────────────
# Operator report: "Create Dataset — could not read any columns for the
# selected tables: why you are connecting to starburst or s3 to get
# columns... we should have saved all columns in our local db".
#
# These endpoints serve columns from the LOCAL catalog
# (core/schema_catalog.py) and NEVER touch the source on a GET.  A source
# read happens only on the explicit POST refresh, or as a bounded background
# top-up.  When nothing is known the response is source:"none" WITH a
# message — never a bare empty list.


async def _require_catalog_conn_access(connection_id: int, user: dict) -> dict:
    """Connection visibility check, delegated to connections_api's
    ACL helper so catalog reads and connection reads can never disagree
    about who may see a connection.  404 on denial (no existence oracle)."""
    from api.connections_api import _require_connection_access
    return await _require_connection_access(connection_id, user)


async def _require_catalog_conn_visible(conn_raw: dict, user: dict) -> None:
    """Visibility gate for the per-table routes, checked on the connection
    the route ALREADY fetched (get_connection_raw) so it costs no extra DB
    read.  Reuses connections_api._connection_visible_to so catalog and
    connection visibility can never disagree.  404 on denial (no oracle)."""
    from api.connections_api import _connection_visible_to
    if not await _connection_visible_to(conn_raw, user):
        raise HTTPException(status_code=404, detail="Connection not found")


def _column_catalog():
    from core.schema_catalog import ColumnCatalog
    if _db_manager is None:
        raise HTTPException(status_code=503,
                            detail="Metadata Catalog not initialised")
    return ColumnCatalog(_db_manager)


class ColumnsRefreshBody(BaseModel):
    """Body for POST /api/catalog/columns/refresh — one table or several."""
    connection_id: int
    table: Optional[str] = None
    tables: Optional[List[str]] = None


@router.get("/api/catalog/columns")
async def get_catalog_columns(
    connection_id: int = QParam(..., description="Connection id"),
    table: str = QParam(..., description="Table name"),
    _user: dict = Depends(get_current_user),
):
    """Columns for one table, served from the LOCAL catalog — never the
    source.  Contract::

        {"columns":[{"name","data_type","nullable","ordinal","description"}],
         "source":"catalog"|"none",
         "last_refreshed_at": iso|null, "stale": bool,
         "row_estimate": int|null, "message": str|null}

    Stale columns are served with ``stale:true`` and the timestamp — old
    columns beat no columns.  ``source:"none"`` always carries a message
    (including the last recorded failure reason, if any) and schedules a
    bounded BACKGROUND top-up; it never blocks this request on the source.
    """
    catalog = _column_catalog()
    await _require_catalog_conn_access(connection_id, _user)
    entry = await asyncio.to_thread(catalog.get_entry, connection_id, table)
    resp = catalog.build_response(entry, table_name=table)
    if resp["source"] == "none" and _conn_manager is not None:
        from core.schema_catalog import schedule_topup
        schedule_topup(_db_manager, _conn_manager, connection_id,
                       reason=f"catalog miss for table '{table}'")
    return resp


@router.get("/api/catalog/columns/bulk")
async def get_catalog_columns_bulk(
    connection_id: int = QParam(..., description="Connection id"),
    _user: dict = Depends(get_current_user),
):
    """Columns for EVERY table of a connection, from the LOCAL catalog only.

    Returns ``{"tables": {name: <same shape as GET /api/catalog/columns>}}``.
    The table set is the union of the connection's registered tables and
    every table the catalog has learned (SQL-connector tables browsed via
    CQB have catalog rows but are not in ``registered_tables``).  Tables
    with no recorded columns appear as ``source:"none"`` with a message —
    absence is reported, never silently dropped.
    """
    catalog = _column_catalog()
    await _require_catalog_conn_access(connection_id, _user)
    from core.schema_catalog import normalize_table_name, schedule_topup

    entries = await asyncio.to_thread(catalog.list_entries, connection_id)
    conn_raw = await asyncio.to_thread(_db_manager.get_connection_raw,
                                       connection_id)
    registered = [
        normalize_table_name(str(rt.get("name") or "").strip())
        for rt in ((conn_raw or {}).get("config") or {}).get("registered_tables") or []
        if isinstance(rt, dict) and str(rt.get("name") or "").strip()
    ]
    all_names = list(dict.fromkeys(registered + sorted(entries.keys())))
    tables = {
        name: catalog.build_response(entries.get(name), table_name=name)
        for name in all_names
    }
    if _conn_manager is not None and any(
            t["source"] == "none" for t in tables.values()):
        schedule_topup(_db_manager, _conn_manager, connection_id,
                       reason="bulk read found tables with no columns")
    return {"tables": tables}


@router.post("/api/catalog/columns/refresh")
async def refresh_catalog_columns(
    body: ColumnsRefreshBody,
    _user: dict = Depends(get_current_user),
):
    """EXPLICIT refresh — the only user-triggered path that reads the source.

    Body: ``{"connection_id": N, "table": "t"}`` or
    ``{"connection_id": N, "tables": ["t1","t2"]}``.

    Returns ``{"refreshed":[...], "failed":[{"table","reason"}],
    "columns": ...}`` where ``columns`` is the per-table contract object
    when a single ``table`` was named, or ``{name: object}`` when
    ``tables`` was used.  Refreshed tables report ``source:"source"``
    (this response really did come from the source); a failed table keeps
    its previously saved columns and the failure reason is recorded in the
    catalog AND returned — a failed refresh never erases what we know.
    """
    catalog = _column_catalog()
    if _conn_manager is None:
        raise HTTPException(status_code=503,
                            detail="Metadata Catalog not initialised")
    await _require_catalog_conn_access(body.connection_id, _user)

    single = body.table is not None and str(body.table).strip() != ""
    names = [str(body.table).strip()] if single else [
        str(t).strip() for t in (body.tables or []) if str(t).strip()
    ]
    if not names:
        raise HTTPException(status_code=400,
                            detail="Provide 'table' or a non-empty 'tables' list")
    from core.schema_catalog import refresh_max_tables_per_call, \
        refresh_timeout_seconds
    cap = refresh_max_tables_per_call()
    if len(names) > cap:
        raise HTTPException(
            status_code=400,
            detail=f"Refresh accepts at most {cap} tables per call "
                   f"(got {len(names)}); split the request",
        )

    from core.schema_reader import SchemaReader, SchemaReadError
    reader = SchemaReader(_db_manager, _conn_manager)
    username = _user.get("username", "") or ""
    timeout = refresh_timeout_seconds()

    refreshed: List[str] = []
    failed: List[dict] = []
    per_table: Dict[str, dict] = {}
    for name in names:
        try:
            await asyncio.wait_for(
                reader.read(body.connection_id, name, username=username,
                            refresh=True, stale_on_error=False,
                            catalog_source="refresh"),
                timeout=timeout,
            )
            refreshed.append(name)
        except (SchemaReadError, asyncio.TimeoutError) as exc:
            reason = str(exc) or exc.__class__.__name__
            if isinstance(exc, asyncio.TimeoutError):
                reason = f"source read timed out after {timeout}s"
            await asyncio.to_thread(catalog.record_failure,
                                    body.connection_id, name, reason)
            failed.append({"table": name, "reason": reason})
        except Exception as exc:  # noqa: BLE001 — one table must not abort the rest
            # Unexpected class: record + surface it loudly, keep going.
            logger.exception("Unexpected error refreshing columns for "
                             "conn=%s table=%s", body.connection_id, name)
            reason = f"{exc.__class__.__name__}: {exc}"
            await asyncio.to_thread(catalog.record_failure,
                                    body.connection_id, name, reason)
            failed.append({"table": name, "reason": reason})
        entry = await asyncio.to_thread(catalog.get_entry,
                                        body.connection_id, name)
        resp = catalog.build_response(entry, table_name=name)
        if name in refreshed:
            resp["source"] = "source"
        per_table[name] = resp

    return {
        "refreshed": refreshed,
        "failed": failed,
        "columns": per_table[names[0]] if single else per_table,
    }
