"""Netcool / OMNIbus event contract (BRD §12).

Netcool is the bank's event console, so it — not an inbox and not a WebSocket
— is where these alerts land.  Nothing here talks to a network: this module
turns an ``acting_time.Alert`` (or any other platform condition) into the
EVENT BODY Netcool expects, and hands it to the existing durable
``notification_queue`` so the console being unreachable can never fail a feed.

The two mistakes that make a Netcool integration hated, both designed against
here:

1. **Never sending a resolution event.**  An alert raised at 04:19 and cleared
   by an arrival at 04:31 must send ``Type = 2``.  Without it the console
   fills with stale alerts, operators learn to ignore the AlertGroup, and the
   real one is missed.  So ``build_event`` REFUSES to build a problem event
   that has no stated clear condition (FR-ALT-01) — if a clear cannot be
   stated, the alert must not be raised.

2. **An unstable Identifier.**  OMNIbus deduplicates on ``Identifier``: an
   event whose Identifier matches an open alert increments its ``Tally``
   instead of creating a new row.  Including a timestamp or a run id defeats
   that — every poll cycle creates a new row.  The Identifier here is keyed on
   the ENVIRONMENT, the alert type, the OBJECT and the BUSINESS DATE, and
   deliberately excludes the feed and the run so 34 blocked feeds raise ONE
   alert (FR-ALT-02).

Transport is a site decision (EIF probe, SNMP trap, or a REST gateway in front
of ObjectServer) and is NOT chosen here: the event is enqueued, and a sender
drains the queue.  See §18 — the transport, endpoint, agreed Node/AlertGroup
naming and the submission rate limit are inputs owed by the Netcool team.
"""
from __future__ import annotations

import logging
import re
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import date
from typing import Any

logger = logging.getLogger(__name__)

# ── Netcool vocabulary ────────────────────────────────────────────────────

TYPE_PROBLEM = 1
TYPE_RESOLUTION = 2

SEVERITY_CLEAR = 0
SEVERITY_INDETERMINATE = 1
SEVERITY_WARNING = 2
SEVERITY_MINOR = 3
SEVERITY_MAJOR = 4
SEVERITY_CRITICAL = 5

#: Lets the console route and suppress by CLASS rather than by individual
#: alert, which is what makes ownership routing possible at all (§18).
GROUP_DEPENDENCY = "FEED_DEPENDENCY"
GROUP_SLA = "FEED_SLA"
GROUP_COMPLETENESS = "FEED_COMPLETENESS"
GROUP_DELIVERY = "FEED_DELIVERY"
#: 2026-09-28 -- a REPORT's promise ("fresh and served by 07:00 London")
#: missed for a business date (core/reports/slo.py).  Its own group because
#: it is owned by the report's team, not the feed operators: routing it
#: under FEED_SLA would page the wrong queue.
GROUP_REPORT_SLO = "REPORT_SLO"
#: 2026-10-17 -- a PUBLISHED API's alerts (error rate, latency, consumers
#: rate-limited, a dependency gone, a sunset due; core/published_api/alerts.py):
#: owned by the API's publisher, not the feed operators.  The six API alert
#: kinds are SEEDED with ``published_views.alert_group`` (default this), which
#: must be a member here; the console team maps the group
#: (docs/PUBLISHED_API_INVENTORY_DASHBOARD_DESIGN_2026_10_17.html §8 Q11).
GROUP_PUBLISHED_API = "PUBLISHED_API"
#: 2026-10-17 -- a PLATFORM component (a pod, a daemon, a dependency: core/
#: component_health/) is down / degraded / unknown.  Owned by the platform
#: team, not the feed operators.  The word the console maps is the declared
#: key component_health.alert_group (default "PLATFORM"); the Netcool console
#: team must map it before the first event routes.
GROUP_PLATFORM = "PLATFORM"

ALERT_GROUPS = frozenset({GROUP_DEPENDENCY, GROUP_SLA, GROUP_COMPLETENESS,
                          GROUP_DELIVERY, GROUP_REPORT_SLO, GROUP_PUBLISHED_API,
                          GROUP_PLATFORM})

#: Which group each acting-time rung belongs to.  Overdue is a DEPENDENCY
#: problem; everything past the decision deadline is an SLA problem — they are
#: owned by different people and must route differently.
STAGE_GROUP = {
    "overdue":          GROUP_DEPENDENCY,
    "decision_due":     GROUP_DEPENDENCY,
    "deadline_passed":  GROUP_SLA,
    "breached":         GROUP_SLA,
}

#: Summary is what a human reads at 04:50.  OMNIbus truncates long values, and
#: a truncated line that loses the deadline is worse than a short one.
MAX_SUMMARY = 255

#: ``:`` is deliberately ABSENT from the safe set even though the
#: Identifier is colon-joined: a name containing one would forge extra
#: separators, so two different objects could produce the SAME
#: Identifier and the console would show unrelated problems as one
#: alert that clearing either would close.
_IDENT_UNSAFE = re.compile(r"[^A-Za-z0-9_.-]")


class NetcoolContractError(ValueError):
    """A refusal to build an event that would damage the console.

    Its own type because the correct handling is to FIX THE CALL, never to
    fall back to a best-effort event: a malformed Identifier is exactly how a
    console fills with duplicates nobody can clear.
    """


@dataclass(frozen=True)
class NetcoolEvent:
    identifier: str
    node: str
    alert_group: str
    alert_key: str
    severity: int
    summary: str
    type: int
    expire_time: int | None = None
    qs_run_id: str | None = None
    qs_feed: str | None = None
    qs_business_date: str | None = None
    qs_url: str | None = None

    def to_dict(self) -> dict:
        """The wire body.  Field names are OMNIbus's, not ours — a renaming
        here would have to be undone in whatever probe the site runs."""
        body = {
            "Identifier": self.identifier,
            "Node": self.node,
            "AlertGroup": self.alert_group,
            "AlertKey": self.alert_key,
            "Severity": self.severity,
            "Summary": self.summary,
            "Type": self.type,
        }
        if self.expire_time is not None:
            body["ExpireTime"] = self.expire_time
        for key, value in (("QSRunId", self.qs_run_id),
                           ("QSFeed", self.qs_feed),
                           ("QSBusinessDate", self.qs_business_date),
                           ("QSUrl", self.qs_url)):
            if value:
                body[key] = value
        return body


def build_identifier(env: str, alert_type: str, obj: str,
                     business_date: date) -> str:
    """``QS:<env>:<alert_type>:<object>:<business_date>``.

    Business date is IN the key so today's problem is not folded into
    yesterday's open alert; the feed and the run are OUT of it so one broken
    dependency does not raise one alert per blocked feed.
    """
    for name, value in (("env", env), ("alert_type", alert_type),
                        ("object", obj)):
        if not str(value or "").strip():
            # The env case NAMES THE KEY TO SET.  This refusal was reached on
            # every breach for weeks and the message sent the reader looking
            # for a bug in the alert, not for an unset deployment knob
            # (2026-09-07).
            hint = ("  Set app.environment (or QUERYSTUDIO_APP_ENVIRONMENT) "
                    "to this deployment's name, e.g. UAT or PROD — no value "
                    "is guessed, because an alert labelled with the wrong "
                    "environment is worse than no alert."
                    if name == "env" else "")
            raise NetcoolContractError(
                f"Netcool Identifier needs a non-empty {name} — an Identifier "
                f"with a blank part collides with every other blank one and "
                f"the console shows them as the same problem.{hint}")
    parts = [_IDENT_UNSAFE.sub("_", str(p).strip())
             for p in (env, alert_type, obj)]
    return "QS:" + ":".join(parts) + ":" + business_date.isoformat()


def build_event(*, env: str, alert_type: str, obj: str, business_date: date,
                severity: int, summary: str, alert_group: str,
                clears_when: str, node: str | None = None,
                type_: int = TYPE_PROBLEM, expire_time: int | None = None,
                run_id: str | None = None, feed: str | None = None,
                url: str | None = None,
                identifier_obj: str | None = None) -> NetcoolEvent:
    """Build one event body, refusing the two console-damaging mistakes.

    ``identifier_obj`` (default ``obj``) is the Identifier's object when ONE
    object carries several distinct problems (a published API's thresholds,
    2026-10-23): the AlertKey stays the object, the Identifier tells them apart.

    ``clears_when`` is REQUIRED on a problem event and is not sent to the
    console — it exists to make the caller state one.  FR-ALT-01: every alert
    this platform raises must have a defined clear condition, and if one
    cannot be stated the alert must not be raised.
    """
    if alert_group not in ALERT_GROUPS:
        raise NetcoolContractError(
            f"AlertGroup {alert_group!r} is not one of {sorted(ALERT_GROUPS)} "
            f"— the console routes and suppresses BY GROUP, so an unknown one "
            f"reaches nobody's queue")
    if type_ == TYPE_PROBLEM and not str(clears_when or "").strip():
        raise NetcoolContractError(
            f"refusing to raise {alert_type!r} for {obj!r}: no clear condition "
            f"was stated.  An alert that never clears fills the console, "
            f"operators learn to ignore the AlertGroup, and the real one is "
            f"missed")
    if not (SEVERITY_CLEAR <= int(severity) <= SEVERITY_CRITICAL):
        raise NetcoolContractError(
            f"severity {severity} is outside OMNIbus's 0-5 range")
    text = str(summary or "").strip()
    if not text:
        raise NetcoolContractError(
            f"refusing to raise {alert_type!r} for {obj!r} with an empty "
            f"Summary — Summary is the only thing a human reads at 04:50")
    if len(text) > MAX_SUMMARY:
        logger.warning(
            "[netcool] Summary for %s:%s is %d chars and will be truncated to "
            "%d — check the deadline survives the cut",
            alert_type, obj, len(text), MAX_SUMMARY)
        text = text[:MAX_SUMMARY]
    return NetcoolEvent(
        identifier=build_identifier(env, alert_type, identifier_obj or obj, business_date),
        node=str(node or env),
        alert_group=alert_group,
        alert_key=str(obj),
        severity=int(severity),
        summary=text,
        type=int(type_),
        expire_time=expire_time,
        qs_run_id=run_id,
        qs_feed=feed,
        qs_business_date=business_date.isoformat(),
        qs_url=url,
    )


def event_from_alert(alert: Any, *, env: str, node: str | None = None,
                     url: str | None = None) -> NetcoolEvent:
    """Map an ``acting_time.Alert`` onto the wire contract."""
    group = STAGE_GROUP.get(alert.stage)
    if group is None:
        raise NetcoolContractError(
            f"acting-time stage {alert.stage!r} has no declared AlertGroup — "
            f"add it to STAGE_GROUP rather than defaulting, because a wrong "
            f"group routes the alert to the wrong support queue")
    return build_event(
        env=env, alert_type=alert.stage.upper(), obj=alert.dependency_name,
        business_date=alert.business_date, severity=alert.severity,
        summary=alert.summary, alert_group=group,
        clears_when=alert.clears_when, node=node,
        feed=(alert.blocked_feeds[0] if alert.blocked_feeds else None),
        url=url,
    )


def resolution_for(event: NetcoolEvent) -> NetcoolEvent:
    """The ``Type = 2`` event that closes *event*.

    Same Identifier — that is the whole mechanism; a resolution with a
    different Identifier closes nothing and adds a row.
    """
    return NetcoolEvent(
        identifier=event.identifier,
        node=event.node,
        alert_group=event.alert_group,
        alert_key=event.alert_key,
        severity=SEVERITY_CLEAR,
        summary=f"CLEARED: {event.summary}"[:MAX_SUMMARY],
        type=TYPE_RESOLUTION,
        qs_run_id=event.qs_run_id,
        qs_feed=event.qs_feed,
        qs_business_date=event.qs_business_date,
        qs_url=event.qs_url,
    )


def heartbeat_event(*, env: str, business_date: date,
                    node: str | None = None) -> NetcoolEvent:
    """A low-severity heartbeat (FR-ALT-07).

    Netcool cannot tell "nothing is wrong" from "the sender is dead".  A
    heartbeat on a fixed interval, with a console rule that alerts on its
    ABSENCE, is the standard answer and costs almost nothing.
    """
    return build_event(
        env=env, alert_type="HEARTBEAT", obj="querystudio-feed-platform",
        business_date=business_date, severity=SEVERITY_INDETERMINATE,
        summary="QueryStudio feed platform alert sender is alive",
        alert_group=GROUP_SLA,
        clears_when="the next heartbeat, or the console's absence rule",
        node=node, expire_time=900)


# ── Store-and-forward ─────────────────────────────────────────────────────

def enqueue_event(session_factory, event: NetcoolEvent, *,
                  enqueue_fn=None) -> int | None:
    """Hand the event to the durable queue.  FAIL-OPEN, and audible.

    FR-ALT-04: a Netcool outage delays alerts; it must never delay or fail a
    feed.  The queue is also the audit (FR-ALT-05) — what was raised, when,
    and whether it was accepted, which is what answers "why did nobody get
    paged?" afterwards.

    Returns the queued id, or None when the enqueue itself failed — logged at
    ERROR, because silently dropping an alert is the worst possible failure of
    an alerting system.
    """
    if enqueue_fn is None:
        from core.notification_queue import enqueue as enqueue_fn
    payload = {"kind": "netcool_event", "event": event.to_dict()}
    try:
        return enqueue_fn(session_factory, payload)
    except Exception as exc:
        logger.error(
            "[netcool] could not enqueue %s (%s) — THIS ALERT IS LOST. "
            "Identifier=%s severity=%s summary=%.120s",
            event.alert_group, exc, event.identifier, event.severity,
            event.summary)
        return None


@dataclass(frozen=True)
class AlertOutcome:
    """What actually happened to ONE alert.  Three OPPOSITE findings.

    * ``queue_id is not None``           — raised.
    * ``refusal is not None``            — the contract REFUSED it (a blank
      environment, an unknown AlertGroup, no clear condition, an empty
      Summary).  It was never built and never will be until config or the
      caller changes.
    * ``event is not None`` and both of the above are None — built, and the
      ENQUEUE failed.  Transient; already screamed at ERROR as
      "THIS ALERT IS LOST".

    They are separated because a refusal and a lost enqueue send an operator
    to different places: one is a misconfiguration, the other is the queue.
    Folding them into a single "not raised" count is how a permanently
    unalertable pod reads as a flaky one.
    """
    alert: Any
    event: "NetcoolEvent | None"
    queue_id: Any | None
    refusal: str | None


def enqueue_alerts_with_outcome(session_factory, alerts: Sequence[Any], *,
                                env: str, node: str | None = None,
                                url: str | None = None,
                                enqueue_fn=None) -> list:
    """One :class:`AlertOutcome` per alert, IN THE ORDER GIVEN.

    Never lets one bad alert stop the rest: an operator who receives nothing
    cannot tell "quiet night" from "the sender died on alert 3".

    Replaced a wrapper that returned only the ids it managed to queue —
    the right answer to "what got sent" and the WRONG one to "what
    happened": a caller zipping that shorter list back against ``alerts``
    pairs alert 0 with alert 1's id the moment anything is refused.  This
    function is positional, so counting refusals and mapping raised alerts
    back to their events are both exact.

    The built event is returned too, so a caller that needs it (to send a
    resolution later) does not build it a SECOND time — two constructions of
    the same event are free to disagree.
    """
    outcomes = []
    for alert in alerts:
        try:
            event = event_from_alert(alert, env=env, node=node, url=url)
        except NetcoolContractError as exc:
            logger.error(
                "[netcool] refusing to send an alert for %s: %s",
                getattr(alert, "dependency_name", "?"), exc)
            outcomes.append(AlertOutcome(alert=alert, event=None,
                                         queue_id=None, refusal=str(exc)))
            continue
        qid = enqueue_event(session_factory, event, enqueue_fn=enqueue_fn)
        outcomes.append(AlertOutcome(alert=alert, event=event,
                                     queue_id=qid, refusal=None))
    return outcomes
